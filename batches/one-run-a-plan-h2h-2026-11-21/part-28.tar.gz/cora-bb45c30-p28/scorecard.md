# Doctrine scorecard: cora-bb45c30-p28

### Scorecard: cora-bb45c30-p28

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 285 |
| L0524 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 335 |
| L0612 | 6 | 1 | Opponent | no | 8 | 5 | 1 | 0 | 1 | 0 | 0 | 165 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 461 |
| L0628 | 4 | 1 | Opponent | no | 10 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 5.0 | 0.7 | 3.0 | 0.0 | 0.0 | 0.0 | 360.3 |
| **Average** | | | Opponent | 0% | 9.0 | 5.0 | 0.7 | 1.3 | 0.3 | 0.0 | 0.0 | 55.0 |

### KPIs: cora-bb45c30-p28

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 16) | 48% (15 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | - | 50% (15 of 30) | 50% (15 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 60% (15 of 25) | 60% (15 of 25) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 75% (4507 of 6000) | 65% (3910 of 5998) | 70% (8417 of 11998) |
|   infantry points that never fought | lower | 79% (1760 of 2232) | 100% (694 of 694) | 84% (2454 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (14 of 27) | 61% (14 of 23) | 56% (28 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.3 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2035 of 4232) | 64% (3716 of 5787) | 57% (5751 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (40%) | 2.0 (40%) |
| MARCHED: its unit marched | - | 1.3 (27%) | 1.3 (27%) |
| IN COMBAT: engaged in combat | - | 1.7 (33%) | 1.7 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.3 | 5.0 | 0.7 | 1.0 |
| not cast | 2.0 | 2.7 | 5.0 | 3.3 | 23.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (100%) | 2.0 (40%) | 0.3 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (27%) | 0.7 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.7 (33%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (70%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (99%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (142 of 216) | 73% (8 of 11) | 66% (150 of 227) |
|   cavalry | 45% (9 of 20) | 50% (2 of 4) | 46% (11 of 24) |
|   character | 87% (26 of 30) | - | 87% (26 of 30) |
|   infantry | 50% (27 of 54) | - | 50% (27 of 54) |
|   monster | 82% (9 of 11) | - | 82% (9 of 11) |
|   war machine | 70% (71 of 101) | 86% (6 of 7) | 71% (77 of 108) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (16%) | 0.3 (33%) | 4.3 (17%) |
| CHARGED: it charged | 1.3 (5%) | 0.0 (0%) | 1.3 (5%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (33%) | 0.3 (1%) |
| NO TARGET IN RANGE | 10.7 (43%) | 0.3 (33%) | 11.0 (43%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 6.3 (26%) | 0.0 (0%) | 6.3 (25%) |
| SHELTERED: the target was sheltered | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.0 | 83% | 4.0 pts | 16 pts |
| character | 9.7 | 3.7 | 79% | 7.9 pts | 76 pts |
| infantry | 18.7 | 5.3 | 75% | 7.2 pts | 135 pts |
| monster | 3.3 | 0.7 | 80% | 4.6 pts | 15 pts |
| war machine | 25.7 | 10.0 | 77% | 13.2 pts | 339 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 3.0 | 2.3 |
| Charges that made contact a game | 1.3 | 1.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 1.00 declared, 1.00 contact (3 units) | 1.00 declared, 1.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.24 declared, 0.19 contact (21 units) | 0.42 declared, 0.08 contact (12 units) | 0.30 declared, 0.15 contact (33 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (1 of 1) | 50% (1 of 2) | 57% (4 of 7) |
| Character in a unit | 50% (4 of 8) | 50% (2 of 4) | 100% (1 of 1) | 54% (7 of 13) |
| Character on its own | - | 67% (2 of 3) | 50% (1 of 2) | 60% (3 of 5) |
| Infantry | 29% (2 of 7) | 50% (3 of 6) | - | 38% (5 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 67% (2 of 3); on the table 67% | - | 75% | 52% (14 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (2 of 2); on the table 100% | 50% (9 of 18) | 54% | 44% (4 of 9) | 100% (3 of 3); 10.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | - | 33% (2 of 6) | 94% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 67% (4 of 6) | 47% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p28, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 100% (1) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 1.00 | 0.00 | 1.00 |

### Quality by phase: cora-bb45c30-p28

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 80% (4 of 5) | 56% (5 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 64% (47 of 73) | 36% (5 of 14) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 33% (4 of 12) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 67% (4 of 6) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 3.0 | 1.3 |
| Movement | Points that never moved of their own | 360.3 | 55.0 |
| Movement | Fights charged into per game | 1.3 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net -60 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 1 of 3, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net +14 | 1 of 3, net +233 |
| Shooting | Shots by shooting units (incl. breath weapons) | 25.0 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (46 of 75) | 0% (0 of 3) |
| Shooting | Points destroyed by shooting units | 109.3 | 0.0 |
| Shooting | War machine shots | 23.7 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (44 of 71) | 0% (0 of 6) |
| Shooting | Points destroyed by war machines | 0.0 | 40.0 |
| Magic | Magic missiles cast | - | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 50% (5 of 10) |
| Magic | Wounds caused by magic missiles | - | 2.3 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 55.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.3 / 0.3 / 0.3 / 0.7 |
| Combat | Points destroyed in combat | 16.7 | 58.3 |
| Combat | Points run down | 13.7 | 77.7 |
| Combat | Net points per charged fight, damage counted | +12 | +74 |
| Combat | Net per 100 charger points, damage counted | +17.0 | +22.1 |
| Combat | First round won (charged fights) | 75% | 75% |
| Combat | Net points per charged fight | -5 | +74 |
| Combat | Net points per supported fight / lone fight | - / -5 | +233 / +22 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 2 of 4 |
| Game | Points lost | 231.0 | 194.7 |
| Game | VP from objectives | 716.7 | 540.0 |
| Game | Lone holders (player turns) | 0.0 | 9.0 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +136 VP
- Points traded per game (both sides' losses): 426
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p28

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +13.8 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 6.3 | +95.0 | 0.0 | 0.0 | 8.7 | +144.8 | 0.0 | 72.3 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 217.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 17.3 | +349.9 | 521.7 | 76.7 | 2.0 | +166.4 | 80.0 | 55.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 77.7 | 0.0 |
| CAST JOB | - | - | - | - | 1.3 | +15.5 | 40.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.3 | +2.5 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +20.8 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 14.7 | -363.5 | 0.0 | 425.3 | 18.7 | -799.3 | 0.0 | 218.7 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 13.7 | 0.0 | 1.3 | +0.0 | 35.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 33.3 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 11.3 | -765.3 | 0.0 | 77.7 | 3.7 | -152.7 | 0.0 | 72.3 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -23.9 | 38.3 | 0.0 |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 0.0 | 4.3 | +35.7 | 0.0 | 55.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -8.1 | 77.7 | 0.0 |
| EXACT ROUND | 1.0 | +2.5 | 13.7 | 0.0 | 2.0 | +9.0 | 73.3 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 193.7 | 16.7 |
| FALLBACK BY WORTH | 0.7 | +0.5 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 23.3 | +283.8 | 0.0 | 37.0 |
| FEATURE BUFFS | 0.7 | +0.5 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +0.7 | 13.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 141.7 | +4686.1 | 1461.3 | 904.0 | 63.3 | +2267.4 | 428.7 | 406.0 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 112.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +51.4 | 13.7 | 20.0 | 3.0 | +160.8 | 228.7 | 16.7 |
| FREED FROM HIS FIGHT | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.7 | +291.2 | 0.0 | 0.0 | 1.0 | +33.7 | 0.0 | 0.0 |
| GUN FIGURES | 2.7 | +0.0 | 37.0 | 0.0 | - | - | - | - |
| GUN MASK | 5.0 | +69.2 | 0.0 | 110.0 | 1.3 | +77.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 6.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 225.3 | 8.7 | +0.0 | 0.0 | 144.7 |
| HIS CHARGE LIST | 14.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 72.3 |
| HIS MOVE AND SHOT | 3.3 | -16.3 | 0.0 | 40.0 | 3.0 | -25.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 72.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 50.7 | +1546.1 | 0.0 | 535.3 | 42.7 | +4718.3 | 0.0 | 246.0 |
| HIS SHOTS BY HIS RUN | 25.3 | +215.4 | 0.0 | 535.3 | 37.7 | +1219.5 | 0.0 | 246.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +49.7 | 38.3 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.7 | +0.0 | 0.0 | 0.0 | 13.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.3 | +1065.1 | 0.0 | 0.0 | 8.3 | +917.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -5.8 | 13.7 | 0.0 | 2.7 | -100.2 | 228.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +112.7 | 0.0 | 72.3 |
| IDLE COST | - | - | - | - | 15.3 | -368.7 | 0.0 | 139.7 |
| JOINT CHARGE NOW | 0.3 | -5.6 | 0.0 | 0.0 | 0.7 | -44.7 | 155.3 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 72.3 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +4.6 | 13.7 | 20.0 | 1.3 | -0.4 | 193.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | -14.2 | 0.0 | 35.0 | 2.0 | +1.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +13.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +47.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | +44.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.3 | +1.2 | 0.0 | 0.0 | 1.7 | +8.0 | 0.0 | 0.0 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 0.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 7.0 | +44.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 8.7 | +47.9 | 0.0 | 0.0 |
| MODEL FACING | 2.3 | +583.5 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 1.3 | +25.1 | 0.0 | 0.0 | 2.0 | +123.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +275.0 | 0.0 | 0.0 | 3.7 | +153.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 2.0 | +123.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -11.6 | 13.7 | 0.0 | 2.0 | -43.3 | 73.3 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 1.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -108.3 | 0.0 | 0.0 | 2.3 | -52.6 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.7 | +18.3 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 35.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -10.3 | 0.0 | 112.7 | 1.7 | -33.3 | 0.0 | 72.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +5.2 | 77.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | +15.9 | 0.0 | 0.0 | 2.7 | -180.1 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +0.5 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 0.0 |
| PLAN RESULT | 62.3 | +806.1 | 464.7 | 442.0 | 30.0 | +154.7 | 80.0 | 279.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 4.7 | -66.6 | 0.0 | 0.0 | 4.0 | -14.6 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.7 | +1028.3 | 148.0 | 60.0 | 2.3 | +930.7 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +10.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +80.0 | 0.0 | 0.0 | 0.7 | +38.2 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +8.8 | 0.0 | 13.7 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +54.8 | 13.7 | 20.0 | 1.0 | +46.1 | 35.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -14.2 | 0.0 | 16.7 |
| RUN DOWN | 1.0 | -15.4 | 13.7 | 0.0 | 2.0 | -4.3 | 190.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -162.6 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -6.5 | 0.0 | 0.0 | 2.0 | -87.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +7.3 | 0.0 | 0.0 | 3.0 | +116.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 2.0 | +45.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 24.0 | +0.0 | 0.0 | 154.3 | 3.0 | +0.0 | 0.0 | 55.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +32.1 | 0.0 | 0.0 | 2.7 | +13.9 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.0 | -7.6 | 13.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 30.7 | +1008.3 | 0.0 | 420.0 | 21.7 | -555.6 | 0.0 | 101.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 34.0 | +1159.2 | 0.0 | 189.3 | 3.0 | +191.2 | 0.0 | 92.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +148.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | +6.5 | 73.3 | 0.0 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.4 | 35.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 74.0 |
| STANDS STILL | 107.3 | +0.0 | 1447.7 | 468.7 | 15.3 | +0.0 | 200.0 | 110.0 |
| STAY WORTH | 58.0 | +107.3 | 435.0 | 135.0 | 7.7 | +150.4 | 200.0 | 202.0 |
| SUPPORT ADDS | 2.0 | +45.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 16.7 |
| SUPPORT WORKED OUT | 2.0 | +45.0 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | - | - | - | - | 2.7 | +59.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +2.5 | 0.0 | 13.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 77.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 55.3 | +0.0 | 0.0 | 362.0 | 30.7 | +0.0 | 0.0 | 194.7 |
| TIED UP BY THE SUM | 0.7 | +19.0 | 13.7 | 0.0 | 0.7 | +68.8 | 35.0 | 0.0 |
| TIME ON OUR SIDE | 56.3 | +620.6 | 0.0 | 420.7 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | -14.5 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.3 | +8.7 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +44.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -105.2 | 0.0 | 155.3 | 0.7 | -99.1 | 0.0 | 144.7 |
| WHOLE FIGHT GAIN | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +51.8 | 77.7 | 0.0 |
| WOUNDS ON THE RANKS | 3.3 | +14.5 | 0.0 | 0.0 | 3.3 | +390.9 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p28

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 280 | 280 | 94 | 31.33 | +3215 | +34.2 |
| HOLDER ASSIGNMENT | 56 | 56 | 52 | 17.33 | +3694 | +71.0 |
| HIS SHOTS BY HIS RUN | 189 | 183 | 51 | 17.00 | +1014 | +19.9 |
| SHOT RISK POINTS | 157 | 157 | 46 | 15.33 | +1940 | +42.2 |
| ARMY TABLE | 45 | 45 | 35 | 11.67 | +734 | +21.0 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| TIME ON OUR SIDE | 169 | 153 | 29 | 9.67 | +59 | +2.0 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -483 | -20.1 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| CHARGE LOSSES | 100 | 100 | 16 | 5.33 | +1053 | +65.8 |
| COVER ONCE | 45 | 40 | 14 | 4.67 | +95 | +6.8 |
| FIVE ACTION | 615 | 609 | 14 | 4.67 | +283 | +20.2 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 12 | 4.00 | +49 | +4.0 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| IDLE COST | 46 | 42 | 10 | 3.33 | +335 | +33.5 |
| CANNON PLANNED TARGET | 58 | 58 | 9 | 3.00 | +21 | +2.4 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 9 | 3.00 | -244 | -27.1 |
| FOUR ROUNDS | 14 | 14 | 8 | 2.67 | +144 | +18.0 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +55 | +6.8 |
| GOAL WALK | 14 | 14 | 7 | 2.33 | +678 | +96.8 |
| MODEL FACING | 7 | 7 | 7 | 2.33 | +1751 | +250.1 |
| MOVE TO CHARGE COMPUTED | 10 | 8 | 7 | 2.33 | +140 | +20.1 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SET UP BY THE SET | 13 | 13 | 7 | 2.33 | +5 | +0.7 |
| QUARTER ODDS | 60 | 60 | 6 | 2.00 | +414 | +68.9 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 6 | 6 | 5 | 1.67 | +136 | +27.2 |
| RISK BY ARC | 8 | 8 | 5 | 1.67 | +101 | +20.3 |
| SHOTS AFTER THE MOVES | 23 | 23 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 111 | 95 | 5 | 1.67 | +331 | +66.2 |
| WOUNDS ON THE RANKS | 20 | 20 | 5 | 1.67 | +319 | +63.9 |
| FALLS SHORT | 70 | 65 | 4 | 1.33 | +67 | +16.9 |
| LEGAL CHARGES ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +83 | +20.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| GUN MASK | 19 | 19 | 3 | 1.00 | +127 | +42.2 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -151 | -50.3 |
| MOVE ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 27 | 25 | 3 | 1.00 | +151 | +50.4 |
| SET UP TOGETHER | 6 | 6 | 3 | 1.00 | +72 | +23.8 |
| STAY WORTH | 197 | 185 | 3 | 1.00 | +21 | +7.0 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -19 | -9.3 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +40 | +19.8 |
| MISSILES IN THE MOVE | 21 | 17 | 2 | 0.67 | +4 | +2.0 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +48 | +24.1 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT ADDS | 6 | 6 | 2 | 0.67 | +3 | +1.3 |
| SUPPORT WORKED OUT | 6 | 6 | 2 | 0.67 | +3 | +1.3 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +134 | +66.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +41 | +41.4 |
| CAST JOB | 4 | 4 | 1 | 0.33 | +8 | +7.6 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| FALLBACK BY WORTH | 3 | 3 | 1 | 0.33 | +2 | +1.5 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +29 | +29.2 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +167 | +167.4 |
| LOST AFTER ESCAPE | 8 | 8 | 1 | 0.33 | +5 | +4.8 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +3 | +3.0 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +36 | +35.6 |
| NEARER NOT NEEDED | 29 | 27 | 1 | 0.33 | +28 | +28.3 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +7 | +6.8 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -3 | -3.3 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.6 |
| THE ROW IN ITS ORDER | 9 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -44 | -43.5 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +7 | +6.8 |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 43 | 43 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 9 | 9 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 54 | 54 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 65 | 65 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 34 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 80 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 11 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 23 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 10 | 10 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 12 | 9 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 277 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 81 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 26 | 20 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 368 | 364 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 8 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 258 | not checked | - | - | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p28

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 2.33 | 21.6 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 0.33 | 27.1 |
| CHARGE NOW FIRST | rule | - | 0.67 | 9.3 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 78.9 |
| TURN GATE | gate | 0.67 | - | 4.0 |
| ARMY TABLE | rule | - | 0.33 | 10.6 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 5.5 |
| REFUSING RETIRES | rule | - | 0.33 | 3.3 |
| SET UP BY THE SET | rule | - | 0.33 | 35.5 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 43.5 |

### Plans: cora-bb45c30-p28

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 25% | 39 | 23 | 58% |
| Mine | join | 1.7 | 100% | 54 | 0 | 0% |
| Mine | move | 39.0 | 97% | 1070 | 0 | 0% |
| Mine | shoot | 20.3 | 61% | 535 | 783 | 147% |
| Opponent | charge | 1.7 | 20% | 103 | 35 | 34% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 23.3 | 96% | 705 | 0 | 0% |
| Opponent | shoot | 3.0 | 56% | 204 | 120 | 59% |
| Opponent | support | 1.0 | 100% | 25 | 0 | 0% |

### Battle groups: cora-bb45c30-p28

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p28

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 10 (13) | 10 | 0 | 0 | 38% | 2.5 | 5 (6) | 18 (6) | 0 (1) | 11 (11) | 0 (2) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 10 | 75% | 1.0 | 0 (1) | 0 (1) | 0 (2) | 0 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 73 | 33% | 1.0 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 123 (4) | 2 | 121 | 0 | 25% | 3.0 | 4 (1) | 206 (3) | - | 123 (4) | - |
| Mine | Shooter | 8 | 62 (8) | 3 | 59 | 18 | 25% | 2.3 | 82 (1) | 98 (4) | 9 (3) | 54 (6) | 82 (2) |
| Mine | War machine | 17 | 13 (17) | 13 | 0 | 14 | 12% | 1.4 | 0 (4) | 23 (9) | 0 (4) | 0 (3) | 16 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 25 | 33% | 4.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 24 (10) | 24 | 0 | 11 | 30% | 3.6 | 0 (3) | 47 (5) | 14 (2) | 29 (9) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 3 | 25 (3) | 0 | 25 | 0 | 67% | 6.0 | 0 (1) | 84 (1) | 0 (1) | 35 (2) | 0 (1) |
| Opponent | Holder | 6 | 76 (6) | 0 | 76 | 10 | 50% | 3.3 | 0 (1) | 90 (5) | - | 96 (5) | 0 (1) |
| Opponent | War machine | 2 | 36 (2) | 36 | 0 | 50 | 0% | 1.0 | - | 73 (1) | 0 (1) | - | 36 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: cora-bb45c30-p28

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 109 | 14 | 1.3 | 1.0 | 10 | 15 | -5 | 1 of 4 | 3 of 4 | - | -5 |
| Opponent | Grand Cathay | 1 | 285 | 348 | 3.0 | 1.3 | 116 | 0 | +116 | 1 of 3 | 3 of 3 | +233 | +58 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 50 | -50 | 1 of 1 | 0 of 1 | - | -50 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 95 | 116 | 1.3 | 1.2 | 87 | 12 | +74 | 2 of 4 | 3 of 4 | +233 | +22 |

### Effective charges: cora-bb45c30-p28

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net -60) | 0 | 0 | 0 | 0 | 3 (net +14) | 0 | 0% (0 of 4) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 0 | 1 (net +115) | 1 (net +0) | 1 (net +233) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: cora-bb45c30-p28

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 60 | 494 | -60 | 0 | 60 | -60 | -100.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 72 | 71 | +14 | 44 | 9 | +36 | +49.6 |
| Mine | All fights | 4 | 69 | 176 | -5 | 33 | 22 | +12 | +17.0 |
| Opponent | 76-89% | 1 | 379 | 115 | +115 | 115 | 0 | +115 | +30.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 539 | 183 | +233 | 233 | 0 | +233 | +43.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 379 | 105 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 1 | 50 | 239 | -50 | 0 | 50 | -50 | -100.0 |
| Opponent | All fights | 4 | 337 | 160 | +74 | 87 | 12 | +74 | +22.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p28 | move | 7 | 3 (43%) | 3 (43%) | 1 (14%) | 3 (43%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

# Doctrine scorecard: cora-bb45c30-p32

### Scorecard: cora-bb45c30-p32

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 7 | 2 | 1 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1335 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1431 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1431 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 100% | - | 3.0 | 7.0 | 2.0 | 1.0 | 0.0 | 0.0 | 140.0 |
| **Average** | | | Opponent | 0% | - | 2.0 | 2.0 | 2.0 | 1.0 | 0.0 | 0.0 | 0.0 |

### KPIs: cora-bb45c30-p32

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 11% (1 of 9) | 0% (0 of 7) | 6% (1 of 16) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 100% (6 of 6); on the table 100% | 100% (11 of 11); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 33% (4 of 12) | 29% (5 of 17) | 31% (9 of 29) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (4 of 11) | 56% (5 of 9) | 45% (9 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 25% (1 of 4) | 25% (1 of 4) |
| Points that never fought | lower | 31% (619 of 2000) | 16% (310 of 2000) | 23% (929 of 4000) |
|   infantry points that never fought | lower | 31% (177 of 569) | 0% (0 of 60) | 28% (177 of 629) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (5 of 8) | 75% (6 of 8) | 69% (11 of 16) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 50% (1 of 2); 0.7 uses a game | 75% (3 of 4); 1.2 uses a game |
| Bound items with another spell used |  | 20% (2 of 10); 0.7 uses a game | 0.0 uses a game | 20% (2 of 10); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (941 of 1860) | 68% (1245 of 1830) | 59% (2186 of 3690) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (50%) | 1.0 (25%) | 2.3 (35%) |
| MARCHED: its unit marched | 0.7 (25%) | 0.3 (8%) | 1.0 (15%) |
| IN COMBAT: engaged in combat | 0.3 (12%) | 0.7 (17%) | 1.0 (15%) |
| GONE: slain | 0.0 (0%) | 2.0 (50%) | 2.0 (30%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (12%) | 0.0 (0%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 0.3 | 2.7 | 3.0 | 0.0 | 1.0 |
| not cast | 2.3 | 1.3 | 2.7 | 6.7 | 0.7 | 14.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 2.3 (35%) | 0.3 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (15%) | 0.3 (50%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (12%) | 1.0 (15%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (43%) | 0.0 (0%) | 1.0 (38%) | 2.0 (30%) | 0.0 (0%) | 2.0 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (12%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (57%) | 0.0 (0%) | 1.0 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.3 a game | 1.3 a game |
| stood (cast and not dispelled) | 71% (5 of 7) | - | 71% (5 of 7) |
| the unit moved after it | 0% (0 of 5) | - | 0% (0 of 5) |
| it charged on its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| the enemy charged it first | 20% (1 of 5) | - | 20% (1 of 5) |
| it fought by the end of its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 80% (4 of 5) | - | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (20 of 33) | - | 61% (20 of 33) |
|   character | 42% (5 of 12) | - | 42% (5 of 12) |
|   infantry | 33% (3 of 9) | - | 33% (3 of 9) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (31%) | - | 1.3 (31%) |
| CHARGED: it charged | 1.0 (23%) | - | 1.0 (23%) |
| IN COMBAT: it fought this turn or the last | 0.3 (8%) | - | 0.3 (8%) |
| NO TARGET IN RANGE | 0.3 (8%) | - | 0.3 (8%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (23%) | - | 1.0 (23%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (8%) | - | 0.3 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 2.7 | 0.3 | 88% | 1.4 pts | 4 pts |
| infantry | 2.0 | 0.7 | 67% | 16.7 pts | 33 pts |
| war machine | 4.0 | 2.0 | 67% | 18.9 pts | 76 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 1.3 | 2.5 |
| Charges that made contact a game | 3.0 | 1.0 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.25 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.42 declared, 0.33 contact (24 units) | 0.17 declared, 0.13 contact (23 units) | 0.30 declared, 0.23 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Character on its own | 100% (3 of 3) | 67% (2 of 3) | 0% (0 of 2) | 62% (5 of 8) |
| Infantry | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 31% | 62% (5 of 8) | 100% (1 of 1); 2.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (6 of 6); on the table 100% | 33% (4 of 12) | 16% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p32, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 57% (4) | 67% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p32

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 70% (7 of 10) | - |
| Strategy | Shoot objectives carried out (shot that target) | 62% (15 of 24) | 33% (1 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Lone characters that fought | 100% (3 of 3) | 100% (5 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.0 | 2.0 |
| Movement | Points that never moved of their own | 140.0 | 0.0 |
| Movement | Fights charged into per game | 5.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 3, net -201 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (5 of 8) | - |
| Shooting | Points destroyed by shooting units | 116.7 | 0.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (6 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.3 / 0.3 / 0.0 | 0.3 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 300.7 | 201.3 |
| Combat | Points run down | 131.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -78 | -526 |
| Combat | Net per 100 charger points, damage counted | -25.0 | -259.8 |
| Combat | First round won (charged fights) | 40% | 100% |
| Combat | Net points per charged fight | -42 | -451 |
| Combat | Net points per supported fight / lone fight | - / -42 | - / -451 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 5 | 1 of 2 |
| Game | Points lost | 504.0 | 1705.0 |
| Game | VP from objectives | 700.0 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 0 of 1 ended games (of 3); mean margin (Mine - Opponent) +2054 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 2209
- Games not ended: 2 (L1335-1, L1431-1); findings 2, warnings 0

### Opponent rules: cora-bb45c30-p32

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 19.3 | +333.7 | 0.0 | 108.0 | 17.3 | +145.4 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.7 | 0.0 | 108.7 |
| BEST PRIZE | 0.3 | -17.6 | 131.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.7 | +33.8 | 270.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +2.0 | 0.0 | 54.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 0.7 | +3.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +13.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +31.3 | 0.0 | 54.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.3 | -450.2 | 0.0 | 54.0 | 14.0 | -811.9 | 0.0 | 116.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 0.0 | 147.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 170.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.0 | +183.2 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 4.0 | -318.8 | 0.0 | 0.0 | 3.3 | -240.1 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 1.0 | -40.6 | 131.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +146.1 | 0.0 | 0.0 | - | - | - | - |
| ELIXIR WORTH | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +3.2 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +10.2 | 0.0 | 147.3 | 0.3 | +5.1 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +3.9 | 131.0 | 147.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 17.0 | +144.4 | 0.0 | 0.0 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +21.3 | 131.0 | 0.0 | 0.3 | +2.2 | 0.0 | 0.0 |
| FIVE ACTION | 68.7 | +3428.2 | 634.3 | 309.3 | 40.7 | +1616.0 | 0.0 | 305.0 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +31.8 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 3.3 | +360.9 | 131.0 | 147.3 | 0.3 | +19.2 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.0 | -9.1 | 0.0 | 54.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +3.5 | 0.0 | 147.3 | - | - | - | - |
| GIVES UP | 0.3 | -9.7 | 131.0 | 0.0 | - | - | - | - |
| GOAL WALK | 6.7 | +310.9 | 0.0 | 0.0 | 8.3 | +393.3 | 0.0 | 0.0 |
| GUN MASK | 1.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 54.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -15.2 | 0.0 | 0.0 | 2.7 | -11.8 | 0.0 | 116.7 |
| HIS ONE QUARTER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 4.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 26.0 | +908.0 | 0.0 | 54.0 | 27.3 | +526.0 | 0.0 | 305.0 |
| HIS SHOTS BY HIS RUN | 22.0 | +549.6 | 0.0 | 54.0 | 33.7 | +794.8 | 0.0 | 305.0 |
| HIS TURN DENIED | 1.0 | +28.1 | 131.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 85.0 |
| HOLDER ASSIGNMENT | 7.0 | +693.7 | 0.0 | 0.0 | 4.0 | +308.7 | 0.0 | 85.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -98.1 | 131.0 | 0.0 | 0.3 | -1.8 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 9.0 | -139.9 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 247.7 | 147.3 | 2.7 | +0.0 | 147.3 | 18.3 |
| LOST AFTER ESCAPE | 2.0 | +13.6 | 131.0 | 147.3 | 0.3 | +0.1 | 0.0 | 0.0 |
| LOST CHARGE | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +4.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +74.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +25.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -67.0 | 0.0 | 0.0 | 0.3 | +47.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.3 | +28.0 | 0.0 | 0.0 | 1.0 | +82.6 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +39.4 | 0.0 | 54.0 | 2.7 | +87.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.3 | +34.7 | 0.0 | 54.0 | 3.0 | +65.5 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.0 | +390.2 | 0.0 | 0.0 | 2.7 | +206.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +181.9 | 0.0 | 0.0 | 3.3 | +103.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +122.0 | 0.0 | 0.0 | 1.7 | +152.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -20.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -204.9 | 0.0 | 147.3 | 0.3 | -5.8 | 0.0 | 0.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.7 | -339.1 | 0.0 | 201.3 | 2.7 | -35.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -115.4 | 0.0 | 0.0 | 3.0 | -43.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | -9.3 | 0.0 | 0.0 | 0.7 | +33.3 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.7 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.7 | +21.8 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 28.0 | +371.4 | 266.0 | 255.3 | 17.0 | +3.1 | 0.0 | 337.7 |
| PROMISE BY ITS OWN SUM | 9.3 | -491.9 | 0.0 | 0.0 | 4.3 | -43.8 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 9.0 | +1015.7 | 503.3 | 147.3 | 1.7 | +252.0 | 0.0 | 201.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.3 | -0.0 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +93.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | -17.6 | 131.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.3 | -35.1 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 147.3 | - | - | - | - |
| RISK BY ARC | 2.7 | -12.0 | 131.0 | 147.3 | 0.3 | -1.5 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -23.5 | 131.0 | 0.0 | - | - | - | - |
| RUN DOWN | 3.0 | -116.2 | 0.0 | 147.3 | 0.3 | -1.2 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +41.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +22.8 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 1.0 | +4.4 | 0.0 | 108.7 |
| SET CREDITED ONCE | 1.0 | -19.2 | 0.0 | 54.0 | 2.0 | -88.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | -40.7 | 0.0 | 54.0 | 2.3 | +83.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 2.0 | -4.0 | 0.0 | 54.0 | - | - | - | - |
| SHOT RISK POINTS | 16.0 | -311.4 | 0.0 | 54.0 | 19.0 | -341.9 | 0.0 | 135.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.7 | +297.1 | 0.0 | 54.0 | 4.3 | +119.6 | 0.0 | 0.0 |
| SPELL WORTH | 2.7 | +75.2 | 0.0 | 0.0 | 1.0 | +2.6 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -1.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 54.0 | 6.7 | +0.0 | 0.0 | 234.3 |
| STAND AND SHOOT | 0.3 | -4.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 38.7 | +0.0 | 503.3 | 108.0 | 12.3 | +0.0 | 0.0 | 0.0 |
| STAY WORTH | 23.0 | -15.0 | 36.7 | 0.0 | 6.0 | +90.1 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +14.3 | 183.0 | 0.0 | 0.3 | +9.3 | 54.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.7 | +305.2 | 0.0 | 0.0 | 5.0 | +908.1 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.7 | +305.2 | 0.0 | 0.0 | 5.0 | +908.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +2.4 | 0.0 | 0.0 | 1.0 | +19.8 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 54.0 | - | - | - | - |
| THE PROMISE ADDS | 0.7 | -8.8 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.3 | +0.0 | 0.0 | 54.0 | 18.3 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 1.3 | +129.4 | 0.0 | 147.3 | - | - | - | - |
| TIME ON OUR SIDE | 39.0 | +421.4 | 0.0 | 108.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -8.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 147.3 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | +18.6 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -2.5 | 0.0 | 147.3 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +17.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.0 | -55.7 | 0.0 | 0.0 | 1.3 | -470.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 2.0 | +88.7 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p32

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 110 | 110 | 92 | 30.67 | +1355 | +14.7 |
| HIS SHOTS BY HIS RUN | 167 | 157 | 35 | 11.67 | +508 | +14.5 |
| FIVE ACTION | 328 | 314 | 31 | 10.33 | +658 | +21.2 |
| HIS SHOT LIST | 160 | 151 | 31 | 10.33 | +725 | +23.4 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| HOLDER ASSIGNMENT | 33 | 33 | 26 | 8.67 | +2283 | +87.8 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -1125 | -59.2 |
| PROMISE BY ITS OWN SUM | 41 | 41 | 19 | 6.33 | -1607 | -84.6 |
| THE TABLE AGAIN | 22 | 22 | 17 | 5.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| CHARGE LOSSES | 79 | 76 | 14 | 4.67 | +1147 | +81.9 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| SHOT RISK POINTS | 105 | 98 | 14 | 4.67 | +252 | +18.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 23 | 17 | 12 | 4.00 | +439 | +36.6 |
| SUPPORT ADDS | 29 | 29 | 10 | 3.33 | +655 | +65.5 |
| SUPPORT WORKED OUT | 29 | 29 | 10 | 3.33 | +655 | +65.5 |
| GOAL WALK | 45 | 45 | 9 | 3.00 | +479 | +53.2 |
| TIME ON OUR SIDE | 117 | 93 | 9 | 3.00 | +37 | +4.1 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| QUARTER ODDS | 32 | 32 | 8 | 2.67 | +684 | +85.4 |
| NEXT CHARGE BY LIST | 12 | 11 | 7 | 2.33 | +337 | +48.2 |
| CANNON PLANNED TARGET | 20 | 20 | 6 | 2.00 | -4 | -0.6 |
| FOUR ROUNDS | 11 | 11 | 5 | 1.67 | +315 | +62.9 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 7 | 7 | 4 | 1.33 | +27 | +6.8 |
| FALLS SHORT | 51 | 44 | 3 | 1.00 | +45 | +15.1 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 13 | 13 | 3 | 1.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 57 | 49 | 3 | 1.00 | +54 | +18.1 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +71 | +23.6 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +96 | +48.1 |
| CHARGE NOW FIRST | 10 | 10 | 2 | 0.67 | -77 | -38.3 |
| COVER ONCE | 22 | 14 | 2 | 0.67 | +82 | +41.0 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +399 | +199.4 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +223 | +111.3 |
| OPENS A LANE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT COUNTER | 5 | 3 | 2 | 0.67 | +49 | +24.3 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SET UP BY THE SET | 14 | 14 | 2 | 0.67 | +31 | +15.4 |
| STAY WORTH | 87 | 81 | 2 | 0.67 | +58 | +28.9 |
| TIED UP BY THE SUM | 4 | 4 | 2 | 0.67 | +93 | +46.4 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +68 | +33.8 |
| WHOLE FIGHT DANGER | 7 | 7 | 2 | 0.67 | +199 | +99.7 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -53 | -52.8 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| EVASIVE BY THE ODDS | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 7 | 7 | 1 | 0.33 | +0 | +0.5 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +95 | +95.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +11 | +10.7 |
| GUN MASK | 3 | 3 | 1 | 0.33 | +1 | +1.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +37 | +37.0 |
| IDLE COST | 27 | 19 | 1 | 0.33 | +0 | +0.3 |
| LOST AFTER ESCAPE | 7 | 7 | 1 | 0.33 | +33 | +32.8 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +14 | +13.9 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -77 | -77.1 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 9 | 9 | 1 | 0.33 | +17 | +17.0 |
| ONE FIGHT FORMULA | 22 | 13 | 1 | 0.33 | +1 | +0.6 |
| ONE OBJECTIVE FORMULA | 12 | 10 | 1 | 0.33 | +36 | +36.2 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +0 | +0.5 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -3 | -3.4 |
| RANDOM MOVE BY FIGURES | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +65 | +65.2 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -25 | -25.1 |
| RISK BY ARC | 9 | 9 | 1 | 0.33 | +33 | +32.8 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +124 | +124.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +68 | +68.2 |
| SET CREDITED ONCE | 9 | 9 | 1 | 0.33 | +14 | +13.6 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT OR CHARGE | 6 | 6 | 1 | 0.33 | +0 | +0.1 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 4 | 2 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.6 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -24 | -23.9 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +34 | +33.8 |
| CASTING BLOCK | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 28 | 28 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 20 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 7 | 6 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 45 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 10 | 10 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 12 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 11 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 2 | 2 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 26 | 22 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 23 | 23 | 0 | 0.00 | - | - |
| HIS TURN RUN | 10 | 10 | 0 | 0.00 | - | - |
| HOLD ODDS | 42 | 42 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 14 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 25 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 25 | 24 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 22 | 22 | 0 | 0.00 | - | - |
| NO SECOND RUN | 22 | 22 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 12 | 12 | 0 | 0.00 | - | - |
| PLAN RESULT | 135 | trace | - | - | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | not checked | - | - | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 29 | 27 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 153 | 144 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 152 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p32

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 1.33 | 84.6 |
| ARMY TABLE | rule | 2.00 | 3.00 | 79.2 |
| JOB FIRST | gate | 3.00 | 2.00 | 62.8 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 3.5 |
| CHARGE NOW FIRST | rule | 0.67 | - | 38.3 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 2.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 160.1 |
| BEST PRIZE | rule | 0.33 | - | 52.8 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| FALLBACK | gate | - | 0.33 | 17.5 |
| MARCH OF THE TABLE | rule | 0.33 | - | 77.1 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 3.4 |
| REFUSING RETIRES | rule | 0.33 | - | 25.1 |
| SET UP BY THE SET | rule | 0.33 | - | 11.6 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 23.9 |

### Plans: cora-bb45c30-p32

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 320 | 100 | 31% |
| Mine | move | 19.3 | 100% | 876 | 0 | 0% |
| Mine | shoot | 6.3 | 53% | 59 | 271 | 460% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 15.3 | 93% | 1140 | 0 | 0% |
| Opponent | shoot | 0.7 | 50% | 7 | 3 | 44% |

### Battle groups: cora-bb45c30-p32

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p32

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 3 | 131 (3) | 131 | 0 | 45 | 0% | 2.3 | 88 (2) | 212 (1) | - | 143 (1) | 123 (2) |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Shooter | 2 | 103 (2) | 103 | 0 | 48 | 0% | 3.5 | 198 (1) | 0 (1) | - | 198 (1) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 33% | 4.5 | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 3 | 26 (3) | 26 | 0 | 116 | 0% | 2.7 | 46 (1) | - | - | 46 (1) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 115 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 2 | 90 (2) | 90 | 0 | 52 | 50% | 5.0 | 90 (2) | - | - | 90 (2) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 126 | 0% | 1.0 | - | - | - | - | - |

### Charged fights: cora-bb45c30-p32

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 350 | 393 | 5.0 | 1.0 | 79 | 121 | -42 | 3 of 5 | 2 of 5 | - | -42 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 451 | -451 | 1 of 2 | 2 of 2 | - | -451 |

### Effective charges: cora-bb45c30-p32

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 5 | 0 | 0 | 0 | 0 | 0 | 3 (net -201) | 2 | 0% (0 of 3) |

### Charged fights, damage counted: cora-bb45c30-p32

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 273 | 273 | -201 | 42 | 304 | -261 | -95.7 |
| Mine | No odds | 2 | 371 | 343 | +196 | 196 | 0 | +196 | +53.0 |
| Mine | All fights | 5 | 312 | 301 | -42 | 104 | 182 | -78 | -25.0 |
| Opponent | No odds | 2 | 202 | 252 | -451 | 0 | 526 | -526 | -259.8 |
| Opponent | All fights | 2 | 202 | 252 | -451 | 0 | 526 | -526 | -259.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p32 | move | 14 | 6 (43%) | 4 (29%) | 3 (21%) | 5 (36%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

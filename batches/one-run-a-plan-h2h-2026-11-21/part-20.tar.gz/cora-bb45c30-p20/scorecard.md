# Doctrine scorecard: cora-bb45c30-p20

### Scorecard: cora-bb45c30-p20

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 9 | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 72 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 6 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 123 |
| L1435 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.5 | 2.3 | 3.0 | 2.0 | 0.0 | 0.0 | 0.0 | 87.7 |
| **Average** | | | Opponent | 50% | 0.0 | 4.0 | 3.0 | 1.0 | 0.3 | 0.0 | 0.0 | 24.0 |

### KPIs: cora-bb45c30-p20

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 17) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 100% | 80% (4 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 60% (3 of 5); on the table 60% | 50% (1 of 2); on the table 50% | 57% (4 of 7); on the table 57% |
| Winner chose to follow up or pursue (all three) |  | 71% (5 of 7); on the table 71% | 60% (3 of 5); on the table 80% | 67% (8 of 12); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 17% (3 of 18) | - | 17% (3 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (3 of 8) | - | 38% (3 of 8) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 53% (3166 of 6000) | 53% (3200 of 6000) | 53% (6366 of 12000) |
|   infantry points that never fought | lower | 81% (746 of 923) | 65% (752 of 1159) | 72% (1498 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (17 of 26) | 79% (19 of 24) | 72% (36 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 2.0 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (2 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 21% (3 of 14); 3.3 uses a game | 0.0 uses a game | 21% (3 of 14); 1.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (3214 of 5860) | 77% (3960 of 5131) | 65% (7174 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (13%) | - | 0.7 (13%) |
| MARCHED: its unit marched | 0.7 (13%) | - | 0.7 (13%) |
| CHARGED: its unit charged | 0.3 (7%) | - | 0.3 (7%) |
| IN COMBAT: engaged in combat | 0.3 (7%) | - | 0.3 (7%) |
| GONE: slain | 3.0 (60%) | - | 3.0 (60%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 3.3 | 1.7 | 1.0 | 1.3 |
| not cast | 3.7 | 6.7 | 6.3 | 5.0 | 26.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (45%) | 0.3 (5%) | 0.7 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.3 (7%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.0 (27%) | 1.0 (15%) | 1.0 (16%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (36%) | 1.7 (25%) | 3.0 (47%) | 3.0 (60%) | 9.3 (35%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (27%) | 1.0 (15%) | 1.0 (16%) | 0.0 (0%) | 2.3 (9%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (9%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (55%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 60% (3 of 5) | - | 60% (3 of 5) |
| the unit moved after it | 0% (0 of 3) | - | 0% (0 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 33% (1 of 3) | - | 33% (1 of 3) |
| it fought by the end of its next turn | 33% (1 of 3) | - | 33% (1 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 67% (2 of 3) | - | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (43 of 80) | 71% (74 of 104) | 64% (117 of 184) |
|   cavalry | 33% (8 of 24) | 71% (17 of 24) | 52% (25 of 48) |
|   character | 18% (4 of 22) | 77% (10 of 13) | 40% (14 of 35) |
|   chariot | - | 83% (10 of 12) | 83% (10 of 12) |
|   infantry | 86% (19 of 22) | 71% (32 of 45) | 76% (51 of 67) |
|   monster | - | 50% (5 of 10) | 50% (5 of 10) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (19%) | 1.7 (17%) | 4.0 (18%) |
| CHARGED: it charged | 2.3 (19%) | 0.7 (7%) | 3.0 (13%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (7%) | 0.7 (3%) |
| NO TARGET IN RANGE | 5.3 (43%) | 3.0 (30%) | 8.3 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.7 (7%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (14%) | 2.7 (27%) | 4.3 (19%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 0.3 (3%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.7 | 1.3 | 89% | 3.5 pts | 40 pts |
| character | 6.7 | 2.3 | 75% | 14.3 pts | 95 pts |
| chariot | 3.3 | 3.0 | 50% | 48.4 pts | 161 pts |
| infantry | 25.7 | 10.0 | 74% | 8.2 pts | 211 pts |
| monster | 1.7 | 0.3 | 80% | 6.0 pts | 10 pts |
| war machine | 4.0 | 1.7 | 75% | 15.9 pts | 64 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 3.3 | 3.8 |
| Charges that made contact a game | 3.0 | 2.3 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | - | 0.67 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.35 contact (23 units) | 0.30 declared, 0.21 contact (33 units) | 0.38 declared, 0.27 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 65% (11 of 17) | - | - | 65% (11 of 17) |
| Character in a unit | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Character on its own | - | 75% (3 of 4) | 50% (4 of 8) | 58% (7 of 12) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 100% (10 of 10) | 0% (0 of 1) | - | 91% (10 of 11) |
| Monster | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 71% (5 of 7); on the table 71% | 17% (3 of 18) | 53% | 65% (17 of 26) | 100% (1 of 1); 2.0 uses a game | 21% (3 of 14); 3.3 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 75% (3 of 4); on the table 100% | - | 33% | 86% (6 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 0% (0 of 1); on the table 0% | - | 55% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 72% | 75% (9 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p20, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 50% (3) | 55% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p20

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 58% (7 of 12) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (7 of 24) | 25% (3 of 12) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | 50% (4 of 8) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 2) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 1.0 |
| Movement | Points that never moved of their own | 87.7 | 24.0 |
| Movement | Fights charged into per game | 3.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 8 | 1 of 3, net -195 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 8 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 8, net +112 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 8, net +174 | 2 of 3, net +200 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.0 | 29.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (11 of 36) | 57% (50 of 87) |
| Shooting | Points destroyed by shooting units | 23.3 | 50.3 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (8 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 166.7 |
| Magic | Magic missiles cast | 1.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | - |
| Magic | Wounds caused by magic missiles | 2.0 | 1.0 |
| Magic | Wounds caused by other spells | 6.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 47.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.3 / 1.0 / 0.0 | 3.3 / 2.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 365.3 | 133.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +125 | +44 |
| Combat | Net per 100 charger points, damage counted | +34.9 | +26.2 |
| Combat | First round won (charged fights) | 89% | 43% |
| Combat | Net points per charged fight | +152 | +39 |
| Combat | Net points per supported fight / lone fight | - / +152 | - / +39 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 9 | 4 of 7 |
| Game | Points lost | 504.7 | 683.3 |
| Game | VP from objectives | 420.0 | 753.3 |
| Game | Lone holders (player turns) | 4.5 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -99 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1188
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p20

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +9.1 | 0.0 | 0.0 |
| ARMY TABLE | 20.3 | +48.7 | 0.0 | 181.0 | 39.7 | +544.5 | 0.0 | 334.0 |
| ASSAILMENT BY POINTS | 0.3 | +2.0 | 0.0 | 133.3 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 23.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +25.9 | 46.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +19.2 | 66.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 133.3 | - | - | - | - |
| CHAFF PASSED | 1.0 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +25.3 | 0.0 | 41.7 |
| CHARGE LOSSES | 25.0 | -969.7 | 0.0 | 1015.0 | 14.7 | -614.1 | 0.0 | 556.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 310.0 | 0.0 | 1.3 | +0.0 | 234.0 | 65.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 133.3 | 10.7 | +0.0 | 0.0 | 232.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 78.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +116.9 | 266.7 | 266.7 | - | - | - | - |
| COVER ONCE | 9.7 | -431.2 | 0.0 | 347.7 | 6.7 | -390.9 | 0.0 | 23.3 |
| DENIED BY THE FIGHT | 0.7 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +14.9 | 166.3 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 2.0 | +55.7 | 0.0 | 0.0 |
| EXACT ROUND | 3.0 | -6.7 | 205.0 | 0.0 | 1.0 | +13.3 | 133.3 | 65.0 |
| FALL BACK GOOD ORDER | 3.0 | +12.2 | 310.0 | 0.0 | 0.7 | +4.7 | 133.3 | 65.0 |
| FALLS SHORT | 8.3 | +100.3 | 0.0 | 166.7 | 13.3 | +156.1 | 0.0 | 83.3 |
| FEATURE BUFFS | 1.7 | +16.8 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +1.0 | 0.0 | 65.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 91.7 | +3830.5 | 718.3 | 1354.0 | 102.7 | +6266.8 | 900.7 | 1359.7 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 214.3 | 10.3 | +0.0 | 0.0 | 227.3 |
| FOLLOW UP WEIGHED | 1.0 | +418.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.3 | +164.1 | 377.3 | 0.0 | 1.3 | +142.6 | 133.3 | 65.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 266.0 |
| FRIEND SHOOTS FIRST | 0.3 | -9.6 | 0.0 | 0.0 | 1.3 | -12.7 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -28.6 | 0.0 | 0.0 | 0.3 | -2.4 | 0.0 | 0.0 |
| GOAL WALK | 6.3 | +423.9 | 0.0 | 362.0 | 10.3 | +587.6 | 0.0 | 68.0 |
| GUN FIGURES | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +84.9 | 547.7 | 0.0 |
| GUN MASK | 1.3 | +37.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 38.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 266.0 |
| HIS CHARGE BY HIS RUN | 17.3 | +0.0 | 0.0 | 781.0 | 9.3 | +0.0 | 0.0 | 400.7 |
| HIS CHARGE LIST | 12.3 | +0.0 | 0.0 | 234.0 | 12.0 | +0.0 | 0.0 | 402.7 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 333.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.0 | -55.3 | 0.0 | 0.0 | 4.3 | -22.3 | 0.0 | 156.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 83.3 |
| HIS OWN BEST MOVE | 10.3 | +0.0 | 0.0 | 428.7 | 8.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 66.0 | +3332.5 | 0.0 | 954.0 | 65.7 | +1888.1 | 0.0 | 1193.0 |
| HIS SHOTS BY HIS RUN | 52.7 | +1385.0 | 0.0 | 1258.7 | 40.0 | +524.9 | 0.0 | 681.3 |
| HIS TURN DENIED | 1.7 | +62.7 | 103.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 18.3 | +0.0 | 0.0 | 100.7 | 14.0 | +0.0 | 0.0 | 70.7 |
| HOLDER ASSIGNMENT | 10.0 | +906.4 | 0.0 | 50.3 | 8.3 | +685.0 | 0.0 | 35.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -140.9 | 335.7 | 0.0 | 1.3 | -20.5 | 133.3 | 65.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +3.3 | 0.0 | 0.0 |
| IDLE COST | 7.7 | -117.9 | 0.0 | 214.3 | 12.3 | -185.8 | 0.0 | 72.0 |
| JOINT CHARGE NOW | 0.7 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 192.0 | 47.7 | 5.3 | +0.0 | 181.0 | 296.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +2.8 | 80.7 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -77.6 | 0.0 | 11.3 |
| MANOEUVRE | 0.7 | -0.1 | 0.0 | 0.0 | 2.7 | -9.7 | 0.0 | 125.7 |
| MARCH BY THE SUM | 0.3 | +13.3 | 0.0 | 133.3 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +11.9 | 0.0 | 133.3 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +52.7 | 0.0 | 0.0 | 0.3 | +56.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +16.5 | 0.0 | 166.7 | 1.7 | +38.2 | 0.0 | 34.7 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +34.6 | 0.0 | 0.0 | 1.7 | +43.7 | 0.0 | 99.0 |
| MISSILES NEXT TURN | 4.0 | +25.6 | 0.0 | 433.3 | 2.7 | +48.5 | 0.0 | 198.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 133.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.3 | +578.5 | 0.0 | 95.3 | 7.3 | +430.9 | 0.0 | 156.0 |
| NEARER NOT NEEDED | 7.7 | +272.0 | 0.0 | 50.3 | 9.0 | +332.2 | 0.0 | 224.7 |
| NEXT CHARGE BY LIST | 6.0 | +448.9 | 0.0 | 95.3 | 5.7 | +363.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.3 | -84.8 | 377.3 | 0.0 | 1.3 | -114.4 | 133.3 | 65.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 2.0 | -94.0 | 0.0 | 0.0 | 6.0 | -251.0 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | 0.3 | +5.8 | 41.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.3 | -111.7 | 0.0 | 166.7 | 5.7 | -113.6 | 0.0 | 101.3 |
| ONE JOINT FIGURE | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 6.0 | -52.0 | 0.0 | 50.3 | 4.0 | -170.8 | 0.0 | 35.3 |
| ONE PROMISE A TARGET | 0.7 | -8.3 | 0.0 | 95.3 | - | - | - | - |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +34.8 | 38.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.7 | +221.9 | 270.0 | 0.0 | 0.3 | +1.3 | 133.3 | 0.0 |
| PATHS CROSS | 0.3 | +12.2 | 0.0 | 47.7 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -7.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 41.3 | +626.8 | 240.3 | 555.0 | 47.7 | +608.7 | 225.7 | 1010.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.0 | -168.0 | 0.0 | 0.0 | 12.7 | -329.6 | 0.0 | 156.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 156.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -12.6 | 46.7 | 0.0 | - | - | - | - |
| QUARTER ODDS | 14.0 | +1150.1 | 79.7 | 0.0 | 20.3 | +2266.5 | 0.0 | 83.3 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +128.9 | 0.0 | 60.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.7 | +0.0 | 0.0 | 119.7 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.7 | -62.0 | 0.0 | 0.0 | 3.7 | -131.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +53.5 | 0.0 | 0.0 |
| RISK BY ARC | 3.7 | -311.2 | 326.0 | 0.0 | 1.3 | +42.0 | 133.3 | 65.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -15.5 | 137.0 | 0.0 | 0.3 | -5.1 | 133.3 | 0.0 |
| RUN DOWN | 2.7 | -17.4 | 205.3 | 0.0 | 0.7 | -2.5 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -73.3 | 0.0 | 34.0 |
| SEARCH SPOT | 0.3 | +9.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 23.3 |
| SECOND LOOK | 0.3 | +22.0 | 34.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 4.0 | -248.6 | 0.0 | 30.0 |
| SET UP BY THE SET | 1.0 | +54.3 | 0.0 | 95.3 | 6.0 | +281.5 | 0.0 | 30.0 |
| SET-UP ANY TARGET | 0.3 | +51.6 | 133.3 | 133.3 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 49.3 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +16.0 | 25.7 | 0.0 | 1.7 | +178.6 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -2.4 | 25.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 40.0 | -375.7 | 0.0 | 1354.0 | 22.3 | -171.6 | 0.0 | 381.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +300.4 | 0.0 | 133.3 | 26.7 | +899.0 | 0.0 | 202.7 |
| SPELL SETS UP CHARGE | 0.3 | +51.6 | 133.3 | 133.3 | - | - | - | - |
| SPELL WORTH | 0.7 | +14.7 | 266.7 | 266.7 | 1.7 | +28.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.3 | +6.3 | 67.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 228.7 | 8.3 | +0.0 | 0.0 | 183.7 |
| STAND AND SHOOT | 1.3 | -29.9 | 25.7 | 0.0 | 0.3 | -1.7 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 25.7 | 0.0 | 5.7 | +0.0 | 100.7 | 76.0 |
| STANDS STILL | 32.3 | +0.0 | 341.0 | 0.0 | 32.7 | +0.0 | 767.3 | 280.0 |
| STAY WORTH | 22.0 | +45.7 | 315.3 | 133.3 | 18.7 | +114.1 | 333.3 | 78.0 |
| SUPPORT ADDS | 4.0 | +173.9 | 0.0 | 0.0 | 3.3 | +180.1 | 0.0 | 82.7 |
| SUPPORT WORKED OUT | 4.0 | +173.9 | 0.0 | 0.0 | 3.3 | +180.1 | 0.0 | 82.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 133.3 | 1.7 | +0.0 | 0.0 | 34.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 153.7 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 148.3 | 5.7 | +0.0 | 0.0 | 99.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 98.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.7 | +0.0 | 0.0 | 677.0 | 50.7 | +0.0 | 0.0 | 643.7 |
| TIED UP BY THE SUM | 2.7 | +305.9 | 211.0 | 0.0 | 0.3 | +19.8 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 26.7 | +329.6 | 0.0 | 462.7 | 25.7 | +275.7 | 333.3 | 724.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.0 | +0.0 | 333.3 | 0.0 |
| WHO FIGHTS | 0.7 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| WHO GETS IN | 0.7 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 1.7 | +327.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.7 | -234.2 | 0.0 | 300.0 | 2.7 | -304.3 | 0.0 | 354.0 |
| WHOLE FIGHT GAIN | 0.3 | +25.3 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: cora-bb45c30-p20

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 180 | 180 | 134 | 44.67 | +2142 | +16.0 |
| HIS SHOT LIST | 395 | 382 | 110 | 36.67 | +2094 | +19.0 |
| HIS SHOTS BY HIS RUN | 278 | 268 | 62 | 20.67 | +744 | +12.0 |
| HOLDER ASSIGNMENT | 55 | 55 | 51 | 17.00 | +3027 | +59.4 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| SHOT RISK POINTS | 187 | 183 | 32 | 10.67 | +624 | +19.5 |
| LEGAL CHARGES ONLY | 31 | 31 | 31 | 10.33 | +0 | +0.0 |
| FIVE ACTION | 583 | 562 | 27 | 9.00 | +1390 | +51.5 |
| PROMISE BY ITS OWN SUM | 68 | 68 | 27 | 9.00 | -1493 | -55.3 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -1035 | -43.1 |
| MOVE TO CHARGE COMPUTED | 47 | 46 | 22 | 7.33 | +712 | +32.4 |
| QUARTER ODDS | 103 | 100 | 21 | 7.00 | +1433 | +68.2 |
| REDIRECT FOR A FRIEND IN REACH | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 157 | 136 | 17 | 5.67 | +99 | +5.8 |
| NEXT CHARGE BY LIST | 35 | 34 | 14 | 4.67 | +605 | +43.2 |
| CHARGE LOSSES | 119 | 116 | 13 | 4.33 | +1146 | +88.2 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| COVER ONCE | 49 | 34 | 8 | 2.67 | +155 | +19.3 |
| GOAL WALK | 50 | 49 | 8 | 2.67 | +241 | +30.1 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| SHOTS IN THE MOVE | 128 | 98 | 8 | 2.67 | +160 | +20.0 |
| TIED UP BY THE SUM | 9 | 8 | 8 | 2.67 | +329 | +41.1 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 7 | 2.33 | +80 | +11.5 |
| WHOLE FIGHT DANGER | 19 | 19 | 7 | 2.33 | +577 | +82.4 |
| FOUR ROUNDS | 17 | 16 | 6 | 2.00 | +197 | +32.8 |
| SUPPORT ADDS | 22 | 22 | 6 | 2.00 | +10 | +1.7 |
| SUPPORT WORKED OUT | 22 | 22 | 6 | 2.00 | +10 | +1.7 |
| FALLS SHORT | 65 | 58 | 5 | 1.67 | +27 | +5.4 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +852 | +170.4 |
| CANNON PLANNED TARGET | 12 | 12 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +1255 | +313.8 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +160 | +40.1 |
| SET UP BY THE SET | 21 | 21 | 4 | 1.33 | +316 | +78.9 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +27 | +8.9 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -11 | -3.8 |
| EVASIVE BY THE ODDS | 6 | 6 | 3 | 1.00 | +111 | +37.0 |
| IDLE COST | 60 | 42 | 3 | 1.00 | +40 | +13.3 |
| MAX FOR POSITIONING | 10 | 10 | 3 | 1.00 | +4 | +1.5 |
| OVERRUNS AWAY | 9 | 9 | 3 | 1.00 | +119 | +39.6 |
| SHOTS AFTER THE MOVES | 22 | 22 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +76 | +37.9 |
| CHARGE NOW FIRST | 11 | 11 | 2 | 0.67 | -45 | -22.5 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +31 | +15.6 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +31 | +15.7 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -25 | -12.3 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +58 | +29.2 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -38 | -19.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +31 | +15.6 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +27 | +27.4 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +22 | +21.8 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +4 | +4.4 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +40 | +39.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -36 | -35.8 |
| MISSILES IN THE MOVE | 14 | 12 | 1 | 0.33 | +5 | +5.1 |
| NEARER NOT NEEDED | 50 | 49 | 1 | 0.33 | +27 | +26.8 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +37 | +36.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -22 | -21.5 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | +0 | +0.4 |
| REDIRECT COUNTER | 10 | 8 | 1 | 0.33 | +85 | +84.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +61 | +60.8 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -20 | -19.8 |
| RISK BY ARC | 15 | 14 | 1 | 0.33 | +113 | +112.9 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +28 | +28.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +66 | +66.0 |
| THE ROW IN ITS ORDER | 18 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +22 | +21.8 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 12 | 11 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 10 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 50 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 45 | 43 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| GUN MASK | 4 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 27 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 80 | 80 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 73 | 71 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 36 | 34 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 28 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 55 | 53 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 97 | 97 | 0 | 0.00 | - | - |
| HONEST WORTH | 16 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 20 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 17 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 33 | 19 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 30 | 25 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 267 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 19 | 18 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 12 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 44 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 44 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 19 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 195 | 182 | 0 | 0.00 | - | - |
| STAY WORTH | 122 | 108 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 26 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 283 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p20

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 5.67 | 55.3 |
| JOB FIRST | gate | 2.00 | 5.67 | 43.4 |
| ARMY TABLE | rule | 3.33 | 2.67 | 30.4 |
| CHAFF PASSED | rule | 0.67 | - | 5.7 |
| CHARGE NOW FIRST | rule | 0.67 | - | 22.5 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 5.9 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 12.3 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 19.0 |
| MARCH OF THE TABLE | rule | 0.33 | - | 35.8 |
| NO REASON | gate | - | 0.33 | 36.2 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 21.5 |
| REFUSING RETIRES | rule | 0.33 | - | 19.8 |

### Plans: cora-bb45c30-p20

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 80% | 393 | 350 | 89% |
| Mine | move | 31.7 | 94% | 1303 | 0 | 0% |
| Mine | shoot | 6.3 | 63% | 170 | 277 | 163% |
| Opponent | charge | 1.0 | 100% | 184 | 286 | 155% |
| Opponent | move | 42.0 | 93% | 2101 | 0 | 0% |
| Opponent | shoot | 3.3 | 60% | 223 | 323 | 145% |
| Opponent | support | 1.3 | 50% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p20

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 20% | 100% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p20

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 64 (7) | 64 | 0 | 30 | 0% | 1.4 | 42 (5) | 217 (1) | 0 (1) | 19 (5) | 154 (2) |
| Mine | Clean-up | 1 | 104 (1) | 0 | 104 | 0 | 100% | - | 104 (1) | - | - | 104 (1) | - |
| Mine | Fast Hammer | 14 | 24 (14) | 6 | 19 | 22 | 57% | 2.7 | 29 (8) | 18 (6) | - | 32 (9) | 11 (5) |
| Mine | Shooter | 4 | 0 (4) | 0 | 0 | 26 | 0% | 1.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | War machine | 2 | 50 (2) | 50 | 0 | 0 | 0% | 1.0 | 50 (2) | - | - | - | 50 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 7 | 176 (7) | 0 | 176 | 82 | 0% | 2.7 | - | 345 (4) | 16 (3) | 405 (4) | 14 (3) |
| Opponent | Character | 4 | 41 (4) | 25 | 16 | 0 | 0% | 1.2 | - | 41 (4) | - | 0 (2) | 75 (2) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 80 | 50% | 4.0 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 31 (4) | 22 | 9 | 29 | 0% | 2.5 | 60 (2) | 0 (2) | - | 44 (3) | 0 (1) |
| Opponent | Hammer | 8 | 33 (8) | 33 | 0 | 51 | 12% | 2.7 | 0 (2) | 70 (3) | 0 (3) | 81 (4) | 0 (4) |
| Opponent | Holder | 3 | 141 (3) | 0 | 141 | 0 | 0% | 2.3 | 205 (2) | - | 0 (1) | 450 (1) | 0 (2) |
| Opponent | Shooter | 4 | 27 (4) | 0 | 27 | 21 | 0% | 1.5 | 0 (1) | 59 (2) | 0 (1) | 67 (2) | 0 (2) |
| Opponent | Wizard | 3 | 21 (3) | 21 | 0 | 61 | 0% | 2.0 | 39 (2) | - | - | 52 (1) | 0 (1) |

### Charged fights: cora-bb45c30-p20

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 23 | 457 | 3.0 | 1.0 | 152 | 0 | +152 | 1 of 9 | 8 of 9 | - | +152 |
| Opponent | Ogre Kingdoms | 1 | 500 | 0 | 4.0 | 1.0 | 0 | 27 | -27 | 2 of 4 | 0 of 4 | - | -27 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 577 | 3.0 | 1.0 | 192 | 65 | +127 | 2 of 3 | 3 of 3 | - | +127 |
| Opponent | Wood Elf Realms | 1 | 294 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 265 | 192 | 2.3 | 1.0 | 82 | 43 | +39 | 4 of 7 | 3 of 7 | - | +39 |

### Effective charges: cora-bb45c30-p20

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 9 | 0 | 0 | 0 | 0 | 4 (net +112) | 4 (net +174) | 1 | 0% (0 of 8) |
| Opponent | Ogre Kingdoms | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 3 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net -195) | 0 | 0 | 0 | 0 | 1 (net +400) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: cora-bb45c30-p20

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 316 | 171 | +174 | 180 | 0 | +180 | +56.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 368 | 86 | +112 | 112 | 67 | +45 | +12.2 |
| Mine | No odds | 1 | 489 | 102 | +227 | 227 | 0 | +227 | +46.4 |
| Mine | All fights | 9 | 359 | 126 | +152 | 155 | 30 | +125 | +34.9 |
| Opponent | Long shot (under 50%) | 1 | 195 | 342 | -195 | 285 | 439 | -154 | -79.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 312 | 276 | +200 | 215 | 18 | +197 | +62.9 |
| Opponent | No odds | 4 | 88 | 326 | +17 | 44 | 27 | +17 | +19.5 |
| Opponent | All fights | 7 | 168 | 314 | +39 | 127 | 83 | +44 | +26.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p20 | move | 24 | 3 (12%) | 3 (12%) | 5 (21%) | 16 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

# Doctrine scorecard: cora-bb45c30-p5

### Scorecard: cora-bb45c30-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 0 | 4 | 4 | 2 | 0 | 0 | 0 | 250 |
| L0717 | 3 | 1 | Opponent | yes | 10 | 4 | 2 | 1 | 1 | 0 | 0 | 141 |
| L0733 | 1 | 1 | Mine | no | 7 | 3 | 1 | 0 | 0 | 0 | 0 | 125 |
| L0733 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 13 | - | 0 | 1 | 1 | 0 | 0 | 385 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 195 |
| **Average** | | | Mine | 0% | 6.7 | 3.5 | 1.7 | 1.0 | 0.3 | 0.0 | 0.0 | 253.3 |
| **Average** | | | Opponent | 33% | 3.3 | 3.3 | 1.7 | 1.7 | 0.7 | 0.0 | 0.0 | 112.0 |

### KPIs: cora-bb45c30-p5

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 88% (14 of 16) | 0% (0 of 12) | 50% (14 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 100% (5 of 5); on the table 100% | 86% (6 of 7); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 100% (8 of 8); on the table 100% | 92% (11 of 12); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 58% (7 of 12) | 25% (3 of 12) | 42% (10 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 58% (7 of 12) | 25% (3 of 12) | 42% (10 of 24) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 53% (3179 of 5998) | 63% (3797 of 6000) | 58% (6976 of 11998) |
|   infantry points that never fought | lower | 37% (267 of 715) | 83% (1180 of 1418) | 68% (1447 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (16 of 30) | 59% (13 of 22) | 56% (29 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 3.0 uses a game | 100% (2 of 2); 1.5 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (2689 of 5389) | 54% (2725 of 5023) | 52% (5414 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (89%) | 2.7 (57%) |
| MARCHED: its unit marched | 1.3 (80%) | 0.3 (11%) | 1.7 (36%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (20%) | 0.0 (0%) | 0.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.0 | 3.3 | 1.3 | 0.0 |
| not cast | 3.7 | 1.0 | 4.7 | 0.7 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (100%) | 2.7 (57%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.7 (36%) | 0.3 (50%) | 0.0 (0%) |
| GONE: slain | 1.3 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.3 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (64%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.7 (89%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (71 of 97) | 70% (69 of 98) | 72% (140 of 195) |
|   cavalry | 80% (8 of 10) | 74% (14 of 19) | 76% (22 of 29) |
|   character | - | 62% (10 of 16) | 62% (10 of 16) |
|   chariot | 50% (2 of 4) | - | 50% (2 of 4) |
|   infantry | 65% (15 of 23) | 75% (43 of 57) | 72% (58 of 80) |
|   monster | - | 33% (2 of 6) | 33% (2 of 6) |
|   war machine | 77% (46 of 60) | - | 77% (46 of 60) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (23%) | 0.3 (3%) | 2.3 (13%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (17%) | 1.7 (9%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 0.3 (3%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.7 (19%) | 0.0 (0%) | 1.7 (9%) |
| NO TARGET IN RANGE | 1.0 (12%) | 2.3 (24%) | 3.3 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (8%) | 2.3 (24%) | 3.0 (16%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (19%) | 2.7 (28%) | 4.3 (24%) |
| SHELTERED: the target was sheltered | 1.3 (15%) | 0.0 (0%) | 1.3 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.3 | 4.3 | 65% | 7.8 pts | 81 pts |
| character | 3.3 | 1.7 | 50% | 17.3 pts | 58 pts |
| chariot | 0.7 | 1.0 | 50% | 73.3 pts | 49 pts |
| infantry | 28.3 | 8.3 | 78% | 7.5 pts | 211 pts |
| monster | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 15.3 | 16.3 | 43% | 35.8 pts | 548 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 4.3 | 3.3 |
| Charges that made contact a game | 2.3 | 2.3 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.30 contact (23 units) | 0.43 declared, 0.23 contact (30 units) | 0.38 declared, 0.26 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (6 of 9) | 0% (0 of 3) | - | 50% (6 of 12) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | 100% (1 of 1) | 100% (7 of 7) |
| Character on its own | 50% (2 of 4) | - | 33% (2 of 6) | 40% (4 of 10) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | 0% (0 of 1) | 17% (1 of 6) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 50% (5 of 10) | - | - | 50% (5 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 75% (3 of 4); on the table 75% | 58% (7 of 12) | 53% | 53% (16 of 30) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 48% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (5 of 5); on the table 100% | 0% (0 of 6) | 65% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 77% | 70% (7 of 10) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p5, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (1) | - | 20% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.67 | 0.00 | 0.67 |

### Quality by phase: cora-bb45c30-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 83% (5 of 6) | 62% (5 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 22% (14 of 64) | 50% (6 of 12) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 67% (2 of 3) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 50% (5 of 10) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 253.3 | 112.0 |
| Movement | Fights charged into per game | 2.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net -189 | 1 of 4, net +85 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +19 | 1 of 4, net +77 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +83 | 2 of 4, net +560 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.3 | 24.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (10 of 25) | 51% (37 of 72) |
| Shooting | Points destroyed by shooting units | 88.3 | 15.0 |
| Shooting | War machine shots | 15.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (27 of 46) | - |
| Shooting | Points destroyed by war machines | 411.7 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 5) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 1.7 | 1.0 |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 63.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.0 / 0.0 / 0.0 | 2.0 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 30.3 | 299.3 |
| Combat | Points run down | 27.7 | 256.0 |
| Combat | Net points per charged fight, damage counted | +31 | +218 |
| Combat | Net per 100 charger points, damage counted | +13.1 | +87.2 |
| Combat | First round won (charged fights) | 67% | 67% |
| Combat | Net points per charged fight | +11 | +274 |
| Combat | Net points per supported fight / lone fight | +19 / +10 | +691 / +190 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 4 of 6 |
| Game | Points lost | 638.0 | 552.3 |
| Game | VP from objectives | 986.7 | 910.0 |
| Game | Lone holders (player turns) | 6.7 | 3.3 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -78 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1190
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 17.0 | +287.6 | 0.0 | 88.7 | 34.3 | +450.9 | 0.0 | 300.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.7 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 2.0 | +0.0 | 310.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 14.0 | +513.4 | 2009.0 | 41.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.7 | +120.6 | 0.0 | 0.0 | 0.7 | +12.7 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.7 | +15.6 | 63.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +66.4 | 0.0 | 12.7 |
| CHAFF PASSED | - | - | - | - | 0.7 | -5.8 | 0.0 | 27.7 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +1.5 | 0.0 | 27.7 |
| CHARACTER GUNS | - | - | - | - | 6.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 20.0 | -1199.3 | 0.0 | 817.0 | 20.0 | -1027.6 | 0.0 | 672.7 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 51.7 | 63.0 | 1.3 | +0.0 | 135.0 | 23.3 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 63.0 | 14.3 | +0.0 | 0.0 | 180.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 13.0 | -827.0 | 0.0 | 129.3 | 6.3 | -330.5 | 0.0 | 51.7 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -4.4 | 24.0 | 0.0 | 0.7 | +17.5 | 54.7 | 23.3 |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 65.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -9.4 | 54.7 | 0.0 |
| EXACT ROUND | 1.3 | -2.2 | 30.3 | 63.0 | 1.7 | +69.4 | 335.3 | 23.3 |
| FALL BACK GOOD ORDER | 1.0 | +21.1 | 24.0 | 63.0 | 1.3 | +2.3 | 166.0 | 0.0 |
| FALLBACK BY WORTH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 18.3 | +265.4 | 0.0 | 351.7 |
| FEATURE BUFFS | 1.3 | +41.5 | 0.0 | 0.0 | 0.7 | +33.9 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +14.4 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.7 | +0.0 | 86.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 110.3 | +7417.2 | 4919.0 | 1218.0 | 89.0 | +6043.0 | 907.0 | 936.7 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 203.3 | 1.7 | +0.0 | 0.0 | 180.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +96.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +123.8 | 92.0 | 126.0 | 2.7 | +262.8 | 415.7 | 23.3 |
| FREED FROM HIS FIGHT | 5.3 | +0.0 | 0.0 | 109.3 | 2.3 | +0.0 | 0.0 | 55.3 |
| FRIEND CHARGES FIRST | 0.3 | -74.7 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.3 | -78.9 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.7 | +43.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -13.7 | 0.0 | 63.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| GOAL WALK | 7.0 | +510.5 | 0.0 | 0.0 | 17.3 | +1060.1 | 0.0 | 129.3 |
| GUN FIGURES | 0.7 | +0.0 | 180.0 | 0.0 | - | - | - | - |
| GUN MASK | 0.7 | -17.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 27.7 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.3 | +0.0 | 0.0 | 707.7 | 9.7 | +0.0 | 0.0 | 439.3 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 204.0 |
| HIS MOVE AND SHOT | 1.0 | -1.9 | 0.0 | 140.3 | 5.3 | -143.8 | 0.0 | 116.7 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 12.7 |
| HIS OWN BEST MOVE | 11.7 | +0.0 | 0.0 | 126.0 | 6.7 | +0.0 | 0.0 | 204.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 45.3 | +1996.6 | 0.0 | 931.7 | 61.0 | +3895.3 | 0.0 | 414.0 |
| HIS SHOTS BY HIS RUN | 41.3 | +1240.7 | 0.0 | 957.3 | 41.7 | +1607.1 | 0.0 | 790.0 |
| HIS TURN DENIED | 1.0 | +13.3 | 51.7 | 0.0 | 1.3 | +67.8 | 109.3 | 23.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 22.3 | +0.0 | 0.0 | 831.3 | 24.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 13.7 | +1248.9 | 0.0 | 415.7 | 15.7 | +1379.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -54.0 | 92.0 | 63.0 | 2.0 | -86.9 | 135.0 | 23.3 |
| HORN WORTH | - | - | - | - | 0.3 | +3.8 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +15.9 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 14.7 | -224.9 | 0.0 | 129.3 |
| JOINT CHARGE NOW | 0.7 | +38.6 | 12.7 | 0.0 | 1.3 | +20.7 | 390.0 | 23.3 |
| KEEP FALLS | 0.3 | +4.0 | 0.0 | 90.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 75.7 | 405.7 | 12.0 | +0.0 | 280.0 | 330.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 140.3 | 15.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +1.8 | 79.3 | 126.0 | 1.7 | +5.1 | 335.3 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +4.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +12.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.7 | +21.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +190.0 | 0.0 | 0.0 | 0.3 | +9.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.0 | +44.0 | 0.0 | 0.0 | 1.3 | +15.9 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +114.6 | 0.0 | 0.0 | 4.0 | +71.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +75.7 | 0.0 | 0.0 | 4.0 | +45.5 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 6.3 |
| MOVE TO CHARGE COMPUTED | 7.3 | +955.9 | 0.0 | 126.0 | 4.7 | +346.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.7 | +323.6 | 0.0 | 80.3 | 11.3 | +559.7 | 0.0 | 51.7 |
| NEXT CHARGE BY LIST | 5.0 | +480.7 | 0.0 | 63.0 | 3.3 | +226.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -68.4 | 79.3 | 126.0 | 2.7 | -164.3 | 415.7 | 23.3 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 28.3 | - | - | - | - |
| OFF BEST | 5.7 | -267.7 | 0.0 | 117.7 | 5.0 | -44.0 | 0.0 | 147.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -65.9 | 0.0 | 203.3 | 3.7 | -95.7 | 0.0 | 266.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +24.4 | 195.0 | 23.3 |
| ONE OBJECTIVE FORMULA | 3.7 | +3.1 | 0.0 | 220.7 | 6.7 | +22.5 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.0 | -45.1 | 0.0 | 0.0 | 1.0 | -72.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 3.3 | +20.7 | 12.7 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +17.3 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +16.5 | 55.3 | 63.0 | 0.7 | +2.5 | 54.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +2.9 | 0.0 | 0.0 |
| PLAN RESULT | 51.7 | +2307.0 | 895.0 | 817.7 | 41.0 | +411.2 | 166.3 | 889.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 61.7 |
| PROMISE BY ITS OWN SUM | 5.3 | -29.1 | 0.0 | 0.0 | 5.0 | -20.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | -14.0 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -148.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 30.7 | +2650.8 | 734.0 | 146.3 | 18.3 | +1937.3 | 233.3 | 68.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +35.2 | 0.0 | 12.7 |
| REDIRECT COUNTER | 0.3 | +2.3 | 0.0 | 0.0 | 1.0 | -11.3 | 0.0 | 12.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.7 | +40.3 | 0.0 | 31.7 |
| REFORMS TO MEET IT | 1.3 | -2.0 | 0.0 | 126.0 | 0.3 | -3.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +14.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +10.0 | 85.7 | 126.0 | 1.3 | -47.7 | 80.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -27.8 | 220.7 | 0.0 |
| RUN DOWN | 2.0 | -26.3 | 85.7 | 126.0 | 2.3 | -20.9 | 415.7 | 23.3 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | -1.5 | 0.0 | 0.0 | 0.7 | +4.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +30.4 | 24.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -76.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | -33.5 | 0.0 | 0.0 | 1.7 | +15.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 24.0 | +0.0 | 0.0 | 97.3 | 5.3 | +0.0 | 0.0 | 68.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +1.5 | 0.0 | 0.0 | 2.0 | +67.1 | 280.7 | 123.3 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -13.1 | 0.0 | 0.0 | 0.3 | -20.7 | 140.3 | 0.0 |
| SHOT RISK POINTS | 31.7 | -140.5 | 0.0 | 536.3 | 33.7 | +616.3 | 0.0 | 630.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.7 | +964.8 | 0.0 | 122.0 | 19.3 | +492.3 | 0.0 | 321.0 |
| SPELL WORTH | 0.3 | +3.1 | 28.3 | 28.3 | 4.0 | +40.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +2.5 | 30.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 6.3 |
| STAND AND SHOOT | 1.0 | -16.3 | 55.3 | 63.0 | 1.3 | -26.3 | 135.0 | 23.3 |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 360.0 |
| STANDS STILL | 66.0 | +0.0 | 4827.0 | 134.7 | 22.3 | +0.0 | 491.3 | 382.7 |
| STAY WORTH | 54.0 | +537.1 | 3544.0 | 234.3 | 16.0 | +131.7 | 84.7 | 120.0 |
| STRIKE BY THE ODDS | 0.7 | +2.8 | 0.0 | 140.3 | 1.7 | +60.7 | 168.7 | 0.0 |
| SUPPORT ADDS | 2.0 | +201.2 | 0.0 | 0.0 | 1.3 | +90.0 | 0.0 | 24.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 27.7 | 63.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +201.2 | 0.0 | 0.0 | 1.3 | +90.0 | 0.0 | 24.0 |
| SURE REACH TOGETHER | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -88.3 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 61.7 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 58.3 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 58.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 52.7 | +0.0 | 0.0 | 435.7 | 42.0 | +0.0 | 0.0 | 463.0 |
| TIED UP BY THE SUM | 1.0 | +77.2 | 58.0 | 63.0 | 0.3 | +56.3 | 25.7 | 0.0 |
| TIME ON OUR SIDE | 40.7 | +445.7 | 123.3 | 238.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -0.8 | 0.0 | 63.0 | 1.3 | +55.0 | 335.3 | 23.3 |
| WHOLE FIGHT DANGER | 1.7 | -648.7 | 0.0 | 280.7 | 2.0 | -89.9 | 0.0 | 55.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +77.7 | 195.0 | 23.3 |
| WOUNDS ON THE RANKS | 6.7 | +409.1 | 0.0 | 280.7 | 2.7 | +119.5 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 154 | 154 | 112 | 37.33 | +1947 | +17.4 |
| HIS SHOT LIST | 319 | 317 | 96 | 32.00 | +2776 | +28.9 |
| HOLDER ASSIGNMENT | 88 | 88 | 77 | 25.67 | +3679 | +47.8 |
| LEGAL CHARGES ONLY | 53 | 53 | 53 | 17.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 249 | 247 | 49 | 16.33 | +620 | +12.6 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| OFF BEST | 32 | 32 | 32 | 10.67 | -935 | -29.2 |
| SHOT RISK POINTS | 196 | 195 | 32 | 10.67 | +1508 | +47.1 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 122 | 103 | 19 | 6.33 | +51 | +2.7 |
| FIVE ACTION | 598 | 595 | 17 | 5.67 | +1311 | +77.1 |
| QUARTER ODDS | 147 | 147 | 17 | 5.67 | +1052 | +61.9 |
| MOVE TO CHARGE COMPUTED | 36 | 35 | 16 | 5.33 | +1109 | +69.3 |
| GOAL WALK | 73 | 73 | 14 | 4.67 | +507 | +36.2 |
| STAY WORTH | 210 | 190 | 12 | 4.00 | +142 | +11.8 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 25 | 25 | 11 | 3.67 | +649 | +59.0 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 11 | 3.67 | +10 | +0.9 |
| COVER ONCE | 58 | 38 | 9 | 3.00 | +199 | +22.1 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| CHARGE LOSSES | 120 | 120 | 7 | 2.33 | +495 | +70.7 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +178 | +29.7 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -353 | -58.9 |
| STRIKE BY THE ODDS | 7 | 7 | 6 | 2.00 | +100 | +16.6 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CAST JOB | 10 | 10 | 5 | 1.67 | +76 | +15.2 |
| FIRE IN ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOUR ROUNDS | 15 | 15 | 5 | 1.67 | +201 | +40.2 |
| IDLE COST | 44 | 23 | 5 | 1.67 | +62 | +12.4 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| SET UP BY THE SET | 9 | 9 | 5 | 1.67 | +278 | +55.5 |
| SUPPORT ADDS | 10 | 10 | 5 | 1.67 | +242 | +48.3 |
| SUPPORT WORKED OUT | 10 | 10 | 5 | 1.67 | +242 | +48.3 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 4 | 1.33 | -43 | -10.9 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 4 | 1.33 | +22 | +5.5 |
| SHOTS IN THE MOVE | 132 | 98 | 4 | 1.33 | +65 | +16.3 |
| WOUNDS ON THE RANKS | 28 | 28 | 4 | 1.33 | +658 | +164.6 |
| CANNON PLANNED TARGET | 42 | 42 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +82 | +27.4 |
| THE ROW IN ITS ORDER | 25 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +45 | +15.1 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +21 | +10.5 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -18 | -8.8 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +290 | +145.1 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +129 | +64.4 |
| HIS TURN DENIED | 7 | 7 | 2 | 0.67 | +53 | +26.3 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MISSILES IN THE MOVE | 20 | 15 | 2 | 0.67 | +23 | +11.7 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 2 | 0.67 | -147 | -73.6 |
| REDIRECT COUNTER | 4 | 2 | 2 | 0.67 | +72 | +36.1 |
| RISK BY ARC | 10 | 10 | 2 | 0.67 | +91 | +45.6 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +13 | +6.6 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| BACKUP TARGETS | 1 | 1 | 1 | 0.33 | +3 | +2.7 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +4.4 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DENIED BY THE FIGHT | 4 | 4 | 1 | 0.33 | +22 | +21.7 |
| EXACT ROUND | 9 | 9 | 1 | 0.33 | +59 | +58.7 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +12 | +11.5 |
| HUNT IN PAIRS | 4 | 2 | 1 | 0.33 | +8 | +8.3 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +88 | +88.4 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +15 | +14.7 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +37 | +37.0 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +14 | +13.5 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -11 | -11.4 |
| MAX FOR POSITIONING | 10 | 9 | 1 | 0.33 | +7 | +7.0 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +22 | +21.7 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 1 | 0.33 | +0 | +0.3 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +43 | +43.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +91 | +91.2 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 26 | 26 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -15 | -15.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 6 | 1 | 0.33 | +59 | +58.7 |
| WHOLE FIGHT DANGER | 11 | 11 | 1 | 0.33 | +123 | +122.9 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +22 | +21.7 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 19 | 18 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 60 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FALLS SHORT | 55 | 53 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 33 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 23 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 72 | 72 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 24 | 24 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 55 | 54 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 141 | 141 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 16 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 57 | 54 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 21 | 12 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 31 | 27 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS A LANE | 10 | 9 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 278 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 88 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 265 | 264 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 284 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 5.00 | 20.9 |
| ARMY TABLE | rule | 1.67 | 5.33 | 37.6 |
| HOLDER ASSIGNMENT | rule | 1.33 | 1.33 | 34.5 |
| ONE PROMISE A TARGET | rule | 1.00 | 1.00 | 58.9 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | 0.33 | 10.9 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 45.0 |
| CHAFF PASSED | rule | - | 0.67 | 8.8 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 0.33 | 73.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 286.0 |
| MARCH OF THE TABLE | rule | 0.33 | - | 11.4 |
| SUPPORT NARROWED | rule | 0.33 | - | 15.0 |

### Plans: cora-bb45c30-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 67% | 286 | 76 | 27% |
| Mine | join | 3.3 | 80% | 32 | 0 | 0% |
| Mine | move | 27.7 | 98% | 1692 | 0 | 0% |
| Mine | shoot | 18.7 | 82% | 1335 | 2231 | 167% |
| Opponent | charge | 1.7 | 100% | 194 | 185 | 96% |
| Opponent | move | 35.3 | 93% | 2123 | 0 | 0% |
| Opponent | shoot | 3.3 | 80% | 199 | 226 | 113% |
| Opponent | support | 0.7 | 100% | 36 | 0 | 0% |

### Battle groups: cora-bb45c30-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 33% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 18 (12) | 5 | 14 | 19 | 33% | 3.5 | 8 (7) | 59 (2) | 6 (2) | 9 (6) | 38 (5) |
| Mine | Clean-up | 1 | 82 (1) | 0 | 82 | 0 | 100% | - | - | 82 (1) | - | 82 (1) | - |
| Mine | Fast Hammer | 8 | 47 (8) | 18 | 29 | 37 | 25% | 3.7 | 63 (4) | 0 (3) | 88 (1) | 72 (4) | 20 (4) |
| Mine | Hammer | 2 | 38 (2) | 0 | 38 | 108 | 0% | 1.5 | - | 0 (1) | 65 (1) | 38 (2) | - |
| Mine | Shooter | 5 | 70 (5) | 0 | 70 | 51 | 0% | 1.4 | 78 (2) | 128 (1) | 0 (2) | 104 (3) | 0 (2) |
| Mine | War machine | 10 | 103 (10) | 103 | 0 | 10 | 0% | 1.3 | 62 (8) | 270 (2) | - | 52 (1) | 109 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 35 (4) | 0 | 35 | 22 | 25% | 1.7 | 0 (3) | 91 (1) | - | 35 (4) | - |
| Opponent | Character | 9 | 26 (9) | 26 | 0 | 25 | 22% | 2.1 | 47 (1) | 48 (4) | 0 (4) | 26 (5) | 26 (4) |
| Opponent | Clean-up | 3 | 278 (3) | 278 | 0 | 28 | 67% | 6.0 | 494 (2) | 0 (1) | - | 0 (1) | 494 (2) |
| Opponent | Fast Hammer | 5 | 56 (5) | 56 | 0 | 48 | 20% | 3.2 | 44 (1) | 124 (2) | 0 (2) | 17 (3) | 124 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (3) | - | - | - | 0 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 61 | 67% | 1.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Holder | 3 | 117 (3) | 23 | 94 | 0 | 33% | 1.0 | 150 (1) | 102 (2) | - | 188 (2) | 0 (1) |
| Opponent | Shooter | 7 | 133 (7) | 19 | 114 | 24 | 0% | 1.1 | 138 (2) | 143 (3) | 110 (2) | 133 (3) | 133 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cora-bb45c30-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 500 | 86 | 2.0 | 1.2 | 43 | 32 | +11 | 1 of 6 | 4 of 6 | +19 | +10 |
| Opponent | Lizardmen | 1 | 0 | 77 | 1.0 | 1.0 | 77 | 0 | +77 | 0 of 1 | 1 of 1 | - | +77 |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 1205 | 3.0 | 1.3 | 402 | 0 | +402 | 3 of 3 | 1 of 3 | +691 | +257 |
| Opponent | Wood Elf Realms | 1 | 189 | 359 | 2.0 | 1.0 | 180 | 0 | +180 | 1 of 2 | 2 of 2 | - | +180 |
| **Opponent** | all armies | 3 | 78 | 547 | 2.0 | 1.2 | 274 | 0 | +274 | 4 of 6 | 4 of 6 | +691 | +190 |

### Effective charges: cora-bb45c30-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 6 | 1 (net -189) | 0 | 0 | 1 (net +0) | 1 (net +19) | 2 (net +83) | 1 | 0% (0 of 5) |
| Opponent | Lizardmen | 1 | 0 | 0 | 0 | 0 | 1 (net +77) | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net +85) | 0 | 0 | 0 | 0 | 2 (net +560) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: cora-bb45c30-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 189 | 405 | -189 | 58 | 189 | -131 | -69.4 |
| Mine | 76-89% | 1 | 189 | 108 | +0 | 261 | 203 | +58 | +30.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 214 | 83 | +83 | 83 | 0 | +83 | +38.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 419 | 19 | +19 | 19 | 0 | +19 | +4.5 |
| Mine | No odds | 1 | 181 | 72 | +72 | 72 | 0 | +72 | +39.8 |
| Mine | All fights | 6 | 234 | 128 | +11 | 96 | 65 | +31 | +13.1 |
| Opponent | Long shot (under 50%) | 1 | 195 | 371 | +85 | 85 | 0 | +85 | +43.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 348 | 318 | +560 | 560 | 167 | +393 | +112.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 399 | 77 | +77 | 77 | 0 | +77 | +19.3 |
| Opponent | No odds | 2 | 104 | 117 | +180 | 180 | 0 | +180 | +172.6 |
| Opponent | All fights | 6 | 250 | 220 | +274 | 274 | 56 | +218 | +87.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p5 | move | 16 | 3 (19%) | 3 (19%) | 1 (6%) | 12 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

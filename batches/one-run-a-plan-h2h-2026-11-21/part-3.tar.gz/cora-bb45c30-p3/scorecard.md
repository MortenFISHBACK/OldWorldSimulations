# Doctrine scorecard: cora-bb45c30-p3

### Scorecard: cora-bb45c30-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 7 | 3 | 3 | 3 | 1 | 0 | 0 | 139 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1236 |
| L0421 | 1 | 1 | Mine | no | 5 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 1 | 7 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 6.3 | 3.5 | 1.7 | 2.3 | 0.3 | 0.0 | 0.0 | 173.0 |
| **Average** | | | Opponent | 0% | 0.0 | - | 0.3 | 4.0 | 0.0 | 0.0 | 0.0 | 668.7 |

### KPIs: cora-bb45c30-p3

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 9) | 50% (4 of 8) | 24% (4 of 17) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 33% (1 of 3); on the table 67% | 50% (2 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 2); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 17% (1 of 6); on the table 33% | 29% (2 of 7); on the table 43% |
| Magic missiles tried each own turn | 50%+ | 17% (2 of 12) | 50% (3 of 6) | 28% (5 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 29% (2 of 7) | 50% (3 of 6) | 38% (5 of 13) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 38% (3 of 8) | 38% (3 of 8) |
| Points that never fought | lower | 72% (4295 of 5998) | 59% (3540 of 5999) | 65% (7835 of 11997) |
|   infantry points that never fought | lower | 95% (1359 of 1424) | 59% (1003 of 1703) | 76% (2362 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (12 of 23) | 73% (19 of 26) | 63% (31 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (2191 of 5120) | 68% (3196 of 4677) | 55% (5387 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (20%) | 0.7 (67%) | 1.3 (31%) |
| MARCHED: its unit marched | 1.0 (30%) | 0.3 (33%) | 1.3 (31%) |
| IN COMBAT: engaged in combat | 0.7 (20%) | 0.0 (0%) | 0.7 (15%) |
| GONE: slain | 1.0 (30%) | 0.0 (0%) | 1.0 (23%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 0.3 | 1.7 | 1.0 | 1.0 |
| not cast | 2.0 | 3.7 | 4.3 | 3.0 | 11.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (15%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (45%) | 1.3 (31%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (31%) | 0.3 (11%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (18%) | 0.7 (15%) | 0.3 (11%) | 0.0 (0%) |
| GONE: slain | 1.0 (50%) | 1.0 (27%) | 1.0 (23%) | 1.0 (33%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (44%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (50%) | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.3 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | - | 100% (1 of 1) |
| the unit moved after it | 0% (0 of 1) | - | 0% (0 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (49 of 83) | 67% (63 of 94) | 63% (112 of 177) |
|   cavalry | 64% (7 of 11) | 0% (0 of 7) | 39% (7 of 18) |
|   character | 50% (5 of 10) | 67% (12 of 18) | 61% (17 of 28) |
|   chariot | 54% (13 of 24) | 45% (5 of 11) | 51% (18 of 35) |
|   infantry | 17% (2 of 12) | 40% (8 of 20) | 31% (10 of 32) |
|   war machine | 85% (22 of 26) | 100% (38 of 38) | 94% (60 of 64) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (24%) | 1.3 (13%) | 4.0 (18%) |
| FLEEING: it fled or was fleeing | 0.7 (6%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.7 (41%) | 5.0 (48%) | 9.7 (45%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (6%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (29%) | 3.0 (29%) | 6.3 (29%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 1.7 | 57% | 3.3 pts | 8 pts |
| character | 6.7 | 5.3 | 65% | 18.0 pts | 120 pts |
| chariot | 6.0 | 4.3 | 56% | 14.5 pts | 87 pts |
| infantry | 6.3 | 2.3 | 74% | 13.3 pts | 85 pts |
| war machine | 20.0 | 17.3 | 62% | 20.4 pts | 408 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 0.3 | 1.0 |
| Charges that made contact a game | 1.3 | 0.3 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.14 contact (22 units) | 0.05 declared, 0.05 contact (22 units) | 0.11 declared, 0.09 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (1 of 1) | - | 25% (1 of 4) |
| Character in a unit | 100% (8 of 8) | 50% (1 of 2) | - | 90% (9 of 10) |
| Character on its own | 100% (4 of 4) | 50% (1 of 2) | 33% (1 of 3) | 67% (6 of 9) |
| Chariot | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| Infantry | 75% (6 of 8) | 40% (2 of 5) | 0% (0 of 1) | 57% (8 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 57% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 0% (0 of 4); on the table 25% | - | 67% | 79% (11 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 50% | 50% (3 of 6) | 44% | 67% (6 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p3, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 100% (2) | 100% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cora-bb45c30-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 75% (3 of 4) | 0% (0 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 53% (19 of 36) | 69% (31 of 45) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 71% (5 of 7) |
| Strategy | Lone characters that fought | 67% (4 of 6) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.3 | 4.0 |
| Movement | Points that never moved of their own | 173.0 | 668.7 |
| Movement | Fights charged into per game | 1.3 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 2, net +120 | 1 of 1, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (12 of 27) | 72% (18 of 25) |
| Shooting | Points destroyed by shooting units | 152.3 | 0.0 |
| Shooting | War machine shots | 7.3 | 12.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 53% (20 of 38) |
| Shooting | Points destroyed by war machines | 176.0 | 261.3 |
| Magic | Magic missiles cast | 0.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 67% (2 of 3) |
| Magic | Wounds caused by magic missiles | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 0.3 / 1.0 | 1.3 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 107.7 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +35 | +0 |
| Combat | Net per 100 charger points, damage counted | +9.3 | - |
| Combat | First round won (charged fights) | 50% | 0% |
| Combat | Net points per charged fight | +88 | +0 |
| Combat | Net points per supported fight / lone fight | - / +88 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 4 | 1 of 1 |
| Game | Points lost | 350.3 | 733.3 |
| Game | VP from objectives | 873.3 | 843.3 |
| Game | Lone holders (player turns) | 6.3 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +413 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1084
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +234.5 | 0.0 | 79.7 |
| ARMY TABLE | 15.3 | +334.3 | 0.0 | 92.7 | 15.3 | -95.8 | 0.0 | 244.3 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 43.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.6 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.7 | -240.1 | 159.3 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 0.7 | +0.0 | 68.0 | 0.0 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 12.3 | +484.3 | 1194.7 | 190.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 1.7 | +5.8 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +1.9 | 0.0 | 12.0 |
| CHALLENGE BY POINTS | 0.3 | +5.4 | 0.0 | 193.3 | 0.3 | +5.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 318.7 |
| CHARGE LOSSES | 16.0 | -626.2 | 0.0 | 0.0 | 10.0 | -530.7 | 0.0 | 364.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 237.7 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 43.3 | 7.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 70.0 |
| CONVEYANCE SEARCH | 0.3 | +11.5 | 46.3 | 0.0 | - | - | - | - |
| COVER ONCE | 4.0 | -79.6 | 0.0 | 31.7 | 3.0 | -312.7 | 0.0 | 159.3 |
| DENIED BY THE FIGHT | 0.3 | -2.6 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| EVASIVE BY THE ODDS | 0.3 | +0.0 | 79.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +7.2 | 79.7 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +0.8 | 159.3 | 193.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 6.7 | +83.8 | 0.0 | 92.7 | 8.7 | +135.3 | 0.0 | 0.0 |
| FEATURE BUFFS | 0.3 | +5.6 | 0.0 | 0.0 | 1.3 | +5.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +82.9 | 159.3 | 193.3 | - | - | - | - |
| FIRE IN ORDER | 1.3 | +0.0 | 41.7 | 31.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 93.0 | +6636.5 | 2028.7 | 669.3 | 90.3 | +5195.7 | 2961.3 | 1345.7 |
| FLANK NOT WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 79.7 |
| FOLLOW UP WEIGHED | 0.3 | +44.8 | 0.0 | 0.0 | 0.3 | +87.9 | 0.0 | 70.0 |
| FOUR ROUNDS | 1.7 | +315.6 | 159.3 | 193.3 | 0.3 | +3.0 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -53.1 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 14.3 | +2085.8 | 0.0 | 43.3 | 3.7 | +99.3 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +24.9 | 21.7 | 0.0 | 1.7 | +0.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 2.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 229.3 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 91.7 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS MOVE AND SHOT | 2.3 | -20.5 | 0.0 | 0.0 | 3.3 | -113.7 | 0.0 | 43.3 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 30.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 3.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 46.7 | +2079.7 | 0.0 | 199.3 | 39.0 | +1412.4 | 0.0 | 777.3 |
| HIS SHOTS BY HIS RUN | 31.3 | +833.5 | 0.0 | 179.3 | 27.3 | +617.3 | 0.0 | 734.0 |
| HIS TURN DENIED | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 318.7 |
| HOLDER ASSIGNMENT | 9.7 | +964.8 | 0.0 | 0.0 | 8.7 | +729.7 | 0.0 | 226.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -90.8 | 159.3 | 193.3 | - | - | - | - |
| HUNT IN PAIRS | 0.7 | +127.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 7.0 | -112.6 | 0.0 | 68.0 | 9.3 | -117.8 | 0.0 | 70.3 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 70.0 | 21.7 | 0.3 | +0.0 | 0.0 | 79.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -5.1 | 159.3 | 0.0 | - | - | - | - |
| MANOEUVRE | 3.3 | +11.7 | 0.0 | 0.0 | 2.3 | +3.1 | 0.0 | 79.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +92.5 | 0.0 | 0.0 | 0.7 | +36.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +121.1 | 0.0 | 0.0 | 1.0 | +17.9 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 1.0 | +13.5 | 0.0 | 0.0 | 1.7 | +8.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.0 | +28.5 | 0.0 | 0.0 | 2.7 | +11.0 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.0 | +91.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.7 | -89.1 | 0.0 | 193.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.3 | +125.3 | 0.0 | 0.0 | 0.7 | +44.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +297.5 | 0.0 | 0.0 | 6.3 | +254.4 | 0.0 | 159.3 |
| NEXT CHARGE BY LIST | 2.0 | +119.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.7 | -95.7 | 159.3 | 193.3 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -280.9 | 0.0 | 31.7 | 3.7 | -134.9 | 0.0 | 41.7 |
| ONE FIGHT FORMULA | 4.0 | -83.0 | 0.0 | 0.0 | 0.7 | -1.0 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +18.8 | 79.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 1.7 | +26.7 | 0.0 | 0.0 | 4.0 | -62.4 | 0.0 | 159.3 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +2.4 | 79.7 | 193.3 | - | - | - | - |
| PATHS CROSS | 0.3 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +40.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.7 | +777.4 | 477.7 | 603.0 | 42.0 | +1343.6 | 865.3 | 845.0 |
| PROMISE BY ITS OWN SUM | 6.3 | -376.9 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 26.0 | +2480.6 | 331.3 | 63.3 | 24.7 | +2021.0 | 298.7 | 263.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +4.0 | 0.0 | 285.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 0.7 | -21.9 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 43.3 |
| REFORMS TO MEET IT | 0.3 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +99.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | -22.3 | 159.3 | 193.3 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.0 | -12.9 | 159.3 | 193.3 | - | - | - | - |
| RUN DOWN | 0.7 | -0.7 | 159.3 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +23.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.7 | -386.5 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.7 | +379.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.3 | +0.0 | 0.0 | 95.0 | 14.7 | +0.0 | 0.0 | 190.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +78.7 | 202.7 | 0.0 | - | - | - | - |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT OR CHARGE | 1.3 | -15.2 | 159.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 27.3 | +411.5 | 0.0 | 150.0 | 20.7 | -15.1 | 0.0 | 688.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.3 | +417.4 | 0.0 | 126.7 | 18.3 | +1356.7 | 0.0 | 349.3 |
| SPELL WORTH | 0.3 | +3.1 | 193.3 | 193.3 | 3.7 | +81.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 48.3 |
| STAND AND SHOOT | 0.3 | -3.0 | 0.0 | 193.3 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 51.7 | +0.0 | 1869.3 | 389.3 | 54.0 | +0.0 | 2961.3 | 809.7 |
| STAY WORTH | 28.3 | +265.9 | 1187.3 | 221.7 | 38.0 | +403.8 | 2258.0 | 637.3 |
| STRIKE BY THE ODDS | 0.7 | +44.1 | 159.3 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 96.7 |
| SUPPORT ADDS | 0.7 | +22.2 | 0.0 | 0.0 | 6.0 | +989.5 | 0.0 | 318.7 |
| SUPPORT WORKED OUT | 0.7 | +22.2 | 0.0 | 0.0 | 6.0 | +989.5 | 0.0 | 318.7 |
| SWIFTSTRIDE BY POINTS | 0.3 | +2.9 | 0.0 | 37.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 21.7 | 3.7 | +0.0 | 0.0 | 43.3 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 21.7 | 2.7 | +0.0 | 0.0 | 43.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.7 | +0.0 | 0.0 | 206.3 | 43.3 | +0.0 | 0.0 | 383.3 |
| TIME ON OUR SIDE | 25.7 | +317.3 | 269.3 | 86.7 | 14.7 | +207.7 | 0.0 | 226.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 2.7 | +0.0 | 352.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -99.9 | 159.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.0 | -66.2 | 0.0 | 0.0 | 1.0 | -270.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +199.1 | 0.0 | 0.0 | 2.0 | +47.6 | 0.0 | 294.0 |

### Rule changes: cora-bb45c30-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 92 | 92 | 64 | 21.33 | +491 | +7.7 |
| HIS SHOT LIST | 257 | 247 | 56 | 18.67 | +869 | +15.5 |
| HOLDER ASSIGNMENT | 55 | 55 | 51 | 17.00 | +2741 | +53.7 |
| HIS SHOTS BY HIS RUN | 176 | 170 | 48 | 16.00 | +555 | +11.6 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -1247 | -46.2 |
| GOAL WALK | 54 | 48 | 21 | 7.00 | +1877 | +89.4 |
| SHOT RISK POINTS | 144 | 139 | 21 | 7.00 | +356 | +17.0 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 121 | 97 | 15 | 5.00 | +10 | +0.7 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| IDLE COST | 49 | 40 | 13 | 4.33 | +59 | +4.6 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FIVE ACTION | 550 | 538 | 8 | 2.67 | +590 | +73.8 |
| PROMISE BY ITS OWN SUM | 21 | 21 | 8 | 2.67 | -1131 | -141.3 |
| QUARTER ODDS | 152 | 152 | 8 | 2.67 | +306 | +38.3 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 57 | 57 | 6 | 2.00 | -509 | -84.8 |
| FIRE IN ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 199 | 174 | 6 | 2.00 | +140 | +23.4 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 10 | 8 | 5 | 1.67 | +75 | +14.9 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SET UP BY THE SET | 8 | 8 | 5 | 1.67 | +700 | +140.0 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 5 | 1.67 | +96 | +19.3 |
| SUPPORT ADDS | 20 | 20 | 5 | 1.67 | +384 | +76.9 |
| SUPPORT WORKED OUT | 20 | 20 | 5 | 1.67 | +384 | +76.9 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| MANOEUVRE | 17 | 17 | 4 | 1.33 | +44 | +11.1 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| SHOTS IN THE MOVE | 107 | 73 | 4 | 1.33 | +780 | +195.1 |
| FIGHT TO THE END | 3 | 3 | 3 | 1.00 | +154 | +51.2 |
| MARCH CHECK | 5 | 4 | 3 | 1.00 | +87 | +29.1 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 3 | 1.00 | +12 | +4.0 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +703 | +351.7 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +31 | +15.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 46 | 40 | 2 | 0.67 | +22 | +10.8 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +398 | +199.0 |
| FOUR ROUNDS | 6 | 5 | 2 | 0.67 | +305 | +152.3 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -22 | -11.2 |
| MOVE TO CHARGE COMPUTED | 9 | 9 | 2 | 0.67 | +5 | +2.5 |
| NEXT CHARGE BY LIST | 6 | 6 | 2 | 0.67 | +5 | +2.5 |
| SHOTS AFTER THE MOVES | 23 | 23 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 14 | 14 | 2 | 0.67 | +30 | +14.8 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.9 |
| CHARGE LOSSES | 78 | 73 | 1 | 0.33 | +143 | +143.2 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +166 | +166.5 |
| ONE OBJECTIVE FORMULA | 17 | 11 | 1 | 0.33 | +28 | +28.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -6 | -6.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -5 | -4.9 |
| REDIRECT COUNTER | 3 | 1 | 1 | 0.33 | +56 | +56.4 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | +38 | +37.5 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +298 | +297.6 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +71 | +71.3 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 1 | 0.33 | +22 | +22.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +8.8 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CAST JOB | 5 | 5 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 28 | 28 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 7 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 54 | 53 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| COVER ONCE | 21 | 11 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | not checked | - | - | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 5 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 13 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 23 | 23 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 14 | 14 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 9 | 9 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 31 | 31 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 9 | 9 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 85 | 84 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 5 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 8 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 14 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| NEARER NOT NEEDED | 36 | 33 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 14 | 5 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 248 | trace | - | - | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 75 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 24 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 317 | 313 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 16 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 261 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 8 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 3.67 | 44.9 |
| ARMY TABLE | rule | 2.00 | 1.67 | 121.5 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | - | 141.3 |
| RULE SWITCHED OFF | gate | 1.00 | - | 56.3 |
| CANNON PLANNED TARGET | rule | - | 0.67 | 254.5 |
| MARCH OF THE TABLE | rule | 0.67 | - | 11.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 13.5 |
| PATHS CROSS | rule | 0.33 | - | 6.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 4.9 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |

### Plans: cora-bb45c30-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 20% | 366 | 85 | 23% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 28.0 | 95% | 2097 | 0 | 0% |
| Mine | shoot | 10.7 | 62% | 395 | 693 | 175% |
| Opponent | charge | 0.3 | 0% | 3 | 0 | 0% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 26.7 | 90% | 1490 | 0 | 0% |
| Opponent | shoot | 13.3 | 62% | 852 | 1344 | 158% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 42 (11) | 42 | 0 | 23 | 18% | 2.2 | 38 (5) | 62 (4) | 19 (2) | 31 (7) | 55 (4) |
| Mine | Clean-up | 3 | 99 (3) | 0 | 99 | 0 | 100% | - | 99 (3) | - | - | 150 (2) | 0 (1) |
| Mine | Hammer | 8 | 29 (8) | 14 | 15 | 4 | 12% | 1.9 | 0 (2) | 34 (6) | - | 51 (5) | 7 (3) |
| Mine | Holder | 4 | 35 (4) | 0 | 35 | 49 | 75% | 2.0 | 0 (1) | 46 (3) | - | 108 (1) | 8 (3) |
| Mine | Shooter | 1 | 188 (1) | 0 | 188 | 0 | 0% | 2.0 | 188 (1) | - | - | - | 188 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 0 (14) | 0 | 0 | 27 | 36% | 3.2 | 0 (9) | 0 (1) | 0 (2) | 0 (10) | 0 (2) |
| Opponent | Clean-up | 4 | 96 (4) | 0 | 96 | 0 | 75% | 6.0 | - | 96 (4) | - | 96 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 6 | 34 (6) | 17 | 17 | 59 | 17% | 2.6 | 44 (2) | 0 (1) | 42 (3) | 34 (6) | - |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 54 | 75% | 4.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 79 (9) | 79 | 0 | 62 | 11% | 1.0 | 79 (9) | - | - | 0 (1) | 92 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: cora-bb45c30-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 128 | 176 | 2.0 | 1.0 | 88 | 0 | +88 | 4 of 4 | 2 of 4 | - | +88 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 328 | 117 | 1.3 | 1.0 | 88 | 0 | +88 | 4 of 4 | 2 of 4 | - | +88 |
| Opponent | Dwarfen Mountain Holds | 1 | 719 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 261 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |

### Effective charges: cora-bb45c30-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 2 (net +120) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 339 | 239 | +120 | 127 | 107 | +20 | +5.9 |
| Mine | No odds | 2 | 410 | 340 | +56 | 180 | 130 | +50 | +12.2 |
| Mine | All fights | 4 | 374 | 289 | +88 | 153 | 119 | +35 | +9.3 |
| Opponent | Long shot (under 50%) | 1 | 0 | 480 | +0 | 0 | 0 | +0 | - |
| Opponent | All fights | 1 | 0 | 480 | +0 | 0 | 0 | +0 | - |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p3 | move | 10 | 1 (10%) | 0 (0%) | 0 (0%) | 9 (90%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

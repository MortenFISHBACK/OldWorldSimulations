# Doctrine scorecard: cora-bb45c30-p30

### Scorecard: cora-bb45c30-p30

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 537 |
| L0913 | 1 | 1 | Opponent | no | 19 | 3 | 2 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 250 |
| L0930 | 6 | 1 | Opponent | no | 7 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 7 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 2.7 | 3.0 | 1.0 | 0.7 | 0.3 | 0.0 | 0.0 | 372.3 |
| **Average** | | | Opponent | 0% | 8.7 | 2.5 | 1.0 | 2.3 | 0.7 | 0.0 | 0.0 | 143.3 |

### KPIs: cora-bb45c30-p30

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 57% (8 of 14) | 0% (0 of 13) | 30% (8 of 27) |
| Winner chose to follow up after the loser gave ground |  | 33% (1 of 3); on the table 100% | 100% (3 of 3); on the table 100% | 67% (4 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 25% (1 of 4); on the table 75% | 100% (6 of 6); on the table 100% | 70% (7 of 10); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 35% (17 of 48) | 0% (0 of 12) | 28% (17 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (17 of 42) | 0% (0 of 8) | 34% (17 of 50) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 53% (8 of 15) | 53% (8 of 15) |
| Points that never fought | lower | 58% (3501 of 5997) | 72% (4302 of 5999) | 65% (7803 of 11996) |
|   infantry points that never fought | lower | 68% (1089 of 1591) | 83% (1386 of 1660) | 76% (2475 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (25 of 34) | 65% (15 of 23) | 70% (40 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 50% (1 of 2); 2.0 uses a game | 75% (3 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 73% (4130 of 5667) | 62% (3178 of 5150) | 68% (7308 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.7 (55%) | 1.7 (42%) | 7.3 (51%) |
| MARCHED: its unit marched | 2.7 (26%) | 0.7 (17%) | 3.3 (23%) |
| IN COMBAT: engaged in combat | 1.7 (16%) | 0.0 (0%) | 1.7 (12%) |
| GONE: slain | 0.3 (3%) | 1.3 (33%) | 1.7 (12%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 3.3 | 1.0 | 5.7 | 0.3 | 0.3 |
| not cast | 1.3 | 4.3 | 1.0 | 14.3 | 1.7 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (77%) | 0.0 (0%) | 7.3 (51%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (23%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (100%) | 0.0 (0%) | 1.0 (100%) | 1.7 (12%) | 0.0 (0%) | 3.3 (17%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (23%) | 0.0 (0%) | 0.3 (2%) | 1.7 (100%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 100% (3 of 3) | 100% (3 of 3) |
| the unit moved after it | - | 33% (1 of 3) | 33% (1 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (63 of 101) | 74% (39 of 53) | 66% (102 of 154) |
|   character | 100% (5 of 5) | 46% (6 of 13) | 61% (11 of 18) |
|   chariot | 64% (7 of 11) | 78% (7 of 9) | 70% (14 of 20) |
|   infantry | 41% (18 of 44) | 74% (14 of 19) | 51% (32 of 63) |
|   monster | 50% (4 of 8) | - | 50% (4 of 8) |
|   war machine | 88% (29 of 33) | 100% (12 of 12) | 91% (41 of 45) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (32%) | 1.3 (29%) | 5.3 (31%) |
| CHARGED: it charged | 0.7 (5%) | 1.0 (21%) | 1.7 (10%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| MOVED: a war machine that moved | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 2.7 (21%) | 1.0 (21%) | 3.7 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 2.3 (18%) | 0.3 (7%) | 2.7 (15%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (11%) | 1.0 (21%) | 2.3 (13%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 4.3 | 1.3 | 69% | 10.2 pts | 44 pts |
| chariot | 4.7 | 1.7 | 86% | 6.4 pts | 30 pts |
| infantry | 14.0 | 7.0 | 69% | 9.1 pts | 127 pts |
| monster | 2.7 | 0.3 | 88% | 1.8 pts | 5 pts |
| war machine | 14.0 | 9.7 | 69% | 27.0 pts | 378 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 2.0 | 1.7 |
| Charges that made contact a game | 1.3 | 1.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.40 declared, 0.40 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.11 declared, 0.11 contact (19 units) | 0.26 declared, 0.22 contact (23 units) | 0.19 declared, 0.17 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Character in a unit | 100% (5 of 5) | 100% (2 of 2) | - | 100% (7 of 7) |
| Character on its own | 100% (2 of 2) | 50% (2 of 4) | 50% (2 of 4) | 60% (6 of 10) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 50% (7 of 14) | 75% (3 of 4) | - | 56% (10 of 18) |
| Monster | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 0% (0 of 3); on the table 67% | 42% (10 of 24) | 63% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (1 of 1); on the table 100% | 29% (7 of 24) | 50% | 70% (7 of 10) | 100% (2 of 2); 8.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 71% | 25% (2 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | - | 0% (0 of 6) | 72% | 89% (8 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | 100% (5 of 5); on the table 100% | - | 73% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p30, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (3) | 100% (4) | 100% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cora-bb45c30-p30

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 75% (3 of 4) | 67% (4 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (11 of 44) | 48% (10 of 21) |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (3 of 4) | - |
| Strategy | Joined characters whose unit fought | 14% (1 of 7) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 372.3 | 143.3 |
| Movement | Fights charged into per game | 1.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net +48 | 1 of 3, net +227 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (17 of 34) | 66% (19 of 29) |
| Shooting | Points destroyed by shooting units | 166.0 | 125.0 |
| Shooting | War machine shots | 10.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (20 of 30) | 8% (1 of 12) |
| Shooting | Points destroyed by war machines | 201.7 | 0.0 |
| Magic | Magic missiles cast | 4.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (3 of 12) | - |
| Magic | Wounds caused by magic missiles | 12.3 | 4.3 |
| Magic | Points destroyed by magic (all spells) | 55.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.3 / 0.0 / 0.3 | 1.7 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 48.3 | 276.3 |
| Combat | Points run down | 0.0 | 321.7 |
| Combat | Net points per charged fight, damage counted | +12 | +237 |
| Combat | Net per 100 charger points, damage counted | +4.9 | +71.5 |
| Combat | First round won (charged fights) | 100% | 60% |
| Combat | Net points per charged fight | +10 | +306 |
| Combat | Net points per supported fight / lone fight | - / +10 | - / +306 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 4 | 3 of 5 |
| Game | Points lost | 731.0 | 470.3 |
| Game | VP from objectives | 690.0 | 996.7 |
| Game | Lone holders (player turns) | 2.7 | 8.7 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -510 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1201
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p30

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 1.0 | +76.1 | 0.0 | 34.7 | - | - | - | - |
| ARMY TABLE | 18.3 | +395.7 | 0.0 | 259.3 | 21.3 | +184.3 | 0.0 | 280.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 400.0 | 41.7 | 0.7 | +0.0 | 83.3 | 0.0 |
| CANNON PLANNED TARGET | 9.3 | +724.3 | 1225.0 | 166.7 | 4.0 | +87.7 | 208.3 | 0.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 2.3 | +72.5 | 0.0 | 0.0 | 0.7 | +11.1 | 69.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 266.7 |
| CHAFF PASSED | - | - | - | - | 0.3 | -2.2 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +40.0 | 0.0 | 86.3 | 0.7 | +4.9 | 0.0 | 0.0 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.7 | -841.8 | 0.0 | 151.3 | 28.3 | -1894.4 | 0.0 | 1546.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 48.3 | 45.0 | 0.7 | +0.0 | 86.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 54.0 | 10.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 88.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +255.5 | 266.7 | 266.7 |
| COVER ONCE | 7.3 | -635.6 | 0.0 | 75.7 | 3.0 | -113.8 | 0.0 | 198.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.2 | 75.7 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 0.0 | 7.0 | +37.9 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -13.8 | 86.3 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +3.3 | 48.3 | 79.7 | 0.7 | +5.4 | 86.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +3.9 | 0.0 | 79.7 | 2.0 | +10.8 | 248.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 24.0 | +309.3 | 0.0 | 544.7 |
| FEATURE BUFFS | 2.0 | +32.7 | 0.0 | 0.0 | 2.7 | +34.6 | 0.0 | 130.7 |
| FIGHT TO THE END | 0.3 | +0.6 | 0.0 | 34.7 | 0.7 | +5.5 | 45.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 41.7 | 0.0 |
| FIVE ACTION | 88.0 | +7573.7 | 2917.3 | 825.0 | 96.7 | +5950.2 | 1060.3 | 1809.3 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 75.7 | 2.7 | +0.0 | 0.0 | 32.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +244.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +61.4 | 48.3 | 79.7 | 2.0 | +195.8 | 248.7 | 0.0 |
| FREED FROM HIS FIGHT | 7.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -11.8 | 65.3 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 1.0 | -14.2 | 162.0 | 0.0 |
| GOAL WALK | 8.7 | +1432.3 | 0.0 | 0.0 | 15.0 | +1868.2 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +105.9 | 133.3 | 0.0 | 1.3 | +0.0 | 83.3 | 0.0 |
| GUN MASK | 3.3 | +108.7 | 0.0 | 151.3 | 2.0 | +23.8 | 0.0 | 133.3 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 5.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 151.3 | 11.7 | +0.0 | 0.0 | 579.0 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 151.3 | 5.3 | +0.0 | 0.0 | 48.3 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 133.3 |
| HIS MOVE AND SHOT | 2.0 | -31.5 | 0.0 | 0.0 | 7.0 | -98.5 | 0.0 | 217.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 108.0 | 5.3 | +0.0 | 0.0 | 360.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 133.3 |
| HIS RANDOM MOVE | 18.7 | +0.0 | 0.0 | 108.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.3 | +1166.0 | 0.0 | 342.7 | 71.7 | +3941.2 | 0.0 | 1701.0 |
| HIS SHOTS BY HIS RUN | 22.3 | +340.7 | 0.0 | 151.3 | 72.0 | +2207.2 | 0.0 | 1744.3 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +38.3 | 117.3 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 20.7 | +0.0 | 0.0 | 0.0 | 31.3 | +0.0 | 0.0 | 261.3 |
| HOLDER ASSIGNMENT | 12.0 | +1136.3 | 0.0 | 0.0 | 16.3 | +1667.9 | 0.0 | 65.3 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -30.1 | 48.3 | 79.7 | 1.7 | -69.2 | 203.7 | 0.0 |
| IDLE COST | - | - | - | - | 12.3 | -244.8 | 0.0 | 498.3 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 0.0 | 88.3 | 4.3 | +0.0 | 251.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -1.2 | 0.0 | 34.7 | 0.7 | +0.0 | 0.0 | 43.3 |
| LOST AFTER ESCAPE | 1.0 | +4.6 | 0.0 | 79.7 | 1.3 | +1.0 | 120.7 | 0.0 |
| MANOEUVRE | 1.7 | -9.2 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +65.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +58.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.7 | -281.4 | 0.0 | 54.0 | 0.7 | +34.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.3 | +69.1 | 0.0 | 54.0 | 1.0 | +15.1 | 0.0 | 266.7 |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.0 | +254.6 | 0.0 | 0.0 | 3.0 | +57.3 | 0.0 | 266.7 |
| MISSILES NEXT TURN | 14.0 | +237.3 | 0.0 | 54.0 | 4.7 | +47.1 | 0.0 | 626.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 266.7 |
| MOVE TO CHARGE COMPUTED | 4.0 | +194.7 | 0.0 | 0.0 | 3.7 | +297.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 11.7 | +558.5 | 0.0 | 75.7 | 7.7 | +336.4 | 0.0 | 32.7 |
| NEXT CHARGE BY LIST | 3.0 | +151.9 | 65.3 | 0.0 | 2.7 | +270.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -36.2 | 48.3 | 79.7 | 1.7 | -52.3 | 203.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -186.1 | 0.0 | 0.0 | 1.3 | -77.4 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 2.7 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -87.6 | 0.0 | 0.0 | 3.7 | -79.6 | 0.0 | 166.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -41.7 | 0.0 | 0.0 | 7.0 | +175.3 | 0.0 | 65.3 |
| ONE PROMISE A TARGET | 0.3 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +12.3 | 0.0 | 45.0 | 2.0 | +16.7 | 248.7 | 0.0 |
| OWN CAST FIRST | 1.0 | -8.7 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +10.0 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PLAN RESULT | 39.0 | +1430.3 | 982.0 | 1003.0 | 44.3 | +546.6 | 321.7 | 949.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.0 | +0.0 | 0.0 | 32.7 |
| PROMISE BY ITS OWN SUM | 7.0 | -204.7 | 0.0 | 0.0 | 4.3 | -3.5 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.0 | +0.0 | 65.3 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.3 | -13.2 | 65.3 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -13.6 | 65.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 14.0 | +1616.4 | 425.0 | 108.0 | 21.0 | +1965.4 | 291.7 | 520.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 5.0 | +86.4 | 0.0 | 96.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.7 | -11.6 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +15.9 | 88.3 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -32.6 | 0.0 | 0.0 | 0.3 | -1.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 75.7 | - | - | - | - |
| RISK BY ARC | 1.0 | -16.0 | 48.3 | 79.7 | 2.0 | -101.1 | 248.7 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -13.8 | 86.3 | 0.0 |
| RUN DOWN | 1.3 | -16.9 | 48.3 | 79.7 | 1.3 | -17.1 | 120.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -0.5 | 32.7 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +1.9 | 0.0 | 34.7 | - | - | - | - |
| SET UP BY THE SET | 0.7 | -28.7 | 0.0 | 0.0 | 0.3 | -3.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 14.7 | +0.0 | 0.0 | 201.3 | 7.7 | +0.0 | 0.0 | 43.3 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +44.5 | 43.3 | 0.0 | 1.7 | +14.4 | 0.0 | 0.0 |
| SHOT RISK POINTS | 12.7 | -138.0 | 0.0 | 259.3 | 42.3 | -635.3 | 0.0 | 1412.3 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 20.7 | +1373.7 | 0.0 | 243.0 | 12.7 | +369.1 | 0.0 | 310.0 |
| SPELL WORTH | - | - | - | - | 2.7 | +84.4 | 626.7 | 626.7 |
| SPELLS IN THE FIGHT | 0.3 | +1.3 | 48.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 336.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.2 | 75.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 75.7 | 180.0 |
| STANDS STILL | 36.7 | +0.0 | 2869.0 | 486.0 | 31.0 | +0.0 | 811.7 | 550.0 |
| STAY WORTH | 37.7 | +652.1 | 2738.7 | 395.7 | 22.3 | +334.3 | 811.7 | 331.7 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.3 | +82.0 | 0.0 | 108.0 | 3.3 | +135.2 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 45.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.3 | +82.0 | 0.0 | 108.0 | 3.3 | +135.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | 1.7 | +3.9 | 0.0 | 266.7 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 21.7 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 21.7 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 32.7 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 32.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.0 | +0.0 | 0.0 | 331.0 | 44.7 | +0.0 | 0.0 | 856.3 |
| TIED UP BY THE SUM | 0.7 | +58.5 | 48.3 | 45.0 | 0.7 | +70.5 | 117.3 | 0.0 |
| TIME ON OUR SIDE | 32.3 | +514.1 | 0.0 | 125.3 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +0.6 | 90.0 | 0.0 |
| WHO FIGHTS | 0.3 | -1.1 | 0.0 | 34.7 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.7 | 45.0 | 0.0 |
| WHOLE FIGHT DANGER | 6.7 | -657.9 | 0.0 | 0.0 | 2.7 | -297.5 | 0.0 | 465.3 |
| WOUNDS ON THE RANKS | 0.7 | +34.2 | 0.0 | 0.0 | 1.3 | +124.5 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p30

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 327 | 325 | 81 | 27.00 | +2152 | +26.6 |
| HOLDER ASSIGNMENT | 85 | 85 | 80 | 26.67 | +4772 | +59.7 |
| ARMY TABLE | 119 | 119 | 69 | 23.00 | +1510 | +21.9 |
| HIS SHOTS BY HIS RUN | 283 | 280 | 64 | 21.33 | +867 | +13.6 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| SHOT RISK POINTS | 165 | 163 | 23 | 7.67 | +864 | +37.6 |
| GOAL WALK | 71 | 70 | 20 | 6.67 | +3573 | +178.6 |
| FIVE ACTION | 554 | 550 | 19 | 6.33 | +518 | +27.3 |
| OFF BEST | 16 | 16 | 16 | 5.33 | -791 | -49.4 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| CHARGE LOSSES | 132 | 129 | 14 | 4.67 | +949 | +67.8 |
| MOVE TO CHARGE COMPUTED | 23 | 22 | 14 | 4.67 | +374 | +26.7 |
| QUARTER ODDS | 105 | 104 | 13 | 4.33 | +1201 | +92.4 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| PROMISE BY ITS OWN SUM | 34 | 34 | 11 | 3.67 | -625 | -56.8 |
| STAY WORTH | 180 | 165 | 11 | 3.67 | +95 | +8.6 |
| TIME ON OUR SIDE | 97 | 81 | 11 | 3.67 | +12 | +1.1 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CAST JOB | 9 | 9 | 9 | 3.00 | +77 | +8.6 |
| NEXT CHARGE BY LIST | 17 | 17 | 9 | 3.00 | +276 | +30.7 |
| FOUR ROUNDS | 10 | 10 | 8 | 2.67 | +465 | +58.1 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +110 | +13.7 |
| RANDOM MOVE BY FIGURES | 15 | 15 | 8 | 2.67 | +259 | +32.4 |
| ARTILLERY RE-ROLL WEIGHED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 7 | 2.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 5 | 1.67 | +32 | +6.3 |
| SUPPORT ADDS | 20 | 20 | 5 | 1.67 | +171 | +34.2 |
| SUPPORT WORKED OUT | 20 | 20 | 5 | 1.67 | +171 | +34.2 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 4 | 4 | 4 | 1.33 | -95 | -23.8 |
| COVER ONCE | 31 | 23 | 4 | 1.33 | +94 | +23.5 |
| FALLS SHORT | 72 | 59 | 4 | 1.33 | +31 | +7.8 |
| GUN MASK | 16 | 16 | 4 | 1.33 | +189 | +47.2 |
| IDLE COST | 37 | 32 | 4 | 1.33 | +35 | +8.8 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +197 | +49.2 |
| MAX FOR POSITIONING | 16 | 16 | 4 | 1.33 | +15 | +3.7 |
| NEARER NOT NEEDED | 58 | 49 | 4 | 1.33 | +115 | +28.8 |
| PROMISE KNOWS THE FIGHT | 6 | 6 | 4 | 1.33 | -40 | -9.9 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +164 | +40.9 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +228 | +76.1 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +135 | +45.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +34 | +11.4 |
| ONE OBJECTIVE FORMULA | 38 | 27 | 3 | 1.00 | +207 | +69.1 |
| OWN CAST FIRST | 3 | 3 | 3 | 1.00 | -26 | -8.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +734 | +367.1 |
| MISSILES IN THE MOVE | 42 | 28 | 2 | 0.67 | +18 | +9.2 |
| OVERRUNS AWAY | 7 | 7 | 2 | 0.67 | +8 | +3.9 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -41 | -20.4 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS IN THE MOVE | 100 | 79 | 2 | 0.67 | +12 | +5.9 |
| SURE REACH TOGETHER | 6 | 5 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 31 | 2 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -4 | -2.1 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +1 | +0.4 |
| WHOLE FIGHT DANGER | 28 | 27 | 2 | 0.67 | +26 | +13.1 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -7 | -6.6 |
| EVASIVE BY THE ODDS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 5 | 5 | 1 | 0.33 | +5 | +5.1 |
| FALL BACK GOOD ORDER | 9 | 9 | 1 | 0.33 | +8 | +7.5 |
| LOST AFTER ESCAPE | 7 | 7 | 1 | 0.33 | +0 | +0.4 |
| MISSILES NEXT TURN | 56 | 41 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -13 | -12.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +30 | +30.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +94 | +93.9 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -5 | -5.1 |
| RISK BY ARC | 9 | 9 | 1 | 0.33 | +6 | +5.9 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +6 | +5.6 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +0 | +0.4 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 40 | 40 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 49 | 49 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 14 | 14 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 26 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 17 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 55 | 55 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 10 | 10 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 27 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 15 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 56 | 55 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 15 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 156 | 156 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 27 | 16 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 250 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 2 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 67 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 40 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 203 | 201 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 28 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 260 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 15 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p30

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 1.33 | 49.4 |
| ARMY TABLE | rule | 1.67 | 2.33 | 87.4 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 0.67 | 56.8 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.00 | 17.0 |
| CHARGE NOW FIRST | rule | 0.67 | 0.67 | 23.8 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 9.9 |
| OWN CAST FIRST | rule | 1.00 | - | 8.7 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 20.4 |
| WAR ENGINE JOBS | rule | 0.67 | - | 2.1 |
| CHAFF PASSED | rule | - | 0.33 | 6.6 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 12.9 |
| REFUSING RETIRES | rule | 0.33 | - | 5.1 |

### Plans: cora-bb45c30-p30

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 34 | 48 | 141% |
| Mine | move | 25.3 | 96% | 1859 | 0 | 0% |
| Mine | shoot | 12.7 | 55% | 1329 | 1382 | 104% |
| Opponent | charge | 1.7 | 100% | 158 | 222 | 140% |
| Opponent | move | 36.7 | 94% | 2525 | 0 | 0% |
| Opponent | shoot | 6.0 | 61% | 326 | 325 | 100% |

### Battle groups: cora-bb45c30-p30

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p30

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 19 (10) | 19 | 0 | 31 | 30% | 3.3 | 28 (6) | 0 (3) | - | 32 (5) | 0 (4) |
| Mine | Clean-up | 3 | 66 (3) | 0 | 66 | 0 | 67% | 4.0 | 16 (1) | 92 (2) | - | 66 (3) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 64 | 0% | 3.3 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Mine | Hammer | 6 | 7 (6) | 7 | 0 | 54 | 17% | 2.2 | 22 (2) | 0 (4) | - | 8 (5) | 0 (1) |
| Mine | Shooter | 6 | 194 (6) | 64 | 130 | 33 | 0% | 1.7 | 0 (1) | 359 (3) | 43 (2) | 194 (6) | - |
| Mine | War machine | 8 | 56 (8) | 56 | 0 | 58 | 12% | 1.3 | 0 (3) | 0 (3) | 183 (2) | 0 (1) | 63 (7) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 25 | 25% | 2.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Opponent | Chaff | 2 | 155 (2) | 83 | 72 | 44 | 50% | 3.0 | 277 (1) | 0 (1) | - | 277 (1) | 0 (1) |
| Opponent | Character | 9 | 61 (9) | 61 | 0 | 35 | 44% | 2.0 | 0 (1) | 75 (7) | 63 (1) | 38 (5) | 92 (4) |
| Opponent | Clean-up | 3 | 122 (3) | 0 | 122 | 0 | 100% | - | 0 (1) | 221 (2) | - | 221 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 73 (6) | 0 | 73 | 20 | 83% | 1.0 | - | 110 (4) | 16 (2) | 73 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 24 (4) | 24 | 0 | 22 | 25% | 2.7 | - | 46 (2) | 0 (2) | 24 (4) | - |
| Opponent | Holder | 4 | 80 (4) | 34 | 45 | 0 | 50% | 3.5 | - | 80 (4) | - | 147 (1) | 59 (3) |
| Opponent | Shooter | 4 | 27 (4) | 27 | 0 | 28 | 25% | 1.7 | 0 (1) | 0 (1) | 37 (2) | 31 (3) | 0 (1) |
| Opponent | War machine | 2 | 89 (2) | 89 | 0 | 0 | 0% | 1.0 | - | - | 89 (2) | 0 (1) | 179 (1) |

### Charged fights: cora-bb45c30-p30

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 249 | 0 | 0.5 | 1.0 | 0 | 104 | -104 | 0 of 1 | 1 of 1 | - | -104 |
| Mine | Grand Cathay | 1 | 770 | 145 | 3.0 | 1.0 | 48 | 0 | +48 | 0 of 3 | 3 of 3 | - | +48 |
| **Mine** | all armies | 3 | 423 | 48 | 1.3 | 1.0 | 36 | 26 | +10 | 0 of 4 | 4 of 4 | - | +10 |
| Opponent | High Elf Realms | 1 | 375 | 444 | 2.0 | 1.0 | 222 | 0 | +222 | 1 of 2 | 1 of 2 | - | +222 |
| Opponent | Skaven | 1 | 0 | 135 | 1.0 | 1.0 | 135 | 0 | +135 | 0 of 1 | 1 of 1 | - | +135 |
| Opponent | Warriors of Chaos | 1 | 0 | 949 | 2.0 | 1.0 | 474 | 0 | +474 | 2 of 2 | 1 of 2 | - | +474 |
| **Opponent** | all armies | 3 | 125 | 509 | 1.7 | 1.0 | 306 | 0 | +306 | 3 of 5 | 3 of 5 | - | +306 |

### Effective charges: cora-bb45c30-p30

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 0 | 0 | 1 (net -104) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +48) | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +227) | 1 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +135) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 1 (net +559) | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p30

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 104 | 70 | -104 | 0 | 104 | -104 | -100.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 279 | 116 | +48 | 50 | 0 | +50 | +18.0 |
| Mine | All fights | 4 | 236 | 105 | +10 | 38 | 26 | +12 | +4.9 |
| Opponent | 76-89% | 2 | 296 | 172 | +347 | 347 | 133 | +214 | +72.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 227 | +227 | 360 | 82 | +278 | +112.4 |
| Opponent | No odds | 2 | 410 | 227 | +304 | 336 | 96 | +240 | +58.6 |
| Opponent | All fights | 5 | 332 | 205 | +306 | 345 | 108 | +237 | +71.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p30 | move | 16 | 4 (25%) | 3 (19%) | 1 (6%) | 11 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

# Doctrine scorecard: cora-bb45c30-p27

### Scorecard: cora-bb45c30-p27

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 2 | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1148 |
| L0421 | 1 | 1 | Mine | no | 5 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 4.7 | 2.5 | 1.0 | 1.7 | 0.0 | 0.0 | 0.0 | 126.7 |
| **Average** | | | Opponent | 0% | 0.0 | - | 0.0 | 3.0 | 0.0 | 0.0 | 0.0 | 639.3 |

### KPIs: cora-bb45c30-p27

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 8) | 38% (3 of 8) | 19% (3 of 16) |
| Winner chose to follow up after the loser gave ground |  | 44% (4 of 9); on the table 100% | - | 44% (4 of 9); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 4); on the table 50% | 0% (0 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 44% (4 of 9); on the table 100% | 0% (0 of 5); on the table 60% | 29% (4 of 14); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | 50% (3 of 6) | 44% (8 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (5 of 12) | 50% (3 of 6) | 44% (8 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 44% (4 of 9) | 44% (4 of 9) |
| Points that never fought | lower | 82% (4899 of 5998) | 84% (5040 of 5999) | 83% (9939 of 11997) |
|   infantry points that never fought | lower | 78% (1115 of 1424) | 78% (1322 of 1703) | 78% (2437 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (13 of 23) | 69% (18 of 26) | 63% (31 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2671 of 5120) | 62% (2908 of 4677) | 57% (5579 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (29%) | 0.3 (33%) | 1.0 (30%) |
| MARCHED: its unit marched | 1.3 (57%) | 0.7 (67%) | 2.0 (60%) |
| CHARGED: its unit charged | 0.3 (14%) | 0.0 (0%) | 0.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.0 | 2.7 | 2.0 | 0.0 |
| not cast | 2.3 | 3.0 | 3.3 | 2.0 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (89%) | 1.0 (30%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (60%) | 0.7 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.3 (17%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (100%) | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 33% (1 of 3) | - | 33% (1 of 3) |
| the unit moved after it | 0% (0 of 1) | - | 0% (0 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (49 of 78) | 73% (75 of 103) | 69% (124 of 181) |
|   cavalry | 50% (4 of 8) | 0% (0 of 7) | 27% (4 of 15) |
|   character | 50% (5 of 10) | 75% (18 of 24) | 68% (23 of 34) |
|   chariot | 73% (16 of 22) | 46% (6 of 13) | 63% (22 of 35) |
|   infantry | 17% (2 of 12) | 75% (15 of 20) | 53% (17 of 32) |
|   war machine | 85% (22 of 26) | 92% (36 of 39) | 89% (58 of 65) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (28%) | 1.3 (14%) | 4.0 (21%) |
| CHARGED: it charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.7 (38%) | 4.0 (43%) | 7.7 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (28%) | 2.7 (29%) | 5.3 (28%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 8.0 | 6.0 | 58% | 21.7 pts | 174 pts |
| chariot | 7.3 | 13.0 | 32% | 23.1 pts | 169 pts |
| infantry | 9.0 | 3.7 | 70% | 14.5 pts | 130 pts |
| war machine | 19.3 | 12.7 | 72% | 15.5 pts | 300 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 0.0 | 1.2 |
| Charges that made contact a game | 1.7 | 0.0 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.23 contact (22 units) | 0.00 declared, 0.00 contact (22 units) | 0.14 declared, 0.11 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (1 of 1) | - | 25% (1 of 4) |
| Character in a unit | 100% (10 of 10) | 0% (0 of 2) | - | 83% (10 of 12) |
| Character on its own | 100% (2 of 2) | 50% (1 of 2) | 67% (2 of 3) | 71% (5 of 7) |
| Chariot | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| Infantry | 75% (6 of 8) | 40% (2 of 5) | 0% (0 of 1) | 57% (8 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 44% (4 of 9); on the table 100% | 42% (5 of 12) | 73% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 87% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 5); on the table 60% | 50% (3 of 6) | 78% | 67% (6 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p27, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cora-bb45c30-p27

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | - |
| Strategy | Shoot objectives carried out (shot that target) | 62% (20 of 32) | 83% (35 of 42) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 20% (2 of 10) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 0% (0 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 3.0 |
| Movement | Points that never moved of their own | 126.7 | 639.3 |
| Movement | Fights charged into per game | 1.3 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net -124 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 13.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (13 of 27) | 90% (36 of 40) |
| Shooting | Points destroyed by shooting units | 125.7 | 149.7 |
| Shooting | War machine shots | 7.3 | 12.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 50% (18 of 36) |
| Shooting | Points destroyed by war machines | 176.0 | 21.7 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 1.7 | 2.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 59.0 |
| Combat | Points run down | 18.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | -58 | - |
| Combat | Net per 100 charger points, damage counted | -18.5 | - |
| Combat | First round won (charged fights) | 75% | - |
| Combat | Net points per charged fight | +4 | - |
| Combat | Net points per supported fight / lone fight | -112 / +43 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 2 of 4 | - |
| Game | Points lost | 335.0 | 542.3 |
| Game | VP from objectives | 1000.0 | 700.0 |
| Game | Lone holders (player turns) | 4.7 | 0.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +454 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 877
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p27

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.0 | +36.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.7 | +61.2 | 0.0 | 41.3 | - | - | - | - |
| ARMY TABLE | 19.7 | +506.1 | 0.0 | 327.7 | 12.3 | +184.8 | 0.0 | 258.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 43.3 |
| BEST PRIZE | 0.7 | -38.1 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 1.0 | +0.0 | 228.3 | 31.7 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 12.0 | +227.5 | 685.3 | 221.7 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +25.3 | 36.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +10.2 | 0.0 | 12.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +8.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 25.0 | -857.6 | 0.0 | 327.7 | 7.3 | -250.8 | 0.0 | 156.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 43.3 | 6.7 | +0.0 | 0.0 | 43.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 41.3 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +25.3 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 3.3 | -74.1 | 0.0 | 31.7 | 1.3 | -119.5 | 0.0 | 21.7 |
| DEFENSIVE FLOOR | 0.3 | -5.3 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -19.8 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| DUEL STOPS AT THE KILL | 0.3 | -23.9 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.3 | +9.3 | 71.7 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +3.3 | 53.3 | 37.3 | - | - | - | - |
| FALLS SHORT | 7.0 | +102.8 | 0.0 | 140.7 | 10.7 | +127.2 | 0.0 | 65.0 |
| FEATURE BUFFS | 0.3 | +2.8 | 0.0 | 0.0 | 2.0 | +13.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.3 | +0.0 | 41.7 | 31.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 90.3 | +6406.4 | 1638.3 | 794.7 | 88.0 | +3910.1 | 1830.3 | 1063.7 |
| FLANK NOT WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 18.3 |
| FOUR ROUNDS | 2.3 | +190.8 | 71.7 | 37.3 | - | - | - | - |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.7 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -13.3 | 21.7 | 0.0 | - | - | - | - |
| GOAL WALK | 13.0 | +1879.9 | 0.0 | 43.3 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 4.0 | +35.2 | 43.3 | 103.3 | 3.0 | +0.9 | 0.0 | 65.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 21.7 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS MOVE AND SHOT | 4.3 | -33.1 | 0.0 | 0.0 | 3.0 | -51.2 | 0.0 | 40.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVE | 5.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 46.0 | +2202.2 | 0.0 | 480.7 | 37.7 | +1509.1 | 0.0 | 370.3 |
| HIS SHOTS BY HIS RUN | 34.3 | +650.2 | 0.0 | 414.3 | 26.3 | +705.4 | 0.0 | 318.7 |
| HIS TURN DENIED | 0.7 | +32.8 | 0.0 | 37.3 | - | - | - | - |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 74.7 | 18.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.7 | +941.6 | 0.0 | 74.7 | 10.0 | +890.9 | 0.0 | 67.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -81.0 | 71.7 | 0.0 | - | - | - | - |
| IDLE COST | 7.7 | -127.3 | 0.0 | 68.0 | 8.7 | -114.9 | 0.0 | 60.3 |
| JOINT CHARGE NOW | 0.7 | +25.1 | 0.0 | 37.3 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 74.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 0.0 | 63.0 | - | - | - | - |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -0.5 | 0.0 | 37.3 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -22.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -0.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +94.1 | 0.0 | 0.0 | 0.3 | +24.2 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +44.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | -6.7 | 0.0 | 0.0 | 0.7 | +106.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +8.1 | 0.0 | 0.0 | 0.7 | +22.5 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 2.0 | +31.6 | 0.0 | 0.0 | 1.7 | +9.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +30.6 | 0.0 | 0.0 | 3.0 | +10.2 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.7 | +126.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.3 | -157.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.0 | +156.3 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.7 | +199.1 | 0.0 | 0.0 | 6.3 | +282.8 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +96.9 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.7 | -34.4 | 71.7 | 37.3 | - | - | - | - |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -235.8 | 18.3 | 152.7 | 4.3 | -65.0 | 0.0 | 73.3 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -132.7 | 0.0 | 0.0 | - | - | - | - |
| ONE JOINT FIGURE | 0.7 | +339.6 | 0.0 | 37.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.0 | +43.3 | 0.0 | 0.0 | 4.3 | +17.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 1.0 | +39.3 | 40.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.3 | +12.1 | 40.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -62.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.3 | +585.6 | 389.0 | 506.7 | 41.0 | +854.7 | 585.0 | 600.3 |
| PROMISE BY ITS OWN SUM | 6.3 | -277.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 25.0 | +2735.8 | 264.7 | 63.3 | 24.7 | +1939.9 | 826.7 | 373.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +4.8 | 0.0 | 48.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 1.0 | +33.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 58.3 |
| REDIRECT WEIGHED | 0.3 | -7.8 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +9.5 | 0.0 | 37.3 | - | - | - | - |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +15.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | -39.3 | 40.0 | 37.3 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.0 | -35.3 | 18.3 | 0.0 | - | - | - | - |
| RUN DOWN | 0.7 | -3.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +43.9 | 18.3 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.7 | -105.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.3 | +140.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.0 | +0.0 | 0.0 | 95.0 | 14.0 | +0.0 | 0.0 | 221.7 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +89.9 | 65.0 | 0.0 | - | - | - | - |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT RISK POINTS | 34.3 | +296.5 | 0.0 | 524.0 | 16.7 | +21.7 | 0.0 | 428.7 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +372.8 | 0.0 | 230.0 | 21.3 | +523.0 | 0.0 | 318.3 |
| SPELL WORTH | - | - | - | - | 3.7 | +58.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 18.3 |
| STAND AND SHOOT | 0.7 | -7.3 | 21.7 | 37.3 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 43.7 | +0.0 | 1566.7 | 296.7 | 54.0 | +0.0 | 1830.3 | 834.7 |
| STAY WORTH | 28.3 | +295.3 | 1065.7 | 325.0 | 40.3 | +41.0 | 1784.0 | 617.3 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | - | - | - | - | 1.3 | +85.1 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | - | - | - | - | 1.3 | +85.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +25.1 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 18.3 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 21.7 | 4.0 | +0.0 | 0.0 | 36.7 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 21.7 | 3.3 | +0.0 | 0.0 | 36.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.3 | +0.0 | 0.0 | 347.0 | 42.0 | +0.0 | 0.0 | 408.7 |
| TIED UP BY THE SUM | 1.0 | +108.3 | 40.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 21.7 | +311.1 | 269.3 | 86.7 | 16.7 | +209.0 | 0.0 | 175.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 43.3 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | +43.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -105.0 | 0.0 | 0.0 | 1.3 | -94.1 | 0.0 | 21.7 |
| WHOLE FIGHT GAIN | 0.7 | +110.2 | 0.0 | 37.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +185.7 | 0.0 | 0.0 | 3.0 | +62.2 | 0.0 | 134.7 |

### Rule changes: cora-bb45c30-p27

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 96 | 96 | 63 | 21.00 | +1784 | +28.3 |
| HIS SHOT LIST | 251 | 241 | 56 | 18.67 | +690 | +12.3 |
| HOLDER ASSIGNMENT | 59 | 59 | 55 | 18.33 | +2942 | +53.5 |
| HIS SHOTS BY HIS RUN | 182 | 173 | 47 | 15.67 | +437 | +9.3 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -902 | -31.1 |
| SHOT RISK POINTS | 153 | 144 | 25 | 8.33 | +825 | +33.0 |
| GOAL WALK | 48 | 39 | 22 | 7.33 | +2420 | +110.0 |
| TIME ON OUR SIDE | 115 | 98 | 16 | 5.33 | +8 | +0.5 |
| THE TABLE AGAIN | 36 | 36 | 14 | 4.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| IDLE COST | 49 | 38 | 9 | 3.00 | +58 | +6.5 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| STAY WORTH | 206 | 178 | 9 | 3.00 | +169 | +18.7 |
| CANNON PLANNED TARGET | 56 | 56 | 7 | 2.33 | +0 | +0.0 |
| CHARGE LOSSES | 97 | 87 | 7 | 2.33 | +601 | +85.9 |
| QUARTER ODDS | 149 | 148 | 7 | 2.33 | +1115 | +159.3 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 7 | 2.33 | +83 | +11.8 |
| PROMISE BY ITS OWN SUM | 19 | 19 | 6 | 2.00 | -833 | -138.8 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FIRE IN ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| FALLS SHORT | 53 | 43 | 4 | 1.33 | +44 | +11.1 |
| FIVE ACTION | 535 | 521 | 4 | 1.33 | +408 | +101.9 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| MOVE TO CHARGE COMPUTED | 9 | 8 | 4 | 1.33 | +216 | +54.1 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 4 | 1.33 | +14 | +3.6 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| SHOTS IN THE MOVE | 114 | 78 | 4 | 1.33 | +87 | +21.7 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +108 | +36.1 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +355 | +118.3 |
| MAX FOR POSITIONING | 5 | 4 | 3 | 1.00 | +2 | +0.5 |
| SET UP BY THE SET | 7 | 7 | 3 | 1.00 | +354 | +118.1 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +184 | +91.8 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -114 | -57.1 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +27 | +13.4 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOUR ROUNDS | 7 | 5 | 2 | 0.67 | +101 | +50.4 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +75 | +37.7 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| NEXT CHARGE BY LIST | 6 | 6 | 2 | 0.67 | +74 | +36.8 |
| ONE JOINT FIGURE | 2 | 2 | 2 | 0.67 | +382 | +191.2 |
| REDIRECT COUNTER | 4 | 2 | 2 | 0.67 | +103 | +51.7 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +28 | +14.2 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +132 | +65.8 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +174 | +87.2 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +24 | +24.5 |
| CHARGE NOW FIRST | 2 | 2 | 1 | 0.33 | -49 | -49.1 |
| EXACT ROUND | 4 | 3 | 1 | 0.33 | +14 | +13.6 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +4 | +3.7 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +4 | +4.5 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +5 | +4.9 |
| MISSILES IN THE MOVE | 11 | 3 | 1 | 0.33 | +0 | +0.3 |
| NEARER NOT NEEDED | 33 | 31 | 1 | 0.33 | +47 | +47.1 |
| ONE OBJECTIVE FORMULA | 19 | 9 | 1 | 0.33 | +28 | +28.1 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +19 | +19.4 |
| OPENS UP | 3 | 1 | 1 | 0.33 | +14 | +13.6 |
| OVERRUNS AWAY | 4 | 2 | 1 | 0.33 | +14 | +13.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -187 | -186.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +78 | +78.5 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +46 | +45.7 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +14 | +13.7 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT ADDS | 4 | 4 | 1 | 0.33 | +17 | +16.9 |
| SUPPORT WORKED OUT | 4 | 4 | 1 | 0.33 | +17 | +16.9 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +38 | +38.2 |
| THE ROW IN ITS ORDER | 18 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 3 | 1 | 1 | 0.33 | +14 | +13.6 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| WAR ENGINE JOBS | 2 | 2 | 1 | 0.33 | -150 | -150.1 |
| WHOLE FIGHT DANGER | 11 | 10 | 1 | 0.33 | +9 | +8.7 |
| WOUNDS ON THE RANKS | 17 | 17 | 1 | 0.33 | +14 | +13.6 |
| CANNON PLAN MISSED | 8 | 8 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 31 | 31 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 49 | 48 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| COVER ONCE | 14 | 9 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 7 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 21 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 22 | 21 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 15 | 15 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 14 | 14 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 19 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 15 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 16 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 101 | 100 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| NO DOUBLE ROUNDS | 5 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 11 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 244 | trace | - | - | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 5 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 72 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 23 | 23 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 31 | 23 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 293 | 293 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 250 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p27

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 4.33 | 30.1 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | - | 138.8 |
| ARMY TABLE | rule | 1.33 | 0.33 | 88.3 |
| NO REASON | gate | 1.33 | - | 37.3 |
| BEST PRIZE | rule | 0.67 | - | 57.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 13.4 |
| CHARGE NOW FIRST | rule | 0.33 | - | 49.1 |
| JOINT CHARGE NOW | rule | 0.33 | - | 58.2 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 186.9 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |
| WAR ENGINE JOBS | rule | 0.33 | - | 150.1 |

### Plans: cora-bb45c30-p27

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 67% | 290 | 55 | 19% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 28.7 | 95% | 2249 | 0 | 0% |
| Mine | shoot | 9.3 | 64% | 205 | 530 | 258% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 27.3 | 90% | 1117 | 0 | 0% |
| Opponent | shoot | 12.0 | 61% | 435 | 855 | 196% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p27

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p27

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 14 (11) | 14 | 0 | 0 | 18% | 1.9 | 24 (5) | 11 (4) | 0 (2) | 19 (7) | 8 (4) |
| Mine | Clean-up | 3 | 99 (3) | 0 | 99 | 34 | 33% | 3.5 | 99 (3) | - | - | 150 (2) | 0 (1) |
| Mine | Hammer | 8 | 22 (8) | 7 | 15 | 20 | 12% | 1.9 | 0 (2) | 26 (6) | - | 37 (5) | 7 (3) |
| Mine | Holder | 4 | 70 (4) | 0 | 70 | 49 | 75% | 1.0 | 0 (1) | 92 (3) | - | 216 (1) | 16 (3) |
| Mine | Shooter | 1 | 54 (1) | 0 | 54 | 0 | 0% | 1.0 | 54 (1) | - | - | - | 54 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 17 (14) | 17 | 0 | 5 | 50% | 2.3 | 23 (10) | 0 (3) | - | 23 (9) | 0 (4) |
| Opponent | Clean-up | 4 | 96 (4) | 0 | 96 | 0 | 75% | 6.0 | - | 96 (4) | - | 96 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 6 | 75 (6) | 48 | 27 | 12 | 17% | 2.6 | 115 (2) | 0 (1) | 76 (3) | 75 (6) | - |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 67% | 3.0 | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 67 | 50% | 2.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 7 (9) | 7 | 0 | 71 | 11% | 1.0 | 7 (9) | - | - | 0 (1) | 8 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: cora-bb45c30-p27

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 88 | 126 | 2.0 | 1.2 | 63 | 59 | +4 | 2 of 4 | 3 of 4 | -112 | +43 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 302 | 84 | 1.3 | 1.2 | 63 | 59 | +4 | 2 of 4 | 3 of 4 | -112 | +43 |
| Opponent | Dwarfen Mountain Holds | 1 | 449 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 171 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: cora-bb45c30-p27

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 0 | 0 | 1 (net -124) | 1 (net -112) | 0 | 0 | 2 | 50% (1 of 2) |

### Charged fights, damage counted: cora-bb45c30-p27

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 120 | 210 | -124 | 35 | 217 | -182 | -151.9 |
| Mine | 76-89% | 1 | 451 | 239 | -112 | 105 | 378 | -273 | -60.6 |
| Mine | No odds | 2 | 339 | 71 | +126 | 181 | 68 | +112 | +33.2 |
| Mine | All fights | 4 | 312 | 148 | +4 | 125 | 183 | -58 | -18.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p27 | move | 7 | 3 (43%) | 2 (29%) | 0 (0%) | 4 (57%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: cora-bb45c30-p13

### Scorecard: cora-bb45c30-p13

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 448 |
| L0122 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 72 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 6 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 2 | 0 | 0 | 0 | 853 |
| **Average** | | | Mine | 0% | 0.0 | 6.0 | 0.7 | 2.7 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 0.0 | 2.5 | 1.3 | 2.0 | 0.0 | 0.0 | 0.0 | 457.7 |

### KPIs: cora-bb45c30-p13

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 9) | 65% (11 of 17) | 42% (11 of 26) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | - | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 100% (4 of 4); on the table 100% | 88% (7 of 8); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 46% (41 of 90) | - | 46% (41 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (41 of 87) | - | 47% (41 of 87) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (6 of 6) | - | 100% (6 of 6) |
| Points that never fought | lower | 52% (2959 of 5699) | 76% (4553 of 6000) | 64% (7512 of 11699) |
|   infantry points that never fought | lower | 51% (1151 of 2239) | 98% (2061 of 2111) | 74% (3212 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 44% (7 of 16) | 64% (16 of 25) | 56% (23 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 3.7 uses a game | 0.0 uses a game | 100% (4 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 38% (1496 of 3916) | 68% (2987 of 4382) | 54% (4483 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 7.0 (43%) | - | 7.0 (43%) |
| MARCHED: its unit marched | 6.0 (37%) | - | 6.0 (37%) |
| IN COMBAT: engaged in combat | 0.7 (4%) | - | 0.7 (4%) |
| GONE: slain | 0.3 (2%) | - | 0.3 (2%) |
| STUPIDITY: Stupidity | 1.0 (6%) | - | 1.0 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.3 (8%) | - | 1.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 8.0 | 13.7 | 0.0 | 1.0 |
| not cast | 2.0 | 3.0 | 2.0 | 16.3 | 2.0 | 27.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (78%) | 0.0 (0%) | 7.0 (43%) | 1.3 (67%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.0 (37%) | 0.3 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.3 (17%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.3 (17%) | 1.0 (6%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.7 (22%) | 1.7 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.3 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 9.3 a game | 0.0 a game | 4.7 a game |
| stood (cast and not dispelled) | 61% (17 of 28) | - | 61% (17 of 28) |
| the unit moved after it | 59% (10 of 17) | - | 59% (10 of 17) |
| it charged on its next turn | 0% (0 of 17) | - | 0% (0 of 17) |
| the enemy charged it first | 12% (2 of 17) | - | 12% (2 of 17) |
| it fought by the end of its next turn | 12% (2 of 17) | - | 12% (2 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (2 of 17) | - | 12% (2 of 17) |
| none of these (no charge, no fight, no charge escaped) | 76% (13 of 17) | - | 76% (13 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (14 of 21) | 62% (118 of 190) | 63% (132 of 211) |
|   cavalry | - | 50% (12 of 24) | 50% (12 of 24) |
|   character | - | 50% (10 of 20) | 50% (10 of 20) |
|   chariot | - | 0% (0 of 1) | 0% (0 of 1) |
|   infantry | 67% (14 of 21) | 62% (40 of 64) | 64% (54 of 85) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | - | 67% (46 of 69) | 67% (46 of 69) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (71%) | 1.3 (6%) | 3.0 (11%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (7%) | 1.7 (6%) |
| NO TARGET IN RANGE | 0.7 (29%) | 10.7 (44%) | 11.3 (43%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (3%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 4.7 (19%) | 4.7 (18%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (3%) | 0.7 (3%) |
| OTHER BAR | 0.0 (0%) | 4.3 (18%) | 4.3 (16%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.0 | 81% | 2.7 pts | 15 pts |
| character | 3.3 | 3.7 | 30% | 10.0 pts | 33 pts |
| infantry | 26.7 | 12.0 | 74% | 4.3 pts | 115 pts |
| monster | 3.3 | 0.3 | 90% | 0.8 pts | 3 pts |
| war machine | 15.3 | 12.3 | 65% | 8.0 pts | 123 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 3.3 | 2.0 |
| Charges that made contact a game | 0.7 | 2.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (20 units) | 0.37 declared, 0.26 contact (27 units) | 0.26 declared, 0.19 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 50% (2 of 4) | 50% (2 of 4) | - | 50% (4 of 8) |
| Character on its own | 50% (1 of 2) | 100% (2 of 2) | 100% (2 of 2) | 83% (5 of 6) |
| Infantry | 57% (4 of 7) | 29% (2 of 7) | - | 43% (6 of 14) |
| Monster | 40% (2 of 5) | - | - | 40% (2 of 5) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 75% (3 of 4); on the table 75% | 46% (41 of 90) | 52% | 44% (7 of 16) | 100% (4 of 4); 3.7 uses a game | 50% (1 of 2); 1.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | 100% (2 of 2); on the table 100% | - | 95% | 65% (13 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 38% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p13, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 100% (2) | 40% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p13

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 60% (6 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 8% (1 of 13) | 44% (33 of 75) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | - |
| Strategy | Joined characters whose unit fought | 73% (8 of 11) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 14% (1 of 7) | 100% (2 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.7 | 2.0 |
| Movement | Points that never moved of their own | 56.7 | 457.7 |
| Movement | Fights charged into per game | 0.7 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 2 of 5, net +2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 5, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 1 of 5, net +77 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 5, net +52 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.7 | 25.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (5 of 14) | 60% (45 of 75) |
| Shooting | Points destroyed by shooting units | 24.0 | 146.0 |
| Shooting | War machine shots | - | 15.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 70% (32 of 46) |
| Shooting | Points destroyed by war machines | 20.0 | 0.0 |
| Magic | Magic missiles cast | 6.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (7 of 20) | - |
| Magic | Wounds caused by magic missiles | 22.7 | - |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 210.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 1.0 / 0.0 | 4.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 85.0 | 49.0 |
| Combat | Points run down | 0.0 | 64.7 |
| Combat | Net points per charged fight, damage counted | +57 | +44 |
| Combat | Net per 100 charger points, damage counted | +12.9 | +16.8 |
| Combat | First round won (charged fights) | 100% | 40% |
| Combat | Net points per charged fight | +72 | +27 |
| Combat | Net points per supported fight / lone fight | - / +72 | +64 / +2 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 2 of 5 |
| Game | Points lost | 259.7 | 356.3 |
| Game | VP from objectives | 713.3 | 686.7 |
| Game | Lone holders (player turns) | 0.0 | 0.0 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +84 VP
- Points traded per game (both sides' losses): 616
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p13

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +239.8 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 20.0 | +86.2 | 0.0 | 241.7 | 14.7 | +414.0 | 0.0 | 212.0 |
| BACKUP TARGETS | 0.7 | +1.6 | 0.0 | 17.3 | - | - | - | - |
| BOMBING RUN | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.3 | +0.0 | 27.0 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 14.3 | +137.3 | 462.3 | 38.3 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 6.0 | +437.7 | 321.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.7 | +0.0 | 0.0 | 63.3 | - | - | - | - |
| CATCH FLIERS | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.3 | +112.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 1.3 | +0.0 | 0.0 | 48.0 |
| CHARACTER GUNS | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 20.0 | -1471.2 | 0.0 | 367.3 | 18.0 | -781.7 | 0.0 | 334.0 |
| CHARGE NOW FIRST | - | - | - | - | 2.0 | +0.0 | 78.0 | 0.0 |
| CHARIOT NO STATIC JOB | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 125.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 6.3 | +1359.1 | 0.0 | 31.7 | - | - | - | - |
| COVER ONCE | 6.3 | -315.7 | 0.0 | 95.3 | 11.7 | -362.1 | 0.0 | 123.3 |
| DEFENSIVE ARMY | - | - | - | - | 0.7 | +0.0 | 181.3 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -8.7 | 43.3 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -255.5 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | +1.5 | 0.0 | 17.3 | 1.7 | -1.8 | 56.3 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +3.3 | 0.0 | 17.3 | 2.7 | +0.0 | 78.0 | 20.0 |
| FALLS SHORT | 15.7 | +351.1 | 0.0 | 225.0 | 13.7 | +117.4 | 0.0 | 244.3 |
| FEATURE BUFFS | 15.3 | +467.1 | 0.0 | 175.7 | 1.7 | +36.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +1.2 | 0.0 | 17.3 | 1.0 | +5.6 | 17.3 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 71.3 | +7078.1 | 321.0 | 804.0 | 136.7 | +5591.3 | 1473.3 | 779.3 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 97.0 | 5.3 | +0.0 | 0.0 | 89.0 |
| FOLLOW UP WEIGHED | 0.3 | +33.9 | 0.0 | 17.3 | - | - | - | - |
| FOUR ROUNDS | 0.3 | +10.5 | 0.0 | 17.3 | 3.3 | +137.3 | 129.3 | 20.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 20.0 |
| FRIEND SHOOTS FIRST | 0.7 | -40.6 | 0.0 | 0.0 | 2.0 | -157.6 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| GOAL WALK | 13.7 | +2350.2 | 0.0 | 182.7 | 0.7 | +10.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +4.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 20.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.0 | +0.0 | 0.0 | 276.7 | 12.0 | +0.0 | 0.0 | 210.0 |
| HIS CHARGE LIST | 15.3 | +0.0 | 0.0 | 227.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 64.0 |
| HIS MOVE AND SHOT | 5.0 | -34.7 | 0.0 | 201.3 | 4.7 | -144.3 | 0.0 | 40.0 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 40.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 64.0 |
| HIS RANDOM MOVE | - | - | - | - | 10.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 52.0 | +1580.9 | 0.0 | 739.3 | 53.0 | +1901.0 | 0.0 | 324.0 |
| HIS SHOTS BY HIS RUN | 47.3 | +783.1 | 0.0 | 682.7 | 43.7 | +1041.3 | 0.0 | 558.0 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +31.0 | 43.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 39.3 | +0.0 | 0.0 | 635.3 | 14.7 | +0.0 | 0.0 | 48.0 |
| HOLDER ASSIGNMENT | 14.3 | +1587.8 | 0.0 | 185.3 | 9.7 | +1329.0 | 0.0 | 48.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -0.9 | 0.0 | 17.3 | 2.3 | -111.1 | 112.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +137.5 | 0.0 | 0.0 |
| IDLE COST | 10.3 | -64.9 | 0.0 | 82.3 | 5.0 | -105.7 | 0.0 | 107.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | +34.3 | 86.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 8.7 | +0.0 | 294.0 | 185.3 | 3.3 | +0.0 | 21.7 | 158.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +0.3 | 0.0 | 17.3 | 2.3 | +2.6 | 90.3 | 20.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +3.4 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +13.5 | 0.0 | 0.0 | 2.0 | -12.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +171.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +1.6 | 0.0 | 27.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -138.7 | 0.0 | 27.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +72.0 | 0.0 | 0.0 | 2.0 | +35.8 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.3 | +392.4 | 0.0 | 117.7 | - | - | - | - |
| MISSILES NEXT TURN | 9.7 | +314.3 | 0.0 | 144.7 | - | - | - | - |
| MISSILES ON ONE TARGET | 3.0 | -89.9 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | - | - | - | - | 4.3 | +775.0 | 0.0 | 40.0 |
| MOVE ORDER | 1.3 | +0.0 | 21.7 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.0 | -55.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.7 | +129.1 | 0.0 | 0.0 | 9.7 | +1004.4 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.7 | +213.9 | 0.0 | 43.3 | 8.7 | +376.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +169.7 | 0.0 | 0.0 | 6.0 | +870.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -6.4 | 0.0 | 17.3 | 3.0 | -33.5 | 103.7 | 20.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.0 | -44.3 | 0.0 | 44.3 | 7.0 | -195.6 | 0.0 | 85.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -134.4 | 0.0 | 199.3 | 5.7 | -70.9 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +1.1 | 17.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.7 | -6.7 | 0.0 | 163.7 | 3.3 | -87.3 | 0.0 | 24.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -23.1 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.7 | +32.2 | 78.0 | 0.0 |
| PATHS CROSS | 0.3 | +0.5 | 0.0 | 0.0 | 0.3 | +2.3 | 0.0 | 0.0 |
| PLAN RESULT | 31.7 | +128.0 | 82.3 | 427.7 | 60.3 | +792.8 | 611.3 | 655.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 27.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 3.7 | -26.9 | 0.0 | 0.0 | 8.7 | -47.6 | 0.0 | 40.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -40.6 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 7.3 | +1265.2 | 0.0 | 0.0 | 17.0 | +810.7 | 0.0 | 100.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +22.9 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.0 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.3 | +92.4 | 0.0 | 0.0 | 1.7 | +55.2 | 0.0 | 72.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.0 | +9.4 | 0.0 | 79.7 | 1.0 | +0.0 | 0.0 | 48.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +106.9 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 3.0 | -9.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +15.9 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.7 | +70.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | -7.0 | 0.0 | 17.3 | 2.3 | +22.1 | 78.0 | 20.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | +68.5 | 94.7 | 0.0 |
| RUN DOWN | 0.3 | -2.3 | 0.0 | 17.3 | 3.0 | -17.6 | 129.3 | 0.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 1.0 | -1.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.3 | -78.1 | 0.0 | 108.0 | 2.3 | -191.1 | 0.0 | 24.0 |
| SET UP BY THE SET | 3.0 | +8.2 | 0.0 | 108.0 | 6.0 | +327.3 | 0.0 | 48.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +3.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 21.7 | 25.0 | +0.0 | 0.0 | 80.7 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +108.7 | 0.0 | 0.0 | 0.7 | +81.2 | 181.3 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.1 | 0.0 | 0.0 |
| SHOT RISK POINTS | 33.7 | -88.6 | 0.0 | 377.3 | 47.0 | +234.1 | 0.0 | 558.0 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 4.0 | +76.8 | 0.0 | 21.7 | 45.7 | +951.2 | 0.0 | 254.7 |
| SPELL OFF EDGE | 0.3 | +16.9 | 24.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.7 | +314.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.0 | +4.4 | 20.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 156.7 | 6.0 | +0.0 | 0.0 | 44.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -4.8 | 43.3 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 117.7 | 7.0 | +0.0 | 0.0 | 156.7 |
| STANDS STILL | 19.7 | +0.0 | 321.0 | 125.7 | 90.0 | +0.0 | 1344.0 | 567.3 |
| STAY WORTH | 6.0 | +68.1 | 144.0 | 0.0 | 69.0 | +113.1 | 746.0 | 297.7 |
| SUPPORT ADDS | 7.7 | +397.2 | 0.0 | 73.7 | 0.7 | +3.5 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 7.7 | +397.2 | 0.0 | 73.7 | 0.7 | +3.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -19.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 20.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 17.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 17.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 34.3 | +0.0 | 0.0 | 348.0 | 59.7 | +0.0 | 0.0 | 379.7 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +42.5 | 43.3 | 0.0 |
| TIME ON OUR SIDE | 13.0 | +285.8 | 48.0 | 94.7 | 43.0 | +355.8 | 0.0 | 122.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 21.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | +7.4 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -4.8 | 0.0 | 34.7 | - | - | - | - |
| WHO GETS IN | - | - | - | - | 0.7 | +40.1 | 51.3 | 0.0 |
| WHO HITS BACK | 0.7 | +26.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +4.7 | 0.0 | 17.3 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.7 | -937.6 | 0.0 | 151.3 | 1.0 | -310.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +11.1 | 17.3 | 0.0 |
| WOUNDS ON THE RANKS | 7.7 | +1104.1 | 0.0 | 272.0 | 1.3 | +18.5 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p13

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 315 | 304 | 83 | 27.67 | +1143 | +13.8 |
| HOLDER ASSIGNMENT | 72 | 72 | 70 | 23.33 | +3874 | +55.3 |
| ARMY TABLE | 104 | 104 | 63 | 21.00 | +1617 | +25.7 |
| HIS SHOTS BY HIS RUN | 273 | 259 | 57 | 19.00 | +472 | +8.3 |
| SHOT RISK POINTS | 242 | 230 | 46 | 15.33 | +721 | +15.7 |
| LEGAL CHARGES ONLY | 36 | 36 | 36 | 12.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| FIVE ACTION | 624 | 609 | 34 | 11.33 | +1834 | +53.9 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -720 | -24.0 |
| GOAL WALK | 43 | 42 | 24 | 8.00 | +4263 | +177.6 |
| MOVE TO CHARGE COMPUTED | 34 | 28 | 24 | 8.00 | +2018 | +84.1 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| CASTING BLOCK | 18 | 18 | 18 | 6.00 | +413 | +23.0 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +15 | +0.8 |
| NEXT CHARGE BY LIST | 24 | 22 | 17 | 5.67 | +2005 | +117.9 |
| TIME ON OUR SIDE | 168 | 154 | 15 | 5.00 | +121 | +8.0 |
| MODEL FACING | 13 | 13 | 13 | 4.33 | +2325 | +178.9 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| CANNON PLANNED TARGET | 43 | 43 | 11 | 3.67 | -31 | -2.8 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 11 | 3.67 | -224 | -20.3 |
| QUARTER ODDS | 73 | 71 | 11 | 3.67 | +828 | +75.3 |
| SET UP BY THE SET | 27 | 27 | 11 | 3.67 | +464 | +42.2 |
| WOUNDS ON THE RANKS | 27 | 27 | 11 | 3.67 | +934 | +85.0 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| SUPPORT ADDS | 25 | 23 | 9 | 3.00 | +495 | +55.0 |
| SUPPORT WORKED OUT | 25 | 23 | 9 | 3.00 | +495 | +55.0 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 8 | 2.67 | +155 | +19.4 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOUR ROUNDS | 11 | 11 | 6 | 2.00 | +117 | +19.5 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 6 | 2.00 | +69 | +11.4 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 114 | 108 | 5 | 1.67 | +334 | +66.7 |
| RESERVE MOVE SPELL | 5 | 5 | 5 | 1.67 | +212 | +42.3 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 88 | 60 | 4 | 1.33 | +83 | +20.8 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +103 | +25.8 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +514 | +128.5 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +48 | +11.9 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 3 | 1.00 | +44 | +14.7 |
| COVER ONCE | 54 | 30 | 3 | 1.00 | +70 | +23.2 |
| FEATURE BUFFS | 51 | 49 | 3 | 1.00 | +40 | +13.3 |
| IDLE COST | 46 | 30 | 3 | 1.00 | +38 | +12.7 |
| MANOEUVRE | 10 | 10 | 3 | 1.00 | +46 | +15.5 |
| RISK BY ARC | 8 | 8 | 3 | 1.00 | +41 | +13.7 |
| SHOTS IN THE MOVE | 149 | 120 | 3 | 1.00 | +45 | +14.8 |
| STAY WORTH | 225 | 208 | 3 | 1.00 | +67 | +22.5 |
| CHARIOT NO STATIC JOB | 3 | 3 | 2 | 0.67 | -136 | -67.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -5 | -2.4 |
| MAX FOR POSITIONING | 15 | 14 | 2 | 0.67 | +7 | +3.6 |
| ONE OBJECTIVE FORMULA | 36 | 25 | 2 | 0.67 | +84 | +42.2 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -69 | -34.7 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +8 | +4.2 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +14 | +7.2 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +56 | +27.9 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +120 | +60.1 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +58 | +29.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +719 | +719.4 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +6 | +6.0 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -166 | -165.8 |
| FALL BACK GOOD ORDER | 9 | 9 | 1 | 0.33 | +6 | +6.4 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +15 | +15.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +102 | +101.5 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| HIS MOVE AND SHOT | 29 | 27 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +8 | +8.3 |
| HUNT IN PAIRS | 4 | 4 | 1 | 0.33 | +97 | +97.4 |
| MISSILES IN THE MOVE | 22 | 16 | 1 | 0.33 | +71 | +71.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 40 | 39 | 1 | 0.33 | +13 | +13.1 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +8 | +8.3 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 1 | 0.33 | +15 | +14.7 |
| REDIRECT COUNTER | 15 | 12 | 1 | 0.33 | +33 | +32.8 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +321 | +320.7 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| ROUNDS AFTER TERROR | 5 | 5 | 1 | 0.33 | +48 | +47.6 |
| SHOTS AFTER THE MOVES | 16 | 16 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 10 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +22 | +22.1 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +6 | +6.4 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +3 | +3.1 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 45 | 45 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 19 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 78 | 72 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 62 | 61 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 25 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 33 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 32 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 162 | 158 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 29 | 19 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 9 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 10 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 32 | 18 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 276 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 14 | 14 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 87 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 40 | 38 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 23 | 23 | 0 | 0.00 | - | - |
| STANDS STILL | 329 | 322 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 7 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 282 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 8 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 14 | 13 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p13

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 5.33 | 12.2 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 3.00 | 20.3 |
| HOLDER ASSIGNMENT | rule | 2.00 | 1.00 | 8.6 |
| ARMY TABLE | rule | 1.67 | 0.67 | 26.6 |
| CANNON PLANNED TARGET | rule | - | 1.67 | 6.2 |
| NO REASON | gate | - | 1.33 | 93.9 |
| CHARIOT NO STATIC JOB | rule | 0.67 | - | 67.8 |
| JOINT CHARGE NOW | rule | - | 0.67 | 27.8 |
| MARCH OF THE TABLE | rule | 0.67 | - | 2.4 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 34.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 21.0 |
| CHARGE NOW FIRST | rule | - | 0.33 | 165.8 |
| RULE SWITCHED OFF | gate | 0.33 | - | 29.1 |
| WHO GETS IN | rule | - | 0.33 | 30.2 |

### Plans: cora-bb45c30-p13

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 0% | 0 | 0 | 0% |
| Mine | move | 27.3 | 95% | 2935 | 0 | 0% |
| Mine | shoot | 3.3 | 60% | 478 | 128 | 27% |
| Mine | support | 0.7 | 100% | 17 | 0 | 0% |
| Opponent | charge | 2.0 | 50% | 217 | 66 | 31% |
| Opponent | move | 37.0 | 93% | 1562 | 0 | 0% |
| Opponent | shoot | 21.3 | 84% | 478 | 726 | 152% |

### Battle groups: cora-bb45c30-p13

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 20% | 50% | 0% | - | 50% | 0% | 0% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p13

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 37 | 25% | 3.0 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 28 (15) | 28 | 0 | 0 | 13% | 3.3 | - | 21 (10) | 14 (2) | 12 (6) | 27 (6) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 67 | 33% | 3.5 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 66 (6) | 11 | 55 | 16 | 50% | 4.7 | 0 (1) | 84 (3) | 56 (2) | 50 (4) | 93 (2) |
| Mine | Holder | 5 | 0 (5) | 0 | 0 | 21 | 40% | 4.3 | 0 (4) | - | 0 (1) | 0 (2) | 0 (3) |
| Mine | Shooter | 2 | 209 (2) | 55 | 154 | 50 | 0% | 1.0 | - | 418 (1) | 0 (1) | 209 (2) | - |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 22 | 0% | 2.3 | - | - | - | - | - |
| Opponent | Chaff | 2 | 139 (2) | 0 | 139 | 100 | 0% | 1.5 | 278 (1) | 0 (1) | - | 139 (2) | - |
| Opponent | Character | 8 | 19 (8) | 19 | 0 | 0 | 50% | 2.8 | 212 (1) | 0 (5) | 0 (2) | 88 (3) | 0 (5) |
| Opponent | Clean-up | 6 | 7 (6) | 7 | 0 | 17 | 33% | 2.2 | 0 (1) | 11 (5) | - | 10 (5) | 0 (1) |
| Opponent | Fast Hammer | 4 | 25 (4) | 25 | 0 | 47 | 25% | 4.3 | 0 (1) | 39 (1) | 24 (2) | 31 (3) | 0 (1) |
| Opponent | Hammer | 3 | 15 (3) | 15 | 0 | 0 | 67% | 3.0 | 0 (1) | 104 (1) | 0 (1) | 52 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | Shooter | 10 | 71 (10) | 14 | 58 | 23 | 0% | 2.1 | 170 (2) | 62 (8) | - | 98 (8) | 0 (2) |
| Opponent | War machine | 12 | 11 (12) | 11 | 0 | 9 | 8% | 1.8 | 8 (10) | - | 27 (2) | 0 (2) | 14 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: cora-bb45c30-p13

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 255 | 65 | 0.7 | 1.0 | 98 | 26 | +72 | 1 of 2 | 2 of 2 | - | +72 |
| Opponent | Dwarfen Mountain Holds | 2 | 219 | 26 | 1.5 | 1.3 | 17 | 20 | -3 | 1 of 3 | 1 of 3 | +52 | -30 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 142 | 2.0 | 1.5 | 71 | 0 | +71 | 1 of 2 | 1 of 2 | +77 | +65 |
| **Opponent** | all armies | 3 | 146 | 65 | 1.7 | 1.4 | 39 | 12 | +27 | 2 of 5 | 2 of 5 | +64 | +2 |

### Effective charges: cora-bb45c30-p13

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 1 (net -52) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 3 | 1 (net -60) | 0 | 1 (net +0) | 0 | 0 | 1 (net +52) | 0 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 2 | 1 (net +65) | 0 | 0 | 0 | 1 (net +77) | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cora-bb45c30-p13

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 52 | 105 | -52 | 128 | 144 | -17 | -32.7 |
| Mine | No odds | 1 | 836 | 195 | +195 | 195 | 63 | +132 | +15.7 |
| Mine | All fights | 2 | 444 | 150 | +72 | 161 | 104 | +57 | +12.9 |
| Opponent | Long shot (under 50%) | 2 | 236 | 532 | +2 | 76 | 30 | +46 | +19.3 |
| Opponent | Effective (55-75%) | 1 | 60 | 55 | +0 | 32 | 0 | +32 | +53.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 155 | 52 | +52 | 52 | 0 | +52 | +33.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 626 | 77 | +77 | 77 | 32 | +44 | +7.1 |
| Opponent | All fights | 5 | 262 | 249 | +27 | 62 | 18 | +44 | +16.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p13 | move | 22 | 2 (9%) | 2 (9%) | 0 (0%) | 20 (91%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

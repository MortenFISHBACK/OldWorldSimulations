# Doctrine scorecard: cora-bb45c30-p24

### Scorecard: cora-bb45c30-p24

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2735 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L3033 | 3 | 1 | Mine | yes | 9 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 4.5 | 3.0 | 2.0 | 2.5 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 0% | 2.0 | 2.5 | 3.0 | 1.5 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: cora-bb45c30-p24

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 33% (4 of 12) | 17% (4 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | 100% (4 of 4); on the table 100% | 89% (8 of 9); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 43% (9 of 21) | 64% (9 of 14) | 51% (18 of 35) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (9 of 19) | 64% (9 of 14) | 55% (18 of 33) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 34% (1354 of 3999) | 46% (1841 of 4000) | 40% (3195 of 7999) |
|   infantry points that never fought | lower | 24% (148 of 606) | 54% (695 of 1293) | 44% (843 of 1899) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 75% (9 of 12) | 59% (13 of 22) | 65% (22 of 34) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 2.0 uses a game | 50% (2 of 4); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (2325 of 3262) | 54% (2152 of 3962) | 62% (4477 of 7224) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (58%) | 0.7 (40%) | 3.0 (53%) |
| MARCHED: its unit marched | 0.3 (8%) | 1.0 (60%) | 1.3 (24%) |
| IN COMBAT: engaged in combat | 0.7 (17%) | 0.0 (0%) | 0.7 (12%) |
| STUPIDITY: Stupidity | 0.7 (17%) | 0.0 (0%) | 0.7 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 2.7 | 4.0 | 6.0 | 1.7 | 0.0 |
| not cast | 3.3 | 0.3 | 0.7 | 5.7 | 2.0 | 16.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 3.0 (53%) | 0.7 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (24%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (67%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.3 (100%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 2.0 a game | 2.0 a game |
| stood (cast and not dispelled) | 33% (2 of 6) | 33% (2 of 6) | 33% (4 of 12) |
| the unit moved after it | 100% (2 of 2) | 50% (1 of 2) | 75% (3 of 4) |
| it charged on its next turn | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| the enemy charged it first | 50% (1 of 2) | 0% (0 of 2) | 25% (1 of 4) |
| it fought by the end of its next turn | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | 100% (2 of 2) | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 4) | 65% (44 of 68) | 61% (44 of 72) |
|   cavalry | - | 66% (19 of 29) | 66% (19 of 29) |
|   character | 0% (0 of 4) | 71% (10 of 14) | 56% (10 of 18) |
|   infantry | - | 60% (15 of 25) | 60% (15 of 25) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 3.3 (42%) | 3.3 (36%) |
| CHARGED: it charged | 0.7 (50%) | 1.3 (17%) | 2.0 (21%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (12%) | 1.0 (11%) |
| NO TARGET IN RANGE | 0.3 (25%) | 0.7 (8%) | 1.0 (11%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (25%) | 0.3 (4%) | 0.7 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.3 (17%) | 1.3 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 2.7 | 74% | 6.9 pts | 53 pts |
| character | 3.3 | 1.7 | 50% | 9.3 pts | 31 pts |
| infantry | 7.0 | 2.0 | 71% | 14.4 pts | 101 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 3.7 | 3.5 |
| Charges that made contact a game | 3.0 | 2.0 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (4 units) | - | 0.50 declared, 0.50 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | - | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.27 contact (22 units) | 0.35 declared, 0.19 contact (31 units) | 0.34 declared, 0.23 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | 100% (2 of 2) | - | 75% (6 of 8) |
| Character in a unit | 100% (2 of 2) | 75% (3 of 4) | 100% (1 of 1) | 86% (6 of 7) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 33% (1 of 3) | 60% (3 of 5) |
| Infantry | 57% (4 of 7) | 33% (1 of 3) | - | 50% (5 of 10) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Monstrous | 67% (2 of 3) | - | - | 67% (2 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 1 | 67% (2 of 3); on the table 67% | 44% (8 of 18) | 23% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 45% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 2 | 100% (4 of 4); on the table 100% | 58% (7 of 12) | 46% | 59% (13 of 22) | 67% (2 of 3); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p24, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | 0% (0) | 20% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p24

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 83% (5 of 6) | 38% (3 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 3) | 43% (3 of 7) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 100% (1 of 1) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.5 | 1.5 |
| Movement | Points that never moved of their own | 0.0 | 0.0 |
| Movement | Fights charged into per game | 2.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 4, net +666 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 1 of 4, net +254 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 5, net +129 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +0 | 2 of 4, net +72 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.7 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 57% (25 of 44) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (2 of 5) | 33% (3 of 9) |
| Magic | Wounds caused by magic missiles | - | 4.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 151.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 0.0 / 0.7 | 1.3 / 1.0 / 0.0 / 1.0 |
| Combat | Points destroyed in combat | 120.7 | 354.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +23 | +191 |
| Combat | Net per 100 charger points, damage counted | +6.1 | +123.1 |
| Combat | First round won (charged fights) | 75% | 83% |
| Combat | Net points per charged fight | +32 | +176 |
| Combat | Net points per supported fight / lone fight | +258 / +0 | - / +176 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 8 | 2 of 6 |
| Game | Points lost | 732.0 | 156.0 |
| Game | VP from objectives | 535.0 | 785.0 |
| Game | Lone holders (player turns) | 4.5 | 2.0 |

- Mine won / drew / lost: 0 / 0 / 2 of 2 ended games (of 3); mean margin (Mine - Opponent) -876 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 888
- Games not ended: 1 (L2735-1); findings 1, warnings 0

### Opponent rules: cora-bb45c30-p24

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 17.3 | +436.6 | 0.0 | 174.3 | 33.0 | +78.8 | 0.0 | 86.0 |
| BACKUP TARGETS | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -24.5 | 86.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | +119.8 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.0 | +19.5 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 7.0 | +178.8 | 0.0 | 0.0 | 1.3 | +46.8 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 1.0 | -0.5 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +4.2 | 0.0 | 0.0 | 0.7 | +57.2 | 0.0 | 86.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -6.1 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 19.7 | -766.6 | 0.0 | 553.3 | 9.7 | -167.1 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 86.0 | 179.7 | 2.0 | +0.0 | 275.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 14.0 | +0.0 | 0.0 | 25.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.0 | +45.4 | 0.0 | 0.0 | 1.7 | +70.1 | 86.0 | 0.0 |
| COVER ONCE | 6.7 | -402.8 | 0.0 | 32.7 | 11.7 | -348.3 | 0.0 | 34.7 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | +7.9 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.7 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 0.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -44.8 | 132.7 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +23.9 | 0.0 | 84.7 | - | - | - | - |
| EXACT ROUND | 1.3 | +12.6 | 86.0 | 179.7 | 2.0 | +2.7 | 109.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +2.7 | 86.0 | 95.0 | 2.0 | +0.0 | 190.3 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 20.0 | +267.0 | 0.0 | 82.7 | - | - | - | - |
| FEATURE BUFFS | 0.7 | +7.0 | 0.0 | 0.0 | 0.3 | +3.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.3 | 0.0 | 84.7 | - | - | - | - |
| FIVE ACTION | 65.0 | +4265.0 | 86.0 | 912.3 | 80.0 | +5617.7 | 597.7 | 448.0 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 32.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +121.9 | 0.0 | 84.7 | 1.0 | +39.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +269.6 | 86.0 | 179.7 | 3.0 | +309.7 | 275.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 3.7 | +279.2 | 0.0 | 0.0 | 17.3 | +1276.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 363.3 | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +5.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 25.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 34.7 |
| HIS MOVE AND SHOT | 3.7 | -35.0 | 0.0 | 56.0 | 4.3 | -16.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 265.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 104.0 |
| HIS RUN AFTER OUR TURN | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.0 | +1020.1 | 0.0 | 605.0 | 26.7 | +280.5 | 0.0 | 172.0 |
| HIS SHOTS BY HIS RUN | 45.7 | +846.7 | 0.0 | 632.7 | 19.7 | +207.8 | 0.0 | 172.0 |
| HIS TURN DENIED | 1.3 | +30.4 | 86.0 | 95.0 | - | - | - | - |
| HIS TURN RUN | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 65.3 | 11.3 | +0.0 | 0.0 | 172.0 |
| HOLDER ASSIGNMENT | 7.3 | +518.1 | 0.0 | 32.7 | 7.7 | +471.1 | 0.0 | 86.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 2.3 | -108.4 | 86.0 | 179.7 | 3.0 | -92.1 | 275.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +6.9 | 0.0 | 0.0 |
| IDLE COST | 16.0 | -200.4 | 0.0 | 23.3 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 34.7 | 347.3 | 11.3 | +0.0 | 808.7 | 0.0 |
| LONG SHOT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +33.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.0 | 86.0 | 95.0 | 1.3 | +0.7 | 165.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -29.8 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -5.2 | 0.0 | 0.0 | 0.7 | -16.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.9 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.7 | +52.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +45.9 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +13.1 | 0.0 | 0.0 | 1.7 | +280.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +18.3 | 0.0 | 50.0 | 2.0 | +23.2 | 0.0 | 86.0 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +8.7 | 0.0 | 0.0 | 4.3 | +151.2 | 0.0 | 172.0 |
| MISSILES NEXT TURN | 4.3 | +17.1 | 0.0 | 0.0 | 5.3 | +119.3 | 0.0 | 172.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 34.7 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 2.0 | -66.2 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.0 | +1390.7 | 0.0 | 32.7 | 3.7 | +152.1 | 0.0 | 69.3 |
| NEARER NOT NEEDED | 8.0 | +299.3 | 0.0 | 0.0 | 6.0 | +266.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 6.7 | +916.7 | 0.0 | 0.0 | 2.3 | +111.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -245.6 | 86.0 | 179.7 | 2.0 | -63.2 | 142.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 2.3 | -4.1 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -102.1 | 0.0 | 0.0 | 7.0 | -227.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 86.0 |
| ONE FIGHT FORMULA | 7.0 | -93.5 | 0.0 | 248.0 | 5.7 | -102.7 | 0.0 | 34.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.0 | +4.4 | 0.0 | 32.7 | 2.3 | -51.4 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.3 | -147.4 | 0.0 | 32.7 | - | - | - | - |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.3 | +66.5 | 86.0 | 179.7 | 0.3 | +0.7 | 0.0 | 0.0 |
| OWN CAST FIRST | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.3 | +4.0 | 0.0 | 0.0 | 0.7 | +40.7 | 0.0 | 0.0 |
| PLAN RESULT | 35.7 | +171.2 | 132.7 | 874.7 | 34.0 | +450.8 | 350.0 | 206.7 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 95.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.7 | -328.4 | 0.0 | 0.0 | 8.0 | -223.0 | 0.0 | 69.3 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | -0.6 | 0.0 | 0.0 | 1.0 | -13.1 | 0.0 | 0.0 |
| QUARTER ODDS | 13.3 | +1858.6 | 0.0 | 520.7 | 19.0 | +2282.2 | 455.3 | 0.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +31.0 | 0.0 | 0.0 | 1.7 | +16.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.0 | +168.9 | 0.0 | 25.0 | 1.3 | +49.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +55.8 | 0.0 | 50.0 | 2.0 | +130.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -282.4 | 0.0 | 0.0 | 0.7 | -13.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +14.9 | 0.0 | 0.0 | 1.3 | +42.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | -124.9 | 86.0 | 179.7 | 1.7 | +25.4 | 190.3 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -20.7 | 86.0 | 179.7 | 0.3 | -15.7 | 32.7 | 0.0 |
| RUN DOWN | 2.0 | -30.3 | 86.0 | 179.7 | 0.3 | -4.6 | 32.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | 4.3 | -15.1 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +1.7 | 0.0 | 0.0 | 0.3 | -23.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +6.3 | 0.0 | 0.0 | 0.3 | +2.5 | 32.7 | 0.0 |
| SET CREDITED ONCE | 1.7 | -34.8 | 0.0 | 50.0 | - | - | - | - |
| SET UP BY THE SET | 2.0 | -8.1 | 0.0 | 50.0 | - | - | - | - |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +20.9 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +28.4 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +36.0 | 0.0 | 0.0 | 1.7 | +22.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.2 | 132.7 | 0.0 |
| SHOT RISK POINTS | 36.0 | -471.1 | 0.0 | 359.7 | 11.0 | +42.7 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.3 | +17.8 | 0.0 | 0.0 | 17.0 | +252.0 | 0.0 | 172.0 |
| SPELL OFF EDGE | - | - | - | - | 0.3 | +20.9 | 32.7 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +20.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +0.7 | 0.0 | 0.0 | 1.7 | +8.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 10.7 | +0.0 | 0.0 | 148.0 | 7.7 | +0.0 | 0.0 | 155.3 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 9.7 | +0.0 | 0.0 | 0.0 | 30.7 | +0.0 | 322.7 | 0.0 |
| STAY WORTH | - | - | - | - | 13.0 | +69.0 | 322.7 | 86.0 |
| STUPIDITY NEXT TURN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 5.3 | +494.0 | 0.0 | 0.0 | 2.7 | +56.7 | 0.0 | 172.0 |
| SUPPORT WORKED OUT | 5.3 | +494.0 | 0.0 | 0.0 | 2.7 | +56.7 | 0.0 | 172.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +4.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +4.3 | 0.0 | 32.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 34.7 |
| THE ROW KEEPS ITS WAY | 5.3 | +0.0 | 0.0 | 132.7 | 1.0 | +0.0 | 0.0 | 86.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 132.7 | 0.3 | +0.0 | 0.0 | 86.0 |
| THE TABLE AGAIN | 5.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.3 | +0.0 | 0.0 | 366.3 | 39.0 | +0.0 | 0.0 | 206.7 |
| TIED UP BY THE SUM | 1.3 | +195.6 | 86.0 | 95.0 | 0.3 | +43.7 | 32.7 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 49.3 | +514.6 | 0.0 | 378.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -38.9 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -14.7 | 169.3 | 0.0 |
| WHO FIGHTS | 0.3 | +2.7 | 0.0 | 0.0 | 0.7 | -0.1 | 25.0 | 0.0 |
| WHO HITS BACK | 0.3 | +84.7 | 0.0 | 0.0 | 0.7 | +31.0 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | -11.9 | 84.7 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -121.5 | 0.0 | 330.7 | 1.3 | -92.2 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.0 | +57.3 | 0.0 | 0.0 | 2.3 | +26.2 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p24

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 151 | 151 | 105 | 35.00 | +1552 | +14.8 |
| LEGAL CHARGES ONLY | 46 | 46 | 46 | 15.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 45 | 45 | 38 | 12.67 | +1458 | +38.4 |
| OFF BEST | 38 | 38 | 38 | 12.67 | -987 | -26.0 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| FIVE ACTION | 435 | 418 | 32 | 10.67 | +2256 | +70.5 |
| MOVE TO CHARGE COMPUTED | 41 | 35 | 25 | 8.33 | +1785 | +71.4 |
| HIS SHOT LIST | 227 | 219 | 23 | 7.67 | +168 | +7.3 |
| HIS SHOTS BY HIS RUN | 196 | 187 | 22 | 7.33 | +384 | +17.5 |
| THE TABLE AGAIN | 29 | 29 | 19 | 6.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 27 | 24 | 18 | 6.00 | +1472 | +81.8 |
| PROMISE BY ITS OWN SUM | 53 | 53 | 18 | 6.00 | -1654 | -91.9 |
| TIME ON OUR SIDE | 148 | 117 | 16 | 5.33 | +85 | +5.3 |
| GOAL WALK | 63 | 62 | 15 | 5.00 | +538 | +35.9 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 14 | 4.67 | +34 | +2.4 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 25 | 24 | 12 | 4.00 | +19 | +1.6 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| QUARTER ODDS | 97 | 95 | 11 | 3.67 | +731 | +66.5 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| CHARGE LOSSES | 88 | 84 | 8 | 2.67 | +391 | +48.8 |
| FOUR ROUNDS | 16 | 15 | 8 | 2.67 | +368 | +46.0 |
| IDLE COST | 48 | 32 | 8 | 2.67 | +52 | +6.5 |
| SHOT RISK POINTS | 141 | 135 | 8 | 2.67 | +234 | +29.2 |
| CAST JOB | 6 | 6 | 6 | 2.00 | +16 | +2.6 |
| PATHS CROSS | 6 | 6 | 6 | 2.00 | +134 | +22.3 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +172 | +34.3 |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 5 | 1.67 | +8 | +1.6 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +485 | +121.3 |
| NEARER NOT NEEDED | 42 | 40 | 4 | 1.33 | +131 | +32.7 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -442 | -110.6 |
| PROMISE KNOWS THE FIGHT | 5 | 4 | 4 | 1.33 | -41 | -10.3 |
| SUPPORT ADDS | 24 | 23 | 4 | 1.33 | +130 | +32.6 |
| SUPPORT WORKED OUT | 24 | 23 | 4 | 1.33 | +130 | +32.6 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -2 | -0.5 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +184 | +61.4 |
| COVER ONCE | 55 | 32 | 3 | 1.00 | +51 | +16.9 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -140 | -46.6 |
| REDIRECT COUNTER | 13 | 10 | 3 | 1.00 | +119 | +39.6 |
| REFUSING RETIRES | 5 | 5 | 3 | 1.00 | -54 | -18.0 |
| RISK BY ARC | 12 | 11 | 3 | 1.00 | +74 | +24.6 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 3 | 1.00 | +11 | +3.8 |
| TIED UP BY THE SUM | 5 | 4 | 3 | 1.00 | +34 | +11.5 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +307 | +102.5 |
| WHOLE FIGHT DANGER | 11 | 11 | 3 | 1.00 | +137 | +45.8 |
| CHARGE NOW FIRST | 12 | 12 | 2 | 0.67 | -349 | -174.7 |
| EXACT ROUND | 10 | 10 | 2 | 0.67 | +9 | +4.5 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 2 | 0.67 | +34 | +17.1 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +26 | +13.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOTS IN THE MOVE | 52 | 38 | 2 | 0.67 | +21 | +10.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -96 | -96.1 |
| BLOWS WHERE AIMED | 1 | 1 | 1 | 0.33 | +9 | +9.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +21 | +20.7 |
| FALLS SHORT | 60 | 46 | 1 | 0.33 | +1 | +1.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +5 | +5.3 |
| HIS TURN DENIED | 4 | 3 | 1 | 0.33 | +33 | +32.9 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +21 | +20.6 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| LOST AFTER ESCAPE | 7 | 7 | 1 | 0.33 | +0 | +0.0 |
| MARCH CHECK | 5 | 5 | 1 | 0.33 | +11 | +10.8 |
| MAX FOR POSITIONING | 10 | 7 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 20 | 13 | 1 | 0.33 | +10 | +10.3 |
| NO DOUBLE ROUNDS | 13 | 12 | 1 | 0.33 | +21 | +20.7 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +5 | +5.3 |
| OVERRUNS AWAY | 5 | 4 | 1 | 0.33 | +21 | +20.7 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -4 | -3.5 |
| SEARCH SPOT | 5 | 5 | 1 | 0.33 | +5 | +5.0 |
| SET UP BY THE SET | 6 | 6 | 1 | 0.33 | +22 | +21.5 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +13 | +13.0 |
| THE ROW IN ITS ORDER | 16 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -117 | -116.6 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 16 | 16 | 1 | 0.33 | +8 | +7.8 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 17 | 17 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 58 | 58 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 11 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 11 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 61 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 38 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 28 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 24 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 12 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 51 | 46 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 28 | 28 | 0 | 0.00 | - | - |
| HIS TURN RUN | 15 | 15 | 0 | 0.00 | - | - |
| HOLD ODDS | 68 | 68 | 0 | 0.00 | - | - |
| HONEST WORTH | 16 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 7 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 29 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 29 | 29 | 0 | 0.00 | - | - |
| NO SECOND RUN | 29 | 29 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 38 | 22 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 16 | 11 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 10 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 14 | 14 | 0 | 0.00 | - | - |
| PLAN RESULT | 209 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 21 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 6 | 6 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 55 | 50 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 121 | 114 | 0 | 0.00 | - | - |
| STAY WORTH | 39 | 32 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 6 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 229 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 3 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p24

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 6.00 | 25.5 |
| ARMY TABLE | rule | - | 6.00 | 44.0 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 3.67 | 91.9 |
| ONE PROMISE A TARGET | rule | 1.33 | - | 110.6 |
| MARCH OF THE TABLE | rule | 0.67 | 0.33 | 46.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.67 | 13.6 |
| REFUSING RETIRES | rule | 0.33 | 0.67 | 18.0 |
| CHAFF PASSED | rule | - | 0.67 | 0.8 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 174.7 |
| NO REASON | gate | - | 0.67 | 24.1 |
| BEST PRIZE | rule | 0.33 | - | 96.1 |
| FALLBACK | gate | - | 0.33 | 69.4 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 0.9 |
| JOINT CHARGE NOW | rule | - | 0.33 | 0.9 |
| OWN CAST FIRST | rule | 0.33 | - | 3.5 |
| RULE SWITCHED OFF | gate | 0.33 | - | 1.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 116.6 |

### Plans: cora-bb45c30-p24

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 401 | 171 | 43% |
| Mine | join | 4.7 | 100% | 222 | 0 | 0% |
| Mine | move | 26.3 | 92% | 1490 | 0 | 0% |
| Mine | shoot | 0.3 | 0% | 6 | 0 | 0% |
| Mine | support | 2.0 | 100% | 47 | 0 | 0% |
| Opponent | charge | 2.0 | 67% | 337 | 250 | 74% |
| Opponent | move | 29.0 | 98% | 1600 | 0 | 0% |
| Opponent | shoot | 1.7 | 40% | 135 | 200 | 149% |
| Opponent | support | 1.3 | 100% | 77 | 0 | 0% |

### Battle groups: cora-bb45c30-p24

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 33% | 100% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p24

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 92 (5) | 0 | 92 | 65 | 40% | 3.7 | 116 (4) | - | 0 (1) | 116 (4) | 0 (1) |
| Mine | Character | 6 | 9 (6) | 9 | 0 | 16 | 50% | 3.3 | 0 (2) | 12 (3) | - | 0 (2) | 12 (3) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 5 | 55 (5) | 49 | 6 | 86 | 40% | 3.3 | 0 (1) | 0 (2) | 146 (2) | - | 55 (5) |
| Mine | Hammer | 2 | 112 (2) | 0 | 112 | 0 | 0% | 4.5 | 208 (1) | 0 (1) | - | 208 (1) | 0 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | 0 (1) | - | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 5 | 54 (5) | 54 | 0 | 0 | 0% | 1.4 | 18 (3) | 133 (1) | 0 (1) | 33 (2) | 64 (3) |
| Opponent | Clean-up | 2 | 83 (2) | 0 | 83 | 0 | 0% | 2.0 | 167 (1) | 0 (1) | - | 167 (1) | 0 (1) |
| Opponent | Fast Hammer | 3 | 39 (3) | 0 | 39 | 27 | 0% | 1.3 | 95 (1) | 0 (1) | 0 (1) | 95 (1) | 0 (2) |
| Opponent | Hammer | 6 | 49 (6) | 49 | 0 | 0 | 33% | 4.5 | - | 56 (4) | 41 (2) | 0 (1) | 57 (5) |
| Opponent | Shooter | 5 | 30 (5) | 0 | 30 | 32 | 0% | 1.2 | 86 (1) | 21 (3) | 13 (1) | 86 (1) | 18 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cora-bb45c30-p24

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 4 | 3 of 4 | - | +0 |
| Mine | Warriors of Chaos | 1 | 0 | 258 | 4.0 | 1.2 | 64 | 0 | +64 | 0 of 4 | 3 of 4 | +258 | +0 |
| **Mine** | all armies | 3 | 0 | 86 | 2.7 | 1.1 | 32 | 0 | +32 | 0 of 8 | 6 of 8 | +258 | +0 |
| Opponent | Wood Elf Realms | 3 | 151 | 387 | 2.0 | 1.0 | 194 | 17 | +176 | 2 of 6 | 5 of 6 | - | +176 |

### Effective charges: cora-bb45c30-p24

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 4 | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 1 | 0% (0 of 3) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 1 (net +0) | 1 (net +258) | 0 | 2 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 6 | 1 (net +666) | 0 | 1 (net +254) | 0 | 0 | 2 (net +72) | 2 | 25% (1 of 4) |

### Charged fights, damage counted: cora-bb45c30-p24

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 366 | 63 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 254 | 114 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 622 | 166 | +129 | 174 | 78 | +96 | +15.5 |
| Mine | No odds | 3 | 275 | 119 | +0 | 6 | 8 | -2 | -0.6 |
| Mine | All fights | 8 | 382 | 116 | +32 | 46 | 22 | +23 | +6.1 |
| Opponent | Long shot (under 50%) | 1 | 499 | 348 | +666 | 666 | 0 | +666 | +133.5 |
| Opponent | Effective (55-75%) | 1 | 102 | 254 | +254 | 254 | 63 | +191 | +187.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 114 | 111 | +72 | 133 | 9 | +124 | +109.1 |
| Opponent | No odds | 2 | 52 | 84 | -3 | 74 | 52 | +22 | +41.3 |
| Opponent | All fights | 6 | 155 | 165 | +176 | 222 | 31 | +191 | +123.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p24 | move | 26 | 7 (27%) | 6 (23%) | 2 (8%) | 17 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

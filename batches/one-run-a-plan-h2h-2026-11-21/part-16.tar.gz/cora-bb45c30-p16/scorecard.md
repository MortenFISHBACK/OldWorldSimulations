# Doctrine scorecard: cora-bb45c30-p16

### Scorecard: cora-bb45c30-p16

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 807 |
| L0528 | 6 | 1 | Opponent | no | 12 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 1 | - | 1 | 3 | 0 | 0 | 0 | 798 |
| L0616 | 4 | 1 | Opponent | no | 0 | 4 | 0 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | - | 4 | 2 | 0 | 0 | 0 | 495 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 0 | 5 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.5 | - | 1.7 | 2.7 | 0.0 | 0.0 | 0.0 | 700.0 |
| **Average** | | | Opponent | 0% | 6.0 | 3.0 | 0.0 | 3.0 | 0.7 | 0.0 | 0.0 | 66.7 |

### KPIs: cora-bb45c30-p16

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (12 of 12) | 0% (0 of 9) | 57% (12 of 21) |
| Winner chose to follow up after the loser gave ground |  | 33% (1 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 60% (3 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 60% (3 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | - | 17% (1 of 6) | 17% (1 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 17% (1 of 6) | 17% (1 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (9 of 12) | 75% (9 of 12) |
| Points that never fought | lower | 87% (5197 of 6000) | 81% (4866 of 5999) | 84% (10063 of 11999) |
|   infantry points that never fought | lower | 92% (2049 of 2232) | 100% (720 of 720) | 94% (2769 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (21 of 27) | 57% (12 of 21) | 69% (33 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 77% (3256 of 4232) | 58% (3143 of 5415) | 66% (6399 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (100%) | 1.7 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 0.3 | 0.0 | 0.3 | 0.0 |
| not cast | 3.7 | 2.0 | 1.7 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.7 (100%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.7 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (55%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (112 of 171) | 52% (21 of 40) | 63% (133 of 211) |
|   cavalry | 38% (6 of 16) | 64% (9 of 14) | 50% (15 of 30) |
|   character | 56% (9 of 16) | 0% (0 of 9) | 36% (9 of 25) |
|   infantry | 46% (24 of 52) | 0% (0 of 5) | 42% (24 of 57) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |
|   war machine | 87% (65 of 75) | 100% (12 of 12) | 89% (77 of 87) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 6.3 (32%) | 0.7 (11%) | 7.0 (27%) |
| CHARGED: it charged | 2.0 (10%) | 0.7 (11%) | 2.7 (10%) |
| IN COMBAT: it fought this turn or the last | 1.0 (5%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET IN RANGE | 4.3 (22%) | 3.3 (53%) | 7.7 (29%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.3 (27%) | 1.7 (26%) | 7.0 (27%) |
| SHELTERED: the target was sheltered | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.3 | 80% | 6.6 pts | 33 pts |
| character | 3.0 | 3.0 | 44% | 27.4 pts | 82 pts |
| infantry | 16.0 | 3.7 | 83% | 4.5 pts | 73 pts |
| monster | 2.7 | 0.3 | 88% | 0.9 pts | 2 pts |
| war machine | 25.7 | 18.0 | 65% | 21.1 pts | 542 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.0 | 2.0 |
| Charges that made contact a game | 1.7 | 0.7 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.24 contact (21 units) | 0.30 declared, 0.10 contact (20 units) | 0.29 declared, 0.17 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | - | 50% (1 of 2) | 67% (4 of 6) |
| Character in a unit | 86% (6 of 7) | 100% (3 of 3) | 100% (1 of 1) | 91% (10 of 11) |
| Character on its own | - | 0% (0 of 2) | 67% (2 of 3) | 40% (2 of 5) |
| Infantry | 71% (5 of 7) | 50% (3 of 6) | - | 62% (8 of 13) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 0% (0 of 1) | - | - | 0% (0 of 1) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 33% (1 of 3); on the table 67% | - | 87% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 72% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | - | 17% (1 of 6) | 85% | 73% (11 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p16, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (4) | 100% (4) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p16

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 80% (4 of 5) | 0% (0 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (64 of 96) | 53% (8 of 15) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 11) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 50% (1 of 2) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.7 | 3.0 |
| Movement | Points that never moved of their own | 700.0 | 66.7 |
| Movement | Fights charged into per game | 1.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +0 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net -20 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.3 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (30 of 52) | 10% (1 of 10) |
| Shooting | Points destroyed by shooting units | 302.3 | 0.0 |
| Shooting | War machine shots | 21.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 77% (50 of 65) | 42% (5 of 12) |
| Shooting | Points destroyed by war machines | 0.0 | 38.3 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 100% (1 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 100.0 |
| Combat | Points run down | 0.0 | 40.0 |
| Combat | Net points per charged fight, damage counted | -16 | +44 |
| Combat | Net per 100 charger points, damage counted | -23.4 | +15.9 |
| Combat | First round won (charged fights) | 80% | 100% |
| Combat | Net points per charged fight | -12 | +152 |
| Combat | Net points per supported fight / lone fight | - / -12 | - / +152 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 0 of 2 |
| Game | Points lost | 372.7 | 335.7 |
| Game | VP from objectives | 623.3 | 523.3 |
| Game | Lone holders (player turns) | 0.5 | 6.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +18 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 708
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p16

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +21.4 | 0.0 | 20.0 | - | - | - | - |
| ARMY TABLE | 6.0 | +87.2 | 0.0 | 0.0 | 15.3 | +118.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.3 | +0.0 | 0.0 | 31.7 | - | - | - | - |
| BEST PRIZE | 0.3 | +9.2 | 0.0 | 0.0 | 1.3 | -76.6 | 80.0 | 92.3 |
| BOMBING RUN | 0.7 | +20.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 2.0 | +0.0 | 655.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 23.7 | +478.7 | 1562.7 | 303.3 | 4.0 | +202.2 | 76.7 | 66.7 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +9.9 | 0.0 | 10.0 |
| CHAFF PASSED | 1.0 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +28.0 | 0.0 | 92.3 |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.3 | -198.5 | 0.0 | 20.0 | 27.3 | -1527.5 | 0.0 | 474.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 4.0 | +0.0 | 0.0 | 20.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 8.7 | -1512.8 | 0.0 | 150.0 | 4.3 | -176.0 | 0.0 | 0.0 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +25.4 | 0.0 | 20.0 | 1.3 | +7.0 | 35.0 | 255.3 |
| FALL BACK GOOD ORDER | 2.0 | +0.9 | 0.0 | 20.0 | 1.3 | +0.0 | 35.0 | 255.3 |
| FALLS SHORT | - | - | - | - | 21.7 | +202.4 | 0.0 | 274.0 |
| FEATURE BUFFS | 0.7 | +3.9 | 0.0 | 0.0 | 0.7 | +5.6 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.1 | 0.0 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| FIVE ACTION | 127.0 | +6633.6 | 3858.0 | 808.7 | 81.3 | +2361.1 | 248.3 | 892.7 |
| FLANK NOT WEIGHED | 1.7 | +0.0 | 0.0 | 61.0 | 6.0 | +0.0 | 0.0 | 92.3 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +4.2 | 0.0 | 20.0 | 2.0 | +16.0 | 35.0 | 255.3 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 4.3 | +220.1 | 0.0 | 0.0 | 14.7 | +1061.0 | 0.0 | 0.0 |
| GUN FIGURES | 0.7 | +4.3 | 10.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.3 | +51.7 | 0.0 | 0.0 | 1.7 | +38.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 20.0 | 12.3 | +0.0 | 0.0 | 326.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 122.0 | 19.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 20.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -8.6 | 0.0 | 0.0 | 9.0 | -71.4 | 0.0 | 30.0 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 20.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 20.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 21.3 | +596.1 | 0.0 | 162.0 | 64.3 | +4910.3 | 0.0 | 474.0 |
| HIS SHOTS BY HIS RUN | 16.3 | +262.7 | 0.0 | 20.0 | 55.0 | +1687.3 | 0.0 | 504.0 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +36.5 | 35.0 | 163.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 11.7 | +0.0 | 0.0 | 0.0 | 17.7 | +0.0 | 0.0 | 74.0 |
| HOLDER ASSIGNMENT | 10.0 | +1226.6 | 0.0 | 0.0 | 9.7 | +987.4 | 0.0 | 37.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -12.8 | 0.0 | 20.0 | 2.0 | -72.2 | 35.0 | 255.3 |
| IDLE COST | - | - | - | - | 20.3 | -297.1 | 0.0 | 220.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | +85.3 | 0.0 | 92.3 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 92.3 | 181.0 | 2.0 | +0.0 | 80.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +3.4 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | -13.6 | 0.0 | 0.0 | 3.7 | +67.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +3.8 | 0.0 | 0.0 |
| MODEL FACING | 4.0 | +624.4 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 37.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.3 | +89.1 | 0.0 | 0.0 | 2.3 | +129.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +265.8 | 0.0 | 0.0 | 2.7 | +123.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 2.3 | +129.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -52.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -23.7 | 0.0 | 20.0 | 1.7 | -26.4 | 0.0 | 255.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -142.7 | 0.0 | 35.0 | 3.3 | -155.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -43.9 | 0.0 | 20.0 | 2.0 | -54.8 | 0.0 | 255.3 |
| ONE OBJECTIVE FORMULA | 3.3 | -110.9 | 0.0 | 0.0 | 4.3 | -136.2 | 0.0 | 37.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +25.4 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +81.2 | 35.0 | 163.0 |
| PATHS CROSS | 0.3 | +0.1 | 0.0 | 0.0 | 0.3 | -10.6 | 0.0 | 0.0 |
| PLAN RESULT | 58.3 | +2548.4 | 2199.3 | 570.3 | 37.7 | +212.9 | 0.0 | 634.3 |
| PROMISE BELOW ZERO | - | - | - | - | 1.3 | +0.0 | 0.0 | 255.3 |
| PROMISE BY ITS OWN SUM | 10.3 | -171.6 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 9.7 | +1079.5 | 369.3 | 0.0 | 9.3 | +637.1 | 60.0 | 133.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +118.3 | 0.0 | 0.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -5.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +3.9 | 0.0 | 20.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -35.7 | 40.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -13.3 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +56.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +73.3 | 0.0 | 20.0 | 1.7 | -110.7 | 35.0 | 255.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -5.4 | 35.0 | 163.0 |
| RUN DOWN | 1.3 | -17.8 | 0.0 | 20.0 | 1.3 | -1.9 | 0.0 | 92.3 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -82.0 | 0.0 | 10.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | +14.6 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.7 | -99.5 | 0.0 | 20.0 | - | - | - | - |
| SET UP BY THE SET | 2.0 | +105.1 | 0.0 | 20.0 | - | - | - | - |
| SET UP TOGETHER | 1.0 | +6.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 33.3 | +0.0 | 0.0 | 303.3 | 5.0 | +0.0 | 0.0 | 66.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 11.0 | +135.0 | 0.0 | 40.0 | 46.7 | -690.4 | 0.0 | 504.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 40.0 | +1912.3 | 0.0 | 323.3 | 8.3 | +273.3 | 0.0 | 229.7 |
| SPELL WORTH | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 20.0 | 7.0 | +0.0 | 0.0 | 37.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -12.0 | 0.0 | 92.3 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 326.0 |
| STANDS STILL | 96.7 | +0.0 | 3858.0 | 728.7 | 27.0 | +0.0 | 213.3 | 207.3 |
| STAY WORTH | 78.3 | +429.8 | 2510.7 | 625.0 | 14.3 | +208.1 | 213.3 | 263.0 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.0 | +12.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.0 | +12.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -13.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 20.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 20.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 62.0 | +0.0 | 0.0 | 384.3 | 37.7 | +0.0 | 0.0 | 323.7 |
| TIED UP BY THE SUM | 1.0 | +22.5 | 0.0 | 20.0 | 1.3 | +146.5 | 35.0 | 163.0 |
| TIME ON OUR SIDE | 61.7 | +616.9 | 326.0 | 203.0 | - | - | - | - |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 20.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | -15.4 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -7.2 | 0.0 | 0.0 | - | - | - | - |
| WHO GETS IN | - | - | - | - | 0.7 | +26.8 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 1.0 | +133.0 | 0.0 | 92.3 |
| WHOLE FIGHT DANGER | 0.3 | -30.1 | 0.0 | 0.0 | 2.0 | -127.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.0 | +19.3 | 0.0 | 0.0 | 6.3 | +500.0 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p16

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 257 | 253 | 92 | 30.67 | +2372 | +25.8 |
| HIS SHOTS BY HIS RUN | 214 | 214 | 65 | 21.67 | +906 | +13.9 |
| HOLDER ASSIGNMENT | 59 | 59 | 56 | 18.67 | +4072 | +72.7 |
| ARMY TABLE | 64 | 64 | 50 | 16.67 | +485 | +9.7 |
| SHOT RISK POINTS | 173 | 169 | 41 | 13.67 | +1555 | +37.9 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| TIME ON OUR SIDE | 185 | 170 | 29 | 9.67 | +77 | +2.6 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -896 | -34.5 |
| CANNON PLANNED TARGET | 83 | 83 | 19 | 6.33 | -48 | -2.5 |
| HARD STAY DROPPED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| FIVE ACTION | 625 | 620 | 15 | 5.00 | +624 | +41.6 |
| PROMISE BY ITS OWN SUM | 35 | 35 | 15 | 5.00 | -514 | -34.3 |
| THE TABLE AGAIN | 36 | 36 | 15 | 5.00 | +0 | +0.0 |
| GOAL WALK | 57 | 57 | 14 | 4.67 | +1032 | +73.7 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 17 | 17 | 13 | 4.33 | +275 | +21.2 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +1873 | +156.1 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 101 | 101 | 11 | 3.67 | +506 | +46.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +355 | +39.4 |
| COVER ONCE | 39 | 33 | 6 | 2.00 | +85 | +14.2 |
| GUN MASK | 9 | 9 | 6 | 2.00 | +157 | +26.2 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| RISK BY ARC | 9 | 9 | 6 | 2.00 | +141 | +23.6 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 7 | 7 | 6 | 2.00 | +182 | +30.4 |
| BEST PRIZE | 5 | 5 | 5 | 1.67 | -231 | -46.2 |
| CHAFF IN THE MOVE | 5 | 5 | 5 | 1.67 | +16 | +3.2 |
| IDLE COST | 61 | 45 | 5 | 1.67 | +82 | +16.4 |
| NEXT CHARGE BY LIST | 7 | 7 | 5 | 1.67 | +207 | +41.5 |
| EXACT ROUND | 10 | 10 | 4 | 1.33 | +30 | +7.6 |
| FALLS SHORT | 65 | 54 | 4 | 1.33 | +62 | +15.6 |
| FOUR ROUNDS | 12 | 12 | 4 | 1.33 | +32 | +8.1 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +256 | +63.9 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| MANOEUVRE | 16 | 16 | 4 | 1.33 | +220 | +55.1 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 145 | 112 | 4 | 1.33 | +203 | +50.7 |
| WOUNDS ON THE RANKS | 22 | 22 | 4 | 1.33 | +95 | +23.6 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -3 | -1.1 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +168 | +56.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 3 | 1.00 | +0 | +0.0 |
| STAY WORTH | 278 | 251 | 3 | 1.00 | +60 | +19.9 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +232 | +77.3 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +64 | +32.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.67 | +60 | +30.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +226 | +112.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -31 | -15.7 |
| QUARTER ODDS | 57 | 57 | 2 | 0.67 | +23 | +11.6 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +187 | +93.3 |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 2 | 0.67 | +18 | +8.8 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +80 | +40.1 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +84 | +83.9 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +4 | +3.7 |
| HONEST WORTH | 11 | 11 | 1 | 0.33 | +13 | +13.2 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| LOST AFTER ESCAPE | 4 | 4 | 1 | 0.33 | +1 | +0.9 |
| ONE OBJECTIVE FORMULA | 23 | 21 | 1 | 0.33 | +11 | +11.3 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +4 | +3.7 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +44 | +43.7 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| SET UP BY THE SET | 6 | 6 | 1 | 0.33 | +53 | +53.4 |
| SET UP TOGETHER | 3 | 2 | 1 | 0.33 | +0 | +0.5 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -46 | -46.2 |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 36 | 36 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 23 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 48 | 48 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 70 | 70 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 30 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 5 | 5 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 25 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 42 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 88 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 20 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 4 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 25 | 24 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 18 | 13 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 288 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 115 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 29 | 23 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 371 | 367 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 3 | 2 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 299 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 7 | 7 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p16

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.33 | 35.5 |
| PROMISE BY ITS OWN SUM | rule | 5.00 | - | 34.3 |
| ARMY TABLE | rule | - | 4.00 | 17.3 |
| CANNON PLANNED TARGET | rule | 3.33 | - | 4.8 |
| BEST PRIZE | rule | 0.33 | 1.33 | 46.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 22.2 |
| CHAFF PASSED | rule | 0.67 | - | 1.7 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| PATHS CROSS | rule | - | 0.33 | 31.8 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 46.2 |

### Plans: cora-bb45c30-p16

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 0% | 93 | 13 | 14% |
| Mine | join | 2.7 | 100% | 75 | 0 | 0% |
| Mine | move | 26.3 | 99% | 1287 | 0 | 0% |
| Mine | shoot | 28.0 | 64% | 1637 | 2535 | 155% |
| Opponent | charge | 2.0 | 17% | 138 | 88 | 63% |
| Opponent | move | 30.7 | 97% | 1052 | 0 | 0% |
| Opponent | shoot | 4.0 | 50% | 234 | 125 | 54% |
| Opponent | support | 1.0 | 100% | 1 | 0 | 0% |

### Deployment: positions vs output by unit type: cora-bb45c30-p16

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 7 (13) | 7 | 0 | 6 | 62% | 2.0 | 0 (2) | 11 (8) | 0 (2) | 10 (9) | 0 (3) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 32 | 33% | 1.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Hammer | 6 | 41 (6) | 0 | 41 | 0 | 83% | 1.0 | - | 61 (4) | 0 (2) | 56 (5) | 0 (1) |
| Mine | Shooter | 10 | 67 (10) | 0 | 67 | 13 | 0% | 1.7 | - | 131 (4) | 0 (6) | 121 (5) | 0 (5) |
| Mine | War machine | 17 | 47 (17) | 47 | 0 | 42 | 12% | 1.3 | 3 (9) | 0 (2) | 134 (6) | 0 (3) | 57 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 11 | 60% | 2.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 20 (8) | 20 | 0 | 30 | 62% | 4.3 | 40 (3) | 0 (1) | 5 (4) | 32 (5) | 0 (3) |
| Opponent | Clean-up | 3 | 61 (3) | 9 | 53 | 0 | 67% | 3.0 | 89 (1) | 34 (2) | - | 61 (3) | - |
| Opponent | Fast Hammer | 4 | 50 (4) | 0 | 50 | 0 | 75% | 4.0 | - | 89 (3) | 0 (1) | 73 (2) | 32 (2) |
| Opponent | Hammer | 3 | 30 (3) | 30 | 0 | 0 | 67% | 5.0 | 0 (1) | 35 (2) | - | 30 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 44 | 50% | 6.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 2 | 58 (2) | 58 | 0 | 50 | 0% | 1.0 | - | - | 58 (2) | - | 58 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.5 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: cora-bb45c30-p16

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 302 | 0 | 1.7 | 1.0 | 0 | 12 | -12 | 0 of 5 | 4 of 5 | - | -12 |
| Opponent | Kingdom of Bretonnia | 1 | 115 | 303 | 2.0 | 1.0 | 152 | 0 | +152 | 0 of 2 | 2 of 2 | - | +152 |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 38 | 101 | 0.7 | 1.0 | 152 | 0 | +152 | 0 of 2 | 2 of 2 | - | +152 |

### Effective charges: cora-bb45c30-p16

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 (net -20) | 1 | 25% (1 of 4) |

### Charged fights, damage counted: cora-bb45c30-p16

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 60 | 275 | +0 | 0 | 40 | -40 | -66.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 75 | 137 | -20 | 7 | 20 | -13 | -17.8 |
| Mine | No odds | 1 | 60 | 137 | +0 | 20 | 20 | -0 | -0.7 |
| Mine | All fights | 5 | 69 | 165 | -12 | 8 | 24 | -16 | -23.4 |
| Opponent | No odds | 2 | 276 | 60 | +152 | 152 | 108 | +44 | +15.9 |
| Opponent | All fights | 2 | 276 | 60 | +152 | 152 | 108 | +44 | +15.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p16 | move | 14 | 2 (14%) | 1 (7%) | 3 (21%) | 9 (64%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

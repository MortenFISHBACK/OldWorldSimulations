# Doctrine scorecard: cora-bb45c30-p6

### Scorecard: cora-bb45c30-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 608 |
| L0913 | 1 | 1 | Opponent | no | 5 | - | 1 | 1 | 2 | 0 | 0 | 540 |
| L0930 | 6 | 1 | Mine | no | 0 | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Opponent | no | 15 | 5 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 5 | 6 | 1 | 0 | 0 | 0 | 0 | 465 |
| L1021 | 1 | 1 | Opponent | no | 2 | - | 0 | 6 | 1 | 0 | 0 | 565 |
| **Average** | | | Mine | 0% | 3.7 | 6.0 | 0.7 | 1.3 | 0.0 | 0.0 | 0.0 | 357.7 |
| **Average** | | | Opponent | 0% | 7.3 | 5.0 | 0.3 | 3.0 | 1.0 | 0.0 | 0.0 | 368.3 |

### KPIs: cora-bb45c30-p6

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 85% (11 of 13) | 0% (0 of 11) | 46% (11 of 24) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 33% (16 of 48) | 0% (0 of 12) | 27% (16 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 34% (16 of 47) | 0% (0 of 10) | 28% (16 of 57) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 54% (7 of 13) | 54% (7 of 13) |
| Points that never fought | lower | 86% (5148 of 5997) | 92% (5518 of 5999) | 89% (10666 of 11996) |
|   infantry points that never fought | lower | 83% (1316 of 1591) | 86% (1430 of 1660) | 84% (2746 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (19 of 34) | 83% (19 of 23) | 67% (38 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 50% (1 of 2); 2.0 uses a game | 75% (3 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (3363 of 5667) | 86% (4447 of 5150) | 72% (7810 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (56%) | 3.3 (83%) | 9.3 (64%) |
| MARCHED: its unit marched | 4.0 (38%) | 0.0 (0%) | 4.0 (27%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.0 (0%) | 0.7 (17%) | 0.7 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 4.3 | 1.7 | 5.3 | 0.0 | 0.3 |
| not cast | 0.7 | 3.3 | 0.3 | 14.7 | 2.0 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (100%) | 0.0 (0%) | 9.3 (64%) | 0.7 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (27%) | 1.0 (50%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.3 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (100%) | 0.0 (0%) | 0.3 (100%) | 0.7 (5%) | 0.0 (0%) | 2.0 (10%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 100% (5 of 5) | 100% (5 of 5) |
| the unit moved after it | - | 0% (0 of 5) | 0% (0 of 5) |
| it charged on its next turn | - | 0% (0 of 5) | 0% (0 of 5) |
| the enemy charged it first | - | 0% (0 of 5) | 0% (0 of 5) |
| it fought by the end of its next turn | - | 0% (0 of 5) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 5) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (5 of 5) | 100% (5 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (84 of 127) | 59% (27 of 46) | 64% (111 of 173) |
|   character | 100% (5 of 5) | 17% (2 of 12) | 41% (7 of 17) |
|   chariot | 100% (18 of 18) | 62% (5 of 8) | 88% (23 of 26) |
|   infantry | 49% (25 of 51) | 68% (13 of 19) | 54% (38 of 70) |
|   monster | 20% (2 of 10) | - | 20% (2 of 10) |
|   war machine | 79% (34 of 43) | 100% (7 of 7) | 82% (41 of 50) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (21%) | 0.7 (11%) | 3.7 (18%) |
| MOVED: a war machine that moved | 2.0 (14%) | 0.0 (0%) | 2.0 (10%) |
| NO TARGET IN RANGE | 7.0 (49%) | 4.0 (63%) | 11.0 (53%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (12%) | 1.7 (26%) | 3.3 (16%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 2.7 | 0.7 | 75% | 8.7 pts | 23 pts |
| chariot | 7.7 | 5.3 | 65% | 15.5 pts | 119 pts |
| infantry | 16.7 | 6.3 | 68% | 6.0 pts | 99 pts |
| monster | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 14.0 | 14.7 | 60% | 51.8 pts | 725 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 1.0 | 1.0 |
| Charges that made contact a game | 0.3 | 0.3 | 0.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.40 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.00 contact (19 units) | 0.13 declared, 0.04 contact (23 units) | 0.10 declared, 0.02 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Character in a unit | 86% (6 of 7) | 100% (2 of 2) | - | 89% (8 of 9) |
| Character on its own | - | 50% (2 of 4) | 100% (4 of 4) | 75% (6 of 8) |
| Chariot | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Infantry | 50% (7 of 14) | 75% (3 of 4) | - | 56% (10 of 18) |
| Monster | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 38% (3 of 8) | - | - | 38% (3 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 33% (8 of 24) | 97% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (2 of 2); on the table 100% | 33% (8 of 24) | 63% | 40% (4 of 10) | 100% (2 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 88% | 62% (5 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | - | 0% (0 of 6) | 87% | 89% (8 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | - | 100% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p6, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 100% (1) | 100% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cora-bb45c30-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 33% (1 of 3) | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 18% (11 of 60) | 81% (13 of 16) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 4) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 10) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 50% (2 of 4) | 0% (0 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.0 |
| Movement | Points that never moved of their own | 357.7 | 368.3 |
| Movement | Fights charged into per game | 0.3 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 1, net +41 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 1, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.7 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (23 of 50) | 62% (15 of 24) |
| Shooting | Points destroyed by shooting units | 147.3 | 110.7 |
| Shooting | War machine shots | 11.3 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 82% (28 of 34) | 57% (4 of 7) |
| Shooting | Points destroyed by war machines | 544.7 | 0.0 |
| Magic | Magic missiles cast | 3.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (4 of 10) | - |
| Magic | Wounds caused by magic missiles | 8.3 | 5.0 |
| Magic | Points destroyed by magic (all spells) | 30.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.3 / 0.0 / 0.0 | 2.7 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 0.0 |
| Combat | Points run down | 21.7 | 75.7 |
| Combat | Net points per charged fight, damage counted | +41 | -4 |
| Combat | Net per 100 charger points, damage counted | +20.0 | -1.6 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +41 | +0 |
| Combat | Net points per supported fight / lone fight | - / +41 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 0 of 1 |
| Game | Points lost | 262.7 | 713.0 |
| Game | VP from objectives | 793.3 | 1073.3 |
| Game | Lone holders (player turns) | 3.7 | 7.3 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +272 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 976
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +25.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 20.3 | +91.8 | 0.0 | 0.0 | 18.3 | +171.8 | 0.0 | 694.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.2 | 0.0 | 0.0 | 1.0 | +3.9 | 0.0 | 159.7 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 476.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 11.0 | +1100.1 | 2446.0 | 166.7 | 2.3 | +63.9 | 83.3 | 23.3 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.7 | +23.1 | 367.7 | 0.0 | 0.7 | +11.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.7 | +0.0 | 0.0 | 266.7 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +2.1 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -2.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.0 | -366.8 | 0.0 | 0.0 | 31.7 | -2882.9 | 0.0 | 2457.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 75.7 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 30.7 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +252.6 | 266.7 | 266.7 |
| COVER ONCE | 10.7 | -1152.7 | 0.0 | 159.0 | 4.3 | -222.7 | 0.0 | 380.7 |
| DEFENSIVE ARMY | 3.3 | +0.0 | 638.7 | 69.3 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.1 | 75.7 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 0.0 | 7.0 | +37.9 | 0.0 | 23.3 |
| EDGE GIVE GROUND | 0.3 | +0.6 | 13.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +8.0 | 0.0 | 0.0 | 0.3 | +1.2 | 75.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 13.7 | 0.0 | 0.7 | +0.0 | 75.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 25.3 | +297.0 | 0.0 | 638.3 |
| FEATURE BUFFS | 2.0 | +37.3 | 0.0 | 0.0 | 2.0 | +10.8 | 0.0 | 61.3 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 104.3 | +11059.7 | 6952.0 | 662.0 | 98.3 | +4550.9 | 378.0 | 2953.7 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 515.7 |
| FOUR ROUNDS | 1.0 | +35.3 | 13.7 | 0.0 | 1.0 | +15.0 | 151.3 | 0.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +33.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 10.3 | +1684.3 | 0.0 | 0.0 | 16.0 | +1794.7 | 0.0 | 0.0 |
| GUN FIGURES | 3.0 | +8.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 21.7 |
| GUN MASK | 4.0 | +90.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 1043.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +8.2 | 75.7 | 0.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 74.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.3 | -12.7 | 0.0 | 0.0 | 7.3 | -183.4 | 0.0 | 1228.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 858.3 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 75.7 | 5.3 | +0.0 | 0.0 | 294.7 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 108.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 38.3 | +888.9 | 0.0 | 108.0 | 77.7 | +6211.8 | 0.0 | 2737.3 |
| HIS SHOTS BY HIS RUN | 26.3 | +510.2 | 0.0 | 0.0 | 75.0 | +2623.0 | 0.0 | 2682.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +5.6 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 20.0 | +0.0 | 0.0 | 0.0 | 30.0 | +0.0 | 0.0 | 211.3 |
| HOLDER ASSIGNMENT | 13.7 | +1340.7 | 0.0 | 0.0 | 16.3 | +1568.3 | 0.0 | 75.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -31.5 | 13.7 | 0.0 | 0.3 | -7.4 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 14.0 | -292.3 | 0.0 | 335.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +142.3 | 151.3 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +80.6 | 75.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 34.7 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +0.0 | 13.7 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.3 | +12.5 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.3 | +102.7 | 0.0 | 0.0 | 2.3 | +1.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +155.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +98.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 3.3 | -95.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 7.0 | +214.4 | 0.0 | 54.0 | 0.7 | +1.1 | 0.0 | 133.3 |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.0 | +171.1 | 0.0 | 54.0 | 2.3 | +60.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 14.3 | +286.7 | 0.0 | 54.0 | 4.3 | +28.8 | 0.0 | 266.7 |
| MOVE ORDER | 2.0 | +0.0 | 75.7 | 0.0 | 2.3 | +0.0 | 30.7 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 266.7 |
| MOVE TO CHARGE COMPUTED | 0.3 | +23.0 | 0.0 | 75.7 | 3.3 | +276.2 | 0.0 | 294.7 |
| NEARER NOT NEEDED | 12.3 | +562.0 | 0.0 | 0.0 | 10.3 | +441.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.3 | +23.0 | 0.0 | 75.7 | 3.0 | +253.7 | 0.0 | 294.7 |
| NEXT OBJECTIVE NEARER | 0.7 | -27.1 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 0.7 | -12.3 | 13.7 | 0.0 | 1.0 | -58.1 | 151.3 | 0.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -154.5 | 0.0 | 41.7 | 3.7 | -86.8 | 0.0 | 169.0 |
| OGRE LOADER SECOND SHOT | 2.3 | +99.7 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -97.9 | 0.0 | 54.0 | 4.0 | -110.3 | 0.0 | 600.0 |
| ONE OBJECTIVE FORMULA | 5.0 | +23.3 | 0.0 | 0.0 | 7.3 | +28.3 | 0.0 | 75.0 |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +2.8 | 61.3 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +27.9 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +6.2 | 75.7 | 0.0 |
| PATHS CROSS | 0.3 | -2.4 | 0.0 | 75.7 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +21.1 | 0.0 | 0.0 |
| PLAN RESULT | 45.3 | +2449.2 | 2698.3 | 453.7 | 45.7 | +259.7 | 106.3 | 1442.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 147.3 |
| PROMISE BY ITS OWN SUM | 6.0 | -240.7 | 0.0 | 0.0 | 4.3 | -87.2 | 0.0 | 0.0 |
| QUARTER ODDS | 16.0 | +1487.8 | 2805.7 | 0.0 | 22.0 | +2102.2 | 30.0 | 1357.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.3 | +57.9 | 0.0 | 96.7 |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +104.9 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 13.7 |
| REDIRECT WEIGHED | 0.3 | +4.3 | 21.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | - | - | - | - | 1.0 | -48.8 | 151.3 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 0.7 | -0.4 | 13.7 | 0.0 | 1.0 | -19.5 | 151.3 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -114.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -84.0 | 0.0 | 0.0 | 0.7 | -9.3 | 0.0 | 294.7 |
| SET UP BY THE SET | 1.3 | +84.0 | 0.0 | 0.0 | 0.7 | +9.0 | 0.0 | 294.7 |
| SET UP TOGETHER | 1.3 | +12.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 19.7 | +0.0 | 0.0 | 201.3 | 6.3 | +0.0 | 0.0 | 45.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +483.8 | 589.3 | 0.0 | 1.3 | +44.7 | 0.0 | 43.3 |
| SHOT OR CHARGE | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 9.0 | -76.9 | 0.0 | 0.0 | 48.3 | -869.3 | 0.0 | 2775.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 31.7 | +2271.6 | 0.0 | 201.3 | 11.0 | +385.2 | 0.0 | 497.7 |
| SPELL WORTH | - | - | - | - | 3.3 | +81.0 | 626.7 | 626.7 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 280.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -3.1 | 75.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 0.0 | 638.7 |
| STANDS STILL | 58.3 | +0.0 | 6938.3 | 478.3 | 34.7 | +0.0 | 226.7 | 1696.3 |
| STAY WORTH | 39.7 | +1061.2 | 3524.3 | 401.3 | 15.0 | +169.8 | 226.7 | 358.3 |
| SUPPORT ADDS | 4.0 | +634.3 | 0.0 | 0.0 | 1.3 | +73.2 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.0 | +634.3 | 0.0 | 0.0 | 1.3 | +73.2 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 75.7 | 1.7 | +0.0 | 0.0 | 30.7 |
| THE ROW IN ITS ORDER | 5.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 13.7 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.3 | +0.0 | 0.0 | 331.0 | 47.3 | +0.0 | 0.0 | 1417.7 |
| TIME ON OUR SIDE | 42.3 | +606.6 | 319.3 | 255.0 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 2.7 | +0.0 | 816.7 | 0.0 | - | - | - | - |
| WHO GETS IN | - | - | - | - | 0.7 | +142.3 | 151.3 | 0.0 |
| WHOLE FIGHT DANGER | 4.7 | -264.6 | 0.0 | 0.0 | 1.7 | -45.4 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.3 | +5.2 | 0.0 | 0.0 | 2.0 | +56.0 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 348 | 333 | 90 | 30.00 | +1383 | +15.4 |
| HOLDER ASSIGNMENT | 90 | 90 | 85 | 28.33 | +5794 | +68.2 |
| ARMY TABLE | 116 | 116 | 83 | 27.67 | +345 | +4.2 |
| HIS SHOTS BY HIS RUN | 304 | 293 | 77 | 25.67 | +994 | +12.9 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| GOAL WALK | 79 | 78 | 32 | 10.67 | +3421 | +106.9 |
| SHOT RISK POINTS | 172 | 167 | 27 | 9.00 | +1190 | +44.1 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -724 | -31.5 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 13 | 4.33 | -984 | -75.7 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 11 | 3.67 | +347 | +31.5 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 131 | 126 | 9 | 3.00 | +445 | +49.5 |
| IDLE COST | 42 | 36 | 8 | 2.67 | +86 | +10.8 |
| SHOTS IN THE MOVE | 128 | 102 | 8 | 2.67 | +327 | +40.9 |
| COVER ONCE | 45 | 32 | 7 | 2.33 | +241 | +34.5 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +299 | +42.7 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 7 | 2.33 | +174 | +24.8 |
| SUPPORT ADDS | 16 | 14 | 7 | 2.33 | +403 | +57.6 |
| SUPPORT WORKED OUT | 16 | 14 | 7 | 2.33 | +403 | +57.6 |
| TIME ON OUR SIDE | 127 | 96 | 7 | 2.33 | +12 | +1.7 |
| CAST JOB | 7 | 7 | 6 | 2.00 | +36 | +5.9 |
| MAX FOR POSITIONING | 23 | 21 | 6 | 2.00 | +80 | +13.4 |
| QUARTER ODDS | 114 | 110 | 6 | 2.00 | +421 | +70.1 |
| FIVE ACTION | 608 | 592 | 5 | 1.67 | +300 | +60.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +466 | +93.1 |
| MARCH CHECK | 5 | 5 | 5 | 1.67 | +114 | +22.9 |
| CANNON PLANNED TARGET | 40 | 40 | 4 | 1.33 | +165 | +41.2 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| NEARER NOT NEEDED | 68 | 62 | 4 | 1.33 | +143 | +35.7 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| STAY WORTH | 164 | 153 | 4 | 1.33 | +42 | +10.4 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 11 | 9 | 3 | 1.00 | +74 | +24.6 |
| NEXT CHARGE BY LIST | 10 | 9 | 3 | 1.00 | +74 | +24.6 |
| SHOTS AFTER THE MOVES | 23 | 23 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 2 | 0.67 | -64 | -31.9 |
| FALLS SHORT | 76 | 64 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 12 | 12 | 2 | 0.67 | +21 | +10.5 |
| GUN MASK | 12 | 12 | 2 | 0.67 | +15 | +7.3 |
| HIS MOVE AND SHOT | 29 | 29 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +427 | +213.4 |
| MANOEUVRE | 14 | 14 | 2 | 0.67 | +330 | +164.9 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +34 | +16.9 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +12 | +6.0 |
| SET UP BY THE SET | 6 | 6 | 2 | 0.67 | +21 | +10.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -68 | -34.1 |
| THE ROW IN ITS ORDER | 30 | 2 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 8 | 8 | 2 | 0.67 | -71 | -35.6 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +427 | +213.4 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +75 | +75.4 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -7 | -6.6 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -212 | -211.8 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOUR ROUNDS | 6 | 6 | 1 | 0.33 | +16 | +15.9 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +101 | +101.2 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +242 | +241.8 |
| MISSILES IN THE MOVE | 37 | 23 | 1 | 0.33 | +4 | +3.7 |
| ONE OBJECTIVE FORMULA | 37 | 28 | 1 | 0.33 | +25 | +24.9 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +36 | +36.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -7 | -7.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +63 | +63.3 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +9.1 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 7 | 7 | 1 | 0.33 | +14 | +14.3 |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 24 | 24 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 45 | 41 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 10 | 10 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 50 | 50 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 38 | 34 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 39 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 150 | 150 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 56 | 37 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 23 | 11 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | not checked | - | - | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 273 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 5 | 3 | 0 | 0.00 | - | - |
| RISK BY ARC | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 78 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 45 | 38 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 279 | 269 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 287 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 19 | 19 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 3.00 | 33.6 |
| ARMY TABLE | rule | 3.67 | 2.00 | 36.9 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 1.33 | 75.7 |
| HOLDER ASSIGNMENT | rule | 1.33 | 0.33 | 16.2 |
| CHARGE NOW FIRST | rule | 0.67 | - | 31.9 |
| NO REASON | gate | - | 0.67 | 9.4 |
| SUPPORT NARROWED | rule | 0.67 | - | 34.1 |
| WAR ENGINE JOBS | rule | 0.67 | - | 35.6 |
| CHAFF PASSED | rule | - | 0.33 | 6.6 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 211.8 |
| PATHS CROSS | rule | 0.33 | - | 7.2 |

### Plans: cora-bb45c30-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | join | 0.3 | 100% | 4 | 0 | 0% |
| Mine | move | 28.0 | 99% | 2475 | 0 | 0% |
| Mine | shoot | 17.0 | 59% | 2059 | 2449 | 119% |
| Opponent | charge | 1.0 | 67% | 118 | 159 | 135% |
| Opponent | move | 39.7 | 95% | 2532 | 0 | 0% |
| Opponent | shoot | 4.0 | 42% | 148 | 100 | 68% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 40% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 39 (10) | 39 | 0 | 3 | 40% | 3.5 | 46 (6) | 25 (4) | - | 12 (6) | 94 (4) |
| Mine | Clean-up | 3 | 33 (3) | 0 | 33 | 0 | 67% | 5.0 | 0 (1) | 50 (2) | - | 33 (3) | - |
| Mine | Fast Hammer | 3 | 32 (3) | 0 | 32 | 35 | 33% | 1.0 | 46 (2) | - | 0 (1) | 32 (3) | - |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 16 | 50% | 1.7 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Shooter | 6 | 144 (6) | 0 | 144 | 17 | 0% | 1.5 | 0 (1) | 231 (3) | 87 (2) | 144 (6) | - |
| Mine | War machine | 8 | 151 (8) | 151 | 0 | 23 | 0% | 1.6 | 125 (3) | 128 (3) | 208 (2) | 383 (1) | 121 (7) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Opponent | Chaff | 2 | 240 (2) | 0 | 240 | 0 | 100% | - | 429 (1) | 0 (1) | - | 429 (1) | 0 (1) |
| Opponent | Character | 9 | 0 (9) | 0 | 0 | 70 | 56% | 2.2 | 0 (1) | 0 (5) | 0 (3) | 0 (7) | 0 (2) |
| Opponent | Clean-up | 3 | 85 (3) | 0 | 85 | 8 | 33% | 4.5 | 0 (1) | 155 (2) | - | 155 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 97 (6) | 23 | 73 | 0 | 83% | 1.0 | - | 95 (4) | 98 (2) | 97 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 24 (4) | 24 | 0 | 22 | 25% | 2.7 | - | 0 (2) | 51 (2) | 24 (4) | - |
| Opponent | Holder | 4 | 8 (4) | 0 | 8 | 23 | 100% | - | - | 11 (3) | 0 (1) | 15 (2) | 0 (2) |
| Opponent | Shooter | 4 | 10 (4) | 10 | 0 | 28 | 25% | 2.3 | 0 (1) | 0 (1) | 13 (2) | 11 (3) | 0 (1) |
| Opponent | War machine | 2 | 89 (2) | 89 | 0 | 50 | 0% | 1.0 | - | - | 89 (2) | 0 (1) | 179 (1) |

### Charged fights: cora-bb45c30-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 696 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 777 | 41 | 1.0 | 1.0 | 41 | 0 | +41 | 0 of 1 | 1 of 1 | - | +41 |
| **Mine** | all armies | 3 | 723 | 14 | 0.3 | 1.0 | 41 | 0 | +41 | 0 of 1 | 1 of 1 | - | +41 |
| Opponent | High Elf Realms | 1 | 170 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Skaven | 1 | 162 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 111 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |

### Effective charges: cora-bb45c30-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 1 | 0 | 0 | 0 | 0 | 1 (net +41) | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 205 | 41 | +41 | 41 | 0 | +41 | +20.0 |
| Mine | All fights | 1 | 205 | 41 | +41 | 41 | 0 | +41 | +20.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 230 | 104 | +0 | 24 | 28 | -4 | -1.6 |
| Opponent | All fights | 1 | 230 | 104 | +0 | 24 | 28 | -4 | -1.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p6 | move | 15 | 0 (0%) | 0 (0%) | 1 (7%) | 14 (93%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

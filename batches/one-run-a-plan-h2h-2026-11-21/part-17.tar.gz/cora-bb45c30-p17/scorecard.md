# Doctrine scorecard: cora-bb45c30-p17

### Scorecard: cora-bb45c30-p17

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 125 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 0 | 5 | 0 | 0 | 0 | 555 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 551 |
| L0810 | 6 | 1 | Opponent | no | 13 | 2 | 0 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 471 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 6 | 0 | 0 | 0 | 60 |
| **Average** | | | Mine | 0% | 3.0 | 2.0 | 1.7 | 1.3 | 0.0 | 0.0 | 0.0 | 382.3 |
| **Average** | | | Opponent | 67% | 6.5 | 2.0 | 0.3 | 3.7 | 0.3 | 0.0 | 0.0 | 315.0 |

### KPIs: cora-bb45c30-p17

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 88% (14 of 16) | 0% (0 of 14) | 47% (14 of 30) |
| Winner chose to follow up after the loser gave ground |  | 50% (2 of 4); on the table 50% | 78% (7 of 9); on the table 100% | 69% (9 of 13); on the table 85% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 60% | 78% (7 of 9); on the table 100% | 71% (10 of 14); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 83% (5 of 6) | 39% (14 of 36) | 45% (19 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (5 of 5) | 50% (14 of 28) | 58% (19 of 33) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (4 of 6) | 67% (4 of 6) |
| Points that never fought | lower | 67% (4010 of 5999) | 79% (4749 of 5998) | 73% (8759 of 11997) |
|   infantry points that never fought | lower | 100% (968 of 968) | 76% (844 of 1113) | 87% (1812 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (20 of 30) | 60% (15 of 25) | 64% (35 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 4.0 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 50% (1 of 2); 0.3 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (3293 of 5378) | 64% (3293 of 5181) | 62% (6586 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (41%) | 3.0 (39%) |
| MARCHED: its unit marched | 0.0 (0%) | 1.0 (14%) | 1.0 (13%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.7 (9%) | 0.7 (9%) |
| IN COMBAT: engaged in combat | 0.3 (100%) | 0.0 (0%) | 0.3 (4%) |
| GONE: slain | 0.0 (0%) | 2.7 (36%) | 2.7 (35%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 1.7 | 4.3 | 6.3 | 0.7 | 0.3 |
| not cast | 4.3 | 0.3 | 1.7 | 7.7 | 3.3 | 27.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (8%) | 0.3 (100%) | 0.3 (20%) | 3.0 (39%) | 1.3 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (13%) | 0.7 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (31%) | 0.0 (0%) | 1.3 (80%) | 2.7 (35%) | 1.3 (40%) | 6.0 (22%) |
| STUPIDITY: Stupidity | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.7 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 4.3 a game | 2.2 a game |
| stood (cast and not dispelled) | - | 62% (8 of 13) | 62% (8 of 13) |
| the unit moved after it | - | 50% (4 of 8) | 50% (4 of 8) |
| it charged on its next turn | - | 0% (0 of 8) | 0% (0 of 8) |
| the enemy charged it first | - | 0% (0 of 8) | 0% (0 of 8) |
| it fought by the end of its next turn | - | 0% (0 of 8) | 0% (0 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 8) | 0% (0 of 8) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (8 of 8) | 100% (8 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (61 of 92) | 65% (17 of 26) | 66% (78 of 118) |
|   cavalry | 82% (18 of 22) | - | 82% (18 of 22) |
|   chariot | 73% (8 of 11) | 67% (6 of 9) | 70% (14 of 20) |
|   infantry | 50% (6 of 12) | 44% (4 of 9) | 48% (10 of 21) |
|   war machine | 62% (29 of 47) | 88% (7 of 8) | 65% (36 of 55) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (19%) | 0.7 (22%) | 2.7 (20%) |
| CHARGED: it charged | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (11%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.3 (13%) | 0.0 (0%) | 1.3 (10%) |
| NO TARGET IN RANGE | 0.3 (3%) | 1.3 (44%) | 1.7 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 2.0 (19%) | 0.3 (11%) | 2.3 (18%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (19%) | 0.0 (0%) | 2.0 (15%) |
| SHELTERED: the target was sheltered | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |
| OTHER BAR | 0.7 (6%) | 0.3 (11%) | 1.0 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.0 | 4.0 | 78% | 8.0 pts | 96 pts |
| chariot | 4.7 | 0.3 | 93% | 1.9 pts | 9 pts |
| infantry | 3.3 | 1.3 | 70% | 7.7 pts | 26 pts |
| war machine | 12.3 | 15.7 | 54% | 48.0 pts | 592 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.3 | 2.2 |
| Charges that made contact a game | 1.7 | 1.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.40 declared, 0.00 contact (5 units) | 0.50 declared, 0.17 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.23 declared, 0.18 contact (22 units) | 0.22 declared, 0.17 contact (23 units) | 0.22 declared, 0.18 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 22% (2 of 9) | 33% (1 of 3) | 100% (1 of 1) | 31% (4 of 13) |
| Character in a unit | 100% (9 of 9) | - | - | 100% (9 of 9) |
| Character on its own | 50% (1 of 2) | 50% (1 of 2) | 50% (2 of 4) | 50% (4 of 8) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 33% (1 of 3) | 100% (1 of 1) | 50% (1 of 2) | 50% (3 of 6) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 69% (9 of 13) | - | - | 69% (9 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 60% (3 of 5); on the table 60% | 83% (5 of 6) | 67% | 67% (20 of 30) | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game | 33% (1 of 3); 0.3 uses a game |
| Grand Cathay | 1 | - | 46% (11 of 24) | 92% | 30% (3 of 10) | 100% (2 of 2); 9.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 0% (0 of 6) | 67% | 89% (8 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 78% (7 of 9); on the table 100% | 50% (3 of 6) | 79% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p17, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 60% (3) | 50% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.67 | 0.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cora-bb45c30-p17

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (3 of 6) | 57% (4 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 24% (11 of 45) | 31% (4 of 13) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (2 of 4) | - |
| Strategy | Joined characters whose unit fought | 29% (2 of 7) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 29% (2 of 7) | 11% (1 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.7 |
| Movement | Points that never moved of their own | 382.3 | 315.0 |
| Movement | Fights charged into per game | 1.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +0 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net +48 | 1 of 2, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 32% (11 of 34) | 50% (5 of 10) |
| Shooting | Points destroyed by shooting units | 248.0 | 0.0 |
| Shooting | War machine shots | 9.7 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (14 of 29) | 38% (3 of 8) |
| Shooting | Points destroyed by war machines | 216.7 | 85.0 |
| Magic | Magic missiles cast | 1.7 | 3.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (2 of 5) | 9% (1 of 11) |
| Magic | Wounds caused by magic missiles | 4.3 | 6.7 |
| Magic | Wounds caused by other spells | 3.0 | - |
| Magic | Points destroyed by magic (all spells) | 83.7 | 66.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 1.3 / 0.3 / 0.0 | 3.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 70.0 | 131.7 |
| Combat | Points run down | 0.0 | 41.7 |
| Combat | Net points per charged fight, damage counted | +51 | +198 |
| Combat | Net per 100 charger points, damage counted | +22.9 | +65.0 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +60 | +198 |
| Combat | Net points per supported fight / lone fight | - / +60 | +0 / +395 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 1 of 2 |
| Game | Points lost | 370.0 | 638.0 |
| Game | VP from objectives | 703.3 | 706.7 |
| Game | Lone holders (player turns) | 3.0 | 6.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +298 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1008
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p17

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +77.3 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +21.1 | 0.0 | 0.0 | 0.3 | +9.0 | 0.0 | 0.0 |
| ARMY TABLE | 13.3 | +315.1 | 0.0 | 0.0 | 21.3 | +358.1 | 0.0 | 397.7 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 126.7 | 0.3 | +0.0 | 0.0 | 55.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 346.3 | 41.7 | 0.3 | +0.0 | 43.3 | 0.0 |
| CANNON PLANNED TARGET | 8.3 | +282.7 | 1512.7 | 173.3 | 2.3 | +142.1 | 170.0 | 110.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +38.6 | 74.7 | 0.0 | 4.0 | +86.6 | 223.3 | 144.7 |
| CASTS AFTER FRIENDS | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +8.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +95.5 | 0.0 | 30.0 |
| CHAFF PASSED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.0 | -412.5 | 0.0 | 86.7 | 20.3 | -1333.9 | 0.0 | 1273.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 85.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 289.3 |
| CONVEYANCE SEARCH | - | - | - | - | 4.3 | +396.2 | 434.0 | 289.3 |
| COVER ONCE | 4.3 | -177.0 | 0.0 | 133.3 | 10.0 | -683.9 | 0.0 | 346.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.4 | 41.7 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 48.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +4.3 | 13.7 | 0.0 | 2.0 | -6.1 | 126.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +10.1 | 13.7 | 0.0 | 2.3 | +0.2 | 126.7 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 2.0 | +59.0 | 0.0 | 0.0 | 23.3 | +310.6 | 0.0 | 720.0 |
| FEATURE BUFFS | 0.3 | +1.9 | 0.0 | 0.0 | 3.3 | +32.8 | 0.0 | 27.3 |
| FIGHT TO THE END | 1.0 | +10.4 | 0.0 | 0.0 | 1.3 | +106.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 41.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 96.3 | +5855.0 | 3920.7 | 653.3 | 87.0 | +4397.2 | 690.0 | 1961.0 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 21.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.7 | +255.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +115.8 | 62.0 | 0.0 | 2.3 | +221.1 | 126.7 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 86.7 |
| FRIEND CHARGES FIRST | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -64.2 | 0.0 | 0.0 | 1.3 | -63.3 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -1.9 | 41.7 | 0.0 |
| GOAL WALK | 5.3 | +529.9 | 0.0 | 0.0 | 15.0 | +1074.6 | 0.0 | 289.3 |
| GUN FIGURES | 3.0 | +46.6 | 0.0 | 0.0 | 1.3 | +2.2 | 0.0 | 21.7 |
| GUN MASK | 4.0 | +104.0 | 0.0 | 0.0 | 0.7 | +36.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 86.7 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 86.7 | 12.7 | +0.0 | 0.0 | 242.0 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 109.3 | 3.7 | +0.0 | 0.0 | 43.3 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -35.1 | 0.0 | 0.0 | 2.0 | -73.9 | 0.0 | 158.3 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 43.3 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.7 | +1116.6 | 0.0 | 220.0 | 51.3 | +2988.5 | 0.0 | 828.0 |
| HIS SHOTS BY HIS RUN | 23.0 | +435.5 | 0.0 | 133.3 | 52.3 | +2081.4 | 0.0 | 1273.0 |
| HIS TURN DENIED | - | - | - | - | 2.3 | +73.3 | 126.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 0.0 | 24.3 | +0.0 | 0.0 | 54.7 |
| HOLDER ASSIGNMENT | 9.7 | +1089.2 | 0.0 | 0.0 | 12.7 | +914.4 | 0.0 | 13.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -31.8 | 62.0 | 0.0 | 2.3 | -58.0 | 126.7 | 0.0 |
| IDLE COST | 1.7 | -12.5 | 0.0 | 0.0 | 12.7 | -147.6 | 0.0 | 541.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | -75.9 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 37.3 | 530.0 | 13.0 | +0.0 | 573.3 | 147.3 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +1.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -0.4 | 62.0 | 0.0 | 0.3 | +0.0 | 41.7 | 0.0 |
| MANOEUVRE | 2.3 | -3.2 | 0.0 | 0.0 | 3.3 | +29.1 | 0.0 | 13.7 |
| MARCH CHECK | - | - | - | - | 1.3 | +29.9 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 1.0 | +56.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.0 | +138.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.3 | +0.9 | 0.0 | 0.0 | 4.0 | +63.7 | 0.0 | 289.3 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 48.3 |
| MISSILES IN THE MOVE | 1.7 | +61.9 | 0.0 | 0.0 | 8.7 | +183.9 | 0.0 | 144.7 |
| MISSILES NEXT TURN | 1.3 | +28.9 | 0.0 | 0.0 | 9.7 | +114.9 | 0.0 | 469.3 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 21.7 | 195.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.7 | +355.0 | 0.0 | 0.0 | 4.0 | +612.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.0 | +368.0 | 0.0 | 54.7 | 10.0 | +466.9 | 0.0 | 13.7 |
| NEXT CHARGE BY LIST | 3.7 | +407.5 | 0.0 | 0.0 | 4.0 | +543.5 | 90.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -81.0 | 62.0 | 0.0 | 1.7 | -60.0 | 126.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.3 | -213.6 | 0.0 | 41.7 | 2.3 | -151.2 | 0.0 | 21.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 41.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -66.3 | 0.0 | 0.0 | 5.0 | -103.4 | 0.0 | 289.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +10.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.7 | +49.0 | 0.0 | 0.0 | 9.7 | -105.2 | 0.0 | 13.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -71.9 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +5.0 | 48.3 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +7.4 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +24.8 | 0.0 | 180.0 |
| PIVOT GUARDS FLANK | 0.3 | -5.1 | 0.0 | 0.0 | 0.3 | -2.8 | 0.0 | 0.0 |
| PLAN RESULT | 42.3 | +1767.4 | 821.3 | 435.0 | 43.7 | +551.8 | 83.3 | 768.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -160.3 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | -6.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -8.3 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -1.0 | 96.7 | 0.0 | - | - | - | - |
| QUARTER ODDS | 22.7 | +1565.1 | 164.7 | 0.0 | 15.0 | +1551.2 | 0.0 | 43.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +51.0 | 0.0 | 285.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +43.7 | 0.0 | 0.0 | 2.7 | +213.5 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 0.3 | -4.0 | 0.0 | 0.0 | 0.7 | -17.3 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +21.2 | 62.0 | 0.0 | 2.3 | +25.6 | 126.7 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -4.0 | 43.3 | 0.0 |
| RUN DOWN | 1.7 | -27.7 | 62.0 | 0.0 | 1.3 | -1.4 | 126.7 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.7 | +39.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.3 | -99.3 | 0.0 | 85.0 |
| SET CREDITED ONCE | 1.0 | -24.7 | 0.0 | 0.0 | 0.3 | -15.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | +23.1 | 0.0 | 0.0 | 1.3 | -12.2 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 1.3 | +158.4 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.7 | +0.0 | 0.0 | 173.3 | 6.0 | +0.0 | 0.0 | 254.7 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +111.3 | 289.3 | 0.0 | 0.3 | +6.9 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -0.2 | 13.7 | 0.0 | 0.3 | -0.0 | 41.7 | 55.0 |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 0.0 |
| SHOT RISK POINTS | 15.3 | +162.6 | 0.0 | 133.3 | 40.7 | +25.9 | 0.0 | 1464.3 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 20.3 | +1138.4 | 0.0 | 228.0 | 7.0 | +322.1 | 0.0 | 110.0 |
| SPELL WORTH | 1.7 | +3.4 | 0.0 | 0.0 | 4.0 | +50.5 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 0.7 | +1.0 | 62.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 193.0 |
| STAND AND SHOOT | 0.3 | -2.0 | 48.3 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 62.0 | +0.0 | 3858.7 | 544.0 | 24.3 | +0.0 | 563.3 | 961.3 |
| STAY WORTH | 35.3 | +249.5 | 2591.3 | 179.7 | 8.7 | +73.9 | 340.0 | 378.3 |
| SUPPORT ADDS | 0.3 | +42.6 | 0.0 | 0.0 | 2.7 | +58.6 | 0.0 | 43.3 |
| SUPPORT WORKED OUT | 0.3 | +42.6 | 0.0 | 0.0 | 2.7 | +58.6 | 0.0 | 43.3 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 166.3 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 21.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 21.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.3 | +0.0 | 0.0 | 240.0 | 42.7 | +0.0 | 0.0 | 824.3 |
| TIED UP BY THE SUM | 1.3 | +123.7 | 62.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 41.7 | +447.8 | 27.3 | 90.7 | 3.3 | +37.1 | 0.0 | 0.0 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.0 | +42.1 | 43.3 | 0.0 |
| WHO HITS BACK | 0.3 | +29.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -272.8 | 0.0 | 86.7 | 2.7 | -209.9 | 0.0 | 13.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.0 | +26.1 | 0.0 | 0.0 | 3.7 | +97.6 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p17

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOTS BY HIS RUN | 226 | 225 | 72 | 24.00 | +1254 | +17.4 |
| ARMY TABLE | 104 | 104 | 71 | 23.67 | +1810 | +25.5 |
| HOLDER ASSIGNMENT | 67 | 67 | 62 | 20.67 | +4945 | +79.8 |
| LEGAL CHARGES ONLY | 55 | 55 | 55 | 18.33 | +0 | +0.0 |
| HIS SHOT LIST | 249 | 249 | 52 | 17.33 | +1076 | +20.7 |
| SHOT RISK POINTS | 168 | 168 | 44 | 14.67 | +1164 | +26.5 |
| FIVE ACTION | 550 | 549 | 42 | 14.00 | +2421 | +57.6 |
| TIME ON OUR SIDE | 135 | 122 | 28 | 9.33 | +108 | +3.8 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| GOAL WALK | 61 | 61 | 21 | 7.00 | +1670 | +79.5 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 23 | 22 | 18 | 6.00 | +866 | +48.1 |
| CAST JOB | 14 | 14 | 14 | 4.67 | +85 | +6.1 |
| NEXT CHARGE BY LIST | 23 | 22 | 14 | 4.67 | +627 | +44.8 |
| OFF BEST | 14 | 14 | 14 | 4.67 | -1095 | -78.2 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CHARGE LOSSES | 94 | 94 | 11 | 3.67 | +411 | +37.4 |
| QUARTER ODDS | 113 | 113 | 11 | 3.67 | +657 | +59.7 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| IDLE COST | 43 | 37 | 7 | 2.33 | +56 | +8.0 |
| COVER ONCE | 43 | 32 | 6 | 2.00 | +43 | +7.1 |
| FALLS SHORT | 76 | 61 | 6 | 2.00 | +90 | +15.1 |
| FOUR ROUNDS | 13 | 13 | 6 | 2.00 | +287 | +47.9 |
| PROMISE KNOWS THE FIGHT | 9 | 9 | 6 | 2.00 | -18 | -3.0 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 6 | 2.00 | +129 | +21.4 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +768 | +153.6 |
| MAX FOR POSITIONING | 13 | 13 | 5 | 1.67 | +14 | +2.8 |
| MISSILES IN THE MOVE | 31 | 20 | 5 | 1.67 | +114 | +22.8 |
| CHAFF IN THE MOVE | 8 | 7 | 4 | 1.33 | +10 | +2.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| MARCH CHECK | 4 | 4 | 4 | 1.33 | +54 | +13.5 |
| PROMISE BY ITS OWN SUM | 27 | 27 | 4 | 1.33 | -481 | -120.2 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 4 | 1.33 | +153 | +38.2 |
| RISK BY ARC | 13 | 13 | 4 | 1.33 | +96 | +24.1 |
| SHOTS IN THE MOVE | 82 | 66 | 4 | 1.33 | +379 | +94.8 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 10 | 10 | 3 | 1.00 | +12 | +3.8 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -228 | -75.9 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -170 | -56.6 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +28 | +9.5 |
| SHOTS AFTER THE MOVES | 23 | 23 | 3 | 1.00 | +0 | +0.0 |
| STAY WORTH | 132 | 125 | 3 | 1.00 | +24 | +8.1 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +110 | +36.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +232 | +116.0 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +90 | +45.2 |
| CANNON PLANNED TARGET | 32 | 32 | 2 | 0.67 | +26 | +13.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -174 | -86.8 |
| FIGHT TO THE END | 7 | 7 | 2 | 0.67 | +179 | +89.4 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 7 | 7 | 2 | 0.67 | +73 | +36.6 |
| NEARER NOT NEEDED | 57 | 54 | 2 | 0.67 | +32 | +16.2 |
| ONE OBJECTIVE FORMULA | 37 | 28 | 2 | 0.67 | +223 | +111.7 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -24 | -11.8 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -3 | -1.4 |
| SAFER THAN THE JOB | 2 | 2 | 2 | 0.67 | +117 | +58.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 2 | 0.67 | +10 | +5.2 |
| SET UP BY THE SET | 10 | 10 | 2 | 0.67 | +52 | +26.2 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT ADDS | 9 | 9 | 2 | 0.67 | +23 | +11.6 |
| SUPPORT WORKED OUT | 9 | 9 | 2 | 0.67 | +23 | +11.6 |
| THE ROW IN ITS ORDER | 10 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 16 | 16 | 2 | 0.67 | +13 | +6.3 |
| WOUNDS ON THE RANKS | 20 | 20 | 2 | 0.67 | +98 | +48.8 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -14 | -14.3 |
| GUN MASK | 14 | 14 | 1 | 0.33 | +7 | +6.7 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +35 | +34.8 |
| MANOEUVRE | 17 | 17 | 1 | 0.33 | +91 | +91.1 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -6 | -6.0 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE FIGHT FORMULA | 26 | 16 | 1 | 0.33 | +2 | +1.5 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +14 | +14.3 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -216 | -215.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +74 | +74.4 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +132 | +132.4 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +5 | +5.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +78 | +77.6 |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 13 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 11 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 17 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 13 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 13 | 13 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 53 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 12 | 12 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 22 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 120 | 120 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 13 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 33 | 22 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 10 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 258 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 9 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 65 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 30 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 259 | 259 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 255 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p17

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 2.33 | 78.2 |
| ARMY TABLE | rule | - | 2.33 | 80.6 |
| PROMISE KNOWS THE FIGHT | rule | - | 2.00 | 3.0 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | - | 120.2 |
| MARCH OF THE TABLE | rule | - | 1.00 | 56.6 |
| CHARGE NOW FIRST | rule | - | 0.67 | 86.8 |
| JOINT CHARGE NOW | rule | - | 0.67 | 120.9 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 11.8 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 1.4 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 14.3 |
| MARCH ODDS | rule | 0.33 | - | 6.0 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 215.6 |

### Plans: cora-bb45c30-p17

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 50% | 111 | 88 | 79% |
| Mine | move | 27.3 | 96% | 1536 | 0 | 0% |
| Mine | shoot | 13.0 | 64% | 957 | 1680 | 176% |
| Opponent | charge | 2.3 | 71% | 248 | 218 | 88% |
| Opponent | join | 2.7 | 100% | 100 | 0 | 0% |
| Opponent | move | 33.7 | 94% | 1601 | 0 | 0% |
| Opponent | shoot | 3.7 | 73% | 115 | 334 | 291% |
| Opponent | support | 1.3 | 50% | 11 | 0 | 0% |

### Battle groups: cora-bb45c30-p17

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p17

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 27 (12) | 27 | 0 | 0 | 67% | 3.0 | 0 (4) | 0 (4) | 49 (4) | 37 (7) | 0 (5) |
| Mine | Fast Hammer | 5 | 33 (5) | 7 | 26 | 0 | 40% | 2.3 | 19 (3) | 0 (1) | 88 (1) | 45 (3) | 17 (2) |
| Mine | Hammer | 4 | 28 (4) | 0 | 28 | 21 | 50% | 1.0 | 0 (1) | 40 (3) | - | 0 (3) | 97 (1) |
| Mine | Shooter | 5 | 118 (5) | 109 | 9 | 24 | 0% | 1.0 | 265 (1) | 12 (2) | 122 (2) | 118 (5) | - |
| Mine | War machine | 11 | 46 (11) | 46 | 0 | 46 | 9% | 1.6 | 102 (5) | 0 (6) | - | 0 (2) | 57 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 19 | 100% | - | 0 (3) | 0 (2) | - | 0 (5) | - |
| Opponent | Character | 11 | 12 (11) | 12 | 0 | 40 | 36% | 2.0 | 0 (3) | 0 (5) | 32 (3) | 14 (5) | 11 (6) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 6 | 82 (6) | 35 | 47 | 0 | 17% | 2.0 | 60 (3) | 116 (3) | - | 114 (4) | 46 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 45 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 0 (4) | 0 | 0 | 69 | 50% | 2.5 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Holder | 4 | 92 (4) | 0 | 92 | 42 | 50% | 3.5 | - | 27 (2) | 148 (2) | 120 (3) | 0 (1) |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 100 | 0% | 2.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 77 (2) | 77 | 0 | 50 | 0% | 1.0 | - | 77 (2) | - | 79 (1) | 76 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: cora-bb45c30-p17

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 548 | 101 | 1.7 | 1.0 | 60 | 0 | +60 | 0 of 5 | 5 of 5 | - | +60 |
| Opponent | Grand Cathay | 1 | 455 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 395 | 2.0 | 2.0 | 198 | 0 | +198 | 1 of 2 | 2 of 2 | +0 | +395 |
| **Opponent** | all armies | 3 | 152 | 132 | 0.7 | 2.0 | 198 | 0 | +198 | 1 of 2 | 2 of 2 | +0 | +395 |

### Effective charges: cora-bb45c30-p17

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 5 | 0 | 0 | 0 | 1 (net +157) | 1 (net +0) | 3 (net +48) | 0 | 0% (0 of 5) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 1 (net +395) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cora-bb45c30-p17

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 189 | 92 | +157 | 293 | 54 | +238 | +126.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 249 | 164 | +48 | 67 | 72 | -5 | -2.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 181 | 41 | +0 | 32 | 0 | +32 | +17.4 |
| Mine | All fights | 5 | 223 | 125 | +60 | 105 | 54 | +51 | +22.9 |
| Opponent | 76-89% | 1 | 186 | 130 | +395 | 395 | 0 | +395 | +212.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 422 | 265 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 2 | 304 | 198 | +198 | 198 | 0 | +198 | +65.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p17 | move | 16 | 2 (12%) | 1 (6%) | 2 (12%) | 12 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

# Doctrine scorecard: cora-bb45c30-p46

### Scorecard: cora-bb45c30-p46

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 1 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 1 | 6 | 0 | 1 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 1 | 2 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 0.3 | 2.5 | 3.3 | 0.3 | 1.0 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 0% | 2.0 | 2.0 | 4.0 | 2.0 | 0.0 | 0.0 | 0.0 | 56.7 |

### KPIs: cora-bb45c30-p46

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 15) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 50% (3 of 6); on the table 83% | 92% (11 of 12); on the table 92% | 78% (14 of 18); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 60% (3 of 5); on the table 80% | 50% (3 of 6); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 43% (3 of 7); on the table 71% | 82% (14 of 17); on the table 88% | 71% (17 of 24); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 17% (4 of 24) | 50% (6 of 12) | 28% (10 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 22% (4 of 18) | 50% (6 of 12) | 33% (10 of 30) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 83% (5 of 6) | 50% (3 of 6) | 67% (8 of 12) |
| Points that never fought | lower | 19% (1160 of 5999) | 39% (2368 of 5999) | 29% (3528 of 11998) |
|   infantry points that never fought | lower | 68% (676 of 993) | 86% (679 of 793) | 76% (1355 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (13 of 22) | 47% (9 of 19) | 54% (22 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3089 of 5151) | 36% (1800 of 4976) | 48% (4889 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (15%) | 1.7 (83%) | 2.7 (31%) |
| MARCHED: its unit marched | 1.0 (15%) | 0.3 (17%) | 1.3 (15%) |
| IN COMBAT: engaged in combat | 1.7 (25%) | 0.0 (0%) | 1.7 (19%) |
| REAR RANK: in a rear rank | 1.7 (25%) | 0.0 (0%) | 1.7 (19%) |
| GONE: slain | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |
| NOT OFFERED: not in the cast list | 1.0 (15%) | 0.0 (0%) | 1.0 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 2.3 | 3.3 | 1.7 | 3.0 |
| not cast | 8.0 | 7.7 | 8.7 | 2.3 | 29.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 2.7 (31%) | 1.3 (57%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (15%) | 0.3 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (25%) | 2.7 (35%) | 1.7 (19%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (4%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.3 (1%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (9%) | 0.0 (0%) | 0.7 (29%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.0 (12%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.7 (71%) | 4.3 (57%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.3 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 1.3 a game | 1.2 a game |
| stood (cast and not dispelled) | 0% (0 of 3) | 50% (2 of 4) | 29% (2 of 7) |
| the unit moved after it | - | 100% (2 of 2) | 100% (2 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 53% (30 of 57) | 12% (1 of 8) | 48% (31 of 65) |
|   cavalry | - | 33% (1 of 3) | 33% (1 of 3) |
|   character | 83% (5 of 6) | 0% (0 of 5) | 45% (5 of 11) |
|   chariot | 60% (6 of 10) | - | 60% (6 of 10) |
|   infantry | 41% (13 of 32) | - | 41% (13 of 32) |
|   monster | 67% (6 of 9) | - | 67% (6 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (44%) | 0.3 (14%) | 4.3 (38%) |
| CHARGED: it charged | 1.0 (11%) | 1.3 (57%) | 2.3 (21%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 0.7 (7%) | 0.3 (14%) | 1.0 (9%) |
| ONLY IN COMBAT: the only targets were in combat | 1.7 (19%) | 0.3 (14%) | 2.0 (18%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 0.0 (0%) | 1.3 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.3 | 0.3 | 0% | 35.0 pts | 12 pts |
| character | 2.0 | 0.7 | 83% | 10.6 pts | 21 pts |
| chariot | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 4.7 | 2.0 | 64% | 17.0 pts | 79 pts |
| monster | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.3 | 6.0 | 6.2 |
| Charges that made contact a game | 5.0 | 5.0 | 5.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.33 declared, 1.33 contact (3 units) | 1.33 declared, 1.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.68 declared, 0.54 contact (28 units) | 0.56 declared, 0.44 contact (25 units) | 0.62 declared, 0.49 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | 33% (1 of 3) | 0% (0 of 2) | 22% (2 of 9) |
| Character in a unit | 60% (3 of 5) | 50% (1 of 2) | - | 57% (4 of 7) |
| Character on its own | 100% (3 of 3) | 0% (0 of 1) | 50% (3 of 6) | 60% (6 of 10) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (2 of 4) | 0% (0 of 1) | - | 40% (2 of 5) |
| Monster | 100% (1 of 1) | 100% (3 of 3) | - | 100% (4 of 4) |
| Monstrous | - | 50% (2 of 4) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 100% | 0% (0 of 6) | 20% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 50% (1 of 2); on the table 100% | 25% (3 of 12) | 0% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 33% (1 of 3); on the table 33% | 17% (1 of 6) | 38% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 2 | 83% (10 of 12); on the table 92% | 50% (6 of 12) | 46% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 80% (4 of 5); on the table 80% | - | 27% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p46, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (6) | 58% (7) | 59% (13) |
| ...free all their last turn and able to turn (per game) | 2.00 | 1.33 | 3.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.67 | 1.33 | 3.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cora-bb45c30-p46

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (3 of 6) | 56% (9 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 14% (1 of 7) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 100% (5 of 5) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 73% (8 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 2.0 |
| Movement | Points that never moved of their own | 225.0 | 56.7 |
| Movement | Fights charged into per game | 4.3 | 4.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net -210 | 1 of 12, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 2 of 12, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +45 | 1 of 12, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +75 | 7 of 12, net +175 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (20 of 31) | 50% (1 of 2) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 33% (1 of 3) |
| Magic | Wounds caused by magic missiles | 2.0 | - |
| Magic | Wounds caused by other spells | - | 3.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 116.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.7 / 0.0 | 2.0 / 0.0 / 1.7 / 0.0 |
| Combat | Points destroyed in combat | 312.3 | 518.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -0 | +106 |
| Combat | Net per 100 charger points, damage counted | -0.1 | +33.7 |
| Combat | First round won (charged fights) | 54% | 79% |
| Combat | Net points per charged fight | +25 | +120 |
| Combat | Net points per supported fight / lone fight | -55 / +40 | +235 / +111 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 13 | 6 of 14 |
| Game | Points lost | 948.7 | 313.0 |
| Game | VP from objectives | 586.7 | 950.0 |
| Game | Lone holders (player turns) | 0.3 | 2.0 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -1020 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 1262
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p46

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.0 | +66.7 | 0.0 | 0.0 | 0.3 | +6.2 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +31.2 | 0.0 | 0.0 |
| ARMY TABLE | 25.3 | +411.0 | 0.0 | 280.0 | 17.3 | +217.7 | 0.0 | 184.7 |
| ARRIVAL HUNT | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +9.7 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +2.5 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 1.0 | +3.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.7 | +128.1 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +17.8 | 0.0 | 15.0 |
| CHAFF PASSED | 2.0 | -8.5 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +4.7 | 0.0 | 64.0 | 0.7 | +22.5 | 0.0 | 16.7 |
| CHARGE LOSSES | 9.0 | -1026.2 | 0.0 | 386.3 | 13.3 | -654.0 | 0.0 | 320.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 40.0 | 0.0 | 3.3 | +0.0 | 625.3 | 16.7 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 0.0 | 20.0 | +0.0 | 0.0 | 807.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 116.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +72.2 | 0.0 | 0.0 | 1.3 | +24.1 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -441.4 | 0.0 | 85.7 | 2.0 | -101.5 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -1.4 | 180.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 0.0 | 7.0 | +58.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +76.2 | 134.0 | 0.0 |
| EXACT ROUND | 1.7 | +13.0 | 40.0 | 0.0 | 4.3 | +31.1 | 657.0 | 16.7 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 4.7 | +22.0 | 725.3 | 33.3 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 2.0 | +22.7 | 0.0 | 85.7 | 18.7 | +197.7 | 0.0 | 425.3 |
| FEATURE BUFFS | 2.0 | +26.6 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 2.7 | +69.3 | 303.0 | 33.3 |
| FIVE ACTION | 73.3 | +6618.3 | 40.0 | 861.3 | 85.3 | +7067.2 | 1063.7 | 1027.3 |
| FLANK NOT WEIGHED | 13.7 | +0.0 | 0.0 | 244.0 | 3.3 | +0.0 | 0.0 | 43.0 |
| FOLLOW UP WEIGHED | 0.7 | +156.1 | 0.0 | 0.0 | 2.0 | +310.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +97.1 | 40.0 | 0.0 | 6.0 | +436.2 | 1063.7 | 33.3 |
| FREED FROM HIS FIGHT | 9.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND CHARGES FIRST | - | - | - | - | 1.0 | -49.9 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 17.0 | +1798.9 | 0.0 | 0.0 | 7.7 | +1106.7 | 0.0 | 0.0 |
| GUN FIGURES | 5.0 | +0.9 | 0.0 | 43.3 | - | - | - | - |
| GUN MASK | 0.3 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 10.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 5.3 | +0.0 | 0.0 | 386.3 | 3.7 | +0.0 | 0.0 | 303.3 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 116.7 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 0.3 | -7.2 | 0.0 | 0.0 | 5.7 | -55.2 | 0.0 | 15.0 |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 381.7 | 4.3 | +0.0 | 0.0 | 36.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 116.7 | 10.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.7 | +0.0 | 0.0 | 596.3 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 4.0 | +0.0 | 0.0 | 308.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 12.3 | +107.8 | 0.0 | 250.0 | 33.0 | +661.5 | 0.0 | 383.3 |
| HIS SHOTS BY HIS RUN | 10.7 | +168.8 | 0.0 | 21.7 | 38.3 | +522.6 | 0.0 | 712.0 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +23.3 | 319.7 | 16.7 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 128.0 | 15.7 | +0.0 | 0.0 | 573.3 |
| HOLDER ASSIGNMENT | 10.0 | +1005.4 | 0.0 | 64.0 | 10.0 | +952.8 | 0.0 | 286.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -18.8 | 40.0 | 0.0 | 6.0 | -171.8 | 1063.7 | 33.3 |
| IDLE COST | 0.7 | -12.9 | 0.0 | 0.0 | 18.0 | -221.0 | 0.0 | 33.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | -4.0 | 156.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 0.0 | 176.3 | 6.7 | +0.0 | 399.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 1.0 | +13.1 | 15.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +9.0 | 0.0 | 0.0 | 3.3 | +7.7 | 599.7 | 16.7 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +14.0 | 0.0 | 0.0 |
| MANOEUVRE | 2.3 | +84.3 | 0.0 | 64.0 | 1.3 | +1.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +108.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +1.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +79.0 | 0.0 | 180.0 | 0.7 | -24.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +99.7 | 0.0 | 0.0 | 3.7 | +63.2 | 0.0 | 58.0 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 0.0 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +155.6 | 0.0 | 0.0 | 2.3 | +5.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.7 | +65.3 | 0.0 | 180.0 | 3.0 | +6.3 | 0.0 | 0.0 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -3.8 | 0.0 | 31.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.3 | +447.6 | 0.0 | 116.7 | 13.3 | +1781.6 | 0.0 | 322.7 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.7 | +383.9 | 0.0 | 64.0 | 6.0 | +237.9 | 0.0 | 184.0 |
| NEXT CHARGE BY LIST | 3.7 | +325.4 | 0.0 | 0.0 | 7.3 | +1410.2 | 0.0 | 286.7 |
| NO DOUBLE ROUNDS | 1.0 | -19.8 | 40.0 | 0.0 | 5.3 | -245.7 | 1042.0 | 16.7 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +11.1 | 0.0 | 180.0 | - | - | - | - |
| NO SECOND RUN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 2.0 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -64.8 | 0.0 | 0.0 | 4.0 | -82.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -11.9 | 0.0 | 0.0 | 8.7 | -187.5 | 0.0 | 161.3 |
| ONE OBJECTIVE FORMULA | 3.7 | +39.3 | 0.0 | 64.0 | 3.7 | -52.8 | 0.0 | 143.3 |
| ONE PROMISE A TARGET | 1.0 | -71.1 | 0.0 | 0.0 | 1.0 | +21.1 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +34.1 | 21.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 2.3 | +22.6 | 673.0 | 16.7 |
| PATHS CROSS | - | - | - | - | 0.7 | +13.1 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +21.1 | 0.0 | 180.0 | - | - | - | - |
| PLAN RESULT | 37.3 | +40.0 | 0.0 | 1337.7 | 44.0 | +402.8 | 571.3 | 525.7 |
| PROMISE BY ITS OWN SUM | 6.3 | -388.2 | 0.0 | 116.7 | 14.7 | -416.5 | 0.0 | 36.0 |
| PROMISE KNOWS THE FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 36.0 |
| QUARTER ODDS | 16.3 | +2216.4 | 0.0 | 460.0 | 24.3 | +2672.7 | 410.7 | 36.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +214.6 | 0.0 | 70.0 | 2.0 | +107.7 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.3 | +417.9 | 0.0 | 0.0 | 3.7 | +252.0 | 0.0 | 55.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 48.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +46.9 | 78.3 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -32.5 | 0.0 | 0.0 | 1.3 | -10.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +18.0 | 0.0 | 18.0 |
| RESTRAINS TO SHOOT | 0.3 | +14.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | +89.6 | 40.0 | 0.0 | 5.7 | +42.5 | 1045.3 | 33.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.3 | -122.2 | 381.7 | 33.3 |
| RUN DOWN | 0.3 | -11.0 | 0.0 | 0.0 | 4.0 | -33.0 | 722.0 | 16.7 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -68.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +62.6 | 0.0 | 0.0 | 0.7 | +2.2 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +51.5 | 96.3 | 0.0 |
| SELF MOVE SPELL | 1.3 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 4.3 | -133.7 | 0.0 | 316.7 |
| SET UP BY THE SET | 1.3 | +106.2 | 0.0 | 0.0 | 5.7 | +162.9 | 0.0 | 316.7 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +14.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +113.5 | 0.0 | 0.0 | 1.0 | +10.4 | 0.0 | 0.0 |
| SHOT RISK POINTS | 8.0 | +46.6 | 0.0 | 0.0 | 22.0 | -127.9 | 0.0 | 179.3 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 7.7 | +144.4 | 0.0 | 43.3 | 0.7 | +9.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +27.5 | 180.0 | 180.0 | 2.0 | +19.5 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +2.7 | 85.0 | 0.0 |
| SPOT AS THE GAME MOVES | 12.0 | +0.0 | 0.0 | 288.3 | 11.3 | +0.0 | 0.0 | 18.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -4.4 | 21.7 | 0.0 |
| STANDS STILL | 15.7 | +0.0 | 0.0 | 128.0 | 16.3 | +0.0 | 0.0 | 36.0 |
| STAY WORTH | 7.0 | +62.3 | 0.0 | 43.3 | 1.3 | +5.0 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 1.0 | +5.2 | 430.0 | 0.0 | 0.3 | +0.0 | 0.0 | 25.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 11.3 | +1225.5 | 0.0 | 43.3 | 7.0 | +252.6 | 0.0 | 45.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 25.0 | 0.0 | 1.0 | +0.0 | 78.0 | 33.3 |
| SUPPORT WORKED OUT | 11.3 | +1225.5 | 0.0 | 43.3 | 7.0 | +252.6 | 0.0 | 45.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +4.3 | 0.0 | 15.0 |
| SWIFTSTRIDE BY POINTS | 1.3 | +2.2 | 0.0 | 18.3 | 0.3 | +0.3 | 0.0 | 10.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -16.0 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 18.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 184.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 40.7 |
| THE TABLE AGAIN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.7 | +0.0 | 0.0 | 287.3 | 41.7 | +0.0 | 0.0 | 476.7 |
| TIED UP BY THE SUM | 0.7 | +31.8 | 40.0 | 0.0 | 1.7 | +145.1 | 110.0 | 16.7 |
| TIME ON OUR SIDE | 29.0 | +356.4 | 0.0 | 21.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 116.7 | 2.7 | +0.0 | 0.0 | 143.3 |
| WAR ENGINE CHARGES | 0.3 | -2.2 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -27.5 | 140.0 | 0.0 |
| WHO FIGHTS | 0.3 | -3.3 | 0.0 | 0.0 | 0.3 | +5.0 | 78.0 | 0.0 |
| WHO HITS BACK | 0.3 | +18.1 | 0.0 | 0.0 | 1.0 | +47.2 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +2.5 | 70.0 | 0.0 |
| WHOLE FIGHT DANGER | 7.3 | -907.2 | 0.0 | 206.3 | 1.7 | -417.5 | 0.0 | 286.7 |
| WOUNDS ON THE RANKS | 0.3 | +4.5 | 0.0 | 0.0 | 2.7 | +43.0 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p46

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 128 | 128 | 82 | 27.33 | +2280 | +27.8 |
| HOLDER ASSIGNMENT | 60 | 60 | 54 | 18.00 | +3286 | +60.9 |
| FIVE ACTION | 476 | 462 | 40 | 13.33 | +1910 | +47.8 |
| LEGAL CHARGES ONLY | 35 | 35 | 35 | 11.67 | +0 | +0.0 |
| THE TABLE AGAIN | 35 | 35 | 29 | 9.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 63 | 63 | 27 | 9.00 | -2414 | -89.4 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| HIS SHOTS BY HIS RUN | 147 | 139 | 24 | 8.00 | +184 | +7.7 |
| QUARTER ODDS | 122 | 116 | 24 | 8.00 | +2305 | +96.0 |
| MOVE TO CHARGE COMPUTED | 56 | 44 | 23 | 7.67 | +777 | +33.8 |
| REDIRECT FOR A FRIEND IN REACH | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| SUPPORT ADDS | 55 | 54 | 22 | 7.33 | +898 | +40.8 |
| SUPPORT WORKED OUT | 55 | 54 | 22 | 7.33 | +898 | +40.8 |
| HIS SHOT LIST | 136 | 131 | 21 | 7.00 | +128 | +6.1 |
| GOAL WALK | 74 | 74 | 17 | 5.67 | +1425 | +83.8 |
| FOUR ROUNDS | 24 | 23 | 14 | 4.67 | +540 | +38.6 |
| OFF BEST | 14 | 14 | 14 | 4.67 | -440 | -31.5 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 33 | 29 | 11 | 3.67 | +666 | +60.5 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 11 | 3.67 | +43 | +3.9 |
| IDLE COST | 56 | 37 | 9 | 3.00 | +34 | +3.8 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1400 | +175.1 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +967 | +120.8 |
| SHOT RISK POINTS | 90 | 85 | 8 | 2.67 | +186 | +23.2 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| CHAFF PASSED | 6 | 6 | 6 | 2.00 | -25 | -4.2 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -150 | -25.0 |
| SET UP BY THE SET | 21 | 21 | 6 | 2.00 | +668 | +111.2 |
| CASTING BLOCK | 5 | 5 | 5 | 1.67 | +46 | +9.1 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| RISK BY ARC | 20 | 20 | 5 | 1.67 | +101 | +20.1 |
| SWIFTSTRIDE BY POINTS | 5 | 5 | 5 | 1.67 | +7 | +1.5 |
| WHOLE FIGHT DANGER | 27 | 27 | 5 | 1.67 | +323 | +64.6 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 1.33 | +219 | +54.7 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +82 | +20.4 |
| CHARGE NOW FIRST | 12 | 12 | 4 | 1.33 | -133 | -33.3 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 18 | 16 | 4 | 1.33 | +7 | +1.7 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +16 | +3.9 |
| THE ROW IN ITS ORDER | 26 | 4 | 4 | 1.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 7 | 6 | 4 | 1.33 | +124 | +31.1 |
| TIME ON OUR SIDE | 87 | 69 | 4 | 1.33 | +18 | +4.5 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +148 | +37.0 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +30 | +10.1 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +2 | +0.7 |
| CHARGE LOSSES | 67 | 64 | 3 | 1.00 | +40 | +13.3 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 27 | 10 | 3 | 1.00 | +52 | +17.5 |
| EXACT ROUND | 18 | 17 | 3 | 1.00 | +10 | +3.2 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 11 | 11 | 3 | 1.00 | +273 | +91.0 |
| NEARER NOT NEEDED | 44 | 40 | 3 | 1.00 | +82 | +27.3 |
| REDIRECT COUNTER | 24 | 15 | 3 | 1.00 | +131 | +43.7 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STAY WORTH | 25 | 20 | 3 | 1.00 | +29 | +9.8 |
| WOUNDS ON THE RANKS | 9 | 9 | 3 | 1.00 | +62 | +20.8 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| FALLS SHORT | 62 | 53 | 2 | 0.67 | +10 | +4.9 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -12 | -6.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +326 | +163.1 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -5 | -2.5 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +9 | +4.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +39 | +19.6 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +194 | +97.1 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +154 | +77.2 |
| SET CREDITED ONCE | 13 | 13 | 2 | 0.67 | +11 | +5.7 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +94 | +93.6 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 8 | 8 | 1 | 0.33 | +21 | +20.7 |
| HONEST WORTH | 23 | 22 | 1 | 0.33 | +11 | +10.7 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| MISSILES IN THE MOVE | 15 | 8 | 1 | 0.33 | +5 | +5.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 19 | 18 | 1 | 0.33 | +4 | +4.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| ONE FIGHT FORMULA | 34 | 14 | 1 | 0.33 | +3 | +2.5 |
| OVERRUNS AWAY | 7 | 7 | 1 | 0.33 | +6 | +5.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +63 | +63.4 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +141 | +140.7 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -3 | -2.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +43 | +42.9 |
| SUPPORT NARROWED | 4 | 4 | 1 | 0.33 | -25 | -25.2 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WAR ENGINE JOBS | 1 | 1 | 1 | 0.33 | -10 | -9.7 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 77 | 77 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 15 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 51 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 29 | 26 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| GUN MASK | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 32 | 28 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 27 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 14 | 14 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 30 | 29 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 57 | 57 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 18 | 18 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 97 | 97 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 20 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 22 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 244 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 17 | 9 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 8 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 10 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 17 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 25 | 17 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 70 | 60 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 96 | 96 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 217 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p46

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 6.33 | 89.4 |
| ARMY TABLE | rule | 4.33 | 2.00 | 82.6 |
| JOB FIRST | gate | 0.67 | 4.00 | 31.4 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 33.3 |
| ONE PROMISE A TARGET | rule | 1.00 | 0.33 | 62.7 |
| CHAFF PASSED | rule | 0.67 | - | 12.7 |
| MARCH OF THE TABLE | rule | - | 0.67 | 2.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 1.6 |
| JOINT CHARGE NOW | rule | - | 0.33 | 101.9 |
| REFUSING RETIRES | rule | 0.33 | - | 2.8 |
| SUPPORT NARROWED | rule | - | 0.33 | 25.2 |
| WAR ENGINE JOBS | rule | 0.33 | - | 9.7 |

### Plans: cora-bb45c30-p46

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 75% | 84 | 40 | 48% |
| Mine | move | 34.7 | 89% | 2734 | 0 | 0% |
| Mine | shoot | 1.3 | 0% | 136 | 0 | 0% |
| Opponent | charge | 5.0 | 60% | 812 | 397 | 49% |
| Opponent | join | 3.3 | 100% | 125 | 0 | 0% |
| Opponent | move | 34.3 | 93% | 2242 | 0 | 0% |
| Opponent | shoot | 1.0 | 33% | 157 | 6 | 4% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p46

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.7 | 36% | 75% | 0% | - | 25% | 0% | 0% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p46

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 139 (7) | 22 | 116 | 16 | 14% | 2.8 | 137 (6) | 150 (1) | - | 137 (6) | 150 (1) |
| Mine | Character | 7 | 17 (7) | 17 | 0 | 61 | 14% | 1.8 | 0 (1) | 38 (4) | 0 (1) | 38 (3) | 7 (3) |
| Mine | Clean-up | 2 | 38 (2) | 0 | 38 | 0 | 100% | - | 38 (2) | - | - | 0 (1) | 46 (1) |
| Mine | Fast Hammer | 1 | 155 (1) | 155 | 0 | 0 | 0% | 3.0 | - | 155 (1) | - | 155 (1) | - |
| Mine | Hammer | 10 | 3 (10) | 1 | 1 | 68 | 0% | 2.0 | 0 (2) | 5 (5) | 0 (3) | 4 (4) | 2 (6) |
| Mine | Holder | 3 | 36 (3) | 0 | 36 | 46 | 33% | 4.0 | 0 (1) | 66 (2) | - | 36 (3) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 67 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 20 | 0% | 2.3 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 47 (9) | 0 | 47 | 29 | 56% | 2.8 | 0 (4) | 267 (2) | 0 (3) | 133 (4) | 0 (5) |
| Opponent | Character | 10 | 74 (10) | 74 | 0 | 15 | 20% | 2.9 | 83 (4) | 38 (4) | 152 (1) | 125 (4) | 33 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 8 | 62 (8) | 39 | 24 | 22 | 12% | 3.1 | 75 (2) | 68 (4) | 28 (2) | 46 (5) | 88 (3) |
| Opponent | Hammer | 2 | 61 (2) | 0 | 61 | 0 | 50% | 3.0 | - | 61 (2) | - | 0 (1) | 93 (1) |
| Opponent | Holder | 1 | 71 (1) | 0 | 71 | 0 | 0% | 4.0 | - | 71 (1) | - | 71 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.3 | 0 (1) | 0 (1) | 0 (2) | - | 0 (4) |

### Charged fights: cora-bb45c30-p46

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 120 | 5.0 | 1.4 | 24 | 37 | -13 | 0 of 5 | 3 of 5 | -55 | +15 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 767 | 7.0 | 1.0 | 110 | 24 | +86 | 2 of 7 | 4 of 7 | - | +86 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 210 | -210 | 1 of 1 | 0 of 1 | - | -210 |
| **Mine** | all armies | 3 | 0 | 296 | 4.3 | 1.2 | 68 | 43 | +25 | 3 of 13 | 7 of 13 | -55 | +40 |
| Opponent | Vampire Counts | 2 | 175 | 362 | 4.0 | 1.1 | 90 | 6 | +84 | 2 of 8 | 5 of 8 | +235 | +63 |
| Opponent | Warriors of Chaos | 1 | 0 | 1007 | 6.0 | 1.0 | 168 | 0 | +168 | 4 of 6 | 6 of 6 | - | +168 |
| **Opponent** | all armies | 3 | 117 | 577 | 4.7 | 1.1 | 124 | 4 | +120 | 6 of 14 | 11 of 14 | +235 | +111 |

### Effective charges: cora-bb45c30-p46

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 1 (net -185) | 1 (net +45) | 1 (net +75) | 2 | 0% (0 of 3) |
| Mine | Skaven | 1 | 1 (net -210) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 8 | 1 (net +0) | 0 | 2 (net +0) | 0 | 0 | 3 (net +163) | 2 | 33% (2 of 6) |
| Opponent | Warriors of Chaos | 6 | 0 | 1 (net +210) | 0 | 0 | 1 (net +65) | 4 (net +183) | 0 | 0% (0 of 6) |

### Charged fights, damage counted: cora-bb45c30-p46

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 0 | 494 | -210 | 0 | 210 | -210 | - |
| Mine | 76-89% | 1 | 275 | 186 | -185 | 0 | 259 | -259 | -94.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 68 | 75 | +75 | 75 | 0 | +75 | +110.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 228 | 45 | +45 | 45 | 0 | +45 | +19.7 |
| Mine | No odds | 9 | 180 | 165 | +67 | 86 | 47 | +38 | +21.4 |
| Mine | All fights | 13 | 168 | 176 | +25 | 69 | 69 | -0 | -0.1 |
| Opponent | Long shot (under 50%) | 1 | 186 | 185 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 50-54% | 1 | 205 | 210 | +210 | 210 | 171 | +39 | +19.1 |
| Opponent | Effective (55-75%) | 2 | 186 | 235 | +0 | 0 | 16 | -16 | -8.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 432 | 280 | +175 | 175 | 0 | +175 | +40.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 365 | 65 | +65 | 65 | 0 | +65 | +17.8 |
| Opponent | No odds | 2 | 118 | 266 | +92 | 117 | 25 | +92 | +78.0 |
| Opponent | All fights | 14 | 314 | 244 | +120 | 124 | 18 | +106 | +33.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p46 | move | 22 | 8 (36%) | 7 (32%) | 3 (14%) | 11 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

# Doctrine scorecard: cora-bb45c30-p23

### Scorecard: cora-bb45c30-p23

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 2 | 3 | 1 | 3 | 1 | 0 | 0 | 500 |
| L2131 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 0 | 1 | 0 | 0 | 562 |
| L2235 | 3 | 1 | Mine | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 72 |
| L2235 | 3 | 1 | Opponent | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 6 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 2.5 | 2.5 | 2.0 | 2.7 | 0.3 | 0.0 | 0.0 | 190.7 |
| **Average** | | | Opponent | 33% | 0.0 | 4.3 | 1.7 | 2.0 | 0.7 | 0.0 | 0.0 | 187.3 |

### KPIs: cora-bb45c30-p23

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 15) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (4 of 6); on the table 67% | - | 67% (4 of 6); on the table 67% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 100% | - | 67% (2 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 73% (8 of 11); on the table 82% | 100% (1 of 1); on the table 100% | 75% (9 of 12); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 25% (3 of 12) | - | 25% (3 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 27% (3 of 11) | - | 27% (3 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 92% (11 of 12) | 57% (8 of 14) | 73% (19 of 26) |
| Points that never fought | lower | 53% (3197 of 5997) | 34% (2026 of 5999) | 44% (5223 of 11996) |
|   infantry points that never fought | lower | 79% (1323 of 1675) | 45% (585 of 1306) | 64% (1908 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (12 of 21) | 81% (25 of 31) | 71% (37 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (2591 of 4866) | 74% (4360 of 5884) | 65% (6951 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (33%) | - | 1.0 (33%) |
| MARCHED: its unit marched | 1.0 (33%) | - | 1.0 (33%) |
| CHARGED: its unit charged | 0.7 (22%) | - | 0.7 (22%) |
| IN COMBAT: engaged in combat | 0.3 (11%) | - | 0.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 3.0 | 0.7 | 1.0 | 1.3 |
| not cast | 4.0 | 5.0 | 1.3 | 3.0 | 22.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.3 (87%) | 0.0 (0%) | 1.0 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (22%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (13%) | 0.3 (25%) | 0.0 (0%) | 1.0 (4%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (100%) | 0.0 (0%) | 1.0 (75%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 100% (2 of 2) | 100% (2 of 2) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 100% (2 of 2) | 100% (2 of 2) |
| it fought by the end of its next turn | - | 100% (2 of 2) | 100% (2 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 0% (0 of 2) | 0% (0 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (44 of 70) | 59% (19 of 32) | 62% (63 of 102) |
|   cavalry | 92% (11 of 12) | 62% (8 of 13) | 76% (19 of 25) |
|   character | 0% (0 of 11) | 25% (2 of 8) | 11% (2 of 19) |
|   chariot | 77% (10 of 13) | - | 77% (10 of 13) |
|   infantry | 68% (23 of 34) | 82% (9 of 11) | 71% (32 of 45) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (4%) | 1.0 (23%) | 1.3 (10%) |
| CHARGED: it charged | 2.3 (27%) | 0.7 (15%) | 3.0 (23%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET IN RANGE | 3.7 (42%) | 2.0 (46%) | 5.7 (44%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 0.3 (8%) | 1.7 (13%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.7 | 2.0 | 86% | 3.9 pts | 45 pts |
| character | 0.7 | 0.3 | 50% | 23.9 pts | 16 pts |
| chariot | 3.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 11.3 | 6.7 | 65% | 15.4 pts | 175 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 3.0 | 4.0 |
| Charges that made contact a game | 4.0 | 2.0 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.00 contact (2 units) | - | 1.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.43 contact (28 units) | 0.35 declared, 0.23 contact (26 units) | 0.41 declared, 0.33 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | 100% (4 of 4) | - | 80% (8 of 10) |
| Character in a unit | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Character on its own | 100% (5 of 5) | 100% (1 of 1) | 38% (3 of 8) | 64% (9 of 14) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 73% (8 of 11) | 100% (4 of 4) | - | 80% (12 of 15) |
| Monster | 40% (2 of 5) | 0% (0 of 1) | - | 33% (2 of 6) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 60% (3 of 5); on the table 80% | 33% (2 of 6) | 23% | 56% (5 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 83% (5 of 6); on the table 83% | - | 48% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 89% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (1 of 1); on the table 100% | - | 41% | 79% (15 of 19) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 19% | 83% (10 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p23, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 100% (7) | 82% (9) |
| ...free all their last turn and able to turn (per game) | 0.00 | 2.33 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.67 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: cora-bb45c30-p23

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 67% (8 of 12) | 25% (2 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (6 of 14) | 67% (2 of 3) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 40% (2 of 5) | - |
| Strategy | Lone characters that fought | 50% (3 of 6) | 67% (6 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 2.7 | 2.0 |
| Movement | Points that never moved of their own | 190.7 | 187.3 |
| Movement | Fights charged into per game | 3.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 7, net +136 | 1 of 5, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 7, net +59 | 4 of 5, net -209 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.0 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (17 of 45) | 50% (12 of 24) |
| Shooting | Points destroyed by shooting units | 76.0 | 65.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | - |
| Magic | Wounds caused by magic missiles | 0.7 | - |
| Magic | Wounds caused by other spells | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 38.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.0 / 0.7 / 0.7 / 0.0 | 0.0 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 622.7 | 181.7 |
| Combat | Points run down | 41.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +92 | -143 |
| Combat | Net per 100 charger points, damage counted | +23.6 | -48.9 |
| Combat | First round won (charged fights) | 100% | 40% |
| Combat | Net points per charged fight | +92 | -155 |
| Combat | Net points per supported fight / lone fight | +283 / +70 | +0 / -194 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 10 | 4 of 5 |
| Game | Points lost | 260.3 | 947.7 |
| Game | VP from objectives | 1193.3 | 103.3 |
| Game | Lone holders (player turns) | 2.5 | 0.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1819 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1208
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: cora-bb45c30-p23

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.7 | +20.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 32.7 | +430.7 | 0.0 | 290.0 | 31.3 | +319.4 | 0.0 | 1112.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +4.1 | 0.0 | 83.7 |
| CAST JOB | 1.3 | +50.0 | 226.7 | 0.0 | 0.3 | +2.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 91.3 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.7 | +47.5 | 0.0 | 20.0 | 1.3 | +5.9 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -0.8 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +23.3 | 0.0 | 0.0 | 1.0 | +73.9 | 0.0 | 83.3 |
| CHARACTER GUNS | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 9.7 | -641.6 | 0.0 | 173.3 | 23.7 | -1719.4 | 0.0 | 1401.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.7 | +0.0 | 0.0 | 80.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 306.0 | 0.0 | 1.3 | +0.0 | 20.0 | 117.3 |
| CLOSES ON WHAT IT BEATS | 11.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 166.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +17.6 | 75.7 | 91.3 |
| COVER ONCE | 7.0 | -561.3 | 0.0 | 86.7 | 12.0 | -664.4 | 0.0 | 440.7 |
| DEFENSIVE FLOOR | 0.3 | +7.5 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -11.3 | 52.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +10.0 | 52.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 5.0 | +293.6 | 0.0 | 241.7 |
| EXACT ROUND | 2.3 | +13.5 | 151.3 | 0.0 | 1.7 | +57.1 | 0.0 | 157.3 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +12.5 | 162.3 | 0.0 | 2.7 | +14.6 | 0.0 | 357.0 |
| FALLS SHORT | 7.7 | +111.4 | 0.0 | 20.0 | 15.7 | +195.8 | 0.0 | 514.3 |
| FEATURE BUFFS | - | - | - | - | 1.3 | +22.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +19.4 | 0.0 | 0.0 | 0.7 | +19.3 | 0.0 | 78.7 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 52.7 |
| FIVE ACTION | 102.0 | +6953.2 | 1661.0 | 395.0 | 82.3 | +3725.7 | 150.0 | 2579.7 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 86.7 | 9.7 | +0.0 | 0.0 | 518.0 |
| FOCUS FIRE | 0.3 | +29.7 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +44.3 | 0.0 | 0.0 | 0.3 | +42.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.0 | +316.0 | 381.7 | 0.0 | 3.0 | +316.4 | 20.0 | 357.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 151.3 |
| GIVES UP | 0.7 | -8.0 | 34.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.0 | +155.3 | 0.0 | 0.0 | 14.3 | +1451.2 | 0.0 | 301.3 |
| GUN FIGURES | 1.3 | +9.2 | 38.7 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 136.0 |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 173.3 | 12.0 | +0.0 | 0.0 | 1150.7 |
| HIS CHARGE DENIED | 0.3 | +19.0 | 41.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 8.7 | +0.0 | 0.0 | 21.7 | 8.7 | +0.0 | 0.0 | 77.3 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 550.7 |
| HIS MOVE AND SHOT | 1.7 | -7.2 | 0.0 | 20.0 | 4.7 | -54.2 | 0.0 | 145.3 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 70.0 | 5.3 | +0.0 | 0.0 | 665.3 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 170.0 | 7.3 | +0.0 | 0.0 | 618.7 |
| HIS RANDOM MOVE | 25.3 | +0.0 | 0.0 | 195.0 | 14.7 | +0.0 | 0.0 | 585.3 |
| HIS RANDOM MOVER COMES | 3.0 | +0.0 | 0.0 | 21.7 | 3.7 | +0.0 | 0.0 | 322.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 25.7 | +413.6 | 0.0 | 151.7 | 47.3 | +1015.3 | 0.0 | 1688.7 |
| HIS SHOTS BY HIS RUN | 27.0 | +226.7 | 0.0 | 211.7 | 39.0 | +660.7 | 0.0 | 1623.3 |
| HIS TURN DENIED | 1.0 | +11.1 | 105.3 | 0.0 | 0.3 | +0.5 | 0.0 | 38.7 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 23.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 167.3 |
| HOLDER ASSIGNMENT | 16.0 | +1065.1 | 0.0 | 0.0 | 4.0 | +336.4 | 0.0 | 83.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -173.6 | 381.7 | 0.0 | 1.3 | -81.7 | 20.0 | 199.7 |
| IDLE COST | 5.0 | -88.9 | 0.0 | 0.0 | 10.7 | -146.4 | 0.0 | 315.3 |
| JOINT CHARGE NOW | 1.0 | -18.3 | 41.7 | 0.0 | 1.3 | +58.0 | 0.0 | 118.7 |
| KEPT FROM ITS LAST STOP | 6.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 7.7 | +0.0 | 935.7 | 0.0 | 5.7 | +0.0 | 200.0 | 299.7 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +1.2 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 40.0 |
| LOST AFTER ESCAPE | 1.0 | +3.6 | 41.7 | 0.0 | 1.3 | +6.5 | 0.0 | 279.7 |
| LOST CHARGE | - | - | - | - | 0.3 | -1.0 | 0.0 | 38.7 |
| LURE BY WHAT IT DRAWS | 0.3 | -19.7 | 0.0 | 20.0 | - | - | - | - |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -17.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +3.0 | 0.0 | 0.0 | 2.3 | +44.8 | 0.0 | 77.3 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +59.0 | 0.0 | 0.0 | 3.0 | +32.9 | 0.0 | 182.7 |
| MISSILES NEXT TURN | 4.0 | +30.2 | 0.0 | 0.0 | 3.0 | +20.2 | 0.0 | 144.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 84.0 | 156.3 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +723.8 | 0.0 | 170.0 | 6.7 | +472.2 | 0.0 | 544.7 |
| NEARER NOT NEEDED | 11.0 | +425.6 | 0.0 | 20.0 | 7.0 | +333.9 | 0.0 | 174.3 |
| NEXT CHARGE BY LIST | 3.7 | +590.8 | 0.0 | 130.0 | 2.7 | +178.4 | 0.0 | 38.7 |
| NEXT OBJECTIVE NEARER | 0.3 | -13.0 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 5.0 | -297.9 | 381.7 | 0.0 | 2.3 | -194.6 | 20.0 | 357.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +5.4 | 0.0 | 0.0 |
| NOT WORTH A CAST | 4.0 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -141.0 | 34.0 | 0.0 | 3.7 | -127.3 | 0.0 | 76.7 |
| ONE CHALLENGE TEST | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 41.7 |
| ONE FIGHT FORMULA | 3.0 | -51.3 | 0.0 | 0.0 | 6.0 | -187.0 | 0.0 | 470.7 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +17.3 | 0.0 | 78.7 |
| ONE OBJECTIVE FORMULA | 6.3 | -8.2 | 0.0 | 0.0 | 1.3 | +59.9 | 0.0 | 83.7 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +37.2 | 0.0 | 0.0 | 0.3 | +3.1 | 20.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +3.1 | 41.7 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 50.0 | +878.1 | 769.3 | 458.7 | 40.7 | +130.0 | 21.7 | 1445.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -133.0 | 0.0 | 40.0 | 14.7 | -459.7 | 0.0 | 438.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 2.0 | +0.0 | 0.0 | 38.7 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -4.8 | 0.0 | 38.7 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -15.6 | 130.0 | 0.0 |
| QUARTER ODDS | 28.0 | +3208.2 | 762.0 | 70.0 | 21.0 | +2131.4 | 0.0 | 1188.3 |
| RANDOM MOVE BY FIGURES | 4.0 | +120.4 | 0.0 | 118.3 | 4.7 | +57.0 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +33.2 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 2.0 | +1.5 | 0.0 | 0.0 | 1.7 | +39.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +41.9 | 0.0 | 40.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.7 | -149.5 | 0.0 | 130.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| RESERVE FALL BACK | 0.7 | +8.6 | 0.0 | 0.0 | 2.0 | +132.0 | 0.0 | 181.3 |
| RISK BY ARC | 4.3 | +126.5 | 306.0 | 0.0 | 2.7 | +40.2 | 0.0 | 357.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -37.4 | 105.3 | 0.0 | - | - | - | - |
| RUN DOWN | 4.0 | -33.4 | 313.7 | 0.0 | 0.7 | -25.9 | 0.0 | 40.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.3 | -3.7 | 0.0 | 0.0 | 1.3 | -97.3 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +3.3 | 0.0 | 0.0 | 0.7 | +4.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +10.9 | 34.0 | 0.0 | 0.3 | +9.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -15.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | +10.9 | 34.0 | 0.0 | 1.3 | -137.7 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +2.0 | 0.0 | 38.7 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +11.7 | 34.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +15.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +32.5 | 399.3 | 0.0 | 1.0 | +6.8 | 0.0 | 0.0 |
| SHOT RISK POINTS | 14.0 | -228.3 | 0.0 | 171.7 | 23.3 | -214.5 | 0.0 | 1029.3 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +221.2 | 0.0 | 21.7 | 6.7 | +92.3 | 0.0 | 185.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +11.7 | 34.0 | 0.0 |
| SPELL WORTH | 2.0 | +41.4 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | +1.6 | 0.0 | 0.0 | 1.7 | -117.2 | 0.0 | 157.3 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 20.0 | 10.3 | +0.0 | 0.0 | 355.3 |
| STAND AND SHOOT | 0.7 | -5.0 | 52.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 39.3 | +0.0 | 1279.3 | 118.3 | 25.0 | +0.0 | 130.0 | 188.7 |
| STAY WORTH | 11.7 | +74.5 | 648.7 | 0.0 | 4.7 | +17.3 | 0.0 | 38.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 41.7 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 10.3 | +799.6 | 0.0 | 63.3 | 7.3 | +379.9 | 0.0 | 116.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 117.3 |
| SUPPORT WORKED OUT | 10.3 | +799.6 | 0.0 | 63.3 | 7.3 | +379.9 | 0.0 | 116.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.3 | +5.1 | 0.0 | 38.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 48.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 48.0 |
| THE ROW KEEPS ITS WAY | 5.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 167.3 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 167.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.0 | +0.0 | 0.0 | 128.3 | 37.7 | +0.0 | 0.0 | 1111.3 |
| TIED UP BY THE SUM | 3.3 | +382.0 | 276.3 | 0.0 | 0.3 | +42.3 | 20.0 | 0.0 |
| TIME ON OUR SIDE | 29.3 | +266.8 | 68.0 | 108.3 | 17.3 | +173.1 | 0.0 | 0.0 |
| WAITS AGAIN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | +35.1 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -2.5 | 0.0 | 0.0 | 0.7 | +35.2 | 0.0 | 80.0 |
| WHO HITS BACK | 0.3 | +33.0 | 0.0 | 0.0 | 0.3 | +4.1 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +0.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -474.3 | 0.0 | 21.7 | 5.0 | -1344.0 | 0.0 | 532.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 2.7 | +71.3 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p23

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 192 | 192 | 132 | 44.00 | +1496 | +11.3 |
| HOLDER ASSIGNMENT | 60 | 60 | 56 | 18.67 | +3130 | +55.9 |
| HIS SHOT LIST | 219 | 200 | 45 | 15.00 | +481 | +10.7 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 198 | 188 | 35 | 11.67 | +351 | +10.0 |
| FIVE ACTION | 553 | 524 | 32 | 10.67 | +1444 | +45.1 |
| PROMISE BY ITS OWN SUM | 59 | 59 | 26 | 8.67 | -1778 | -68.4 |
| QUARTER ODDS | 147 | 144 | 26 | 8.67 | +2872 | +110.5 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| MOVE TO CHARGE COMPUTED | 36 | 28 | 22 | 7.33 | +1526 | +69.4 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -805 | -38.3 |
| SUPPORT ADDS | 53 | 49 | 20 | 6.67 | +498 | +24.9 |
| SUPPORT WORKED OUT | 53 | 49 | 20 | 6.67 | +498 | +24.9 |
| RANDOM MOVE BY FIGURES | 26 | 26 | 19 | 6.33 | +533 | +28.0 |
| TIME ON OUR SIDE | 140 | 126 | 16 | 5.33 | +5 | +0.3 |
| FOUR ROUNDS | 24 | 22 | 15 | 5.00 | +345 | +23.0 |
| NEXT CHARGE BY LIST | 19 | 17 | 15 | 5.00 | +1429 | +95.3 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +76 | +5.9 |
| COVER ONCE | 57 | 40 | 11 | 3.67 | +60 | +5.5 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| SHOT RISK POINTS | 112 | 102 | 11 | 3.67 | +130 | +11.8 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 15 | 15 | 9 | 3.00 | +844 | +93.7 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| GOAL WALK | 52 | 49 | 8 | 2.67 | +258 | +32.3 |
| RESERVE FALL BACK | 8 | 8 | 8 | 2.67 | +422 | +52.7 |
| TIED UP BY THE SUM | 11 | 10 | 8 | 2.67 | +197 | +24.6 |
| CHAFF IN THE MOVE | 9 | 9 | 7 | 2.33 | +76 | +10.9 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| IDLE COST | 47 | 30 | 7 | 2.33 | +46 | +6.6 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +119 | +17.0 |
| CHARGE LOSSES | 100 | 91 | 6 | 2.00 | +240 | +40.0 |
| RISK BY ARC | 21 | 20 | 6 | 2.00 | +93 | +15.5 |
| CAST JOB | 5 | 5 | 4 | 1.33 | +6 | +1.5 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +292 | +73.0 |
| CHARGE NOW FIRST | 13 | 13 | 4 | 1.33 | -200 | -49.9 |
| NEARER NOT NEEDED | 54 | 52 | 4 | 1.33 | +63 | +15.7 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 4 | 1.33 | +35 | +8.7 |
| SHOTS IN THE MOVE | 67 | 52 | 4 | 1.33 | +39 | +9.7 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +261 | +87.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +23 | +7.6 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +62 | +30.8 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -2 | -1.2 |
| CHARGE NOT DECLARED | 2 | 2 | 2 | 0.67 | -562 | -280.9 |
| FIGHT TO THE END | 4 | 4 | 2 | 0.67 | +52 | +25.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -47 | -23.3 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +76 | +38.2 |
| REDIRECT COUNTER | 11 | 8 | 2 | 0.67 | +49 | +24.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +62 | +31.1 |
| SET UP BY THE SET | 8 | 8 | 2 | 0.67 | +24 | +11.9 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| STAY WORTH | 49 | 42 | 2 | 0.67 | +25 | +12.3 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 26 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHAT THE JOINER ADDS | 4 | 2 | 2 | 0.67 | +1 | +0.4 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +111 | +55.7 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.33 | +11 | +10.8 |
| EXACT ROUND | 12 | 11 | 1 | 0.33 | +14 | +14.1 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 17 | 15 | 1 | 0.33 | +1 | +0.8 |
| FALLS SHORT | 70 | 59 | 1 | 0.33 | +10 | +9.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +89 | +89.2 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +27 | +27.2 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +1 | +0.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +7 | +6.8 |
| MAX FOR POSITIONING | 9 | 8 | 1 | 0.33 | +5 | +5.2 |
| MISSILES IN THE MOVE | 18 | 14 | 1 | 0.33 | +3 | +2.8 |
| ONE OBJECTIVE FORMULA | 23 | 18 | 1 | 0.33 | +37 | +36.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +13 | +13.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -8 | -8.2 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | +58 | +57.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +63 | +62.6 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 4 | 4 | 1 | 0.33 | -2 | -1.7 |
| SURE REACH TOGETHER | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +34 | +34.3 |
| WHOLE FIGHT | 2 | 1 | 1 | 0.33 | +0 | +0.4 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 9 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 56 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 16 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 16 | 16 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 55 | 52 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 52 | 47 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 26 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 41 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 120 | 111 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 20 | 18 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 92 | 0 | 0.00 | - | - |
| HONEST WORTH | 18 | 16 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 25 | 24 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 22 | 21 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 27 | 14 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 272 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 19 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 9 | 9 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 42 | 38 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 193 | 186 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 257 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 25 | 23 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p23

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 7.00 | 68.4 |
| ARMY TABLE | rule | 3.33 | 4.33 | 84.0 |
| JOB FIRST | gate | 2.33 | 2.33 | 22.2 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 49.9 |
| NO REASON | gate | - | 1.33 | 46.8 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 12.7 |
| RULE SWITCHED OFF | gate | 1.00 | - | 102.6 |
| CHAFF PASSED | rule | - | 0.67 | 1.2 |
| CHARGE NOT DECLARED | rule | - | 0.67 | 280.9 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 75.1 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 23.3 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 8.2 |
| SUPPORT NARROWED | rule | 0.33 | - | 1.7 |

### Plans: cora-bb45c30-p23

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.0 | 60% | 677 | 345 | 51% |
| Mine | join | 1.7 | 100% | 96 | 0 | 0% |
| Mine | move | 39.7 | 95% | 2119 | 0 | 0% |
| Mine | shoot | 3.3 | 70% | 188 | 534 | 283% |
| Mine | support | 0.3 | 0% | 21 | 0 | 0% |
| Opponent | charge | 2.0 | 17% | 276 | 65 | 24% |
| Opponent | join | 0.3 | 100% | 20 | 0 | 0% |
| Opponent | move | 36.7 | 92% | 1722 | 0 | 0% |
| Opponent | shoot | 1.0 | 33% | 31 | 65 | 211% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p23

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p23

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 141 (5) | 0 | 141 | 19 | 40% | 1.7 | 174 (4) | 0 (1) | - | 174 (4) | 0 (1) |
| Mine | Character | 9 | 46 (9) | 46 | 0 | 0 | 33% | 3.8 | 45 (5) | 48 (4) | - | 86 (4) | 14 (5) |
| Mine | Clean-up | 2 | 44 (2) | 44 | 0 | 0 | 0% | 4.5 | - | 106 (1) | 0 (1) | 0 (1) | 106 (1) |
| Mine | Fast Hammer | 4 | 90 (4) | 90 | 0 | 24 | 50% | 1.5 | 135 (2) | 0 (2) | - | 371 (1) | 0 (3) |
| Mine | Hammer | 4 | 95 (4) | 95 | 0 | 53 | 0% | 1.8 | 74 (1) | 144 (2) | 0 (1) | 102 (3) | 74 (1) |
| Mine | Holder | 7 | 41 (7) | 0 | 41 | 5 | 86% | 5.0 | 85 (2) | 18 (4) | 0 (1) | 45 (6) | 0 (1) |
| Mine | Shooter | 5 | 126 (5) | 35 | 92 | 44 | 0% | 1.2 | 218 (1) | 135 (2) | 75 (2) | 65 (3) | 229 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 9 | 11 (9) | 11 | 0 | 43 | 33% | 3.0 | 4 (5) | 0 (2) | 54 (1) | 15 (6) | 7 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 7 (5) | 0 | 7 | 60 | 40% | 2.0 | 11 (3) | - | 0 (2) | 0 (2) | 12 (3) |
| Opponent | Hammer | 10 | 18 (10) | 18 | 0 | 57 | 10% | 2.6 | 35 (4) | 0 (5) | 0 (1) | 45 (4) | 0 (6) |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 54 | 25% | 4.3 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Opponent | Shooter | 3 | 54 (3) | 54 | 0 | 62 | 0% | 1.0 | 139 (1) | 0 (2) | - | - | 54 (3) |

### Charged fights: cora-bb45c30-p23

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 116 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 228 | 745 | 9.0 | 1.2 | 83 | 0 | +83 | 1 of 9 | 9 of 9 | +283 | +58 |
| Mine | Vampire Counts | 1 | 0 | 170 | 1.0 | 1.0 | 170 | 0 | +170 | 0 of 1 | 1 of 1 | - | +170 |
| **Mine** | all armies | 3 | 115 | 305 | 3.3 | 1.2 | 92 | 0 | +92 | 1 of 10 | 10 of 10 | +283 | +70 |
| Opponent | Warriors of Chaos | 2 | 0 | 30 | 2.0 | 1.2 | 15 | 59 | -44 | 3 of 4 | 2 of 4 | +0 | -59 |
| Opponent | Wood Elf Realms | 1 | 195 | 0 | 1.0 | 1.0 | 0 | 599 | -599 | 1 of 1 | 0 of 1 | - | -599 |
| **Opponent** | all armies | 3 | 65 | 20 | 1.7 | 1.2 | 12 | 167 | -155 | 4 of 5 | 2 of 5 | +0 | -194 |

### Effective charges: cora-bb45c30-p23

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 9 | 0 | 0 | 0 | 0 | 3 (net +136) | 4 (net +59) | 2 | 0% (0 of 7) |
| Opponent | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 1 (net +60) | 3 (net -79) | 0 | 0% (0 of 4) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -599) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p23

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 254 | 126 | +59 | 59 | 0 | +59 | +23.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 620 | 125 | +136 | 136 | 0 | +136 | +21.9 |
| Mine | No odds | 3 | 334 | 125 | +91 | 91 | 0 | +91 | +27.1 |
| Mine | All fights | 10 | 388 | 125 | +92 | 92 | 0 | +92 | +23.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 243 | 379 | -209 | 24 | 218 | -194 | -79.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 494 | 60 | +60 | 60 | 0 | +60 | +12.1 |
| Opponent | All fights | 5 | 293 | 315 | -155 | 32 | 175 | -143 | -48.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p23 | move | 22 | 4 (18%) | 3 (14%) | 5 (23%) | 13 (59%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

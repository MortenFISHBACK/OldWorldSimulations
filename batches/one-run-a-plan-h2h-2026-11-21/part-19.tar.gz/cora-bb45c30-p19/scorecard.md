# Doctrine scorecard: cora-bb45c30-p19

### Scorecard: cora-bb45c30-p19

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 140 |
| L1228 | 4 | 1 | Mine | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Opponent | no | 4 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.0 | 2.0 | 3.3 | 0.7 | 0.3 | 0.0 | 0.0 | 110.0 |
| **Average** | | | Opponent | 0% | 2.0 | 4.0 | 0.7 | 1.7 | 0.0 | 0.0 | 0.0 | 46.7 |

### KPIs: cora-bb45c30-p19

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 33% (5 of 15) | 0% (0 of 15) | 17% (5 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (2 of 4); on the table 50% | 100% (1 of 1); on the table 100% | 60% (3 of 5); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 67% | 100% (1 of 1); on the table 100% | 71% (5 of 7); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 17% (12 of 72) | 33% (6 of 18) | 20% (18 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 23% (12 of 52) | 38% (6 of 16) | 26% (18 of 68) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 45% (2671 of 5998) | 32% (1915 of 6000) | 38% (4586 of 11998) |
|   infantry points that never fought | lower | 73% (536 of 730) | 45% (352 of 782) | 59% (888 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (15 of 25) | 65% (17 of 26) | 63% (32 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 57% (4 of 7); 4.0 uses a game | 50% (1 of 2); 1.0 uses a game | 56% (5 of 9); 2.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (3077 of 5614) | 61% (3427 of 5644) | 58% (6504 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.3 (17%) | 1.0 (25%) | 4.3 (18%) |
| MARCHED: its unit marched | 8.0 (40%) | 1.0 (25%) | 9.0 (38%) |
| CHARGED: its unit charged | 2.0 (10%) | 0.0 (0%) | 2.0 (8%) |
| IN COMBAT: engaged in combat | 5.3 (27%) | 0.0 (0%) | 5.3 (22%) |
| FLEEING: fleeing | 1.3 (7%) | 0.0 (0%) | 1.3 (6%) |
| GONE: slain | 0.0 (0%) | 0.7 (17%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (8%) | 0.3 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.0 (25%) | 1.0 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 6.0 | 1.7 | 6.0 | 0.3 | 4.0 |
| not cast | 1.3 | 10.0 | 4.3 | 24.0 | 3.7 | 24.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (14%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (50%) | 0.0 (0%) | 4.3 (18%) | 0.3 (9%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.0 (38%) | 1.0 (27%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 5.3 (22%) | 0.7 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.0 (10%) | 1.0 (23%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 2.7 (27%) | 0.0 (0%) | 1.3 (6%) | 1.3 (36%) | 3.3 (14%) |
| GONE: slain | 0.7 (50%) | 0.0 (0%) | 0.7 (15%) | 0.7 (3%) | 0.0 (0%) | 1.3 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (3%) | 0.3 (8%) | 0.3 (1%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) | 0.3 (9%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (25%) | 0.3 (3%) | 2.0 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (60%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 60% (3 of 5) | 60% (3 of 5) |
| the unit moved after it | - | 0% (0 of 3) | 0% (0 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 33% (1 of 3) | 33% (1 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 67% (2 of 3) | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (36 of 52) | 68% (49 of 72) | 69% (85 of 124) |
|   cavalry | - | 79% (15 of 19) | 79% (15 of 19) |
|   character | - | 100% (12 of 12) | 100% (12 of 12) |
|   chariot | 62% (5 of 8) | 100% (9 of 9) | 82% (14 of 17) |
|   infantry | 83% (10 of 12) | 29% (7 of 24) | 47% (17 of 36) |
|   monster | - | 75% (6 of 8) | 75% (6 of 8) |
|   war machine | 66% (21 of 32) | - | 66% (21 of 32) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (19%) | 4.0 (52%) | 5.0 (38%) |
| CHARGED: it charged | 0.3 (6%) | 0.3 (4%) | 0.7 (5%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (13%) | 1.0 (8%) |
| MOVED: a war machine that moved | 1.7 (31%) | 0.0 (0%) | 1.7 (13%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.0 (26%) | 2.0 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | 0.3 (4%) | 1.0 (8%) |
| SHELTERED: the target was sheltered | 1.0 (19%) | 0.0 (0%) | 1.0 (8%) |
| OTHER BAR | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.0 | 1.0 | 90% | 2.3 pts | 16 pts |
| character | 4.0 | 1.3 | 92% | 3.6 pts | 14 pts |
| chariot | 4.7 | 1.0 | 93% | 11.8 pts | 55 pts |
| infantry | 8.7 | 0.7 | 92% | 2.7 pts | 24 pts |
| monster | 2.0 | 0.7 | 83% | 7.1 pts | 14 pts |
| war machine | 8.0 | 9.3 | 50% | 29.9 pts | 239 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.3 | 1.7 | 4.0 |
| Charges that made contact a game | 5.3 | 1.3 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 2.17 declared, 1.67 contact (6 units) | - | 2.17 declared, 1.67 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 3.00 declared, 3.00 contact (1 units) | - | 3.00 declared, 3.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.33 contact (9 units) | 0.19 declared, 0.15 contact (26 units) | 0.23 declared, 0.20 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | - | 25% (1 of 4) | 50% (5 of 10) |
| Character in a unit | 67% (2 of 3) | 67% (2 of 3) | 100% (1 of 1) | 71% (5 of 7) |
| Character on its own | - | 71% (5 of 7) | 50% (2 of 4) | 64% (7 of 11) |
| Chariot | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Infantry | 50% (4 of 8) | - | - | 50% (4 of 8) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 67% (4 of 6); on the table 67% | 17% (12 of 72) | 45% | 60% (15 of 25) | 57% (4 of 7); 4.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 33% (2 of 6) | 42% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 0% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 50% (3 of 6) | 54% | 92% (11 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p19, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | 50% (4) | 42% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p19

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 84% (16 of 19) | 80% (4 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (18 of 46) | 50% (8 of 16) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (3 of 6) | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 100% (5 of 5) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 33% (1 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 1.7 |
| Movement | Points that never moved of their own | 110.0 | 46.7 |
| Movement | Fights charged into per game | 4.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 14, net -320 | 2 of 4, net -51 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 14 | 1 of 4, net +150 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 14, net +62 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 14, net +175 | 1 of 4, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 15) | 63% (31 of 49) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 7.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (6 of 21) | - |
| Shooting | Points destroyed by war machines | 61.7 | 55.0 |
| Magic | Magic missiles cast | 3.3 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (2 of 10) | 80% (4 of 5) |
| Magic | Wounds caused by magic missiles | 7.7 | 1.7 |
| Magic | Wounds caused by other spells | 7.7 | - |
| Magic | Points destroyed by magic (all spells) | 13.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 2.0 / 2.7 / 0.3 | 1.3 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 216.7 | 230.0 |
| Combat | Points run down | 71.0 | 144.7 |
| Combat | Net points per charged fight, damage counted | -26 | +47 |
| Combat | Net per 100 charger points, damage counted | -8.2 | +33.6 |
| Combat | First round won (charged fights) | 50% | 50% |
| Combat | Net points per charged fight | -39 | +50 |
| Combat | Net points per supported fight / lone fight | -395 / +21 | - / +50 |
| Combat | Charged fights on a top-3 enemy unit | 9 of 14 | 2 of 4 |
| Game | Points lost | 655.7 | 483.3 |
| Game | VP from objectives | 750.0 | 410.0 |
| Game | Lone holders (player turns) | 1.0 | 2.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +151 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1139
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p19

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +31.3 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 6.0 | +161.3 | 0.0 | 64.7 | 34.0 | +237.8 | 0.0 | 648.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +24.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +4.4 | 0.0 | 68.3 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +1.3 | 0.0 | 50.0 | 0.7 | +8.8 | 0.0 | 0.0 |
| BEST PRIZE | 0.7 | -21.7 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.3 | +10.8 | 0.0 | 50.0 | - | - | - | - |
| CANNON PLANNED TARGET | 7.0 | +130.3 | 134.7 | 110.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.7 | +37.9 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.7 | +18.3 | 93.3 | 0.0 | 1.7 | +20.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +6.3 | 0.0 | 68.3 | 1.7 | +49.2 | 0.0 | 37.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -1.7 | 0.0 | 57.7 | - | - | - | - |
| CHARGE LOSSES | 15.7 | -323.0 | 0.0 | 484.0 | 19.0 | -889.9 | 0.0 | 443.7 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 289.3 | 176.3 | 0.7 | +0.0 | 50.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.0 | +0.0 | 0.0 | 136.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +136.0 | 0.0 | 0.0 |
| COVER ONCE | 4.7 | -236.0 | 0.0 | 0.0 | 8.7 | -1106.0 | 0.0 | 245.7 |
| DENIED BY THE FIGHT | 0.7 | -3.2 | 46.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 1.0 | +7.2 | 52.7 | 144.7 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +96.4 | 52.7 | 144.7 | 0.3 | +0.9 | 0.0 | 11.3 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +57.7 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +6.6 | 125.3 | 50.0 | 1.3 | -21.0 | 100.0 | 68.0 |
| FALL BACK GOOD ORDER | 3.0 | +31.1 | 236.7 | 176.3 | 1.3 | +0.4 | 50.0 | 79.3 |
| FALLS SHORT | 3.0 | +65.8 | 0.0 | 0.0 | 25.0 | +378.5 | 0.0 | 259.0 |
| FEATURE BUFFS | 1.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 2.0 | +32.6 | 0.0 | 198.7 | 0.7 | +14.5 | 0.0 | 68.0 |
| FIVE ACTION | 73.0 | +5563.8 | 1007.0 | 1802.7 | 80.0 | +4458.0 | 430.0 | 829.3 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 189.0 |
| FOLLOW UP WEIGHED | 0.3 | +193.6 | 0.0 | 0.0 | 0.3 | +11.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 6.3 | +990.6 | 314.3 | 519.3 | 1.7 | +109.6 | 100.0 | 79.3 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 57.7 | 6.0 | +0.0 | 0.0 | 123.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -15.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -0.2 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -5.1 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.3 | +237.3 | 0.0 | 0.0 | 10.0 | +1002.0 | 0.0 | 150.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +46.6 | 55.0 | 61.7 |
| GUN MASK | 1.0 | +5.7 | 0.0 | 164.7 | 0.7 | +61.7 | 0.0 | 123.3 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 57.7 | 3.7 | +0.0 | 0.0 | 123.3 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 100.0 | 9.7 | +0.0 | 0.0 | 443.7 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 113.7 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 352.7 | 4.7 | +0.0 | 0.0 | 123.3 |
| HIS MOVE AND SHOT | 1.3 | -10.1 | 0.0 | 0.0 | 13.3 | -124.2 | 0.0 | 123.3 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 352.7 | 5.0 | +0.0 | 0.0 | 123.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 30.0 | +957.9 | 0.0 | 466.0 | 52.0 | +2834.9 | 0.0 | 573.7 |
| HIS SHOTS BY HIS RUN | 31.7 | +698.0 | 0.0 | 610.3 | 46.7 | +1487.9 | 0.0 | 598.0 |
| HIS TURN DENIED | 1.0 | +10.3 | 99.3 | 0.0 | 0.7 | +12.1 | 50.0 | 11.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 187.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.3 | +1011.5 | 0.0 | 187.0 | 5.7 | +776.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -148.0 | 314.3 | 68.3 | 0.3 | -8.8 | 0.0 | 34.0 |
| HUNT IN PAIRS | 0.3 | +37.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | - | - | - | - | 0.3 | +0.0 | 0.0 | 11.3 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +107.0 | 0.0 | 11.3 |
| IDLE COST | - | - | - | - | 15.0 | -222.5 | 0.0 | 114.0 |
| JOINT CHARGE NOW | 1.7 | +320.9 | 0.0 | 198.7 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 4.7 | +0.0 | 122.3 | 234.3 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 3.7 | -15.2 | 199.7 | 469.3 | 1.3 | -0.4 | 100.0 | 45.3 |
| LOST CHARGE | 0.3 | -1.6 | 0.0 | 50.0 | - | - | - | - |
| MANOEUVRE | 2.0 | -3.9 | 0.0 | 0.0 | 1.7 | +26.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +112.0 | 0.0 | 0.0 | 0.7 | +99.7 | 0.0 | 0.0 |
| MARCH CHECK | 2.7 | +165.1 | 0.0 | 0.0 | 0.3 | +18.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.3 | +164.4 | 0.0 | 0.0 | 0.3 | +21.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 3.7 | -23.7 | 0.0 | 0.0 | 0.7 | +11.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.0 | +57.6 | 0.0 | 0.0 | 2.0 | +64.2 | 0.0 | 13.3 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.0 | +104.3 | 0.0 | 122.3 | 3.7 | +38.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 10.3 | +109.4 | 0.0 | 458.0 | 4.0 | +31.3 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.0 | -32.1 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 1.7 | +200.5 | 0.0 | 100.0 | 3.0 | +123.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +241.2 | 0.0 | 0.0 | 5.3 | +241.4 | 0.0 | 46.7 |
| NEXT CHARGE BY LIST | 2.0 | +224.1 | 0.0 | 100.0 | 2.7 | +114.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -275.4 | 303.0 | 50.0 | 1.7 | -29.7 | 100.0 | 79.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -196.3 | 0.0 | 64.7 | 4.7 | -157.0 | 0.0 | 190.0 |
| OGRE LOADER SECOND SHOT | 5.7 | +53.3 | 0.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -76.2 | 0.0 | 50.0 | 4.0 | -94.3 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | -5.4 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 6.3 | +13.2 | 0.0 | 57.7 | 1.0 | +31.5 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.3 | +30.3 | 224.7 | 50.0 | 0.7 | +2.7 | 50.0 | 11.3 |
| PATHS CROSS | 0.3 | +24.0 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 33.3 | +845.9 | 387.3 | 792.7 | 35.7 | +120.9 | 110.0 | 733.7 |
| PROMISE BELOW ZERO | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 2.3 | -126.4 | 0.0 | 0.0 | 3.3 | -62.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 12.3 | +1923.1 | 204.7 | 328.3 | 12.3 | +1162.1 | 0.0 | 152.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +373.8 | 0.0 | 13.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 11.3 |
| REDIRECT WEIGHED | 0.3 | -8.1 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | - | - | - | - | 1.3 | -24.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 122.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +4.2 | 0.0 | 52.7 |
| RISK BY ARC | 5.7 | +81.7 | 314.3 | 447.0 | 1.3 | -8.3 | 50.0 | 79.3 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -8.2 | 0.0 | 72.3 | 0.3 | -3.7 | 50.0 | 0.0 |
| RUN DOWN | 4.3 | -49.1 | 314.3 | 194.7 | 1.3 | -4.3 | 100.0 | 45.3 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | -2.6 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -242.5 | 0.0 | 74.0 |
| SET UP BY THE SET | - | - | - | - | 4.0 | +99.2 | 0.0 | 74.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 12.0 | +0.0 | 0.0 | 174.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +65.2 | 278.7 | 187.0 | 1.3 | +71.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | 2.7 | -191.7 | 52.7 | 68.3 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 15.7 | -155.0 | 0.0 | 484.0 | 33.7 | +167.9 | 0.0 | 326.0 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.3 | +688.0 | 0.0 | 160.0 | 14.7 | +484.2 | 0.0 | 246.7 |
| SPELL WORTH | 1.3 | +13.9 | 144.7 | 144.7 | 2.0 | +26.0 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 0.3 | +2.9 | 100.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 2.0 | +0.0 | 0.0 | 107.7 | 5.7 | +0.0 | 0.0 | 37.0 |
| STAND AND SHOOT | 1.3 | -12.2 | 184.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 10.0 | +0.0 | 0.0 | 153.0 |
| STANDS STILL | 40.0 | +0.0 | 692.7 | 475.3 | 27.0 | +0.0 | 330.0 | 246.3 |
| STANDS TO CAST | - | - | - | - | 0.3 | +16.6 | 0.0 | 0.0 |
| STAY WORTH | 30.7 | +162.0 | 320.7 | 380.0 | 20.0 | +207.9 | 330.0 | 99.7 |
| STOPS | - | - | - | - | 0.3 | +2.4 | 0.0 | 11.3 |
| STRIKE BY THE ODDS | 1.0 | +27.2 | 0.0 | 263.3 | 1.0 | +6.5 | 0.0 | 68.0 |
| SUPPORT ADDS | 0.3 | +32.4 | 0.0 | 0.0 | 3.7 | +401.3 | 0.0 | 87.3 |
| SUPPORT WORKED OUT | 0.3 | +32.4 | 0.0 | 0.0 | 3.7 | +401.3 | 0.0 | 87.3 |
| SWIFTSTRIDE BY POINTS | 0.7 | -3.3 | 0.0 | 194.7 | 0.3 | +0.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 57.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -22.6 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 57.7 | 2.3 | +0.0 | 0.0 | 38.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 64.7 | 6.3 | +0.0 | 0.0 | 13.7 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 64.7 | 5.7 | +0.0 | 0.0 | 13.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.0 | +0.0 | 0.0 | 641.7 | 38.3 | +0.0 | 0.0 | 348.7 |
| TIED UP BY THE SUM | 2.0 | +207.9 | 97.3 | 50.0 | - | - | - | - |
| TIME ON OUR SIDE | 22.3 | +381.9 | 93.3 | 683.0 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | +12.8 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -18.4 | 100.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | +3.1 | 50.0 | 0.0 |
| WHO HITS BACK | 0.3 | +1.3 | 0.0 | 0.0 | 0.7 | +133.9 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +11.6 | 50.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.0 | -57.9 | 0.0 | 57.7 | 3.0 | -300.0 | 0.0 | 193.7 |
| WHOLE FIGHT GAIN | 0.3 | +15.9 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 5.0 | +52.4 | 0.0 | 0.0 | 4.7 | +116.6 | 0.0 | 52.7 |

### Rule changes: cora-bb45c30-p19

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 120 | 120 | 89 | 29.67 | +1572 | +17.7 |
| HIS SHOTS BY HIS RUN | 235 | 226 | 66 | 22.00 | +1400 | +21.2 |
| HIS SHOT LIST | 246 | 237 | 65 | 21.67 | +1775 | +27.3 |
| HOLDER ASSIGNMENT | 48 | 48 | 42 | 14.00 | +3540 | +84.3 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -1060 | -44.2 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| FIVE ACTION | 459 | 450 | 21 | 7.00 | +1713 | +81.6 |
| SHOT RISK POINTS | 148 | 142 | 19 | 6.33 | +548 | +28.9 |
| THE TABLE AGAIN | 35 | 35 | 19 | 6.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 17 | 17 | 17 | 5.67 | +160 | +9.4 |
| FOUR ROUNDS | 24 | 24 | 15 | 5.00 | +1469 | +98.0 |
| LEGAL CHARGES ONLY | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| GOAL WALK | 40 | 39 | 13 | 4.33 | +790 | +60.8 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| QUARTER ODDS | 74 | 73 | 12 | 4.00 | +1188 | +99.0 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| SET UP BY THE SET | 12 | 12 | 10 | 3.33 | +276 | +27.6 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 9 | 3.00 | +210 | +23.3 |
| CAST JOB | 8 | 8 | 7 | 2.33 | +13 | +1.8 |
| IDLE COST | 45 | 30 | 7 | 2.33 | +68 | +9.8 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +166 | +27.7 |
| CHARGE LOSSES | 104 | 99 | 6 | 2.00 | +142 | +23.7 |
| MARCH BY THE SUM | 6 | 6 | 6 | 2.00 | +635 | +105.9 |
| MARCH CHECK | 9 | 9 | 6 | 2.00 | +144 | +24.0 |
| MOVE TO CHARGE COMPUTED | 14 | 14 | 6 | 2.00 | +337 | +56.1 |
| NEXT CHARGE BY LIST | 14 | 14 | 6 | 2.00 | +337 | +56.1 |
| STRIKE BY THE ODDS | 6 | 6 | 6 | 2.00 | +101 | +16.9 |
| TIED UP BY THE SUM | 6 | 6 | 6 | 2.00 | +192 | +31.9 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CASTING BLOCK | 10 | 10 | 5 | 1.67 | +38 | +7.5 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +963 | +192.5 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -558 | -111.6 |
| TIME ON OUR SIDE | 67 | 59 | 5 | 1.67 | +42 | +8.4 |
| COVER ONCE | 40 | 24 | 4 | 1.33 | +110 | +27.4 |
| FALLS SHORT | 84 | 66 | 4 | 1.33 | +39 | +9.7 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RISK BY ARC | 21 | 21 | 4 | 1.33 | +40 | +9.9 |
| SHOTS AFTER THE MOVES | 24 | 24 | 4 | 1.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 21 | 21 | 3 | 1.00 | -82 | -27.4 |
| CHARGE NOW FIRST | 11 | 11 | 3 | 1.00 | -251 | -83.8 |
| HIS MOVE AND SHOT | 44 | 43 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 11 | 11 | 3 | 1.00 | +81 | +26.9 |
| PROMISE BY ITS OWN SUM | 17 | 17 | 3 | 1.00 | -568 | -189.2 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REFUSING RETIRES | 4 | 4 | 3 | 1.00 | +20 | +6.6 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STAY WORTH | 152 | 134 | 3 | 1.00 | +3 | +1.0 |
| SUPPORT ADDS | 12 | 12 | 3 | 1.00 | +82 | +27.2 |
| SUPPORT WORKED OUT | 12 | 12 | 3 | 1.00 | +82 | +27.2 |
| SWIFTSTRIDE BY POINTS | 3 | 3 | 3 | 1.00 | -9 | -3.1 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +184 | +61.4 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -65 | -32.6 |
| EVASIVE BY THE ODDS | 4 | 4 | 2 | 0.67 | +82 | +41.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +617 | +308.4 |
| GUN MASK | 5 | 5 | 2 | 0.67 | +117 | +58.5 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| OVERRUNS AWAY | 9 | 9 | 2 | 0.67 | +9 | +4.5 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 2 | 0.67 | -0 | -0.1 |
| WOUNDS ON THE RANKS | 29 | 27 | 2 | 0.67 | +24 | +11.9 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +94 | +93.9 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +13 | +13.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +32 | +32.5 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +113 | +113.3 |
| EXACT ROUND | 10 | 10 | 1 | 0.33 | +1 | +0.7 |
| FIGHT TO THE END | 8 | 8 | 1 | 0.33 | +19 | +18.9 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +24 | +24.2 |
| HUNT IN PAIRS | 1 | 1 | 1 | 0.33 | +64 | +63.9 |
| MISSILES NEXT TURN | 43 | 33 | 1 | 0.33 | +0 | +0.2 |
| NEARER NOT NEEDED | 33 | 30 | 1 | 0.33 | +54 | +53.5 |
| NO DOUBLE ROUNDS | 16 | 16 | 1 | 0.33 | +1 | +0.6 |
| ONE OBJECTIVE FORMULA | 22 | 15 | 1 | 0.33 | +17 | +16.7 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +72 | +72.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +24 | +23.5 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +13 | +12.7 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +24 | +23.5 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 87 | 64 | 1 | 0.33 | +38 | +37.6 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -4 | -4.5 |
| THE ROW IN ITS ORDER | 10 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +38 | +38.5 |
| WHO FIGHTS | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +19 | +18.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 32 | 31 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 23 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 52 | 48 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 7 | 7 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 28 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 67 | 67 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 13 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 15 | 15 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 15 | 15 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 26 | 23 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 24 | 18 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 207 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 7 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 54 | not checked | - | - | - | - |
| SHOT OR CHARGE | 8 | 8 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 23 | 20 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 30 | 27 | 0 | 0.00 | - | - |
| STANDS STILL | 201 | 196 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 205 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p19

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 4.00 | 48.4 |
| ARMY TABLE | rule | 0.33 | 3.33 | 115.0 |
| MARCH OF THE TABLE | rule | 1.33 | 0.33 | 111.6 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 83.8 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 13.5 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 0.33 | 189.2 |
| BEST PRIZE | rule | 0.67 | - | 32.6 |
| NO REASON | gate | - | 0.67 | 20.9 |
| REFUSING RETIRES | rule | 0.67 | - | 6.6 |
| SWIFTSTRIDE BY POINTS | rule | 0.67 | - | 5.0 |
| AFTERMATH BAND | gate | 0.33 | - | 1.1 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 104.8 |
| JOINT CHARGE NOW | rule | 0.33 | - | 47.7 |
| SET UP BY THE SET | rule | - | 0.33 | 2.5 |
| STANDS TO CAST | rule | - | 0.33 | 4.5 |
| WHO HITS BACK | rule | 0.33 | - | 1.1 |

### Plans: cora-bb45c30-p19

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.3 | 38% | 1024 | 370 | 36% |
| Mine | move | 14.7 | 98% | 1016 | 0 | 0% |
| Mine | shoot | 13.3 | 40% | 624 | 476 | 76% |
| Opponent | charge | 1.3 | 25% | 90 | 58 | 64% |
| Opponent | move | 28.7 | 94% | 1497 | 0 | 0% |
| Opponent | shoot | 5.3 | 12% | 462 | 63 | 14% |
| Opponent | support | 0.3 | 0% | 22 | 0 | 0% |

### Packages: hunt the guns, cora-bb45c30-p19

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 321 | 0 | 0% | 62 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 321 | 0 | 0% | 185 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: cora-bb45c30-p19

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 43% | 67% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p19

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 38 (12) | 38 | 0 | 42 | 8% | 2.5 | - | 8 (8) | 89 (4) | 34 (7) | 40 (5) |
| Mine | Fast Hammer | 4 | 10 (4) | 10 | 0 | 30 | 25% | 2.3 | 0 (2) | 14 (2) | - | 16 (3) | 0 (1) |
| Mine | Holder | 5 | 42 (5) | 0 | 42 | 42 | 20% | 3.5 | - | 58 (3) | 18 (2) | 42 (5) | - |
| Mine | Shooter | 2 | 454 (2) | 0 | 454 | 0 | 0% | 1.0 | 186 (1) | 722 (1) | - | 454 (2) | - |
| Mine | War machine | 6 | 19 (6) | 19 | 0 | 17 | 0% | 1.8 | 0 (2) | 0 (2) | 56 (2) | 0 (1) | 22 (5) |
| Opponent | Chaff | 6 | 0 (6) | 0 | 0 | 43 | 33% | 4.5 | 0 (5) | 0 (1) | - | 0 (5) | 0 (1) |
| Opponent | Character | 7 | 41 (7) | 41 | 0 | 14 | 0% | 2.3 | 0 (1) | 55 (5) | - | 67 (5) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 68 | 33% | 2.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 79 (4) | 71 | 8 | 14 | 0% | 2.5 | - | 89 (3) | 0 (1) | 89 (3) | 0 (1) |
| Opponent | Hammer | 8 | 44 (8) | 30 | 13 | 32 | 12% | 1.9 | 45 (2) | 36 (2) | 49 (4) | 53 (5) | 27 (3) |
| Opponent | Holder | 1 | 81 (1) | 0 | 81 | 100 | 0% | 2.0 | - | 81 (1) | - | 81 (1) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 56 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: cora-bb45c30-p19

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 75 | 353 | 4.7 | 1.1 | 76 | 114 | -39 | 9 of 14 | 7 of 14 | -395 | +21 |
| Opponent | Ogre Kingdoms | 1 | 165 | 150 | 1.0 | 1.0 | 150 | 0 | +150 | 0 of 1 | 1 of 1 | - | +150 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 150 | 3.0 | 1.0 | 50 | 34 | +16 | 2 of 3 | 1 of 3 | - | +16 |
| **Opponent** | all armies | 3 | 55 | 100 | 1.3 | 1.0 | 75 | 26 | +50 | 2 of 4 | 2 of 4 | - | +50 |

### Effective charges: cora-bb45c30-p19

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 14 | 5 (net -320) | 1 (net +0) | 0 | 0 | 3 (net +62) | 5 (net +175) | 0 | 0% (0 of 14) |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +150) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 3 | 2 (net -51) | 0 | 1 (net +150) | 0 | 0 | 0 | 0 | 33% (1 of 3) |

### Charged fights, damage counted: cora-bb45c30-p19

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 344 | 467 | -320 | 15 | 320 | -305 | -88.7 |
| Mine | 50-54% | 1 | 369 | 297 | +0 | 82 | 0 | +82 | +22.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 271 | 166 | +175 | 178 | 0 | +178 | +65.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 346 | 62 | +62 | 62 | 0 | +62 | +17.9 |
| Mine | All fights | 14 | 320 | 261 | -39 | 88 | 114 | -26 | -8.2 |
| Opponent | Long shot (under 50%) | 2 | 102 | 358 | -51 | 5 | 60 | -55 | -54.2 |
| Opponent | Effective (55-75%) | 1 | 125 | 150 | +150 | 150 | 0 | +150 | +120.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 234 | 150 | +150 | 150 | 0 | +150 | +64.1 |
| Opponent | All fights | 4 | 141 | 254 | +50 | 77 | 30 | +47 | +33.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p19 | move | 18 | 3 (17%) | 3 (17%) | 2 (11%) | 13 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

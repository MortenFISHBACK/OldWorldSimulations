# Doctrine scorecard: cora-bb45c30-p4

### Scorecard: cora-bb45c30-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 358 |
| L0524 | 2 | 1 | Opponent | - | - | - | 2 | 5 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 500 |
| L0612 | 6 | 1 | Opponent | no | 11 | 6 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 461 |
| L0628 | 4 | 1 | Opponent | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 6.0 | 0.3 | 2.0 | 0.0 | 0.0 | 0.0 | 439.7 |
| **Average** | | | Opponent | 0% | 8.5 | 6.0 | 0.7 | 2.3 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: cora-bb45c30-p4

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (14 of 14) | 0% (0 of 13) | 52% (14 of 27) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | - | - |
| Magic missiles tried each own turn | 50%+ | - | 47% (14 of 30) | 47% (14 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 50% (14 of 28) | 50% (14 of 28) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 86% (5182 of 6000) | 93% (5569 of 5998) | 90% (10751 of 11998) |
|   infantry points that never fought | lower | 89% (1993 of 2232) | 100% (694 of 694) | 92% (2687 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (14 of 27) | 70% (16 of 23) | 60% (30 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 2.3 uses a game | 100% (3 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (1915 of 4232) | 73% (4215 of 5787) | 61% (6130 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (25%) | 1.3 (25%) |
| MARCHED: its unit marched | - | 2.7 (50%) | 2.7 (50%) |
| IN COMBAT: engaged in combat | - | 0.7 (12%) | 0.7 (12%) |
| STUPIDITY: Stupidity | - | 0.7 (12%) | 0.7 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.0 | 4.7 | 0.3 | 0.3 |
| not cast | 2.0 | 3.0 | 5.3 | 3.7 | 23.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (100%) | 1.3 (25%) | 1.3 (36%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.7 (50%) | 1.3 (36%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (12%) | 0.3 (9%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) |
| STUPIDITY: Stupidity | 0.7 (33%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 2.7 (11%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (18%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (80%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (150 of 219) | 78% (7 of 9) | 69% (157 of 228) |
|   cavalry | 55% (12 of 22) | 0% (0 of 2) | 50% (12 of 24) |
|   character | 91% (30 of 33) | - | 91% (30 of 33) |
|   infantry | 56% (30 of 54) | - | 56% (30 of 54) |
|   monster | 92% (11 of 12) | - | 92% (11 of 12) |
|   war machine | 68% (67 of 98) | 100% (7 of 7) | 70% (74 of 105) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (14%) | 0.3 (50%) | 3.7 (15%) |
| NO TARGET IN RANGE | 9.0 (39%) | 0.0 (0%) | 9.0 (38%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 8.7 (38%) | 0.3 (50%) | 9.0 (38%) |
| SHELTERED: the target was sheltered | 1.3 (6%) | 0.0 (0%) | 1.3 (6%) |
| OTHER BAR | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 2.7 | 62% | 30.0 pts | 130 pts |
| character | 11.0 | 9.0 | 64% | 11.6 pts | 128 pts |
| infantry | 20.3 | 6.7 | 75% | 6.4 pts | 129 pts |
| monster | 3.7 | 0.7 | 82% | 4.2 pts | 15 pts |
| war machine | 24.7 | 15.7 | 65% | 18.2 pts | 449 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 1.3 | 0.8 |
| Charges that made contact a game | 0.0 | 0.7 | 0.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.33 declared, 0.33 contact (3 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.00 contact (22 units) | 0.23 declared, 0.08 contact (13 units) | 0.11 declared, 0.03 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (1 of 1) | 50% (1 of 2) | 57% (4 of 7) |
| Character in a unit | 67% (4 of 6) | 67% (2 of 3) | 100% (1 of 1) | 70% (7 of 10) |
| Character on its own | 100% (2 of 2) | 100% (4 of 4) | 50% (1 of 2) | 88% (7 of 8) |
| Infantry | 29% (2 of 7) | 33% (2 of 6) | - | 31% (4 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 70% (7 of 10) | - | - | 70% (7 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | - | - | 86% | 52% (14 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 39% (7 of 18) | 81% | 67% (6 of 9) | 100% (3 of 3); 7.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | - | 50% (3 of 6) | 97% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 67% (4 of 6) | 100% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p4, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | - | - |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cora-bb45c30-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 1) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 51% (45 of 89) | 33% (5 of 15) |
| Strategy | Joined characters whose unit fought | 27% (3 of 11) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 2) | 25% (2 of 8) |
| Movement | Charges halted short of contact | 0.3 | 0.7 |
| Movement | Idle units | 2.0 | 2.3 |
| Movement | Points that never moved of their own | 439.7 | 110.0 |
| Movement | Fights charged into per game | 0.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 1, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 29.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (43 of 89) | - |
| Shooting | Points destroyed by shooting units | 359.7 | 0.0 |
| Shooting | War machine shots | 22.3 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (36 of 67) | 14% (1 of 7) |
| Shooting | Points destroyed by war machines | 0.0 | 40.0 |
| Magic | Magic missiles cast | - | 3.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 36% (4 of 11) |
| Magic | Wounds caused by magic missiles | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 5.0 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 16.7 | 20.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | - | +5 |
| Combat | Net per 100 charger points, damage counted | - | +2.3 |
| Combat | First round won (charged fights) | - | 50% |
| Combat | Net points per charged fight | - | +5 |
| Combat | Net points per supported fight / lone fight | - / - | - / +5 |
| Combat | Charged fights on a top-3 enemy unit | - | 1 of 2 |
| Game | Points lost | 132.3 | 489.0 |
| Game | VP from objectives | 840.0 | 483.3 |
| Game | Lone holders (player turns) | 0.0 | 8.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +646 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 621
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 12.7 | -113.8 | 0.0 | 0.0 | 10.0 | +143.1 | 0.0 | 68.3 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 2.3 | +0.0 | 443.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 20.3 | +149.4 | 1299.3 | 66.7 | 2.3 | +114.0 | 40.0 | 55.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CAST JOB | - | - | - | - | 3.7 | +30.0 | 60.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +101.4 | 0.0 | 73.7 |
| CHALLENGE BY POINTS | 0.3 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -5.0 | 39.0 | 0.0 |
| CHARACTER GUNS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 13.7 | -194.1 | 0.0 | 120.0 | 17.0 | -735.5 | 0.0 | 438.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 37.0 | 0.0 | 0.7 | +0.0 | 39.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 148.7 |
| COVER ONCE | 12.3 | -898.8 | 0.0 | 138.0 | 3.3 | -100.1 | 0.0 | 85.0 |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 0.0 | 4.3 | +35.7 | 0.0 | 55.0 |
| EXACT ROUND | 0.3 | +8.6 | 16.7 | 0.0 | 1.0 | +5.5 | 59.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.3 | +0.0 | 59.0 | 16.7 |
| FALLS SHORT | - | - | - | - | 22.3 | +254.6 | 0.0 | 250.3 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +5.0 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 145.7 | +4743.5 | 3407.7 | 373.3 | 63.0 | +1993.9 | 219.0 | 954.7 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 78.0 | 3.7 | +0.0 | 0.0 | 122.0 |
| FOLLOW UP WEIGHED | 0.3 | +10.9 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 0.3 | -2.2 | 16.7 | 0.0 | 1.3 | +52.1 | 59.0 | 16.7 |
| FRIEND CHARGES FIRST | 0.3 | -6.8 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 5.3 | -131.1 | 37.0 | 0.0 | 0.7 | -4.1 | 0.0 | 0.0 |
| GOAL WALK | 3.7 | +298.0 | 0.0 | 0.0 | 1.3 | +34.2 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +9.3 | 69.7 | 0.0 | - | - | - | - |
| GUN MASK | 3.3 | +55.7 | 0.0 | 0.0 | 3.3 | +64.9 | 0.0 | 68.3 |
| HARD STAY DROPPED | 6.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.7 | +0.0 | 0.0 | 120.0 | 7.0 | +0.0 | 0.0 | 210.7 |
| HIS CHARGE LIST | 13.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 101.3 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 329.3 |
| HIS MOVE AND SHOT | 4.0 | -14.3 | 0.0 | 80.0 | 5.7 | -48.5 | 0.0 | 323.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 329.3 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 329.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.0 | +1182.9 | 0.0 | 220.0 | 36.7 | +3865.3 | 0.0 | 596.0 |
| HIS SHOTS BY HIS RUN | 36.7 | +430.3 | 0.0 | 240.0 | 34.0 | +1060.7 | 0.0 | 794.7 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 13.7 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 115.3 |
| HOLDER ASSIGNMENT | 10.7 | +961.0 | 0.0 | 0.0 | 9.0 | +1063.0 | 0.0 | 57.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.0 | -34.0 | 59.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +145.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.7 | -365.5 | 0.0 | 123.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.7 | 39.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 39.0 | - | - | - | - |
| LOST AFTER ESCAPE | - | - | - | - | 0.3 | -0.0 | 20.0 | 0.0 |
| MANOEUVRE | 2.0 | -43.1 | 0.0 | 0.0 | 2.0 | -23.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +12.6 | 0.0 | 57.7 |
| MARCH CHECK | - | - | - | - | 1.7 | +79.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +12.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.0 | +189.7 | 0.0 | 57.7 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | - | - | - | - | 3.0 | +51.8 | 0.0 | 56.0 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 0.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 6.3 | +39.1 | 0.0 | 56.0 |
| MISSILES NEXT TURN | - | - | - | - | 9.0 | +56.1 | 0.0 | 113.7 |
| MODEL FACING | 4.7 | +1650.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +150.8 | 0.0 | 0.0 | 1.7 | +134.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +240.5 | 0.0 | 0.0 | 4.7 | +205.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.0 | +102.7 | 37.0 | 0.0 | 1.3 | +109.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.0 | -23.8 | 59.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 39.0 | - | - | - | - |
| OFF BEST | 9.7 | -187.9 | 0.0 | 39.0 | 4.3 | -117.3 | 0.0 | 68.3 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.7 | +5.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -16.2 | 0.0 | 0.0 | 3.3 | -69.1 | 0.0 | 76.0 |
| ONE JOINT FIGURE | 0.3 | +0.6 | 16.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 6.0 | -101.0 | 0.0 | 0.0 | 3.7 | -100.6 | 0.0 | 57.7 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +8.2 | 20.0 | 0.0 |
| PLAN RESULT | 62.3 | +1772.5 | 389.3 | 264.7 | 29.7 | +8.7 | 99.0 | 810.3 |
| PROMISE BY ITS OWN SUM | 3.3 | -24.9 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 37.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 2.3 | -41.3 | 0.0 | 0.0 | 0.7 | -4.1 | 0.0 | 0.0 |
| QUARTER ODDS | 16.0 | +1166.5 | 0.0 | 0.0 | 3.0 | +719.8 | 0.0 | 329.3 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +54.8 | 0.0 | 40.0 |
| REDIRECT COUNTER | 1.0 | +128.0 | 0.0 | 0.0 | 1.0 | -35.6 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -34.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 0.7 | +66.9 | 39.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -8.0 | 39.0 | 16.7 |
| RUN DOWN | - | - | - | - | 0.3 | -0.0 | 20.0 | 0.0 |
| SAME CHARGE LATER | 0.3 | -6.6 | 37.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -100.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.8 | 0.0 | 0.0 | 0.7 | +2.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.0 | -65.5 | 0.0 | 0.0 | 1.3 | -52.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | +51.4 | 0.0 | 0.0 | 2.0 | +47.7 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +67.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 30.0 | +0.0 | 0.0 | 105.7 | 5.7 | +0.0 | 0.0 | 55.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +79.9 | 152.3 | 0.0 | 2.0 | +44.2 | 20.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 29.3 | +828.1 | 0.0 | 220.0 | 21.0 | -13.9 | 0.0 | 720.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 40.3 | +1025.6 | 0.0 | 106.7 | 2.7 | +156.6 | 0.0 | 92.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +135.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +0.5 | 20.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 94.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -4.8 | 20.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 20.0 | 0.0 |
| STANDS STILL | 108.7 | +0.0 | 3391.0 | 293.3 | 17.3 | +0.0 | 160.0 | 110.0 |
| STAY WORTH | 66.0 | +180.3 | 1966.0 | 200.0 | 8.7 | +81.0 | 40.0 | 165.0 |
| SUPPORT ADDS | 3.3 | +226.9 | 0.0 | 0.0 | 0.7 | +17.5 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.3 | +226.9 | 0.0 | 0.0 | 0.7 | +17.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +24.2 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.3 | 0.0 | 57.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 57.7 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 233.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 164.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 61.0 | +0.0 | 0.0 | 145.7 | 31.3 | +0.0 | 0.0 | 469.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +22.0 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 59.3 | +628.2 | 107.3 | 118.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | +13.4 | 39.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -101.1 | 0.0 | 20.0 | 2.0 | -123.6 | 0.0 | 210.7 |
| WOUNDS ON THE RANKS | 4.0 | +24.8 | 0.0 | 0.0 | 2.0 | +144.6 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 227 | 225 | 66 | 22.00 | +1807 | +27.4 |
| HOLDER ASSIGNMENT | 59 | 59 | 55 | 18.33 | +3298 | +60.0 |
| ARMY TABLE | 68 | 68 | 47 | 15.67 | +170 | +3.6 |
| HIS SHOTS BY HIS RUN | 212 | 207 | 45 | 15.00 | +415 | +9.2 |
| OFF BEST | 42 | 42 | 42 | 14.00 | -916 | -21.8 |
| TIME ON OUR SIDE | 178 | 164 | 38 | 12.67 | +165 | +4.4 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| SHOT RISK POINTS | 151 | 149 | 29 | 9.67 | +1763 | +60.8 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| FIVE ACTION | 626 | 621 | 21 | 7.00 | +425 | +20.2 |
| MOVE TO CHARGE COMPUTED | 19 | 18 | 18 | 6.00 | +422 | +23.5 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| COVER ONCE | 47 | 42 | 14 | 4.67 | +168 | +12.0 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +4951 | +353.7 |
| CHARGE LOSSES | 92 | 91 | 13 | 4.33 | +1540 | +118.5 |
| IDLE COST | 47 | 41 | 13 | 4.33 | +379 | +29.2 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 13 | 13 | 11 | 3.67 | +227 | +20.7 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 11 | 3.67 | +73 | +6.7 |
| CANNON PLANNED TARGET | 68 | 68 | 10 | 3.33 | -42 | -4.2 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 129 | 102 | 9 | 3.00 | +333 | +37.0 |
| CAST JOB | 11 | 11 | 8 | 2.67 | +18 | +2.3 |
| SHOTS AFTER THE MOVES | 24 | 24 | 8 | 2.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 67 | 60 | 5 | 1.67 | +148 | +29.7 |
| GOAL WALK | 15 | 15 | 5 | 1.67 | +423 | +84.7 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +16 | +3.1 |
| PROMISE BY ITS OWN SUM | 19 | 19 | 5 | 1.67 | -75 | -14.9 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| GUN MASK | 20 | 20 | 4 | 1.33 | +124 | +31.0 |
| STAY WORTH | 224 | 203 | 4 | 1.33 | +10 | +2.6 |
| SUPPORT ADDS | 12 | 12 | 4 | 1.33 | +242 | +60.5 |
| SUPPORT WORKED OUT | 12 | 12 | 4 | 1.33 | +242 | +60.5 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 9 | 9 | 3 | 1.00 | +34 | +11.5 |
| NEARER NOT NEEDED | 30 | 27 | 3 | 1.00 | +48 | +16.0 |
| SET UP BY THE SET | 12 | 11 | 3 | 1.00 | +117 | +39.1 |
| WOUNDS ON THE RANKS | 18 | 18 | 3 | 1.00 | +65 | +21.6 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOUR ROUNDS | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| LEGAL CHARGES ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 5 | 5 | 2 | 0.67 | +98 | +48.8 |
| QUARTER ODDS | 57 | 57 | 2 | 0.67 | +156 | +77.9 |
| RISK BY ARC | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +11 | +5.4 |
| WHO FIGHTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 11 | 11 | 2 | 0.67 | +1002 | +501.2 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.4 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +33 | +32.6 |
| HIS MOVE AND SHOT | 29 | 28 | 1 | 0.33 | +25 | +24.6 |
| HUNT IN PAIRS | 4 | 4 | 1 | 0.33 | +53 | +53.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +4 | +3.8 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +50 | +50.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +38 | +38.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -36 | -36.4 |
| MISSILES IN THE MOVE | 19 | 14 | 1 | 0.33 | +2 | +2.5 |
| ONE FIGHT FORMULA | 20 | 18 | 1 | 0.33 | +5 | +4.5 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 29 | 27 | 1 | 0.33 | +0 | +0.5 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| SAME CHARGE LATER | 1 | 1 | 1 | 0.33 | +4 | +4.1 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +20 | +20.1 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CHAFF IN THE MOVE | 6 | 4 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 18 | 18 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 55 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 18 | 17 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 35 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 66 | 65 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 35 | 34 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 79 | 79 | 0 | 0.00 | - | - |
| HONEST WORTH | 3 | 3 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 23 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 276 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 9 | 9 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 6 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 107 | not checked | - | - | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 26 | 23 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 378 | 375 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 277 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 8 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 9.00 | 4.33 | 22.7 |
| ARMY TABLE | rule | 2.67 | 1.67 | 42.5 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | - | 14.9 |
| CANNON PLANNED TARGET | rule | 1.00 | - | 14.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 4.3 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | - | 7.5 |
| MARCH OF THE TABLE | rule | - | 0.33 | 36.4 |
| RULE SWITCHED OFF | gate | 0.33 | - | 1.4 |

### Plans: cora-bb45c30-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | join | 1.3 | 75% | 46 | 0 | 0% |
| Mine | move | 36.0 | 100% | 1165 | 0 | 0% |
| Mine | shoot | 25.0 | 76% | 605 | 1772 | 293% |
| Opponent | charge | 0.7 | 0% | 52 | 0 | 0% |
| Opponent | join | 1.3 | 100% | 67 | 0 | 0% |
| Opponent | move | 23.0 | 91% | 563 | 0 | 0% |
| Opponent | shoot | 4.0 | 17% | 234 | 9 | 4% |
| Opponent | support | 0.7 | 50% | 29 | 0 | 0% |

### Battle groups: cora-bb45c30-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 2 (13) | 2 | 0 | 8 | 38% | 3.0 | 4 (6) | 0 (6) | 0 (1) | 3 (11) | 0 (2) |
| Mine | Clean-up | 4 | 110 (4) | 81 | 30 | 0 | 75% | 1.0 | 0 (1) | 0 (1) | 217 (2) | 110 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 27 | 33% | 1.0 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 134 (4) | 12 | 121 | 0 | 50% | 2.0 | 30 (1) | 206 (3) | - | 134 (4) | - |
| Mine | Shooter | 8 | 75 (8) | 9 | 66 | 0 | 0% | 2.2 | 164 (1) | 88 (4) | 23 (3) | 85 (6) | 49 (2) |
| Mine | War machine | 17 | 24 (17) | 24 | 0 | 13 | 12% | 1.5 | 0 (4) | 45 (9) | 0 (4) | 0 (3) | 31 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 63 | 100% | - | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 2 (10) | 2 | 0 | 10 | 60% | 3.0 | 0 (3) | 6 (5) | 0 (1) | 3 (8) | 0 (1) |
| Opponent | Clean-up | 1 | 73 (1) | 73 | 0 | 0 | 100% | - | - | 73 (1) | - | 73 (1) | - |
| Opponent | Fast Hammer | 3 | 18 (3) | 0 | 18 | 41 | 100% | - | 0 (1) | 59 (1) | 0 (1) | 25 (2) | 0 (1) |
| Opponent | Holder | 6 | 73 (6) | 0 | 73 | 42 | 67% | 3.0 | 0 (2) | 106 (4) | - | 93 (5) | 0 (1) |
| Opponent | War machine | 2 | 36 (2) | 36 | 0 | 50 | 0% | 1.0 | - | 73 (1) | 0 (1) | - | 36 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: cora-bb45c30-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 360 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 120 | 60 | 1.0 | 1.0 | 60 | 0 | +60 | 0 of 1 | 1 of 1 | - | +60 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 50 | -50 | 1 of 1 | 0 of 1 | - | -50 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 40 | 20 | 0.7 | 1.0 | 30 | 25 | +5 | 1 of 2 | 1 of 2 | - | +5 |

### Effective charges: cora-bb45c30-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 0 | 1 (net +60) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 379 | 60 | +60 | 60 | 0 | +60 | +15.8 |
| Opponent | No odds | 1 | 50 | 239 | -50 | 0 | 50 | -50 | -100.0 |
| Opponent | All fights | 2 | 214 | 150 | +5 | 30 | 25 | +5 | +2.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p4 | move | 11 | 1 (9%) | 0 (0%) | 0 (0%) | 10 (91%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

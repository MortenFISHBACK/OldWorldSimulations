# Doctrine scorecard: cora-bb45c30-p7

### Scorecard: cora-bb45c30-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 0 | 0 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 5 | - | 1 | 0 | 0 | 0 | 0 | 165 |
| L1131 | 3 | 1 | Opponent | yes | 2 | 4 | 2 | 1 | 2 | 0 | 0 | 0 |
| L1224 | 6 | 1 | Mine | no | 14 | 2 | 4 | 0 | 0 | 0 | 0 | 165 |
| L1224 | 6 | 1 | Opponent | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 470 |
| **Average** | | | Mine | 0% | 6.3 | 2.0 | 1.7 | 0.0 | 0.3 | 0.0 | 0.0 | 220.0 |
| **Average** | | | Opponent | 33% | 2.7 | 3.5 | 1.3 | 1.7 | 1.0 | 0.0 | 0.0 | 156.7 |

### KPIs: cora-bb45c30-p7

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 56% (9 of 16) | 0% (0 of 14) | 30% (9 of 30) |
| Winner chose to follow up after the loser gave ground |  | 86% (6 of 7); on the table 86% | - | 86% (6 of 7); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 67% (2 of 3); on the table 67% | 50% (2 of 4); on the table 50% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% | 50% (2 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 70% (7 of 10); on the table 70% | 60% (3 of 5); on the table 60% | 67% (10 of 15); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 42% (28 of 66) | 17% (3 of 18) | 37% (31 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 56% (28 of 50) | 30% (3 of 10) | 52% (31 of 60) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 70% (7 of 10) | 70% (7 of 10) |
| Points that never fought | lower | 48% (2891 of 5998) | 52% (3143 of 5998) | 50% (6034 of 11996) |
|   infantry points that never fought | lower | 100% (730 of 730) | 81% (737 of 913) | 89% (1467 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 44% (11 of 25) | 79% (22 of 28) | 62% (33 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 7.3 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (8 of 8); 4.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 33% (2 of 6); 1.0 uses a game | 33% (2 of 6); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 36% (2028 of 5614) | 73% (4244 of 5828) | 55% (6272 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (11%) | 1.3 (27%) | 2.7 (15%) |
| MARCHED: its unit marched | 5.0 (39%) | 1.0 (20%) | 6.0 (34%) |
| CHARGED: its unit charged | 1.0 (8%) | 0.0 (0%) | 1.0 (6%) |
| IN COMBAT: engaged in combat | 5.3 (42%) | 0.3 (7%) | 5.7 (32%) |
| GONE: slain | 0.0 (0%) | 1.7 (33%) | 1.7 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (13%) | 0.7 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 5.0 | 2.0 | 10.3 | 2.3 | 3.0 |
| not cast | 1.0 | 7.0 | 2.0 | 17.7 | 5.7 | 33.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.3 (62%) | 0.0 (0%) | 2.7 (15%) | 1.0 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.0 (34%) | 1.0 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (6%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 1.0 (14%) | 0.3 (17%) | 5.7 (32%) | 1.3 (24%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.7 (10%) | 0.7 (33%) | 1.7 (9%) | 0.0 (0%) | 2.7 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (67%) | 0.7 (10%) | 0.7 (33%) | 0.7 (4%) | 0.0 (0%) | 1.7 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 2.3 (41%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (33%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 28.0 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.0 a game | 1.0 a game |
| stood (cast and not dispelled) | - | 67% (4 of 6) | 67% (4 of 6) |
| the unit moved after it | - | 0% (0 of 4) | 0% (0 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 25% (1 of 4) | 25% (1 of 4) |
| it fought by the end of its next turn | - | 25% (1 of 4) | 25% (1 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 75% (3 of 4) | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 83% (49 of 59) | 60% (12 of 20) | 77% (61 of 79) |
|   cavalry | - | 86% (6 of 7) | 86% (6 of 7) |
|   character | - | 0% (0 of 7) | 0% (0 of 7) |
|   chariot | 67% (8 of 12) | - | 67% (8 of 12) |
|   infantry | 100% (12 of 12) | 100% (6 of 6) | 100% (18 of 18) |
|   war machine | 83% (29 of 35) | - | 83% (29 of 35) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (40%) | 0.0 (0%) | 1.3 (22%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (25%) | 0.7 (11%) |
| MOVED: a war machine that moved | 0.7 (20%) | 0.0 (0%) | 0.7 (11%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.0 (75%) | 2.0 (33%) |
| SHELTERED: the target was sheltered | 0.7 (20%) | 0.0 (0%) | 0.7 (11%) |
| OTHER BAR | 0.7 (20%) | 0.0 (0%) | 0.7 (11%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.3 | 92% | 3.2 pts | 13 pts |
| chariot | 2.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 12.0 | 2.3 | 83% | 9.0 pts | 108 pts |
| war machine | 10.3 | 10.0 | 55% | 27.5 pts | 285 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 4.0 | 3.7 |
| Charges that made contact a game | 2.7 | 3.0 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.43 declared, 1.14 contact (7 units) | 0.67 declared, 0.33 contact (3 units) | 1.20 declared, 0.90 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (10 units) | 0.48 declared, 0.38 contact (21 units) | 0.32 declared, 0.26 contact (31 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (7 of 11) | 50% (1 of 2) | 0% (0 of 2) | 53% (8 of 15) |
| Character on its own | 100% (7 of 7) | 67% (4 of 6) | 29% (2 of 7) | 65% (13 of 20) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 70% (7 of 10); on the table 70% | 42% (28 of 66) | 48% | 44% (11 of 25) | 100% (7 of 7); 7.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 61% | 78% (7 of 9) | 0.0 uses a game | 33% (2 of 6); 3.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 53% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 67% (2 of 3); on the table 67% | 17% (1 of 6) | 43% | 75% (9 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p7, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 29% (2) | 60% (3) | 42% (5) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: cora-bb45c30-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 78% (7 of 9) | 70% (7 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (21 of 56) | 57% (4 of 7) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (5 of 5) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | - |
| Strategy | Lone characters that fought | 70% (7 of 10) | 36% (4 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.0 | 1.7 |
| Movement | Points that never moved of their own | 220.0 | 156.7 |
| Movement | Fights charged into per game | 2.3 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 2 of 6, net -76 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +863 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 6, net +79 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 6 | 3 of 6, net +154 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.7 | 5.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (11 of 20) | 87% (13 of 15) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 10.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (11 of 31) | - |
| Shooting | Points destroyed by war machines | 77.3 | 0.0 |
| Magic | Magic missiles cast | 6.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (9 of 20) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 13.0 | - |
| Magic | Wounds caused by other spells | 2.0 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 349.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.7 / 1.7 / 1.3 | 1.3 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 278.0 | 153.7 |
| Combat | Points run down | 38.7 | 234.7 |
| Combat | Net points per charged fight, damage counted | +191 | +159 |
| Combat | Net per 100 charger points, damage counted | +50.6 | +49.5 |
| Combat | First round won (charged fights) | 100% | 57% |
| Combat | Net points per charged fight | +177 | +145 |
| Combat | Net points per supported fight / lone fight | +60 / +197 | +352 / +62 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 5 of 7 |
| Game | Points lost | 305.0 | 1015.3 |
| Game | VP from objectives | 923.3 | 503.3 |
| Game | Lone holders (player turns) | 6.3 | 2.7 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +982 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1320
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +12.5 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.7 | +82.1 | 0.0 | 0.0 |
| ARMY TABLE | 8.7 | +66.8 | 0.0 | 0.0 | 20.3 | -61.0 | 0.0 | 633.7 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 9.3 | +455.4 | 535.3 | 55.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.7 | +0.0 | 272.0 | 0.0 |
| CAST JOB | 5.3 | +229.4 | 621.3 | 0.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 156.7 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +86.6 | 0.0 | 100.0 |
| CHALLENGE BY POINTS | 1.0 | +13.3 | 0.0 | 0.0 | 0.7 | +15.6 | 0.0 | 86.3 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.7 | -40.3 | 136.0 | 0.0 |
| CHARGE LOSSES | 10.7 | -557.0 | 0.0 | 272.0 | 28.3 | -1281.0 | 0.0 | 1362.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 469.7 | 0.0 | 2.7 | +0.0 | 272.0 | 127.7 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 230.3 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 213.3 |
| CONVEYANCE SEARCH | - | - | - | - | 2.0 | +334.5 | 323.3 | 323.3 |
| COVER ONCE | 14.7 | -1067.5 | 0.0 | 55.0 | 6.7 | -472.5 | 0.0 | 304.3 |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -8.6 | 131.0 | 0.0 | 0.3 | -21.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +17.4 | 47.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.3 | +12.4 | 323.0 | 0.0 | 2.3 | +26.5 | 55.0 | 89.0 |
| FALL BACK GOOD ORDER | 2.3 | +6.0 | 306.3 | 0.0 | 3.0 | +0.1 | 191.0 | 38.7 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| FALLS SHORT | - | - | - | - | 23.0 | +185.9 | 0.0 | 957.7 |
| FIGHT TO THE END | 1.3 | +13.0 | 383.0 | 0.0 | 2.0 | +43.7 | 408.0 | 127.7 |
| FIVE ACTION | 90.0 | +8179.3 | 4832.3 | 382.0 | 76.0 | +4539.6 | 463.0 | 2457.7 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 136.0 | 6.0 | +0.0 | 0.0 | 428.3 |
| FOLLOW UP WEIGHED | 1.3 | +493.3 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 3.3 | +303.5 | 540.3 | 0.0 | 4.0 | +557.3 | 463.0 | 127.7 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 263.3 |
| FRIEND SHOOTS FIRST | 4.3 | -166.6 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -34.2 | 151.0 | 0.0 | 0.7 | -7.7 | 136.0 | 0.0 |
| GOAL WALK | 1.0 | +79.9 | 0.0 | 0.0 | 13.0 | +2053.5 | 0.0 | 330.7 |
| GUN MASK | 1.7 | +177.2 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 38.7 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 96.7 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 272.0 | 13.7 | +0.0 | 0.0 | 725.3 |
| HIS CHARGE DENIED | 1.0 | +40.5 | 208.3 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 320.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 136.0 | 3.7 | +0.0 | 0.0 | 38.7 |
| HIS MOVE AND SHOT | 1.7 | -5.1 | 0.0 | 0.0 | 15.3 | -315.0 | 0.0 | 679.0 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 95.3 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 136.0 | 4.3 | +0.0 | 0.0 | 38.7 |
| HIS RANDOM MOVE | 12.3 | +0.0 | 0.0 | 272.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 10.7 | +402.9 | 0.0 | 0.0 | 60.0 | +4743.9 | 0.0 | 1994.7 |
| HIS SHOTS BY HIS RUN | 20.3 | +227.8 | 0.0 | 272.0 | 51.7 | +1539.8 | 0.0 | 1913.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +24.0 | 55.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 13.7 | +0.0 | 0.0 | 272.0 | 10.7 | +0.0 | 0.0 | 229.3 |
| HOLDER ASSIGNMENT | 10.7 | +1004.5 | 0.0 | 136.0 | 7.3 | +799.3 | 0.0 | 114.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -118.4 | 540.3 | 0.0 | 2.3 | -84.1 | 327.0 | 38.7 |
| HUNT DROPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 2.3 | +77.4 | 0.0 | 0.0 | 0.3 | +13.9 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +132.6 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 17.3 | -280.0 | 0.0 | 656.0 |
| JOINT CHARGE NOW | 0.7 | -37.7 | 151.0 | 0.0 | 2.0 | -186.7 | 408.0 | 89.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -4.9 | 136.0 | 0.0 |
| KEEP FALLS | 0.3 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 237.0 | 0.0 | 6.0 | +0.0 | 0.0 | 601.3 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -1.0 | 0.0 | 38.7 |
| LOST AFTER ESCAPE | 1.7 | +0.4 | 421.7 | 0.0 | 3.3 | -4.7 | 463.0 | 127.7 |
| MAKE SURE TOGETHER | 0.3 | +0.8 | 0.0 | 0.0 | 0.7 | +6.8 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +13.2 | 0.0 | 0.0 | 1.7 | -37.0 | 0.0 | 151.0 |
| MARCH BY THE SUM | 1.7 | +31.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +87.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 3.0 | +69.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.3 | +225.9 | 0.0 | 0.0 | 1.0 | +191.8 | 0.0 | 221.7 |
| MAX FOR POSITIONING | 7.0 | +235.6 | 0.0 | 0.0 | 3.3 | +87.0 | 0.0 | 85.0 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 14.7 | +492.2 | 0.0 | 0.0 | 2.0 | +11.4 | 0.0 | 103.7 |
| MISSILES NEXT TURN | 16.0 | +374.2 | 0.0 | 0.0 | 4.7 | +19.9 | 0.0 | 453.3 |
| MISSILES ON ONE TARGET | 0.7 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 131.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 156.7 |
| MOVE TO CHARGE COMPUTED | 9.0 | +766.0 | 0.0 | 0.0 | 5.3 | +416.8 | 0.0 | 38.7 |
| NEARER NOT NEEDED | 6.3 | +286.7 | 0.0 | 136.0 | 6.3 | +171.6 | 0.0 | 151.0 |
| NEXT CHARGE BY LIST | 4.3 | +371.3 | 0.0 | 0.0 | 3.3 | +309.8 | 0.0 | 38.7 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -1.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -81.1 | 461.7 | 0.0 | 4.0 | -222.1 | 463.0 | 127.7 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +11.3 | 0.0 | 38.7 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | -12.2 | 0.0 | 20.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -299.3 | 0.0 | 0.0 | 5.3 | -353.7 | 0.0 | 78.7 |
| OGRE LOADER SECOND SHOT | 5.0 | +65.2 | 38.7 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | -3.1 | 47.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 169.7 |
| ONE FIGHT FORMULA | 8.0 | -144.2 | 0.0 | 0.0 | 7.0 | -136.3 | 0.0 | 142.3 |
| ONE JOINT FIGURE | 0.3 | +40.1 | 131.0 | 0.0 | 1.3 | +85.0 | 136.0 | 89.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -66.2 | 0.0 | 136.0 | 3.7 | -105.4 | 0.0 | 73.7 |
| ONE PROMISE A TARGET | 0.3 | -6.8 | 0.0 | 0.0 | 0.3 | +17.2 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +40.1 | 60.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +7.1 | 55.0 | 0.0 |
| OWN CAST FIRST | 1.3 | -20.4 | 0.0 | 0.0 | 0.7 | -1.1 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +34.4 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -19.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 39.0 | +1866.8 | 1848.3 | 382.0 | 39.0 | +487.8 | 136.0 | 1958.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 12.3 | -357.9 | 0.0 | 0.0 | 9.0 | -204.1 | 0.0 | 0.0 |
| PROMISE IN STEPS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | -13.2 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.0 | -47.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 3.0 | -57.0 | 390.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.3 | +1717.4 | 1372.0 | 110.0 | 13.0 | +1401.0 | 327.0 | 211.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +61.1 | 0.0 | 56.7 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +17.8 | 0.0 | 40.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +165.6 | 0.0 | 80.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +24.5 | 0.0 | 60.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 4.3 | -108.9 | 0.0 | 0.0 | 1.0 | -6.3 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 47.7 |
| RISK BY ARC | 3.0 | +111.8 | 501.7 | 0.0 | 3.7 | -201.2 | 463.0 | 89.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -32.6 | 0.0 | 0.0 |
| RUN DOWN | 1.3 | -12.9 | 172.7 | 0.0 | 4.0 | -72.2 | 463.0 | 127.7 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -34.9 | 0.0 | 40.0 |
| SEARCH SPOT | 0.7 | +59.6 | 0.0 | 0.0 | 1.0 | +46.5 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +7.1 | 131.0 | 0.0 | 0.3 | +39.6 | 136.0 | 38.7 |
| SET CREDITED ONCE | 1.3 | -28.9 | 0.0 | 0.0 | 1.3 | -88.4 | 0.0 | 33.3 |
| SET UP BY THE SET | 3.7 | -24.0 | 0.0 | 0.0 | 3.0 | +35.7 | 0.0 | 33.3 |
| SET UP TOGETHER | 0.3 | +0.8 | 0.0 | 0.0 | 0.7 | +6.8 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 17.7 | +0.0 | 0.0 | 55.0 | 3.7 | +0.0 | 0.0 | 103.7 |
| SHOOTS FROM THE BEST SPOT | 7.0 | +629.1 | 1281.3 | 0.0 | 1.0 | +110.2 | 0.0 | 130.0 |
| SHOT OR CHARGE | 0.7 | -17.2 | 58.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 10.3 | +93.5 | 0.0 | 0.0 | 42.7 | +1064.6 | 0.0 | 1603.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.0 | +1379.1 | 0.0 | 55.0 | 4.3 | +324.1 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +8.7 | 0.0 | 0.0 | 1.3 | +35.4 | 313.3 | 313.3 |
| SPELLS IN THE FIGHT | 0.7 | +1.2 | 204.3 | 0.0 | 0.7 | +17.6 | 0.0 | 50.3 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 673.7 |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 48.7 | +0.0 | 4292.0 | 246.0 | 19.0 | +0.0 | 0.0 | 186.7 |
| STAY WORTH | 34.3 | +299.2 | 2482.7 | 0.0 | 6.0 | +44.3 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +14.2 | 0.0 | 136.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +338.2 | 0.0 | 0.0 | 3.7 | +263.2 | 0.0 | 20.0 |
| SUPPORT NARROWED | - | - | - | - | 1.0 | +0.0 | 272.0 | 38.7 |
| SUPPORT WORKED OUT | 2.3 | +338.2 | 0.0 | 0.0 | 3.7 | +263.2 | 0.0 | 20.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +2.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 190.7 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 155.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.3 | +0.0 | 0.0 | 191.0 | 35.3 | +0.0 | 0.0 | 1175.3 |
| TIED UP BY THE SUM | 1.3 | +112.0 | 80.0 | 0.0 | 0.3 | +22.4 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 32.3 | +535.4 | 0.0 | 408.0 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.3 | +6.3 | 55.0 | 50.3 |
| WHO GETS IN | 0.3 | -20.7 | 20.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +47.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.7 | -445.3 | 0.0 | 272.0 | 3.0 | -191.2 | 0.0 | 481.3 |
| WHOLE FIGHT GAIN | 0.3 | +34.8 | 131.0 | 0.0 | 1.7 | +233.8 | 272.0 | 89.0 |
| WOUNDS ON THE RANKS | 2.3 | +10.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: cora-bb45c30-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 87 | 87 | 62 | 20.67 | +730 | +11.8 |
| FIVE ACTION | 498 | 480 | 60 | 20.00 | +3933 | +65.5 |
| HIS SHOT LIST | 212 | 202 | 57 | 19.00 | +2522 | +44.2 |
| HOLDER ASSIGNMENT | 54 | 54 | 48 | 16.00 | +3070 | +64.0 |
| HIS SHOTS BY HIS RUN | 216 | 209 | 39 | 13.00 | +856 | +22.0 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -1959 | -59.4 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| SHOT RISK POINTS | 159 | 153 | 25 | 8.33 | +1161 | +46.4 |
| MOVE TO CHARGE COMPUTED | 43 | 37 | 24 | 8.00 | +865 | +36.1 |
| PROMISE BY ITS OWN SUM | 64 | 64 | 24 | 8.00 | -1686 | -70.3 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 20 | 6.67 | +691 | +34.6 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| CHARGE LOSSES | 117 | 116 | 16 | 5.33 | +1908 | +119.2 |
| OGRE LOADER SECOND SHOT | 15 | 15 | 15 | 5.00 | +196 | +13.0 |
| QUARTER ODDS | 91 | 86 | 15 | 5.00 | +773 | +51.5 |
| CAST JOB | 18 | 18 | 14 | 4.67 | +133 | +9.5 |
| FOUR ROUNDS | 22 | 20 | 12 | 4.00 | +620 | +51.7 |
| GOAL WALK | 42 | 42 | 12 | 4.00 | +2423 | +201.9 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| NEXT CHARGE BY LIST | 23 | 22 | 12 | 4.00 | +651 | +54.3 |
| SET UP BY THE SET | 20 | 20 | 12 | 4.00 | +522 | +43.5 |
| TIME ON OUR SIDE | 97 | 84 | 12 | 4.00 | +76 | +6.4 |
| SUPPORT ADDS | 18 | 16 | 11 | 3.67 | +750 | +68.2 |
| SUPPORT WORKED OUT | 18 | 16 | 11 | 3.67 | +750 | +68.2 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MARCH OF THE TABLE | 9 | 9 | 9 | 3.00 | -209 | -23.2 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| PROMISE SHOT AWAY | 9 | 9 | 9 | 3.00 | -171 | -19.0 |
| COVER ONCE | 64 | 44 | 8 | 2.67 | +207 | +25.9 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | -673 | -84.1 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 7 | 2.33 | +183 | +26.2 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 28 | 28 | 6 | 2.00 | +34 | +5.7 |
| CHAFF IN THE MOVE | 8 | 7 | 6 | 2.00 | +0 | +0.0 |
| OWN CAST FIRST | 6 | 6 | 6 | 2.00 | -64 | -10.7 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +87 | +17.3 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +94 | +18.9 |
| NEARER NOT NEEDED | 38 | 35 | 5 | 1.67 | +94 | +18.9 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +155 | +30.9 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +1480 | +370.0 |
| MARCH CHECK | 5 | 5 | 4 | 1.33 | +44 | +10.9 |
| MAX FOR POSITIONING | 31 | 27 | 4 | 1.33 | +122 | +30.5 |
| SHOTS AFTER THE MOVES | 22 | 22 | 4 | 1.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 6 | 4 | 4 | 1.33 | +262 | +65.4 |
| HUNT IN PAIRS | 8 | 8 | 3 | 1.00 | +55 | +18.4 |
| IDLE COST | 52 | 30 | 3 | 1.00 | +54 | +18.2 |
| MISSILES IN THE MOVE | 50 | 38 | 3 | 1.00 | +38 | +12.6 |
| OPENS UP | 3 | 3 | 3 | 1.00 | +97 | +32.2 |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 3 | 1.00 | -40 | -13.2 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| RISK BY ARC | 20 | 18 | 3 | 1.00 | +56 | +18.7 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +325 | +108.2 |
| WHOLE FIGHT DANGER | 23 | 23 | 3 | 1.00 | +633 | +211.0 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +246 | +123.2 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +63 | +31.7 |
| ONE OBJECTIVE FORMULA | 27 | 23 | 2 | 0.67 | +42 | +20.8 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | +31 | +15.6 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +140 | +70.0 |
| SHOTS IN THE MOVE | 67 | 48 | 2 | 0.67 | +358 | +178.8 |
| STAY WORTH | 121 | 113 | 2 | 0.67 | +12 | +5.9 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +42 | +21.2 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +126 | +62.9 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +38 | +37.6 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.6 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +51 | +51.4 |
| EXACT ROUND | 14 | 14 | 1 | 0.33 | +12 | +11.7 |
| FALLS SHORT | 69 | 59 | 1 | 0.33 | +2 | +1.9 |
| FIGHT TO THE END | 10 | 8 | 1 | 0.33 | +17 | +17.1 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +36 | +35.6 |
| GUN MASK | 5 | 5 | 1 | 0.33 | +84 | +84.0 |
| HIS CHARGE DENIED | 3 | 2 | 1 | 0.33 | +27 | +27.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +7 | +6.8 |
| NO DOUBLE ROUNDS | 19 | 17 | 1 | 0.33 | +7 | +7.4 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +28 | +28.5 |
| ONE FIGHT FORMULA | 45 | 29 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 5 | 3 | 1 | 0.33 | +150 | +149.7 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +103 | +103.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -58 | -57.8 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +22 | +22.3 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -62 | -62.1 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 15 | 15 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 15 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 13 | 13 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 69 | 68 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 29 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 24 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 51 | 51 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 19 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 34 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 37 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 73 | 73 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 15 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 15 | 13 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 62 | 48 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 9 | not checked | - | - | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 234 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 6 | 6 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 7 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 16 | 14 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 15 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 64 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 33 | 29 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 203 | 196 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 8 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 227 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 10 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 7 | 6 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 4.67 | 59.0 |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 3.00 | 70.3 |
| ARMY TABLE | rule | 1.33 | 3.33 | 50.9 |
| PROMISE SHOT AWAY | rule | 3.00 | - | 19.0 |
| JOINT CHARGE NOW | rule | 0.67 | 1.67 | 97.0 |
| MARCH OF THE TABLE | rule | 2.33 | - | 29.9 |
| OWN CAST FIRST | rule | 1.33 | 0.67 | 10.7 |
| HOLDER ASSIGNMENT | rule | 1.33 | - | 9.5 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 13.2 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 55.9 |
| FALLBACK | gate | - | 0.33 | 93.9 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 20.3 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 57.8 |
| SET UP BY THE SET | rule | - | 0.33 | 3.2 |
| TURN GATE | gate | - | 0.33 | 36.7 |
| WHO GETS IN | rule | 0.33 | - | 62.1 |

### Plans: cora-bb45c30-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 78% | 283 | 433 | 153% |
| Mine | move | 20.3 | 98% | 1469 | 0 | 0% |
| Mine | shoot | 15.7 | 51% | 1825 | 1434 | 79% |
| Opponent | charge | 3.3 | 30% | 473 | 481 | 102% |
| Opponent | join | 1.3 | 100% | 70 | 0 | 0% |
| Opponent | move | 30.7 | 90% | 1648 | 0 | 0% |
| Opponent | shoot | 2.3 | 14% | 165 | 7 | 4% |
| Opponent | support | 1.3 | 75% | 44 | 0 | 0% |

### Packages: hunt the guns, cora-bb45c30-p7

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 398 | 0 | 0% | 77 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 398 | 0 | 0% | 232 |

### Battle groups: cora-bb45c30-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 71% | 60% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 87 (9) | 87 | 0 | 27 | 11% | 2.6 | 87 (2) | 109 (5) | - | 73 (4) | 136 (3) |
| Mine | Clean-up | 2 | 99 (2) | 0 | 99 | 0 | 0% | 2.5 | 0 (1) | 186 (1) | - | 99 (2) | - |
| Mine | Fast Hammer | 4 | 63 (4) | 15 | 48 | 40 | 0% | 3.0 | 83 (2) | 55 (2) | - | 84 (3) | 25 (1) |
| Mine | Holder | 1 | 175 (1) | 0 | 175 | 0 | 0% | 1.0 | 175 (1) | - | - | 175 (1) | - |
| Mine | Shooter | 4 | 88 (4) | 9 | 79 | 0 | 0% | 3.0 | 59 (3) | 216 (1) | - | 88 (4) | - |
| Mine | War machine | 6 | 23 (6) | 23 | 0 | 17 | 0% | 1.0 | 70 (2) | 0 (2) | 0 (2) | 70 (1) | 14 (5) |
| Mine | Wizard | 3 | 69 (3) | 69 | 0 | 0 | 0% | 2.0 | 0 (2) | 130 (1) | - | 69 (3) | - |
| Opponent | Chaff | 2 | 175 (2) | 0 | 175 | 100 | 0% | 4.5 | - | 350 (1) | 0 (1) | 175 (2) | - |
| Opponent | Character | 10 | 38 (10) | 38 | 0 | 54 | 50% | 2.8 | 70 (3) | 24 (5) | 0 (2) | 71 (5) | 0 (5) |
| Opponent | Fast Hammer | 9 | 24 (9) | 11 | 14 | 72 | 44% | 2.8 | 0 (2) | 30 (7) | - | 7 (5) | 48 (4) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 63 | 33% | 3.5 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 5 | 28 (5) | 0 | 28 | 0 | 80% | 5.0 | 77 (1) | 42 (1) | 0 (2) | 33 (4) | - |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cora-bb45c30-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 427 | 414 | 2.3 | 1.1 | 177 | 0 | +177 | 2 of 7 | 7 of 7 | +60 | +197 |
| Opponent | High Elf Realms | 1 | 0 | 296 | 3.0 | 1.3 | 99 | 50 | +48 | 3 of 3 | 1 of 3 | +0 | +72 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 869 | 4.0 | 1.2 | 217 | 0 | +217 | 2 of 4 | 3 of 4 | +704 | +55 |
| **Opponent** | all armies | 3 | 0 | 388 | 2.3 | 1.3 | 166 | 22 | +145 | 5 of 7 | 4 of 7 | +352 | +62 |

### Effective charges: cora-bb45c30-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 7 | 0 | 0 | 1 (net +863) | 2 (net +72) | 3 (net +79) | 0 | 1 | 17% (1 of 6) |
| Opponent | High Elf Realms | 3 | 2 (net -76) | 0 | 0 | 0 | 0 | 1 (net +296) | 0 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 4 | 0 | 0 | 0 | 1 (net +704) | 0 | 2 (net +82) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: cora-bb45c30-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 379 | 470 | +863 | 892 | 0 | +892 | +235.5 |
| Mine | 76-89% | 2 | 233 | 143 | +72 | 72 | 0 | +72 | +30.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 472 | 79 | +79 | 100 | 0 | +100 | +21.2 |
| Mine | No odds | 1 | 379 | 343 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 7 | 377 | 191 | +177 | 191 | 0 | +191 | +50.6 |
| Opponent | Long shot (under 50%) | 2 | 396 | 358 | -76 | 91 | 115 | -24 | -6.1 |
| Opponent | 76-89% | 1 | 536 | 358 | +704 | 704 | 21 | +683 | +127.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 269 | 228 | +154 | 186 | 0 | +186 | +69.1 |
| Opponent | No odds | 1 | 116 | 358 | +0 | 0 | 77 | -77 | -66.7 |
| Opponent | All fights | 7 | 321 | 302 | +145 | 206 | 47 | +159 | +49.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p7 | move | 35 | 7 (20%) | 6 (17%) | 1 (3%) | 27 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

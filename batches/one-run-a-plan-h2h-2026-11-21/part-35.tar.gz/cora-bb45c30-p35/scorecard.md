# Doctrine scorecard: cora-bb45c30-p35

### Scorecard: cora-bb45c30-p35

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 4 | 4 | 1 | 4 | 1 | 0 | 0 | 555 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 4 | 6 | 0 | 0 | 0 | 0 | 242 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 2 | 2 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 2.0 | 3.7 | 4.0 | 1.7 | 0.3 | 0.0 | 0.0 | 265.7 |
| **Average** | | | Opponent | 0% | 0.5 | 2.5 | 2.3 | 1.7 | 0.7 | 0.0 | 0.0 | 56.7 |

### KPIs: cora-bb45c30-p35

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 8% (1 of 13) | 0% (0 of 13) | 4% (1 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (3 of 3); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 86% (6 of 7); on the table 86% | 100% (3 of 3); on the table 100% | 90% (9 of 10); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 17% (1 of 6) | 39% (7 of 18) | 33% (8 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 20% (1 of 5) | 41% (7 of 17) | 36% (8 of 22) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 38% (3 of 8) | 50% (4 of 8) | 44% (7 of 16) |
| Points that never fought | lower | 44% (2661 of 5999) | 38% (2274 of 6000) | 41% (4935 of 11999) |
|   infantry points that never fought | lower | 85% (1320 of 1552) | 40% (415 of 1035) | 67% (1735 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 42% (8 of 19) | 87% (26 of 30) | 69% (34 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 50% (1 of 2); 0.7 uses a game | 67% (2 of 3); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 29% (1289 of 4484) | 89% (4948 of 5546) | 62% (6237 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (64%) | 2.3 (44%) |
| MARCHED: its unit marched | 1.3 (80%) | 1.0 (27%) | 2.3 (44%) |
| IN COMBAT: engaged in combat | 0.3 (20%) | 0.0 (0%) | 0.3 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (9%) | 0.3 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 11.7 | 1.3 | 0.7 | 2.7 | 0.3 | 0.3 |
| not cast | 2.3 | 0.7 | 1.3 | 5.3 | 1.7 | 15.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 1.0 (75%) | 2.3 (44%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (44%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (50%) | 0.3 (25%) | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.7 (29%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (80%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (71%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 100% (2 of 2) | 100% (2 of 2) |
| the unit moved after it | - | 50% (1 of 2) | 50% (1 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (70 of 109) | 79% (22 of 28) | 67% (92 of 137) |
|   cavalry | 89% (16 of 18) | 75% (12 of 16) | 82% (28 of 34) |
|   character | 0% (0 of 16) | 50% (1 of 2) | 6% (1 of 18) |
|   chariot | 85% (11 of 13) | - | 85% (11 of 13) |
|   infantry | 69% (43 of 62) | 90% (9 of 10) | 72% (52 of 72) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (3%) | 1.0 (50%) | 1.3 (9%) |
| CHARGED: it charged | 2.7 (21%) | 0.3 (17%) | 3.0 (20%) |
| IN COMBAT: it fought this turn or the last | 1.3 (10%) | 0.7 (33%) | 2.0 (13%) |
| NO TARGET IN RANGE | 6.0 (46%) | 0.0 (0%) | 6.0 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (18%) | 0.0 (0%) | 2.3 (16%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.3 | 1.0 | 93% | 2.6 pts | 37 pts |
| character | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.7 | 0.7 | 82% | 2.8 pts | 10 pts |
| infantry | 21.0 | 6.0 | 83% | 4.9 pts | 104 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 3.7 | 4.8 |
| Charges that made contact a game | 3.7 | 2.3 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.00 contact (2 units) | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.31 contact (32 units) | 0.45 declared, 0.32 contact (22 units) | 0.50 declared, 0.31 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 86% (6 of 7) | 100% (1 of 1) | 100% (1 of 1) | 89% (8 of 9) |
| Character in a unit | 100% (7 of 7) | - | 100% (1 of 1) | 100% (8 of 8) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 29% (2 of 7) | 44% (4 of 9) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 73% (8 of 11) | 100% (1 of 1) | - | 75% (9 of 12) |
| Monster | 50% (3 of 6) | 0% (0 of 1) | - | 43% (3 of 7) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 55% | 56% (5 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 80% (4 of 5); on the table 80% | - | 39% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 50% (3 of 6) | 75% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 0% (0 of 6) | 26% | 92% (11 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 13% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p35, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 67% (2) | 33% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.33 | 0.67 |

### Quality by phase: cora-bb45c30-p35

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 47% (8 of 17) | 40% (4 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (9 of 20) | 30% (3 of 10) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 57% (4 of 7) |
| Strategy | Lone characters that fought | 100% (5 of 5) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.7 | 0.0 |
| Movement | Idle units | 1.7 | 1.7 |
| Movement | Points that never moved of their own | 265.7 | 56.7 |
| Movement | Fights charged into per game | 3.7 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 10 | 1 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 10 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 10, net +38 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 10, net +124 | 3 of 6, net -170 |
| Shooting | Shots by shooting units (incl. breath weapons) | 26.7 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (20 of 80) | 72% (18 of 25) |
| Shooting | Points destroyed by shooting units | 15.0 | 70.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 1.0 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 7.3 / 0.0 / 0.0 / 0.0 | 2.0 / 1.3 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 625.0 | 136.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +109 | -107 |
| Combat | Net per 100 charger points, damage counted | +34.4 | -64.4 |
| Combat | First round won (charged fights) | 91% | 57% |
| Combat | Net points per charged fight | +123 | -88 |
| Combat | Net points per supported fight / lone fight | - / +123 | - / -88 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 11 | 3 of 7 |
| Game | Points lost | 206.0 | 767.3 |
| Game | VP from objectives | 1133.3 | 323.3 |
| Game | Lone holders (player turns) | 2.0 | 0.5 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1431 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 973
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p35

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 32.0 | +454.0 | 0.0 | 70.0 | 23.7 | +601.7 | 0.0 | 121.3 |
| BACKUP TARGETS | 1.0 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| BEST OVERALL | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -6.5 | 52.7 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.7 | +6.7 | 24.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 91.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +22.0 | 0.0 | 0.0 | 0.7 | +4.2 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +35.7 | 0.0 | 41.7 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 15.0 | -493.9 | 0.0 | 0.0 | 27.7 | -1150.5 | 0.0 | 1009.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 70.0 | 0.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 208.0 | 0.0 | 2.3 | +0.0 | 182.0 | 216.3 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 139.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 52.7 | 0.0 | 0.3 | +0.0 | 0.0 | 25.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +155.4 | 52.7 | 91.3 |
| COVER ONCE | 8.0 | -444.2 | 0.0 | 20.0 | 8.7 | -487.4 | 0.0 | 79.7 |
| DENIED BY THE FIGHT | 1.0 | -11.4 | 89.3 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +34.0 | 143.3 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 2.0 | +275.3 | 0.0 | 399.3 |
| EXACT ROUND | 3.7 | +208.4 | 345.3 | 0.0 | 3.3 | -21.4 | 182.0 | 216.3 |
| FALL BACK GOOD ORDER | 4.0 | +47.4 | 245.7 | 0.0 | 2.7 | +0.0 | 182.0 | 216.3 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 2.0 | +12.7 | 0.0 | 0.0 | 19.7 | +258.0 | 0.0 | 383.0 |
| FEATURE BUFFS | 1.0 | +39.1 | 0.0 | 22.0 | 1.7 | +81.6 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +21.8 | 70.0 | 0.0 |
| FIVE ACTION | 117.7 | +9886.1 | 1286.3 | 337.0 | 75.7 | +4099.0 | 206.0 | 1371.0 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 21.7 | 7.7 | +0.0 | 0.0 | 41.7 |
| FOLLOW UP WEIGHED | 1.7 | +177.2 | 0.0 | 0.0 | 0.3 | +124.5 | 0.0 | 62.0 |
| FOUR ROUNDS | 6.0 | +817.8 | 495.3 | 0.0 | 3.3 | +203.9 | 182.0 | 216.3 |
| FREED FROM HIS FIGHT | 4.3 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 176.7 |
| FRIEND SHOOTS FIRST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +25.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -20.3 | 73.3 | 0.0 | 0.7 | -3.3 | 0.0 | 0.0 |
| GOAL WALK | 14.3 | +1671.3 | 0.0 | 0.0 | 7.3 | +357.7 | 0.0 | 41.7 |
| GUN FIGURES | 1.0 | +0.0 | 15.0 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 176.7 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 591.3 |
| HIS CHARGE DENIED | 1.0 | +33.2 | 103.7 | 0.0 | 0.3 | +46.5 | 0.0 | 199.7 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 237.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 338.7 |
| HIS MOVE AND SHOT | 2.0 | -18.1 | 0.0 | 0.0 | 8.0 | -128.4 | 0.0 | 197.3 |
| HIS ONE QUARTER | 5.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 8.3 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 538.3 |
| HIS RANDOM MOVE | 17.0 | +0.0 | 0.0 | 48.0 | 8.0 | +0.0 | 0.0 | 124.0 |
| HIS RANDOM MOVER COMES | 3.7 | +0.0 | 0.0 | 48.0 | 0.7 | +0.0 | 0.0 | 124.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.0 | +755.4 | 0.0 | 162.0 | 52.7 | +1191.5 | 0.0 | 795.0 |
| HIS SHOTS BY HIS RUN | 36.7 | +500.5 | 0.0 | 92.0 | 52.0 | +595.9 | 0.0 | 1081.3 |
| HIS TURN DENIED | 1.7 | +92.8 | 220.7 | 0.0 | 1.0 | +5.7 | 22.0 | 16.7 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 24.0 | +0.0 | 0.0 | 66.0 | 12.0 | +0.0 | 0.0 | 38.0 |
| HOLDER ASSIGNMENT | 15.3 | +1133.3 | 0.0 | 44.0 | 7.3 | +731.4 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -164.7 | 390.0 | 0.0 | 3.0 | -57.5 | 182.0 | 216.3 |
| HUNT IN PAIRS | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 2.0 | -38.9 | 0.0 | 0.0 | 16.7 | -146.0 | 0.0 | 256.3 |
| JOINT CHARGE NOW | 1.3 | -4.2 | 105.3 | 0.0 | 1.0 | -29.6 | 140.0 | 16.7 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 38.0 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 11.3 | +0.0 | 170.0 | 128.0 | 6.7 | +0.0 | 91.7 | 529.3 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 1.3 | +9.8 | 22.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +13.1 | 83.3 | 0.0 | 0.7 | +1.5 | 0.0 | 16.7 |
| LURE BY WHAT IT DRAWS | 0.7 | -43.9 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | -2.5 | 0.0 | 0.0 | 2.0 | -0.9 | 0.0 | 36.7 |
| MARCH AT ESCAPER | 0.7 | +8.3 | 0.0 | 0.0 | 1.3 | +28.0 | 0.0 | 52.7 |
| MARCH BY THE SUM | 0.3 | +8.0 | 0.0 | 0.0 | 0.3 | +46.3 | 0.0 | 52.7 |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +11.3 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.3 | +15.9 | 0.0 | 0.0 | 0.7 | +252.1 | 0.0 | 52.7 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +18.0 | 0.0 | 0.0 | 1.3 | +11.3 | 0.0 | 15.0 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +28.1 | 0.0 | 0.0 | 3.7 | +59.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +34.0 | 0.0 | 0.0 | 6.7 | +65.2 | 0.0 | 52.7 |
| MOVE ORDER | 2.7 | +0.0 | 22.0 | 0.0 | 3.3 | +0.0 | 0.0 | 38.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -24.1 | 0.0 | 91.3 |
| MOVE TO CHARGE COMPUTED | 9.3 | +1439.4 | 0.0 | 0.0 | 7.3 | +582.1 | 0.0 | 523.3 |
| NEARER NOT NEEDED | 16.3 | +655.3 | 0.0 | 46.0 | 7.3 | +326.7 | 0.0 | 36.7 |
| NEXT CHARGE BY LIST | 7.0 | +1218.7 | 0.0 | 0.0 | 5.0 | +498.9 | 0.0 | 523.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -0.2 | 0.0 | 38.0 |
| NO DOUBLE ROUNDS | 6.0 | -349.0 | 495.3 | 0.0 | 3.0 | -86.8 | 182.0 | 216.3 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -176.4 | 41.7 | 22.0 | 6.0 | -112.2 | 0.0 | 38.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -123.2 | 0.0 | 20.0 | 6.0 | -82.3 | 0.0 | 62.0 |
| ONE JOINT FIGURE | 0.3 | -19.7 | 52.7 | 0.0 | 0.3 | +0.8 | 0.0 | 16.7 |
| ONE OBJECTIVE FORMULA | 8.3 | -4.0 | 0.0 | 22.0 | 3.7 | -16.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -4.7 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.7 | +48.1 | 38.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.3 | +45.7 | 151.3 | 0.0 | 0.7 | +2.1 | 20.0 | 199.7 |
| PATHS CROSS | 0.7 | +2.1 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| PLAN RESULT | 54.0 | +735.1 | 316.3 | 315.3 | 43.0 | +201.3 | 206.0 | 1269.7 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 11.3 | -285.3 | 0.0 | 0.0 | 8.7 | -103.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -6.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 29.0 | +2771.2 | 245.3 | 40.0 | 15.7 | +2251.9 | 20.0 | 16.7 |
| RANDOM MOVE BY FIGURES | 2.7 | +67.3 | 0.0 | 118.3 | 2.7 | +47.1 | 0.0 | 170.0 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.7 | +194.3 | 0.0 | 46.0 | 1.0 | +31.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 6.0 | +5.8 | 0.0 | 24.0 | 2.3 | +0.0 | 0.0 | 15.0 |
| REDIRECT WEIGHED | 1.0 | +30.5 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.0 | -54.8 | 0.0 | 0.0 | 0.3 | -1.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 2.3 | +33.2 | 0.0 | 24.0 | 0.3 | +9.0 | 0.0 | 38.0 |
| RISK BY ARC | 4.0 | -81.9 | 323.7 | 0.0 | 3.0 | +2.8 | 182.0 | 216.3 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 3.0 | -67.0 | 210.7 | 0.0 | - | - | - | - |
| RUN DOWN | 5.0 | -152.0 | 351.7 | 0.0 | 0.7 | -1.1 | 0.0 | 16.7 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -25.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 52.7 |
| SECOND LOOK | 0.3 | +20.4 | 41.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.7 | -25.5 | 0.0 | 0.0 | 1.3 | -37.8 | 0.0 | 15.0 |
| SET UP BY THE SET | 1.7 | +25.4 | 0.0 | 0.0 | 2.7 | +34.0 | 0.0 | 214.7 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.3 | +0.0 | 0.0 | 63.3 | 3.3 | +0.0 | 0.0 | 36.7 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +53.3 | 41.7 | 86.7 | - | - | - | - |
| SHOT OR CHARGE | 2.0 | -19.3 | 88.3 | 20.0 | 0.3 | -4.5 | 0.0 | 36.7 |
| SHOT RISK POINTS | 26.7 | -123.8 | 0.0 | 44.0 | 32.3 | -341.5 | 0.0 | 887.7 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.0 | +291.8 | 0.0 | 109.3 | 5.7 | +183.0 | 0.0 | 121.3 |
| SPELL WORTH | 1.7 | +44.9 | 0.0 | 0.0 | 3.3 | +6.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.0 | -21.7 | 167.3 | 0.0 | 0.3 | -32.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 253.3 |
| STAND AND SHOOT | 2.0 | -18.1 | 263.3 | 0.0 | 1.0 | -1.6 | 22.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 48.7 | +0.0 | 791.0 | 293.0 | 22.0 | +0.0 | 24.0 | 111.3 |
| STAY WORTH | 21.0 | +72.5 | 569.3 | 0.0 | 7.7 | -59.5 | 24.0 | 289.0 |
| STRIKE BY THE ODDS | 1.0 | +337.5 | 52.7 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 10.0 | +426.6 | 0.0 | 0.0 | 2.7 | +581.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 46.7 | 0.0 | 0.7 | +0.0 | 22.0 | 0.0 |
| SUPPORT WORKED OUT | 10.0 | +426.6 | 0.0 | 0.0 | 2.7 | +581.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 22.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -6.1 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 21.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 54.0 | +0.0 | 0.0 | 109.3 | 38.3 | +0.0 | 0.0 | 454.3 |
| TIED UP BY THE SUM | 3.0 | +348.6 | 303.0 | 0.0 | 0.7 | +100.1 | 70.0 | 199.7 |
| TIME ON OUR SIDE | 54.3 | +450.6 | 226.7 | 137.3 | 5.7 | +55.6 | 0.0 | 0.0 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | +1.1 | 0.0 | 38.0 |
| WHO FIGHTS | 0.7 | +116.3 | 0.0 | 0.0 | 1.3 | +21.8 | 70.0 | 0.0 |
| WHO HITS BACK | 0.7 | +101.7 | 0.0 | 70.0 | 0.3 | +19.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.0 | -227.3 | 0.0 | 0.0 | 4.0 | -598.0 | 0.0 | 208.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +13.1 | 0.0 | 16.7 |
| WOUNDS ON THE RANKS | - | - | - | - | 8.0 | +115.2 | 0.0 | 105.3 |

### Rule changes: cora-bb45c30-p35

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 167 | 167 | 129 | 43.00 | +2629 | +20.4 |
| HOLDER ASSIGNMENT | 68 | 68 | 62 | 20.67 | +4141 | +66.8 |
| HIS SHOT LIST | 305 | 288 | 60 | 20.00 | +585 | +9.8 |
| LEGAL CHARGES ONLY | 54 | 54 | 54 | 18.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 266 | 255 | 37 | 12.33 | +497 | +13.4 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -866 | -28.9 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 50 | 45 | 28 | 9.33 | +2182 | +77.9 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| GOAL WALK | 65 | 65 | 25 | 8.33 | +1368 | +54.7 |
| REDIRECT FOR A FRIEND IN REACH | 25 | 25 | 25 | 8.33 | +11 | +0.4 |
| FIVE ACTION | 580 | 560 | 23 | 7.67 | +1592 | +69.2 |
| NEXT CHARGE BY LIST | 36 | 35 | 21 | 7.00 | +2030 | +96.7 |
| PROMISE BY ITS OWN SUM | 60 | 60 | 20 | 6.67 | -1167 | -58.4 |
| SHOT RISK POINTS | 177 | 171 | 20 | 6.67 | +93 | +4.7 |
| MOVE ORDER | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| QUARTER ODDS | 134 | 129 | 18 | 6.00 | +1586 | +88.1 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 180 | 154 | 14 | 4.67 | +42 | +3.0 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| FOUR ROUNDS | 28 | 27 | 11 | 3.67 | +635 | +57.7 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 11 | 3.67 | +84 | +7.7 |
| SUPPORT ADDS | 38 | 35 | 11 | 3.67 | +879 | +79.9 |
| SUPPORT WORKED OUT | 38 | 35 | 11 | 3.67 | +879 | +79.9 |
| CHARGE LOSSES | 128 | 122 | 10 | 3.33 | +1193 | +119.3 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| RESERVE FALL BACK | 8 | 8 | 8 | 2.67 | +126 | +15.8 |
| WHOLE FIGHT DANGER | 21 | 21 | 8 | 2.67 | +871 | +108.9 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | -101 | -14.5 |
| RANDOM MOVE BY FIGURES | 16 | 16 | 7 | 2.33 | +343 | +49.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +905 | +150.8 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| TIED UP BY THE SUM | 11 | 10 | 6 | 2.00 | +403 | +67.2 |
| COVER ONCE | 50 | 28 | 5 | 1.67 | +96 | +19.1 |
| IDLE COST | 56 | 33 | 5 | 1.67 | +13 | +2.5 |
| WOUNDS ON THE RANKS | 24 | 24 | 5 | 1.67 | +36 | +7.1 |
| CHARGE NOW FIRST | 14 | 14 | 4 | 1.33 | -166 | -41.6 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 13 | 12 | 4 | 1.33 | +252 | +63.0 |
| STAY WORTH | 86 | 80 | 4 | 1.33 | +33 | +8.2 |
| CAST JOB | 8 | 8 | 3 | 1.00 | +3 | +0.9 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +11 | +3.6 |
| EVASIVE BY THE ODDS | 6 | 6 | 3 | 1.00 | +784 | +261.4 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -34 | -11.3 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +16 | +5.4 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +92 | +30.5 |
| RISK BY ARC | 21 | 21 | 3 | 1.00 | +30 | +10.1 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +362 | +120.7 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +107 | +53.6 |
| FEATURE BUFFS | 8 | 8 | 2 | 0.67 | +70 | +34.8 |
| HIS MOVE AND SHOT | 30 | 30 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +18 | +9.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +163 | +81.6 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +74 | +37.2 |
| SHOTS IN THE MOVE | 89 | 74 | 2 | 0.67 | +98 | +48.8 |
| STRIKE BY THE ODDS | 3 | 3 | 2 | 0.67 | +314 | +157.2 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| BEST OVERALL | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -87 | -87.1 |
| EXACT ROUND | 21 | 21 | 1 | 0.33 | +309 | +308.6 |
| FALLS SHORT | 65 | 52 | 1 | 0.33 | +24 | +24.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +76 | +75.7 |
| HIS CHARGE DENIED | 4 | 3 | 1 | 0.33 | +9 | +9.0 |
| MAX FOR POSITIONING | 7 | 6 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 27 | 26 | 1 | 0.33 | +90 | +89.6 |
| ONE OBJECTIVE FORMULA | 36 | 28 | 1 | 0.33 | +30 | +29.6 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -14 | -13.9 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +9 | +9.0 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -2.4 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +2 | +1.9 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +61 | +61.2 |
| SHOTS AFTER THE MOVES | 17 | 17 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 4 | 4 | 1 | 0.33 | +9 | +9.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +26 | +26.3 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -2 | -1.9 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +3 | +3.2 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +26 | +26.1 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 20 | 20 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 44 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 41 | 40 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 23 | 22 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 75 | 72 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 38 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 33 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 54 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 75 | 74 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 8 | 8 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 108 | 108 | 0 | 0.00 | - | - |
| HONEST WORTH | 23 | 22 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 15 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 29 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEARER NOT NEEDED | 71 | 65 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | not checked | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 18 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 291 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 17 | 16 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 35 | not checked | - | - | - | - |
| SHOT OR CHARGE | 7 | 6 | 0 | 0.00 | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 49 | 42 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 9 | 9 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 212 | 205 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 18 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 21 | not checked | - | - | - | - |
| THE TABLE BINDS | 277 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p35

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 5.33 | 28.7 |
| ARMY TABLE | rule | 3.33 | 4.67 | 59.4 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 2.67 | 58.4 |
| CHARGE NOW FIRST | rule | 0.67 | 0.67 | 41.6 |
| JOINT CHARGE NOW | rule | 0.67 | 0.67 | 108.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 8.2 |
| MARCH OF THE TABLE | rule | 0.67 | - | 16.9 |
| NO REASON | gate | 0.67 | - | 20.6 |
| RULE SWITCHED OFF | gate | - | 0.67 | 38.6 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 87.1 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 13.9 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 2.4 |
| SET UP BY THE SET | rule | - | 0.33 | 35.2 |
| SUPPORT NARROWED | rule | 0.33 | - | 1.9 |

### Plans: cora-bb45c30-p35

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 69% | 1096 | 360 | 33% |
| Mine | move | 42.7 | 98% | 2960 | 0 | 0% |
| Mine | shoot | 6.3 | 47% | 392 | 375 | 96% |
| Mine | support | 0.7 | 100% | 6 | 0 | 0% |
| Opponent | charge | 3.0 | 44% | 310 | 120 | 39% |
| Opponent | join | 5.3 | 94% | 216 | 0 | 0% |
| Opponent | move | 31.3 | 94% | 1656 | 0 | 0% |
| Opponent | shoot | 3.0 | 56% | 67 | 81 | 121% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p35

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 21% | 67% | 0% | - | 0% | 0% | 0% | 67% | 33% |
| Opponent | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p35

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 15 (6) | 0 | 15 | 34 | 17% | 1.0 | - | 17 (5) | 0 (1) | 17 (5) | 0 (1) |
| Mine | Character | 7 | 32 (7) | 32 | 0 | 0 | 14% | 2.7 | 31 (4) | 42 (1) | 27 (2) | 34 (4) | 27 (3) |
| Mine | Clean-up | 1 | 878 (1) | 0 | 878 | 0 | 100% | - | - | 878 (1) | - | - | 878 (1) |
| Mine | Fast Hammer | 6 | 139 (6) | 139 | 0 | 0 | 50% | 4.0 | 104 (4) | 226 (2) | - | - | 139 (6) |
| Mine | Hammer | 5 | 79 (5) | 49 | 30 | 39 | 20% | 1.5 | 89 (3) | 66 (2) | - | 90 (2) | 74 (3) |
| Mine | Holder | 8 | 89 (8) | 12 | 77 | 0 | 38% | 1.8 | 139 (3) | 66 (4) | - | 245 (2) | 48 (5) |
| Mine | Shooter | 5 | 54 (5) | 11 | 43 | 30 | 0% | 1.8 | 0 (2) | 122 (3) | - | 51 (4) | 69 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 100 (4) | 0 | 100 | 50 | 75% | 4.0 | 133 (3) | - | 0 (1) | 133 (3) | 0 (1) |
| Opponent | Character | 11 | 0 (11) | 0 | 0 | 38 | 27% | 4.2 | 0 (2) | 0 (8) | - | 0 (6) | 0 (4) |
| Opponent | Fast Hammer | 6 | 17 (6) | 17 | 0 | 43 | 17% | 2.6 | - | 19 (5) | 0 (1) | 0 (3) | 28 (3) |
| Opponent | Hammer | 8 | 19 (8) | 19 | 0 | 45 | 12% | 4.3 | 0 (3) | 30 (5) | - | 25 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 0 | 67% | 4.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | Shooter | 3 | 49 (3) | 0 | 49 | 100 | 0% | 1.0 | - | 71 (2) | 0 (1) | 72 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: cora-bb45c30-p35

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 45 | 261 | 2.0 | 1.0 | 130 | 0 | +130 | 0 of 2 | 2 of 2 | - | +130 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 546 | 4.5 | 1.0 | 121 | 0 | +121 | 2 of 9 | 8 of 9 | - | +121 |
| **Mine** | all armies | 3 | 15 | 451 | 3.7 | 1.0 | 123 | 0 | +123 | 2 of 11 | 10 of 11 | - | +123 |
| Opponent | Vampire Counts | 1 | 210 | 210 | 2.0 | 1.0 | 105 | 93 | +12 | 1 of 2 | 1 of 2 | - | +12 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 170 | -170 | 1 of 1 | 0 of 1 | - | -170 |
| Opponent | Wood Elf Realms | 1 | 0 | 126 | 4.0 | 1.0 | 32 | 150 | -118 | 1 of 4 | 3 of 4 | - | -118 |
| **Opponent** | all armies | 3 | 70 | 112 | 2.3 | 1.0 | 48 | 136 | -88 | 3 of 7 | 4 of 7 | - | -88 |

### Effective charges: cora-bb45c30-p35

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 2 | 0 | 0 | 0 | 1 (net +186) | 0 | 1 (net +75) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 9 | 0 | 0 | 0 | 2 (net +216) | 3 (net +38) | 3 (net +140) | 1 | 0% (0 of 8) |
| Opponent | Vampire Counts | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +24) | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 0 | 2 (net +30) | 0 | 2 (net -266) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: cora-bb45c30-p35

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 3 | 314 | 182 | +206 | 232 | 56 | +176 | +56.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 202 | 124 | +124 | 139 | 7 | +132 | +65.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 440 | 126 | +38 | 56 | 33 | +23 | +5.3 |
| Mine | No odds | 1 | 431 | 125 | +125 | 125 | 48 | +77 | +17.9 |
| Mine | All fights | 11 | 318 | 140 | +123 | 140 | 31 | +109 | +34.4 |
| Opponent | Long shot (under 50%) | 1 | 50 | 145 | +0 | 29 | 17 | +12 | +24.7 |
| Opponent | 76-89% | 2 | 102 | 60 | +30 | 42 | 8 | +34 | +33.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 262 | 157 | -170 | 92 | 262 | -170 | -64.7 |
| Opponent | No odds | 1 | 120 | 411 | -170 | 0 | 319 | -319 | -266.1 |
| Opponent | All fights | 7 | 166 | 164 | -88 | 56 | 163 | -107 | -64.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p35 | move | 25 | 7 (28%) | 6 (24%) | 4 (16%) | 14 (56%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

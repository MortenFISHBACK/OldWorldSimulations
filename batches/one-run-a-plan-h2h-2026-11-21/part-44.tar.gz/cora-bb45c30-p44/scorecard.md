# Doctrine scorecard: cora-bb45c30-p44

### Scorecard: cora-bb45c30-p44

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 3 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 6 | 1 | 2 | 1 | 0 | 0 | 77 |
| L1435 | 1 | 1 | Mine | no | 4 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 3 | 0 | 0 | 0 | 126 |
| **Average** | | | Mine | 0% | 3.5 | 2.0 | 3.3 | 1.7 | 1.0 | 0.0 | 0.0 | 46.7 |
| **Average** | | | Opponent | 50% | 0.0 | 3.0 | 2.7 | 2.0 | 0.7 | 0.0 | 0.0 | 89.7 |

### KPIs: cora-bb45c30-p44

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 16) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 33% (1 of 3); on the table 33% | 50% (2 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 100% (6 of 6); on the table 100% | 50% (3 of 6); on the table 50% | 75% (9 of 12); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 17% (3 of 18) | - | 17% (3 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (3 of 9) | - | 33% (3 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 45% (2715 of 6000) | 42% (2498 of 6000) | 43% (5213 of 12000) |
|   infantry points that never fought | lower | 75% (693 of 923) | 70% (817 of 1159) | 73% (1510 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (13 of 26) | 58% (14 of 24) | 54% (27 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 100% (2 of 2); 3.0 uses a game | 100% (3 of 3); 2.2 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 1.7 uses a game | 0.0 uses a game | 29% (4 of 14); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 37% (2139 of 5860) | 55% (2808 of 5131) | 45% (4947 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (13%) | - | 0.7 (13%) |
| MARCHED: its unit marched | 1.3 (27%) | - | 1.3 (27%) |
| IN COMBAT: engaged in combat | 0.3 (7%) | - | 0.3 (7%) |
| GONE: slain | 2.7 (53%) | - | 2.7 (53%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 3.0 | 2.7 | 1.0 | 1.3 |
| not cast | 3.0 | 7.0 | 5.3 | 5.0 | 26.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (43%) | 0.0 (0%) | 0.7 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (27%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.3 (7%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (67%) | 2.0 (29%) | 2.0 (38%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (22%) | 2.0 (29%) | 2.7 (50%) | 2.7 (53%) | 10.3 (39%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (11%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.0 (56%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 62% (5 of 8) | - | 62% (5 of 8) |
| the unit moved after it | 20% (1 of 5) | - | 20% (1 of 5) |
| it charged on its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| the enemy charged it first | 20% (1 of 5) | - | 20% (1 of 5) |
| it fought by the end of its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (1 of 5) | - | 20% (1 of 5) |
| none of these (no charge, no fight, no charge escaped) | 40% (2 of 5) | - | 40% (2 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (53 of 80) | 66% (65 of 99) | 66% (118 of 179) |
|   cavalry | 57% (13 of 23) | 94% (15 of 16) | 72% (28 of 39) |
|   character | 24% (5 of 21) | 31% (5 of 16) | 27% (10 of 37) |
|   chariot | - | 67% (8 of 12) | 67% (8 of 12) |
|   infantry | 100% (24 of 24) | 65% (28 of 43) | 78% (52 of 67) |
|   monster | - | 75% (9 of 12) | 75% (9 of 12) |
|   war machine | 92% (11 of 12) | - | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (11%) | 1.0 (9%) | 2.0 (10%) |
| CHARGED: it charged | 2.7 (30%) | 3.3 (29%) | 6.0 (30%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 2.7 (30%) | 3.7 (32%) | 6.3 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (26%) | 2.0 (18%) | 4.3 (21%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.7 | 3.3 | 80% | 8.4 pts | 123 pts |
| character | 5.3 | 1.0 | 81% | 4.4 pts | 24 pts |
| chariot | 2.7 | 0.7 | 88% | 15.6 pts | 42 pts |
| infantry | 26.0 | 6.7 | 81% | 11.8 pts | 308 pts |
| monster | 3.3 | 2.3 | 60% | 42.1 pts | 140 pts |
| war machine | 3.7 | 1.0 | 73% | 10.3 pts | 38 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 5.7 | 4.8 |
| Charges that made contact a game | 3.7 | 3.3 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | - | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.43 contact (23 units) | 0.52 declared, 0.30 contact (33 units) | 0.50 declared, 0.36 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 65% (11 of 17) | - | - | 65% (11 of 17) |
| Character in a unit | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Character on its own | - | 50% (2 of 4) | 25% (2 of 8) | 33% (4 of 12) |
| Chariot | 0% (0 of 2) | - | - | 0% (0 of 2) |
| Infantry | 70% (7 of 10) | 0% (0 of 1) | - | 64% (7 of 11) |
| Monster | 50% (1 of 2) | 0% (0 of 1) | - | 33% (1 of 3) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 100% (6 of 6); on the table 100% | 17% (3 of 18) | 45% | 50% (13 of 26) | 100% (1 of 1); 1.3 uses a game | 29% (4 of 14); 1.7 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 33% (1 of 3); on the table 33% | - | 19% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 67% (2 of 3); on the table 67% | - | 24% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 82% | 67% (8 of 12) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p44, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 25% (1) | 38% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p44

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 73% (8 of 11) | 57% (8 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (12 of 33) | 54% (14 of 26) |
| Strategy | Support requests answered (helper made contact too) | - | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 2) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 1.7 | 2.0 |
| Movement | Points that never moved of their own | 46.7 | 89.7 |
| Movement | Fights charged into per game | 3.7 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 9 | 1 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 9, net +320 | 1 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 9, net +69 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 9, net +0 | 4 of 6, net +206 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.7 | 24.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (18 of 50) | 74% (53 of 72) |
| Shooting | Points destroyed by shooting units | 180.0 | 333.3 |
| Shooting | War machine shots | 3.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (7 of 11) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | - |
| Magic | Wounds caused by magic missiles | 0.7 | 2.0 |
| Magic | Wounds caused by other spells | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 34.7 | 47.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.3 / 0.7 / 0.0 | 3.3 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 398.7 | 324.7 |
| Combat | Points run down | 0.0 | 50.3 |
| Combat | Net points per charged fight, damage counted | +114 | +152 |
| Combat | Net per 100 charger points, damage counted | +33.7 | +40.8 |
| Combat | First round won (charged fights) | 100% | 71% |
| Combat | Net points per charged fight | +119 | +139 |
| Combat | Net points per supported fight / lone fight | - / +119 | +72 / +166 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 11 | 2 of 7 |
| Game | Points lost | 780.3 | 597.0 |
| Game | VP from objectives | 440.0 | 800.0 |
| Game | Lone holders (player turns) | 3.5 | 0.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -444 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1377
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p44

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +15.7 | 0.0 | 0.0 |
| ARMY TABLE | 27.7 | +357.4 | 0.0 | 762.3 | 31.0 | +438.1 | 0.0 | 200.7 |
| ASSAILMENT BY POINTS | 1.0 | +6.0 | 0.0 | 181.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.4 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | +25.8 | 0.0 | 0.0 | 0.7 | -21.1 | 41.0 | 0.0 |
| BOUND ASSAILMENT | 0.3 | +0.0 | 0.0 | 50.3 | - | - | - | - |
| CANNON PLANNED TARGET | 3.7 | +16.3 | 360.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -19.7 | 0.0 | 0.0 | 0.7 | -12.0 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +19.2 | 66.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 433.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +9.4 | 0.0 | 11.3 |
| CHALLENGE BY POINTS | 0.7 | +36.7 | 0.0 | 50.3 | 0.7 | +78.8 | 0.0 | 41.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -1.3 | 25.7 | 0.0 | 0.3 | -3.0 | 50.3 | 0.0 |
| CHARGE LIST READ AGAIN | 0.3 | +5.2 | 22.0 | 0.0 | 0.7 | +89.4 | 95.3 | 78.0 |
| CHARGE LOSSES | 24.0 | -1580.7 | 0.0 | 1393.3 | 13.7 | -488.9 | 0.0 | 46.7 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 130.3 | 0.0 | 2.7 | +0.0 | 324.7 | 180.0 |
| CHARGER SLAIN LOST | 0.3 | -0.4 | 25.7 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 11.3 |
| CONVEYANCE SEARCH | 2.7 | +338.4 | 433.3 | 600.0 | - | - | - | - |
| COVER ONCE | 9.0 | -377.5 | 0.0 | 312.3 | 9.7 | -1091.9 | 0.0 | 185.0 |
| DENIED BY THE FIGHT | 0.7 | -1.2 | 78.0 | 0.0 | 1.3 | -1.5 | 190.7 | 78.0 |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 47.7 | 9.3 | +8.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -82.5 | 0.0 | 0.0 | 0.3 | -62.1 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | 0.3 | +2.0 | 0.0 | 0.0 | 4.0 | +111.1 | 82.0 | 41.7 |
| EXACT ROUND | 1.3 | +9.5 | 84.7 | 0.0 | 3.3 | +53.9 | 372.3 | 281.3 |
| FALL BACK GOOD ORDER | 3.3 | +35.7 | 219.0 | 0.0 | 4.7 | +9.4 | 475.0 | 281.3 |
| FALLS SHORT | 12.3 | +137.6 | 0.0 | 255.3 | 14.3 | +140.6 | 0.0 | 107.3 |
| FEATURE BUFFS | 0.7 | +4.6 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.3 | 25.7 | 0.0 | 0.7 | +38.7 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 0.0 | 41.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 92.7 | +3610.2 | 1959.0 | 2210.0 | 101.3 | +9515.8 | 3875.3 | 1030.0 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 292.0 | 10.0 | +0.0 | 0.0 | 112.7 |
| FOCUS FIRE | 0.3 | +10.6 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +237.7 | 0.0 | 0.0 | 1.0 | +129.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.7 | +226.8 | 230.3 | 0.0 | 5.3 | +293.9 | 616.0 | 281.3 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 122.7 |
| FRIEND CHARGES FIRST | 0.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.3 | -270.9 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +43.0 | 0.0 | 0.0 | 0.3 | +15.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -20.9 | 0.0 | 23.3 |
| GOAL WALK | 5.0 | +390.2 | 0.0 | 0.0 | 8.7 | +479.3 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +57.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 145.7 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 46.7 |
| HIS CHARGE BY HIS RUN | 17.3 | +0.0 | 0.0 | 1060.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 1.7 | +160.4 | 238.3 | 78.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 362.0 | 3.7 | +0.0 | 0.0 | 22.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 262.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 8.7 | -224.7 | 0.0 | 815.0 | 5.3 | -69.1 | 0.0 | 0.0 |
| HIS ONE QUARTER | 9.7 | +0.0 | 0.0 | 182.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 8.0 | +0.0 | 0.0 | 262.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 57.3 | +3466.3 | 0.0 | 1794.7 | 56.0 | +1792.2 | 0.0 | 426.0 |
| HIS SHOTS BY HIS RUN | 53.7 | +1745.4 | 0.0 | 2128.0 | 51.7 | +972.5 | 0.0 | 240.7 |
| HIS TURN DENIED | 1.7 | +52.4 | 158.0 | 0.0 | 0.7 | +9.5 | 0.0 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 44.0 |
| HOLDER ASSIGNMENT | 9.0 | +985.4 | 0.0 | 0.0 | 8.0 | +618.3 | 0.0 | 22.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -180.5 | 152.3 | 0.0 | 3.7 | -118.5 | 467.7 | 258.0 |
| IDLE COST | 6.7 | -91.6 | 0.0 | 0.0 | 10.7 | -128.6 | 0.0 | 87.0 |
| JOINT CHARGE NOW | - | - | - | - | 2.0 | -16.5 | 241.0 | 78.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +80.8 | 47.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.7 | +0.0 | 78.0 | 276.0 | 4.3 | +0.0 | 381.0 | 149.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | -1.2 | 98.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +0.4 | 117.0 | 0.0 | 1.7 | -0.6 | 241.0 | 78.0 |
| LURE BY WHAT IT DRAWS | 1.3 | -338.7 | 0.0 | 0.0 | 0.3 | -56.3 | 0.0 | 11.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +122.6 | 0.0 | 13.3 |
| MARCH BY THE SUM | 0.7 | +36.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +87.3 | 0.0 | 166.7 | 0.3 | +15.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +186.4 | 0.0 | 300.0 | 0.3 | -18.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +21.0 | 0.0 | 214.3 | 3.0 | +133.7 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 47.7 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +36.8 | 0.0 | 166.7 | 3.0 | +113.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +30.7 | 0.0 | 600.0 | 3.3 | +96.9 | 0.0 | 0.0 |
| MOVE ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 22.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 266.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.3 | +694.2 | 0.0 | 143.0 | 7.0 | +690.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +253.1 | 0.0 | 0.0 | 10.0 | +390.8 | 0.0 | 84.7 |
| NEXT CHARGE BY LIST | 5.3 | +471.1 | 0.0 | 143.0 | 4.7 | +478.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -0.0 | 0.0 | 0.0 | 0.3 | -46.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -75.2 | 208.3 | 0.0 | 5.0 | -185.1 | 616.0 | 281.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +1.3 | 0.0 | 93.3 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -179.0 | 0.0 | 98.0 | 3.0 | -143.1 | 0.0 | 42.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +0.7 | 50.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -147.4 | 0.0 | 312.3 | 6.0 | -129.4 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.3 | +85.6 | 143.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | +11.7 | 0.0 | 0.0 | 2.7 | -126.7 | 0.0 | 22.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 1.0 | +74.7 | 49.3 | 0.0 | 0.7 | +48.9 | 0.0 | 0.0 |
| OVERRUNS AWAY | 2.0 | +36.5 | 82.7 | 0.0 | 2.0 | +84.9 | 372.3 | 258.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +7.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.7 | -30.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 42.7 | +1060.7 | 607.3 | 1312.0 | 46.7 | +1647.6 | 1299.0 | 960.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 11.7 | -279.8 | 0.0 | 0.0 | 8.7 | -370.2 | 0.0 | 42.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | -0.5 | 0.0 | 0.0 | 1.0 | -13.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -5.8 | 0.0 | 0.0 |
| QUARTER ODDS | 16.3 | +1034.6 | 38.0 | 384.0 | 17.0 | +2566.1 | 513.0 | 23.3 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +307.9 | 0.0 | 68.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.0 | +0.0 | 0.0 | 105.7 |
| REDIRECT WEIGHED | 0.7 | +32.6 | 41.7 | 0.0 | 0.3 | +3.4 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.3 | -137.2 | 0.0 | 0.0 | 2.7 | -51.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +17.6 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | -179.6 | 152.3 | 0.0 | 3.7 | -34.4 | 467.7 | 203.3 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -58.8 | 38.0 | 0.0 | 2.7 | -27.3 | 274.3 | 258.0 |
| RUN DOWN | 2.0 | -21.6 | 117.0 | 0.0 | 4.3 | -5.1 | 616.0 | 258.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -24.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +20.1 | 0.0 | 0.0 | 1.3 | +75.8 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +24.3 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -13.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | -0.5 | 0.0 | 0.0 | 1.3 | +14.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +91.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.3 | +0.0 | 0.0 | 41.0 | 11.0 | +0.0 | 0.0 | 157.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +45.9 | 0.0 | 0.0 | 4.0 | +303.7 | 788.7 | 0.0 |
| SHOT OR CHARGE | 1.3 | -10.3 | 22.7 | 41.0 | 0.3 | -15.6 | 93.3 | 0.0 |
| SHOT RISK POINTS | 39.3 | -480.2 | 0.0 | 1428.0 | 21.3 | +38.2 | 0.0 | 190.0 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.0 | +397.6 | 0.0 | 248.7 | 21.7 | +1517.6 | 0.0 | 261.0 |
| SPELL SETS UP CHARGE | 1.0 | +174.2 | 0.0 | 166.7 | - | - | - | - |
| SPELL WORTH | 1.3 | +26.7 | 266.7 | 266.7 | 1.7 | +33.6 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +3.0 | 78.0 | 0.0 | 2.0 | -17.7 | 241.0 | 101.3 |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 347.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.7 | -3.7 | 22.0 | 0.0 | 0.7 | -3.3 | 0.0 | 0.0 |
| STANDS FOR A REASON | 2.3 | +0.0 | 0.0 | 82.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 40.7 | +0.0 | 1728.7 | 636.0 | 39.0 | +0.0 | 3259.3 | 487.3 |
| STAY WORTH | 26.0 | +81.4 | 648.7 | 123.0 | 21.3 | +388.4 | 1280.0 | 0.0 |
| SUPPORT ADDS | 6.7 | +394.7 | 0.0 | 95.3 | 8.3 | +505.3 | 0.0 | 46.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 42.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 6.7 | +394.7 | 0.0 | 95.3 | 8.3 | +505.3 | 0.0 | 46.0 |
| SURE REACH TOGETHER | 0.7 | +5.4 | 0.0 | 166.7 | 1.7 | +30.3 | 0.0 | 44.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.7 | +0.0 | 0.0 | 1021.7 | 48.0 | +0.0 | 0.0 | 374.3 |
| TIED UP BY THE SUM | 2.3 | +225.1 | 126.7 | 0.0 | 1.3 | +151.7 | 141.0 | 0.0 |
| TIME ON OUR SIDE | 26.0 | +307.5 | 44.0 | 747.7 | 29.3 | +323.4 | 0.0 | 317.3 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -20.7 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | - | - | - | - | 0.7 | +36.3 | 95.3 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | -6.1 | 50.3 | 0.0 |
| WHO HITS BACK | 0.7 | +15.6 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -117.9 | 0.0 | 214.3 | 2.0 | -236.9 | 0.0 | 46.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +54.5 | 47.7 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 0.3 | +10.1 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p44

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 176 | 176 | 134 | 44.67 | +1585 | +11.8 |
| HIS SHOT LIST | 340 | 316 | 88 | 29.33 | +1845 | +21.0 |
| HIS SHOTS BY HIS RUN | 316 | 291 | 78 | 26.00 | +1456 | +18.7 |
| HOLDER ASSIGNMENT | 51 | 51 | 47 | 15.67 | +2933 | +62.4 |
| SHOT RISK POINTS | 182 | 167 | 36 | 12.00 | +1092 | +30.3 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| FIVE ACTION | 582 | 553 | 28 | 9.33 | +1280 | +45.7 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 46 | 37 | 26 | 8.67 | +827 | +31.8 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -967 | -40.3 |
| PROMISE BY ITS OWN SUM | 61 | 61 | 24 | 8.00 | -1949 | -81.2 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| QUARTER ODDS | 100 | 93 | 18 | 6.00 | +1439 | +80.0 |
| TIME ON OUR SIDE | 166 | 142 | 18 | 6.00 | +68 | +3.8 |
| SHOTS IN THE MOVE | 122 | 99 | 16 | 5.33 | +577 | +36.1 |
| NEXT CHARGE BY LIST | 30 | 25 | 15 | 5.00 | +454 | +30.3 |
| STAY WORTH | 142 | 133 | 15 | 5.00 | +74 | +5.0 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| SUPPORT ADDS | 45 | 43 | 14 | 4.67 | +283 | +20.2 |
| SUPPORT WORKED OUT | 45 | 43 | 14 | 4.67 | +283 | +20.2 |
| CHARGE LOSSES | 113 | 101 | 13 | 4.33 | +720 | +55.4 |
| GOAL WALK | 41 | 41 | 13 | 4.33 | +396 | +30.5 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 12 | 4.00 | +299 | +24.9 |
| FOUR ROUNDS | 27 | 25 | 11 | 3.67 | +392 | +35.6 |
| CHARGE NOW FIRST | 16 | 16 | 10 | 3.33 | -620 | -62.0 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 11 | 11 | 9 | 3.00 | +316 | +35.1 |
| COVER ONCE | 56 | 35 | 8 | 2.67 | +269 | +33.6 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| EVASIVE BY THE ODDS | 13 | 13 | 7 | 2.33 | +222 | +31.7 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1100 | +183.3 |
| IDLE COST | 52 | 41 | 6 | 2.00 | +53 | +8.8 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | -50 | -8.2 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +288 | +57.5 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +346 | +86.6 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 5 | 5 | 4 | 1.33 | +184 | +45.9 |
| OVERRUNS AWAY | 12 | 11 | 4 | 1.33 | +223 | +55.8 |
| SHOTS AFTER THE MOVES | 30 | 30 | 4 | 1.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +18 | +6.1 |
| BEST PRIZE | 3 | 3 | 3 | 1.00 | -120 | -39.9 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +27 | +8.9 |
| CHARGE LIST READ AGAIN | 3 | 3 | 3 | 1.00 | +284 | +94.6 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -309 | -103.0 |
| NO DOUBLE ROUNDS | 25 | 24 | 3 | 1.00 | +131 | +43.6 |
| OPENS UP | 5 | 5 | 3 | 1.00 | +112 | +37.4 |
| PROMISE KNOWS THE FIGHT | 8 | 4 | 3 | 1.00 | -41 | -13.5 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +118 | +39.4 |
| SURE REACH TOGETHER | 7 | 7 | 3 | 1.00 | +7 | +2.4 |
| WHOLE FIGHT DANGER | 12 | 12 | 3 | 1.00 | +145 | +48.4 |
| CARRIES OUT SET-UP | 3 | 3 | 2 | 0.67 | -95 | -47.5 |
| EXACT ROUND | 14 | 14 | 2 | 0.67 | +3 | +1.4 |
| FALL BACK GOOD ORDER | 24 | 22 | 2 | 0.67 | +1 | +0.5 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +174 | +87.2 |
| HIS MOVE AND SHOT | 42 | 40 | 2 | 0.67 | +197 | +98.7 |
| HIS TURN DENIED | 7 | 7 | 2 | 0.67 | +56 | +28.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 13 | 13 | 2 | 0.67 | +384 | +192.2 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +109 | +54.4 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -90 | -45.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +53 | +26.4 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +73 | +36.5 |
| SET UP BY THE SET | 6 | 5 | 2 | 0.67 | +11 | +5.3 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| THE ROW IN ITS ORDER | 16 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +47 | +23.4 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +47 | +47.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| CANNON PLANNED TARGET | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 80 | 70 | 1 | 0.33 | +4 | +3.5 |
| FIGHT TO THE END | 3 | 2 | 1 | 0.33 | +3 | +2.8 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +32 | +31.8 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +242 | +242.4 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| LOST AFTER ESCAPE | 11 | 10 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 50 | 49 | 1 | 0.33 | +27 | +26.8 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 35 | 17 | 1 | 0.33 | +2 | +2.1 |
| ONE JOINT FIGURE | 4 | 3 | 1 | 0.33 | +28 | +28.4 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +22 | +21.9 |
| REDIRECT COUNTER | 9 | 8 | 1 | 0.33 | +60 | +59.5 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -65 | -64.7 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +7.4 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -62 | -62.0 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.33 | +28 | +28.4 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 1 | 1 | 1 | 0.33 | +15 | +15.4 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 53 | 52 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 28 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 22 | 20 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 78 | 71 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 21 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 28 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 39 | 35 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 45 | 39 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 77 | 77 | 0 | 0.00 | - | - |
| HONEST WORTH | 21 | 20 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 13 | 10 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 15 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 23 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 268 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 15 | 13 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 21 | 20 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 12 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 67 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 30 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 239 | 222 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 16 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 278 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p44

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 5.33 | 3.00 | 44.2 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | 3.33 | 81.2 |
| JOB FIRST | gate | 4.33 | 2.33 | 33.7 |
| CHARGE NOW FIRST | rule | 2.33 | 1.00 | 62.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.33 | 43.5 |
| JOINT CHARGE NOW | rule | - | 1.67 | 58.4 |
| BEST PRIZE | rule | 0.33 | 0.67 | 39.9 |
| MARCH OF THE TABLE | rule | 0.67 | 0.33 | 103.0 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.67 | 13.5 |
| CARRIES OUT SET-UP | rule | 0.33 | 0.33 | 47.5 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| NO REASON | gate | 0.67 | - | 45.7 |
| PIVOT GUARDS FLANK | rule | 0.67 | - | 45.1 |
| RULE SWITCHED OFF | gate | - | 0.67 | 100.6 |
| REDIRECT WEIGHED | rule | - | 0.33 | 14.8 |
| SUPPORT NARROWED | rule | 0.33 | - | 64.7 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 62.0 |

### Plans: cora-bb45c30-p44

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 80% | 462 | 252 | 55% |
| Mine | move | 29.3 | 92% | 1367 | 0 | 0% |
| Mine | shoot | 9.3 | 71% | 213 | 809 | 379% |
| Mine | support | 0.7 | 100% | 0 | 0 | - |
| Opponent | charge | 3.3 | 40% | 555 | 414 | 75% |
| Opponent | move | 35.7 | 94% | 2498 | 0 | 0% |
| Opponent | shoot | 7.3 | 68% | 1071 | 1234 | 115% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p44

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 56% | 60% | 0% | - | 0% | 0% | 0% | 80% | 20% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p44

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 40 (7) | 40 | 0 | 47 | 0% | 1.6 | 28 (5) | 119 (1) | 7 (1) | 18 (5) | 84 (2) |
| Mine | Clean-up | 1 | 39 (1) | 0 | 39 | 122 | 0% | 2.0 | 39 (1) | - | - | 39 (1) | - |
| Mine | Fast Hammer | 14 | 55 (14) | 10 | 45 | 36 | 43% | 3.8 | 29 (8) | 91 (6) | - | 54 (9) | 56 (5) |
| Mine | Shooter | 4 | 78 (4) | 78 | 0 | 0 | 0% | 1.0 | 105 (3) | 0 (1) | - | 105 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 7 | 204 (7) | 0 | 204 | 89 | 29% | 2.4 | - | 402 (4) | 16 (3) | 473 (4) | 14 (3) |
| Opponent | Character | 4 | 34 (4) | 34 | 0 | 34 | 0% | 1.5 | - | 34 (4) | - | 0 (2) | 63 (2) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 20 | 75% | 5.0 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 42 (4) | 42 | 0 | 19 | 0% | 2.2 | 79 (2) | 0 (2) | - | 58 (3) | 0 (1) |
| Opponent | Hammer | 8 | 60 (8) | 60 | 0 | 24 | 25% | 2.7 | 17 (2) | 80 (3) | 73 (3) | 67 (4) | 55 (4) |
| Opponent | Holder | 3 | 141 (3) | 0 | 141 | 31 | 0% | 2.0 | 450 (1) | 0 (1) | 0 (1) | 450 (1) | 0 (2) |
| Opponent | Shooter | 4 | 118 (4) | 91 | 27 | 21 | 0% | 1.2 | 0 (1) | 256 (2) | 0 (1) | 54 (2) | 163 (2) |
| Opponent | Wizard | 3 | 21 (3) | 21 | 0 | 61 | 0% | 1.7 | 39 (2) | - | - | 52 (1) | 0 (1) |

### Charged fights: cora-bb45c30-p44

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 215 | 438 | 3.7 | 1.0 | 119 | 0 | +119 | 2 of 11 | 11 of 11 | - | +119 |
| Opponent | Ogre Kingdoms | 1 | 500 | 143 | 1.0 | 3.0 | 143 | 0 | +143 | 0 of 1 | 1 of 1 | +143 | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 831 | 6.0 | 1.2 | 138 | 0 | +138 | 2 of 6 | 4 of 6 | +0 | +166 |
| Opponent | Wood Elf Realms | 1 | 643 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 381 | 325 | 2.3 | 1.4 | 139 | 0 | +139 | 2 of 7 | 5 of 7 | +72 | +166 |

### Effective charges: cora-bb45c30-p44

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 11 | 0 | 0 | 2 (net +320) | 1 (net +77) | 5 (net +69) | 1 (net +0) | 2 | 22% (2 of 9) |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +143) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 3 (net +227) | 1 | 20% (1 of 5) |

### Charged fights, damage counted: cora-bb45c30-p44

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 316 | 266 | +320 | 394 | 0 | +394 | +124.6 |
| Mine | 76-89% | 1 | 143 | 77 | +77 | 77 | 0 | +77 | +53.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 489 | 251 | +0 | 167 | 0 | +167 | +34.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 294 | 69 | +69 | 80 | 48 | +32 | +10.8 |
| Mine | No odds | 2 | 494 | 126 | +126 | 126 | 94 | +32 | +6.4 |
| Mine | All fights | 11 | 338 | 132 | +119 | 153 | 39 | +114 | +33.7 |
| Opponent | Long shot (under 50%) | 1 | 70 | 151 | +0 | 60 | 0 | +60 | +86.3 |
| Opponent | Effective (55-75%) | 1 | 626 | 230 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 371 | 293 | +206 | 263 | 49 | +213 | +57.5 |
| Opponent | No odds | 1 | 431 | 151 | +151 | 151 | 0 | +151 | +35.0 |
| Opponent | All fights | 7 | 373 | 244 | +139 | 180 | 28 | +152 | +40.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p44 | move | 25 | 7 (28%) | 5 (20%) | 5 (20%) | 13 (52%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

# Doctrine scorecard: cora-bb45c30-p12

### Scorecard: cora-bb45c30-p12

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | no | - | 3 | 2 | 3 | 1 | 0 | 0 | 211 |
| L2531 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 6 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 3 | 4 | 1 | 0 | 1 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.5 | 3.0 | 2.7 | 2.0 | 0.7 | 0.0 | 0.0 | 127.0 |
| **Average** | | | Opponent | 33% | 2.5 | 2.0 | 4.0 | 2.3 | 0.0 | 0.0 | 0.0 | 56.7 |

### KPIs: cora-bb45c30-p12

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 17) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 50% (2 of 4); on the table 50% | 50% (3 of 6); on the table 50% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 50% (1 of 2); on the table 50% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 80% | 57% (4 of 7); on the table 57% | 58% (7 of 12); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 33% (2 of 6) | 50% (6 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (4 of 6) | 50% (2 of 4) | 60% (6 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (2 of 2) | 71% (5 of 7) | 78% (7 of 9) |
| Points that never fought | lower | 28% (1658 of 5998) | 27% (1638 of 5998) | 27% (3296 of 11996) |
|   infantry points that never fought | lower | 34% (310 of 902) | 53% (568 of 1072) | 44% (878 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (13 of 19) | 62% (16 of 26) | 64% (29 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (3439 of 5038) | 56% (3020 of 5360) | 62% (6459 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (100%) | 0.3 (25%) | 1.0 (50%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (25%) | 0.3 (17%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (50%) | 0.7 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 1.3 | 2.0 | 2.0 | 0.7 | 2.0 |
| not cast | 4.3 | 0.0 | 2.0 | 2.0 | 1.3 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.0 (50%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (12%) |
| STUPIDITY: Stupidity | 0.3 (8%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (92%) | - | 1.7 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 83% (5 of 6) | - | 83% (5 of 6) |
| the unit moved after it | 100% (5 of 5) | - | 100% (5 of 5) |
| it charged on its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| the enemy charged it first | 0% (0 of 5) | - | 0% (0 of 5) |
| it fought by the end of its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 80% (4 of 5) | - | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 17% (1 of 6) | 70% (26 of 37) | 63% (27 of 43) |
|   cavalry | 50% (1 of 2) | 92% (11 of 12) | 86% (12 of 14) |
|   character | 0% (0 of 4) | 23% (3 of 13) | 18% (3 of 17) |
|   infantry | - | 100% (12 of 12) | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| CHARGED: it charged | 1.0 (60%) | 3.3 (91%) | 4.3 (81%) |
| NO TARGET IN RANGE | 0.7 (40%) | 0.3 (9%) | 1.0 (19%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 1.3 | 83% | 2.2 pts | 17 pts |
| character | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 6.3 | 1.0 | 84% | 3.5 pts | 22 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 6.3 | 5.2 |
| Charges that made contact a game | 3.0 | 5.0 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.60 declared, 0.60 contact (5 units) | 0.00 declared, 0.00 contact (1 units) | 0.50 declared, 0.50 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.27 contact (22 units) | 0.76 declared, 0.60 contact (25 units) | 0.60 declared, 0.45 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (3 of 7) | 80% (4 of 5) | 0% (0 of 1) | 54% (7 of 13) |
| Character in a unit | 100% (5 of 5) | - | 0% (0 of 1) | 83% (5 of 6) |
| Character on its own | 0% (0 of 2) | 100% (3 of 3) | 57% (4 of 7) | 58% (7 of 12) |
| Infantry | 57% (4 of 7) | 100% (1 of 1) | - | 62% (5 of 8) |
| Monster | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 75% (3 of 4); on the table 100% | 67% (4 of 6) | 36% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 25% (1 of 4); on the table 25% | 33% (2 of 6) | 19% | 76% (19 of 25) | 100% (1 of 1); 0.7 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 75% (3 of 4); on the table 75% | - | 36% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p12, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 71% (10) | 50% (4) | 64% (14) |
| ...free all their last turn and able to turn (per game) | 2.67 | 1.33 | 4.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.67 | 1.00 | 2.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.33 | 0.67 |

### Quality by phase: cora-bb45c30-p12

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (5 of 10) | 62% (10 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 1) | 44% (4 of 9) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 20% (1 of 5) | 67% (2 of 3) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.7 | 0.3 |
| Movement | Idle units | 2.0 | 2.3 |
| Movement | Points that never moved of their own | 127.0 | 56.7 |
| Movement | Fights charged into per game | 3.0 | 5.0 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 7, net -193 | 1 of 11, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 11 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 7, net +0 | 2 of 11, net +128 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 7, net +138 | 2 of 11, net +102 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.0 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | 39% (12 of 31) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 100% (1 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 0.7 / 0.3 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 38.7 | 535.3 |
| Combat | Points run down | 262.7 | 68.3 |
| Combat | Net points per charged fight, damage counted | +84 | +72 |
| Combat | Net per 100 charger points, damage counted | +23.6 | +25.3 |
| Combat | First round won (charged fights) | 78% | 73% |
| Combat | Net points per charged fight | +34 | +76 |
| Combat | Net points per supported fight / lone fight | - / +34 | - / +76 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 9 | 5 of 15 |
| Game | Points lost | 547.0 | 300.7 |
| Game | VP from objectives | 506.7 | 576.7 |
| Game | Lone holders (player turns) | 4.5 | 2.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -322 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 848
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p12

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +5.9 | 0.0 | 0.0 | 0.7 | +115.8 | 0.0 | 0.0 |
| ARMY TABLE | 22.0 | +5.1 | 0.0 | 206.7 | 22.3 | -298.7 | 0.0 | 26.7 |
| ASSAILMENT BY POINTS | 1.3 | +7.3 | 0.0 | 418.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +16.1 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +1.2 | 0.0 | 140.7 | 2.0 | +16.5 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 70.3 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.7 | +84.3 | 0.0 | 15.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +65.1 | 0.0 | 223.3 | 0.3 | +3.3 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +36.4 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.3 | -401.7 | 0.0 | 125.0 | 4.0 | -197.5 | 0.0 | 132.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 98.7 | 0.0 | 3.0 | +0.0 | 240.0 | 38.7 |
| CLOSES ON WHAT IT BEATS | 22.3 | +0.0 | 0.0 | 66.7 | 14.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.3 | +56.9 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 5.7 | -293.7 | 0.0 | 0.0 | 7.0 | -294.2 | 0.0 | 164.7 |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 0.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -33.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +58.5 | 155.0 | 0.0 |
| EXACT ROUND | 2.7 | -24.5 | 32.7 | 0.0 | 4.0 | +43.9 | 291.7 | 32.7 |
| FACES THE THREAT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.3 | +6.7 | 66.0 | 0.0 | 4.7 | +0.0 | 220.0 | 32.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 21.0 | +244.7 | 0.0 | 780.0 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 0.3 | +3.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +71.5 | 0.0 | 0.0 | 1.7 | +113.0 | 0.0 | 32.7 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 85.0 | +3621.2 | 98.7 | 1284.0 | 94.0 | +5734.5 | 385.0 | 519.3 |
| FLANK NOT WEIGHED | 10.0 | +0.0 | 0.0 | 271.7 | 10.7 | +0.0 | 0.0 | 98.7 |
| FOCUS FIRE | - | - | - | - | 0.3 | +5.7 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +258.8 | 0.0 | 0.0 | 0.7 | +12.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.0 | +430.3 | 98.7 | 0.0 | 6.3 | +524.4 | 375.0 | 71.3 |
| FREED FROM HIS FIGHT | 8.3 | +0.0 | 0.0 | 386.7 | 9.7 | +0.0 | 0.0 | 356.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.7 | -22.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -2.5 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +26.5 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -3.0 | 0.0 | 0.0 | 1.3 | -19.5 | 31.7 | 32.7 |
| GOAL WALK | 7.0 | +585.9 | 0.0 | 0.0 | 12.0 | +955.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 70.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 5.7 | +0.0 | 0.0 | 48.3 | 5.7 | +0.0 | 0.0 | 290.7 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 56.7 | 4.0 | +0.0 | 0.0 | 132.0 |
| HIS CHARGE DENIED | - | - | - | - | 1.3 | +16.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 65.3 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 132.0 |
| HIS MOVE AND SHOT | 3.7 | -72.5 | 0.0 | 78.3 | - | - | - | - |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 132.0 |
| HIS RANDOM MOVE | 14.0 | +0.0 | 0.0 | 63.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.3 | +372.7 | 0.0 | 1095.0 | 10.0 | +178.1 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 32.0 | +306.2 | 0.0 | 1061.7 | 11.7 | +372.1 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 18.7 | +0.0 | 0.0 | 28.3 | 17.0 | +0.0 | 0.0 | 157.3 |
| HOLDER ASSIGNMENT | 11.3 | +1033.0 | 0.0 | 28.3 | 10.3 | +1215.6 | 0.0 | 92.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -195.6 | 98.7 | 0.0 | 5.3 | -215.0 | 220.0 | 71.3 |
| IDLE COST | 24.7 | -354.4 | 0.0 | 411.7 | - | - | - | - |
| JOIN BY POINTS | - | - | - | - | 0.3 | +22.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.3 | -1.3 | 0.0 | 0.0 | 1.0 | +59.6 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 26.7 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 8.7 | +0.0 | 0.0 | 1265.0 | 5.0 | +0.0 | 443.3 | 59.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -1.7 | 15.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +12.8 | 98.7 | 0.0 | 2.7 | +2.3 | 88.3 | 32.7 |
| LURE BY WHAT IT DRAWS | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.7 | +2.5 | 0.0 | 68.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +35.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +37.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +33.5 | 0.0 | 70.3 | 0.7 | -29.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +64.6 | 0.0 | 0.0 | 2.0 | +34.3 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +4.0 | 0.0 | 70.3 | 2.0 | +15.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +2.8 | 0.0 | 70.3 | 2.3 | +24.7 | 0.0 | 0.0 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 16.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.3 | +463.6 | 0.0 | 0.0 | 6.0 | +609.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.3 | +382.4 | 0.0 | 0.0 | 7.7 | +337.5 | 0.0 | 125.3 |
| NEXT CHARGE BY LIST | 5.3 | +319.8 | 0.0 | 0.0 | 4.7 | +440.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -19.8 | 0.0 | 26.7 |
| NO DOUBLE ROUNDS | 3.7 | -183.8 | 98.7 | 0.0 | 4.3 | -155.0 | 220.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +14.4 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.0 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.0 | -189.8 | 0.0 | 98.3 | 5.7 | -259.6 | 71.7 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +0.8 | 0.0 | 38.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.3 | +0.0 | 0.0 | 32.7 |
| ONE FIGHT FORMULA | 5.3 | -90.7 | 0.0 | 0.0 | 4.3 | -87.7 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +80.4 | 66.0 | 0.0 | 1.0 | +12.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -27.9 | 0.0 | 0.0 | 2.7 | -38.7 | 0.0 | 65.3 |
| ONE PROMISE A TARGET | 0.7 | -39.1 | 0.0 | 0.0 | 1.0 | -119.8 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +47.1 | 0.0 | 0.0 | 0.3 | +18.4 | 28.3 | 0.0 |
| OVERRUNS AWAY | 0.7 | +12.1 | 0.0 | 0.0 | 0.7 | +23.6 | 165.0 | 0.0 |
| PATHS CROSS | 1.3 | +28.9 | 0.0 | 68.3 | 0.3 | +18.9 | 0.0 | 0.0 |
| PLAN RESULT | 44.7 | +245.0 | 32.7 | 960.7 | 46.0 | +337.3 | 294.3 | 393.3 |
| PROMISE BY ITS OWN SUM | 10.3 | -170.5 | 0.0 | 0.0 | 10.7 | -609.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.6 | 0.0 | 0.0 | 2.7 | -1.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -2.5 | 0.0 | 0.0 |
| QUARTER ODDS | 7.3 | +489.1 | 0.0 | 140.7 | 8.7 | +1012.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +46.2 | 0.0 | 56.7 | 2.3 | +70.0 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.7 | +38.5 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.7 | +285.4 | 0.0 | 63.3 | 2.7 | +60.6 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +44.6 | 0.0 | 25.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -15.4 | 0.0 | 0.0 | 1.3 | -31.4 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| RESERVE FALL BACK | 0.3 | +36.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.7 | +82.3 | 66.0 | 0.0 | 5.7 | +145.1 | 306.7 | 71.3 |
| ROUNDS AFTER TERROR | 1.0 | -11.4 | 32.7 | 0.0 | 1.0 | -31.1 | 28.3 | 0.0 |
| RUN DOWN | 3.3 | -28.6 | 98.7 | 0.0 | 2.7 | -10.9 | 116.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.3 | -122.7 | 0.0 | 0.0 | 3.0 | -69.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.7 | +59.9 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | - | - | - | - | 1.0 | +61.0 | 71.7 | 0.0 |
| SET CREDITED ONCE | 3.3 | -177.0 | 0.0 | 108.3 | 1.3 | -58.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 7.3 | +140.8 | 66.0 | 108.3 | 2.0 | +80.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.3 | +0.0 | 0.0 | 140.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -4.6 | 10.0 | 0.0 |
| SHOT RISK POINTS | 13.7 | -157.3 | 0.0 | 221.7 | 9.0 | +32.8 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +23.0 | 0.0 | 28.3 | 8.7 | +121.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +17.9 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -4.0 | 155.0 | 0.0 |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 83.3 | 7.3 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -0.6 | 28.3 | 0.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 13.0 | +0.0 | 0.0 | 885.7 | 40.3 | +0.0 | 10.0 | 224.0 |
| STANDS TO CAST | - | - | - | - | 0.3 | +5.3 | 0.0 | 0.0 |
| STAY WORTH | 0.7 | +0.4 | 0.0 | 140.7 | 10.3 | +48.3 | 10.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 5.3 | +642.4 | 0.0 | 185.0 | 3.3 | +466.2 | 0.0 | 26.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 5.3 | +642.4 | 0.0 | 185.0 | 3.3 | +466.2 | 0.0 | 26.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 68.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -30.4 | 0.0 | 15.0 | 0.3 | -10.6 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.0 | +0.0 | 0.0 | 684.0 | 45.7 | +0.0 | 0.0 | 224.0 |
| TIED UP BY THE SUM | 1.0 | +120.0 | 32.7 | 0.0 | 1.7 | +255.3 | 100.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 73.3 | +592.8 | 0.0 | 553.3 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | +22.2 | 0.0 | 142.7 |
| WHO FIGHTS | 0.7 | +15.1 | 0.0 | 0.0 | 0.3 | -2.4 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +46.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 71.3 |
| WHOLE FIGHT DANGER | 4.3 | -248.2 | 0.0 | 0.0 | 1.7 | -146.6 | 0.0 | 132.0 |
| WHOLE FIGHT GAIN | 0.3 | +1.3 | 0.0 | 0.0 | 0.7 | +28.8 | 0.0 | 0.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: cora-bb45c30-p12

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 133 | 133 | 97 | 32.33 | -407 | -4.2 |
| HOLDER ASSIGNMENT | 65 | 65 | 60 | 20.00 | +4128 | +68.8 |
| LEGAL CHARGES ONLY | 41 | 41 | 41 | 13.67 | +0 | +0.0 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -1347 | -38.5 |
| FIVE ACTION | 537 | 515 | 33 | 11.00 | +1799 | +54.5 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 220 | 188 | 30 | 10.00 | +24 | +0.8 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| PROMISE BY ITS OWN SUM | 63 | 63 | 23 | 7.67 | -2339 | -101.7 |
| GOAL WALK | 57 | 57 | 20 | 6.67 | +1379 | +69.0 |
| FOUR ROUNDS | 31 | 28 | 17 | 5.67 | +857 | +50.4 |
| REDIRECT FOR A FRIEND IN REACH | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 131 | 124 | 16 | 5.33 | +57 | +3.6 |
| MOVE TO CHARGE COMPUTED | 40 | 29 | 16 | 5.33 | +587 | +36.7 |
| HIS SHOT LIST | 133 | 124 | 15 | 5.00 | +108 | +7.2 |
| IDLE COST | 74 | 54 | 14 | 4.67 | +99 | +7.1 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 30 | 25 | 10 | 3.33 | +175 | +17.5 |
| RISK BY ARC | 28 | 25 | 10 | 3.33 | +508 | +50.8 |
| SET UP BY THE SET | 28 | 27 | 10 | 3.33 | +636 | +63.6 |
| CHARGE NOW FIRST | 17 | 17 | 7 | 2.33 | -650 | -92.8 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 7 | 2.33 | +349 | +49.8 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FIGHT TO THE END | 9 | 9 | 6 | 2.00 | +302 | +50.4 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| QUARTER ODDS | 48 | 48 | 6 | 2.00 | +188 | +31.2 |
| SUPPORT ADDS | 26 | 26 | 6 | 2.00 | +97 | +16.1 |
| SUPPORT WORKED OUT | 26 | 26 | 6 | 2.00 | +97 | +16.1 |
| TIED UP BY THE SUM | 8 | 6 | 6 | 2.00 | +224 | +37.4 |
| CAST JOB | 8 | 8 | 5 | 1.67 | +8 | +1.6 |
| COVER ONCE | 38 | 26 | 5 | 1.67 | +110 | +22.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -477 | -95.3 |
| PATHS CROSS | 5 | 5 | 5 | 1.67 | +143 | +28.7 |
| WHOLE FIGHT DANGER | 18 | 18 | 5 | 1.67 | +387 | +77.3 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +22 | +5.5 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 8 | 8 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +205 | +51.3 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +815 | +203.8 |
| HONEST WORTH | 28 | 26 | 4 | 1.33 | +106 | +26.6 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +175 | +43.8 |
| MAX FOR POSITIONING | 10 | 9 | 4 | 1.33 | +4 | +0.9 |
| SHOT RISK POINTS | 68 | 62 | 4 | 1.33 | +15 | +3.7 |
| SHOTS IN THE MOVE | 28 | 21 | 4 | 1.33 | +29 | +7.3 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +365 | +121.7 |
| EXACT ROUND | 20 | 18 | 3 | 1.00 | +18 | +6.1 |
| OPENS UP | 3 | 3 | 3 | 1.00 | +77 | +25.7 |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 3 | 1.00 | +27 | +9.1 |
| REDIRECT COUNTER | 22 | 19 | 3 | 1.00 | +314 | +104.6 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +141 | +47.0 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +180 | +59.9 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +183 | +61.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 63 | 49 | 2 | 0.67 | +0 | +0.0 |
| LOST AFTER ESCAPE | 14 | 14 | 2 | 0.67 | +16 | +8.2 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +105 | +52.6 |
| NEARER NOT NEEDED | 51 | 49 | 2 | 0.67 | +33 | +16.6 |
| ONE JOINT FIGURE | 5 | 4 | 2 | 0.67 | +44 | +21.8 |
| ONE OBJECTIVE FORMULA | 24 | 23 | 2 | 0.67 | +37 | +18.6 |
| PROMISE KNOWS THE FIGHT | 9 | 6 | 2 | 0.67 | -5 | -2.6 |
| STAY WORTH | 33 | 26 | 2 | 0.67 | +4 | +1.9 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -284 | -142.1 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +109 | +109.2 |
| CHARGE LOSSES | 52 | 47 | 1 | 0.33 | +27 | +27.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +61 | +60.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +17 | +17.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +80 | +79.6 |
| JOIN BY POINTS | 1 | 1 | 1 | 0.33 | +66 | +65.9 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +8 | +7.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -113 | -112.7 |
| MISSILES IN THE MOVE | 11 | 1 | 1 | 0.33 | +6 | +5.6 |
| MISSILES NEXT TURN | 12 | 2 | 1 | 0.33 | +1 | +0.7 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +13 | +13.0 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +12 | +12.2 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +109 | +108.8 |
| ROUNDS AFTER TERROR | 6 | 6 | 1 | 0.33 | +8 | +7.6 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -8 | -7.5 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +88 | +88.4 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +67 | +66.9 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.33 | -48 | -47.9 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 111 | 110 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 24 | 21 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 62 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 54 | 51 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 34 | 31 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 39 | 36 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 33 | 33 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 19 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 11 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 60 | 56 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 107 | 107 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 24 | 21 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 29 | 16 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 272 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 18 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 14 | 13 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 21 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 49 | 45 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 160 | 155 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 2 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 18 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 272 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p12

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 4.00 | 41.1 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 4.67 | 101.7 |
| ARMY TABLE | rule | 2.67 | 4.67 | 101.3 |
| CHARGE NOW FIRST | rule | 0.67 | 1.67 | 92.8 |
| ONE PROMISE A TARGET | rule | 0.67 | 1.00 | 95.3 |
| NO REASON | gate | - | 1.00 | 73.5 |
| FALLBACK | gate | 0.33 | 0.33 | 22.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 9.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.33 | 2.6 |
| RULE SWITCHED OFF | gate | 0.67 | - | 5.3 |
| SUPPORT NARROWED | rule | 0.67 | - | 142.1 |
| FIGHT ORDER BAND | gate | - | 0.33 | 1.8 |
| JOINT CHARGE NOW | rule | 0.33 | - | 3.8 |
| MARCH OF THE TABLE | rule | - | 0.33 | 112.7 |
| STANDS TO CAST | rule | - | 0.33 | 7.5 |
| TURN GATE | gate | 0.33 | - | 0.6 |
| WOUNDED STAYS OUT | rule | - | 0.33 | 47.9 |

### Plans: cora-bb45c30-p12

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 50% | 446 | 236 | 53% |
| Mine | join | 4.3 | 100% | 172 | 0 | 0% |
| Mine | move | 35.0 | 96% | 1582 | 0 | 0% |
| Mine | shoot | 0.3 | 100% | 24 | 9 | 40% |
| Mine | support | 1.7 | 100% | 23 | 0 | 0% |
| Opponent | charge | 5.7 | 41% | 644 | 332 | 51% |
| Opponent | join | 1.3 | 100% | 168 | 0 | 0% |
| Opponent | move | 35.7 | 98% | 1758 | 0 | 0% |
| Opponent | shoot | 2.0 | 17% | 112 | 6 | 5% |
| Opponent | support | 1.3 | 100% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p12

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 36% | 80% | 0% | - | 40% | 0% | 0% | 60% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 12% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p12

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 91 (9) | 0 | 91 | 14 | 78% | 2.5 | 0 (4) | 200 (3) | 156 (2) | 142 (6) | 0 (3) |
| Mine | Character | 9 | 27 (9) | 27 | 0 | 48 | 33% | 2.7 | 64 (2) | 0 (6) | 0 (1) | 34 (6) | 0 (3) |
| Mine | Clean-up | 1 | 221 (1) | 0 | 221 | 0 | 0% | 6.0 | - | - | 221 (1) | 221 (1) | - |
| Mine | Fast | 1 | 46 (1) | 46 | 0 | 0 | 0% | 2.0 | - | 46 (1) | - | - | 46 (1) |
| Mine | Fast Hammer | 6 | 18 (6) | 12 | 6 | 14 | 33% | 3.5 | - | 15 (4) | 25 (2) | 19 (3) | 16 (3) |
| Mine | Hammer | 2 | 0 (2) | 0 | 0 | 34 | 0% | 2.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Holder | 1 | 35 (1) | 0 | 35 | 100 | 0% | 3.0 | - | 35 (1) | - | - | 35 (1) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 39 | 25% | 2.3 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 3 | 266 (3) | 24 | 242 | 0 | 67% | 3.0 | 111 (1) | 429 (1) | 0 (1) | 266 (3) | - |
| Opponent | Character | 10 | 55 (10) | 55 | 0 | 18 | 20% | 2.2 | 96 (3) | 42 (5) | 0 (1) | 36 (5) | 91 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 38 (5) | 0 | 38 | 45 | 0% | 3.2 | 50 (2) | 0 (1) | 47 (2) | 61 (2) | 26 (3) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 33 (6) | 26 | 7 | 0 | 17% | 4.6 | - | 43 (4) | 0 (2) | 49 (3) | 16 (3) |
| Opponent | Holder | 6 | 30 (6) | 0 | 30 | 11 | 50% | 2.3 | 48 (2) | 36 (2) | 0 (1) | 0 (1) | 42 (4) |
| Opponent | Shooter | 1 | 19 (1) | 0 | 19 | 0 | 0% | 1.0 | - | - | 19 (1) | 19 (1) | - |

### Charged fights: cora-bb45c30-p12

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 443 | 3.5 | 1.0 | 127 | 83 | +44 | 4 of 7 | 5 of 7 | - | +44 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| **Mine** | all armies | 3 | 0 | 295 | 3.0 | 1.0 | 98 | 64 | +34 | 5 of 9 | 7 of 9 | - | +34 |
| Opponent | Warriors of Chaos | 2 | 0 | 153 | 3.5 | 1.0 | 44 | 17 | +27 | 3 of 7 | 4 of 7 | - | +27 |
| Opponent | Wood Elf Realms | 1 | 0 | 955 | 8.0 | 1.0 | 119 | 0 | +119 | 2 of 8 | 7 of 8 | - | +119 |
| **Opponent** | all armies | 3 | 0 | 420 | 5.0 | 1.0 | 84 | 8 | +76 | 5 of 15 | 11 of 15 | - | +76 |

### Effective charges: cora-bb45c30-p12

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 7 | 3 (net -193) | 0 | 0 | 0 | 0 | 2 (net +138) | 2 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 7 | 0 | 1 (net +0) | 0 | 2 (net +72) | 0 | 1 (net +0) | 3 | 0% (0 of 4) |
| Opponent | Wood Elf Realms | 8 | 1 (net +0) | 0 | 0 | 3 (net +165) | 2 (net +128) | 1 (net +205) | 1 | 0% (0 of 7) |

### Charged fights, damage counted: cora-bb45c30-p12

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 307 | 283 | -193 | 119 | 193 | -74 | -24.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 186 | 192 | +138 | 209 | 46 | +163 | +87.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 494 | 126 | +0 | 23 | 0 | +23 | +4.6 |
| Mine | No odds | 2 | 471 | 242 | +305 | 305 | 0 | +305 | +64.8 |
| Mine | All fights | 9 | 358 | 219 | +34 | 159 | 75 | +84 | +23.6 |
| Opponent | Long shot (under 50%) | 1 | 499 | 323 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 50-54% | 1 | 98 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 5 | 157 | 146 | +128 | 154 | 35 | +120 | +76.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 490 | 196 | +102 | 102 | 28 | +75 | +15.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 500 | 104 | +128 | 158 | 0 | +158 | +31.6 |
| Opponent | No odds | 4 | 226 | 258 | +11 | 32 | 29 | +3 | +1.5 |
| Opponent | All fights | 15 | 284 | 191 | +76 | 95 | 23 | +72 | +25.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p12 | move | 22 | 5 (23%) | 5 (23%) | 3 (14%) | 14 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

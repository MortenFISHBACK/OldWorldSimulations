# Doctrine scorecard: cora-bb45c30-p42

### Scorecard: cora-bb45c30-p42

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 375 |
| L0918 | 6 | 1 | Opponent | no | 7 | - | 2 | 0 | 1 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 596 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 5 | 4 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 12 | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 3 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.0 | 3.0 | 0.3 | 0.7 | 0.0 | 0.0 | 0.0 | 433.7 |
| **Average** | | | Opponent | 0% | 3.3 | 3.0 | 2.7 | 2.3 | 0.3 | 0.0 | 0.0 | 0.0 |

### KPIs: cora-bb45c30-p42

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (4 of 10) | 0% (0 of 14) | 17% (4 of 24) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 100% (6 of 6); on the table 100% | 90% (9 of 10); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | 100% (6 of 6); on the table 100% | 91% (10 of 11); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 29% (14 of 48) | 17% (2 of 12) | 27% (16 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 37% (14 of 38) | 18% (2 of 11) | 33% (16 of 49) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 50% (2996 of 5997) | 66% (3932 of 5998) | 58% (6928 of 11995) |
|   infantry points that never fought | lower | 46% (729 of 1591) | 90% (1027 of 1147) | 64% (1756 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (20 of 34) | 60% (12 of 20) | 59% (32 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 1.3 uses a game | 100% (1 of 1); 1.3 uses a game | 67% (2 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (3105 of 5667) | 56% (2923 of 5186) | 56% (6028 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.7 (50%) | 0.3 (10%) | 6.0 (41%) |
| MARCHED: its unit marched | 2.3 (21%) | 0.7 (20%) | 3.0 (20%) |
| IN COMBAT: engaged in combat | 2.3 (21%) | 0.3 (10%) | 2.7 (18%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (20%) | 0.7 (5%) |
| GONE: slain | 1.0 (9%) | 0.0 (0%) | 1.0 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (40%) | 1.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.7 | 5.3 | 1.0 | 1.3 |
| not cast | 2.0 | 4.3 | 14.7 | 3.0 | 14.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (46%) | 6.0 (41%) | 1.0 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.0 (20%) | 1.3 (44%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 2.7 (18%) | 0.7 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (46%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (98%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (78 of 121) | 61% (49 of 80) | 63% (127 of 201) |
|   cavalry | - | 58% (7 of 12) | 58% (7 of 12) |
|   character | 100% (4 of 4) | 56% (10 of 18) | 64% (14 of 22) |
|   chariot | 69% (11 of 16) | 100% (12 of 12) | 82% (23 of 28) |
|   infantry | 43% (21 of 49) | 46% (12 of 26) | 44% (33 of 75) |
|   monster | 67% (6 of 9) | 67% (8 of 12) | 67% (14 of 21) |
|   war machine | 84% (36 of 43) | - | 84% (36 of 43) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (26%) | 4.0 (39%) | 7.7 (31%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (6%) | 0.7 (3%) |
| IN COMBAT: it fought this turn or the last | 1.3 (9%) | 0.0 (0%) | 1.3 (5%) |
| NO TARGET IN RANGE | 2.7 (19%) | 3.3 (32%) | 6.0 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (5%) | 0.0 (0%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 4.3 (30%) | 2.3 (23%) | 6.7 (27%) |
| SHELTERED: the target was sheltered | 1.3 (9%) | 0.0 (0%) | 1.3 (5%) |
| OTHER BAR | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 0.3 | 91% | 0.7 pts | 3 pts |
| character | 4.7 | 2.0 | 64% | 3.6 pts | 17 pts |
| chariot | 7.7 | 6.7 | 61% | 10.8 pts | 83 pts |
| infantry | 11.3 | 5.3 | 74% | 7.4 pts | 84 pts |
| monster | 6.3 | 1.7 | 84% | 6.2 pts | 39 pts |
| war machine | 12.3 | 6.7 | 78% | 12.2 pts | 150 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 4.0 | 2.7 |
| Charges that made contact a game | 1.3 | 3.7 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (3 units) | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (20 units) | 0.29 declared, 0.26 contact (31 units) | 0.20 declared, 0.18 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 75% (3 of 4) | 100% (1 of 1) | - | 80% (4 of 5) |
| Character on its own | 100% (1 of 1) | 33% (1 of 3) | 40% (2 of 5) | 44% (4 of 9) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 36% (4 of 11) | 50% (1 of 2) | 0% (0 of 1) | 36% (5 of 14) |
| Monster | 100% (1 of 1) | 0% (0 of 1) | - | 50% (1 of 2) |
| Monstrous | 50% (1 of 2) | 80% (4 of 5) | - | 71% (5 of 7) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 75% (3 of 4); on the table 75% | 33% (8 of 24) | 56% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (1 of 1); on the table 100% | 25% (6 of 24) | 38% | 50% (5 of 10) | 50% (1 of 2); 4.0 uses a game | 0% (0 of 1); 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 92% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 42% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (3 of 3); on the table 100% | - | 63% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p42, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (6) | 50% (1) | 70% (7) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p42

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (4 of 4) | 57% (4 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (24 of 58) | 58% (15 of 26) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 57% (4 of 7) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 433.7 | 0.0 |
| Movement | Fights charged into per game | 1.0 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 1 of 5, net +60 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 1 of 5, net +217 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 3, net +20 | 1 of 5, net +162 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | 1 of 5, net +145 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (15 of 44) | 41% (20 of 49) |
| Shooting | Points destroyed by shooting units | 35.7 | 41.7 |
| Shooting | War machine shots | 12.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (20 of 36) | - |
| Shooting | Points destroyed by war machines | 9.0 | 0.0 |
| Magic | Magic missiles cast | 2.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 8) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 6.3 | 2.0 |
| Magic | Wounds caused by other spells | 0.7 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 47.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.3 / 0.7 | 2.3 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 92.7 | 249.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +20 | +72 |
| Combat | Net per 100 charger points, damage counted | +5.6 | +29.6 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +20 | +66 |
| Combat | Net points per supported fight / lone fight | +0 / +30 | +162 / +55 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 3 of 10 |
| Game | Points lost | 493.0 | 184.3 |
| Game | VP from objectives | 446.7 | 700.0 |
| Game | Lone holders (player turns) | 4.0 | 3.3 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -577 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 677
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p42

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +64.5 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 10.7 | +350.9 | 0.0 | 151.3 | 30.0 | -6.7 | 0.0 | 74.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.7 | +0.0 | 0.0 | 125.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -24.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 11.3 | +102.6 | 22.7 | 333.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.0 | +83.9 | 0.0 | 54.0 | 0.7 | +3.2 | 108.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +47.9 | 83.3 | 0.0 |
| CHAFF PASSED | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +44.5 | 0.0 | 54.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 21.0 | -546.4 | 0.0 | 220.7 | 18.0 | -695.2 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 35.0 | 0.0 | 0.3 | +0.0 | 68.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 0.0 | 17.0 | +0.0 | 0.0 | 96.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 68.3 | - | - | - | - |
| COVER ONCE | 7.0 | -190.1 | 0.0 | 125.0 | 3.7 | -423.8 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -16.2 | 34.7 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -37.9 | 54.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +2.1 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +0.2 | 75.0 | 68.3 | 0.7 | -6.3 | 68.3 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 35.0 | 0.0 | 2.0 | +0.0 | 157.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 33.3 | +360.1 | 0.0 | 77.3 |
| FEATURE BUFFS | 1.0 | +22.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 1.3 | +22.2 | 68.3 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 98.7 | +4165.9 | 385.7 | 1323.0 | 109.7 | +5400.9 | 1015.3 | 388.0 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 54.0 | 4.0 | +0.0 | 0.0 | 20.0 |
| FOLLOW UP WEIGHED | 0.3 | +21.5 | 0.0 | 0.0 | 0.7 | +53.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +78.7 | 75.0 | 68.3 | 2.3 | +223.6 | 211.0 | 0.0 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -3.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +19.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.0 | +494.2 | 0.0 | 0.0 | 22.7 | +2110.9 | 0.0 | 37.3 |
| GUN FIGURES | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +10.2 | 0.0 | 0.0 |
| GUN MASK | 4.0 | +109.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 35.7 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -12.4 | 0.0 | 0.0 | 9.0 | -93.8 | 0.0 | 53.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 36.0 | +888.6 | 0.0 | 220.7 | 83.7 | +5494.9 | 0.0 | 170.0 |
| HIS SHOTS BY HIS RUN | 37.7 | +655.0 | 0.0 | 382.7 | 64.3 | +1517.4 | 0.0 | 159.3 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +70.5 | 142.7 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 20.3 | +0.0 | 0.0 | 162.0 | 19.3 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 12.7 | +1176.4 | 0.0 | 108.0 | 14.7 | +1434.3 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -43.2 | 75.0 | 68.3 | 2.3 | -168.6 | 211.0 | 0.0 |
| IDLE COST | - | - | - | - | 25.0 | -350.7 | 0.0 | 28.3 |
| JOINT CHARGE NOW | 0.7 | +36.0 | 40.0 | 68.3 | 1.3 | -21.0 | 108.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -5.9 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 7.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 60.0 | 239.7 | 5.7 | +0.0 | 248.7 | 50.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +1.5 | 20.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.0 | 20.0 | 68.3 | 2.0 | +7.8 | 176.3 | 0.0 |
| MANOEUVRE | 1.7 | +5.5 | 0.0 | 75.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +37.9 | 0.0 | 0.0 | 0.7 | +37.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +115.1 | 0.0 | 0.0 | 0.3 | +12.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 4.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +6.3 | 0.0 | 54.0 | 1.7 | +18.3 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.7 | +132.2 | 0.0 | 108.0 | 2.3 | +41.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 11.3 | +99.5 | 0.0 | 54.0 | 3.3 | +35.7 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.7 | +125.9 | 0.0 | 0.0 | 4.7 | +159.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +242.7 | 0.0 | 75.7 | 4.7 | +210.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +75.1 | 0.0 | 0.0 | 3.0 | +105.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -31.1 | 75.0 | 68.3 | 1.3 | -71.2 | 103.0 | 0.0 |
| NO LATE CUT | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +15.8 | 0.0 | 54.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 6.7 | -141.0 | 0.0 | 242.3 | 1.3 | -7.3 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 4.7 | +28.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -25.2 | 0.0 | 0.0 | 4.3 | -64.5 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +56.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.7 | +36.2 | 0.0 | 108.0 | 5.3 | +64.5 | 0.0 | 0.0 |
| ONE ROUTE | 4.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +17.2 | 34.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +6.7 | 68.3 | 0.0 |
| OWN CAST FIRST | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +50.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -2.7 | 0.0 | 0.0 | 0.3 | -9.6 | 0.0 | 0.0 |
| PLAN RESULT | 43.0 | +485.0 | 82.7 | 757.0 | 50.0 | +358.4 | 425.7 | 320.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.0 | -116.5 | 0.0 | 0.0 | 5.0 | -94.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.7 | -0.6 | 0.0 | 0.0 |
| QUARTER ODDS | 10.0 | +770.3 | 71.3 | 166.7 | 12.3 | +1085.7 | 0.0 | 142.7 |
| REAL GROUND | 4.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +155.9 | 0.0 | 35.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 6.3 | +0.0 | 0.0 | 62.3 |
| REFORMS TO MEET IT | 0.7 | -52.3 | 0.0 | 0.0 | 0.3 | -5.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +7.5 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +36.6 | 75.0 | 68.3 | 1.7 | -149.3 | 103.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -51.4 | 211.0 | 0.0 |
| RUN DOWN | - | - | - | - | 2.3 | -29.9 | 211.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -266.7 | 0.0 | 36.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +3.7 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -72.9 | 0.0 | 54.0 | 0.3 | -1.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +83.6 | 0.0 | 54.0 | 0.3 | +1.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 20.0 | +0.0 | 0.0 | 463.0 | 9.0 | +0.0 | 0.0 | 108.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +304.4 | 116.7 | 0.0 | 1.3 | +12.8 | 83.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -1.5 | 15.0 | 0.0 | 0.3 | -0.8 | 0.0 | 0.0 |
| SHOT RISK POINTS | 20.3 | -321.6 | 0.0 | 220.7 | 41.7 | -424.0 | 0.0 | 79.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 26.3 | +854.6 | 0.0 | 443.7 | 16.7 | +302.1 | 0.0 | 90.0 |
| SPELL WORTH | - | - | - | - | 4.0 | +50.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 72.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.8 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 13.7 | +0.0 | 267.0 | 37.3 |
| STANDS STILL | 50.0 | +0.0 | 310.7 | 872.0 | 32.3 | +0.0 | 804.3 | 180.0 |
| STAY WORTH | 49.0 | +18.2 | 100.0 | 1065.7 | 26.0 | +277.6 | 529.7 | 181.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +5.7 | 20.0 | 20.0 |
| SUPPORT ADDS | 3.3 | +176.7 | 0.0 | 54.0 | 0.7 | +47.7 | 0.0 | 15.0 |
| SUPPORT WORKED OUT | 3.3 | +176.7 | 0.0 | 54.0 | 0.7 | +47.7 | 0.0 | 15.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 18.7 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 75.7 | 5.7 | +0.0 | 0.0 | 13.3 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 75.7 | 4.0 | +0.0 | 0.0 | 13.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.0 | +0.0 | 0.0 | 627.3 | 54.0 | +0.0 | 0.0 | 195.0 |
| TIED UP BY THE SUM | 0.7 | +80.2 | 35.0 | 0.0 | 0.7 | +125.6 | 103.0 | 0.0 |
| TIME ON OUR SIDE | 44.7 | +624.0 | 64.0 | 445.3 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 3.0 | +0.0 | 454.0 | 0.0 |
| WEAPON BY POINTS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +36.9 | 0.0 | 0.0 | 0.7 | +46.0 | 0.0 | 11.3 |
| WHOLE FIGHT DANGER | 3.3 | -202.9 | 0.0 | 0.0 | 0.3 | -83.1 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +38.3 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.7 | +43.7 | 0.0 | 0.0 | 0.3 | +27.7 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p42

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 359 | 355 | 126 | 42.00 | +2225 | +17.7 |
| ARMY TABLE | 122 | 122 | 99 | 33.00 | +1519 | +15.3 |
| HIS SHOTS BY HIS RUN | 306 | 301 | 86 | 28.67 | +1112 | +12.9 |
| HOLDER ASSIGNMENT | 82 | 82 | 76 | 25.33 | +4335 | +57.0 |
| SHOT RISK POINTS | 186 | 182 | 42 | 14.00 | +1151 | +27.4 |
| GOAL WALK | 95 | 94 | 39 | 13.00 | +1670 | +42.8 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| LEGAL CHARGES ONLY | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -445 | -18.6 |
| ARTILLERY RE-ROLL WEIGHED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| FIVE ACTION | 625 | 614 | 15 | 5.00 | +980 | +65.4 |
| OGRE LOADER SECOND SHOT | 14 | 14 | 14 | 4.67 | +85 | +6.1 |
| IDLE COST | 75 | 49 | 13 | 4.33 | +76 | +5.8 |
| TIME ON OUR SIDE | 134 | 108 | 13 | 4.33 | +102 | +7.9 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 33 | 33 | 12 | 4.00 | -633 | -52.7 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 12 | 4.00 | +43 | +3.6 |
| STAY WORTH | 225 | 200 | 12 | 4.00 | +86 | +7.1 |
| CHARGE LOSSES | 117 | 113 | 10 | 3.33 | +1278 | +127.8 |
| MOVE TO CHARGE COMPUTED | 22 | 17 | 10 | 3.33 | +218 | +21.8 |
| CAST JOB | 11 | 11 | 8 | 2.67 | +91 | +11.3 |
| NEXT CHARGE BY LIST | 13 | 11 | 8 | 2.67 | +125 | +15.6 |
| FOUR ROUNDS | 11 | 11 | 6 | 2.00 | +193 | +32.1 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +45 | +7.5 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 129 | 103 | 5 | 1.67 | +36 | +7.2 |
| SUPPORT ADDS | 12 | 11 | 5 | 1.67 | +270 | +53.9 |
| SUPPORT WORKED OUT | 12 | 11 | 5 | 1.67 | +270 | +53.9 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 32 | 28 | 4 | 1.33 | +8 | +2.1 |
| FALLS SHORT | 100 | 80 | 4 | 1.33 | +22 | +5.5 |
| GUN MASK | 12 | 12 | 4 | 1.33 | +177 | +44.3 |
| HIS MOVE AND SHOT | 40 | 37 | 4 | 1.33 | +3 | +0.7 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| MAX FOR POSITIONING | 9 | 9 | 4 | 1.33 | +2 | +0.5 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +143 | +35.8 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +240 | +60.0 |
| CANNON PLANNED TARGET | 34 | 34 | 3 | 1.00 | +26 | +8.5 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +134 | +44.5 |
| FEATURE BUFFS | 3 | 3 | 3 | 1.00 | +28 | +9.3 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +225 | +75.0 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +90 | +29.9 |
| QUARTER ODDS | 67 | 67 | 3 | 1.00 | +143 | +47.8 |
| WOUNDS ON THE RANKS | 15 | 15 | 3 | 1.00 | +62 | +20.8 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 2 | 0.67 | +15 | +7.5 |
| EVASIVE BY THE ODDS | 3 | 3 | 2 | 0.67 | +4 | +1.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 6 | 6 | 2 | 0.67 | +82 | +41.1 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -20 | -10.0 |
| MISSILES IN THE MOVE | 30 | 22 | 2 | 0.67 | +10 | +5.0 |
| NEARER NOT NEEDED | 29 | 27 | 2 | 0.67 | +56 | +27.9 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -0 | -0.2 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -37 | -18.4 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 2 | 0.67 | -2 | -0.8 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -4 | -2.0 |
| RISK BY ARC | 9 | 9 | 2 | 0.67 | +23 | +11.6 |
| SET UP BY THE SET | 5 | 5 | 2 | 0.67 | +88 | +43.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS AFTER THE MOVES | 28 | 28 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +17 | +8.6 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +193 | +193.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -72 | -71.9 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -0 | -0.4 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -38 | -37.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +20 | +19.8 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +59 | +58.9 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +44 | +43.7 |
| MANOEUVRE | 9 | 9 | 1 | 0.33 | +17 | +16.6 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +9 | +9.2 |
| MISSILES NEXT TURN | 44 | 32 | 1 | 0.33 | +1 | +1.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +11 | +11.1 |
| ONE FIGHT FORMULA | 20 | 14 | 1 | 0.33 | +18 | +18.4 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +20 | +19.8 |
| ONE OBJECTIVE FORMULA | 30 | 29 | 1 | 0.33 | +172 | +172.2 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +152 | +151.5 |
| REDIRECT COUNTER | 7 | 6 | 1 | 0.33 | +106 | +105.9 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +23 | +22.5 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +11 | +11.2 |
| THE ROW IN ITS ORDER | 15 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 11 | 11 | 1 | 0.33 | +49 | +49.4 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +20 | +19.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 81 | 81 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 33 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 25 | 25 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 13 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 56 | 54 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 12 | 11 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 29 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 119 | 119 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 11 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 31 | 31 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 19 | 19 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 18 | 18 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 6 | not checked | - | - | - | - |
| ONE ROUTE | 19 | 19 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 279 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 19 | 19 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 87 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 39 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 41 | 38 | 0 | 0.00 | - | - |
| STANDS STILL | 247 | 243 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 28 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 21 | not checked | - | - | - | - |
| THE TABLE BINDS | 303 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p42

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.33 | 1.33 | 17.7 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 0.67 | 52.7 |
| ARMY TABLE | rule | 0.33 | 3.00 | 24.6 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.00 | 26.0 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 54.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 18.4 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 0.8 |
| BEST PRIZE | rule | - | 0.33 | 71.9 |
| CHARGE NOW FIRST | rule | 0.33 | - | 37.9 |
| MARCH OF THE TABLE | rule | 0.33 | - | 20.0 |
| NO REASON | gate | 0.33 | - | 38.6 |
| REFUSING RETIRES | rule | - | 0.33 | 3.5 |

### Plans: cora-bb45c30-p42

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 100% | 48 | 75 | 156% |
| Mine | join | 0.3 | 100% | 0 | 0 | - |
| Mine | move | 26.0 | 97% | 1348 | 0 | 0% |
| Mine | shoot | 15.3 | 41% | 514 | 410 | 80% |
| Opponent | charge | 1.7 | 80% | 91 | 122 | 133% |
| Opponent | move | 40.7 | 97% | 1943 | 0 | 0% |
| Opponent | shoot | 6.3 | 47% | 388 | 237 | 61% |
| Opponent | support | 1.3 | 75% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p42

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 29% | 100% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p42

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 14 (12) | 14 | 0 | 27 | 33% | 3.4 | 15 (5) | 7 (5) | 0 (1) | 4 (6) | 18 (5) |
| Mine | Clean-up | 2 | 108 (2) | 8 | 100 | 0 | 0% | 3.5 | - | - | 108 (2) | 108 (2) | - |
| Mine | Fast Hammer | 3 | 13 (3) | 0 | 13 | 35 | 33% | 2.5 | 0 (1) | 20 (2) | - | 18 (2) | 0 (1) |
| Mine | Hammer | 7 | 9 (7) | 9 | 0 | 14 | 14% | 2.2 | 0 (1) | 8 (3) | 13 (3) | 13 (5) | 0 (2) |
| Mine | Shooter | 6 | 84 (6) | 17 | 67 | 33 | 0% | 2.2 | 103 (1) | 130 (2) | 48 (3) | 101 (5) | 0 (1) |
| Mine | War machine | 8 | 2 (8) | 2 | 0 | 46 | 0% | 1.1 | 0 (1) | 5 (4) | 0 (3) | - | 2 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 11 | 125 (11) | 38 | 87 | 62 | 36% | 3.1 | 189 (3) | 117 (1) | 98 (7) | 125 (11) | - |
| Opponent | Character | 6 | 27 (6) | 27 | 0 | 0 | 0% | 1.7 | 37 (2) | 44 (2) | 0 (2) | 32 (2) | 24 (4) |
| Opponent | Clean-up | 4 | 27 (4) | 0 | 27 | 24 | 50% | 1.0 | - | 56 (2) | 0 (2) | 36 (3) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 10 | 22 (10) | 12 | 10 | 0 | 40% | 2.0 | 0 (4) | 25 (4) | 46 (2) | 24 (2) | 21 (8) |
| Opponent | Holder | 1 | 67 (1) | 0 | 67 | 0 | 100% | - | - | 67 (1) | - | - | 67 (1) |
| Opponent | Shooter | 1 | 150 (1) | 0 | 150 | 0 | 0% | 1.0 | - | 150 (1) | - | 150 (1) | - |

### Charged fights: cora-bb45c30-p42

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 95 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 85 | 60 | 3.0 | 1.3 | 20 | 0 | +20 | 0 of 3 | 3 of 3 | +0 | +30 |
| **Mine** | all armies | 3 | 92 | 20 | 1.0 | 1.3 | 20 | 0 | +20 | 0 of 3 | 3 of 3 | +0 | +30 |
| Opponent | Ogre Kingdoms | 1 | 125 | 125 | 5.0 | 1.0 | 25 | 32 | -7 | 2 of 5 | 2 of 5 | - | -7 |
| Opponent | Vampire Counts | 1 | 0 | 367 | 2.0 | 1.5 | 184 | 30 | +154 | 1 of 2 | 2 of 2 | +162 | +145 |
| Opponent | Wood Elf Realms | 1 | 0 | 381 | 3.0 | 1.0 | 127 | 0 | +127 | 0 of 3 | 1 of 3 | - | +127 |
| **Opponent** | all armies | 3 | 42 | 291 | 3.3 | 1.1 | 87 | 22 | +66 | 3 of 10 | 5 of 10 | +162 | +55 |

### Effective charges: cora-bb45c30-p42

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 0 | 3 (net +20) | 0 | 0 | 0% (0 of 3) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 1 (net +162) | 1 (net +145) | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 3 | 1 (net +60) | 0 | 1 (net +217) | 1 (net +104) | 0 | 0 | 0 | 33% (1 of 3) |

### Charged fights, damage counted: cora-bb45c30-p42

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 360 | 55 | +20 | 20 | 0 | +20 | +5.6 |
| Mine | All fights | 3 | 360 | 55 | +20 | 20 | 0 | +20 | +5.6 |
| Opponent | Long shot (under 50%) | 1 | 109 | 189 | +60 | 99 | 68 | +31 | +28.1 |
| Opponent | Effective (55-75%) | 1 | 499 | 189 | +217 | 300 | 111 | +189 | +38.0 |
| Opponent | 76-89% | 1 | 109 | 104 | +104 | 157 | 18 | +139 | +127.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 500 | 205 | +145 | 205 | 60 | +145 | +29.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 999 | 162 | +162 | 162 | 0 | +162 | +16.2 |
| Opponent | No odds | 5 | 45 | 183 | -7 | 45 | 33 | +11 | +25.2 |
| Opponent | All fights | 10 | 244 | 176 | +66 | 115 | 42 | +72 | +29.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p42 | move | 12 | 3 (25%) | 3 (25%) | 2 (17%) | 7 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

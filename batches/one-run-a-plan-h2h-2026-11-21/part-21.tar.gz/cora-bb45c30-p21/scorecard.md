# Doctrine scorecard: cora-bb45c30-p21

### Scorecard: cora-bb45c30-p21

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 2 | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 1 | - | 1 | 1 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 6 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 3 | 5 | 6 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 4.0 | 2.7 | 2.7 | 0.3 | 0.3 | 0.0 | 0.0 | 66.7 |
| **Average** | | | Opponent | 33% | 3.5 | 2.5 | 4.0 | 2.7 | 0.7 | 0.0 | 0.0 | 113.3 |

### KPIs: cora-bb45c30-p21

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 16) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 60% (6 of 10); on the table 90% | 100% (2 of 2); on the table 100% | 67% (8 of 12); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 0% (0 of 3); on the table 0% | 0% (0 of 4); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 58% (7 of 12); on the table 83% | 33% (2 of 6); on the table 33% | 50% (9 of 18); on the table 67% |
| Magic missiles tried each own turn | 50%+ | - | 33% (4 of 12) | 33% (4 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 36% (4 of 11) | 36% (4 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 27% (4 of 15) | 27% (4 of 15) |
| Points that never fought | lower | 39% (2353 of 6000) | 45% (2695 of 5999) | 42% (5048 of 11999) |
|   infantry points that never fought | lower | 61% (813 of 1332) | 86% (735 of 855) | 71% (1548 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (12 of 20) | 68% (17 of 25) | 64% (29 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.0 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (3 of 3); 1.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (2990 of 5135) | 61% (3308 of 5430) | 60% (6298 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (75%) | 2.0 (75%) |
| MARCHED: its unit marched | - | 0.3 (12%) | 0.3 (12%) |
| FLEEING: fleeing | - | 0.3 (12%) | 0.3 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 0.7 | 0.7 | 1.3 | 2.3 |
| not cast | 6.0 | 1.3 | 1.3 | 2.7 | 17.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (75%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (17%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (78%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (47 of 83) | 25% (2 of 8) | 54% (49 of 91) |
|   cavalry | 62% (5 of 8) | 50% (2 of 4) | 58% (7 of 12) |
|   character | 45% (5 of 11) | 0% (0 of 4) | 33% (5 of 15) |
|   chariot | 20% (1 of 5) | - | 20% (1 of 5) |
|   infantry | 61% (22 of 36) | - | 61% (22 of 36) |
|   monster | 33% (4 of 12) | - | 33% (4 of 12) |
|   war machine | 91% (10 of 11) | - | 91% (10 of 11) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (17%) | 0.3 (17%) | 2.3 (17%) |
| CHARGED: it charged | 1.3 (11%) | 1.3 (67%) | 2.7 (19%) |
| IN COMBAT: it fought this turn or the last | 2.3 (19%) | 0.0 (0%) | 2.3 (17%) |
| MOVED: a war machine that moved | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.0 (25%) | 0.3 (17%) | 3.3 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (19%) | 0.0 (0%) | 2.3 (17%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 3.0 | 0.3 | 89% | 4.3 pts | 13 pts |
| chariot | 0.3 | 0.3 | 0% | 20.6 pts | 7 pts |
| infantry | 13.3 | 1.7 | 90% | 4.3 pts | 57 pts |
| monster | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 3.3 | 2.0 | 80% | 10.2 pts | 34 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.0 | 4.3 |
| Charges that made contact a game | 3.0 | 2.3 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 1.50 declared, 0.50 contact (2 units) | 0.67 declared, 0.33 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.40 contact (20 units) | 0.60 declared, 0.30 contact (20 units) | 0.55 declared, 0.35 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 80% (4 of 5) | 67% (2 of 3) | 100% (2 of 2) | 80% (8 of 10) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 60% (3 of 5) | 50% (1 of 2) | 56% (5 of 9) | 56% (9 of 16) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 71% (5 of 7) | 0% (0 of 3) | - | 50% (5 of 10) |
| Monster | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 75% (3 of 4); on the table 75% | - | 42% | 71% (5 of 7) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 25% (1 of 4); on the table 75% | - | 34% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 75% (3 of 4); on the table 100% | - | 42% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 60% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 40% (2 of 5); on the table 40% | 67% (4 of 6) | 37% | 63% (12 of 19) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p21, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (3) | 83% (5) | 89% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.33 | 1.33 |

### Quality by phase: cora-bb45c30-p21

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 67% (6 of 9) | 27% (3 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (9 of 19) | 0% (0 of 2) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 60% (6 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 2.7 |
| Movement | Points that never moved of their own | 66.7 | 113.3 |
| Movement | Fights charged into per game | 3.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +205 | 2 of 5, net -15 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 1 of 5, net +115 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 7, net +85 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 7, net +0 | 2 of 5, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.7 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 27% (11 of 41) | 75% (3 of 4) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 3.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 10% (1 of 10) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 1.3 | 0.7 |
| Magic | Wounds caused by other spells | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 16.7 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.7 / 2.0 / 0.0 | 1.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 357.7 | 174.3 |
| Combat | Points run down | 107.0 | 60.0 |
| Combat | Net points per charged fight, damage counted | +173 | +59 |
| Combat | Net per 100 charger points, damage counted | +53.3 | +29.1 |
| Combat | First round won (charged fights) | 100% | 71% |
| Combat | Net points per charged fight | +140 | +52 |
| Combat | Net points per supported fight / lone fight | - / +140 | - / +52 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 9 | 0 of 7 |
| Game | Points lost | 325.7 | 431.3 |
| Game | VP from objectives | 596.7 | 886.7 |
| Game | Lone holders (player turns) | 4.0 | 3.5 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) -155 VP
- Points traded per game (both sides' losses): 757
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p21

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.3 | +94.5 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +3.3 | 0.0 | 0.0 |
| ARMY TABLE | 23.7 | +505.9 | 0.0 | 138.7 | 23.3 | +16.9 | 0.0 | 346.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +6.8 | 0.0 | 0.0 | 0.7 | +7.7 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | +24.8 | 56.7 | 0.0 | 0.3 | -33.4 | 71.3 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -23.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.3 | +184.3 | 0.0 | 33.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +12.7 | 0.0 | 0.0 | 1.3 | +11.9 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +7.2 | 0.0 | 35.7 | - | - | - | - |
| CHARGE LOSSES | 6.7 | -291.4 | 0.0 | 158.7 | 17.7 | -1236.6 | 0.0 | 193.3 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 83.7 | 0.0 | 1.3 | +0.0 | 96.7 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -2.6 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 40.0 | 11.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 71.3 | 56.7 |
| COVER ONCE | 12.3 | -838.6 | 0.0 | 210.3 | 11.3 | -1154.5 | 0.0 | 136.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.2 | 0.0 | 10.0 |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 0.0 | 6.3 | +63.8 | 0.0 | 15.0 |
| EXACT ROUND | 2.3 | +2.5 | 96.7 | 0.0 | 4.7 | +38.1 | 190.0 | 10.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.3 | 68.3 | 0.0 | 4.0 | +0.0 | 163.3 | 10.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 19.7 | +247.8 | 0.0 | 0.0 |
| FEATURE BUFFS | 2.0 | +136.0 | 0.0 | 84.0 | 2.7 | +221.4 | 0.0 | 0.0 |
| FIGHT LIFT | 0.7 | +14.1 | 71.3 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +9.7 | 68.3 | 0.0 | 1.7 | +9.1 | 38.3 | 0.0 |
| FIRE AND FLEE | 0.3 | +0.9 | 0.0 | 26.7 | - | - | - | - |
| FIVE ACTION | 83.0 | +6986.3 | 210.3 | 554.0 | 84.0 | +5100.9 | 190.0 | 560.0 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 96.7 | 15.0 | +0.0 | 0.0 | 78.3 |
| FOLLOW UP WEIGHED | 1.7 | +320.7 | 0.0 | 0.0 | 1.0 | +138.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +275.3 | 180.3 | 0.0 | 4.7 | +107.4 | 190.0 | 10.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -44.0 | 0.0 | 26.7 | 0.7 | -3.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +5.1 | 0.0 | 71.3 | - | - | - | - |
| GIVES UP | 0.7 | -4.2 | 0.0 | 0.0 | 0.3 | -9.9 | 0.0 | 0.0 |
| GOAL WALK | 9.3 | +829.1 | 0.0 | 58.3 | 7.0 | +497.4 | 0.0 | 136.7 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.7 | +0.0 | 0.0 | 138.7 | 14.3 | +0.0 | 0.0 | 193.3 |
| HIS CHARGE DENIED | 0.7 | +12.6 | 0.0 | 0.0 | 0.3 | +55.7 | 0.0 | 0.0 |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 38.3 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -11.8 | 0.0 | 20.0 | 5.3 | -64.0 | 0.0 | 56.7 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 80.0 | 5.3 | +0.0 | 0.0 | 76.7 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 38.3 | 11.0 | +0.0 | 0.0 | 30.0 |
| HIS RANDOM MOVE | 15.0 | +0.0 | 0.0 | 200.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 42.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 13.0 | +280.9 | 0.0 | 155.0 | 33.7 | +760.9 | 0.0 | 193.3 |
| HIS SHOTS BY HIS RUN | 11.0 | +162.7 | 0.0 | 131.7 | 38.7 | +1107.5 | 0.0 | 241.7 |
| HIS TURN DENIED | 0.3 | +8.2 | 0.0 | 0.0 | 1.3 | +80.0 | 60.0 | 10.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 12.7 | +0.0 | 0.0 | 168.0 | 17.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.7 | +778.7 | 0.0 | 42.0 | 8.7 | +911.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -138.3 | 180.3 | 0.0 | 3.7 | -101.9 | 118.3 | 0.0 |
| IDLE COST | - | - | - | - | 15.7 | -217.2 | 0.0 | 151.7 |
| JOINT CHARGE NOW | - | - | - | - | 2.3 | +44.2 | 66.7 | 10.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 16.3 | +0.0 | 222.0 | 77.7 | 3.7 | +0.0 | 0.0 | 150.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | +1.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +4.6 | 68.3 | 0.0 | 2.0 | +18.3 | 71.7 | 10.0 |
| MANOEUVRE | 1.7 | -2.9 | 0.0 | 0.0 | 1.0 | +4.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +1.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +23.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -29.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +33.6 | 0.0 | 0.0 | 1.7 | +32.6 | 0.0 | 15.0 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.3 | +46.8 | 0.0 | 0.0 | 2.7 | +41.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +30.4 | 0.0 | 0.0 | 4.0 | +44.4 | 0.0 | 0.0 |
| MOVE ORDER | 3.7 | +0.0 | 38.3 | 65.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 11.3 | +960.9 | 0.0 | 155.0 | 11.7 | +727.4 | 0.0 | 30.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.7 | +349.2 | 0.0 | 0.0 | 5.0 | +189.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 8.3 | +723.9 | 0.0 | 116.7 | 8.3 | +489.7 | 0.0 | 30.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.3 | -131.6 | 180.3 | 0.0 | 4.3 | -139.7 | 190.0 | 10.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.3 | +3.2 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -401.7 | 0.0 | 118.7 | 5.3 | -143.8 | 0.0 | 96.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.0 | -175.9 | 0.0 | 58.3 | 9.7 | -169.4 | 0.0 | 15.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +6.3 | 33.3 | 10.0 |
| ONE OBJECTIVE FORMULA | 3.0 | +74.3 | 0.0 | 42.0 | 5.0 | +0.1 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 1.3 | -61.6 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +3.3 | 0.0 | 0.0 | 0.3 | +0.3 | 38.3 | 0.0 |
| OPENS UP | 0.3 | +20.0 | 28.3 | 0.0 | 1.0 | +59.1 | 60.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +8.8 | 83.7 | 0.0 | 1.0 | +120.7 | 26.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.3 | +13.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -1.2 | 0.0 | 0.0 | 0.3 | -5.6 | 0.0 | 0.0 |
| PLAN RESULT | 38.7 | +313.6 | 83.7 | 410.7 | 43.0 | +139.0 | 83.7 | 449.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 11.7 | -268.1 | 0.0 | 76.7 | 11.7 | -274.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -65.5 | 0.0 | 65.0 | - | - | - | - |
| QUARTER ODDS | 22.3 | +2596.7 | 28.3 | 146.7 | 24.7 | +2801.1 | 66.7 | 256.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 5.0 | +62.4 | 0.0 | 113.3 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +51.0 | 0.0 | 0.0 | 0.3 | -6.8 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +98.9 | 0.0 | 26.7 | 1.3 | +117.1 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +87.9 | 0.0 | 26.7 | 1.0 | +0.0 | 0.0 | 66.7 |
| REDIRECT WEIGHED | 1.0 | +33.4 | 56.7 | 0.0 | 1.3 | +7.2 | 178.3 | 0.0 |
| REFORMS TO MEET IT | 6.3 | -159.0 | 0.0 | 115.0 | 0.7 | -23.2 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +26.1 | 0.0 | 26.7 | 0.3 | +0.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +139.8 | 152.0 | 0.0 | 4.0 | -97.4 | 190.0 | 10.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -34.4 | 112.0 | 0.0 | 1.7 | -22.1 | 0.0 | 0.0 |
| RUN DOWN | 2.7 | -102.0 | 180.3 | 0.0 | 3.3 | -16.9 | 105.0 | 10.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -65.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +11.8 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | +110.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.0 | -46.3 | 0.0 | 26.7 | 3.7 | -161.6 | 0.0 | 146.7 |
| SET UP BY THE SET | 4.7 | +204.0 | 0.0 | 26.7 | 5.3 | +127.5 | 58.3 | 146.7 |
| SET UP TOGETHER | 1.0 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 33.3 | 2.0 | +0.0 | 0.0 | 28.3 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +20.3 | 30.0 | 0.0 | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -20.7 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 6.7 | +11.9 | 0.0 | 173.3 | 18.0 | -338.0 | 0.0 | 56.7 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 10.7 | +472.3 | 0.0 | 137.7 | 1.0 | +14.4 | 0.0 | 56.7 |
| SPELL WORTH | 1.0 | +28.8 | 71.3 | 0.0 | 3.0 | +9.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 10.0 | +0.0 | 0.0 | 127.0 | 13.3 | +0.0 | 0.0 | 156.7 |
| STAND AND SHOOT | 0.3 | -1.8 | 28.3 | 0.0 | 1.0 | -3.5 | 65.0 | 10.0 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 30.0 | +0.0 | 30.0 | 66.7 | 18.7 | +0.0 | 0.0 | 190.0 |
| STAY WORTH | 12.3 | +48.7 | 0.0 | 0.0 | 1.0 | +4.2 | 0.0 | 85.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | -23.0 | 0.0 | 0.0 |
| STUBBORN BY POINTS | 0.7 | +14.8 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +74.3 | 0.0 | 76.7 | 6.7 | +257.8 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +74.3 | 0.0 | 76.7 | 6.7 | +257.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +15.3 | 0.0 | 0.0 | 1.0 | +4.3 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -63.7 | 0.0 | 38.3 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 42.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 100.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 28.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 28.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.3 | +0.0 | 0.0 | 277.0 | 39.7 | +0.0 | 0.0 | 218.3 |
| TIED UP BY THE SUM | 1.0 | +97.9 | 0.0 | 0.0 | 1.7 | +149.3 | 85.0 | 0.0 |
| TIME ON OUR SIDE | 38.3 | +501.5 | 0.0 | 239.3 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 30.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 28.3 |
| WHO FIGHTS | 0.3 | -0.1 | 0.0 | 0.0 | 0.7 | +6.7 | 38.3 | 10.0 |
| WHO HITS BACK | 1.3 | +99.9 | 0.0 | 0.0 | 0.3 | +3.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -268.8 | 0.0 | 100.3 | 5.7 | -715.8 | 0.0 | 136.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +43.2 | 33.3 | 10.0 |
| WOUNDED STAYS OUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.3 | +8.5 | 0.0 | 0.0 | 2.0 | +21.7 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p21

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 141 | 141 | 82 | 27.33 | +2101 | +25.6 |
| LEGAL CHARGES ONLY | 60 | 60 | 60 | 20.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 49 | 49 | 46 | 15.33 | +3617 | +78.6 |
| FIVE ACTION | 501 | 478 | 42 | 14.00 | +3089 | +73.5 |
| HIS SHOTS BY HIS RUN | 149 | 142 | 41 | 13.67 | +301 | +7.3 |
| HIS SHOT LIST | 140 | 129 | 35 | 11.67 | +177 | +5.0 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -1637 | -46.8 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 70 | 70 | 27 | 9.00 | -1627 | -60.3 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| MOVE TO CHARGE COMPUTED | 69 | 53 | 23 | 7.67 | +1279 | +55.6 |
| QUARTER ODDS | 141 | 135 | 21 | 7.00 | +1640 | +78.1 |
| MOVE ORDER | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 50 | 41 | 19 | 6.33 | +1035 | +54.5 |
| SUPPORT ADDS | 28 | 25 | 14 | 4.67 | +342 | +24.5 |
| SUPPORT WORKED OUT | 28 | 25 | 14 | 4.67 | +342 | +24.5 |
| GOAL WALK | 49 | 49 | 13 | 4.33 | +725 | +55.8 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +245 | +24.5 |
| SET UP BY THE SET | 30 | 30 | 10 | 3.33 | +545 | +54.5 |
| SHOT RISK POINTS | 74 | 69 | 10 | 3.33 | +42 | +4.2 |
| COVER ONCE | 71 | 39 | 9 | 3.00 | +448 | +49.8 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1377 | +172.1 |
| FOUR ROUNDS | 24 | 24 | 8 | 2.67 | +196 | +24.5 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| IDLE COST | 47 | 38 | 7 | 2.33 | +59 | +8.4 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +133 | +19.0 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| REDIRECT WEIGHED | 7 | 7 | 7 | 2.33 | +799 | +114.2 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 8 | 8 | 6 | 2.00 | +161 | +26.8 |
| NEARER NOT NEEDED | 38 | 38 | 5 | 1.67 | +191 | +38.2 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +62 | +12.5 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 1.33 | +283 | +70.8 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -185 | -46.2 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +41 | +10.3 |
| RANDOM MOVE BY FIGURES | 15 | 15 | 4 | 1.33 | +187 | +46.8 |
| RISK BY ARC | 18 | 18 | 4 | 1.33 | +141 | +35.2 |
| TIME ON OUR SIDE | 115 | 94 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 21 | 21 | 3 | 1.00 | +23 | +7.7 |
| FALLS SHORT | 59 | 51 | 3 | 1.00 | +23 | +7.8 |
| FEATURE BUFFS | 14 | 14 | 3 | 1.00 | +313 | +104.5 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 5 | 3 | 1.00 | +147 | +48.9 |
| MAX FOR POSITIONING | 11 | 8 | 3 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 18 | 12 | 3 | 1.00 | +44 | +14.7 |
| NO DOUBLE ROUNDS | 23 | 23 | 3 | 1.00 | +82 | +27.2 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| WOUNDS ON THE RANKS | 7 | 7 | 3 | 1.00 | +23 | +7.8 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -109 | -54.6 |
| CAST JOB | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 6 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 8 | 8 | 2 | 0.67 | -199 | -99.3 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 20 | 20 | 2 | 0.67 | +40 | +20.0 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +85 | +42.5 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +44 | +22.0 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -20 | -10.2 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +80 | +39.9 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +40 | +19.9 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 2 | 0.67 | +1 | +0.6 |
| STUBBORN BY POINTS | 2 | 2 | 2 | 0.67 | +44 | +22.2 |
| SURE REACH TOGETHER | 5 | 4 | 2 | 0.67 | +21 | +10.6 |
| WHOLE FIGHT DANGER | 30 | 29 | 2 | 0.67 | +31 | +15.6 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +10 | +10.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +22 | +21.7 |
| CHARGE LOSSES | 73 | 71 | 1 | 0.33 | +130 | +129.8 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 7 | 7 | 1 | 0.33 | +5 | +4.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +3 | +2.6 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +15 | +15.3 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +69 | +69.4 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| LOST AFTER ESCAPE | 10 | 10 | 1 | 0.33 | +4 | +3.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -5 | -5.0 |
| MISSILES NEXT TURN | 22 | 17 | 1 | 0.33 | +0 | +0.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NEXT OBJECTIVE NEARER | 1 | 1 | 1 | 0.33 | +20 | +19.8 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +1 | +1.2 |
| OPENS UP | 4 | 4 | 1 | 0.33 | +17 | +17.2 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +150 | +150.3 |
| REDIRECT COUNTER | 8 | 6 | 1 | 0.33 | +97 | +96.8 |
| REFORMS TO MEET IT | 21 | 15 | 1 | 0.33 | +47 | +47.0 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +15 | +14.6 |
| SHOTS AFTER THE MOVES | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 35 | 22 | 1 | 0.33 | +24 | +23.9 |
| STAY WORTH | 40 | 38 | 1 | 0.33 | +57 | +57.3 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| THE ROW IN ITS ORDER | 21 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +32 | +31.9 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +1 | +1.2 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 5 | 5 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 65 | 60 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 18 | 18 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 73 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 34 | 32 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 28 | 26 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 57 | 55 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 43 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 44 | 37 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 56 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 45 | 43 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 90 | 90 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 6 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 47 | 24 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 24 | 16 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 245 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 12 | 9 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 18 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 17 | 17 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 28 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 70 | 66 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 146 | 141 | 0 | 0.00 | - | - |
| STRIKE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 234 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p21

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 4.33 | 44.1 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 5.33 | 60.3 |
| ARMY TABLE | rule | 3.67 | 4.00 | 71.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 35.4 |
| ONE PROMISE A TARGET | rule | - | 1.33 | 46.2 |
| JOINT CHARGE NOW | rule | - | 1.00 | 41.7 |
| RULE SWITCHED OFF | gate | 1.00 | - | 115.4 |
| BEST PRIZE | rule | 0.33 | 0.33 | 54.6 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 99.3 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 2.8 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 10.2 |
| REDIRECT WEIGHED | rule | 0.33 | 0.33 | 27.3 |
| FALLBACK | gate | 0.33 | - | 5.0 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 33.0 |
| MARCH OF THE TABLE | rule | - | 0.33 | 5.0 |
| NO REASON | gate | - | 0.33 | 56.5 |

### Plans: cora-bb45c30-p21

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 343 | 134 | 39% |
| Mine | move | 30.3 | 97% | 1856 | 0 | 0% |
| Mine | shoot | 5.7 | 41% | 419 | 179 | 43% |
| Mine | support | 0.3 | 100% | 44 | 0 | 0% |
| Opponent | charge | 3.0 | 33% | 335 | 139 | 41% |
| Opponent | join | 3.3 | 100% | 126 | 0 | 0% |
| Opponent | move | 36.0 | 95% | 1722 | 0 | 0% |
| Opponent | shoot | 0.3 | 0% | 90 | 0 | 0% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p21

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 50% | 100% | 0% | - | 50% | 0% | 0% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p21

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Mine | Chaff | 2 | 188 (2) | 19 | 169 | 50 | 0% | 1.0 | 375 (1) | 0 (1) | - | 375 (1) | 0 (1) |
| Mine | Character | 8 | 49 (8) | 49 | 0 | 0 | 12% | 3.1 | 5 (4) | 140 (3) | 0 (1) | 56 (6) | 11 (2) |
| Mine | Clean-up | 1 | 70 (1) | 0 | 70 | 100 | 0% | 3.0 | 70 (1) | - | - | 70 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 5 (4) | 5 | 0 | 12 | 0% | 2.8 | 0 (3) | 27 (1) | - | 6 (3) | 0 (1) |
| Mine | Hammer | 3 | 22 (3) | 0 | 22 | 26 | 33% | 1.5 | 0 (1) | 29 (2) | - | 0 (1) | 29 (2) |
| Mine | Shooter | 6 | 18 (6) | 0 | 18 | 19 | 0% | 1.8 | 0 (3) | 43 (3) | - | 36 (3) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 28 | 60% | 3.5 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 16 (10) | 16 | 0 | 29 | 40% | 2.8 | 23 (4) | 24 (4) | 0 (1) | 19 (6) | 19 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 7 (6) | 7 | 0 | 33 | 33% | 3.8 | 0 (3) | 17 (3) | - | 0 (4) | 17 (2) |
| Opponent | Hammer | 5 | 57 (5) | 19 | 38 | 18 | 20% | 2.8 | 59 (3) | 54 (2) | - | 70 (4) | 0 (1) |
| Opponent | Holder | 4 | 42 (4) | 12 | 30 | 17 | 25% | 5.0 | 0 (1) | 60 (3) | - | 20 (2) | 73 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 13 (3) | 13 | 0 | 0 | 33% | 4.5 | 0 (1) | 0 (1) | 31 (1) | 31 (1) | 0 (2) |

### Charged fights: cora-bb45c30-p21

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 1029 | 2.0 | 1.0 | 514 | 0 | +514 | 1 of 2 | 2 of 2 | - | +514 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 290 | 4.0 | 1.0 | 72 | 25 | +48 | 0 of 4 | 4 of 4 | - | +48 |
| Mine | Lizardmen | 1 | 50 | 45 | 3.0 | 1.0 | 15 | 0 | +15 | 0 of 3 | 3 of 3 | - | +15 |
| **Mine** | all armies | 3 | 17 | 455 | 3.0 | 1.0 | 152 | 11 | +140 | 1 of 9 | 9 of 9 | - | +140 |
| Opponent | Vampire Counts | 1 | 0 | 175 | 4.0 | 1.0 | 44 | 0 | +44 | 0 of 4 | 3 of 4 | - | +44 |
| Opponent | Warriors of Chaos | 2 | 30 | 111 | 1.5 | 1.0 | 74 | 10 | +64 | 0 of 3 | 2 of 3 | - | +64 |
| **Opponent** | all armies | 3 | 20 | 132 | 2.3 | 1.0 | 57 | 4 | +52 | 0 of 7 | 5 of 7 | - | +52 |

### Effective charges: cora-bb45c30-p21

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 2 | 0 | 0 | 0 | 1 (net +859) | 1 (net +170) | 0 | 0 | 0% (0 of 2) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +205) | 0 | 0 | 1 (net -100) | 1 (net +85) | 0 | 1 | 0% (0 of 3) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 3 | 1 (net -30) | 0 | 1 (net +115) | 0 | 0 | 0 | 1 | 50% (1 of 2) |

### Charged fights, damage counted: cora-bb45c30-p21

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 275 | 205 | +205 | 205 | 0 | +205 | +74.5 |
| Mine | 76-89% | 2 | 387 | 203 | +380 | 541 | 119 | +422 | +108.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 405 | 186 | +0 | 155 | 0 | +155 | +38.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 351 | 85 | +85 | 130 | 26 | +104 | +29.6 |
| Mine | No odds | 2 | 209 | 125 | +22 | 22 | 0 | +22 | +10.8 |
| Mine | All fights | 9 | 325 | 145 | +140 | 209 | 35 | +173 | +53.3 |
| Opponent | Long shot (under 50%) | 2 | 40 | 76 | -15 | 0 | 15 | -15 | -37.5 |
| Opponent | Effective (55-75%) | 1 | 144 | 115 | +115 | 115 | 0 | +115 | +79.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 118 | 158 | +0 | 24 | 0 | +24 | +19.9 |
| Opponent | No odds | 2 | 482 | 141 | +141 | 141 | 0 | +141 | +29.2 |
| Opponent | All fights | 7 | 204 | 124 | +52 | 63 | 4 | +59 | +29.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p21 | move | 34 | 4 (12%) | 4 (12%) | 9 (26%) | 21 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

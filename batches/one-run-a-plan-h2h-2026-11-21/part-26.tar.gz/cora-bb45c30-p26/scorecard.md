# Doctrine scorecard: cora-bb45c30-p26

### Scorecard: cora-bb45c30-p26

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 8 | 0 | 0 | 0 | 285 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 5 | 0 | 0 | 0 | 74 |
| L0235 | 1 | 1 | Mine | no | 2 | - | 0 | 7 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | yes | 3 | 2 | 0 | 4 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0319 | 1 | 1 | Opponent | no | 3 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.0 | - | 0.0 | 5.0 | 0.0 | 0.0 | 0.0 | 235.0 |
| **Average** | | | Opponent | 50% | 3.0 | 2.5 | 1.0 | 4.0 | 0.0 | 0.0 | 0.0 | 66.3 |

### KPIs: cora-bb45c30-p26

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 12% (1 of 8) | 0% (0 of 13) | 5% (1 of 21) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 57% (24 of 42) | 17% (4 of 24) | 42% (28 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (24 of 42) | 17% (4 of 24) | 42% (28 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (9 of 12) | - | 75% (9 of 12) |
| Points that never fought | lower | 67% (3879 of 5797) | 92% (5490 of 6000) | 79% (9369 of 11797) |
|   infantry points that never fought | lower | 57% (788 of 1374) | 100% (842 of 842) | 74% (1630 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 75% (15 of 20) | 59% (16 of 27) | 66% (31 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 6.0 uses a game | 50% (1 of 2); 1.7 uses a game | 83% (5 of 6); 3.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (3 of 5); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (3 of 6); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (2694 of 4039) | 61% (3387 of 5515) | 64% (6081 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (100%) | 1.0 (15%) | 7.0 (55%) |
| MARCHED: its unit marched | 0.0 (0%) | 1.0 (15%) | 1.0 (8%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 3.0 (45%) | 3.0 (24%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.7 (25%) | 1.7 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.0 | 3.3 | 9.3 | 0.3 |
| not cast | 3.0 | 6.7 | 12.7 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (33%) | 0.0 (0%) | 7.0 (55%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (67%) | 3.3 (50%) | 3.0 (24%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.7 (13%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 3.3 (50%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 27.3 (99%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 1.0 a game | 1.7 a game |
| stood (cast and not dispelled) | 71% (5 of 7) | 67% (2 of 3) | 70% (7 of 10) |
| the unit moved after it | 100% (5 of 5) | 0% (0 of 2) | 71% (5 of 7) |
| it charged on its next turn | 0% (0 of 5) | 0% (0 of 2) | 0% (0 of 7) |
| the enemy charged it first | 0% (0 of 5) | 0% (0 of 2) | 0% (0 of 7) |
| it fought by the end of its next turn | 0% (0 of 5) | 0% (0 of 2) | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | 0% (0 of 2) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 100% (5 of 5) | 100% (2 of 2) | 100% (7 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (26 of 36) | 51% (43 of 84) | 58% (69 of 120) |
|   cavalry | - | 50% (9 of 18) | 50% (9 of 18) |
|   character | - | 42% (5 of 12) | 42% (5 of 12) |
|   chariot | 75% (9 of 12) | 58% (7 of 12) | 67% (16 of 24) |
|   infantry | - | 40% (12 of 30) | 40% (12 of 30) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 71% (17 of 24) | - | 71% (17 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (30%) | 2.0 (15%) | 3.0 (18%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (7%) | 1.0 (6%) |
| MOVED: a war machine that moved | 1.0 (30%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 0.0 (0%) | 6.7 (49%) | 6.7 (39%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (30%) | 1.0 (7%) | 2.0 (12%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (7%) | 1.0 (6%) |
| OTHER BAR | 0.3 (10%) | 1.7 (12%) | 2.0 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.7 | 83% | 3.5 pts | 14 pts |
| character | 1.7 | 0.3 | 80% | 5.7 pts | 9 pts |
| chariot | 5.3 | 7.3 | 38% | 25.4 pts | 135 pts |
| infantry | 4.0 | 3.0 | 67% | 10.3 pts | 41 pts |
| monster | 3.3 | 1.3 | 80% | 8.5 pts | 28 pts |
| war machine | 5.7 | 3.7 | 65% | 7.8 pts | 44 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 3.0 | 1.5 |
| Charges that made contact a game | 0.0 | 1.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (25 units) | 0.31 declared, 0.17 contact (29 units) | 0.17 declared, 0.09 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (1 of 1) | - | 25% (1 of 4) |
| Character in a unit | 100% (5 of 5) | 50% (3 of 6) | - | 73% (8 of 11) |
| Character on its own | 100% (3 of 3) | 100% (2 of 2) | 100% (2 of 2) | 100% (7 of 7) |
| Chariot | 50% (1 of 2) | 50% (1 of 2) | - | 50% (2 of 4) |
| Infantry | 60% (3 of 5) | 33% (1 of 3) | - | 50% (4 of 8) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 25% (1 of 4) | - | 50% (3 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | - | 80% (24 of 30) | 69% | 67% (8 of 12) | 100% (4 of 4); 9.0 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | - | 0% (0 of 12) | 63% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 98% | 57% (4 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 8% (1 of 12) | 82% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | - | 50% (3 of 6) | 94% | 50% (6 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p26, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | - | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p26

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | - | 60% (3 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (12 of 24) | 23% (3 of 13) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 55% (6 of 11) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 14% (1 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 5.0 | 4.0 |
| Movement | Points that never moved of their own | 235.0 | 66.3 |
| Movement | Fights charged into per game | 0.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.0 | 14.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 78% (7 of 9) | 19% (8 of 43) |
| Shooting | Points destroyed by shooting units | 132.7 | 83.7 |
| Shooting | War machine shots | 5.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (8 of 17) | - |
| Shooting | Points destroyed by war machines | 0.0 | 28.3 |
| Magic | Magic missiles cast | 4.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (2 of 14) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 14.0 | 3.0 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 41.7 | 10.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 0.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 11.3 | 17.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | - | +45 |
| Combat | Net per 100 charger points, damage counted | - | +16.5 |
| Combat | First round won (charged fights) | - | 50% |
| Combat | Net points per charged fight | - | +4 |
| Combat | Net points per supported fight / lone fight | - / - | - / +4 |
| Combat | Charged fights on a top-3 enemy unit | - | 3 of 5 |
| Game | Points lost | 139.3 | 215.3 |
| Game | VP from objectives | 863.3 | 940.0 |
| Game | Lone holders (player turns) | 4.0 | 3.0 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +5 VP
- Points traded per game (both sides' losses): 355
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p26

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| ARMY TABLE | 21.0 | +458.5 | 0.0 | 220.7 | 29.7 | -114.2 | 0.0 | 132.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -6.6 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 55.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.3 | +163.0 | 338.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.3 | +9.5 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 2.0 | +60.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +14.8 | 0.0 | 10.0 | 0.7 | +1.2 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 1.3 | -2.3 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.3 | -356.5 | 0.0 | 34.7 | 10.3 | -429.8 | 0.0 | 228.7 |
| CHARGE NOW FIRST | - | - | - | - | 0.7 | +0.0 | 28.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 12.7 | +0.0 | 0.0 | 28.3 | 9.3 | +0.0 | 0.0 | 55.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.0 | +241.0 | 0.0 | 0.0 | 1.0 | +20.4 | 0.0 | 0.0 |
| COVER ONCE | 3.0 | -93.1 | 0.0 | 0.0 | 2.3 | -60.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -2.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | - | - | - | - | 2.0 | -9.8 | 45.7 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.3 | +0.3 | 28.3 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 10.0 | - | - | - | - |
| FALLS SHORT | 21.7 | +298.5 | 0.0 | 66.7 | 3.3 | +111.0 | 0.0 | 18.3 |
| FEATURE BUFFS | 11.3 | +586.4 | 0.0 | 20.0 | 1.0 | +77.6 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 27.0 | 0.0 |
| FIVE ACTION | 104.3 | +8284.6 | 832.7 | 377.3 | 102.0 | +7084.4 | 487.0 | 336.0 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 128.0 | 3.7 | +0.0 | 0.0 | 18.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 2.7 | +130.0 | 45.7 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -10.0 | 0.0 | 0.0 |
| GOAL WALK | 9.0 | +885.0 | 0.0 | 28.3 | 13.0 | +997.8 | 0.0 | 0.0 |
| GROUND FLIERS | 0.7 | +22.4 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 3.0 | +122.3 | 361.3 | 0.0 | 2.0 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +23.6 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 13.3 | -210.3 | 0.0 | 170.0 | 2.3 | -34.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | 9.7 | +0.0 | 0.0 | 142.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 28.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 24.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 68.3 | +2265.3 | 0.0 | 377.3 | 66.0 | +3959.9 | 0.0 | 336.0 |
| HIS SHOTS BY HIS RUN | 60.3 | +1065.3 | 0.0 | 367.3 | 46.3 | +1078.3 | 0.0 | 336.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +28.7 | 0.0 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 35.7 | +0.0 | 0.0 | 20.0 | 20.7 | +0.0 | 0.0 | 36.7 |
| HOLDER ASSIGNMENT | 16.3 | +1784.7 | 0.0 | 10.0 | 14.3 | +1408.0 | 0.0 | 18.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 2.3 | -102.2 | 28.3 | 0.0 |
| IDLE COST | 18.0 | -99.3 | 0.0 | 56.7 | 4.0 | -67.2 | 0.0 | 18.3 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | - | - | - | - | 2.3 | +0.0 | 28.3 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +0.2 | 28.3 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.0 | -0.2 | 17.3 | 0.0 |
| MANOEUVRE | 1.3 | -7.4 | 0.0 | 0.0 | 2.7 | -5.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +58.6 | 0.0 | 0.0 | 0.7 | +48.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +22.1 | 0.0 | 0.0 | 1.3 | +61.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -4.4 | 0.0 | 0.0 | 0.7 | +127.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +36.0 | 0.0 | 85.0 | 0.7 | +7.1 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +388.5 | 0.0 | 54.0 | 5.0 | +105.2 | 0.0 | 114.3 |
| MISSILES NEXT TURN | 6.7 | +257.5 | 0.0 | 27.0 | 5.0 | +65.5 | 0.0 | 114.3 |
| MISSILES ON ONE TARGET | 1.7 | -83.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 3.7 | +0.0 | 83.7 | 27.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.0 | -68.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.0 | +675.9 | 0.0 | 85.0 | 2.0 | +158.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +194.3 | 0.0 | 0.0 | 10.7 | +484.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.0 | +566.8 | 0.0 | 85.0 | 2.0 | +158.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -15.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 2.0 | -15.0 | 45.7 | 0.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -1484.2 | 0.0 | 0.0 | 4.3 | -106.3 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 1.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.3 | -13.7 | 0.0 | 85.0 | 3.0 | -55.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 10.0 | +62.3 | 0.0 | 10.0 | 4.0 | -101.7 | 0.0 | 18.3 |
| ONE PROMISE A TARGET | 1.3 | -77.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +3.8 | 0.0 | 0.0 |
| PLAN RESULT | 45.3 | +284.6 | 590.0 | 212.0 | 44.0 | +85.6 | 56.7 | 317.7 |
| PROMISE BY ITS OWN SUM | 8.3 | -3081.1 | 0.0 | 0.0 | 5.0 | -112.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | -4.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 2.7 | -5.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 20.3 | +1184.1 | 686.0 | 177.3 | 20.0 | +2530.3 | 260.3 | 228.7 |
| RANDOM MOVE BY FIGURES | 4.0 | +68.0 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.7 | +31.5 | 0.0 | 122.0 | 1.3 | -59.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 66.7 | 2.7 | +0.0 | 0.0 | 41.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.3 | -273.4 | 0.0 | 28.3 | 1.3 | -10.3 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| RISK BY ARC | - | - | - | - | 1.3 | +23.3 | 28.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -13.5 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.7 | -15.9 | 45.7 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -2.4 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -11.3 | 0.0 | 10.0 | 0.3 | -16.5 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 10.0 | - | - | - | - |
| SECOND LOOK | - | - | - | - | 1.0 | +23.5 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 0.7 | -0.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +7.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +18.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +107.6 | 0.0 | 0.0 | 1.3 | +40.7 | 54.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 55.3 | +457.8 | 0.0 | 323.3 | 51.0 | +1343.5 | 0.0 | 336.0 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 9.7 | +676.6 | 0.0 | 0.0 | 19.0 | +483.8 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +18.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 85.0 | 5.7 | +0.0 | 0.0 | 114.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -4.7 | 0.0 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 45.3 | +0.0 | 832.7 | 30.0 | 46.0 | +0.0 | 441.3 | 34.0 |
| STAY WORTH | 21.0 | +246.9 | 604.0 | 0.0 | 20.7 | +104.8 | 168.7 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +1.0 | 0.0 | 11.3 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.0 | +2.7 | 0.0 | 10.0 | 1.7 | +53.5 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.0 | +2.7 | 0.0 | 10.0 | 1.7 | +53.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +1.2 | 0.0 | 0.0 | 0.7 | +4.2 | 0.0 | 11.3 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.8 | 0.0 | 0.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 18.3 |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 28.3 | 28.3 | 3.3 | +0.0 | 0.0 | 18.3 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 17.3 | 5.3 | +0.0 | 0.0 | 114.3 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 17.3 | 4.0 | +0.0 | 0.0 | 114.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.0 | +0.0 | 0.0 | 193.7 | 49.0 | +0.0 | 0.0 | 162.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +84.0 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 9.3 | +156.5 | 0.0 | 0.0 | 59.7 | +495.6 | 0.0 | 45.3 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 56.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 56.7 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | +1.6 | 28.3 | 0.0 |
| WHO HITS BACK | 0.3 | +107.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.3 | -66.8 | 0.0 | 0.0 | 0.7 | -46.6 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 6.0 | +516.0 | 0.0 | 0.0 | 4.0 | +530.4 | 0.0 | 228.7 |

### Rule changes: cora-bb45c30-p26

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SHOT RISK POINTS | 319 | 311 | 118 | 39.33 | +3409 | +28.9 |
| HIS SHOTS BY HIS RUN | 320 | 307 | 113 | 37.67 | +1486 | +13.2 |
| ARMY TABLE | 152 | 152 | 98 | 32.67 | +961 | +9.8 |
| HIS SHOT LIST | 403 | 395 | 98 | 32.67 | +1302 | +13.3 |
| HOLDER ASSIGNMENT | 92 | 92 | 86 | 28.67 | +4950 | +57.6 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 207 | 185 | 26 | 8.67 | +62 | +2.4 |
| FIVE ACTION | 619 | 595 | 24 | 8.00 | +1538 | +64.1 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -4771 | -207.4 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| MOVE ORDER | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| QUARTER ODDS | 121 | 120 | 19 | 6.33 | +1523 | +80.1 |
| PROMISE BY ITS OWN SUM | 40 | 40 | 16 | 5.33 | -9580 | -598.7 |
| GOAL WALK | 66 | 60 | 15 | 5.00 | +672 | +44.8 |
| MOVE TO CHARGE COMPUTED | 21 | 19 | 15 | 5.00 | +1286 | +85.8 |
| NEXT CHARGE BY LIST | 18 | 17 | 14 | 4.67 | +1168 | +83.4 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 10 | 3.33 | +179 | +17.9 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +204 | +22.7 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CAST JOB | 10 | 10 | 8 | 2.67 | +13 | +1.6 |
| PROMISE SHOT AWAY | 8 | 8 | 8 | 2.67 | -17 | -2.1 |
| WOUNDS ON THE RANKS | 30 | 30 | 8 | 2.67 | +500 | +62.5 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| STAY WORTH | 125 | 107 | 7 | 2.33 | +15 | +2.2 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 86 | 66 | 6 | 2.00 | +679 | +113.1 |
| CHARGE LOSSES | 86 | 83 | 5 | 1.67 | +397 | +79.5 |
| CASTING BLOCK | 6 | 6 | 4 | 1.33 | +58 | +14.6 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -7 | -1.7 |
| FALLS SHORT | 75 | 54 | 4 | 1.33 | +132 | +33.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +321 | +80.2 |
| MISSILES IN THE MOVE | 36 | 23 | 4 | 1.33 | +272 | +67.9 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -231 | -57.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FEATURE BUFFS | 37 | 36 | 3 | 1.00 | +57 | +19.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 6 | 6 | 3 | 1.00 | +0 | +0.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +1 | +0.4 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +71 | +23.6 |
| SHOTS AFTER THE MOVES | 13 | 13 | 3 | 1.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 16 | 16 | 2 | 0.67 | +6 | +3.0 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 2 | 0.67 | +1 | +0.3 |
| FOUR ROUNDS | 8 | 5 | 2 | 0.67 | +29 | +14.6 |
| IDLE COST | 66 | 46 | 2 | 0.67 | +5 | +2.6 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| MARCH CHECK | 6 | 6 | 2 | 0.67 | +99 | +49.7 |
| ONE OBJECTIVE FORMULA | 42 | 28 | 2 | 0.67 | +392 | +196.1 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SURE REACH TOGETHER | 3 | 3 | 2 | 0.67 | +0 | +0.1 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +3 | +1.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -20 | -19.9 |
| CHARGE NOW FIRST | 2 | 2 | 1 | 0.33 | -78 | -77.5 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COVER ONCE | 16 | 10 | 1 | 0.33 | +4 | +3.5 |
| FALL BACK GOOD ORDER | 4 | 3 | 1 | 0.33 | +0 | +0.5 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 47 | 46 | 1 | 0.33 | +0 | +0.0 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +0 | +0.5 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +2 | +2.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 19 | 6 | 1 | 0.33 | +7 | +7.3 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -12 | -12.5 |
| REDIRECT COUNTER | 12 | 6 | 1 | 0.33 | +3 | +2.8 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| RISK BY ARC | 4 | 2 | 1 | 0.33 | +0 | +0.5 |
| SET UP BY THE SET | 2 | 2 | 1 | 0.33 | +15 | +14.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +3 | +3.0 |
| SUPPORT ADDS | 8 | 8 | 1 | 0.33 | +24 | +24.4 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -39 | -39.3 |
| SUPPORT WORKED OUT | 8 | 8 | 1 | 0.33 | +24 | +24.4 |
| THE ROW IN ITS ORDER | 23 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 2 | 1 | 1 | 0.33 | +0 | +0.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +294 | +293.8 |
| WHOLE FIGHT DANGER | 6 | 6 | 1 | 0.33 | +160 | +160.0 |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 66 | 62 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 6 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | not checked | - | - | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 33 | 33 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | not checked | - | - | - | - |
| HIS CHARGE LIST | 27 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 8 | 8 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 36 | 36 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 74 | 70 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 169 | 164 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 13 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 35 | 22 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 5 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 43 | 39 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 6 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE ROUTE | 13 | 10 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 1 | not checked | - | - | - | - |
| PLAN RESULT | 268 | trace | - | - | - | - |
| REAL GROUND | 13 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 14 | 13 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 3 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 2 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 39 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 41 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 274 | 266 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 288 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p26

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 3.00 | 239.9 |
| ARMY TABLE | rule | 1.00 | 4.33 | 88.9 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 1.33 | 598.7 |
| PROMISE SHOT AWAY | rule | 2.67 | - | 2.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.67 | 31.4 |
| ONE PROMISE A TARGET | rule | 1.33 | - | 57.8 |
| RULE SWITCHED OFF | gate | - | 1.33 | 53.3 |
| CHAFF PASSED | rule | - | 1.00 | 2.2 |
| BEST PRIZE | rule | - | 0.33 | 19.9 |
| CHARGE NOW FIRST | rule | - | 0.33 | 77.5 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 12.5 |
| SUPPORT NARROWED | rule | - | 0.33 | 39.3 |

### Plans: cora-bb45c30-p26

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 38.7 | 97% | 2903 | 0 | 0% |
| Mine | shoot | 6.7 | 65% | 322 | 285 | 88% |
| Opponent | charge | 1.7 | 0% | 91 | 9 | 10% |
| Opponent | move | 40.0 | 96% | 2556 | 0 | 0% |
| Opponent | shoot | 2.3 | 57% | 66 | 77 | 116% |

### Battle groups: cora-bb45c30-p26

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 38% | 67% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p26

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 8 (11) | 8 | 0 | 0 | 45% | 2.2 | - | 1 (6) | 15 (5) | 8 (11) | - |
| Mine | Clean-up | 2 | 258 (2) | 0 | 258 | 0 | 100% | - | 316 (1) | - | 198 (1) | 258 (2) | - |
| Mine | Fast Hammer | 10 | 0 (10) | 0 | 0 | 47 | 90% | 6.0 | 0 (6) | 0 (1) | 0 (3) | 0 (7) | 0 (3) |
| Mine | Hammer | 9 | 60 (9) | 21 | 38 | 4 | 33% | 3.0 | 0 (2) | 77 (4) | 83 (3) | 60 (9) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | - | 0 (2) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 23 (8) | 0 | 23 | 45 | 75% | 4.5 | 47 (3) | 0 (4) | 0 (1) | 25 (7) | 0 (1) |
| Opponent | Character | 7 | 2 (7) | 2 | 0 | 0 | 29% | 1.8 | 0 (1) | 3 (4) | 0 (1) | 3 (4) | 0 (2) |
| Opponent | Clean-up | 3 | 42 (3) | 42 | 0 | 0 | 67% | 2.0 | - | 42 (3) | - | 42 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 58 (10) | 8 | 50 | 6 | 60% | 1.5 | 21 (5) | 105 (4) | 0 (1) | 24 (5) | 83 (5) |
| Opponent | Shooter | 4 | 107 (4) | 16 | 92 | 0 | 0% | 2.0 | 74 (1) | 121 (2) | 107 (1) | 86 (3) | 184 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (2) | - | 0 (2) | - |

### Charged fights: cora-bb45c30-p26

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 62 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Chaos Dwarfs | 1 | 398 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 174 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 1 of 1 | 0 of 1 | - | -34 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 196 | 52 | 2.0 | 1.0 | 26 | 0 | +26 | 0 of 2 | 1 of 1 | - | +26 |
| **Opponent** | all armies | 3 | 122 | 17 | 1.7 | 1.0 | 10 | 7 | +4 | 3 of 5 | 2 of 4 | - | +4 |

### Effective charges: cora-bb45c30-p26

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Orc & Goblin Tribes | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 1 (net +52) | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p26

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 1 | 350 | 310 | +0 | 133 | 0 | +133 | +38.0 |
| Opponent | 76-89% | 1 | 126 | 52 | +52 | 52 | 0 | +52 | +41.3 |
| Opponent | No odds | 3 | 294 | 213 | -11 | 32 | 18 | +13 | +4.5 |
| Opponent | All fights | 5 | 272 | 200 | +4 | 56 | 11 | +45 | +16.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p26 | move | 14 | 1 (7%) | 1 (7%) | 1 (7%) | 12 (86%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

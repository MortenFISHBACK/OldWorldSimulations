# Doctrine scorecard: cora-bb45c30-p1

### Scorecard: cora-bb45c30-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 4 | 2 | 0 | 6 | 1 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | - | 2 | 4 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 5 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 2.3 | - | 0.0 | 1.3 | 0.0 | 0.0 | 0.0 | 36.7 |
| **Average** | | | Opponent | 0% | 2.0 | 2.0 | 1.3 | 5.0 | 0.3 | 0.0 | 0.0 | 131.3 |

### KPIs: cora-bb45c30-p1

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 6) | 0% (0 of 10) | 0% (0 of 16) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 38% (34 of 90) | 17% (4 of 24) | 33% (38 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (34 of 90) | 17% (4 of 24) | 33% (38 of 114) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (4 of 6) | 67% (4 of 6) |
| Points that never fought | lower | 55% (3140 of 5700) | 94% (5570 of 5899) | 75% (8710 of 11599) |
|   infantry points that never fought | lower | 60% (1622 of 2703) | 97% (1179 of 1219) | 71% (2801 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (8 of 15) | 76% (19 of 25) | 68% (27 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.7 uses a game | 75% (3 of 4); 4.0 uses a game | 86% (6 of 7); 4.3 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 1.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (2284 of 4077) | 73% (3541 of 4883) | 65% (5825 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 14.7 (79%) | 5.3 (80%) | 20.0 (79%) |
| MARCHED: its unit marched | 2.3 (12%) | 1.3 (20%) | 3.7 (14%) |
| REAR RANK: in a rear rank | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 10.7 | 2.0 | 10.0 | 12.7 | 1.0 |
| not cast | 7.3 | 8.0 | 6.0 | 25.3 | 43.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (50%) | 1.0 (17%) | 20.0 (79%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (5%) | 0.0 (0%) | 0.7 (11%) | 0.7 (3%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 7.0 (95%) | 4.0 (50%) | 4.3 (72%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 41.0 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 9.3 a game | 2.3 a game | 5.8 a game |
| stood (cast and not dispelled) | 79% (22 of 28) | 71% (5 of 7) | 77% (27 of 35) |
| the unit moved after it | 73% (16 of 22) | 60% (3 of 5) | 70% (19 of 27) |
| it charged on its next turn | 0% (0 of 22) | 0% (0 of 5) | 0% (0 of 27) |
| the enemy charged it first | 14% (3 of 22) | 0% (0 of 5) | 11% (3 of 27) |
| it fought by the end of its next turn | 5% (1 of 22) | 0% (0 of 5) | 4% (1 of 27) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 22) | 0% (0 of 5) | 0% (0 of 27) |
| none of these (no charge, no fight, no charge escaped) | 82% (18 of 22) | 100% (5 of 5) | 85% (23 of 27) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 41% (12 of 29) | 52% (35 of 67) | 49% (47 of 96) |
|   cavalry | - | 75% (9 of 12) | 75% (9 of 12) |
|   character | - | 73% (8 of 11) | 73% (8 of 11) |
|   chariot | - | 56% (5 of 9) | 56% (5 of 9) |
|   infantry | 41% (12 of 29) | 17% (4 of 23) | 31% (16 of 52) |
|   monster | - | 75% (9 of 12) | 75% (9 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (53%) | 1.7 (16%) | 4.7 (29%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.0 (18%) | 7.0 (66%) | 8.0 (49%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (24%) | 0.7 (6%) | 2.0 (12%) |
| OTHER BAR | 0.0 (0%) | 0.7 (6%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 3.0 | 46% | 6.0 pts | 26 pts |
| character | 2.7 | 1.0 | 62% | 3.4 pts | 9 pts |
| chariot | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 5.3 | 2.3 | 69% | 7.8 pts | 41 pts |
| monster | 3.0 | 0.3 | 89% | 0.9 pts | 3 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 2.0 | 1.0 |
| Charges that made contact a game | 0.0 | 1.0 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (15 units) | 0.19 declared, 0.09 contact (32 units) | 0.13 declared, 0.06 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 60% (3 of 5) | 80% (8 of 10) | - | 73% (11 of 15) |
| Character on its own | - | 100% (1 of 1) | 100% (1 of 1) | 100% (2 of 2) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 29% (2 of 7) | - | 50% (6 of 12) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 67% (2 of 3); on the table 67% | 34% (37 of 108) | 63% | 57% (12 of 21) | 100% (5 of 5); 5.5 uses a game | 100% (3 of 3); 1.2 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 96% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 100% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p1, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | - | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 20% (1 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 14% (2 of 14) | 19% (4 of 21) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 50% (9 of 18) | 0% (0 of 7) |
| Strategy | Lone characters that fought | - | 0% (0 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 5.0 |
| Movement | Points that never moved of their own | 36.7 | 131.3 |
| Movement | Fights charged into per game | 0.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 2, net +55 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 12.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (3 of 12) | 75% (27 of 36) |
| Shooting | Points destroyed by shooting units | 0.0 | 18.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 7.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 4% (1 of 23) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 22.7 | 3.7 |
| Magic | Wounds caused by other spells | 3.0 | - |
| Magic | Points destroyed by magic (all spells) | 201.3 | 18.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.3 / 1.0 / 1.0 / 0.0 | 2.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 68.0 | 0.0 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | - | -11 |
| Combat | Net per 100 charger points, damage counted | - | -20.3 |
| Combat | First round won (charged fights) | - | 33% |
| Combat | Net points per charged fight | - | +7 |
| Combat | Net points per supported fight / lone fight | - / - | - / +7 |
| Combat | Charged fights on a top-3 enemy unit | - | 2 of 3 |
| Game | Points lost | 98.3 | 367.7 |
| Game | VP from objectives | 810.0 | 643.3 |
| Game | Lone holders (player turns) | 2.3 | 2.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +460 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 466
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 36.7 |
| ARMY TABLE | 10.3 | +136.2 | 0.0 | 80.0 | 21.0 | +300.3 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.7 | +21.3 | 36.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 4.3 | +422.0 | 155.0 | 0.0 | 3.0 | +38.7 | 21.7 | 0.0 |
| CASTS AFTER FRIENDS | 6.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +16.0 | 0.0 | 20.0 |
| CHAFF PASSED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.3 | -325.3 | 0.0 | 86.7 | 10.7 | -389.1 | 0.0 | 83.3 |
| CHARGE NOW FIRST | - | - | - | - | 0.3 | +0.0 | 18.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 4.7 | +0.0 | 0.0 | 55.0 | 14.7 | +0.0 | 0.0 | 83.3 |
| CONVEYANCE SEARCH | 5.7 | +684.9 | 0.0 | 0.0 | 2.0 | +50.3 | 0.0 | 0.0 |
| COVER ONCE | 2.0 | -36.3 | 0.0 | 21.7 | 4.0 | -144.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 74.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +10.8 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.0 | -1.1 | 36.7 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.0 | +0.0 | 18.3 | 0.0 |
| FALLS SHORT | 1.7 | +39.2 | 0.0 | 0.0 | 23.7 | +200.9 | 0.0 | 61.7 |
| FEATURE BUFFS | 13.7 | +583.7 | 0.0 | 178.3 | - | - | - | - |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 53.7 | +8757.0 | 211.7 | 270.0 | 103.3 | +3976.2 | 168.3 | 727.3 |
| FLANK NOT WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 10.0 |
| FOUR ROUNDS | - | - | - | - | 1.7 | +25.0 | 36.7 | 0.0 |
| GOAL WALK | 5.3 | +634.0 | 0.0 | 0.0 | 0.7 | +21.4 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.3 | +0.0 | 0.0 | 61.7 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.7 | +0.0 | 0.0 | 86.7 | 4.0 | +0.0 | 0.0 | 83.3 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -30.9 | 0.0 | 36.7 | 4.7 | -153.0 | 0.0 | 113.3 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 110.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 7.0 | +0.0 | 0.0 | 86.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 86.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 33.7 | +447.2 | 0.0 | 91.7 | 53.3 | +2994.3 | 0.0 | 477.3 |
| HIS SHOTS BY HIS RUN | 34.7 | +308.5 | 0.0 | 251.7 | 39.0 | +1157.7 | 0.0 | 401.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 39.7 | +0.0 | 0.0 | 353.3 | 14.3 | +0.0 | 0.0 | 113.3 |
| HOLDER ASSIGNMENT | 15.7 | +1818.6 | 0.0 | 80.0 | 11.0 | +1222.8 | 0.0 | 151.3 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.0 | -7.2 | 36.7 | 0.0 |
| IDLE COST | 1.0 | -13.5 | 0.0 | 0.0 | 29.3 | -353.6 | 0.0 | 123.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -4.3 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 36.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 11.3 | 226.7 | - | - | - | - |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 1.0 | +4.4 | 18.3 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 0.3 | -0.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +6.1 | 0.0 | 0.0 | 0.7 | +1.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +28.1 | 0.0 | 0.0 | 0.3 | +54.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -68.5 | 0.0 | 0.0 | 0.3 | -37.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +7.0 | 0.0 | 18.3 | 0.3 | +0.5 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 74.7 |
| MISSILES IN THE MOVE | 9.7 | +801.2 | 0.0 | 0.0 | 6.7 | +96.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 9.0 | +478.6 | 0.0 | 0.0 | 6.0 | +54.8 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 3.7 | -206.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 11.3 |
| MOVE SPELL OUT OF RANGE | 2.7 | -235.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 1.3 | +54.4 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +351.3 | 0.0 | 43.3 | 3.0 | +149.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 0.7 | +36.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.0 | -7.2 | 36.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 4.3 | -7.4 | 0.0 | 0.0 | 2.0 | -2.2 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -68.9 | 0.0 | 0.0 | 2.3 | -30.7 | 0.0 | 13.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.0 | -45.3 | 0.0 | 36.7 | 1.3 | -24.5 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +132.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.7 | +149.4 | 0.0 | 61.7 | 2.7 | +80.9 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.3 | +5.5 | 81.7 | 0.0 | 1.7 | +1.9 | 108.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +22.8 | 36.7 | 0.0 |
| PLAN RESULT | 22.7 | +84.4 | 56.7 | 160.0 | 46.0 | +126.0 | 0.0 | 494.7 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 1.3 | -18.2 | 0.0 | 0.0 |
| QUARTER ODDS | 13.3 | +2368.7 | 0.0 | 0.0 | 21.0 | +1945.5 | 36.7 | 110.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +137.7 | 0.0 | 113.3 |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +42.8 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 73.3 | 3.0 | +0.0 | 0.0 | 51.0 |
| RESERVE FALL BACK | 0.3 | +9.5 | 0.0 | 0.0 | - | - | - | - |
| RESERVE MOVE SPELL | 1.7 | +35.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.3 | -35.3 | 36.7 | 0.0 |
| RUN DOWN | - | - | - | - | 0.7 | -0.1 | 36.7 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -0.7 | 0.0 | 20.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +45.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.3 | 0.0 | 20.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 10.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +66.0 | 56.7 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -4.8 | 18.3 | 0.0 |
| SHOT RISK POINTS | 18.7 | -262.1 | 0.0 | 156.7 | 56.7 | +739.6 | 0.0 | 670.7 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 5.3 | +93.0 | 0.0 | 43.3 | 13.0 | +110.0 | 0.0 | 123.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +45.9 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +6.8 | 0.0 | 0.0 | 2.0 | +4.6 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -3.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 55.0 | 3.0 | +0.0 | 0.0 | 28.3 |
| STANDS FOR A REASON | - | - | - | - | 11.3 | +0.0 | 36.7 | 0.0 |
| STANDS STILL | 16.0 | +0.0 | 211.7 | 55.0 | 44.0 | +0.0 | 131.7 | 358.0 |
| STAY WORTH | 9.7 | +132.4 | 0.0 | 0.0 | 21.7 | +105.3 | 131.7 | 123.3 |
| SUPPORT ADDS | 1.0 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.0 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 28.3 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 28.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 26.0 | +0.0 | 0.0 | 135.0 | 49.7 | +0.0 | 0.0 | 311.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +7.8 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 23.0 | +626.3 | 0.0 | 190.0 | 7.3 | +54.6 | 0.0 | 73.0 |
| WAITS AGAIN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -121.3 | 0.0 | 86.7 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +4.3 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 11.7 | +287.9 | 0.0 | 0.0 | 0.7 | +61.3 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 261 | 259 | 78 | 26.00 | +949 | +12.2 |
| ARMY TABLE | 94 | 94 | 75 | 25.00 | +864 | +11.5 |
| HOLDER ASSIGNMENT | 80 | 80 | 72 | 24.00 | +4220 | +58.6 |
| HIS SHOTS BY HIS RUN | 221 | 217 | 70 | 23.33 | +915 | +13.1 |
| SHOT RISK POINTS | 226 | 223 | 55 | 18.33 | +694 | +12.6 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| CASTING BLOCK | 22 | 22 | 19 | 6.33 | +314 | +16.5 |
| IDLE COST | 91 | 73 | 17 | 5.67 | +154 | +9.1 |
| QUARTER ODDS | 103 | 103 | 17 | 5.67 | +2173 | +127.8 |
| WOUNDS ON THE RANKS | 37 | 37 | 17 | 5.67 | +319 | +18.8 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| STAY WORTH | 94 | 76 | 12 | 4.00 | +86 | +7.2 |
| GOAL WALK | 18 | 18 | 11 | 3.67 | +1356 | +123.3 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 91 | 76 | 10 | 3.33 | +75 | +7.5 |
| OFF BEST | 9 | 9 | 9 | 3.00 | -299 | -33.2 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CAST JOB | 8 | 8 | 7 | 2.33 | +30 | +4.3 |
| FEATURE BUFFS | 41 | 41 | 7 | 2.33 | +159 | +22.7 |
| FALLS SHORT | 76 | 58 | 6 | 2.00 | +110 | +18.4 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FIVE ACTION | 471 | 466 | 5 | 1.67 | +267 | +53.5 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RESERVE MOVE SPELL | 5 | 5 | 5 | 1.67 | +108 | +21.5 |
| CHARGE LOSSES | 81 | 78 | 4 | 1.33 | +111 | +27.8 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +247 | +61.7 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 4 | 1.33 | +413 | +103.3 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 49 | 32 | 3 | 1.00 | +404 | +134.8 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +19 | +9.4 |
| COVER ONCE | 18 | 11 | 2 | 0.67 | +10 | +5.1 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +22 | +11.0 |
| MAX FOR POSITIONING | 3 | 3 | 2 | 0.67 | +4 | +1.8 |
| MISSILES NEXT TURN | 45 | 30 | 2 | 0.67 | +38 | +18.8 |
| MOVE TO CHARGE COMPUTED | 4 | 2 | 2 | 0.67 | +74 | +37.1 |
| NEXT CHARGE BY LIST | 2 | 2 | 2 | 0.67 | +74 | +37.1 |
| ONE JOINT FIGURE | 2 | 2 | 2 | 0.67 | +61 | +30.6 |
| ONE OBJECTIVE FORMULA | 31 | 18 | 2 | 0.67 | +94 | +47.0 |
| PROMISE BY ITS OWN SUM | 4 | 4 | 2 | 0.67 | -54 | -27.2 |
| REDIRECT COUNTER | 7 | 6 | 2 | 0.67 | +38 | +19.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOUR ROUNDS | 5 | 5 | 1 | 0.33 | +4 | +4.1 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -13 | -12.8 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +11 | +10.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -7 | -6.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 31 | 26 | 1 | 0.33 | +48 | +48.5 |
| OPENS A LANE | 9 | 2 | 1 | 0.33 | +0 | +0.1 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +32 | +32.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +28 | +28.5 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +6 | +5.7 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 1 | 0.33 | +31 | +31.1 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +9 | +8.8 |
| CASTS AFTER FRIENDS | 25 | trace | - | - | - | - |
| CHARGE NOW FIRST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 58 | 56 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 23 | not checked | - | - | - | - |
| EVASIVE BY THE ODDS | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 29 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 6 | 6 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 24 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 23 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 20 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 162 | 162 | 0 | 0.00 | - | - |
| HONEST WORTH | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 26 | 26 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 11 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 8 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 19 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 16 | 9 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 206 | trace | - | - | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 34 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 13 | 13 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 55 | 33 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 28 | 28 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 34 | 33 | 0 | 0.00 | - | - |
| STANDS STILL | 180 | 179 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 31 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 24 | not checked | - | - | - | - |
| THE TABLE BINDS | 227 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 8 | 8 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 1.67 | 1.33 | 60.8 |
| JOB FIRST | gate | 0.67 | 2.00 | 36.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 7.4 |
| PROMISE BY ITS OWN SUM | rule | - | 0.67 | 27.2 |
| JOINT CHARGE NOW | rule | - | 0.33 | 12.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 6.7 |
| NO REASON | gate | - | 0.33 | 5.3 |

### Plans: cora-bb45c30-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 19.3 | 93% | 2888 | 0 | 0% |
| Mine | shoot | 3.3 | 30% | 494 | 84 | 17% |
| Opponent | charge | 1.0 | 67% | 21 | 39 | 187% |
| Opponent | move | 39.3 | 94% | 1037 | 0 | 0% |
| Opponent | shoot | 5.3 | 62% | 234 | 87 | 37% |
| Opponent | support | 0.3 | 0% | 3 | 0 | 0% |

### Battle groups: cora-bb45c30-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 67% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 26 (18) | 26 | 0 | 0 | 11% | 1.9 | 76 (3) | 21 (12) | 0 (3) | 38 (12) | 3 (6) |
| Mine | Hammer | 6 | 44 (6) | 2 | 42 | 0 | 50% | 4.7 | 112 (1) | 35 (4) | 11 (1) | 49 (4) | 33 (2) |
| Mine | Holder | 3 | 65 (3) | 0 | 65 | 0 | 100% | - | - | 97 (2) | - | - | 97 (2) |
| Mine | Shooter | 6 | 69 (6) | 0 | 69 | 33 | 0% | 2.5 | - | 83 (5) | 0 (1) | 92 (4) | 23 (2) |
| Opponent | Chaff | 6 | 118 (6) | 0 | 118 | 41 | 67% | 4.0 | 0 (3) | 429 (2) | 0 (1) | 118 (6) | - |
| Opponent | Character | 8 | 3 (8) | 3 | 0 | 0 | 25% | 1.7 | 0 (4) | 6 (4) | - | 0 (4) | 6 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 7 | 38 (7) | 18 | 20 | 28 | 57% | 2.0 | 111 (1) | 0 (3) | 25 (3) | 29 (3) | 42 (4) |
| Opponent | Hammer | 13 | 16 (13) | 3 | 13 | 27 | 54% | 1.7 | - | 23 (8) | 0 (5) | 11 (3) | 18 (10) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Shooter | 3 | 99 (3) | 0 | 99 | 62 | 67% | 1.0 | 257 (1) | 0 (2) | - | 257 (1) | 0 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |

### Charged fights: cora-bb45c30-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 201 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 0 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 0 of 1 | 1 of 1 | - | +55 |
| Opponent | Ogre Kingdoms | 1 | 55 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 2 of 2 | 0 of 2 | - | -17 |
| Opponent | Wood Elf Realms | 1 | 55 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 37 | 18 | 1.0 | 1.0 | 18 | 11 | +7 | 2 of 3 | 1 of 3 | - | +7 |

### Effective charges: cora-bb45c30-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +55) | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 1 | 40 | 322 | +0 | 0 | 32 | -32 | -80.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 85 | 55 | +55 | 55 | 21 | +34 | +39.7 |
| Opponent | No odds | 1 | 34 | 836 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 3 | 53 | 404 | +7 | 18 | 29 | -11 | -20.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p1 | move | 3 | 0 (0%) | 0 (0%) | 1 (33%) | 2 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

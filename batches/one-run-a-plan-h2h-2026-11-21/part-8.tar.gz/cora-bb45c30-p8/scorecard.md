# Doctrine scorecard: cora-bb45c30-p8

### Scorecard: cora-bb45c30-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 9 | 2 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 3 | 3 | 2 | 2 | 0 | 0 | 0 | 110 |
| L1431 | 3 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 170 |
| **Average** | | | Mine | 33% | 4.5 | 2.3 | 1.7 | 1.0 | 0.0 | 0.0 | 0.0 | 93.3 |
| **Average** | | | Opponent | 0% | 1.5 | 2.5 | 2.0 | 2.3 | 0.7 | 0.0 | 0.0 | 93.3 |

### KPIs: cora-bb45c30-p8

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 14) | 0% (0 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 67% | - | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 88% (7 of 8); on the table 88% | 100% (2 of 2); on the table 100% | 90% (9 of 10); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 11% (2 of 18) | 42% (10 of 24) | 29% (12 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 14% (2 of 14) | 50% (10 of 20) | 35% (12 of 34) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 49% (2937 of 6000) | 38% (2303 of 6000) | 44% (5240 of 12000) |
|   infantry points that never fought | lower | 83% (1085 of 1315) | 61% (566 of 921) | 74% (1651 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (13 of 25) | 78% (25 of 32) | 67% (38 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.7 uses a game | 50% (1 of 2); 1.3 uses a game | 75% (3 of 4); 2.5 uses a game |
| Bound items with another spell used |  | 40% (4 of 10); 1.7 uses a game | 0.0 uses a game | 40% (4 of 10); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (2874 of 5720) | 74% (4293 of 5830) | 62% (7167 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (38%) | 1.7 (36%) | 3.7 (37%) |
| MARCHED: its unit marched | 1.7 (31%) | 1.7 (36%) | 3.3 (33%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.3 (6%) | 0.7 (14%) | 1.0 (10%) |
| FLEEING: fleeing | 0.3 (6%) | 0.7 (14%) | 1.0 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (12%) | 0.0 (0%) | 0.7 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 0.7 | 2.3 | 4.0 | 0.3 | 1.3 |
| not cast | 3.7 | 3.3 | 3.7 | 10.0 | 1.7 | 22.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (90%) | 0.3 (9%) | 3.7 (37%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (33%) | 0.7 (40%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (10%) | 0.3 (20%) | 0.0 (0%) |
| FLEEING: fleeing | 1.0 (27%) | 0.0 (0%) | 0.7 (18%) | 1.0 (10%) | 0.0 (0%) | 1.7 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.3 (10%) | 0.7 (18%) | 0.7 (7%) | 0.0 (0%) | 2.0 (9%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (64%) | 0.0 (0%) | 2.0 (55%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.3 a game | 1.2 a game |
| stood (cast and not dispelled) | 50% (3 of 6) | - | 50% (3 of 6) |
| the unit moved after it | 33% (1 of 3) | - | 33% (1 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 33% (1 of 3) | - | 33% (1 of 3) |
| it fought by the end of its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 67% (2 of 3) | - | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (64 of 94) | 77% (24 of 31) | 70% (88 of 125) |
|   cavalry | 58% (7 of 12) | 88% (15 of 17) | 76% (22 of 29) |
|   character | 34% (11 of 32) | 33% (2 of 6) | 34% (13 of 38) |
|   infantry | 87% (26 of 30) | 88% (7 of 8) | 87% (33 of 38) |
|   war machine | 100% (20 of 20) | - | 100% (20 of 20) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (27%) | 1.0 (43%) | 3.7 (30%) |
| CHARGED: it charged | 2.3 (23%) | 1.0 (43%) | 3.3 (27%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 2.7 (27%) | 0.3 (14%) | 3.0 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.3 | 1.0 | 91% | 2.7 pts | 30 pts |
| character | 6.3 | 2.0 | 74% | 11.2 pts | 71 pts |
| infantry | 19.7 | 5.7 | 75% | 8.5 pts | 167 pts |
| war machine | 6.7 | 4.3 | 65% | 26.5 pts | 177 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 3.3 | 3.2 |
| Charges that made contact a game | 2.7 | 1.7 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | - | 0.67 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.32 contact (22 units) | 0.42 declared, 0.21 contact (24 units) | 0.37 declared, 0.26 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (7 of 15) | 100% (2 of 2) | - | 53% (9 of 17) |
| Character in a unit | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Character on its own | 100% (7 of 7) | 60% (3 of 5) | 43% (3 of 7) | 68% (13 of 19) |
| Infantry | 83% (10 of 12) | 50% (1 of 2) | - | 79% (11 of 14) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 88% (7 of 8); on the table 88% | 11% (2 of 18) | 49% | 52% (13 of 25) | 100% (2 of 2); 3.7 uses a game | 40% (4 of 10); 1.7 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 50% (6 of 12) | 30% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 27% | 83% (10 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 58% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p8, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 80% (4) | 25% (1) | 56% (5) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.33 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.00 | 1.00 |

### Quality by phase: cora-bb45c30-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 88% (7 of 8) | 38% (3 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (16 of 34) | 22% (4 of 18) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 1) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 91% (10 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 93.3 | 93.3 |
| Movement | Fights charged into per game | 2.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 4, net -104 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 5, net +126 | 1 of 4, net +350 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +118 | 1 of 4, net +280 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.3 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (16 of 46) | 88% (21 of 24) |
| Shooting | Points destroyed by shooting units | 361.3 | 50.3 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (12 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 20% (1 of 5) |
| Magic | Wounds caused by magic missiles | 2.0 | 1.3 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.7 / 0.3 | 1.3 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 109.3 | 121.3 |
| Combat | Points run down | 113.0 | 237.0 |
| Combat | Net points per charged fight, damage counted | +136 | -4 |
| Combat | Net per 100 charger points, damage counted | +28.0 | -1.8 |
| Combat | First round won (charged fights) | 100% | 60% |
| Combat | Net points per charged fight | +136 | +135 |
| Combat | Net points per supported fight / lone fight | +57 / +175 | - / +135 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 1 of 5 |
| Game | Points lost | 559.0 | 885.0 |
| Game | VP from objectives | 590.0 | 483.3 |
| Game | Lone holders (player turns) | 4.5 | 1.5 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +509 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1444
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +21.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 24.7 | +206.5 | 0.0 | 402.7 | 23.7 | +90.5 | 0.0 | 148.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 114.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.7 | +173.5 | 366.0 | 46.7 | - | - | - | - |
| CAST JOB | 0.7 | +54.4 | 228.7 | 0.0 | 1.0 | +15.6 | 143.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.7 | +3.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +2.8 | 0.0 | 0.0 | 1.0 | +133.3 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.0 | -537.2 | 0.0 | 619.7 | 18.7 | -1612.6 | 0.0 | 548.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 145.0 | 0.0 | 2.7 | +0.0 | 171.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 287.3 | 7.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.7 | +223.4 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.7 | -577.0 | 0.0 | 244.3 | 5.0 | -286.4 | 0.0 | 67.0 |
| DENIED BY THE FIGHT | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -86.9 | 0.0 | 0.0 | 0.3 | -64.1 | 93.3 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +99.2 | 107.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 4.0 | +33.8 | 0.0 | 125.0 |
| EXACT ROUND | 1.0 | +8.3 | 116.0 | 0.0 | 1.7 | +26.0 | 124.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +1.7 | 200.7 | 0.0 | 1.7 | +5.8 | 167.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 20.3 | +270.2 | 0.0 | 288.7 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +6.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +14.7 | 0.0 | 0.0 | 0.3 | +2.0 | 50.3 | 0.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 88.7 | 0.0 | 0.3 | +0.0 | 133.3 | 0.0 |
| FIVE ACTION | 95.0 | +6563.5 | 1868.7 | 1539.3 | 74.3 | +5103.4 | 609.3 | 1204.3 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 486.0 | 7.0 | +0.0 | 0.0 | 125.0 |
| FOCUS FIRE | 0.3 | +7.8 | 70.3 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.3 | +220.3 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +322.3 | 267.7 | 0.0 | 2.7 | +107.2 | 217.3 | 0.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 83.3 |
| FRIEND SHOOTS FIRST | 2.0 | -11.2 | 0.0 | 186.7 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 1.0 | +110.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -8.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 6.7 | +277.1 | 0.0 | 0.0 | 6.7 | +309.4 | 0.0 | 0.0 |
| GUN FIGURES | 0.3 | +46.9 | 70.3 | 0.0 | - | - | - | - |
| GUN MASK | 0.7 | -3.6 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.3 | +0.0 | 0.0 | 83.3 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 433.0 | 10.7 | +0.0 | 0.0 | 330.7 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 100.7 | 7.3 | +0.0 | 0.0 | 83.3 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 93.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -31.3 | 0.0 | 100.7 | 2.7 | -21.7 | 0.0 | 153.3 |
| HIS ONE QUARTER | 6.3 | +0.0 | 0.0 | 388.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 93.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 13.0 | +0.0 | 0.0 | 196.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 95.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.3 | +1102.8 | 0.0 | 871.3 | 39.3 | +783.1 | 0.0 | 664.0 |
| HIS SHOTS BY HIS RUN | 34.7 | +701.4 | 0.0 | 1244.7 | 45.3 | +803.5 | 0.0 | 649.7 |
| HIS TURN DENIED | 0.7 | +8.3 | 38.0 | 0.0 | 0.3 | +2.9 | 23.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 847.3 | 11.7 | +0.0 | 0.0 | 192.0 |
| HOLDER ASSIGNMENT | 9.0 | +655.1 | 0.0 | 423.7 | 7.3 | +757.1 | 0.0 | 96.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -139.5 | 267.7 | 0.0 | 1.7 | -102.1 | 116.7 | 0.0 |
| IDLE COST | - | - | - | - | 11.3 | -157.3 | 0.0 | 274.3 |
| JOINT CHARGE NOW | 0.7 | -13.8 | 38.0 | 0.0 | 1.0 | +61.3 | 194.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 434.0 | 0.0 | 3.7 | +0.0 | 151.0 | 155.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 67.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +7.3 | 48.0 | 0.0 | 1.0 | +4.7 | 143.7 | 0.0 |
| MANOEUVRE | 0.7 | -2.8 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 67.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +32.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +40.5 | 0.0 | 0.0 | 0.3 | +11.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +7.5 | 0.0 | 0.0 | 1.0 | +37.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +77.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +9.3 | 0.0 | 0.0 | 1.0 | +167.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.3 | +3.0 | 0.0 | 0.0 | 2.7 | +267.0 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.7 | +170.7 | 0.0 | 0.0 | 5.7 | +108.0 | 0.0 | 130.0 |
| MISSILES NEXT TURN | 7.0 | +103.4 | 0.0 | 0.0 | 6.0 | +89.0 | 0.0 | 65.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 7.0 | +711.6 | 0.0 | 186.7 | 7.0 | +632.4 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +224.0 | 0.0 | 194.0 | 5.0 | +181.0 | 0.0 | 174.0 |
| NEXT CHARGE BY LIST | 5.7 | +395.7 | 0.0 | 186.7 | 4.0 | +417.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -132.1 | 219.7 | 0.0 | 2.3 | -95.4 | 217.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.0 | +7.5 | 0.0 | 65.0 |
| NOT WORTH A CAST | 0.7 | -0.3 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 6.7 | -211.1 | 67.0 | 0.0 | 3.7 | -123.6 | 0.0 | 103.7 |
| ONE CHALLENGE TEST | 0.3 | -5.1 | 0.0 | 0.0 | 0.3 | +1.2 | 50.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -161.5 | 0.0 | 141.0 | 6.0 | -94.0 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +31.5 | 0.0 | 0.0 | 0.3 | +26.7 | 93.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -39.3 | 0.0 | 330.3 | 2.3 | +70.2 | 0.0 | 48.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +12.0 | 38.0 | 0.0 | 0.7 | +26.9 | 23.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +37.5 | 36.7 | 0.0 | 1.3 | +7.1 | 124.0 | 0.0 |
| OWN CAST FIRST | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +7.5 | 0.0 | 0.0 |
| PLAN RESULT | 42.3 | +935.3 | 861.7 | 1028.0 | 37.0 | +485.4 | 656.3 | 839.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.7 | -368.4 | 0.0 | 0.0 | 6.7 | -28.1 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.4 | 0.0 | 0.0 | 0.3 | -2.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -1.1 | 36.7 | 0.0 | - | - | - | - |
| QUARTER ODDS | 23.7 | +2163.0 | 884.7 | 388.0 | 21.7 | +2768.6 | 93.3 | 387.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +52.6 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 1.3 | +73.6 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 18.3 |
| REFORMS TO MEET IT | 2.7 | -47.9 | 0.0 | 186.7 | 2.7 | -26.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.7 | +88.8 | 0.0 | 38.0 |
| RISK BY ARC | 2.0 | -103.3 | 141.7 | 0.0 | 2.3 | -27.1 | 217.3 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.0 | -9.4 | 153.0 | 0.0 | 0.7 | -11.9 | 116.7 | 0.0 |
| RUN DOWN | 2.0 | -95.1 | 229.7 | 0.0 | 2.0 | -18.7 | 217.3 | 0.0 |
| SAME CHARGE LATER | 0.7 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 50.3 | 1.0 | +10.6 | 0.0 | 38.0 |
| SECOND LOOK | 0.3 | +3.9 | 67.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | - | - | - | - | 1.7 | +3.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -10.0 | 0.0 | 93.3 | 0.3 | -29.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | -10.6 | 0.0 | 186.7 | 0.7 | +9.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.7 | +42.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.7 | +0.0 | 0.0 | 46.7 | 6.3 | +0.0 | 0.0 | 74.7 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +24.8 | 67.0 | 0.0 | 2.7 | +16.1 | 47.7 | 65.0 |
| SHOT OR CHARGE | 0.3 | -8.3 | 38.0 | 0.0 | 0.3 | -3.9 | 0.0 | 0.0 |
| SHOT RISK POINTS | 21.0 | -212.0 | 0.0 | 670.0 | 25.7 | -276.4 | 0.0 | 584.0 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 21.7 | +714.9 | 0.0 | 46.7 | 7.0 | +165.2 | 0.0 | 36.7 |
| SPELL SETS UP CHARGE | 0.7 | +42.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.3 | +84.6 | 0.0 | 0.0 | 1.7 | +3.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +1.3 | 40.0 | 0.0 | 0.7 | -5.8 | 100.7 | 0.0 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 194.0 | 8.0 | +0.0 | 0.0 | 67.0 |
| STAND AND SHOOT | 0.3 | -3.0 | 38.0 | 0.0 | 0.3 | -1.4 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 47.0 | +0.0 | 1601.0 | 373.3 | 27.0 | +0.0 | 392.0 | 310.3 |
| STAY WORTH | 29.0 | +164.7 | 960.0 | 70.0 | 13.7 | +118.9 | 196.0 | 38.0 |
| STRIKE BY THE ODDS | 0.7 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.7 | +252.5 | 0.0 | 194.0 | 5.3 | +1134.3 | 0.0 | 116.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 23.3 | 0.0 |
| SUPPORT WORKED OUT | 5.7 | +252.5 | 0.0 | 194.0 | 5.3 | +1134.3 | 0.0 | 116.7 |
| SURE REACH TOGETHER | 0.3 | +2.0 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.7 | +2.8 | 0.0 | 183.7 | 0.3 | +6.4 | 0.0 | 114.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 50.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 93.3 | 5.0 | +0.0 | 0.0 | 238.3 |
| THE STEP BACK IS MADE | - | - | - | - | 4.0 | +0.0 | 0.0 | 257.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 46.0 | +0.0 | 0.0 | 769.7 | 34.0 | +0.0 | 0.0 | 485.0 |
| TIED UP BY THE SUM | 1.3 | +133.8 | 152.7 | 0.0 | 0.3 | +32.0 | 23.3 | 0.0 |
| TIME ON OUR SIDE | 45.0 | +540.0 | 140.3 | 529.0 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 186.7 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +36.7 | 0.0 | 0.0 |
| WHO GETS IN | 0.3 | +18.7 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +95.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +3.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -141.5 | 0.0 | 196.0 | 3.7 | -1251.9 | 0.0 | 297.3 |
| WHOLE FIGHT GAIN | 0.3 | +23.4 | 0.0 | 0.0 | 0.3 | +9.9 | 93.3 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 5.7 | +150.8 | 0.0 | 268.0 |

### Rule changes: cora-bb45c30-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 145 | 145 | 97 | 32.33 | +339 | +3.5 |
| HIS SHOT LIST | 230 | 219 | 54 | 18.00 | +1237 | +22.9 |
| HIS SHOTS BY HIS RUN | 240 | 231 | 54 | 18.00 | +477 | +8.8 |
| HOLDER ASSIGNMENT | 49 | 49 | 42 | 14.00 | +2875 | +68.5 |
| FIVE ACTION | 508 | 489 | 32 | 10.67 | +1715 | +53.6 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -1004 | -32.4 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| LEGAL CHARGES ONLY | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 42 | 37 | 24 | 8.00 | +970 | +40.4 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| SHOT RISK POINTS | 140 | 136 | 21 | 7.00 | +258 | +12.3 |
| QUARTER ODDS | 136 | 132 | 20 | 6.67 | +1432 | +71.6 |
| NEXT CHARGE BY LIST | 29 | 28 | 18 | 6.00 | +775 | +43.0 |
| PROMISE BY ITS OWN SUM | 49 | 49 | 13 | 4.33 | -1190 | -91.5 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 13 | 4.33 | +25 | +1.9 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 135 | 113 | 11 | 3.67 | +46 | +4.2 |
| WHOLE FIGHT DANGER | 24 | 24 | 10 | 3.33 | +539 | +53.9 |
| FOUR ROUNDS | 17 | 16 | 9 | 3.00 | +264 | +29.3 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 20 | 20 | 8 | 2.67 | -21 | -2.6 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +158 | +19.7 |
| STAY WORTH | 128 | 112 | 8 | 2.67 | +106 | +13.2 |
| EVASIVE BY THE ODDS | 12 | 12 | 7 | 2.33 | +94 | +13.4 |
| SUPPORT ADDS | 33 | 30 | 7 | 2.33 | +409 | +58.5 |
| SUPPORT WORKED OUT | 33 | 30 | 7 | 2.33 | +409 | +58.5 |
| CHARGE NOW FIRST | 15 | 15 | 6 | 2.00 | -220 | -36.6 |
| CAST JOB | 5 | 5 | 5 | 1.67 | +41 | +8.1 |
| GOAL WALK | 40 | 40 | 5 | 1.67 | +292 | +58.4 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +142 | +28.5 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| MAX FOR POSITIONING | 12 | 11 | 5 | 1.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +267 | +53.3 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +408 | +102.0 |
| CHARGE LOSSES | 110 | 106 | 4 | 1.33 | +562 | +140.4 |
| COVER ONCE | 38 | 22 | 4 | 1.33 | +30 | +7.4 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 9 | 8 | 4 | 1.33 | +187 | +46.8 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.33 | +82 | +20.5 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 1.00 | +332 | +110.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +157 | +52.3 |
| MISSILES IN THE MOVE | 31 | 20 | 3 | 1.00 | +30 | +10.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +32 | +10.6 |
| SHOTS AFTER THE MOVES | 19 | 19 | 3 | 1.00 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 3 | 3 | 3 | 1.00 | +28 | +9.3 |
| THE ROW IN ITS ORDER | 17 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +661 | +330.4 |
| IDLE COST | 34 | 23 | 2 | 0.67 | +0 | +0.2 |
| LOST AFTER ESCAPE | 6 | 6 | 2 | 0.67 | +15 | +7.4 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +33 | +16.7 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -233 | -116.7 |
| ONE JOINT FIGURE | 2 | 2 | 2 | 0.67 | +43 | +21.4 |
| ONE OBJECTIVE FORMULA | 20 | 10 | 2 | 0.67 | +123 | +61.6 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 2 | 0.67 | -8 | -3.9 |
| REDIRECT COUNTER | 4 | 4 | 2 | 0.67 | +104 | +52.1 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +19 | +9.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +181 | +90.3 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +194 | +97.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +43 | +21.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +63 | +63.4 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -2 | -2.2 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -3 | -2.6 |
| FALLS SHORT | 61 | 55 | 1 | 0.33 | +37 | +36.8 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +37 | +37.3 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +23 | +23.4 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +3 | +3.4 |
| HONEST WORTH | 13 | 12 | 1 | 0.33 | +9 | +9.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 31 | 29 | 1 | 0.33 | +8 | +7.8 |
| NO DOUBLE ROUNDS | 14 | 13 | 1 | 0.33 | +52 | +51.7 |
| ONE FIGHT FORMULA | 38 | 21 | 1 | 0.33 | +29 | +28.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +29 | +29.2 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +28 | +28.0 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -3 | -3.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +22 | +22.4 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -3 | -3.4 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -0 | -0.4 |
| ROUNDS AFTER TERROR | 5 | 4 | 1 | 0.33 | +9 | +9.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +12 | +11.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS IN THE MOVE | 86 | 59 | 1 | 0.33 | +24 | +24.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -326 | -325.7 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +56 | +56.0 |
| WOUNDS ON THE RANKS | 17 | 17 | 1 | 0.33 | +10 | +10.3 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTING BLOCK | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 45 | 40 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 8 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 13 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 10 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 60 | 58 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 34 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 20 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 41 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 39 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 79 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| MANOEUVRE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 39 | 28 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 238 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 16 | 16 | 0 | 0.00 | - | - |
| RISK BY ARC | 13 | 12 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 11 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 3 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 51 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 33 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 222 | 218 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 240 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 2.67 | 38.9 |
| ARMY TABLE | rule | 2.33 | 4.00 | 79.9 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 0.67 | 91.5 |
| CHARGE NOW FIRST | rule | 1.00 | 1.00 | 36.7 |
| RULE SWITCHED OFF | gate | 1.67 | - | 18.9 |
| CANNON PLANNED TARGET | rule | 1.33 | - | 5.2 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 9.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.33 | 3.9 |
| AFTERMATH BAND | gate | 0.33 | - | 3.6 |
| BEST PRIZE | rule | - | 0.33 | 2.2 |
| CHAFF PASSED | rule | 0.33 | - | 2.6 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| FALLBACK | gate | - | 0.33 | 33.2 |
| JOINT CHARGE NOW | rule | 0.33 | - | 97.3 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 4.5 |
| MARCH OF THE TABLE | rule | 0.33 | - | 233.3 |
| OWN CAST FIRST | rule | - | 0.33 | 3.1 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 3.4 |
| SET UP BY THE SET | rule | 0.33 | - | 11.6 |
| SUPPORT NARROWED | rule | - | 0.33 | 325.7 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 2.5 |
| TURN GATE | gate | - | 0.33 | 12.4 |
| WHO HITS BACK | rule | 0.33 | - | 3.6 |

### Plans: cora-bb45c30-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 88% | 444 | 387 | 87% |
| Mine | move | 30.7 | 92% | 1548 | 0 | 0% |
| Mine | shoot | 9.0 | 37% | 555 | 549 | 99% |
| Opponent | charge | 2.0 | 83% | 152 | 267 | 176% |
| Opponent | join | 2.0 | 100% | 82 | 0 | 0% |
| Opponent | move | 28.0 | 94% | 2365 | 0 | 0% |
| Opponent | shoot | 5.0 | 33% | 165 | 218 | 132% |

### Battle groups: cora-bb45c30-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 62 (8) | 62 | 0 | 13 | 0% | 2.8 | 78 (6) | 14 (2) | - | 73 (2) | 59 (6) |
| Mine | Clean-up | 3 | 85 (3) | 0 | 85 | 0 | 33% | 2.0 | 134 (2) | 0 (1) | - | 134 (2) | 0 (1) |
| Mine | Fast Hammer | 7 | 31 (7) | 0 | 31 | 71 | 43% | 4.8 | 20 (3) | 54 (3) | 0 (1) | 30 (2) | 32 (5) |
| Mine | Holder | 2 | 46 (2) | 0 | 46 | 122 | 50% | 5.0 | 46 (2) | - | - | 46 (2) | - |
| Mine | Shooter | 5 | 87 (5) | 87 | 0 | 0 | 0% | 1.4 | 49 (4) | 250 (1) | - | 49 (4) | 250 (1) |
| Mine | War machine | 4 | 75 (4) | 75 | 0 | 25 | 0% | 1.0 | 0 (2) | 151 (2) | - | 151 (2) | 0 (2) |
| Opponent | Chaff | 3 | 89 (3) | 89 | 0 | 32 | 67% | 4.0 | 89 (3) | - | - | 89 (3) | - |
| Opponent | Character | 9 | 30 (9) | 30 | 0 | 60 | 11% | 3.0 | 56 (3) | 0 (3) | - | 75 (2) | 28 (4) |
| Opponent | Clean-up | 3 | 46 (3) | 46 | 0 | 0 | 67% | 1.0 | - | 46 (3) | - | 148 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 38 (3) | 0 | 38 | 77 | 0% | 2.7 | 171 (1) | 0 (2) | - | 0 (1) | 75 (2) |
| Opponent | Hammer | 8 | 22 (8) | 22 | 0 | 19 | 62% | 2.0 | 0 (4) | 86 (2) | 0 (2) | 33 (5) | 0 (3) |
| Opponent | Holder | 3 | 44 (3) | 0 | 44 | 65 | 33% | 5.0 | 62 (2) | - | 0 (1) | - | 44 (3) |
| Opponent | Shooter | 3 | 41 (3) | 41 | 0 | 62 | 0% | 1.0 | - | 59 (2) | 0 (1) | - | 41 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 34 | 0% | 2.7 | 0 (1) | - | - | - | 0 (1) |

### Charged fights: cora-bb45c30-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 361 | 271 | 2.0 | 1.3 | 136 | 0 | +136 | 2 of 6 | 6 of 6 | +57 | +175 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 501 | 3.0 | 1.0 | 167 | 35 | +132 | 1 of 3 | 2 of 3 | - | +132 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 151 | 280 | 1.0 | 1.0 | 280 | 0 | +280 | 0 of 1 | 1 of 1 | - | +280 |
| **Opponent** | all armies | 3 | 50 | 260 | 1.7 | 1.0 | 156 | 21 | +135 | 1 of 5 | 3 of 5 | - | +135 |

### Effective charges: cora-bb45c30-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 6 | 0 | 0 | 0 | 0 | 3 (net +126) | 2 (net +118) | 1 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 3 | 1 (net -104) | 0 | 0 | 0 | 1 (net +350) | 0 | 1 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +280) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 418 | 226 | +118 | 118 | 0 | +118 | +28.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 526 | 126 | +126 | 126 | 0 | +126 | +24.0 |
| Mine | No odds | 1 | 489 | 201 | +201 | 201 | 0 | +201 | +41.1 |
| Mine | All fights | 6 | 484 | 172 | +136 | 136 | 0 | +136 | +28.0 |
| Opponent | Long shot (under 50%) | 1 | 55 | 342 | -104 | 22 | 396 | -373 | -679.0 |
| Opponent | 76-89% | 1 | 116 | 151 | +0 | 30 | 0 | +30 | +26.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 230 | +280 | 350 | 333 | +17 | +3.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 350 | 70 | +350 | 350 | 194 | +156 | +44.6 |
| Opponent | No odds | 1 | 55 | 151 | +151 | 151 | 0 | +151 | +274.5 |
| Opponent | All fights | 5 | 215 | 189 | +135 | 181 | 184 | -4 | -1.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p8 | move | 27 | 6 (22%) | 6 (22%) | 7 (26%) | 14 (52%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

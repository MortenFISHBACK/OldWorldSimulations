# Doctrine scorecard: t10-mine-ba3e30a-p2

### Scorecard: t10-mine-ba3e30a-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 615 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 6 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 675 |
| L0222 | 6 | 1 | Mine | no | 8 | 2 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | yes | 10 | 4 | 2 | 1 | 1 | 0 | 0 | 497 |
| L0323 | 5 | 1 | Mine | no | - | 3 | 2 | 3 | 0 | 0 | 0 | 310 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 13 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 537 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | - | 2 | 2 | 0 | 0 | 0 | 85 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 0 | 0 | 0 | 0 | 95 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0528 | 6 | 1 | Opponent | no | 7 | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 476 |
| L0616 | 4 | 1 | Opponent | no | 6 | 3 | 1 | 2 | 2 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 518 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 11 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Opponent | yes | 1 | - | 1 | 5 | 0 | 0 | 0 | 290 |
| L0810 | 6 | 1 | Mine | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 717 |
| L0810 | 6 | 1 | Opponent | no | 16 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 0 | 0 | 0 | 0 | 385 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 75 |
| L0918 | 6 | 1 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 250 |
| L0918 | 6 | 1 | Opponent | no | 0 | 6 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 346 |
| L0934 | 4 | 1 | Opponent | no | 4 | 2 | 5 | 4 | 0 | 0 | 0 | 107 |
| L1026 | 6 | 1 | Mine | no | 6 | 3 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1026 | 6 | 1 | Opponent | no | 2 | 6 | 2 | 2 | 0 | 0 | 0 | 60 |
| L1118 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 165 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 1 | 4 | 3 | 2 | 1 | 0 | 0 | 370 |
| L1228 | 4 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 6 | 3 | 1 | 1 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 2 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 1 | - | 2 | 0 | 0 | 0 | 0 | 114 |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 1 | 3 | 2 | 0 | 0 | 0 | 350 |
| L1727 | 5 | 1 | Opponent | yes | - | 3 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | yes | 15 | - | 3 | 2 | 1 | 0 | 0 | 262 |
| L1827 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 60 |
| L1927 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 0 | 5 | 1 | 2 | 1 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 0 | 0 | 0 | 0 | 0 | 210 |
| L2131 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 2 | 0 | 0 | 125 |
| L2429 | 5 | 1 | Mine | yes | - | - | 2 | 4 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 2 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 4 | 3 | 2 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 108 |
| **Average** | | | Mine | 33% | 4.0 | 2.5 | 1.8 | 1.4 | 0.2 | 0.0 | 0.0 | 183.4 |
| **Average** | | | Opponent | 27% | 2.7 | 2.6 | 2.9 | 1.6 | 0.2 | 0.0 | 0.0 | 143.6 |

### KPIs: t10-mine-ba3e30a-p2

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (57 of 176) | 11% (20 of 178) | 22% (77 of 354) |
| Winner chose to follow up after the loser gave ground |  | 85% (44 of 52); on the table 87% | 98% (46 of 47); on the table 98% | 91% (90 of 99); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 64% (7 of 11); on the table 82% | 88% (14 of 16); on the table 94% | 78% (21 of 27); on the table 89% |
| Winner chose to pursue after the loser fled |  | 58% (15 of 26); on the table 69% | 84% (32 of 38); on the table 89% | 73% (47 of 64); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 74% (66 of 89); on the table 81% | 91% (92 of 101); on the table 94% | 83% (158 of 190); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 39% (133 of 342) | 35% (54 of 156) | 38% (187 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (133 of 252) | 45% (54 of 121) | 50% (187 of 373) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 66% (19 of 29) | 51% (23 of 45) | 57% (42 of 74) |
| Points that never fought | lower | 46% (33180 of 71583) | 44% (31982 of 71989) | 45% (65162 of 143572) |
|   infantry points that never fought | lower | 57% (9245 of 16324) | 58% (8206 of 14029) | 57% (17451 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (175 of 284) | 63% (186 of 297) | 62% (361 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.6 uses a game | 72% (13 of 18); 1.1 uses a game | 84% (32 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.6 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 29% (2 of 7); 0.1 uses a game | 56% (15 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33778 of 60231) | 60% (37813 of 63281) | 58% (71591 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (19%) | 0.8 (29%) | 1.9 (22%) |
| MARCHED: its unit marched | 1.7 (29%) | 0.6 (23%) | 2.3 (27%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.0 (1%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 1.4 (24%) | 0.3 (12%) | 1.8 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (2%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.9 (16%) | 0.6 (20%) | 1.5 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (9%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.5 | 1.5 | 5.2 | 0.5 | 1.8 |
| not cast | 3.5 | 3.3 | 3.5 | 8.6 | 1.8 | 19.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (52%) | 0.3 (9%) | 1.9 (22%) | 0.3 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (27%) | 0.6 (32%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.3 (9%) | 0.5 (15%) | 1.8 (20%) | 0.2 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.3 (10%) | 0.3 (8%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.6 (16%) | 0.2 (8%) | 0.5 (15%) | 1.5 (17%) | 0.3 (18%) | 2.0 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.2 (8%) | 0.1 (4%) | 0.1 (1%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.2 (6%) | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.2 (6%) | 0.0 (1%) | 0.0 (0%) | 0.3 (18%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (59%) | 0.2 (7%) | 1.4 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.8 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.8 a game | 0.8 a game |
| stood (cast and not dispelled) | 68% (19 of 28) | 63% (17 of 27) | 65% (36 of 55) |
| the unit moved after it | 68% (13 of 19) | 65% (11 of 17) | 67% (24 of 36) |
| it charged on its next turn | 5% (1 of 19) | 6% (1 of 17) | 6% (2 of 36) |
| the enemy charged it first | 26% (5 of 19) | 0% (0 of 17) | 14% (5 of 36) |
| it fought by the end of its next turn | 11% (2 of 19) | 0% (0 of 17) | 6% (2 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 19) | 6% (1 of 17) | 3% (1 of 36) |
| none of these (no charge, no fight, no charge escaped) | 68% (13 of 19) | 88% (15 of 17) | 78% (28 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (604 of 882) | 57% (469 of 829) | 63% (1073 of 1711) |
|   cavalry | 70% (45 of 64) | 60% (100 of 167) | 63% (145 of 231) |
|   character | 66% (82 of 124) | 31% (36 of 116) | 49% (118 of 240) |
|   chariot | 65% (64 of 99) | 70% (39 of 56) | 66% (103 of 155) |
|   infantry | 62% (170 of 272) | 55% (175 of 319) | 58% (345 of 591) |
|   monster | 49% (19 of 39) | 70% (30 of 43) | 60% (49 of 82) |
|   war machine | 79% (224 of 284) | 70% (89 of 128) | 76% (313 of 412) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (26%) | 1.9 (19%) | 3.9 (22%) |
| CHARGED: it charged | 0.8 (10%) | 1.9 (19%) | 2.7 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.3 (3%) | 0.4 (3%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.4 (4%) | 0.9 (5%) |
| MOVED: a war machine that moved | 0.8 (11%) | 0.0 (0%) | 0.8 (5%) |
| NO TARGET IN RANGE | 1.4 (18%) | 2.2 (22%) | 3.5 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (8%) | 0.8 (8%) | 1.4 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (17%) | 1.8 (18%) | 3.2 (18%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.1 (1%) | 0.5 (5%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.4 | 1.5 | 81% | 4.0 pts | 26 pts |
| character | 3.5 | 1.6 | 66% | 11.9 pts | 41 pts |
| chariot | 2.9 | 2.5 | 65% | 18.5 pts | 54 pts |
| infantry | 12.9 | 5.2 | 70% | 10.3 pts | 133 pts |
| monster | 1.6 | 0.6 | 74% | 9.7 pts | 16 pts |
| war machine | 8.7 | 6.7 | 66% | 22.6 pts | 197 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.2 | 6.0 | 4.6 |
| Charges that made contact a game | 2.6 | 4.1 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.73 declared, 0.58 contact (26 units) | 0.36 declared, 0.27 contact (11 units) | 0.62 declared, 0.49 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.60 declared, 0.40 contact (5 units) | 1.00 declared, 0.82 contact (11 units) | 0.88 declared, 0.69 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.29 contact (255 units) | 0.72 declared, 0.48 contact (279 units) | 0.55 declared, 0.39 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (35 of 73) | 61% (11 of 18) | 67% (8 of 12) | 52% (54 of 103) |
| Character in a unit | 80% (35 of 44) | 62% (10 of 16) | 100% (3 of 3) | 76% (48 of 63) |
| Character on its own | 86% (24 of 28) | 66% (25 of 38) | 37% (23 of 63) | 56% (72 of 129) |
| Chariot | 71% (12 of 17) | 69% (9 of 13) | - | 70% (21 of 30) |
| Infantry | 59% (55 of 94) | 44% (15 of 34) | 67% (2 of 3) | 55% (72 of 131) |
| Monster | 66% (19 of 29) | 89% (8 of 9) | - | 71% (27 of 38) |
| Monstrous | 50% (7 of 14) | 64% (9 of 14) | - | 57% (16 of 28) |
| War Machines | 86% (49 of 57) | 100% (2 of 2) | - | 86% (51 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 82% (9 of 11); on the table 82% | 44% (45 of 102) | 47% | 59% (13 of 22) | 100% (6 of 6); 4.2 uses a game | 100% (2 of 2); 1.2 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 100% (6 of 6); on the table 100% | 50% (18 of 36) | 71% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 6 | 61% (11 of 18); on the table 61% | - | 65% | 72% (39 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 90% (9 of 10); on the table 100% | 48% (23 of 48) | 49% | 75% (57 of 76) | 0.0 uses a game | 50% (1 of 2); 0.6 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 100% (4 of 4); on the table 100% | 28% (39 of 138) | 54% | 54% (29 of 54) | 86% (12 of 14); 6.5 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 71% (10 of 14); on the table 86% | 28% (5 of 18) | 36% | 55% (18 of 33) | 100% (3 of 3); 2.5 uses a game | 50% (7 of 14); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (7 of 7); on the table 100% | - | 56% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 67% (4 of 6); on the table 67% | - | 25% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (6 of 6); on the table 100% | 0% (0 of 18) | 55% | 71% (20 of 28) | 100% (4 of 4); 3.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (5 of 5); on the table 100% | 42% (5 of 12) | 16% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 75% (9 of 12); on the table 83% | 33% (6 of 18) | 31% | 56% (14 of 25) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 88% (22 of 25); on the table 88% | - | 31% | 32% (8 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 81% (26 of 32); on the table 88% | 41% (27 of 66) | 43% | 63% (34 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 82% (18 of 22); on the table 95% | 56% (10 of 18) | 40% | 68% (50 of 73) | 100% (2 of 2); 0.9 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 100% (12 of 12); on the table 100% | 38% (9 of 24) | 32% | 60% (47 of 78) | 57% (4 of 7); 1.1 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t10-mine-ba3e30a-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (47) | 64% (30) | 62% (77) |
| ...free all their last turn and able to turn (per game) | 0.97 | 0.58 | 1.56 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.14 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.50 | 1.14 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.03 | 1.03 | 1.06 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.72 | 0.72 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.17 | 6.39 | 6.56 |

### Quality by phase: t10-mine-ba3e30a-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 64% (72 of 113) | 45% (91 of 202) |
| Strategy | Shoot objectives carried out (shot that target) | 37% (146 of 391) | 48% (139 of 289) |
| Strategy | Close-in objectives charged next turn | - | 16% (45 of 282) |
| Strategy | Support requests answered (helper made contact too) | 73% (8 of 11) | 49% (18 of 37) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 47% (9 of 19) | 77% (10 of 13) |
| Strategy | Joined characters whose unit fought | 38% (22 of 58) | 42% (17 of 40) |
| Strategy | Lone characters that fought | 75% (65 of 87) | 67% (56 of 83) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.4 | 1.6 |
| Movement | Points that never moved of their own | 183.4 | 143.6 |
| Movement | Fights charged into per game | 2.3 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 78, net +127 | 23 of 101, net +61 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 78, net -7 | 14 of 101, net +54 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 78, net +109 | 4 of 101, net +146 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 78, net +114 | 30 of 101, net +119 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (169 of 422) | 50% (201 of 406) |
| Shooting | Points destroyed by shooting units | 117.6 | 35.7 |
| Shooting | War machine shots | 6.2 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (146 of 224) | 63% (56 of 89) |
| Shooting | Points destroyed by war machines | 48.8 | 51.1 |
| Magic | Magic missiles cast | 2.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (19 of 72) | 37% (13 of 35) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.8 |
| Magic | Wounds caused by other spells | 1.8 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 45.9 | 20.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.6 / 0.8 / 0.1 | 2.1 / 0.4 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 283.9 | 272.6 |
| Combat | Points run down | 47.2 | 176.2 |
| Combat | Net points per charged fight, damage counted | +97 | +86 |
| Combat | Net per 100 charger points, damage counted | +34.9 | +31.0 |
| Combat | First round won (charged fights) | 79% | 71% |
| Combat | Net points per charged fight | +86 | +87 |
| Combat | Net points per supported fight / lone fight | -81 / +107 | +193 / +64 |
| Combat | Charged fights on a top-3 enemy unit | 22 of 82 | 52 of 117 |
| Game | Points lost | 632.8 | 619.1 |
| Game | VP from objectives | 632.5 | 617.5 |
| Game | Lone holders (player turns) | 4.0 | 2.7 |

- Mine won / drew / lost: 16 / 6 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) +3 VP
- The side that went first won 16 of 30 games with a winner
- Points traded per game (both sides' losses): 1252
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t10-mine-ba3e30a-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 5.9 | -152.7 | 143.2 | 60.7 |
| AFTERMATH IN POINTS | 0.2 | +32.8 | 0.0 | 29.2 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.1 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 11.6 | +146.0 | 0.0 | 183.1 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +3.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 23.5 | 0.4 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.3 | +1.6 | 0.0 | 12.6 | 0.3 | +1.8 | 0.0 | 19.6 |
| BEST FACING | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +4.7 | 0.0 | 3.1 |
| BEST FIRST | - | - | - | - | 1.5 | +66.1 | 19.4 | 14.8 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.7 | +38.6 | 0.0 | 11.5 |
| BEST OVERALL | - | - | - | - | 0.2 | +4.8 | 0.0 | 0.0 |
| BEST PREY | - | - | - | - | 0.9 | +34.3 | 31.8 | 3.2 |
| BEST PRIZE | - | - | - | - | 0.1 | -5.6 | 3.8 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.1 | -0.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 9.6 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.5 | +7.5 | 0.0 | 1.2 |
| BLOWS WHERE AIMED | 0.2 | -29.0 | 14.4 | 25.8 | 0.5 | -89.7 | 54.6 | 6.0 |
| BOMBING RUN | 0.1 | +2.3 | 10.5 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.4 | - | - | - | - |
| CANNON PLAN MISSED | 1.2 | +0.0 | 278.9 | 23.8 | 0.4 | +0.0 | 26.6 | 3.5 |
| CANNON PLANNED TARGET | 5.6 | +249.1 | 519.5 | 73.1 | 2.3 | +85.3 | 92.0 | 17.4 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 1.2 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.8 | 3.5 | 0.0 | 0.4 | -7.0 | 24.3 | 2.2 |
| CAST JOB | 0.6 | +10.5 | 20.3 | 4.7 | 0.6 | +12.7 | 21.1 | 24.5 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +12.4 | 0.0 | 0.0 | 0.3 | +9.1 | 14.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 11.1 | 0.4 | +0.0 | 0.0 | 32.3 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +5.9 | 0.0 | 2.8 | 1.5 | +78.3 | 0.0 | 31.4 |
| CHAFF PASSED | 0.4 | -0.3 | 0.0 | 12.3 | 0.4 | -0.4 | 0.0 | 11.7 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.1 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 5.8 | -224.1 | 0.0 | 183.6 | - | - | - | - |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 1.7 | 0.0 | 0.9 | +0.0 | 86.7 | 4.2 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 237.5 | 23.8 | 2.4 | +0.0 | 231.2 | 39.9 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.6 | -54.7 | 43.6 | 4.9 |
| CHARGER SLAIN LOST | 0.3 | -13.3 | 21.9 | 20.2 | 0.6 | -11.1 | 53.4 | 15.7 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 15.5 | 1.4 |
| COMBAT PIVOT | 0.4 | +0.0 | 28.6 | 12.3 | 0.4 | +0.0 | 5.2 | 35.6 |
| CONVEYANCE SEARCH | 0.5 | +51.6 | 15.6 | 11.1 | 0.6 | +53.9 | 21.1 | 34.1 |
| COVER ONCE | 7.0 | -549.3 | 0.0 | 150.2 | 6.5 | -493.3 | 0.0 | 129.5 |
| DEFENSIVE ARMY | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.1 | +16.0 | 0.0 | 16.9 | 8.0 | +56.8 | 0.0 | 19.8 |
| EDGE GIVE GROUND | 0.2 | +5.3 | 18.7 | 1.2 | 0.3 | +17.1 | 30.4 | 14.2 |
| ELIXIR WORTH | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.0 | +0.4 | 0.0 | 0.0 | 1.0 | +73.2 | 0.0 | 34.9 |
| FALL BACK GOOD ORDER | 2.3 | +4.5 | 256.6 | 28.8 | - | - | - | - |
| FALLBACK BY WORTH | 0.1 | +1.1 | 0.0 | 0.0 | 5.3 | +46.3 | 0.0 | 34.6 |
| FALLS SHORT | 7.7 | +138.1 | 0.0 | 172.8 | - | - | - | - |
| FEATURE BUFFS | 1.1 | +24.6 | 0.0 | 19.3 | - | - | - | - |
| FIGHT TO THE END | 1.2 | +30.5 | 161.8 | 37.4 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +1.2 | 0.8 | 6.8 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 23.3 | 3.5 | 0.1 | +0.0 | 2.7 | 0.0 |
| FIVE ACTION | 45.1 | +2828.8 | 1222.2 | 668.6 | - | - | - | - |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 172.6 | 5.6 | +0.0 | 0.0 | 136.7 |
| FOCUS FIRE | 0.1 | +2.2 | 21.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +140.6 | 0.0 | 10.3 | 1.0 | +131.1 | 0.0 | 37.6 |
| FOUR ROUNDS | 3.1 | +272.3 | 318.7 | 62.5 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.1 | -7.5 | 0.0 | 3.1 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.4 | -7.6 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.2 | +4.2 | 0.0 | 1.7 | 0.2 | +12.1 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.8 | 5.4 | 0.0 | 0.2 | -2.5 | 0.0 | 2.6 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 0.0 | 1.2 | 0.0 | -0.1 | 0.0 | 0.0 |
| GUN FIGURES | 1.4 | +14.3 | 20.1 | 54.3 | 0.5 | +13.4 | 22.0 | 8.8 |
| GUN MASK | 0.5 | +15.2 | 0.0 | 5.6 | - | - | - | - |
| HARD STAY DROPPED | 1.5 | +0.0 | 0.0 | 24.3 | - | - | - | - |
| HE SHOOTS OR CHARGES | 1.8 | +0.0 | 0.0 | 64.4 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 30.3 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 10.3 | 0.0 | 0.1 | +0.0 | 10.8 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.6 | -61.9 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.7 | +32.4 | 48.5 | 11.1 | - | - | - | - |
| HIS CHARGE LIST | 3.6 | +0.0 | 0.0 | 75.8 | - | - | - | - |
| HIS FIGHT TOGETHER | 1.5 | -12.4 | 0.0 | 71.8 | - | - | - | - |
| HIS LEGAL MOVES | 3.1 | +0.0 | 0.0 | 63.0 | - | - | - | - |
| HIS MOVE AND SHOT | 1.9 | -25.4 | 0.0 | 80.2 | - | - | - | - |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 49.2 | - | - | - | - |
| HIS RANDOM MOVE | 3.6 | +0.0 | 0.0 | 19.4 | - | - | - | - |
| HIS SHOT LIST | 17.3 | +595.1 | 0.0 | 356.7 | - | - | - | - |
| HIS TURN DENIED | 1.2 | +38.8 | 140.4 | 46.4 | - | - | - | - |
| HOLDER ASSIGNMENT | 11.8 | +1144.4 | 0.0 | 132.6 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.0 | +157.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.5 | -90.6 | 238.9 | 32.1 | 10.9 | -219.8 | 491.4 | 189.8 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 14.0 |
| HUNT ADVANCE | - | - | - | - | 0.3 | +1.3 | 18.8 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 4.6 | 0.0 |
| HUNT IN PAIRS | 0.1 | +5.6 | 0.0 | 0.0 | 0.7 | +20.2 | 0.0 | 32.5 |
| HUNT KEPT | - | - | - | - | 0.1 | +1.7 | 12.4 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.2 | +39.1 | 4.6 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +70.5 | 23.6 | 0.0 |
| IDLE COST | 3.6 | -47.5 | 0.0 | 61.5 | 19.2 | -294.1 | 0.0 | 188.7 |
| INVITES THE FIGHT | - | - | - | - | 1.4 | +9.0 | 35.8 | 18.6 |
| JOINT CHARGE NOW | 0.7 | +63.9 | 72.6 | 34.1 | - | - | - | - |
| JOINT CHARGE PLAN | - | - | - | - | 0.6 | +41.4 | 10.4 | 22.9 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.9 | 0.0 | 0.0 | 0.1 | -2.0 | 14.9 | 0.0 |
| JOINT ON THE TABLE | 0.1 | +17.7 | 6.8 | 1.4 | - | - | - | - |
| KEEP FALLS | 0.2 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.0 | 2.1 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.6 | +78.3 | 145.6 | 49.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | - | - | - | - | 2.4 | +94.1 | 144.4 | 26.3 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.6 | +266.1 | 257.4 | 156.6 |
| LANE BY FIGURES | 0.7 | +29.8 | 0.0 | 0.0 | 0.9 | +43.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.0 | +0.0 | 252.0 | 263.2 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.5 | 0.0 | 1.2 | 0.2 | +7.7 | 16.2 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.3 | +0.0 | 0.0 | 23.2 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +24.1 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +1.0 | 12.9 | 0.0 | 0.5 | +2.8 | 36.0 | 5.4 |
| LOST CHARGE | - | - | - | - | 1.7 | -27.0 | 63.2 | 29.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -1.9 | 0.0 | 0.0 | 0.3 | -35.8 | 0.0 | 7.9 |
| MAKE SURE TOGETHER | 0.1 | +0.3 | 0.0 | 0.0 | 1.5 | +149.8 | 60.1 | 26.6 |
| MANOEUVRE | 1.6 | +20.0 | 0.0 | 21.5 | 0.2 | +5.7 | 0.0 | 2.4 |
| MARCH AT ESCAPER | 0.2 | +3.7 | 0.0 | 9.6 | 0.1 | +0.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +15.1 | 0.0 | 11.1 | - | - | - | - |
| MARCH CHECK | 1.0 | +45.1 | 0.0 | 27.4 | 0.4 | +3.6 | 0.0 | 16.9 |
| MARCH ODDS | - | - | - | - | 0.2 | +16.4 | 15.4 | 25.6 |
| MARCH OVER CASTS | 0.9 | +97.7 | 0.0 | 37.1 | 0.3 | +23.8 | 0.0 | 20.5 |
| MAX FOR POSITIONING | 5.6 | +66.7 | 0.0 | 123.1 | 7.2 | +109.7 | 0.0 | 125.5 |
| MISSILES IN THE MOVE | 4.2 | +88.3 | 0.0 | 85.9 | 3.3 | +65.5 | 0.0 | 92.3 |
| MISSILES NEXT TURN | 5.2 | +63.7 | 0.0 | 106.4 | 3.9 | +51.4 | 0.0 | 114.7 |
| MODEL FACING | 0.3 | +79.7 | 0.0 | 1.7 | 0.2 | +61.1 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 0.0 | 12.1 |
| MOVE AND CAST | - | - | - | - | 0.2 | +5.5 | 0.0 | 17.4 |
| MOVE ORDER | 1.7 | +0.0 | 35.6 | 13.5 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.2 | +6.2 | 0.0 | 0.0 | 0.1 | +3.3 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.5 | -25.4 | 0.0 | 25.0 | 0.2 | -7.1 | 0.0 | 28.2 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 13.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 5.9 | +456.9 | 166.8 | 146.1 |
| MOVE TO CHARGE COMPUTED | 4.1 | +452.0 | 0.0 | 64.9 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.1 | +173.0 | 0.0 | 50.0 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +15.3 | 1.9 | 0.0 |
| NEXT CHARGE BY LIST | 4.6 | -163.1 | 34.3 | 71.2 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 5.7 | -187.2 | 47.2 | 69.5 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.5 | -122.7 | 263.3 | 62.5 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +0.1 | 0.0 | 2.1 | 0.1 | +15.1 | 0.0 | 3.1 |
| NOT NEEDED | - | - | - | - | 0.5 | -30.2 | 79.3 | 0.8 |
| NOT TURNED | 0.2 | +0.2 | 0.0 | 0.0 | 6.4 | +74.3 | 0.0 | 125.8 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 2.4 | 0.6 | -0.7 | 0.0 | 15.0 |
| OFF BEST | 0.9 | -30.4 | 0.0 | 15.3 | 17.4 | -802.6 | 7.8 | 254.6 |
| ONE CHARGE A CHARGER | 3.0 | +0.0 | 0.0 | 75.1 | - | - | - | - |
| ONE FIGHT FORMULA | 6.2 | -115.8 | 0.0 | 151.2 | 9.8 | -189.7 | 30.1 | 205.9 |
| ONE OBJECTIVE FORMULA | 3.6 | +0.4 | 0.0 | 52.1 | 2.4 | -194.7 | 0.0 | 14.8 |
| ONE TARGET A SHOOTER | 14.6 | +345.4 | 0.0 | 237.2 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.3 | 3.8 | 0.0 | 0.1 | +0.2 | 6.7 | 7.6 |
| OPENS UP | 0.3 | +19.0 | 11.0 | 0.0 | 0.2 | +14.5 | 13.6 | 0.0 |
| OVERRUNS AWAY | 0.5 | +11.4 | 55.4 | 16.2 | 0.4 | +3.7 | 35.2 | 5.4 |
| PATHS CROSS | 2.2 | +88.9 | 0.0 | 16.2 | 3.0 | +179.4 | 0.0 | 39.4 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.5 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 5.8 |
| PLAN RESULT | 40.2 | +1226.8 | 638.0 | 895.0 | 42.9 | +1203.7 | 1269.6 | 825.4 |
| PURSUES BIG PREY | 0.0 | -0.3 | 0.0 | 0.0 | 0.2 | -18.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +8.5 | 0.0 | 5.8 | 1.2 | +16.8 | 0.0 | 49.9 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.3 | -16.8 | 12.9 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -0.8 | 0.0 | 1.5 | 1.0 | -24.1 | 0.0 | 20.1 |
| REDIRECT COUNTER | 2.0 | +138.2 | 0.0 | 51.4 | 4.0 | +282.1 | 0.0 | 49.4 |
| REDIRECT WEIGHED | 0.0 | +1.4 | 3.9 | 1.7 | 0.4 | +1.5 | 16.4 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -26.3 | 0.0 | 13.2 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 12.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +18.7 | 0.0 | 8.2 | 0.9 | +26.9 | 0.0 | 22.3 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +66.9 | 245.0 | 39.9 | 3.2 | +115.9 | 251.3 | 44.8 |
| RISK BY HIS FIGURE | 12.8 | -169.0 | 0.0 | 307.9 | - | - | - | - |
| RISK ONCE | - | - | - | - | 4.4 | +299.3 | 82.8 | 253.4 |
| RUN DOWN | 2.2 | -35.8 | 178.6 | 48.4 | - | - | - | - |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -2.1 | 2.4 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.7 | +37.2 | 0.0 | 7.1 |
| SAME CHARGE LATER | 0.1 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.3 | +1.1 | 0.0 | 2.0 | 0.5 | +1.6 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 2.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.3 | 0.0 | 0.0 | 0.4 | -32.0 | 0.0 | 3.4 |
| SEARCH SPOT | 7.5 | +373.1 | 0.0 | 112.1 | 3.4 | +117.6 | 0.0 | 29.2 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.2 | 13.2 | 0.0 |
| SELF MOVE SPELL | 0.3 | +12.9 | 0.0 | 18.1 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +29.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.2 | +1.9 | 0.0 | 0.0 | 2.4 | +259.0 | 75.7 | 72.8 |
| SET-UP ANY TARGET | - | - | - | - | 0.2 | +15.4 | 0.0 | 7.6 |
| SET-UP MISSED | 0.0 | +0.5 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 7.6 |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +34.1 | 37.3 | 2.4 | 1.2 | +29.8 | 34.1 | 7.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -10.3 | 89.5 | 3.1 | - | - | - | - |
| SHOT RISK POINTS | 7.9 | -10.5 | 0.0 | 206.2 | - | - | - | - |
| SHOTS IN THE MOVE | 16.2 | +960.3 | 0.0 | 280.0 | 13.2 | +363.0 | 0.0 | 130.4 |
| SPELL SETS UP CHARGE | 0.0 | +15.4 | 0.0 | 0.0 | 0.2 | +30.8 | 0.0 | 7.6 |
| SPELL WORTH | 1.0 | +16.1 | 48.7 | 48.7 | 1.6 | +22.1 | 102.6 | 104.6 |
| SPELLS IN THE FIGHT | 0.6 | +1.9 | 92.1 | 32.0 | 0.6 | -9.5 | 46.6 | 19.8 |
| STABLE ROLE | - | - | - | - | 11.5 | +0.0 | 364.2 | 159.8 |
| STAND AND SHOOT | 0.5 | -6.4 | 55.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 2.9 | - | - | - | - |
| STANDS STILL | 16.4 | +0.0 | 903.5 | 188.8 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.1 | +7.4 | 0.0 | 0.0 |
| STAY WORTH | 18.0 | +146.5 | 587.7 | 215.8 | 16.2 | +162.4 | 228.9 | 87.2 |
| STOPS | - | - | - | - | 0.1 | +9.5 | 17.2 | 0.0 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.3 | +5.3 | 0.0 | 6.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 1.4 | +0.0 | 166.1 | 25.3 | 8.1 | -64.4 | 360.5 | 101.5 |
| SUPPORTS | - | - | - | - | 5.3 | +66.2 | 164.9 | 55.4 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -5.4 | 0.0 | 5.4 |
| SURE REACH TOGETHER | 0.2 | +2.3 | 0.0 | 1.7 | 0.8 | -4.5 | 17.2 | 35.3 |
| THE DEARER SUM KEEPS ITS PLAN | 2.9 | +0.0 | 0.0 | 24.9 | - | - | - | - |
| THE PROMISE ADDS | 0.2 | -13.4 | 0.0 | 3.1 | - | - | - | - |
| THE PROMISED MOVE | 1.7 | +0.0 | 0.0 | 24.1 | - | - | - | - |
| THROUGH LINE OF FIRE | - | - | - | - | 0.4 | +26.6 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.9 | +78.8 | 79.0 | 9.9 | - | - | - | - |
| TIME ON OUR SIDE | 21.8 | +332.1 | 5.2 | 243.4 | - | - | - | - |
| TURN WORTH | - | - | - | - | 0.3 | -18.6 | 30.9 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.6 | +4.4 | 0.0 | 9.9 |
| WAIT AFTER COSTS | - | - | - | - | 9.5 | -476.2 | 274.9 | 210.7 |
| WAITS AGAIN | 1.9 | +0.0 | 0.0 | 25.2 | - | - | - | - |
| WALKS TO THE FIGHT | - | - | - | - | 1.3 | +7.9 | 17.5 | 6.9 |
| WAR ENGINE CHARGES | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.2 | +0.0 | 19.0 | 0.0 | 0.4 | +0.0 | 30.0 | 5.1 |
| WEARS DOWN | - | - | - | - | 1.8 | +48.7 | 195.7 | 47.3 |
| WHO HITS BACK | 0.4 | +39.0 | 0.0 | 11.6 | 0.1 | +6.8 | 0.0 | 4.6 |
| WHOLE FIGHT | 0.2 | +12.2 | 23.3 | 0.0 | 0.3 | +21.3 | 53.4 | 1.2 |
| WHOLE FIGHT GAIN | 0.1 | +5.5 | 14.6 | 1.7 | 0.7 | +67.9 | 67.9 | 8.1 |
| WIDER SPREAD | 2.0 | -3.4 | 204.1 | 54.8 | 3.9 | -7.0 | 305.0 | 54.8 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.4 | +62.8 | 0.0 | 27.4 | - | - | - | - |

### Rule changes: t10-mine-ba3e30a-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 658 | 658 | 658 | 18.28 | -29987 | -45.6 |
| HOLDER ASSIGNMENT | 425 | 425 | 400 | 11.11 | +25795 | +64.5 |
| SEARCH SPOT | 392 | 392 | 379 | 10.53 | +17666 | +46.6 |
| DEPLOY BY FIGURES | 578 | 578 | 357 | 9.92 | +4929 | +13.8 |
| ARMY TABLE | 419 | 419 | 292 | 8.11 | +4056 | +13.9 |
| LEGAL CHARGES ONLY | 215 | 215 | 215 | 5.97 | +0 | +0.0 |
| PATHS CROSS | 189 | 189 | 189 | 5.25 | +9658 | +51.1 |
| HIS SHOT LIST | 624 | 618 | 158 | 4.39 | +3888 | +24.6 |
| FIVE ACTION | 1624 | 1612 | 155 | 4.31 | +4751 | +30.7 |
| TIME ON OUR SIDE | 784 | 696 | 136 | 3.78 | +385 | +2.8 |
| SHOTS IN THE MOVE | 1059 | 882 | 121 | 3.36 | +5527 | +45.7 |
| ONE TARGET A SHOOTER | 527 | 523 | 114 | 3.17 | +1433 | +12.6 |
| MOVE TO CHARGE | 214 | 214 | 111 | 3.08 | +6601 | +59.5 |
| COVER ONCE | 486 | 341 | 86 | 2.39 | +1538 | +17.9 |
| MOVE TO CHARGE COMPUTED | 146 | 145 | 84 | 2.33 | +5480 | +65.2 |
| WAIT AFTER COSTS | 343 | 343 | 80 | 2.22 | +1425 | +17.8 |
| SUPPORTS | 190 | 190 | 77 | 2.14 | +786 | +10.2 |
| KILLS COUNT NEXT TURN | 272 | 272 | 75 | 2.08 | +2251 | +30.0 |
| ADVANCE LANE KEPT | 68 | 68 | 68 | 1.89 | +0 | +0.0 |
| MOVE ORDER | 61 | 61 | 61 | 1.69 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 60 | 60 | 60 | 1.67 | +9781 | +163.0 |
| LANE BY FIGURES | 57 | 57 | 57 | 1.58 | +2647 | +46.4 |
| MAX FOR POSITIONING | 462 | 343 | 56 | 1.56 | +217 | +3.9 |
| HARD STAY DROPPED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| FOUR ROUNDS | 113 | 112 | 54 | 1.50 | +2549 | +47.2 |
| RISK BY ARC | 195 | 189 | 54 | 1.50 | +1359 | +25.2 |
| BEST FIRST | 53 | 53 | 53 | 1.47 | +2381 | +44.9 |
| RESERVE FALL BACK | 49 | 49 | 49 | 1.36 | +1640 | +33.5 |
| CANNON PLANNED TARGET | 287 | 287 | 48 | 1.33 | -147 | -3.1 |
| REDIRECT COUNTER | 216 | 127 | 48 | 1.33 | +3683 | +76.7 |
| RISK ONCE | 160 | 127 | 48 | 1.33 | +3078 | +64.1 |
| CANNON SIGHT KEPT | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| IDLE COST | 820 | 505 | 45 | 1.25 | +605 | +13.4 |
| FALLBACK BY WORTH | 197 | 197 | 44 | 1.22 | +1705 | +38.7 |
| SET UP TOGETHER | 92 | 78 | 43 | 1.19 | +4275 | +99.4 |
| RANDOM MOVE BY FIGURES | 74 | 74 | 42 | 1.17 | +910 | +21.7 |
| SHOT RISK POINTS | 284 | 280 | 41 | 1.14 | +1705 | +41.6 |
| ADVANCE WORTH | 214 | 214 | 40 | 1.11 | +507 | +12.7 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| MANOEUVRE | 67 | 67 | 40 | 1.11 | +1049 | +26.2 |
| MISSILES IN THE MOVE | 269 | 204 | 40 | 1.11 | +546 | +13.7 |
| CHAFF IN THE MOVE | 65 | 62 | 39 | 1.08 | +1023 | +26.2 |
| FACES THE THREAT | 38 | 38 | 38 | 1.06 | +2647 | +69.7 |
| SHOOTS FROM THE BEST SPOT | 76 | 76 | 37 | 1.03 | +417 | +11.3 |
| MARCH CHECK | 49 | 48 | 36 | 1.00 | +759 | +21.1 |
| STAY WORTH | 1233 | 1082 | 34 | 0.94 | +433 | +12.7 |
| CHARGE NOT DECLARED | 33 | 33 | 33 | 0.92 | -3308 | -100.2 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2288 | +69.3 |
| ONE FIGHT FORMULA | 578 | 349 | 33 | 0.92 | +118 | +3.6 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CHAFF PASSED | 27 | 27 | 27 | 0.75 | -28 | -1.0 |
| CHARGE NOW FIRST | 153 | 153 | 27 | 0.75 | -1211 | -44.9 |
| COMBAT PIVOT | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| HONEST WORTH | 482 | 476 | 27 | 0.75 | +221 | +8.2 |
| BEST MOVE FOR SHOOTERS | 26 | 26 | 26 | 0.72 | +1388 | +53.4 |
| MAKE SURE TOGETHER | 57 | 42 | 26 | 0.72 | +2623 | +100.9 |
| NEXT OBJECTIVE NEARER | 206 | 204 | 26 | 0.72 | +510 | +19.6 |
| SAFER THAN THE JOB | 26 | 26 | 26 | 0.72 | +1340 | +51.5 |
| SHOOTERS IN TWO RANKS | 26 | 26 | 26 | 0.72 | +53 | +2.0 |
| JOINT CHARGE NOW | 24 | 24 | 24 | 0.67 | +2301 | +95.9 |
| RISK BY HIS FIGURE | 459 | 456 | 24 | 0.67 | +2308 | +96.1 |
| CHARGE LOSSES | 209 | 207 | 23 | 0.64 | +2110 | +91.7 |
| KILLS COUNT | 86 | 82 | 22 | 0.61 | +841 | +38.2 |
| TIED UP BY THE SUM | 32 | 32 | 21 | 0.58 | +521 | +24.8 |
| CHARGE NOW WEIGHED | 20 | 20 | 20 | 0.56 | +2247 | +112.4 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +945 | +47.2 |
| INVITES THE FIGHT | 49 | 49 | 19 | 0.53 | +108 | +5.7 |
| NEARER NOT NEEDED | 146 | 140 | 19 | 0.53 | +495 | +26.0 |
| WALKS TO THE FIGHT | 46 | 46 | 19 | 0.53 | +79 | +4.1 |
| HOLDER AT DEPLOYMENT | 35 | 35 | 18 | 0.50 | +958 | +53.2 |
| KEEPS ITS TARGET | 94 | 91 | 18 | 0.50 | +312 | +17.3 |
| WHOLE FIGHT GAIN | 31 | 29 | 18 | 0.50 | +795 | +44.2 |
| BLOCKED WHEEL | 17 | 17 | 17 | 0.47 | +271 | +16.0 |
| FALLS SHORT | 277 | 239 | 17 | 0.47 | +120 | +7.1 |
| MODEL FACING | 17 | 17 | 17 | 0.47 | +5068 | +298.1 |
| NEXT CHARGE BY LIST | 164 | 162 | 17 | 0.47 | +261 | +15.3 |
| FIRE IN ORDER | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| STUCK PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +958 | +59.9 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CAST JOB | 43 | 43 | 14 | 0.39 | +127 | +9.1 |
| FRIENDS SHOTS CHECKED | 14 | 14 | 14 | 0.39 | +588 | +42.0 |
| MARCH BY THE SUM | 14 | 14 | 14 | 0.39 | +545 | +38.9 |
| REDIRECT WEIGHED | 14 | 14 | 14 | 0.39 | +216 | +15.4 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CASTING BLOCK | 19 | 19 | 13 | 0.36 | +262 | +20.2 |
| HUNT IN PAIRS | 28 | 17 | 13 | 0.36 | +403 | +31.0 |
| ONE OBJECTIVE FORMULA | 216 | 146 | 12 | 0.33 | +414 | +34.5 |
| MISSILES NEXT TURN | 327 | 226 | 10 | 0.28 | +31 | +3.1 |
| STOPS SHORT OF THE FLANK | 10 | 10 | 10 | 0.28 | +190 | +19.0 |
| BEST FACING | 9 | 9 | 9 | 0.25 | +168 | +18.6 |
| HIS CHARGE DENIED | 26 | 26 | 9 | 0.25 | +291 | +32.4 |
| MARCH ODDS | 9 | 9 | 9 | 0.25 | +82 | +9.1 |
| MOVE AND CAST | 9 | 9 | 9 | 0.25 | +198 | +22.0 |
| OPENS UP | 20 | 19 | 9 | 0.25 | +241 | +26.8 |
| AFTERMATH IN POINTS | 8 | 8 | 8 | 0.22 | +1180 | +147.5 |
| REFUSING RETIRES | 18 | 18 | 8 | 0.22 | -3 | -0.4 |
| SUPPORT NARROWED | 344 | 344 | 8 | 0.22 | -169 | -21.1 |
| BEST PREY | 32 | 32 | 7 | 0.19 | +283 | +40.4 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -659 | -94.1 |
| SET UP BY THE SET | 26 | 26 | 7 | 0.19 | +113 | +16.2 |
| SURE REACH TOGETHER | 37 | 30 | 7 | 0.19 | +3 | +0.4 |
| WEARS DOWN | 66 | 64 | 7 | 0.19 | +431 | +61.6 |
| WOUNDS ON THE RANKS | 50 | 50 | 7 | 0.19 | +256 | +36.5 |
| BEST OVERALL | 6 | 6 | 6 | 0.17 | +172 | +28.7 |
| HIS TURN DENIED | 45 | 44 | 6 | 0.17 | +137 | +22.8 |
| JOINT CHARGE PLAN | 21 | 21 | 6 | 0.17 | +487 | +81.1 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +243 | +40.5 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -171 | -28.5 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -388 | -77.6 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.14 | -17 | -3.4 |
| HIS FIGHT TOGETHER | 54 | 54 | 5 | 0.14 | +60 | +12.1 |
| AFTERMATH WITH FRIENDS | 4 | 4 | 4 | 0.11 | +138 | +34.6 |
| CARRIES OUT SET-UP | 17 | 17 | 4 | 0.11 | -320 | -80.0 |
| FIGHT TO THE END | 44 | 44 | 4 | 0.11 | +208 | +52.0 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +80 | +19.9 |
| GUN MASK | 19 | 19 | 4 | 0.11 | +83 | +20.7 |
| HIS MOVE AND SHOT | 70 | 69 | 4 | 0.11 | +199 | +49.7 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 4 | 0.11 | -231 | -57.8 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| OVERRUNS AWAY | 32 | 29 | 4 | 0.11 | +92 | +23.0 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +83 | +27.7 |
| CHARGE LIST READ AGAIN | 3 | 3 | 3 | 0.08 | +53 | +17.7 |
| EDGE GIVE GROUND | 17 | 16 | 3 | 0.08 | +54 | +18.1 |
| FEATURE BUFFS | 41 | 41 | 3 | 0.08 | +36 | +12.0 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +45 | +15.0 |
| JOINT ON THE TABLE | 3 | 3 | 3 | 0.08 | +638 | +212.6 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +291 | +97.1 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +100 | +33.3 |
| SPELLS IN THE FIGHT | 45 | 44 | 3 | 0.08 | +59 | +19.7 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -194 | -64.6 |
| WHOLE FIGHT | 20 | 20 | 3 | 0.08 | +260 | +86.8 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -39 | -19.6 |
| DEFENSIVE ARMY | 4 | 4 | 2 | 0.06 | -50 | -25.2 |
| LONG SHOT | 25 | 24 | 2 | 0.06 | +9 | +4.3 |
| LOST CHARGE | 62 | 62 | 2 | 0.06 | +19 | +9.7 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 89 | 88 | 2 | 0.06 | +35 | +17.3 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +110 | +55.1 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -93 | -46.5 |
| WIDER SPREAD | 213 | 210 | 2 | 0.06 | +16 | +7.9 |
| BACKUP TARGETS | 24 | 12 | 1 | 0.03 | +0 | +0.0 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +17 | +16.8 |
| FALL BACK GOOD ORDER | 84 | 84 | 1 | 0.03 | +5 | +5.2 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +15 | +14.8 |
| MOVE SPELL IN RANGE | 9 | 7 | 1 | 0.03 | +22 | +22.2 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -76 | -76.5 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +36 | +36.2 |
| WAR ENGINE JOBS | 20 | 20 | 1 | 0.03 | -10 | -10.2 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -7 | -6.9 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 26 | 24 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 56 | 56 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CHARACTER GUNS | 22 | 22 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 32 | 31 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 389 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 13 | 13 | 0 | 0.00 | - | - |
| GIVES UP | 11 | 10 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 69 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 64 | 64 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 6 | 6 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 20 | 20 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 129 | 128 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 111 | 109 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 83 | 81 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 129 | 128 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 10 | 10 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 9 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 12 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 14 | 14 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 43 | 43 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NOT NEEDED | 19 | 19 | 0 | 0.00 | - | - |
| NOT TURNED | 236 | 236 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 109 | 107 | 0 | 0.00 | - | - |
| OPENS A LANE | 5 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 2995 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 11 | 11 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 37 | 37 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 33 | 33 | 0 | 0.00 | - | - |
| RUN DOWN | 78 | 77 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 13 | 13 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 93 | not checked | - | - | - | - |
| STABLE ROLE | 415 | 412 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 19 | 19 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 591 | 587 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 103 | not checked | - | - | - | - |
| THE PROMISE ADDS | 7 | 7 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 62 | not checked | - | - | - | - |
| TURN WORTH | 11 | 11 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 20 | 17 | 0 | 0.00 | - | - |
| WAITS AGAIN | 69 | 69 | 0 | 0.00 | - | - |

### Off best figure: t10-mine-ba3e30a-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.31 | 15.81 | 47.0 |
| ARMY TABLE | rule | 1.39 | - | 38.3 |
| HOLDER ASSIGNMENT | rule | 1.28 | - | 21.7 |
| CHARGE NOT DECLARED | rule | 0.06 | 0.83 | 106.7 |
| CHARGE NOW FIRST | rule | 0.28 | 0.44 | 46.6 |
| FALLBACK | gate | 0.03 | 0.67 | 19.1 |
| TURN GATE | gate | - | 0.56 | 46.5 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.14 | 59.2 |
| NO REASON | gate | 0.28 | - | 54.7 |
| PATHS CROSS | rule | 0.14 | 0.14 | 14.4 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 2.3 |
| JOINT CHARGE NOW | rule | 0.22 | - | 47.4 |
| SUPPORT NARROWED | rule | 0.06 | 0.17 | 21.1 |
| PURSUES BIG PREY | rule | 0.03 | 0.17 | 94.1 |
| CHAFF PASSED | rule | 0.08 | 0.08 | 4.6 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.08 | 28.5 |
| BEST PRIZE | rule | - | 0.14 | 77.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.06 | 21.6 |
| SUPPORT REQUEST | gate | - | 0.14 | 47.2 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.08 | 80.0 |
| BIG CHARACTER SAFETY | rule | - | 0.08 | 6.3 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 1.4 |
| LONE WIZARD HOLDS BACK | rule | - | 0.08 | 77.0 |
| REDIRECT WEIGHED | rule | - | 0.08 | 85.7 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.08 | 64.6 |
| CATCH ODDS | rule | - | 0.06 | 19.6 |
| DEFENSIVE ARMY | rule | - | 0.06 | 25.2 |
| REFUSING RETIRES | rule | 0.06 | - | 0.6 |
| STANDS TO CAST | rule | - | 0.06 | 46.5 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 7.8 |
| THROUGH LINE OF FIRE | rule | - | 0.06 | 30.2 |
| WHO HITS BACK | rule | 0.06 | - | 2.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 389.3 |
| BLOCKED WHEEL | rule | - | 0.03 | 0.7 |
| CHARGE LIST READ AGAIN | rule | 0.03 | - | 53.8 |
| DEPLOY BY FIGURES | rule | 0.03 | - | 9.9 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 4.5 |
| MARCH ODDS | rule | - | 0.03 | 6.9 |
| RULE SWITCHED OFF | gate | - | 0.03 | 9.3 |
| SAFE SURE CHARGE | rule | - | 0.03 | 76.5 |
| SAFER THAN THE JOB | rule | - | 0.03 | 3.4 |
| SET UP BY THE SET | rule | 0.03 | - | 331.0 |
| WAR ENGINE JOBS | rule | 0.03 | - | 10.2 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 6.9 |

### Plans: t10-mine-ba3e30a-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.6 | 71% | 427 | 257 | 60% |
| Mine | join | 0.7 | 88% | 27 | 0 | 0% |
| Mine | move | 27.8 | 93% | 1704 | 0 | 0% |
| Mine | shoot | 9.0 | 61% | 530 | 970 | 183% |
| Mine | support | 0.2 | 83% | 1 | 0 | 0% |
| Opponent | advance | 11.6 | 12% | 173 | 239 | 139% |
| Opponent | charge | 5.0 | 53% | 400 | 424 | 106% |
| Opponent | close in | 7.7 | 26% | 542 | 145 | 27% |
| Opponent | hold | 5.1 | 39% | 371 | 0 | 0% |
| Opponent | join | 0.8 | 100% | 32 | 0 | 0% |
| Opponent | shoot | 6.2 | 64% | 272 | 395 | 145% |
| Opponent | support | 6.6 | 90% | 50 | 0 | 0% |

### Packages: hunt the guns, t10-mine-ba3e30a-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 30 |
| Opponent | 0.2 | 9 | 0 | 22% | 78% | 0% | 2.4 | 282 | 156 | 78% | 71 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 114 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 136 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.5 | 2 | 0 | 50% | 50% | 0% | 3.0 | 633 | 238 | 50% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Tomb Kings of Khemri | 1.2 | 6 | 0 | 0% | 83% | 0% | 2.4 | 148 | 102 | 83% | 78 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 49 |
| Wood Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 382 | 318 | 100% | 0 |

### Battle groups: t10-mine-ba3e30a-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 43% | 55% | 6% | 0% | 21% | 7% | 10% | 62% | 0% |
| Opponent | REDIRECT COUNTER | 4.0 | 20% | 69% | 7% | 0% | 26% | 0% | 7% | 63% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t10-mine-ba3e30a-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 11 (5) | 11 | 0 | 48 | 20% | 2.8 | 0 (1) | 20 (3) | - | - | 13 (4) |
| Mine | Chaff | 35 | 59 (35) | 17 | 42 | 57 | 34% | 3.3 | 116 (14) | 23 (12) | 10 (9) | 77 (23) | 27 (12) |
| Mine | Character | 124 | 48 (124) | 48 | 0 | 26 | 17% | 2.5 | 64 (35) | 47 (49) | 25 (23) | 50 (52) | 49 (55) |
| Mine | Clean-up | 19 | 61 (19) | 22 | 40 | 21 | 42% | 2.0 | 39 (3) | 49 (12) | 110 (4) | 81 (14) | 18 (5) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 47 | 36 (47) | 17 | 19 | 40 | 30% | 2.5 | 34 (18) | 27 (22) | 71 (7) | 42 (29) | 26 (18) |
| Mine | Hammer | 59 | 36 (59) | 19 | 18 | 32 | 32% | 2.5 | 17 (17) | 41 (30) | 50 (12) | 42 (35) | 29 (24) |
| Mine | Holder | 29 | 64 (29) | 3 | 61 | 28 | 38% | 2.9 | 57 (14) | 62 (12) | 103 (3) | 73 (20) | 36 (9) |
| Mine | Shooter | 45 | 88 (45) | 28 | 60 | 50 | 0% | 1.8 | 97 (11) | 84 (23) | 85 (11) | 101 (33) | 57 (12) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 0% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 36 (59) | 36 | 0 | 43 | 3% | 1.3 | 35 (21) | 36 (20) | 37 (18) | 2 (11) | 44 (48) |
| Mine | Wizard | 21 | 6 (21) | 6 | 0 | 44 | 10% | 2.2 | 0 (8) | 0 (4) | 25 (5) | 7 (8) | 10 (9) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 89 (76) | 34 | 55 | 42 | 37% | 2.6 | 65 (29) | 112 (29) | 80 (18) | 101 (59) | 54 (17) |
| Opponent | Character | 96 | 40 (96) | 40 | 0 | 32 | 24% | 2.5 | 35 (35) | 52 (41) | 45 (10) | 38 (62) | 54 (24) |
| Opponent | Clean-up | 18 | 24 (18) | 9 | 15 | 45 | 33% | 2.8 | 15 (6) | 35 (10) | 0 (2) | 25 (14) | 18 (4) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 49 | 45 (49) | 40 | 6 | 42 | 20% | 2.7 | 34 (21) | 56 (20) | 43 (8) | 61 (29) | 24 (20) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 29 | 67% | 1.0 | - | 0 (1) | 0 (2) | 0 (1) | 0 (2) |
| Opponent | Hammer | 70 | 40 (70) | 30 | 10 | 26 | 30% | 3.0 | 63 (19) | 31 (42) | 39 (9) | 48 (41) | 30 (29) |
| Opponent | Holder | 34 | 75 (34) | 14 | 61 | 47 | 29% | 3.0 | 123 (10) | 69 (14) | 55 (9) | 83 (24) | 53 (9) |
| Opponent | Shooter | 36 | 59 (36) | 11 | 48 | 29 | 6% | 1.8 | 54 (11) | 75 (18) | 25 (7) | 89 (22) | 19 (14) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 67% | 5.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 39 (24) | 39 | 0 | 18 | 8% | 1.5 | 61 (11) | 0 (2) | 21 (11) | 0 (3) | 44 (21) |
| Opponent | Wizard | 27 | 7 (27) | 7 | 0 | 34 | 4% | 2.0 | 7 (13) | 2 (10) | - | 6 (11) | 2 (12) |

### Charged fights: t10-mine-ba3e30a-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 69 | 41 | 0.8 | 1.0 | 55 | 0 | +55 | 0 of 3 | 3 of 3 | - | +55 |
| Mine | Chaos Dwarfs | 4 | 184 | 501 | 2.5 | 1.0 | 200 | 0 | +200 | 4 of 10 | 8 of 10 | - | +200 |
| Mine | Dwarfen Mountain Holds | 4 | 854 | 55 | 1.0 | 1.2 | 55 | 30 | +25 | 0 of 4 | 4 of 4 | +19 | +27 |
| Mine | Empire of Man | 5 | 90 | 178 | 1.2 | 1.2 | 148 | 32 | +117 | 2 of 6 | 4 of 6 | -189 | +178 |
| Mine | Grand Cathay | 4 | 102 | 373 | 2.5 | 1.1 | 149 | 105 | +44 | 4 of 10 | 7 of 10 | -813 | +140 |
| Mine | High Elf Realms | 4 | 216 | 428 | 3.8 | 1.1 | 114 | 18 | +96 | 3 of 15 | 13 of 15 | -58 | +120 |
| Mine | Kingdom of Bretonnia | 1 | 30 | 377 | 5.0 | 1.0 | 75 | 0 | +75 | 1 of 5 | 3 of 5 | - | +75 |
| Mine | Lizardmen | 1 | 186 | 246 | 4.0 | 1.5 | 62 | 101 | -40 | 1 of 4 | 4 of 4 | +186 | -115 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 473 | 4.0 | 1.0 | 118 | 28 | +91 | 1 of 4 | 3 of 4 | - | +91 |
| Mine | Skaven | 2 | 102 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 797 | 841 | 5.0 | 1.2 | 168 | 0 | +168 | 2 of 5 | 4 of 5 | +102 | +185 |
| Mine | Vampire Counts | 3 | 91 | 285 | 3.7 | 1.2 | 78 | 5 | +72 | 2 of 11 | 8 of 11 | +40 | +79 |
| Mine | Warriors of Chaos | 1 | 0 | 19 | 2.0 | 1.0 | 10 | 0 | +10 | 1 of 2 | 2 of 2 | - | +10 |
| **Mine** | all armies | 36 | 212 | 258 | 2.3 | 1.1 | 113 | 27 | +86 | 22 of 82 | 65 of 82 | -81 | +107 |
| Opponent | Dwarfen Mountain Holds | 2 | 170 | 75 | 3.0 | 1.3 | 25 | 0 | +25 | 2 of 6 | 6 of 6 | +0 | +38 |
| Opponent | Empire of Man | 2 | 366 | 42 | 1.5 | 1.3 | 28 | 37 | -8 | 0 of 3 | 3 of 3 | -110 | +42 |
| Opponent | Grand Cathay | 2 | 384 | 588 | 3.0 | 1.3 | 196 | 0 | +196 | 4 of 6 | 4 of 6 | +0 | +235 |
| Opponent | Kingdom of Bretonnia | 1 | 220 | 246 | 2.0 | 1.0 | 123 | 0 | +123 | 1 of 2 | 2 of 2 | - | +123 |
| Opponent | Ogre Kingdoms | 3 | 289 | 246 | 3.0 | 1.3 | 82 | 46 | +36 | 4 of 9 | 6 of 9 | +85 | +12 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 140 | 622 | 4.8 | 1.5 | 131 | 40 | +91 | 9 of 19 | 15 of 19 | +272 | -14 |
| Opponent | Vampire Counts | 6 | 0 | 606 | 3.5 | 1.3 | 173 | 71 | +102 | 11 of 21 | 13 of 20 | +503 | +8 |
| Opponent | Warriors of Chaos | 8 | 24 | 140 | 2.0 | 1.0 | 70 | 7 | +63 | 7 of 16 | 9 of 16 | - | +63 |
| Opponent | Wood Elf Realms | 7 | 24 | 638 | 4.9 | 1.1 | 131 | 30 | +102 | 14 of 34 | 23 of 34 | +0 | +111 |
| **Opponent** | all armies | 36 | 107 | 392 | 3.2 | 1.2 | 121 | 33 | +87 | 52 of 117 | 82 of 116 | +193 | +64 |

### Effective charges: t10-mine-ba3e30a-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 1 (net +60) | 1 (net +105) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 10 | 1 (net +666) | 1 (net +217) | 0 | 1 (net +85) | 0 | 7 (net +148) | 0 | 0% (0 of 10) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +80) | 0 | 0 | 3 (net +6) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 6 | 0 | 0 | 0 | 0 | 1 (net +0) | 4 (net +147) | 1 | 0% (0 of 5) |
| Mine | Grand Cathay | 10 | 3 (net +82) | 0 | 0 | 2 (net -116) | 4 (net +40) | 1 (net +274) | 0 | 0% (0 of 10) |
| Mine | High Elf Realms | 15 | 0 | 1 (net -115) | 0 | 4 (net +34) | 3 (net +130) | 7 (net +147) | 0 | 0% (0 of 15) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +170) | 2 (net +61) | 1 (net +85) | 1 (net +0) | 0 | 20% (1 of 5) |
| Mine | Lizardmen | 4 | 1 (net +0) | 0 | 2 (net -172) | 0 | 1 (net +186) | 0 | 0 | 50% (2 of 4) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 1 (net +233) | 0 | 0 | 1 (net -55) | 1 (net +54) | 0 | 1 | 0% (0 of 3) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 5 | 1 (net +0) | 0 | 0 | 0 | 0 | 3 (net +246) | 1 | 0% (0 of 4) |
| Mine | Vampire Counts | 11 | 2 (net +0) | 0 | 0 | 4 (net +16) | 1 (net +432) | 4 (net +74) | 0 | 0% (0 of 11) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +10) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 6 | 2 (net +32) | 0 | 0 | 2 (net +0) | 0 | 2 (net +42) | 0 | 0% (0 of 6) |
| Opponent | Empire of Man | 3 | 0 | 0 | 0 | 2 (net -55) | 0 | 1 (net +85) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 6 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +498) | 0 | 0 | 2 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 0 | 1 (net +60) | 0 | 1 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 9 | 1 (net +165) | 0 | 1 (net +177) | 1 (net +0) | 0 | 2 (net +124) | 4 | 20% (1 of 5) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 19 | 3 (net -23) | 1 (net +0) | 3 (net +121) | 5 (net -3) | 1 (net +222) | 4 (net +308) | 2 | 18% (3 of 17) |
| Opponent | Vampire Counts | 21 | 6 (net +104) | 3 (net +66) | 1 (net +0) | 5 (net +225) | 0 | 3 (net -94) | 3 | 6% (1 of 18) |
| Opponent | Warriors of Chaos | 16 | 2 (net -58) | 1 (net +128) | 3 (net +32) | 2 (net +0) | 0 | 8 (net +112) | 0 | 19% (3 of 16) |
| Opponent | Wood Elf Realms | 34 | 7 (net +104) | 1 (net -102) | 5 (net +23) | 5 (net +115) | 2 (net +150) | 10 (net +132) | 4 | 17% (5 of 30) |

### Charged fights, damage counted: t10-mine-ba3e30a-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 315 | 316 | +127 | 286 | 104 | +181 | +57.5 |
| Mine | 50-54% | 2 | 476 | 195 | +51 | 108 | 182 | -73 | -15.4 |
| Mine | Effective (55-75%) | 5 | 257 | 207 | -7 | 155 | 86 | +69 | +26.9 |
| Mine | 76-89% | 15 | 238 | 122 | +15 | 60 | 42 | +18 | +7.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 235 | 177 | +114 | 146 | 26 | +119 | +50.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 407 | 99 | +109 | 119 | 2 | +118 | +28.9 |
| Mine | No odds | 4 | 278 | 112 | +86 | 114 | 41 | +73 | +26.3 |
| Mine | All fights | 82 | 279 | 170 | +86 | 140 | 42 | +97 | +34.9 |
| Opponent | Long shot (under 50%) | 23 | 178 | 237 | +61 | 131 | 81 | +50 | +28.0 |
| Opponent | 50-54% | 6 | 205 | 265 | +37 | 102 | 54 | +48 | +23.4 |
| Opponent | Effective (55-75%) | 14 | 397 | 210 | +54 | 113 | 88 | +25 | +6.3 |
| Opponent | 76-89% | 24 | 319 | 184 | +107 | 148 | 35 | +113 | +35.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 295 | 166 | +119 | 156 | 32 | +124 | +41.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 378 | 60 | +146 | 157 | 16 | +141 | +37.3 |
| Opponent | No odds | 16 | 217 | 246 | +69 | 105 | 27 | +78 | +36.0 |
| Opponent | All fights | 117 | 277 | 201 | +87 | 135 | 49 | +86 | +31.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t10-mine-ba3e30a-p2 | move | 382 | 82 (21%) | 63 (16%) | 57 (15%) | 243 (64%) |
| t10-mine-ba3e30a-p2 | objective | 282 | 45 (16%) | 31 (11%) | 32 (11%) | 205 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

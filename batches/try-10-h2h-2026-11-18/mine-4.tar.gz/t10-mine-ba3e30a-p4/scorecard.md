# Doctrine scorecard: t10-mine-ba3e30a-p4

### Scorecard: t10-mine-ba3e30a-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0114 | 6 | 1 | Opponent | no | 7 | 2 | 1 | 1 | 0 | 0 | 0 | 177 |
| L0130 | 4 | 1 | Mine | no | 5 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 4 | - | 1 | 3 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 7 | 4 | 0 | 0 | 0 | 85 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 11 | 3 | 1 | 0 | 0 | 0 | 0 | 360 |
| L0315 | 3 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 650 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 7 | 0 | 0 | 0 | 340 |
| L0417 | 3 | 1 | Mine | no | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 177 |
| L0417 | 3 | 1 | Opponent | no | 4 | 2 | 0 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 885 |
| L0520 | 4 | 1 | Opponent | no | 4 | - | 0 | 8 | 2 | 0 | 0 | 245 |
| L0608 | 2 | 1 | Mine | - | - | 6 | 0 | 3 | 0 | 0 | 0 | 160 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 475 |
| L0624 | 6 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 120 |
| L0624 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 1 | 1 | 0 | 2 | 0 | 0 | 122 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 1 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 314 |
| L0729 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 292 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 712 |
| L0819 | 3 | 1 | Opponent | yes | 11 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 110 |
| L0926 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 310 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 110 |
| L1017 | 3 | 1 | Mine | no | 9 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Opponent | yes | 15 | 2 | 4 | 0 | 1 | 0 | 0 | 98 |
| L1034 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 1 | 0 | 0 | 165 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 7 | 3 | 4 | 0 | 0 | 0 | 0 | 165 |
| L1126 | 4 | 1 | Opponent | no | 6 | 3 | 3 | 1 | 1 | 0 | 0 | 60 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1220 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 21 | 2 | 1 | 0 | 1 | 0 | 0 | 70 |
| L1314 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 247 |
| L1331 | 5 | 1 | Opponent | yes | - | 3 | 0 | 2 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1621 | 1 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 6 | 1 | 0 | 0 | 860 |
| L1719 | 3 | 1 | Mine | yes | 10 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | no | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | yes | 3 | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | yes | 4 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | - | 3 | 1 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | 4 | 2 | 4 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 0 | 7 | 0 | 0 | 0 | 290 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 5 | 0 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 2 | 1 | 6 | 0 | 1 | 0 | 0 | 144 |
| L2227 | 1 | 1 | Opponent | no | 2 | 1 | 3 | 1 | 0 | 0 | 0 | 60 |
| L2331 | 3 | 1 | Mine | no | 1 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 4 | 5 | 1 | 2 | 4 | 0 | 0 | 460 |
| L2527 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 75 |
| L2527 | 1 | 1 | Opponent | no | 6 | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 3 | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 1 | 3 | 4 | 1 | 0 | 0 | 170 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 4.8 | 2.6 | 2.4 | 1.2 | 0.3 | 0.0 | 0.0 | 178.0 |
| **Average** | | | Opponent | 33% | 3.8 | 2.2 | 2.6 | 2.5 | 0.5 | 0.0 | 0.0 | 116.1 |

### KPIs: t10-mine-ba3e30a-p4

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 35 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (49 of 171) | 0% (0 of 169) | 14% (49 of 340) |
| Winner chose to follow up after the loser gave ground |  | 71% (30 of 42); on the table 81% | 100% (42 of 42); on the table 100% | 86% (72 of 84); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (12 of 15); on the table 80% | 88% (7 of 8); on the table 88% | 83% (19 of 23); on the table 83% |
| Winner chose to pursue after the loser fled |  | 79% (15 of 19); on the table 79% | 63% (19 of 30); on the table 67% | 69% (34 of 49); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 75% (57 of 76); on the table 80% | 85% (68 of 80); on the table 86% | 80% (125 of 156); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 27% (75 of 273) | 36% (61 of 170) | 31% (136 of 443) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (75 of 192) | 44% (61 of 139) | 41% (136 of 331) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 46% (13 of 28) | 54% (43 of 79) | 52% (56 of 107) |
| Points that never fought | lower | 41% (26955 of 65943) | 39% (27096 of 69986) | 40% (54051 of 135929) |
|   infantry points that never fought | lower | 48% (7377 of 15284) | 67% (8953 of 13291) | 57% (16330 of 28575) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (160 of 262) | 55% (150 of 272) | 58% (310 of 534) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.0 uses a game | 89% (8 of 9); 0.6 uses a game | 94% (29 of 31); 1.3 uses a game |
| Bound items with another spell used |  | 44% (7 of 16); 0.3 uses a game | 50% (10 of 20); 0.4 uses a game | 47% (17 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 37% (7 of 19); 0.2 uses a game | 79% (11 of 14); 0.3 uses a game | 55% (18 of 33); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (30465 of 55874) | 46% (28347 of 61641) | 50% (58812 of 117515) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (26%) | 0.8 (27%) | 2.3 (26%) |
| MARCHED: its unit marched | 1.3 (22%) | 0.8 (27%) | 2.1 (24%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.4 (14%) | 0.7 (8%) |
| IN COMBAT: engaged in combat | 1.0 (18%) | 0.4 (14%) | 1.4 (16%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (1%) | 0.2 (3%) |
| FLEEING: fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.9 (16%) | 0.4 (12%) | 1.3 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (3%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.5 | 2.0 | 3.9 | 0.2 | 1.7 |
| not cast | 3.0 | 2.5 | 2.9 | 8.8 | 1.9 | 21.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (56%) | 0.4 (13%) | 2.3 (26%) | 0.5 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (24%) | 0.3 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (8%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (2%) | 0.3 (11%) | 1.4 (16%) | 0.4 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (12%) | 0.2 (7%) | 0.4 (13%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.1 (4%) | 0.3 (3%) | 0.1 (6%) | 0.4 (2%) |
| GONE: slain | 0.8 (26%) | 0.3 (10%) | 0.4 (13%) | 1.3 (14%) | 0.1 (8%) | 3.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.2 (7%) | 0.1 (3%) | 0.3 (3%) | 0.1 (8%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.4 (15%) | 0.0 (0%) | 0.1 (1%) | 0.2 (11%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (53%) | 0.1 (3%) | 1.3 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.8 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.9 a game | 1.0 a game |
| stood (cast and not dispelled) | 76% (28 of 37) | 53% (10 of 19) | 68% (38 of 56) |
| the unit moved after it | 82% (23 of 28) | 70% (7 of 10) | 79% (30 of 38) |
| it charged on its next turn | 0% (0 of 28) | 0% (0 of 10) | 0% (0 of 38) |
| the enemy charged it first | 21% (6 of 28) | 0% (0 of 10) | 16% (6 of 38) |
| it fought by the end of its next turn | 11% (3 of 28) | 0% (0 of 10) | 8% (3 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 29% (8 of 28) | 10% (1 of 10) | 24% (9 of 38) |
| none of these (no charge, no fight, no charge escaped) | 50% (14 of 28) | 90% (9 of 10) | 61% (23 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (592 of 884) | 56% (287 of 517) | 63% (879 of 1401) |
|   cavalry | 69% (59 of 85) | 68% (78 of 115) | 68% (137 of 200) |
|   character | 57% (65 of 114) | 18% (24 of 132) | 36% (89 of 246) |
|   chariot | 72% (72 of 100) | 71% (15 of 21) | 72% (87 of 121) |
|   infantry | 59% (152 of 256) | 68% (135 of 198) | 63% (287 of 454) |
|   monster | 58% (25 of 43) | 33% (6 of 18) | 51% (31 of 61) |
|   war machine | 77% (219 of 286) | 88% (29 of 33) | 78% (248 of 319) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (18%) | 0.9 (14%) | 2.4 (16%) |
| CHARGED: it charged | 0.8 (10%) | 1.8 (28%) | 2.6 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.4 (6%) | 1.3 (8%) |
| MOVED: a war machine that moved | 1.2 (14%) | 0.0 (0%) | 1.2 (8%) |
| NO TARGET IN RANGE | 1.8 (22%) | 1.6 (25%) | 3.5 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (9%) | 0.5 (7%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.9 (11%) | 1.2 (18%) | 2.1 (14%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.2 (2%) | 0.1 (1%) | 0.2 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.5 | 1.8 | 79% | 5.8 pts | 38 pts |
| character | 3.0 | 0.9 | 84% | 4.6 pts | 14 pts |
| chariot | 2.5 | 1.8 | 61% | 25.5 pts | 64 pts |
| infantry | 11.5 | 4.8 | 73% | 8.9 pts | 103 pts |
| monster | 0.9 | 0.2 | 84% | 6.9 pts | 6 pts |
| war machine | 7.1 | 7.6 | 60% | 36.1 pts | 256 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 6.0 | 4.9 |
| Charges that made contact a game | 2.7 | 4.0 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.11 declared, 1.00 contact (18 units) | 0.47 declared, 0.24 contact (17 units) | 0.80 declared, 0.63 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.71 declared, 0.43 contact (7 units) | 1.25 declared, 0.83 contact (12 units) | 1.05 declared, 0.68 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.30 contact (249 units) | 0.65 declared, 0.44 contact (288 units) | 0.55 declared, 0.37 contact (537 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (43 of 76) | 25% (4 of 16) | 33% (2 of 6) | 50% (49 of 98) |
| Character in a unit | 77% (23 of 30) | 89% (16 of 18) | 0% (0 of 1) | 80% (39 of 49) |
| Character on its own | 77% (27 of 35) | 33% (8 of 24) | 26% (19 of 73) | 41% (54 of 132) |
| Chariot | 67% (10 of 15) | 58% (7 of 12) | - | 63% (17 of 27) |
| Infantry | 64% (52 of 81) | 40% (10 of 25) | 83% (5 of 6) | 60% (67 of 112) |
| Monster | 66% (21 of 32) | 79% (11 of 14) | - | 70% (32 of 46) |
| Monstrous | 91% (10 of 11) | 50% (7 of 14) | - | 68% (17 of 25) |
| War Machines | 77% (33 of 43) | 100% (2 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 86% (6 of 7); on the table 86% | 30% (31 of 102) | 38% | 64% (14 of 22) | 100% (6 of 6); 5.0 uses a game | 100% (2 of 2); 0.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 83% (5 of 6); on the table 83% | 62% (15 of 24) | 49% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 33% (1 of 3); on the table 67% | - | 73% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 73% (11 of 15); on the table 73% | 44% (8 of 18) | 49% | 68% (42 of 62) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 40% (2 of 5); 0.3 uses a game |
| Grand Cathay | 4 | 80% (8 of 10); on the table 90% | 19% (16 of 84) | 43% | 51% (19 of 37) | 89% (8 of 9); 6.8 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 69% (9 of 13); on the table 77% | 19% (7 of 36) | 32% | 51% (36 of 70) | 100% (7 of 7); 2.9 uses a game | 43% (13 of 30); 1.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 0% (0 of 1); on the table 0% | - | 54% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 86% (6 of 7); on the table 86% | 83% (5 of 6) | 30% | 57% (12 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 80% (4 of 5); on the table 80% | 0% (0 of 6) | 64% | 79% (11 of 14) | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (9 of 9); on the table 100% | 12% (5 of 42) | 11% | 29% (7 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 6 | 42% (5 of 12); on the table 50% | 38% (16 of 42) | 52% | 78% (35 of 45) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 100% (13 of 13); on the table 100% | 50% (3 of 6) | 31% | 20% (4 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 93% (26 of 28); on the table 93% | 39% (23 of 59) | 28% | 55% (23 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 86% (12 of 14); on the table 86% | 50% (6 of 12) | 38% | 56% (36 of 64) | 100% (2 of 2); 0.5 uses a game | 0.0 uses a game | 100% (3 of 3); 0.4 uses a game |
| Wood Elf Realms | 5 | 77% (10 of 13); on the table 85% | 17% (1 of 6) | 37% | 67% (32 of 48) | 50% (1 of 2); 0.2 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t10-mine-ba3e30a-p4, 35 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (34) | 62% (38) | 53% (72) |
| ...free all their last turn and able to turn (per game) | 0.63 | 0.80 | 1.43 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.23 | 0.14 | 0.37 |
| ...with the charger already in that arc before they moved (per game) | 0.43 | 0.63 | 1.06 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.80 | 0.80 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.66 | 0.66 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.34 | 5.60 | 5.94 |

### Quality by phase: t10-mine-ba3e30a-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 52% (72 of 138) | 42% (67 of 160) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (159 of 399) | 43% (69 of 161) |
| Strategy | Close-in objectives charged next turn | - | 16% (34 of 219) |
| Strategy | Support requests answered (helper made contact too) | 50% (7 of 14) | 57% (13 of 23) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 36% (5 of 14) | 67% (6 of 9) |
| Strategy | Joined characters whose unit fought | 41% (16 of 39) | 44% (14 of 32) |
| Strategy | Lone characters that fought | 77% (63 of 82) | 73% (60 of 82) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.2 | 2.5 |
| Movement | Points that never moved of their own | 178.0 | 116.1 |
| Movement | Fights charged into per game | 2.6 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 81, net +18 | 17 of 89, net +224 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 81, net -5 | 15 of 89, net +158 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 17 of 81, net +48 | 11 of 89, net +120 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 of 81, net +148 | 18 of 89, net +121 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (186 of 397) | 43% (132 of 309) |
| Shooting | Points destroyed by shooting units | 85.0 | 66.8 |
| Shooting | War machine shots | 6.3 | 0.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (139 of 219) | 62% (18 of 29) |
| Shooting | Points destroyed by war machines | 86.3 | 5.2 |
| Magic | Magic missiles cast | 1.4 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (20 of 49) | 29% (14 of 49) |
| Magic | Wounds caused by magic missiles | 3.2 | 1.3 |
| Magic | Wounds caused by other spells | 2.3 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 103.9 | 21.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.5 / 0.6 / 0.1 | 1.9 / 0.5 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 271.3 | 422.9 |
| Combat | Points run down | 24.3 | 122.5 |
| Combat | Net points per charged fight, damage counted | +56 | +124 |
| Combat | Net per 100 charger points, damage counted | +19.7 | +34.8 |
| Combat | First round won (charged fights) | 70% | 72% |
| Combat | Net points per charged fight | +55 | +127 |
| Combat | Net points per supported fight / lone fight | +130 / +50 | +223 / +107 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 92 | 54 of 113 |
| Game | Points lost | 786.4 | 619.3 |
| Game | VP from objectives | 595.4 | 588.3 |
| Game | Lone holders (player turns) | 4.8 | 3.8 |

- Mine won / drew / lost: 11 / 8 / 16 of 35 ended games (of 35); mean margin (Mine - Opponent) -193 VP
- The side that went first won 13 of 27 games with a winner
- Points traded per game (both sides' losses): 1406
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t10-mine-ba3e30a-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.1 | +0.0 | 0.0 | 4.1 | 1.1 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 6.2 | -131.6 | 139.6 | 85.1 |
| AFTERMATH IN POINTS | 0.3 | +34.8 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.1 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 10.7 | +130.3 | 0.0 | 244.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 0.8 | +0.0 | 0.0 | 13.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.3 | 0.0 | 10.8 | 0.7 | +4.2 | 0.0 | 0.0 |
| BEST FACING | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| BEST FIRST | - | - | - | - | 1.1 | +41.5 | 5.4 | 28.6 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.5 | +28.7 | 0.0 | 4.6 |
| BEST OVERALL | - | - | - | - | 0.1 | +9.6 | 0.0 | 8.1 |
| BEST PREY | - | - | - | - | 0.7 | +73.7 | 33.6 | 0.0 |
| BEST PRIZE | 0.1 | -0.7 | 3.9 | 0.0 | 0.2 | -10.1 | 19.9 | 13.3 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.2 | -0.4 | 0.0 | 0.0 |
| BLOCKED CHARGE HANDED OVER | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 2.6 | 8.1 |
| BLOCKED WHEEL | - | - | - | - | 0.6 | +27.4 | 0.0 | 1.9 |
| BLOWS WHERE AIMED | 0.2 | -20.4 | 1.7 | 5.0 | 0.2 | -43.2 | 31.7 | 5.6 |
| BOMBING RUN | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 172.6 | 11.4 | 0.2 | +0.0 | 20.8 | 0.0 |
| CANNON PLANNED TARGET | 5.9 | +190.9 | 512.5 | 73.0 | 0.8 | +25.7 | 94.8 | 2.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | -0.8 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | +0.0 | 26.5 | 0.0 |
| CAST JOB | 0.6 | +15.9 | 33.8 | 10.9 | 0.5 | +12.9 | 38.4 | 6.7 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +32.3 | 18.8 | 0.0 | 0.1 | +0.7 | 6.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 76.4 | 0.3 | +0.0 | 0.0 | 36.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.7 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +17.7 | 0.0 | 0.9 | 2.3 | +126.6 | 0.0 | 62.3 |
| CHAFF PASSED | 0.3 | -0.1 | 0.0 | 2.1 | 0.1 | -0.0 | 3.3 | 8.5 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 6.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.0 | -2.5 | 0.0 | 4.2 | - | - | - | - |
| CHARGE LOSSES | 4.0 | -209.2 | 0.0 | 159.2 | - | - | - | - |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 47.0 | 8.9 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 192.5 | 72.5 | 2.8 | +0.0 | 399.8 | 24.6 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.3 | -16.5 | 0.0 | 19.2 |
| CHARGER SLAIN LOST | 0.5 | -20.2 | 61.7 | 14.6 | 0.3 | -6.2 | 15.1 | 17.3 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -0.0 | 0.0 | 15.4 |
| CHEAP HELPER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 39.4 | 64.0 | 0.4 | +0.0 | 27.5 | 12.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.1 | +87.4 | 32.2 | 59.7 | 0.3 | +66.7 | 0.0 | 0.0 |
| COVER ONCE | 6.7 | -415.1 | 0.0 | 137.4 | 5.4 | -378.9 | 0.0 | 89.3 |
| DEFENSIVE FLOOR | 0.0 | -0.8 | 5.3 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | +15.4 | 0.0 | 7.6 | 7.7 | +53.2 | 0.0 | 19.1 |
| EDGE GIVE GROUND | 0.1 | +15.1 | 21.5 | 0.0 | 0.3 | +17.1 | 21.7 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.2 | 0.0 | 20.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.8 | +59.5 | 0.0 | 48.6 |
| FALL BACK GOOD ORDER | 2.3 | +6.0 | 203.1 | 51.8 | - | - | - | - |
| FALLBACK BY WORTH | 0.3 | +0.2 | 0.0 | 0.9 | 5.6 | +42.6 | 0.0 | 58.0 |
| FALLS SHORT | 2.7 | +40.3 | 0.0 | 64.2 | - | - | - | - |
| FEATURE BUFFS | 1.4 | +30.2 | 0.0 | 29.5 | - | - | - | - |
| FIGHT LIFT | 0.1 | +0.2 | 10.1 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +57.9 | 117.3 | 12.1 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +10.2 | 3.6 | 5.8 | 0.0 | +0.3 | 0.0 | 2.4 |
| FIRE IN ORDER | 0.3 | +0.0 | 13.6 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 45.5 | +2863.4 | 1235.9 | 824.8 | - | - | - | - |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 130.4 | 5.2 | +0.0 | 0.0 | 140.1 |
| FOCUS FIRE | 0.0 | +0.6 | 1.6 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +86.9 | 0.0 | 10.5 | 1.2 | +144.0 | 0.0 | 68.3 |
| FOUR ROUNDS | 4.0 | +340.7 | 333.8 | 76.8 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.1 | -4.4 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.2 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.2 | +6.5 | 0.0 | 0.0 | 0.1 | +10.6 | 0.0 | 0.0 |
| GIVES UP | 0.5 | -8.0 | 20.1 | 0.0 | 0.1 | -1.4 | 6.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.0 | 2.0 | 0.0 |
| GROUND FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.3 | +23.8 | 70.2 | 17.9 | 0.4 | +1.3 | 21.4 | 0.0 |
| GUN MASK | 0.5 | +9.5 | 0.0 | 18.1 | - | - | - | - |
| HARD STAY DROPPED | 1.6 | +0.0 | 0.0 | 15.5 | - | - | - | - |
| HE SHOOTS OR CHARGES | 1.5 | +0.0 | 0.0 | 80.3 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 1.9 | 1.5 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.0 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.7 | -48.7 | 0.0 | 13.1 |
| HIS CHARGE DENIED | 0.6 | +31.1 | 53.8 | 5.9 | - | - | - | - |
| HIS CHARGE LIST | 2.5 | +0.0 | 0.0 | 59.0 | - | - | - | - |
| HIS FIGHT TOGETHER | 1.5 | -20.6 | 0.0 | 87.3 | - | - | - | - |
| HIS LEGAL MOVES | 2.8 | +0.0 | 0.0 | 72.4 | - | - | - | - |
| HIS MOVE AND SHOT | 1.0 | -12.4 | 0.0 | 22.2 | - | - | - | - |
| HIS OWN BEST MOVE | 2.1 | +0.0 | 0.0 | 81.8 | - | - | - | - |
| HIS RANDOM MOVE | 3.3 | +0.0 | 0.0 | 87.5 | - | - | - | - |
| HIS SHOT LIST | 14.4 | +377.2 | 0.0 | 320.8 | - | - | - | - |
| HIS TURN DENIED | 1.3 | +43.6 | 165.4 | 29.5 | - | - | - | - |
| HOLDER ASSIGNMENT | 10.6 | +1014.7 | 0.0 | 115.5 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 0.8 | +125.4 | 0.0 | 1.6 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -127.6 | 229.3 | 58.0 | 9.7 | -256.2 | 648.0 | 141.2 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.5 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.6 |
| HUNT IN PAIRS | 0.4 | +9.3 | 0.0 | 28.8 | 0.3 | +22.0 | 0.0 | 5.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +2.7 | 0.0 | 3.3 |
| HUNT RESULT | 0.0 | +4.8 | 2.0 | 0.0 | 0.1 | +5.1 | 0.0 | 6.3 |
| HUNT THE GUNS | 0.0 | +5.7 | 2.0 | 0.0 | 0.1 | +32.4 | 3.0 | 0.0 |
| IDLE COST | 1.7 | -23.6 | 0.0 | 23.3 | 21.0 | -354.0 | 0.0 | 233.9 |
| INVITES THE FIGHT | - | - | - | - | 0.9 | +5.7 | 36.6 | 9.4 |
| JOINT CHARGE NOW | 0.9 | +66.0 | 94.1 | 17.1 | - | - | - | - |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +8.9 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -1.4 | 12.3 | 0.0 | 0.2 | -8.7 | 22.6 | 5.6 |
| JOINT ON THE TABLE | 0.0 | +17.9 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.1 | +62.6 | 146.8 | 11.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 2.1 | +134.5 | 310.2 | 24.7 |
| KILLS COUNT NEXT TURN | - | - | - | - | 6.0 | +241.5 | 211.4 | 146.5 |
| LANE BY FIGURES | 0.8 | +28.2 | 0.0 | 0.0 | 1.1 | +60.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.9 | +0.0 | 232.4 | 423.7 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.0 | +0.8 | 0.0 | 0.0 | 0.3 | +9.0 | 0.0 | 32.2 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.3 | +0.0 | 19.5 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +27.7 | 0.0 | 0.0 | 0.2 | +20.9 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -4.5 | 27.4 | 0.0 | 0.4 | +3.0 | 17.5 | 4.9 |
| LOST CHARGE | 0.0 | -0.0 | 0.0 | 0.0 | 1.9 | -29.5 | 67.3 | 99.7 |
| LURE BY WHAT IT DRAWS | 0.1 | -12.1 | 0.0 | 1.6 | 0.1 | -13.2 | 0.0 | 3.7 |
| MAKE SURE TOGETHER | 0.2 | +4.7 | 0.0 | 10.4 | 0.5 | +27.5 | 0.0 | 7.9 |
| MANOEUVRE | 1.3 | +15.7 | 0.0 | 30.6 | 0.2 | +10.2 | 0.0 | 3.3 |
| MARCH AT ESCAPER | 0.1 | +1.3 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +15.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.6 | +29.9 | 0.0 | 10.7 | 0.2 | +5.7 | 0.0 | 3.3 |
| MARCH ODDS | - | - | - | - | 0.4 | +29.6 | 17.4 | 11.3 |
| MARCH OVER CASTS | 0.8 | +75.7 | 0.0 | 15.4 | 0.4 | +23.1 | 0.0 | 38.1 |
| MAX FOR POSITIONING | 5.1 | +67.6 | 0.0 | 117.8 | 6.6 | +75.8 | 0.0 | 156.6 |
| MISSILES IN THE MOVE | 3.9 | +162.6 | 0.0 | 102.4 | 2.5 | +35.9 | 0.0 | 73.4 |
| MISSILES NEXT TURN | 4.9 | +102.1 | 0.0 | 138.0 | 3.1 | +24.1 | 0.0 | 138.5 |
| MODEL FACING | 0.2 | +45.7 | 0.0 | 3.4 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.3 | +16.7 | 0.0 | 0.0 |
| MOVE ORDER | 1.5 | +0.0 | 22.1 | 30.8 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.4 | +9.7 | 0.0 | 2.4 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -12.2 | 0.0 | 0.0 | 0.2 | -7.3 | 3.6 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 44.9 | 0.1 | +0.0 | 0.0 | 14.3 |
| MOVE TO CHARGE | - | - | - | - | 4.0 | +333.3 | 131.1 | 94.6 |
| MOVE TO CHARGE COMPUTED | 3.9 | +462.8 | 0.0 | 68.4 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.8 | +161.9 | 0.0 | 60.4 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +9.3 | 15.9 | 0.0 |
| NEXT CHARGE BY LIST | 4.5 | -153.3 | 19.8 | 94.3 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 5.6 | -186.3 | 31.0 | 100.7 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.9 | -105.4 | 266.4 | 58.9 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +0.1 | 0.0 | 4.1 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.4 | -14.0 | 47.0 | 4.3 |
| NOT TURNED | 0.3 | +2.1 | 0.0 | 3.6 | 5.6 | +63.7 | 0.0 | 124.3 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 34.5 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -17.5 | 0.0 | 1.7 | 16.8 | -817.0 | 5.3 | 311.1 |
| ONE CHARGE A CHARGER | 3.1 | +0.0 | 0.0 | 88.1 | - | - | - | - |
| ONE FIGHT FORMULA | 5.3 | -112.9 | 0.0 | 133.0 | 8.3 | -175.1 | 31.7 | 152.2 |
| ONE OBJECTIVE FORMULA | 3.5 | +44.3 | 0.0 | 64.8 | 2.9 | -107.7 | 0.0 | 48.3 |
| ONE TARGET A SHOOTER | 11.7 | +160.7 | 0.0 | 233.5 | - | - | - | - |
| OPENS A LANE | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| OPENS UP | 0.5 | +27.2 | 32.2 | 12.4 | 0.3 | +22.2 | 17.1 | 0.0 |
| OVERRUNS AWAY | 0.5 | +26.5 | 57.6 | 14.1 | 0.5 | +11.8 | 58.0 | 18.9 |
| PATHS CROSS | 2.3 | +66.2 | 0.0 | 50.9 | 2.8 | +216.9 | 0.0 | 34.3 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.1 | +9.9 | 0.0 | 15.4 |
| PIVOT GUARDS FLANK | 0.1 | -0.9 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 2.8 |
| PLAN RESULT | 40.5 | +1031.0 | 795.9 | 1117.9 | 40.5 | +1160.3 | 1374.3 | 884.9 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -7.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +14.3 | 0.0 | 7.8 |
| RANDOM MOVE BY FIGURES | 0.8 | +5.9 | 0.0 | 30.0 | 2.3 | +21.6 | 0.0 | 79.6 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.3 | -10.1 | 9.9 | 12.4 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +0.5 | 0.0 | 0.9 | 2.0 | -61.9 | 0.0 | 55.2 |
| REDIRECT COUNTER | 2.2 | +114.1 | 0.0 | 36.5 | 4.2 | +321.6 | 0.0 | 92.3 |
| REDIRECT WEIGHED | 0.4 | +7.9 | 10.2 | 0.0 | 0.5 | +10.2 | 26.9 | 7.3 |
| REFORMS TO MEET IT | 0.9 | -33.4 | 0.0 | 10.1 | - | - | - | - |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 11.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +12.3 | 0.0 | 15.6 | 0.5 | +20.3 | 0.0 | 11.5 |
| RESTRAINS TO SHOOT | 0.1 | +4.3 | 0.0 | 0.0 | 0.1 | +6.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | +87.6 | 212.7 | 30.7 | 2.5 | +60.5 | 272.9 | 53.6 |
| RISK BY HIS FIGURE | 12.7 | -156.3 | 0.0 | 334.1 | - | - | - | - |
| RISK ONCE | - | - | - | - | 3.8 | +194.6 | 70.8 | 243.9 |
| RUN DOWN | 2.3 | -20.6 | 185.0 | 29.3 | - | - | - | - |
| SAFER THAN THE JOB | - | - | - | - | 0.7 | +38.0 | 0.0 | 11.4 |
| SAME CHARGE LATER | 0.1 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 3.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 3.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -4.3 | 0.0 | 2.1 | 0.5 | -38.3 | 0.0 | 3.4 |
| SEARCH SPOT | 6.3 | +244.4 | 0.0 | 142.5 | 2.8 | +96.5 | 0.0 | 53.0 |
| SELF MOVE SPELL | 0.2 | +17.2 | 0.0 | 22.6 | 0.7 | +37.5 | 0.0 | 22.6 |
| SET UP BY THE SET | 0.6 | -26.4 | 3.1 | 30.0 | - | - | - | - |
| SET UP TOGETHER | 0.2 | +4.7 | 0.0 | 10.4 | 0.8 | +57.1 | 5.2 | 15.3 |
| SET-UP ANY TARGET | 0.2 | +17.1 | 2.4 | 2.4 | - | - | - | - |
| SET-UP MISSED | 0.1 | +5.3 | 10.4 | 2.4 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +84.9 | 103.9 | 17.8 | 0.9 | +32.9 | 30.5 | 20.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.5 | -56.2 | 124.4 | 3.9 | - | - | - | - |
| SHOT RISK POINTS | 5.7 | +4.9 | 0.0 | 163.9 | - | - | - | - |
| SHOTS IN THE MOVE | 17.1 | +724.2 | 0.0 | 310.4 | 8.1 | +226.2 | 0.0 | 128.0 |
| SPELL SETS UP CHARGE | 0.2 | +17.1 | 2.4 | 2.4 | 0.1 | +41.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +18.2 | 91.8 | 111.5 | 2.5 | +40.9 | 97.7 | 97.7 |
| SPELLS IN THE FIGHT | 0.9 | -2.5 | 121.5 | 34.3 | 0.9 | -11.6 | 159.1 | 24.3 |
| STABLE ROLE | - | - | - | - | 11.9 | +0.0 | 363.4 | 128.1 |
| STAND AND SHOOT | 0.8 | -8.6 | 69.5 | 19.0 | - | - | - | - |
| STANDS FOR A REASON | 0.1 | +0.0 | 1.7 | 0.0 | - | - | - | - |
| STANDS STILL | 17.5 | +0.0 | 902.1 | 275.1 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.1 | +1.6 | 0.0 | 0.0 |
| STAY WORTH | 19.4 | +90.2 | 508.1 | 294.2 | 9.2 | +65.1 | 236.9 | 127.6 |
| STOPS | 0.0 | +1.0 | 2.0 | 0.0 | 0.1 | +3.8 | 3.0 | 3.3 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.3 | +7.2 | 0.0 | 22.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 6.0 | 0.3 | +0.0 | 0.0 | 10.9 |
| SUPPORT NARROWED | 1.4 | +0.0 | 129.5 | 12.1 | 7.5 | -59.8 | 290.6 | 73.5 |
| SUPPORTS | - | - | - | - | 5.3 | +59.8 | 86.0 | 37.9 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -1.2 | 3.7 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +4.8 | 0.0 | 23.2 | 0.4 | +1.7 | 0.0 | 16.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.8 | +0.0 | 0.0 | 55.5 | - | - | - | - |
| THE PROMISE ADDS | 0.2 | -5.5 | 0.0 | 13.3 | - | - | - | - |
| THE PROMISED MOVE | 1.5 | +0.0 | 0.0 | 30.3 | - | - | - | - |
| THROUGH LINE OF FIRE | - | - | - | - | 0.2 | +15.3 | 0.0 | 1.9 |
| TIED UP BY THE SUM | 0.9 | +102.5 | 54.4 | 1.3 | - | - | - | - |
| TIME ON OUR SIDE | 27.5 | +406.6 | 9.1 | 478.7 | - | - | - | - |
| TURN WORTH | - | - | - | - | 0.2 | -12.7 | 12.9 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.2 | +1.0 | 0.0 | 4.0 |
| WAIT AFTER COSTS | - | - | - | - | 7.3 | -343.5 | 240.6 | 124.4 |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 17.1 | - | - | - | - |
| WALKS TO THE FIGHT | - | - | - | - | 1.8 | +9.4 | 57.5 | 6.9 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 49.8 | 26.9 | 0.1 | +0.0 | 5.3 | 10.4 |
| WEARS DOWN | - | - | - | - | 1.1 | +31.6 | 79.0 | 23.8 |
| WHO HITS BACK | 0.4 | +58.1 | 0.0 | 26.3 | 0.2 | +19.8 | 0.0 | 7.2 |
| WHOLE FIGHT | 0.2 | -0.5 | 4.5 | 3.9 | 0.3 | +2.1 | 28.4 | 1.3 |
| WHOLE FIGHT GAIN | 0.2 | +10.9 | 31.1 | 1.5 | 0.6 | +47.5 | 62.7 | 16.6 |
| WIDER SPREAD | 2.7 | -8.1 | 208.5 | 53.6 | 3.1 | -11.4 | 358.5 | 40.9 |
| WOUNDS ON THE RANKS | 0.4 | +13.8 | 0.0 | 20.9 | - | - | - | - |

### Rule changes: t10-mine-ba3e30a-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 612 | 612 | 612 | 17.49 | -29208 | -47.7 |
| DEPLOY BY FIGURES | 558 | 558 | 359 | 10.26 | +4932 | +13.7 |
| HOLDER ASSIGNMENT | 372 | 372 | 343 | 9.80 | +18958 | +55.3 |
| SEARCH SPOT | 318 | 318 | 308 | 8.80 | +11947 | +38.8 |
| ARMY TABLE | 374 | 374 | 251 | 7.17 | +2863 | +11.4 |
| LEGAL CHARGES ONLY | 242 | 242 | 242 | 6.91 | +0 | +0.0 |
| PATHS CROSS | 179 | 179 | 179 | 5.11 | +9906 | +55.3 |
| TIME ON OUR SIDE | 962 | 860 | 165 | 4.71 | +620 | +3.8 |
| FIVE ACTION | 1594 | 1585 | 152 | 4.34 | +6585 | +43.3 |
| HIS SHOT LIST | 504 | 499 | 122 | 3.49 | +1567 | +12.8 |
| MOVE TO CHARGE | 141 | 141 | 94 | 2.69 | +4279 | +45.5 |
| SHOTS IN THE MOVE | 881 | 761 | 93 | 2.66 | +2658 | +28.6 |
| MOVE TO CHARGE COMPUTED | 138 | 135 | 92 | 2.63 | +6230 | +67.7 |
| ADVANCE LANE KEPT | 77 | 77 | 77 | 2.20 | +0 | +0.0 |
| FOUR ROUNDS | 139 | 139 | 77 | 2.20 | +4562 | +59.2 |
| ONE TARGET A SHOOTER | 409 | 408 | 76 | 2.17 | +563 | +7.4 |
| COVER ONCE | 424 | 297 | 75 | 2.14 | +1395 | +18.6 |
| KILLS COUNT NEXT TURN | 210 | 210 | 67 | 1.91 | +1963 | +29.3 |
| LANE BY FIGURES | 67 | 67 | 67 | 1.91 | +3099 | +46.2 |
| REDIRECT COUNTER | 224 | 141 | 64 | 1.83 | +5898 | +92.2 |
| CHAFF IN THE MOVE | 92 | 92 | 63 | 1.80 | +1894 | +30.1 |
| FOLLOW UP WEIGHED | 63 | 63 | 63 | 1.80 | +8081 | +128.3 |
| SUPPORTS | 187 | 187 | 61 | 1.74 | +600 | +9.8 |
| WAIT AFTER COSTS | 256 | 256 | 57 | 1.63 | +747 | +13.1 |
| RANDOM MOVE BY FIGURES | 107 | 107 | 56 | 1.60 | +963 | +17.2 |
| HARD STAY DROPPED | 55 | 55 | 55 | 1.57 | +0 | +0.0 |
| RISK BY ARC | 178 | 174 | 54 | 1.54 | +1607 | +29.8 |
| MAX FOR POSITIONING | 412 | 325 | 51 | 1.46 | +186 | +3.7 |
| MOVE ORDER | 51 | 51 | 51 | 1.46 | +0 | +0.0 |
| CHARGE NOW FIRST | 164 | 164 | 44 | 1.26 | -2396 | -54.4 |
| MISSILES IN THE MOVE | 227 | 175 | 43 | 1.23 | +1044 | +24.3 |
| FALLBACK BY WORTH | 206 | 206 | 42 | 1.20 | +1498 | +35.7 |
| COMBAT PIVOT | 40 | 40 | 40 | 1.14 | +0 | +0.0 |
| BEST FIRST | 38 | 38 | 38 | 1.09 | +1452 | +38.2 |
| CANNON SIGHT KEPT | 37 | 37 | 37 | 1.06 | +0 | +0.0 |
| ADVANCE WORTH | 218 | 218 | 35 | 1.00 | +1110 | +31.7 |
| HOLDS AMBUSHERS | 34 | 34 | 34 | 0.97 | +0 | +0.0 |
| CANNON PLANNED TARGET | 233 | 233 | 33 | 0.94 | -214 | -6.5 |
| REDIRECT WEIGHED | 33 | 33 | 33 | 0.94 | +3521 | +106.7 |
| SHOOTS FROM THE BEST SPOT | 65 | 65 | 33 | 0.94 | +709 | +21.5 |
| SHOT RISK POINTS | 199 | 198 | 33 | 0.94 | +542 | +16.4 |
| ARTILLERY RE-ROLL WEIGHED | 31 | 31 | 31 | 0.89 | +0 | +0.0 |
| JOINT CHARGE NOW | 30 | 30 | 30 | 0.86 | +2311 | +77.0 |
| RESERVE FALL BACK | 30 | 30 | 30 | 0.86 | +1142 | +38.1 |
| IDLE COST | 793 | 455 | 29 | 0.83 | +279 | +9.6 |
| RISK ONCE | 133 | 107 | 29 | 0.83 | +2800 | +96.6 |
| FACES THE THREAT | 28 | 28 | 28 | 0.80 | +2083 | +74.4 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.80 | +1699 | +60.7 |
| MANOEUVRE | 52 | 52 | 28 | 0.80 | +952 | +34.0 |
| TIED UP BY THE SUM | 33 | 33 | 28 | 0.80 | +922 | +32.9 |
| ONE FIGHT FORMULA | 477 | 262 | 26 | 0.74 | +107 | +4.1 |
| MARCH CHECK | 26 | 26 | 23 | 0.66 | +448 | +19.5 |
| SAFER THAN THE JOB | 23 | 23 | 23 | 0.66 | +1329 | +57.8 |
| STAY WORTH | 1000 | 912 | 23 | 0.66 | +270 | +11.7 |
| WALKS TO THE FIGHT | 62 | 62 | 23 | 0.66 | +70 | +3.0 |
| BLOCKED WHEEL | 22 | 22 | 22 | 0.63 | +960 | +43.6 |
| KILLS COUNT | 72 | 71 | 22 | 0.63 | +1450 | +65.9 |
| NEXT OBJECTIVE NEARER | 196 | 196 | 21 | 0.60 | +133 | +6.4 |
| SCOUT WAITS | 21 | 21 | 21 | 0.60 | +0 | +0.0 |
| WHO HITS BACK | 20 | 20 | 20 | 0.57 | +2147 | +107.3 |
| CAST JOB | 36 | 36 | 19 | 0.54 | +299 | +15.8 |
| HONEST WORTH | 452 | 451 | 19 | 0.54 | +214 | +11.2 |
| CASTER AWAY FROM SCREEN | 18 | 18 | 18 | 0.51 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.51 | +41 | +2.3 |
| NEXT CHARGE BY LIST | 156 | 153 | 17 | 0.49 | +595 | +35.0 |
| RISK BY HIS FIGURE | 443 | 439 | 17 | 0.49 | +1674 | +98.5 |
| BEST MOVE FOR SHOOTERS | 16 | 16 | 16 | 0.46 | +1006 | +62.8 |
| OPENS UP | 28 | 28 | 16 | 0.46 | +538 | +33.6 |
| WHOLE FIGHT GAIN | 30 | 29 | 15 | 0.43 | +576 | +38.4 |
| CHAFF PASSED | 14 | 14 | 14 | 0.40 | -5 | -0.3 |
| INVITES THE FIGHT | 31 | 31 | 14 | 0.40 | +52 | +3.7 |
| MARCH ODDS | 14 | 14 | 14 | 0.40 | +251 | +17.9 |
| CASTING BLOCK | 15 | 15 | 13 | 0.37 | +451 | +34.7 |
| FIRE IN ORDER | 13 | 13 | 13 | 0.37 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 27 | 27 | 13 | 0.37 | +628 | +48.3 |
| NEARER NOT NEEDED | 132 | 127 | 13 | 0.37 | +302 | +23.3 |
| CHARGE NOT DECLARED | 12 | 12 | 12 | 0.34 | -473 | -39.5 |
| KEEPS ITS TARGET | 73 | 73 | 12 | 0.34 | +209 | +17.4 |
| MARCH BY THE SUM | 12 | 12 | 12 | 0.34 | +540 | +45.0 |
| STOPS SHORT OF THE FLANK | 12 | 12 | 12 | 0.34 | +252 | +21.0 |
| STUCK PIVOT | 12 | 12 | 12 | 0.34 | +0 | +0.0 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.31 | +1216 | +110.6 |
| CHARGE LOSSES | 140 | 138 | 11 | 0.31 | +1043 | +94.8 |
| HIS TURN DENIED | 46 | 46 | 11 | 0.31 | +450 | +40.9 |
| MISSILES NEXT TURN | 279 | 205 | 11 | 0.31 | +22 | +2.0 |
| OVERRUNS AWAY | 37 | 37 | 11 | 0.31 | +316 | +28.7 |
| SET UP TOGETHER | 36 | 30 | 11 | 0.31 | +674 | +61.3 |
| BEST PRIZE | 10 | 10 | 10 | 0.29 | -792 | -79.2 |
| CHARGE NOW WEIGHED | 10 | 10 | 10 | 0.29 | +460 | +46.0 |
| FIGHT TO THE END | 45 | 45 | 10 | 0.29 | +689 | +68.9 |
| ONE OBJECTIVE FORMULA | 225 | 156 | 10 | 0.29 | +340 | +34.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.26 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.26 | +597 | +66.3 |
| MOVE AND CAST | 9 | 9 | 9 | 0.26 | +586 | +65.1 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.26 | +0 | +0.0 |
| SURE REACH TOGETHER | 30 | 25 | 9 | 0.26 | +16 | +1.8 |
| FALLS SHORT | 94 | 80 | 8 | 0.23 | +12 | +1.6 |
| MODEL FACING | 8 | 8 | 8 | 0.23 | +1598 | +199.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.20 | +138 | +19.7 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.20 | +359 | +51.2 |
| BEST PREY | 26 | 26 | 6 | 0.17 | +1186 | +197.6 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.17 | -14 | -2.4 |
| MAKE SURE TOGETHER | 24 | 11 | 6 | 0.17 | +345 | +57.5 |
| SET UP BY THE SET | 21 | 21 | 6 | 0.17 | +326 | +54.4 |
| SUPPORT NARROWED | 310 | 310 | 6 | 0.17 | -74 | -12.3 |
| THROUGH LINE OF FIRE | 6 | 6 | 6 | 0.17 | +534 | +89.1 |
| BEST OVERALL | 5 | 5 | 5 | 0.14 | +336 | +67.2 |
| FEATURE BUFFS | 48 | 48 | 5 | 0.14 | +25 | +5.0 |
| HUNT IN PAIRS | 27 | 12 | 5 | 0.14 | +161 | +32.2 |
| NO DOUBLE ROUNDS | 103 | 103 | 5 | 0.14 | +235 | +46.9 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +402 | +80.3 |
| WIDER SPREAD | 201 | 198 | 5 | 0.14 | +25 | +5.1 |
| WOUNDS ON THE RANKS | 14 | 14 | 5 | 0.14 | +149 | +29.8 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 81 | 81 | 4 | 0.11 | +118 | +29.4 |
| HIS CHARGE DENIED | 22 | 22 | 4 | 0.11 | +337 | +84.3 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -69 | -17.2 |
| BACKUP TARGETS | 30 | 14 | 3 | 0.09 | +5 | +1.6 |
| EDGE GIVE GROUND | 14 | 14 | 3 | 0.09 | +225 | +75.0 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.09 | +77 | +25.6 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.09 | +368 | +122.6 |
| KEEP FALLS | 3 | 3 | 3 | 0.09 | +186 | +62.1 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.09 | -261 | -87.0 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 3 | 0.09 | +107 | +35.6 |
| REDIRECT BY WHAT IT STOPS | 80 | 80 | 3 | 0.09 | +60 | +19.9 |
| REFUSING RETIRES | 12 | 12 | 3 | 0.09 | -1 | -0.4 |
| WAR ENGINE JOBS | 16 | 16 | 3 | 0.09 | -105 | -34.9 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.06 | +96 | +47.8 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -29 | -14.6 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +31 | +15.6 |
| HIS MOVE AND SHOT | 36 | 35 | 2 | 0.06 | +11 | +5.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 2 | 0.06 | -25 | -12.6 |
| LOST CHARGE | 67 | 67 | 2 | 0.06 | +13 | +6.7 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +3 | +1.5 |
| SPELLS IN THE FIGHT | 61 | 59 | 2 | 0.06 | +20 | +9.9 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +15 | +7.7 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.06 | -42 | -20.9 |
| WEARS DOWN | 37 | 35 | 2 | 0.06 | +14 | +6.8 |
| BEST FACING | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +20 | +20.1 |
| BLOWS WHERE AIMED | 13 | 12 | 1 | 0.03 | +170 | +169.8 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +37 | +37.4 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -28 | -28.2 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.03 | -89 | -88.6 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| GUN MASK | 18 | 18 | 1 | 0.03 | +11 | +11.3 |
| HIS FIGHT TOGETHER | 51 | 49 | 1 | 0.03 | +11 | +11.3 |
| HUNT ADVANCE | 2 | 2 | 1 | 0.03 | +10 | +10.3 |
| JOINT CHARGE PLAN | 3 | 3 | 1 | 0.03 | +115 | +115.2 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.03 | +628 | +627.6 |
| KEEPS ITS PREY | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 21 | 21 | 1 | 0.03 | +6 | +5.5 |
| REFORMS TO MEET IT | 33 | 33 | 1 | 0.03 | +60 | +60.2 |
| STOPS | 4 | 4 | 1 | 0.03 | +54 | +54.3 |
| WHOLE FIGHT | 17 | 17 | 1 | 0.03 | +0 | +0.0 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 43 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 30 | 29 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 50 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 374 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 19 | 19 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 57 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 51 | 51 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 24 | 24 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 86 | 85 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 97 | 95 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 74 | 72 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 116 | 113 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 9 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 10 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 41 | 41 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 13 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 27 | not checked | - | - | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 208 | 208 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 25 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 108 | 107 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2834 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 11 | 11 | 0 | 0.00 | - | - |
| RUN DOWN | 79 | 79 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 29 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 18 | 18 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 127 | not checked | - | - | - | - |
| STABLE ROLE | 416 | 415 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 28 | 28 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 611 | 607 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 97 | not checked | - | - | - | - |
| THE PROMISE ADDS | 6 | 6 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 52 | not checked | - | - | - | - |
| TURN WORTH | 8 | 8 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 7 | 7 | 0 | 0.00 | - | - |
| WAITS AGAIN | 57 | 54 | 0 | 0.00 | - | - |

### Off best figure: t10-mine-ba3e30a-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.11 | 15.54 | 49.8 |
| ARMY TABLE | rule | 1.43 | - | 19.0 |
| CHARGE NOW FIRST | rule | 0.43 | 0.80 | 55.7 |
| HOLDER ASSIGNMENT | rule | 0.94 | - | 23.2 |
| FALLBACK | gate | - | 0.54 | 28.5 |
| PATHS CROSS | rule | 0.34 | 0.11 | 25.8 |
| TURN GATE | gate | 0.03 | 0.40 | 35.2 |
| BEST PRIZE | rule | 0.06 | 0.23 | 79.2 |
| CHARGE NOT DECLARED | rule | - | 0.29 | 53.2 |
| JOINT CHARGE NOW | rule | 0.26 | - | 83.3 |
| NO REASON | gate | 0.26 | - | 22.2 |
| AFTERMATH BAND | gate | 0.14 | 0.06 | 1.6 |
| SUPPORT NARROWED | rule | 0.06 | 0.11 | 12.3 |
| CANNON PLANNED TARGET | rule | 0.14 | - | 51.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.09 | 0.03 | 78.9 |
| BIG CHARACTER SAFETY | rule | - | 0.11 | 4.0 |
| DEPLOY BY FIGURES | rule | 0.06 | 0.06 | 5.4 |
| FIGHT ORDER BAND | gate | 0.09 | 0.03 | 2.2 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.06 | 17.2 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.09 | 15.9 |
| PURSUES BIG PREY | rule | - | 0.09 | 87.0 |
| STOPS SHORT OF THE FLANK | rule | - | 0.09 | 2.8 |
| SUPPORT REQUEST | gate | - | 0.09 | 96.5 |
| WAR ENGINE JOBS | rule | - | 0.09 | 34.9 |
| CATCH ODDS | rule | 0.03 | 0.03 | 14.6 |
| CHARGE NOW WEIGHED | rule | - | 0.06 | 70.5 |
| MARCH ODDS | rule | - | 0.06 | 5.8 |
| REDIRECT WEIGHED | rule | - | 0.06 | 11.7 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.06 | 20.9 |
| AFTERMATH WITH FRIENDS | rule | 0.03 | - | 1.3 |
| BLOCKED WHEEL | rule | - | 0.03 | 3.4 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 28.2 |
| CHAFF PASSED | rule | 0.03 | - | 3.9 |
| CHARGE LIST READ AGAIN | rule | 0.03 | - | 88.6 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 25.1 |
| REFUSING RETIRES | rule | - | 0.03 | 0.7 |
| SAFER THAN THE JOB | rule | - | 0.03 | 7.3 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 18.8 |

### Plans: t10-mine-ba3e30a-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.1 | 66% | 493 | 255 | 52% |
| Mine | join | 0.3 | 90% | 7 | 0 | 0% |
| Mine | move | 27.1 | 93% | 1689 | 0 | 0% |
| Mine | shoot | 9.5 | 58% | 445 | 776 | 174% |
| Mine | support | 0.5 | 82% | 2 | 0 | 0% |
| Opponent | advance | 12.8 | 13% | 188 | 297 | 158% |
| Opponent | charge | 4.0 | 54% | 360 | 459 | 127% |
| Opponent | close in | 6.2 | 23% | 336 | 138 | 41% |
| Opponent | hold | 5.7 | 35% | 400 | 0 | 0% |
| Opponent | join | 0.7 | 96% | 41 | 0 | 0% |
| Opponent | shoot | 3.5 | 64% | 100 | 266 | 265% |
| Opponent | support | 7.6 | 90% | 39 | 0 | 0% |

### Packages: hunt the guns, t10-mine-ba3e30a-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 199 | 166 | 100% | 19 |
| Opponent | 0.1 | 4 | 0 | 25% | 25% | 0% | 2.0 | 284 | 44 | 25% | 113 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 93 |
| Empire of Man | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 199 | 166 | 100% | 63 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 159 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 171 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 33% | 33% | 0% | 2.0 | 307 | 59 | 33% | 50 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 214 | 0 | 0% | 40 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |

### Battle groups: t10-mine-ba3e30a-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 27% | 76% | 14% | 33% | 28% | 0% | 0% | 72% | 0% |
| Opponent | REDIRECT COUNTER | 4.2 | 26% | 74% | 13% | 40% | 9% | 3% | 6% | 82% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t10-mine-ba3e30a-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 157 (4) | 157 | 0 | 0 | 25% | 3.0 | 252 (3) | 0 (1) | - | 157 (4) | - |
| Mine | Chaff | 29 | 59 (29) | 8 | 51 | 48 | 34% | 2.4 | 83 (10) | 48 (15) | 42 (4) | 67 (25) | 0 (4) |
| Mine | Character | 105 | 40 (105) | 40 | 0 | 46 | 15% | 2.2 | 39 (37) | 38 (39) | 83 (10) | 47 (56) | 42 (30) |
| Mine | Clean-up | 29 | 54 (29) | 25 | 29 | 48 | 48% | 2.9 | 79 (10) | 56 (14) | 8 (5) | 76 (17) | 26 (12) |
| Mine | Early | 1 | 51 (1) | 51 | 0 | 100 | 0% | 4.0 | - | 51 (1) | - | - | 51 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 23 | 75% | 1.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 37 | 36 (37) | 16 | 20 | 33 | 19% | 2.6 | 10 (14) | 55 (16) | 56 (7) | 56 (17) | 20 (20) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Mine | Hammer | 62 | 35 (62) | 17 | 18 | 43 | 18% | 2.3 | 17 (22) | 48 (32) | 41 (8) | 46 (37) | 19 (25) |
| Mine | Holder | 28 | 77 (28) | 6 | 71 | 27 | 39% | 2.6 | 53 (9) | 117 (14) | 0 (5) | 137 (16) | 0 (12) |
| Mine | Shooter | 36 | 57 (36) | 25 | 32 | 54 | 3% | 1.5 | 40 (13) | 43 (15) | 110 (8) | 51 (24) | 74 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | War machine | 56 | 58 (56) | 58 | 0 | 42 | 4% | 1.3 | 51 (29) | 59 (21) | 90 (6) | 31 (10) | 63 (46) |
| Mine | Wizard | 16 | 21 (16) | 21 | 0 | 15 | 6% | 2.0 | 30 (5) | 5 (7) | 63 (2) | 12 (7) | 38 (7) |
| Opponent | Blocker | 1 | 283 (1) | 283 | 0 | 0 | 0% | 3.0 | 283 (1) | - | - | 283 (1) | - |
| Opponent | Chaff | 69 | 67 (69) | 11 | 56 | 52 | 45% | 3.0 | 56 (32) | 122 (15) | 41 (22) | 77 (49) | 48 (20) |
| Opponent | Character | 95 | 62 (95) | 62 | 0 | 27 | 21% | 2.2 | 45 (36) | 77 (36) | 84 (13) | 68 (49) | 63 (36) |
| Opponent | Clean-up | 15 | 41 (15) | 10 | 31 | 25 | 47% | 3.2 | 15 (6) | 83 (6) | 0 (3) | 34 (10) | 47 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 55 | 57 (55) | 34 | 23 | 42 | 24% | 2.9 | 73 (16) | 49 (30) | 59 (9) | 71 (31) | 40 (24) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 80 | 10% | 3.8 | 0 (1) | 0 (3) | 0 (2) | 0 (5) | 0 (1) |
| Opponent | Hammer | 62 | 33 (62) | 20 | 12 | 36 | 37% | 3.0 | 5 (21) | 58 (25) | 23 (16) | 14 (38) | 59 (24) |
| Opponent | Holder | 29 | 41 (29) | 13 | 29 | 21 | 62% | 4.1 | 8 (9) | 66 (17) | 0 (2) | 63 (14) | 24 (14) |
| Opponent | Shooter | 43 | 63 (43) | 27 | 37 | 41 | 14% | 1.4 | 70 (16) | 81 (19) | 0 (8) | 68 (25) | 57 (18) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (1) | - | 0 (1) | - | 0 (2) |
| Opponent | War machine | 6 | 100 (6) | 100 | 0 | 11 | 0% | 1.5 | 72 (3) | 141 (3) | - | 72 (3) | 141 (3) |
| Opponent | Wizard | 19 | 12 (19) | 12 | 0 | 11 | 11% | 2.1 | 20 (9) | 5 (6) | 0 (3) | 0 (9) | 22 (9) |

### Charged fights: t10-mine-ba3e30a-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 146 | 86 | 1.0 | 1.0 | 86 | 0 | +86 | 0 of 4 | 4 of 4 | - | +86 |
| Mine | Chaos Dwarfs | 4 | 254 | 220 | 2.0 | 1.0 | 110 | 0 | +110 | 0 of 8 | 6 of 8 | - | +110 |
| Mine | Dwarfen Mountain Holds | 3 | 449 | 157 | 1.0 | 1.0 | 157 | 0 | +157 | 2 of 3 | 2 of 3 | - | +157 |
| Mine | Empire of Man | 5 | 377 | 25 | 1.4 | 1.0 | 18 | 38 | -20 | 2 of 7 | 4 of 7 | - | -20 |
| Mine | Grand Cathay | 4 | 445 | 312 | 3.8 | 1.1 | 83 | 38 | +45 | 3 of 15 | 11 of 15 | +147 | +38 |
| Mine | High Elf Realms | 4 | 316 | 199 | 3.2 | 1.2 | 61 | 31 | +31 | 3 of 13 | 11 of 13 | -200 | +72 |
| Mine | Kingdom of Bretonnia | 1 | 210 | 1005 | 3.0 | 1.3 | 335 | 0 | +335 | 2 of 3 | 3 of 3 | +750 | +128 |
| Mine | Lizardmen | 1 | 55 | 316 | 7.0 | 1.0 | 45 | 121 | -76 | 4 of 7 | 4 of 7 | - | -76 |
| Mine | Ogre Kingdoms | 2 | 199 | 240 | 2.5 | 1.0 | 96 | 32 | +64 | 2 of 5 | 2 of 5 | - | +64 |
| Mine | Skaven | 2 | 310 | 20 | 1.0 | 1.0 | 20 | 0 | +20 | 1 of 2 | 1 of 2 | - | +20 |
| Mine | Tomb Kings of Khemri | 2 | 176 | 1099 | 6.0 | 1.1 | 183 | 84 | +99 | 4 of 12 | 9 of 12 | +0 | +108 |
| Mine | Vampire Counts | 2 | 58 | 286 | 5.0 | 1.2 | 57 | 19 | +38 | 4 of 10 | 5 of 10 | +283 | +11 |
| Mine | Warriors of Chaos | 1 | 0 | 253 | 3.0 | 1.0 | 84 | 57 | +28 | 0 of 3 | 2 of 3 | - | +28 |
| **Mine** | all armies | 35 | 275 | 249 | 2.6 | 1.1 | 95 | 39 | +55 | 27 of 92 | 64 of 92 | +130 | +50 |
| Opponent | Empire of Man | 1 | 641 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 174 | 506 | 3.8 | 1.3 | 133 | 0 | +133 | 7 of 19 | 15 of 19 | +248 | +92 |
| Opponent | Lizardmen | 2 | 0 | 100 | 1.5 | 1.3 | 67 | 0 | +67 | 1 of 3 | 2 of 3 | +135 | +32 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 679 | 4.0 | 1.0 | 170 | 9 | +161 | 2 of 12 | 8 of 12 | - | +161 |
| Opponent | Skaven | 4 | 118 | 95 | 0.5 | 1.0 | 190 | 70 | +120 | 2 of 2 | 1 of 2 | - | +120 |
| Opponent | Tomb Kings of Khemri | 2 | 30 | 1074 | 6.5 | 1.1 | 165 | 20 | +146 | 7 of 13 | 8 of 13 | +145 | +146 |
| Opponent | Vampire Counts | 6 | 28 | 285 | 3.8 | 1.2 | 74 | 21 | +54 | 15 of 23 | 19 of 23 | +190 | +16 |
| Opponent | Warriors of Chaos | 7 | 0 | 501 | 2.7 | 1.2 | 185 | 2 | +183 | 9 of 19 | 13 of 19 | +315 | +158 |
| Opponent | Wood Elf Realms | 5 | 213 | 579 | 4.4 | 1.4 | 132 | 1 | +130 | 11 of 22 | 15 of 22 | +208 | +108 |
| **Opponent** | all armies | 35 | 94 | 440 | 3.2 | 1.2 | 136 | 9 | +127 | 54 of 113 | 81 of 113 | +223 | +107 |

### Effective charges: t10-mine-ba3e30a-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 2 (net +123) | 0 | 1 (net +98) | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 8 | 0 | 0 | 1 (net +282) | 1 (net +109) | 3 (net +66) | 3 (net +97) | 0 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +470) | 0 | 0 | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 7 | 1 (net +0) | 0 | 2 (net -132) | 0 | 0 | 3 (net +42) | 1 | 33% (2 of 6) |
| Mine | Grand Cathay | 15 | 2 (net -5) | 0 | 1 (net +27) | 1 (net -101) | 5 (net +62) | 3 (net +81) | 3 | 8% (1 of 12) |
| Mine | High Elf Realms | 13 | 1 (net +0) | 0 | 1 (net -400) | 3 (net +87) | 4 (net +25) | 3 (net +146) | 1 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +750) | 2 | 0% (0 of 1) |
| Mine | Lizardmen | 7 | 2 (net -91) | 1 (net +0) | 2 (net +0) | 1 (net -405) | 0 | 0 | 1 | 33% (2 of 6) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 2 (net +182) | 1 (net +24) | 0 | 0 | 2 | 67% (2 of 3) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 1 (net +41) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 12 | 1 (net +663) | 0 | 5 (net -17) | 3 (net +78) | 2 (net +60) | 1 (net +251) | 0 | 42% (5 of 12) |
| Mine | Vampire Counts | 10 | 4 (net -11) | 2 (net +142) | 0 | 2 (net +70) | 2 (net +0) | 0 | 0 | 0% (0 of 10) |
| Mine | Warriors of Chaos | 3 | 1 (net -170) | 0 | 0 | 0 | 1 (net +80) | 1 (net +173) | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 19 | 1 (net +238) | 0 | 4 (net +292) | 5 (net +111) | 1 (net +0) | 5 (net +82) | 3 | 25% (4 of 16) |
| Opponent | Orc & Goblin Tribes | 12 | 0 | 0 | 0 | 0 | 0 | 1 (net +304) | 11 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 1 (net +379) | 0 | 0 | 0 | 0 | 1 (net -140) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 13 | 2 (net +268) | 1 (net -60) | 1 (net +92) | 3 (net +75) | 2 (net +136) | 2 (net +270) | 2 | 9% (1 of 11) |
| Opponent | Vampire Counts | 23 | 3 (net +99) | 2 (net +68) | 4 (net +75) | 5 (net +49) | 3 (net +30) | 5 (net +33) | 1 | 18% (4 of 22) |
| Opponent | Warriors of Chaos | 19 | 5 (net +272) | 0 | 3 (net +142) | 4 (net +124) | 2 (net +230) | 2 (net +210) | 3 | 19% (3 of 16) |
| Opponent | Wood Elf Realms | 22 | 5 (net +199) | 1 (net +0) | 3 (net +130) | 7 (net +75) | 3 (net +165) | 2 (net +234) | 1 | 14% (3 of 21) |

### Charged fights, damage counted: t10-mine-ba3e30a-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 185 | 340 | +18 | 93 | 86 | +7 | +3.9 |
| Mine | 50-54% | 4 | 282 | 255 | +71 | 108 | 80 | +28 | +9.9 |
| Mine | Effective (55-75%) | 14 | 300 | 200 | -5 | 148 | 136 | +12 | +3.9 |
| Mine | 76-89% | 16 | 243 | 156 | +64 | 138 | 67 | +70 | +29.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 312 | 192 | +148 | 154 | 17 | +137 | +43.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 17 | 426 | 87 | +48 | 65 | 10 | +56 | +13.0 |
| Mine | No odds | 11 | 210 | 159 | +40 | 60 | 10 | +49 | +23.6 |
| Mine | All fights | 92 | 286 | 189 | +55 | 111 | 55 | +56 | +19.7 |
| Opponent | Long shot (under 50%) | 17 | 309 | 285 | +224 | 239 | 24 | +215 | +69.4 |
| Opponent | 50-54% | 4 | 394 | 336 | +19 | 177 | 132 | +44 | +11.3 |
| Opponent | Effective (55-75%) | 15 | 430 | 219 | +158 | 192 | 51 | +140 | +32.7 |
| Opponent | 76-89% | 24 | 410 | 205 | +85 | 112 | 45 | +67 | +16.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 313 | 237 | +121 | 150 | 9 | +141 | +45.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 470 | 102 | +120 | 140 | 17 | +124 | +26.3 |
| Opponent | No odds | 24 | 259 | 133 | +108 | 122 | 17 | +105 | +40.6 |
| Opponent | All fights | 113 | 355 | 203 | +127 | 155 | 31 | +124 | +34.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t10-mine-ba3e30a-p4 | move | 310 | 88 (28%) | 56 (18%) | 48 (15%) | 174 (56%) |
| t10-mine-ba3e30a-p4 | objective | 219 | 34 (16%) | 20 (9%) | 30 (14%) | 155 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

# Doctrine scorecard: t10-mine-ba3e30a-p3

### Scorecard: t10-mine-ba3e30a-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 10 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 2 | 0 | 0 | 60 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 8 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 3 | 1 | 5 | 1 | 0 | 0 | 30 |
| L0226 | 4 | 1 | Opponent | no | 12 | 2 | 0 | 2 | 0 | 0 | 0 | 60 |
| L0311 | 5 | 1 | Mine | no | - | - | 1 | 3 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 4 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 16 | 2 | 0 | 0 | 0 | 0 | 0 | 230 |
| L0327 | 3 | 1 | Opponent | no | 1 | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 6 | 2 | 0 | 1 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | no | 2 | 4 | 3 | 0 | 0 | 0 | 0 | 310 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 350 |
| L0516 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 160 |
| L0533 | 5 | 1 | Opponent | no | - | - | 0 | 6 | 0 | 0 | 0 | 271 |
| L0620 | 2 | 1 | Mine | - | - | 5 | 2 | 1 | 0 | 0 | 0 | 609 |
| L0620 | 2 | 1 | Opponent | - | - | 6 | 1 | 5 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Mine | yes | 17 | 2 | 8 | 0 | 0 | 0 | 0 | 250 |
| L0709 | 1 | 1 | Opponent | yes | 1 | 5 | 0 | 0 | 0 | 0 | 0 | 953 |
| L0725 | 5 | 1 | Mine | no | - | 2 | 3 | 2 | 0 | 0 | 0 | 452 |
| L0725 | 5 | 1 | Opponent | yes | - | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 491 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 379 |
| L0831 | 3 | 1 | Opponent | yes | 5 | 6 | 1 | 3 | 1 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 486 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 250 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 135 |
| L1013 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 1 | 0 | 0 | 479 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 165 |
| L1030 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 1 | 0 | 0 | 70 |
| L1122 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1122 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 7 | 3 | 7 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 475 |
| L1232 | 2 | 1 | Mine | - | - | 4 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 2 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 1 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 3 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 115 |
| L1519 | 1 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 1 | 2 | 2 | 0 | 0 | 0 | 125 |
| L1633 | 1 | 1 | Mine | yes | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 207 |
| L1633 | 1 | 1 | Opponent | no | 2 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 7 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 1 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 9 | 5 | 2 | 1 | 1 | 0 | 0 | 34 |
| L1831 | 1 | 1 | Opponent | no | 3 | 3 | 4 | 2 | 2 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 1 | 0 | 2 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 8 | 2 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 65 |
| L2033 | 5 | 1 | Opponent | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 405 |
| L2223 | 3 | 1 | Mine | no | 1 | 1 | 6 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | no | - | 2 | 8 | 0 | 0 | 0 | 0 | 136 |
| L2327 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 8 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 8 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 23% | 4.2 | 2.7 | 2.6 | 1.2 | 0.2 | 0.0 | 0.0 | 172.2 |
| **Average** | | | Opponent | 23% | 2.3 | 2.6 | 3.2 | 1.7 | 0.4 | 0.0 | 0.0 | 191.2 |

### KPIs: t10-mine-ba3e30a-p3

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 34 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (39 of 157) | 6% (10 of 162) | 15% (49 of 319) |
| Winner chose to follow up after the loser gave ground |  | 84% (62 of 74); on the table 88% | 97% (36 of 37); on the table 97% | 88% (98 of 111); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (6 of 9); on the table 78% | 82% (9 of 11); on the table 82% | 75% (15 of 20); on the table 80% |
| Winner chose to pursue after the loser fled |  | 58% (11 of 19); on the table 68% | 70% (16 of 23); on the table 70% | 64% (27 of 42); on the table 69% |
| Winner chose to follow up or pursue (all three) |  | 77% (79 of 102); on the table 83% | 86% (61 of 71); on the table 86% | 81% (140 of 173); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 34% (112 of 330) | 33% (62 of 186) | 34% (174 of 516) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (112 of 233) | 44% (62 of 140) | 47% (174 of 373) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 52% (11 of 21) | 52% (23 of 44) | 52% (34 of 65) |
| Points that never fought | lower | 41% (26946 of 65320) | 39% (26458 of 67991) | 40% (53404 of 133311) |
|   infantry points that never fought | lower | 43% (6061 of 13938) | 51% (6943 of 13489) | 47% (13004 of 27427) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (138 of 255) | 64% (170 of 267) | 59% (308 of 522) |
| Bound items with a magic missile used (at least once a game) |  | 92% (22 of 24); 2.0 uses a game | 95% (21 of 22); 1.9 uses a game | 93% (43 of 46); 2.0 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 0.3 uses a game | 33% (2 of 6); 0.1 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.4 uses a game | 38% (5 of 13); 0.1 uses a game | 52% (17 of 33); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (27353 of 55951) | 57% (34294 of 60205) | 53% (61647 of 116156) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (22%) | 1.1 (29%) | 2.5 (25%) |
| MARCHED: its unit marched | 1.7 (27%) | 0.8 (21%) | 2.5 (25%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.3 (9%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.6 (26%) | 0.9 (24%) | 2.5 (25%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.4 (6%) | 0.1 (3%) | 0.5 (5%) |
| GONE: slain | 0.8 (12%) | 0.3 (9%) | 1.1 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.1 | 1.2 | 2.3 | 5.1 | 1.0 | 2.1 |
| not cast | 3.8 | 1.3 | 4.0 | 10.1 | 2.3 | 19.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (52%) | 0.2 (6%) | 2.5 (25%) | 0.3 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (25%) | 0.5 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.1 (11%) | 0.6 (16%) | 2.5 (25%) | 0.5 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.4 (9%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (11%) | 0.3 (8%) | 0.5 (5%) | 0.2 (8%) | 0.8 (4%) |
| GONE: slain | 1.0 (27%) | 0.1 (7%) | 0.7 (18%) | 1.1 (11%) | 0.0 (1%) | 2.3 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (5%) | 0.0 (1%) | 0.1 (1%) | 0.0 (1%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.7 (32%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (59%) | 0.2 (14%) | 1.6 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.1 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 1.2 a game | 1.2 a game |
| stood (cast and not dispelled) | 59% (20 of 34) | 61% (20 of 33) | 60% (40 of 67) |
| the unit moved after it | 65% (13 of 20) | 90% (18 of 20) | 78% (31 of 40) |
| it charged on its next turn | 0% (0 of 20) | 5% (1 of 20) | 2% (1 of 40) |
| the enemy charged it first | 15% (3 of 20) | 10% (2 of 20) | 12% (5 of 40) |
| it fought by the end of its next turn | 15% (3 of 20) | 5% (1 of 20) | 10% (4 of 40) |
| it moved out of a charge the enemy had planned (not charged first) | 30% (6 of 20) | 15% (3 of 20) | 22% (9 of 40) |
| none of these (no charge, no fight, no charge escaped) | 55% (11 of 20) | 70% (14 of 20) | 62% (25 of 40) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (495 of 758) | 57% (334 of 587) | 62% (829 of 1345) |
|   cavalry | 59% (36 of 61) | 73% (77 of 105) | 68% (113 of 166) |
|   character | 49% (47 of 96) | 25% (29 of 117) | 36% (76 of 213) |
|   chariot | 79% (75 of 95) | 73% (19 of 26) | 78% (94 of 121) |
|   infantry | 62% (124 of 199) | 58% (150 of 258) | 60% (274 of 457) |
|   monster | 42% (16 of 38) | 100% (2 of 2) | 45% (18 of 40) |
|   war machine | 73% (197 of 269) | 72% (57 of 79) | 73% (254 of 348) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (22%) | 1.4 (19%) | 3.1 (21%) |
| CHARGED: it charged | 0.8 (10%) | 1.6 (21%) | 2.4 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.4 (5%) | 0.7 (9%) | 1.1 (7%) |
| MOVED: a war machine that moved | 1.3 (17%) | 0.1 (1%) | 1.4 (9%) |
| NO TARGET IN RANGE | 1.8 (23%) | 1.3 (17%) | 3.0 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.7 (9%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.9 (11%) | 1.3 (17%) | 2.1 (14%) |
| SHELTERED: the target was sheltered | 0.4 (5%) | 0.2 (3%) | 0.6 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.1 (2%) | 0.1 (2%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 1.0 | 84% | 5.0 pts | 28 pts |
| character | 2.8 | 1.1 | 77% | 6.9 pts | 19 pts |
| chariot | 2.8 | 1.6 | 68% | 19.5 pts | 54 pts |
| infantry | 12.3 | 4.6 | 72% | 9.0 pts | 110 pts |
| monster | 0.7 | 0.3 | 70% | 14.0 pts | 9 pts |
| war machine | 7.6 | 7.4 | 59% | 24.1 pts | 185 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.5 | 4.6 |
| Charges that made contact a game | 2.9 | 3.8 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.89 declared, 0.75 contact (28 units) | 0.83 declared, 0.44 contact (18 units) | 0.87 declared, 0.63 contact (46 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.67 contact (6 units) | 0.77 declared, 0.54 contact (13 units) | 0.79 declared, 0.58 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.33 contact (220 units) | 0.64 declared, 0.46 contact (250 units) | 0.54 declared, 0.40 contact (470 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (37 of 69) | 50% (7 of 14) | 75% (6 of 8) | 55% (50 of 91) |
| Character in a unit | 76% (28 of 37) | 62% (10 of 16) | 100% (2 of 2) | 73% (40 of 55) |
| Character on its own | 85% (28 of 33) | 41% (16 of 39) | 26% (18 of 68) | 44% (62 of 140) |
| Chariot | 73% (8 of 11) | 58% (7 of 12) | - | 65% (15 of 23) |
| Infantry | 59% (40 of 68) | 56% (22 of 39) | 80% (4 of 5) | 59% (66 of 112) |
| Monster | 73% (22 of 30) | 71% (5 of 7) | - | 73% (27 of 37) |
| Monstrous | 88% (7 of 8) | 64% (7 of 11) | - | 74% (14 of 19) |
| War Machines | 77% (33 of 43) | 50% (1 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 88% (7 of 8); on the table 88% | 34% (33 of 96) | 42% | 55% (12 of 22) | 100% (6 of 6); 5.0 uses a game | 50% (1 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 82% (9 of 11); on the table 91% | 50% (18 of 36) | 65% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 40% (2 of 5); on the table 60% | - | 74% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (4 of 5); on the table 80% | 40% (12 of 30) | 47% | 61% (36 of 59) | 0.0 uses a game | 50% (1 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 81% (21 of 26); on the table 85% | 30% (58 of 192) | 40% | 47% (35 of 74) | 94% (17 of 18); 6.1 uses a game | 25% (1 of 4); 0.1 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 81% (13 of 16); on the table 94% | 24% (10 of 42) | 40% | 54% (29 of 54) | 89% (8 of 9); 4.1 uses a game | 33% (4 of 12); 0.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 82% (9 of 11); on the table 82% | - | 35% | 39% (7 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | 83% (5 of 6) | 25% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 50% (3 of 6) | 17% | 57% (4 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (4 of 4); on the table 100% | 33% (4 of 12) | 9% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 88% (7 of 8); on the table 88% | 8% (1 of 12) | 45% | 43% (6 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 73% (11 of 15); on the table 73% | 17% (1 of 6) | 28% | 50% (13 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 87% (27 of 31); on the table 90% | 35% (19 of 54) | 32% | 63% (29 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 75% (18 of 24); on the table 75% | 56% (10 of 18) | 39% | 62% (44 of 71) | 100% (3 of 3); 1.1 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 5 | 80% (4 of 5); on the table 80% | 0% (0 of 6) | 39% | 83% (43 of 52) | 100% (9 of 9); 5.2 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t10-mine-ba3e30a-p3, 34 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 58% (40) | 47% (30) | 53% (70) |
| ...free all their last turn and able to turn (per game) | 0.71 | 0.41 | 1.12 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.15 | 0.21 | 0.35 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.29 | 0.79 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 1.21 | 1.21 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.26 | 0.26 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.12 | 5.94 | 6.06 |

### Quality by phase: t10-mine-ba3e30a-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 63% (81 of 128) | 39% (65 of 165) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (166 of 374) | 39% (71 of 184) |
| Strategy | Close-in objectives charged next turn | - | 15% (35 of 230) |
| Strategy | Support requests answered (helper made contact too) | 50% (8 of 16) | 40% (12 of 30) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (4 of 12) | 92% (11 of 12) |
| Strategy | Joined characters whose unit fought | 40% (20 of 50) | 49% (17 of 35) |
| Strategy | Lone characters that fought | 76% (59 of 78) | 75% (70 of 93) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 172.2 | 191.2 |
| Movement | Fights charged into per game | 2.8 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 87, net +35 | 19 of 81, net +84 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 87, net +139 | 20 of 81, net +82 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 87, net +111 | 7 of 81, net +108 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 of 87, net +117 | 19 of 81, net +119 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.4 | 9.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (130 of 321) | 49% (164 of 335) |
| Shooting | Points destroyed by shooting units | 63.8 | 35.5 |
| Shooting | War machine shots | 5.8 | 1.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (87 of 197) | 49% (31 of 63) |
| Shooting | Points destroyed by war machines | 78.7 | 16.7 |
| Magic | Magic missiles cast | 2.1 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (27 of 70) | 40% (18 of 45) |
| Magic | Wounds caused by magic missiles | 3.4 | 2.6 |
| Magic | Wounds caused by other spells | 1.6 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 123.7 | 35.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.4 / 0.7 / 0.3 | 1.8 / 0.4 / 0.3 / 0.6 |
| Combat | Points destroyed in combat | 334.1 | 336.8 |
| Combat | Points run down | 125.5 | 96.7 |
| Combat | Net points per charged fight, damage counted | +89 | +92 |
| Combat | Net per 100 charger points, damage counted | +32.6 | +31.6 |
| Combat | First round won (charged fights) | 79% | 68% |
| Combat | Net points per charged fight | +96 | +88 |
| Combat | Net points per supported fight / lone fight | +114 / +94 | +73 / +90 |
| Combat | Charged fights on a top-3 enemy unit | 31 of 95 | 51 of 108 |
| Game | Points lost | 653.9 | 758.8 |
| Game | VP from objectives | 617.6 | 605.0 |
| Game | Lone holders (player turns) | 4.2 | 2.3 |

- Mine won / drew / lost: 15 / 6 / 13 of 34 ended games (of 34); mean margin (Mine - Opponent) +102 VP
- The side that went first won 16 of 28 games with a winner
- Points traded per game (both sides' losses): 1413
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: t10-mine-ba3e30a-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 3.4 |
| ADVANCE WORTH | - | - | - | - | 3.7 | -152.7 | 90.6 | 89.5 |
| AFTERMATH IN POINTS | 0.3 | +43.6 | 0.0 | 15.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.2 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 10.0 | +103.8 | 0.0 | 185.4 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 2.1 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 32.9 | 0.2 | +0.0 | 0.0 | 4.9 |
| BACKUP TARGETS | 0.3 | +0.9 | 0.0 | 9.4 | 0.8 | +4.6 | 0.0 | 17.2 |
| BEST FACING | - | - | - | - | 0.2 | +6.1 | 0.0 | 0.0 |
| BEST FIRST | - | - | - | - | 1.1 | +58.1 | 38.7 | 35.2 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.6 | +37.2 | 0.0 | 15.7 |
| BEST OVERALL | - | - | - | - | 0.1 | +1.7 | 0.0 | 0.0 |
| BEST PREY | - | - | - | - | 0.6 | +11.6 | 7.0 | 5.0 |
| BEST PRIZE | 0.1 | -3.3 | 0.0 | 5.4 | 0.1 | -6.6 | 17.9 | 15.9 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.1 | -0.4 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 5.7 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.4 | +18.3 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.4 | -27.7 | 21.5 | 5.7 | 0.4 | -29.5 | 27.9 | 11.5 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.4 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 96.9 | 15.0 | 0.2 | +0.0 | 13.9 | 2.9 |
| CANNON PLANNED TARGET | 5.8 | +127.6 | 388.4 | 99.7 | 1.3 | +53.2 | 36.5 | 43.2 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 2.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.5 | 7.9 | 11.1 | 0.2 | +0.0 | 0.0 | 8.6 |
| CAST JOB | 0.7 | +25.4 | 72.6 | 11.2 | 0.7 | +14.4 | 22.7 | 11.6 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +27.2 | 17.9 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 20.5 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.4 | +24.9 | 0.0 | 3.7 | 1.4 | +55.1 | 0.0 | 27.9 |
| CHAFF PASSED | 0.2 | -0.5 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 5.9 |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 7.6 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.1 | +14.8 | 0.0 | 5.7 | - | - | - | - |
| CHARGE LOSSES | 5.3 | -258.3 | 0.0 | 135.9 | - | - | - | - |
| CHARGE NOT DECLARED | 0.0 | +0.0 | 0.9 | 1.8 | 0.7 | +0.0 | 53.2 | 5.2 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 240.9 | 81.0 | 2.7 | +0.0 | 255.8 | 99.2 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.4 | -20.6 | 0.0 | 25.0 |
| CHARGER SLAIN LOST | 0.4 | -18.1 | 91.7 | 7.8 | 0.8 | -21.9 | 88.9 | 10.0 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -1.2 | 0.0 | 11.8 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 4.4 | 1.3 |
| COMBAT PIVOT | 0.6 | +0.0 | 24.7 | 52.6 | 0.2 | +0.0 | 29.0 | 29.7 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.8 | +97.0 | 20.1 | 45.3 | 0.6 | +43.7 | 30.4 | 46.5 |
| COVER ONCE | 7.7 | -592.9 | 0.0 | 184.6 | 6.1 | -422.3 | 0.0 | 158.6 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 4.2 | 2.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +1.2 | 2.5 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.9 | +18.1 | 0.0 | 18.1 | 7.4 | +40.6 | 0.0 | 11.7 |
| EDGE GIVE GROUND | 0.2 | +8.2 | 32.2 | 31.4 | 0.1 | +0.6 | 11.7 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 1.2 | +80.9 | 0.0 | 23.6 |
| FALL BACK GOOD ORDER | 2.8 | +6.1 | 287.4 | 105.0 | - | - | - | - |
| FALLBACK BY WORTH | 0.1 | +1.0 | 0.0 | 2.4 | 5.5 | +53.6 | 0.0 | 27.1 |
| FALLS SHORT | 5.4 | +84.8 | 0.0 | 105.0 | - | - | - | - |
| FEATURE BUFFS | 1.1 | +29.9 | 0.0 | 33.4 | - | - | - | - |
| FIGHT LIFT | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +0.1 | 1.8 | 0.0 |
| FIGHT TO THE END | 1.6 | +61.2 | 179.1 | 84.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.5 | 3.1 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.2 | +0.0 | 5.6 | 12.4 | 0.2 | +0.0 | 7.4 | 0.0 |
| FIVE ACTION | 44.9 | +2782.2 | 1176.9 | 800.6 | - | - | - | - |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 193.1 | 5.3 | +0.0 | 0.0 | 126.1 |
| FOCUS FIRE | 0.1 | +5.0 | 9.4 | 0.0 | 0.0 | +1.0 | 3.6 | 0.0 |
| FOLLOW UP WEIGHED | 1.2 | +279.2 | 0.0 | 40.4 | 1.1 | +189.9 | 0.0 | 51.6 |
| FOUR ROUNDS | 3.8 | +384.0 | 394.5 | 126.8 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.1 | -16.7 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -3.0 | 0.0 | 10.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +1.0 | 0.0 | 18.3 | 0.0 | +1.5 | 0.0 | 0.0 |
| GATEWAY ESCAPE | - | - | - | - | 0.0 | +2.1 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -9.5 | 23.1 | 23.3 | 0.1 | -3.1 | 10.3 | 0.0 |
| GROUND FLIERS | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.3 | +29.7 | 65.2 | 20.0 | 0.3 | +7.1 | 11.2 | 0.0 |
| GUN MASK | 0.8 | +17.4 | 0.0 | 27.2 | - | - | - | - |
| HARD STAY DROPPED | 1.9 | +0.0 | 0.0 | 14.9 | - | - | - | - |
| HE SHOOTS OR CHARGES | 1.1 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 18.6 | 2.1 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 18.8 | 2.4 |
| HILL BY ITS CHANCE | - | - | - | - | 0.5 | -50.2 | 0.0 | 6.1 |
| HIS CHARGE DENIED | 0.6 | +26.1 | 92.7 | 13.5 | - | - | - | - |
| HIS CHARGE LIST | 2.9 | +0.0 | 0.0 | 55.3 | - | - | - | - |
| HIS FIGHT TOGETHER | 1.2 | -12.6 | 0.0 | 71.2 | - | - | - | - |
| HIS LEGAL MOVES | 3.1 | +0.0 | 0.0 | 78.9 | - | - | - | - |
| HIS MOVE AND SHOT | 1.2 | -19.8 | 0.0 | 54.9 | - | - | - | - |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 28.9 | - | - | - | - |
| HIS RANDOM MOVE | 2.9 | +0.0 | 0.0 | 98.9 | - | - | - | - |
| HIS SHOT LIST | 16.4 | +623.3 | 0.0 | 274.2 | - | - | - | - |
| HIS TURN DENIED | 1.5 | +54.2 | 118.1 | 59.1 | - | - | - | - |
| HOLDER ASSIGNMENT | 10.5 | +1005.8 | 0.0 | 145.8 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 0.9 | +140.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.2 | -112.0 | 270.0 | 113.0 | 9.2 | -229.0 | 436.4 | 214.1 |
| HORN WORTH | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +8.0 | 3.7 | 3.4 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 2.1 |
| HUNT IN PAIRS | 0.5 | +8.2 | 0.0 | 20.8 | 0.6 | +52.3 | 0.0 | 14.7 |
| HUNT RESULT | - | - | - | - | 0.1 | +14.7 | 0.0 | 2.1 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +47.6 | 3.7 | 3.4 |
| IDLE COST | 2.9 | -42.2 | 0.0 | 60.8 | 18.8 | -335.5 | 0.0 | 218.4 |
| INVITES THE FIGHT | - | - | - | - | 1.0 | +6.8 | 29.3 | 28.6 |
| JOINT CHARGE NOW | 0.9 | +52.8 | 112.0 | 17.6 | - | - | - | - |
| JOINT CHARGE PLAN | - | - | - | - | 0.2 | +0.5 | 0.0 | 2.1 |
| JOINT KNOWS CHALLENGE | 0.0 | -2.4 | 0.0 | 0.0 | 0.1 | -1.2 | 6.3 | 1.8 |
| JOINT ON THE TABLE | 0.0 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.1 | 1.2 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.5 | +74.1 | 168.9 | 48.5 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 1.9 | +98.4 | 166.8 | 53.3 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.0 | +223.1 | 151.6 | 181.7 |
| LANE BY FIGURES | 0.9 | +30.2 | 0.0 | 11.2 | 1.0 | +48.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.4 | +0.0 | 372.9 | 412.5 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.0 | +0.2 | 0.0 | 0.0 | 0.4 | +12.9 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.4 | +0.0 | 9.8 | 20.6 |
| LONE WIZARD KEPT IN | 0.6 | +39.5 | 0.0 | 0.0 | 0.4 | +26.9 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +1.7 | 3.2 | 3.9 | 0.3 | -0.8 | 10.2 | 1.8 |
| LOST CHARGE | 0.0 | -0.0 | 2.1 | 0.0 | 2.2 | -37.1 | 46.1 | 83.9 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -14.5 | 0.0 | 1.2 |
| MAKE SURE TOGETHER | 0.2 | +5.4 | 0.0 | 0.0 | 0.9 | +42.0 | 10.9 | 33.6 |
| MANOEUVRE | 1.1 | +13.0 | 0.0 | 5.2 | 0.1 | +3.3 | 0.0 | 7.7 |
| MARCH AT ESCAPER | 0.2 | +2.3 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +28.5 | 0.0 | 11.6 | - | - | - | - |
| MARCH CHECK | 0.7 | +33.1 | 0.0 | 11.6 | 0.5 | +11.6 | 0.0 | 0.0 |
| MARCH ODDS | 0.0 | +0.2 | 0.0 | 0.0 | 0.3 | +19.1 | 19.6 | 14.9 |
| MARCH OVER CASTS | 0.9 | +83.4 | 0.0 | 11.6 | 0.5 | +34.2 | 0.0 | 3.4 |
| MAX FOR POSITIONING | 5.7 | +74.2 | 0.0 | 122.7 | 7.5 | +104.3 | 0.0 | 160.4 |
| MISSILES IN THE MOVE | 4.6 | +183.0 | 0.0 | 75.5 | 4.3 | +73.7 | 0.0 | 85.3 |
| MISSILES NEXT TURN | 6.0 | +116.2 | 0.0 | 101.3 | 5.1 | +50.0 | 0.0 | 97.7 |
| MODEL FACING | 0.2 | +29.9 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 9.1 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.4 | +9.6 | 0.0 | 0.0 |
| MOVE ORDER | 1.2 | +0.0 | 23.1 | 30.1 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.2 | +6.7 | 0.0 | 22.4 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.2 | -15.4 | 0.0 | 11.2 | 0.4 | -14.0 | 0.0 | 21.8 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 5.3 | +363.3 | 74.9 | 119.7 |
| MOVE TO CHARGE COMPUTED | 3.7 | +481.5 | 0.0 | 74.6 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.8 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.4 | +183.1 | 0.0 | 66.9 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.0 | +2.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.9 | -164.8 | 12.6 | 90.9 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 5.3 | -173.7 | 25.1 | 101.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.8 | -131.8 | 279.0 | 70.7 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +0.4 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| NOT NEEDED | - | - | - | - | 0.4 | -12.0 | 31.8 | 9.5 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 5.9 | +120.7 | 0.0 | 152.0 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 22.9 | 0.6 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -18.9 | 0.0 | 12.0 | 17.4 | -925.3 | 19.5 | 259.9 |
| ONE CHARGE A CHARGER | 2.8 | +0.0 | 0.0 | 75.7 | - | - | - | - |
| ONE FIGHT FORMULA | 5.5 | -124.8 | 0.0 | 109.5 | 8.1 | -178.7 | 23.5 | 239.7 |
| ONE OBJECTIVE FORMULA | 3.4 | +33.2 | 0.0 | 74.6 | 2.5 | -144.4 | 0.0 | 22.9 |
| ONE TARGET A SHOOTER | 12.9 | +244.7 | 0.0 | 260.2 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +0.2 | 3.7 | 2.9 |
| OPENS UP | 0.1 | +9.3 | 8.9 | 17.5 | 0.2 | +16.9 | 12.2 | 0.0 |
| OVERRUNS AWAY | 0.8 | +51.5 | 67.0 | 36.1 | 0.4 | +4.0 | 15.9 | 21.9 |
| PATHS CROSS | 2.0 | +61.9 | 0.0 | 31.7 | 2.5 | +201.9 | 0.0 | 16.1 |
| PERIAPT WORTH | 0.0 | +1.7 | 0.0 | 0.0 | 0.0 | +1.7 | 0.0 | 15.9 |
| PIVOT GUARDS FLANK | 0.0 | -0.4 | 0.0 | 0.0 | 0.1 | -2.3 | 0.0 | 16.6 |
| PLAN RESULT | 39.4 | +853.3 | 541.6 | 963.0 | 38.2 | +1040.3 | 1255.4 | 1007.0 |
| PURSUES BIG PREY | 0.1 | -1.5 | 0.0 | 0.0 | 0.1 | -10.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +3.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +7.7 | 0.0 | 5.0 | 1.3 | +19.9 | 0.0 | 56.2 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.3 | -15.6 | 1.2 | 15.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.3 | 0.0 | 0.0 | 1.0 | -36.5 | 0.0 | 22.1 |
| REDIRECT COUNTER | 1.7 | +83.9 | 0.0 | 39.5 | 4.3 | +408.4 | 0.0 | 66.6 |
| REDIRECT WEIGHED | 0.2 | +4.9 | 0.0 | 13.2 | 0.4 | +10.8 | 9.6 | 12.6 |
| REFORMS TO MEET IT | 0.7 | -37.1 | 0.0 | 26.6 | - | - | - | - |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 23.7 | 0.3 | +0.0 | 0.0 | 10.9 |
| RESERVE FALL BACK | 0.5 | +15.9 | 0.0 | 10.9 | 0.9 | +30.6 | 0.0 | 29.7 |
| RESTRAINS TO SHOOT | 0.1 | +1.3 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.9 | +55.2 | 261.9 | 126.8 | 2.6 | +69.9 | 259.7 | 86.3 |
| RISK BY HIS FIGURE | 12.9 | -210.1 | 0.0 | 324.3 | - | - | - | - |
| RISK ONCE | - | - | - | - | 3.9 | +118.6 | 43.7 | 259.4 |
| RUN DOWN | 2.3 | -40.0 | 255.4 | 57.1 | - | - | - | - |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.2 | 5.7 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +11.1 | 0.0 | 11.9 |
| SAME CHARGE LATER | 0.1 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 1.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 1.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.6 | 0.0 | 2.4 | 0.6 | -35.2 | 0.0 | 6.4 |
| SEARCH SPOT | 5.3 | +240.9 | 0.0 | 71.8 | 3.1 | +114.8 | 0.0 | 26.5 |
| SELF MOVE SPELL | 0.5 | +33.8 | 0.0 | 19.2 | 0.4 | +60.6 | 0.0 | 19.2 |
| SET UP BY THE SET | 0.7 | -10.1 | 0.0 | 12.3 | - | - | - | - |
| SET UP TOGETHER | 0.2 | +5.5 | 0.0 | 0.0 | 1.6 | +88.8 | 10.9 | 51.5 |
| SET-UP ANY TARGET | 0.1 | +15.7 | 0.0 | 0.0 | 0.2 | +37.5 | 15.5 | 23.5 |
| SET-UP MISSED | 0.0 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.6 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +53.9 | 74.1 | 11.8 | 1.0 | +30.9 | 21.0 | 16.2 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.5 | -34.1 | 122.4 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 8.3 | +55.4 | 0.0 | 138.2 | - | - | - | - |
| SHOTS IN THE MOVE | 16.1 | +682.8 | 0.0 | 340.2 | 9.2 | +300.2 | 0.0 | 203.2 |
| SPELL SETS UP CHARGE | 0.1 | +36.9 | 0.0 | 11.8 | 0.2 | +37.5 | 15.5 | 23.5 |
| SPELL WORTH | 1.5 | +32.3 | 67.3 | 75.4 | 2.3 | +35.7 | 113.6 | 111.9 |
| SPELLS IN THE FIGHT | 0.6 | -5.0 | 101.9 | 28.9 | 0.8 | -22.7 | 89.2 | 39.4 |
| STABLE ROLE | - | - | - | - | 9.0 | +0.0 | 287.7 | 211.4 |
| STAND AND SHOOT | 0.6 | -7.0 | 43.1 | 32.2 | - | - | - | - |
| STANDS FOR A REASON | 0.2 | +0.0 | 2.1 | 2.4 | - | - | - | - |
| STANDS STILL | 17.9 | +0.0 | 782.4 | 267.3 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| STAY WORTH | 18.1 | +59.9 | 428.6 | 258.2 | 9.6 | +72.3 | 149.8 | 121.4 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.2 | +7.5 | 0.0 | 19.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.5 | +0.0 | 154.4 | 64.9 | 6.6 | -58.0 | 365.1 | 119.3 |
| SUPPORTS | - | - | - | - | 4.8 | +59.1 | 220.2 | 52.6 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -6.1 | 5.6 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +1.2 | 0.0 | 0.0 | 0.9 | +0.2 | 0.0 | 11.3 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 36.2 | - | - | - | - |
| THE PROMISE ADDS | 0.1 | -10.7 | 5.1 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 1.2 | +0.0 | 0.0 | 15.2 | - | - | - | - |
| THROUGH LINE OF FIRE | - | - | - | - | 0.2 | +7.1 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.9 | +76.1 | 76.2 | 28.3 | - | - | - | - |
| TIME ON OUR SIDE | 23.6 | +358.8 | 25.8 | 334.4 | - | - | - | - |
| TURN WORTH | - | - | - | - | 0.3 | -16.3 | 21.4 | 8.2 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.4 | +1.8 | 10.9 | 12.3 |
| WAIT AFTER COSTS | - | - | - | - | 7.7 | -387.9 | 153.4 | 177.6 |
| WAITS AGAIN | 1.4 | +0.0 | 0.0 | 23.1 | - | - | - | - |
| WALKS TO THE FIGHT | - | - | - | - | 0.9 | +5.9 | 19.6 | 11.4 |
| WAR ENGINE JOBS | 0.1 | +0.0 | 3.4 | 5.4 | 0.1 | +0.0 | 9.6 | 4.0 |
| WEARS DOWN | - | - | - | - | 1.2 | +43.1 | 125.8 | 55.9 |
| WHO HITS BACK | 0.5 | +60.0 | 0.0 | 12.8 | 0.1 | +12.2 | 0.0 | 13.9 |
| WHOLE FIGHT | 0.3 | +21.3 | 63.1 | 11.8 | 0.5 | +9.7 | 86.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +2.6 | 5.7 | 0.0 | 0.9 | +71.3 | 84.7 | 32.5 |
| WIDER SPREAD | 2.7 | -12.7 | 292.8 | 92.8 | 3.0 | -5.7 | 339.3 | 61.8 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.4 | +24.8 | 0.0 | 11.6 | - | - | - | - |

### Rule changes: t10-mine-ba3e30a-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 616 | 616 | 616 | 18.12 | -32102 | -52.1 |
| DEPLOY BY FIGURES | 520 | 520 | 329 | 9.68 | +4682 | +14.2 |
| HOLDER ASSIGNMENT | 358 | 358 | 325 | 9.56 | +20457 | +62.9 |
| SEARCH SPOT | 286 | 286 | 280 | 8.24 | +12094 | +43.2 |
| ARMY TABLE | 339 | 339 | 253 | 7.44 | +3130 | +12.4 |
| LEGAL CHARGES ONLY | 218 | 218 | 218 | 6.41 | +0 | +0.0 |
| PATHS CROSS | 152 | 152 | 152 | 4.47 | +8970 | +59.0 |
| TIME ON OUR SIDE | 802 | 723 | 147 | 4.32 | +534 | +3.6 |
| FIVE ACTION | 1526 | 1514 | 138 | 4.06 | +6309 | +45.7 |
| HIS SHOT LIST | 557 | 550 | 126 | 3.71 | +2219 | +17.6 |
| MOVE TO CHARGE | 179 | 179 | 103 | 3.03 | +4571 | +44.4 |
| COVER ONCE | 468 | 325 | 99 | 2.91 | +1371 | +13.9 |
| ARTILLERY RE-ROLL WEIGHED | 84 | 84 | 84 | 2.47 | +0 | +0.0 |
| KILLS COUNT NEXT TURN | 239 | 239 | 84 | 2.47 | +2164 | +25.8 |
| ONE TARGET A SHOOTER | 437 | 430 | 82 | 2.41 | +953 | +11.6 |
| FOLLOW UP WEIGHED | 79 | 79 | 79 | 2.32 | +15949 | +201.9 |
| MOVE TO CHARGE COMPUTED | 126 | 124 | 79 | 2.32 | +5686 | +72.0 |
| SHOTS IN THE MOVE | 858 | 717 | 76 | 2.24 | +3615 | +47.6 |
| FOUR ROUNDS | 128 | 127 | 67 | 1.97 | +4782 | +71.4 |
| ADVANCE LANE KEPT | 66 | 66 | 66 | 1.94 | +0 | +0.0 |
| HARD STAY DROPPED | 66 | 66 | 66 | 1.94 | +0 | +0.0 |
| LANE BY FIGURES | 65 | 65 | 65 | 1.91 | +2673 | +41.1 |
| MISSILES IN THE MOVE | 302 | 231 | 64 | 1.88 | +1141 | +17.8 |
| MAX FOR POSITIONING | 451 | 339 | 63 | 1.85 | +252 | +4.0 |
| REDIRECT COUNTER | 203 | 120 | 61 | 1.79 | +4797 | +78.6 |
| RISK BY ARC | 186 | 184 | 55 | 1.62 | +1524 | +27.7 |
| CANNON SIGHT KEPT | 48 | 48 | 48 | 1.41 | +0 | +0.0 |
| FALLBACK BY WORTH | 190 | 190 | 48 | 1.41 | +1856 | +38.7 |
| RESERVE FALL BACK | 48 | 48 | 48 | 1.41 | +1583 | +33.0 |
| SUPPORTS | 164 | 164 | 43 | 1.26 | +437 | +10.2 |
| IDLE COST | 737 | 426 | 42 | 1.24 | +327 | +7.8 |
| CANNON PLANNED TARGET | 240 | 240 | 41 | 1.21 | +82 | +2.0 |
| FACES THE THREAT | 41 | 41 | 41 | 1.21 | +2750 | +67.1 |
| WAIT AFTER COSTS | 262 | 262 | 41 | 1.21 | +751 | +18.3 |
| MOVE ORDER | 40 | 40 | 40 | 1.18 | +0 | +0.0 |
| BEST FIRST | 38 | 38 | 38 | 1.12 | +1977 | +52.0 |
| SHOT RISK POINTS | 282 | 278 | 37 | 1.09 | +1426 | +38.5 |
| CHARGE NOW FIRST | 166 | 166 | 36 | 1.06 | -2073 | -57.6 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 1.03 | +0 | +0.0 |
| ONE FIGHT FORMULA | 463 | 246 | 34 | 1.00 | +118 | +3.5 |
| RANDOM MOVE BY FIGURES | 65 | 65 | 34 | 1.00 | +937 | +27.6 |
| CHAFF IN THE MOVE | 60 | 57 | 33 | 0.97 | +635 | +19.2 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.97 | +2259 | +68.5 |
| JOINT CHARGE NOW | 31 | 31 | 31 | 0.91 | +1793 | +57.8 |
| MARCH CHECK | 40 | 40 | 29 | 0.85 | +388 | +13.4 |
| SHOOTS FROM THE BEST SPOT | 65 | 65 | 29 | 0.85 | +389 | +13.4 |
| RISK ONCE | 134 | 102 | 28 | 0.82 | +588 | +21.0 |
| STAY WORTH | 942 | 850 | 28 | 0.82 | +402 | +14.3 |
| COMBAT PIVOT | 27 | 27 | 27 | 0.79 | +0 | +0.0 |
| SET UP TOGETHER | 63 | 55 | 27 | 0.79 | +1616 | +59.8 |
| CHARGE NOT DECLARED | 25 | 25 | 25 | 0.74 | -520 | -20.8 |
| SCOUT WAITS | 25 | 25 | 25 | 0.74 | +0 | +0.0 |
| HONEST WORTH | 421 | 420 | 23 | 0.68 | +169 | +7.3 |
| TIED UP BY THE SUM | 29 | 29 | 23 | 0.68 | +942 | +41.0 |
| CAST JOB | 46 | 46 | 22 | 0.65 | +278 | +12.7 |
| SHOOTERS IN TWO RANKS | 22 | 22 | 22 | 0.65 | +53 | +2.4 |
| WHO HITS BACK | 22 | 22 | 22 | 0.65 | +1562 | +71.0 |
| KILLS COUNT | 65 | 63 | 20 | 0.59 | +901 | +45.0 |
| MANOEUVRE | 43 | 43 | 20 | 0.59 | +599 | +29.9 |
| WHOLE FIGHT GAIN | 31 | 30 | 20 | 0.59 | +736 | +36.8 |
| BEST MOVE FOR SHOOTERS | 19 | 19 | 19 | 0.56 | +1264 | +66.5 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.53 | +1023 | +56.8 |
| KEEPS ITS TARGET | 84 | 84 | 17 | 0.50 | +334 | +19.7 |
| ADVANCE WORTH | 126 | 126 | 16 | 0.47 | +209 | +13.1 |
| RISK BY HIS FIGURE | 439 | 435 | 16 | 0.47 | +1323 | +82.7 |
| CHARGE LOSSES | 179 | 178 | 15 | 0.44 | +2080 | +138.7 |
| CHARGE NOW WEIGHED | 15 | 15 | 15 | 0.44 | +761 | +50.7 |
| NEXT OBJECTIVE NEARER | 179 | 179 | 15 | 0.44 | +219 | +14.6 |
| BLOCKED WHEEL | 14 | 14 | 14 | 0.41 | +624 | +44.5 |
| FIRE IN ORDER | 14 | 14 | 14 | 0.41 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 29 | 29 | 14 | 0.41 | +764 | +54.6 |
| ONE OBJECTIVE FORMULA | 203 | 142 | 14 | 0.41 | +623 | +44.5 |
| FALLS SHORT | 184 | 150 | 13 | 0.38 | +102 | +7.9 |
| INVITES THE FIGHT | 33 | 33 | 13 | 0.38 | +86 | +6.6 |
| MISSILES NEXT TURN | 375 | 266 | 13 | 0.38 | +96 | +7.4 |
| MOVE AND CAST | 13 | 13 | 13 | 0.38 | +328 | +25.2 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.35 | +0 | +0.0 |
| HIS TURN DENIED | 50 | 49 | 12 | 0.35 | +328 | +27.4 |
| MAKE SURE TOGETHER | 38 | 24 | 12 | 0.35 | +694 | +57.8 |
| MARCH BY THE SUM | 12 | 12 | 12 | 0.35 | +968 | +80.7 |
| NEXT CHARGE BY LIST | 133 | 130 | 12 | 0.35 | +522 | +43.5 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.32 | +1482 | +134.8 |
| CHAFF PASSED | 11 | 11 | 11 | 0.32 | -18 | -1.7 |
| HUNT IN PAIRS | 36 | 19 | 11 | 0.32 | +619 | +56.3 |
| MARCH ODDS | 11 | 11 | 11 | 0.32 | +268 | +24.3 |
| WALKS TO THE FIGHT | 30 | 30 | 11 | 0.32 | +30 | +2.7 |
| FIGHT TO THE END | 53 | 52 | 10 | 0.29 | +350 | +35.0 |
| SURE REACH TOGETHER | 38 | 33 | 10 | 0.29 | +100 | +10.0 |
| WEARS DOWN | 40 | 40 | 10 | 0.29 | +123 | +12.3 |
| WHOLE FIGHT | 27 | 27 | 10 | 0.29 | +596 | +59.6 |
| BEST PRIZE | 9 | 9 | 9 | 0.26 | -630 | -70.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.26 | +0 | +0.0 |
| LOST CHARGE | 77 | 77 | 9 | 0.26 | +78 | +8.7 |
| NEARER NOT NEEDED | 148 | 142 | 9 | 0.26 | +144 | +16.0 |
| OPENS UP | 12 | 11 | 9 | 0.26 | +531 | +59.0 |
| OVERRUNS AWAY | 39 | 38 | 9 | 0.26 | +141 | +15.7 |
| SAFER THAN THE JOB | 9 | 9 | 9 | 0.26 | +377 | +41.9 |
| SUPPORT NARROWED | 277 | 277 | 9 | 0.26 | -87 | -9.7 |
| AFTERMATH WITH FRIENDS | 8 | 8 | 8 | 0.24 | +488 | +61.1 |
| BEST FACING | 8 | 8 | 8 | 0.24 | +207 | +25.9 |
| HIS CHARGE DENIED | 19 | 19 | 8 | 0.24 | +311 | +38.9 |
| STOPS SHORT OF THE FLANK | 8 | 8 | 8 | 0.24 | +254 | +31.8 |
| CASTING BLOCK | 11 | 11 | 7 | 0.21 | +106 | +15.2 |
| KEEP FALLS | 7 | 7 | 7 | 0.21 | +171 | +24.4 |
| MODEL FACING | 7 | 7 | 7 | 0.21 | +1017 | +145.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.21 | +141 | +20.1 |
| REFUSING RETIRES | 21 | 21 | 7 | 0.21 | -1 | -0.2 |
| SET UP BY THE SET | 23 | 23 | 7 | 0.21 | +561 | +80.1 |
| STUCK PIVOT | 7 | 7 | 7 | 0.21 | +0 | +0.0 |
| WIDER SPREAD | 193 | 188 | 7 | 0.21 | +51 | +7.3 |
| BACKUP TARGETS | 36 | 19 | 6 | 0.18 | +6 | +1.0 |
| FEATURE BUFFS | 38 | 38 | 6 | 0.18 | +110 | +18.3 |
| THROUGH LINE OF FIRE | 6 | 6 | 6 | 0.18 | +242 | +40.4 |
| BEST PREY | 22 | 22 | 5 | 0.15 | +12 | +2.3 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.15 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 49 | 49 | 5 | 0.15 | +113 | +22.7 |
| FOCUS FIRE | 4 | 4 | 4 | 0.12 | +204 | +51.0 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.12 | +85 | +21.2 |
| GUN MASK | 26 | 26 | 4 | 0.12 | +29 | +7.3 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.12 | -92 | -22.9 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.12 | -395 | -98.8 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.12 | +57 | +14.3 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.12 | -208 | -51.9 |
| BEST OVERALL | 3 | 3 | 3 | 0.09 | +57 | +18.9 |
| BIG CHARACTER SAFETY | 3 | 3 | 3 | 0.09 | -15 | -4.9 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.09 | +19 | +6.2 |
| NO DOUBLE ROUNDS | 95 | 95 | 3 | 0.09 | +54 | +17.9 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.09 | +6 | +1.9 |
| SPELLS IN THE FIGHT | 48 | 44 | 3 | 0.09 | +95 | +31.6 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.06 | +502 | +251.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +25 | +12.6 |
| HUNT ADVANCE | 4 | 4 | 2 | 0.06 | +49 | +24.5 |
| LONG SHOT | 18 | 18 | 2 | 0.06 | +21 | +10.3 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +113 | +56.5 |
| WOUNDED STAYS OUT | 3 | 3 | 2 | 0.06 | -346 | -172.8 |
| BLOWS WHERE AIMED | 25 | 24 | 1 | 0.03 | +29 | +28.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +27 | +27.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT SET-UP | 8 | 8 | 1 | 0.03 | -51 | -51.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.5 |
| CHARGER SLAIN LOST | 40 | 37 | 1 | 0.03 | +23 | +23.4 |
| EDGE GIVE GROUND | 10 | 9 | 1 | 0.03 | +55 | +55.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +17 | +16.6 |
| HIS FIGHT TOGETHER | 40 | 40 | 1 | 0.03 | +28 | +28.1 |
| HIS MOVE AND SHOT | 42 | 42 | 1 | 0.03 | +3 | +3.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.03 | +310 | +310.3 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 1 | 0.03 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 7 | 3 | 1 | 0.03 | +21 | +20.6 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 5 | 1 | 1 | 0.03 | +1 | +1.3 |
| REDIRECT BY WHAT IT STOPS | 37 | 37 | 1 | 0.03 | +0 | +0.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -40 | -40.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +8 | +8.1 |
| WAR ENGINE JOBS | 9 | 9 | 1 | 0.03 | -2 | -1.9 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 27 | 27 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 47 | trace | - | - | - | - |
| CHARACTER GUNS | 9 | 9 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 50 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 5 | 5 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 94 | 94 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 351 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 10 | 0 | 0.00 | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| GIVES UP | 13 | 12 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 55 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 36 | 35 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 6 | 6 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 16 | 16 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 98 | 98 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 105 | 105 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 79 | 79 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 97 | 94 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 6 | 6 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 15 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 12 | trace | - | - | - | - |
| MARCH OVER CASTS | 49 | 49 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 20 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 206 | 206 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 38 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 95 | 93 | 0 | 0.00 | - | - |
| PLAN RESULT | 2639 | trace | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 10 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 23 | 22 | 0 | 0.00 | - | - |
| RUN DOWN | 78 | 77 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 28 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 16 | 16 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 128 | not checked | - | - | - | - |
| STABLE ROLE | 306 | 306 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 20 | 20 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 607 | 600 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 91 | not checked | - | - | - | - |
| THE PROMISE ADDS | 5 | 5 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 40 | not checked | - | - | - | - |
| TURN WORTH | 9 | 9 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 13 | 12 | 0 | 0.00 | - | - |
| WAITS AGAIN | 48 | 48 | 0 | 0.00 | - | - |

### Off best figure: t10-mine-ba3e30a-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.12 | 15.85 | 54.4 |
| ARMY TABLE | rule | 1.21 | - | 40.9 |
| CHARGE NOW FIRST | rule | 0.21 | 0.85 | 57.6 |
| FALLBACK | gate | 0.03 | 0.71 | 45.4 |
| HOLDER ASSIGNMENT | rule | 0.74 | - | 29.7 |
| CHARGE NOT DECLARED | rule | 0.03 | 0.56 | 39.2 |
| PATHS CROSS | rule | 0.29 | 0.09 | 12.1 |
| NO REASON | gate | 0.35 | - | 42.0 |
| BEST PRIZE | rule | 0.12 | 0.15 | 70.0 |
| JOINT CHARGE NOW | rule | 0.26 | - | 80.9 |
| SUPPORT NARROWED | rule | 0.09 | 0.18 | 9.7 |
| TURN GATE | gate | - | 0.26 | 23.8 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.24 | 32.5 |
| AFTERMATH BAND | gate | 0.09 | 0.09 | 2.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.12 | 0.03 | 13.5 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.09 | 22.9 |
| PURSUES BIG PREY | rule | 0.06 | 0.06 | 98.8 |
| SUPPORT REQUEST | gate | - | 0.12 | 89.1 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.12 | 51.9 |
| CHAFF PASSED | rule | 0.06 | 0.03 | 6.0 |
| CHARGE NOW WEIGHED | rule | - | 0.09 | 33.2 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 1.9 |
| BIG CHARACTER SAFETY | rule | - | 0.06 | 7.8 |
| CANNON PLANNED TARGET | rule | 0.03 | 0.03 | 53.6 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 7.8 |
| WOUNDED STAYS OUT | rule | - | 0.06 | 172.8 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 51.1 |
| CATCH ODDS | rule | - | 0.03 | 1.5 |
| DEPLOY BY FIGURES | rule | - | 0.03 | 4.0 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.1 |
| MARCH ODDS | rule | 0.03 | - | 2.9 |
| REDIRECT WEIGHED | rule | - | 0.03 | 88.4 |
| RULE SWITCHED OFF | gate | - | 0.03 | 2.0 |
| SAFE SURE CHARGE | rule | - | 0.03 | 40.4 |
| WAR ENGINE JOBS | rule | - | 0.03 | 1.9 |
| WHO HITS BACK | rule | 0.03 | - | 3.6 |

### Plans: t10-mine-ba3e30a-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 69% | 570 | 255 | 45% |
| Mine | join | 0.4 | 100% | 12 | 0 | 0% |
| Mine | move | 26.6 | 95% | 1681 | 0 | 0% |
| Mine | shoot | 9.3 | 60% | 378 | 598 | 158% |
| Mine | support | 0.1 | 100% | 0 | 0 | 0% |
| Opponent | advance | 10.8 | 14% | 157 | 225 | 143% |
| Opponent | charge | 4.0 | 47% | 345 | 394 | 114% |
| Opponent | close in | 6.7 | 18% | 380 | 126 | 33% |
| Opponent | hold | 5.0 | 42% | 323 | 0 | 0% |
| Opponent | join | 1.3 | 100% | 74 | 0 | 0% |
| Opponent | shoot | 4.2 | 52% | 211 | 297 | 141% |
| Opponent | support | 6.2 | 88% | 45 | 0 | 0% |

### Packages: hunt the guns, t10-mine-ba3e30a-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 6 |
| Opponent | 0.1 | 4 | 0 | 0% | 25% | 0% | 2.0 | 405 | 125 | 25% | 74 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 26 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 576 | 501 | 100% | 10 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 249 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 65 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 26 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 360 | 0 | 0% | 60 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 46 |

### Battle groups: t10-mine-ba3e30a-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 26% | 67% | 33% | 60% | 30% | 0% | 0% | 70% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 17% | 84% | 28% | 43% | 22% | 0% | 11% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t10-mine-ba3e30a-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 31 | 68 (31) | 12 | 56 | 52 | 42% | 2.8 | 80 (15) | 88 (9) | 9 (7) | 81 (24) | 28 (7) |
| Mine | Character | 112 | 57 (112) | 57 | 0 | 32 | 19% | 2.4 | 48 (41) | 61 (43) | 83 (20) | 52 (64) | 75 (40) |
| Mine | Clean-up | 20 | 93 (20) | 28 | 65 | 29 | 30% | 3.2 | 47 (6) | 92 (11) | 166 (3) | 90 (15) | 101 (5) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 41 | 41 (41) | 33 | 8 | 57 | 24% | 2.6 | 22 (19) | 57 (19) | 60 (3) | 45 (25) | 34 (16) |
| Mine | Hammer | 49 | 31 (49) | 16 | 16 | 25 | 14% | 2.6 | 19 (15) | 35 (23) | 42 (11) | 29 (33) | 36 (16) |
| Mine | Holder | 23 | 35 (23) | 10 | 25 | 36 | 43% | 2.6 | 18 (11) | 52 (8) | 27 (4) | 41 (12) | 25 (11) |
| Mine | Infantry | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Shooter | 37 | 83 (37) | 42 | 41 | 46 | 3% | 2.0 | 81 (13) | 104 (19) | 18 (5) | 92 (27) | 57 (10) |
| Mine | Support | 4 | 30 (4) | 30 | 0 | 0 | 0% | 2.8 | - | 30 (4) | - | - | 30 (4) |
| Mine | War machine | 52 | 38 (52) | 38 | 0 | 37 | 2% | 1.4 | 46 (25) | 32 (26) | 0 (1) | 29 (15) | 43 (37) |
| Mine | Wizard | 16 | 12 (16) | 12 | 0 | 34 | 25% | 2.3 | 8 (7) | 0 (5) | 37 (3) | 0 (5) | 19 (10) |
| Opponent | Chaff | 62 | 73 (62) | 12 | 61 | 67 | 40% | 2.9 | 24 (22) | 115 (27) | 47 (13) | 74 (45) | 69 (17) |
| Opponent | Character | 97 | 45 (97) | 45 | 0 | 33 | 20% | 2.5 | 51 (36) | 31 (41) | 82 (12) | 52 (45) | 43 (44) |
| Opponent | Clean-up | 14 | 52 (14) | 6 | 46 | 26 | 43% | 3.2 | 29 (6) | 75 (7) | 0 (1) | 89 (9) | 0 (5) |
| Opponent | Fast | 1 | 357 (1) | 357 | 0 | 100 | 0% | 2.0 | - | 357 (1) | - | 357 (1) | - |
| Opponent | Fast Hammer | 56 | 35 (56) | 24 | 11 | 48 | 27% | 2.8 | 33 (18) | 37 (32) | 33 (6) | 48 (25) | 23 (31) |
| Opponent | Hammer | 45 | 33 (45) | 30 | 3 | 46 | 27% | 2.8 | 10 (15) | 41 (23) | 50 (7) | 34 (28) | 31 (17) |
| Opponent | Holder | 38 | 69 (38) | 11 | 58 | 19 | 47% | 2.4 | 73 (10) | 82 (16) | 62 (10) | 84 (26) | 41 (10) |
| Opponent | Shooter | 27 | 45 (27) | 13 | 32 | 52 | 7% | 1.5 | 89 (12) | 14 (13) | 0 (2) | 56 (22) | 0 (5) |
| Opponent | Support | 5 | 0 (5) | 0 | 0 | 0 | 80% | 6.0 | 0 (1) | 0 (3) | 0 (1) | 0 (2) | 0 (3) |
| Opponent | War machine | 17 | 9 (17) | 9 | 0 | 59 | 6% | 1.8 | 8 (9) | 12 (7) | 0 (1) | 28 (4) | 5 (13) |
| Opponent | Wizard | 31 | 12 (31) | 12 | 0 | 51 | 6% | 2.4 | 3 (10) | 21 (9) | 0 (3) | 4 (9) | 12 (13) |

### Charged fights: t10-mine-ba3e30a-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 186 | 21 | 1.0 | 1.0 | 21 | 0 | +21 | 0 of 4 | 4 of 4 | - | +21 |
| Mine | Chaos Dwarfs | 4 | 134 | 276 | 1.5 | 1.0 | 184 | 0 | +184 | 2 of 6 | 6 of 6 | - | +184 |
| Mine | Dwarfen Mountain Holds | 3 | 482 | 180 | 1.7 | 1.2 | 108 | 37 | +71 | 1 of 5 | 5 of 5 | +540 | -46 |
| Mine | Empire of Man | 5 | 385 | 272 | 2.4 | 1.0 | 113 | 32 | +82 | 2 of 12 | 9 of 12 | - | +82 |
| Mine | Grand Cathay | 5 | 553 | 369 | 4.6 | 1.1 | 80 | 35 | +45 | 8 of 23 | 17 of 23 | +86 | +41 |
| Mine | High Elf Realms | 4 | 168 | 701 | 3.2 | 1.1 | 216 | 0 | +216 | 9 of 13 | 9 of 13 | +195 | +217 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 255 | 4.0 | 1.5 | 64 | 0 | +64 | 2 of 4 | 4 of 4 | +0 | +128 |
| Mine | Lizardmen | 1 | 116 | 778 | 4.0 | 1.0 | 194 | 0 | +194 | 2 of 4 | 2 of 4 | - | +194 |
| Mine | Ogre Kingdoms | 1 | 311 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 0 of 2 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Skaven | 1 | 0 | 19 | 2.0 | 1.0 | 10 | 0 | +10 | 0 of 2 | 2 of 2 | - | +10 |
| Mine | Tomb Kings of Khemri | 2 | 124 | 385 | 5.5 | 1.2 | 70 | 0 | +70 | 3 of 11 | 9 of 11 | +0 | +86 |
| Mine | Vampire Counts | 2 | 144 | 511 | 4.5 | 1.0 | 114 | 12 | +101 | 2 of 9 | 8 of 9 | - | +101 |
| **Mine** | all armies | 34 | 266 | 311 | 2.8 | 1.1 | 111 | 16 | +96 | 31 of 95 | 75 of 95 | +114 | +94 |
| Opponent | Empire of Man | 1 | 380 | 189 | 1.0 | 1.0 | 189 | 0 | +189 | 1 of 1 | 1 of 1 | - | +189 |
| Opponent | Grand Cathay | 3 | 222 | 407 | 3.0 | 1.3 | 136 | 41 | +95 | 4 of 9 | 8 of 9 | -73 | +179 |
| Opponent | High Elf Realms | 3 | 155 | 161 | 0.7 | 1.5 | 242 | 0 | +242 | 1 of 2 | 1 of 2 | +214 | +270 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 332 | 2.5 | 1.6 | 133 | 36 | +97 | 2 of 5 | 3 of 5 | +95 | +100 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 477 | 4.0 | 1.0 | 119 | 0 | +119 | 1 of 4 | 3 of 4 | - | +119 |
| Opponent | Skaven | 1 | 120 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 156 | 942 | 4.8 | 1.0 | 198 | 5 | +194 | 10 of 19 | 14 of 19 | - | +194 |
| Opponent | Vampire Counts | 6 | 0 | 341 | 3.7 | 1.3 | 93 | 47 | +46 | 12 of 22 | 13 of 22 | +78 | +37 |
| Opponent | Warriors of Chaos | 8 | 25 | 586 | 3.9 | 1.0 | 151 | 29 | +122 | 16 of 31 | 22 of 31 | +350 | +114 |
| Opponent | Wood Elf Realms | 5 | 109 | 24 | 3.0 | 1.1 | 8 | 104 | -96 | 4 of 15 | 8 of 15 | +0 | -103 |
| **Opponent** | all armies | 34 | 88 | 402 | 3.2 | 1.1 | 126 | 38 | +88 | 51 of 108 | 73 of 108 | +73 | +90 |

### Effective charges: t10-mine-ba3e30a-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 2 (net +22) | 0 | 0 | 2 (net +20) | 0 | 50% (2 of 4) |
| Mine | Chaos Dwarfs | 6 | 0 | 0 | 2 (net +42) | 0 | 2 (net +61) | 2 (net +449) | 0 | 33% (2 of 6) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 0 | 1 (net +540) | 0 | 1 (net +0) | 3 | 0% (0 of 2) |
| Mine | Empire of Man | 12 | 1 (net -112) | 0 | 2 (net +114) | 5 (net +63) | 0 | 4 (net +137) | 0 | 17% (2 of 12) |
| Mine | Grand Cathay | 23 | 3 (net -56) | 0 | 1 (net +275) | 6 (net -28) | 4 (net +104) | 8 (net +86) | 1 | 5% (1 of 22) |
| Mine | High Elf Realms | 13 | 0 | 0 | 5 (net +282) | 2 (net +216) | 3 (net +152) | 3 (net +169) | 0 | 38% (5 of 13) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +0) | 0 | 0 | 1 (net +19) | 0 | 2 (net +118) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 1 (net +492) | 0 | 0 | 1 (net +0) | 0 | 1 (net +170) | 1 | 0% (0 of 3) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 1 (net +19) | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 11 | 0 | 0 | 5 (net +64) | 3 (net +65) | 1 (net +255) | 2 (net +0) | 0 | 45% (5 of 11) |
| Mine | Vampire Counts | 9 | 0 | 0 | 0 | 3 (net +58) | 1 (net +70) | 4 (net +108) | 1 | 0% (0 of 8) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +189) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 9 | 1 (net -369) | 0 | 1 (net +355) | 4 (net +179) | 2 (net +75) | 1 (net +0) | 0 | 11% (1 of 9) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 1 (net +270) | 0 | 1 (net +214) | 0 | 0 | 50% (1 of 2) |
| Opponent | Kingdom of Bretonnia | 5 | 1 (net +279) | 0 | 0 | 2 (net +142) | 0 | 0 | 2 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 1 (net +115) | 0 | 3 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 19 | 3 (net +548) | 1 (net +511) | 4 (net +60) | 4 (net +190) | 1 (net +104) | 2 (net +62) | 4 | 27% (4 of 15) |
| Opponent | Vampire Counts | 22 | 7 (net -0) | 0 | 2 (net -93) | 2 (net +31) | 2 (net +86) | 5 (net +94) | 4 | 11% (2 of 18) |
| Opponent | Warriors of Chaos | 31 | 3 (net +52) | 1 (net +0) | 10 (net +124) | 2 (net +408) | 0 | 8 (net +198) | 7 | 42% (10 of 24) |
| Opponent | Wood Elf Realms | 15 | 4 (net -26) | 0 | 2 (net -141) | 0 | 0 | 2 (net -52) | 7 | 25% (2 of 8) |

### Charged fights, damage counted: t10-mine-ba3e30a-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 343 | 263 | +35 | 221 | 268 | -47 | -13.6 |
| Mine | Effective (55-75%) | 17 | 261 | 232 | +139 | 147 | 42 | +105 | +40.3 |
| Mine | 76-89% | 22 | 262 | 197 | +68 | 105 | 18 | +86 | +32.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 259 | 196 | +117 | 117 | 3 | +115 | +44.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 386 | 96 | +111 | 118 | 4 | +114 | +29.5 |
| Mine | No odds | 8 | 160 | 162 | +21 | 71 | 41 | +30 | +18.9 |
| Mine | All fights | 95 | 273 | 191 | +96 | 123 | 34 | +89 | +32.6 |
| Opponent | Long shot (under 50%) | 19 | 220 | 299 | +84 | 161 | 97 | +64 | +29.1 |
| Opponent | 50-54% | 2 | 288 | 333 | +256 | 275 | 0 | +275 | +95.5 |
| Opponent | Effective (55-75%) | 20 | 349 | 278 | +82 | 176 | 77 | +98 | +28.1 |
| Opponent | 76-89% | 14 | 392 | 232 | +188 | 241 | 71 | +170 | +43.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 272 | 179 | +119 | 155 | 15 | +140 | +51.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 459 | 101 | +108 | 108 | 9 | +99 | +21.5 |
| Opponent | No odds | 27 | 215 | 195 | +4 | 92 | 74 | +17 | +8.0 |
| Opponent | All fights | 108 | 291 | 227 | +88 | 154 | 62 | +92 | +31.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t10-mine-ba3e30a-p3 | move | 315 | 72 (23%) | 49 (16%) | 51 (16%) | 192 (61%) |
| t10-mine-ba3e30a-p3 | objective | 230 | 35 (15%) | 21 (9%) | 37 (16%) | 158 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

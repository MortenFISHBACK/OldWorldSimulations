# Doctrine scorecard: t10-opp-ba3e30a-p4

### Scorecard: t10-opp-ba3e30a-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 10 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 5 | 2 | 7 | 2 | 0 | 0 | 0 | 177 |
| L0130 | 4 | 1 | Mine | no | 1 | 6 | 1 | 1 | 1 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 1070 |
| L0315 | 3 | 1 | Opponent | yes | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 3 | 4 | 0 | 0 | 0 | 0 | 790 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 8 | 2 | 3 | 0 | 1 | 0 | 0 | 234 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1128 |
| L0520 | 4 | 1 | Opponent | yes | 0 | - | 0 | 6 | 1 | 0 | 0 | 192 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 0 | 0 | 0 | 265 |
| L0624 | 6 | 1 | Mine | no | 0 | - | 5 | 1 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 1 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 1 | 3 | 3 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0729 | 3 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | yes | 5 | - | 0 | 0 | 0 | 0 | 0 | 762 |
| L0819 | 3 | 1 | Opponent | no | 3 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 110 |
| L1017 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 1 | 0 | 0 | 165 |
| L1017 | 3 | 1 | Opponent | no | 3 | 1 | 2 | 2 | 1 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 3 | 2 | 1 | 4 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 440 |
| L1314 | 6 | 1 | Mine | no | 9 | 2 | 3 | 0 | 0 | 0 | 0 | 479 |
| L1314 | 6 | 1 | Opponent | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | 2 | 5 | 1 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 6 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | - | 1 | 1 | 2 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1621 | 1 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 355 |
| L1621 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 355 |
| L1719 | 3 | 1 | Mine | yes | 8 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | yes | 0 | 5 | 5 | 1 | 0 | 0 | 0 | 185 |
| L1819 | 1 | 1 | Opponent | yes | 7 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 6 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 1 | 5 | 0 | 0 | 0 | 500 |
| **Average** | | | Mine | 32% | 2.6 | 3.0 | 2.4 | 0.9 | 0.2 | 0.0 | 0.0 | 341.8 |
| **Average** | | | Opponent | 36% | 3.2 | 2.6 | 2.0 | 2.2 | 0.2 | 0.0 | 0.0 | 90.3 |

### KPIs: t10-opp-ba3e30a-p4

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 29 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (43 of 139) | 0% (0 of 143) | 15% (43 of 282) |
| Winner chose to follow up after the loser gave ground |  | 98% (49 of 50); on the table 98% | 97% (32 of 33); on the table 100% | 98% (81 of 83); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (14 of 14); on the table 100% | 50% (1 of 2); on the table 50% | 94% (15 of 16); on the table 94% |
| Winner chose to pursue after the loser fled |  | 76% (16 of 21); on the table 81% | 78% (14 of 18); on the table 78% | 77% (30 of 39); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 93% (79 of 85); on the table 94% | 89% (47 of 53); on the table 91% | 91% (126 of 138); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 34% (87 of 253) | 32% (44 of 136) | 34% (131 of 389) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (87 of 210) | 42% (44 of 106) | 41% (131 of 316) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 39% (7 of 18) | 68% (52 of 77) | 62% (59 of 95) |
| Points that never fought | lower | 43% (23817 of 55494) | 43% (24805 of 57988) | 43% (48622 of 113482) |
|   infantry points that never fought | lower | 49% (6254 of 12663) | 66% (7607 of 11494) | 57% (13861 of 24157) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (128 of 229) | 61% (139 of 229) | 58% (267 of 458) |
| Bound items with a magic missile used (at least once a game) |  | 86% (18 of 21); 2.4 uses a game | 75% (6 of 8); 0.7 uses a game | 83% (24 of 29); 1.5 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.6 uses a game | 45% (9 of 20); 0.4 uses a game | 53% (19 of 36); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 67% (12 of 18); 0.4 uses a game | 67% (8 of 12); 0.3 uses a game | 67% (20 of 30); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (24764 of 47310) | 56% (28912 of 51743) | 54% (53676 of 99053) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.4 (42%) | 0.9 (29%) | 3.3 (38%) |
| MARCHED: its unit marched | 0.9 (16%) | 1.0 (33%) | 2.0 (22%) |
| CHARGED: its unit charged | 0.4 (8%) | 0.1 (4%) | 0.6 (7%) |
| IN COMBAT: engaged in combat | 0.9 (16%) | 0.4 (13%) | 1.3 (15%) |
| REAR RANK: in a rear rank | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.5 (8%) | 0.5 (15%) | 1.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (4%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.2 | 2.6 | 4.5 | 0.6 | 1.6 |
| not cast | 2.5 | 2.5 | 3.4 | 8.9 | 1.7 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (56%) | 0.3 (9%) | 3.3 (38%) | 0.7 (41%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (22%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (7%) | 0.2 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.2 (10%) | 0.6 (16%) | 1.3 (15%) | 0.2 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (16%) | 0.2 (8%) | 0.4 (12%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.2 (7%) | 0.1 (3%) | 0.3 (8%) | 1.0 (11%) | 0.0 (2%) | 1.3 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (16%) | 0.0 (0%) | 0.2 (6%) | 0.2 (3%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (1%) | 0.0 (1%) | 0.2 (2%) | 0.0 (2%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.4 (16%) | 0.0 (1%) | 0.0 (0%) | 0.2 (12%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (58%) | 0.1 (5%) | 1.6 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 1.0 a game | 1.4 a game |
| stood (cast and not dispelled) | 71% (32 of 45) | 63% (12 of 19) | 69% (44 of 64) |
| the unit moved after it | 75% (24 of 32) | 100% (12 of 12) | 82% (36 of 44) |
| it charged on its next turn | 9% (3 of 32) | 0% (0 of 12) | 7% (3 of 44) |
| the enemy charged it first | 19% (6 of 32) | 0% (0 of 12) | 14% (6 of 44) |
| it fought by the end of its next turn | 16% (5 of 32) | 0% (0 of 12) | 11% (5 of 44) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 32) | 0% (0 of 12) | 0% (0 of 44) |
| none of these (no charge, no fight, no charge escaped) | 72% (23 of 32) | 100% (12 of 12) | 80% (35 of 44) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (502 of 783) | 55% (248 of 453) | 61% (750 of 1236) |
|   cavalry | 53% (32 of 60) | 71% (60 of 85) | 63% (92 of 145) |
|   character | 60% (43 of 72) | 19% (20 of 105) | 36% (63 of 177) |
|   chariot | 54% (45 of 84) | 61% (14 of 23) | 55% (59 of 107) |
|   infantry | 54% (120 of 223) | 66% (126 of 191) | 59% (246 of 414) |
|   monster | 62% (28 of 45) | 17% (3 of 18) | 49% (31 of 63) |
|   war machine | 78% (234 of 299) | 81% (25 of 31) | 78% (259 of 330) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (23%) | 1.2 (18%) | 3.5 (21%) |
| CHARGED: it charged | 0.9 (9%) | 1.1 (15%) | 1.9 (12%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.3 (4%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.2 (2%) | 0.2 (3%) | 0.4 (2%) |
| NO TARGET IN RANGE | 2.3 (23%) | 2.1 (30%) | 4.4 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.9 (12%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.6 (27%) | 1.2 (17%) | 3.8 (23%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.2 | 2.0 | 76% | 6.7 pts | 35 pts |
| character | 2.8 | 0.5 | 87% | 2.6 pts | 7 pts |
| chariot | 2.1 | 1.0 | 65% | 18.3 pts | 38 pts |
| infantry | 13.2 | 3.9 | 79% | 8.7 pts | 115 pts |
| monster | 1.3 | 0.2 | 86% | 3.2 pts | 4 pts |
| war machine | 8.9 | 9.3 | 61% | 35.1 pts | 313 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 4.8 | 4.5 |
| Charges that made contact a game | 2.9 | 3.3 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.15 declared, 0.69 contact (13 units) | 0.43 declared, 0.29 contact (14 units) | 0.78 declared, 0.48 contact (27 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.67 contact (6 units) | 0.92 declared, 0.58 contact (12 units) | 0.89 declared, 0.61 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.38 contact (190 units) | 0.50 declared, 0.35 contact (242 units) | 0.52 declared, 0.36 contact (432 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (36 of 67) | 50% (6 of 12) | 75% (3 of 4) | 54% (45 of 83) |
| Character in a unit | 69% (25 of 36) | 71% (12 of 17) | 100% (1 of 1) | 70% (38 of 54) |
| Character on its own | 68% (13 of 19) | 57% (13 of 23) | 34% (19 of 56) | 46% (45 of 98) |
| Chariot | 62% (8 of 13) | 83% (10 of 12) | - | 72% (18 of 25) |
| Infantry | 59% (41 of 69) | 43% (10 of 23) | 80% (4 of 5) | 57% (55 of 97) |
| Monster | 73% (16 of 22) | 67% (8 of 12) | - | 71% (24 of 34) |
| Monstrous | 89% (8 of 9) | 31% (4 of 13) | - | 55% (12 of 22) |
| War Machines | 65% (28 of 43) | 100% (2 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 89% (8 of 9); on the table 100% | 40% (41 of 102) | 50% | 68% (15 of 22) | 83% (5 of 6); 6.0 uses a game | 100% (2 of 2); 1.5 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 90% (19 of 21); on the table 90% | 29% (7 of 24) | 29% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 90% (9 of 10); on the table 90% | - | 70% | 56% (15 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (11 of 11); on the table 100% | 22% (4 of 18) | 57% | 56% (35 of 62) | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 100% (6 of 6); on the table 100% | 38% (32 of 84) | 46% | 46% (17 of 37) | 89% (8 of 9); 6.8 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 89% (16 of 18); on the table 89% | 37% (13 of 35) | 32% | 59% (41 of 70) | 100% (7 of 7); 2.7 uses a game | 47% (14 of 30); 2.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 23% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 83% (10 of 12); on the table 83% | 17% (1 of 6) | 20% | 48% (10 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (7 of 7); on the table 100% | 0% (0 of 6) | 61% | 64% (9 of 14) | 50% (1 of 2); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (3 of 3); on the table 100% | 19% (8 of 42) | 33% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 5 | 86% (6 of 7); on the table 86% | 25% (9 of 36) | 51% | 69% (25 of 36) | 50% (1 of 2); 0.6 uses a game | 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| Tomb Kings of Khemri | 1 | 100% (7 of 7); on the table 100% | - | 40% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 88% (15 of 17); on the table 94% | 50% (12 of 24) | 34% | 61% (14 of 23) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 5 | 86% (6 of 7); on the table 86% | 50% (3 of 6) | 40% | 56% (22 of 39) | 100% (1 of 1); 0.8 uses a game | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game |
| Wood Elf Realms | 4 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 52% | 80% (32 of 40) | 50% (1 of 2); 0.8 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t10-opp-ba3e30a-p4, 29 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (27) | 50% (25) | 50% (52) |
| ...free all their last turn and able to turn (per game) | 0.55 | 0.76 | 1.31 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.21 | 0.03 | 0.24 |
| ...with the charger already in that arc before they moved (per game) | 0.34 | 0.48 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 0.03 | 2.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.76 | 0.03 | 0.79 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.48 | 0.38 | 4.86 |

### Quality by phase: t10-opp-ba3e30a-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.4 |
| Strategy | Charge objectives carried out (made contact) | 49% (59 of 120) | 55% (65 of 119) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (155 of 428) | 44% (40 of 90) |
| Strategy | Close-in objectives charged next turn | 14% (20 of 141) | - |
| Strategy | Support requests answered (helper made contact too) | 45% (5 of 11) | 44% (8 of 18) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 44% (7 of 16) | 67% (6 of 9) |
| Strategy | Joined characters whose unit fought | 42% (20 of 48) | 41% (11 of 27) |
| Strategy | Lone characters that fought | 71% (41 of 58) | 71% (44 of 62) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 0.9 | 2.2 |
| Movement | Points that never moved of their own | 341.8 | 90.3 |
| Movement | Fights charged into per game | 2.6 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 66, net -10 | 15 of 77, net +38 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 66, net +279 | 12 of 77, net +8 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 66, net +156 | 6 of 77, net +117 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 of 66, net +65 | 19 of 77, net +118 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (138 of 287) | 44% (114 of 262) |
| Shooting | Points destroyed by shooting units | 91.9 | 41.7 |
| Shooting | War machine shots | 8.1 | 0.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (120 of 234) | 52% (13 of 25) |
| Shooting | Points destroyed by war machines | 77.5 | 3.6 |
| Magic | Magic missiles cast | 1.9 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (24 of 56) | 22% (7 of 32) |
| Magic | Wounds caused by magic missiles | 5.0 | 1.9 |
| Magic | Wounds caused by other spells | 1.4 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 78.9 | 25.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.5 / 0.7 / 0.5 / 0.2 | 2.4 / 0.5 / 0.5 / 0.0 |
| Combat | Points destroyed in combat | 229.4 | 311.8 |
| Combat | Points run down | 77.3 | 85.7 |
| Combat | Net points per charged fight, damage counted | +65 | +59 |
| Combat | Net per 100 charger points, damage counted | +27.0 | +19.9 |
| Combat | First round won (charged fights) | 76% | 67% |
| Combat | Net points per charged fight | +56 | +60 |
| Combat | Net points per supported fight / lone fight | +212 / +26 | +62 / +60 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 75 | 43 of 86 |
| Game | Points lost | 558.0 | 638.8 |
| Game | VP from objectives | 627.6 | 561.4 |
| Game | Lone holders (player turns) | 2.6 | 3.2 |

- Mine won / drew / lost: 16 / 3 / 10 of 29 ended games (of 29); mean margin (Mine - Opponent) +162 VP
- The side that went first won 13 of 26 games with a winner
- Points traded per game (both sides' losses): 1197
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t10-opp-ba3e30a-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 3.9 | 1.1 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.8 | -167.8 | 132.9 | 102.4 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.1 | +5.3 | 0.0 | 4.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.1 | +2.0 | 0.0 | 2.1 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | - | - | - | - | 14.8 | +196.4 | 0.0 | 204.6 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 24.1 | 0.1 | +0.0 | 0.0 | 4.5 |
| BACKUP TARGETS | 0.7 | +2.4 | 0.0 | 30.9 | 0.3 | +1.4 | 0.0 | 0.0 |
| BEST FACING | 0.4 | +5.1 | 0.0 | 6.5 | - | - | - | - |
| BEST FIRST | 1.8 | +88.0 | 27.4 | 39.0 | - | - | - | - |
| BEST MOVE FOR SHOOTERS | 1.1 | +64.7 | 0.0 | 49.3 | - | - | - | - |
| BEST OVERALL | 0.3 | +14.3 | 0.0 | 0.0 | - | - | - | - |
| BEST PREY | 0.3 | +12.9 | 3.4 | 6.7 | - | - | - | - |
| BEST PRIZE | 0.1 | -2.8 | 0.0 | 0.0 | 0.2 | -2.2 | 4.1 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 15.2 | 0.0 |
| BLOCKED WHEEL | 0.3 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | +1.4 | 27.1 | 3.1 | 0.4 | -104.6 | 15.2 | 16.9 |
| BOMBING RUN | 0.0 | +1.1 | 0.0 | 5.2 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.9 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 114.4 | 2.4 | 0.1 | +0.0 | 12.5 | 4.5 |
| CANNON PLANNED TARGET | 7.3 | +148.0 | 483.0 | 79.7 | 0.9 | +35.0 | 58.8 | 22.8 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 17.1 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | -2.0 | 61.4 | 7.5 | 0.1 | +0.0 | 6.3 | 13.3 |
| CAST JOB | 1.2 | +37.8 | 55.8 | 20.1 | 0.2 | +1.1 | 10.7 | 6.4 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.8 | +62.7 | 63.7 | 0.0 | 0.1 | +0.9 | 0.0 | 13.6 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 24.5 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.7 | 0.0 | 0.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.1 | +48.2 | 0.0 | 17.4 | 0.7 | +23.7 | 0.0 | 7.2 |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 11.7 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.1 | +21.9 | 31.0 | 16.9 |
| CHARGE LOSSES | - | - | - | - | 5.7 | -327.9 | 0.0 | 191.2 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 2.5 | 5.8 | 0.1 | +0.0 | 15.2 | 1.6 |
| CHARGE NOW FIRST | 2.5 | +0.0 | 269.3 | 107.2 | 1.9 | +0.0 | 221.8 | 102.8 |
| CHARGE NOW WEIGHED | 0.5 | -36.3 | 15.1 | 4.7 | - | - | - | - |
| CHARGER SLAIN LOST | 0.8 | -27.2 | 69.2 | 31.0 | 0.6 | -15.7 | 86.7 | 19.9 |
| CHEAP HELPER | 0.1 | +0.0 | 5.2 | 4.4 | - | - | - | - |
| COMBAT PIVOT | 0.5 | +0.0 | 37.4 | 59.2 | 0.4 | +0.0 | 0.0 | 12.2 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 15.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.2 | +108.4 | 0.0 | 12.2 | 0.4 | +28.5 | 0.0 | 0.0 |
| COVER ONCE | 5.9 | -383.5 | 0.0 | 108.9 | 5.7 | -502.3 | 0.0 | 158.1 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 1.2 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +2.7 | 4.2 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.4 | +14.5 | 0.0 | 19.4 | 7.7 | +53.4 | 0.0 | 26.5 |
| EDGE GIVE GROUND | 0.2 | +2.1 | 12.2 | 5.6 | 0.1 | +11.8 | 10.7 | 4.9 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +3.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +154.5 | 0.0 | 40.5 | 0.0 | +5.4 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 3.1 | +6.8 | 298.5 | 116.7 |
| FALLBACK BY WORTH | 4.5 | +41.7 | 0.0 | 57.3 | 0.4 | +0.0 | 0.0 | 1.9 |
| FALLS SHORT | - | - | - | - | 19.0 | +247.3 | 0.0 | 273.3 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +4.6 | 0.0 | 10.4 |
| FIGHT LIFT | 0.3 | +3.4 | 13.4 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 1.6 | +118.1 | 181.7 | 102.8 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 8.2 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | - | - | - | - | 43.9 | +2808.3 | 522.3 | 736.8 |
| FLANK NOT WEIGHED | 4.5 | +0.0 | 0.0 | 92.2 | 5.6 | +0.0 | 0.0 | 94.0 |
| FOCUS FIRE | 0.0 | +0.2 | 4.3 | 0.0 | 0.0 | +0.5 | 2.1 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +98.4 | 0.0 | 40.8 | 0.7 | +139.9 | 0.0 | 15.6 |
| FOUR ROUNDS | - | - | - | - | 4.1 | +403.3 | 374.9 | 149.2 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.2 | -26.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.4 | +29.8 | 0.0 | 9.6 | 0.2 | +2.9 | 0.0 | 18.6 |
| GIVES UP | 0.2 | -0.7 | 2.5 | 5.6 | 0.2 | -6.0 | 26.8 | 0.0 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.5 | +19.1 | 45.2 | 47.1 | 0.7 | +3.2 | 2.1 | 9.0 |
| GUN MASK | - | - | - | - | 0.1 | +0.7 | 0.0 | 5.6 |
| HARD STAY DROPPED | - | - | - | - | 0.7 | +0.0 | 0.0 | 6.4 |
| HE SHOOTS OR CHARGES | - | - | - | - | 2.4 | +0.0 | 0.0 | 62.6 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 16.2 | - | - | - | - |
| HILL BY ITS CHANCE | 0.8 | -82.9 | 0.0 | 10.4 | - | - | - | - |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +37.2 | 29.3 | 31.0 |
| HIS CHARGE LIST | - | - | - | - | 4.0 | +0.0 | 0.0 | 71.7 |
| HIS FIGHT TOGETHER | - | - | - | - | 1.5 | -25.3 | 0.0 | 38.6 |
| HIS LEGAL MOVES | - | - | - | - | 3.6 | +0.0 | 0.0 | 51.1 |
| HIS MOVE AND SHOT | - | - | - | - | 2.4 | -63.7 | 0.0 | 87.5 |
| HIS OWN BEST MOVE | - | - | - | - | 2.8 | +0.0 | 0.0 | 40.7 |
| HIS RANDOM MOVE | - | - | - | - | 1.7 | +0.0 | 0.0 | 35.7 |
| HIS SHOT LIST | - | - | - | - | 25.8 | +1400.0 | 0.0 | 407.6 |
| HIS TURN DENIED | - | - | - | - | 2.1 | +91.9 | 182.7 | 53.9 |
| HOLDER ASSIGNMENT | - | - | - | - | 11.0 | +998.4 | 0.0 | 153.1 |
| HOLDER AT DEPLOYMENT | 0.7 | +121.7 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.8 | -143.8 | 448.3 | 220.7 | 3.3 | -147.1 | 279.4 | 127.3 |
| HUNT ADVANCE | 0.1 | +1.0 | 0.0 | 3.8 | - | - | - | - |
| HUNT DROPPED | 0.0 | +0.0 | 4.7 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +8.8 | 0.0 | 13.1 | 0.4 | +19.7 | 0.0 | 16.2 |
| HUNT RESULT | 0.1 | +0.0 | 4.7 | 3.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +18.6 | 0.0 | 3.8 | 0.0 | +7.4 | 0.0 | 0.0 |
| IDLE COST | 15.7 | -260.9 | 0.0 | 181.9 | 13.2 | -221.4 | 0.0 | 216.3 |
| INVITES THE FIGHT | 1.6 | +8.4 | 28.4 | 55.0 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 1.2 | +83.6 | 135.5 | 33.4 |
| JOINT CHARGE PLAN | 0.2 | +9.8 | 16.3 | 13.5 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -0.8 | 13.2 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | - | - | - | - | 0.1 | +23.5 | 25.9 | 6.1 |
| KEEP FALLS | 0.2 | +1.2 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +46.6 | 181.0 | 43.8 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.7 | +76.9 | 103.8 | 38.0 | - | - | - | - |
| KILLS COUNT NEXT TURN | 5.2 | +126.3 | 149.1 | 116.1 | - | - | - | - |
| LANE BY FIGURES | 0.7 | +21.1 | 0.0 | 0.0 | 1.0 | +61.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 5.3 | +0.0 | 275.8 | 260.8 |
| LONE CHARACTER SAFE SPOT | 0.3 | +17.0 | 7.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +25.3 | 0.0 | 0.0 | 0.2 | +23.2 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +3.6 | 21.9 | 2.7 | 0.2 | -0.1 | 13.7 | 0.0 |
| LOST CHARGE | 3.1 | -41.3 | 131.0 | 118.4 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.2 | -26.5 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.8 | +62.8 | 2.8 | 41.1 | 0.2 | +1.7 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | +6.7 | 0.0 | 5.2 | 1.4 | +38.8 | 0.0 | 16.1 |
| MARCH AT ESCAPER | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.1 | +3.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +14.2 | 0.0 | 16.6 | 0.6 | +40.8 | 0.0 | 13.6 |
| MARCH ODDS | 0.2 | +10.9 | 8.3 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +20.8 | 0.0 | 0.0 | 0.6 | +54.7 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 5.3 | +95.8 | 0.0 | 71.7 | 6.3 | +72.5 | 0.0 | 140.0 |
| MISSILES IN THE MOVE | 4.7 | +176.5 | 0.0 | 89.5 | 2.3 | +32.5 | 0.0 | 31.0 |
| MISSILES NEXT TURN | 5.3 | +107.5 | 0.0 | 90.8 | 3.1 | +23.9 | 0.0 | 36.4 |
| MODEL FACING | 0.3 | +49.9 | 0.0 | 4.1 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 7.1 | - | - | - | - |
| MOVE AND CAST | 0.7 | +33.9 | 0.0 | 26.1 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 2.8 | +0.0 | 18.2 | 16.6 |
| MOVE SPELL IN RANGE | 0.5 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -31.6 | 0.0 | 12.2 | 0.1 | -4.3 | 4.3 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.8 | +191.7 | 94.1 | 73.4 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 4.6 | +772.3 | 0.0 | 98.8 |
| MOVES UNITS SPELL | 0.1 | +4.1 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | - | - | - | - | 3.4 | +146.7 | 0.0 | 36.8 |
| NEEDED THERE | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | - | - | - | - | 5.3 | -219.9 | 10.7 | 116.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 5.4 | -172.0 | 36.0 | 88.5 |
| NO DOUBLE ROUNDS | - | - | - | - | 3.0 | -143.0 | 237.1 | 111.7 |
| NO RALLY LEFT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.4 | -17.7 | 95.9 | 9.3 | - | - | - | - |
| NOT TURNED | 4.5 | +84.9 | 0.0 | 74.7 | 0.4 | +3.8 | 0.0 | 2.9 |
| NOT WORTH A CAST | 0.9 | -0.6 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 16.9 | -784.1 | 6.6 | 286.0 | 1.2 | -34.5 | 0.0 | 0.9 |
| ONE CHARGE A CHARGER | - | - | - | - | 3.2 | +0.0 | 0.0 | 74.0 |
| ONE FIGHT FORMULA | 8.4 | -116.2 | 18.2 | 213.8 | 6.1 | -166.2 | 0.0 | 160.6 |
| ONE OBJECTIVE FORMULA | 2.4 | -134.7 | 0.0 | 36.2 | 2.7 | +30.5 | 0.0 | 63.3 |
| ONE TARGET A SHOOTER | - | - | - | - | 19.9 | +613.5 | 0.0 | 292.9 |
| OPENS A LANE | 0.4 | +7.1 | 33.8 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +12.2 | 10.4 | 15.2 | 0.1 | +4.8 | 13.2 | 0.0 |
| OVERRUNS AWAY | 0.6 | +22.1 | 28.7 | 29.1 | 0.6 | +16.6 | 51.3 | 3.9 |
| PATHS CROSS | 1.8 | +132.8 | 0.0 | 37.3 | 3.3 | +192.0 | 0.0 | 34.7 |
| PERIAPT WORTH | 0.0 | +4.2 | 0.0 | 0.0 | 0.1 | +5.4 | 0.0 | 18.6 |
| PIVOT GUARDS FLANK | 0.0 | -0.5 | 0.0 | 0.0 | 0.1 | -1.6 | 0.0 | 4.3 |
| PLAN RESULT | 40.5 | +1511.3 | 1305.9 | 875.7 | 40.3 | +419.1 | 278.4 | 961.6 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -2.3 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.6 | +7.1 | 0.0 | 5.9 | 2.7 | +64.0 | 0.0 | 27.2 |
| RANDOM MOVER NO PROMISE | 0.1 | -3.5 | 13.5 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.6 | -17.3 | 0.0 | 12.2 | 1.0 | -34.3 | 0.0 | 12.2 |
| REDIRECT COUNTER | 2.0 | +175.5 | 0.0 | 35.4 | 4.0 | +260.6 | 0.0 | 74.1 |
| REDIRECT WEIGHED | 0.3 | +6.8 | 0.0 | 15.2 | 0.2 | +2.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.1 | -19.6 | 0.0 | 4.3 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +6.5 | 0.0 | 18.3 | 0.3 | +18.6 | 0.0 | 7.4 |
| RESTRAINS TO SHOOT | 0.1 | +5.9 | 0.0 | 6.4 | 0.1 | +7.1 | 0.0 | 5.0 |
| RISK BY ARC | 3.2 | +106.1 | 295.7 | 157.7 | 2.5 | +9.9 | 243.6 | 94.9 |
| RISK BY HIS FIGURE | - | - | - | - | 14.0 | -210.9 | 0.0 | 330.5 |
| RISK ONCE | 1.8 | +33.5 | 14.4 | 50.8 | - | - | - | - |
| RUN DOWN | - | - | - | - | 3.0 | -25.9 | 197.8 | 95.3 |
| SAFER THAN THE JOB | 0.8 | +38.2 | 0.0 | 7.8 | 0.0 | +5.9 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -1.5 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.2 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.4 | -39.0 | 0.0 | 0.0 | 0.5 | -37.3 | 0.0 | 0.9 |
| SEARCH SPOT | 3.0 | +156.6 | 0.0 | 56.4 | 7.1 | +330.8 | 0.0 | 158.1 |
| SELF MOVE SPELL | 0.2 | +62.6 | 0.0 | 0.0 | 0.7 | +43.5 | 0.0 | 22.5 |
| SET UP BY THE SET | - | - | - | - | 0.8 | +13.8 | 4.0 | 13.3 |
| SET UP TOGETHER | 1.5 | +136.5 | 29.9 | 56.8 | 0.3 | +3.8 | 0.0 | 17.6 |
| SET-UP ANY TARGET | 0.5 | +95.7 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.1 | +13.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +44.3 | 26.8 | 31.5 | 0.6 | +41.3 | 25.7 | 10.9 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.1 | -1.0 | 15.9 | 0.0 |
| SHOT RISK POINTS | - | - | - | - | 13.4 | +21.2 | 0.0 | 312.6 |
| SHOTS IN THE MOVE | 16.8 | +595.3 | 0.0 | 253.9 | 8.3 | +249.7 | 0.0 | 154.1 |
| SPELL SETS UP CHARGE | 0.6 | +104.1 | 0.0 | 0.0 | 0.0 | +24.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +24.3 | 41.0 | 52.1 | 2.8 | +61.8 | 89.0 | 85.7 |
| SPELLS IN THE FIGHT | 1.3 | -5.1 | 203.7 | 44.8 | 1.0 | +0.4 | 56.6 | 59.1 |
| STABLE ROLE | 11.2 | +0.0 | 253.1 | 215.4 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.9 | -12.6 | 63.3 | 14.9 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 19.6 |
| STANDS STILL | - | - | - | - | 9.0 | +0.0 | 147.4 | 116.2 |
| STAY WEIGHED | 0.0 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 23.3 | +33.8 | 466.7 | 229.5 | 7.7 | +56.2 | 64.0 | 104.8 |
| STOPS | - | - | - | - | 0.0 | +4.1 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +16.8 | 0.0 | 14.1 | - | - | - | - |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.3 | -51.4 | 300.1 | 106.0 | 1.3 | +0.0 | 101.5 | 73.1 |
| SUPPORTS | 3.0 | +51.6 | 103.2 | 33.7 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.8 | 22.8 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.7 | +16.7 | 2.8 | 39.7 | 0.6 | +6.3 | 0.0 | 18.5 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 3.2 | +0.0 | 0.0 | 30.7 |
| THE PROMISE ADDS | - | - | - | - | 0.1 | -8.9 | 0.0 | 4.9 |
| THE PROMISED MOVE | - | - | - | - | 1.9 | +0.0 | 0.0 | 37.7 |
| THROUGH LINE OF FIRE | 0.4 | +21.5 | 0.0 | 1.3 | - | - | - | - |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +71.9 | 73.6 | 18.2 |
| TIME ON OUR SIDE | - | - | - | - | 2.9 | +38.5 | 0.0 | 36.9 |
| TURN WORTH | 0.5 | -37.0 | 48.3 | 2.9 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.8 | +7.0 | 13.6 | 47.7 | - | - | - | - |
| WAIT AFTER COSTS | 7.3 | -301.7 | 202.4 | 168.2 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.2 | +0.0 | 0.0 | 15.9 |
| WALKS TO THE FIGHT | 1.8 | +14.1 | 58.4 | 64.8 | - | - | - | - |
| WAR ENGINE CHARGES | 0.0 | +1.6 | 0.0 | 10.7 | 0.0 | +1.9 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 21.0 | 32.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 1.5 | +67.2 | 186.8 | 79.9 | - | - | - | - |
| WHO HITS BACK | 0.3 | +23.3 | 0.0 | 18.8 | 0.3 | +25.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +1.6 | 37.1 | 26.7 | 0.6 | +35.7 | 108.9 | 15.3 |
| WHOLE FIGHT GAIN | 0.3 | +12.2 | 21.3 | 5.8 | 0.3 | +10.7 | 11.9 | 1.6 |
| WIDER SPREAD | 2.9 | -9.1 | 276.5 | 105.4 | 3.0 | -10.6 | 278.0 | 111.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 0.6 | +42.4 | 0.0 | 25.4 |

### Rule changes: t10-opp-ba3e30a-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 525 | 525 | 525 | 18.10 | -23738 | -45.2 |
| ARMY TABLE | 428 | 428 | 308 | 10.62 | +4335 | +14.1 |
| DEPLOY BY FIGURES | 467 | 467 | 307 | 10.59 | +4696 | +15.3 |
| HOLDER ASSIGNMENT | 320 | 320 | 299 | 10.31 | +13291 | +44.5 |
| SEARCH SPOT | 294 | 294 | 277 | 9.55 | +14139 | +51.0 |
| HIS SHOT LIST | 747 | 732 | 216 | 7.45 | +5886 | +27.3 |
| LEGAL CHARGES ONLY | 154 | 154 | 154 | 5.31 | +0 | +0.0 |
| PATHS CROSS | 146 | 146 | 146 | 5.03 | +9419 | +64.5 |
| FIVE ACTION | 1273 | 1255 | 126 | 4.34 | +7240 | +57.5 |
| ONE TARGET A SHOOTER | 578 | 565 | 124 | 4.28 | +2223 | +17.9 |
| MOVE ORDER | 80 | 80 | 80 | 2.76 | +0 | +0.0 |
| SHOTS IN THE MOVE | 728 | 584 | 80 | 2.76 | +2237 | +28.0 |
| SHOT RISK POINTS | 388 | 382 | 78 | 2.69 | +2939 | +37.7 |
| MOVE TO CHARGE COMPUTED | 134 | 132 | 68 | 2.34 | +8338 | +122.6 |
| MOVE TO CHARGE | 110 | 110 | 63 | 2.17 | +1492 | +23.7 |
| ADVANCE LANE KEPT | 62 | 62 | 62 | 2.14 | +0 | +0.0 |
| COVER ONCE | 337 | 232 | 62 | 2.14 | +1081 | +17.4 |
| ARTILLERY RE-ROLL WEIGHED | 59 | 59 | 59 | 2.03 | +0 | +0.0 |
| FACES THE THREAT | 59 | 59 | 59 | 2.03 | +4635 | +78.6 |
| RANDOM MOVE BY FIGURES | 95 | 95 | 59 | 2.03 | +2062 | +35.0 |
| IDLE COST | 839 | 562 | 57 | 1.97 | +629 | +11.0 |
| MAX FOR POSITIONING | 337 | 277 | 56 | 1.93 | +224 | +4.0 |
| BEST FIRST | 52 | 52 | 52 | 1.79 | +2552 | +49.1 |
| LANE BY FIGURES | 50 | 50 | 50 | 1.72 | +2390 | +47.8 |
| FOUR ROUNDS | 120 | 120 | 46 | 1.59 | +3078 | +66.9 |
| KILLS COUNT NEXT TURN | 151 | 151 | 45 | 1.55 | +775 | +17.2 |
| WAIT AFTER COSTS | 212 | 212 | 45 | 1.55 | +619 | +13.8 |
| FOLLOW UP WEIGHED | 44 | 44 | 44 | 1.52 | +6910 | +157.0 |
| CHAFF IN THE MOVE | 53 | 52 | 41 | 1.41 | +692 | +16.9 |
| RISK BY ARC | 164 | 161 | 40 | 1.38 | +1172 | +29.3 |
| SUPPORTS | 88 | 88 | 37 | 1.28 | +462 | +12.5 |
| CANNON PLANNED TARGET | 238 | 238 | 36 | 1.24 | -223 | -6.2 |
| REDIRECT COUNTER | 175 | 131 | 36 | 1.24 | +3676 | +102.1 |
| CANNON SIGHT KEPT | 35 | 35 | 35 | 1.21 | +0 | +0.0 |
| JOINT CHARGE NOW | 35 | 35 | 35 | 1.21 | +2424 | +69.3 |
| FALLS SHORT | 552 | 494 | 34 | 1.17 | +76 | +2.2 |
| MISSILES IN THE MOVE | 204 | 143 | 32 | 1.10 | +830 | +25.9 |
| STAY WORTH | 900 | 791 | 32 | 1.10 | +434 | +13.6 |
| BEST MOVE FOR SHOOTERS | 31 | 31 | 31 | 1.07 | +1876 | +60.5 |
| CHARGE NOW FIRST | 127 | 127 | 31 | 1.07 | -1686 | -54.4 |
| MANOEUVRE | 49 | 49 | 29 | 1.00 | +1324 | +45.7 |
| ONE FIGHT FORMULA | 421 | 265 | 28 | 0.97 | +114 | +4.1 |
| FALLBACK BY WORTH | 141 | 141 | 27 | 0.93 | +1208 | +44.7 |
| SET UP TOGETHER | 53 | 49 | 27 | 0.93 | +1194 | +44.2 |
| ADVANCE WORTH | 168 | 168 | 26 | 0.90 | +268 | +10.3 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.90 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 51 | 51 | 24 | 0.83 | +743 | +31.0 |
| LONE WIZARD KEPT IN | 23 | 23 | 23 | 0.79 | +1407 | +61.2 |
| MARCH CHECK | 26 | 26 | 23 | 0.79 | +1446 | +62.9 |
| SAFER THAN THE JOB | 23 | 23 | 23 | 0.79 | +1278 | +55.6 |
| CAST JOB | 40 | 40 | 22 | 0.76 | +326 | +14.8 |
| HOLDS AMBUSHERS | 22 | 22 | 22 | 0.76 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 157 | 156 | 22 | 0.76 | +345 | +15.7 |
| CASTER AWAY FROM SCREEN | 20 | 20 | 20 | 0.69 | +0 | +0.0 |
| HARD STAY DROPPED | 20 | 20 | 20 | 0.69 | +0 | +0.0 |
| MOVE AND CAST | 20 | 20 | 20 | 0.69 | +982 | +49.1 |
| WALKS TO THE FIGHT | 51 | 51 | 20 | 0.69 | +77 | +3.9 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.62 | +951 | +52.8 |
| TIED UP BY THE SUM | 20 | 20 | 18 | 0.62 | +841 | +46.7 |
| HONEST WORTH | 352 | 350 | 17 | 0.59 | +112 | +6.6 |
| WHO HITS BACK | 17 | 17 | 17 | 0.59 | +863 | +50.8 |
| HIS TURN DENIED | 62 | 62 | 16 | 0.55 | +634 | +39.6 |
| RESERVE FALL BACK | 16 | 16 | 16 | 0.55 | +728 | +45.5 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.55 | +32 | +2.0 |
| STUCK PIVOT | 16 | 16 | 16 | 0.55 | +0 | +0.0 |
| SCOUT WAITS | 15 | 15 | 15 | 0.52 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 14 | 14 | 14 | 0.48 | +818 | +58.4 |
| KILLS COUNT | 50 | 49 | 14 | 0.48 | +554 | +39.6 |
| SUPPORT NARROWED | 193 | 193 | 14 | 0.48 | -369 | -26.3 |
| BEST FACING | 13 | 13 | 13 | 0.45 | +146 | +11.3 |
| CASTING BLOCK | 25 | 25 | 13 | 0.45 | +639 | +49.2 |
| CHARGE LOSSES | 166 | 164 | 13 | 0.45 | +817 | +62.8 |
| INVITES THE FIGHT | 46 | 46 | 13 | 0.45 | +75 | +5.7 |
| NEXT CHARGE BY LIST | 154 | 151 | 13 | 0.45 | +353 | +27.1 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.45 | +527 | +40.6 |
| STOPS SHORT OF THE FLANK | 12 | 12 | 12 | 0.41 | +488 | +40.6 |
| THROUGH LINE OF FIRE | 12 | 12 | 12 | 0.41 | +624 | +52.0 |
| CHARGE NOT DECLARED | 11 | 11 | 11 | 0.38 | -841 | -76.5 |
| FIGHT TO THE END | 46 | 46 | 11 | 0.38 | +1030 | +93.7 |
| RISK BY HIS FIGURE | 406 | 396 | 11 | 0.38 | +791 | +71.9 |
| TIME ON OUR SIDE | 83 | 73 | 11 | 0.38 | +14 | +1.3 |
| BLOCKED WHEEL | 10 | 10 | 10 | 0.34 | +266 | +26.6 |
| FIRE IN ORDER | 10 | 10 | 10 | 0.34 | +0 | +0.0 |
| HIS MOVE AND SHOT | 69 | 69 | 10 | 0.34 | +257 | +25.7 |
| MODEL FACING | 10 | 10 | 10 | 0.34 | +1447 | +144.7 |
| RISK ONCE | 52 | 42 | 10 | 0.34 | +177 | +17.7 |
| SURE REACH TOGETHER | 36 | 31 | 10 | 0.34 | +55 | +5.5 |
| WEARS DOWN | 44 | 41 | 10 | 0.34 | +167 | +16.7 |
| BEST OVERALL | 9 | 9 | 9 | 0.31 | +415 | +46.1 |
| MAKE SURE TOGETHER | 27 | 16 | 9 | 0.31 | +125 | +13.9 |
| SET UP BY THE SET | 23 | 23 | 9 | 0.31 | +589 | +65.4 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.31 | +0 | +0.0 |
| OPENS UP | 13 | 13 | 8 | 0.28 | +135 | +16.9 |
| WIDER SPREAD | 173 | 168 | 8 | 0.28 | +28 | +3.5 |
| BEST PRIZE | 7 | 7 | 7 | 0.24 | -491 | -70.2 |
| MISSILES NEXT TURN | 244 | 167 | 7 | 0.24 | +48 | +6.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.24 | +138 | +19.7 |
| ONE OBJECTIVE FORMULA | 148 | 109 | 7 | 0.24 | +156 | +22.3 |
| WHOLE FIGHT GAIN | 16 | 14 | 7 | 0.24 | +167 | +23.9 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.21 | -25 | -4.2 |
| HOLDER AT DEPLOYMENT | 21 | 21 | 6 | 0.21 | +280 | +46.7 |
| KEEP FALLS | 6 | 6 | 6 | 0.21 | +197 | +32.8 |
| NEARER NOT NEEDED | 100 | 98 | 6 | 0.21 | +117 | +19.5 |
| OVERRUNS AWAY | 33 | 33 | 6 | 0.21 | +148 | +24.6 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.21 | +376 | +62.7 |
| WHOLE FIGHT | 22 | 22 | 6 | 0.21 | +274 | +45.7 |
| WOUNDS ON THE RANKS | 18 | 18 | 6 | 0.21 | +197 | +32.8 |
| CHAFF PASSED | 5 | 5 | 5 | 0.17 | -2 | -0.3 |
| HIS FIGHT TOGETHER | 43 | 41 | 5 | 0.17 | +102 | +20.4 |
| MARCH ODDS | 5 | 5 | 5 | 0.17 | +106 | +21.2 |
| BACKUP TARGETS | 31 | 14 | 4 | 0.14 | +5 | +1.3 |
| BEST PREY | 10 | 10 | 4 | 0.14 | +90 | +22.4 |
| CHARGE LIST READ AGAIN | 4 | 4 | 4 | 0.14 | +634 | +158.4 |
| HIS CHARGE DENIED | 20 | 20 | 4 | 0.14 | +196 | +49.1 |
| HUNT IN PAIRS | 22 | 12 | 4 | 0.14 | +121 | +30.2 |
| JOINT ON THE TABLE | 4 | 4 | 4 | 0.14 | +682 | +170.5 |
| KEEPS ITS TARGET | 45 | 44 | 4 | 0.14 | +74 | +18.5 |
| LONG SHOT | 21 | 21 | 4 | 0.14 | +63 | +15.7 |
| MARCH BY THE SUM | 4 | 4 | 4 | 0.14 | +100 | +25.0 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.14 | -62 | -15.4 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 0.10 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.10 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 87 | 87 | 3 | 0.10 | +57 | +18.9 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.10 | +278 | +92.6 |
| SPELLS IN THE FIGHT | 67 | 66 | 3 | 0.10 | +114 | +37.9 |
| WAR ENGINE JOBS | 17 | 17 | 3 | 0.10 | -112 | -37.3 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.07 | +153 | +76.3 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.07 | +59 | +29.6 |
| EDGE GIVE GROUND | 9 | 9 | 2 | 0.07 | +126 | +63.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.07 | +98 | +48.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.07 | +21 | +10.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.07 | +0 | +0.0 |
| LOST CHARGE | 90 | 88 | 2 | 0.07 | +39 | +19.6 |
| OPENS A LANE | 11 | 8 | 2 | 0.07 | +36 | +18.1 |
| REFUSING RETIRES | 12 | 12 | 2 | 0.07 | -1 | -0.4 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.07 | -138 | -69.2 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +32 | +32.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CARRIES OUT SET-UP | 8 | 8 | 1 | 0.03 | -57 | -56.7 |
| DEFENSIVE ARMY | 4 | 4 | 1 | 0.03 | -38 | -38.3 |
| FEATURE BUFFS | 10 | 10 | 1 | 0.03 | +24 | +23.5 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +6 | +6.0 |
| JOINT CHARGE PLAN | 7 | 7 | 1 | 0.03 | +61 | +61.4 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -68 | -67.5 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | -1 | -0.7 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +167 | +167.2 |
| STOPS | 1 | 1 | 1 | 0.03 | +56 | +56.3 |
| TURN WORTH | 15 | 15 | 1 | 0.03 | +18 | +17.8 |
| TWO OR MORE ARRIVE | 23 | 17 | 1 | 0.03 | +13 | +12.9 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +11 | +10.9 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 17 | 16 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 52 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 39 | 37 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 45 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 3 | 3 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 90 | 90 | 0 | 0.00 | - | - |
| FIGHT LIFT | 9 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 292 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 6 | 6 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 10 | 10 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 65 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 71 | 70 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 23 | 23 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 117 | 112 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 103 | 99 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 82 | 78 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 48 | 48 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 2 | 2 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 10 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 14 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 27 | not checked | - | - | - | - |
| NOT NEEDED | 12 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 141 | 141 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 30 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 94 | 91 | 0 | 0.00 | - | - |
| PLAN RESULT | 2343 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 48 | 48 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 32 | 31 | 0 | 0.00 | - | - |
| RUN DOWN | 88 | 88 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 13 | 13 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 27 | 27 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 27 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 17 | not checked | - | - | - | - |
| SPELL WORTH | 119 | not checked | - | - | - | - |
| STABLE ROLE | 324 | 323 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 27 | 27 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 20 | 20 | 0 | 0.00 | - | - |
| STANDS STILL | 262 | 255 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 92 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 56 | not checked | - | - | - | - |
| WAITS AGAIN | 35 | 35 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: t10-opp-ba3e30a-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.69 | 0.41 | 47.1 |
| ARMY TABLE | rule | - | 1.66 | 32.0 |
| HOLDER ASSIGNMENT | rule | - | 1.24 | 26.0 |
| CHARGE NOW FIRST | rule | 0.52 | 0.55 | 54.4 |
| NO REASON | gate | - | 0.59 | 26.7 |
| FALLBACK | gate | 0.45 | 0.03 | 17.5 |
| SUPPORT NARROWED | rule | 0.41 | 0.07 | 26.3 |
| JOINT CHARGE NOW | rule | - | 0.41 | 38.2 |
| PATHS CROSS | rule | - | 0.41 | 22.7 |
| TURN GATE | gate | 0.31 | - | 76.0 |
| CANNON PLANNED TARGET | rule | 0.28 | - | 44.2 |
| BEST PRIZE | rule | 0.07 | 0.17 | 70.2 |
| CHARGE NOT DECLARED | rule | 0.10 | 0.14 | 134.9 |
| FIGHT ORDER BAND | gate | 0.10 | 0.07 | 2.9 |
| SUPPORT REQUEST | gate | 0.17 | - | 21.4 |
| DEPLOY BY FIGURES | rule | 0.07 | 0.07 | 5.4 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.10 | 15.4 |
| BIG CHARACTER SAFETY | rule | 0.10 | - | 10.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.07 | 0.03 | 6.7 |
| WAR ENGINE JOBS | rule | 0.10 | - | 37.3 |
| AFTERMATH BAND | gate | 0.03 | 0.03 | 3.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.07 | - | 95.2 |
| SAFER THAN THE JOB | rule | 0.07 | - | 11.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.07 | - | 69.2 |
| BLOCKED WHEEL | rule | 0.03 | - | 5.8 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 56.7 |
| CHAFF PASSED | rule | 0.03 | - | 1.6 |
| CHARGE NOW WEIGHED | rule | 0.03 | - | 70.8 |
| DEFENSIVE ARMY | rule | 0.03 | - | 38.3 |
| FACES THE THREAT | rule | 0.03 | - | 8.8 |
| PURSUES BIG PREY | rule | - | 0.03 | 67.5 |
| PURSUES ON | rule | 0.03 | - | 0.7 |
| REDIRECT WEIGHED | rule | 0.03 | - | 37.4 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| RULE SWITCHED OFF | gate | 0.03 | - | 24.3 |
| SET UP BY THE SET | rule | - | 0.03 | 84.2 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 3.8 |
| WHO HITS BACK | rule | 0.03 | - | 4.5 |

### Plans: t10-opp-ba3e30a-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.1 | 14% | 135 | 222 | 165% |
| Mine | charge | 3.5 | 56% | 246 | 296 | 121% |
| Mine | close in | 4.9 | 21% | 265 | 90 | 34% |
| Mine | hold | 5.3 | 32% | 370 | 0 | 0% |
| Mine | join | 0.3 | 100% | 5 | 0 | 0% |
| Mine | shoot | 12.4 | 62% | 358 | 903 | 252% |
| Mine | support | 4.0 | 91% | 42 | 0 | 0% |
| Opponent | charge | 3.2 | 62% | 630 | 312 | 50% |
| Opponent | join | 0.7 | 100% | 39 | 0 | 0% |
| Opponent | move | 32.8 | 92% | 1898 | 0 | 0% |
| Opponent | shoot | 2.4 | 63% | 86 | 107 | 124% |
| Opponent | support | 1.2 | 81% | 7 | 0 | 0% |

### Packages: hunt the guns, t10-opp-ba3e30a-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 270 | 0 | 0% | 9 |
| Opponent | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 214 | 0 | 0% | 103 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 310 | 0 | 0% | 55 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 231 | 0 | 0% | 24 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 86 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 108 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 237 |
| Warriors of Chaos | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 214 | 0 | 0% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 90 |

### Battle groups: t10-opp-ba3e30a-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 32% | 63% | 0% | - | 26% | 5% | 5% | 58% | 5% |
| Opponent | REDIRECT COUNTER | 4.0 | 28% | 73% | 21% | 29% | 19% | 0% | 19% | 62% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t10-opp-ba3e30a-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 38 | 0% | 4.8 | 0 (4) | - | - | 0 (1) | 0 (3) |
| Mine | Chaff | 18 | 106 (18) | 6 | 100 | 37 | 44% | 3.0 | 97 (7) | 121 (10) | 0 (1) | 110 (16) | 67 (2) |
| Mine | Character | 93 | 39 (93) | 37 | 1 | 23 | 23% | 2.4 | 23 (48) | 62 (30) | 50 (12) | 41 (53) | 38 (37) |
| Mine | Clean-up | 21 | 84 (21) | 33 | 50 | 58 | 19% | 3.1 | 58 (9) | 124 (10) | 77 (2) | 122 (12) | 37 (9) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | Fast Hammer | 32 | 40 (32) | 33 | 8 | 39 | 25% | 2.5 | 40 (14) | 39 (14) | 52 (4) | 53 (15) | 30 (17) |
| Mine | Hammer | 54 | 24 (54) | 13 | 11 | 30 | 17% | 2.5 | 22 (21) | 31 (27) | 0 (6) | 25 (34) | 22 (20) |
| Mine | Holder | 19 | 95 (19) | 26 | 68 | 18 | 42% | 4.0 | 11 (7) | 167 (7) | 96 (5) | 91 (12) | 100 (7) |
| Mine | Shooter | 32 | 83 (32) | 29 | 55 | 47 | 3% | 1.9 | 57 (10) | 102 (15) | 73 (7) | 95 (23) | 48 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 44 (56) | 44 | 0 | 27 | 2% | 1.4 | 48 (30) | 50 (20) | 0 (6) | 66 (14) | 36 (42) |
| Mine | Wizard | 13 | 2 (13) | 2 | 0 | 18 | 23% | 3.0 | 0 (3) | 3 (7) | 0 (1) | 0 (4) | 3 (7) |
| Opponent | Chaff | 53 | 44 (53) | 6 | 38 | 61 | 42% | 3.1 | 38 (26) | 53 (11) | 47 (16) | 57 (38) | 16 (15) |
| Opponent | Character | 75 | 38 (75) | 38 | 0 | 24 | 21% | 2.4 | 26 (32) | 43 (31) | 69 (7) | 37 (37) | 39 (33) |
| Opponent | Clean-up | 15 | 23 (15) | 15 | 9 | 27 | 40% | 2.8 | 31 (8) | 29 (4) | 0 (3) | 21 (10) | 25 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 41 | 34 (41) | 13 | 21 | 58 | 27% | 2.9 | 28 (13) | 49 (19) | 17 (9) | 41 (22) | 27 (19) |
| Opponent | Fragile | 13 | 61 (13) | 61 | 0 | 27 | 31% | 3.9 | 0 (4) | 0 (6) | 288 (3) | 0 (8) | 178 (5) |
| Opponent | Hammer | 54 | 44 (54) | 28 | 16 | 30 | 39% | 3.2 | 30 (17) | 47 (28) | 60 (9) | 48 (35) | 38 (19) |
| Opponent | Holder | 23 | 35 (23) | 0 | 35 | 28 | 74% | 3.7 | 12 (7) | 48 (14) | 0 (2) | 64 (11) | 8 (12) |
| Opponent | Shooter | 35 | 57 (35) | 22 | 35 | 42 | 9% | 1.5 | 71 (13) | 58 (16) | 24 (6) | 56 (19) | 59 (16) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | War machine | 6 | 42 (6) | 42 | 0 | 70 | 0% | 1.2 | 16 (3) | 80 (3) | - | 16 (3) | 80 (3) |
| Opponent | Wizard | 14 | 15 (14) | 15 | 0 | 26 | 14% | 2.0 | 26 (7) | 6 (3) | 0 (1) | 3 (6) | 36 (5) |

### Charged fights: t10-opp-ba3e30a-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 184 | 226 | 2.5 | 1.4 | 90 | 14 | +77 | 2 of 10 | 8 of 10 | +119 | +48 |
| Mine | Chaos Dwarfs | 4 | 62 | 238 | 4.0 | 1.1 | 60 | 4 | +55 | 5 of 16 | 14 of 16 | +60 | +55 |
| Mine | Dwarfen Mountain Holds | 3 | 573 | 0 | 1.7 | 1.0 | 0 | 0 | +0 | 3 of 5 | 5 of 5 | - | +0 |
| Mine | Empire of Man | 5 | 383 | 182 | 2.2 | 1.2 | 83 | 35 | +48 | 2 of 11 | 9 of 11 | +118 | +33 |
| Mine | Grand Cathay | 4 | 508 | 344 | 2.0 | 1.1 | 172 | 94 | +79 | 2 of 8 | 5 of 7 | +287 | +49 |
| Mine | High Elf Realms | 4 | 68 | 128 | 2.2 | 1.1 | 57 | 94 | -36 | 3 of 9 | 5 of 9 | +186 | -64 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 587 | 5.0 | 1.0 | 117 | 0 | +117 | 3 of 5 | 3 of 5 | - | +117 |
| Mine | Lizardmen | 1 | 0 | 1240 | 4.0 | 1.5 | 310 | 0 | +310 | 2 of 4 | 4 of 4 | +620 | +0 |
| Mine | Ogre Kingdoms | 2 | 79 | 51 | 3.0 | 1.0 | 17 | 36 | -19 | 5 of 6 | 2 of 6 | - | -19 |
| Mine | Skaven | 1 | 55 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 29 | 248 | 227 | 2.6 | 1.2 | 88 | 32 | +56 | 28 of 75 | 56 of 74 | +212 | +26 |
| Opponent | Empire of Man | 1 | 408 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | High Elf Realms | 5 | 83 | 256 | 3.6 | 1.1 | 71 | 49 | +22 | 10 of 18 | 9 of 18 | +65 | +20 |
| Opponent | Lizardmen | 2 | 146 | 325 | 2.5 | 1.0 | 130 | 100 | +30 | 4 of 5 | 5 of 5 | - | +30 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 317 | 3.3 | 1.0 | 95 | 6 | +90 | 3 of 10 | 7 of 10 | - | +90 |
| Opponent | Skaven | 4 | 171 | 0 | 1.0 | 1.0 | 0 | 50 | -50 | 2 of 4 | 1 of 4 | - | -50 |
| Opponent | Tomb Kings of Khemri | 1 | 60 | 712 | 7.0 | 1.3 | 102 | 9 | +92 | 4 of 7 | 5 of 7 | -33 | +142 |
| Opponent | Vampire Counts | 4 | 0 | 424 | 4.0 | 1.0 | 106 | 42 | +64 | 8 of 16 | 13 of 16 | - | +64 |
| Opponent | Warriors of Chaos | 5 | 32 | 292 | 2.6 | 1.0 | 112 | 11 | +102 | 5 of 13 | 11 of 13 | - | +102 |
| Opponent | Wood Elf Realms | 4 | 8 | 246 | 3.0 | 1.4 | 82 | 8 | +74 | 7 of 12 | 6 of 12 | +125 | +57 |
| **Opponent** | all armies | 29 | 71 | 267 | 3.0 | 1.1 | 90 | 30 | +60 | 43 of 86 | 58 of 86 | +62 | +60 |

### Effective charges: t10-opp-ba3e30a-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 4 (net +42) | 0 | 1 (net +123) | 2 (net +49) | 0 | 3 (net +127) | 0 | 10% (1 of 10) |
| Mine | Chaos Dwarfs | 16 | 0 | 1 (net +0) | 0 | 3 (net +98) | 2 (net +92) | 9 (net +32) | 1 | 0% (0 of 15) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 1 | 25% (1 of 4) |
| Mine | Empire of Man | 11 | 0 | 0 | 2 (net +174) | 3 (net -127) | 1 (net +85) | 4 (net +120) | 1 | 20% (2 of 10) |
| Mine | Grand Cathay | 8 | 0 | 0 | 2 (net +260) | 3 (net -79) | 2 (net +174) | 0 | 1 | 29% (2 of 7) |
| Mine | High Elf Realms | 9 | 2 (net -200) | 0 | 1 (net +0) | 2 (net +168) | 0 | 3 (net +59) | 1 | 12% (1 of 8) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +210) | 0 | 0 | 2 (net +28) | 1 (net +322) | 0 | 1 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 1 (net +0) | 0 | 1 (net +1240) | 1 (net +0) | 0 | 0 | 1 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 6 | 2 (net -45) | 0 | 0 | 0 | 0 | 2 (net +51) | 2 | 0% (0 of 4) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | High Elf Realms | 18 | 3 (net -95) | 0 | 4 (net -147) | 6 (net +134) | 0 | 4 (net +119) | 1 | 24% (4 of 17) |
| Opponent | Lizardmen | 5 | 2 (net +258) | 0 | 0 | 2 (net -250) | 0 | 1 (net +135) | 0 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 10 | 1 (net +0) | 0 | 0 | 1 (net +185) | 0 | 3 (net +148) | 5 | 0% (0 of 5) |
| Opponent | Skaven | 4 | 1 (net +0) | 0 | 0 | 1 (net -157) | 0 | 1 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 7 | 2 (net +0) | 0 | 1 (net +0) | 2 (net +356) | 0 | 2 (net -33) | 0 | 14% (1 of 7) |
| Opponent | Vampire Counts | 16 | 2 (net +288) | 1 (net +0) | 1 (net +0) | 5 (net -87) | 4 (net +137) | 3 (net +115) | 0 | 6% (1 of 16) |
| Opponent | Warriors of Chaos | 13 | 2 (net -68) | 1 (net +151) | 0 | 1 (net +85) | 2 (net +77) | 5 (net +180) | 2 | 0% (0 of 11) |
| Opponent | Wood Elf Realms | 12 | 2 (net -51) | 1 (net +0) | 5 (net +137) | 4 (net +75) | 0 | 0 | 0 | 42% (5 of 12) |

### Charged fights, damage counted: t10-opp-ba3e30a-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 191 | 323 | -10 | 88 | 85 | +3 | +1.5 |
| Mine | 50-54% | 1 | 310 | 500 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 8 | 258 | 224 | +279 | 309 | 54 | +255 | +98.7 |
| Mine | 76-89% | 18 | 241 | 197 | +9 | 91 | 65 | +27 | +11.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 189 | 144 | +65 | 99 | 14 | +85 | +44.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 492 | 102 | +156 | 163 | 52 | +111 | +22.5 |
| Mine | No odds | 9 | 224 | 243 | -50 | 58 | 85 | -27 | -12.0 |
| Mine | All fights | 75 | 239 | 205 | +56 | 117 | 52 | +65 | +27.0 |
| Opponent | Long shot (under 50%) | 15 | 230 | 301 | +38 | 107 | 69 | +38 | +16.4 |
| Opponent | 50-54% | 3 | 95 | 234 | +50 | 50 | 0 | +50 | +53.0 |
| Opponent | Effective (55-75%) | 12 | 347 | 247 | +8 | 67 | 106 | -39 | -11.3 |
| Opponent | 76-89% | 22 | 308 | 238 | +45 | 122 | 85 | +37 | +12.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 311 | 192 | +118 | 162 | 12 | +150 | +48.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 470 | 108 | +117 | 117 | 0 | +117 | +24.9 |
| Opponent | No odds | 9 | 242 | 213 | +44 | 65 | 14 | +51 | +21.2 |
| Opponent | All fights | 86 | 298 | 228 | +60 | 112 | 53 | +59 | +19.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t10-opp-ba3e30a-p4 | move | 275 | 71 (26%) | 47 (17%) | 32 (12%) | 172 (63%) |
| t10-opp-ba3e30a-p4 | objective | 141 | 20 (14%) | 12 (9%) | 24 (17%) | 97 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Opponent | L0624, L1427 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

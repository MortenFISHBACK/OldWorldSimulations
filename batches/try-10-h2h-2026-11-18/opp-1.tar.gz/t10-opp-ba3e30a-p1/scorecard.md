# Doctrine scorecard: t10-opp-ba3e30a-p1

### Scorecard: t10-opp-ba3e30a-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 18 | 3 | 1 | 1 | 1 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 4 | 3 | 2 | 0 | 0 | 0 | 68 |
| L0135 | 3 | 1 | Mine | no | 5 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | yes | 2 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 274 |
| L0218 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 9 | 4 | 0 | 1 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 6 | - | 0 | 2 | 0 | 0 | 0 | 1157 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 139 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 145 |
| L0508 | 4 | 1 | Mine | no | 5 | 2 | 0 | 1 | 0 | 0 | 0 | 986 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 599 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 548 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 700 |
| L0612 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 615 |
| L0628 | 4 | 1 | Opponent | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 5 | 2 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0733 | 1 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0823 | 1 | 1 | Opponent | no | 8 | 2 | 4 | 2 | 2 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 375 |
| L0913 | 1 | 1 | Opponent | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 1 | 4 | 2 | 2 | 0 | 0 | 0 | 757 |
| L0930 | 6 | 1 | Opponent | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 500 |
| L1114 | 4 | 1 | Mine | no | 12 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 123 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | - | 1 | 4 | 3 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 5 | 5 | 3 | 0 | 0 | 0 | 0 | 524 |
| L1224 | 6 | 1 | Opponent | no | 1 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 1 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 8 | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 1 | - | 1 | 3 | 0 | 0 | 0 | 499 |
| L1431 | 3 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 657 |
| L1527 | 3 | 1 | Mine | no | 7 | 2 | 4 | 0 | 0 | 0 | 0 | 126 |
| L1527 | 3 | 1 | Opponent | no | 0 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 9 | 5 | 3 | 0 | 0 | 0 | 0 | 175 |
| L1723 | 1 | 1 | Opponent | yes | 0 | 2 | 8 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 6 | 4 | 1 | 0 | 0 | 0 | 185 |
| L1823 | 5 | 1 | Opponent | yes | - | 3 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | yes | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | no | 7 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 2 | - | 0 | 5 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 0 | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | no | - | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 1 | 3 | 2 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 2 | 3 | 10 | 3 | 0 | 0 | 0 | 250 |
| L2730 | 6 | 1 | Opponent | no | 4 | 3 | 0 | 0 | 0 | 0 | 0 | 479 |
| **Average** | | | Mine | 15% | 4.0 | 2.8 | 2.3 | 1.1 | 0.2 | 0.0 | 0.0 | 283.7 |
| **Average** | | | Opponent | 27% | 2.6 | 2.3 | 2.7 | 1.6 | 0.3 | 0.0 | 0.0 | 144.2 |

### KPIs: t10-opp-ba3e30a-p1

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 35 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (46 of 172) | 2% (4 of 173) | 14% (50 of 345) |
| Winner chose to follow up after the loser gave ground |  | 92% (34 of 37); on the table 95% | 81% (42 of 52); on the table 83% | 85% (76 of 89); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 86% | 33% (2 of 6); on the table 50% | 62% (8 of 13); on the table 69% |
| Winner chose to pursue after the loser fled |  | 50% (10 of 20); on the table 55% | 72% (18 of 25); on the table 72% | 62% (28 of 45); on the table 64% |
| Winner chose to follow up or pursue (all three) |  | 78% (50 of 64); on the table 81% | 75% (62 of 83); on the table 77% | 76% (112 of 147); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 37% (122 of 330) | 34% (71 of 210) | 36% (193 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (122 of 253) | 42% (71 of 171) | 46% (193 of 424) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (18 of 27) | 60% (29 of 48) | 63% (47 of 75) |
| Points that never fought | lower | 41% (28617 of 69485) | 42% (29484 of 69891) | 42% (58101 of 139376) |
|   infantry points that never fought | lower | 61% (10000 of 16418) | 67% (8608 of 12835) | 64% (18608 of 29253) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (162 of 272) | 56% (161 of 287) | 58% (323 of 559) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 2.1 uses a game | 70% (14 of 20); 1.2 uses a game | 81% (34 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.6 uses a game | 38% (3 of 8); 0.1 uses a game | 46% (11 of 24); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 42% (8 of 19); 0.2 uses a game | 55% (6 of 11); 0.2 uses a game | 47% (14 of 30); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (31740 of 57782) | 51% (31097 of 60993) | 53% (62837 of 118775) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (31%) | 1.8 (45%) | 3.7 (37%) |
| MARCHED: its unit marched | 1.2 (21%) | 0.7 (18%) | 1.9 (20%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (1%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.2 (20%) | 0.5 (12%) | 1.7 (17%) |
| REAR RANK: in a rear rank | 0.4 (6%) | 0.1 (1%) | 0.4 (4%) |
| GONE: slain | 0.9 (15%) | 0.4 (10%) | 1.3 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (6%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.7 | 1.3 | 5.5 | 0.6 | 1.6 |
| not cast | 3.6 | 2.8 | 3.5 | 9.9 | 1.8 | 22.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (62%) | 0.3 (10%) | 3.7 (37%) | 0.5 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (20%) | 0.2 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (4%) | 0.5 (14%) | 1.7 (17%) | 0.4 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.3 (12%) | 0.5 (14%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.6 (17%) | 0.3 (9%) | 0.6 (18%) | 1.3 (13%) | 0.1 (8%) | 2.2 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) | 0.1 (1%) | 0.5 (25%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (61%) | 0.1 (4%) | 1.5 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.6 a game | 0.8 a game |
| stood (cast and not dispelled) | 69% (22 of 32) | 70% (14 of 20) | 69% (36 of 52) |
| the unit moved after it | 64% (14 of 22) | 71% (10 of 14) | 67% (24 of 36) |
| it charged on its next turn | 5% (1 of 22) | 0% (0 of 14) | 3% (1 of 36) |
| the enemy charged it first | 32% (7 of 22) | 21% (3 of 14) | 28% (10 of 36) |
| it fought by the end of its next turn | 32% (7 of 22) | 7% (1 of 14) | 22% (8 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (3 of 22) | 14% (2 of 14) | 14% (5 of 36) |
| none of these (no charge, no fight, no charge escaped) | 50% (11 of 22) | 64% (9 of 14) | 56% (20 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (571 of 880) | 58% (362 of 619) | 62% (933 of 1499) |
|   cavalry | 70% (48 of 69) | 75% (96 of 128) | 73% (144 of 197) |
|   character | 54% (59 of 110) | 28% (31 of 111) | 41% (90 of 221) |
|   chariot | 57% (39 of 69) | 73% (24 of 33) | 62% (63 of 102) |
|   infantry | 65% (208 of 321) | 57% (137 of 241) | 61% (345 of 562) |
|   monster | 58% (23 of 40) | 49% (19 of 39) | 53% (42 of 79) |
|   war machine | 72% (194 of 271) | 82% (55 of 67) | 74% (249 of 338) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (24%) | 1.3 (18%) | 3.4 (21%) |
| CHARGED: it charged | 1.1 (12%) | 1.4 (19%) | 2.5 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.4 (4%) | 0.5 (7%) | 0.9 (5%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.9 (22%) | 2.3 (31%) | 4.2 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.4 (6%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.4 (27%) | 0.7 (9%) | 3.1 (19%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.4 (5%) | 0.6 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.2 | 82% | 5.5 pts | 30 pts |
| character | 2.9 | 1.4 | 69% | 7.5 pts | 22 pts |
| chariot | 1.9 | 1.5 | 62% | 14.3 pts | 26 pts |
| infantry | 14.2 | 5.9 | 74% | 8.5 pts | 121 pts |
| monster | 1.3 | 0.5 | 70% | 7.0 pts | 9 pts |
| war machine | 7.1 | 5.7 | 60% | 18.6 pts | 133 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 5.4 | 4.6 |
| Charges that made contact a game | 2.8 | 3.9 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.80 declared, 0.70 contact (20 units) | 0.31 declared, 0.25 contact (16 units) | 0.58 declared, 0.50 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.67 contact (6 units) | 1.55 declared, 0.82 contact (11 units) | 1.24 declared, 0.76 contact (17 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.32 contact (253 units) | 0.59 declared, 0.44 contact (281 units) | 0.52 declared, 0.38 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (38 of 68) | 79% (15 of 19) | 38% (3 of 8) | 59% (56 of 95) |
| Character in a unit | 80% (39 of 49) | 55% (12 of 22) | 40% (2 of 5) | 70% (53 of 76) |
| Character on its own | 84% (32 of 38) | 55% (21 of 38) | 33% (19 of 57) | 54% (72 of 133) |
| Chariot | 62% (10 of 16) | 70% (7 of 10) | - | 65% (17 of 26) |
| Infantry | 53% (46 of 86) | 40% (14 of 35) | 0% (0 of 2) | 49% (60 of 123) |
| Monster | 45% (14 of 31) | 60% (6 of 10) | - | 49% (20 of 41) |
| Monstrous | 78% (7 of 9) | 71% (10 of 14) | - | 74% (17 of 23) |
| War Machines | 66% (27 of 41) | 100% (1 of 1) | - | 67% (28 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 56% (10 of 18); on the table 67% | 36% (50 of 138) | 36% | 36% (12 of 33) | 89% (8 of 9); 3.7 uses a game | 67% (2 of 3); 1.2 uses a game | 67% (6 of 9); 1.0 uses a game |
| Chaos Dwarfs | 3 | 89% (8 of 9); on the table 89% | 29% (7 of 24) | 44% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 43% (3 of 7); on the table 57% | - | 70% | 68% (28 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 91% (10 of 11); on the table 91% | 39% (14 of 36) | 47% | 61% (39 of 64) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 77% (10 of 13); on the table 77% | 48% (52 of 108) | 46% | 48% (21 of 44) | 100% (12 of 12); 8.4 uses a game | 0% (0 of 1); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 78% (7 of 9); on the table 78% | 17% (5 of 30) | 45% | 47% (23 of 49) | 100% (5 of 5); 3.2 uses a game | 39% (7 of 18); 1.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 22% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (3 of 3); on the table 100% | - | 39% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 80% (4 of 5); on the table 80% | 8% (1 of 12) | 41% | 62% (13 of 21) | 67% (2 of 3); 2.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (5 of 5); on the table 100% | 25% (9 of 36) | 7% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 4 | 100% (2 of 2); on the table 100% | 40% (12 of 30) | 46% | 62% (21 of 34) | 67% (2 of 3); 1.2 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 75% (12 of 16); on the table 75% | 0% (0 of 12) | 33% | 43% (13 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 83% (19 of 23); on the table 83% | 39% (21 of 54) | 39% | 68% (34 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 7 | 57% (8 of 14); on the table 64% | 33% (10 of 30) | 44% | 73% (49 of 67) | 100% (4 of 4); 2.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 5 | 91% (10 of 11); on the table 91% | 40% (12 of 30) | 37% | 47% (27 of 58) | 17% (1 of 6); 0.8 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t10-opp-ba3e30a-p1, 35 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (43) | 48% (29) | 49% (72) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.63 | 1.46 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.26 | 0.09 | 0.34 |
| ...with the charger already in that arc before they moved (per game) | 0.66 | 0.43 | 1.09 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.60 | 0.06 | 1.66 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.54 | 0.00 | 0.54 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.09 | 0.34 | 5.43 |

### Quality by phase: t10-opp-ba3e30a-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 56% (65 of 116) | 46% (80 of 173) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (202 of 428) | 52% (85 of 162) |
| Strategy | Close-in objectives charged next turn | 12% (18 of 151) | - |
| Strategy | Support requests answered (helper made contact too) | 41% (7 of 17) | 56% (18 of 32) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (4 of 12) | 81% (13 of 16) |
| Strategy | Joined characters whose unit fought | 46% (27 of 59) | 43% (22 of 51) |
| Strategy | Lone characters that fought | 72% (61 of 85) | 72% (60 of 83) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 283.7 | 144.2 |
| Movement | Fights charged into per game | 2.4 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 76, net +27 | 18 of 99, net +162 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 76, net +73 | 13 of 99, net +74 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 76, net +132 | 8 of 99, net +92 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 of 76, net +63 | 37 of 99, net +104 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 9.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (165 of 397) | 43% (144 of 337) |
| Shooting | Points destroyed by shooting units | 50.8 | 39.7 |
| Shooting | War machine shots | 5.5 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (81 of 194) | 40% (22 of 55) |
| Shooting | Points destroyed by war machines | 26.2 | 41.6 |
| Magic | Magic missiles cast | 2.1 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (21 of 72) | 38% (16 of 42) |
| Magic | Wounds caused by magic missiles | 4.6 | 1.7 |
| Magic | Wounds caused by other spells | 1.5 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 58.0 | 58.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.4 / 0.7 / 0.2 | 1.8 / 0.6 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 313.2 | 427.3 |
| Combat | Points run down | 59.0 | 67.9 |
| Combat | Net points per charged fight, damage counted | +82 | +110 |
| Combat | Net per 100 charger points, damage counted | +25.9 | +40.2 |
| Combat | First round won (charged fights) | 72% | 76% |
| Combat | Net points per charged fight | +90 | +113 |
| Combat | Net points per supported fight / lone fight | +34 / +98 | +85 / +118 |
| Combat | Charged fights on a top-3 enemy unit | 34 of 85 | 48 of 114 |
| Game | Points lost | 729.6 | 553.3 |
| Game | VP from objectives | 636.3 | 687.4 |
| Game | Lone holders (player turns) | 4.0 | 2.6 |

- Mine won / drew / lost: 11 / 8 / 16 of 35 ended games (of 35); mean margin (Mine - Opponent) -230 VP
- The side that went first won 12 of 27 games with a winner
- Points traded per game (both sides' losses): 1283
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t10-opp-ba3e30a-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 5.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 4.7 | -91.0 | 149.1 | 128.4 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +56.3 | 0.0 | 13.1 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.2 | +12.0 | 0.0 | 0.9 |
| ARMY TABLE | - | - | - | - | 14.6 | +246.0 | 0.0 | 191.6 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 42.3 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +3.9 | 0.0 | 26.3 | 0.2 | +2.0 | 0.0 | 0.0 |
| BEST FACING | 0.3 | +9.8 | 0.0 | 18.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| BEST FIRST | 1.4 | +69.4 | 22.8 | 48.3 | - | - | - | - |
| BEST MOVE FOR SHOOTERS | 1.0 | +68.6 | 0.0 | 33.1 | - | - | - | - |
| BEST OVERALL | 0.3 | +10.4 | 0.0 | 9.8 | - | - | - | - |
| BEST PREY | 0.9 | +43.0 | 31.8 | 37.6 | - | - | - | - |
| BEST PRIZE | 0.0 | +2.0 | 0.0 | 0.0 | 0.1 | -12.7 | 12.2 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +2.5 | 0.0 | 8.6 | - | - | - | - |
| BLOWS WHERE AIMED | 0.4 | -50.1 | 40.8 | 26.9 | 0.2 | -38.2 | 30.4 | 0.0 |
| BOMBING RUN | 0.0 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 8.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 63.9 | 14.6 | 0.2 | +0.0 | 20.1 | 0.0 |
| CANNON PLANNED TARGET | 4.9 | +165.7 | 204.6 | 106.1 | 1.5 | +51.6 | 65.2 | 11.3 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 15.4 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 15.4 | 10.9 | 0.0 | +0.0 | 9.2 | 0.0 |
| CAST JOB | 1.1 | +34.1 | 38.8 | 46.3 | 0.3 | +6.5 | 36.2 | 15.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +49.0 | 30.5 | 0.0 | 0.1 | +5.8 | 12.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 32.9 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.1 | +55.9 | 0.0 | 28.1 | 0.8 | +41.7 | 0.0 | 1.7 |
| CHAFF PASSED | 0.3 | -1.4 | 0.0 | 11.1 | 0.2 | -0.2 | 21.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.4 | +0.0 | 0.0 | 6.3 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.1 | +17.3 | 10.2 | 4.5 |
| CHARGE LOSSES | - | - | - | - | 5.5 | -247.6 | 0.0 | 152.7 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 12.9 | 27.7 | 0.2 | +0.0 | 28.9 | 0.0 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 220.6 | 112.2 | 2.5 | +0.0 | 337.4 | 29.7 |
| CHARGE NOW WEIGHED | 0.3 | -24.5 | 19.1 | 8.2 | - | - | - | - |
| CHARGER SLAIN LOST | 0.4 | -10.7 | 66.5 | 11.0 | 0.3 | -10.7 | 21.4 | 16.6 |
| CHARIOT WIZARD CAREFUL | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 6.4 | 2.4 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 4.9 | 64.5 | 0.4 | +0.0 | 14.4 | 4.9 |
| CONVEYANCE SEARCH | 0.6 | +98.9 | 7.2 | 32.9 | 0.4 | +67.4 | 6.0 | 13.9 |
| COVER ONCE | 6.9 | -469.2 | 0.0 | 198.7 | 5.6 | -321.9 | 0.0 | 103.2 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 7.4 | 3.1 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +0.8 | 4.1 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.1 | +13.8 | 0.0 | 18.7 | 7.6 | +80.4 | 0.0 | 8.3 |
| EDGE GIVE GROUND | 0.2 | +7.6 | 13.1 | 1.3 | 0.3 | +6.0 | 27.7 | 1.7 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +1.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +105.0 | 0.0 | 58.8 | 0.1 | +2.1 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 3.7 | +3.0 | 382.8 | 56.0 |
| FALLBACK BY WORTH | 4.2 | +56.3 | 0.0 | 34.3 | 0.2 | +0.0 | 0.0 | 5.4 |
| FALLS SHORT | - | - | - | - | 17.8 | +254.6 | 0.0 | 200.6 |
| FEATURE BUFFS | - | - | - | - | 0.4 | +7.1 | 0.0 | 2.8 |
| FIGHT LIFT | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 1.7 | +84.6 | 175.1 | 27.4 |
| FIRE AND FLEE | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +1.5 | 0.0 | 7.2 |
| FIRE IN ORDER | 0.2 | +0.0 | 15.8 | 3.6 | 0.2 | +0.0 | 5.6 | 0.0 |
| FIVE ACTION | - | - | - | - | 45.5 | +3145.5 | 734.7 | 530.4 |
| FLANK NOT WEIGHED | 4.6 | +0.0 | 0.0 | 165.6 | 6.0 | +0.0 | 0.0 | 101.3 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.8 | 1.3 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +61.1 | 0.0 | 10.1 | 0.7 | +138.1 | 0.0 | 14.7 |
| FOUR ROUNDS | - | - | - | - | 5.0 | +470.1 | 493.7 | 60.1 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -4.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.1 | -4.2 | 0.0 | 5.9 |
| FRIENDS SHOTS CHECKED | 0.1 | +4.5 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.0 | 9.9 | 0.0 | 0.3 | -6.7 | 36.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 0.0 | 0.0 | 0.0 | -0.2 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| GUN FIGURES | 1.0 | +2.7 | 9.5 | 32.4 | 0.5 | +7.6 | 14.3 | 12.4 |
| GUN MASK | - | - | - | - | 0.2 | +0.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 1.1 | +0.0 | 0.0 | 15.7 |
| HE SHOOTS OR CHARGES | - | - | - | - | 2.3 | +0.0 | 0.0 | 45.7 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 28.1 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.6 | +31.7 | 57.8 | 0.0 |
| HIS CHARGE LIST | - | - | - | - | 2.8 | +0.0 | 0.0 | 46.5 |
| HIS FIGHT TOGETHER | - | - | - | - | 1.4 | -20.5 | 0.0 | 44.7 |
| HIS LEGAL MOVES | - | - | - | - | 3.6 | +0.0 | 0.0 | 32.5 |
| HIS MOVE AND SHOT | - | - | - | - | 1.5 | -25.4 | 0.0 | 59.0 |
| HIS OWN BEST MOVE | - | - | - | - | 2.5 | +0.0 | 0.0 | 22.7 |
| HIS RANDOM MOVE | - | - | - | - | 2.3 | +0.0 | 0.0 | 8.7 |
| HIS SHOT LIST | - | - | - | - | 22.3 | +1054.0 | 0.0 | 290.9 |
| HIS TURN DENIED | - | - | - | - | 2.6 | +143.8 | 262.2 | 48.2 |
| HOLDER ASSIGNMENT | - | - | - | - | 13.0 | +1232.3 | 0.0 | 110.0 |
| HOLDER AT DEPLOYMENT | 1.1 | +191.1 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.4 | -137.9 | 418.4 | 272.7 | 4.1 | -163.7 | 423.5 | 35.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +5.9 | 0.0 | 5.6 | 0.4 | +14.0 | 0.0 | 2.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +15.5 | 6.0 | 0.0 |
| HUNT THE GUNS | 0.0 | +8.6 | 0.0 | 1.6 | 0.1 | +26.1 | 11.7 | 1.7 |
| IDLE COST | 14.8 | -249.3 | 0.0 | 215.8 | 10.1 | -136.8 | 0.0 | 124.7 |
| INVITES THE FIGHT | 0.9 | +8.0 | 27.3 | 30.3 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | +60.0 | 138.7 | 22.1 |
| JOINT CHARGE PLAN | 0.0 | +0.0 | 11.2 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -1.9 | 0.0 | 0.0 | 0.1 | -1.9 | 0.0 | 2.4 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +28.2 | 4.6 | 6.4 |
| KEEP FALLS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.3 | 0.0 | 15.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.4 | +42.9 | 130.0 | 57.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +61.8 | 138.5 | 68.4 | - | - | - | - |
| KILLS COUNT NEXT TURN | 5.1 | +172.7 | 222.8 | 174.9 | - | - | - | - |
| LANE BY FIGURES | 0.8 | +24.1 | 0.0 | 0.0 | 0.7 | +41.6 | 0.0 | 17.1 |
| LEGAL CHARGES ONLY | - | - | - | - | 5.0 | +0.0 | 200.3 | 111.4 |
| LONE CHARACTER SAFE SPOT | 0.3 | +6.7 | 15.6 | 22.7 | 0.1 | +8.4 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.7 | +52.2 | 0.0 | 0.0 | 0.3 | +25.2 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +4.8 | 17.2 | 5.9 | 0.5 | -0.5 | 7.1 | 7.0 |
| LOST CHARGE | 2.5 | -61.2 | 121.0 | 142.2 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.2 | -17.7 | 0.0 | 2.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +25.1 | 44.9 | 33.9 | 0.1 | +0.3 | 0.0 | 2.0 |
| MANOEUVRE | 0.2 | +1.7 | 0.0 | 0.0 | 1.3 | +27.8 | 0.0 | 11.6 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 4.5 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +7.4 | 0.0 | 2.3 |
| MARCH CHECK | 0.1 | +3.7 | 0.0 | 0.0 | 1.0 | +50.4 | 0.0 | 13.2 |
| MARCH ODDS | 0.2 | +12.3 | 7.4 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +37.0 | 0.0 | 32.3 | 0.7 | +98.6 | 0.0 | 11.3 |
| MAX FOR POSITIONING | 5.6 | +78.3 | 0.0 | 158.0 | 7.1 | +78.2 | 0.0 | 67.9 |
| MISSILES IN THE MOVE | 4.7 | +177.8 | 0.0 | 109.7 | 3.6 | +73.7 | 0.0 | 80.6 |
| MISSILES NEXT TURN | 5.4 | +132.9 | 0.0 | 168.4 | 4.7 | +42.9 | 0.0 | 104.1 |
| MODEL FACING | 0.1 | +60.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.7 | +26.9 | 0.0 | 13.2 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 2.9 | +0.0 | 27.4 | 29.0 |
| MOVE SPELL IN RANGE | 0.1 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -35.0 | 0.0 | 13.9 | 0.1 | -1.5 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.1 | +134.7 | 154.8 | 116.4 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 5.1 | +692.4 | 0.0 | 30.9 |
| MOVES UNITS SPELL | 0.1 | +3.5 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | - | - | - | - | 3.0 | +124.1 | 0.0 | 13.9 |
| NEEDED THERE | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | - | - | - | - | 5.5 | -181.1 | 21.2 | 23.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 5.7 | -180.4 | 40.9 | 54.4 |
| NO DOUBLE ROUNDS | - | - | - | - | 4.1 | -182.2 | 401.4 | 56.3 |
| NO RALLY LEFT | 0.1 | +1.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.2 |
| NOT NEEDED | 0.2 | -14.9 | 21.5 | 3.9 | - | - | - | - |
| NOT TURNED | 5.1 | +88.6 | 0.0 | 187.1 | 0.3 | +3.1 | 0.0 | 8.3 |
| NOT WORTH A CAST | 0.9 | -0.6 | 0.0 | 31.9 | 0.1 | -5.3 | 0.0 | 6.7 |
| OFF BEST | 18.4 | -844.4 | 0.0 | 399.9 | 1.6 | -70.8 | 0.0 | 19.5 |
| ONE CHARGE A CHARGER | - | - | - | - | 3.6 | +0.0 | 0.0 | 82.0 |
| ONE FIGHT FORMULA | 7.6 | -140.5 | 27.3 | 270.1 | 6.8 | -139.0 | 0.0 | 62.6 |
| ONE OBJECTIVE FORMULA | 3.0 | -87.8 | 0.0 | 46.7 | 3.2 | +28.7 | 0.0 | 64.7 |
| ONE TARGET A SHOOTER | - | - | - | - | 19.1 | +508.8 | 0.0 | 187.8 |
| OPENS A LANE | 0.4 | +1.6 | 24.6 | 0.0 | 0.2 | +1.2 | 11.8 | 0.0 |
| OPENS UP | 0.0 | +1.0 | 3.3 | 0.0 | 0.3 | +13.8 | 11.3 | 0.0 |
| OVERRUNS AWAY | 0.2 | +11.6 | 36.3 | 18.1 | 0.5 | +36.8 | 67.4 | 0.0 |
| PATHS CROSS | 1.8 | +114.8 | 0.0 | 22.2 | 3.3 | +146.8 | 0.0 | 17.8 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +5.2 | 0.0 | 30.9 |
| PIVOT GUARDS FLANK | 0.2 | -1.1 | 0.0 | 2.0 | 0.1 | -11.2 | 0.0 | 5.3 |
| PLAN RESULT | 38.3 | +1256.0 | 1117.0 | 1090.7 | 41.3 | +621.0 | 304.9 | 756.8 |
| PURSUES BIG PREY | 0.1 | -7.8 | 0.0 | 0.0 | 0.0 | -1.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.8 | +18.7 | 0.0 | 17.3 | 1.4 | +50.0 | 0.0 | 65.6 |
| RANDOM MOVER NO PROMISE | 0.1 | -6.7 | 3.3 | 4.9 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.8 | -14.9 | 0.0 | 19.5 | 0.4 | +8.5 | 0.0 | 1.6 |
| REDIRECT COUNTER | 2.0 | +118.5 | 0.0 | 39.9 | 3.6 | +222.4 | 0.0 | 43.0 |
| REDIRECT WEIGHED | 0.1 | +4.0 | 3.6 | 0.0 | 0.3 | -1.2 | 3.6 | 4.1 |
| REFORMS TO MEET IT | - | - | - | - | 1.0 | -33.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 8.8 |
| RESERVE FALL BACK | 0.5 | +10.0 | 0.0 | 14.7 | 0.5 | +37.3 | 0.0 | 3.8 |
| RESTRAINS TO SHOOT | 0.1 | +6.6 | 0.0 | 4.1 | 0.1 | +6.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +79.2 | 204.4 | 97.5 | 3.3 | -1.1 | 307.8 | 53.8 |
| RISK BY HIS FIGURE | - | - | - | - | 14.4 | -189.8 | 0.0 | 270.4 |
| RISK ONCE | 2.1 | +49.6 | 23.1 | 109.3 | - | - | - | - |
| RUN DOWN | - | - | - | - | 3.5 | -39.7 | 341.1 | 41.8 |
| SAFE SURE CHARGE | 0.0 | -0.6 | 4.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.5 | +20.3 | 0.0 | 9.1 | - | - | - | - |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -2.7 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +1.0 | 0.0 | 1.6 | 0.3 | +0.7 | 0.0 | 1.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 1.6 | 0.3 | +0.0 | 0.0 | 1.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -9.1 | 0.0 | 2.1 | 0.2 | -19.1 | 0.0 | 3.0 |
| SEARCH SPOT | 2.9 | +127.8 | 0.0 | 101.1 | 6.3 | +251.6 | 0.0 | 66.4 |
| SELF MOVE SPELL | 0.2 | +11.9 | 0.0 | 0.0 | 0.2 | -0.4 | 0.0 | 9.3 |
| SET UP BY THE SET | - | - | - | - | 0.8 | +30.2 | 33.1 | 6.9 |
| SET UP TOGETHER | 0.5 | +27.3 | 44.9 | 48.0 | 0.1 | +0.6 | 0.0 | 2.0 |
| SET-UP ANY TARGET | 0.3 | +45.3 | 0.0 | 3.7 | 0.0 | +5.6 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +1.5 | 5.3 | 11.6 | 0.0 | +4.7 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.9 | +72.9 | 63.7 | 37.4 | 0.6 | +31.0 | 15.0 | 8.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.2 | -4.0 | 19.6 | 0.0 |
| SHOT RISK POINTS | - | - | - | - | 12.4 | +113.9 | 0.0 | 249.0 |
| SHOTS IN THE MOVE | 14.9 | +511.2 | 0.0 | 307.8 | 10.2 | +300.1 | 0.0 | 70.4 |
| SPELL SETS UP CHARGE | 0.4 | +112.5 | 0.0 | 3.7 | 0.0 | +5.6 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +18.8 | 112.6 | 112.6 | 2.1 | +40.1 | 69.5 | 69.5 |
| SPELLS IN THE FIGHT | 0.5 | +1.9 | 51.3 | 20.1 | 0.5 | -8.1 | 43.0 | 5.6 |
| STABLE ROLE | 11.1 | +0.0 | 335.3 | 248.6 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.8 | -8.9 | 62.8 | 3.3 |
| STANDS FOR A REASON | - | - | - | - | 0.5 | +0.0 | 0.0 | 12.5 |
| STANDS STILL | - | - | - | - | 10.0 | +0.0 | 240.9 | 142.3 |
| STAY WEIGHED | 0.1 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 18.7 | +78.4 | 319.3 | 293.7 | 11.1 | +94.9 | 175.3 | 44.0 |
| STOPS | 0.0 | +0.0 | 0.0 | 1.6 | 0.1 | +1.7 | 11.7 | 1.7 |
| STOPS SHORT OF THE FLANK | 0.4 | +17.9 | 0.0 | 19.5 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.9 | 0.2 | +0.0 | 0.0 | 15.7 |
| SUPPORT NARROWED | 5.0 | -38.8 | 507.0 | 108.5 | 1.9 | +0.0 | 192.4 | 19.0 |
| SUPPORTS | 3.5 | +42.2 | 369.5 | 76.2 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.9 | 8.3 | 5.4 | - | - | - | - |
| SURE REACH TOGETHER | 0.2 | -0.5 | 22.5 | 0.0 | 0.5 | +7.5 | 0.0 | 7.2 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 3.3 | +0.0 | 0.0 | 19.7 |
| THE PROMISE ADDS | - | - | - | - | 0.4 | -29.3 | 9.8 | 2.3 |
| THE PROMISED MOVE | - | - | - | - | 2.0 | +0.0 | 0.0 | 6.3 |
| THROUGH LINE OF FIRE | 0.3 | +12.2 | 0.0 | 9.7 | - | - | - | - |
| TIED UP BY THE SUM | - | - | - | - | 0.9 | +93.6 | 92.6 | 18.9 |
| TIME ON OUR SIDE | - | - | - | - | 8.7 | +122.7 | 0.0 | 83.5 |
| TURN WORTH | 0.3 | -18.2 | 40.2 | 15.2 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 11.2 | 9.9 | - | - | - | - |
| WAIT AFTER COSTS | 6.5 | -269.4 | 256.9 | 182.5 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 2.1 | +0.0 | 0.0 | 13.7 |
| WALKS TO THE FIGHT | 1.9 | +17.2 | 61.3 | 16.3 | - | - | - | - |
| WAR ENGINE CHARGES | 0.0 | +3.8 | 6.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 65.7 | 34.6 | 0.2 | +0.0 | 4.9 | 9.4 |
| WEARS DOWN | 1.2 | +58.4 | 113.1 | 61.4 | - | - | - | - |
| WHO HITS BACK | 0.4 | +24.5 | 0.0 | 8.7 | 0.4 | +72.8 | 0.0 | 5.6 |
| WHOLE FIGHT | 0.1 | +8.8 | 37.5 | 0.0 | 0.3 | +7.1 | 35.0 | 2.3 |
| WHOLE FIGHT GAIN | 0.4 | +28.4 | 11.7 | 6.6 | 0.2 | +12.6 | 26.2 | 0.0 |
| WIDER SPREAD | 2.1 | -7.7 | 207.4 | 57.9 | 3.4 | -8.6 | 343.5 | 40.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 7.3 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.1 | +53.8 | 0.0 | 40.6 |

### Rule changes: t10-opp-ba3e30a-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 701 | 701 | 701 | 20.03 | -32033 | -45.7 |
| HOLDER ASSIGNMENT | 455 | 455 | 431 | 12.31 | +23281 | +54.0 |
| ARMY TABLE | 510 | 510 | 353 | 10.09 | +6961 | +19.7 |
| DEPLOY BY FIGURES | 551 | 551 | 333 | 9.51 | +4579 | +13.8 |
| SEARCH SPOT | 322 | 322 | 313 | 8.94 | +13288 | +42.5 |
| HIS SHOT LIST | 782 | 774 | 210 | 6.00 | +4642 | +22.1 |
| FIVE ACTION | 1594 | 1581 | 202 | 5.77 | +11535 | +57.1 |
| PATHS CROSS | 181 | 181 | 181 | 5.17 | +9157 | +50.6 |
| LEGAL CHARGES ONLY | 176 | 176 | 176 | 5.03 | +0 | +0.0 |
| ONE TARGET A SHOOTER | 669 | 662 | 158 | 4.51 | +2089 | +13.2 |
| MOVE ORDER | 100 | 100 | 100 | 2.86 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 180 | 179 | 97 | 2.77 | +9600 | +99.0 |
| SHOTS IN THE MOVE | 880 | 670 | 85 | 2.43 | +2347 | +27.6 |
| SHOT RISK POINTS | 435 | 426 | 76 | 2.17 | +2816 | +37.1 |
| COVER ONCE | 436 | 256 | 74 | 2.11 | +1168 | +15.8 |
| FOUR ROUNDS | 176 | 176 | 70 | 2.00 | +5786 | +82.7 |
| MAX FOR POSITIONING | 444 | 357 | 70 | 2.00 | +294 | +4.2 |
| ARTILLERY RE-ROLL WEIGHED | 62 | 62 | 62 | 1.77 | +0 | +0.0 |
| JOINT CHARGE NOW | 61 | 61 | 61 | 1.74 | +2101 | +34.4 |
| ADVANCE LANE KEPT | 59 | 59 | 59 | 1.69 | +0 | +0.0 |
| KILLS COUNT NEXT TURN | 177 | 177 | 59 | 1.69 | +1494 | +25.3 |
| FACES THE THREAT | 58 | 58 | 58 | 1.66 | +3751 | +64.7 |
| IDLE COST | 869 | 558 | 56 | 1.60 | +398 | +7.1 |
| LANE BY FIGURES | 53 | 53 | 53 | 1.51 | +2298 | +43.4 |
| MOVE TO CHARGE | 108 | 108 | 53 | 1.51 | +1356 | +25.6 |
| BEST FIRST | 50 | 50 | 50 | 1.43 | +2428 | +48.6 |
| FOLLOW UP WEIGHED | 50 | 50 | 50 | 1.43 | +6971 | +139.4 |
| MISSILES IN THE MOVE | 292 | 205 | 50 | 1.43 | +2192 | +43.8 |
| WAIT AFTER COSTS | 228 | 228 | 48 | 1.37 | +668 | +13.9 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.34 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 75 | 75 | 47 | 1.34 | +2402 | +51.1 |
| SHOOTS FROM THE BEST SPOT | 89 | 89 | 47 | 1.34 | +710 | +15.1 |
| TIME ON OUR SIDE | 303 | 260 | 47 | 1.34 | +71 | +1.5 |
| CANNON PLANNED TARGET | 226 | 226 | 46 | 1.31 | -1348 | -29.3 |
| STAY WORTH | 1042 | 904 | 45 | 1.29 | +683 | +15.2 |
| HOLDS AMBUSHERS | 43 | 43 | 43 | 1.23 | +0 | +0.0 |
| REDIRECT COUNTER | 197 | 140 | 43 | 1.23 | +3033 | +70.5 |
| CHAFF IN THE MOVE | 67 | 65 | 40 | 1.14 | +1159 | +29.0 |
| FALLS SHORT | 622 | 523 | 38 | 1.09 | +243 | +6.4 |
| HARD STAY DROPPED | 38 | 38 | 38 | 1.09 | +0 | +0.0 |
| RISK BY ARC | 184 | 183 | 38 | 1.09 | +1276 | +33.6 |
| SUPPORTS | 121 | 121 | 38 | 1.09 | +430 | +11.3 |
| FALLBACK BY WORTH | 154 | 154 | 37 | 1.06 | +1972 | +53.3 |
| BEST MOVE FOR SHOOTERS | 36 | 36 | 36 | 1.03 | +2401 | +66.7 |
| CHARGE NOW FIRST | 162 | 162 | 36 | 1.03 | -1925 | -53.5 |
| LONE WIZARD KEPT IN | 35 | 35 | 35 | 1.00 | +2708 | +77.4 |
| RESERVE FALL BACK | 34 | 34 | 34 | 0.97 | +1656 | +48.7 |
| ADVANCE WORTH | 166 | 166 | 30 | 0.86 | +613 | +20.4 |
| MANOEUVRE | 51 | 51 | 29 | 0.83 | +1099 | +37.9 |
| ONE FIGHT FORMULA | 505 | 289 | 29 | 0.83 | +127 | +4.4 |
| WHO HITS BACK | 29 | 29 | 29 | 0.83 | +2277 | +78.5 |
| MARCH CHECK | 37 | 37 | 28 | 0.80 | +484 | +17.3 |
| CAST JOB | 48 | 48 | 26 | 0.74 | +388 | +14.9 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.74 | +0 | +0.0 |
| MOVE AND CAST | 26 | 26 | 26 | 0.74 | +942 | +36.2 |
| SCOUT WAITS | 26 | 26 | 26 | 0.74 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.71 | +0 | +0.0 |
| WALKS TO THE FIGHT | 68 | 68 | 25 | 0.71 | +222 | +8.9 |
| HIS TURN DENIED | 92 | 92 | 23 | 0.66 | +1388 | +60.4 |
| SHOOTERS IN TWO RANKS | 23 | 23 | 23 | 0.66 | +53 | +2.3 |
| TIED UP BY THE SUM | 32 | 32 | 22 | 0.63 | +1016 | +46.2 |
| RISK BY HIS FIGURE | 504 | 499 | 21 | 0.60 | +2043 | +97.3 |
| CHARGE LOSSES | 193 | 191 | 20 | 0.57 | +2176 | +108.8 |
| HOLDER AT DEPLOYMENT | 38 | 38 | 19 | 0.54 | +913 | +48.1 |
| NEXT OBJECTIVE NEARER | 198 | 196 | 19 | 0.54 | +398 | +20.9 |
| SAFER THAN THE JOB | 19 | 19 | 19 | 0.54 | +712 | +37.5 |
| CHAFF PASSED | 18 | 18 | 18 | 0.51 | -59 | -3.3 |
| KILLS COUNT | 50 | 50 | 18 | 0.51 | +670 | +37.2 |
| NEXT CHARGE BY LIST | 192 | 190 | 18 | 0.51 | +734 | +40.8 |
| CHARGE NOT DECLARED | 17 | 17 | 17 | 0.49 | -1166 | -68.6 |
| FIRE IN ORDER | 15 | 15 | 15 | 0.43 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 219 | 157 | 15 | 0.43 | +531 | +35.4 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.43 | +784 | +52.3 |
| CASTING BLOCK | 24 | 24 | 14 | 0.40 | +949 | +67.8 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.40 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 14 | 14 | 14 | 0.40 | +627 | +44.8 |
| INVITES THE FIGHT | 33 | 33 | 13 | 0.37 | +132 | +10.2 |
| WAR ENGINE JOBS | 31 | 31 | 13 | 0.37 | -854 | -65.7 |
| CHARGE NOW WEIGHED | 12 | 12 | 12 | 0.34 | +764 | +63.7 |
| SET UP BY THE SET | 28 | 28 | 12 | 0.34 | +1531 | +127.6 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.31 | +1969 | +179.0 |
| FIGHT TO THE END | 60 | 60 | 11 | 0.31 | +678 | +61.6 |
| KEEPS ITS TARGET | 50 | 50 | 11 | 0.31 | +202 | +18.4 |
| RISK ONCE | 75 | 49 | 11 | 0.31 | +314 | +28.5 |
| SUPPORT NARROWED | 242 | 242 | 11 | 0.31 | -149 | -13.5 |
| BEST FACING | 10 | 10 | 10 | 0.29 | +348 | +34.8 |
| NEARER NOT NEEDED | 105 | 100 | 10 | 0.29 | +289 | +28.9 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.29 | -428 | -42.8 |
| THROUGH LINE OF FIRE | 10 | 10 | 10 | 0.29 | +427 | +42.7 |
| WEARS DOWN | 42 | 41 | 10 | 0.29 | +308 | +30.8 |
| BEST OVERALL | 9 | 9 | 9 | 0.26 | +365 | +40.6 |
| HIS CHARGE DENIED | 22 | 22 | 9 | 0.26 | +363 | +40.4 |
| HONEST WORTH | 402 | 401 | 9 | 0.26 | +19 | +2.1 |
| JOINT ON THE TABLE | 9 | 9 | 9 | 0.26 | +987 | +109.7 |
| MARCH BY THE SUM | 9 | 9 | 9 | 0.26 | +258 | +28.7 |
| MISSILES NEXT TURN | 352 | 228 | 9 | 0.26 | +105 | +11.7 |
| OVERRUNS AWAY | 26 | 26 | 9 | 0.26 | +181 | +20.2 |
| STUCK PIVOT | 9 | 9 | 9 | 0.26 | +0 | +0.0 |
| BEST PREY | 31 | 31 | 8 | 0.23 | +218 | +27.3 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.23 | +0 | +0.0 |
| SURE REACH TOGETHER | 23 | 22 | 8 | 0.23 | +30 | +3.7 |
| MARCH ODDS | 7 | 7 | 7 | 0.20 | -16 | -2.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.20 | +186 | +26.5 |
| REFUSING RETIRES | 15 | 15 | 7 | 0.20 | -3 | -0.4 |
| AFTERMATH WITH FRIENDS | 6 | 6 | 6 | 0.17 | +421 | +70.2 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -590 | -98.4 |
| BLOCKED WHEEL | 6 | 6 | 6 | 0.17 | +88 | +14.7 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +444 | +74.0 |
| WHOLE FIGHT GAIN | 19 | 18 | 6 | 0.17 | +358 | +59.6 |
| CHARGE LIST READ AGAIN | 5 | 5 | 5 | 0.14 | +606 | +121.3 |
| HIS MOVE AND SHOT | 54 | 53 | 5 | 0.14 | +49 | +9.9 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -138 | -27.5 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +63 | +15.8 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.11 | +182 | +45.5 |
| HIS FIGHT TOGETHER | 48 | 48 | 4 | 0.11 | +9 | +2.2 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +2112 | +527.9 |
| OPENS UP | 10 | 10 | 4 | 0.11 | +109 | +27.2 |
| REDIRECT BY WHAT IT STOPS | 41 | 41 | 4 | 0.11 | +207 | +51.8 |
| SET UP TOGETHER | 22 | 20 | 4 | 0.11 | +88 | +22.0 |
| SPELLS IN THE FIGHT | 36 | 35 | 4 | 0.11 | +47 | +11.9 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +323 | +80.7 |
| BACKUP TARGETS | 29 | 17 | 3 | 0.09 | +9 | +3.1 |
| BIG CHARACTER SAFETY | 3 | 3 | 3 | 0.09 | +8 | +2.7 |
| EDGE GIVE GROUND | 20 | 20 | 3 | 0.09 | +64 | +21.5 |
| HUNT IN PAIRS | 25 | 13 | 3 | 0.09 | +88 | +29.5 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.09 | +9 | +3.2 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.09 | -306 | -101.8 |
| WHOLE FIGHT | 17 | 17 | 3 | 0.09 | +113 | +37.5 |
| WOUNDS ON THE RANKS | 39 | 39 | 3 | 0.09 | +171 | +57.0 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| GUN MASK | 6 | 6 | 2 | 0.06 | +40 | +19.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 33 | 33 | 2 | 0.06 | +14 | +6.9 |
| LOST CHARGE | 88 | 88 | 2 | 0.06 | +1 | +0.3 |
| MAKE SURE TOGETHER | 18 | 11 | 2 | 0.06 | +82 | +41.2 |
| OPENS A LANE | 21 | 5 | 2 | 0.06 | +4 | +2.2 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +182 | +91.2 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +62 | +30.9 |
| WIDER SPREAD | 191 | 190 | 2 | 0.06 | +3 | +1.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +154 | +154.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -1 | -1.0 |
| DEFENSIVE ARMY | 12 | 12 | 1 | 0.03 | -18 | -17.9 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +62 | +61.9 |
| FALL BACK GOOD ORDER | 128 | 128 | 1 | 0.03 | +0 | +0.1 |
| FEATURE BUFFS | 14 | 14 | 1 | 0.03 | +13 | +13.4 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +26 | +26.3 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +2 | +1.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +10 | +9.6 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 142 | 142 | 1 | 0.03 | +0 | +0.1 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -175 | -174.8 |
| STOPS | 5 | 5 | 1 | 0.03 | +11 | +10.8 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.03 | +95 | +95.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 20 | 20 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 15 | 15 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 24 | 24 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 371 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 15 | 15 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 53 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 79 | 77 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 98 | 97 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 126 | 125 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 86 | 85 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 81 | 79 | 0 | 0.00 | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 1 | 1 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 15 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 47 | 47 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 3 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NOT NEEDED | 8 | 8 | 0 | 0.00 | - | - |
| NOT TURNED | 190 | 190 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 35 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 126 | 124 | 0 | 0.00 | - | - |
| PLAN RESULT | 2786 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 35 | 35 | 0 | 0.00 | - | - |
| RUN DOWN | 124 | 124 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 14 | not checked | - | - | - | - |
| SPELL WORTH | 107 | not checked | - | - | - | - |
| STABLE ROLE | 388 | 388 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 28 | 28 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 349 | 346 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 117 | not checked | - | - | - | - |
| THE PROMISE ADDS | 14 | 14 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 69 | not checked | - | - | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 3 | 3 | 0 | 0.00 | - | - |
| WAITS AGAIN | 72 | 72 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: t10-opp-ba3e30a-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 16.89 | 0.97 | 47.1 |
| ARMY TABLE | rule | - | 2.00 | 23.4 |
| HOLDER ASSIGNMENT | rule | - | 1.34 | 28.2 |
| CHARGE NOW FIRST | rule | 0.40 | 0.60 | 55.0 |
| FALLBACK | gate | 0.74 | 0.03 | 31.6 |
| PATHS CROSS | rule | 0.09 | 0.54 | 15.9 |
| JOINT CHARGE NOW | rule | - | 0.60 | 58.6 |
| CHARGE NOT DECLARED | rule | 0.29 | 0.17 | 72.8 |
| NO REASON | gate | - | 0.40 | 80.4 |
| CANNON PLANNED TARGET | rule | 0.20 | 0.17 | 107.6 |
| TURN GATE | gate | 0.37 | - | 19.7 |
| WAR ENGINE JOBS | rule | 0.37 | - | 65.7 |
| CHAFF PASSED | rule | 0.17 | 0.14 | 5.3 |
| SUPPORT NARROWED | rule | 0.17 | 0.14 | 13.5 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.11 | 42.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.09 | 0.09 | 27.9 |
| BEST PRIZE | rule | 0.03 | 0.14 | 98.4 |
| AFTERMATH BAND | gate | 0.09 | 0.06 | 1.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | - | 27.5 |
| FIGHT ORDER BAND | gate | 0.06 | 0.06 | 2.7 |
| PURSUES BIG PREY | rule | 0.06 | 0.03 | 101.8 |
| SUPPORT REQUEST | gate | 0.09 | - | 25.7 |
| DEPLOY BY FIGURES | rule | - | 0.06 | 10.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.03 | 23.0 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 93.7 |
| REFUSING RETIRES | rule | - | 0.06 | 0.6 |
| RULE SWITCHED OFF | gate | 0.06 | - | 31.8 |
| CATCH ODDS | rule | - | 0.03 | 1.0 |
| CHARGE LIST READ AGAIN | rule | - | 0.03 | 1.0 |
| CHARGE NOW WEIGHED | rule | 0.03 | - | 14.6 |
| DEFENSIVE ARMY | rule | 0.03 | - | 17.9 |
| MARCH ODDS | rule | 0.03 | - | 62.2 |
| MOVE AND CAST | rule | 0.03 | - | 7.2 |
| SAFE SURE CHARGE | rule | 0.03 | - | 174.8 |

### Plans: t10-opp-ba3e30a-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.2 | 16% | 216 | 268 | 124% |
| Mine | charge | 2.9 | 59% | 242 | 270 | 112% |
| Mine | close in | 4.3 | 24% | 209 | 156 | 75% |
| Mine | hold | 6.1 | 46% | 347 | 0 | 0% |
| Mine | join | 0.7 | 92% | 20 | 0 | 0% |
| Mine | shoot | 9.8 | 58% | 364 | 563 | 155% |
| Mine | support | 4.3 | 86% | 32 | 0 | 0% |
| Opponent | charge | 4.1 | 57% | 744 | 398 | 53% |
| Opponent | join | 1.3 | 91% | 63 | 0 | 0% |
| Opponent | move | 31.7 | 94% | 1956 | 0 | 0% |
| Opponent | shoot | 3.7 | 60% | 176 | 223 | 127% |
| Opponent | support | 0.6 | 80% | 33 | 0 | 0% |

### Packages: hunt the guns, t10-opp-ba3e30a-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 35 |
| Opponent | 0.1 | 4 | 0 | 75% | 75% | 0% | 2.0 | 228 | 136 | 75% | 47 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 245 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 12 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 12 |
| Vampire Counts | 0.4 | 3 | 0 | 67% | 67% | 0% | 2.0 | 231 | 108 | 67% | 8 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 221 | 219 | 100% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 187 |

### Battle groups: t10-opp-ba3e30a-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 31% | 50% | 9% | 50% | 10% | 0% | 10% | 70% | 10% |
| Opponent | REDIRECT COUNTER | 3.6 | 17% | 82% | 14% | 0% | 26% | 0% | 0% | 74% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t10-opp-ba3e30a-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 44 | 33% | 5.5 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Mine | Chaff | 36 | 43 (36) | 17 | 27 | 51 | 44% | 2.2 | 40 (12) | 57 (16) | 29 (8) | 53 (26) | 23 (10) |
| Mine | Character | 121 | 48 (121) | 48 | 0 | 37 | 16% | 2.5 | 50 (48) | 33 (43) | 86 (18) | 53 (58) | 48 (51) |
| Mine | Clean-up | 24 | 76 (24) | 25 | 52 | 39 | 38% | 3.4 | 92 (12) | 79 (10) | 0 (2) | 114 (15) | 34 (9) |
| Mine | Fast | 4 | 45 (4) | 45 | 0 | 87 | 25% | 1.7 | 0 (3) | 362 (1) | - | 96 (3) | 0 (1) |
| Mine | Fast Hammer | 39 | 34 (39) | 17 | 17 | 66 | 26% | 2.6 | 43 (19) | 34 (15) | 5 (5) | 49 (22) | 17 (17) |
| Mine | Hammer | 56 | 24 (56) | 16 | 8 | 41 | 16% | 2.7 | 5 (22) | 35 (25) | 38 (9) | 18 (31) | 32 (25) |
| Mine | Holder | 23 | 117 (23) | 5 | 111 | 16 | 57% | 3.2 | 111 (8) | 125 (13) | 74 (2) | 152 (14) | 64 (9) |
| Mine | Shooter | 49 | 94 (49) | 12 | 82 | 28 | 2% | 1.9 | 98 (14) | 105 (27) | 45 (8) | 139 (32) | 22 (17) |
| Mine | Support | 5 | 37 (5) | 37 | 0 | 84 | 20% | 2.8 | 0 (2) | - | - | 0 (2) | - |
| Mine | War machine | 56 | 25 (56) | 25 | 0 | 45 | 5% | 1.5 | 35 (23) | 14 (25) | 28 (8) | 115 (6) | 15 (50) |
| Mine | Wizard | 23 | 18 (23) | 18 | 0 | 16 | 17% | 2.7 | 18 (13) | 33 (5) | 0 (2) | 33 (11) | 1 (9) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 61 | 94 (61) | 21 | 72 | 37 | 38% | 2.8 | 114 (19) | 127 (23) | 36 (19) | 111 (45) | 42 (16) |
| Opponent | Character | 112 | 62 (112) | 62 | 0 | 22 | 29% | 2.6 | 60 (36) | 73 (50) | 49 (17) | 63 (59) | 65 (44) |
| Opponent | Clean-up | 14 | 27 (14) | 16 | 11 | 49 | 43% | 3.5 | 29 (4) | 27 (9) | 0 (1) | 45 (9) | 0 (5) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 58 | 36 (58) | 17 | 18 | 35 | 29% | 3.1 | 47 (18) | 33 (32) | 26 (8) | 44 (35) | 23 (23) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 100 | 40% | 2.0 | - | - | 0 (2) | - | 0 (2) |
| Opponent | Hammer | 63 | 39 (63) | 26 | 14 | 35 | 29% | 2.5 | 50 (17) | 35 (29) | 37 (17) | 52 (39) | 17 (24) |
| Opponent | Holder | 40 | 53 (40) | 10 | 44 | 15 | 50% | 3.5 | 102 (9) | 43 (23) | 35 (7) | 109 (15) | 25 (24) |
| Opponent | Shooter | 33 | 45 (33) | 3 | 42 | 48 | 3% | 1.8 | 54 (13) | 45 (12) | 28 (8) | 53 (22) | 29 (11) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 84 (13) | 84 | 0 | 21 | 0% | 1.5 | 107 (9) | 50 (2) | 0 (2) | 32 (2) | 92 (11) |
| Opponent | Wizard | 22 | 18 (22) | 18 | 0 | 34 | 9% | 2.4 | 59 (6) | 10 (7) | 0 (6) | 35 (8) | 8 (11) |

### Charged fights: t10-opp-ba3e30a-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 144 | 34 | 1.2 | 1.5 | 28 | 14 | +14 | 2 of 6 | 5 of 6 | -85 | +34 |
| Mine | Chaos Dwarfs | 3 | 108 | 827 | 3.3 | 1.2 | 248 | 0 | +248 | 7 of 10 | 4 of 10 | +0 | +310 |
| Mine | Dwarfen Mountain Holds | 4 | 215 | 124 | 1.0 | 1.2 | 124 | 0 | +124 | 2 of 4 | 3 of 4 | +60 | +145 |
| Mine | Empire of Man | 5 | 145 | 187 | 1.2 | 1.3 | 156 | 127 | +29 | 0 of 6 | 5 of 6 | -214 | +151 |
| Mine | Grand Cathay | 4 | 307 | 346 | 2.8 | 1.2 | 126 | 31 | +95 | 5 of 11 | 9 of 11 | +98 | +94 |
| Mine | High Elf Realms | 4 | 134 | 786 | 3.5 | 1.1 | 225 | 8 | +216 | 6 of 14 | 11 of 14 | +432 | +200 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 254 | 4.0 | 1.0 | 64 | 0 | +64 | 4 of 4 | 2 of 4 | - | +64 |
| Mine | Lizardmen | 1 | 70 | 196 | 3.0 | 1.0 | 65 | 0 | +65 | 0 of 3 | 3 of 3 | - | +65 |
| Mine | Ogre Kingdoms | 1 | 0 | 136 | 4.0 | 1.2 | 34 | 17 | +17 | 0 of 4 | 3 of 4 | +70 | -1 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 531 | 4.0 | 1.0 | 133 | 0 | +133 | 0 of 4 | 4 of 4 | - | +133 |
| Mine | Skaven | 2 | 130 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 492 | 5.5 | 1.1 | 89 | 165 | -75 | 5 of 11 | 7 of 11 | +125 | -96 |
| Mine | Vampire Counts | 2 | 0 | 496 | 4.0 | 1.0 | 124 | 112 | +12 | 3 of 8 | 5 of 8 | - | +12 |
| **Mine** | all armies | 35 | 135 | 334 | 2.4 | 1.2 | 138 | 48 | +90 | 34 of 85 | 61 of 85 | +34 | +98 |
| Opponent | Beastmen Brayherds | 1 | 377 | 485 | 6.0 | 2.3 | 81 | 88 | -7 | 6 of 6 | 3 of 6 | +8 | -81 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 1177 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 285 | 280 | 3.0 | 1.3 | 93 | 0 | +93 | 3 of 3 | 1 of 3 | +95 | +92 |
| Opponent | High Elf Realms | 2 | 0 | 506 | 4.5 | 1.0 | 112 | 0 | +112 | 3 of 9 | 6 of 9 | - | +112 |
| Opponent | Lizardmen | 1 | 77 | 1323 | 7.0 | 1.0 | 189 | 0 | +189 | 2 of 7 | 7 of 7 | - | +189 |
| Opponent | Ogre Kingdoms | 2 | 180 | 98 | 5.5 | 1.4 | 18 | 25 | -7 | 3 of 11 | 8 of 11 | -17 | -4 |
| Opponent | Orc & Goblin Tribes | 2 | 221 | 772 | 5.0 | 1.2 | 154 | 6 | +149 | 5 of 10 | 6 of 10 | +328 | +104 |
| Opponent | Skaven | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 122 | 951 | 4.0 | 1.1 | 238 | 12 | +226 | 8 of 16 | 13 of 16 | +128 | +240 |
| Opponent | Vampire Counts | 6 | 70 | 446 | 3.7 | 1.0 | 122 | 14 | +107 | 8 of 22 | 18 of 22 | +0 | +112 |
| Opponent | Warriors of Chaos | 7 | 0 | 336 | 2.3 | 1.0 | 147 | 18 | +129 | 6 of 16 | 14 of 16 | - | +129 |
| Opponent | Wood Elf Realms | 5 | 256 | 195 | 2.8 | 1.3 | 70 | 8 | +62 | 4 of 14 | 11 of 14 | +132 | +34 |
| **Opponent** | all armies | 35 | 140 | 418 | 3.3 | 1.2 | 128 | 16 | +113 | 48 of 114 | 87 of 114 | +85 | +118 |

### Effective charges: t10-opp-ba3e30a-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net +0) | 0 | 0 | 0 | 0 | 3 (net +18) | 2 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 10 | 5 (net +251) | 0 | 0 | 2 (net +451) | 1 (net +112) | 2 (net +105) | 0 | 0% (0 of 10) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 2 (net +217) | 1 (net +60) | 0 | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 6 | 0 | 0 | 1 (net -380) | 1 (net +345) | 1 (net -48) | 2 (net +129) | 1 | 20% (1 of 5) |
| Mine | Grand Cathay | 11 | 0 | 1 (net +393) | 3 (net +114) | 5 (net +61) | 0 | 2 (net +0) | 0 | 27% (3 of 11) |
| Mine | High Elf Realms | 14 | 1 (net +190) | 2 (net +332) | 2 (net +346) | 2 (net +248) | 2 (net +288) | 5 (net +82) | 0 | 14% (2 of 14) |
| Mine | Kingdom of Bretonnia | 4 | 2 (net +0) | 0 | 2 (net +127) | 0 | 0 | 0 | 0 | 50% (2 of 4) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 2 (net +65) | 0 | 1 (net +66) | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 2 (net +18) | 0 | 0 | 0 | 2 | 100% (2 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 1 (net +325) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 11 | 3 (net -415) | 1 (net -195) | 2 (net -186) | 1 (net +170) | 1 (net +125) | 2 (net +286) | 1 | 20% (2 of 10) |
| Mine | Vampire Counts | 8 | 2 (net +90) | 1 (net +0) | 1 (net +198) | 1 (net +0) | 1 (net +98) | 2 (net -190) | 0 | 12% (1 of 8) |
| Opponent | Beastmen Brayherds | 6 | 2 (net +94) | 0 | 2 (net -4) | 0 | 0 | 2 (net -111) | 0 | 33% (2 of 6) |
| Opponent | Grand Cathay | 3 | 1 (net +185) | 0 | 2 (net +48) | 0 | 0 | 0 | 0 | 67% (2 of 3) |
| Opponent | High Elf Realms | 9 | 2 (net +48) | 0 | 1 (net +125) | 1 (net +165) | 0 | 4 (net +157) | 1 | 12% (1 of 8) |
| Opponent | Lizardmen | 7 | 0 | 0 | 1 (net +526) | 2 (net +203) | 1 (net +77) | 2 (net +94) | 1 | 17% (1 of 6) |
| Opponent | Ogre Kingdoms | 11 | 1 (net +0) | 0 | 2 (net +58) | 1 (net -80) | 1 (net +0) | 2 (net -20) | 4 | 29% (2 of 7) |
| Opponent | Orc & Goblin Tribes | 10 | 2 (net +174) | 0 | 0 | 1 (net +735) | 0 | 0 | 7 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 16 | 1 (net +855) | 0 | 2 (net -5) | 4 (net +326) | 1 (net +0) | 7 (net +166) | 1 | 13% (2 of 15) |
| Opponent | Vampire Counts | 22 | 4 (net +35) | 0 | 2 (net +58) | 6 (net +67) | 2 (net +105) | 7 (net +136) | 1 | 10% (2 of 21) |
| Opponent | Warriors of Chaos | 16 | 2 (net +548) | 0 | 1 (net +0) | 3 (net -15) | 1 (net +0) | 9 (net +113) | 0 | 6% (1 of 16) |
| Opponent | Wood Elf Realms | 14 | 3 (net +0) | 0 | 0 | 5 (net +51) | 2 (net +224) | 4 (net +40) | 0 | 0% (0 of 14) |

### Charged fights, damage counted: t10-opp-ba3e30a-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 268 | 251 | +27 | 151 | 150 | +0 | +0.0 |
| Mine | 50-54% | 5 | 411 | 301 | +172 | 211 | 50 | +161 | +39.2 |
| Mine | Effective (55-75%) | 15 | 308 | 217 | +73 | 187 | 117 | +70 | +22.7 |
| Mine | 76-89% | 16 | 324 | 184 | +174 | 193 | 16 | +177 | +54.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 256 | 148 | +63 | 125 | 71 | +54 | +21.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 469 | 119 | +132 | 186 | 68 | +118 | +25.1 |
| Mine | No odds | 9 | 356 | 83 | +43 | 54 | 4 | +51 | +14.2 |
| Mine | All fights | 85 | 317 | 184 | +90 | 156 | 73 | +82 | +25.9 |
| Opponent | Long shot (under 50%) | 18 | 216 | 278 | +162 | 193 | 73 | +119 | +55.1 |
| Opponent | Effective (55-75%) | 13 | 236 | 219 | +74 | 120 | 51 | +69 | +29.1 |
| Opponent | 76-89% | 23 | 276 | 186 | +137 | 186 | 45 | +141 | +51.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 280 | 166 | +104 | 122 | 16 | +106 | +38.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 475 | 118 | +92 | 124 | 2 | +122 | +25.7 |
| Opponent | No odds | 15 | 244 | 252 | +86 | 104 | 16 | +88 | +36.1 |
| Opponent | All fights | 114 | 273 | 202 | +113 | 144 | 34 | +110 | +40.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t10-opp-ba3e30a-p1 | move | 329 | 75 (23%) | 54 (16%) | 50 (15%) | 204 (62%) |
| t10-opp-ba3e30a-p1 | objective | 151 | 18 (12%) | 17 (11%) | 17 (11%) | 116 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

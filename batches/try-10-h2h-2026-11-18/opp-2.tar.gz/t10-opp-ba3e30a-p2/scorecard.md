# Doctrine scorecard: t10-opp-ba3e30a-p2

### Scorecard: t10-opp-ba3e30a-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 3 | - | 0 | 3 | 0 | 0 | 0 | 442 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 280 |
| L0122 | 2 | 1 | Mine | - | - | 5 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 5 | 2 | 1 | 0 | 0 | 0 | 280 |
| L0222 | 6 | 1 | Mine | no | 0 | 3 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 8 | 4 | 2 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 900 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 66 |
| L0409 | 1 | 1 | Mine | no | 6 | 2 | 6 | 3 | 0 | 0 | 0 | 112 |
| L0409 | 1 | 1 | Opponent | no | 0 | 4 | 0 | 1 | 0 | 0 | 0 | 265 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | 5 | 0 | 1 | 0 | 0 | 0 | 475 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0528 | 6 | 1 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 798 |
| L0616 | 4 | 1 | Opponent | no | 3 | - | 1 | 0 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 1 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 1 | 3 | 1 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 16 | 2 | 3 | 0 | 0 | 0 | 0 | 165 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 707 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 6 | 0 | 0 | 0 | 75 |
| L0918 | 6 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 6 | - | 2 | 0 | 0 | 0 | 0 | 462 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 908 |
| L0934 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 5 | 1 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 5 | 3 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 6 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 5 | 2 | 2 | 0 | 0 | 0 | 185 |
| L1135 | 1 | 1 | Mine | yes | 10 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | - | 2 | 3 | 0 | 0 | 0 | 114 |
| L1228 | 4 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 479 |
| L1323 | 3 | 1 | Opponent | yes | 5 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 1 | 3 | 3 | 1 | 0 | 0 | 0 | 177 |
| L1435 | 1 | 1 | Opponent | no | 1 | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 2 | 5 | 2 | 0 | 0 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 3 | 6 | 4 | 0 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 6 | 0 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | no | - | 2 | 4 | 6 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 8 | 5 | 3 | 0 | 2 | 0 | 0 | 305 |
| L1827 | 3 | 1 | Opponent | no | 11 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | yes | 3 | 2 | 7 | 0 | 0 | 0 | 0 | 490 |
| L1927 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 60 |
| **Average** | | | Mine | 26% | 2.9 | 2.8 | 2.0 | 1.2 | 0.1 | 0.0 | 0.0 | 372.1 |
| **Average** | | | Opponent | 22% | 3.7 | 3.0 | 2.7 | 1.8 | 0.2 | 0.0 | 0.0 | 146.6 |

### KPIs: t10-opp-ba3e30a-p2

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 29 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 34% (47 of 140) | 11% (16 of 149) | 22% (63 of 289) |
| Winner chose to follow up after the loser gave ground |  | 98% (53 of 54); on the table 98% | 77% (33 of 43); on the table 86% | 89% (86 of 97); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 67% | 81% (13 of 16); on the table 81% | 79% (15 of 19); on the table 79% |
| Winner chose to pursue after the loser fled |  | 47% (9 of 19); on the table 63% | 67% (18 of 27); on the table 67% | 59% (27 of 46); on the table 65% |
| Winner chose to follow up or pursue (all three) |  | 84% (64 of 76); on the table 88% | 74% (64 of 86); on the table 79% | 79% (128 of 162); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 39% (116 of 300) | 28% (38 of 138) | 35% (154 of 438) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (116 of 254) | 33% (38 of 114) | 42% (154 of 368) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (6 of 9) | 56% (20 of 36) | 58% (26 of 45) |
| Points that never fought | lower | 43% (24922 of 57588) | 47% (27332 of 57991) | 45% (52254 of 115579) |
|   infantry points that never fought | lower | 49% (6456 of 13093) | 65% (6726 of 10360) | 56% (13182 of 23453) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (142 of 238) | 59% (132 of 225) | 59% (274 of 463) |
| Bound items with a magic missile used (at least once a game) |  | 79% (15 of 19); 1.7 uses a game | 83% (10 of 12); 0.8 uses a game | 81% (25 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 61% (11 of 18); 1.1 uses a game | 50% (1 of 2); 0.2 uses a game | 60% (12 of 20); 0.6 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (9 of 17); 0.3 uses a game | 17% (1 of 6); 0.0 uses a game | 43% (10 of 23); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (26872 of 48921) | 53% (26450 of 49551) | 54% (53322 of 98472) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.2 (51%) | 1.0 (28%) | 4.2 (43%) |
| MARCHED: its unit marched | 0.8 (13%) | 1.0 (28%) | 1.8 (18%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.2 (6%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.2 (20%) | 0.5 (14%) | 1.7 (18%) |
| REAR RANK: in a rear rank | 0.5 (8%) | 0.3 (8%) | 0.8 (8%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.2 (4%) | 0.3 (9%) | 0.6 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.8 | 1.4 | 5.3 | 0.4 | 1.3 |
| not cast | 3.6 | 3.2 | 3.7 | 9.8 | 1.6 | 19.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.9 (59%) | 0.3 (9%) | 4.2 (43%) | 0.4 (26%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (18%) | 0.4 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.2 (8%) | 0.5 (13%) | 1.7 (18%) | 0.2 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.4 (13%) | 0.5 (14%) | 0.8 (8%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.9 (26%) | 0.2 (5%) | 0.4 (10%) | 0.6 (6%) | 0.0 (2%) | 1.6 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (5%) | 0.2 (8%) | 0.0 (0%) | 0.1 (1%) | 0.5 (30%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (52%) | 0.1 (4%) | 1.9 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.8 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.7 a game | 0.8 a game |
| stood (cast and not dispelled) | 70% (16 of 23) | 60% (12 of 20) | 65% (28 of 43) |
| the unit moved after it | 62% (10 of 16) | 83% (10 of 12) | 71% (20 of 28) |
| it charged on its next turn | 0% (0 of 16) | 17% (2 of 12) | 7% (2 of 28) |
| the enemy charged it first | 6% (1 of 16) | 0% (0 of 12) | 4% (1 of 28) |
| it fought by the end of its next turn | 6% (1 of 16) | 0% (0 of 12) | 4% (1 of 28) |
| it moved out of a charge the enemy had planned (not charged first) | 6% (1 of 16) | 8% (1 of 12) | 7% (2 of 28) |
| none of these (no charge, no fight, no charge escaped) | 88% (14 of 16) | 75% (9 of 12) | 82% (23 of 28) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (558 of 799) | 61% (406 of 669) | 66% (964 of 1468) |
|   cavalry | 58% (42 of 73) | 62% (63 of 101) | 60% (105 of 174) |
|   character | 61% (62 of 102) | 35% (26 of 75) | 50% (88 of 177) |
|   chariot | 58% (49 of 85) | 71% (39 of 55) | 63% (88 of 140) |
|   infantry | 67% (143 of 212) | 58% (158 of 271) | 62% (301 of 483) |
|   monster | 45% (21 of 47) | 62% (26 of 42) | 53% (47 of 89) |
|   war machine | 86% (241 of 280) | 75% (94 of 125) | 83% (335 of 405) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (22%) | 2.1 (24%) | 3.9 (23%) |
| CHARGED: it charged | 1.2 (14%) | 1.2 (13%) | 2.4 (14%) |
| FLEEING: it fled or was fleeing | 0.3 (4%) | 0.2 (2%) | 0.5 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (9%) | 0.4 (5%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.2 (2%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.6 (19%) | 2.1 (24%) | 3.7 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.7 (7%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (21%) | 1.4 (15%) | 3.1 (18%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.2 (2%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.2 (2%) | 0.5 (5%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.9 | 0.9 | 86% | 3.5 pts | 21 pts |
| character | 3.3 | 1.7 | 70% | 12.3 pts | 41 pts |
| chariot | 3.1 | 2.1 | 65% | 15.9 pts | 49 pts |
| infantry | 14.7 | 5.2 | 75% | 7.2 pts | 105 pts |
| monster | 1.8 | 0.4 | 79% | 5.4 pts | 10 pts |
| war machine | 11.6 | 11.5 | 58% | 30.8 pts | 356 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 5.1 | 4.2 |
| Charges that made contact a game | 2.8 | 3.6 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.74 declared, 0.53 contact (19 units) | 1.23 declared, 0.92 contact (13 units) | 0.94 declared, 0.69 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.20 declared, 1.20 contact (5 units) | 1.08 declared, 0.75 contact (12 units) | 1.12 declared, 0.88 contact (17 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.34 contact (190 units) | 0.49 declared, 0.35 contact (243 units) | 0.45 declared, 0.34 contact (433 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (32 of 56) | 40% (4 of 10) | 45% (5 of 11) | 53% (41 of 77) |
| Character in a unit | 76% (28 of 37) | 73% (11 of 15) | 33% (1 of 3) | 73% (40 of 55) |
| Character on its own | 95% (21 of 22) | 48% (15 of 31) | 30% (14 of 46) | 51% (50 of 99) |
| Chariot | 67% (10 of 15) | 54% (7 of 13) | - | 61% (17 of 28) |
| Infantry | 57% (38 of 67) | 54% (14 of 26) | 33% (1 of 3) | 55% (53 of 96) |
| Monster | 57% (13 of 23) | 60% (3 of 5) | - | 57% (16 of 28) |
| Monstrous | 57% (4 of 7) | 79% (11 of 14) | - | 71% (15 of 21) |
| War Machines | 70% (40 of 57) | 100% (2 of 2) | - | 71% (42 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (9 of 9); on the table 100% | 29% (30 of 102) | 47% | 64% (14 of 22) | 83% (5 of 6); 4.2 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 80% (4 of 5); on the table 80% | 50% (18 of 36) | 52% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 67% (8 of 12); on the table 83% | - | 65% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 71% (10 of 14); on the table 71% | 40% (19 of 48) | 34% | 59% (45 of 76) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 61% (11 of 18); on the table 67% | 39% (54 of 138) | 62% | 44% (24 of 54) | 79% (11 of 14); 5.5 uses a game | 0% (0 of 2); 0.0 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 81% (13 of 16); on the table 81% | 28% (5 of 18) | 22% | 61% (20 of 33) | 100% (3 of 3); 2.2 uses a game | 64% (9 of 14); 6.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 91% (10 of 11); on the table 91% | - | 51% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 67% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 67% (2 of 3); on the table 100% | 0% (0 of 18) | 49% | 79% (22 of 28) | 75% (3 of 4); 1.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 25% (3 of 12) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 86% (6 of 7); on the table 86% | 0% (0 of 6) | 46% | 67% (6 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 4 | 91% (10 of 11); on the table 91% | - | 43% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 82% (23 of 28); on the table 89% | 47% (17 of 36) | 34% | 57% (20 of 35) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 5 | 54% (7 of 13); on the table 62% | 39% (7 of 18) | 38% | 56% (23 of 41) | 100% (1 of 1); 0.4 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 3 | 100% (8 of 8); on the table 100% | 17% (1 of 6) | 56% | 66% (21 of 32) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t10-opp-ba3e30a-p2, 29 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (29) | 46% (21) | 48% (50) |
| ...free all their last turn and able to turn (per game) | 0.48 | 0.59 | 1.07 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.24 | 0.07 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.45 | 0.45 | 0.90 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.59 | 0.00 | 1.59 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.86 | 0.07 | 0.93 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.59 | 0.38 | 4.97 |

### Quality by phase: t10-opp-ba3e30a-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 2.6 |
| Strategy | Charge objectives carried out (made contact) | 59% (46 of 78) | 52% (75 of 143) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (180 of 422) | 50% (111 of 221) |
| Strategy | Close-in objectives charged next turn | 7% (9 of 129) | - |
| Strategy | Support requests answered (helper made contact too) | 50% (7 of 14) | 47% (8 of 17) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 67% (2 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 27% (4 of 15) | 33% (3 of 9) |
| Strategy | Joined characters whose unit fought | 53% (29 of 55) | 24% (8 of 33) |
| Strategy | Lone characters that fought | 61% (38 of 62) | 76% (54 of 71) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 372.1 | 146.6 |
| Movement | Fights charged into per game | 2.4 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 58, net +22 | 22 of 83, net -16 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 58, net +89 | 13 of 83, net +84 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 58, net -8 | 4 of 83, net +74 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 of 58, net +41 | 17 of 83, net +61 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.0 | 11.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (155 of 349) | 46% (157 of 343) |
| Shooting | Points destroyed by shooting units | 73.2 | 38.3 |
| Shooting | War machine shots | 8.3 | 3.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (148 of 241) | 70% (66 of 94) |
| Shooting | Points destroyed by war machines | 121.2 | 16.1 |
| Magic | Magic missiles cast | 2.6 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (21 of 74) | 30% (8 of 27) |
| Magic | Wounds caused by magic missiles | 4.6 | 1.1 |
| Magic | Wounds caused by other spells | 1.1 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 62.8 | 31.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.8 / 0.6 / 0.5 / 0.1 | 2.1 / 0.3 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 258.6 | 277.3 |
| Combat | Points run down | 68.4 | 63.8 |
| Combat | Net points per charged fight, damage counted | +63 | +55 |
| Combat | Net per 100 charger points, damage counted | +23.6 | +22.8 |
| Combat | First round won (charged fights) | 76% | 71% |
| Combat | Net points per charged fight | +58 | +52 |
| Combat | Net points per supported fight / lone fight | +34 / +62 | +57 / +51 |
| Combat | Charged fights on a top-3 enemy unit | 19 of 70 | 40 of 96 |
| Game | Points lost | 581.1 | 593.8 |
| Game | VP from objectives | 422.4 | 771.4 |
| Game | Lone holders (player turns) | 2.9 | 3.7 |

- Mine won / drew / lost: 7 / 6 / 16 of 29 ended games (of 29); mean margin (Mine - Opponent) -386 VP
- The side that went first won 13 of 23 games with a winner
- Points traded per game (both sides' losses): 1175
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t10-opp-ba3e30a-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 2.6 |
| ADVANCE WORTH | 5.4 | -76.0 | 175.9 | 56.8 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +38.0 | 0.0 | 23.7 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.2 | +5.7 | 0.0 | 1.6 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | - | - | - | - | 14.0 | +119.8 | 0.0 | 236.0 |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.6 | +0.0 | 0.0 | 28.1 | 0.6 | +0.0 | 0.0 | 15.7 |
| BACKUP TARGETS | 0.5 | +2.5 | 0.0 | 8.9 | 0.4 | +2.1 | 0.0 | 9.6 |
| BEST FACING | 0.4 | +14.7 | 0.0 | 8.2 | - | - | - | - |
| BEST FIRST | 1.4 | +83.5 | 37.8 | 19.9 | - | - | - | - |
| BEST MOVE FOR SHOOTERS | 1.1 | +56.3 | 0.0 | 17.1 | - | - | - | - |
| BEST OVERALL | 0.3 | +18.9 | 0.0 | 6.4 | - | - | - | - |
| BEST PREY | 1.1 | +55.1 | 26.8 | 14.9 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.1 | -7.5 | 3.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 1.4 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.2 | +9.5 | 0.0 | 6.3 | - | - | - | - |
| BLOWS WHERE AIMED | 0.1 | -4.3 | 14.1 | 3.6 | 0.2 | -26.2 | 18.3 | 29.8 |
| BOMBING RUN | 0.1 | +3.4 | 9.6 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.2 | +0.0 | 0.0 | 18.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.1 | +0.0 | 178.4 | 6.7 | 0.4 | +0.0 | 14.8 | 3.4 |
| CANNON PLANNED TARGET | 7.6 | +220.0 | 674.6 | 127.1 | 2.9 | +45.1 | 76.7 | 19.1 |
| CANNON SIGHT KEPT | 1.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 6.7 | 1.8 | 0.1 | -1.8 | 9.2 | 0.0 |
| CAST JOB | 1.4 | +31.1 | 74.0 | 26.3 | 0.3 | +3.4 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +30.2 | 28.9 | 12.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 7.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.1 | +68.3 | 0.0 | 31.1 | 0.7 | +29.2 | 0.0 | 5.5 |
| CHAFF PASSED | 0.3 | -0.1 | 7.7 | 0.0 | 0.1 | -0.1 | 0.0 | 2.8 |
| CHARACTER GUNS | - | - | - | - | 0.3 | +0.0 | 0.0 | 7.7 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.1 | +6.7 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 5.8 | -332.6 | 0.0 | 226.9 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 12.8 | 0.0 | 0.1 | +0.0 | 9.8 | 2.1 |
| CHARGE NOW FIRST | 2.5 | +0.0 | 165.5 | 46.8 | 2.0 | +0.0 | 197.1 | 96.3 |
| CHARGE NOW WEIGHED | 0.2 | -22.2 | 5.6 | 0.0 | - | - | - | - |
| CHARGER SLAIN LOST | 0.3 | -19.4 | 37.8 | 22.5 | 0.5 | -17.1 | 33.4 | 26.2 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 2.1 | - | - | - | - |
| COMBAT PIVOT | 0.5 | +0.0 | 17.8 | 22.1 | 0.3 | +0.0 | 14.0 | 8.1 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +94.2 | 0.0 | 0.0 | 0.6 | +44.5 | 5.4 | 23.4 |
| COVER ONCE | 8.1 | -645.1 | 0.0 | 112.6 | 6.4 | -463.6 | 0.0 | 91.5 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 36.9 | 3.6 | - | - | - | - |
| DEPLOY BY FIGURES | 8.2 | -9.8 | 0.0 | 8.6 | 7.9 | +88.1 | 0.0 | 16.5 |
| EDGE GIVE GROUND | 0.1 | +1.1 | 13.0 | 0.0 | 0.4 | +14.8 | 67.4 | 8.2 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +134.9 | 0.0 | 32.4 | - | - | - | - |
| FALL BACK GOOD ORDER | - | - | - | - | 3.5 | +4.5 | 278.6 | 131.4 |
| FALLBACK BY WORTH | 3.8 | +50.7 | 0.0 | 45.4 | 0.4 | +2.3 | 0.0 | 4.0 |
| FALLS SHORT | - | - | - | - | 19.5 | +280.9 | 0.0 | 236.9 |
| FEATURE BUFFS | - | - | - | - | 0.4 | +6.8 | 0.0 | 4.7 |
| FIGHT LIFT | 0.1 | +2.8 | 6.9 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 2.1 | +87.5 | 201.4 | 96.7 |
| FIRE AND FLEE | 0.0 | +0.3 | 19.7 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.1 | +0.0 | 10.4 | 0.0 | 0.2 | +0.0 | 1.8 | 3.9 |
| FIVE ACTION | - | - | - | - | 48.8 | +2929.8 | 568.6 | 665.7 |
| FLANK NOT WEIGHED | 4.4 | +0.0 | 0.0 | 61.4 | 5.1 | +0.0 | 0.0 | 96.1 |
| FOCUS FIRE | 0.0 | +0.0 | 2.8 | 0.0 | 0.1 | +2.4 | 4.2 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +64.0 | 0.0 | 18.7 | 0.6 | +148.5 | 0.0 | 24.3 |
| FOUR ROUNDS | - | - | - | - | 5.0 | +430.4 | 389.1 | 168.5 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.2 | -30.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.5 | -10.6 | 0.0 | 10.2 |
| FRIENDS SHOTS CHECKED | 0.3 | +4.0 | 0.0 | 0.0 | 0.2 | +3.2 | 0.0 | 0.0 |
| GATEWAY ESCAPE | - | - | - | - | 0.0 | +2.1 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -1.4 | 0.0 | 0.0 | 0.2 | -4.5 | 13.9 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.0 | 4.2 | 0.0 |
| GROUND FLIERS | 0.0 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.2 | +24.1 | 64.4 | 21.2 | 1.0 | +22.2 | 2.9 | 6.4 |
| GUN MASK | - | - | - | - | 0.3 | +2.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | - | - | - | - | 2.7 | +0.0 | 0.0 | 57.8 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HILL BY ITS CHANCE | 0.5 | -59.6 | 0.0 | 4.5 | - | - | - | - |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +16.3 | 14.5 | 14.7 |
| HIS CHARGE LIST | - | - | - | - | 3.1 | +0.0 | 0.0 | 67.7 |
| HIS FIGHT TOGETHER | - | - | - | - | 0.9 | -56.6 | 0.0 | 41.1 |
| HIS LEGAL MOVES | - | - | - | - | 3.2 | +0.0 | 0.0 | 91.5 |
| HIS MOVE AND SHOT | - | - | - | - | 2.0 | -35.8 | 0.0 | 82.8 |
| HIS OWN BEST MOVE | - | - | - | - | 2.1 | +0.0 | 0.0 | 20.0 |
| HIS RANDOM MOVE | - | - | - | - | 1.2 | +0.0 | 0.0 | 11.0 |
| HIS SHOT LIST | - | - | - | - | 25.0 | +1248.3 | 0.0 | 315.2 |
| HIS TURN DENIED | - | - | - | - | 2.8 | +102.8 | 238.3 | 135.6 |
| HOLDER ASSIGNMENT | - | - | - | - | 12.6 | +1154.1 | 0.0 | 59.7 |
| HOLDER AT DEPLOYMENT | 0.8 | +145.9 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.9 | -117.7 | 318.5 | 117.1 | 4.2 | -169.4 | 331.9 | 122.6 |
| HUNT ADVANCE | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +15.4 | 0.0 | 7.5 | 0.7 | +22.1 | 0.0 | 7.5 |
| HUNT KEPT | 0.1 | +0.1 | 0.0 | 1.8 | - | - | - | - |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 1.8 | 0.1 | +28.7 | 0.0 | 2.3 |
| HUNT THE GUNS | 0.1 | +12.2 | 0.0 | 0.0 | 0.1 | +53.9 | 12.9 | 2.3 |
| IDLE COST | 14.1 | -255.6 | 0.0 | 113.8 | 12.4 | -163.9 | 0.0 | 192.8 |
| INVITES THE FIGHT | 1.3 | +9.9 | 24.4 | 12.7 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 1.4 | +85.3 | 110.0 | 42.8 |
| JOINT CHARGE PLAN | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -4.4 | 0.0 | 1.8 | 0.1 | -1.3 | 12.8 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.1 | +8.1 | 4.7 | 0.0 |
| KEEP FALLS | 0.1 | +3.6 | 0.0 | 9.3 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.1 | +34.1 | 103.6 | 27.7 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.1 | +60.9 | 99.8 | 32.5 | - | - | - | - |
| KILLS COUNT NEXT TURN | 4.3 | +159.4 | 123.5 | 102.9 | - | - | - | - |
| LANE BY FIGURES | 0.7 | +24.9 | 0.0 | 0.0 | 0.9 | +47.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 6.6 | +0.0 | 203.1 | 196.0 |
| LONE CHARACTER SAFE SPOT | 0.2 | +8.3 | 0.0 | 0.0 | 0.1 | +1.5 | 0.0 | 4.0 |
| LONE WIZARD KEPT IN | 0.7 | +42.7 | 0.0 | 0.0 | 0.3 | +30.0 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.8 | 23.9 | 4.1 | 0.3 | -0.5 | 2.2 | 2.1 |
| LOST CHARGE | 2.3 | -29.0 | 71.8 | 49.7 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -16.0 | 0.0 | 4.7 | 0.1 | -4.6 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +10.8 | 8.1 | 4.7 | 0.3 | +2.8 | 0.0 | 4.0 |
| MANOEUVRE | 0.3 | +2.6 | 0.0 | 1.9 | 1.3 | +15.4 | 0.0 | 6.2 |
| MARCH AT ESCAPER | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 5.4 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +17.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.2 | +4.4 | 0.0 | 0.0 | 0.6 | +35.1 | 0.0 | 22.0 |
| MARCH ODDS | 0.4 | +19.3 | 7.9 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.4 | +26.6 | 0.0 | 5.8 | 0.7 | +47.6 | 0.0 | 10.9 |
| MAX FOR POSITIONING | 6.5 | +85.4 | 0.0 | 86.0 | 7.2 | +78.7 | 0.0 | 106.7 |
| MISSILES IN THE MOVE | 5.1 | +112.2 | 0.0 | 50.9 | 2.7 | +38.8 | 0.0 | 31.8 |
| MISSILES NEXT TURN | 5.6 | +84.6 | 0.0 | 53.7 | 3.8 | +37.1 | 0.0 | 61.3 |
| MODEL FACING | 0.2 | +83.4 | 0.0 | 0.0 | 0.2 | +47.3 | 0.0 | 4.1 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 8.7 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.4 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 2.8 | +0.0 | 34.2 | 37.1 |
| MOVE SPELL IN RANGE | 0.2 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -15.0 | 5.8 | 14.0 | 0.2 | -6.4 | 6.4 | 9.4 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.2 | +128.0 | 141.8 | 54.8 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 5.4 | +681.6 | 0.0 | 61.4 |
| MOVES UNITS SPELL | 0.1 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | - | - | - | - | 4.1 | +183.3 | 0.0 | 25.6 |
| NEXT CHARGE BY LIST | - | - | - | - | 6.0 | -215.8 | 0.0 | 80.9 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 5.4 | -170.4 | 39.1 | 58.9 |
| NO DOUBLE ROUNDS | - | - | - | - | 3.6 | -138.2 | 280.9 | 98.5 |
| NOT NEEDED | 0.1 | -8.6 | 14.4 | 2.1 | - | - | - | - |
| NOT TURNED | 4.6 | +94.8 | 0.0 | 59.6 | 0.4 | +0.1 | 0.0 | 2.9 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.4 | -0.3 | 0.0 | 2.1 |
| OFF BEST | 17.4 | -746.6 | 0.0 | 293.7 | 1.2 | -33.7 | 0.0 | 5.0 |
| ONE CHARGE A CHARGER | - | - | - | - | 2.7 | +0.0 | 0.0 | 30.5 |
| ONE FIGHT FORMULA | 8.9 | -145.0 | 23.0 | 99.0 | 7.8 | -155.3 | 0.0 | 148.2 |
| ONE OBJECTIVE FORMULA | 2.4 | -121.6 | 0.0 | 15.0 | 3.0 | -24.4 | 0.0 | 20.0 |
| ONE TARGET A SHOOTER | - | - | - | - | 20.0 | +612.3 | 0.0 | 217.7 |
| OPENS A LANE | 0.1 | +1.1 | 1.9 | 0.0 | - | - | - | - |
| OPENS UP | 0.1 | +5.8 | 5.2 | 0.0 | 0.4 | +16.3 | 24.4 | 0.0 |
| OVERRUNS AWAY | 0.3 | +11.0 | 28.6 | 7.0 | 0.8 | +36.5 | 70.3 | 34.9 |
| PATHS CROSS | 1.2 | +81.1 | 0.0 | 15.3 | 3.6 | +158.5 | 0.0 | 34.6 |
| PIVOT GUARDS FLANK | 0.0 | -0.9 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 0.0 |
| PLAN RESULT | 38.3 | +1594.2 | 1214.0 | 845.1 | 43.5 | +654.1 | 328.1 | 895.9 |
| PURSUES BIG PREY | 0.1 | -14.3 | 0.0 | 10.7 | 0.0 | -1.2 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.3 | +8.5 | 0.0 | 5.9 | 1.2 | +32.2 | 0.0 | 12.2 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.8 | -23.4 | 0.0 | 24.3 | 0.4 | -9.3 | 0.0 | 5.0 |
| REDIRECT COUNTER | 2.4 | +195.5 | 0.0 | 47.9 | 3.3 | +276.2 | 0.0 | 42.7 |
| REDIRECT WEIGHED | 0.1 | +2.5 | 4.3 | 0.0 | 0.2 | -4.9 | 12.2 | 7.8 |
| REFORMS TO MEET IT | - | - | - | - | 0.6 | -16.7 | 0.0 | 3.1 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 2.1 |
| RESERVE FALL BACK | 0.3 | +8.2 | 0.0 | 12.6 | 0.7 | +26.5 | 0.0 | 12.0 |
| RESTRAINS TO SHOOT | 0.1 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.8 | +94.0 | 128.2 | 57.4 | 3.0 | -14.9 | 237.0 | 81.4 |
| RISK BY HIS FIGURE | - | - | - | - | 13.1 | -194.6 | 0.0 | 250.7 |
| RISK ONCE | 3.1 | +71.4 | 8.4 | 84.2 | - | - | - | - |
| RUN DOWN | - | - | - | - | 3.8 | -42.1 | 305.3 | 90.9 |
| SAFER THAN THE JOB | 0.9 | +28.1 | 0.0 | 6.4 | 0.1 | +0.8 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -1.9 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 1.9 | 0.6 | +2.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 1.9 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -11.0 | 0.0 | 2.1 | 0.2 | -10.4 | 0.0 | 1.0 |
| SEARCH SPOT | 2.7 | +87.6 | 0.0 | 29.7 | 7.0 | +241.1 | 0.0 | 102.8 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.0 | 4.3 | 1.2 |
| SELF MOVE SPELL | 0.4 | +28.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | - | - | - | - | 0.8 | -19.6 | 12.1 | 8.4 |
| SET UP TOGETHER | 0.5 | +18.5 | 21.9 | 4.7 | 0.8 | +6.5 | 0.0 | 29.0 |
| SET-UP ANY TARGET | 0.2 | +13.2 | 0.0 | 0.0 | 0.1 | +7.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.2 | -1.0 | 0.0 | 2.1 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +46.7 | 46.9 | 5.6 | 1.0 | +28.2 | 16.0 | 8.9 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.5 | -42.0 | 12.6 | 10.5 |
| SHOT RISK POINTS | - | - | - | - | 12.8 | +11.2 | 0.0 | 229.3 |
| SHOTS IN THE MOVE | 16.5 | +661.7 | 0.0 | 263.1 | 14.8 | +366.0 | 0.0 | 179.9 |
| SPELL SETS UP CHARGE | 0.3 | +87.4 | 0.0 | 0.0 | 0.1 | +7.5 | 0.0 | 0.0 |
| SPELL WORTH | 0.8 | +12.5 | 6.9 | 0.0 | 1.8 | +22.8 | 67.9 | 67.9 |
| SPELLS IN THE FIGHT | 0.4 | +2.2 | 52.3 | 4.9 | 0.9 | -1.7 | 83.1 | 37.9 |
| STABLE ROLE | 11.0 | +0.0 | 257.0 | 176.7 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.9 | -10.4 | 66.2 | 58.6 |
| STANDS FOR A REASON | - | - | - | - | 1.1 | +0.0 | 16.4 | 35.1 |
| STANDS STILL | - | - | - | - | 13.2 | +0.0 | 179.5 | 107.0 |
| STAY WEIGHED | 0.1 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 19.7 | +83.1 | 644.0 | 275.5 | 16.4 | +128.6 | 146.4 | 203.2 |
| STOPS | - | - | - | - | 0.1 | +4.7 | 12.9 | 2.3 |
| STOPS SHORT OF THE FLANK | 0.3 | +16.3 | 0.0 | 6.9 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.1 | -41.1 | 207.9 | 67.1 | 1.6 | +0.0 | 120.6 | 48.7 |
| SUPPORTS | 3.8 | +49.0 | 120.8 | 24.6 | - | - | - | - |
| SURE REACH TOGETHER | 0.4 | -0.1 | 0.0 | 3.8 | 0.4 | +8.6 | 0.0 | 11.4 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 4.0 | +0.0 | 0.0 | 10.1 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -16.6 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 2.0 | +0.0 | 0.0 | 15.0 |
| THROUGH LINE OF FIRE | 0.2 | +15.4 | 0.0 | 0.0 | - | - | - | - |
| TIED UP BY THE SUM | - | - | - | - | 0.5 | +57.7 | 40.9 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 7.6 | +93.9 | 0.0 | 57.6 |
| TURN WORTH | 0.4 | -30.4 | 15.9 | 5.2 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.1 | +4.1 | 16.7 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 6.4 | -288.1 | 201.0 | 83.1 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.5 | +0.0 | 0.0 | 3.1 |
| WALKS TO THE FIGHT | 1.5 | +9.4 | 32.4 | 15.6 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +9.5 | 20.4 | 15.9 | - | - | - | - |
| WAR ENGINE JOBS | 1.1 | +0.0 | 43.6 | 32.9 | 0.1 | +0.0 | 4.5 | 0.0 |
| WEARS DOWN | 0.9 | +27.6 | 57.3 | 37.7 | - | - | - | - |
| WHO HITS BACK | 0.4 | +33.0 | 0.0 | 5.9 | 0.4 | +54.5 | 0.0 | 7.2 |
| WHOLE FIGHT | 0.1 | +4.6 | 20.7 | 2.2 | 0.6 | +15.7 | 55.7 | 4.7 |
| WHOLE FIGHT GAIN | 0.2 | +17.1 | 21.8 | 0.0 | 0.3 | +16.2 | 15.0 | 0.0 |
| WIDER SPREAD | 1.5 | -0.9 | 154.0 | 63.6 | 3.8 | -7.0 | 318.5 | 95.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.4 | +66.6 | 0.0 | 19.6 |

### Rule changes: t10-opp-ba3e30a-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 541 | 541 | 541 | 18.66 | -22629 | -41.8 |
| HOLDER ASSIGNMENT | 364 | 364 | 345 | 11.90 | +17663 | +51.2 |
| DEPLOY BY FIGURES | 466 | 466 | 283 | 9.76 | +4480 | +15.8 |
| ARMY TABLE | 405 | 405 | 280 | 9.66 | +2691 | +9.6 |
| SEARCH SPOT | 282 | 282 | 263 | 9.07 | +9558 | +36.3 |
| HIS SHOT LIST | 725 | 719 | 236 | 8.14 | +5558 | +23.5 |
| LEGAL CHARGES ONLY | 191 | 191 | 191 | 6.59 | +0 | +0.0 |
| ONE TARGET A SHOOTER | 581 | 575 | 158 | 5.45 | +1775 | +11.2 |
| FIVE ACTION | 1414 | 1406 | 148 | 5.10 | +8365 | +56.5 |
| PATHS CROSS | 138 | 138 | 138 | 4.76 | +6949 | +50.4 |
| SHOTS IN THE MOVE | 908 | 734 | 108 | 3.72 | +3466 | +32.1 |
| MOVE TO CHARGE COMPUTED | 156 | 156 | 94 | 3.24 | +7622 | +81.1 |
| ARTILLERY RE-ROLL WEIGHED | 92 | 92 | 92 | 3.17 | +0 | +0.0 |
| SHOT RISK POINTS | 371 | 368 | 87 | 3.00 | +2855 | +32.8 |
| MOVE ORDER | 80 | 80 | 80 | 2.76 | +0 | +0.0 |
| COVER ONCE | 423 | 266 | 73 | 2.52 | +1263 | +17.3 |
| FOUR ROUNDS | 146 | 145 | 69 | 2.38 | +3818 | +55.3 |
| CANNON SIGHT KEPT | 55 | 55 | 55 | 1.90 | +0 | +0.0 |
| CANNON PLANNED TARGET | 305 | 305 | 54 | 1.86 | -279 | -5.2 |
| MAX FOR POSITIONING | 397 | 301 | 54 | 1.86 | +261 | +4.8 |
| ADVANCE LANE KEPT | 53 | 53 | 53 | 1.83 | +0 | +0.0 |
| MOVE TO CHARGE | 92 | 92 | 51 | 1.76 | +1168 | +22.9 |
| STAY WORTH | 1047 | 940 | 51 | 1.76 | +636 | +12.5 |
| KILLS COUNT NEXT TURN | 125 | 125 | 50 | 1.72 | +1156 | +23.1 |
| IDLE COST | 768 | 490 | 48 | 1.66 | +564 | +11.7 |
| SUPPORTS | 110 | 110 | 47 | 1.62 | +477 | +10.1 |
| FACES THE THREAT | 46 | 46 | 46 | 1.59 | +3911 | +85.0 |
| LANE BY FIGURES | 45 | 45 | 45 | 1.55 | +2085 | +46.3 |
| MISSILES IN THE MOVE | 224 | 146 | 44 | 1.52 | +643 | +14.6 |
| BEST FIRST | 42 | 42 | 42 | 1.45 | +2421 | +57.6 |
| JOINT CHARGE NOW | 41 | 41 | 41 | 1.41 | +2473 | +60.3 |
| REDIRECT COUNTER | 166 | 116 | 39 | 1.34 | +3572 | +91.6 |
| TIME ON OUR SIDE | 220 | 203 | 39 | 1.34 | +88 | +2.2 |
| CHAFF IN THE MOVE | 53 | 53 | 38 | 1.31 | +986 | +25.9 |
| FOLLOW UP WEIGHED | 37 | 37 | 37 | 1.28 | +6162 | +166.5 |
| RISK BY ARC | 139 | 138 | 37 | 1.28 | +1046 | +28.3 |
| ONE FIGHT FORMULA | 483 | 267 | 36 | 1.24 | +116 | +3.2 |
| SHOOTS FROM THE BEST SPOT | 71 | 71 | 35 | 1.21 | +735 | +21.0 |
| WAIT AFTER COSTS | 185 | 185 | 35 | 1.21 | +354 | +10.1 |
| ADVANCE WORTH | 158 | 158 | 33 | 1.14 | +1067 | +32.3 |
| CHARGE NOW FIRST | 130 | 130 | 32 | 1.10 | -1318 | -41.2 |
| FALLBACK BY WORTH | 121 | 121 | 32 | 1.10 | +1537 | +48.0 |
| BEST MOVE FOR SHOOTERS | 31 | 31 | 31 | 1.07 | +1632 | +52.6 |
| FALLS SHORT | 566 | 470 | 30 | 1.03 | +252 | +8.4 |
| HOLDS AMBUSHERS | 30 | 30 | 30 | 1.03 | +0 | +0.0 |
| SCOUT WAITS | 30 | 30 | 30 | 1.03 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 29 | 29 | 29 | 1.00 | +2108 | +72.7 |
| RESERVE FALL BACK | 29 | 29 | 29 | 1.00 | +1006 | +34.7 |
| SAFER THAN THE JOB | 27 | 27 | 27 | 0.93 | +837 | +31.0 |
| RANDOM MOVE BY FIGURES | 45 | 45 | 26 | 0.90 | +1181 | +45.4 |
| COMBAT PIVOT | 25 | 25 | 25 | 0.86 | +0 | +0.0 |
| MANOEUVRE | 48 | 48 | 25 | 0.86 | +544 | +21.7 |
| CHARGE LOSSES | 167 | 167 | 24 | 0.83 | +1891 | +78.8 |
| SHOOTERS IN TWO RANKS | 23 | 23 | 23 | 0.79 | +51 | +2.2 |
| WHO HITS BACK | 23 | 23 | 23 | 0.79 | +1655 | +72.0 |
| CAST JOB | 50 | 50 | 22 | 0.76 | +445 | +20.2 |
| NEXT OBJECTIVE NEARER | 157 | 157 | 22 | 0.76 | +532 | +24.2 |
| NEXT CHARGE BY LIST | 175 | 171 | 20 | 0.69 | +353 | +17.7 |
| HIS TURN DENIED | 82 | 81 | 19 | 0.66 | +469 | +24.7 |
| INVITES THE FIGHT | 37 | 37 | 16 | 0.55 | +111 | +6.9 |
| MARCH CHECK | 24 | 23 | 16 | 0.55 | +211 | +13.2 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.52 | +209 | +13.9 |
| BEST PREY | 31 | 31 | 14 | 0.48 | +491 | +35.1 |
| HARD STAY DROPPED | 14 | 14 | 14 | 0.48 | +0 | +0.0 |
| MODEL FACING | 14 | 14 | 14 | 0.48 | +3791 | +270.8 |
| RISK BY HIS FIGURE | 380 | 378 | 14 | 0.48 | +916 | +65.4 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.48 | +0 | +0.0 |
| WAR ENGINE JOBS | 36 | 36 | 14 | 0.48 | -869 | -62.1 |
| CASTER AWAY FROM SCREEN | 13 | 13 | 13 | 0.45 | +0 | +0.0 |
| FIGHT TO THE END | 60 | 60 | 13 | 0.45 | +630 | +48.5 |
| HOLDER AT DEPLOYMENT | 24 | 24 | 13 | 0.45 | +670 | +51.5 |
| MOVE AND CAST | 13 | 13 | 13 | 0.45 | +180 | +13.8 |
| MARCH ODDS | 12 | 12 | 12 | 0.41 | +29 | +2.4 |
| TIED UP BY THE SUM | 15 | 15 | 12 | 0.41 | +425 | +35.4 |
| BEST FACING | 11 | 11 | 11 | 0.38 | +425 | +38.7 |
| CASTING BLOCK | 22 | 22 | 11 | 0.38 | +353 | +32.1 |
| CHAFF PASSED | 11 | 11 | 11 | 0.38 | -4 | -0.4 |
| FIRE IN ORDER | 11 | 11 | 11 | 0.38 | +0 | +0.0 |
| WALKS TO THE FIGHT | 43 | 43 | 11 | 0.38 | +65 | +5.9 |
| AFTERMATH IN POINTS | 10 | 10 | 10 | 0.34 | +1103 | +110.3 |
| CASTS FROM BEHIND | 10 | 10 | 10 | 0.34 | +0 | +0.0 |
| RISK ONCE | 91 | 66 | 10 | 0.34 | +418 | +41.9 |
| BEST OVERALL | 9 | 9 | 9 | 0.31 | +549 | +61.0 |
| SET UP BY THE SET | 22 | 22 | 9 | 0.31 | +489 | +54.3 |
| SURE REACH TOGETHER | 26 | 24 | 9 | 0.31 | +25 | +2.8 |
| HONEST WORTH | 321 | 319 | 8 | 0.28 | +58 | +7.2 |
| MARCH BY THE SUM | 8 | 8 | 8 | 0.28 | +498 | +62.2 |
| MISSILES NEXT TURN | 273 | 170 | 8 | 0.28 | +23 | +2.8 |
| ONE OBJECTIVE FORMULA | 157 | 102 | 8 | 0.28 | +342 | +42.8 |
| OPENS UP | 14 | 14 | 8 | 0.28 | +222 | +27.8 |
| REFUSING RETIRES | 12 | 12 | 8 | 0.28 | -2 | -0.2 |
| SET UP TOGETHER | 37 | 30 | 8 | 0.28 | +203 | +25.3 |
| STOPS SHORT OF THE FLANK | 8 | 8 | 8 | 0.28 | +474 | +59.2 |
| BLOCKED WHEEL | 7 | 7 | 7 | 0.24 | +274 | +39.2 |
| CHARGE NOW WEIGHED | 7 | 7 | 7 | 0.24 | +646 | +92.3 |
| NEARER NOT NEEDED | 118 | 114 | 7 | 0.24 | +322 | +46.0 |
| OVERRUNS AWAY | 32 | 32 | 7 | 0.24 | +387 | +55.2 |
| REDIRECT WEIGHED | 7 | 7 | 7 | 0.24 | +863 | +123.3 |
| THROUGH LINE OF FIRE | 7 | 7 | 7 | 0.24 | +446 | +63.7 |
| WIDER SPREAD | 154 | 152 | 7 | 0.24 | +40 | +5.8 |
| BOUND ASSAILMENT | 6 | 6 | 6 | 0.21 | +1 | +0.2 |
| CHARGE NOT DECLARED | 6 | 6 | 6 | 0.21 | -98 | -16.3 |
| KILLS COUNT | 33 | 32 | 6 | 0.21 | +243 | +40.5 |
| WHOLE FIGHT GAIN | 16 | 16 | 6 | 0.21 | +156 | +26.0 |
| AFTERMATH WITH FRIENDS | 5 | 5 | 5 | 0.17 | +164 | +32.9 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.17 | -16 | -3.2 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.17 | -450 | -89.9 |
| SUPPORT NARROWED | 193 | 193 | 5 | 0.17 | -62 | -12.5 |
| WOUNDS ON THE RANKS | 41 | 41 | 5 | 0.17 | +182 | +36.4 |
| EDGE GIVE GROUND | 15 | 15 | 4 | 0.14 | +13 | +3.2 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.14 | +0 | +0.0 |
| LOST CHARGE | 68 | 68 | 4 | 0.14 | +29 | +7.3 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.14 | +122 | +30.4 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.14 | -60 | -15.0 |
| SPELLS IN THE FIGHT | 38 | 37 | 4 | 0.14 | +31 | +7.7 |
| STAY WEIGHED | 4 | 4 | 4 | 0.14 | +57 | +14.4 |
| WEARS DOWN | 25 | 25 | 4 | 0.14 | +106 | +26.6 |
| BEST PRIZE | 3 | 3 | 3 | 0.10 | -218 | -72.5 |
| FOCUS FIRE | 3 | 3 | 3 | 0.10 | +71 | +23.6 |
| HIS FIGHT TOGETHER | 27 | 27 | 3 | 0.10 | +27 | +9.0 |
| HUNT IN PAIRS | 30 | 15 | 3 | 0.10 | +206 | +68.5 |
| KEEP FALLS | 3 | 3 | 3 | 0.10 | +275 | +91.8 |
| KEEPS ITS TARGET | 33 | 33 | 3 | 0.10 | +39 | +13.0 |
| MAKE SURE TOGETHER | 19 | 6 | 3 | 0.10 | +86 | +28.7 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.10 | +150 | +50.0 |
| STUCK PIVOT | 3 | 3 | 3 | 0.10 | +0 | +0.0 |
| TWO OR MORE ARRIVE | 5 | 4 | 3 | 0.10 | +26 | +8.6 |
| WHOLE FIGHT | 19 | 19 | 3 | 0.10 | +135 | +44.9 |
| BACKUP TARGETS | 25 | 15 | 2 | 0.07 | +3 | +1.7 |
| BOMBING RUN | 2 | 2 | 2 | 0.07 | +100 | +49.8 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.07 | +193 | +96.7 |
| FALL BACK GOOD ORDER | 102 | 101 | 2 | 0.07 | +2 | +1.0 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.07 | +13 | +6.5 |
| HIS CHARGE DENIED | 10 | 10 | 2 | 0.07 | +42 | +21.2 |
| HIS MOVE AND SHOT | 58 | 58 | 2 | 0.07 | +21 | +10.6 |
| JOINT CHARGE PLAN | 2 | 2 | 2 | 0.07 | +49 | +24.4 |
| JOINT ON THE TABLE | 2 | 2 | 2 | 0.07 | +235 | +117.3 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.07 | +101 | +50.5 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -51 | -51.0 |
| CHARGER SLAIN LOST | 24 | 24 | 1 | 0.03 | +10 | +9.9 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| GUN MASK | 9 | 9 | 1 | 0.03 | +2 | +1.8 |
| HUNT ADVANCE | 3 | 3 | 1 | 0.03 | +4 | +3.6 |
| LONG SHOT | 16 | 16 | 1 | 0.03 | +5 | +5.3 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +28 | +28.2 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +24 | +23.7 |
| STOPS | 4 | 4 | 1 | 0.03 | +4 | +3.6 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 9 | 9 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 46 | 46 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CHARACTER GUNS | 9 | 9 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 7 | 7 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 12 | 12 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 277 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 6 | 6 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 15 | 15 | 0 | 0.00 | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| GIVES UP | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 64 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 77 | 75 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 14 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 89 | 89 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 93 | 93 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 61 | 61 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 36 | 36 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 7 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 3 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 103 | 102 | 0 | 0.00 | - | - |
| NOT NEEDED | 4 | 4 | 0 | 0.00 | - | - |
| NOT TURNED | 144 | 144 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 19 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 78 | 77 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2372 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 34 | 34 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 18 | 18 | 0 | 0.00 | - | - |
| RUN DOWN | 109 | 108 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 26 | 26 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 15 | 15 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 75 | not checked | - | - | - | - |
| STABLE ROLE | 319 | 319 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 27 | 27 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 31 | 31 | 0 | 0.00 | - | - |
| STANDS STILL | 383 | 381 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 115 | not checked | - | - | - | - |
| THE PROMISE ADDS | 6 | 6 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 59 | not checked | - | - | - | - |
| TURN WORTH | 13 | 12 | 0 | 0.00 | - | - |
| WAITS AGAIN | 44 | 44 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: t10-opp-ba3e30a-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 16.21 | 0.55 | 43.7 |
| ARMY TABLE | rule | - | 1.79 | 39.9 |
| HOLDER ASSIGNMENT | rule | - | 1.28 | 18.4 |
| CHARGE NOW FIRST | rule | 0.66 | 0.45 | 41.2 |
| JOINT CHARGE NOW | rule | - | 0.55 | 58.3 |
| CANNON PLANNED TARGET | rule | 0.34 | 0.17 | 19.8 |
| FALLBACK | gate | 0.48 | - | 50.6 |
| WAR ENGINE JOBS | rule | 0.45 | 0.03 | 62.1 |
| PATHS CROSS | rule | - | 0.45 | 15.0 |
| TURN GATE | gate | 0.45 | - | 10.2 |
| AFTERMATH BAND | gate | 0.03 | 0.28 | 2.6 |
| NO REASON | gate | - | 0.28 | 40.3 |
| PURSUES BIG PREY | rule | 0.14 | 0.03 | 89.9 |
| SUPPORT NARROWED | rule | 0.07 | 0.10 | 12.5 |
| CHARGE NOT DECLARED | rule | - | 0.14 | 27.9 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.10 | 4.0 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.10 | 15.0 |
| RULE SWITCHED OFF | gate | 0.14 | - | 12.2 |
| BEST PRIZE | rule | - | 0.10 | 72.5 |
| CHAFF PASSED | rule | 0.07 | 0.03 | 1.2 |
| MARCH ODDS | rule | 0.07 | 0.03 | 9.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 31.2 |
| BIG CHARACTER SAFETY | rule | 0.07 | - | 7.9 |
| FIGHT ORDER BAND | gate | - | 0.07 | 1.2 |
| SAFER THAN THE JOB | rule | 0.07 | - | 7.9 |
| SUPPORT REQUEST | gate | 0.07 | - | 35.6 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 51.0 |
| CHARGE NOW WEIGHED | rule | 0.03 | - | 2.9 |
| DEPLOY BY FIGURES | rule | 0.03 | - | 9.9 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 1.6 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.03 | 11.2 |
| REDIRECT WEIGHED | rule | - | 0.03 | 80.2 |
| SET UP BY THE SET | rule | - | 0.03 | 165.5 |

### Plans: t10-opp-ba3e30a-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.1 | 9% | 201 | 162 | 81% |
| Mine | charge | 2.3 | 65% | 185 | 194 | 105% |
| Mine | close in | 4.4 | 24% | 204 | 119 | 58% |
| Mine | hold | 5.0 | 34% | 329 | 0 | 0% |
| Mine | join | 0.2 | 100% | 8 | 0 | 0% |
| Mine | shoot | 12.4 | 65% | 362 | 1120 | 310% |
| Mine | support | 4.8 | 92% | 34 | 0 | 0% |
| Opponent | charge | 3.9 | 57% | 618 | 314 | 51% |
| Opponent | join | 1.1 | 97% | 43 | 0 | 0% |
| Opponent | move | 31.9 | 94% | 1816 | 0 | 0% |
| Opponent | shoot | 6.1 | 65% | 275 | 340 | 124% |
| Opponent | support | 0.6 | 94% | 8 | 0 | 0% |

### Packages: hunt the guns, t10-opp-ba3e30a-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 177 | 0 | 0% | 21 |
| Opponent | 0.1 | 4 | 0 | 75% | 75% | 0% | 2.0 | 391 | 208 | 75% | 157 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 177 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 89 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 454 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 75% | 75% | 0% | 2.0 | 391 | 208 | 75% | 113 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 805 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 6 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 566 |

### Battle groups: t10-opp-ba3e30a-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.4 | 14% | 70% | 10% | 0% | 22% | 0% | 11% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 21% | 90% | 25% | 0% | 7% | 0% | 20% | 67% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t10-opp-ba3e30a-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 62 | 75% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 20 | 64 (20) | 0 | 64 | 51 | 35% | 2.1 | 124 (8) | 36 (8) | 0 (4) | 80 (16) | 0 (4) |
| Mine | Character | 102 | 43 (102) | 43 | 0 | 17 | 25% | 2.4 | 44 (37) | 34 (36) | 51 (21) | 48 (61) | 28 (33) |
| Mine | Clean-up | 15 | 68 (15) | 25 | 43 | 46 | 33% | 3.0 | 47 (4) | 73 (7) | 82 (4) | 96 (11) | 0 (4) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 37 | 28 (37) | 13 | 15 | 51 | 22% | 2.6 | 31 (15) | 33 (17) | 2 (5) | 33 (25) | 16 (12) |
| Mine | Hammer | 51 | 25 (51) | 19 | 6 | 29 | 20% | 2.4 | 30 (11) | 28 (26) | 15 (14) | 29 (31) | 20 (20) |
| Mine | Holder | 17 | 61 (17) | 0 | 61 | 26 | 59% | 1.9 | 0 (3) | 64 (10) | 106 (4) | 104 (9) | 17 (8) |
| Mine | Shooter | 36 | 37 (36) | 9 | 29 | 36 | 6% | 1.3 | 9 (10) | 55 (20) | 28 (6) | 46 (27) | 15 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 59 | 64 (59) | 64 | 0 | 50 | 3% | 1.2 | 26 (25) | 71 (21) | 117 (13) | 14 (12) | 76 (47) |
| Mine | Wizard | 15 | 19 (15) | 19 | 0 | 16 | 20% | 3.4 | 35 (8) | 0 (3) | 0 (3) | 2 (9) | 72 (5) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.5 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Chaff | 71 | 98 (71) | 25 | 73 | 47 | 32% | 2.8 | 67 (28) | 90 (18) | 138 (25) | 101 (63) | 77 (8) |
| Opponent | Character | 79 | 38 (79) | 38 | 0 | 34 | 23% | 2.6 | 40 (27) | 37 (40) | 43 (6) | 37 (48) | 42 (25) |
| Opponent | Clean-up | 15 | 12 (15) | 0 | 12 | 49 | 40% | 2.0 | 12 (7) | 10 (8) | - | 13 (13) | 0 (2) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 38 | 42 (38) | 27 | 15 | 25 | 32% | 3.0 | 23 (11) | 46 (22) | 83 (5) | 42 (22) | 42 (16) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 35 | 67% | 1.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Hammer | 47 | 35 (47) | 24 | 11 | 35 | 32% | 2.6 | 43 (12) | 35 (26) | 26 (9) | 53 (28) | 13 (19) |
| Opponent | Holder | 28 | 99 (28) | 2 | 97 | 19 | 25% | 2.9 | 85 (8) | 114 (15) | 74 (5) | 150 (15) | 25 (13) |
| Opponent | Shooter | 25 | 86 (25) | 28 | 58 | 27 | 12% | 1.6 | 71 (6) | 102 (11) | 77 (8) | 81 (17) | 95 (8) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 33% | 5.5 | 0 (2) | - | 0 (1) | - | 0 (3) |
| Opponent | War machine | 24 | 21 (24) | 21 | 0 | 24 | 8% | 1.5 | 16 (11) | 0 (5) | 40 (8) | 15 (3) | 22 (21) |
| Opponent | Wizard | 25 | 7 (25) | 7 | 0 | 25 | 0% | 2.2 | 0 (11) | 14 (9) | 0 (1) | 12 (11) | 0 (10) |

### Charged fights: t10-opp-ba3e30a-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 33 | 77 | 1.2 | 1.4 | 62 | 38 | +24 | 2 of 5 | 3 of 5 | -94 | +103 |
| Mine | Chaos Dwarfs | 4 | 135 | 199 | 1.8 | 1.0 | 114 | 0 | +114 | 3 of 7 | 4 of 7 | - | +114 |
| Mine | Dwarfen Mountain Holds | 4 | 319 | 86 | 1.2 | 1.4 | 68 | 24 | +44 | 1 of 5 | 4 of 5 | +72 | +26 |
| Mine | Empire of Man | 5 | 584 | 161 | 1.2 | 1.0 | 134 | 32 | +103 | 3 of 6 | 3 of 6 | - | +103 |
| Mine | Grand Cathay | 4 | 488 | 143 | 2.8 | 1.1 | 52 | 20 | +32 | 2 of 11 | 9 of 11 | +0 | +36 |
| Mine | High Elf Realms | 4 | 94 | 639 | 5.0 | 1.1 | 128 | 26 | +102 | 6 of 20 | 18 of 20 | +88 | +104 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 327 | 4.0 | 1.2 | 82 | 0 | +82 | 0 of 4 | 4 of 4 | +122 | +68 |
| Mine | Lizardmen | 1 | 186 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Ogre Kingdoms | 1 | 75 | 120 | 5.0 | 1.2 | 24 | 150 | -126 | 1 of 5 | 2 of 5 | +0 | -158 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 299 | 6.0 | 1.0 | 50 | 10 | +40 | 1 of 6 | 5 of 6 | - | +40 |
| **Mine** | all armies | 29 | 257 | 211 | 2.4 | 1.1 | 88 | 29 | +58 | 19 of 70 | 53 of 70 | +34 | +62 |
| Opponent | Dwarfen Mountain Holds | 2 | 101 | 60 | 2.5 | 1.2 | 24 | 0 | +24 | 0 of 5 | 4 of 5 | +65 | +14 |
| Opponent | Empire of Man | 2 | 198 | 468 | 3.0 | 1.0 | 156 | 101 | +55 | 2 of 6 | 4 of 6 | - | +55 |
| Opponent | Grand Cathay | 2 | 348 | 706 | 5.0 | 1.1 | 141 | 0 | +141 | 4 of 10 | 9 of 10 | +0 | +157 |
| Opponent | Kingdom of Bretonnia | 1 | 220 | 105 | 1.0 | 1.0 | 105 | 0 | +105 | 0 of 1 | 1 of 1 | - | +105 |
| Opponent | Ogre Kingdoms | 3 | 41 | 148 | 3.7 | 1.1 | 40 | 34 | +6 | 3 of 11 | 5 of 11 | +0 | +7 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 50 | 483 | 3.2 | 1.1 | 149 | 99 | +50 | 6 of 13 | 8 of 13 | +335 | +26 |
| Opponent | Vampire Counts | 6 | 34 | 306 | 4.2 | 1.2 | 74 | 53 | +20 | 12 of 25 | 19 of 25 | +14 | +21 |
| Opponent | Warriors of Chaos | 5 | 35 | 211 | 2.2 | 1.0 | 96 | 10 | +86 | 6 of 11 | 10 of 11 | - | +86 |
| Opponent | Wood Elf Realms | 3 | 91 | 325 | 4.3 | 1.0 | 75 | 10 | +65 | 6 of 13 | 8 of 13 | - | +65 |
| **Opponent** | all armies | 29 | 86 | 304 | 3.3 | 1.1 | 92 | 40 | +52 | 40 of 96 | 68 of 96 | +57 | +51 |

### Effective charges: t10-opp-ba3e30a-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 3 (net +45) | 0 | 0 | 0 | 0 | 1 (net -137) | 1 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 7 | 2 (net +120) | 1 (net +217) | 0 | 2 (net +108) | 1 (net +0) | 0 | 1 | 0% (0 of 6) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net -60) | 0 | 3 (net +26) | 1 (net +205) | 0 | 0 | 0 | 60% (3 of 5) |
| Mine | Empire of Man | 6 | 1 (net +210) | 0 | 2 (net +181) | 0 | 1 (net +0) | 2 (net +23) | 0 | 33% (2 of 6) |
| Mine | Grand Cathay | 11 | 1 (net +15) | 0 | 1 (net +111) | 3 (net +0) | 2 (net +0) | 4 (net +58) | 0 | 9% (1 of 11) |
| Mine | High Elf Realms | 20 | 2 (net -161) | 0 | 3 (net +45) | 6 (net +241) | 4 (net +106) | 4 (net +87) | 1 | 16% (3 of 19) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +205) | 2 (net +0) | 1 (net +122) | 0 | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 0 | 2 (net -316) | 0 | 3 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 2 (net +28) | 0 | 2 (net +32) | 0 | 20% (1 of 5) |
| Opponent | Empire of Man | 6 | 2 (net -144) | 0 | 1 (net -9) | 3 (net +209) | 0 | 0 | 0 | 17% (1 of 6) |
| Opponent | Grand Cathay | 10 | 1 (net +0) | 0 | 1 (net +95) | 6 (net +213) | 1 (net +36) | 1 (net +0) | 0 | 10% (1 of 10) |
| Opponent | Ogre Kingdoms | 11 | 3 (net +30) | 0 | 0 | 0 | 0 | 2 (net +5) | 6 | 0% (0 of 5) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 13 | 4 (net -173) | 0 | 3 (net +289) | 2 (net +70) | 0 | 3 (net +81) | 1 | 25% (3 of 12) |
| Opponent | Vampire Counts | 25 | 6 (net -8) | 1 (net +183) | 1 (net +0) | 8 (net +22) | 3 (net +87) | 4 (net +58) | 2 | 4% (1 of 23) |
| Opponent | Warriors of Chaos | 11 | 4 (net +90) | 0 | 2 (net +0) | 2 (net +58) | 0 | 2 (net +139) | 1 | 20% (2 of 10) |
| Opponent | Wood Elf Realms | 13 | 1 (net +217) | 0 | 4 (net +36) | 3 (net -42) | 0 | 3 (net +69) | 2 | 36% (4 of 11) |

### Charged fights, damage counted: t10-opp-ba3e30a-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 211 | 245 | +22 | 95 | 72 | +23 | +10.8 |
| Mine | 50-54% | 1 | 339 | 189 | +217 | 312 | 0 | +312 | +91.9 |
| Mine | Effective (55-75%) | 10 | 310 | 168 | +89 | 112 | 37 | +75 | +24.4 |
| Mine | 76-89% | 14 | 304 | 189 | +133 | 133 | 6 | +127 | +41.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 221 | 132 | +41 | 106 | 44 | +62 | +28.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 351 | 77 | -8 | 82 | 75 | +7 | +2.0 |
| Mine | No odds | 12 | 191 | 138 | +40 | 55 | 13 | +42 | +21.9 |
| Mine | All fights | 70 | 266 | 158 | +58 | 101 | 38 | +63 | +23.6 |
| Opponent | Long shot (under 50%) | 22 | 244 | 228 | -16 | 78 | 94 | -16 | -6.7 |
| Opponent | 50-54% | 1 | 186 | 228 | +183 | 228 | 45 | +183 | +98.4 |
| Opponent | Effective (55-75%) | 13 | 175 | 217 | +84 | 145 | 59 | +86 | +49.2 |
| Opponent | 76-89% | 26 | 256 | 192 | +87 | 135 | 41 | +94 | +36.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 251 | 160 | +61 | 101 | 34 | +67 | +26.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 455 | 74 | +74 | 74 | 0 | +74 | +16.4 |
| Opponent | No odds | 13 | 206 | 173 | +35 | 116 | 78 | +38 | +18.4 |
| Opponent | All fights | 96 | 242 | 191 | +52 | 113 | 58 | +55 | +22.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t10-opp-ba3e30a-p2 | move | 325 | 54 (17%) | 41 (13%) | 38 (12%) | 233 (72%) |
| t10-opp-ba3e30a-p2 | objective | 129 | 9 (7%) | 8 (6%) | 16 (12%) | 104 (81%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

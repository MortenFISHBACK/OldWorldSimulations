# Doctrine scorecard: t10-mine-ba3e30a-p1

### Scorecard: t10-mine-ba3e30a-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 8 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 3 | 3 | 3 | 3 | 0 | 0 | 0 | 30 |
| L0118 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 1 | 0 | 0 | 225 |
| L0135 | 3 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 137 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 2 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 10 | 6 | 1 | 0 | 0 | 0 | 0 | 455 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 6 | 4 | 0 | 1 | 0 | 0 | 0 | 1331 |
| L0421 | 1 | 1 | Mine | no | 4 | 1 | 8 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | - | 1 | 4 | 0 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 10 | - | 0 | 3 | 0 | 0 | 0 | 285 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 769 |
| L0524 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 508 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 9 | - | 0 | 1 | 0 | 0 | 0 | 360 |
| L0612 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 1455 |
| L0628 | 4 | 1 | Opponent | yes | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 1 | 4 | 3 | 1 | 0 | 0 | 0 | 170 |
| L0717 | 3 | 1 | Opponent | yes | 6 | 2 | 2 | 1 | 3 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 3 | 1 | 2 | 0 | 0 | 0 | 0 | 189 |
| L0733 | 1 | 1 | Opponent | no | 6 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 6 | 6 | 1 | 1 | 0 | 0 | 0 | 255 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 555 |
| L0913 | 1 | 1 | Opponent | no | 15 | 2 | 3 | 1 | 1 | 0 | 0 | 291 |
| L0930 | 6 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 442 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Opponent | no | 2 | - | 1 | 6 | 0 | 0 | 0 | 500 |
| L1114 | 4 | 1 | Mine | no | 3 | 2 | 0 | 0 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 1 | 2 | 0 | 0 | 1 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 5 | - | 3 | 1 | 0 | 0 | 0 | 165 |
| L1131 | 3 | 1 | Opponent | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 14 | 2 | 2 | 1 | 0 | 0 | 0 | 345 |
| L1319 | 5 | 1 | Mine | no | - | 2 | 1 | 1 | 0 | 0 | 0 | 317 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 7 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 6 | 2 | 3 | 0 | 0 | 0 | 624 |
| L1431 | 3 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | no | 6 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Opponent | yes | - | 4 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 1 | 4 | 4 | 0 | 1 | 0 | 0 | 175 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 16% | 4.0 | 2.8 | 1.9 | 1.0 | 0.1 | 0.0 | 0.0 | 234.2 |
| **Average** | | | Opponent | 16% | 2.8 | 2.5 | 2.4 | 1.7 | 0.4 | 0.0 | 0.0 | 199.3 |

### KPIs: t10-mine-ba3e30a-p1

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 27 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (52 of 130) | 5% (6 of 125) | 23% (58 of 255) |
| Winner chose to follow up after the loser gave ground |  | 80% (24 of 30); on the table 87% | 100% (22 of 22); on the table 100% | 88% (46 of 52); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (3 of 4); on the table 75% | 78% (7 of 9); on the table 78% | 77% (10 of 13); on the table 77% |
| Winner chose to pursue after the loser fled |  | 71% (10 of 14); on the table 86% | 85% (17 of 20); on the table 100% | 79% (27 of 34); on the table 94% |
| Winner chose to follow up or pursue (all three) |  | 77% (37 of 48); on the table 85% | 90% (46 of 51); on the table 96% | 84% (83 of 99); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 40% (114 of 288) | 36% (61 of 168) | 38% (175 of 456) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (114 of 213) | 45% (61 of 135) | 50% (175 of 348) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (7 of 12) | 60% (29 of 48) | 60% (36 of 60) |
| Points that never fought | lower | 42% (22367 of 53488) | 47% (25498 of 53892) | 45% (47865 of 107380) |
|   infantry points that never fought | lower | 45% (6052 of 13416) | 71% (7246 of 10204) | 56% (13298 of 23620) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (119 of 219) | 59% (131 of 223) | 57% (250 of 442) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 2.7 uses a game | 76% (13 of 17); 1.6 uses a game | 86% (32 of 37); 2.1 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.8 uses a game | 38% (3 of 8); 0.2 uses a game | 54% (13 of 24); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (10 of 16); 0.4 uses a game | 50% (5 of 10); 0.2 uses a game | 58% (15 of 26); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (22084 of 44993) | 55% (26136 of 47293) | 52% (48220 of 92286) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (26%) | 1.3 (33%) | 3.0 (28%) |
| MARCHED: its unit marched | 1.9 (29%) | 0.7 (18%) | 2.6 (25%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.4 (10%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.6 (25%) | 0.5 (12%) | 2.1 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.6 (9%) | 0.6 (14%) | 1.1 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (9%) | 0.2 (5%) | 0.8 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 2.1 | 1.8 | 6.5 | 0.4 | 2.4 |
| not cast | 3.1 | 3.1 | 3.1 | 10.4 | 2.2 | 23.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (51%) | 0.3 (11%) | 3.0 (28%) | 0.5 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.6 (25%) | 0.4 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.0 (1%) | 0.4 (14%) | 2.1 (20%) | 0.5 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (14%) | 0.4 (14%) | 0.4 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.6 (19%) | 0.4 (12%) | 0.6 (19%) | 1.1 (11%) | 0.2 (10%) | 2.6 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.4 (12%) | 0.0 (0%) | 0.8 (7%) | 0.0 (0%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (5%) | 0.0 (1%) | 0.1 (1%) | 0.4 (20%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (57%) | 0.1 (5%) | 1.2 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.5 a game | 1.0 a game |
| stood (cast and not dispelled) | 81% (30 of 37) | 57% (8 of 14) | 75% (38 of 51) |
| the unit moved after it | 77% (23 of 30) | 88% (7 of 8) | 79% (30 of 38) |
| it charged on its next turn | 0% (0 of 30) | 0% (0 of 8) | 0% (0 of 38) |
| the enemy charged it first | 13% (4 of 30) | 0% (0 of 8) | 11% (4 of 38) |
| it fought by the end of its next turn | 3% (1 of 30) | 0% (0 of 8) | 3% (1 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 17% (5 of 30) | 0% (0 of 8) | 13% (5 of 38) |
| none of these (no charge, no fight, no charge escaped) | 70% (21 of 30) | 100% (8 of 8) | 76% (29 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (478 of 752) | 63% (311 of 490) | 64% (789 of 1242) |
|   cavalry | 44% (31 of 71) | 69% (68 of 99) | 58% (99 of 170) |
|   character | 63% (58 of 92) | 46% (40 of 87) | 55% (98 of 179) |
|   chariot | 57% (42 of 74) | 75% (24 of 32) | 62% (66 of 106) |
|   infantry | 68% (138 of 203) | 62% (116 of 188) | 65% (254 of 391) |
|   monster | 53% (18 of 34) | 38% (10 of 26) | 47% (28 of 60) |
|   war machine | 69% (191 of 278) | 91% (53 of 58) | 73% (244 of 336) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (24%) | 1.5 (23%) | 3.9 (23%) |
| CHARGED: it charged | 0.7 (7%) | 1.4 (21%) | 2.1 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (10%) | 0.3 (4%) | 1.3 (8%) |
| MOVED: a war machine that moved | 1.3 (13%) | 0.0 (0%) | 1.3 (8%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.4 (4%) | 0.0 (0%) | 0.4 (3%) |
| NO TARGET IN RANGE | 1.9 (18%) | 1.9 (28%) | 3.7 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.3 (4%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (14%) | 1.1 (16%) | 2.4 (15%) |
| SHELTERED: the target was sheltered | 0.5 (5%) | 0.0 (0%) | 0.5 (3%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.8 | 73% | 6.6 pts | 35 pts |
| character | 4.2 | 1.9 | 66% | 10.7 pts | 45 pts |
| chariot | 2.5 | 1.9 | 59% | 17.6 pts | 44 pts |
| infantry | 14.2 | 5.2 | 74% | 8.9 pts | 127 pts |
| monster | 1.2 | 0.7 | 62% | 7.9 pts | 9 pts |
| war machine | 9.0 | 5.6 | 68% | 19.8 pts | 179 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 5.3 | 4.1 |
| Charges that made contact a game | 2.6 | 3.6 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.89 contact (19 units) | 0.90 declared, 0.50 contact (10 units) | 0.97 declared, 0.76 contact (29 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 1.33 declared, 1.00 contact (6 units) | 0.90 declared, 0.70 contact (10 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.29 contact (177 units) | 0.63 declared, 0.43 contact (199 units) | 0.49 declared, 0.36 contact (376 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (24 of 56) | 50% (6 of 12) | 50% (3 of 6) | 45% (33 of 74) |
| Character in a unit | 81% (29 of 36) | 71% (17 of 24) | 67% (2 of 3) | 76% (48 of 63) |
| Character on its own | 90% (28 of 31) | 36% (10 of 28) | 40% (16 of 40) | 55% (54 of 99) |
| Chariot | 67% (8 of 12) | 40% (4 of 10) | - | 55% (12 of 22) |
| Infantry | 46% (30 of 65) | 50% (17 of 34) | 50% (1 of 2) | 48% (48 of 101) |
| Monster | 58% (11 of 19) | 60% (3 of 5) | - | 58% (14 of 24) |
| Monstrous | 86% (6 of 7) | 30% (3 of 10) | - | 53% (9 of 17) |
| War Machines | 76% (31 of 41) | 100% (1 of 1) | - | 76% (32 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 92% (12 of 13); on the table 100% | 46% (63 of 138) | 45% | 48% (16 of 33) | 100% (9 of 9); 6.2 uses a game | 100% (3 of 3); 1.2 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 86% (6 of 7); on the table 100% | 21% (5 of 24) | 50% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 50% (2 of 4); on the table 75% | - | 69% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 25% (1 of 4); on the table 50% | 33% (12 of 36) | 52% | 62% (40 of 64) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 5 | 88% (7 of 8); on the table 88% | 41% (44 of 108) | 49% | 45% (20 of 44) | 92% (11 of 12); 7.4 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |
| High Elf Realms | 6 | 89% (16 of 18); on the table 89% | 17% (5 of 30) | 32% | 45% (22 of 49) | 80% (4 of 5); 3.0 uses a game | 44% (8 of 18); 2.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 25% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 0% (0 of 1); on the table 0% | - | 32% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 90% (9 of 10); on the table 100% | 0% (0 of 6) | 43% | 36% (5 of 14) | 100% (2 of 2); 4.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (5 of 5); on the table 100% | 46% (11 of 24) | 41% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | - | 33% (4 of 12) | 43% | 78% (14 of 18) | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 49% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 100% (8 of 8); on the table 100% | 30% (9 of 30) | 25% | 50% (13 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 67% (8 of 12); on the table 83% | 44% (8 of 18) | 32% | 70% (26 of 37) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 4 | 100% (7 of 7); on the table 100% | 58% (14 of 24) | 56% | 65% (30 of 46) | 40% (2 of 5); 1.2 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t10-mine-ba3e30a-p1, 27 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (25) | 48% (19) | 51% (44) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.56 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.15 | 0.04 | 0.19 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.41 | 0.74 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.52 | 0.52 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.15 | 5.67 | 5.81 |

### Quality by phase: t10-mine-ba3e30a-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 68% (51 of 75) | 47% (57 of 122) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (159 of 336) | 47% (81 of 171) |
| Strategy | Close-in objectives charged next turn | - | 20% (39 of 198) |
| Strategy | Support requests answered (helper made contact too) | 60% (3 of 5) | 47% (7 of 15) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 65% (11 of 17) | 38% (6 of 16) |
| Strategy | Joined characters whose unit fought | 49% (21 of 43) | 35% (14 of 40) |
| Strategy | Lone characters that fought | 76% (53 of 70) | 66% (41 of 62) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 234.2 | 199.3 |
| Movement | Fights charged into per game | 2.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 62, net +109 | 15 of 67, net +101 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 62, net +121 | 11 of 67, net +71 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 62, net +144 | 1 of 67, net +612 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 62, net +134 | 18 of 67, net +205 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (163 of 305) | 47% (131 of 278) |
| Shooting | Points destroyed by shooting units | 60.9 | 51.1 |
| Shooting | War machine shots | 7.1 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (116 of 191) | 34% (18 of 53) |
| Shooting | Points destroyed by war machines | 116.0 | 9.8 |
| Magic | Magic missiles cast | 2.7 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 23% (17 of 73) | 36% (12 of 33) |
| Magic | Wounds caused by magic missiles | 6.1 | 2.5 |
| Magic | Wounds caused by other spells | 2.4 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 138.8 | 13.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.7 / 1.2 / 0.1 | 1.7 / 0.6 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 312.8 | 365.1 |
| Combat | Points run down | 38.1 | 88.5 |
| Combat | Net points per charged fight, damage counted | +113 | +117 |
| Combat | Net per 100 charger points, damage counted | +37.9 | +44.1 |
| Combat | First round won (charged fights) | 83% | 71% |
| Combat | Net points per charged fight | +107 | +125 |
| Combat | Net points per supported fight / lone fight | +226 / +97 | +237 / +99 |
| Combat | Charged fights on a top-3 enemy unit | 22 of 63 | 40 of 80 |
| Game | Points lost | 706.9 | 698.0 |
| Game | VP from objectives | 660.7 | 681.9 |
| Game | Lone holders (player turns) | 4.0 | 2.8 |

- Mine won / drew / lost: 12 / 4 / 11 of 27 ended games (of 27); mean margin (Mine - Opponent) -31 VP
- The side that went first won 12 of 23 games with a winner
- Points traded per game (both sides' losses): 1405
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t10-mine-ba3e30a-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 5.4 | -157.3 | 206.7 | 130.4 |
| AFTERMATH IN POINTS | 0.2 | +21.1 | 0.0 | 5.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.0 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 10.1 | +107.2 | 0.0 | 167.8 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 38.7 | 0.7 | +0.0 | 0.0 | 4.8 |
| BACKUP TARGETS | 0.2 | +1.1 | 0.0 | 0.0 | 0.6 | +3.4 | 0.0 | 7.2 |
| BEST FACING | - | - | - | - | 0.1 | +2.0 | 0.0 | 8.2 |
| BEST FIRST | - | - | - | - | 1.3 | +136.4 | 18.9 | 68.4 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.1 | +49.8 | 0.0 | 17.6 |
| BEST OVERALL | - | - | - | - | 0.2 | +13.3 | 0.0 | 2.4 |
| BEST PREY | - | - | - | - | 0.5 | +20.6 | 5.3 | 10.6 |
| BEST PRIZE | - | - | - | - | 0.1 | -1.5 | 3.7 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.3 | -1.4 | 0.0 | 20.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.3 |
| BLOCKED WHEEL | - | - | - | - | 0.4 | +11.0 | 0.0 | 5.4 |
| BLOWS WHERE AIMED | 0.2 | -42.3 | 25.4 | 1.9 | 0.3 | -24.0 | 46.7 | 12.5 |
| BOMBING RUN | 0.1 | +3.4 | 0.0 | 11.1 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.1 | +0.0 | 109.9 | 19.1 | 0.3 | +0.0 | 74.7 | 9.6 |
| CANNON PLANNED TARGET | 6.4 | +241.0 | 475.6 | 140.6 | 1.9 | +54.8 | 160.0 | 26.7 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | -2.5 | 5.2 | 0.0 | 0.3 | -4.2 | 45.6 | 18.5 |
| CAST JOB | 0.7 | +22.9 | 33.9 | 13.3 | 0.4 | +6.2 | 38.9 | 6.3 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +34.5 | 14.4 | 0.0 | 0.3 | +7.4 | 19.5 | 0.0 |
| CASTS AFTER FRIENDS | 1.1 | +0.0 | 0.0 | 29.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.4 | +17.7 | 0.0 | 15.7 | 1.9 | +93.9 | 0.0 | 49.3 |
| CHAFF PASSED | 0.2 | -0.4 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.5 | +0.0 | 0.0 | 45.0 | - | - | - | - |
| CHARGE LOSSES | 6.0 | -318.9 | 0.0 | 155.7 | - | - | - | - |
| CHARGE NOT DECLARED | - | - | - | - | 0.5 | +0.0 | 31.5 | 3.1 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 245.9 | 60.8 | 3.0 | +0.0 | 293.0 | 79.7 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.6 | -25.9 | 8.9 | 6.1 |
| CHARGER SLAIN LOST | 0.4 | -9.1 | 46.3 | 12.1 | 1.0 | -35.7 | 68.6 | 70.2 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.1 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.3 | -1.8 | 7.0 | 57.4 |
| CHEAP HELPER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 28.5 | 0.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +112.7 | 0.0 | 0.0 | 0.4 | +77.7 | 0.0 | 0.0 |
| COVER ONCE | 6.8 | -630.0 | 0.0 | 133.6 | 5.5 | -352.7 | 0.0 | 138.1 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 3.9 | 0.1 | +0.0 | 14.9 | 0.0 |
| DEPLOY BY FIGURES | 8.3 | +0.5 | 0.0 | 21.4 | 7.7 | +83.6 | 0.0 | 42.8 |
| EDGE GIVE GROUND | 0.1 | +2.3 | 15.7 | 1.9 | 0.3 | +9.2 | 48.6 | 25.7 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.7 | +34.6 | 0.0 | 43.6 |
| FALL BACK GOOD ORDER | 1.7 | +13.5 | 161.0 | 62.8 | - | - | - | - |
| FALLBACK BY WORTH | 0.3 | +3.2 | 0.0 | 3.0 | 5.3 | +38.5 | 0.0 | 72.8 |
| FALLS SHORT | 2.3 | +40.7 | 0.0 | 31.4 | - | - | - | - |
| FEATURE BUFFS | 1.7 | +59.5 | 0.0 | 35.5 | - | - | - | - |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +36.3 | 52.2 | 41.7 | - | - | - | - |
| FIRE IN ORDER | 0.4 | +0.0 | 21.2 | 5.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 43.5 | +2846.2 | 1261.3 | 786.4 | - | - | - | - |
| FLANK NOT WEIGHED | 4.1 | +0.0 | 0.0 | 113.4 | 4.6 | +0.0 | 0.0 | 154.2 |
| FOCUS FIRE | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.6 | +118.0 | 0.0 | 14.6 | 0.7 | +126.7 | 0.0 | 19.2 |
| FOUR ROUNDS | 2.9 | +324.9 | 300.0 | 109.2 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.0 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.5 | -24.2 | 2.0 | 18.9 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +4.8 | 0.0 | 0.0 | 0.1 | +1.6 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -8.3 | 31.1 | 1.9 | 0.0 | -0.0 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| GUN FIGURES | 0.6 | +5.1 | 18.9 | 11.5 | 0.6 | +21.0 | 16.3 | 9.3 |
| GUN MASK | 0.6 | +0.3 | 0.0 | 13.3 | - | - | - | - |
| HARD STAY DROPPED | 1.2 | +0.0 | 0.0 | 24.6 | - | - | - | - |
| HE SHOOTS OR CHARGES | 2.0 | +0.0 | 0.0 | 83.6 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 1.9 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 14.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.3 | -46.2 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +17.2 | 25.4 | 1.9 | - | - | - | - |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS FIGHT TOGETHER | 1.3 | -22.9 | 0.0 | 42.8 | - | - | - | - |
| HIS LEGAL MOVES | 2.4 | +0.0 | 0.0 | 111.2 | - | - | - | - |
| HIS MOVE AND SHOT | 1.4 | -16.7 | 0.0 | 46.5 | - | - | - | - |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 73.3 | - | - | - | - |
| HIS RANDOM MOVE | 2.8 | +0.0 | 0.0 | 31.4 | - | - | - | - |
| HIS SHOT LIST | 15.3 | +506.4 | 0.0 | 203.5 | - | - | - | - |
| HIS TURN DENIED | 1.2 | +32.7 | 128.3 | 50.3 | - | - | - | - |
| HOLDER ASSIGNMENT | 11.5 | +1151.9 | 0.0 | 98.8 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.1 | +184.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.5 | -101.9 | 237.0 | 83.0 | 9.5 | -210.7 | 461.3 | 177.2 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +9.4 | 0.0 | 4.3 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 3.7 | 4.3 |
| HUNT IN PAIRS | 0.4 | +19.4 | 0.0 | 0.0 | 0.5 | +22.2 | 0.0 | 15.3 |
| HUNT RESULT | - | - | - | - | 0.3 | +8.5 | 3.7 | 12.4 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +100.0 | 8.3 | 8.1 |
| IDLE COST | 1.8 | -25.9 | 0.0 | 20.4 | 17.6 | -283.8 | 0.0 | 270.7 |
| INVITES THE FIGHT | - | - | - | - | 1.0 | +5.5 | 55.6 | 39.4 |
| JOINT CHARGE NOW | 0.5 | +37.8 | 106.0 | 13.3 | - | - | - | - |
| JOINT CHARGE PLAN | - | - | - | - | 0.3 | +16.6 | 7.0 | 7.2 |
| JOINT KNOWS CHALLENGE | 0.1 | -2.6 | 25.4 | 0.0 | 0.4 | -24.2 | 28.9 | 8.7 |
| KEEP FALLS | 0.1 | +1.3 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.1 | +63.3 | 201.9 | 26.3 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 2.1 | +101.1 | 173.0 | 35.6 |
| KILLS COUNT NEXT TURN | - | - | - | - | 6.9 | +274.3 | 242.1 | 88.7 |
| LANE BY FIGURES | 0.7 | +23.0 | 0.0 | 0.0 | 0.7 | +46.5 | 0.0 | 22.2 |
| LEGAL CHARGES ONLY | 4.9 | +0.0 | 210.3 | 239.8 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.1 | +1.5 | 0.0 | 0.0 | 0.6 | +27.9 | 2.0 | 32.9 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.2 | +0.0 | 6.3 | 7.0 |
| LONE WIZARD KEPT IN | 0.8 | +57.3 | 0.0 | 0.0 | 0.3 | +28.3 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -1.2 | 2.8 | 0.0 | 0.7 | +1.3 | 27.1 | 25.8 |
| LOST CHARGE | - | - | - | - | 2.9 | -42.3 | 110.0 | 73.7 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 3.0 | 0.1 | -22.8 | 0.0 | 9.6 |
| MAKE SURE TOGETHER | 0.1 | +2.5 | 0.0 | 11.0 | 1.4 | +139.7 | 0.0 | 18.0 |
| MANOEUVRE | 1.1 | +20.1 | 0.0 | 26.1 | 0.1 | +13.8 | 0.0 | 4.3 |
| MARCH AT ESCAPER | 0.0 | +0.2 | 0.0 | 9.0 | 0.2 | +0.8 | 0.0 | 20.0 |
| MARCH BY THE SUM | 0.2 | +8.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +41.4 | 0.0 | 3.0 | 0.2 | +6.0 | 0.0 | 10.2 |
| MARCH ODDS | - | - | - | - | 0.2 | +18.5 | 25.6 | 0.0 |
| MARCH OVER CASTS | 0.9 | +72.9 | 0.0 | 12.2 | 0.5 | +41.6 | 0.0 | 60.0 |
| MAX FOR POSITIONING | 5.5 | +104.0 | 0.0 | 121.6 | 6.6 | +92.0 | 0.0 | 135.0 |
| MISSILES IN THE MOVE | 5.2 | +239.5 | 0.0 | 121.2 | 4.0 | +56.3 | 0.0 | 73.7 |
| MISSILES NEXT TURN | 5.6 | +137.1 | 0.0 | 115.4 | 4.4 | +41.7 | 0.0 | 131.1 |
| MODEL FACING | 0.5 | +203.7 | 0.0 | 2.2 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.6 | +19.3 | 0.0 | 24.3 |
| MOVE ORDER | 1.1 | +0.0 | 7.6 | 29.9 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -69.6 | 6.0 | 26.3 | 0.0 | -0.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 29.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 5.7 | +553.1 | 214.7 | 126.8 |
| MOVE TO CHARGE COMPUTED | 3.9 | +453.6 | 0.0 | 60.6 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +4.4 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.6 | +157.5 | 0.0 | 63.1 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.0 | +0.0 | 6.5 | 0.0 |
| NEXT CHARGE BY LIST | 4.4 | -254.6 | 46.0 | 41.0 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 4.0 | -136.4 | 86.1 | 56.5 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.3 | -118.9 | 232.7 | 99.6 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +0.6 | 0.0 | 7.6 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.4 | -14.5 | 16.9 | 6.0 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 5.7 | +85.1 | 0.0 | 177.3 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 14.8 | 0.0 | -0.0 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -13.1 | 0.0 | 7.7 | 17.4 | -864.0 | 0.0 | 372.4 |
| ONE CHARGE A CHARGER | 1.7 | +0.0 | 0.0 | 57.3 | - | - | - | - |
| ONE FIGHT FORMULA | 5.7 | -114.0 | 0.0 | 80.7 | 8.1 | -141.2 | 43.2 | 161.6 |
| ONE OBJECTIVE FORMULA | 3.8 | +71.2 | 0.0 | 44.7 | 2.6 | -78.2 | 0.0 | 16.3 |
| ONE TARGET A SHOOTER | 13.9 | +262.6 | 0.0 | 197.8 | - | - | - | - |
| OPENS A LANE | 0.2 | +1.5 | 9.4 | 0.0 | 0.2 | +0.4 | 10.2 | 0.0 |
| OPENS UP | 0.3 | +22.2 | 17.4 | 16.4 | 0.1 | +9.5 | 5.4 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.3 | 0.0 | 20.0 |
| OVERRUNS AWAY | 0.4 | +23.1 | 58.4 | 31.1 | 0.7 | +9.3 | 108.6 | 36.6 |
| PATHS CROSS | 2.7 | +165.7 | 0.0 | 32.8 | 2.6 | +199.9 | 0.0 | 36.9 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +3.9 | 0.0 | 20.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.5 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 2.8 |
| PLAN RESULT | 38.9 | +1234.3 | 775.6 | 1007.1 | 39.3 | +1116.4 | 1333.4 | 1016.7 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -27.5 | 0.0 | 8.7 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.4 | +9.8 | 0.0 | 0.0 | 1.8 | +28.5 | 0.0 | 34.6 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.4 | -18.7 | 9.1 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +8.2 | 0.0 | 8.6 | 0.9 | -27.4 | 0.0 | 24.7 |
| REDIRECT COUNTER | 1.4 | +63.2 | 0.0 | 45.3 | 3.3 | +217.0 | 0.0 | 74.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +10.4 | 20.4 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -72.8 | 0.0 | 5.1 | - | - | - | - |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 7.7 | 0.3 | +0.0 | 0.0 | 16.0 |
| RESERVE FALL BACK | 0.3 | +13.0 | 0.0 | 11.1 | 0.5 | +24.6 | 0.0 | 10.1 |
| RISK BY ARC | 2.2 | +44.0 | 255.0 | 97.7 | 2.9 | +56.3 | 269.2 | 112.1 |
| RISK BY HIS FIGURE | 11.8 | -278.0 | 0.0 | 304.3 | - | - | - | - |
| RISK ONCE | - | - | - | - | 6.0 | +249.0 | 86.0 | 373.6 |
| RUN DOWN | 1.9 | -21.0 | 187.8 | 88.6 | - | - | - | - |
| SAFER THAN THE JOB | - | - | - | - | 0.5 | +19.6 | 0.0 | 35.1 |
| SAME CHARGE LATER | 0.0 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.2 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.0 | -2.3 | 0.0 | 0.0 | 0.7 | -50.1 | 0.0 | 9.8 |
| SEARCH SPOT | 5.4 | +236.2 | 0.0 | 65.0 | 3.3 | +128.0 | 0.0 | 50.3 |
| SELF MOVE SPELL | 0.2 | +44.9 | 0.0 | 14.6 | 0.3 | -0.7 | 0.0 | 24.1 |
| SET UP BY THE SET | 0.7 | -8.0 | 24.6 | 11.5 | - | - | - | - |
| SET UP TOGETHER | 0.1 | +2.5 | 0.0 | 11.0 | 3.1 | +370.0 | 28.0 | 80.5 |
| SET-UP ANY TARGET | 0.0 | +0.7 | 0.0 | 0.0 | 0.2 | +23.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +15.6 | 0.0 | 0.0 | 0.1 | +6.1 | 4.7 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.5 | +1.0 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +61.3 | 146.8 | 6.6 | 1.3 | +43.2 | 4.6 | 29.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.1 | -3.0 | 25.1 | 3.7 | - | - | - | - |
| SHOT RISK POINTS | 9.1 | +77.3 | 0.0 | 117.6 | - | - | - | - |
| SHOTS IN THE MOVE | 17.8 | +918.6 | 0.0 | 397.9 | 10.7 | +307.5 | 0.0 | 149.8 |
| SPELL SETS UP CHARGE | 0.1 | +98.7 | 0.0 | 0.0 | 0.2 | +68.5 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +15.0 | 45.1 | 49.4 | 2.1 | +40.6 | 107.6 | 107.6 |
| SPELLS IN THE FIGHT | 0.4 | +0.9 | 65.0 | 1.9 | 1.2 | -25.3 | 117.2 | 52.0 |
| STABLE ROLE | - | - | - | - | 12.4 | +0.0 | 374.7 | 194.1 |
| STAND AND SHOOT | 0.6 | -8.8 | 44.3 | 30.4 | - | - | - | - |
| STANDS FOR A REASON | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 18.9 | +0.0 | 961.3 | 296.3 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.1 | +12.6 | 3.1 | 7.3 |
| STAY WEIGHED | - | - | - | - | 0.0 | +3.0 | 0.0 | 0.0 |
| STAY WORTH | 21.9 | +106.9 | 619.5 | 341.0 | 13.0 | +122.5 | 260.3 | 169.0 |
| STOPS | - | - | - | - | 0.1 | +4.7 | 8.3 | 3.9 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.4 | +11.2 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.1 | +0.0 | 128.1 | 37.4 | 6.5 | -59.3 | 394.4 | 100.9 |
| SUPPORTS | - | - | - | - | 4.1 | +60.7 | 157.1 | 40.4 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.0 | -2.0 | 3.6 | 0.0 |
| SURE REACH TOGETHER | 0.1 | +0.9 | 0.0 | 0.0 | 0.8 | +19.9 | 0.0 | 39.1 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 59.4 | - | - | - | - |
| THE PROMISE ADDS | 0.1 | -11.2 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 1.3 | +0.0 | 0.0 | 14.4 | - | - | - | - |
| THROUGH LINE OF FIRE | - | - | - | - | 0.1 | +2.5 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 1.0 | +100.9 | 109.4 | 28.4 | - | - | - | - |
| TIME ON OUR SIDE | 24.2 | +418.7 | 24.6 | 390.6 | - | - | - | - |
| TURN WORTH | - | - | - | - | 0.1 | -6.9 | 14.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.0 | +0.0 | 0.0 | 11.0 | 1.0 | +13.4 | 0.0 | 34.0 |
| WAIT AFTER COSTS | - | - | - | - | 9.1 | -516.0 | 363.5 | 204.1 |
| WAITS AGAIN | 1.2 | +0.0 | 0.0 | 4.1 | - | - | - | - |
| WALKS TO THE FIGHT | - | - | - | - | 1.6 | +12.8 | 65.9 | 25.1 |
| WAR ENGINE CHARGES | 0.0 | +5.0 | 0.0 | 11.5 | - | - | - | - |
| WAR ENGINE JOBS | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 19.1 | 16.5 |
| WEARS DOWN | - | - | - | - | 1.6 | +59.5 | 146.9 | 65.6 |
| WHO HITS BACK | 0.5 | +71.1 | 0.0 | 31.1 | 0.3 | +17.8 | 0.0 | 15.6 |
| WHOLE FIGHT | 0.3 | +13.1 | 55.9 | 6.3 | 0.2 | +25.9 | 60.1 | 4.6 |
| WHOLE FIGHT GAIN | 0.0 | +0.6 | 12.7 | 0.0 | 0.4 | +39.7 | 32.9 | 15.6 |
| WIDER SPREAD | 1.7 | -7.6 | 197.1 | 57.0 | 3.1 | -2.0 | 255.4 | 84.6 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.5 | +42.9 | 0.0 | 64.1 | - | - | - | - |

### Rule changes: t10-mine-ba3e30a-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 487 | 487 | 487 | 18.04 | -23682 | -48.6 |
| HOLDER ASSIGNMENT | 311 | 311 | 281 | 10.41 | +17975 | +64.0 |
| DEPLOY BY FIGURES | 432 | 432 | 279 | 10.33 | +3985 | +14.3 |
| SEARCH SPOT | 235 | 235 | 227 | 8.41 | +9833 | +43.3 |
| ARMY TABLE | 272 | 272 | 178 | 6.59 | +2219 | +12.5 |
| PATHS CROSS | 143 | 143 | 143 | 5.30 | +9873 | +69.0 |
| LEGAL CHARGES ONLY | 133 | 133 | 133 | 4.93 | +0 | +0.0 |
| TIME ON OUR SIDE | 653 | 571 | 99 | 3.67 | +341 | +3.4 |
| HIS SHOT LIST | 413 | 411 | 97 | 3.59 | +1451 | +15.0 |
| FIVE ACTION | 1174 | 1168 | 85 | 3.15 | +5697 | +67.0 |
| MOVE TO CHARGE | 155 | 155 | 81 | 3.00 | +6976 | +86.1 |
| SHOTS IN THE MOVE | 769 | 653 | 70 | 2.59 | +2157 | +30.8 |
| MOVE TO CHARGE COMPUTED | 104 | 101 | 65 | 2.41 | +5218 | +80.3 |
| COVER ONCE | 332 | 228 | 63 | 2.33 | +800 | +12.7 |
| KILLS COUNT NEXT TURN | 185 | 185 | 63 | 2.33 | +1695 | +26.9 |
| ONE TARGET A SHOOTER | 376 | 373 | 63 | 2.33 | +531 | +8.4 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 2.00 | +0 | +0.0 |
| SUPPORTS | 111 | 111 | 51 | 1.89 | +665 | +13.0 |
| MAX FOR POSITIONING | 326 | 238 | 50 | 1.85 | +255 | +5.1 |
| WAIT AFTER COSTS | 246 | 246 | 49 | 1.81 | +887 | +18.1 |
| CANNON PLANNED TARGET | 222 | 222 | 48 | 1.78 | -694 | -14.5 |
| MISSILES IN THE MOVE | 248 | 175 | 48 | 1.78 | +1516 | +31.6 |
| RISK ONCE | 163 | 129 | 48 | 1.78 | +1118 | +23.3 |
| STAY WORTH | 941 | 849 | 47 | 1.74 | +867 | +18.4 |
| ADVANCE LANE KEPT | 44 | 44 | 44 | 1.63 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 71 | 71 | 41 | 1.52 | +949 | +23.2 |
| SHOT RISK POINTS | 247 | 246 | 40 | 1.48 | +824 | +20.6 |
| CANNON SIGHT KEPT | 38 | 38 | 38 | 1.41 | +0 | +0.0 |
| LANE BY FIGURES | 38 | 38 | 38 | 1.41 | +1878 | +49.4 |
| SET UP TOGETHER | 88 | 75 | 38 | 1.41 | +4843 | +127.4 |
| BEST FIRST | 36 | 36 | 36 | 1.33 | +3682 | +102.3 |
| RANDOM MOVE BY FIGURES | 60 | 60 | 36 | 1.33 | +1034 | +28.7 |
| FOLLOW UP WEIGHED | 35 | 35 | 35 | 1.30 | +6606 | +188.8 |
| FOUR ROUNDS | 78 | 77 | 34 | 1.26 | +2822 | +83.0 |
| CHARGE NOW FIRST | 128 | 128 | 32 | 1.19 | -1921 | -60.0 |
| HARD STAY DROPPED | 32 | 32 | 32 | 1.19 | +0 | +0.0 |
| CHAFF IN THE MOVE | 60 | 55 | 31 | 1.15 | +1141 | +36.8 |
| BEST MOVE FOR SHOOTERS | 30 | 30 | 30 | 1.11 | +1345 | +44.8 |
| MOVE ORDER | 30 | 30 | 30 | 1.11 | +0 | +0.0 |
| ONE FIGHT FORMULA | 375 | 205 | 30 | 1.11 | +186 | +6.2 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 1.04 | +2311 | +82.5 |
| RISK BY ARC | 139 | 132 | 28 | 1.04 | +1111 | +39.7 |
| HOLDS AMBUSHERS | 27 | 27 | 27 | 1.00 | +0 | +0.0 |
| REDIRECT COUNTER | 126 | 70 | 27 | 1.00 | +2098 | +77.7 |
| FALLBACK BY WORTH | 152 | 152 | 26 | 0.96 | +1126 | +43.3 |
| CHARGE LOSSES | 162 | 161 | 23 | 0.85 | +2080 | +90.4 |
| MARCH CHECK | 26 | 26 | 22 | 0.81 | +548 | +24.9 |
| RESERVE FALL BACK | 22 | 22 | 22 | 0.81 | +1016 | +46.2 |
| RISK BY HIS FIGURE | 319 | 315 | 22 | 0.81 | +1877 | +85.3 |
| SHOOTERS IN TWO RANKS | 21 | 21 | 21 | 0.78 | +47 | +2.2 |
| WALKS TO THE FIGHT | 44 | 44 | 21 | 0.78 | +109 | +5.2 |
| WHO HITS BACK | 21 | 21 | 21 | 0.78 | +1434 | +68.3 |
| CASTER AWAY FROM SCREEN | 20 | 20 | 20 | 0.74 | +0 | +0.0 |
| ADVANCE WORTH | 147 | 147 | 19 | 0.70 | +144 | +7.6 |
| MANOEUVRE | 35 | 35 | 19 | 0.70 | +1031 | +54.3 |
| CAST JOB | 29 | 29 | 18 | 0.67 | +269 | +14.9 |
| FACES THE THREAT | 18 | 18 | 18 | 0.67 | +935 | +51.9 |
| TIED UP BY THE SUM | 26 | 25 | 18 | 0.67 | +652 | +36.2 |
| MOVE AND CAST | 17 | 17 | 17 | 0.63 | +522 | +30.7 |
| CHARGE NOW WEIGHED | 15 | 15 | 15 | 0.56 | +201 | +13.4 |
| HOLDER AT DEPLOYMENT | 30 | 30 | 15 | 0.56 | +587 | +39.1 |
| IDLE COST | 523 | 309 | 15 | 0.56 | +85 | +5.7 |
| SCOUT WAITS | 15 | 15 | 15 | 0.56 | +0 | +0.0 |
| CASTING BLOCK | 18 | 18 | 14 | 0.52 | +367 | +26.2 |
| JOINT CHARGE NOW | 14 | 14 | 14 | 0.52 | +1021 | +72.9 |
| MODEL FACING | 14 | 14 | 14 | 0.52 | +5501 | +392.9 |
| SAFER THAN THE JOB | 14 | 14 | 14 | 0.52 | +530 | +37.9 |
| CHARGE NOT DECLARED | 13 | 13 | 13 | 0.48 | -1020 | -78.5 |
| FIRE IN ORDER | 13 | 13 | 13 | 0.48 | +0 | +0.0 |
| INVITES THE FIGHT | 28 | 28 | 13 | 0.48 | +62 | +4.8 |
| CHAFF PASSED | 12 | 12 | 12 | 0.44 | -15 | -1.2 |
| FALLS SHORT | 63 | 51 | 12 | 0.44 | +52 | +4.3 |
| COMBAT PIVOT | 11 | 11 | 11 | 0.41 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 11 | 11 | 11 | 0.41 | +302 | +27.4 |
| BLOCKED WHEEL | 10 | 10 | 10 | 0.37 | +298 | +29.8 |
| FEATURE BUFFS | 45 | 45 | 9 | 0.33 | +213 | +23.7 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 0.33 | +472 | +52.4 |
| SUPPORT NARROWED | 205 | 205 | 9 | 0.33 | -221 | -24.6 |
| WAR ENGINE JOBS | 15 | 15 | 9 | 0.33 | -1636 | -181.7 |
| WEARS DOWN | 42 | 38 | 9 | 0.33 | +216 | +24.0 |
| BIG CHARACTER SAFETY | 8 | 8 | 8 | 0.30 | -37 | -4.6 |
| HIS TURN DENIED | 32 | 31 | 8 | 0.30 | +189 | +23.6 |
| HONEST WORTH | 324 | 320 | 8 | 0.30 | +20 | +2.5 |
| MAKE SURE TOGETHER | 42 | 23 | 8 | 0.30 | +1201 | +150.2 |
| NEXT CHARGE BY LIST | 120 | 118 | 8 | 0.30 | +88 | +10.9 |
| SET UP BY THE SET | 18 | 18 | 8 | 0.30 | +761 | +95.1 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.30 | +0 | +0.0 |
| KILLS COUNT | 56 | 55 | 7 | 0.26 | +233 | +33.3 |
| NEARER NOT NEEDED | 97 | 93 | 7 | 0.26 | +156 | +22.3 |
| REFUSING RETIRES | 18 | 18 | 7 | 0.26 | -2 | -0.3 |
| WHOLE FIGHT GAIN | 12 | 11 | 7 | 0.26 | +546 | +78.0 |
| WOUNDS ON THE RANKS | 41 | 41 | 7 | 0.26 | +167 | +23.9 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.22 | +571 | +95.2 |
| BEST OVERALL | 6 | 6 | 6 | 0.22 | +359 | +59.8 |
| BEST PREY | 13 | 13 | 6 | 0.22 | +181 | +30.2 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 0.22 | +0 | +0.0 |
| MARCH ODDS | 6 | 6 | 6 | 0.22 | +69 | +11.5 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.22 | +181 | +30.2 |
| OPENS UP | 10 | 10 | 6 | 0.22 | +315 | +52.5 |
| STUCK PIVOT | 6 | 6 | 6 | 0.22 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.19 | +174 | +34.7 |
| KEEPS ITS TARGET | 57 | 55 | 5 | 0.19 | +64 | +12.8 |
| MARCH BY THE SUM | 5 | 5 | 5 | 0.19 | +228 | +45.7 |
| MISSILES NEXT TURN | 272 | 179 | 5 | 0.19 | +102 | +20.4 |
| ONE OBJECTIVE FORMULA | 171 | 111 | 5 | 0.19 | +180 | +36.0 |
| OVERRUNS AWAY | 31 | 29 | 5 | 0.19 | +207 | +41.4 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.19 | -64 | -12.7 |
| SURE REACH TOGETHER | 25 | 19 | 5 | 0.19 | +64 | +12.8 |
| FIGHT TO THE END | 18 | 18 | 4 | 0.15 | +151 | +37.7 |
| HIS FIGHT TOGETHER | 35 | 35 | 4 | 0.15 | +279 | +69.8 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.15 | -742 | -185.5 |
| BEST PRIZE | 3 | 3 | 3 | 0.11 | -42 | -13.9 |
| BOMBING RUN | 3 | 3 | 3 | 0.11 | +92 | +30.8 |
| CARRIES OUT SET-UP | 8 | 8 | 3 | 0.11 | -183 | -60.9 |
| FALL BACK GOOD ORDER | 46 | 45 | 3 | 0.11 | +23 | +7.8 |
| HIS CHARGE DENIED | 9 | 9 | 3 | 0.11 | +104 | +34.7 |
| HUNT ADVANCE | 4 | 4 | 3 | 0.11 | +51 | +16.9 |
| HUNT IN PAIRS | 24 | 13 | 3 | 0.11 | +155 | +51.7 |
| KEEP FALLS | 3 | 3 | 3 | 0.11 | +216 | +71.8 |
| NEXT OBJECTIVE NEARER | 108 | 107 | 3 | 0.11 | +56 | +18.8 |
| STANDS TO CAST | 3 | 3 | 3 | 0.11 | -35 | -11.7 |
| THROUGH LINE OF FIRE | 3 | 3 | 3 | 0.11 | +66 | +22.2 |
| WHOLE FIGHT | 14 | 14 | 3 | 0.11 | +579 | +193.0 |
| WIDER SPREAD | 130 | 125 | 3 | 0.11 | +8 | +2.6 |
| BEST FACING | 2 | 2 | 2 | 0.07 | +53 | +26.6 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.07 | +0 | +0.2 |
| DEFENSIVE ARMY | 5 | 5 | 2 | 0.07 | -6 | -3.0 |
| EDGE GIVE GROUND | 12 | 11 | 2 | 0.07 | +17 | +8.6 |
| FOCUS FIRE | 2 | 2 | 2 | 0.07 | +36 | +17.8 |
| HIS MOVE AND SHOT | 38 | 37 | 2 | 0.07 | +12 | +6.2 |
| JOINT CHARGE PLAN | 7 | 7 | 2 | 0.07 | +128 | +63.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.07 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.07 | +11 | +5.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.07 | +106 | +53.0 |
| REDIRECT BY WHAT IT STOPS | 27 | 27 | 2 | 0.07 | +14 | +6.8 |
| TWO OR MORE ARRIVE | 27 | 23 | 2 | 0.07 | +11 | +5.7 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.04 | +48 | +48.4 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.04 | +0 | +0.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.04 | -19 | -19.1 |
| CHARGER SLAIN LOST | 36 | 33 | 1 | 0.04 | +37 | +36.6 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.04 | -47 | -47.2 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.04 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.04 | +21 | +21.2 |
| LONE WIZARD HOLDS BACK | 6 | 6 | 1 | 0.04 | -92 | -91.5 |
| LONG SHOT | 20 | 20 | 1 | 0.04 | +46 | +46.5 |
| LOST CHARGE | 77 | 74 | 1 | 0.04 | +10 | +9.5 |
| OPENS A LANE | 12 | 5 | 1 | 0.04 | +1 | +1.4 |
| RUN DOWN | 50 | 49 | 1 | 0.04 | +6 | +6.3 |
| STAY WEIGHED | 1 | 1 | 1 | 0.04 | +81 | +81.2 |
| STOPS | 3 | 3 | 1 | 0.04 | +10 | +9.6 |
| SURE CHARGE BEATS ADVANCE | 1 | 1 | 1 | 0.04 | -54 | -53.6 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.04 | +123 | +123.0 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.04 | -416 | -416.0 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 23 | 15 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 14 | 11 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 13 | 12 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 235 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 14 | 14 | 0 | 0.00 | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 33 | not checked | - | - | - | - |
| GUN MASK | 16 | 16 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 54 | 54 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 47 | 47 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 64 | 63 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 63 | 61 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 76 | 75 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 13 | 10 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 21 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 37 | 37 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NEEDED THERE | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 63 | 62 | 0 | 0.00 | - | - |
| NOT NEEDED | 10 | 10 | 0 | 0.00 | - | - |
| NOT TURNED | 157 | 157 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 20 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 46 | 45 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2110 | trace | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 11 | 11 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 24 | 23 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 13 | 13 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 14 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 89 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 43 | 41 | 0 | 0.00 | - | - |
| STABLE ROLE | 336 | 335 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 15 | 14 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 511 | 510 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 89 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 35 | not checked | - | - | - | - |
| TURN WORTH | 4 | 4 | 0 | 0.00 | - | - |
| WAITS AGAIN | 32 | 31 | 0 | 0.00 | - | - |

### Off best figure: t10-mine-ba3e30a-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.30 | 16.04 | 50.2 |
| ARMY TABLE | rule | 1.41 | - | 41.7 |
| CHARGE NOW FIRST | rule | 0.52 | 0.63 | 62.0 |
| HOLDER ASSIGNMENT | rule | 0.96 | - | 16.7 |
| FALLBACK | gate | - | 0.63 | 52.1 |
| CANNON PLANNED TARGET | rule | 0.41 | 0.07 | 67.6 |
| CHARGE NOT DECLARED | rule | - | 0.44 | 86.0 |
| SUPPORT NARROWED | rule | 0.11 | 0.22 | 24.6 |
| WAR ENGINE JOBS | rule | - | 0.33 | 181.7 |
| PATHS CROSS | rule | 0.22 | 0.07 | 10.0 |
| TURN GATE | gate | - | 0.30 | 7.5 |
| CHAFF PASSED | rule | 0.15 | 0.11 | 2.1 |
| BIG CHARACTER SAFETY | rule | - | 0.22 | 7.5 |
| CHARGE NOW WEIGHED | rule | - | 0.22 | 27.7 |
| NO REASON | gate | 0.19 | - | 47.8 |
| PIVOT GUARDS FLANK | rule | 0.07 | 0.11 | 12.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.07 | 0.07 | 17.6 |
| JOINT CHARGE NOW | rule | 0.15 | - | 66.4 |
| PURSUES BIG PREY | rule | - | 0.15 | 185.5 |
| SUPPORT REQUEST | gate | - | 0.15 | 48.4 |
| AFTERMATH BAND | gate | 0.04 | 0.07 | 1.4 |
| BEST PRIZE | rule | - | 0.11 | 13.9 |
| CARRIES OUT SET-UP | rule | 0.04 | 0.07 | 60.9 |
| STOPS SHORT OF THE FLANK | rule | - | 0.11 | 7.9 |
| DEFENSIVE ARMY | rule | - | 0.07 | 3.0 |
| DEPLOY BY FIGURES | rule | - | 0.07 | 12.9 |
| FIGHT ORDER BAND | gate | 0.07 | - | 1.6 |
| RULE SWITCHED OFF | gate | - | 0.07 | 35.0 |
| SAFER THAN THE JOB | rule | - | 0.07 | 6.8 |
| CATCH ODDS | rule | - | 0.04 | 19.1 |
| CHARIOT NO STATIC JOB | rule | - | 0.04 | 47.2 |
| FACES THE THREAT | rule | - | 0.04 | 8.0 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.04 | 31.8 |
| LONE WIZARD HOLDS BACK | rule | - | 0.04 | 91.5 |
| MOVE AND CAST | rule | - | 0.04 | 1.8 |
| REFUSING RETIRES | rule | 0.04 | - | 1.0 |
| STANDS TO CAST | rule | - | 0.04 | 43.9 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.04 | 53.6 |
| THROUGH LINE OF FIRE | rule | - | 0.04 | 12.7 |
| WOUNDED STAYS OUT | rule | - | 0.04 | 416.0 |

### Plans: t10-mine-ba3e30a-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.2 | 70% | 414 | 272 | 66% |
| Mine | join | 0.7 | 100% | 8 | 0 | 0% |
| Mine | move | 25.0 | 94% | 1686 | 0 | 0% |
| Mine | shoot | 10.7 | 65% | 615 | 962 | 156% |
| Mine | support | 0.2 | 67% | 15 | 0 | 0% |
| Opponent | advance | 11.2 | 11% | 119 | 263 | 221% |
| Opponent | charge | 4.0 | 48% | 393 | 313 | 80% |
| Opponent | close in | 7.3 | 25% | 652 | 209 | 32% |
| Opponent | hold | 6.0 | 48% | 449 | 0 | 0% |
| Opponent | join | 0.5 | 93% | 27 | 0 | 0% |
| Opponent | shoot | 4.7 | 62% | 169 | 331 | 196% |
| Opponent | support | 5.6 | 85% | 44 | 0 | 0% |

### Packages: hunt the guns, t10-mine-ba3e30a-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 4 |
| Opponent | 0.3 | 7 | 0 | 14% | 14% | 0% | 2.0 | 386 | 33 | 14% | 132 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 95 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 348 |
| Vampire Counts | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 205 | 0 | 0% | 176 |
| Warriors of Chaos | 1.0 | 4 | 0 | 0% | 0% | 0% | - | 502 | 0 | 0% | 129 |
| Wood Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 281 | 229 | 100% | 0 |

### Battle groups: t10-mine-ba3e30a-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.4 | 32% | 58% | 17% | 0% | 30% | 0% | 10% | 50% | 10% |
| Opponent | REDIRECT COUNTER | 3.3 | 18% | 75% | 12% | 100% | 29% | 0% | 0% | 71% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t10-mine-ba3e30a-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 15 | 26 (15) | 4 | 21 | 88 | 40% | 2.6 | 64 (3) | 7 (7) | 13 (5) | 33 (12) | 9 (3) |
| Mine | Character | 99 | 51 (99) | 51 | 0 | 34 | 17% | 2.5 | 52 (40) | 41 (33) | 73 (16) | 55 (46) | 51 (43) |
| Mine | Clean-up | 11 | 21 (11) | 0 | 21 | 57 | 45% | 3.0 | 6 (6) | 57 (4) | 0 (1) | 17 (7) | 26 (4) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 27 | 0% | 2.0 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Mine | Fast Hammer | 34 | 44 (34) | 19 | 25 | 56 | 26% | 3.0 | 49 (20) | 39 (11) | 44 (3) | 58 (23) | 19 (11) |
| Mine | Hammer | 41 | 42 (41) | 17 | 25 | 27 | 20% | 2.3 | 34 (15) | 49 (21) | 31 (5) | 40 (28) | 47 (13) |
| Mine | Holder | 17 | 93 (17) | 9 | 84 | 34 | 53% | 3.6 | 94 (5) | 86 (11) | 198 (1) | 125 (11) | 39 (6) |
| Mine | Shooter | 40 | 98 (40) | 36 | 63 | 34 | 0% | 1.6 | 124 (11) | 106 (22) | 31 (7) | 134 (27) | 34 (13) |
| Mine | Support | 3 | 80 (3) | 80 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Mine | War machine | 56 | 54 (56) | 54 | 0 | 53 | 4% | 1.6 | 71 (25) | 50 (24) | 18 (7) | 11 (7) | 59 (49) |
| Mine | Wizard | 14 | 35 (14) | 35 | 0 | 26 | 0% | 2.9 | 42 (7) | 39 (3) | 0 (1) | 39 (5) | 41 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 46 | 82 (46) | 5 | 77 | 44 | 43% | 3.1 | 66 (15) | 139 (20) | 4 (11) | 92 (31) | 60 (15) |
| Opponent | Character | 84 | 42 (84) | 42 | 0 | 33 | 29% | 2.5 | 24 (26) | 44 (36) | 73 (14) | 50 (51) | 36 (25) |
| Opponent | Clean-up | 10 | 19 (10) | 19 | 0 | 71 | 30% | 3.3 | 0 (4) | 39 (5) | 0 (1) | 10 (8) | 40 (2) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 42 | 54 (42) | 34 | 20 | 42 | 31% | 2.9 | 49 (14) | 50 (21) | 79 (7) | 65 (28) | 29 (14) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 19 | 100% | - | 0 (4) | 0 (1) | - | 0 (5) | - |
| Opponent | Hammer | 51 | 43 (51) | 34 | 9 | 41 | 33% | 2.6 | 53 (16) | 50 (23) | 16 (12) | 47 (30) | 38 (21) |
| Opponent | Holder | 29 | 76 (29) | 5 | 72 | 17 | 45% | 3.6 | 48 (5) | 93 (19) | 57 (5) | 107 (14) | 53 (15) |
| Opponent | Shooter | 26 | 64 (26) | 16 | 47 | 42 | 8% | 1.5 | 53 (8) | 83 (13) | 11 (5) | 75 (15) | 48 (11) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 13 | 7 (13) | 7 | 0 | 49 | 0% | 1.0 | 10 (9) | 0 (2) | 0 (2) | 0 (2) | 8 (11) |
| Opponent | Wizard | 18 | 8 (18) | 8 | 0 | 36 | 17% | 2.2 | 17 (6) | 4 (9) | 0 (2) | 15 (8) | 0 (9) |

### Charged fights: t10-mine-ba3e30a-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 260 | 72 | 1.6 | 1.1 | 45 | 30 | +15 | 2 of 8 | 3 of 8 | -85 | +29 |
| Mine | Chaos Dwarfs | 3 | 100 | 802 | 4.3 | 1.2 | 185 | 24 | +161 | 8 of 13 | 11 of 13 | +378 | +122 |
| Mine | Dwarfen Mountain Holds | 4 | 323 | 15 | 0.8 | 1.0 | 20 | 0 | +20 | 0 of 3 | 2 of 3 | - | +20 |
| Mine | Empire of Man | 5 | 419 | 98 | 1.4 | 1.3 | 70 | 54 | +16 | 1 of 7 | 6 of 7 | +72 | +6 |
| Mine | Grand Cathay | 4 | 794 | 225 | 2.2 | 1.1 | 100 | 0 | +100 | 5 of 9 | 9 of 9 | +385 | +64 |
| Mine | High Elf Realms | 4 | 71 | 724 | 4.0 | 1.0 | 181 | 0 | +181 | 4 of 16 | 15 of 16 | - | +181 |
| Mine | Kingdom of Bretonnia | 1 | 75 | 669 | 5.0 | 1.0 | 134 | 0 | +134 | 2 of 5 | 5 of 5 | - | +134 |
| Mine | Lizardmen | 1 | 0 | 60 | 2.0 | 1.0 | 30 | 88 | -58 | 0 of 2 | 1 of 2 | - | -58 |
| **Mine** | all armies | 27 | 316 | 290 | 2.3 | 1.1 | 124 | 18 | +107 | 22 of 63 | 52 of 63 | +226 | +97 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 83 | -83 | 2 of 2 | 0 of 2 | - | -83 |
| Opponent | Dwarfen Mountain Holds | 1 | 719 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | +0 | - |
| Opponent | Empire of Man | 1 | 160 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 60 | 280 | 4.0 | 1.0 | 70 | 0 | +70 | 4 of 4 | 1 of 4 | - | +70 |
| Opponent | High Elf Realms | 2 | 0 | 1055 | 3.0 | 1.3 | 352 | 0 | +352 | 2 of 6 | 5 of 6 | +400 | +328 |
| Opponent | Lizardmen | 1 | 0 | 266 | 2.0 | 1.0 | 133 | 0 | +133 | 1 of 2 | 2 of 2 | - | +133 |
| Opponent | Ogre Kingdoms | 2 | 138 | 491 | 4.5 | 1.3 | 109 | 55 | +54 | 6 of 9 | 4 of 9 | +317 | -77 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 962 | 4.0 | 1.4 | 240 | 48 | +193 | 4 of 8 | 7 of 8 | +272 | +166 |
| Opponent | Skaven | 2 | 0 | 62 | 1.0 | 1.0 | 62 | 0 | +62 | 1 of 2 | 1 of 2 | - | +62 |
| Opponent | Tomb Kings of Khemri | 2 | 162 | 335 | 3.5 | 1.4 | 96 | 57 | +39 | 2 of 7 | 3 of 7 | +7 | +63 |
| Opponent | Vampire Counts | 4 | 0 | 616 | 4.5 | 1.2 | 137 | 30 | +107 | 9 of 18 | 15 of 18 | +270 | +74 |
| Opponent | Warriors of Chaos | 4 | 0 | 469 | 2.5 | 1.1 | 188 | 0 | +188 | 5 of 10 | 9 of 10 | +435 | +160 |
| Opponent | Wood Elf Realms | 4 | 119 | 344 | 2.8 | 1.0 | 125 | 9 | +115 | 4 of 11 | 9 of 11 | - | +115 |
| **Opponent** | all armies | 27 | 75 | 447 | 3.0 | 1.2 | 151 | 26 | +125 | 40 of 80 | 57 of 80 | +237 | +99 |

### Effective charges: t10-mine-ba3e30a-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 3 (net -46) | 1 (net -52) | 1 (net -52) | 2 (net +117) | 0 | 1 (net +125) | 0 | 12% (1 of 8) |
| Mine | Chaos Dwarfs | 13 | 2 (net +306) | 0 | 1 (net +0) | 3 (net +137) | 2 (net +72) | 5 (net +185) | 0 | 8% (1 of 13) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 2 (net +0) | 0 | 1 (net +60) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 7 | 1 (net -380) | 0 | 2 (net +168) | 1 (net +0) | 1 (net +72) | 2 (net +42) | 0 | 29% (2 of 7) |
| Mine | Grand Cathay | 9 | 1 (net +385) | 0 | 2 (net +98) | 1 (net +0) | 1 (net +0) | 3 (net +107) | 1 | 25% (2 of 8) |
| Mine | High Elf Realms | 16 | 1 (net +233) | 0 | 2 (net +246) | 1 (net +0) | 5 (net +233) | 7 (net +144) | 0 | 12% (2 of 16) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +268) | 0 | 0 | 3 (net +85) | 0 | 1 (net +147) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 2 | 0 | 1 (net -175) | 0 | 0 | 1 (net +60) | 0 | 0 | 0% (0 of 2) |
| Opponent | Beastmen Brayherds | 2 | 1 (net -85) | 1 (net -81) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 4 | 4 (net +70) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 6 | 1 (net +406) | 0 | 1 (net +95) | 2 (net +176) | 0 | 2 (net +628) | 0 | 17% (1 of 6) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 1 (net +77) | 0 | 1 (net +189) | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 9 | 1 (net +0) | 0 | 1 (net +30) | 0 | 0 | 2 (net +476) | 5 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 8 | 1 (net +297) | 0 | 2 (net +199) | 1 (net +225) | 0 | 0 | 4 | 50% (2 of 4) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +124) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 7 | 1 (net -136) | 1 (net +141) | 1 (net -195) | 3 (net +96) | 0 | 1 (net +175) | 0 | 14% (1 of 7) |
| Opponent | Vampire Counts | 18 | 3 (net +111) | 1 (net -60) | 4 (net +99) | 4 (net +30) | 1 (net +612) | 4 (net +105) | 1 | 24% (4 of 17) |
| Opponent | Warriors of Chaos | 10 | 1 (net +416) | 0 | 1 (net +0) | 4 (net +226) | 0 | 3 (net +145) | 1 | 11% (1 of 9) |
| Opponent | Wood Elf Realms | 11 | 1 (net +0) | 2 (net +248) | 1 (net +52) | 2 (net +340) | 0 | 3 (net +49) | 2 | 11% (1 of 9) |

### Charged fights, damage counted: t10-mine-ba3e30a-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 320 | 223 | +109 | 182 | 90 | +92 | +28.8 |
| Mine | 50-54% | 2 | 114 | 114 | -114 | 46 | 114 | -68 | -59.8 |
| Mine | Effective (55-75%) | 8 | 252 | 212 | +121 | 132 | 6 | +125 | +49.7 |
| Mine | 76-89% | 13 | 231 | 166 | +69 | 113 | 31 | +82 | +35.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 264 | 170 | +134 | 145 | 3 | +142 | +53.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 512 | 94 | +144 | 154 | 0 | +154 | +30.2 |
| Mine | No odds | 1 | 334 | 112 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 63 | 299 | 167 | +107 | 138 | 25 | +113 | +37.9 |
| Opponent | Long shot (under 50%) | 15 | 245 | 247 | +101 | 142 | 53 | +89 | +36.3 |
| Opponent | 50-54% | 5 | 161 | 251 | +99 | 142 | 101 | +41 | +25.4 |
| Opponent | Effective (55-75%) | 11 | 260 | 136 | +71 | 140 | 54 | +87 | +33.4 |
| Opponent | 76-89% | 17 | 279 | 198 | +156 | 174 | 28 | +146 | +52.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 354 | 204 | +205 | 214 | 19 | +195 | +55.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 813 | 239 | +612 | 612 | 0 | +612 | +75.3 |
| Opponent | No odds | 13 | 155 | 302 | +19 | 99 | 77 | +22 | +14.4 |
| Opponent | All fights | 80 | 266 | 221 | +125 | 164 | 46 | +117 | +44.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t10-mine-ba3e30a-p1 | move | 245 | 56 (23%) | 40 (16%) | 34 (14%) | 155 (63%) |
| t10-mine-ba3e30a-p1 | objective | 198 | 39 (20%) | 25 (13%) | 26 (13%) | 133 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

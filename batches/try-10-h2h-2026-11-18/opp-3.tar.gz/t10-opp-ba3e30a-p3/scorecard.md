# Doctrine scorecard: t10-opp-ba3e30a-p3

### Scorecard: t10-opp-ba3e30a-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 165 |
| L0126 | 6 | 1 | Mine | no | 9 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 2 | - | 0 | 5 | 0 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L0226 | 4 | 1 | Mine | no | 0 | - | 0 | 6 | 1 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 1 | 5 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 0 | - | 3 | 5 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 1 | 0 | 0 | 302 |
| L0429 | 3 | 1 | Mine | no | 3 | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 8 | 2 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 7 | - | 1 | 1 | 1 | 0 | 0 | 100 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | no | - | - | 0 | 6 | 0 | 0 | 0 | 19 |
| L0620 | 2 | 1 | Mine | - | - | - | 1 | 1 | 1 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 1 | 4 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 11 | 3 | 1 | 1 | 0 | 0 | 0 | 45 |
| L0725 | 5 | 1 | Mine | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Opponent | yes | - | - | 4 | 0 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 1 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 769 |
| L0831 | 3 | 1 | Opponent | no | 10 | 5 | 1 | 3 | 0 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0922 | 4 | 1 | Opponent | yes | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 4 | 3 | 0 | 1 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 427 |
| L1122 | 6 | 1 | Opponent | no | 4 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 651 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 1 | 0 | 0 | 137 |
| L1327 | 1 | 1 | Mine | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 7 | 5 | 1 | 5 | 0 | 0 | 0 | 75 |
| L1422 | 6 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 7 | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 5 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | no | - | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 3 | 2 | 5 | 0 | 0 | 0 | 158 |
| L1633 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1633 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1731 | 3 | 1 | Mine | yes | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | yes | 5 | 2 | 4 | 0 | 3 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 2 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 7 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 370 |
| **Average** | | | Mine | 20% | 2.7 | 2.4 | 1.8 | 1.4 | 0.4 | 0.0 | 0.0 | 280.1 |
| **Average** | | | Opponent | 24% | 4.9 | 2.9 | 2.2 | 1.9 | 0.4 | 0.0 | 0.0 | 140.2 |

### KPIs: t10-opp-ba3e30a-p3

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 29 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (38 of 123) | 5% (7 of 134) | 18% (45 of 257) |
| Winner chose to follow up after the loser gave ground |  | 96% (43 of 45); on the table 98% | 97% (34 of 35); on the table 97% | 96% (77 of 80); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (4 of 5); on the table 80% | 100% (4 of 4); on the table 100% | 89% (8 of 9); on the table 89% |
| Winner chose to pursue after the loser fled |  | 73% (8 of 11); on the table 73% | 57% (8 of 14); on the table 64% | 64% (16 of 25); on the table 68% |
| Winner chose to follow up or pursue (all three) |  | 90% (55 of 61); on the table 92% | 87% (46 of 53); on the table 89% | 89% (101 of 114); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 32% (99 of 306) | 26% (50 of 190) | 30% (149 of 496) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (99 of 216) | 39% (50 of 129) | 43% (149 of 345) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (5 of 8) | 59% (26 of 44) | 60% (31 of 52) |
| Points that never fought | lower | 52% (28683 of 54695) | 50% (27849 of 55991) | 51% (56532 of 110686) |
|   infantry points that never fought | lower | 63% (6943 of 11096) | 57% (6091 of 10611) | 60% (13034 of 21707) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (136 of 224) | 65% (142 of 220) | 63% (278 of 444) |
| Bound items with a magic missile used (at least once a game) |  | 83% (20 of 24); 2.5 uses a game | 78% (14 of 18); 1.3 uses a game | 81% (34 of 42); 1.9 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.4 uses a game | 33% (2 of 6); 0.1 uses a game | 45% (9 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 68% (13 of 19); 0.4 uses a game | 40% (4 of 10); 0.1 uses a game | 59% (17 of 29); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (26465 of 47255) | 62% (30616 of 49673) | 59% (57081 of 96928) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (33%) | 1.1 (23%) | 3.4 (29%) |
| MARCHED: its unit marched | 1.2 (16%) | 1.5 (32%) | 2.7 (22%) |
| CHARGED: its unit charged | 0.2 (2%) | 0.2 (4%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.7 (23%) | 1.1 (24%) | 2.8 (23%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| GONE: slain | 0.9 (13%) | 0.7 (15%) | 1.7 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.1 (1%) | 0.5 (4%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.4 | 2.1 | 5.1 | 0.7 | 2.4 |
| not cast | 3.2 | 1.1 | 4.8 | 11.8 | 2.7 | 18.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (58%) | 0.4 (8%) | 3.4 (29%) | 0.4 (16%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (22%) | 0.4 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.1 (6%) | 0.7 (15%) | 2.8 (23%) | 0.4 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.5 (10%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (6%) | 0.0 (1%) | 0.1 (1%) | 0.0 (1%) | 0.2 (1%) |
| GONE: slain | 1.1 (35%) | 0.2 (15%) | 1.3 (26%) | 1.7 (14%) | 0.2 (8%) | 2.5 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (12%) | 0.1 (3%) | 0.5 (4%) | 0.1 (5%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.2 (5%) | 0.0 (0%) | 0.3 (6%) | 0.2 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.0 (3%) | 0.0 (0%) | 0.0 (0%) | 1.0 (37%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (46%) | 0.0 (0%) | 1.5 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 1.0 a game | 1.1 a game |
| stood (cast and not dispelled) | 70% (21 of 30) | 48% (12 of 25) | 60% (33 of 55) |
| the unit moved after it | 57% (12 of 21) | 75% (9 of 12) | 64% (21 of 33) |
| it charged on its next turn | 5% (1 of 21) | 0% (0 of 12) | 3% (1 of 33) |
| the enemy charged it first | 10% (2 of 21) | 0% (0 of 12) | 6% (2 of 33) |
| it fought by the end of its next turn | 0% (0 of 21) | 0% (0 of 12) | 0% (0 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 10% (2 of 21) | 0% (0 of 12) | 6% (2 of 33) |
| none of these (no charge, no fight, no charge escaped) | 76% (16 of 21) | 100% (12 of 12) | 85% (28 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (463 of 683) | 58% (266 of 458) | 64% (729 of 1141) |
|   cavalry | 76% (31 of 41) | 61% (31 of 51) | 67% (62 of 92) |
|   character | 57% (47 of 83) | 22% (20 of 89) | 39% (67 of 172) |
|   chariot | 67% (60 of 90) | 58% (21 of 36) | 64% (81 of 126) |
|   infantry | 62% (104 of 169) | 71% (132 of 187) | 66% (236 of 356) |
|   monster | 42% (16 of 38) | 50% (3 of 6) | 43% (19 of 44) |
|   war machine | 78% (205 of 262) | 66% (59 of 89) | 75% (264 of 351) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (22%) | 1.6 (24%) | 3.2 (23%) |
| CHARGED: it charged | 0.9 (12%) | 1.0 (16%) | 2.0 (14%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (6%) | 0.2 (3%) | 0.7 (5%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.5 (7%) | 0.5 (3%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.5 (20%) | 1.3 (20%) | 2.8 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.1 (2%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (23%) | 1.3 (20%) | 3.1 (22%) |
| SHELTERED: the target was sheltered | 0.4 (5%) | 0.1 (1%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.2 (4%) | 0.5 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.9 | 1.1 | 76% | 9.5 pts | 37 pts |
| character | 2.7 | 0.7 | 79% | 6.5 pts | 17 pts |
| chariot | 2.8 | 1.0 | 72% | 11.8 pts | 33 pts |
| infantry | 12.1 | 4.5 | 74% | 9.5 pts | 115 pts |
| monster | 0.8 | 0.3 | 73% | 17.2 pts | 13 pts |
| war machine | 9.2 | 8.8 | 59% | 34.2 pts | 316 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 4.0 | 3.8 |
| Charges that made contact a game | 2.5 | 2.6 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.15 declared, 1.00 contact (20 units) | 0.80 declared, 0.70 contact (20 units) | 0.97 declared, 0.85 contact (40 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.67 declared, 1.00 contact (3 units) | 0.71 declared, 0.43 contact (7 units) | 1.00 declared, 0.60 contact (10 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.42 declared, 0.27 contact (182 units) | 0.43 declared, 0.27 contact (220 units) | 0.43 declared, 0.27 contact (402 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 61% (36 of 59) | 62% (8 of 13) | 71% (5 of 7) | 62% (49 of 79) |
| Character in a unit | 94% (32 of 34) | 82% (9 of 11) | 100% (2 of 2) | 91% (43 of 47) |
| Character on its own | 77% (20 of 26) | 47% (17 of 36) | 43% (23 of 53) | 52% (60 of 115) |
| Chariot | 73% (8 of 11) | 75% (9 of 12) | - | 74% (17 of 23) |
| Infantry | 56% (34 of 61) | 58% (15 of 26) | 75% (3 of 4) | 57% (52 of 91) |
| Monster | 56% (14 of 25) | 50% (2 of 4) | - | 55% (16 of 29) |
| Monstrous | 60% (3 of 5) | 60% (6 of 10) | - | 60% (9 of 15) |
| War Machines | 70% (30 of 43) | 100% (2 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 75% (6 of 8); on the table 75% | 28% (27 of 96) | 40% | 64% (14 of 22) | 100% (6 of 6); 5.8 uses a game | 100% (2 of 2); 0.8 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 89% (8 of 9); on the table 89% | 28% (10 of 36) | 60% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 84% | 83% (20 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 91% (10 of 11); on the table 91% | 30% (9 of 30) | 59% | 68% (40 of 59) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 78% (18 of 23); on the table 83% | 35% (67 of 192) | 51% | 49% (36 of 74) | 83% (15 of 18); 5.5 uses a game | 25% (1 of 4); 0.1 uses a game | 50% (4 of 8); 0.5 uses a game |
| High Elf Realms | 7 | 100% (16 of 16); on the table 100% | 7% (3 of 42) | 40% | 61% (33 of 54) | 67% (6 of 9); 3.1 uses a game | 42% (5 of 12); 1.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | - | - | 73% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 37% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | 83% (5 of 6) | 87% | 57% (4 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (2 of 2); on the table 100% | 8% (1 of 12) | 9% | 81% (13 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 1 | 75% (3 of 4); on the table 100% | 50% (3 of 6) | 65% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 3 | 100% (10 of 10); on the table 100% | 17% (1 of 6) | 43% | 53% (8 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 100% (7 of 7); on the table 100% | 39% (14 of 36) | 51% | 75% (21 of 28) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 7 | 87% (13 of 15); on the table 87% | 17% (3 of 18) | 43% | 60% (39 of 65) | 100% (3 of 3); 1.4 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 2 | 100% (3 of 3); on the table 100% | 50% (3 of 6) | 71% | 82% (18 of 22) | 67% (2 of 3); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t10-opp-ba3e30a-p3, 29 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (24) | 40% (17) | 45% (41) |
| ...free all their last turn and able to turn (per game) | 0.66 | 0.38 | 1.03 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.10 | 0.21 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.45 | 0.31 | 0.76 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.31 | 0.00 | 1.31 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.86 | 0.03 | 0.90 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.97 | 0.28 | 5.24 |

### Quality by phase: t10-opp-ba3e30a-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.8 |
| Strategy | Charge objectives carried out (made contact) | 56% (43 of 77) | 54% (58 of 107) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (178 of 375) | 51% (69 of 135) |
| Strategy | Close-in objectives charged next turn | 17% (25 of 146) | - |
| Strategy | Support requests answered (helper made contact too) | 42% (5 of 12) | 38% (5 of 13) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 54% (7 of 13) | 40% (2 of 5) |
| Strategy | Joined characters whose unit fought | 27% (11 of 41) | 15% (4 of 27) |
| Strategy | Lone characters that fought | 70% (48 of 69) | 66% (51 of 77) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.4 | 1.9 |
| Movement | Points that never moved of their own | 280.1 | 140.2 |
| Movement | Fights charged into per game | 2.1 | 2.4 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 46, net +69 | 14 of 62, net +89 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 46, net +117 | 9 of 62, net +59 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 46, net +71 | 6 of 62, net +119 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 of 46, net +59 | 22 of 62, net +141 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 8.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (117 of 271) | 55% (135 of 245) |
| Shooting | Points destroyed by shooting units | 81.0 | 42.2 |
| Shooting | War machine shots | 7.1 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (102 of 205) | 49% (31 of 63) |
| Shooting | Points destroyed by war machines | 80.2 | 13.5 |
| Magic | Magic missiles cast | 2.5 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 49% (36 of 73) | 27% (9 of 33) |
| Magic | Wounds caused by magic missiles | 4.7 | 1.6 |
| Magic | Wounds caused by other spells | 2.7 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 123.8 | 18.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.4 / 1.0 / 0.2 | 1.8 / 0.2 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 241.3 | 263.4 |
| Combat | Points run down | 88.7 | 80.7 |
| Combat | Net points per charged fight, damage counted | +86 | +68 |
| Combat | Net per 100 charger points, damage counted | +24.9 | +22.7 |
| Combat | First round won (charged fights) | 80% | 68% |
| Combat | Net points per charged fight | +82 | +77 |
| Combat | Net points per supported fight / lone fight | +135 / +69 | +452 / +41 |
| Combat | Charged fights on a top-3 enemy unit | 22 of 59 | 29 of 68 |
| Game | Points lost | 606.5 | 709.0 |
| Game | VP from objectives | 542.1 | 569.3 |
| Game | Lone holders (player turns) | 2.7 | 4.9 |

- Mine won / drew / lost: 11 / 6 / 11 of 28 ended games (of 29); mean margin (Mine - Opponent) +117 VP
- The side that went first won 16 of 22 games with a winner
- Points traded per game (both sides' losses): 1315
- Games not ended: 1 (L1633-1); findings 1, warnings 0

### Opponent rules: t10-opp-ba3e30a-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 10.8 |
| ADVANCE WORTH | 5.9 | -149.1 | 205.0 | 76.7 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.1 | +20.5 | 0.0 | 0.0 |
| ARMY TABLE | - | - | - | - | 12.3 | +134.6 | 0.0 | 184.8 |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 14.3 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +3.9 | 0.0 | 10.1 | 0.1 | +0.5 | 0.0 | 0.0 |
| BEST FACING | 0.5 | +13.3 | 0.0 | 11.1 | - | - | - | - |
| BEST FIRST | 1.4 | +61.6 | 46.3 | 21.6 | - | - | - | - |
| BEST MOVE FOR SHOOTERS | 1.1 | +85.4 | 0.0 | 18.1 | - | - | - | - |
| BEST OVERALL | 0.2 | +11.3 | 0.0 | 8.7 | - | - | - | - |
| BEST PREY | 0.8 | +42.7 | 23.4 | 12.3 | - | - | - | - |
| BEST PRIZE | 0.2 | -1.3 | 15.9 | 17.6 | 0.1 | -3.9 | 0.0 | 8.8 |
| BIG CHARACTER SAFETY | 0.2 | -2.2 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 5.9 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.3 | +7.3 | 0.0 | 4.9 | - | - | - | - |
| BLOWS WHERE AIMED | 0.1 | -6.2 | 0.0 | 0.0 | 0.2 | -43.8 | 44.4 | 6.7 |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.9 | 0.0 | +0.0 | 0.0 | 5.2 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 96.3 | 20.3 | 0.3 | +0.0 | 10.6 | 0.0 |
| CANNON PLANNED TARGET | 6.7 | +178.1 | 361.1 | 82.6 | 1.6 | +60.9 | 28.2 | 20.7 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | -6.4 | 44.8 | 0.0 | 0.1 | -7.1 | 6.4 | 4.0 |
| CAST JOB | 1.0 | +27.8 | 66.0 | 5.9 | 0.2 | +1.6 | 2.9 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +3.5 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 52.6 | 0.5 | +0.0 | 0.0 | 20.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.8 | +50.6 | 0.0 | 21.4 | 0.6 | +35.2 | 0.0 | 9.4 |
| CHAFF PASSED | 0.1 | -0.7 | 0.0 | 0.0 | 0.1 | -0.5 | 4.3 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.0 | +16.4 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 5.8 | -306.4 | 0.0 | 181.1 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 15.8 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 228.0 | 19.8 | 1.9 | +0.0 | 171.8 | 31.3 |
| CHARGE NOW WEIGHED | 0.3 | -15.7 | 5.9 | 0.0 | - | - | - | - |
| CHARGER SLAIN LOST | 0.4 | -10.6 | 85.4 | 0.0 | 0.1 | -3.9 | 11.1 | 16.0 |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.7 | 8.1 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 10.5 | 42.0 | 0.4 | +0.0 | 12.8 | 42.7 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 2.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +72.1 | 8.4 | 13.1 | 0.6 | +27.7 | 18.1 | 30.5 |
| COVER ONCE | 7.0 | -694.4 | 0.0 | 101.4 | 5.9 | -485.2 | 0.0 | 125.2 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 8.7 | 1.2 | - | - | - | - |
| DEPLOY BY FIGURES | 7.9 | +20.9 | 0.0 | 15.9 | 7.3 | +67.2 | 0.0 | 40.2 |
| EDGE GIVE GROUND | 0.2 | +8.8 | 48.9 | 0.0 | 0.1 | +0.4 | 13.7 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.3 | +102.9 | 0.0 | 17.8 | - | - | - | - |
| FALL BACK GOOD ORDER | - | - | - | - | 2.4 | +11.6 | 266.5 | 71.8 |
| FALLBACK BY WORTH | 4.1 | +57.6 | 0.0 | 40.2 | 0.4 | +7.5 | 0.0 | 6.7 |
| FALLS SHORT | - | - | - | - | 16.5 | +226.7 | 0.0 | 347.0 |
| FEATURE BUFFS | - | - | - | - | 0.6 | +12.1 | 0.0 | 23.0 |
| FIGHT LIFT | 0.1 | +0.5 | 0.0 | 13.6 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 1.4 | +113.1 | 147.3 | 48.7 |
| FIRE IN ORDER | 0.2 | +0.0 | 8.0 | 4.0 | 0.1 | +0.0 | 4.2 | 2.5 |
| FIVE ACTION | - | - | - | - | 39.9 | +2703.0 | 571.3 | 643.4 |
| FLANK NOT WEIGHED | 4.2 | +0.0 | 0.0 | 92.7 | 5.1 | +0.0 | 0.0 | 101.8 |
| FOLLOW UP WEIGHED | 1.0 | +152.3 | 0.0 | 40.1 | 0.8 | +188.7 | 0.0 | 20.7 |
| FOUR ROUNDS | - | - | - | - | 3.7 | +404.6 | 349.3 | 85.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.2 | -17.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.2 | -18.6 | 0.0 | 4.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +4.3 | 0.0 | 0.0 | 0.1 | +6.1 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.3 | 11.6 | 20.6 | 0.3 | -3.1 | 32.3 | 6.7 |
| GROUND FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +1.7 | 0.0 | 0.0 |
| GUN FIGURES | 1.1 | +16.8 | 62.0 | 10.7 | 0.4 | +0.3 | 0.0 | 20.5 |
| GUN MASK | - | - | - | - | 0.4 | +8.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | - | - | - | - | 2.5 | +0.0 | 0.0 | 125.4 |
| HELPER UNSEEN | 0.1 | +0.0 | 13.7 | 0.0 | 0.1 | +0.0 | 8.7 | 1.6 |
| HILL BY ITS CHANCE | 0.2 | -11.3 | 0.0 | 2.2 | - | - | - | - |
| HIS CHARGE DENIED | - | - | - | - | 0.2 | +24.7 | 3.6 | 11.2 |
| HIS CHARGE LIST | - | - | - | - | 3.4 | +0.0 | 0.0 | 105.4 |
| HIS FIGHT TOGETHER | - | - | - | - | 1.0 | -21.3 | 0.0 | 71.6 |
| HIS LEGAL MOVES | - | - | - | - | 2.6 | +0.0 | 0.0 | 53.9 |
| HIS MOVE AND SHOT | - | - | - | - | 1.3 | -24.6 | 0.0 | 73.7 |
| HIS OWN BEST MOVE | - | - | - | - | 2.3 | +0.0 | 0.0 | 9.6 |
| HIS RANDOM MOVE | - | - | - | - | 0.5 | +0.0 | 0.0 | 1.6 |
| HIS SHOT LIST | - | - | - | - | 23.0 | +1328.6 | 0.0 | 416.1 |
| HIS TURN DENIED | - | - | - | - | 1.9 | +98.7 | 188.1 | 54.6 |
| HOLDER ASSIGNMENT | - | - | - | - | 10.9 | +1096.7 | 0.0 | 108.3 |
| HOLDER AT DEPLOYMENT | 0.9 | +141.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.3 | -142.6 | 456.2 | 83.0 | 3.0 | -132.5 | 285.7 | 56.3 |
| HUNT ADVANCE | 0.2 | +12.1 | 0.0 | 10.1 | - | - | - | - |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 5.9 | - | - | - | - |
| HUNT IN PAIRS | 0.6 | +18.3 | 0.0 | 0.0 | 0.2 | +6.1 | 0.0 | 6.7 |
| HUNT KEPT | 0.1 | +3.1 | 0.0 | 3.6 | - | - | - | - |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 5.9 | - | - | - | - |
| HUNT THE GUNS | 0.1 | +59.9 | 0.0 | 6.5 | - | - | - | - |
| IDLE COST | 14.1 | -252.7 | 0.0 | 125.6 | 10.9 | -172.4 | 0.0 | 150.6 |
| INVITES THE FIGHT | 1.0 | +7.2 | 26.9 | 10.7 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 0.9 | +9.5 | 131.8 | 17.5 |
| JOINT CHARGE PLAN | 0.0 | +0.0 | 11.6 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.0 | -0.2 | 11.6 | 0.0 | 0.1 | -0.5 | 0.0 | 2.1 |
| KEEP FALLS | 0.3 | +5.1 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.4 | +43.4 | 124.0 | 12.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +62.7 | 124.8 | 7.1 | - | - | - | - |
| KILLS COUNT NEXT TURN | 5.4 | +154.5 | 195.7 | 63.7 | - | - | - | - |
| LANE BY FIGURES | 0.8 | +26.7 | 0.0 | 0.0 | 1.1 | +43.5 | 0.0 | 16.2 |
| LEGAL CHARGES ONLY | - | - | - | - | 5.5 | +0.0 | 215.3 | 242.4 |
| LONE CHARACTER SAFE SPOT | 0.3 | +11.4 | 30.6 | 0.0 | 0.1 | +3.0 | 0.0 | 6.6 |
| LONE WIZARD KEPT IN | 0.6 | +41.6 | 0.0 | 0.0 | 0.4 | +30.8 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.1 | 4.3 | 0.0 | 0.2 | -1.1 | 15.8 | 0.0 |
| LOST CHARGE | 2.7 | -44.5 | 143.9 | 27.4 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.2 | -28.9 | 0.0 | 3.9 | 0.0 | -1.6 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.8 | +49.6 | 62.2 | 13.1 | 0.3 | +30.0 | 0.0 | 2.9 |
| MANOEUVRE | 0.5 | +14.5 | 0.0 | 6.7 | 1.4 | +27.0 | 0.0 | 8.3 |
| MARCH AT ESCAPER | 0.2 | +1.3 | 0.0 | 11.8 | 0.1 | +1.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +23.8 | 0.0 | 28.4 |
| MARCH CHECK | 0.4 | +8.6 | 0.0 | 0.0 | 0.9 | +40.7 | 0.0 | 52.6 |
| MARCH ODDS | 0.2 | +18.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.6 | +41.6 | 0.0 | 6.7 | 0.9 | +50.9 | 0.0 | 28.4 |
| MAX FOR POSITIONING | 6.3 | +104.5 | 0.0 | 103.1 | 5.9 | +98.2 | 0.0 | 162.4 |
| MISSILES IN THE MOVE | 5.0 | +190.0 | 0.0 | 42.3 | 3.2 | +50.9 | 0.0 | 61.8 |
| MISSILES NEXT TURN | 6.2 | +121.9 | 0.0 | 66.8 | 4.6 | +39.6 | 0.0 | 124.4 |
| MODEL FACING | 0.1 | +15.0 | 0.0 | 4.1 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 29.3 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.5 | +22.0 | 0.0 | 5.9 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 2.3 | +0.0 | 49.0 | 29.1 |
| MOVE SPELL IN RANGE | 0.2 | +5.6 | 0.0 | 13.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -20.5 | 0.0 | 13.1 | 0.2 | -11.7 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 1.9 | 0.3 | +0.0 | 0.0 | 13.8 |
| MOVE TO CHARGE | 3.7 | +162.3 | 153.6 | 21.2 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 3.9 | +600.6 | 0.0 | 75.2 |
| MOVES UNITS SPELL | 0.2 | +4.5 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | - | - | - | - | 3.1 | +112.7 | 0.0 | 31.9 |
| NEEDED THERE | 0.0 | +5.1 | 5.9 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | - | - | - | - | 4.7 | -150.6 | 18.5 | 121.8 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 4.6 | -129.2 | 13.4 | 114.4 |
| NO DOUBLE ROUNDS | - | - | - | - | 3.1 | -155.3 | 286.3 | 69.9 |
| NO RALLY LEFT | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.3 | -10.2 | 41.9 | 0.0 | - | - | - | - |
| NOT TURNED | 5.0 | +69.4 | 0.0 | 121.7 | 0.3 | +0.0 | 0.0 | 5.0 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 26.7 | 0.1 | -0.0 | 0.0 | 0.0 |
| OFF BEST | 16.1 | -755.9 | 21.1 | 172.4 | 1.2 | -45.3 | 0.0 | 7.2 |
| ONE CHARGE A CHARGER | - | - | - | - | 2.8 | +0.0 | 0.0 | 84.7 |
| ONE FIGHT FORMULA | 7.2 | -120.8 | 7.4 | 87.8 | 5.3 | -140.9 | 0.0 | 133.4 |
| ONE OBJECTIVE FORMULA | 2.7 | -125.2 | 0.0 | 31.3 | 3.1 | +66.5 | 0.0 | 64.7 |
| ONE TARGET A SHOOTER | - | - | - | - | 17.9 | +547.9 | 0.0 | 323.5 |
| OPENS A LANE | 0.2 | +0.6 | 0.0 | 0.0 | 0.1 | +0.2 | 4.8 | 0.0 |
| OPENS UP | 0.2 | +14.4 | 9.1 | 0.0 | 0.1 | +5.6 | 12.0 | 0.0 |
| OVERRUN THREAT | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.6 | +12.5 | 65.4 | 11.7 | 0.6 | +23.2 | 91.3 | 0.0 |
| PATHS CROSS | 1.7 | +110.1 | 0.0 | 2.9 | 3.4 | +116.3 | 0.0 | 64.4 |
| PIVOT GUARDS FLANK | 0.0 | -0.6 | 0.0 | 4.0 | 0.2 | -7.1 | 0.0 | 15.2 |
| PLAN RESULT | 37.0 | +1485.0 | 1065.5 | 748.1 | 36.4 | +520.4 | 336.7 | 947.6 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -7.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +10.1 | 0.0 | 1.9 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.3 | +1.8 | 0.0 | 0.0 | 1.5 | +35.1 | 0.0 | 55.5 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.5 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.6 | -12.0 | 0.0 | 18.2 | 0.7 | -13.3 | 0.0 | 8.8 |
| REDIRECT COUNTER | 2.2 | +216.0 | 0.0 | 51.2 | 2.8 | +284.3 | 0.0 | 44.2 |
| REDIRECT WEIGHED | 0.4 | +0.3 | 25.3 | 15.7 | 0.3 | -3.9 | 0.0 | 8.8 |
| REFORMS TO MEET IT | - | - | - | - | 0.6 | -8.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +7.7 | 0.0 | 20.1 | 0.6 | +12.6 | 0.0 | 11.3 |
| RESTRAINS TO SHOOT | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.1 | +84.0 | 264.8 | 18.7 | 2.8 | +3.0 | 272.5 | 54.2 |
| RISK BY HIS FIGURE | - | - | - | - | 11.7 | -183.7 | 0.0 | 339.6 |
| RISK ONCE | 3.7 | +108.5 | 20.4 | 133.5 | - | - | - | - |
| RUN DOWN | - | - | - | - | 3.0 | -37.2 | 303.4 | 60.3 |
| SAFE SURE CHARGE | 0.0 | -2.5 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +30.4 | 0.0 | 14.7 | 0.0 | +1.2 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -0.3 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.5 | 0.0 | 1.2 | 0.3 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 1.2 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -7.0 | 0.0 | 3.2 | 0.2 | -15.0 | 0.0 | 0.7 |
| SEARCH SPOT | 2.0 | +83.5 | 0.0 | 20.2 | 5.1 | +196.3 | 0.0 | 89.6 |
| SECOND HUNTER | 0.1 | -3.3 | 0.0 | 1.8 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +53.3 | 0.0 | 63.3 | 0.2 | +41.4 | 0.0 | 49.7 |
| SET UP BY THE SET | - | - | - | - | 0.7 | -28.7 | 4.7 | 28.7 |
| SET UP TOGETHER | 1.6 | +86.0 | 81.8 | 15.2 | 0.5 | +31.9 | 0.0 | 2.9 |
| SET-UP ANY TARGET | 0.5 | +82.8 | 6.5 | 13.1 | 0.2 | +31.8 | 0.0 | 7.3 |
| SET-UP MISSED | 0.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +73.6 | 105.1 | 29.6 | 0.8 | +38.9 | 11.9 | 16.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.2 | -7.1 | 19.7 | 0.0 |
| SHOT RISK POINTS | - | - | - | - | 11.8 | -0.2 | 0.0 | 293.9 |
| SHOTS IN THE MOVE | 15.3 | +714.4 | 0.0 | 190.0 | 9.9 | +397.8 | 0.0 | 170.1 |
| SPELL SETS UP CHARGE | 0.6 | +106.0 | 6.5 | 13.1 | 0.2 | +31.8 | 0.0 | 7.3 |
| SPELL WORTH | 1.0 | +16.2 | 17.0 | 16.6 | 2.3 | +43.4 | 36.9 | 27.4 |
| SPELLS IN THE FIGHT | 0.6 | -1.3 | 118.3 | 7.1 | 0.6 | -13.0 | 51.0 | 18.8 |
| STABLE ROLE | 11.0 | +0.0 | 275.8 | 131.4 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.6 | -12.8 | 50.0 | 4.6 |
| STANDS FOR A REASON | - | - | - | - | 0.8 | +0.0 | 10.7 | 13.6 |
| STANDS STILL | - | - | - | - | 9.3 | +0.0 | 222.1 | 98.0 |
| STAY WEIGHED | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 20.3 | +61.0 | 465.5 | 146.2 | 10.6 | +117.7 | 169.3 | 142.2 |
| STOPS SHORT OF THE FLANK | 0.5 | +31.2 | 0.0 | 4.9 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 5.9 |
| SUPPORT NARROWED | 4.6 | -54.4 | 191.8 | 42.1 | 1.3 | +0.0 | 123.2 | 34.9 |
| SUPPORTS | 3.3 | +64.5 | 107.8 | 22.0 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.2 | -4.5 | 7.9 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.6 | +3.4 | 19.7 | 2.9 | 0.2 | +6.7 | 0.0 | 2.5 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 3.7 | +0.0 | 0.0 | 58.2 |
| THE PROMISE ADDS | - | - | - | - | 0.1 | -12.9 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 1.8 | +0.0 | 0.0 | 23.5 |
| THROUGH LINE OF FIRE | 0.6 | +20.3 | 0.0 | 1.2 | - | - | - | - |
| TIED UP BY THE SUM | - | - | - | - | 0.6 | +64.2 | 41.4 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 6.1 | +98.7 | 0.0 | 26.2 |
| TURN WORTH | 0.5 | -31.6 | 40.6 | 9.6 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.3 | +1.9 | 0.0 | 0.0 | 0.0 | +1.9 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 7.4 | -305.7 | 293.0 | 50.4 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.2 | +0.0 | 0.0 | 0.0 |
| WALKS TO THE FIGHT | 2.1 | +16.5 | 53.2 | 18.5 | - | - | - | - |
| WAR ENGINE CHARGES | 0.0 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 42.8 | 15.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 0.7 | +25.7 | 106.6 | 27.3 | - | - | - | - |
| WHO HITS BACK | 0.2 | +21.0 | 0.0 | 9.6 | 0.3 | +34.4 | 0.0 | 10.7 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +43.9 | 71.3 | 4.0 |
| WHOLE FIGHT GAIN | 0.2 | +21.1 | 17.4 | 0.0 | 0.2 | +8.8 | 2.2 | 3.4 |
| WIDER SPREAD | 1.7 | -4.1 | 173.1 | 45.3 | 2.3 | -8.4 | 218.7 | 68.0 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 6.9 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 1.2 | +46.5 | 0.0 | 17.4 |

### Rule changes: t10-opp-ba3e30a-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 501 | 501 | 501 | 17.28 | -23234 | -46.4 |
| HOLDER ASSIGNMENT | 317 | 317 | 295 | 10.17 | +17440 | +59.1 |
| DEPLOY BY FIGURES | 441 | 441 | 285 | 9.83 | +4354 | +15.3 |
| ARMY TABLE | 357 | 357 | 263 | 9.07 | +3815 | +14.5 |
| SEARCH SPOT | 208 | 208 | 200 | 6.90 | +8114 | +40.6 |
| HIS SHOT LIST | 666 | 657 | 195 | 6.72 | +4940 | +25.3 |
| LEGAL CHARGES ONLY | 159 | 159 | 159 | 5.48 | +0 | +0.0 |
| PATHS CROSS | 149 | 149 | 149 | 5.14 | +6565 | +44.1 |
| ONE TARGET A SHOOTER | 518 | 512 | 123 | 4.24 | +1981 | +16.1 |
| FIVE ACTION | 1157 | 1146 | 105 | 3.62 | +5953 | +56.7 |
| MOVE TO CHARGE COMPUTED | 114 | 112 | 71 | 2.45 | +8066 | +113.6 |
| SHOT RISK POINTS | 343 | 340 | 69 | 2.38 | +2452 | +35.5 |
| SHOTS IN THE MOVE | 730 | 597 | 68 | 2.34 | +2702 | +39.7 |
| MOVE ORDER | 66 | 66 | 66 | 2.28 | +0 | +0.0 |
| COVER ONCE | 373 | 240 | 64 | 2.21 | +1604 | +25.1 |
| ADVANCE LANE KEPT | 60 | 60 | 60 | 2.07 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 58 | 58 | 58 | 2.00 | +0 | +0.0 |
| LANE BY FIGURES | 57 | 57 | 57 | 1.97 | +2035 | +35.7 |
| MOVE TO CHARGE | 106 | 106 | 53 | 1.83 | +1416 | +26.7 |
| FOLLOW UP WEIGHED | 52 | 52 | 52 | 1.79 | +9890 | +190.2 |
| FOUR ROUNDS | 108 | 107 | 52 | 1.79 | +5549 | +106.7 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.76 | +0 | +0.0 |
| IDLE COST | 726 | 448 | 50 | 1.72 | +711 | +14.2 |
| KILLS COUNT NEXT TURN | 157 | 157 | 50 | 1.72 | +1044 | +20.9 |
| MAX FOR POSITIONING | 354 | 266 | 45 | 1.55 | +181 | +4.0 |
| CANNON PLANNED TARGET | 238 | 238 | 44 | 1.52 | -148 | -3.4 |
| BEST FIRST | 40 | 40 | 40 | 1.38 | +1788 | +44.7 |
| SHOOTS FROM THE BEST SPOT | 61 | 61 | 39 | 1.34 | +1313 | +33.7 |
| WAIT AFTER COSTS | 215 | 215 | 39 | 1.34 | +623 | +16.0 |
| FACES THE THREAT | 38 | 38 | 38 | 1.31 | +2984 | +78.5 |
| REDIRECT COUNTER | 147 | 104 | 38 | 1.31 | +3096 | +81.5 |
| FALLBACK BY WORTH | 129 | 129 | 36 | 1.24 | +1887 | +52.4 |
| MANOEUVRE | 55 | 55 | 34 | 1.17 | +1204 | +35.4 |
| STAY WORTH | 894 | 802 | 34 | 1.17 | +277 | +8.1 |
| MISSILES IN THE MOVE | 236 | 168 | 33 | 1.14 | +1265 | +38.3 |
| FALLS SHORT | 478 | 416 | 32 | 1.10 | +189 | +5.9 |
| BEST MOVE FOR SHOOTERS | 31 | 31 | 31 | 1.07 | +2477 | +79.9 |
| RANDOM MOVE BY FIGURES | 52 | 52 | 31 | 1.07 | +1070 | +34.5 |
| RISK BY ARC | 143 | 136 | 31 | 1.07 | +1304 | +42.1 |
| ADVANCE WORTH | 172 | 172 | 30 | 1.03 | +853 | +28.4 |
| HOLDS AMBUSHERS | 30 | 30 | 30 | 1.03 | +0 | +0.0 |
| SUPPORTS | 96 | 96 | 30 | 1.03 | +615 | +20.5 |
| CHAFF IN THE MOVE | 38 | 37 | 28 | 0.97 | +697 | +24.9 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.97 | +2097 | +74.9 |
| MARCH CHECK | 39 | 35 | 28 | 0.97 | +369 | +13.2 |
| SET UP TOGETHER | 59 | 50 | 28 | 0.97 | +1856 | +66.3 |
| WALKS TO THE FIGHT | 61 | 61 | 28 | 0.97 | +170 | +6.1 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.90 | +0 | +0.0 |
| ONE FIGHT FORMULA | 362 | 192 | 26 | 0.90 | +123 | +4.7 |
| SAFER THAN THE JOB | 26 | 26 | 26 | 0.90 | +917 | +35.3 |
| JOINT CHARGE NOW | 25 | 25 | 25 | 0.86 | +276 | +11.1 |
| CHARGE NOW FIRST | 115 | 115 | 23 | 0.79 | -1387 | -60.3 |
| RESERVE FALL BACK | 23 | 23 | 23 | 0.79 | +589 | +25.6 |
| CHARGE LOSSES | 168 | 165 | 21 | 0.72 | +1631 | +77.7 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.69 | +1456 | +72.8 |
| SCOUT WAITS | 19 | 19 | 19 | 0.66 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 19 | 19 | 19 | 0.66 | +39 | +2.1 |
| NEXT OBJECTIVE NEARER | 132 | 132 | 18 | 0.62 | +303 | +16.8 |
| TIME ON OUR SIDE | 176 | 144 | 18 | 0.62 | +42 | +2.3 |
| CAST JOB | 37 | 37 | 17 | 0.59 | +348 | +20.5 |
| RISK ONCE | 106 | 73 | 17 | 0.59 | +448 | +26.4 |
| HARD STAY DROPPED | 16 | 16 | 16 | 0.55 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.55 | +589 | +36.8 |
| BEST FACING | 15 | 15 | 15 | 0.52 | +386 | +25.7 |
| MOVE AND CAST | 15 | 15 | 15 | 0.52 | +638 | +42.6 |
| TIED UP BY THE SUM | 16 | 15 | 15 | 0.52 | +637 | +42.4 |
| WHO HITS BACK | 15 | 15 | 15 | 0.52 | +1046 | +69.7 |
| NEXT CHARGE BY LIST | 136 | 134 | 14 | 0.48 | +494 | +35.3 |
| STOPS SHORT OF THE FLANK | 14 | 14 | 14 | 0.48 | +906 | +64.7 |
| RISK BY HIS FIGURE | 339 | 335 | 13 | 0.45 | +1621 | +124.7 |
| ONE OBJECTIVE FORMULA | 170 | 121 | 12 | 0.41 | +339 | +28.2 |
| HIS TURN DENIED | 55 | 54 | 11 | 0.38 | +462 | +42.0 |
| HONEST WORTH | 328 | 322 | 11 | 0.38 | +101 | +9.1 |
| KILLS COUNT | 38 | 34 | 11 | 0.38 | +606 | +55.1 |
| MAKE SURE TOGETHER | 31 | 15 | 11 | 0.38 | +743 | +67.6 |
| BEST PREY | 24 | 24 | 10 | 0.34 | +334 | +33.5 |
| BLOCKED WHEEL | 10 | 10 | 10 | 0.34 | +212 | +21.2 |
| INVITES THE FIGHT | 30 | 30 | 10 | 0.34 | +64 | +6.4 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.31 | +0 | +0.0 |
| FIRE IN ORDER | 9 | 9 | 9 | 0.31 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 25 | 25 | 9 | 0.31 | +475 | +52.8 |
| KEEP FALLS | 9 | 9 | 9 | 0.31 | +425 | +47.3 |
| MARCH BY THE SUM | 9 | 9 | 9 | 0.31 | +691 | +76.7 |
| CHAFF PASSED | 8 | 8 | 8 | 0.28 | -34 | -4.3 |
| CHARGE NOW WEIGHED | 8 | 8 | 8 | 0.28 | +693 | +86.7 |
| OVERRUNS AWAY | 36 | 35 | 8 | 0.28 | +240 | +30.0 |
| BEST OVERALL | 7 | 7 | 7 | 0.24 | +326 | +46.6 |
| BEST PRIZE | 7 | 7 | 7 | 0.24 | -286 | -40.9 |
| CHARGE NOT DECLARED | 7 | 7 | 7 | 0.24 | -793 | -113.3 |
| FIGHT TO THE END | 41 | 41 | 7 | 0.24 | +939 | +134.2 |
| MARCH ODDS | 7 | 7 | 7 | 0.24 | +46 | +6.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.24 | +141 | +20.1 |
| OPENS UP | 9 | 9 | 7 | 0.24 | +240 | +34.2 |
| WHOLE FIGHT GAIN | 12 | 12 | 7 | 0.24 | +383 | +54.7 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.21 | -65 | -10.8 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 0.21 | +0 | +0.0 |
| MISSILES NEXT TURN | 313 | 198 | 6 | 0.21 | +7 | +1.1 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.21 | -225 | -37.5 |
| SET UP BY THE SET | 21 | 21 | 6 | 0.21 | +382 | +63.7 |
| STUCK PIVOT | 6 | 6 | 6 | 0.21 | +0 | +0.0 |
| SUPPORT NARROWED | 172 | 172 | 6 | 0.21 | -202 | -33.7 |
| WEARS DOWN | 20 | 18 | 6 | 0.21 | +182 | +30.4 |
| CARRIES OUT SET-UP | 10 | 10 | 5 | 0.17 | -389 | -77.9 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.17 | +301 | +60.2 |
| NEARER NOT NEEDED | 91 | 90 | 5 | 0.17 | +83 | +16.6 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.17 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.17 | -130 | -26.0 |
| HIS CHARGE DENIED | 7 | 7 | 4 | 0.14 | +392 | +97.9 |
| HUNT IN PAIRS | 22 | 11 | 4 | 0.14 | +151 | +37.8 |
| KEEPS ITS TARGET | 42 | 39 | 4 | 0.14 | +71 | +17.8 |
| LOST CHARGE | 79 | 78 | 4 | 0.14 | +215 | +53.6 |
| SURE REACH TOGETHER | 23 | 15 | 4 | 0.14 | +36 | +8.9 |
| WHOLE FIGHT | 10 | 10 | 4 | 0.14 | +330 | +82.6 |
| AFTERMATH WITH FRIENDS | 3 | 3 | 3 | 0.10 | +595 | +198.3 |
| BACKUP TARGETS | 19 | 11 | 3 | 0.10 | +4 | +1.4 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.10 | +0 | +0.0 |
| MODEL FACING | 3 | 3 | 3 | 0.10 | +436 | +145.2 |
| SPELLS IN THE FIGHT | 34 | 33 | 3 | 0.10 | +3 | +1.0 |
| WAR ENGINE JOBS | 21 | 21 | 3 | 0.10 | -68 | -22.6 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.07 | +0 | +0.1 |
| CASTING BLOCK | 6 | 6 | 2 | 0.07 | +16 | +8.2 |
| DEFENSIVE ARMY | 6 | 6 | 2 | 0.07 | -34 | -16.8 |
| FALL BACK GOOD ORDER | 71 | 70 | 2 | 0.07 | +5 | +2.5 |
| FEATURE BUFFS | 18 | 18 | 2 | 0.07 | +28 | +13.8 |
| HIS FIGHT TOGETHER | 30 | 30 | 2 | 0.07 | +31 | +15.4 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.07 | +12 | +6.1 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.07 | -226 | -112.8 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 2 | 0.07 | +86 | +43.1 |
| STAY WEIGHED | 2 | 2 | 2 | 0.07 | +31 | +15.5 |
| WIDER SPREAD | 117 | 111 | 2 | 0.07 | +16 | +7.8 |
| WOUNDS ON THE RANKS | 36 | 35 | 2 | 0.07 | +80 | +39.9 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.03 | +22 | +21.6 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.03 | +475 | +475.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +4 | +4.3 |
| HILL BY ITS CHANCE | 7 | 7 | 1 | 0.03 | +30 | +30.3 |
| HIS MOVE AND SHOT | 39 | 39 | 1 | 0.03 | +0 | +0.4 |
| HUNT ADVANCE | 6 | 6 | 1 | 0.03 | +79 | +79.0 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 5 | 3 | 1 | 0.03 | +6 | +5.9 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 91 | 90 | 1 | 0.03 | +4 | +3.7 |
| REDIRECT BY WHAT IT STOPS | 36 | 36 | 1 | 0.03 | +101 | +100.7 |
| REFUSING RETIRES | 7 | 7 | 1 | 0.03 | -0 | -0.1 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.03 | +24 | +24.3 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -73 | -72.9 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +1 | +1.1 |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 9 | 7 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 35 | 35 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 16 | 14 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 9 | 9 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 268 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 5 | 5 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 10 | 9 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 43 | not checked | - | - | - | - |
| GUN MASK | 11 | 11 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 73 | 72 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 99 | 96 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 75 | 74 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 67 | 66 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 15 | 15 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 1 | 1 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 12 | not checked | - | - | - | - |
| LONG SHOT | 9 | 9 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 10 | trace | - | - | - | - |
| MARCH OVER CASTS | 43 | 43 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT NEEDED | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 152 | 152 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 19 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 80 | 79 | 0 | 0.00 | - | - |
| OPENS A LANE | 8 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2131 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 18 | 18 | 0 | 0.00 | - | - |
| RUN DOWN | 86 | 85 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 18 | 18 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 14 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 7 | 7 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 22 | not checked | - | - | - | - |
| SPELL WORTH | 97 | not checked | - | - | - | - |
| STABLE ROLE | 320 | 317 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 18 | 17 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 23 | 23 | 0 | 0.00 | - | - |
| STANDS STILL | 270 | 269 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 108 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 53 | not checked | - | - | - | - |
| TURN WORTH | 14 | 13 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 9 | 8 | 0 | 0.00 | - | - |
| WAITS AGAIN | 34 | 33 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: t10-opp-ba3e30a-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.97 | 0.69 | 46.5 |
| ARMY TABLE | rule | - | 1.48 | 40.2 |
| CHARGE NOW FIRST | rule | 0.45 | 0.34 | 60.3 |
| HOLDER ASSIGNMENT | rule | - | 0.79 | 33.2 |
| FALLBACK | gate | 0.48 | 0.07 | 51.3 |
| NO REASON | gate | - | 0.34 | 54.7 |
| JOINT CHARGE NOW | rule | - | 0.31 | 86.2 |
| PATHS CROSS | rule | 0.03 | 0.28 | 31.7 |
| BEST PRIZE | rule | 0.17 | 0.07 | 40.9 |
| CHARGE NOT DECLARED | rule | 0.10 | 0.14 | 113.3 |
| TURN GATE | gate | 0.24 | - | 41.0 |
| BIG CHARACTER SAFETY | rule | 0.21 | - | 10.8 |
| CHAFF PASSED | rule | 0.07 | 0.14 | 5.7 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.17 | 37.5 |
| SUPPORT NARROWED | rule | - | 0.21 | 33.7 |
| CARRIES OUT SET-UP | rule | 0.14 | 0.03 | 77.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.03 | 27.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | - | 26.0 |
| CANNON PLANNED TARGET | rule | 0.07 | 0.03 | 90.3 |
| FIGHT ORDER BAND | gate | 0.10 | - | 1.6 |
| SUPPORT REQUEST | gate | 0.10 | - | 102.4 |
| WAR ENGINE JOBS | rule | 0.07 | 0.03 | 22.6 |
| DEFENSIVE ARMY | rule | 0.07 | - | 16.8 |
| FACES THE THREAT | rule | 0.07 | - | 10.8 |
| PURSUES BIG PREY | rule | - | 0.07 | 112.8 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 44.9 |
| SAFER THAN THE JOB | rule | 0.07 | - | 9.7 |
| STOPS SHORT OF THE FLANK | rule | 0.07 | - | 11.9 |
| THROUGH LINE OF FIRE | rule | 0.07 | - | 32.6 |
| AFTERMATH BAND | gate | - | 0.03 | 1.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 7.6 |
| DEPLOY BY FIGURES | rule | - | 0.03 | 4.0 |
| RESERVE FALL BACK | rule | - | 0.03 | 5.3 |
| RULE SWITCHED OFF | gate | 0.03 | - | 12.1 |
| SAFE SURE CHARGE | rule | 0.03 | - | 72.9 |

### Plans: t10-opp-ba3e30a-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.3 | 14% | 189 | 289 | 152% |
| Mine | charge | 2.3 | 71% | 182 | 290 | 160% |
| Mine | close in | 5.0 | 27% | 234 | 181 | 77% |
| Mine | hold | 5.5 | 35% | 343 | 0 | 0% |
| Mine | join | 0.3 | 100% | 10 | 0 | 0% |
| Mine | shoot | 10.6 | 64% | 324 | 725 | 224% |
| Mine | support | 4.1 | 87% | 54 | 0 | 0% |
| Opponent | charge | 2.9 | 62% | 597 | 288 | 48% |
| Opponent | join | 1.1 | 94% | 78 | 0 | 0% |
| Opponent | move | 28.1 | 91% | 1599 | 0 | 0% |
| Opponent | shoot | 3.6 | 55% | 241 | 233 | 97% |
| Opponent | support | 0.6 | 72% | 12 | 0 | 0% |

### Packages: hunt the guns, t10-opp-ba3e30a-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 0% | 0% | 0% | - | 434 | 0 | 0% | 28 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 107 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 0 | 0% | 0% | 0% | - | 434 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 99 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 85 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 374 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 210 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 89 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 131 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |

### Battle groups: t10-opp-ba3e30a-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 32% | 67% | 10% | 0% | 11% | 0% | 16% | 68% | 5% |
| Opponent | REDIRECT COUNTER | 2.8 | 20% | 81% | 38% | 17% | 0% | 0% | 20% | 80% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t10-opp-ba3e30a-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 20 | 78 (20) | 3 | 75 | 72 | 55% | 3.0 | 53 (9) | 159 (7) | 16 (4) | 95 (16) | 0 (4) |
| Mine | Character | 98 | 51 (98) | 51 | 0 | 28 | 21% | 2.4 | 51 (35) | 69 (33) | 42 (15) | 60 (53) | 50 (30) |
| Mine | Clean-up | 12 | 39 (12) | 0 | 39 | 28 | 42% | 2.9 | 16 (9) | 94 (3) | - | 32 (9) | 75 (3) |
| Mine | Fast | 1 | 233 (1) | 233 | 0 | 100 | 0% | 2.0 | - | 233 (1) | - | 233 (1) | - |
| Mine | Fast Hammer | 36 | 43 (36) | 34 | 9 | 39 | 39% | 2.3 | 30 (19) | 17 (8) | 90 (9) | 12 (23) | 111 (13) |
| Mine | Hammer | 43 | 26 (43) | 12 | 14 | 28 | 21% | 2.4 | 10 (15) | 38 (21) | 30 (7) | 24 (29) | 30 (14) |
| Mine | Holder | 18 | 68 (18) | 0 | 68 | 21 | 50% | 4.4 | 33 (9) | 92 (8) | 143 (1) | 74 (11) | 57 (7) |
| Mine | Shooter | 34 | 70 (34) | 31 | 38 | 37 | 3% | 1.4 | 71 (9) | 92 (19) | 3 (6) | 76 (25) | 54 (9) |
| Mine | Support | 3 | 214 (3) | 214 | 0 | 0 | 0% | 1.0 | - | 347 (1) | 147 (2) | 214 (3) | - |
| Mine | War machine | 50 | 48 (50) | 48 | 0 | 40 | 2% | 1.2 | 61 (23) | 38 (26) | 0 (1) | 58 (14) | 43 (36) |
| Mine | Wizard | 12 | 0 (12) | 0 | 0 | 42 | 33% | 2.9 | 0 (4) | 0 (2) | 0 (3) | 0 (6) | 0 (3) |
| Opponent | Chaff | 49 | 68 (49) | 3 | 65 | 59 | 51% | 2.8 | 71 (20) | 81 (21) | 14 (8) | 70 (36) | 59 (13) |
| Opponent | Character | 80 | 42 (80) | 42 | 0 | 29 | 31% | 2.3 | 66 (23) | 24 (38) | 65 (13) | 33 (42) | 60 (32) |
| Opponent | Clean-up | 13 | 45 (13) | 6 | 38 | 33 | 38% | 3.0 | 10 (6) | 152 (3) | 17 (4) | 59 (10) | 0 (3) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 39 | 33 (39) | 21 | 12 | 47 | 46% | 3.0 | 10 (11) | 49 (22) | 16 (6) | 20 (20) | 49 (19) |
| Opponent | Hammer | 38 | 33 (38) | 21 | 12 | 45 | 32% | 2.9 | 12 (9) | 36 (24) | 41 (5) | 35 (24) | 29 (14) |
| Opponent | Holder | 36 | 65 (36) | 13 | 53 | 29 | 39% | 2.8 | 32 (14) | 139 (13) | 20 (9) | 69 (28) | 46 (8) |
| Opponent | Shooter | 19 | 55 (19) | 36 | 19 | 41 | 0% | 1.7 | 87 (8) | 35 (9) | 0 (2) | 71 (15) | 0 (4) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 50% | 4.5 | 0 (1) | 0 (2) | 0 (1) | 0 (1) | 0 (3) |
| Opponent | War machine | 17 | 39 (17) | 39 | 0 | 29 | 0% | 1.2 | 12 (10) | 51 (6) | 225 (1) | 0 (3) | 43 (14) |
| Opponent | Wizard | 24 | 1 (24) | 1 | 0 | 63 | 21% | 2.0 | 4 (6) | 0 (9) | 0 (2) | 4 (9) | 0 (8) |

### Charged fights: t10-opp-ba3e30a-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 40 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Chaos Dwarfs | 4 | 222 | 125 | 2.2 | 1.2 | 55 | 0 | +55 | 3 of 9 | 8 of 9 | +146 | +30 |
| Mine | Dwarfen Mountain Holds | 3 | 278 | 0 | 0.3 | 1.0 | 0 | 105 | -105 | 0 of 1 | 0 of 1 | - | -105 |
| Mine | Empire of Man | 5 | 429 | 42 | 1.4 | 1.1 | 30 | 0 | +30 | 2 of 7 | 6 of 7 | +0 | +35 |
| Mine | Grand Cathay | 5 | 568 | 564 | 3.0 | 1.2 | 188 | 21 | +167 | 7 of 15 | 10 of 15 | +189 | +162 |
| Mine | High Elf Realms | 4 | 228 | 738 | 4.0 | 1.4 | 184 | 102 | +82 | 6 of 16 | 15 of 16 | +128 | +55 |
| Mine | Lizardmen | 1 | 116 | 260 | 5.0 | 1.0 | 52 | 0 | +52 | 1 of 5 | 4 of 5 | - | +52 |
| Mine | Ogre Kingdoms | 1 | 365 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 170 | 4.0 | 1.0 | 42 | 0 | +42 | 3 of 4 | 3 of 4 | - | +42 |
| **Mine** | all armies | 28 | 295 | 247 | 2.1 | 1.2 | 117 | 35 | +82 | 22 of 59 | 47 of 59 | +135 | +69 |
| Opponent | Empire of Man | 1 | 569 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 227 | 554 | 4.3 | 1.1 | 128 | 13 | +115 | 7 of 13 | 10 of 13 | +822 | +56 |
| Opponent | High Elf Realms | 3 | 97 | 426 | 2.7 | 1.1 | 160 | 78 | +81 | 5 of 8 | 4 of 8 | +776 | -18 |
| Opponent | Kingdom of Bretonnia | 2 | 32 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 259 | 3.0 | 1.0 | 86 | 0 | +86 | 0 of 3 | 2 of 3 | - | +86 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 3 | 117 | 560 | 3.0 | 1.0 | 187 | 22 | +165 | 4 of 9 | 6 of 9 | - | +165 |
| Opponent | Vampire Counts | 5 | 0 | 107 | 2.8 | 1.1 | 38 | 111 | -73 | 4 of 14 | 7 of 14 | -191 | -54 |
| Opponent | Warriors of Chaos | 7 | 10 | 386 | 2.4 | 1.1 | 159 | 49 | +110 | 8 of 17 | 14 of 17 | +747 | +25 |
| Opponent | Wood Elf Realms | 2 | 62 | 255 | 1.5 | 1.0 | 170 | 0 | +170 | 1 of 3 | 3 of 3 | - | +170 |
| **Opponent** | all armies | 28 | 77 | 308 | 2.4 | 1.1 | 127 | 50 | +77 | 29 of 68 | 46 of 68 | +452 | +41 |

### Effective charges: t10-opp-ba3e30a-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 9 | 1 (net +0) | 0 | 2 (net +0) | 1 (net +0) | 3 (net +107) | 0 | 2 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 1 | 1 (net -105) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 7 | 1 (net +0) | 1 (net +0) | 0 | 3 (net +0) | 0 | 2 (net +106) | 0 | 0% (0 of 7) |
| Mine | Grand Cathay | 15 | 2 (net +221) | 1 (net +170) | 4 (net +305) | 4 (net +166) | 0 | 3 (net +5) | 1 | 29% (4 of 14) |
| Mine | High Elf Realms | 16 | 0 | 0 | 2 (net -141) | 2 (net +540) | 5 (net +49) | 4 (net +76) | 3 | 15% (2 of 13) |
| Mine | Lizardmen | 5 | 2 (net +72) | 0 | 0 | 2 (net +0) | 0 | 0 | 1 | 0% (0 of 4) |
| Opponent | Grand Cathay | 13 | 3 (net +155) | 0 | 2 (net +42) | 3 (net -8) | 2 (net +74) | 3 (net +274) | 0 | 15% (2 of 13) |
| Opponent | High Elf Realms | 8 | 1 (net -347) | 0 | 1 (net -280) | 1 (net +0) | 0 | 5 (net +255) | 0 | 12% (1 of 8) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 1 (net +199) | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 9 | 3 (net +186) | 0 | 2 (net +82) | 1 (net +558) | 0 | 3 (net +68) | 0 | 22% (2 of 9) |
| Opponent | Vampire Counts | 14 | 5 (net -155) | 1 (net -447) | 1 (net +52) | 1 (net +0) | 2 (net +71) | 2 (net +85) | 2 | 8% (1 of 12) |
| Opponent | Warriors of Chaos | 17 | 2 (net +672) | 0 | 1 (net +0) | 3 (net -101) | 1 (net +422) | 9 (net +70) | 1 | 6% (1 of 16) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 2 (net +255) | 0 | 1 (net +0) | 0 | 0 | 67% (2 of 3) |

### Charged fights, damage counted: t10-opp-ba3e30a-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 193 | 252 | +69 | 93 | 38 | +55 | +28.6 |
| Mine | 50-54% | 2 | 488 | 119 | +85 | 96 | 54 | +42 | +8.6 |
| Mine | Effective (55-75%) | 8 | 406 | 311 | +117 | 235 | 101 | +134 | +33.1 |
| Mine | 76-89% | 12 | 364 | 197 | +145 | 216 | 56 | +160 | +44.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 | 305 | 205 | +59 | 98 | 43 | +54 | +17.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 524 | 83 | +71 | 76 | 0 | +76 | +14.5 |
| Mine | No odds | 13 | 273 | 165 | +33 | 87 | 47 | +40 | +14.7 |
| Mine | All fights | 59 | 346 | 195 | +82 | 134 | 48 | +86 | +24.9 |
| Opponent | Long shot (under 50%) | 14 | 255 | 281 | +89 | 215 | 137 | +78 | +30.7 |
| Opponent | 50-54% | 1 | 397 | 836 | -447 | 16 | 447 | -431 | -108.6 |
| Opponent | Effective (55-75%) | 9 | 266 | 228 | +59 | 90 | 57 | +33 | +12.3 |
| Opponent | 76-89% | 10 | 213 | 150 | +43 | 141 | 111 | +30 | +14.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 356 | 207 | +141 | 169 | 36 | +134 | +37.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 457 | 88 | +119 | 135 | 0 | +135 | +29.6 |
| Opponent | No odds | 6 | 222 | 132 | -57 | 28 | 92 | -64 | -28.8 |
| Opponent | All fights | 68 | 300 | 209 | +77 | 146 | 78 | +68 | +22.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t10-opp-ba3e30a-p3 | move | 249 | 50 (20%) | 39 (16%) | 33 (13%) | 166 (67%) |
| t10-opp-ba3e30a-p3 | objective | 146 | 25 (17%) | 17 (12%) | 21 (14%) | 100 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

import sys, glob, re, os, collections, statistics as st
R=sys.argv[1]; tot=collections.Counter(); n=collections.Counter(); games=0; per=collections.defaultdict(list)
def cat(s):
    l=s.lower()
    if 'herdstone' in l: return 'Herdstone (end)'
    if 'special feature' in l or 'special features' in l: return 'Special feature (end)'
    if 'baggage' in l: return 'Baggage destroyed' if 'destroy' in l else 'Baggage held (end)'
    if 'domination' in l: return 'Quarters (end)'
    if 'strategic location' in l: return 'Markers'
    if 'hill' in l and 'king' in l or l.startswith('the hill'): return 'Hill'
    if re.search(r'destroyed|fleeing|below|slain|general|standard|captured|% of its points|off the table', l): return 'Kills'
    return 'Other: '+s[:40]
for f in glob.glob(os.path.join(R,'*/*/game-*.txt')):
    arm=os.path.relpath(f,R).split('/')[0]; new='Mine' if arm.startswith('mine') else 'Opponent'
    L=open(f).read().split('\n')[:12]
    if not any('result:' in x for x in L): continue
    games+=1; g=collections.Counter()
    for x in L:
        m=re.match(r'\s+(Mine|Opponent): [\d,]+ VP = (.*)',x)
        if not m: continue
        k='new' if m.group(1)==new else 'old'
        for it in m.group(2).split('; '):
            mm=re.match(r'(.*) ([\d,]+)$',it)
            if not mm: continue
            c=cat(mm.group(1)); v=int(mm.group(2).replace(',','')); tot[(c,k)]+=v; n[(c,k)]+=1; g[c]+= v if k=='new' else -v
    for c in g: per[c].append(g[c])
print('games',games)
cats=sorted({c for c,_ in tot})
for c in cats:
    d=per[c]+[0]*(games-len(per[c])); se=st.pstdev(d)/len(d)**.5
    print(f"{c:28} new {tot[(c,'new')]/games:7.1f} ({n[(c,'new')]:4})  old {tot[(c,'old')]/games:7.1f} ({n[(c,'old')]:4})  diff {(tot[(c,'new')]-tot[(c,'old')])/games:+7.1f} ±{1.96*se:.0f}")

import sys, glob, json, re, os, collections
R=sys.argv[1]; rx=re.compile(r'HOLDER ASSIGNMENT: (.+?) goes to (.+?) \((holds it this turn|walks on to it): gives up ~([\d.]+) VP of its other options for the ~([\d.]+) VP')
agg=collections.defaultdict(lambda: collections.Counter()); seen=set()
def kind(s):
    l=s.lower()
    return 'Herdstone' if 'herdstone' in l else 'Special feature' if 'feature' in l else 'Baggage' if 'baggage' in l else 'Hill' if 'hill' in l else 'Marker'
for f in glob.glob(os.path.join(R,'*/*/game-*.log.jsonl')):
    for l in open(f):
        if 'HOLDER ASSIGNMENT' not in l or ' goes to ' not in l: continue
        d=json.loads(l)
        for m in rx.finditer(d.get('summary') or ''):
            key=(f,d.get('turn'),m.group(1))
            if key in seen: continue
            seen.add(key); k=kind(m.group(1)); late='r5+' if (d.get('turn') or 0)>=5 else 'r1-4'
            a=agg[(k,late)]; a['n']+=1; a['walk']+= m.group(3).startswith('walks'); a['gu']+=float(m.group(4)); a['w']+=float(m.group(5))
for k in sorted(agg):
    a=agg[k]; print(f"{k[0]:16}{k[1]:5} n {a['n']:5}  walks on {a['walk']/a['n']:4.0%}  mean worth {a['w']/a['n']:6.1f}  mean gives up {a['gu']/a['n']:6.1f}")

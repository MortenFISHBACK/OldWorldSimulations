import sys, glob, json, re, os, collections
R=sys.argv[1]
rx=re.compile(r'HOLDER ASSIGNMENT: (.+?) goes to (.+?) \((holds it this turn|walks on to it): gives up ~([\d.]+) VP of its other options for the ~([\d.]+) VP')
c=collections.Counter(); took=collections.Counter(); n=0
def kind(s):
    l=s.lower(); return 'Herdstone/feature' if 'herdstone' in l or 'feature' in l else 'baggage' if 'baggage' in l else 'hill' if 'hill' in l else 'marker'
for f in glob.glob(os.path.join(R,'*/*/game-*.log.jsonl')):
    arm=os.path.relpath(f,R).split('/')[0]; new='Mine' if arm.startswith('mine') else 'Opponent'
    tab={}; rows=collections.defaultdict(list); turns=set(); score=collections.defaultdict(set)
    for l in open(f):
        if l.startswith('{"kind":"objective"'):
            d=json.loads(l)
            if d.get('side')==new: score[(d['turn'],d['turn_side']==new)].add((d.get('unit'),d['objective'],d['index']))
            continue
        if '"side":"%s"'%new not in l or 'HOLDER ASSIGNMENT' not in l: continue
        d=json.loads(l); s=d.get('summary') or ''; turns.add(d['turn'])
        for m in rx.finditer(s): tab.setdefault((d['turn'],m.group(1)),(m.group(2),m.group(3)[0],float(m.group(5))))
        if d.get('type')!='Computer' or True:
            m=re.search(r'HOLDER ASSIGNMENT: [^:]*VP: (.+?): (the assigned holder takes it|taken by its own pick|its holder took another job[^|]*)',s)
            if m: rows[(d['turn'],m.group(1))].append((d.get('actor'),m.group(2)[:40]))
    for (t,spot),(unit,how,w) in tab.items():
        if how!='w' or 'Marker' not in spot or w<40: continue
        n+=1
        r=rows.get((t,spot),[])
        tk='walker took the walk' if any(a==unit and x.startswith('the assigned') for a,x in r) else 'another unit took it by its own pick' if any(x.startswith('taken by') for a,x in r) else 'walker took another job (passed on / nobody)' if any(x.startswith('its holder') for a,x in r) else 'no row (pick did not claim it)'
        took[tk]+=1
        if (t+1) not in turns: c[(tk,'no next turn')]+=1; continue
        mine=[(s2,v) for (t2,s2),v in tab.items() if t2==t+1 and v[0]==unit]
        if any(u==unit for u,_,_ in score.get((t+1,True),())): k='scored a marker/hill next own turn'
        elif mine:
            s2,v=mine[0]; k=('same marker' if s2==spot else 'other '+kind(s2))+(' holds' if v[1]=='h' else ' walks')
        else: k='walker has no assignment next turn'
        c[(tk,k)]+=1
print('next-turn marker walk-ons',n); 
for k,v in took.most_common(): print(v,k)
print()
for k,v in sorted(c.items(), key=lambda x:-x[1]): print(v,k)

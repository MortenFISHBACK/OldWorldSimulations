import sys,glob,json,os,re,collections
R=sys.argv[1]; c=collections.Counter(); shown=0
for f in sorted(glob.glob(os.path.join(R,'*/*/game-*.log.jsonl'))):
    acts=[json.loads(l) for l in open(f)]
    by=collections.defaultdict(list)
    for d in acts:
        if d.get('type')=='Computer' and d.get('phase')=='Strategy' and d.get('summary','').startswith('HOLDER ASSIGNMENT'): by[(d['turn'],d['side'])].append(d['summary'])
    for k,ls in by.items():
        assigned={}
        for s in ls:
            m=re.match(r'HOLDER ASSIGNMENT: (.+?) goes to (.+?) \((holds|walks)',s)
            if m: assigned[m.group(2)]=m.group(1)
        for s in ls:
            if 'stays empty' not in s: continue
            m2=re.search(r"holding it \((.+?) would give up ~([-\d.]+) VP of its other options for the ~([-\d.]+) VP",s)
            if not m2: continue
            gain=float(m2.group(3))-float(m2.group(2))
            if gain<=0.05: c['empty, least unit gains nothing']+=1; continue
            if m2.group(1) in assigned: c['empty, its least unit holds another']+=1
            else:
                c['empty, its least unit holds NOTHING']+=1
                if shown<6: shown+=1; print(f.split('/h2h/')[1],k); [print('   ',x[:330]) for x in ls]
print(c)

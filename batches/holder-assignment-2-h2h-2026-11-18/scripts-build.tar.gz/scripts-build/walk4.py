import sys, glob, json, re, os, collections
R=sys.argv[1]
rx=re.compile(r'HOLDER ASSIGNMENT: (.+?) goes to (.+?) \((holds it this turn|walks on to it): gives up ~([\d.]+) VP of its other options for the ~([\d.]+) VP')
rxe=re.compile(r'HOLDER ASSIGNMENT: (.+?) stays empty this turn - ([^"\\]*)')
c=collections.Counter(); ex=[]; rounds=collections.Counter()
for f in glob.glob(os.path.join(R,'*/*/game-*.log.jsonl')):
    arm=os.path.relpath(f,R).split('/')[0]; new='Mine' if arm.startswith('mine') else 'Opponent'
    tab={}; emp={}; turns=set(); acts=collections.defaultdict(list)
    for l in open(f):
        if '"side":"%s"'%new not in l: continue
        d=None
        if 'HOLDER ASSIGNMENT' in l:
            d=json.loads(l); s=d.get('summary') or ''; turns.add(d['turn'])
            for m in rx.finditer(s): tab.setdefault((d['turn'],m.group(1)),(m.group(2),m.group(3)[0],float(m.group(5))))
            for m in rxe.finditer(s): emp.setdefault((d['turn'],m.group(1)),m.group(2)[:200])
        if '"type":"Computer"' in l or 'charge' in l.lower():
            d=d or json.loads(l)
            if d.get('actor'): acts[(d['turn'],d['actor'])].append((d.get('phase'),(d.get('summary') or '')[:160]))
    for (t,spot),(unit,how,w) in tab.items():
        if how!='w' or 'Marker' not in spot or w<40: continue
        rounds[t]+=1
        if (t+1) not in turns: continue
        if any(v[0]==unit for (t2,s2),v in tab.items() if t2==t+1): continue
        nx=tab.get((t+1,spot)); e=emp.get((t+1,spot))
        k='marker next turn: '+('another unit '+('holds' if nx[1]=='h' else 'walks') if nx else 'empty, no unit gains' if e and e.startswith('no unit') else 'empty, its unit holds another' if e else 'no line at all')
        c[k]+=1
        if len(ex)<5: ex.append((os.path.basename(f),t,spot,unit,e,acts.get((t+1,unit),[])[:3]))
print(dict(sorted(rounds.items())))
for k,v in c.most_common(): print(v,k)
for x in ex: print(x)

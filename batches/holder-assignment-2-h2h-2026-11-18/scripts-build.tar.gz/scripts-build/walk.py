import sys, glob, json, re, os, collections
R=sys.argv[1]
rx=re.compile(r'HOLDER ASSIGNMENT: (.+?) goes to (.+?) \((holds it this turn|walks on to it): gives up ~([\d.]+) VP of its other options for the ~([\d.]+) VP')
rxe=re.compile(r'HOLDER ASSIGNMENT: (.+?) stays empty')
out=collections.Counter(); byw=collections.defaultdict(collections.Counter); n=0
for f in glob.glob(os.path.join(R,'*/*/game-*.log.jsonl')):
    arm=os.path.relpath(f,R).split('/')[0]; new='Mine' if arm.startswith('mine') else 'Opponent'
    tab={}; score=collections.defaultdict(set); fate={}
    for l in open(f):
        if l.startswith('{"kind":"objective"'):
            d=json.loads(l)
            if d.get('side')==new and d['turn_side']==new: score[d['turn']].add(d.get('unit'))
            continue
        if 'HOLDER ASSIGNMENT' not in l: continue
        d=json.loads(l)
        if d.get('side')!=new: continue
        s=d.get('summary') or ''
        for m in rx.finditer(s): tab.setdefault((d['turn'],m.group(1)),(m.group(2),m.group(3)[0],float(m.group(5))))
        for m in rxe.finditer(s): tab.setdefault((d['turn'],m.group(1)),(None,'e',0))
    for (t,spot),(unit,how,w) in tab.items():
        if how!='w' or 'Marker' not in spot: continue
        n+=1; band='next turn (~45)' if w>=40 else '2 more turns (~22)' if w>=20 else '3+ turns'
        nx=tab.get((t+1,spot))
        if unit in score.get(t+1,()): r='scored next round (by it)'   # may be other marker; rough
        elif nx is None: r='no table line next turn (game over / unit gone / nobody able)'
        elif nx[0]==unit and nx[1]=='h': r='same unit, now "holds it" but did not score'
        elif nx[0]==unit: r='same unit still walking'
        elif nx[0] is None: r='next turn: stays empty'
        else: r='next turn: given to another unit ('+('holds' if nx[1]=='h' else 'walks')+')'
        out[r]+=1; byw[band][r]+=1
print('marker walk-ons',n)
for b in byw:
    tot=sum(byw[b].values()); print(b,tot)
    for r,c in byw[b].most_common(): print(f"   {c:4} {c/tot:4.0%} {r}")

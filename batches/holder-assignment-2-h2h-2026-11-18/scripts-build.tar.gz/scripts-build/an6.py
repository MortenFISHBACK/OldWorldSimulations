import sys,glob,json,os,re,collections,math
R=sys.argv[1]; c=collections.Counter(); ex=collections.defaultdict(list)
def pp(p,poly):
    best=1e9; n=len(poly); inside=False
    for i in range(n):
        a=poly[i]; b=poly[(i+1)%n]
        if (a[1]>p[1])!=(b[1]>p[1]) and p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1]+1e-12)+a[0]: inside=not inside
        dx,dy=b[0]-a[0],b[1]-a[1]; L=dx*dx+dy*dy
        t=0 if L<1e-12 else max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/L))
        best=min(best,math.dist(p,(a[0]+t*dx,a[1]+t*dy)))
    return 0 if inside else best
US={'Cavalry':2,'Monstrous Infantry':3,'Monstrous Cavalry':3,'Chariot':3,'Monster':5,'War Machines':3}
for f in sorted(glob.glob(os.path.join(R,'*/*/game-*.log.jsonl'))):
    recs=[json.loads(l) for l in open(f)]; b=recs[0]
    info={u['id']:u for u in b['units']}; idof={(u['s'],u['n']):u['id'] for u in b['units']}
    mk={int(m['l'])-1:(m['x'],m['y']) for m in b.get('markers',[]) if str(m.get('l','')).isdigit()}
    higher=[(t['l'],t['p']) for t in b['terrain'] if t['f'].get('bag') is not None or t['f'].get('sf')]
    acts=[d for d in recs if d['kind']=='action']
    obj=collections.defaultdict(list)
    for d in recs:
        if d['kind']=='objective': obj[(d['turn'],d['turn_side'])].append(d)
    lines={}
    for d in acts:
        if d['type']=='Computer' and d['phase']=='Strategy' and d['summary'].startswith('HOLDER ASSIGNMENT'):
            m=re.match(r'HOLDER ASSIGNMENT: (.+?) goes to (.+?) \((holds it this turn|walks on to it)',d['summary'])
            if m: lines[(d['turn'],d['side'],m.group(2),m.group(1))]=m.group(3)
    claims=[d for d in acts if d['type']=='OpponentRule' and d['phase']=='Strategy' and 'assigned holder takes it' in d['summary'] and re.match(r'Marker (\d+)',d['target'] or '')
            and lines.get((d['turn'],d['side'],d['actor'],d['target']))=='holds it this turn']
    if not claims: continue
    # positions at the end of each player turn: replay frames up to the first action of the next player turn
    order=[]; seen=set()
    for a in acts:
        k=(a['turn'],a['side'])
        if a['phase'] in('Movement','Shooting','Combat') and a['type'] in('March','RemainingMove','Shooting','CombatAttack','Charge','Candidates') and k not in seen: seen.add(k); order.append((k,a['id']))
    startid=dict(order)
    def endid(turn,side):
        later=[i for (k,i) in order if i>startid.get((turn,side),10**9)]
        return min(later) if later else 10**9
    frames=[d for d in recs if d['kind']=='frame']
    for d in claims:
        idx=int(re.match(r'Marker (\d+)',d['target']).group(1))-1
        rows=obj.get((d['turn'],d['side']),[])
        row=next((r for r in rows if r['objective']=='StrategicLocation' and r['index']==idx),None)
        c['n']+=1
        if row and row['side']==d['side'] and row['unit']==d['actor']: c['1 scored by the assigned unit']+=1; continue
        if row and row['side']==d['side']: c['2 scored by another unit of ours (nearer one holds)']+=1; continue
        end=endid(d['turn'],d['side']); pos={}
        for fr in frames:
            if fr['after']>=end: break
            for u in fr['units']: pos[u['id']]=u
        def gap(uid,target):
            u=pos.get(uid)
            if not u or not u.get('on') or not u.get('m'): return None
            h=min(u.get('bw') or 1,u.get('bd') or 1)/2
            if isinstance(target,tuple): return max(0,min(math.dist(m,target) for m in u['m'])-h-0.79)
            return max(0,min(pp(m,target) for m in u['m'])-h)
        uid=idof.get((d['side'],d['actor'])); g=gap(uid,mk[idx]) if idx in mk else None
        u=pos.get(uid)
        if u is None or not u.get('on') or not u.get('m'): why='3 destroyed or off the table by the end of its turn'
        elif u.get('fl'): why='4 fleeing at the end of its turn'
        elif len(u['m'])*US.get(info[uid]['lk']['tt'],1)<10: why='5 under Unit Strength 10 by the end of its turn'
        elif g>6.8: why='6 ended its turn out of range'
        else:
            hi=[l for l,p in higher if (gap(uid,p) or 99)<=6.0]
            en=[i for i in pos if info[i]['s']!=d['side'] and (gap(i,mk[idx]) is not None) and gap(i,mk[idx])<=6.0 and gap(i,mk[idx])<=g+0.01 and len(pos[i]['m'])*US.get(info[i]['lk']['tt'],1)>=10]
            if row and row['side']!=d['side']: why='7 in range, the enemy holds it (nearer or stronger)'
            elif hi: why='8 in range, but within 6" of a baggage train or special feature: the game gives it that one object instead'
            elif en: why='7b in range, an enemy unit as near: contested'
            else: why='9 in range, nobody scored (unexplained)'
        if why.startswith('6'):
            own=[a for a in acts if a['turn']==d['turn'] and a['side']==d['side'] and a['id']>d['id']]
            mine=[a for a in own if a.get('actor')==d['actor']]
            plan=None
            for a in mine:
                if a['phase']=='Movement' and a['type']=='OpponentRule':
                    m=re.search(r'move to \(([\d.]+), ([\d.]+)\)',a['summary'])
                    if m: plan=(float(m.group(1)),float(m.group(2))); break
            mv=[a for a in mine if a['type'] in('March','RemainingMove') and a['to'][0] is not None]
            split=[a for a in mine if a['type']=='JobSplit' and a['summary'].startswith('MOVE SPLIT')]
            counted=bool(split and re.search(r'now \+',split[0]['summary']))
            spell=[a for a in own if a['type'] in('SpellCast','SpellEffect') and d['actor'] in (a.get('summary') or '') and re.search(r'Pathway|Steed of Shadows|Walk Between',a['summary'])]
            if any(a['type']=='Charge' for a in mine): why='6a out of range: it charged'
            elif any(a['type']=='ReserveMove' for a in mine): why='6b out of range: its Reserve Move after shooting took it off the marker'
            elif spell: why='6c out of range: moved away by its own army\'s movement spell'
            elif plan and mv and math.dist(plan,(mv[-1]['to'][0],mv[-1]['to'][1]))>2: why='6d out of range: the move stopped 2\"+ short of the spot it chose'
            elif counted: why='6e out of range at the spot it chose and reached, though the sum counted the marker there'
            else: why='6f out of range: the move phase chose a spot that does not hold it (or stayed)'
        c[why]+=1; ex[why].append((f.split('/h2h/')[1],d['turn'],d['side'],d['actor'],d['target'],None if g is None else round(g,1)))
for k in sorted(c): print(k,c[k])
json.dump(ex,open(os.path.dirname(R)+'/miss3.json','w'))
for k in sorted(ex): print(k); [print('   ',x) for x in ex[k][:6]]

import sys,glob,json,os,re,collections
R=sys.argv[1]; c=collections.Counter(); ex=[]; ties=[]
def norm(s): return re.sub(r'[^a-z]','',s.lower())
for part in sorted(glob.glob(os.path.join(R,'*/*/'))):
    pts=collections.defaultdict(list)
    up=os.path.join(part,'units.jsonl')
    if not os.path.exists(up): continue
    for l in open(up):
        u=json.loads(l); pts[(norm(u['army']),u['unit'],u['models'])].append(u['points'])
    for f in sorted(glob.glob(part+'game-*.log.jsonl')):
        acts=[json.loads(l) for l in open(f)]; b=acts[0]
        army={'Mine':norm(b['mine']),'Opponent':norm(b['opponent'])}
        P={}
        for u in b['units']:
            v=pts.get((army[u['s']],u['lk']['cn'],u['lk']['mc']))
            if v: P[(u['s'],u['n'])]=min(v)
        by=collections.defaultdict(list)
        for d in acts:
            if d.get('type')=='Computer' and d.get('phase')=='Strategy' and d.get('summary','').startswith('HOLDER ASSIGNMENT'): by[(d['turn'],d['side'])].append(d['summary'])
        for (turn,side),ls in by.items():
            asg={}
            for s in ls:
                mm=re.match(r'HOLDER ASSIGNMENT: (.+?) goes to (.+?) \((holds it this turn|walks on to it)',s)
                if mm: asg[mm.group(2)]=mm.group(1)
            for s in ls:
                m=re.match(r'HOLDER ASSIGNMENT: (.+?) goes to (.+?) \((holds it this turn|walks on to it): gives up ~([-\d.]+) VP of its other options for the ~([-\d.]+) VP it is worth there(?:; (.*))?\)$',s)
                if not m: continue
                spot,unit,how,gu,worth,rest=m.groups()
                kind='marker' if spot.startswith('Marker') else 'hill' if 'hill' in spot.lower() else 'other'
                others=re.findall(r'(?:^|, )(.+?) would give up ~([-\d.]+)',rest or '')
                p0=P.get((side,unit))
                po=[(P.get((side,n)),float(g),n) for n,g in others]
                if p0 is None or any(p is None for p,_,_ in po): c[kind,'points unknown']+=1; continue
                c[kind,'n']+=1; c[kind,'pts sum']+=p0
                if not po: c[kind,'only one able row']+=1; continue
                cheaper=[x for x in po if x[0]<p0]
                if not cheaper: c[kind,'assigned is the cheapest listed']+=1
                else:
                    c[kind,'a cheaper unit was listed']+=1
                    best=min(cheaper,key=lambda x:x[1])
                    free=[x for x in cheaper if x[2] not in asg]
                    c[kind,'  every cheaper unit listed holds another objective']+= not free
                    if free:
                        fb=min(free,key=lambda x:x[1]); dd=fb[1]-float(gu)
                        c[kind,'  a cheaper unit was FREE: gives up '+('the same (tie)' if dd<=0.05 else 'up to 10 more' if dd<=10 else 'over 10 more')]+=1
                        if dd<=0.05: ties.append((kind,p0,fb[0],unit,fb[2],spot,turn,how,os.path.basename(f)))
                    c[kind,'  cheaper unit gives up >10 VP more']+= best[1]-float(gu)>10
                    c[kind,'  cheaper unit gives up within 10 VP']+= best[1]-float(gu)<=10
                    if len(ex)<400: ex.append((kind,round(best[1]-float(gu),1),p0,best[0],unit,best[2],spot,turn,os.path.basename(f)))
for k in sorted(c): print(k,c[k])
print('TIES',len(ties)); [print(t) for t in ties[:12]]
import random; random.seed(1)
for e in sorted(random.sample(ex,min(14,len(ex)))): print(e)

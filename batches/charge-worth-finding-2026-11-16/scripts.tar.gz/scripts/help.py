import json,glob,os,re,collections,math
D='/root/data/charge-band-h2h-2026-11-15'
OBJ=re.compile(r'^Objective for (.+?): (charge|close in to charge|advance on|shoot|hold or contest|support|join|stay|flee|rally)?(.*)$')
CH=re.compile(r'^charge #(\d+) ')
W=re.compile(r'win first round (\d+)%')
rows=[]
for f in sorted(glob.glob(D+'/*/game-*.log.jsonl')):
    arm=os.path.basename(os.path.dirname(f)).split('-')[0]; fixside='Mine' if arm=='mine' else 'Opponent'
    pos={}; board=None; acts=[]; frames=[]
    for l in open(f):
        try:d=json.loads(l)
        except ValueError: continue
        k=d.get('kind')
        if k=='board': board=d
        elif k=='action': acts.append(d)
        elif k=='frame': frames.append(d)
    U={u['id']:u for u in board['units']}; byname={u['n']:u for u in board['units']}
    names=sorted(byname,key=len,reverse=True)
    fi=0
    # group the objectives per (turn, side)
    cur=None; groups=[]
    for a in acts:
        while fi<len(frames) and frames[fi]['after']<=a['id']:
            for u in frames[fi]['units']: pos[u['id']]=(u['x'],u['y'],u.get('on',1),u.get('fl',0))
            fi+=1
        s=a.get('summary') or ''
        if a.get('phase')=='Strategy' and a.get('type')=='Computer' and s.startswith('Objective for '):
            key=(a['turn'],a['side'])
            if cur is None or cur['key']!=key: cur=dict(key=key,objs=[],pos=dict(pos),asks=[],band=[]); groups.append(cur)
            rest=s[len('Objective for '):]
            for n in names:
                if rest.startswith(n+': '):
                    cur['objs'].append((byname[n]['id'],n,rest[len(n)+2:])); break
        elif cur is not None and a.get('turn')==cur['key'][0] and a.get('side')==cur['key'][1] and a.get('phase')=='Strategy':
            if ' asks ' in s and 'to charge' in s: cur['asks'].append(s)
            if 'CHARGE BAND' in s and a.get('type')=='OpponentRule': cur['band'].append(a.get('target_id'))
    for g in groups:
        t,side=g['key']
        for uid,n,text in g['objs']:
            m=CH.match(text); w=W.search(text)
            if not m or not w: continue
            tid=int(m.group(1)); win=int(w.group(1))
            tp=g['pos'].get(tid)
            others=[]
            for oid,on,otext in g['objs']:
                if oid==uid: continue
                p=g['pos'].get(oid)
                if not p or not tp: continue
                d=math.hypot(p[0]-tp[0],p[1]-tp[1])
                lk=U[oid]['lk']
                others.append((round(d,1),on,lk.get('tt'),otext.split(': its ')[0][:60], bool(CH.match(otext)) and int(CH.match(otext).group(1))==tid))
            others.sort()
            rows.append(dict(arm=arm,g=os.path.basename(f),turn=t,side=side,fix=side==fixside,unit=n,target=tid,win=win,text=text[:400],
                asked=any(n+' asks ' in s for s in g['asks']) , band=tid in g['band'] or 'CHARGE BAND' in text, others=others[:6],
                partner='asked by' in text or 'with #' in text))
json.dump(rows,open('out/help.json','w'))
print(len(rows))

import json,glob,os,re,collections,sys
D='/root/data/charge-band-h2h-2026-11-15'
def load(f):
    acts=[];board=None
    for l in open(f):
        try:d=json.loads(l)
        except ValueError: continue
        if d.get('kind')=='action': acts.append(d)
        elif d.get('kind')=='board' and board is None: board=d
    return acts,board
ID=re.compile(r'#\d+ ')
def phys(a):
    return a.get('type') not in ('Computer','OpponentRule','SpellHeldBack','SpellNotCast','MissileNotTried','ShotNotTaken','ArmyStance')
def sig(a):
    return (a.get('turn'),a.get('phase'),a.get('side'),a.get('type'),a.get('actor'),a.get('target'),a.get('dice'),tuple(round(x,1) if isinstance(x,(int,float)) else x for x in (a.get('to') or [])))
def objs(acts,turn,side,names):
    out={}
    for a in acts:
        if a.get('turn')==turn and a.get('side')==side and a.get('phase')=='Strategy' and a.get('type')=='Computer':
            s=a.get('summary') or ''
            if s.startswith('Objective for '):
                rest=s[len('Objective for '):]
                for n in sorted(names,key=len,reverse=True):
                    if rest.startswith(n+': '):
                        out[n]=ID.sub('',rest[len(n)+2:]); break
    return out
files={}
for f in glob.glob(D+'/*/game-*.log.jsonl'):
    arm=os.path.basename(os.path.dirname(f)).split('-')[0]; g=os.path.basename(f)
    files.setdefault(g,{})[arm]=f
res=[]
for g,v in sorted(files.items()):
    if len(v)<2: continue
    A,bA=load(v['mine']); B,bB=load(v['opp'])
    names=[u['n'] for u in bA['units']]
    pa=[a for a in A if phys(a)]; pb=[a for a in B if phys(a)]
    i=0
    while i<min(len(pa),len(pb)) and sig(pa[i])==sig(pb[i]): i+=1
    if i>=min(len(pa),len(pb)): res.append(dict(g=g,same=True)); continue
    a,b=pa[i],pb[i]
    # the turn/side whose decisions diverged: the earlier of the two
    t,side,ph=min((a['turn'],a['phase'],a['side']),(b['turn'],b['phase'],b['side']),key=lambda x:x[0])[0],a['side'],a['phase']
    r=dict(g=g,same=False,idx=i,turn=a['turn'],phase=a['phase'],side=a['side'],turnB=b['turn'],phaseB=b['phase'],sideB=b['side'],
           a=(a.get('type'),a.get('actor'),a.get('target'),(a.get('summary') or '')[:200]),b=(b.get('type'),b.get('actor'),b.get('target'),(b.get('summary') or '')[:200]))
    # objectives of the acting side in that turn; in arm mine, Mine=fix; in arm opp, Opponent=fix
    for sd in ('Mine','Opponent'):
        oa=objs(A,a['turn'],sd,names); ob=objs(B,a['turn'],sd,names)
        fixo,offo=(oa,ob) if sd=='Mine' else (ob,oa)
        r['obj_'+sd]={n:(fixo.get(n),offo.get(n)) for n in set(fixo)|set(offo)}
    res.append(r)
json.dump(res,open('out/div.json','w'))
print(len(res),collections.Counter((r.get('turn'),r.get('phase')) for r in res).most_common(30))

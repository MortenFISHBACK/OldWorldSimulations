# Doctrine scorecard: base-s1-882d875-p5

### Scorecard: base-s1-882d875-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0104 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 322 |
| L0104 | 2 | 1 | Opponent | - | - | 2 | 2 | 5 | 0 | 0 | 0 | 309 |
| L0120 | 6 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 2 | 5 | 0 | 5 | 1 | 0 | 0 | 248 |
| L0204 | 6 | 1 | Mine | no | 0 | - | 0 | 6 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Opponent | no | 5 | 2 | 2 | 3 | 0 | 0 | 0 | 139 |
| L0220 | 4 | 1 | Mine | no | 0 | 5 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0220 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 637 |
| L0305 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 0 | 0 | 0 | 110 |
| L0305 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 450 |
| L0321 | 3 | 1 | Mine | yes | 4 | 5 | 1 | 0 | 1 | 0 | 0 | 140 |
| L0321 | 3 | 1 | Opponent | yes | 3 | 5 | 1 | 5 | 0 | 0 | 0 | 500 |
| L0407 | 5 | 1 | Mine | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0407 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 1 | 0 | 0 | 45 |
| L0423 | 3 | 1 | Mine | no | 0 | 4 | 3 | 3 | 0 | 0 | 0 | 310 |
| L0423 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0510 | 6 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 423 |
| L0510 | 6 | 1 | Opponent | no | 7 | 3 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0526 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1016 |
| L0526 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 5 | 1 | 0 | 0 | 0 |
| L0614 | 2 | 1 | Mine | - | - | 6 | 0 | 1 | 0 | 0 | 0 | 879 |
| L0614 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0630 | 6 | 1 | Mine | no | 1 | - | 3 | 0 | 0 | 0 | 0 | 615 |
| L0630 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0719 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 266 |
| L0719 | 5 | 1 | Opponent | yes | - | 5 | 3 | 3 | 0 | 0 | 0 | 60 |
| L0735 | 3 | 1 | Mine | no | 6 | 4 | 2 | 0 | 0 | 0 | 0 | 170 |
| L0735 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 1 | 0 | 0 | 235 |
| L0825 | 3 | 1 | Mine | yes | 5 | 4 | 0 | 0 | 0 | 0 | 0 | 36 |
| L0825 | 3 | 1 | Opponent | no | 0 | 5 | 3 | 4 | 0 | 0 | 0 | 300 |
| L0915 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 541 |
| L0915 | 3 | 1 | Opponent | yes | 10 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0932 | 2 | 1 | Mine | - | - | - | 0 | 0 | 1 | 0 | 0 | 596 |
| L0932 | 2 | 1 | Opponent | - | - | 2 | 1 | 7 | 0 | 0 | 0 | 0 |
| L1024 | 4 | 1 | Mine | no | 5 | 1 | 4 | 1 | 0 | 0 | 0 | 165 |
| L1024 | 4 | 1 | Opponent | no | 2 | - | 2 | 1 | 1 | 0 | 0 | 0 |
| L1116 | 6 | 1 | Mine | no | 18 | 5 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1116 | 6 | 1 | Opponent | no | 2 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L1133 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1133 | 5 | 1 | Opponent | no | - | 2 | 2 | 4 | 0 | 0 | 0 | 144 |
| L1226 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 1 | 0 | 0 | 664 |
| L1226 | 2 | 1 | Opponent | - | - | 1 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1321 | 1 | 1 | Mine | no | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1321 | 1 | 1 | Opponent | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 565 |
| L1416 | 6 | 1 | Mine | no | 0 | 1 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1416 | 6 | 1 | Opponent | no | 13 | 2 | 2 | 0 | 0 | 0 | 0 | 100 |
| L1433 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1433 | 5 | 1 | Opponent | no | - | 5 | 1 | 2 | 0 | 0 | 0 | 641 |
| L1529 | 5 | 1 | Mine | yes | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1529 | 5 | 1 | Opponent | no | - | 6 | 1 | 4 | 2 | 0 | 0 | 292 |
| L1627 | 1 | 1 | Mine | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1627 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1725 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1725 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1825 | 1 | 1 | Mine | no | 2 | - | 2 | 2 | 0 | 0 | 0 | 185 |
| L1825 | 1 | 1 | Opponent | no | 4 | 4 | 1 | 4 | 0 | 0 | 0 | 68 |
| L1925 | 5 | 1 | Mine | no | - | 1 | 4 | 2 | 2 | 0 | 0 | 221 |
| L1925 | 5 | 1 | Opponent | yes | - | 3 | 3 | 5 | 0 | 0 | 0 | 0 |
| L2027 | 5 | 1 | Mine | no | - | 5 | 1 | 3 | 1 | 0 | 0 | 245 |
| L2027 | 5 | 1 | Opponent | yes | - | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| L2129 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 0 | 0 | 0 | 500 |
| L2129 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 170 |
| L2233 | 1 | 1 | Mine | yes | 9 | 1 | 2 | 0 | 2 | 0 | 0 | 369 |
| L2233 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 144 |
| L2426 | 2 | 1 | Mine | - | - | 1 | 1 | 2 | 0 | 0 | 0 | 60 |
| L2426 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2533 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2533 | 1 | 1 | Opponent | no | 3 | 1 | 4 | 3 | 0 | 0 | 0 | 443 |
| L2733 | 3 | 1 | Mine | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 60 |
| L2733 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 3 | 0 | 0 | 0 | 109 |
| L3031 | 1 | 1 | Mine | no | 2 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L3031 | 1 | 1 | Opponent | no | 7 | - | 1 | 0 | 1 | 0 | 0 | 541 |
| **Average** | | | Mine | 37% | 3.3 | 2.9 | 1.8 | 1.7 | 0.3 | 0.0 | 0.0 | 229.5 |
| **Average** | | | Opponent | 20% | 2.9 | 2.8 | 2.2 | 3.0 | 0.3 | 0.0 | 0.0 | 184.9 |

### KPIs: base-s1-882d875-p5

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (51 of 165) | 5% (8 of 157) | 18% (59 of 322) |
| Winner chose to follow up after the loser gave ground |  | 88% (38 of 43); on the table 88% | 92% (34 of 37); on the table 92% | 90% (72 of 80); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 64% (7 of 11); on the table 73% | 76% (16 of 21); on the table 81% |
| Winner chose to pursue after the loser fled |  | 53% (9 of 17); on the table 53% | 48% (11 of 23); on the table 61% | 50% (20 of 40); on the table 58% |
| Winner chose to follow up or pursue (all three) |  | 80% (56 of 70); on the table 80% | 73% (52 of 71); on the table 79% | 77% (108 of 141); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 27% (92 of 336) | 27% (51 of 187) | 27% (143 of 523) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (92 of 232) | 37% (51 of 139) | 39% (143 of 371) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 79% (15 of 19) | 68% (41 of 60) | 71% (56 of 79) |
| Points that never fought | lower | 51% (34997 of 68841) | 51% (35964 of 69984) | 51% (70961 of 138825) |
|   infantry points that never fought | lower | 63% (9844 of 15525) | 63% (9933 of 15672) | 63% (19777 of 31197) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (184 of 275) | 67% (182 of 270) | 67% (366 of 545) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.8 uses a game | 72% (13 of 18); 0.9 uses a game | 84% (32 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 37% (7 of 19); 0.4 uses a game | 12% (1 of 8); 0.0 uses a game | 30% (8 of 27); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 60% (9 of 15); 0.2 uses a game | 57% (20 of 35); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (35448 of 58142) | 60% (37149 of 62076) | 60% (72597 of 120218) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.4 (36%) | 1.4 (37%) | 3.8 (36%) |
| MARCHED: its unit marched | 1.0 (14%) | 0.7 (19%) | 1.7 (16%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (4%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.4 (20%) | 0.5 (13%) | 1.9 (18%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.2 (4%) | 0.4 (4%) |
| GONE: slain | 1.2 (18%) | 0.8 (21%) | 2.1 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.2 | 1.4 | 2.6 | 4.0 | 0.6 | 1.2 |
| not cast | 3.9 | 1.8 | 3.8 | 10.5 | 2.5 | 20.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (48%) | 0.4 (10%) | 3.8 (36%) | 0.7 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (16%) | 0.4 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.2 (9%) | 0.6 (16%) | 1.9 (18%) | 0.4 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.1 (5%) | 0.3 (9%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.1 (28%) | 0.3 (15%) | 0.8 (20%) | 2.1 (20%) | 0.5 (21%) | 2.9 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (8%) | 0.2 (7%) | 0.2 (2%) | 0.1 (3%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.2 (12%) | 0.0 (1%) | 0.1 (1%) | 0.3 (13%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (47%) | 0.1 (3%) | 1.4 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.7 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 0.9 a game | 1.4 a game |
| stood (cast and not dispelled) | 68% (43 of 63) | 54% (14 of 26) | 64% (57 of 89) |
| the unit moved after it | 49% (21 of 43) | 86% (12 of 14) | 58% (33 of 57) |
| it charged on its next turn | 0% (0 of 43) | 0% (0 of 14) | 0% (0 of 57) |
| the enemy charged it first | 9% (4 of 43) | 0% (0 of 14) | 7% (4 of 57) |
| it fought by the end of its next turn | 2% (1 of 43) | 0% (0 of 14) | 2% (1 of 57) |
| it moved out of a charge the enemy had planned (not charged first) | 5% (2 of 43) | 0% (0 of 14) | 4% (2 of 57) |
| none of these (no charge, no fight, no charge escaped) | 86% (37 of 43) | 100% (14 of 14) | 89% (51 of 57) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (581 of 871) | 58% (287 of 499) | 63% (868 of 1370) |
|   cavalry | 72% (61 of 85) | 58% (61 of 106) | 64% (122 of 191) |
|   character | 66% (69 of 105) | 47% (42 of 90) | 57% (111 of 195) |
|   chariot | 66% (63 of 95) | 59% (27 of 46) | 64% (90 of 141) |
|   infantry | 62% (160 of 260) | 57% (105 of 184) | 60% (265 of 444) |
|   monster | 68% (19 of 28) | - | 68% (19 of 28) |
|   war machine | 70% (209 of 298) | 71% (52 of 73) | 70% (261 of 371) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.2 (15%) | 1.1 (18%) | 2.3 (17%) |
| CHARGED: it charged | 0.6 (7%) | 1.0 (17%) | 1.6 (11%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (4%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.4 (5%) | 0.4 (7%) | 0.8 (6%) |
| MOVED: a war machine that moved | 1.6 (20%) | 0.5 (9%) | 2.2 (16%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.7 (21%) | 1.4 (25%) | 3.1 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (7%) | 0.2 (4%) | 0.8 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (17%) | 0.9 (15%) | 2.2 (16%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 0.8 | 86% | 5.0 pts | 23 pts |
| character | 3.4 | 0.9 | 81% | 4.6 pts | 16 pts |
| chariot | 2.5 | 1.4 | 76% | 9.7 pts | 24 pts |
| infantry | 10.8 | 3.5 | 78% | 8.0 pts | 86 pts |
| monster | 0.6 | 0.2 | 77% | 2.3 pts | 1 pts |
| war machine | 7.2 | 4.9 | 67% | 23.0 pts | 167 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.8 | 3.7 | 3.2 |
| Charges that made contact a game | 2.2 | 2.5 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.83 declared, 0.67 contact (24 units) | 0.59 declared, 0.41 contact (22 units) | 0.72 declared, 0.54 contact (46 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.86 declared, 0.57 contact (7 units) | 1.00 declared, 0.85 contact (13 units) | 0.95 declared, 0.75 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.24 contact (254 units) | 0.37 declared, 0.24 contact (288 units) | 0.34 declared, 0.24 contact (542 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 61% (43 of 70) | 67% (14 of 21) | 57% (4 of 7) | 62% (61 of 98) |
| Character in a unit | 89% (42 of 47) | 69% (11 of 16) | 25% (1 of 4) | 81% (54 of 67) |
| Character on its own | 94% (30 of 32) | 69% (24 of 35) | 38% (24 of 64) | 60% (78 of 131) |
| Chariot | 93% (13 of 14) | 67% (10 of 15) | - | 79% (23 of 29) |
| Infantry | 72% (53 of 74) | 55% (27 of 49) | 50% (2 of 4) | 65% (82 of 127) |
| Monster | 65% (11 of 17) | 58% (7 of 12) | - | 62% (18 of 29) |
| Monstrous | 100% (8 of 8) | 64% (7 of 11) | - | 79% (15 of 19) |
| War Machines | 77% (33 of 43) | 100% (2 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 88% (7 of 8); on the table 88% | 40% (43 of 108) | 42% | 50% (11 of 22) | 100% (6 of 6); 5.0 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 6 | 50% (3 of 6); on the table 50% | 12% (5 of 42) | 61% | 54% (26 of 48) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 71% (5 of 7); on the table 71% | - | 83% | 80% (33 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 71% (5 of 7); on the table 71% | 33% (12 of 36) | 55% | 80% (51 of 64) | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game | 75% (3 of 4); 0.5 uses a game |
| Grand Cathay | 5 | 90% (9 of 10); on the table 90% | 23% (26 of 114) | 52% | 69% (31 of 45) | 82% (9 of 11); 4.6 uses a game | 0% (0 of 2); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 60% (6 of 10); on the table 60% | 29% (7 of 24) | 58% | 57% (28 of 49) | 100% (5 of 5); 4.0 uses a game | 25% (5 of 20); 1.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (3 of 3); on the table 100% | - | 45% | 44% (8 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 68% | 86% (6 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (3 of 3); on the table 100% | 11% (2 of 18) | 12% | 88% (14 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 6 | 65% (11 of 17); on the table 76% | 31% (15 of 48) | 55% | 73% (35 of 48) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 83% (5 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 2 | 60% (6 of 10); on the table 60% | 33% (2 of 6) | 32% | 20% (2 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 12 | 87% (34 of 39); on the table 92% | 23% (22 of 96) | 44% | 66% (47 of 71) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 69% (9 of 13); on the table 69% | 83% (5 of 6) | 55% | 61% (27 of 44) | 100% (1 of 1); 0.8 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| Wood Elf Realms | 6 | 88% (7 of 8); on the table 88% | 17% (4 of 24) | 33% | 76% (47 of 62) | 73% (8 of 11); 3.0 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s1-882d875-p5, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (31) | 47% (21) | 49% (52) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.50 | 1.03 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.06 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.36 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.03 | 0.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.08 | 0.08 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.06 | 0.25 | 0.31 |

### Quality by phase: base-s1-882d875-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 60% (52 of 87) | 40% (46 of 114) |
| Strategy | Shoot objectives carried out (shot that target) | 28% (107 of 389) | 49% (74 of 150) |
| Strategy | Support requests answered (helper made contact too) | 64% (9 of 14) | 42% (8 of 19) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (9 of 12) | 50% (6 of 12) |
| Strategy | Joined characters whose unit fought | 43% (22 of 51) | 35% (15 of 43) |
| Strategy | Lone characters that fought | 60% (53 of 89) | 60% (49 of 81) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.7 | 3.0 |
| Movement | Points that never moved of their own | 229.5 | 184.9 |
| Movement | Fights charged into per game | 2.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 59, net +8 | 19 of 65, net +132 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 59, net +103 | 11 of 65, net +169 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 59, net +69 | 9 of 65, net +100 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 59, net +58 | 18 of 65, net +138 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 7.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (175 of 395) | 41% (105 of 256) |
| Shooting | Points destroyed by shooting units | 52.8 | 21.1 |
| Shooting | War machine shots | 5.8 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (116 of 209) | 52% (27 of 52) |
| Shooting | Points destroyed by war machines | 68.7 | 28.8 |
| Magic | Magic missiles cast | 1.7 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (18 of 62) | 25% (9 of 36) |
| Magic | Wounds caused by magic missiles | 3.7 | 0.8 |
| Magic | Wounds caused by other spells | 0.7 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 66.3 | 28.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.5 / 0.4 / 0.2 | 2.5 / 0.5 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 201.6 | 304.9 |
| Combat | Points run down | 40.1 | 102.8 |
| Combat | Net points per charged fight, damage counted | +96 | +133 |
| Combat | Net per 100 charger points, damage counted | +31.2 | +43.7 |
| Combat | First round won (charged fights) | 73% | 70% |
| Combat | Net points per charged fight | +86 | +138 |
| Combat | Net points per supported fight / lone fight | +113 / +82 | +247 / +128 |
| Combat | Charged fights on a top-3 enemy unit | 26 of 71 | 40 of 81 |
| Game | Points lost | 615.7 | 497.2 |
| Game | VP from objectives | 616.0 | 590.3 |
| Game | Lone holders (player turns) | 3.3 | 2.9 |

- Mine won / drew / lost: 13 / 8 / 14 of 35 ended games (of 36); mean margin (Mine - Opponent) -90 VP
- The side that went first won 17 of 27 games with a winner
- Points traded per game (both sides' losses): 1113
- Games not ended: 1 (L1725-1); findings 7, warnings 0

### Opponent rules: base-s1-882d875-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 4.0 |
| AFTERMATH IN POINTS | 0.2 | +11.3 | 0.0 | 26.4 | 0.1 | +22.5 | 0.0 | 10.6 |
| AFTERMATH WITH FRIENDS | 0.1 | +2.3 | 0.0 | 0.0 | 0.2 | +8.8 | 0.0 | 1.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.7 | +208.6 | 0.0 | 152.7 | 17.2 | +208.5 | 0.0 | 184.6 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 19.0 | 0.3 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.1 | +1.0 | 0.0 | 0.0 | 0.2 | +0.9 | 0.0 | 0.0 |
| BEST FACING | - | - | - | - | 0.0 | +1.6 | 0.0 | 0.0 |
| BEST OVERALL | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | -3.4 | 5.8 | 0.0 | 0.1 | -7.1 | 6.3 | 36.7 |
| BLOWS WHERE AIMED | 0.3 | -31.1 | 15.9 | 13.3 | 0.3 | -54.2 | 48.3 | 0.0 |
| BOMBING RUN | 0.1 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.2 | +0.0 | 43.5 | 2.6 | 0.0 | +0.0 | 8.6 | 0.0 |
| CANNON PLANNED TARGET | 5.7 | +100.1 | 396.3 | 86.2 | 1.4 | +74.5 | 128.9 | 20.7 |
| CANNON SIGHT KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.9 | +15.4 | 27.8 | 22.2 | 0.5 | +7.7 | 31.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +12.9 | 15.0 | 0.0 | 0.1 | +2.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 38.3 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.5 | +10.7 | 0.0 | 9.2 | 1.2 | +57.9 | 0.0 | 23.5 |
| CHAFF PASSED | 0.3 | -0.9 | 10.1 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -0.2 | 0.0 | 10.9 | 0.1 | -1.0 | 17.0 | 0.0 |
| CHARACTER GUNS | 1.6 | +0.0 | 0.0 | 10.5 | 2.2 | +0.0 | 0.0 | 15.2 |
| CHARGE LOSSES | 8.7 | -427.0 | 0.0 | 251.5 | 10.6 | -636.3 | 0.0 | 201.4 |
| CHARGE NOT DECLARED | 0.0 | +0.0 | 0.0 | 9.7 | 0.0 | +0.0 | 1.5 | 0.0 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 157.6 | 60.3 | 1.7 | +0.0 | 240.0 | 11.5 |
| CHARGER SLAIN LOST | 0.3 | -17.6 | 10.9 | 11.4 | 0.2 | -4.5 | 4.4 | 7.4 |
| COMBAT PIVOT | 0.3 | +0.0 | 2.7 | 40.0 | 0.3 | +0.0 | 18.5 | 21.8 |
| CONVEYANCE SEARCH | 1.6 | +218.9 | 53.8 | 46.2 | 0.5 | +33.2 | 0.0 | 0.0 |
| COVER ONCE | 5.8 | -415.4 | 0.0 | 116.1 | 4.4 | -340.6 | 0.0 | 53.1 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 12.9 | - | - | - | - |
| DEFENSIVE FLOOR | 0.0 | -1.2 | 0.0 | 0.0 | 0.0 | -2.4 | 0.0 | 5.3 |
| DENIED BY THE FIGHT | 0.4 | -6.2 | 30.9 | 27.8 | 0.9 | -13.6 | 121.8 | 21.7 |
| DEPLOY BY FIGURES | 8.1 | -6.9 | 0.0 | 8.8 | 7.6 | +67.1 | 0.0 | 17.2 |
| EDGE GIVE GROUND | 0.1 | +3.2 | 22.8 | 0.0 | 0.1 | +3.1 | 9.2 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.0 | +1.6 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.9 | +10.0 | 167.7 | 57.2 | 2.4 | +5.2 | 295.6 | 48.6 |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 1.2 | 0.4 | +0.0 | 0.0 | 2.8 |
| FALLS SHORT | 4.8 | +79.7 | 0.0 | 90.0 | 15.6 | +205.4 | 0.0 | 128.0 |
| FEATURE BUFFS | 2.2 | +49.0 | 0.0 | 17.2 | 1.1 | +21.1 | 0.0 | 24.6 |
| FIGHT LIFT | - | - | - | - | 0.0 | +0.3 | 5.4 | 0.0 |
| FIGHT TO THE END | 0.6 | +9.8 | 53.4 | 32.0 | 1.1 | +35.8 | 163.4 | 6.6 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 88.2 | +5443.7 | 1275.1 | 1053.8 | 82.7 | +4449.2 | 771.1 | 805.5 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 124.3 | 4.2 | +0.0 | 0.0 | 93.2 |
| FOCUS FIRE | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +126.1 | 0.0 | 32.2 | 0.6 | +148.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +281.2 | 203.3 | 76.3 | 3.3 | +293.2 | 348.1 | 62.6 |
| FRIEND CHARGES FIRST | 0.1 | -7.2 | 0.0 | 5.2 | 0.0 | -0.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.6 | -15.1 | 0.0 | 8.0 | 0.2 | -1.1 | 0.0 | 1.7 |
| FRIENDS SHOTS CHECKED | 0.2 | +6.7 | 0.0 | 11.2 | 0.1 | -0.2 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -3.0 | 0.0 | 0.0 | 0.3 | -4.0 | 25.4 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.8 | 1.5 | 0.0 |
| GROUND FLIERS | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.1 | +11.9 | 10.7 | 1.8 | 0.6 | +2.2 | 3.0 | 7.2 |
| GUN MASK | 1.4 | +41.9 | 0.0 | 18.7 | 0.2 | +4.6 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.8 | +0.0 | 0.0 | 28.1 | 1.3 | +0.0 | 0.0 | 7.6 |
| HE SHOOTS OR CHARGES | 2.3 | +0.0 | 0.0 | 59.6 | 3.2 | +0.0 | 0.0 | 142.2 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 1.1 | 0.0 |
| HIS CHARGE DENIED | 0.4 | +17.8 | 28.8 | 16.6 | 0.4 | +24.5 | 16.9 | 3.4 |
| HIS CHARGE LIST | 4.6 | +0.0 | 0.0 | 27.1 | 5.0 | +0.0 | 0.0 | 54.4 |
| HIS FIGHT TOGETHER | 1.8 | -32.6 | 0.0 | 70.2 | 2.0 | -34.7 | 0.0 | 130.6 |
| HIS LEGAL MOVES | 4.2 | +0.0 | 0.0 | 51.8 | 3.9 | +0.0 | 0.0 | 61.5 |
| HIS MOVE AND SHOT | 2.3 | -39.0 | 0.0 | 45.6 | 4.0 | -109.3 | 0.0 | 60.6 |
| HIS MOVE AS HE DECIDES | 37.4 | +13.5 | 484.1 | 0.0 | 34.6 | +14.1 | 549.6 | 0.0 |
| HIS MOVE WHY | 35.0 | +0.0 | 0.0 | 375.6 | 36.3 | +0.0 | 0.0 | 342.5 |
| HIS ONE MOVE | 17.6 | +29.4 | 0.0 | 86.1 | 19.5 | +52.3 | 1.2 | 40.8 |
| HIS ONE QUARTER | 3.2 | +0.0 | 0.0 | 19.6 | 3.1 | +0.0 | 0.0 | 52.5 |
| HIS OWN BEST MOVE | 1.5 | +0.0 | 0.0 | 16.2 | 1.5 | +0.0 | 0.0 | 11.9 |
| HIS RANDOM MOVE | 5.4 | +0.0 | 0.0 | 41.3 | 2.1 | +0.0 | 0.0 | 1.7 |
| HIS SHOT LIST | 30.2 | +950.0 | 0.0 | 400.0 | 45.4 | +2061.7 | 0.0 | 425.2 |
| HIS TURN DENIED | 1.3 | +38.0 | 107.8 | 25.8 | 1.6 | +68.7 | 185.8 | 44.9 |
| HOLD ODDS | 16.2 | +0.0 | 0.0 | 151.9 | 15.8 | +0.0 | 0.0 | 128.6 |
| HOLDER ASSIGNMENT | 9.4 | +923.1 | 0.0 | 81.8 | 9.6 | +905.4 | 0.0 | 60.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.1 | -97.0 | 181.4 | 39.3 | 3.0 | -152.7 | 333.8 | 58.2 |
| HORN WORTH | - | - | - | - | 0.1 | +0.8 | 0.0 | 14.0 |
| HUNT IN PAIRS | 0.2 | +5.8 | 0.0 | 12.2 | 0.2 | +9.2 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +13.1 | 0.0 | 0.0 | 0.0 | +6.9 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.0 | +13.6 | 0.0 | 0.0 | 0.0 | +8.1 | 4.6 | 0.0 |
| IDLE COST | 4.0 | -39.3 | 0.0 | 13.4 | 12.3 | -197.1 | 0.0 | 123.8 |
| JOINT CHARGE NOW | 0.7 | +23.4 | 39.4 | 10.4 | 0.8 | +59.8 | 94.9 | 2.9 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | -2.3 | 20.4 | 0.0 |
| JOINT LOOK BACK | 0.0 | +0.8 | 6.6 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +1.6 | 0.0 | 6.8 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.6 | +0.0 | 0.0 | 13.6 | 2.2 | +0.0 | 0.0 | 14.3 |
| LANE BY FIGURES | 0.7 | +20.0 | 0.0 | 0.0 | 1.0 | +40.3 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.4 | +0.0 | 190.9 | 253.6 | 5.3 | +0.0 | 248.6 | 163.5 |
| LONE CHARACTER SAFE SPOT | 0.1 | +1.2 | 2.9 | 1.2 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +33.4 | 0.0 | 0.0 | 0.2 | +19.6 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -4.2 | 9.2 | 0.0 | 0.2 | +0.6 | 11.9 | 1.4 |
| LOST AFTER ESCAPE | 1.4 | -2.3 | 82.4 | 51.0 | 1.8 | +1.4 | 186.7 | 30.3 |
| LURE BY WHAT IT DRAWS | 0.1 | -2.2 | 0.0 | 0.0 | 0.1 | -16.2 | 0.0 | 2.6 |
| MAKE SURE TOGETHER | 0.1 | +5.1 | 0.0 | 9.6 | - | - | - | - |
| MANOEUVRE | 0.7 | +0.5 | 0.0 | 18.2 | 0.5 | -1.3 | 0.0 | 4.2 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 7.2 |
| MARCH BY THE SUM | 0.4 | +29.9 | 0.0 | 25.5 | 0.1 | +1.8 | 0.0 | 10.2 |
| MARCH CHECK | 0.5 | +35.2 | 0.0 | 29.3 | 0.4 | +20.5 | 0.0 | 20.3 |
| MARCH OF THE TABLE | 0.1 | +11.0 | 0.0 | 0.0 | 0.1 | +6.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.5 | -11.1 | 0.0 | 25.5 | 0.5 | +19.8 | 0.0 | 29.8 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.6 | +61.7 | 0.0 | 62.1 | 2.5 | +64.6 | 0.0 | 31.6 |
| MISSILES IN THE MOVE | 3.8 | +96.6 | 0.0 | 88.4 | 2.7 | +36.7 | 0.0 | 45.7 |
| MISSILES NEXT TURN | 4.7 | +73.9 | 0.0 | 119.1 | 4.1 | +34.1 | 0.0 | 84.2 |
| MISSILES ON ONE TARGET | 0.2 | -7.8 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | 0.5 | +152.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 10.6 | 25.4 | 2.4 | +0.0 | 26.9 | 27.2 |
| MOVE SPELL IN RANGE | 0.4 | +16.2 | 0.0 | 0.0 | 0.1 | +1.6 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.4 | -16.4 | 25.6 | 0.0 | 0.4 | -17.0 | 0.0 | 13.0 |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 38.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.9 | +642.6 | 0.0 | 75.7 | 6.0 | +598.2 | 0.0 | 58.2 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.1 | +344.5 | 0.0 | 110.8 | 7.2 | +286.6 | 0.0 | 25.3 |
| NEXT CHARGE BY LIST | 5.3 | -227.1 | 31.0 | 116.8 | 5.8 | -301.8 | 12.1 | 53.2 |
| NEXT OBJECTIVE NEARER | 0.2 | -6.8 | 0.0 | 0.0 | 0.1 | -4.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.2 | -138.3 | 168.2 | 74.9 | 2.6 | -154.9 | 302.6 | 21.1 |
| NO LATE CUT | 0.8 | +0.0 | 0.0 | 13.6 | 0.9 | +0.0 | 0.0 | 14.3 |
| NO RALLY LEFT | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.1 | -0.1 | 0.0 | 2.4 | 0.2 | -1.2 | 0.0 | 12.8 |
| NOT WORTH A CAST | 0.4 | -0.4 | 0.0 | 12.1 | 0.4 | -2.7 | 0.0 | 2.6 |
| OFF BEST | 3.1 | -136.1 | 4.7 | 14.8 | 3.5 | -112.8 | 3.0 | 49.1 |
| ONE CHARGE A CHARGER | 3.7 | +0.0 | 0.0 | 35.4 | 4.7 | +0.0 | 0.0 | 73.5 |
| ONE FIGHT FORMULA | 4.0 | -79.4 | 0.0 | 82.9 | 3.9 | -88.8 | 0.0 | 84.7 |
| ONE OBJECTIVE FORMULA | 3.9 | +72.0 | 0.0 | 68.2 | 3.9 | +2.6 | 0.0 | 31.7 |
| ONE PROMISE A TARGET | 0.2 | -15.3 | 0.0 | 5.2 | 0.1 | -9.5 | 0.0 | 2.9 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 23.5 | +494.6 | 0.0 | 218.1 | 32.8 | +839.7 | 0.0 | 358.2 |
| OPENS A LANE | 0.2 | +0.4 | 99.8 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +13.3 | 11.9 | 0.0 | 0.2 | +4.9 | 10.2 | 0.0 |
| OVERRUNS AWAY | 0.4 | +35.5 | 23.7 | 14.4 | 0.5 | +13.3 | 39.8 | 26.0 |
| PATHS CROSS | 0.4 | +14.6 | 0.0 | 5.3 | 0.4 | +26.0 | 0.0 | 14.2 |
| PERIAPT WORTH | 0.0 | +3.5 | 0.0 | 15.0 | 0.1 | +8.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 0.0 | 0.1 | -2.3 | 0.0 | 4.0 |
| PLAN RESULT | 40.2 | +716.1 | 531.2 | 825.5 | 39.8 | +475.2 | 274.5 | 679.8 |
| PROMISE BELOW ZERO | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 1.4 |
| PROMISE BY ITS OWN SUM | 7.6 | -275.2 | 0.0 | 10.7 | 8.4 | -249.2 | 0.0 | 32.9 |
| PROMISE IN STEPS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.4 | -0.1 | 0.0 | 0.0 | 0.6 | -1.2 | 0.0 | 2.9 |
| PROMISE READS THE TABLE | 0.2 | -8.4 | 0.0 | 0.0 | 0.2 | -9.5 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -7.3 | 73.7 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | 0.1 | -4.5 | 0.0 | 0.0 | 0.0 | -0.4 | 0.0 | 0.0 |
| QUARTER ODDS | 16.8 | +1831.9 | 135.1 | 122.3 | 15.1 | +1475.4 | 73.1 | 122.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +20.0 | 0.0 | 19.7 | 1.7 | +45.3 | 0.0 | 53.2 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -8.1 | 0.0 | 9.0 | 1.1 | -26.5 | 0.0 | 23.4 |
| REDIRECT COUNTER | 1.8 | +110.6 | 0.0 | 15.4 | 2.8 | +197.3 | 0.0 | 52.0 |
| REDIRECT WEIGHED | 0.0 | +0.2 | 0.0 | 0.0 | 0.2 | -3.2 | 12.8 | 37.9 |
| REFORMS TO MEET IT | 1.6 | -22.6 | 0.0 | 38.3 | 1.2 | -24.9 | 0.0 | 3.3 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 4.1 | 0.4 | +0.0 | 0.0 | 5.8 |
| RESERVE FALL BACK | 0.4 | +15.6 | 0.0 | 0.0 | 0.6 | +36.7 | 0.0 | 13.8 |
| RISK BY ARC | 1.8 | +0.7 | 163.1 | 61.2 | 1.9 | -4.4 | 217.4 | 57.4 |
| RISK BY HIS FIGURE | 21.4 | -345.1 | 0.0 | 423.4 | 19.8 | -361.2 | 0.0 | 380.7 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.6 | -17.5 | 63.6 | 31.3 | 1.5 | -37.7 | 184.4 | 27.4 |
| RUN DOWN | 1.6 | -20.9 | 143.0 | 51.9 | 2.1 | -22.6 | 239.7 | 16.2 |
| SAFER THAN THE JOB | - | - | - | - | 0.1 | +3.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +1.3 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.4 | -31.3 | 0.0 | 7.4 | 1.1 | -69.7 | 0.0 | 2.5 |
| SEARCH SPOT | 0.4 | +2.6 | 0.0 | 13.2 | 0.4 | +13.4 | 0.0 | 0.5 |
| SECOND LOOK | 0.2 | +16.4 | 21.2 | 1.2 | 0.1 | +2.5 | 3.8 | 0.0 |
| SELF MOVE SPELL | 0.3 | +17.9 | 0.0 | 18.1 | 0.2 | +59.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +28.6 | 19.6 | 51.8 | 2.4 | +71.4 | 2.9 | 31.1 |
| SET UP TOGETHER | 0.2 | +7.3 | 0.0 | 9.6 | 0.2 | +3.7 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +76.8 | 20.7 | 13.2 | 0.1 | +6.6 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.8 | +123.9 | 74.8 | 57.6 | 1.5 | +27.1 | 25.6 | 3.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -14.9 | 26.9 | 4.6 | 0.2 | -1.5 | 14.9 | 0.0 |
| SHOT RISK POINTS | 14.6 | -75.2 | 0.0 | 178.9 | 21.2 | -12.2 | 0.0 | 304.8 |
| SHOTS AFTER THE MOVES | 3.1 | +0.0 | 0.0 | 0.0 | 1.5 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.9 | +656.2 | 0.0 | 199.8 | 8.5 | +280.6 | 0.0 | 148.7 |
| SPELL SETS UP CHARGE | 0.4 | +113.8 | 20.7 | 13.2 | 0.1 | +6.6 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +19.5 | 51.4 | 43.7 | 2.7 | +41.8 | 34.3 | 35.4 |
| SPELLS IN THE FIGHT | 0.6 | +0.5 | 45.2 | 6.0 | 0.4 | +1.9 | 42.9 | 4.0 |
| SPOT AS THE GAME MOVES | 6.9 | +0.0 | 0.0 | 132.4 | 10.0 | +0.0 | 0.0 | 121.2 |
| STAND AND SHOOT | 0.4 | -3.4 | 37.4 | 6.5 | 0.3 | -2.3 | 32.7 | 4.0 |
| STANDS FOR A REASON | 0.4 | +0.0 | 6.2 | 0.0 | 1.8 | +0.0 | 15.7 | 36.8 |
| STANDS STILL | 45.1 | +0.0 | 1071.8 | 522.4 | 28.6 | +0.0 | 423.0 | 221.9 |
| STANDS TO CAST | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 25.1 | -10.3 | 624.4 | 248.6 | 9.9 | +75.0 | 244.0 | 131.3 |
| STOPS | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.8 | 4.6 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.1 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.9 | +476.2 | 0.0 | 32.8 | 8.7 | +702.3 | 0.0 | 38.1 |
| SUPPORT NARROWED | 0.4 | +0.0 | 11.9 | 12.8 | 0.2 | +0.0 | 3.3 | 10.1 |
| SUPPORT WORKED OUT | 6.9 | +476.2 | 0.0 | 32.8 | 8.7 | +702.3 | 0.0 | 38.1 |
| SURE REACH TOGETHER | 0.2 | +1.0 | 0.0 | 13.9 | 0.5 | +5.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 18.0 | 1.1 | +0.0 | 0.0 | 20.5 |
| THE PROMISE ADDS | 0.1 | -5.5 | 0.0 | 0.0 | 0.2 | -8.8 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.8 | +0.0 | 0.0 | 0.0 | 5.9 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 29.6 | +0.0 | 0.0 | 266.9 | 34.3 | +0.0 | 0.0 | 288.9 |
| TIED UP BY THE SUM | 0.5 | +54.2 | 70.2 | 4.0 | 0.6 | +81.5 | 74.9 | 5.2 |
| TIME ON OUR SIDE | 33.8 | +375.8 | 3.6 | 484.3 | 13.5 | +127.5 | 17.4 | 110.7 |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 13.9 | 1.2 | +0.0 | 0.0 | 16.7 |
| WALKS ON ITS ROUTE | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 22.4 | 34.4 | 0.1 | +0.0 | 11.8 | 0.0 |
| WHAT THE JOINER ADDS | 0.1 | -1.0 | 5.4 | 0.0 | 0.3 | -1.8 | 21.0 | 0.0 |
| WHO GETS IN | 0.2 | +12.5 | 15.5 | 0.0 | 0.1 | +1.2 | 5.1 | 0.0 |
| WHO HITS BACK | 0.3 | +42.7 | 0.0 | 6.7 | 0.3 | +29.1 | 0.0 | 1.2 |
| WHOLE FIGHT | 0.1 | +0.5 | 2.7 | 0.0 | 0.2 | -0.5 | 16.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +14.4 | 8.2 | 10.4 | 0.1 | +6.7 | 17.5 | 1.5 |
| WIDER SPREAD | 1.6 | -4.7 | 146.4 | 28.8 | 1.7 | -5.6 | 165.8 | 43.1 |
| WOUNDS ON THE RANKS | 1.8 | +37.8 | 0.0 | 49.7 | 1.4 | +129.1 | 0.0 | 12.0 |

### Rule changes: base-s1-882d875-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2594 | 2594 | 1598 | 44.39 | +0 | +0.0 |
| HIS MOVE WHY | 2565 | 2565 | 1378 | 38.28 | +0 | +0.0 |
| ARMY TABLE | 1220 | 1220 | 792 | 22.00 | +13817 | +17.4 |
| HIS SHOT LIST | 2722 | 2598 | 643 | 17.86 | +11791 | +18.3 |
| HOLDER ASSIGNMENT | 684 | 684 | 625 | 17.36 | +38404 | +61.4 |
| LEGAL CHARGES ONLY | 383 | 383 | 383 | 10.64 | +0 | +0.0 |
| ONE TARGET A SHOOTER | 2026 | 1924 | 347 | 9.64 | +3917 | +11.3 |
| DEPLOY BY FIGURES | 567 | 567 | 336 | 9.33 | +4110 | +12.2 |
| HIS ONE MOVE | 1335 | 1301 | 280 | 7.78 | +0 | +0.0 |
| FIVE ACTION | 6153 | 5931 | 263 | 7.31 | +15473 | +58.8 |
| THE TABLE AGAIN | 421 | 421 | 260 | 7.22 | +0 | +0.0 |
| TIME ON OUR SIDE | 1704 | 1553 | 248 | 6.89 | +1144 | +4.6 |
| OFF BEST | 239 | 239 | 239 | 6.64 | -8958 | -37.5 |
| PROMISE BY ITS OWN SUM | 578 | 578 | 207 | 5.75 | -18880 | -91.2 |
| MOVE TO CHARGE COMPUTED | 428 | 375 | 200 | 5.56 | +10735 | +53.7 |
| SUPPORT ADDS | 562 | 535 | 194 | 5.39 | +7932 | +40.9 |
| SUPPORT WORKED OUT | 562 | 535 | 194 | 5.39 | +7932 | +40.9 |
| SHOT RISK POINTS | 1289 | 1221 | 189 | 5.25 | +6608 | +35.0 |
| MOVE ORDER | 135 | 135 | 135 | 3.75 | +0 | +0.0 |
| HARD STAY DROPPED | 114 | 114 | 114 | 3.17 | +0 | +0.0 |
| QUARTER ODDS | 1148 | 1091 | 108 | 3.00 | +11053 | +102.3 |
| FOUR ROUNDS | 214 | 210 | 95 | 2.64 | +5974 | +62.9 |
| SHOOTS FROM THE BEST SPOT | 153 | 153 | 94 | 2.61 | +1302 | +13.8 |
| IDLE COST | 588 | 489 | 84 | 2.33 | +786 | +9.4 |
| ADVANCE LANE KEPT | 81 | 81 | 81 | 2.25 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 68 | 68 | 68 | 1.89 | +0 | +0.0 |
| COVER ONCE | 365 | 266 | 62 | 1.72 | +2200 | +35.5 |
| RISK BY HIS FIGURE | 1485 | 1419 | 60 | 1.67 | +5803 | +96.7 |
| LANE BY FIGURES | 59 | 59 | 59 | 1.64 | +2172 | +36.8 |
| JOINT CHARGE NOW | 56 | 56 | 56 | 1.56 | +2997 | +53.5 |
| RANDOM MOVE BY FIGURES | 79 | 79 | 56 | 1.56 | +2350 | +42.0 |
| CHARGE LOSSES | 693 | 653 | 50 | 1.39 | +3731 | +74.6 |
| CHAFF IN THE MOVE | 59 | 57 | 48 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 47 | 47 | 47 | 1.31 | +9876 | +210.1 |
| CANNON SIGHT KEPT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| MAX FOR POSITIONING | 184 | 173 | 41 | 1.14 | +325 | +7.9 |
| STAY WORTH | 1259 | 1176 | 41 | 1.14 | +275 | +6.7 |
| RESERVE FALL BACK | 39 | 39 | 39 | 1.08 | +1885 | +48.3 |
| FALLS SHORT | 734 | 642 | 38 | 1.06 | +546 | +14.4 |
| SET UP BY THE SET | 148 | 146 | 38 | 1.06 | +1421 | +37.4 |
| SHOTS IN THE MOVE | 912 | 754 | 37 | 1.03 | +1131 | +30.6 |
| CAST JOB | 52 | 52 | 35 | 0.97 | +207 | +5.9 |
| TIED UP BY THE SUM | 42 | 40 | 33 | 0.92 | +1209 | +36.6 |
| REDIRECT COUNTER | 163 | 137 | 31 | 0.86 | +1728 | +55.8 |
| NEXT CHARGE BY LIST | 397 | 372 | 30 | 0.83 | +874 | +29.1 |
| HOLDS AMBUSHERS | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 29 | 29 | 29 | 0.81 | +1907 | +65.8 |
| CHARGE NOW FIRST | 118 | 118 | 28 | 0.78 | -2463 | -88.0 |
| PATHS CROSS | 28 | 28 | 28 | 0.78 | +1464 | +52.3 |
| RISK BY ARC | 135 | 133 | 26 | 0.72 | +616 | +23.7 |
| MARCH CHECK | 35 | 34 | 23 | 0.64 | +415 | +18.1 |
| CANNON PLANNED TARGET | 257 | 257 | 22 | 0.61 | -100 | -4.6 |
| COMBAT PIVOT | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| WHO HITS BACK | 21 | 21 | 21 | 0.58 | +1551 | +73.8 |
| SHOOTERS IN TWO RANKS | 20 | 20 | 20 | 0.56 | +42 | +2.1 |
| HIS TURN DENIED | 102 | 100 | 19 | 0.53 | +623 | +32.8 |
| MODEL FACING | 19 | 19 | 19 | 0.53 | +5490 | +289.0 |
| CASTS FROM BEHIND | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| MARCH BY THE SUM | 18 | 18 | 18 | 0.50 | +1140 | +63.3 |
| SHOTS AFTER THE MOVES | 167 | 167 | 18 | 0.50 | +0 | +0.0 |
| CHAFF PASSED | 17 | 17 | 17 | 0.47 | -34 | -2.0 |
| SCOUT WAITS | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 116 | 113 | 16 | 0.44 | +1078 | +67.3 |
| HIS MOVE AND SHOT | 228 | 222 | 15 | 0.42 | +456 | +30.4 |
| NEARER NOT NEEDED | 554 | 534 | 14 | 0.39 | +396 | +28.3 |
| MISSILES IN THE MOVE | 233 | 157 | 12 | 0.33 | +152 | +12.6 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.31 | +1215 | +110.4 |
| CASTING BLOCK | 18 | 18 | 11 | 0.31 | +67 | +6.1 |
| SURE REACH TOGETHER | 23 | 22 | 11 | 0.31 | +50 | +4.6 |
| CASTER AWAY FROM SCREEN | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| FIRE IN ORDER | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +233 | +23.3 |
| ONE PROMISE A TARGET | 10 | 10 | 10 | 0.28 | -893 | -89.3 |
| PROMISE SHOT AWAY | 10 | 10 | 10 | 0.28 | -264 | -26.4 |
| REFUSING RETIRES | 23 | 23 | 10 | 0.28 | -1 | -0.1 |
| SEARCH SPOT | 26 | 26 | 10 | 0.28 | +577 | +57.7 |
| SECOND LOOK | 10 | 10 | 10 | 0.28 | +682 | +68.2 |
| WHO GETS IN | 10 | 10 | 10 | 0.28 | +492 | +49.2 |
| AFTERMATH WITH FRIENDS | 9 | 9 | 9 | 0.25 | +400 | +44.4 |
| ONE FIGHT FORMULA | 286 | 143 | 9 | 0.25 | +55 | +6.1 |
| ONE OBJECTIVE FORMULA | 280 | 211 | 9 | 0.25 | +231 | +25.7 |
| OVERRUNS AWAY | 32 | 32 | 9 | 0.25 | +177 | +19.6 |
| PROMISE READS THE TABLE | 16 | 16 | 9 | 0.25 | +88 | +9.8 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 0.25 | +622 | +69.1 |
| FIGHT TO THE END | 61 | 61 | 8 | 0.22 | +225 | +28.1 |
| HIS FIGHT TOGETHER | 136 | 134 | 8 | 0.22 | +222 | +27.7 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -144 | -18.0 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -578 | -82.5 |
| GUN MASK | 58 | 54 | 7 | 0.19 | +79 | +11.3 |
| MARCH OF THE TABLE | 7 | 7 | 7 | 0.19 | -646 | -92.3 |
| NO DOUBLE ROUNDS | 174 | 170 | 7 | 0.19 | +43 | +6.1 |
| OPENS UP | 14 | 13 | 7 | 0.19 | +199 | +28.5 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| WAR ENGINE JOBS | 17 | 17 | 7 | 0.19 | -543 | -77.6 |
| FEATURE BUFFS | 117 | 117 | 6 | 0.17 | +116 | +19.3 |
| MANOEUVRE | 42 | 42 | 6 | 0.17 | +171 | +28.6 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +133 | +22.2 |
| HIS CHARGE DENIED | 28 | 27 | 5 | 0.14 | +312 | +62.4 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +130 | +25.9 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +428 | +85.6 |
| PROMISE KNOWS THE FIGHT | 36 | 26 | 5 | 0.14 | -48 | -9.7 |
| SUPPORT NARROWED | 19 | 19 | 5 | 0.14 | -181 | -36.2 |
| HONEST WORTH | 184 | 181 | 4 | 0.11 | +75 | +18.8 |
| HUNT IN PAIRS | 12 | 7 | 4 | 0.11 | +158 | +39.5 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -177 | -44.2 |
| WHAT THE JOINER ADDS | 14 | 14 | 4 | 0.11 | +83 | +20.8 |
| WHOLE FIGHT GAIN | 16 | 15 | 4 | 0.11 | +128 | +31.9 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +1 | +0.2 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +31 | +10.2 |
| NEXT OBJECTIVE NEARER | 12 | 10 | 3 | 0.08 | +94 | +31.3 |
| REDIRECT BY WHAT IT STOPS | 50 | 50 | 3 | 0.08 | +88 | +29.2 |
| ROUNDS AFTER TERROR | 74 | 74 | 3 | 0.08 | +14 | +4.6 |
| RUN DOWN | 133 | 131 | 3 | 0.08 | +46 | +15.5 |
| SAFER THAN THE JOB | 3 | 3 | 3 | 0.08 | +113 | +37.8 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +70 | +34.8 |
| CHARGE NOT DECLARED | 2 | 2 | 2 | 0.06 | -78 | -39.1 |
| EDGE GIVE GROUND | 7 | 7 | 2 | 0.06 | +16 | +7.8 |
| FALL BACK GOOD ORDER | 152 | 150 | 2 | 0.06 | +30 | +15.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| REFORMS TO MEET IT | 98 | 89 | 2 | 0.06 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 54 | 54 | 2 | 0.06 | +0 | +0.0 |
| SET UP TOGETHER | 14 | 10 | 2 | 0.06 | +34 | +17.1 |
| WHOLE FIGHT | 8 | 8 | 2 | 0.06 | +30 | +14.9 |
| BEST FACING | 1 | 1 | 1 | 0.03 | +58 | +58.3 |
| BEST OVERALL | 1 | 1 | 1 | 0.03 | +26 | +25.5 |
| BLOWS WHERE AIMED | 21 | 21 | 1 | 0.03 | +132 | +131.9 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -41 | -41.3 |
| CHARGER SLAIN LOST | 17 | 16 | 1 | 0.03 | +137 | +136.6 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +32 | +31.5 |
| FACES THE THREAT | 1 | 1 | 1 | 0.03 | +58 | +58.3 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +18 | +17.7 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +14 | +14.0 |
| FRIEND SHOOTS FIRST | 28 | 26 | 1 | 0.03 | +1 | +1.2 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.03 | +29 | +29.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +41 | +41.4 |
| SPELLS IN THE FIGHT | 36 | 35 | 1 | 0.03 | +1 | +0.8 |
| STAND AND SHOOT | 25 | 25 | 1 | 0.03 | +4 | +3.6 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -16 | -15.9 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| BACKUP TARGETS | 11 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 63 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 139 | 129 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 75 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 48 | 48 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 19 | 19 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 323 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 16 | 15 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 59 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 200 | 193 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 346 | 334 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 292 | 267 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 230 | 216 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 109 | 109 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 273 | 259 | 0 | 0.00 | - | - |
| HOLD ODDS | 1150 | 1146 | 0 | 0.00 | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 171 | 169 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 16 | 16 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LONG SHOT | 13 | 13 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 117 | 116 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 38 | 38 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 61 | 59 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 317 | 228 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 9 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 16 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 30 | trace | - | - | - | - |
| MOVE SPELL SPOT | 31 | not checked | - | - | - | - |
| NO LATE CUT | 58 | 56 | 0 | 0.00 | - | - |
| NOT TURNED | 11 | 11 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 30 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 302 | 295 | 0 | 0.00 | - | - |
| ONE ROUTE | 61 | 59 | 0 | 0.00 | - | - |
| OPENS A LANE | 7 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 2879 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 16 | 16 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 61 | 59 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 24 | 22 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 14 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 16 | 16 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 141 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 609 | 571 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 78 | 74 | 0 | 0.00 | - | - |
| STANDS STILL | 2654 | 2577 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 28 | 27 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 110 | not checked | - | - | - | - |
| THE PROMISE ADDS | 9 | 7 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2302 | not checked | - | - | - | - |
| WAITS AGAIN | 109 | 99 | 0 | 0.00 | - | - |
| WIDER SPREAD | 121 | 118 | 0 | 0.00 | - | - |

### Off best figure: base-s1-882d875-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.78 | 2.94 | 91.6 |
| JOB FIRST | gate | 2.47 | 2.67 | 39.5 |
| ARMY TABLE | rule | 1.28 | 1.42 | 53.5 |
| HOLDER ASSIGNMENT | rule | 0.50 | 0.72 | 27.5 |
| NO REASON | gate | 0.50 | 0.61 | 35.1 |
| CHARGE NOW FIRST | rule | 0.56 | 0.22 | 88.0 |
| JOINT CHARGE NOW | rule | 0.31 | 0.33 | 65.9 |
| ONE PROMISE A TARGET | rule | 0.17 | 0.08 | 105.4 |
| PROMISE SHOT AWAY | rule | 0.25 | - | 29.3 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 18.0 |
| BEST PRIZE | rule | 0.06 | 0.14 | 82.5 |
| CHAFF PASSED | rule | 0.17 | 0.03 | 4.9 |
| WAR ENGINE JOBS | rule | 0.17 | 0.03 | 77.6 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 2.1 |
| MARCH OF THE TABLE | rule | 0.08 | 0.08 | 107.7 |
| DEPLOY BY FIGURES | rule | - | 0.14 | 10.3 |
| PROMISE KNOWS THE FIGHT | rule | 0.06 | 0.08 | 9.7 |
| PROMISE READS THE TABLE | rule | 0.11 | 0.03 | 57.1 |
| SUPPORT NARROWED | rule | 0.14 | - | 36.2 |
| WHO GETS IN | rule | 0.08 | 0.06 | 51.5 |
| CANNON PLANNED TARGET | rule | 0.11 | - | 45.3 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | 0.06 | 2.5 |
| PURSUES BIG PREY | rule | 0.08 | 0.03 | 44.2 |
| SET UP BY THE SET | rule | - | 0.11 | 110.9 |
| FALLBACK | gate | 0.03 | 0.06 | 38.6 |
| TURN GATE | gate | - | 0.08 | 21.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 31.7 |
| CHARGE NOT DECLARED | rule | 0.03 | 0.03 | 39.1 |
| CATCH ODDS | rule | 0.03 | - | 41.3 |
| PATHS CROSS | rule | - | 0.03 | 117.9 |
| REDIRECT WEIGHED | rule | - | 0.03 | 17.1 |
| STANDS TO CAST | rule | 0.03 | - | 15.9 |
| WHO HITS BACK | rule | 0.03 | - | 2.4 |

### Plans: base-s1-882d875-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.1 | 62% | 400 | 208 | 52% |
| Mine | join | 0.5 | 94% | 15 | 0 | 0% |
| Mine | move | 28.1 | 96% | 1531 | 0 | 0% |
| Mine | shoot | 9.1 | 50% | 433 | 508 | 117% |
| Mine | support | 0.3 | 67% | 0 | 0 | - |
| Opponent | charge | 2.7 | 65% | 486 | 311 | 64% |
| Opponent | join | 1.1 | 98% | 51 | 0 | 0% |
| Opponent | move | 31.7 | 94% | 1455 | 0 | 0% |
| Opponent | shoot | 3.2 | 42% | 184 | 165 | 90% |
| Opponent | support | 1.0 | 76% | 7 | 0 | 0% |

### Packages: hunt the guns, base-s1-882d875-p5

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 490 | 471 | 100% | 30 |
| Opponent | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 290 | 249 | 100% | 101 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 490 | 471 | 100% | 74 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 74 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 248 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 79 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 290 | 249 | 100% | 61 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 121 |

### Battle groups: base-s1-882d875-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 19% | 75% | 8% | 0% | 18% | 0% | 9% | 73% | 0% |
| Opponent | REDIRECT COUNTER | 2.8 | 18% | 67% | 6% | 0% | 35% | 0% | 18% | 41% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s1-882d875-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Mine | Chaff | 31 | 60 (31) | 1 | 59 | 35 | 48% | 2.9 | 35 (10) | 86 (16) | 30 (5) | 79 (24) | 0 (7) |
| Mine | Character | 121 | 37 (121) | 37 | 0 | 34 | 25% | 2.3 | 41 (45) | 45 (48) | 20 (14) | 34 (64) | 48 (43) |
| Mine | Clean-up | 20 | 41 (20) | 25 | 16 | 35 | 45% | 3.2 | 28 (7) | 57 (10) | 0 (3) | 54 (14) | 6 (6) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.0 | - | 0 (4) | - | 0 (4) | - |
| Mine | Fast Hammer | 53 | 38 (53) | 19 | 19 | 32 | 30% | 2.5 | 18 (21) | 51 (21) | 58 (11) | 40 (35) | 35 (18) |
| Mine | Hammer | 56 | 21 (56) | 7 | 14 | 37 | 23% | 2.4 | 15 (21) | 25 (27) | 25 (8) | 27 (33) | 15 (23) |
| Mine | Holder | 21 | 13 (21) | 0 | 13 | 27 | 67% | 3.7 | 0 (7) | 33 (9) | 0 (4) | 0 (11) | 31 (9) |
| Mine | Shooter | 40 | 43 (40) | 10 | 33 | 31 | 2% | 1.9 | 66 (13) | 40 (21) | 12 (6) | 55 (29) | 17 (11) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 58 | 50 (58) | 50 | 0 | 32 | 7% | 1.4 | 80 (21) | 35 (30) | 17 (7) | 33 (9) | 54 (49) |
| Mine | Wizard | 19 | 3 (19) | 3 | 0 | 58 | 21% | 2.2 | 0 (5) | 0 (8) | - | 0 (5) | 0 (8) |
| Opponent | Chaff | 71 | 80 (71) | 5 | 75 | 41 | 65% | 2.2 | 68 (27) | 130 (24) | 15 (20) | 98 (56) | 0 (15) |
| Opponent | Character | 101 | 50 (101) | 50 | 0 | 20 | 29% | 2.2 | 45 (39) | 70 (37) | 44 (14) | 42 (50) | 67 (40) |
| Opponent | Clean-up | 27 | 31 (27) | 17 | 14 | 19 | 67% | 3.3 | 17 (11) | 50 (13) | 0 (3) | 32 (14) | 29 (13) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 46 | 18 (46) | 7 | 12 | 28 | 43% | 2.8 | 13 (19) | 16 (17) | 36 (10) | 26 (23) | 11 (23) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Hammer | 52 | 44 (52) | 31 | 13 | 27 | 37% | 3.1 | 23 (18) | 64 (27) | 5 (7) | 60 (36) | 10 (16) |
| Opponent | Holder | 31 | 84 (31) | 14 | 70 | 18 | 68% | 2.8 | 103 (5) | 109 (16) | 30 (6) | 98 (16) | 85 (11) |
| Opponent | Shooter | 28 | 39 (28) | 18 | 21 | 53 | 14% | 1.7 | 4 (6) | 39 (17) | 74 (5) | 12 (14) | 65 (14) |
| Opponent | Support | 4 | 44 (4) | 44 | 0 | 0 | 75% | 4.0 | 0 (1) | 0 (2) | 134 (1) | 0 (1) | 53 (3) |
| Opponent | War machine | 14 | 66 (14) | 66 | 0 | 37 | 0% | 1.2 | 0 (2) | 107 (8) | 22 (4) | 83 (5) | 57 (9) |
| Opponent | Wizard | 23 | 2 (23) | 2 | 0 | 36 | 17% | 2.4 | 0 (13) | 11 (5) | 0 (2) | 0 (8) | 4 (12) |

### Charged fights: base-s1-882d875-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 112 | 0 | 0.5 | 1.5 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | +0 | +0 |
| Mine | Chaos Dwarfs | 4 | 176 | 444 | 2.2 | 1.1 | 197 | 0 | +197 | 5 of 9 | 7 of 9 | +476 | +162 |
| Mine | Dwarfen Mountain Holds | 4 | 502 | 24 | 1.2 | 1.2 | 20 | 19 | +1 | 1 of 5 | 4 of 5 | +0 | +1 |
| Mine | Empire of Man | 5 | 287 | 9 | 0.8 | 1.5 | 11 | 0 | +11 | 1 of 4 | 2 of 4 | +0 | +22 |
| Mine | Grand Cathay | 4 | 278 | 108 | 2.2 | 1.0 | 48 | 26 | +22 | 3 of 9 | 5 of 9 | - | +22 |
| Mine | High Elf Realms | 4 | 118 | 568 | 3.5 | 1.0 | 162 | 43 | +120 | 6 of 14 | 11 of 14 | - | +120 |
| Mine | Kingdom of Bretonnia | 1 | 75 | 483 | 3.0 | 1.0 | 161 | 0 | +161 | 1 of 3 | 3 of 3 | - | +161 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 45 | 4.0 | 1.0 | 11 | 101 | -90 | 2 of 4 | 1 of 4 | - | -90 |
| Mine | Skaven | 2 | 178 | 22 | 1.5 | 1.0 | 15 | 0 | +15 | 0 of 3 | 3 of 3 | - | +15 |
| Mine | Tomb Kings of Khemri | 1 | 146 | 937 | 4.0 | 1.5 | 234 | 98 | +137 | 1 of 4 | 3 of 4 | +101 | +172 |
| Mine | Vampire Counts | 3 | 0 | 510 | 3.7 | 1.2 | 139 | 0 | +139 | 2 of 11 | 11 of 11 | +171 | +132 |
| Mine | Warriors of Chaos | 1 | 0 | 170 | 2.0 | 1.0 | 85 | 0 | +85 | 1 of 2 | 1 of 2 | - | +85 |
| **Mine** | all armies | 35 | 193 | 224 | 2.0 | 1.1 | 110 | 24 | +86 | 26 of 71 | 52 of 71 | +113 | +82 |
| Opponent | Chaos Dwarfs | 2 | 54 | 536 | 2.5 | 1.2 | 214 | 0 | +214 | 3 of 5 | 3 of 5 | +902 | +42 |
| Opponent | Dwarfen Mountain Holds | 1 | 420 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 255 | 190 | 2.0 | 1.0 | 95 | 0 | +95 | 0 of 2 | 2 of 2 | - | +95 |
| Opponent | High Elf Realms | 2 | 85 | 495 | 3.0 | 1.0 | 165 | 0 | +165 | 5 of 6 | 5 of 6 | - | +165 |
| Opponent | Kingdom of Bretonnia | 2 | 396 | 62 | 1.0 | 1.0 | 62 | 0 | +62 | 1 of 2 | 2 of 2 | - | +62 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 526 | 2.0 | 1.0 | 263 | 0 | +263 | 1 of 2 | 1 of 2 | - | +263 |
| Opponent | Skaven | 4 | 21 | 91 | 1.2 | 1.6 | 73 | 135 | -62 | 3 of 5 | 4 of 5 | -20 | -91 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 740 | 5.0 | 1.0 | 148 | 0 | +148 | 3 of 5 | 5 of 5 | - | +148 |
| Opponent | Vampire Counts | 9 | 23 | 639 | 3.6 | 1.1 | 180 | 8 | +172 | 15 of 32 | 21 of 32 | +218 | +167 |
| Opponent | Warriors of Chaos | 5 | 50 | 275 | 1.0 | 1.2 | 275 | 0 | +275 | 4 of 5 | 4 of 5 | +210 | +291 |
| Opponent | Wood Elf Realms | 6 | 91 | 308 | 2.8 | 1.0 | 109 | 49 | +59 | 5 of 17 | 10 of 17 | - | +59 |
| **Opponent** | all armies | 35 | 81 | 371 | 2.3 | 1.1 | 160 | 22 | +138 | 40 of 81 | 57 of 81 | +247 | +128 |

### Effective charges: base-s1-882d875-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 9 | 0 | 0 | 3 (net +339) | 2 (net +252) | 1 (net +60) | 3 (net +65) | 0 | 33% (3 of 9) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 1 (net -95) | 0 | 1 (net +98) | 0 | 1 (net +0) | 2 | 0% (0 of 3) |
| Mine | Empire of Man | 4 | 0 | 0 | 3 (net +15) | 0 | 0 | 0 | 1 | 100% (3 of 3) |
| Mine | Grand Cathay | 9 | 1 (net +0) | 0 | 3 (net +0) | 1 (net +144) | 1 (net +0) | 3 (net +18) | 0 | 33% (3 of 9) |
| Mine | High Elf Realms | 14 | 1 (net +0) | 0 | 4 (net -13) | 1 (net +664) | 1 (net +234) | 4 (net +73) | 3 | 36% (4 of 11) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +233) | 0 | 1 (net +190) | 0 | 1 (net +60) | 0 | 0 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 1 (net -350) | 0 | 0 | 0 | 1 (net +45) | 0 | 2 | 0% (0 of 2) |
| Mine | Skaven | 3 | 0 | 0 | 1 (net +0) | 1 (net +45) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 1 (net -56) | 0 | 0 | 2 (net +247) | 1 | 33% (1 of 3) |
| Mine | Vampire Counts | 11 | 0 | 0 | 1 (net +608) | 3 (net +79) | 2 (net +42) | 3 (net +0) | 2 | 11% (1 of 9) |
| Mine | Warriors of Chaos | 2 | 1 (net +170) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Chaos Dwarfs | 5 | 2 (net +0) | 0 | 0 | 1 (net +902) | 2 (net +84) | 0 | 0 | 0% (0 of 5) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 0 | 1 (net +95) | 1 (net +95) | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 6 | 0 | 0 | 0 | 0 | 0 | 3 (net +80) | 3 | 0% (0 of 3) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +62) | 0 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 2 | 1 (net +526) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Skaven | 5 | 3 (net -153) | 0 | 1 (net +55) | 0 | 0 | 1 (net +91) | 0 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 2 (net +310) | 1 (net +0) | 1 (net +120) | 1 (net +0) | 0 | 40% (2 of 5) |
| Opponent | Vampire Counts | 32 | 11 (net +234) | 1 (net +285) | 6 (net +198) | 4 (net +95) | 3 (net +53) | 6 (net +154) | 1 | 19% (6 of 31) |
| Opponent | Warriors of Chaos | 5 | 0 | 0 | 1 (net +0) | 0 | 2 (net +178) | 1 (net +540) | 1 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 17 | 2 (net -62) | 0 | 1 (net +0) | 0 | 0 | 4 (net +143) | 10 | 14% (1 of 7) |

### Charged fights, damage counted: base-s1-882d875-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 300 | 403 | +8 | 67 | 80 | -12 | -4.1 |
| Mine | 50-54% | 1 | 50 | 334 | -95 | 48 | 95 | -47 | -94.6 |
| Mine | Effective (55-75%) | 17 | 430 | 231 | +103 | 189 | 79 | +110 | +25.6 |
| Mine | 76-89% | 9 | 251 | 216 | +188 | 228 | 1 | +227 | +90.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 236 | 186 | +58 | 96 | 21 | +75 | +31.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 336 | 60 | +69 | 69 | 0 | +69 | +20.6 |
| Mine | No odds | 12 | 293 | 153 | +99 | 115 | 14 | +100 | +34.3 |
| Mine | All fights | 71 | 308 | 206 | +86 | 132 | 36 | +96 | +31.2 |
| Opponent | Long shot (under 50%) | 19 | 303 | 249 | +132 | 195 | 64 | +131 | +43.3 |
| Opponent | 50-54% | 1 | 500 | 235 | +285 | 285 | 0 | +285 | +57.0 |
| Opponent | Effective (55-75%) | 11 | 274 | 248 | +169 | 209 | 42 | +167 | +60.9 |
| Opponent | 76-89% | 7 | 390 | 246 | +197 | 197 | 0 | +197 | +50.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 329 | 197 | +138 | 166 | 36 | +130 | +39.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 474 | 105 | +100 | 100 | 2 | +98 | +20.7 |
| Opponent | No odds | 16 | 155 | 220 | +112 | 167 | 70 | +97 | +62.6 |
| Opponent | All fights | 81 | 304 | 215 | +138 | 176 | 43 | +133 | +43.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s1-882d875-p5 | move | 204 | 41 (20%) | 29 (14%) | 24 (12%) | 139 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0104, L0120, L2426, L2533, L2733 |
| Charmed Shield | Opponent | L0526, L0825, L1024, L1226, L1627, L1725, L1825, L1925, L2027, L2426 |
| Clockwork Compass | Mine | L1226 |
| Elixir of Power | Mine | L1116, L1133, L1925 |
| Elixir of Power | Opponent | L0719 |
| Fistful of Laurels | Mine | L1825 |
| Horn of the Wild Hunt | Opponent | L1133, L1433, L2233, L2533, L2733 |
| Invocation of Nehek | Mine | L2426, L2533, L2733 |
| Invocation of Nehek | Opponent | L0825, L1024, L1627, L1725, L1825, L1925, L2027 |
| Opal Amulet | Mine | L1416, L1433 |
| Opal Amulet | Opponent | L0614 |
| Periapt of Soul Exchange | Mine | L2027, L2129 |
| Periapt of Soul Exchange | Opponent | L0120, L0220, L0321, L1321 |
| Ring of Doom | Mine | L0204, L0220, L1116, L1133, L1226, L1529 |
| Ring of Doom | Opponent | L0915, L1133, L1433, L2233, L2533, L2733, L3031 |
| Ring of Jet | Mine | L1024, L1116, L1133, L1226 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Mine | L1321 |
| Storm Daemon (Renegade 2.0) | Mine | L2129 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321, L1321 |
| Twice-Blessed Armour | Mine | L0719, L0735, L1024 |
| Twice-Blessed Armour | Opponent | L0407, L0510 |
| Witch Hunter's Ward | Mine | L0719, L0735, L0825 |
| Witch Hunter's Ward | Opponent | L0407 |

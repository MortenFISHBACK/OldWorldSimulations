# Doctrine scorecard: base-s2-882d875-p8

### Scorecard: base-s2-882d875-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0116 | 2 | 2 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 322 |
| L0116 | 2 | 2 | Opponent | - | - | 4 | 2 | 5 | 1 | 0 | 0 | 100 |
| L0132 | 6 | 2 | Mine | no | 8 | - | 0 | 1 | 1 | 0 | 0 | 77 |
| L0132 | 6 | 2 | Opponent | no | 10 | 2 | 3 | 3 | 0 | 0 | 0 | 340 |
| L0216 | 6 | 2 | Mine | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 255 |
| L0216 | 6 | 2 | Opponent | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 200 |
| L0233 | 5 | 2 | Mine | yes | - | - | 0 | 7 | 0 | 0 | 0 | 0 |
| L0233 | 5 | 2 | Opponent | yes | - | 4 | 1 | 5 | 0 | 0 | 0 | 213 |
| L0317 | 5 | 2 | Mine | no | - | 5 | 1 | 3 | 0 | 0 | 0 | 715 |
| L0317 | 5 | 2 | Opponent | yes | - | 4 | 1 | 3 | 0 | 0 | 0 | 175 |
| L0334 | 4 | 2 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 85 |
| L0334 | 4 | 2 | Opponent | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0419 | 5 | 2 | Mine | yes | - | 2 | 6 | 4 | 0 | 0 | 0 | 244 |
| L0419 | 5 | 2 | Opponent | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0506 | 2 | 2 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 475 |
| L0506 | 2 | 2 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 773 |
| L0522 | 6 | 2 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 393 |
| L0522 | 6 | 2 | Opponent | no | 7 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0610 | 4 | 2 | Mine | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 836 |
| L0610 | 4 | 2 | Opponent | no | 0 | 5 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0626 | 2 | 2 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 798 |
| L0626 | 2 | 2 | Opponent | - | - | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0715 | 1 | 2 | Mine | no | 2 | 2 | 0 | 1 | 1 | 0 | 0 | 125 |
| L0715 | 1 | 2 | Opponent | no | 14 | 2 | 5 | 2 | 0 | 0 | 0 | 607 |
| L0731 | 5 | 2 | Mine | yes | - | 4 | 1 | 0 | 0 | 0 | 0 | 391 |
| L0731 | 5 | 2 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 340 |
| L0821 | 5 | 2 | Mine | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 452 |
| L0821 | 5 | 2 | Opponent | yes | - | - | 2 | 7 | 2 | 0 | 0 | 355 |
| L0911 | 5 | 2 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 208 |
| L0911 | 5 | 2 | Opponent | no | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0928 | 4 | 2 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 1061 |
| L0928 | 4 | 2 | Opponent | no | 5 | - | 0 | 3 | 0 | 0 | 0 | 111 |
| L1019 | 5 | 2 | Mine | yes | - | 6 | 2 | 1 | 1 | 0 | 0 | 165 |
| L1019 | 5 | 2 | Opponent | yes | - | 1 | 1 | 5 | 1 | 0 | 0 | 0 |
| L1112 | 2 | 2 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L1112 | 2 | 2 | Opponent | - | - | 4 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1128 | 6 | 2 | Mine | no | 14 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1128 | 6 | 2 | Opponent | no | 12 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1222 | 4 | 2 | Mine | no | 5 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1222 | 4 | 2 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1317 | 3 | 2 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 177 |
| L1317 | 3 | 2 | Opponent | yes | 9 | 2 | 2 | 1 | 0 | 0 | 0 | 175 |
| L1333 | 1 | 2 | Mine | yes | 10 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1333 | 1 | 2 | Opponent | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 252 |
| L1429 | 1 | 2 | Mine | no | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1429 | 1 | 2 | Opponent | no | 5 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L1525 | 1 | 2 | Mine | yes | 14 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1525 | 1 | 2 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1623 | 3 | 2 | Mine | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1623 | 3 | 2 | Opponent | no | 1 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1721 | 5 | 2 | Mine | yes | - | 1 | 3 | 0 | 0 | 0 | 0 | 175 |
| L1721 | 5 | 2 | Opponent | no | - | - | 0 | 6 | 1 | 0 | 0 | 355 |
| L1821 | 3 | 2 | Mine | yes | 0 | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| L1821 | 3 | 2 | Opponent | no | 0 | - | 0 | 6 | 0 | 0 | 0 | 145 |
| L1921 | 1 | 2 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1921 | 1 | 2 | Opponent | no | 0 | - | 1 | 6 | 0 | 0 | 0 | 145 |
| L2023 | 1 | 2 | Mine | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 612 |
| L2023 | 1 | 2 | Opponent | no | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 70 |
| L2125 | 1 | 2 | Mine | no | 14 | - | 2 | 1 | 0 | 0 | 0 | 555 |
| L2125 | 1 | 2 | Opponent | no | 5 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L2229 | 3 | 2 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 199 |
| L2229 | 3 | 2 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2333 | 5 | 2 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2333 | 5 | 2 | Opponent | no | - | 1 | 5 | 4 | 0 | 0 | 0 | 19 |
| L2529 | 3 | 2 | Mine | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2529 | 3 | 2 | Opponent | no | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 170 |
| L2728 | 4 | 2 | Mine | no | 3 | 3 | 2 | 3 | 0 | 0 | 0 | 372 |
| L2728 | 4 | 2 | Opponent | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 41 |
| L2932 | 4 | 2 | Mine | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 650 |
| L2932 | 4 | 2 | Opponent | no | 0 | 1 | 7 | 3 | 0 | 0 | 0 | 170 |
| L3334 | 4 | 2 | Mine | no | 1 | 1 | 1 | 4 | 0 | 0 | 0 | 613 |
| L3334 | 4 | 2 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 31% | 3.6 | 2.5 | 1.9 | 1.8 | 0.2 | 0.0 | 0.0 | 276.5 |
| **Average** | | | Opponent | 22% | 3.7 | 2.3 | 2.6 | 2.8 | 0.3 | 0.0 | 0.0 | 136.8 |

### KPIs: base-s2-882d875-p8

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (37 of 149) | 1% (2 of 154) | 13% (39 of 303) |
| Winner chose to follow up after the loser gave ground |  | 84% (27 of 32); on the table 91% | 91% (29 of 32); on the table 94% | 88% (56 of 64); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 71% (5 of 7); on the table 71% | 100% (9 of 9); on the table 100% | 88% (14 of 16); on the table 88% |
| Winner chose to pursue after the loser fled |  | 50% (8 of 16); on the table 56% | 75% (12 of 16); on the table 81% | 62% (20 of 32); on the table 69% |
| Winner chose to follow up or pursue (all three) |  | 73% (40 of 55); on the table 78% | 88% (50 of 57); on the table 91% | 80% (90 of 112); on the table 85% |
| Magic missiles tried each own turn | 50%+ | 28% (86 of 308) | 29% (44 of 154) | 28% (130 of 462) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 35% (86 of 244) | 37% (44 of 119) | 36% (130 of 363) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 37% (11 of 30) | 60% (49 of 82) | 54% (60 of 112) |
| Points that never fought | lower | 48% (33168 of 69031) | 49% (35626 of 71983) | 49% (68794 of 141014) |
|   infantry points that never fought | lower | 64% (9990 of 15539) | 73% (10442 of 14377) | 68% (20432 of 29916) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (172 of 273) | 61% (167 of 275) | 62% (339 of 548) |
| Bound items with a magic missile used (at least once a game) |  | 78% (18 of 23); 1.2 uses a game | 90% (18 of 20); 1.5 uses a game | 84% (36 of 43); 1.3 uses a game |
| Bound items with another spell used |  | 60% (9 of 15); 0.5 uses a game | 100% (1 of 1); 0.1 uses a game | 62% (10 of 16); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 56% (9 of 16); 0.2 uses a game | 53% (19 of 36); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (32993 of 57598) | 52% (32563 of 63116) | 54% (65556 of 120714) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.0 (49%) | 1.0 (34%) | 4.1 (44%) |
| MARCHED: its unit marched | 1.2 (19%) | 0.8 (27%) | 2.0 (22%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (3%) | 0.1 (2%) |
| IN COMBAT: engaged in combat | 0.7 (11%) | 0.6 (18%) | 1.2 (13%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| GONE: slain | 0.7 (11%) | 0.3 (11%) | 1.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (7%) | 0.1 (3%) | 0.5 (5%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.3 | 1.7 | 3.6 | 0.8 | 1.0 |
| not cast | 4.4 | 2.5 | 2.0 | 9.2 | 2.1 | 21.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (56%) | 0.1 (6%) | 4.1 (44%) | 0.5 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (22%) | 0.4 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.0 (1%) | 0.2 (10%) | 1.2 (13%) | 0.2 (9%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.0 (0%) | 0.1 (4%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.6 (15%) | 0.6 (23%) | 0.1 (7%) | 1.0 (11%) | 0.4 (22%) | 1.8 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (11%) | 0.2 (8%) | 0.3 (15%) | 0.5 (5%) | 0.1 (5%) | 1.0 (4%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.4 (18%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (58%) | 0.2 (7%) | 1.2 (58%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.3 a game | 0.9 a game |
| stood (cast and not dispelled) | 63% (33 of 52) | 57% (4 of 7) | 63% (37 of 59) |
| the unit moved after it | 48% (16 of 33) | 100% (4 of 4) | 54% (20 of 37) |
| it charged on its next turn | 0% (0 of 33) | 0% (0 of 4) | 0% (0 of 37) |
| the enemy charged it first | 12% (4 of 33) | 0% (0 of 4) | 11% (4 of 37) |
| it fought by the end of its next turn | 9% (3 of 33) | 0% (0 of 4) | 8% (3 of 37) |
| it moved out of a charge the enemy had planned (not charged first) | 3% (1 of 33) | 25% (1 of 4) | 5% (2 of 37) |
| none of these (no charge, no fight, no charge escaped) | 82% (27 of 33) | 75% (3 of 4) | 81% (30 of 37) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (550 of 921) | 50% (344 of 685) | 56% (894 of 1606) |
|   cavalry | 63% (48 of 76) | 49% (59 of 121) | 54% (107 of 197) |
|   character | 54% (63 of 117) | 24% (27 of 113) | 39% (90 of 230) |
|   chariot | 69% (68 of 98) | 75% (33 of 44) | 71% (101 of 142) |
|   infantry | 51% (146 of 288) | 59% (176 of 300) | 55% (322 of 588) |
|   monster | 51% (24 of 47) | 23% (5 of 22) | 42% (29 of 69) |
|   war machine | 68% (201 of 295) | 52% (44 of 85) | 64% (245 of 380) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.4 (14%) | 0.8 (9%) | 2.2 (11%) |
| CHARGED: it charged | 0.9 (9%) | 1.6 (17%) | 2.6 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.4 (4%) | 0.4 (4%) | 0.8 (4%) |
| MOVED: a war machine that moved | 1.8 (18%) | 0.6 (6%) | 2.4 (12%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 4.0 (39%) | 4.0 (42%) | 8.0 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.3 (3%) | 0.6 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (11%) | 1.4 (15%) | 2.5 (12%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| OTHER BAR | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.2 | 0.9 | 81% | 6.0 pts | 26 pts |
| character | 3.0 | 1.1 | 73% | 9.3 pts | 28 pts |
| chariot | 2.8 | 0.9 | 78% | 9.2 pts | 26 pts |
| infantry | 13.3 | 5.1 | 75% | 9.4 pts | 126 pts |
| monster | 1.0 | 0.3 | 81% | 8.4 pts | 8 pts |
| war machine | 6.9 | 5.7 | 62% | 24.4 pts | 168 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 4.0 | 3.4 |
| Charges that made contact a game | 2.0 | 2.7 | 2.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.36 contact (22 units) | 0.88 declared, 0.75 contact (16 units) | 0.66 declared, 0.53 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.43 declared, 0.29 contact (7 units) | 1.50 declared, 1.00 contact (8 units) | 1.00 declared, 0.67 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.35 declared, 0.24 contact (255 units) | 0.41 declared, 0.27 contact (289 units) | 0.38 declared, 0.26 contact (544 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (33 of 53) | 71% (15 of 21) | 42% (5 of 12) | 62% (53 of 86) |
| Character in a unit | 83% (38 of 46) | 59% (10 of 17) | 50% (3 of 6) | 74% (51 of 69) |
| Character on its own | 83% (24 of 29) | 59% (20 of 34) | 25% (18 of 71) | 46% (62 of 134) |
| Chariot | 68% (13 of 19) | 56% (5 of 9) | - | 64% (18 of 28) |
| Infantry | 62% (45 of 73) | 57% (24 of 42) | 50% (1 of 2) | 60% (70 of 117) |
| Monster | 76% (28 of 37) | 62% (5 of 8) | - | 73% (33 of 45) |
| Monstrous | 90% (9 of 10) | 64% (7 of 11) | - | 76% (16 of 21) |
| War Machines | 74% (34 of 46) | 100% (2 of 2) | - | 75% (36 of 48) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | - | 24% (24 of 102) | 67% | 77% (17 of 22) | 67% (4 of 6); 3.5 uses a game | 100% (2 of 2); 1.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 3 | 60% (3 of 5); on the table 60% | 38% (9 of 24) | 51% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game |
| Dwarfen Mountain Holds | 5 | - | - | 66% | 52% (21 of 40) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 43% (3 of 7); on the table 57% | 17% (5 of 30) | 65% | 80% (43 of 54) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 33% (1 of 3); 0.2 uses a game |
| Grand Cathay | 7 | 92% (11 of 12); on the table 92% | 27% (41 of 150) | 57% | 55% (32 of 58) | 88% (14 of 16); 4.9 uses a game | 100% (2 of 2); 0.4 uses a game | 29% (2 of 7); 0.3 uses a game |
| High Elf Realms | 5 | 88% (14 of 16); on the table 88% | 44% (8 of 18) | 38% | 36% (14 of 39) | 100% (6 of 6); 2.8 uses a game | 50% (5 of 10); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 86% (6 of 7); on the table 100% | - | 64% | 56% (10 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 3 | 100% (11 of 11); on the table 100% | - | 41% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | - | 32% | 43% (3 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | - | 38% (9 of 24) | 31% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 50% (4 of 8); on the table 75% | 19% (8 of 42) | 54% | 75% (39 of 52) | 60% (3 of 5); 1.5 uses a game | 0.0 uses a game | 100% (6 of 6); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 83% (10 of 12); on the table 83% | 0% (0 of 6) | 40% | 50% (15 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 50% (2 of 4); on the table 75% | 47% (17 of 36) | 30% | 69% (20 of 29) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 88% (21 of 24); on the table 88% | 33% (8 of 24) | 40% | 49% (37 of 76) | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 6 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 53% | 74% (40 of 54) | 88% (7 of 8); 3.2 uses a game | 0.0 uses a game | 0% (0 of 6); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s2-882d875-p8, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (28) | 57% (30) | 52% (58) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.69 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.06 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.47 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.03 | 0.00 | 0.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.03 | 0.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.28 | 0.31 | 0.58 |

### Quality by phase: base-s2-882d875-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 49% (45 of 91) | 50% (55 of 109) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (166 of 436) | 47% (69 of 147) |
| Strategy | Support requests answered (helper made contact too) | 33% (3 of 9) | 67% (2 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 80% (4 of 5) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 59% (10 of 17) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 28% (15 of 54) | 24% (10 of 41) |
| Strategy | Lone characters that fought | 69% (59 of 86) | 73% (59 of 81) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.8 | 2.8 |
| Movement | Points that never moved of their own | 276.5 | 136.8 |
| Movement | Fights charged into per game | 1.9 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 58, net +89 | 13 of 64, net +32 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 58, net +118 | 9 of 64, net +253 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 58, net +67 | 13 of 64, net +93 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 58, net +91 | 11 of 64, net +75 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (185 of 362) | 40% (134 of 336) |
| Shooting | Points destroyed by shooting units | 69.7 | 70.5 |
| Shooting | War machine shots | 5.6 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (73 of 201) | 11% (5 of 46) |
| Shooting | Points destroyed by war machines | 51.2 | 17.6 |
| Magic | Magic missiles cast | 1.6 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 27% (16 of 59) | 33% (12 of 36) |
| Magic | Wounds caused by magic missiles | 4.1 | 0.9 |
| Magic | Wounds caused by other spells | 1.4 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 114.6 | 21.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.5 / 0.3 / 0.1 | 1.8 / 0.2 / 0.4 / 0.4 |
| Combat | Points destroyed in combat | 214.5 | 307.4 |
| Combat | Points run down | 57.0 | 54.6 |
| Combat | Net points per charged fight, damage counted | +96 | +97 |
| Combat | Net per 100 charger points, damage counted | +31.7 | +28.8 |
| Combat | First round won (charged fights) | 83% | 79% |
| Combat | Net points per charged fight | +96 | +105 |
| Combat | Net points per supported fight / lone fight | +245 / +85 | +104 / +105 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 70 | 37 of 90 |
| Game | Points lost | 625.6 | 582.5 |
| Game | VP from objectives | 647.2 | 637.8 |
| Game | Lone holders (player turns) | 3.6 | 3.7 |

- Mine won / drew / lost: 14 / 6 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -27 VP
- The side that went first won 14 of 30 games with a winner
- Points traded per game (both sides' losses): 1208
- Games not ended: 0; findings 11, warnings 0

### Opponent rules: base-s2-882d875-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 2.9 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +21.6 | 0.0 | 6.2 | 0.1 | +26.8 | 0.0 | 14.4 |
| AFTERMATH WITH FRIENDS | 0.1 | +5.8 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 13.9 | +201.8 | 0.0 | 268.4 | 21.3 | +225.9 | 0.0 | 255.5 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 10.3 | 0.1 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.2 | +1.1 | 0.0 | 12.3 | 0.2 | +0.9 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.2 | +0.7 | 16.6 | 6.0 |
| BLOWS WHERE AIMED | 0.1 | -16.7 | 21.9 | 0.0 | 0.3 | -73.1 | 24.4 | 26.2 |
| BOMBING RUN | 0.1 | +4.3 | 6.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 7.7 | - | - | - | - |
| CANNON PLAN MISSED | 0.4 | +0.0 | 59.3 | 2.6 | - | - | - | - |
| CANNON PLANNED TARGET | 5.7 | +156.2 | 350.5 | 77.9 | 1.0 | +31.2 | 23.8 | 15.7 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | -1.7 | 8.6 | 0.0 |
| CAST JOB | 0.9 | +19.4 | 29.1 | 0.0 | 0.6 | +5.4 | 16.1 | 5.9 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +54.2 | 26.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 6.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.5 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +23.1 | 0.0 | 17.2 | 1.1 | +49.9 | 0.0 | 21.7 |
| CHAFF PASSED | 0.4 | -0.6 | 3.0 | 12.6 | 0.3 | -0.1 | 3.0 | 10.9 |
| CHAMPION KNOWS CHALLENGE | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | -2.4 | 0.0 | 0.0 |
| CHARACTER GUNS | 1.2 | +0.0 | 0.0 | 26.2 | 2.3 | +0.0 | 0.0 | 24.7 |
| CHARGE LIST READ AGAIN | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +2.9 | 5.2 | 0.0 |
| CHARGE LOSSES | 8.3 | -435.7 | 0.0 | 338.7 | 10.3 | -660.3 | 0.0 | 326.1 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 8.6 | 5.9 | 0.0 | +0.0 | 4.9 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 146.8 | 69.9 | 2.0 | +0.0 | 245.0 | 62.0 |
| CHARGER SLAIN LOST | 0.1 | -7.7 | 12.0 | 10.1 | 0.2 | -2.6 | 5.8 | 1.2 |
| COMBAT PIVOT | 0.3 | +0.0 | 10.6 | 34.3 | 0.3 | +0.0 | 16.5 | 13.7 |
| CONVEYANCE SEARCH | 1.2 | +116.4 | 22.2 | 22.2 | 0.2 | +14.0 | 0.0 | 6.5 |
| COVER ONCE | 5.2 | -379.5 | 0.0 | 140.5 | 3.8 | -277.8 | 0.0 | 97.1 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | -1.2 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.2 | -3.3 | 36.7 | 1.9 | 0.6 | +0.1 | 67.2 | 1.2 |
| DEPLOY BY FIGURES | 8.2 | +19.4 | 0.0 | 10.7 | 7.6 | +76.0 | 0.0 | 25.8 |
| EDGE GIVE GROUND | 0.2 | +8.0 | 20.5 | 12.3 | 0.3 | +4.9 | 24.2 | 7.4 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.0 | +0.6 | 0.0 | 2.4 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.9 | +14.1 | 171.8 | 50.7 | 2.4 | +4.3 | 263.7 | 43.7 |
| FALLBACK BY WORTH | 0.2 | +0.1 | 0.0 | 1.2 | 0.3 | +0.4 | 0.0 | 8.1 |
| FALLS SHORT | 4.4 | +73.4 | 0.0 | 103.6 | 14.5 | +195.1 | 0.0 | 173.7 |
| FEATURE BUFFS | 2.4 | +52.8 | 0.0 | 33.9 | 1.3 | +35.5 | 0.0 | 19.2 |
| FIGHT LIFT | - | - | - | - | 0.1 | +1.3 | 22.6 | 6.5 |
| FIGHT TO THE END | 0.4 | +4.3 | 44.1 | 30.0 | 0.7 | +37.4 | 101.4 | 37.6 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 2.2 | - | - | - | - |
| FIRE IN ORDER | 0.4 | +0.0 | 17.7 | 7.6 | 0.1 | +0.0 | 8.2 | 0.0 |
| FIVE ACTION | 87.4 | +5776.9 | 1670.6 | 1356.6 | 83.4 | +5011.9 | 546.5 | 1053.4 |
| FLANK NOT WEIGHED | 3.9 | +0.0 | 0.0 | 133.6 | 4.0 | +0.0 | 0.0 | 124.0 |
| FOCUS FIRE | 0.1 | +3.5 | 8.3 | 1.7 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.4 | +76.2 | 0.0 | 0.0 | 0.7 | +153.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.8 | +215.3 | 242.0 | 81.4 | 3.4 | +292.9 | 313.7 | 77.0 |
| FRIEND SHOOTS FIRST | 0.6 | -14.3 | 9.2 | 6.2 | 0.2 | -2.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +5.6 | 0.0 | 0.0 | 0.0 | +2.3 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -8.5 | 30.5 | 7.1 | 0.2 | -1.7 | 7.6 | 0.0 |
| GUN FIGURES | 1.0 | +20.3 | 42.0 | 19.0 | 0.7 | +2.8 | 3.0 | 6.8 |
| GUN MASK | 0.9 | +33.9 | 0.0 | 22.7 | 0.7 | +32.6 | 0.0 | 4.4 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 11.5 | 1.1 | +0.0 | 0.0 | 7.5 |
| HE SHOOTS OR CHARGES | 2.3 | +0.0 | 0.0 | 135.6 | 3.4 | +0.0 | 0.0 | 94.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 12.3 | 7.2 | 0.0 | +0.0 | 9.6 | 0.0 |
| HIS CHARGE DENIED | 0.1 | +4.6 | 13.7 | 0.0 | 0.2 | +12.1 | 13.3 | 5.7 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 84.7 | 6.4 | +0.0 | 0.0 | 102.8 |
| HIS FIGHT TOGETHER | 1.2 | -83.9 | 0.0 | 123.4 | 1.3 | -18.5 | 0.0 | 102.3 |
| HIS LEGAL MOVES | 3.9 | +0.0 | 0.0 | 116.6 | 4.2 | +0.0 | 0.0 | 40.6 |
| HIS MOVE AND SHOT | 2.8 | -52.6 | 0.0 | 94.1 | 3.5 | -88.5 | 0.0 | 162.0 |
| HIS MOVE AS HE DECIDES | 37.9 | +13.1 | 632.2 | 0.0 | 33.6 | +13.7 | 530.6 | 0.0 |
| HIS MOVE WHY | 33.1 | +0.0 | 0.0 | 463.9 | 36.9 | +0.0 | 0.0 | 464.3 |
| HIS ONE MOVE | 17.7 | +32.5 | 0.0 | 167.8 | 19.1 | +48.9 | 2.5 | 158.5 |
| HIS ONE QUARTER | 3.5 | +0.0 | 0.0 | 28.2 | 3.8 | +0.0 | 0.0 | 131.7 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 51.6 | 1.2 | +0.0 | 0.0 | 2.2 |
| HIS RANDOM MOVE | 6.5 | +0.0 | 0.0 | 112.7 | 1.8 | +0.0 | 0.0 | 23.8 |
| HIS SHOT LIST | 30.2 | +864.6 | 0.0 | 544.2 | 47.4 | +2211.3 | 0.0 | 608.7 |
| HIS TURN DENIED | 1.0 | +19.1 | 101.9 | 26.4 | 1.8 | +52.7 | 187.6 | 43.6 |
| HOLD ODDS | 16.6 | +0.0 | 0.0 | 193.9 | 15.8 | +0.0 | 0.0 | 123.0 |
| HOLDER ASSIGNMENT | 9.1 | +919.0 | 0.0 | 87.3 | 9.7 | +921.7 | 0.0 | 58.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.2 | -88.7 | 200.2 | 60.3 | 3.1 | -160.9 | 296.4 | 68.3 |
| HORN WORTH | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +7.2 | 0.0 | 0.0 | 0.6 | +27.7 | 0.0 | 10.2 |
| HUNT KEPT | 0.0 | +0.0 | 5.9 | 0.0 | 0.0 | +0.0 | 3.1 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +4.5 | 3.1 | 0.8 |
| HUNT THE GUNS | 0.1 | +12.7 | 5.9 | 0.0 | 0.1 | +19.0 | 0.0 | 0.0 |
| IDLE COST | 4.1 | -51.6 | 0.0 | 90.4 | 10.8 | -175.0 | 0.0 | 136.0 |
| JOINT CHARGE NOW | 0.4 | +16.6 | 31.6 | 0.0 | 0.3 | +21.7 | 39.3 | 26.2 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.0 | -1.9 | 0.0 | 0.0 |
| JOINT ON THE TABLE | 0.0 | +0.8 | 6.2 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +1.5 | 0.0 | 6.6 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.2 | +0.0 | 0.0 | 12.3 | 2.8 | +0.0 | 0.0 | 11.9 |
| LANE BY FIGURES | 0.7 | +26.6 | 0.0 | 0.0 | 1.0 | +51.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.8 | +0.0 | 129.7 | 150.7 | 4.0 | +0.0 | 206.8 | 215.2 |
| LONE WIZARD KEPT IN | 0.6 | +42.2 | 0.0 | 0.0 | 0.4 | +31.0 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -1.7 | 5.8 | 0.0 | 0.2 | +0.2 | 3.5 | 0.0 |
| LOST AFTER ESCAPE | 1.2 | -2.1 | 127.7 | 14.5 | 1.4 | -8.1 | 170.1 | 23.7 |
| LOST CHARGE | - | - | - | - | 0.0 | -0.0 | 6.9 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -8.6 | 0.0 | 4.2 | 0.0 | -1.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +6.6 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| MANOEUVRE | 0.8 | +6.3 | 0.0 | 16.4 | 0.5 | +1.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.8 | 0.0 | 2.9 | 0.1 | +0.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.5 | +34.4 | 0.0 | 7.6 | 0.2 | +15.5 | 0.0 | 3.0 |
| MARCH CHECK | 0.5 | +18.7 | 0.0 | 14.1 | 0.6 | +31.4 | 0.0 | 13.2 |
| MARCH OF THE TABLE | 0.1 | +2.2 | 0.0 | 0.0 | 0.2 | +12.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.8 | +37.1 | 0.0 | 10.6 | 0.8 | +24.1 | 0.0 | 33.6 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 12.3 | 0.9 | +0.0 | 0.0 | 5.9 |
| MAX FOR POSITIONING | 2.1 | +37.5 | 0.0 | 26.5 | 2.6 | +50.8 | 0.0 | 45.1 |
| MISSILES IN THE MOVE | 3.9 | +132.6 | 0.0 | 89.6 | 2.9 | +34.0 | 0.0 | 80.6 |
| MISSILES NEXT TURN | 5.2 | +99.9 | 0.0 | 100.2 | 4.1 | +34.1 | 0.0 | 115.4 |
| MISSILES ON ONE TARGET | 0.2 | -13.9 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | 0.4 | +62.0 | 0.0 | 1.7 | 0.1 | +39.8 | 0.0 | 3.3 |
| MOVE ORDER | 1.4 | +0.0 | 28.8 | 28.0 | 2.3 | +0.0 | 20.2 | 25.4 |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.1 | -1.0 | 0.0 | 9.9 | - | - | - | - |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 11.1 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.1 | +556.4 | 0.0 | 138.8 | 5.6 | +606.3 | 0.0 | 66.8 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.8 | +289.9 | 0.0 | 100.9 | 5.9 | +253.0 | 0.0 | 74.0 |
| NEXT CHARGE BY LIST | 4.9 | -222.5 | 31.4 | 130.5 | 4.7 | -131.8 | 30.3 | 61.3 |
| NEXT OBJECTIVE NEARER | 0.1 | -3.6 | 0.0 | 0.0 | 0.1 | -7.0 | 12.3 | 0.0 |
| NO DOUBLE ROUNDS | 2.1 | -110.4 | 207.5 | 60.4 | 2.5 | -121.2 | 244.4 | 71.0 |
| NO LATE CUT | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +7.9 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 4.0 | 0.3 | +0.0 | 0.0 | 5.8 |
| NOT WORTH A CAST | 1.1 | -0.7 | 0.0 | 24.1 | 0.5 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 3.1 | -118.1 | 0.0 | 21.2 | 4.4 | -228.5 | 14.4 | 56.8 |
| ONE CHARGE A CHARGER | 3.6 | +0.0 | 0.0 | 177.0 | 3.6 | +0.0 | 0.0 | 155.4 |
| ONE FIGHT FORMULA | 4.2 | -102.9 | 0.0 | 96.5 | 3.6 | -92.9 | 0.0 | 58.3 |
| ONE OBJECTIVE FORMULA | 4.1 | +48.1 | 0.0 | 76.8 | 4.2 | +5.6 | 0.0 | 34.6 |
| ONE PROMISE A TARGET | 0.1 | -1.7 | 0.0 | 7.8 | 0.1 | -14.7 | 2.9 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 12.3 | 0.9 | +0.0 | 0.0 | 5.9 |
| ONE TARGET A SHOOTER | 23.2 | +441.0 | 0.0 | 424.5 | 34.3 | +995.6 | 0.0 | 408.6 |
| OPENS UP | 0.2 | +34.5 | 6.1 | 0.0 | 0.4 | +25.0 | 19.6 | 5.4 |
| OVERRUNS AWAY | 0.3 | +11.5 | 25.6 | 26.1 | 0.5 | +16.8 | 36.5 | 31.7 |
| OWN CAST FIRST | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +20.1 | 0.0 | 0.0 | 0.2 | +15.0 | 0.0 | 1.9 |
| PERIAPT WORTH | 0.1 | +5.5 | 0.0 | 0.0 | 0.1 | +9.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.3 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| PLAN RESULT | 40.7 | +892.0 | 555.9 | 903.2 | 39.9 | +375.4 | 257.6 | 840.6 |
| PROMISE BELOW ZERO | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 6.0 |
| PROMISE BY ITS OWN SUM | 7.6 | -209.7 | 0.0 | 51.3 | 8.0 | -302.0 | 0.0 | 30.5 |
| PROMISE IN STEPS | 0.0 | +0.0 | 1.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.4 | -0.3 | 1.1 | 11.1 | 0.6 | -0.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.4 | -8.7 | 0.0 | 7.7 | 0.2 | -1.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.1 | -0.2 | 0.0 | 0.0 | 0.0 | -0.0 | 2.9 | 0.0 |
| PURSUES BIG PREY | 0.1 | -19.5 | 0.0 | 1.9 | 0.1 | -13.8 | 0.0 | 0.0 |
| QUARTER ODDS | 18.1 | +1747.7 | 548.5 | 181.0 | 16.9 | +2024.6 | 75.1 | 282.7 |
| RANDOM MOVE BY FIGURES | 0.8 | +15.1 | 0.0 | 31.4 | 2.3 | +59.9 | 0.0 | 81.4 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 12.3 | 0.9 | +0.0 | 0.0 | 5.9 |
| REDIRECT BY WHAT IT STOPS | 0.8 | -25.2 | 0.0 | 19.6 | 0.9 | -32.9 | 0.0 | 23.1 |
| REDIRECT COUNTER | 1.2 | +38.5 | 0.0 | 19.9 | 2.1 | +102.2 | 0.0 | 46.5 |
| REDIRECT WEIGHED | 0.1 | +1.4 | 2.9 | 0.0 | 0.3 | +2.8 | 10.6 | 15.8 |
| REFORMS TO MEET IT | 1.4 | -12.9 | 0.0 | 16.6 | 1.0 | -25.1 | 0.0 | 9.7 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 23.4 | 0.3 | +0.0 | 0.0 | 19.2 |
| RESERVE FALL BACK | 0.4 | +14.0 | 0.0 | 4.2 | 0.6 | +19.2 | 0.0 | 10.0 |
| RESTRAINS TO SHOOT | 0.0 | +5.2 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +46.0 | 148.1 | 62.2 | 2.4 | +1.9 | 262.9 | 65.0 |
| RISK BY HIS FIGURE | 18.6 | -364.5 | 0.0 | 622.1 | 18.1 | -432.2 | 0.0 | 546.9 |
| RISK ON THE WAY | 0.2 | +0.0 | 0.0 | 12.3 | 0.3 | +0.0 | 0.0 | 9.0 |
| ROUNDS AFTER TERROR | 0.6 | -20.3 | 76.4 | 19.1 | 1.2 | -28.1 | 144.9 | 57.2 |
| RUN DOWN | 1.6 | -19.8 | 160.0 | 55.2 | 2.3 | -27.4 | 195.1 | 30.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.0 | +2.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +1.3 | 0.0 | 0.0 | 0.2 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.6 | -22.6 | 0.0 | 5.0 | 0.6 | -35.2 | 0.0 | 8.3 |
| SEARCH SPOT | 0.4 | +11.5 | 0.0 | 0.0 | 0.5 | +3.0 | 0.0 | 1.7 |
| SECOND LOOK | 0.2 | +14.8 | 10.0 | 0.0 | 0.3 | +18.1 | 30.6 | 5.4 |
| SELF MOVE SPELL | 0.3 | +9.2 | 0.0 | 0.0 | 0.2 | +25.8 | 0.0 | 11.0 |
| SET UP BY THE SET | 1.7 | +113.8 | 1.2 | 31.8 | 1.8 | +45.1 | 21.1 | 7.5 |
| SET UP TOGETHER | 0.2 | +7.6 | 0.0 | 7.8 | 0.2 | +8.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.2 | +31.1 | 11.1 | 11.1 | - | - | - | - |
| SET-UP MISSED | 0.0 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.1 | -0.9 | 0.0 | 1.7 | 0.1 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.8 | +167.0 | 186.3 | 0.0 | 2.0 | +29.3 | 76.7 | 5.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.1 | +0.0 | 0.0 | 3.3 |
| SHOT OR CHARGE | 0.3 | -7.3 | 34.9 | 1.9 | 0.2 | -6.8 | 4.9 | 0.0 |
| SHOT RISK POINTS | 14.5 | +87.5 | 0.0 | 331.2 | 24.8 | +220.0 | 0.0 | 457.7 |
| SHOTS AFTER THE MOVES | 3.6 | +0.0 | 0.0 | 0.0 | 1.8 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.6 | +789.9 | 0.0 | 259.2 | 9.6 | +228.9 | 0.0 | 123.4 |
| SPELL SETS UP CHARGE | 0.3 | +57.0 | 11.1 | 11.1 | - | - | - | - |
| SPELL WORTH | 1.4 | +19.9 | 48.1 | 34.0 | 1.5 | +32.1 | 67.6 | 51.5 |
| SPELLS IN THE FIGHT | 0.3 | -3.3 | 20.1 | 17.1 | 0.4 | +2.2 | 36.8 | 16.5 |
| SPOT AS THE GAME MOVES | 6.6 | +0.0 | 0.0 | 140.0 | 8.7 | +0.0 | 0.0 | 187.7 |
| STAND AND SHOOT | 0.3 | -4.6 | 35.6 | 16.6 | 0.8 | -7.8 | 89.8 | 15.2 |
| STANDS FOR A REASON | 0.9 | +0.0 | 9.2 | 4.1 | 1.7 | +0.0 | 0.0 | 6.1 |
| STANDS STILL | 46.9 | +0.0 | 1428.6 | 563.9 | 28.7 | +0.0 | 232.8 | 194.1 |
| STAY WORTH | 27.1 | +127.0 | 897.2 | 289.9 | 11.7 | +73.2 | 93.8 | 136.1 |
| STOPS | 0.1 | +0.9 | 5.9 | 0.0 | 0.1 | +7.9 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.3 | +0.0 | 0.0 | 13.9 |
| STUPIDITY NEXT TURN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.3 | +438.7 | 0.0 | 74.1 | 8.4 | +566.7 | 0.0 | 97.8 |
| SUPPORT NARROWED | 0.3 | +0.0 | 10.7 | 12.3 | 0.2 | +0.0 | 13.4 | 10.8 |
| SUPPORT WORKED OUT | 5.3 | +438.7 | 0.0 | 74.1 | 8.4 | +566.7 | 0.0 | 97.8 |
| SURE REACH TOGETHER | 0.4 | +6.3 | 0.0 | 17.5 | 0.3 | +6.6 | 0.0 | 1.8 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 12.7 | 1.2 | +0.0 | 0.0 | 7.1 |
| THE PROMISE ADDS | 0.0 | -0.3 | 0.0 | 0.0 | 0.1 | -2.9 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 28.5 | +0.0 | 0.0 | 458.4 | 33.4 | +0.0 | 0.0 | 387.6 |
| TIED UP BY THE SUM | 1.1 | +120.9 | 74.4 | 16.7 | 0.9 | +124.0 | 78.8 | 5.4 |
| TIME ON OUR SIDE | 32.1 | +375.2 | 21.9 | 460.9 | 13.3 | +130.2 | 10.3 | 52.2 |
| TWO OR MORE ARRIVE | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 1.1 | +0.0 | 0.0 | 26.7 | 1.6 | +0.0 | 0.0 | 12.1 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.0 | +2.6 | 9.7 | 0.0 | 0.0 | -1.3 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 24.9 | 21.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.2 | +11.2 | 23.9 | 11.7 | 0.1 | +1.8 | 3.3 | 0.0 |
| WHO GETS IN | 0.1 | +9.7 | 3.9 | 0.0 | 0.0 | -2.3 | 8.6 | 0.0 |
| WHO HITS BACK | 0.1 | +16.9 | 0.0 | 3.1 | 0.2 | +16.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +2.1 | 12.0 | 5.9 | 0.1 | +0.0 | 1.7 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +2.7 | 12.3 | 0.0 | 0.1 | +11.9 | 21.9 | 0.0 |
| WIDER SPREAD | 1.7 | -6.0 | 146.6 | 54.6 | 1.9 | -8.6 | 144.7 | 45.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.9 | +73.0 | 0.0 | 77.4 | 1.7 | +76.8 | 0.0 | 46.8 |

### Rule changes: base-s2-882d875-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2577 | 2577 | 1613 | 44.81 | +0 | +0.0 |
| HIS MOVE WHY | 2521 | 2521 | 1377 | 38.25 | +0 | +0.0 |
| ARMY TABLE | 1268 | 1268 | 821 | 22.81 | +13360 | +16.3 |
| HIS SHOT LIST | 2795 | 2673 | 687 | 19.08 | +12775 | +18.6 |
| HOLDER ASSIGNMENT | 678 | 678 | 624 | 17.33 | +40224 | +64.5 |
| ONE TARGET A SHOOTER | 2072 | 1974 | 411 | 11.42 | +4835 | +11.8 |
| DEPLOY BY FIGURES | 570 | 570 | 358 | 9.94 | +5184 | +14.5 |
| HIS ONE MOVE | 1324 | 1296 | 295 | 8.19 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 279 | 279 | 279 | 7.75 | +0 | +0.0 |
| OFF BEST | 270 | 270 | 270 | 7.50 | -12477 | -46.2 |
| THE TABLE AGAIN | 432 | 432 | 262 | 7.28 | +0 | +0.0 |
| FIVE ACTION | 6149 | 5935 | 246 | 6.83 | +14081 | +57.2 |
| TIME ON OUR SIDE | 1633 | 1475 | 226 | 6.28 | +1079 | +4.8 |
| PROMISE BY ITS OWN SUM | 563 | 563 | 225 | 6.25 | -18421 | -81.9 |
| MOVE TO CHARGE COMPUTED | 422 | 369 | 201 | 5.58 | +10293 | +51.2 |
| SHOT RISK POINTS | 1415 | 1352 | 185 | 5.14 | +5520 | +29.8 |
| SUPPORT ADDS | 492 | 472 | 160 | 4.44 | +8248 | +51.6 |
| SUPPORT WORKED OUT | 492 | 472 | 160 | 4.44 | +8248 | +51.6 |
| MOVE ORDER | 133 | 133 | 133 | 3.69 | +0 | +0.0 |
| QUARTER ODDS | 1260 | 1205 | 120 | 3.33 | +10483 | +87.4 |
| HARD STAY DROPPED | 111 | 111 | 111 | 3.08 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 173 | 173 | 106 | 2.94 | +2454 | +23.2 |
| FOUR ROUNDS | 222 | 211 | 99 | 2.75 | +5704 | +57.6 |
| IDLE COST | 536 | 418 | 74 | 2.06 | +684 | +9.2 |
| LANE BY FIGURES | 61 | 61 | 61 | 1.69 | +2821 | +46.2 |
| RANDOM MOVE BY FIGURES | 112 | 112 | 60 | 1.67 | +2700 | +45.0 |
| ADVANCE LANE KEPT | 59 | 59 | 59 | 1.64 | +0 | +0.0 |
| CANNON SIGHT KEPT | 53 | 53 | 53 | 1.47 | +0 | +0.0 |
| RISK BY HIS FIGURE | 1319 | 1248 | 53 | 1.47 | +7526 | +142.0 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| FALLS SHORT | 679 | 576 | 51 | 1.42 | +629 | +12.3 |
| CHAFF IN THE MOVE | 63 | 56 | 49 | 1.36 | +51 | +1.0 |
| CHARGE LOSSES | 671 | 638 | 49 | 1.36 | +5909 | +120.6 |
| SHOTS IN THE MOVE | 943 | 761 | 48 | 1.33 | +2487 | +51.8 |
| TIED UP BY THE SUM | 71 | 65 | 47 | 1.31 | +1478 | +31.4 |
| STAY WORTH | 1395 | 1291 | 45 | 1.25 | +779 | +17.3 |
| HOLDS AMBUSHERS | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| MAX FOR POSITIONING | 172 | 155 | 38 | 1.06 | +159 | +4.2 |
| COVER ONCE | 325 | 235 | 37 | 1.03 | +1390 | +37.6 |
| FOLLOW UP WEIGHED | 37 | 37 | 37 | 1.03 | +8266 | +223.4 |
| RESERVE FALL BACK | 37 | 37 | 37 | 1.03 | +1196 | +32.3 |
| SET UP BY THE SET | 127 | 123 | 36 | 1.00 | +2690 | +74.7 |
| CHARGE NOW FIRST | 132 | 132 | 35 | 0.97 | -2090 | -59.7 |
| LONE WIZARD KEPT IN | 35 | 35 | 35 | 0.97 | +2636 | +75.3 |
| CANNON PLANNED TARGET | 241 | 241 | 33 | 0.92 | +126 | +3.8 |
| RISK BY ARC | 150 | 143 | 30 | 0.83 | +831 | +27.7 |
| CAST JOB | 56 | 56 | 27 | 0.75 | +41 | +1.5 |
| MISSILES IN THE MOVE | 245 | 168 | 27 | 0.75 | +505 | +18.7 |
| NEXT CHARGE BY LIST | 345 | 317 | 27 | 0.75 | +1125 | +41.7 |
| JOINT CHARGE NOW | 25 | 25 | 25 | 0.69 | +1380 | +55.2 |
| MARCH BY THE SUM | 25 | 25 | 25 | 0.69 | +1796 | +71.9 |
| GUN MASK | 58 | 57 | 24 | 0.67 | +1401 | +58.4 |
| SCOUT WAITS | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +62 | +2.6 |
| SHOTS AFTER THE MOVES | 193 | 193 | 24 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 23 | 23 | 23 | 0.64 | -27 | -1.2 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| MARCH CHECK | 39 | 38 | 23 | 0.64 | +396 | +17.2 |
| NEARER NOT NEEDED | 460 | 446 | 22 | 0.61 | +636 | +28.9 |
| SEARCH SPOT | 30 | 30 | 21 | 0.58 | +526 | +25.0 |
| WOUNDS ON THE RANKS | 130 | 127 | 21 | 0.58 | +628 | +29.9 |
| FIRE IN ORDER | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| MODEL FACING | 19 | 19 | 19 | 0.53 | +3663 | +192.8 |
| PATHS CROSS | 18 | 18 | 18 | 0.50 | +1263 | +70.2 |
| REDIRECT COUNTER | 119 | 97 | 18 | 0.50 | +1442 | +80.1 |
| SECOND LOOK | 18 | 18 | 18 | 0.50 | +1186 | +65.9 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 299 | 231 | 16 | 0.44 | +962 | +60.1 |
| CASTING BLOCK | 23 | 23 | 15 | 0.42 | +620 | +41.3 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.42 | +645 | +43.0 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| HIS TURN DENIED | 102 | 98 | 13 | 0.36 | +374 | +28.8 |
| MANOEUVRE | 46 | 46 | 13 | 0.36 | +346 | +26.6 |
| SURE REACH TOGETHER | 26 | 25 | 13 | 0.36 | +43 | +3.3 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +904 | +69.6 |
| MARCH OF THE TABLE | 12 | 12 | 12 | 0.33 | -527 | -43.9 |
| REFUSING RETIRES | 24 | 24 | 11 | 0.31 | -4 | -0.3 |
| WAR ENGINE JOBS | 31 | 31 | 11 | 0.31 | -201 | -18.3 |
| FEATURE BUFFS | 133 | 133 | 10 | 0.28 | +393 | +39.3 |
| ONE FIGHT FORMULA | 281 | 145 | 10 | 0.28 | +101 | +10.1 |
| OPENS UP | 22 | 19 | 10 | 0.28 | +772 | +77.2 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| AFTERMATH IN POINTS | 8 | 8 | 8 | 0.22 | +1742 | +217.8 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| HIS FIGHT TOGETHER | 90 | 85 | 8 | 0.22 | +626 | +78.2 |
| HUNT IN PAIRS | 31 | 16 | 8 | 0.22 | +243 | +30.3 |
| MISSILES NEXT TURN | 337 | 241 | 8 | 0.22 | +9 | +1.2 |
| ONE PROMISE A TARGET | 8 | 8 | 8 | 0.22 | -589 | -73.6 |
| OVERRUNS AWAY | 30 | 28 | 8 | 0.22 | +277 | +34.6 |
| PROMISE READS THE TABLE | 22 | 22 | 8 | 0.22 | +351 | +43.8 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -339 | -48.4 |
| FIGHT TO THE END | 41 | 39 | 7 | 0.19 | +404 | +57.7 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PERIAPT WORTH | 6 | 6 | 6 | 0.17 | +527 | +87.8 |
| WHAT THE JOINER ADDS | 12 | 12 | 6 | 0.17 | +882 | +146.9 |
| WHO GETS IN | 6 | 6 | 6 | 0.17 | +264 | +44.0 |
| CHARGE NOT DECLARED | 5 | 5 | 5 | 0.14 | -890 | -177.9 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.14 | +284 | +56.7 |
| HIS MOVE AND SHOT | 225 | 218 | 5 | 0.14 | +109 | +21.7 |
| SUPPORT NARROWED | 19 | 19 | 5 | 0.14 | -223 | -44.6 |
| AFTERMATH WITH FRIENDS | 4 | 4 | 4 | 0.11 | +221 | +55.3 |
| FALL BACK GOOD ORDER | 155 | 145 | 4 | 0.11 | +119 | +29.8 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +125 | +31.2 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +193 | +48.2 |
| OWN CAST FIRST | 4 | 4 | 4 | 0.11 | -11 | -2.9 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -14 | -3.5 |
| PROMISE KNOWS THE FIGHT | 37 | 27 | 4 | 0.11 | -18 | -4.5 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -1198 | -299.4 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +156 | +52.0 |
| KEEPS SCOUTS OR AMBUSH | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 0.08 | -8 | -2.6 |
| SCREEN BY WHAT IT SAVES | 43 | 43 | 3 | 0.08 | +95 | +31.8 |
| SET UP TOGETHER | 13 | 10 | 3 | 0.08 | +219 | +73.0 |
| SPELLS IN THE FIGHT | 26 | 25 | 3 | 0.08 | +15 | +5.1 |
| WHOLE FIGHT GAIN | 6 | 5 | 3 | 0.08 | +86 | +28.8 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.06 | +107 | +53.6 |
| FALLBACK BY WORTH | 19 | 19 | 2 | 0.06 | +21 | +10.4 |
| FRIEND SHOOTS FIRST | 27 | 26 | 2 | 0.06 | +217 | +108.4 |
| HONEST WORTH | 192 | 182 | 2 | 0.06 | +73 | +36.3 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +45 | +22.3 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +202 | +100.9 |
| RUN DOWN | 138 | 129 | 2 | 0.06 | +48 | +24.0 |
| BLOWS WHERE AIMED | 15 | 13 | 1 | 0.03 | +167 | +166.6 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.03 | -60 | -59.7 |
| DENIED BY THE FIGHT | 30 | 29 | 1 | 0.03 | +18 | +18.1 |
| EDGE GIVE GROUND | 18 | 18 | 1 | 0.03 | +31 | +30.7 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +5 | +5.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.03 | +22 | +22.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +4 | +3.8 |
| GIVES UP | 18 | 15 | 1 | 0.03 | +3 | +2.6 |
| HIS CHARGE DENIED | 10 | 10 | 1 | 0.03 | +4 | +3.5 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.03 | +29 | +28.6 |
| LONG SHOT | 10 | 10 | 1 | 0.03 | +1 | +1.4 |
| NO DOUBLE ROUNDS | 168 | 158 | 1 | 0.03 | +6 | +5.9 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +275 | +274.7 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.03 | +70 | +70.4 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.03 | +13 | +12.8 |
| WHOLE FIGHT | 6 | 6 | 1 | 0.03 | +18 | +17.8 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -81 | -81.1 |
| ALREADY CARRIED | 5 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 14 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 13 | 13 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 128 | 121 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 12 | 12 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 48 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 286 | not checked | - | - | - | - |
| GUN FIGURES | 59 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 208 | 198 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 375 | 358 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 290 | 266 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 264 | 247 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 90 | 90 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 298 | 277 | 0 | 0.00 | - | - |
| HOLD ODDS | 1167 | 1165 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 181 | 179 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 6 | 6 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 95 | 89 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 15 | trace | - | - | - | - |
| MARCH OVER CASTS | 58 | 58 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 70 | 70 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 7 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 23 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 9 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 49 | 47 | 0 | 0.00 | - | - |
| NOT TURNED | 21 | 21 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 57 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 260 | 253 | 0 | 0.00 | - | - |
| ONE ROUTE | 70 | 70 | 0 | 0.00 | - | - |
| PLAN RESULT | 2903 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 9 | 9 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 70 | 70 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 61 | 61 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 85 | 78 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 19 | 19 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 62 | 60 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 17 | 17 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 104 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 552 | 508 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 41 | 41 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 94 | 83 | 0 | 0.00 | - | - |
| STANDS STILL | 2722 | 2648 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 22 | 18 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 91 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 3 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2226 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 99 | 93 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WIDER SPREAD | 128 | 123 | 0 | 0.00 | - | - |

### Off best figure: base-s2-882d875-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.06 | 3.19 | 81.9 |
| JOB FIRST | gate | 2.56 | 3.19 | 46.4 |
| ARMY TABLE | rule | 1.44 | 2.00 | 62.5 |
| NO REASON | gate | 0.42 | 1.08 | 51.3 |
| CHARGE NOW FIRST | rule | 0.53 | 0.44 | 59.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.31 | 25.1 |
| MARCH OF THE TABLE | rule | 0.08 | 0.22 | 47.9 |
| WAR ENGINE JOBS | rule | 0.11 | 0.17 | 20.1 |
| CHAFF PASSED | rule | 0.14 | 0.11 | 2.9 |
| ONE PROMISE A TARGET | rule | 0.08 | 0.14 | 73.6 |
| BEST PRIZE | rule | - | 0.19 | 48.4 |
| JOINT CHARGE NOW | rule | 0.06 | 0.14 | 82.7 |
| CHARGE NOT DECLARED | rule | 0.11 | 0.03 | 177.9 |
| SUPPORT NARROWED | rule | 0.11 | 0.03 | 44.6 |
| AFTERMATH BAND | gate | 0.06 | 0.06 | 2.8 |
| CANNON PLANNED TARGET | rule | 0.11 | - | 2.3 |
| DEPLOY BY FIGURES | rule | - | 0.11 | 17.3 |
| OWN CAST FIRST | rule | 0.03 | 0.08 | 2.9 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.03 | 3.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.08 | 0.03 | 4.5 |
| PURSUES BIG PREY | rule | 0.06 | 0.06 | 299.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 26.8 |
| PROMISE READS THE TABLE | rule | 0.08 | - | 34.0 |
| PROMISE SHOT AWAY | rule | 0.06 | 0.03 | 2.6 |
| PATHS CROSS | rule | 0.06 | - | 5.6 |
| REDIRECT WEIGHED | rule | - | 0.06 | 35.8 |
| REFUSING RETIRES | rule | 0.06 | - | 0.8 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 59.7 |
| FIGHT ORDER BAND | gate | - | 0.03 | 1.6 |
| SET UP BY THE SET | rule | - | 0.03 | 30.8 |
| TURN GATE | gate | 0.03 | - | 8.3 |
| WHO GETS IN | rule | - | 0.03 | 84.0 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 81.1 |

### Plans: base-s2-882d875-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 58% | 363 | 226 | 62% |
| Mine | join | 0.5 | 95% | 19 | 0 | 0% |
| Mine | move | 26.9 | 93% | 1538 | 0 | 0% |
| Mine | shoot | 10.2 | 48% | 638 | 666 | 104% |
| Mine | support | 0.8 | 64% | 2 | 0 | 0% |
| Opponent | charge | 2.8 | 62% | 523 | 265 | 51% |
| Opponent | join | 0.5 | 100% | 19 | 0 | 0% |
| Opponent | move | 32.8 | 92% | 1570 | 0 | 0% |
| Opponent | shoot | 3.1 | 42% | 164 | 111 | 68% |
| Opponent | support | 0.8 | 86% | 5 | 0 | 0% |

### Packages: hunt the guns, base-s2-882d875-p8

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 1 | 0% | 0% | 0% | - | 235 | 0 | 0% | 23 |
| Opponent | 0.1 | 2 | 0 | 50% | 50% | 0% | 3.0 | 341 | 80 | 50% | 62 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 182 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.4 | 2 | 1 | 0% | 0% | 0% | - | 235 | 0 | 0% | 23 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 149 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 24 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 472 | 0 | 0% | 11 |
| Wood Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 211 | 161 | 100% | 74 |

### Battle groups: base-s2-882d875-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.2 | 32% | 71% | 7% | 0% | 8% | 0% | 15% | 62% | 15% |
| Opponent | REDIRECT COUNTER | 2.1 | 25% | 84% | 11% | 50% | 0% | 0% | 0% | 76% | 24% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s2-882d875-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 34 | 40 (34) | 0 | 40 | 53 | 53% | 2.2 | 26 (8) | 53 (21) | 0 (5) | 52 (23) | 17 (11) |
| Mine | Character | 119 | 45 (119) | 45 | 0 | 30 | 25% | 2.5 | 43 (39) | 50 (47) | 57 (19) | 49 (60) | 46 (45) |
| Mine | Clean-up | 22 | 34 (22) | 8 | 26 | 47 | 59% | 2.9 | 0 (11) | 47 (9) | 171 (2) | 36 (16) | 29 (6) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 73 | 33% | 1.0 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Mine | Fast Hammer | 50 | 31 (50) | 18 | 13 | 39 | 32% | 2.7 | 32 (25) | 22 (18) | 56 (7) | 34 (33) | 27 (17) |
| Mine | Hammer | 54 | 30 (54) | 22 | 8 | 29 | 28% | 2.4 | 27 (21) | 39 (25) | 10 (8) | 38 (37) | 16 (17) |
| Mine | Holder | 21 | 68 (21) | 1 | 67 | 36 | 48% | 3.0 | 65 (9) | 84 (9) | 12 (2) | 90 (10) | 40 (10) |
| Mine | Shooter | 47 | 72 (47) | 30 | 42 | 39 | 9% | 2.0 | 55 (12) | 90 (27) | 20 (8) | 96 (31) | 30 (16) |
| Mine | Support | 4 | 21 (4) | 21 | 0 | 0 | 25% | 6.0 | 37 (3) | - | - | 37 (3) | - |
| Mine | War machine | 58 | 32 (58) | 32 | 0 | 42 | 2% | 1.3 | 14 (24) | 62 (16) | 31 (18) | 54 (14) | 25 (44) |
| Mine | Wizard | 21 | 8 (21) | 8 | 0 | 23 | 43% | 2.1 | 0 (5) | 12 (10) | 14 (2) | 12 (10) | 5 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 26 (66) | 4 | 22 | 46 | 62% | 2.3 | 16 (24) | 32 (21) | 35 (21) | 32 (49) | 10 (17) |
| Opponent | Character | 97 | 54 (97) | 54 | 0 | 24 | 27% | 2.3 | 57 (30) | 55 (45) | 59 (15) | 48 (62) | 78 (28) |
| Opponent | Clean-up | 20 | 41 (20) | 2 | 40 | 24 | 60% | 3.8 | 50 (7) | 48 (11) | 0 (2) | 72 (13) | 0 (7) |
| Opponent | Fast | 4 | 0 (4) | 0 | 0 | 100 | 25% | 1.7 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 45 | 31 (45) | 13 | 18 | 29 | 40% | 3.0 | 19 (14) | 34 (24) | 41 (7) | 35 (26) | 24 (19) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 28 | 60% | 1.8 | 0 (3) | 0 (4) | 0 (3) | 0 (1) | 0 (9) |
| Opponent | Hammer | 53 | 30 (53) | 17 | 13 | 40 | 40% | 3.0 | 21 (18) | 41 (30) | 0 (5) | 28 (33) | 33 (20) |
| Opponent | Holder | 38 | 74 (38) | 4 | 69 | 19 | 47% | 2.6 | 75 (12) | 72 (21) | 86 (5) | 125 (20) | 10 (18) |
| Opponent | Shooter | 40 | 92 (40) | 43 | 49 | 46 | 12% | 1.7 | 106 (15) | 83 (17) | 85 (8) | 91 (23) | 94 (17) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | - | 0 (1) | - | 0 (2) |
| Opponent | War machine | 16 | 41 (16) | 41 | 0 | 35 | 12% | 1.9 | 65 (7) | 36 (5) | 0 (4) | 23 (4) | 48 (12) |
| Opponent | Wizard | 26 | 2 (26) | 2 | 0 | 36 | 27% | 2.0 | 4 (6) | 3 (10) | 0 (4) | 4 (9) | 1 (11) |

### Charged fights: base-s2-882d875-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 168 | 20 | 0.5 | 1.0 | 40 | 40 | -0 | 0 of 2 | 1 of 2 | - | -0 |
| Mine | Chaos Dwarfs | 3 | 143 | 523 | 1.3 | 1.0 | 392 | 0 | +392 | 3 of 4 | 4 of 4 | - | +392 |
| Mine | Dwarfen Mountain Holds | 4 | 326 | 10 | 0.5 | 1.0 | 20 | 0 | +20 | 1 of 2 | 2 of 2 | - | +20 |
| Mine | Empire of Man | 5 | 332 | 42 | 0.4 | 1.0 | 105 | 0 | +105 | 1 of 2 | 1 of 2 | - | +105 |
| Mine | Grand Cathay | 4 | 310 | 173 | 1.8 | 1.0 | 99 | 0 | +99 | 2 of 7 | 6 of 7 | - | +99 |
| Mine | High Elf Realms | 4 | 514 | 635 | 6.0 | 1.0 | 106 | 12 | +94 | 7 of 24 | 19 of 23 | - | +94 |
| Mine | Kingdom of Bretonnia | 1 | 70 | 66 | 1.0 | 1.0 | 66 | 0 | +66 | 0 of 1 | 1 of 1 | - | +66 |
| Mine | Lizardmen | 1 | 145 | 1467 | 4.0 | 1.5 | 367 | 0 | +367 | 3 of 4 | 4 of 4 | +556 | +178 |
| Mine | Ogre Kingdoms | 1 | 245 | 210 | 3.0 | 1.3 | 70 | 0 | +70 | 2 of 3 | 3 of 3 | +0 | +105 |
| Mine | Orc & Goblin Tribes | 1 | 65 | 290 | 4.0 | 1.0 | 72 | 91 | -19 | 2 of 4 | 2 of 4 | - | -19 |
| Mine | Skaven | 2 | 98 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 71 | 382 | 3.0 | 1.2 | 127 | 0 | +127 | 1 of 6 | 6 of 6 | +0 | +153 |
| Mine | Vampire Counts | 2 | 0 | 56 | 2.5 | 1.2 | 22 | 183 | -160 | 2 of 5 | 3 of 5 | +111 | -228 |
| Mine | Warriors of Chaos | 1 | 30 | 442 | 4.0 | 1.0 | 110 | 0 | +110 | 2 of 4 | 4 of 4 | - | +110 |
| Mine | Wood Elf Realms | 1 | 225 | 0 | 1.0 | 1.0 | 0 | 104 | -104 | 1 of 1 | 0 of 1 | - | -104 |
| **Mine** | all armies | 36 | 236 | 236 | 1.9 | 1.1 | 121 | 25 | +96 | 27 of 70 | 57 of 69 | +245 | +85 |
| Opponent | Dwarfen Mountain Holds | 1 | 233 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 385 | 179 | 2.7 | 1.2 | 67 | 0 | +67 | 3 of 8 | 7 of 8 | +128 | +58 |
| Opponent | High Elf Realms | 1 | 391 | 965 | 5.0 | 1.0 | 193 | 0 | +193 | 3 of 5 | 4 of 5 | - | +193 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 85 | 2.0 | 1.0 | 42 | 0 | +42 | 0 of 4 | 4 of 4 | - | +42 |
| Opponent | Lizardmen | 2 | 296 | 742 | 3.0 | 1.2 | 247 | 0 | +247 | 4 of 6 | 6 of 6 | +0 | +297 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 202 | 2.0 | 1.0 | 101 | 0 | +101 | 2 of 4 | 3 of 4 | - | +101 |
| Opponent | Skaven | 4 | 63 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 184 | 422 | 3.8 | 1.1 | 113 | 97 | +15 | 7 of 15 | 10 of 15 | +144 | -5 |
| Opponent | Vampire Counts | 3 | 87 | 342 | 3.0 | 1.0 | 114 | 91 | +23 | 3 of 9 | 7 of 9 | - | +23 |
| Opponent | Warriors of Chaos | 9 | 9 | 419 | 2.6 | 1.0 | 164 | 3 | +161 | 8 of 23 | 19 of 23 | - | +161 |
| Opponent | Wood Elf Realms | 5 | 51 | 405 | 3.2 | 1.0 | 127 | 15 | +112 | 7 of 16 | 11 of 16 | - | +112 |
| **Opponent** | all armies | 36 | 110 | 335 | 2.5 | 1.1 | 134 | 29 | +105 | 37 of 90 | 71 of 90 | +104 | +105 |

### Effective charges: base-s2-882d875-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 1 (net -81) | 0 | 1 (net +80) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Chaos Dwarfs | 4 | 0 | 0 | 1 (net +984) | 1 (net +350) | 0 | 1 (net +0) | 1 | 33% (1 of 3) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +20) | 0 | 0% (0 of 2) |
| Mine | Empire of Man | 2 | 0 | 0 | 1 (net +210) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Mine | Grand Cathay | 7 | 0 | 0 | 1 (net +165) | 2 (net +72) | 3 (net +42) | 0 | 1 | 17% (1 of 6) |
| Mine | High Elf Realms | 24 | 3 (net +221) | 0 | 3 (net +35) | 6 (net +80) | 4 (net +75) | 6 (net +131) | 2 | 14% (3 of 22) |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 0 | 0% (0 of 1) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 1 (net +210) | 0 | 2 (net +358) | 1 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 1 (net +210) | 0 | 2 (net +0) | 0 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 1 (net -255) | 0 | 0 | 1 (net +145) | 2 | 50% (1 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +505) | 1 (net +0) | 0 | 3 (net +86) | 1 | 20% (1 of 5) |
| Mine | Vampire Counts | 5 | 1 (net -50) | 0 | 1 (net -609) | 0 | 1 (net +111) | 1 (net -254) | 1 | 25% (1 of 4) |
| Mine | Warriors of Chaos | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +137) | 2 | 0% (0 of 2) |
| Opponent | Grand Cathay | 8 | 1 (net +128) | 1 (net +0) | 2 (net +52) | 2 (net +52) | 2 (net +100) | 0 | 0 | 25% (2 of 8) |
| Opponent | High Elf Realms | 5 | 0 | 0 | 1 (net +526) | 2 (net +125) | 0 | 1 (net +0) | 1 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 1 (net +0) | 1 (net +85) | 0 | 2 | 0% (0 of 2) |
| Opponent | Lizardmen | 6 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +400) | 4 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 1 (net +112) | 0 | 3 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 15 | 3 (net -268) | 0 | 3 (net +19) | 5 (net +134) | 0 | 2 (net +19) | 2 | 23% (3 of 13) |
| Opponent | Vampire Counts | 9 | 1 (net -155) | 0 | 0 | 3 (net +107) | 2 (net +108) | 2 (net -303) | 1 | 0% (0 of 8) |
| Opponent | Warriors of Chaos | 23 | 5 (net +228) | 0 | 1 (net +772) | 1 (net +0) | 6 (net +98) | 5 (net +198) | 5 | 6% (1 of 18) |
| Opponent | Wood Elf Realms | 16 | 3 (net +37) | 1 (net +0) | 2 (net +408) | 1 (net +310) | 1 (net +0) | 0 | 8 | 25% (2 of 8) |

### Charged fights, damage counted: base-s2-882d875-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 220 | 261 | +89 | 135 | 84 | +52 | +23.5 |
| Mine | Effective (55-75%) | 10 | 222 | 190 | +118 | 231 | 110 | +120 | +54.3 |
| Mine | 76-89% | 13 | 314 | 212 | +107 | 118 | 30 | +88 | +28.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 301 | 196 | +91 | 139 | 23 | +116 | +38.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 392 | 87 | +67 | 72 | 0 | +72 | +18.4 |
| Mine | No odds | 12 | 332 | 271 | +99 | 148 | 60 | +88 | +26.6 |
| Mine | All fights | 70 | 302 | 203 | +96 | 141 | 45 | +96 | +31.7 |
| Opponent | Long shot (under 50%) | 13 | 311 | 269 | +32 | 138 | 108 | +29 | +9.4 |
| Opponent | 50-54% | 2 | 439 | 214 | +0 | 41 | 0 | +41 | +9.3 |
| Opponent | Effective (55-75%) | 9 | 424 | 212 | +253 | 289 | 62 | +227 | +53.6 |
| Opponent | 76-89% | 16 | 343 | 199 | +103 | 148 | 44 | +104 | +30.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 11 | 355 | 206 | +75 | 152 | 94 | +58 | +16.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 413 | 91 | +93 | 93 | 15 | +78 | +18.9 |
| Opponent | No odds | 26 | 267 | 171 | +120 | 137 | 24 | +113 | +42.2 |
| Opponent | All fights | 90 | 338 | 188 | +105 | 148 | 50 | +97 | +28.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s2-882d875-p8 | move | 211 | 54 (26%) | 35 (17%) | 29 (14%) | 128 (61%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0116, L0132, L2529, L2728 |
| Charmed Shield | Opponent | L0334, L0626, L1525, L2125, L3334 |
| Clockwork Compass | Mine | L1222 |
| Clockwork Compass | Opponent | L1112 |
| Elixir of Power | Mine | L1112, L1128, L1921 |
| Elixir of Power | Opponent | L0419, L0911, L1019 |
| Fistful of Laurels | Mine | L1821 |
| Horn of the Wild Hunt | Mine | L3334 |
| Horn of the Wild Hunt | Opponent | L0233, L1333, L2333 |
| Invocation of Nehek | Mine | L2529, L2728 |
| Invocation of Nehek | Opponent | L1525, L2125 |
| Opal Amulet | Mine | L1429 |
| Periapt of Soul Exchange | Mine | L2023, L2125 |
| Periapt of Soul Exchange | Opponent | L0821, L1721, L1821, L1921 |
| Ring of Doom | Mine | L0216, L0233, L1112, L1128, L1222, L1525, L3334 |
| Ring of Doom | Opponent | L0233, L0715, L0731, L0911, L1112, L1333, L2333 |
| Ring of Jet | Mine | L1019, L1112, L1128, L1222 |
| Ring of Jet | Opponent | L0610, L0911, L1112 |
| Standard of the Fell Warrior | Mine | L1317, L1333 |
| Storm Daemon (Renegade 2.0) | Mine | L2125 |
| Storm Daemon (Renegade 2.0) | Opponent | L0821, L1721, L1821, L1921 |
| Twice-Blessed Armour | Mine | L0715, L0731, L1019 |
| Twice-Blessed Armour | Opponent | L0610 |
| Witch Hunter's Ward | Mine | L0715, L0731, L0821 |

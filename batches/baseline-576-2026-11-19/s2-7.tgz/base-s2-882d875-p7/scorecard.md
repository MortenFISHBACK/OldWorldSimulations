# Doctrine scorecard: base-s2-882d875-p7

### Scorecard: base-s2-882d875-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0112 | 4 | 2 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0112 | 4 | 2 | Opponent | no | 9 | 2 | 5 | 2 | 0 | 0 | 0 | 165 |
| L0128 | 2 | 2 | Mine | - | - | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 2 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0212 | 2 | 2 | Mine | - | - | 4 | 1 | 7 | 0 | 0 | 0 | 167 |
| L0212 | 2 | 2 | Opponent | - | - | 5 | 0 | 0 | 0 | 0 | 0 | 165 |
| L0228 | 6 | 2 | Mine | no | 2 | - | 1 | 4 | 0 | 0 | 0 | 451 |
| L0228 | 6 | 2 | Opponent | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 2 | Mine | no | 0 | 6 | 0 | 2 | 0 | 0 | 0 | 675 |
| L0313 | 1 | 2 | Opponent | no | 0 | - | 0 | 3 | 2 | 0 | 0 | 0 |
| L0329 | 5 | 2 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 420 |
| L0329 | 5 | 2 | Opponent | yes | - | 2 | 0 | 4 | 2 | 0 | 0 | 170 |
| L0415 | 1 | 2 | Mine | yes | 2 | 4 | 1 | 3 | 0 | 0 | 0 | 139 |
| L0415 | 1 | 2 | Opponent | yes | 2 | 1 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0432 | 6 | 2 | Mine | no | 8 | 3 | 2 | 3 | 0 | 0 | 0 | 124 |
| L0432 | 6 | 2 | Opponent | no | 1 | 2 | 3 | 4 | 1 | 0 | 0 | 170 |
| L0518 | 2 | 2 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 1350 |
| L0518 | 2 | 2 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 268 |
| L0535 | 1 | 2 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 168 |
| L0535 | 1 | 2 | Opponent | no | 3 | 3 | 0 | 4 | 1 | 0 | 0 | 125 |
| L0622 | 4 | 2 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 556 |
| L0622 | 4 | 2 | Opponent | no | 0 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0711 | 3 | 2 | Mine | no | 7 | 2 | 1 | 0 | 0 | 0 | 0 | 77 |
| L0711 | 3 | 2 | Opponent | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 171 |
| L0727 | 1 | 2 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 314 |
| L0727 | 1 | 2 | Opponent | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0817 | 1 | 2 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 170 |
| L0817 | 1 | 2 | Opponent | yes | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0833 | 5 | 2 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 220 |
| L0833 | 5 | 2 | Opponent | no | - | 3 | 2 | 6 | 0 | 0 | 0 | 236 |
| L0924 | 6 | 2 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 45 |
| L0924 | 6 | 2 | Opponent | no | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1015 | 1 | 2 | Mine | no | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1015 | 1 | 2 | Opponent | yes | 5 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1032 | 6 | 2 | Mine | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 291 |
| L1032 | 6 | 2 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 699 |
| L1124 | 2 | 2 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1124 | 2 | 2 | Opponent | - | - | - | 1 | 5 | 0 | 0 | 0 | 0 |
| L1218 | 6 | 2 | Mine | no | 5 | 2 | 6 | 2 | 0 | 0 | 0 | 165 |
| L1218 | 6 | 2 | Opponent | no | 2 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1234 | 4 | 2 | Mine | no | 6 | 2 | 0 | 0 | 0 | 0 | 0 | 165 |
| L1234 | 4 | 2 | Opponent | no | 0 | 3 | 6 | 6 | 0 | 0 | 0 | 0 |
| L1329 | 3 | 2 | Mine | no | 2 | 1 | 1 | 0 | 0 | 0 | 0 | 70 |
| L1329 | 3 | 2 | Opponent | no | 12 | 3 | 3 | 2 | 2 | 0 | 0 | 292 |
| L1424 | 2 | 2 | Mine | - | - | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1424 | 2 | 2 | Opponent | - | - | 4 | 0 | 2 | 0 | 0 | 0 | 403 |
| L1521 | 3 | 2 | Mine | no | 3 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1521 | 3 | 2 | Opponent | yes | 7 | 5 | 2 | 1 | 0 | 0 | 0 | 355 |
| L1618 | 4 | 2 | Mine | no | 2 | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1618 | 4 | 2 | Opponent | no | 7 | 1 | 2 | 2 | 0 | 0 | 0 | 253 |
| L1635 | 3 | 2 | Mine | no | 5 | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1635 | 3 | 2 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1833 | 3 | 2 | Mine | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 111 |
| L1833 | 3 | 2 | Opponent | no | 5 | 3 | 1 | 3 | 0 | 0 | 0 | 368 |
| L1934 | 2 | 2 | Mine | - | - | 1 | 0 | 2 | 1 | 0 | 0 | 255 |
| L1934 | 2 | 2 | Opponent | - | - | 2 | 7 | 3 | 0 | 0 | 0 | 315 |
| L2035 | 1 | 2 | Mine | no | 8 | - | 0 | 3 | 1 | 0 | 0 | 210 |
| L2035 | 1 | 2 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2225 | 5 | 2 | Mine | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 127 |
| L2225 | 5 | 2 | Opponent | no | - | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2329 | 1 | 2 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 70 |
| L2329 | 1 | 2 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2435 | 5 | 2 | Mine | no | - | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2435 | 5 | 2 | Opponent | yes | - | 1 | 3 | 4 | 0 | 0 | 0 | 125 |
| L2632 | 4 | 2 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2632 | 4 | 2 | Opponent | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 200 |
| **Average** | | | Mine | 15% | 2.7 | 2.9 | 1.5 | 1.7 | 0.1 | 0.0 | 0.0 | 192.1 |
| **Average** | | | Opponent | 22% | 2.6 | 2.6 | 2.4 | 2.6 | 0.4 | 0.0 | 0.0 | 135.8 |

### KPIs: base-s2-882d875-p7

Morten 2026-11-10; 33 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (47 of 146) | 1% (2 of 153) | 16% (49 of 299) |
| Winner chose to follow up after the loser gave ground |  | 90% (35 of 39); on the table 90% | 74% (26 of 35); on the table 89% | 82% (61 of 74); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (7 of 14); on the table 57% | 67% (4 of 6); on the table 67% | 55% (11 of 20); on the table 60% |
| Winner chose to pursue after the loser fled |  | 57% (12 of 21); on the table 71% | 64% (9 of 14); on the table 71% | 60% (21 of 35); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 73% (54 of 74); on the table 78% | 71% (39 of 55); on the table 82% | 72% (93 of 129); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 29% (93 of 318) | 26% (42 of 162) | 28% (135 of 480) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 37% (93 of 253) | 31% (42 of 135) | 35% (135 of 388) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (14 of 22) | 56% (31 of 55) | 58% (45 of 77) |
| Points that never fought | lower | 48% (31667 of 65555) | 50% (32767 of 65981) | 49% (64434 of 131536) |
|   infantry points that never fought | lower | 64% (9295 of 14426) | 70% (8483 of 12191) | 67% (17778 of 26617) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (143 of 256) | 65% (174 of 266) | 61% (317 of 522) |
| Bound items with a magic missile used (at least once a game) |  | 82% (18 of 22); 1.8 uses a game | 76% (19 of 25); 1.6 uses a game | 79% (37 of 47); 1.7 uses a game |
| Bound items with another spell used |  | 64% (9 of 14); 0.8 uses a game | 0% (0 of 2); 0.0 uses a game | 56% (9 of 16); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 43% (9 of 21); 0.3 uses a game | 25% (2 of 8); 0.1 uses a game | 38% (11 of 29); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (27888 of 55661) | 61% (36931 of 60427) | 56% (64819 of 116088) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.2 (46%) | 1.5 (42%) | 4.7 (45%) |
| MARCHED: its unit marched | 1.0 (14%) | 0.6 (17%) | 1.6 (15%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.0 (1%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.0 (15%) | 0.3 (9%) | 1.3 (13%) |
| REAR RANK: in a rear rank | 0.3 (5%) | 0.4 (11%) | 0.7 (7%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (1%) | 0.2 (4%) | 0.2 (2%) |
| GONE: slain | 0.5 (8%) | 0.3 (9%) | 0.9 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (4%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.1 | 1.6 | 3.2 | 4.1 | 0.5 | 1.8 |
| not cast | 3.3 | 3.2 | 3.3 | 10.5 | 1.9 | 22.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (54%) | 0.4 (11%) | 4.7 (45%) | 0.6 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (15%) | 0.3 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.1 (4%) | 0.2 (7%) | 1.3 (13%) | 0.3 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.5 (17%) | 0.8 (23%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 0.5 (16%) | 0.3 (11%) | 0.5 (16%) | 0.9 (8%) | 0.2 (11%) | 2.0 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (13%) | 0.1 (2%) | 0.2 (7%) | 0.3 (3%) | 0.1 (5%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.2 (8%) | 0.0 (0%) | 0.1 (1%) | 0.3 (16%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (55%) | 0.2 (5%) | 1.2 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.8 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 1.7 a game | 1.7 a game |
| stood (cast and not dispelled) | 78% (39 of 50) | 76% (35 of 46) | 77% (74 of 96) |
| the unit moved after it | 44% (17 of 39) | 57% (20 of 35) | 50% (37 of 74) |
| it charged on its next turn | 0% (0 of 39) | 3% (1 of 35) | 1% (1 of 74) |
| the enemy charged it first | 18% (7 of 39) | 6% (2 of 35) | 12% (9 of 74) |
| it fought by the end of its next turn | 5% (2 of 39) | 6% (2 of 35) | 5% (4 of 74) |
| it moved out of a charge the enemy had planned (not charged first) | 3% (1 of 39) | 0% (0 of 35) | 1% (1 of 74) |
| none of these (no charge, no fight, no charge escaped) | 79% (31 of 39) | 91% (32 of 35) | 85% (63 of 74) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (509 of 807) | 53% (338 of 638) | 59% (847 of 1445) |
|   cavalry | 62% (40 of 64) | 59% (81 of 138) | 60% (121 of 202) |
|   character | 57% (58 of 102) | 33% (45 of 138) | 43% (103 of 240) |
|   chariot | 64% (56 of 88) | 69% (33 of 48) | 65% (89 of 136) |
|   infantry | 61% (133 of 218) | 60% (140 of 233) | 61% (273 of 451) |
|   monster | 57% (12 of 21) | 43% (16 of 37) | 48% (28 of 58) |
|   war machine | 67% (210 of 314) | 52% (23 of 44) | 65% (233 of 358) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.4 (15%) | 1.7 (18%) | 3.0 (17%) |
| CHARGED: it charged | 0.6 (6%) | 1.9 (21%) | 2.5 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (5%) | 0.3 (4%) | 0.8 (4%) |
| MOVED: a war machine that moved | 1.8 (20%) | 0.3 (3%) | 2.1 (12%) |
| NO TARGET IN RANGE | 2.0 (22%) | 2.5 (28%) | 4.6 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.4 (5%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (16%) | 1.2 (13%) | 2.7 (15%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (2%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.4 (4%) | 0.4 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 0.8 | 89% | 3.7 pts | 21 pts |
| character | 3.6 | 1.5 | 73% | 8.5 pts | 31 pts |
| chariot | 2.7 | 1.5 | 64% | 19.3 pts | 53 pts |
| infantry | 12.2 | 3.4 | 81% | 7.6 pts | 93 pts |
| monster | 0.9 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 7.1 | 5.9 | 64% | 21.9 pts | 155 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.2 | 4.0 | 3.6 |
| Charges that made contact a game | 2.4 | 2.7 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.89 declared, 0.68 contact (28 units) | 0.50 declared, 0.44 contact (16 units) | 0.75 declared, 0.59 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 1.00 contact (2 units) | 0.82 declared, 0.45 contact (11 units) | 1.00 declared, 0.54 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.26 contact (225 units) | 0.43 declared, 0.28 contact (272 units) | 0.38 declared, 0.27 contact (497 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (32 of 72) | 71% (12 of 17) | 40% (4 of 10) | 48% (48 of 99) |
| Character in a unit | 93% (25 of 27) | 90% (19 of 21) | 25% (1 of 4) | 87% (45 of 52) |
| Character on its own | 88% (21 of 24) | 49% (20 of 41) | 38% (24 of 63) | 51% (65 of 128) |
| Chariot | 59% (10 of 17) | 73% (8 of 11) | - | 64% (18 of 28) |
| Infantry | 59% (42 of 71) | 58% (22 of 38) | 33% (1 of 3) | 58% (65 of 112) |
| Monster | 55% (12 of 22) | 43% (3 of 7) | - | 52% (15 of 29) |
| Monstrous | 94% (16 of 17) | 75% (9 of 12) | - | 86% (25 of 29) |
| War Machines | 79% (34 of 43) | 100% (2 of 2) | - | 80% (36 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 71% (5 of 7); on the table 71% | 27% (26 of 96) | 68% | 73% (16 of 22) | 67% (4 of 6); 3.5 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (7 of 7); on the table 100% | 42% (15 of 36) | 60% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 78% | 83% (20 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 67% (8 of 12); on the table 75% | 38% (9 of 24) | 53% | 63% (33 of 52) | 0.0 uses a game | 50% (1 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 64% (16 of 25); on the table 68% | 27% (44 of 162) | 50% | 54% (39 of 72) | 80% (16 of 20); 5.4 uses a game | 100% (2 of 2); 0.4 uses a game | 12% (1 of 8); 0.1 uses a game |
| High Elf Realms | 6 | 100% (7 of 7); on the table 100% | 50% (12 of 24) | 43% | 46% (21 of 46) | 100% (8 of 8); 5.0 uses a game | 40% (4 of 10); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 80% (4 of 5); on the table 100% | - | 39% | 25% (3 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 60% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 50% (1 of 2); on the table 100% | 4% (1 of 24) | 61% | 75% (21 of 28) | 75% (3 of 4); 1.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 6) | 17% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 29% (2 of 7); on the table 71% | 17% (4 of 24) | 49% | 31% (5 of 16) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 3 | 70% (7 of 10); on the table 70% | - | 27% | 33% (5 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 7 | 72% (13 of 18); on the table 83% | 23% (11 of 48) | 46% | 67% (30 of 45) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 64% (7 of 11); on the table 73% | 50% (6 of 12) | 33% | 59% (35 of 59) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 8 | 92% (12 of 13); on the table 92% | 29% (7 of 24) | 51% | 69% (58 of 84) | 62% (5 of 8); 2.1 uses a game | 0.0 uses a game | 25% (1 of 4); 0.1 uses a game |

Flank and rear charges a unit could have turned to face (base-s2-882d875-p7, 33 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (27) | 42% (19) | 45% (46) |
| ...free all their last turn and able to turn (per game) | 0.55 | 0.48 | 1.03 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.12 | 0.09 | 0.21 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.33 | 0.76 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.09 | 0.06 | 0.15 |

### Quality by phase: base-s2-882d875-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.4 |
| Strategy | Charge objectives carried out (made contact) | 70% (64 of 91) | 49% (55 of 112) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (132 of 381) | 47% (64 of 137) |
| Strategy | Support requests answered (helper made contact too) | 71% (10 of 14) | 27% (4 of 15) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (6 of 15) | 33% (3 of 9) |
| Strategy | Joined characters whose unit fought | 22% (11 of 49) | 38% (10 of 26) |
| Strategy | Lone characters that fought | 66% (55 of 83) | 61% (44 of 72) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.7 | 2.6 |
| Movement | Points that never moved of their own | 192.1 | 135.8 |
| Movement | Fights charged into per game | 2.0 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 59, net +241 | 16 of 68, net +5 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 59, net +55 | 7 of 68, net +36 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 59, net +89 | 10 of 68, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 of 59, net +143 | 14 of 68, net +65 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.6 | 10.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (139 of 318) | 50% (174 of 345) |
| Shooting | Points destroyed by shooting units | 63.2 | 36.3 |
| Shooting | War machine shots | 6.4 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (113 of 210) | 35% (8 of 23) |
| Shooting | Points destroyed by war machines | 63.6 | 16.6 |
| Magic | Magic missiles cast | 1.8 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 47% (28 of 60) | 38% (11 of 29) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.3 |
| Magic | Wounds caused by other spells | 1.9 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 49.9 | 24.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.9 / 0.5 / 0.5 / 0.1 | 2.2 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 281.4 | 233.2 |
| Combat | Points run down | 72.2 | 88.6 |
| Combat | Net points per charged fight, damage counted | +124 | +57 |
| Combat | Net per 100 charger points, damage counted | +36.4 | +19.6 |
| Combat | First round won (charged fights) | 77% | 65% |
| Combat | Net points per charged fight | +130 | +58 |
| Combat | Net points per supported fight / lone fight | +240 / +111 | -30 / +64 |
| Combat | Charged fights on a top-3 enemy unit | 19 of 66 | 41 of 84 |
| Game | Points lost | 504.8 | 609.5 |
| Game | VP from objectives | 619.7 | 635.2 |
| Game | Lone holders (player turns) | 2.7 | 2.6 |

- Mine won / drew / lost: 19 / 4 / 10 of 33 ended games (of 33); mean margin (Mine - Opponent) +145 VP
- The side that went first won 12 of 29 games with a winner
- Points traded per game (both sides' losses): 1114
- Games not ended: 0; findings 5, warnings 0

### Opponent rules: base-s2-882d875-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +25.5 | 0.0 | 0.0 | 0.3 | +39.7 | 0.0 | 8.8 |
| AFTERMATH WITH FRIENDS | 0.0 | +0.5 | 0.0 | 0.0 | 0.1 | +6.3 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 14.9 | +269.0 | 0.0 | 103.2 | 21.6 | +188.6 | 0.0 | 275.7 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 14.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.4 | 0.0 | 0.0 | 0.2 | +0.9 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | -4.0 | 0.9 | 0.0 | 0.1 | -7.3 | 13.3 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -15.7 | 44.6 | 0.0 | 0.3 | -30.6 | 31.3 | 0.0 |
| BOMBING RUN | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 4.5 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 3.8 | - | - | - | - |
| CANNON PLAN MISSED | 0.2 | +0.0 | 38.2 | 0.0 | 0.0 | +0.0 | 2.6 | 0.0 |
| CANNON PLANNED TARGET | 6.2 | +220.8 | 328.5 | 55.2 | 0.6 | +9.6 | 9.8 | 0.0 |
| CANNON SIGHT KEPT | 1.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.6 | +45.0 | 195.2 | 16.5 | 0.7 | +7.7 | 28.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +40.6 | 20.9 | 0.0 | 0.4 | +15.5 | 9.7 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 51.3 | 1.2 | +0.0 | 0.0 | 27.7 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.5 | +21.4 | 0.0 | 16.9 | 1.6 | +66.0 | 0.0 | 7.8 |
| CHAFF PASSED | 0.5 | -1.0 | 29.9 | 12.5 | 0.1 | -1.2 | 0.0 | 4.2 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -1.1 | 14.7 | 0.0 | 0.1 | -0.9 | 3.3 | 0.0 |
| CHARACTER GUNS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.6 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.0 | +2.2 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.0 | -495.6 | 0.0 | 258.5 | 10.0 | -676.5 | 0.0 | 473.2 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 191.1 | 27.8 | 1.8 | +0.0 | 221.7 | 18.2 |
| CHARGER SLAIN LOST | 0.4 | -21.6 | 121.5 | 3.0 | 0.3 | -7.0 | 36.1 | 18.5 |
| COMBAT PIVOT | 0.4 | +0.0 | 21.0 | 18.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.5 | +168.5 | 59.1 | 73.3 | 1.1 | +107.3 | 43.5 | 42.0 |
| COVER ONCE | 6.2 | -428.2 | 0.0 | 100.4 | 3.3 | -260.4 | 0.0 | 70.2 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.7 | -9.1 | 97.4 | 3.6 | 0.9 | -10.6 | 73.6 | 36.4 |
| DEPLOY BY FIGURES | 7.8 | +0.8 | 0.0 | 14.6 | 7.8 | +54.4 | 0.0 | 8.9 |
| EDGE GIVE GROUND | 0.2 | +3.3 | 18.9 | 2.6 | 0.1 | +2.7 | 10.2 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.9 | +1.6 | 187.3 | 19.7 | 2.7 | +5.7 | 259.5 | 108.0 |
| FALLBACK BY WORTH | 0.1 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.8 |
| FALLS SHORT | 4.7 | +85.8 | 0.0 | 46.3 | 15.7 | +218.7 | 0.0 | 242.5 |
| FEATURE BUFFS | 2.3 | +69.3 | 0.0 | 36.4 | 1.2 | +33.1 | 0.0 | 19.4 |
| FIGHT LIFT | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.6 | +5.4 | 79.8 | 10.3 | 0.8 | +18.3 | 49.8 | 31.3 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 2.4 | - | - | - | - |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 4.0 | 0.0 |
| FIVE ACTION | 88.6 | +5628.6 | 1649.1 | 1072.3 | 84.2 | +5171.6 | 805.1 | 1216.0 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 127.8 | 3.2 | +0.0 | 0.0 | 123.3 |
| FOLLOW UP WEIGHED | 0.8 | +120.4 | 0.0 | 2.6 | 0.7 | +110.2 | 0.0 | 20.0 |
| FOUR ROUNDS | 3.0 | +231.4 | 374.1 | 27.9 | 3.8 | +325.6 | 354.1 | 130.9 |
| FRIEND CHARGES FIRST | 0.0 | -1.6 | 0.0 | 0.0 | 0.1 | -3.9 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -15.1 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +9.9 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -4.2 | 23.5 | 0.0 | 0.2 | -3.5 | 7.9 | 29.9 |
| GROUND FLIERS | - | - | - | - | 0.1 | +3.4 | 0.0 | 0.0 |
| GUN FIGURES | 1.0 | +12.1 | 54.1 | 41.8 | 0.4 | +7.6 | 2.4 | 15.2 |
| GUN MASK | 1.4 | +26.9 | 0.0 | 8.2 | 0.6 | +24.6 | 0.0 | 32.2 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 18.8 | 1.6 | +0.0 | 0.0 | 12.4 |
| HE SHOOTS OR CHARGES | 3.0 | +0.0 | 0.0 | 92.2 | 3.5 | +0.0 | 0.0 | 99.9 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 7.6 | 7.6 |
| HIS CHARGE DENIED | 0.2 | +9.6 | 73.8 | 2.6 | 0.6 | +30.0 | 65.4 | 46.0 |
| HIS CHARGE LIST | 6.4 | +0.0 | 0.0 | 66.3 | 5.0 | +0.0 | 0.0 | 97.6 |
| HIS FIGHT TOGETHER | 2.1 | -42.1 | 0.0 | 120.7 | 1.6 | -33.6 | 0.0 | 36.8 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 54.3 | 3.8 | +0.0 | 0.0 | 102.3 |
| HIS MOVE AND SHOT | 3.5 | -55.7 | 0.0 | 73.2 | 3.8 | -70.3 | 0.0 | 175.5 |
| HIS MOVE AS HE DECIDES | 38.6 | +13.1 | 750.5 | 0.0 | 32.9 | +12.6 | 432.6 | 0.0 |
| HIS MOVE WHY | 32.7 | +0.0 | 0.0 | 343.5 | 38.8 | +0.0 | 0.0 | 613.4 |
| HIS ONE MOVE | 15.9 | -7.1 | 0.0 | 82.4 | 19.7 | +5.8 | 0.0 | 96.2 |
| HIS ONE QUARTER | 4.1 | +0.0 | 0.0 | 71.0 | 3.8 | +0.0 | 0.0 | 36.0 |
| HIS OWN BEST MOVE | 1.8 | +0.0 | 0.0 | 12.8 | 1.1 | +0.0 | 0.0 | 18.3 |
| HIS RANDOM MOVE | 5.8 | +0.0 | 0.0 | 136.8 | 3.2 | +0.0 | 0.0 | 27.7 |
| HIS SHOT LIST | 36.4 | +1100.4 | 0.0 | 468.6 | 48.4 | +2550.3 | 0.0 | 737.9 |
| HIS TURN DENIED | 1.2 | +30.7 | 140.9 | 7.2 | 2.2 | +102.6 | 224.5 | 48.9 |
| HOLD ODDS | 17.5 | +0.0 | 0.0 | 165.3 | 15.8 | +0.0 | 0.0 | 127.5 |
| HOLDER ASSIGNMENT | 9.7 | +1018.3 | 0.0 | 91.3 | 9.8 | +905.8 | 0.0 | 63.5 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.4 | -92.6 | 238.8 | 23.3 | 3.2 | -146.1 | 284.4 | 108.6 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +5.5 | 0.0 | 0.0 | 0.3 | +14.3 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.1 | +13.1 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +26.3 | 12.1 | 2.6 |
| IDLE COST | 3.2 | -48.6 | 0.0 | 8.5 | 11.0 | -178.9 | 0.0 | 249.5 |
| JOINT CHARGE NOW | 0.8 | +21.9 | 187.9 | 3.1 | 0.8 | +114.5 | 128.5 | 17.1 |
| JOINT KNOWS CHALLENGE | 0.1 | -1.7 | 37.2 | 0.0 | 0.2 | -7.0 | 22.2 | 0.0 |
| JOINT LOOK BACK | 0.0 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | - | - | - | - | 0.0 | +7.4 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.1 | +0.0 | 0.0 | 7.3 | 2.6 | +0.0 | 0.0 | 22.7 |
| LANE BY FIGURES | 0.8 | +27.9 | 0.0 | 0.0 | 1.0 | +44.5 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.5 | +0.0 | 188.4 | 287.6 | 4.6 | +0.0 | 143.0 | 217.1 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +40.1 | 0.0 | 0.0 | 0.1 | +12.7 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +0.1 | 1.6 | 0.0 | 0.3 | -0.1 | 20.6 | 10.4 |
| LOST AFTER ESCAPE | 1.9 | +1.9 | 230.6 | 24.3 | 2.0 | -2.8 | 188.9 | 97.5 |
| LOST CHARGE | 0.0 | -0.3 | 4.2 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.2 | -8.9 | 0.0 | 7.6 | 0.0 | -4.7 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.8 | 0.0 | 5.1 | 0.0 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 0.9 | +4.5 | 0.0 | 8.8 | 1.0 | +1.4 | 0.0 | 20.1 |
| MARCH AT ESCAPER | 0.2 | +2.4 | 0.0 | 5.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +38.1 | 0.0 | 0.0 | 0.3 | +13.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +39.2 | 0.0 | 10.9 | 0.5 | +19.1 | 0.0 | 4.8 |
| MARCH ODDS | 0.1 | +0.4 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.8 | +6.3 | 0.0 | 30.3 | 0.7 | +74.5 | 0.0 | 49.5 |
| MARCH WHEELS ONLY | 0.9 | +0.0 | 0.0 | 7.3 | 1.3 | +0.0 | 0.0 | 8.4 |
| MAX FOR POSITIONING | 2.9 | +67.0 | 0.0 | 37.9 | 2.7 | +70.5 | 0.0 | 44.9 |
| MISSILES IN THE MOVE | 4.4 | +167.0 | 0.0 | 70.5 | 3.2 | +42.5 | 0.0 | 49.4 |
| MISSILES NEXT TURN | 5.9 | +117.4 | 0.0 | 129.6 | 4.6 | +39.7 | 0.0 | 88.3 |
| MISSILES ON ONE TARGET | 0.4 | -16.3 | 0.0 | 11.1 | 0.0 | -0.0 | 0.0 | 0.0 |
| MODEL FACING | 0.1 | +3.3 | 0.0 | 3.6 | - | - | - | - |
| MOVE ORDER | 1.6 | +0.0 | 15.9 | 17.6 | 1.8 | +0.0 | 37.2 | 15.7 |
| MOVE SPELL IN RANGE | 0.5 | +13.7 | 0.0 | 35.2 | 0.0 | +1.2 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 10.8 | 0.1 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -32.3 | 0.0 | 0.0 | 0.6 | -21.0 | 0.0 | 22.5 |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 47.9 | 0.6 | +0.0 | 0.0 | 14.2 |
| MOVE TO CHARGE COMPUTED | 4.8 | +548.4 | 0.0 | 40.9 | 5.8 | +690.9 | 0.0 | 122.5 |
| MOVES UNITS SPELL | 0.1 | +3.7 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.8 | +279.7 | 0.0 | 63.5 | 6.3 | +256.8 | 0.0 | 90.7 |
| NEXT CHARGE BY LIST | 4.2 | -131.2 | 16.7 | 13.5 | 5.2 | -280.6 | 9.7 | 138.5 |
| NEXT OBJECTIVE NEARER | 0.1 | -8.1 | 0.9 | 0.0 | 0.2 | -2.4 | 0.0 | 4.2 |
| NO DOUBLE ROUNDS | 2.4 | -121.5 | 305.1 | 24.3 | 2.9 | -184.1 | 297.2 | 128.2 |
| NO LATE CUT | 0.4 | +0.0 | 0.0 | 7.3 | 1.0 | +0.0 | 0.0 | 8.4 |
| NOT TURNED | 0.1 | -0.2 | 0.0 | 1.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 2.9 | -93.1 | 0.0 | 71.8 | 4.4 | -228.3 | 10.4 | 76.8 |
| ONE CHARGE A CHARGER | 3.9 | +0.0 | 0.0 | 85.0 | 3.5 | +0.0 | 0.0 | 62.1 |
| ONE FIGHT FORMULA | 3.7 | -88.9 | 0.0 | 44.9 | 4.2 | -114.6 | 0.0 | 131.5 |
| ONE OBJECTIVE FORMULA | 4.8 | +84.2 | 0.0 | 67.7 | 3.7 | -12.4 | 0.0 | 37.2 |
| ONE PROMISE A TARGET | 0.1 | -23.5 | 1.9 | 0.0 | 0.2 | -5.9 | 0.0 | 0.0 |
| ONE ROUTE | 0.9 | +0.0 | 0.0 | 7.3 | 1.3 | +0.0 | 0.0 | 8.4 |
| ONE TARGET A SHOOTER | 24.8 | +450.3 | 0.0 | 295.5 | 33.6 | +983.6 | 0.0 | 602.8 |
| OPENS A LANE | 0.1 | +0.4 | 3.0 | 0.0 | 0.0 | +0.1 | 2.5 | 0.0 |
| OPENS UP | 0.2 | +4.3 | 10.6 | 0.0 | 0.3 | +28.0 | 24.2 | 0.0 |
| OVERRUNS AWAY | 0.5 | +35.8 | 58.1 | 2.6 | 0.6 | +22.0 | 60.3 | 50.9 |
| OWN CAST FIRST | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| PATHS CROSS | 0.4 | +39.5 | 0.0 | 0.0 | 0.4 | +21.8 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.0 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.0 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.3 | +962.4 | 627.8 | 672.1 | 40.7 | +457.7 | 283.4 | 939.5 |
| PROMISE BELOW ZERO | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.2 | -164.8 | 0.0 | 88.1 | 8.2 | -358.6 | 0.0 | 17.7 |
| PROMISE IN STEPS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | -2.4 | 0.0 | 0.0 | 0.4 | -0.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.4 | -7.7 | 0.0 | 0.0 | 0.1 | -4.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.5 | -5.0 | 72.8 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -1.8 | 0.0 | 0.0 |
| QUARTER ODDS | 16.0 | +1609.8 | 302.2 | 177.9 | 15.9 | +1821.9 | 131.6 | 141.8 |
| RANDOM MOVE BY FIGURES | 0.7 | +10.2 | 0.0 | 17.9 | 1.7 | +40.0 | 0.0 | 19.8 |
| REAL GROUND | 0.9 | +0.0 | 0.0 | 7.3 | 1.3 | +0.0 | 0.0 | 8.4 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -6.0 | 0.0 | 8.7 | 1.1 | -29.4 | 0.0 | 5.7 |
| REDIRECT COUNTER | 1.3 | +44.0 | 0.0 | 35.8 | 2.7 | +173.9 | 0.0 | 43.8 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | -2.7 | 13.9 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -39.7 | 0.0 | 1.8 | 0.8 | -26.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 2.5 | 0.2 | +0.0 | 0.0 | 7.9 |
| RESERVE FALL BACK | 0.4 | +11.8 | 0.0 | 26.3 | 0.5 | +36.7 | 0.0 | 3.5 |
| RESTRAINS TO SHOOT | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +2.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +27.5 | 252.9 | 27.9 | 2.6 | -7.6 | 246.0 | 100.8 |
| RISK BY HIS FIGURE | 20.1 | -377.2 | 0.0 | 435.0 | 17.5 | -397.7 | 0.0 | 517.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.7 |
| ROUNDS AFTER TERROR | 0.6 | -13.3 | 78.1 | 0.0 | 1.2 | -34.1 | 118.7 | 64.6 |
| RUN DOWN | 2.2 | -28.3 | 256.5 | 24.3 | 2.3 | -30.4 | 220.7 | 129.5 |
| SAME CHARGE LATER | - | - | - | - | 0.0 | -0.4 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.2 | +1.2 | 0.0 | 4.1 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.1 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.3 | 0.0 | 3.6 | 1.6 | -102.1 | 0.0 | 12.3 |
| SEARCH SPOT | 0.3 | +8.1 | 0.0 | 4.1 | 0.5 | +8.6 | 0.0 | 22.8 |
| SECOND LOOK | 0.2 | +12.0 | 20.0 | 0.0 | 0.3 | +38.8 | 16.2 | 15.0 |
| SELF MOVE SPELL | 0.3 | +6.5 | 0.0 | 0.0 | 0.4 | +40.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.9 | +8.9 | 0.0 | 12.1 | 2.0 | +111.5 | 13.2 | 15.9 |
| SET UP TOGETHER | 0.3 | +0.8 | 0.0 | 5.1 | 0.3 | +1.9 | 0.0 | 22.4 |
| SET-UP ANY TARGET | 0.1 | +17.9 | 13.2 | 0.0 | 0.2 | +26.1 | 14.2 | 14.2 |
| SET-UP MISSED | 0.0 | +2.5 | 0.0 | 12.1 | 0.0 | +0.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 2.7 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.5 | +116.5 | 131.7 | 27.4 | 1.6 | +65.8 | 51.8 | 28.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.5 | -43.2 | 71.3 | 1.0 | 0.4 | -1.9 | 8.2 | 5.3 |
| SHOT RISK POINTS | 17.3 | +111.5 | 0.0 | 246.6 | 22.5 | +108.0 | 0.0 | 608.0 |
| SHOTS AFTER THE MOVES | 3.4 | +0.0 | 0.0 | 0.0 | 1.6 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.2 | +636.2 | 0.0 | 233.6 | 10.2 | +266.8 | 0.0 | 165.4 |
| SPELL SETS UP CHARGE | 0.2 | +59.0 | 13.2 | 0.0 | 0.2 | +33.1 | 14.2 | 14.2 |
| SPELL WORTH | 1.7 | +28.4 | 38.4 | 49.2 | 2.4 | +45.6 | 123.9 | 123.9 |
| SPELLS IN THE FIGHT | 0.5 | -0.4 | 80.2 | 14.2 | 0.6 | -6.5 | 81.8 | 17.1 |
| SPOT AS THE GAME MOVES | 7.2 | +0.0 | 0.0 | 156.8 | 11.0 | +0.0 | 0.0 | 221.2 |
| STAND AND SHOOT | 0.5 | -4.4 | 79.5 | 1.0 | 0.8 | -11.9 | 79.5 | 43.1 |
| STANDS FOR A REASON | 0.2 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 7.5 | 34.9 |
| STANDS STILL | 46.0 | +0.0 | 1275.1 | 471.3 | 27.8 | +0.0 | 451.0 | 234.5 |
| STAY WORTH | 25.4 | -99.0 | 846.6 | 171.5 | 12.7 | +68.9 | 239.8 | 138.7 |
| STOPS | - | - | - | - | 0.1 | +0.2 | 12.1 | 2.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 5.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.7 | +662.0 | 0.0 | 75.5 | 7.7 | +473.1 | 0.0 | 74.9 |
| SUPPORT NARROWED | 0.4 | +0.0 | 50.8 | 0.0 | 0.4 | +0.0 | 24.9 | 2.8 |
| SUPPORT WORKED OUT | 8.7 | +662.0 | 0.0 | 75.5 | 7.7 | +473.1 | 0.0 | 74.9 |
| SURE REACH TOGETHER | 0.4 | +1.9 | 0.0 | 7.5 | 0.5 | +2.8 | 0.0 | 22.4 |
| THE DEARER SUM KEEPS ITS PLAN | 1.5 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 2.6 |
| THE PROMISE ADDS | 0.1 | -0.4 | 0.0 | 0.0 | 0.1 | -11.8 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.0 | +0.0 | 0.0 | 2.8 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 28.4 | +0.0 | 0.0 | 372.1 | 34.5 | +0.0 | 0.0 | 471.7 |
| TIED UP BY THE SUM | 0.8 | +96.3 | 57.3 | 1.8 | 0.8 | +86.1 | 41.8 | 28.1 |
| TIME ON OUR SIDE | 33.6 | +395.0 | 76.4 | 419.6 | 15.1 | +137.9 | 9.8 | 124.5 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 1.8 | 1.1 | +0.0 | 0.0 | 34.8 |
| WALKS ON ITS ROUTE | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | -4.5 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 17.4 | 37.6 | 0.2 | +0.0 | 3.5 | 11.2 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.2 | -2.5 | 6.7 | 0.0 |
| WHO GETS IN | 0.3 | +4.9 | 92.0 | 1.6 | 0.1 | +13.8 | 22.9 | 0.0 |
| WHO HITS BACK | 0.4 | +57.0 | 0.0 | 15.8 | 0.3 | +50.0 | 0.0 | 21.5 |
| WHOLE FIGHT | - | - | - | - | 0.1 | +1.2 | 3.3 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +12.9 | 62.2 | 0.0 | 0.3 | +17.1 | 55.5 | 2.6 |
| WIDER SPREAD | 2.1 | -2.4 | 266.4 | 24.5 | 2.8 | -11.0 | 245.2 | 68.1 |
| WOUNDS ON THE RANKS | 2.2 | +85.8 | 0.0 | 58.5 | 1.3 | +46.1 | 0.0 | 85.0 |

### Rule changes: base-s2-882d875-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2360 | 2360 | 1512 | 45.82 | +0 | +0.0 |
| HIS MOVE WHY | 2362 | 2362 | 1281 | 38.82 | +0 | +0.0 |
| ARMY TABLE | 1204 | 1204 | 776 | 23.52 | +14430 | +18.6 |
| HIS SHOT LIST | 2796 | 2663 | 730 | 22.12 | +15216 | +20.8 |
| HOLDER ASSIGNMENT | 643 | 643 | 601 | 18.21 | +35353 | +58.8 |
| ONE TARGET A SHOOTER | 1929 | 1822 | 376 | 11.39 | +4863 | +12.9 |
| LEGAL CHARGES ONLY | 301 | 301 | 301 | 9.12 | +0 | +0.0 |
| DEPLOY BY FIGURES | 516 | 516 | 295 | 8.94 | +3971 | +13.5 |
| TIME ON OUR SIDE | 1608 | 1420 | 264 | 8.00 | +1148 | +4.3 |
| HIS ONE MOVE | 1177 | 1149 | 254 | 7.70 | +0 | +0.0 |
| THE TABLE AGAIN | 395 | 395 | 246 | 7.45 | +0 | +0.0 |
| OFF BEST | 242 | 242 | 242 | 7.33 | -10606 | -43.8 |
| FIVE ACTION | 5703 | 5473 | 219 | 6.64 | +12145 | +55.5 |
| SUPPORT ADDS | 542 | 523 | 200 | 6.06 | +9056 | +45.3 |
| SUPPORT WORKED OUT | 542 | 523 | 200 | 6.06 | +9056 | +45.3 |
| SHOT RISK POINTS | 1313 | 1257 | 189 | 5.73 | +5888 | +31.2 |
| PROMISE BY ITS OWN SUM | 509 | 509 | 181 | 5.48 | -17272 | -95.4 |
| MOVE TO CHARGE COMPUTED | 348 | 295 | 176 | 5.33 | +12041 | +68.4 |
| HARD STAY DROPPED | 119 | 119 | 119 | 3.61 | +0 | +0.0 |
| MOVE ORDER | 115 | 115 | 115 | 3.48 | +0 | +0.0 |
| FOUR ROUNDS | 223 | 214 | 108 | 3.27 | +5411 | +50.1 |
| QUARTER ODDS | 1053 | 1003 | 106 | 3.21 | +9472 | +89.4 |
| SHOOTS FROM THE BEST SPOT | 133 | 133 | 91 | 2.76 | +1292 | +14.2 |
| ARTILLERY RE-ROLL WEIGHED | 68 | 68 | 68 | 2.06 | +0 | +0.0 |
| IDLE COST | 471 | 380 | 64 | 1.94 | +694 | +10.8 |
| ADVANCE LANE KEPT | 62 | 62 | 62 | 1.88 | +0 | +0.0 |
| LANE BY FIGURES | 59 | 59 | 59 | 1.79 | +2387 | +40.5 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 1.73 | +0 | +0.0 |
| CHAFF IN THE MOVE | 69 | 64 | 57 | 1.73 | +522 | +9.2 |
| JOINT CHARGE NOW | 55 | 55 | 55 | 1.67 | +4500 | +81.8 |
| MAX FOR POSITIONING | 185 | 169 | 55 | 1.67 | +350 | +6.4 |
| CHARGE LOSSES | 693 | 662 | 51 | 1.55 | +6716 | +131.7 |
| FALLS SHORT | 674 | 585 | 49 | 1.48 | +413 | +8.4 |
| RISK BY HIS FIGURE | 1238 | 1166 | 49 | 1.48 | +6678 | +136.3 |
| FOLLOW UP WEIGHED | 48 | 48 | 48 | 1.45 | +7609 | +158.5 |
| TIED UP BY THE SUM | 53 | 51 | 46 | 1.39 | +1673 | +36.4 |
| COVER ONCE | 313 | 222 | 45 | 1.36 | +838 | +18.6 |
| RANDOM MOVE BY FIGURES | 77 | 77 | 45 | 1.36 | +1656 | +36.8 |
| SET UP BY THE SET | 128 | 128 | 45 | 1.36 | +5879 | +130.6 |
| STAY WORTH | 1258 | 1159 | 39 | 1.18 | +480 | +12.3 |
| SHOTS IN THE MOVE | 872 | 695 | 38 | 1.15 | +1782 | +46.9 |
| MISSILES IN THE MOVE | 251 | 188 | 37 | 1.12 | +1096 | +29.6 |
| RISK BY ARC | 154 | 146 | 34 | 1.03 | +744 | +21.9 |
| RESERVE FALL BACK | 31 | 31 | 31 | 0.94 | +1601 | +51.6 |
| HOLDS AMBUSHERS | 30 | 30 | 30 | 0.91 | +0 | +0.0 |
| CAST JOB | 74 | 74 | 29 | 0.88 | +181 | +6.2 |
| MARCH CHECK | 40 | 39 | 27 | 0.82 | +594 | +22.0 |
| CASTING BLOCK | 31 | 31 | 26 | 0.79 | +554 | +21.3 |
| PATHS CROSS | 26 | 26 | 26 | 0.79 | +2020 | +77.7 |
| SCOUT WAITS | 26 | 26 | 26 | 0.79 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 25 | 25 | 25 | 0.76 | +1741 | +69.6 |
| CHARGE NOW FIRST | 119 | 119 | 24 | 0.73 | -1422 | -59.2 |
| SHOTS AFTER THE MOVES | 164 | 164 | 24 | 0.73 | +0 | +0.0 |
| HIS TURN DENIED | 110 | 104 | 23 | 0.70 | +862 | +37.5 |
| MARCH BY THE SUM | 23 | 23 | 23 | 0.70 | +1686 | +73.3 |
| WHO HITS BACK | 23 | 23 | 23 | 0.70 | +2178 | +94.7 |
| WOUNDS ON THE RANKS | 117 | 113 | 23 | 0.70 | +1521 | +66.1 |
| CHAFF PASSED | 21 | 21 | 21 | 0.64 | -75 | -3.6 |
| SHOOTERS IN TWO RANKS | 21 | 21 | 21 | 0.64 | +41 | +2.0 |
| NEXT CHARGE BY LIST | 307 | 288 | 20 | 0.61 | +565 | +28.2 |
| CANNON PLANNED TARGET | 224 | 224 | 19 | 0.58 | -208 | -10.9 |
| PROMISE SHOT AWAY | 18 | 18 | 18 | 0.55 | -164 | -9.1 |
| REDIRECT COUNTER | 131 | 101 | 18 | 0.55 | +536 | +29.8 |
| COMBAT PIVOT | 16 | 16 | 16 | 0.48 | +0 | +0.0 |
| AFTERMATH IN POINTS | 15 | 15 | 15 | 0.45 | +2154 | +143.6 |
| NEARER NOT NEEDED | 434 | 422 | 15 | 0.45 | +549 | +36.6 |
| SEARCH SPOT | 25 | 25 | 15 | 0.45 | +578 | +38.5 |
| SECOND LOOK | 15 | 15 | 15 | 0.45 | +1677 | +111.8 |
| FEATURE BUFFS | 117 | 115 | 14 | 0.42 | +140 | +10.0 |
| MANOEUVRE | 64 | 64 | 14 | 0.42 | +263 | +18.8 |
| CASTER AWAY FROM SCREEN | 13 | 13 | 13 | 0.39 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 278 | 218 | 13 | 0.39 | +598 | +46.0 |
| WHO GETS IN | 12 | 12 | 12 | 0.36 | +617 | +51.4 |
| SUPPORT NARROWED | 25 | 25 | 11 | 0.33 | -2216 | -201.5 |
| SURE REACH TOGETHER | 29 | 27 | 11 | 0.33 | +20 | +1.8 |
| REDIRECT WEIGHED | 10 | 10 | 10 | 0.30 | +525 | +52.5 |
| FIRE IN ORDER | 9 | 9 | 9 | 0.27 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.27 | +407 | +45.2 |
| HIS MOVE AND SHOT | 243 | 232 | 9 | 0.27 | +114 | +12.7 |
| ONE PROMISE A TARGET | 9 | 9 | 9 | 0.27 | -968 | -107.6 |
| OPENS UP | 17 | 17 | 9 | 0.27 | +398 | +44.2 |
| OVERRUNS AWAY | 38 | 35 | 9 | 0.27 | +355 | +39.5 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.24 | +0 | +0.0 |
| HIS CHARGE DENIED | 27 | 26 | 8 | 0.24 | +432 | +54.1 |
| MISSILES NEXT TURN | 347 | 263 | 8 | 0.24 | +66 | +8.3 |
| STUCK PIVOT | 8 | 8 | 8 | 0.24 | +0 | +0.0 |
| GUN MASK | 66 | 60 | 7 | 0.21 | +284 | +40.6 |
| HONEST WORTH | 184 | 175 | 7 | 0.21 | +134 | +19.1 |
| REFUSING RETIRES | 15 | 15 | 7 | 0.21 | -2 | -0.3 |
| WHOLE FIGHT GAIN | 14 | 14 | 7 | 0.21 | +262 | +37.4 |
| MARCH OF THE TABLE | 6 | 6 | 6 | 0.18 | -159 | -26.5 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.18 | +136 | +22.7 |
| NO DOUBLE ROUNDS | 176 | 169 | 6 | 0.18 | +87 | +14.6 |
| PROMISE KNOWS THE FIGHT | 23 | 13 | 6 | 0.18 | -79 | -13.2 |
| WAR ENGINE JOBS | 20 | 20 | 6 | 0.18 | -173 | -28.8 |
| BEST PRIZE | 5 | 5 | 5 | 0.15 | -375 | -75.0 |
| FIGHT TO THE END | 47 | 46 | 5 | 0.15 | +68 | +13.5 |
| HIS FIGHT TOGETHER | 120 | 116 | 5 | 0.15 | +204 | +40.8 |
| ONE FIGHT FORMULA | 260 | 135 | 5 | 0.15 | +43 | +8.7 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.15 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 5 | 5 | 5 | 0.15 | -143 | -28.6 |
| AFTERMATH WITH FRIENDS | 4 | 4 | 4 | 0.12 | +224 | +56.0 |
| EDGE GIVE GROUND | 8 | 7 | 4 | 0.12 | +68 | +16.9 |
| FALLBACK BY WORTH | 14 | 14 | 4 | 0.12 | +47 | +11.8 |
| KEEP FALLS | 4 | 4 | 4 | 0.12 | +101 | +25.2 |
| OWN CAST FIRST | 4 | 4 | 4 | 0.12 | -13 | -3.2 |
| PROMISE READS THE TABLE | 16 | 16 | 4 | 0.12 | +291 | +72.8 |
| CHARGE NOT DECLARED | 3 | 3 | 3 | 0.09 | -419 | -139.7 |
| FALL BACK GOOD ORDER | 152 | 145 | 3 | 0.09 | +14 | +4.6 |
| LONG SHOT | 13 | 12 | 3 | 0.09 | +12 | +4.1 |
| MARCH ODDS | 3 | 3 | 3 | 0.09 | -37 | -12.4 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.09 | +109 | +36.4 |
| WIDER SPREAD | 161 | 155 | 3 | 0.09 | +19 | +6.4 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +32 | +16.1 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| HUNT IN PAIRS | 17 | 5 | 2 | 0.06 | +68 | +34.1 |
| MODEL FACING | 2 | 2 | 2 | 0.06 | +110 | +55.2 |
| RUN DOWN | 151 | 143 | 2 | 0.06 | +4 | +1.8 |
| WHAT THE JOINER ADDS | 8 | 8 | 2 | 0.06 | +31 | +15.5 |
| BACKUP TARGETS | 13 | 4 | 1 | 0.03 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.03 | +72 | +72.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 4 | 4 | 1 | 0.03 | -19 | -18.7 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +29 | +28.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +3 | +2.7 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.03 | +83 | +82.6 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.03 | +246 | +245.6 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LOST AFTER ESCAPE | 127 | 124 | 1 | 0.03 | +2 | +1.9 |
| MOVE SPELL IN RANGE | 16 | 9 | 1 | 0.03 | +6 | +6.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +102 | +101.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.03 | -58 | -58.3 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -60 | -60.0 |
| SET UP TOGETHER | 20 | 14 | 1 | 0.03 | +0 | +0.0 |
| STAND AND SHOOT | 43 | 40 | 1 | 0.03 | +24 | +24.1 |
| WHOLE FIGHT | 4 | 4 | 1 | 0.03 | +2 | +1.9 |
| ALREADY CARRIED | 7 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 16 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 83 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 54 | 46 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 23 | 23 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 84 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 54 | 52 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 262 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 26 | 26 | 0 | 0.00 | - | - |
| GIVES UP | 12 | 11 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GUN FIGURES | 47 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 217 | 210 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 374 | 356 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 247 | 227 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 260 | 240 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 94 | 94 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 296 | 277 | 0 | 0.00 | - | - |
| HOLD ODDS | 1098 | 1088 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 8 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 155 | 149 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 12 | 12 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 4 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 12 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 50 | 50 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 71 | 66 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 13 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 37 | trace | - | - | - | - |
| MOVE SPELL SPOT | 45 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 10 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 47 | 44 | 0 | 0.00 | - | - |
| NOT TURNED | 5 | 5 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 23 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 245 | 230 | 0 | 0.00 | - | - |
| ONE ROUTE | 71 | 66 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2672 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 8 | 8 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 71 | 66 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 46 | 46 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 68 | 61 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 18 | 18 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 59 | 56 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 22 | 22 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 55 | 55 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 30 | 30 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 135 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 38 | 37 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 599 | 560 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 73 | 67 | 0 | 0.00 | - | - |
| STANDS STILL | 2436 | 2348 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 10 | 10 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 92 | not checked | - | - | - | - |
| THE PROMISE ADDS | 6 | 6 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE TABLE BINDS | 2076 | not checked | - | - | - | - |
| WAITS AGAIN | 79 | 68 | 0 | 0.00 | - | - |

### Off best figure: base-s2-882d875-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.58 | 3.21 | 40.1 |
| PROMISE BY ITS OWN SUM | rule | 2.48 | 2.97 | 96.0 |
| ARMY TABLE | rule | 1.18 | 2.42 | 58.2 |
| NO REASON | gate | 0.27 | 1.09 | 63.7 |
| HOLDER ASSIGNMENT | rule | 0.73 | 0.55 | 24.7 |
| CHARGE NOW FIRST | rule | 0.36 | 0.36 | 59.2 |
| JOINT CHARGE NOW | rule | 0.27 | 0.24 | 82.3 |
| PROMISE SHOT AWAY | rule | 0.45 | - | 10.9 |
| SUPPORT NARROWED | rule | 0.12 | 0.21 | 201.5 |
| ONE PROMISE A TARGET | rule | 0.12 | 0.15 | 107.6 |
| CANNON PLANNED TARGET | rule | 0.18 | - | 39.7 |
| CHAFF PASSED | rule | 0.09 | 0.09 | 12.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.15 | 0.03 | 13.2 |
| WAR ENGINE JOBS | rule | 0.18 | - | 28.8 |
| BEST PRIZE | rule | 0.06 | 0.09 | 75.0 |
| MARCH OF THE TABLE | rule | 0.09 | 0.06 | 31.8 |
| OWN CAST FIRST | rule | 0.06 | 0.06 | 3.2 |
| WHO GETS IN | rule | 0.09 | 0.03 | 113.4 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.06 | 11.9 |
| MARCH ODDS | rule | 0.06 | 0.03 | 12.4 |
| WALKS ON ITS ROUTE | rule | - | 0.09 | 57.9 |
| CHARGE NOT DECLARED | rule | 0.03 | 0.03 | 209.3 |
| AFTERMATH BAND | gate | - | 0.03 | 2.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 22.6 |
| DEFENSIVE ARMY | rule | - | 0.03 | 18.7 |
| FALLBACK | gate | - | 0.03 | 44.4 |
| FIGHT ORDER BAND | gate | 0.03 | - | 0.5 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.03 | 10.8 |
| PATHS CROSS | rule | 0.03 | - | 7.2 |
| PIVOT GUARDS FLANK | rule | 0.03 | - | 58.3 |
| PURSUES BIG PREY | rule | - | 0.03 | 60.0 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| SET UP BY THE SET | rule | - | 0.03 | 54.5 |
| TURN GATE | gate | 0.03 | - | 5.5 |

### Plans: base-s2-882d875-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.5 | 70% | 346 | 304 | 88% |
| Mine | join | 0.3 | 100% | 17 | 0 | 0% |
| Mine | move | 27.6 | 95% | 1727 | 0 | 0% |
| Mine | shoot | 9.6 | 63% | 418 | 658 | 158% |
| Mine | support | 0.3 | 67% | 2 | 0 | 0% |
| Opponent | charge | 3.0 | 60% | 666 | 317 | 48% |
| Opponent | join | 0.6 | 95% | 36 | 0 | 0% |
| Opponent | move | 32.3 | 95% | 1502 | 0 | 0% |
| Opponent | shoot | 3.2 | 53% | 224 | 142 | 64% |
| Opponent | support | 1.5 | 82% | 2 | 0 | 0% |

### Packages: hunt the guns, base-s2-882d875-p7

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 4 |
| Opponent | 0.1 | 2 | 0 | 50% | 50% | 0% | 2.0 | 434 | 216 | 50% | 64 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 60 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 420 | 0 | 0% | 58 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 449 | 432 | 100% | 79 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |

### Battle groups: base-s2-882d875-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 21% | 56% | 22% | 0% | 14% | 0% | 0% | 57% | 29% |
| Opponent | REDIRECT COUNTER | 2.7 | 23% | 70% | 15% | 0% | 6% | 0% | 6% | 88% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s2-882d875-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 34 | 26 (34) | 1 | 24 | 77 | 38% | 2.2 | 32 (11) | 34 (16) | 0 (7) | 33 (24) | 5 (10) |
| Mine | Character | 118 | 48 (118) | 48 | 0 | 21 | 24% | 2.1 | 53 (56) | 38 (37) | 72 (13) | 51 (61) | 48 (45) |
| Mine | Clean-up | 22 | 65 (22) | 13 | 52 | 20 | 55% | 3.8 | 21 (9) | 128 (9) | 37 (4) | 73 (18) | 0 (4) |
| Mine | Fast Hammer | 40 | 45 (40) | 23 | 22 | 37 | 25% | 2.5 | 53 (14) | 59 (15) | 11 (11) | 56 (29) | 22 (11) |
| Mine | Hammer | 48 | 38 (48) | 23 | 15 | 25 | 27% | 2.5 | 18 (17) | 50 (26) | 55 (5) | 28 (32) | 56 (16) |
| Mine | Holder | 29 | 61 (29) | 6 | 56 | 29 | 52% | 2.4 | 23 (9) | 97 (16) | 0 (4) | 82 (16) | 23 (13) |
| Mine | Shooter | 30 | 48 (30) | 11 | 37 | 32 | 10% | 2.0 | 14 (11) | 84 (13) | 31 (6) | 48 (22) | 46 (8) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 57 | 30 (57) | 30 | 0 | 25 | 5% | 1.7 | 25 (32) | 15 (19) | 110 (6) | 17 (13) | 34 (44) |
| Mine | Wizard | 14 | 42 (14) | 42 | 0 | 43 | 7% | 2.4 | 85 (8) | 0 (3) | - | 0 (3) | 89 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 66 (66) | 15 | 52 | 33 | 56% | 3.0 | 44 (17) | 97 (24) | 45 (25) | 74 (49) | 49 (17) |
| Opponent | Character | 85 | 35 (85) | 34 | 1 | 38 | 19% | 2.1 | 27 (27) | 44 (41) | 32 (12) | 47 (51) | 18 (29) |
| Opponent | Clean-up | 11 | 61 (11) | 17 | 45 | 14 | 36% | 2.9 | 38 (3) | 83 (7) | 0 (1) | 40 (6) | 90 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Fast Hammer | 49 | 35 (49) | 17 | 18 | 35 | 35% | 2.7 | 31 (13) | 32 (26) | 51 (10) | 36 (29) | 33 (20) |
| Opponent | Fragile | 6 | 0 (6) | 0 | 0 | 15 | 50% | 2.3 | 0 (3) | - | 0 (3) | 0 (1) | 0 (5) |
| Opponent | Hammer | 62 | 15 (62) | 13 | 2 | 38 | 35% | 3.1 | 10 (14) | 16 (33) | 18 (15) | 22 (35) | 6 (27) |
| Opponent | Holder | 26 | 74 (26) | 13 | 61 | 9 | 58% | 2.3 | 35 (10) | 125 (9) | 107 (5) | 100 (15) | 47 (9) |
| Opponent | Shooter | 33 | 59 (33) | 20 | 39 | 29 | 9% | 2.0 | 27 (13) | 73 (17) | 124 (3) | 77 (20) | 30 (13) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 8 | 12 (8) | 12 | 0 | 15 | 12% | 1.6 | 11 (6) | 16 (2) | - | - | 12 (8) |
| Opponent | Wizard | 13 | 2 (13) | 2 | 0 | 30 | 8% | 1.8 | 0 (2) | 4 (7) | 0 (2) | 4 (6) | 0 (5) |

### Charged fights: base-s2-882d875-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 41 | 28 | 1.0 | 1.2 | 28 | 34 | -6 | 2 of 4 | 2 of 4 | -52 | +9 |
| Mine | Chaos Dwarfs | 4 | 337 | 218 | 1.8 | 1.0 | 124 | 0 | +124 | 2 of 7 | 6 of 7 | - | +124 |
| Mine | Dwarfen Mountain Holds | 3 | 433 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Empire of Man | 5 | 144 | 106 | 1.0 | 1.4 | 106 | 0 | +106 | 2 of 5 | 4 of 5 | +296 | +58 |
| Mine | Grand Cathay | 5 | 331 | 418 | 2.8 | 1.2 | 149 | 15 | +135 | 3 of 14 | 13 of 14 | +376 | +94 |
| Mine | High Elf Realms | 3 | 138 | 894 | 3.0 | 1.2 | 298 | 7 | +291 | 6 of 9 | 6 of 9 | +494 | +266 |
| Mine | Kingdom of Bretonnia | 2 | 0 | 412 | 3.5 | 1.1 | 118 | 0 | +118 | 1 of 7 | 7 of 7 | +432 | +66 |
| Mine | Ogre Kingdoms | 1 | 19 | 361 | 2.0 | 1.0 | 180 | 0 | +180 | 0 of 2 | 1 of 2 | - | +180 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 182 | 2.0 | 1.0 | 91 | 0 | +91 | 0 of 2 | 1 of 2 | - | +91 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 106 | 504 | 4.5 | 1.3 | 112 | 0 | +112 | 3 of 9 | 6 of 9 | +176 | +80 |
| Mine | Vampire Counts | 2 | 0 | 199 | 3.0 | 1.2 | 66 | 8 | +58 | 0 of 6 | 5 of 6 | -50 | +80 |
| **Mine** | all armies | 33 | 177 | 274 | 2.0 | 1.2 | 137 | 7 | +130 | 19 of 66 | 51 of 66 | +240 | +111 |
| Opponent | Grand Cathay | 3 | 218 | 96 | 3.0 | 1.0 | 32 | 48 | -16 | 3 of 9 | 6 of 9 | - | -16 |
| Opponent | High Elf Realms | 3 | 56 | 283 | 2.0 | 1.0 | 141 | 100 | +42 | 2 of 6 | 6 of 6 | - | +42 |
| Opponent | Lizardmen | 1 | 0 | 571 | 4.0 | 1.0 | 143 | 125 | +18 | 4 of 4 | 2 of 4 | - | +18 |
| Opponent | Ogre Kingdoms | 3 | 137 | 0 | 1.3 | 1.2 | 0 | 191 | -191 | 2 of 4 | 1 of 4 | -479 | -95 |
| Opponent | Skaven | 1 | 0 | 199 | 2.0 | 1.0 | 100 | 292 | -193 | 1 of 2 | 1 of 2 | - | -193 |
| Opponent | Tomb Kings of Khemri | 1 | 60 | 1249 | 8.0 | 1.0 | 156 | 0 | +156 | 4 of 8 | 6 of 8 | - | +156 |
| Opponent | Vampire Counts | 5 | 0 | 246 | 2.8 | 1.1 | 88 | 19 | +69 | 7 of 14 | 10 of 14 | +123 | +65 |
| Opponent | Warriors of Chaos | 8 | 35 | 284 | 1.5 | 1.1 | 190 | 46 | +144 | 7 of 12 | 10 of 12 | +310 | +128 |
| Opponent | Wood Elf Realms | 8 | 121 | 287 | 3.1 | 1.1 | 92 | 14 | +78 | 11 of 25 | 13 of 25 | -52 | +89 |
| **Opponent** | all armies | 33 | 77 | 271 | 2.5 | 1.1 | 107 | 48 | +58 | 41 of 84 | 55 of 84 | -30 | +64 |

### Effective charges: base-s2-882d875-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net -52) | 0 | 0 | 2 (net +13) | 0 | 0 | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 7 | 0 | 0 | 0 | 2 (net +184) | 0 | 4 (net +83) | 1 | 0% (0 of 6) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 5 | 1 (net +0) | 0 | 0 | 2 (net +148) | 0 | 2 (net +116) | 0 | 0% (0 of 5) |
| Mine | Grand Cathay | 14 | 0 | 0 | 3 (net +92) | 2 (net +100) | 4 (net +19) | 4 (net +264) | 1 | 23% (3 of 13) |
| Mine | High Elf Realms | 9 | 2 (net +544) | 1 (net +572) | 1 (net +0) | 2 (net +247) | 0 | 3 (net +157) | 0 | 11% (1 of 9) |
| Mine | Kingdom of Bretonnia | 7 | 0 | 0 | 3 (net +47) | 0 | 2 (net +250) | 1 (net +0) | 1 | 50% (3 of 6) |
| Mine | Ogre Kingdoms | 2 | 1 (net +342) | 0 | 0 | 1 (net +19) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 0 | 1 (net +182) | 0 | 1 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 9 | 3 (net +184) | 1 (net +0) | 0 | 1 (net +122) | 2 (net +65) | 2 (net +102) | 0 | 0% (0 of 9) |
| Mine | Vampire Counts | 6 | 0 | 0 | 2 (net +38) | 1 (net +135) | 1 (net +0) | 0 | 2 | 50% (2 of 4) |
| Opponent | Grand Cathay | 9 | 1 (net +0) | 0 | 0 | 2 (net -217) | 5 (net +58) | 1 (net +0) | 0 | 0% (0 of 9) |
| Opponent | High Elf Realms | 6 | 0 | 0 | 0 | 4 (net +106) | 0 | 2 (net -88) | 0 | 0% (0 of 6) |
| Opponent | Lizardmen | 4 | 1 (net -229) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 1 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 4 | 0 | 0 | 1 (net -251) | 1 (net -479) | 0 | 0 | 2 | 50% (1 of 2) |
| Opponent | Skaven | 2 | 1 (net -45) | 0 | 0 | 1 (net -341) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 8 | 2 (net +64) | 0 | 0 | 4 (net +130) | 0 | 0 | 2 | 0% (0 of 6) |
| Opponent | Vampire Counts | 14 | 4 (net +119) | 0 | 1 (net +0) | 1 (net +123) | 2 (net +133) | 3 (net +35) | 3 | 9% (1 of 11) |
| Opponent | Warriors of Chaos | 12 | 1 (net +0) | 0 | 2 (net +204) | 2 (net +486) | 3 (net +35) | 3 (net +263) | 1 | 18% (2 of 11) |
| Opponent | Wood Elf Realms | 25 | 6 (net -42) | 0 | 2 (net +48) | 6 (net +155) | 0 | 4 (net +46) | 7 | 11% (2 of 18) |

### Charged fights, damage counted: base-s2-882d875-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 312 | 306 | +241 | 252 | 39 | +213 | +68.3 |
| Mine | 50-54% | 2 | 468 | 272 | +286 | 302 | 49 | +253 | +54.1 |
| Mine | Effective (55-75%) | 9 | 295 | 192 | +55 | 101 | 46 | +55 | +18.7 |
| Mine | 76-89% | 14 | 303 | 191 | +119 | 141 | 13 | +128 | +42.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 318 | 166 | +143 | 167 | 25 | +143 | +44.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 427 | 83 | +89 | 92 | 18 | +74 | +17.2 |
| Mine | No odds | 7 | 397 | 172 | +110 | 124 | 29 | +95 | +23.9 |
| Mine | All fights | 66 | 340 | 183 | +130 | 151 | 27 | +124 | +36.4 |
| Opponent | Long shot (under 50%) | 16 | 201 | 267 | +5 | 61 | 72 | -11 | -5.3 |
| Opponent | Effective (55-75%) | 7 | 337 | 230 | +36 | 83 | 88 | -4 | -1.3 |
| Opponent | 76-89% | 21 | 336 | 208 | +82 | 161 | 101 | +60 | +17.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 330 | 236 | +65 | 174 | 67 | +107 | +32.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 361 | 68 | +66 | 66 | 11 | +55 | +15.1 |
| Opponent | No odds | 16 | 224 | 253 | +81 | 185 | 79 | +106 | +47.1 |
| Opponent | All fights | 84 | 291 | 218 | +58 | 131 | 74 | +57 | +19.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s2-882d875-p7 | move | 167 | 49 (29%) | 38 (23%) | 28 (17%) | 90 (54%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0112, L0128, L2435, L2632 |
| Charmed Shield | Opponent | L0727, L0924, L1124, L1234, L1424, L1934, L2225 |
| Clockwork Compass | Mine | L1218, L1234 |
| Clockwork Compass | Opponent | L0112, L0212 |
| Elixir of Power | Mine | L1124, L1934 |
| Elixir of Power | Opponent | L0711 |
| Fistful of Laurels | Mine | L1833 |
| Fistful of Laurels | Opponent | L0518, L1218, L1618 |
| Horn of the Wild Hunt | Opponent | L0833, L1833 |
| Invocation of Nehek | Mine | L2435 |
| Invocation of Nehek | Opponent | L0727, L0924, L1124, L1424, L2225 |
| Opal Amulet | Mine | L1424 |
| Periapt of Soul Exchange | Mine | L2035 |
| Periapt of Soul Exchange | Opponent | L1521 |
| Ring of Doom | Mine | L0212, L0228, L1124, L1218, L1234, L1521 |
| Ring of Doom | Opponent | L0112, L0212, L0415, L0711, L0833, L1015, L1833 |
| Ring of Jet | Mine | L1015, L1032, L1124, L1218, L1234 |
| Ring of Jet | Opponent | L0112, L0212, L0711 |
| Standard of the Fell Warrior | Mine | L1329 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L1521 |
| Twice-Blessed Armour | Mine | L0711, L0727, L1015, L1032 |
| Witch Hunter's Ward | Mine | L0711, L0727, L0817, L0833 |

# Doctrine scorecard: base-s2-882d875-p5

### Scorecard: base-s2-882d875-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0104 | 2 | 2 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0104 | 2 | 2 | Opponent | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 499 |
| L0120 | 6 | 2 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 2 | Opponent | no | 3 | - | 0 | 4 | 0 | 0 | 0 | 210 |
| L0204 | 6 | 2 | Mine | no | 10 | 4 | 0 | 2 | 1 | 0 | 0 | 170 |
| L0204 | 6 | 2 | Opponent | no | 0 | 1 | 2 | 1 | 0 | 0 | 0 | 120 |
| L0220 | 4 | 2 | Mine | no | 1 | 4 | 2 | 4 | 0 | 0 | 0 | 52 |
| L0220 | 4 | 2 | Opponent | no | 0 | - | 1 | 2 | 1 | 0 | 0 | 440 |
| L0305 | 5 | 2 | Mine | no | - | - | 0 | 6 | 0 | 0 | 0 | 85 |
| L0305 | 5 | 2 | Opponent | no | - | - | 0 | 3 | 0 | 0 | 0 | 589 |
| L0321 | 3 | 2 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 85 |
| L0321 | 3 | 2 | Opponent | no | 1 | - | 0 | 6 | 0 | 0 | 0 | 55 |
| L0407 | 5 | 2 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0407 | 5 | 2 | Opponent | yes | - | - | 0 | 3 | 0 | 0 | 0 | 315 |
| L0423 | 3 | 2 | Mine | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0423 | 3 | 2 | Opponent | no | 2 | 3 | 1 | 1 | 1 | 0 | 0 | 72 |
| L0510 | 6 | 2 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 373 |
| L0510 | 6 | 2 | Opponent | no | 10 | 4 | 1 | 0 | 0 | 0 | 0 | 165 |
| L0526 | 4 | 2 | Mine | no | 2 | 6 | 1 | 1 | 0 | 0 | 0 | 853 |
| L0526 | 4 | 2 | Opponent | no | 0 | 2 | 5 | 4 | 1 | 0 | 0 | 60 |
| L0614 | 2 | 2 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 1087 |
| L0614 | 2 | 2 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0630 | 6 | 2 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 230 |
| L0630 | 6 | 2 | Opponent | no | 3 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0719 | 5 | 2 | Mine | no | - | 3 | 0 | 2 | 0 | 0 | 0 | 125 |
| L0719 | 5 | 2 | Opponent | yes | - | 3 | 3 | 5 | 1 | 0 | 0 | 60 |
| L0735 | 3 | 2 | Mine | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 170 |
| L0735 | 3 | 2 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0825 | 3 | 2 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 216 |
| L0825 | 3 | 2 | Opponent | no | 6 | 6 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0915 | 3 | 2 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 611 |
| L0915 | 3 | 2 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 126 |
| L0932 | 2 | 2 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 546 |
| L0932 | 2 | 2 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 340 |
| L1024 | 4 | 2 | Mine | no | 6 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1024 | 4 | 2 | Opponent | no | 3 | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L1116 | 6 | 2 | Mine | no | 9 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1116 | 6 | 2 | Opponent | no | 0 | 6 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1133 | 5 | 2 | Mine | yes | - | - | 0 | 1 | 0 | 0 | 0 | 165 |
| L1133 | 5 | 2 | Opponent | no | - | 4 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1226 | 2 | 2 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1226 | 2 | 2 | Opponent | - | - | 2 | 7 | 3 | 1 | 0 | 0 | 0 |
| L1321 | 1 | 2 | Mine | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 230 |
| L1321 | 1 | 2 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 577 |
| L1416 | 6 | 2 | Mine | no | 8 | 1 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1416 | 6 | 2 | Opponent | no | 5 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1433 | 5 | 2 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1433 | 5 | 2 | Opponent | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 387 |
| L1529 | 5 | 2 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 176 |
| L1529 | 5 | 2 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L1627 | 1 | 2 | Mine | no | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 100 |
| L1627 | 1 | 2 | Opponent | no | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1725 | 3 | 2 | Mine | no | 9 | 4 | 3 | 0 | 0 | 0 | 0 | 399 |
| L1725 | 3 | 2 | Opponent | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1825 | 1 | 2 | Mine | no | 0 | - | 3 | 0 | 0 | 0 | 0 | 40 |
| L1825 | 1 | 2 | Opponent | no | 0 | 4 | 4 | 4 | 0 | 0 | 0 | 75 |
| L1925 | 5 | 2 | Mine | no | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L1925 | 5 | 2 | Opponent | yes | - | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| L2027 | 5 | 2 | Mine | yes | - | - | 0 | 6 | 0 | 0 | 0 | 874 |
| L2027 | 5 | 2 | Opponent | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2129 | 5 | 2 | Mine | yes | - | - | 0 | 6 | 0 | 0 | 0 | 275 |
| L2129 | 5 | 2 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 170 |
| L2233 | 1 | 2 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2233 | 1 | 2 | Opponent | no | 5 | 1 | 3 | 3 | 0 | 0 | 0 | 224 |
| L2426 | 2 | 2 | Mine | - | - | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L2426 | 2 | 2 | Opponent | - | - | 2 | 8 | 2 | 0 | 0 | 0 | 40 |
| L2533 | 1 | 2 | Mine | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2533 | 1 | 2 | Opponent | yes | 7 | 2 | 1 | 3 | 0 | 0 | 0 | 368 |
| L2733 | 3 | 2 | Mine | no | 1 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L2733 | 3 | 2 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 190 |
| L3031 | 1 | 2 | Mine | no | 1 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L3031 | 1 | 2 | Opponent | no | 5 | - | 4 | 0 | 1 | 0 | 0 | 340 |
| **Average** | | | Mine | 19% | 2.5 | 2.6 | 1.8 | 2.0 | 0.1 | 0.0 | 0.0 | 195.2 |
| **Average** | | | Opponent | 23% | 2.3 | 2.5 | 2.6 | 2.8 | 0.2 | 0.0 | 0.0 | 155.3 |

### KPIs: base-s2-882d875-p5

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (51 of 159) | 7% (11 of 162) | 19% (62 of 321) |
| Winner chose to follow up after the loser gave ground |  | 74% (34 of 46); on the table 87% | 90% (45 of 50); on the table 94% | 82% (79 of 96); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | 71% (5 of 7); on the table 71% | 67% (10 of 15); on the table 67% | 68% (15 of 22); on the table 68% |
| Winner chose to pursue after the loser fled |  | 62% (10 of 16); on the table 62% | 75% (9 of 12); on the table 75% | 68% (19 of 28); on the table 68% |
| Winner chose to follow up or pursue (all three) |  | 71% (49 of 69); on the table 80% | 83% (64 of 77); on the table 86% | 77% (113 of 146); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 37% (120 of 324) | 30% (57 of 192) | 34% (177 of 516) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (120 of 268) | 35% (57 of 164) | 41% (177 of 432) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (18 of 31) | 55% (39 of 71) | 56% (57 of 102) |
| Points that never fought | lower | 49% (34653 of 70841) | 49% (35552 of 71983) | 49% (70205 of 142824) |
|   infantry points that never fought | lower | 60% (9553 of 15898) | 71% (11262 of 15955) | 65% (20815 of 31853) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 66% (186 of 282) | 66% (181 of 276) | 66% (367 of 558) |
| Bound items with a magic missile used (at least once a game) |  | 85% (17 of 20); 1.8 uses a game | 78% (14 of 18); 1.2 uses a game | 82% (31 of 38); 1.5 uses a game |
| Bound items with another spell used |  | 26% (5 of 19); 0.2 uses a game | 25% (2 of 8); 0.2 uses a game | 26% (7 of 27); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 47% (7 of 15); 0.2 uses a game | 54% (19 of 35); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (36466 of 59757) | 59% (37394 of 63684) | 60% (73860 of 123441) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.4 (43%) | 1.9 (50%) | 4.3 (46%) |
| MARCHED: its unit marched | 1.0 (18%) | 0.8 (21%) | 1.8 (19%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.4 (7%) | 0.6 (15%) | 0.9 (10%) |
| REAR RANK: in a rear rank | 0.3 (6%) | 0.2 (4%) | 0.5 (5%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) |
| GONE: slain | 0.8 (15%) | 0.2 (5%) | 1.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.2 | 1.2 | 3.4 | 4.9 | 0.9 | 1.1 |
| not cast | 3.7 | 2.0 | 3.6 | 9.4 | 2.6 | 21.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (64%) | 0.5 (14%) | 4.3 (46%) | 1.0 (38%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (19%) | 0.3 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (6%) | 0.4 (12%) | 0.9 (10%) | 0.2 (6%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.0 (0%) | 0.3 (9%) | 0.5 (5%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.5 (13%) | 0.3 (14%) | 0.5 (15%) | 1.0 (11%) | 0.2 (6%) | 1.9 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (10%) | 0.1 (3%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (11%) | 0.1 (2%) | 0.1 (1%) | 0.9 (34%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (61%) | 0.1 (3%) | 1.6 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.2 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.5 a game | 1.1 a game | 1.8 a game |
| stood (cast and not dispelled) | 56% (48 of 85) | 59% (19 of 32) | 57% (67 of 117) |
| the unit moved after it | 50% (24 of 48) | 63% (12 of 19) | 54% (36 of 67) |
| it charged on its next turn | 6% (3 of 48) | 0% (0 of 19) | 4% (3 of 67) |
| the enemy charged it first | 10% (5 of 48) | 0% (0 of 19) | 7% (5 of 67) |
| it fought by the end of its next turn | 8% (4 of 48) | 0% (0 of 19) | 6% (4 of 67) |
| it moved out of a charge the enemy had planned (not charged first) | 2% (1 of 48) | 0% (0 of 19) | 1% (1 of 67) |
| none of these (no charge, no fight, no charge escaped) | 79% (38 of 48) | 100% (19 of 19) | 85% (57 of 67) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (555 of 920) | 56% (277 of 492) | 59% (832 of 1412) |
|   cavalry | 60% (43 of 72) | 56% (71 of 126) | 58% (114 of 198) |
|   character | 48% (58 of 120) | 43% (36 of 83) | 46% (94 of 203) |
|   chariot | 63% (66 of 105) | 39% (16 of 41) | 56% (82 of 146) |
|   infantry | 58% (156 of 267) | 62% (109 of 177) | 60% (265 of 444) |
|   monster | 72% (31 of 43) | - | 72% (31 of 43) |
|   war machine | 64% (201 of 313) | 69% (45 of 65) | 65% (246 of 378) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (15%) | 1.0 (17%) | 2.5 (16%) |
| CHARGED: it charged | 0.6 (6%) | 1.0 (16%) | 1.6 (10%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.6 (9%) | 1.3 (8%) |
| MOVED: a war machine that moved | 2.0 (19%) | 0.5 (8%) | 2.5 (15%) |
| NO TARGET IN RANGE | 2.6 (25%) | 1.6 (27%) | 4.2 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.2 (4%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (15%) | 1.0 (16%) | 2.5 (16%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.4 | 0.7 | 87% | 3.0 pts | 13 pts |
| character | 2.9 | 1.1 | 68% | 12.2 pts | 35 pts |
| chariot | 2.3 | 1.1 | 70% | 10.4 pts | 24 pts |
| infantry | 11.1 | 3.7 | 77% | 7.6 pts | 84 pts |
| monster | 1.1 | 0.2 | 90% | 3.2 pts | 4 pts |
| war machine | 6.8 | 6.6 | 59% | 37.1 pts | 253 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.6 | 4.1 | 3.3 |
| Charges that made contact a game | 1.9 | 3.2 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.43 declared, 0.26 contact (23 units) | 0.76 declared, 0.62 contact (21 units) | 0.59 declared, 0.43 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.55 declared, 0.45 contact (11 units) | 1.25 declared, 1.00 contact (16 units) | 0.96 declared, 0.78 contact (27 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.31 declared, 0.23 contact (251 units) | 0.39 declared, 0.30 contact (282 units) | 0.35 declared, 0.27 contact (533 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (41 of 70) | 65% (15 of 23) | 71% (5 of 7) | 61% (61 of 100) |
| Character in a unit | 93% (38 of 41) | 55% (11 of 20) | 86% (6 of 7) | 81% (55 of 68) |
| Character on its own | 88% (35 of 40) | 62% (20 of 32) | 31% (20 of 64) | 55% (75 of 136) |
| Chariot | 64% (9 of 14) | 60% (9 of 15) | - | 62% (18 of 29) |
| Infantry | 61% (46 of 76) | 63% (31 of 49) | 75% (3 of 4) | 62% (80 of 129) |
| Monster | 70% (14 of 20) | 67% (8 of 12) | - | 69% (22 of 32) |
| Monstrous | 75% (6 of 8) | 100% (11 of 11) | - | 89% (17 of 19) |
| War Machines | 88% (38 of 43) | 50% (1 of 2) | - | 87% (39 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 67% (4 of 6); on the table 67% | 44% (45 of 102) | 51% | 55% (12 of 22) | 100% (6 of 6); 6.5 uses a game | 100% (2 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 6 | 83% (5 of 6); on the table 100% | 38% (18 of 48) | 64% | 62% (30 of 48) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 67% (6 of 9); on the table 67% | - | 63% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 70% (7 of 10); on the table 70% | 37% (11 of 30) | 41% | 77% (49 of 64) | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 5 | 33% (2 of 6); on the table 50% | 32% (37 of 114) | 61% | 56% (25 of 45) | 73% (8 of 11); 4.8 uses a game | 0% (0 of 2); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 72% (13 of 18); on the table 78% | 42% (5 of 12) | 39% | 47% (23 of 49) | 100% (5 of 5); 3.2 uses a game | 20% (4 of 20); 1.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 75% (3 of 4); on the table 75% | - | 59% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 16% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 37% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (5 of 5); on the table 100% | 11% (2 of 18) | 33% | 94% (15 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 6 | 67% (2 of 3); on the table 67% | 29% (12 of 42) | 70% | 75% (36 of 48) | 33% (1 of 3); 0.5 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 2 | 88% (7 of 8); on the table 88% | 0% (0 of 6) | 22% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 13 | 76% (29 of 38); on the table 87% | 30% (27 of 90) | 44% | 66% (51 of 77) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 88% (15 of 17); on the table 88% | 50% (3 of 6) | 34% | 59% (26 of 44) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| Wood Elf Realms | 6 | 92% (12 of 13); on the table 100% | 39% (14 of 36) | 52% | 73% (45 of 62) | 82% (9 of 11); 4.7 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s2-882d875-p5, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (33) | 55% (28) | 51% (61) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.56 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.11 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.25 | 0.58 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.03 | 0.00 | 0.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.03 | 0.00 | 0.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.28 | 0.22 | 0.50 |

### Quality by phase: base-s2-882d875-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.4 |
| Strategy | Charge objectives carried out (made contact) | 54% (44 of 81) | 54% (68 of 125) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (124 of 408) | 51% (74 of 146) |
| Strategy | Support requests answered (helper made contact too) | 50% (4 of 8) | 69% (11 of 16) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (6 of 8) | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 45% (21 of 47) | 33% (17 of 52) |
| Strategy | Lone characters that fought | 65% (62 of 96) | 70% (54 of 77) |
| Movement | Charges halted short of contact | 0.1 | 0.0 |
| Movement | Idle units | 2.0 | 2.8 |
| Movement | Points that never moved of their own | 195.2 | 155.3 |
| Movement | Fights charged into per game | 1.8 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 54, net +27 | 29 of 81, net +80 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 54, net +89 | 11 of 81, net +92 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 54, net +130 | 9 of 81, net +106 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 of 54, net +113 | 16 of 81, net +74 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.6 | 7.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (180 of 380) | 49% (125 of 253) |
| Shooting | Points destroyed by shooting units | 30.7 | 39.7 |
| Shooting | War machine shots | 5.6 | 1.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (97 of 201) | 44% (20 of 45) |
| Shooting | Points destroyed by war machines | 53.0 | 23.8 |
| Magic | Magic missiles cast | 2.0 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (21 of 71) | 44% (17 of 39) |
| Magic | Wounds caused by magic missiles | 4.5 | 1.5 |
| Magic | Wounds caused by other spells | 0.8 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 40.8 | 43.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 0.4 / 0.1 | 2.3 / 0.2 / 0.4 / 0.4 |
| Combat | Points destroyed in combat | 234.6 | 288.5 |
| Combat | Points run down | 46.4 | 51.1 |
| Combat | Net points per charged fight, damage counted | +86 | +95 |
| Combat | Net per 100 charger points, damage counted | +30.1 | +29.9 |
| Combat | First round won (charged fights) | 70% | 68% |
| Combat | Net points per charged fight | +93 | +89 |
| Combat | Net points per supported fight / lone fight | +0 / +99 | +88 / +89 |
| Combat | Charged fights on a top-3 enemy unit | 23 of 66 | 51 of 99 |
| Game | Points lost | 565.4 | 532.2 |
| Game | VP from objectives | 643.3 | 567.8 |
| Game | Lone holders (player turns) | 2.5 | 2.3 |

- Mine won / drew / lost: 16 / 7 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) +12 VP
- The side that went first won 12 of 29 games with a winner
- Points traded per game (both sides' losses): 1098
- Games not ended: 0; findings 8, warnings 0

### Opponent rules: base-s2-882d875-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.4 | +64.7 | 0.0 | 0.0 | 0.1 | +16.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.1 | +2.4 | 0.0 | 0.0 | 0.1 | +1.6 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.9 | +330.7 | 0.0 | 217.6 | 19.8 | +118.9 | 0.0 | 213.1 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 14.9 | 0.3 | +0.0 | 0.0 | 7.2 |
| BACKUP TARGETS | 0.2 | +2.2 | 0.0 | 0.0 | 0.2 | +1.7 | 0.0 | 11.1 |
| BEST PRIZE | 0.1 | -9.8 | 1.2 | 5.2 | 0.1 | -5.6 | 5.1 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -8.3 | 7.6 | 2.9 | 0.1 | -10.6 | 8.9 | 0.0 |
| BOMBING RUN | 0.1 | +11.8 | 4.2 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 44.1 | 0.0 | 0.1 | +0.0 | 12.8 | 0.0 |
| CANNON PLANNED TARGET | 5.5 | +131.2 | 276.6 | 62.6 | 1.2 | +63.3 | 78.1 | 26.1 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.6 |
| CARRIES OUT SET-UP | 0.0 | -9.4 | 0.0 | 0.0 | 0.1 | -1.1 | 27.0 | 13.9 |
| CAST JOB | 1.5 | +29.0 | 57.0 | 48.7 | 0.7 | +15.7 | 5.3 | 12.3 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.0 | +29.8 | 12.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.4 | +0.0 | 0.0 | 33.9 | 0.6 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +39.5 | 0.0 | 1.1 | 1.4 | +51.5 | 0.0 | 30.5 |
| CHAFF PASSED | 0.1 | -0.6 | 2.9 | 1.5 | 0.2 | -0.1 | 4.7 | 3.1 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -4.6 | 7.7 | 0.0 | 0.2 | -5.1 | 33.6 | 7.1 |
| CHARACTER GUNS | 1.5 | +0.0 | 0.0 | 0.0 | 1.6 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| CHARGE LOSSES | 9.1 | -427.0 | 0.0 | 276.5 | 12.3 | -753.0 | 0.0 | 241.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.1 | +0.0 | 5.8 | 0.0 |
| CHARGE NOW FIRST | 1.5 | +0.0 | 173.5 | 18.3 | 2.0 | +0.0 | 182.8 | 30.2 |
| CHARGER SLAIN LOST | 0.3 | -16.4 | 15.4 | 5.7 | 0.4 | -10.5 | 34.3 | 18.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 22.1 | 0.2 | +0.0 | 8.9 | 10.1 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 1.1 | 0.0 |
| CONVEYANCE SEARCH | 2.3 | +239.7 | 44.4 | 57.6 | 0.7 | +57.3 | 0.0 | 0.0 |
| COVER ONCE | 6.8 | -402.6 | 0.0 | 147.1 | 4.5 | -311.5 | 0.0 | 113.2 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 1.8 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | -1.7 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -3.1 | 16.2 | 1.2 | 1.1 | -13.4 | 108.5 | 10.3 |
| DEPLOY BY FIGURES | 8.0 | -13.2 | 0.0 | 0.0 | 7.6 | +60.8 | 0.0 | 23.4 |
| EDGE GIVE GROUND | 0.2 | +9.6 | 28.1 | 0.0 | 0.1 | +6.3 | 27.9 | 0.0 |
| ELIXIR WORTH | 0.0 | +1.4 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.0 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.6 | +2.9 | 135.7 | 34.1 | 2.8 | +11.8 | 205.0 | 83.2 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.5 |
| FALLS SHORT | 5.1 | +79.3 | 0.0 | 28.8 | 14.8 | +200.2 | 0.0 | 162.4 |
| FEATURE BUFFS | 3.4 | +55.5 | 0.0 | 19.7 | 0.7 | +11.5 | 0.0 | 11.6 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.6 | +10.5 | 76.3 | 4.6 | 1.2 | +25.4 | 104.2 | 20.9 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 6.0 | 0.1 | +0.0 | 2.9 | 0.0 |
| FIVE ACTION | 93.6 | +6006.6 | 1071.7 | 1071.8 | 84.3 | +4617.8 | 710.6 | 1075.2 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 146.3 | 4.1 | +0.0 | 0.0 | 111.2 |
| FOCUS FIRE | 0.1 | +0.3 | 0.5 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.5 | +84.7 | 0.0 | 26.1 | 0.9 | +155.4 | 0.0 | 30.2 |
| FOUR ROUNDS | 2.5 | +241.4 | 244.5 | 43.9 | 3.8 | +363.3 | 319.8 | 104.6 |
| FRIEND CHARGES FIRST | 0.0 | -1.4 | 0.0 | 0.0 | 0.0 | -4.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -33.1 | 1.7 | 5.8 | 0.1 | -1.4 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +3.9 | 0.0 | 0.0 | 0.1 | +6.2 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -4.2 | 21.9 | 0.0 | 0.2 | -2.5 | 18.1 | 4.5 |
| GUN FIGURES | 1.0 | +10.0 | 23.8 | 24.9 | 0.4 | +2.2 | 8.6 | 9.0 |
| GUN MASK | 1.2 | +54.6 | 0.0 | 0.0 | 0.2 | +5.8 | 0.0 | 4.4 |
| HARD STAY DROPPED | 2.5 | +0.0 | 0.0 | 10.3 | 1.4 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.4 | +0.0 | 0.0 | 98.8 | 3.1 | +0.0 | 0.0 | 68.7 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 1.4 | - | - | - | - |
| HIS CHARGE DENIED | 0.4 | +9.1 | 41.0 | 13.1 | 0.2 | +5.9 | 21.4 | 0.5 |
| HIS CHARGE LIST | 4.6 | +0.0 | 0.0 | 71.5 | 5.8 | +0.0 | 0.0 | 105.1 |
| HIS FIGHT TOGETHER | 2.4 | -60.1 | 0.0 | 106.4 | 2.0 | -83.6 | 0.0 | 91.4 |
| HIS LEGAL MOVES | 4.2 | +0.0 | 0.0 | 56.0 | 4.6 | +0.0 | 0.0 | 83.6 |
| HIS MOVE AND SHOT | 2.4 | -42.6 | 0.0 | 114.3 | 3.8 | -86.7 | 0.0 | 88.6 |
| HIS MOVE AS HE DECIDES | 38.8 | +13.6 | 570.4 | 0.0 | 35.9 | +14.7 | 530.3 | 0.0 |
| HIS MOVE WHY | 36.6 | +0.0 | 0.0 | 418.5 | 37.3 | +0.0 | 0.0 | 470.8 |
| HIS ONE MOVE | 18.3 | +63.1 | 0.0 | 83.3 | 20.1 | +44.9 | 7.2 | 99.4 |
| HIS ONE QUARTER | 4.1 | +0.0 | 0.0 | 58.9 | 5.1 | +0.0 | 0.0 | 48.1 |
| HIS OWN BEST MOVE | 1.9 | +0.0 | 0.0 | 16.9 | 2.0 | +0.0 | 0.0 | 63.1 |
| HIS RANDOM MOVE | 7.0 | +0.0 | 0.0 | 93.8 | 3.1 | +0.0 | 0.0 | 12.9 |
| HIS SHOT LIST | 31.7 | +1231.9 | 0.0 | 379.8 | 46.3 | +2268.0 | 0.0 | 614.6 |
| HIS TURN DENIED | 0.9 | +32.9 | 65.2 | 6.5 | 2.1 | +122.3 | 179.9 | 70.8 |
| HOLD ODDS | 18.8 | +0.0 | 0.0 | 129.2 | 13.9 | +0.0 | 0.0 | 175.3 |
| HOLDER ASSIGNMENT | 10.0 | +977.4 | 0.0 | 58.9 | 8.6 | +803.1 | 0.0 | 86.4 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.1 | -85.6 | 212.1 | 19.6 | 3.3 | -193.0 | 285.0 | 95.3 |
| HORN WORTH | - | - | - | - | 0.1 | +2.4 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 2.6 | 3.1 |
| HUNT IN PAIRS | 0.3 | +7.5 | 0.0 | 6.0 | 0.2 | +14.4 | 0.0 | 10.2 |
| HUNT RESULT | - | - | - | - | 0.1 | +7.1 | 6.4 | 3.1 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +11.5 | 3.8 | 0.0 |
| IDLE COST | 4.4 | -57.6 | 0.0 | 27.1 | 11.8 | -182.7 | 0.0 | 128.4 |
| JOINT CHARGE NOW | 0.5 | +26.4 | 24.8 | 2.9 | 0.8 | +54.7 | 71.7 | 18.4 |
| JOINT KNOWS CHALLENGE | 0.1 | -6.6 | 0.0 | 0.0 | 0.1 | -0.2 | 12.9 | 0.0 |
| JOINT LOOK BACK | 0.0 | +0.3 | 3.1 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | - | - | - | - | 0.1 | +13.0 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.6 | +0.0 | 0.0 | 31.3 | 2.3 | +0.0 | 0.0 | 3.7 |
| LANE BY FIGURES | 0.7 | +18.0 | 0.0 | 0.0 | 0.9 | +38.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 153.1 | 172.2 | 5.4 | +0.0 | 232.4 | 269.5 |
| LONE CHARACTER SAFE SPOT | 0.1 | +2.8 | 0.0 | 0.0 | 0.1 | +1.9 | 11.1 | 5.9 |
| LONE WIZARD KEPT IN | 0.6 | +31.7 | 0.0 | 0.0 | 0.2 | +19.1 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +2.4 | 10.2 | 3.5 | 0.2 | +0.0 | 18.0 | 6.1 |
| LOST AFTER ESCAPE | 1.4 | +2.3 | 160.5 | 33.0 | 1.8 | +4.1 | 139.7 | 68.8 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -2.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +8.5 | 0.0 | 0.0 | 0.2 | +3.8 | 0.0 | 21.8 |
| MANOEUVRE | 1.1 | -0.3 | 0.0 | 16.8 | 0.7 | +0.0 | 0.0 | 12.7 |
| MARCH AT ESCAPER | 0.2 | +2.0 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +12.5 | 0.0 | 0.0 | 0.3 | +12.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +17.9 | 0.0 | 0.0 | 0.6 | +32.6 | 0.0 | 14.8 |
| MARCH OF THE TABLE | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +16.0 | 0.0 | 13.9 | 0.6 | +81.1 | 0.0 | 5.8 |
| MARCH WHEELS ONLY | 0.9 | +0.0 | 0.0 | 8.2 | 0.9 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.9 | +65.6 | 0.0 | 27.0 | 3.1 | +89.2 | 0.0 | 32.1 |
| MISSILES IN THE MOVE | 4.3 | +126.2 | 0.0 | 55.5 | 3.4 | +50.7 | 0.0 | 48.9 |
| MISSILES NEXT TURN | 5.2 | +85.1 | 0.0 | 50.8 | 4.6 | +45.4 | 0.0 | 65.0 |
| MISSILES ON ONE TARGET | 0.4 | -11.8 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | 0.4 | +157.3 | 0.0 | 1.7 | - | - | - | - |
| MOVE ORDER | 1.4 | +0.0 | 5.8 | 8.7 | 2.1 | +0.0 | 6.4 | 31.1 |
| MOVE SPELL IN RANGE | 0.5 | +18.3 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -41.3 | 0.0 | 0.0 | 0.4 | -7.4 | 8.2 | 0.0 |
| MOVE SPELL SPOT | 0.9 | +0.0 | 0.0 | 27.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.5 | +725.5 | 0.0 | 45.2 | 7.6 | +674.4 | 0.0 | 122.6 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 6.1 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.4 | +352.9 | 0.0 | 76.0 | 6.8 | +277.8 | 0.0 | 71.7 |
| NEXT CHARGE BY LIST | 5.3 | -201.6 | 17.0 | 51.3 | 6.8 | -350.1 | 4.7 | 109.2 |
| NEXT OBJECTIVE NEARER | 0.1 | -2.2 | 0.0 | 0.0 | 0.1 | -4.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.9 | -88.7 | 185.9 | 34.9 | 2.6 | -127.1 | 229.0 | 72.7 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.2 | 0.0 | 3.5 | - | - | - | - |
| NOT TURNED | 0.3 | -0.6 | 0.0 | 1.1 | 0.2 | -0.1 | 0.0 | 5.6 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 20.6 | 0.7 | -0.4 | 0.0 | 1.7 |
| OFF BEST | 3.8 | -172.5 | 4.7 | 68.7 | 3.9 | -148.3 | 7.9 | 47.6 |
| ONE CHARGE A CHARGER | 4.7 | +0.0 | 0.0 | 112.9 | 3.4 | +0.0 | 0.0 | 82.9 |
| ONE FIGHT FORMULA | 4.2 | -81.3 | 0.0 | 43.9 | 5.4 | -115.7 | 0.0 | 86.4 |
| ONE OBJECTIVE FORMULA | 4.8 | +117.2 | 0.0 | 25.6 | 3.3 | -8.7 | 0.0 | 64.2 |
| ONE PROMISE A TARGET | 0.2 | -7.0 | 8.1 | 0.0 | 0.1 | -5.5 | 0.0 | 7.7 |
| ONE ROUTE | 0.9 | +0.0 | 0.0 | 8.2 | 0.9 | +0.0 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 23.6 | +553.7 | 0.0 | 210.9 | 32.2 | +858.6 | 0.0 | 453.8 |
| OPENS A LANE | 0.2 | +0.5 | 18.1 | 0.0 | 0.0 | +0.0 | 0.0 | 2.8 |
| OPENS UP | 0.1 | +6.1 | 7.9 | 13.1 | 0.4 | +46.7 | 21.2 | 0.0 |
| OVERRUNS AWAY | 0.3 | +12.3 | 32.2 | 13.1 | 0.5 | +18.3 | 46.7 | 23.6 |
| OWN CAST FIRST | 0.0 | -0.5 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| PATHS CROSS | 0.8 | +32.3 | 0.0 | 0.0 | 0.5 | +36.9 | 0.0 | 2.9 |
| PERIAPT WORTH | 0.0 | +1.8 | 0.0 | 0.0 | 0.1 | +5.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -5.3 | 0.0 | 5.2 | 0.1 | -0.1 | 0.0 | 0.0 |
| PLAN RESULT | 43.3 | +839.2 | 428.5 | 765.7 | 41.0 | +421.4 | 316.8 | 802.4 |
| PROMISE BELOW ZERO | 0.2 | +0.0 | 0.0 | 17.3 | 0.4 | +0.0 | 0.0 | 18.6 |
| PROMISE BY ITS OWN SUM | 7.7 | -292.7 | 0.0 | 12.1 | 9.3 | -253.9 | 0.0 | 37.9 |
| PROMISE IN STEPS | 0.2 | +0.0 | 1.7 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -3.4 | 1.7 | 0.0 | 1.1 | -0.5 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.4 | -25.4 | 0.0 | 0.0 | 0.2 | -14.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.2 | -3.3 | 33.6 | 0.0 | 0.2 | -0.8 | 15.1 | 0.0 |
| PURSUES BIG PREY | 0.1 | -6.6 | 0.0 | 0.0 | 0.0 | -5.8 | 0.0 | 0.0 |
| QUARTER ODDS | 17.7 | +1910.3 | 119.6 | 213.6 | 15.9 | +1632.4 | 190.4 | 146.9 |
| RANDOM MOVE BY FIGURES | 0.9 | +25.6 | 0.0 | 13.5 | 2.0 | +41.7 | 0.0 | 71.1 |
| REAL GROUND | 0.9 | +0.0 | 0.0 | 8.2 | 0.9 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.8 | -18.7 | 0.0 | 2.3 | 1.2 | -33.1 | 0.0 | 26.8 |
| REDIRECT COUNTER | 2.3 | +94.0 | 0.0 | 27.1 | 2.4 | +164.1 | 0.0 | 39.2 |
| REDIRECT WEIGHED | 0.2 | +1.5 | 0.0 | 5.2 | 0.3 | +8.1 | 9.2 | 13.6 |
| REFORMS TO MEET IT | 1.8 | -44.7 | 0.0 | 28.1 | 1.1 | -34.2 | 0.0 | 27.6 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 26.8 | 0.8 | +0.0 | 0.0 | 12.4 |
| RESERVE FALL BACK | 0.4 | +14.0 | 0.0 | 6.4 | 0.6 | +16.8 | 0.0 | 19.5 |
| RESTRAINS TO SHOOT | 0.0 | +0.3 | 0.0 | 2.9 | 0.1 | +2.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.6 | +31.9 | 174.9 | 38.9 | 2.0 | -4.0 | 183.6 | 74.7 |
| RISK BY HIS FIGURE | 23.2 | -305.5 | 0.0 | 470.4 | 20.2 | -511.5 | 0.0 | 490.3 |
| RISK ON THE WAY | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.4 | -9.5 | 56.9 | 0.0 | 1.2 | -29.4 | 111.3 | 54.1 |
| RUN DOWN | 1.5 | -13.3 | 130.1 | 6.5 | 2.3 | -20.7 | 221.2 | 64.5 |
| SAFER THAN THE JOB | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.3 | +0.7 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.5 | -26.7 | 0.0 | 0.0 | 1.2 | -98.8 | 0.0 | 4.2 |
| SEARCH SPOT | 0.3 | +2.8 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| SECOND LOOK | 0.2 | +28.0 | 37.9 | 0.0 | 0.2 | +23.2 | 9.0 | 0.0 |
| SELF MOVE SPELL | 0.2 | +14.9 | 0.0 | 9.1 | 0.2 | +53.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.1 | +40.2 | 0.0 | 6.7 | 3.5 | +119.3 | 16.8 | 68.4 |
| SET UP TOGETHER | 0.1 | +8.5 | 0.0 | 0.0 | 0.6 | +13.7 | 0.0 | 21.8 |
| SET-UP ANY TARGET | 0.7 | +117.0 | 0.0 | 0.0 | 0.0 | +7.0 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +10.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.1 | -0.5 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +124.6 | 94.1 | 7.2 | 1.1 | +27.5 | 3.1 | 5.4 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -14.9 | 16.8 | 0.0 | 0.2 | -11.9 | 13.9 | 2.8 |
| SHOT RISK POINTS | 15.9 | +64.1 | 0.0 | 316.4 | 22.8 | +140.1 | 0.0 | 346.9 |
| SHOTS AFTER THE MOVES | 3.1 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.1 | +577.5 | 0.0 | 194.4 | 8.4 | +299.2 | 0.0 | 149.2 |
| SPELL SETS UP CHARGE | 0.8 | +159.0 | 13.9 | 13.9 | 0.0 | +7.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +8.5 | 71.5 | 71.5 | 2.6 | +31.9 | 51.3 | 43.6 |
| SPELLS IN THE FIGHT | 0.5 | +0.6 | 72.9 | 0.0 | 0.4 | +2.3 | 79.3 | 20.9 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 125.4 | 9.8 | +0.0 | 0.0 | 179.0 |
| STAND AND SHOOT | 0.5 | -5.5 | 28.2 | 6.5 | 0.5 | -6.3 | 33.0 | 14.8 |
| STANDS FOR A REASON | 0.2 | +0.0 | 13.0 | 0.0 | 1.4 | +0.0 | 0.0 | 18.8 |
| STANDS STILL | 47.4 | +0.0 | 827.2 | 494.3 | 28.7 | +0.0 | 390.9 | 292.1 |
| STAY WORTH | 24.9 | -53.6 | 447.3 | 217.5 | 10.8 | +56.5 | 226.6 | 190.9 |
| STOPS | - | - | - | - | 0.1 | +0.9 | 3.8 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| STUPIDITY NEXT TURN | 0.1 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.0 | +582.1 | 0.0 | 70.7 | 9.1 | +603.7 | 0.0 | 61.8 |
| SUPPORT NARROWED | 0.5 | +0.0 | 43.5 | 1.2 | 0.3 | +0.0 | 13.0 | 13.4 |
| SUPPORT WORKED OUT | 8.0 | +582.1 | 0.0 | 70.7 | 9.1 | +603.7 | 0.0 | 61.8 |
| SURE REACH TOGETHER | 0.1 | +3.4 | 0.0 | 0.0 | 0.6 | +8.1 | 0.0 | 12.6 |
| THE DEARER SUM KEEPS ITS PLAN | 2.1 | +0.0 | 0.0 | 1.8 | 1.1 | +0.0 | 0.0 | 6.4 |
| THE PROMISE ADDS | 0.1 | -13.4 | 0.0 | 0.0 | 0.3 | -19.7 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.6 | +0.0 | 0.0 | 377.3 | 34.7 | +0.0 | 0.0 | 380.3 |
| TIED UP BY THE SUM | 0.6 | +71.7 | 64.3 | 18.3 | 0.5 | +56.8 | 29.7 | 6.4 |
| TIME ON OUR SIDE | 34.9 | +388.6 | 13.6 | 449.4 | 14.9 | +140.3 | 4.2 | 177.2 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.2 | +0.5 | 0.0 | 13.9 |
| WAITS AGAIN | 2.2 | +0.0 | 0.0 | 14.0 | 1.6 | +0.0 | 0.0 | 6.8 |
| WALKS ON ITS ROUTE | 0.1 | -0.7 | 0.0 | 2.3 | 0.1 | +14.9 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | - | - | - | - | 0.0 | +2.1 | 4.7 | 0.0 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 14.3 | 0.0 | 0.2 | +0.0 | 9.4 | 0.0 |
| WHAT THE JOINER ADDS | 0.2 | +10.6 | 46.1 | 6.7 | 0.4 | -4.2 | 22.2 | 0.0 |
| WHO GETS IN | 0.1 | +14.9 | 0.0 | 0.0 | 0.1 | +11.4 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +42.6 | 0.0 | 10.4 | 0.4 | +46.7 | 0.0 | 19.4 |
| WHOLE FIGHT | 0.1 | -0.3 | 23.0 | 3.3 | 0.2 | +2.0 | 11.1 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +3.8 | 3.1 | 2.9 | 0.2 | +18.8 | 26.0 | 0.0 |
| WIDER SPREAD | 1.8 | -2.3 | 136.4 | 41.7 | 2.2 | -7.0 | 221.8 | 63.6 |
| WOUNDS ON THE RANKS | 2.1 | +57.5 | 0.0 | 39.7 | 1.7 | +65.5 | 0.0 | 40.8 |

### Rule changes: base-s2-882d875-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2687 | 2687 | 1670 | 46.39 | +0 | +0.0 |
| HIS MOVE WHY | 2661 | 2661 | 1461 | 40.58 | +0 | +0.0 |
| ARMY TABLE | 1321 | 1321 | 866 | 24.06 | +15643 | +18.1 |
| HIS SHOT LIST | 2810 | 2682 | 689 | 19.14 | +13225 | +19.2 |
| HOLDER ASSIGNMENT | 668 | 668 | 625 | 17.36 | +37700 | +60.3 |
| ONE TARGET A SHOOTER | 2011 | 1932 | 422 | 11.72 | +4805 | +11.4 |
| LEGAL CHARGES ONLY | 386 | 386 | 386 | 10.72 | +0 | +0.0 |
| DEPLOY BY FIGURES | 562 | 562 | 340 | 9.44 | +3690 | +10.9 |
| FIVE ACTION | 6404 | 6179 | 294 | 8.17 | +17562 | +59.7 |
| HIS ONE MOVE | 1382 | 1345 | 284 | 7.89 | +0 | +0.0 |
| THE TABLE AGAIN | 432 | 432 | 284 | 7.89 | +0 | +0.0 |
| OFF BEST | 278 | 278 | 278 | 7.72 | -11549 | -41.5 |
| TIME ON OUR SIDE | 1791 | 1664 | 272 | 7.56 | +1031 | +3.8 |
| MOVE TO CHARGE COMPUTED | 507 | 445 | 232 | 6.44 | +11134 | +48.0 |
| SUPPORT ADDS | 617 | 580 | 226 | 6.28 | +10848 | +48.0 |
| SUPPORT WORKED OUT | 617 | 580 | 226 | 6.28 | +10848 | +48.0 |
| PROMISE BY ITS OWN SUM | 613 | 613 | 221 | 6.14 | -19677 | -89.0 |
| SHOT RISK POINTS | 1395 | 1327 | 194 | 5.39 | +6296 | +32.5 |
| HARD STAY DROPPED | 140 | 140 | 140 | 3.89 | +0 | +0.0 |
| MOVE ORDER | 124 | 124 | 124 | 3.44 | +0 | +0.0 |
| QUARTER ODDS | 1210 | 1133 | 115 | 3.19 | +10016 | +87.1 |
| FOUR ROUNDS | 226 | 214 | 106 | 2.94 | +6708 | +63.3 |
| SHOOTS FROM THE BEST SPOT | 138 | 138 | 91 | 2.53 | +1980 | +21.8 |
| ADVANCE LANE KEPT | 85 | 85 | 85 | 2.36 | +0 | +0.0 |
| IDLE COST | 582 | 467 | 74 | 2.06 | +711 | +9.6 |
| RISK BY HIS FIGURE | 1565 | 1496 | 63 | 1.75 | +6760 | +107.3 |
| CHAFF IN THE MOVE | 75 | 73 | 59 | 1.64 | +102 | +1.7 |
| LANE BY FIGURES | 57 | 57 | 57 | 1.58 | +2036 | +35.7 |
| RANDOM MOVE BY FIGURES | 102 | 102 | 57 | 1.58 | +2421 | +42.5 |
| SET UP BY THE SET | 165 | 160 | 56 | 1.56 | +3492 | +62.3 |
| CAST JOB | 79 | 79 | 55 | 1.53 | +397 | +7.2 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 48 | 48 | 48 | 1.33 | +8645 | +180.1 |
| PATHS CROSS | 47 | 47 | 47 | 1.31 | +2492 | +53.0 |
| CHARGE LOSSES | 770 | 726 | 46 | 1.28 | +4719 | +102.6 |
| JOINT CHARGE NOW | 46 | 46 | 46 | 1.28 | +2918 | +63.4 |
| CANNON SIGHT KEPT | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| COVER ONCE | 405 | 299 | 44 | 1.22 | +878 | +19.9 |
| STAY WORTH | 1287 | 1196 | 43 | 1.19 | +564 | +13.1 |
| MAX FOR POSITIONING | 214 | 196 | 42 | 1.17 | +243 | +5.8 |
| FALLS SHORT | 719 | 611 | 40 | 1.11 | +372 | +9.3 |
| NEXT CHARGE BY LIST | 437 | 414 | 37 | 1.03 | +1043 | +28.2 |
| SHOTS IN THE MOVE | 882 | 717 | 35 | 0.97 | +1407 | +40.2 |
| CANNON PLANNED TARGET | 241 | 241 | 34 | 0.94 | +281 | +8.3 |
| RESERVE FALL BACK | 33 | 33 | 33 | 0.92 | +1109 | +33.6 |
| MARCH CHECK | 40 | 39 | 32 | 0.89 | +573 | +17.9 |
| TIED UP BY THE SUM | 41 | 37 | 32 | 0.89 | +1098 | +34.3 |
| CHARGE NOW FIRST | 125 | 125 | 30 | 0.83 | -1908 | -63.6 |
| NEARER NOT NEEDED | 544 | 532 | 30 | 0.83 | +1117 | +37.2 |
| HOLDS AMBUSHERS | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 29 | 29 | 29 | 0.81 | +1826 | +63.0 |
| MISSILES IN THE MOVE | 280 | 198 | 28 | 0.78 | +564 | +20.1 |
| HIS TURN DENIED | 106 | 103 | 26 | 0.72 | +1636 | +62.9 |
| WHO HITS BACK | 26 | 26 | 26 | 0.72 | +2262 | +87.0 |
| RISK BY ARC | 130 | 122 | 25 | 0.69 | +705 | +28.2 |
| REFUSING RETIRES | 38 | 38 | 24 | 0.67 | -1 | -0.1 |
| SHOTS AFTER THE MOVES | 165 | 165 | 23 | 0.64 | +0 | +0.0 |
| REDIRECT COUNTER | 170 | 137 | 22 | 0.61 | +1233 | +56.0 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +1444 | +68.8 |
| SHOOTERS IN TWO RANKS | 20 | 20 | 20 | 0.56 | +42 | +2.1 |
| AFTERMATH IN POINTS | 19 | 19 | 19 | 0.53 | +2905 | +152.9 |
| COMBAT PIVOT | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| CASTING BLOCK | 38 | 38 | 18 | 0.50 | +136 | +7.5 |
| CASTS FROM BEHIND | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| SECOND LOOK | 18 | 18 | 18 | 0.50 | +1844 | +102.4 |
| WOUNDS ON THE RANKS | 135 | 129 | 18 | 0.50 | +425 | +23.6 |
| MARCH BY THE SUM | 17 | 17 | 17 | 0.47 | +914 | +53.7 |
| SCOUT WAITS | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| MODEL FACING | 16 | 16 | 16 | 0.44 | +5661 | +353.8 |
| SUPPORT NARROWED | 28 | 28 | 16 | 0.44 | -1103 | -68.9 |
| PROMISE KNOWS THE FIGHT | 64 | 55 | 15 | 0.42 | -141 | -9.4 |
| PROMISE SHOT AWAY | 15 | 15 | 15 | 0.42 | -146 | -9.8 |
| SEARCH SPOT | 22 | 22 | 15 | 0.42 | +162 | +10.8 |
| GUN MASK | 50 | 49 | 12 | 0.33 | +729 | +60.8 |
| HIS FIGHT TOGETHER | 158 | 156 | 12 | 0.33 | +273 | +22.7 |
| WAR ENGINE JOBS | 21 | 21 | 12 | 0.33 | -331 | -27.6 |
| FIRE IN ORDER | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 292 | 233 | 11 | 0.31 | +537 | +48.8 |
| OPENS UP | 21 | 18 | 11 | 0.31 | +737 | +67.0 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -26 | -2.6 |
| ONE PROMISE A TARGET | 10 | 10 | 10 | 0.28 | -449 | -44.9 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| SURE REACH TOGETHER | 25 | 22 | 10 | 0.28 | +22 | +2.2 |
| MANOEUVRE | 65 | 65 | 9 | 0.25 | +158 | +17.5 |
| ONE FIGHT FORMULA | 343 | 192 | 9 | 0.25 | +18 | +2.0 |
| OVERRUNS AWAY | 30 | 29 | 9 | 0.25 | +425 | +47.2 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -195 | -21.7 |
| FEATURE BUFFS | 149 | 149 | 8 | 0.22 | +177 | +22.1 |
| FRIENDS SHOTS CHECKED | 8 | 8 | 8 | 0.22 | +361 | +45.2 |
| HIS MOVE AND SHOT | 220 | 198 | 7 | 0.19 | +318 | +45.5 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -710 | -118.3 |
| EDGE GIVE GROUND | 11 | 11 | 6 | 0.17 | +120 | +19.9 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +133 | +22.2 |
| WHAT THE JOINER ADDS | 21 | 18 | 6 | 0.17 | +400 | +66.6 |
| AFTERMATH WITH FRIENDS | 5 | 5 | 5 | 0.14 | +143 | +28.5 |
| NO DOUBLE ROUNDS | 162 | 154 | 5 | 0.14 | +114 | +22.7 |
| WALKS ON ITS ROUTE | 5 | 5 | 5 | 0.14 | +511 | +102.2 |
| WHO GETS IN | 5 | 5 | 5 | 0.14 | +946 | +189.3 |
| WHOLE FIGHT GAIN | 12 | 12 | 5 | 0.14 | +197 | +39.4 |
| FALL BACK GOOD ORDER | 156 | 147 | 4 | 0.11 | +116 | +29.0 |
| FIGHT TO THE END | 65 | 63 | 4 | 0.11 | +58 | +14.4 |
| LOST AFTER ESCAPE | 116 | 111 | 4 | 0.11 | +46 | +11.5 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 0.11 | -54 | -13.5 |
| MISSILES NEXT TURN | 352 | 265 | 4 | 0.11 | +42 | +10.5 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +275 | +68.8 |
| PROMISE READS THE TABLE | 21 | 21 | 4 | 0.11 | -114 | -28.4 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -449 | -112.2 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +426 | +142.1 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +11 | +3.6 |
| HIS CHARGE DENIED | 21 | 19 | 3 | 0.08 | +49 | +16.3 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +87 | +28.9 |
| HUNT IN PAIRS | 19 | 11 | 3 | 0.08 | +43 | +14.4 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +83 | +27.7 |
| SET UP TOGETHER | 24 | 18 | 3 | 0.08 | +64 | +21.4 |
| BLOWS WHERE AIMED | 9 | 9 | 2 | 0.06 | +217 | +108.3 |
| CARRIES OUT SET-UP | 6 | 6 | 2 | 0.06 | -377 | -188.5 |
| CHARGE NOT DECLARED | 2 | 2 | 2 | 0.06 | -412 | -206.1 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +80 | +40.0 |
| HONEST WORTH | 194 | 182 | 2 | 0.06 | +93 | +46.5 |
| JOINT ON THE TABLE | 2 | 2 | 2 | 0.06 | +468 | +234.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +78 | +38.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OPENS A LANE | 9 | 4 | 2 | 0.06 | +3 | +1.6 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.06 | -17 | -8.6 |
| REFORMS TO MEET IT | 106 | 95 | 2 | 0.06 | +28 | +13.9 |
| ROUNDS AFTER TERROR | 60 | 56 | 2 | 0.06 | +12 | +6.1 |
| SPELLS IN THE FIGHT | 32 | 31 | 2 | 0.06 | +25 | +12.4 |
| BACKUP TARGETS | 15 | 4 | 1 | 0.03 | +32 | +32.2 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.03 | +7 | +6.8 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 3 | 3 | 1 | 0.03 | -68 | -68.3 |
| FACES THE THREAT | 1 | 1 | 1 | 0.03 | +121 | +121.3 |
| FALLBACK BY WORTH | 16 | 16 | 1 | 0.03 | +1 | +0.6 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.03 | +10 | +10.5 |
| NEXT OBJECTIVE NEARER | 9 | 9 | 1 | 0.03 | +8 | +7.7 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +1 | +0.7 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.03 | +44 | +44.5 |
| STOPS | 2 | 1 | 1 | 0.03 | +9 | +9.2 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +20 | +19.7 |
| WHOLE FIGHT | 12 | 10 | 1 | 0.03 | +8 | +8.5 |
| WIDER SPREAD | 145 | 135 | 1 | 0.03 | +4 | +4.0 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 13 | 13 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 73 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 12 | 12 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 112 | 102 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 27 | 27 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 107 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 49 | 47 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 349 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 29 | 27 | 0 | 0.00 | - | - |
| GIVES UP | 16 | 12 | 0 | 0.00 | - | - |
| GUN FIGURES | 53 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 198 | 190 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 373 | 357 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 316 | 301 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 330 | 292 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 139 | 139 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 363 | 339 | 0 | 0.00 | - | - |
| HOLD ODDS | 1180 | 1173 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 176 | 169 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 6 | not checked | - | - | - | - |
| LONG SHOT | 16 | 16 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 13 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 43 | 43 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 66 | 64 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 16 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 24 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 31 | trace | - | - | - | - |
| MOVE SPELL SPOT | 34 | not checked | - | - | - | - |
| NO LATE CUT | 46 | 44 | 0 | 0.00 | - | - |
| NOT TURNED | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 291 | 279 | 0 | 0.00 | - | - |
| ONE ROUTE | 66 | 64 | 0 | 0.00 | - | - |
| PLAN RESULT | 3036 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 20 | 20 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 9 | 9 | 0 | 0.00 | - | - |
| REAL GROUND | 66 | 64 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 73 | 73 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 23 | 22 | 0 | 0.00 | - | - |
| RUN DOWN | 138 | 129 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 63 | 63 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 13 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 26 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 16 | 16 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 31 | not checked | - | - | - | - |
| SPELL WORTH | 130 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 614 | 577 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 35 | 32 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 59 | 57 | 0 | 0.00 | - | - |
| STANDS STILL | 2740 | 2655 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 35 | 30 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 113 | not checked | - | - | - | - |
| THE PROMISE ADDS | 15 | 13 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2389 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 6 | not checked | - | - | - | - |
| WAITS AGAIN | 135 | 119 | 0 | 0.00 | - | - |

### Off best figure: base-s2-882d875-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.81 | 3.31 | 89.4 |
| JOB FIRST | gate | 2.94 | 2.92 | 40.9 |
| ARMY TABLE | rule | 1.42 | 2.03 | 51.3 |
| NO REASON | gate | 0.42 | 0.89 | 45.2 |
| HOLDER ASSIGNMENT | rule | 0.83 | 0.33 | 16.4 |
| CHARGE NOW FIRST | rule | 0.33 | 0.47 | 65.8 |
| JOINT CHARGE NOW | rule | 0.17 | 0.28 | 95.1 |
| SUPPORT NARROWED | rule | 0.28 | 0.17 | 68.9 |
| PROMISE SHOT AWAY | rule | 0.25 | 0.17 | 9.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.06 | 10.0 |
| WAR ENGINE JOBS | rule | 0.22 | 0.11 | 27.6 |
| PIVOT GUARDS FLANK | rule | 0.19 | 0.06 | 21.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.17 | 0.06 | 78.9 |
| CANNON PLANNED TARGET | rule | 0.11 | 0.08 | 18.4 |
| ONE PROMISE A TARGET | rule | 0.14 | 0.06 | 68.4 |
| BEST PRIZE | rule | 0.06 | 0.11 | 118.3 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.14 | 18.8 |
| PATHS CROSS | rule | 0.11 | 0.06 | 12.4 |
| CHAFF PASSED | rule | 0.06 | 0.06 | 6.4 |
| MARCH OF THE TABLE | rule | 0.03 | 0.08 | 13.5 |
| PURSUES BIG PREY | rule | 0.08 | 0.03 | 112.2 |
| SET UP BY THE SET | rule | - | 0.11 | 96.1 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 1.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | - | 36.6 |
| PROMISE READS THE TABLE | rule | 0.06 | 0.03 | 38.3 |
| REFUSING RETIRES | rule | 0.03 | 0.06 | 0.8 |
| AFTERMATH BAND | gate | - | 0.06 | 1.5 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 188.5 |
| CHARGE NOT DECLARED | rule | - | 0.06 | 206.1 |
| FALLBACK | gate | 0.06 | - | 9.6 |
| OWN CAST FIRST | rule | 0.03 | 0.03 | 8.6 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 21.0 |
| TURN GATE | gate | 0.06 | - | 13.1 |
| WALKS ON ITS ROUTE | rule | 0.03 | 0.03 | 12.6 |
| DEFENSIVE ARMY | rule | 0.03 | - | 68.3 |

### Plans: base-s2-882d875-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.1 | 61% | 359 | 239 | 67% |
| Mine | join | 0.9 | 94% | 35 | 0 | 0% |
| Mine | move | 30.3 | 95% | 1718 | 0 | 0% |
| Mine | shoot | 9.4 | 57% | 399 | 600 | 150% |
| Mine | support | 0.6 | 95% | 1 | 0 | 0% |
| Opponent | charge | 2.9 | 56% | 545 | 260 | 48% |
| Opponent | join | 0.8 | 97% | 39 | 0 | 0% |
| Opponent | move | 32.7 | 95% | 1471 | 0 | 0% |
| Opponent | shoot | 3.3 | 55% | 176 | 162 | 92% |
| Opponent | support | 1.3 | 85% | 10 | 0 | 0% |

### Packages: hunt the guns, base-s2-882d875-p5

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 24 |
| Opponent | 0.1 | 2 | 0 | 50% | 50% | 0% | 2.0 | 207 | 128 | 50% | 59 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 118 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 96 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 172 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 190 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 207 | 128 | 50% | 8 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: base-s2-882d875-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 17% | 79% | 21% | 33% | 9% | 0% | 0% | 91% | 0% |
| Opponent | REDIRECT COUNTER | 2.4 | 16% | 79% | 14% | 0% | 25% | 8% | 0% | 50% | 17% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s2-882d875-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 26 | 20% | 2.2 | - | 0 (5) | - | - | 0 (5) |
| Mine | Chaff | 31 | 59 (31) | 31 | 28 | 44 | 58% | 2.5 | 0 (10) | 54 (14) | 142 (7) | 69 (20) | 41 (11) |
| Mine | Character | 124 | 39 (124) | 37 | 2 | 32 | 20% | 2.3 | 45 (49) | 50 (43) | 21 (20) | 34 (64) | 53 (48) |
| Mine | Clean-up | 20 | 108 (20) | 28 | 80 | 15 | 45% | 3.4 | 91 (9) | 134 (7) | 113 (4) | 162 (12) | 51 (8) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 25 | 25% | 2.0 | - | 0 (4) | - | 0 (4) | - |
| Mine | Fast Hammer | 52 | 35 (52) | 17 | 18 | 28 | 37% | 2.6 | 24 (23) | 60 (21) | 0 (8) | 43 (33) | 24 (19) |
| Mine | Hammer | 57 | 29 (57) | 19 | 10 | 29 | 32% | 2.5 | 31 (27) | 35 (23) | 0 (7) | 31 (30) | 27 (27) |
| Mine | Holder | 21 | 22 (21) | 10 | 13 | 30 | 76% | 4.4 | 0 (6) | 35 (14) | - | 31 (9) | 14 (11) |
| Mine | Shooter | 47 | 63 (47) | 12 | 51 | 45 | 4% | 1.8 | 71 (21) | 73 (18) | 26 (8) | 79 (34) | 26 (13) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 58 | 30 (58) | 30 | 0 | 31 | 3% | 1.9 | 6 (28) | 39 (23) | 119 (7) | 23 (11) | 32 (47) |
| Mine | Wizard | 19 | 1 (19) | 1 | 0 | 36 | 21% | 2.3 | 0 (8) | 3 (4) | 0 (3) | 0 (5) | 2 (10) |
| Opponent | Chaff | 75 | 69 (75) | 12 | 57 | 37 | 59% | 3.0 | 59 (32) | 98 (22) | 49 (21) | 78 (58) | 41 (17) |
| Opponent | Character | 103 | 41 (103) | 41 | 0 | 21 | 23% | 2.3 | 40 (42) | 46 (39) | 38 (16) | 47 (62) | 33 (35) |
| Opponent | Clean-up | 29 | 78 (29) | 32 | 46 | 29 | 62% | 3.3 | 33 (7) | 98 (18) | 40 (4) | 80 (18) | 75 (11) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 48 | 38 (48) | 13 | 24 | 29 | 40% | 2.5 | 20 (20) | 54 (17) | 47 (11) | 42 (24) | 34 (24) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 50 | 26 (50) | 20 | 6 | 34 | 40% | 3.3 | 14 (16) | 37 (26) | 8 (8) | 32 (31) | 17 (19) |
| Opponent | Holder | 30 | 60 (30) | 3 | 57 | 29 | 60% | 3.7 | 108 (7) | 74 (17) | 0 (5) | 87 (16) | 20 (13) |
| Opponent | Shooter | 30 | 29 (30) | 16 | 13 | 40 | 13% | 1.5 | 51 (9) | 19 (18) | 9 (3) | 44 (13) | 18 (17) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 33 | 25% | 4.7 | 0 (1) | 0 (1) | 0 (2) | - | 0 (4) |
| Opponent | War machine | 14 | 54 (14) | 54 | 0 | 60 | 0% | 1.2 | 46 (6) | 60 (8) | - | 66 (4) | 49 (10) |
| Opponent | Wizard | 26 | 1 (26) | 1 | 0 | 24 | 23% | 2.6 | 1 (15) | 0 (6) | 12 (2) | 0 (7) | 2 (16) |

### Charged fights: base-s2-882d875-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 32 | 25 | 0.8 | 1.0 | 33 | 27 | +6 | 0 of 3 | 2 of 3 | - | +6 |
| Mine | Chaos Dwarfs | 4 | 93 | 278 | 2.0 | 1.0 | 139 | 15 | +124 | 5 of 8 | 7 of 8 | - | +124 |
| Mine | Dwarfen Mountain Holds | 4 | 398 | 24 | 1.0 | 1.2 | 24 | 26 | -2 | 1 of 4 | 2 of 4 | +0 | -2 |
| Mine | Empire of Man | 5 | 34 | 23 | 1.2 | 1.2 | 19 | 90 | -71 | 3 of 6 | 3 of 6 | +0 | -85 |
| Mine | Grand Cathay | 4 | 415 | 234 | 1.5 | 1.0 | 156 | 0 | +156 | 3 of 6 | 5 of 6 | - | +156 |
| Mine | High Elf Realms | 4 | 92 | 518 | 3.2 | 1.2 | 160 | 0 | +160 | 4 of 13 | 11 of 13 | +0 | +189 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 75 | 2.0 | 1.0 | 38 | 236 | -198 | 1 of 2 | 1 of 2 | - | -198 |
| Mine | Lizardmen | 1 | 45 | 962 | 4.0 | 1.0 | 240 | 0 | +240 | 1 of 4 | 4 of 4 | - | +240 |
| Mine | Ogre Kingdoms | 1 | 45 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 1 of 2 | 0 of 2 | - | -17 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Mine | Skaven | 2 | 22 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 38 | 340 | 4.0 | 1.0 | 85 | 0 | +85 | 2 of 4 | 3 of 4 | - | +85 |
| Mine | Vampire Counts | 3 | 6 | 379 | 2.7 | 1.0 | 142 | 12 | +130 | 1 of 8 | 3 of 8 | - | +130 |
| Mine | Warriors of Chaos | 1 | 0 | 666 | 5.0 | 1.0 | 133 | 0 | +133 | 0 of 5 | 4 of 5 | - | +133 |
| **Mine** | all armies | 36 | 124 | 211 | 1.8 | 1.1 | 115 | 22 | +93 | 23 of 66 | 46 of 66 | +0 | +99 |
| Opponent | Chaos Dwarfs | 2 | 42 | 646 | 3.0 | 1.2 | 215 | 0 | +215 | 4 of 6 | 3 of 6 | +220 | +214 |
| Opponent | Dwarfen Mountain Holds | 1 | 395 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 65 | 213 | 3.0 | 1.3 | 71 | 177 | -106 | 2 of 3 | 1 of 3 | -162 | -78 |
| Opponent | High Elf Realms | 2 | 196 | 577 | 4.5 | 1.6 | 128 | 66 | +62 | 6 of 9 | 8 of 9 | +78 | +54 |
| Opponent | Kingdom of Bretonnia | 2 | 75 | 171 | 1.5 | 1.0 | 114 | 0 | +114 | 1 of 3 | 2 of 3 | - | +114 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 238 | 2.0 | 1.0 | 119 | 0 | +119 | 2 of 2 | 2 of 2 | - | +119 |
| Opponent | Skaven | 4 | 0 | 0 | 0.2 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 139 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 2 of 3 | 2 of 3 | - | +0 |
| Opponent | Vampire Counts | 10 | 47 | 569 | 4.3 | 1.1 | 132 | 30 | +102 | 23 of 43 | 30 of 43 | +111 | +101 |
| Opponent | Warriors of Chaos | 5 | 132 | 493 | 2.8 | 1.1 | 176 | 35 | +141 | 3 of 14 | 13 of 14 | +210 | +136 |
| Opponent | Wood Elf Realms | 6 | 195 | 92 | 2.5 | 1.1 | 37 | 15 | +22 | 7 of 15 | 6 of 15 | +0 | +23 |
| **Opponent** | all armies | 36 | 106 | 332 | 2.8 | 1.1 | 121 | 32 | +89 | 51 of 99 | 67 of 99 | +88 | +89 |

### Effective charges: base-s2-882d875-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 1 (net -81) | 0 | 0 | 0 | 0 | 1 (net +65) | 1 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 8 | 3 (net +135) | 0 | 1 (net +0) | 1 (net +70) | 1 (net +66) | 1 (net +390) | 1 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 2 (net -52) | 0 | 1 (net +98) | 0 | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 6 | 1 (net -541) | 0 | 0 | 2 (net +0) | 0 | 2 (net +57) | 1 | 0% (0 of 5) |
| Mine | Grand Cathay | 6 | 0 | 0 | 2 (net +0) | 1 (net +0) | 0 | 2 (net +217) | 1 | 40% (2 of 5) |
| Mine | High Elf Realms | 13 | 2 (net +138) | 1 (net +465) | 3 (net +33) | 0 | 1 (net +104) | 3 (net +115) | 3 | 30% (3 of 10) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 1 (net -471) | 1 (net +75) | 0 | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 0 | 0 | 2 (net +134) | 1 (net +609) | 0 | 0 | 1 | 67% (2 of 3) |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 2 (net +52) | 0 | 0 | 2 (net +118) | 0 | 50% (2 of 4) |
| Mine | Vampire Counts | 8 | 3 (net +121) | 0 | 3 (net +226) | 0 | 0 | 2 (net +0) | 0 | 38% (3 of 8) |
| Mine | Warriors of Chaos | 5 | 0 | 0 | 0 | 1 (net +260) | 2 (net +203) | 0 | 2 | 0% (0 of 3) |
| Opponent | Chaos Dwarfs | 6 | 2 (net +288) | 1 (net +130) | 1 (net +170) | 0 | 1 (net +0) | 1 (net +417) | 0 | 17% (1 of 6) |
| Opponent | Grand Cathay | 3 | 2 (net -206) | 0 | 0 | 0 | 1 (net +95) | 0 | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 9 | 1 (net -357) | 0 | 0 | 2 (net +179) | 2 (net +0) | 2 (net +146) | 2 | 0% (0 of 7) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 1 (net +165) | 1 (net +0) | 0 | 0 | 1 (net +177) | 0 | 33% (1 of 3) |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 0 | 1 (net +238) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Vampire Counts | 43 | 17 (net +141) | 0 | 6 (net +101) | 7 (net +88) | 4 (net +163) | 7 (net +18) | 2 | 15% (6 of 41) |
| Opponent | Warriors of Chaos | 14 | 1 (net +0) | 0 | 0 | 4 (net +214) | 1 (net +210) | 3 (net +59) | 5 | 0% (0 of 9) |
| Opponent | Wood Elf Realms | 15 | 5 (net +21) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 8 | 14% (1 of 7) |

### Charged fights, damage counted: base-s2-882d875-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 175 | 358 | +27 | 124 | 115 | +9 | +5.1 |
| Mine | 50-54% | 1 | 497 | 365 | +465 | 465 | 0 | +465 | +93.6 |
| Mine | Effective (55-75%) | 14 | 315 | 181 | +89 | 102 | 17 | +84 | +26.7 |
| Mine | 76-89% | 8 | 359 | 280 | +58 | 145 | 99 | +46 | +12.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 269 | 155 | +113 | 136 | 7 | +129 | +48.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 419 | 96 | +130 | 130 | 78 | +52 | +12.4 |
| Mine | No odds | 12 | 270 | 166 | +119 | 134 | 7 | +127 | +46.9 |
| Mine | All fights | 66 | 288 | 213 | +93 | 132 | 45 | +86 | +30.1 |
| Opponent | Long shot (under 50%) | 29 | 272 | 237 | +80 | 163 | 71 | +91 | +33.5 |
| Opponent | 50-54% | 2 | 378 | 244 | +148 | 148 | 120 | +28 | +7.3 |
| Opponent | Effective (55-75%) | 11 | 325 | 213 | +92 | 111 | 13 | +98 | +30.2 |
| Opponent | 76-89% | 14 | 341 | 225 | +131 | 177 | 50 | +126 | +37.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 318 | 196 | +74 | 144 | 57 | +87 | +27.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 575 | 120 | +106 | 112 | 21 | +91 | +15.8 |
| Opponent | No odds | 18 | 229 | 235 | +68 | 141 | 50 | +91 | +39.6 |
| Opponent | All fights | 99 | 317 | 215 | +89 | 147 | 52 | +95 | +29.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s2-882d875-p5 | move | 252 | 53 (21%) | 37 (15%) | 32 (13%) | 167 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0104, L0120, L2426, L2533, L2733 |
| Charmed Shield | Opponent | L0526, L0825, L1024, L1226, L1627, L1725, L1825, L1925, L2027, L2426 |
| Clockwork Compass | Mine | L1226 |
| Elixir of Power | Mine | L1116, L1133, L1925 |
| Elixir of Power | Opponent | L0719 |
| Fistful of Laurels | Mine | L1825 |
| Horn of the Wild Hunt | Opponent | L1133, L1433, L2233, L2533, L2733 |
| Invocation of Nehek | Mine | L2426, L2533, L2733 |
| Invocation of Nehek | Opponent | L0825, L1024, L1627, L1725, L1825, L1925, L2027 |
| Opal Amulet | Mine | L1416, L1433 |
| Opal Amulet | Opponent | L0614 |
| Periapt of Soul Exchange | Mine | L2027, L2129 |
| Periapt of Soul Exchange | Opponent | L0120, L0220, L0321, L1321 |
| Ring of Doom | Mine | L0204, L0220, L1116, L1133, L1226, L1529 |
| Ring of Doom | Opponent | L0915, L1133, L1433, L2233, L2533, L2733, L3031 |
| Ring of Jet | Mine | L1024, L1116, L1133, L1226 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Mine | L1321 |
| Storm Daemon (Renegade 2.0) | Mine | L2129 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321, L1321 |
| Twice-Blessed Armour | Mine | L0719, L0735, L1024 |
| Twice-Blessed Armour | Opponent | L0407, L0510 |
| Witch Hunter's Ward | Mine | L0719, L0735, L0825 |
| Witch Hunter's Ward | Opponent | L0407 |

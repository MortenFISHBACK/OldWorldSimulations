# Doctrine scorecard: base-s2-882d875-p3

### Scorecard: base-s2-882d875-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 2 | Mine | - | - | 5 | 1 | 2 | 1 | 0 | 0 | 377 |
| L0110 | 2 | 2 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 165 |
| L0126 | 6 | 2 | Mine | no | 10 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 2 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 60 |
| L0210 | 6 | 2 | Mine | no | 6 | - | 0 | 6 | 0 | 0 | 0 | 85 |
| L0210 | 6 | 2 | Opponent | no | 1 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 2 | Mine | no | 0 | 6 | 1 | 3 | 0 | 0 | 0 | 30 |
| L0226 | 4 | 2 | Opponent | no | 5 | 2 | 2 | 3 | 0 | 0 | 0 | 357 |
| L0311 | 5 | 2 | Mine | no | - | - | 0 | 4 | 0 | 0 | 0 | 406 |
| L0311 | 5 | 2 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 150 |
| L0327 | 3 | 2 | Mine | yes | 0 | - | 0 | 1 | 0 | 0 | 0 | 110 |
| L0327 | 3 | 2 | Opponent | no | 0 | 3 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 2 | Mine | yes | - | 2 | 1 | 5 | 0 | 0 | 0 | 375 |
| L0413 | 5 | 2 | Opponent | yes | - | - | 0 | 3 | 0 | 0 | 0 | 247 |
| L0429 | 3 | 2 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 139 |
| L0429 | 3 | 2 | Opponent | no | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0516 | 6 | 2 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 255 |
| L0516 | 6 | 2 | Opponent | no | 13 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0533 | 5 | 2 | Mine | no | - | 5 | 2 | 1 | 0 | 0 | 0 | 138 |
| L0533 | 5 | 2 | Opponent | no | - | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 2 | Mine | - | - | 5 | 1 | 1 | 1 | 0 | 0 | 615 |
| L0620 | 2 | 2 | Opponent | - | - | - | 1 | 6 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 2 | Mine | no | 9 | 2 | 2 | 2 | 1 | 0 | 0 | 250 |
| L0709 | 1 | 2 | Opponent | no | 6 | 4 | 1 | 1 | 0 | 0 | 0 | 170 |
| L0725 | 5 | 2 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 189 |
| L0725 | 5 | 2 | Opponent | yes | - | 5 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 2 | Mine | yes | - | - | 1 | 2 | 0 | 0 | 0 | 927 |
| L0815 | 5 | 2 | Opponent | yes | - | 1 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 2 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 310 |
| L0831 | 3 | 2 | Opponent | yes | 4 | - | 1 | 1 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 2 | Mine | no | 4 | 6 | 0 | 0 | 0 | 0 | 0 | 778 |
| L0922 | 4 | 2 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 72 |
| L1013 | 5 | 2 | Mine | yes | - | 2 | 0 | 4 | 0 | 0 | 0 | 165 |
| L1013 | 5 | 2 | Opponent | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1030 | 4 | 2 | Mine | no | 9 | 2 | 4 | 0 | 1 | 0 | 0 | 291 |
| L1030 | 4 | 2 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 2 | Mine | no | 12 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 2 | Opponent | no | 0 | 2 | 7 | 0 | 0 | 0 | 0 | 72 |
| L1216 | 4 | 2 | Mine | no | 9 | 2 | 9 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 2 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 2 | Mine | - | - | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1232 | 2 | 2 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 305 |
| L1327 | 1 | 2 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 70 |
| L1327 | 1 | 2 | Opponent | no | 0 | 5 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 2 | Mine | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 2 | Opponent | no | 1 | 3 | 4 | 0 | 1 | 0 | 0 | 217 |
| L1519 | 1 | 2 | Mine | no | 11 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1519 | 1 | 2 | Opponent | no | 1 | 5 | 1 | 1 | 0 | 0 | 0 | 60 |
| L1535 | 5 | 2 | Mine | no | - | 2 | 3 | 2 | 0 | 0 | 0 | 126 |
| L1535 | 5 | 2 | Opponent | yes | - | 3 | 3 | 5 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 2 | Mine | no | 8 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 2 | Opponent | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 236 |
| L1731 | 3 | 2 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 175 |
| L1731 | 3 | 2 | Opponent | no | 3 | 6 | 2 | 2 | 0 | 0 | 0 | 170 |
| L1831 | 1 | 2 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 117 |
| L1831 | 1 | 2 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 170 |
| L1932 | 6 | 2 | Mine | no | 5 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 2 | Opponent | no | 5 | 2 | 2 | 2 | 0 | 0 | 0 | 228 |
| L2033 | 5 | 2 | Mine | yes | - | - | 0 | 6 | 0 | 0 | 0 | 0 |
| L2033 | 5 | 2 | Opponent | no | - | 5 | 3 | 4 | 0 | 0 | 0 | 104 |
| L2223 | 3 | 2 | Mine | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 145 |
| L2223 | 3 | 2 | Opponent | no | 2 | 1 | 8 | 1 | 1 | 0 | 0 | 257 |
| L2327 | 5 | 2 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 257 |
| L2327 | 5 | 2 | Opponent | no | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 2 | Mine | no | 9 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 2 | Opponent | no | 0 | 4 | 4 | 2 | 0 | 0 | 0 | 378 |
| L2630 | 2 | 2 | Mine | - | - | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 2 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 2 | Mine | no | 9 | 5 | 1 | 0 | 0 | 0 | 0 | 351 |
| L2832 | 6 | 2 | Opponent | no | 14 | 4 | 2 | 4 | 0 | 0 | 0 | 642 |
| **Average** | | | Mine | 26% | 5.0 | 2.9 | 2.2 | 1.7 | 0.2 | 0.0 | 0.0 | 200.3 |
| **Average** | | | Opponent | 23% | 2.6 | 3.1 | 2.3 | 2.2 | 0.2 | 0.0 | 0.0 | 143.4 |

### KPIs: base-s2-882d875-p3

Morten 2026-11-10; 35 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (42 of 160) | 6% (9 of 151) | 16% (51 of 311) |
| Winner chose to follow up after the loser gave ground |  | 80% (36 of 45); on the table 82% | 91% (29 of 32); on the table 94% | 84% (65 of 77); on the table 87% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (6 of 6); on the table 100% | 100% (13 of 13); on the table 100% | 100% (19 of 19); on the table 100% |
| Winner chose to pursue after the loser fled |  | 68% (13 of 19); on the table 79% | 60% (12 of 20); on the table 65% | 64% (25 of 39); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 79% (55 of 70); on the table 83% | 83% (54 of 65); on the table 86% | 81% (109 of 135); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 30% (103 of 348) | 28% (62 of 222) | 29% (165 of 570) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (103 of 244) | 34% (62 of 185) | 38% (165 of 429) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (16 of 24) | 56% (41 of 73) | 59% (57 of 97) |
| Points that never fought | lower | 49% (32773 of 66801) | 52% (36362 of 69990) | 51% (69135 of 136791) |
|   infantry points that never fought | lower | 64% (8916 of 13938) | 66% (8940 of 13552) | 65% (17856 of 27490) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (162 of 260) | 69% (190 of 275) | 66% (352 of 535) |
| Bound items with a magic missile used (at least once a game) |  | 88% (21 of 24); 1.7 uses a game | 95% (21 of 22); 1.9 uses a game | 91% (42 of 46); 1.8 uses a game |
| Bound items with another spell used |  | 71% (10 of 14); 0.5 uses a game | 0% (0 of 6); 0.0 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 38% (5 of 13); 0.1 uses a game | 52% (17 of 33); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (32663 of 57391) | 65% (40112 of 62081) | 61% (72775 of 119472) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (28%) | 1.8 (40%) | 3.8 (33%) |
| MARCHED: its unit marched | 1.4 (20%) | 1.1 (25%) | 2.5 (22%) |
| CHARGED: its unit charged | 0.2 (2%) | 0.2 (5%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.4 (20%) | 0.7 (14%) | 2.0 (18%) |
| REAR RANK: in a rear rank | 0.5 (7%) | 0.1 (1%) | 0.5 (4%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.1 (0%) |
| GONE: slain | 1.2 (17%) | 0.2 (4%) | 1.4 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (5%) | 0.2 (4%) | 0.6 (5%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (3%) | 0.2 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.6 | 2.7 | 4.7 | 1.0 | 1.2 |
| not cast | 4.1 | 1.9 | 2.8 | 11.6 | 2.1 | 17.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (79%) | 0.4 (13%) | 3.8 (33%) | 0.4 (19%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (22%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (6%) | 0.5 (16%) | 2.0 (18%) | 0.5 (26%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (13%) | 0.0 (0%) | 0.3 (12%) | 0.5 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) | 0.1 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.4 (11%) | 0.2 (12%) | 0.5 (18%) | 1.4 (12%) | 0.1 (3%) | 1.4 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.0 (1%) | 0.2 (6%) | 0.6 (5%) | 0.2 (8%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (1%) | 0.0 (0%) | 0.2 (1%) | 0.4 (19%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (61%) | 0.0 (0%) | 0.9 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 1.5 a game | 1.4 a game |
| stood (cast and not dispelled) | 62% (23 of 37) | 55% (26 of 47) | 58% (49 of 84) |
| the unit moved after it | 61% (14 of 23) | 81% (21 of 26) | 71% (35 of 49) |
| it charged on its next turn | 0% (0 of 23) | 4% (1 of 26) | 2% (1 of 49) |
| the enemy charged it first | 4% (1 of 23) | 8% (2 of 26) | 6% (3 of 49) |
| it fought by the end of its next turn | 0% (0 of 23) | 4% (1 of 26) | 2% (1 of 49) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 23) | 0% (0 of 26) | 0% (0 of 49) |
| none of these (no charge, no fight, no charge escaped) | 96% (22 of 23) | 88% (23 of 26) | 92% (45 of 49) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (474 of 821) | 52% (340 of 649) | 55% (814 of 1470) |
|   cavalry | 62% (45 of 73) | 62% (72 of 117) | 62% (117 of 190) |
|   character | 57% (66 of 115) | 27% (38 of 142) | 40% (104 of 257) |
|   chariot | 54% (56 of 103) | 65% (24 of 37) | 57% (80 of 140) |
|   infantry | 55% (126 of 229) | 60% (148 of 246) | 58% (274 of 475) |
|   monster | 41% (14 of 34) | 17% (1 of 6) | 38% (15 of 40) |
|   war machine | 63% (167 of 267) | 56% (57 of 101) | 61% (224 of 368) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (15%) | 1.6 (18%) | 3.1 (16%) |
| CHARGED: it charged | 0.8 (8%) | 1.8 (20%) | 2.6 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.2 (2%) | 0.3 (4%) | 0.6 (3%) |
| MOVED: a war machine that moved | 1.5 (15%) | 0.8 (9%) | 2.3 (12%) |
| NO TARGET IN RANGE | 2.3 (23%) | 2.1 (24%) | 4.4 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.3 (3%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.4 (24%) | 1.4 (16%) | 3.9 (21%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.2 (2%) | 0.6 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.5 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.0 | 85% | 4.9 pts | 26 pts |
| character | 3.4 | 1.1 | 73% | 8.4 pts | 29 pts |
| chariot | 2.3 | 1.9 | 61% | 24.0 pts | 55 pts |
| infantry | 11.8 | 3.2 | 81% | 6.2 pts | 73 pts |
| monster | 0.5 | 0.1 | 76% | 7.0 pts | 3 pts |
| war machine | 6.6 | 5.8 | 67% | 21.6 pts | 142 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.5 | 4.2 | 3.8 |
| Charges that made contact a game | 2.6 | 2.5 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.04 declared, 0.82 contact (28 units) | 0.90 declared, 0.60 contact (20 units) | 0.98 declared, 0.73 contact (48 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.33 declared, 0.67 contact (3 units) | 1.14 declared, 0.86 contact (7 units) | 1.20 declared, 0.80 contact (10 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.29 contact (228 units) | 0.44 declared, 0.25 contact (271 units) | 0.42 declared, 0.27 contact (499 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (45 of 73) | 50% (7 of 14) | 60% (6 of 10) | 60% (58 of 97) |
| Character in a unit | 96% (44 of 46) | 81% (13 of 16) | 50% (3 of 6) | 88% (60 of 68) |
| Character on its own | 96% (24 of 25) | 56% (22 of 39) | 43% (29 of 67) | 57% (75 of 131) |
| Chariot | 73% (8 of 11) | 58% (7 of 12) | - | 65% (15 of 23) |
| Infantry | 68% (46 of 68) | 62% (24 of 39) | 40% (2 of 5) | 64% (72 of 112) |
| Monster | 50% (16 of 32) | 71% (5 of 7) | - | 54% (21 of 39) |
| Monstrous | 89% (8 of 9) | 55% (6 of 11) | - | 70% (14 of 20) |
| War Machines | 81% (35 of 43) | 100% (2 of 2) | - | 82% (37 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (5 of 5); on the table 100% | 28% (30 of 108) | 33% | 82% (18 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 75% (3 of 4); on the table 75% | 47% (17 of 36) | 77% | 75% (24 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 68% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 58% (7 of 12); on the table 83% | 20% (6 of 30) | 53% | 75% (44 of 59) | 0.0 uses a game | 50% (1 of 2); 0.8 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 77% (20 of 26); on the table 81% | 27% (52 of 192) | 49% | 51% (38 of 74) | 83% (15 of 18); 5.1 uses a game | 25% (1 of 4); 0.2 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 77% (10 of 13); on the table 77% | 17% (7 of 42) | 52% | 65% (35 of 54) | 100% (9 of 9); 4.4 uses a game | 50% (6 of 12); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (5 of 5); on the table 100% | - | 58% | 61% (11 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | - | - | 63% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 98% | 71% (5 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (2 of 2); on the table 100% | 8% (1 of 12) | 3% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 50% (1 of 2); on the table 50% | 56% (10 of 18) | 85% | 79% (11 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 100% (14 of 14); on the table 100% | 0% (0 of 6) | 28% | 38% (10 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 89% (16 of 18); on the table 89% | 36% (26 of 72) | 48% | 63% (29 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 74% (20 of 27); on the table 78% | 42% (10 of 24) | 50% | 63% (53 of 84) | 100% (3 of 3); 1.1 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 5 | 75% (3 of 4); on the table 75% | 25% (6 of 24) | 46% | 85% (44 of 52) | 89% (8 of 9); 5.0 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s2-882d875-p3, 35 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (21) | 52% (27) | 48% (48) |
| ...free all their last turn and able to turn (per game) | 0.40 | 0.57 | 0.97 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.14 | 0.26 |
| ...with the charger already in that arc before they moved (per game) | 0.29 | 0.43 | 0.71 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.06 | 0.00 | 0.06 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.03 | 0.03 | 0.06 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 0.09 | 0.20 |

### Quality by phase: base-s2-882d875-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 62% (69 of 112) | 41% (47 of 116) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (109 of 336) | 40% (57 of 144) |
| Strategy | Support requests answered (helper made contact too) | 60% (6 of 10) | 64% (9 of 14) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (10 of 16) | 50% (3 of 6) |
| Strategy | Joined characters whose unit fought | 47% (22 of 47) | 20% (10 of 49) |
| Strategy | Lone characters that fought | 69% (57 of 83) | 64% (52 of 81) |
| Movement | Charges halted short of contact | 0.1 | 0.6 |
| Movement | Idle units | 1.7 | 2.2 |
| Movement | Points that never moved of their own | 200.3 | 143.4 |
| Movement | Fights charged into per game | 2.5 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 73, net +137 | 14 of 59, net +82 |
| Movement | Charges with odds: sweet spot (55-75%) | 7 of 73, net +285 | 7 of 59, net +55 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 19 of 73, net +107 | 11 of 59, net +73 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 73, net +71 | 19 of 59, net +167 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.4 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (133 of 328) | 51% (165 of 326) |
| Shooting | Points destroyed by shooting units | 50.9 | 16.5 |
| Shooting | War machine shots | 4.8 | 1.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (81 of 167) | 44% (28 of 63) |
| Shooting | Points destroyed by war machines | 35.8 | 31.9 |
| Magic | Magic missiles cast | 2.1 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 47% (35 of 75) | 52% (22 of 42) |
| Magic | Wounds caused by magic missiles | 3.7 | 1.5 |
| Magic | Wounds caused by other spells | 2.2 | - |
| Magic | Points destroyed by magic (all spells) | 55.4 | 15.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.5 / 0.9 / 0.1 | 2.0 / 0.4 / 0.0 / 0.4 |
| Combat | Points destroyed in combat | 220.0 | 242.3 |
| Combat | Points run down | 107.9 | 39.3 |
| Combat | Net points per charged fight, damage counted | +114 | +104 |
| Combat | Net per 100 charger points, damage counted | +35.2 | +29.8 |
| Combat | First round won (charged fights) | 88% | 62% |
| Combat | Net points per charged fight | +111 | +99 |
| Combat | Net points per supported fight / lone fight | +194 / +102 | +239 / +84 |
| Combat | Charged fights on a top-3 enemy unit | 23 of 88 | 35 of 74 |
| Game | Points lost | 453.0 | 562.9 |
| Game | VP from objectives | 660.6 | 614.9 |
| Game | Lone holders (player turns) | 5.0 | 2.6 |

- Mine won / drew / lost: 14 / 9 / 12 of 35 ended games (of 35); mean margin (Mine - Opponent) +155 VP
- The side that went first won 12 of 26 games with a winner
- Points traded per game (both sides' losses): 1016
- Games not ended: 0; findings 5, warnings 0

### Opponent rules: base-s2-882d875-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 1.9 | 1.0 | +0.0 | 0.0 | 4.3 |
| AFTERMATH IN POINTS | 0.3 | +48.2 | 0.0 | 11.5 | 0.1 | +1.2 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.1 | +6.3 | 0.0 | 0.0 | 0.1 | +8.5 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 13.8 | +193.2 | 0.0 | 77.9 | 19.1 | +151.2 | 0.0 | 309.6 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 17.1 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 3.3 |
| BEST OVERALL | 0.0 | +1.7 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| BEST PRIZE | 0.0 | -1.6 | 0.0 | 0.0 | 0.2 | +0.2 | 13.6 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -20.0 | 22.3 | 0.0 | 0.4 | -63.8 | 15.9 | 0.0 |
| BOMBING RUN | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 11.9 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 26.0 | 0.0 | 0.2 | +0.0 | 51.2 | 0.0 |
| CANNON PLANNED TARGET | 4.7 | +64.7 | 188.9 | 72.7 | 1.5 | +73.5 | 105.4 | 14.6 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +30.1 | 11.3 | 31.4 | 0.9 | +17.8 | 43.6 | 13.5 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +22.8 | 9.4 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 20.3 | 0.8 | +0.0 | 0.0 | 12.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.6 | +38.5 | 0.0 | 16.9 | 1.0 | +26.2 | 0.0 | 29.5 |
| CHAFF PASSED | 0.2 | -0.6 | 0.0 | 2.1 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -1.4 | 0.0 | 3.1 | 0.0 | -0.2 | 6.1 | 0.0 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 0.0 | 1.9 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.1 | +8.0 | 6.7 | 0.0 |
| CHARGE LOSSES | 10.7 | -444.7 | 0.0 | 149.0 | 9.5 | -513.6 | 0.0 | 279.4 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 3.9 | 3.1 | 0.1 | +0.0 | 5.2 | 3.0 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 225.3 | 38.3 | 1.8 | +0.0 | 174.0 | 48.6 |
| CHARGER SLAIN LOST | 0.3 | -7.0 | 14.5 | 12.9 | 0.1 | -3.2 | 0.0 | 8.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 25.0 | 10.6 | 0.4 | +0.0 | 14.8 | 14.2 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.0 | +111.6 | 29.3 | 23.7 | 1.0 | +77.2 | 3.1 | 14.5 |
| COVER ONCE | 4.5 | -334.4 | 0.0 | 38.6 | 3.9 | -280.7 | 0.0 | 103.4 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +5.0 | 10.3 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.4 | -7.3 | 33.2 | 6.4 | 0.5 | -6.0 | 23.8 | 22.6 |
| DEPLOY BY FIGURES | 7.8 | +6.4 | 0.0 | 15.0 | 7.3 | +34.2 | 0.0 | 7.6 |
| EDGE GIVE GROUND | 0.3 | +26.2 | 46.8 | 0.0 | 0.3 | +19.3 | 42.1 | 0.0 |
| ELIXIR WORTH | 0.0 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.1 | +10.7 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.4 | +6.1 | 268.1 | 42.2 | 2.0 | +16.6 | 106.5 | 76.3 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.3 |
| FALLS SHORT | 5.1 | +87.5 | 0.0 | 72.5 | 13.6 | +177.4 | 0.0 | 223.9 |
| FEATURE BUFFS | 2.2 | +41.6 | 0.0 | 37.1 | 1.5 | +28.0 | 0.0 | 27.5 |
| FIGHT LIFT | 0.0 | +0.1 | 3.3 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.9 | +15.5 | 124.1 | 13.1 | 1.1 | +21.9 | 89.8 | 37.2 |
| FIRE IN ORDER | 0.2 | +0.0 | 5.7 | 0.0 | 0.1 | +0.0 | 1.7 | 3.1 |
| FIVE ACTION | 89.0 | +4816.7 | 1010.2 | 742.1 | 83.4 | +5042.0 | 720.8 | 1203.4 |
| FLANK NOT WEIGHED | 3.9 | +0.0 | 0.0 | 46.6 | 3.2 | +0.0 | 0.0 | 108.3 |
| FOCUS FIRE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +190.0 | 0.0 | 27.9 | 0.6 | +111.9 | 0.0 | 29.9 |
| FOUR ROUNDS | 3.5 | +256.7 | 382.6 | 60.6 | 3.5 | +311.1 | 226.9 | 85.5 |
| FRIEND CHARGES FIRST | 0.1 | -3.3 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.4 | -6.6 | 0.0 | 11.7 | 0.4 | -2.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +1.8 | 0.0 | 0.0 | 0.1 | +4.8 | 0.0 | 0.0 |
| GATEWAY ESCAPE | - | - | - | - | 0.0 | +2.7 | 0.0 | 16.3 |
| GIVES UP | 0.3 | -5.7 | 19.5 | 6.7 | 0.2 | -5.3 | 17.7 | 0.0 |
| GUN FIGURES | 1.1 | +29.0 | 56.3 | 1.9 | 0.3 | +9.0 | 11.0 | 0.0 |
| GUN MASK | 0.9 | +5.9 | 0.0 | 10.8 | 0.6 | +11.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.6 | +0.0 | 0.0 | 9.6 | 0.9 | +0.0 | 0.0 | 4.7 |
| HE SHOOTS OR CHARGES | 2.3 | +0.0 | 0.0 | 59.8 | 3.3 | +0.0 | 0.0 | 141.1 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 5.3 |
| HIS CHARGE DENIED | 0.5 | +12.6 | 40.3 | 6.4 | 0.4 | +18.6 | 31.8 | 14.6 |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 44.5 | 6.6 | +0.0 | 0.0 | 125.4 |
| HIS FIGHT TOGETHER | 1.5 | -48.0 | 0.0 | 55.9 | 1.5 | -40.1 | 0.0 | 157.7 |
| HIS LEGAL MOVES | 3.9 | +0.0 | 0.0 | 29.4 | 4.3 | +0.0 | 0.0 | 52.0 |
| HIS MOVE AND SHOT | 4.4 | -72.7 | 0.0 | 63.3 | 3.3 | -68.6 | 0.0 | 126.7 |
| HIS MOVE AS HE DECIDES | 37.1 | +13.5 | 622.9 | 0.0 | 35.0 | +14.2 | 361.9 | 0.0 |
| HIS MOVE WHY | 35.7 | +0.0 | 0.0 | 254.3 | 36.0 | +0.0 | 0.0 | 526.9 |
| HIS ONE MOVE | 17.7 | +10.3 | 0.0 | 23.1 | 18.9 | +33.8 | 4.2 | 158.1 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 4.1 | 3.5 | +0.0 | 0.0 | 69.7 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 6.0 | 1.4 | +0.0 | 0.0 | 22.3 |
| HIS RANDOM MOVE | 6.7 | +0.0 | 0.0 | 93.4 | 2.2 | +0.0 | 0.0 | 2.6 |
| HIS SHOT LIST | 34.4 | +1234.1 | 0.0 | 239.0 | 48.3 | +2362.1 | 0.0 | 692.5 |
| HIS TURN DENIED | 1.2 | +22.0 | 124.2 | 41.6 | 1.7 | +55.0 | 124.3 | 45.5 |
| HOLD ODDS | 17.7 | +0.0 | 0.0 | 162.7 | 17.3 | +0.0 | 0.0 | 241.3 |
| HOLDER ASSIGNMENT | 9.7 | +915.2 | 0.0 | 73.3 | 10.0 | +954.0 | 0.0 | 111.9 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.2 | -127.3 | 347.9 | 44.6 | 3.1 | -160.6 | 224.3 | 74.1 |
| HORN WORTH | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +6.5 | 0.0 | 0.0 | 0.5 | +45.6 | 0.0 | 0.0 |
| IDLE COST | 3.8 | -59.2 | 0.0 | 47.6 | 11.7 | -179.3 | 0.0 | 181.6 |
| JOINT CHARGE NOW | 0.7 | +38.7 | 104.3 | 3.3 | 0.8 | +18.3 | 27.9 | 10.9 |
| JOINT KNOWS CHALLENGE | 0.0 | -2.8 | 0.0 | 0.0 | 0.0 | -1.2 | 0.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.0 | +2.5 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.1 | +0.0 | 0.0 | 9.4 | 2.9 | +0.0 | 0.0 | 39.0 |
| LANE BY FIGURES | 0.9 | +25.3 | 0.0 | 0.0 | 1.0 | +42.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.6 |
| LEGAL CHARGES ONLY | 4.8 | +0.0 | 163.7 | 231.0 | 4.6 | +0.0 | 148.1 | 232.5 |
| LONE CHARACTER SAFE SPOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.5 | +36.2 | 0.0 | 0.0 | 0.4 | +26.1 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.2 | 16.3 | 0.0 | 0.1 | -2.4 | 0.0 | 3.6 |
| LOST AFTER ESCAPE | 1.9 | +2.7 | 187.0 | 17.3 | 1.7 | +3.7 | 70.3 | 74.1 |
| LOST CHARGE | 0.1 | -0.2 | 5.1 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -9.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.2 | +14.7 | 0.0 | 17.3 |
| MANOEUVRE | 1.0 | +0.3 | 0.0 | 6.7 | 0.7 | +1.9 | 0.0 | 11.8 |
| MARCH AT ESCAPER | 0.3 | +2.7 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.5 | +29.1 | 0.0 | 11.6 | 0.5 | +44.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +28.2 | 0.0 | 17.2 | 1.1 | +98.4 | 0.0 | 19.1 |
| MARCH ODDS | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | +8.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.8 | +20.9 | 0.0 | 11.6 | 0.7 | +27.5 | 0.0 | 10.9 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 8.7 |
| MAX FOR POSITIONING | 2.4 | +48.8 | 0.0 | 29.6 | 2.7 | +80.8 | 0.0 | 65.3 |
| MISSILES IN THE MOVE | 4.3 | +102.2 | 0.0 | 55.4 | 3.8 | +57.8 | 0.0 | 47.4 |
| MISSILES NEXT TURN | 5.6 | +87.4 | 0.0 | 72.9 | 5.3 | +56.0 | 0.0 | 61.4 |
| MISSILES ON ONE TARGET | 0.1 | -7.1 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | 0.1 | +12.3 | 0.0 | 1.7 | - | - | - | - |
| MOVE ORDER | 1.2 | +0.0 | 1.9 | 0.0 | 2.1 | +0.0 | 28.5 | 18.7 |
| MOVE SPELL IN RANGE | 0.3 | +11.2 | 0.0 | 10.9 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -6.9 | 0.0 | 10.9 | 0.1 | -2.6 | 0.0 | 13.4 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.5 | +540.3 | 0.0 | 28.7 | 6.5 | +687.8 | 0.0 | 140.4 |
| MOVES UNITS SPELL | 0.1 | +3.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.8 | +311.6 | 0.0 | 52.4 | 6.3 | +251.7 | 0.0 | 57.4 |
| NEXT CHARGE BY LIST | 4.9 | -176.1 | 0.0 | 19.8 | 5.6 | -208.9 | 30.7 | 178.7 |
| NEXT OBJECTIVE NEARER | 0.0 | -0.9 | 0.0 | 0.0 | 0.1 | -3.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -142.9 | 288.1 | 49.0 | 2.6 | -111.3 | 144.7 | 76.8 |
| NO LATE CUT | 0.6 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 18.2 |
| NO RALLY LEFT | 0.1 | +10.8 | 0.0 | 4.0 | - | - | - | - |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 3.5 | 0.1 | +0.0 | 0.0 | 2.3 |
| NOT WORTH A CAST | 0.7 | -0.4 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 3.1 | -151.0 | 21.8 | 14.5 | 3.7 | -171.7 | 16.1 | 62.0 |
| ONE CHARGE A CHARGER | 4.4 | +0.0 | 0.0 | 101.7 | 3.3 | +0.0 | 0.0 | 73.0 |
| ONE FIGHT FORMULA | 3.9 | -73.9 | 0.0 | 45.6 | 4.2 | -100.7 | 0.0 | 147.6 |
| ONE OBJECTIVE FORMULA | 4.5 | +16.3 | 0.0 | 45.5 | 4.2 | +39.7 | 0.0 | 69.0 |
| ONE PROMISE A TARGET | 0.1 | -1.0 | 0.0 | 5.6 | 0.1 | -1.9 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 8.7 |
| ONE TARGET A SHOOTER | 22.9 | +437.2 | 0.0 | 190.4 | 29.9 | +739.2 | 0.0 | 488.9 |
| OPENS A LANE | - | - | - | - | 0.2 | +0.3 | 43.3 | 0.0 |
| OPENS UP | 0.4 | +23.5 | 20.1 | 27.9 | 0.1 | +4.0 | 3.1 | 0.0 |
| OVERRUNS AWAY | 0.5 | +14.0 | 80.5 | 5.9 | 0.4 | +6.5 | 23.9 | 9.2 |
| OWN CAST FIRST | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +30.1 | 0.0 | 2.1 | 0.3 | +20.4 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.0 | +2.9 | 0.0 | 0.0 | 0.0 | +1.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.4 | 0.0 | 1.5 | 0.1 | -3.0 | 0.0 | 4.0 |
| PLAN RESULT | 40.9 | +677.2 | 440.0 | 588.7 | 40.1 | +514.8 | 225.3 | 848.0 |
| PROMISE BELOW ZERO | 0.1 | +0.0 | 0.0 | 4.3 | 0.4 | +0.0 | 0.0 | 21.1 |
| PROMISE BY ITS OWN SUM | 8.2 | -247.1 | 0.0 | 11.1 | 8.7 | -199.0 | 0.0 | 56.2 |
| PROMISE HOLDS THE SPOT | - | - | - | - | 0.1 | +1.5 | 0.0 | 4.6 |
| PROMISE IN STEPS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.5 | -0.3 | 0.0 | 0.0 | 0.7 | -2.2 | 0.0 | 9.4 |
| PROMISE READS THE TABLE | 0.3 | -14.7 | 0.0 | 11.7 | 0.3 | -1.8 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -13.0 | 83.7 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| PURSUES BIG PREY | 0.0 | -2.6 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| QUARTER ODDS | 19.2 | +1816.4 | 165.0 | 132.1 | 14.1 | +1604.0 | 58.9 | 141.4 |
| RANDOM MOVE BY FIGURES | 0.7 | +11.8 | 0.0 | 9.7 | 2.1 | +38.3 | 0.0 | 60.6 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 8.7 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -5.6 | 0.0 | 15.2 | 0.9 | -29.3 | 0.0 | 26.6 |
| REDIRECT COUNTER | 1.1 | +28.1 | 0.0 | 14.5 | 2.3 | +188.8 | 0.0 | 70.4 |
| REDIRECT WEIGHED | 0.1 | +4.4 | 6.2 | 0.0 | 0.2 | +1.6 | 13.9 | 0.0 |
| REFORMS TO MEET IT | 1.5 | -38.2 | 0.0 | 0.0 | 1.3 | -24.4 | 0.0 | 41.5 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 17.6 | 0.3 | +0.0 | 0.0 | 7.6 |
| RESERVE FALL BACK | 0.3 | +25.3 | 0.0 | 11.3 | 0.7 | +39.8 | 0.0 | 8.6 |
| RESTRAINS TO SHOOT | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.4 | +88.9 | 263.1 | 46.0 | 2.0 | -6.8 | 126.0 | 62.2 |
| RISK BY HIS FIGURE | 18.6 | -309.1 | 0.0 | 280.9 | 18.4 | -295.0 | 0.0 | 574.3 |
| RISK ON THE WAY | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.6 | -17.4 | 81.0 | 0.0 | 1.8 | -40.4 | 148.3 | 38.3 |
| RUN DOWN | 2.1 | -36.0 | 236.7 | 14.0 | 2.5 | -37.4 | 179.5 | 46.4 |
| SAFER THAN THE JOB | 0.0 | +1.7 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.0 | -0.9 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.1 | 0.0 | 1.6 | 0.3 | +0.7 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 1.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | +5.8 | 0.0 | 0.0 | 0.3 | -24.4 | 0.0 | 1.1 |
| SEARCH SPOT | 0.3 | +7.9 | 0.0 | 13.3 | 0.3 | +9.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.2 | +11.4 | 25.3 | 3.3 | 0.1 | +8.0 | 22.7 | 3.0 |
| SELF MOVE SPELL | 0.4 | +44.4 | 0.0 | 0.0 | 0.2 | +50.3 | 0.0 | 18.6 |
| SET UP BY THE SET | 1.8 | +32.4 | 12.9 | 14.6 | 2.1 | +41.7 | 21.1 | 33.1 |
| SET UP TOGETHER | 0.2 | +1.4 | 0.0 | 0.0 | 0.5 | +17.7 | 0.0 | 17.3 |
| SET-UP ANY TARGET | 0.2 | +19.0 | 10.9 | 10.9 | 0.1 | +9.9 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +4.7 | 0.0 | 2.7 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.1 | +82.2 | 86.3 | 11.1 | 1.3 | +58.6 | 59.2 | 9.7 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -7.8 | 36.2 | 3.6 | 0.2 | -14.3 | 10.9 | 0.0 |
| SHOT RISK POINTS | 15.7 | +82.9 | 0.0 | 132.5 | 21.3 | -82.1 | 0.0 | 370.1 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.2 | +445.7 | 0.0 | 168.7 | 10.1 | +297.1 | 0.0 | 164.1 |
| SPELL SETS UP CHARGE | 0.5 | +73.4 | 10.9 | 10.9 | 0.1 | +9.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +18.6 | 3.3 | 10.1 | 2.0 | +29.6 | 30.1 | 24.1 |
| SPELLS IN THE FIGHT | 0.3 | +6.7 | 33.2 | 0.0 | 0.4 | -9.4 | 22.1 | 38.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 82.3 | 9.3 | +0.0 | 0.0 | 226.3 |
| STAND AND SHOOT | 0.6 | -5.1 | 56.3 | 27.1 | 0.6 | -10.6 | 29.5 | 11.9 |
| STANDS FOR A REASON | 0.4 | +0.0 | 1.1 | 15.1 | 1.9 | +0.0 | 6.9 | 59.3 |
| STANDS STILL | 44.6 | +0.0 | 627.6 | 351.3 | 28.0 | +0.0 | 493.9 | 279.8 |
| STAY WORTH | 23.2 | -182.7 | 365.6 | 227.6 | 12.1 | +134.7 | 359.1 | 152.7 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.9 | 0.3 | +0.0 | 0.0 | 14.6 |
| STUPIDITY NEXT TURN | 0.1 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 32.6 |
| SUPPORT ADDS | 6.1 | +452.0 | 0.0 | 41.2 | 5.7 | +403.8 | 0.0 | 101.2 |
| SUPPORT NARROWED | 0.4 | +0.0 | 23.9 | 5.0 | 0.1 | +0.0 | 22.9 | 0.0 |
| SUPPORT WORKED OUT | 6.1 | +452.0 | 0.0 | 41.2 | 5.7 | +403.8 | 0.0 | 101.2 |
| SURE REACH TOGETHER | 0.1 | +2.0 | 0.0 | 0.0 | 0.2 | +3.1 | 0.0 | 3.5 |
| THE DEARER SUM KEEPS ITS PLAN | 1.6 | +0.0 | 0.0 | 6.2 | 1.3 | +0.0 | 0.0 | 24.0 |
| THE PROMISE ADDS | 0.2 | -9.9 | 0.0 | 0.0 | 0.1 | -3.4 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.5 | +0.0 | 0.0 | 186.0 | 33.4 | +0.0 | 0.0 | 450.8 |
| TIED UP BY THE SUM | 1.1 | +114.5 | 101.0 | 21.3 | 0.7 | +83.1 | 48.1 | 3.9 |
| TIME ON OUR SIDE | 33.7 | +369.8 | 58.6 | 149.4 | 15.2 | +159.7 | 1.5 | 187.8 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 44.7 |
| WALKS ON ITS ROUTE | 0.0 | -4.0 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | - | - | - | - | 0.0 | +6.7 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.1 | +0.0 | 32.2 | 0.0 | 0.1 | +0.0 | 0.0 | 3.9 |
| WHAT THE JOINER ADDS | 0.1 | +7.1 | 43.2 | 0.0 | 0.4 | +17.2 | 55.8 | 0.0 |
| WHO GETS IN | 0.1 | +6.3 | 32.6 | 0.0 | 0.2 | -6.3 | 6.3 | 5.6 |
| WHO HITS BACK | 0.3 | +38.8 | 0.0 | 26.3 | 0.2 | +17.2 | 0.0 | 6.7 |
| WHOLE FIGHT | 0.1 | +1.7 | 21.6 | 0.0 | 0.2 | -28.6 | 27.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +22.0 | 21.4 | 3.3 | 0.0 | +1.8 | 0.0 | 0.0 |
| WIDER SPREAD | 2.1 | -7.5 | 267.6 | 32.4 | 2.6 | -13.3 | 191.3 | 54.7 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 3.6 | 0.0 |
| WOUNDS ON THE RANKS | 1.9 | +72.4 | 0.0 | 0.0 | 2.2 | +89.5 | 0.0 | 44.8 |

### Rule changes: base-s2-882d875-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2524 | 2524 | 1554 | 44.40 | +0 | +0.0 |
| HIS MOVE WHY | 2510 | 2510 | 1366 | 39.03 | +0 | +0.0 |
| ARMY TABLE | 1150 | 1150 | 817 | 23.34 | +13444 | +16.5 |
| HIS SHOT LIST | 2895 | 2772 | 694 | 19.83 | +14761 | +21.3 |
| HOLDER ASSIGNMENT | 687 | 687 | 641 | 18.31 | +38304 | +59.8 |
| ONE TARGET A SHOOTER | 1849 | 1759 | 373 | 10.66 | +4456 | +11.9 |
| LEGAL CHARGES ONLY | 331 | 331 | 331 | 9.46 | +0 | +0.0 |
| DEPLOY BY FIGURES | 529 | 529 | 311 | 8.89 | +3607 | +11.6 |
| HIS ONE MOVE | 1281 | 1237 | 285 | 8.14 | +69 | +0.2 |
| THE TABLE AGAIN | 418 | 418 | 275 | 7.86 | +0 | +0.0 |
| OFF BEST | 239 | 239 | 239 | 6.83 | -11293 | -47.3 |
| TIME ON OUR SIDE | 1713 | 1551 | 239 | 6.83 | +873 | +3.7 |
| FIVE ACTION | 6033 | 5816 | 226 | 6.46 | +10843 | +48.0 |
| PROMISE BY ITS OWN SUM | 592 | 592 | 219 | 6.26 | -15612 | -71.3 |
| MOVE TO CHARGE COMPUTED | 418 | 348 | 199 | 5.69 | +11233 | +56.4 |
| SHOT RISK POINTS | 1298 | 1219 | 146 | 4.17 | +4854 | +33.2 |
| QUARTER ODDS | 1166 | 1107 | 144 | 4.11 | +12693 | +88.1 |
| SUPPORT ADDS | 411 | 391 | 128 | 3.66 | +6434 | +50.3 |
| SUPPORT WORKED OUT | 411 | 391 | 128 | 3.66 | +6434 | +50.3 |
| HARD STAY DROPPED | 125 | 125 | 125 | 3.57 | +0 | +0.0 |
| MOVE ORDER | 116 | 116 | 116 | 3.31 | +0 | +0.0 |
| FOUR ROUNDS | 246 | 237 | 114 | 3.26 | +5880 | +51.6 |
| IDLE COST | 541 | 423 | 96 | 2.74 | +811 | +8.5 |
| SHOOTS FROM THE BEST SPOT | 116 | 116 | 73 | 2.09 | +979 | +13.4 |
| ADVANCE LANE KEPT | 69 | 69 | 69 | 1.97 | +0 | +0.0 |
| LANE BY FIGURES | 66 | 66 | 66 | 1.89 | +2363 | +35.8 |
| FOLLOW UP WEIGHED | 58 | 58 | 58 | 1.66 | +10568 | +182.2 |
| RANDOM MOVE BY FIGURES | 97 | 97 | 57 | 1.63 | +1754 | +30.8 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.54 | +0 | +0.0 |
| SET UP BY THE SET | 136 | 126 | 54 | 1.54 | +5131 | +95.0 |
| TIED UP BY THE SUM | 63 | 60 | 54 | 1.54 | +1701 | +31.5 |
| CAST JOB | 77 | 77 | 52 | 1.49 | +608 | +11.7 |
| JOINT CHARGE NOW | 52 | 52 | 52 | 1.49 | +1996 | +38.4 |
| CHARGE LOSSES | 706 | 655 | 49 | 1.40 | +4940 | +100.8 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.34 | +0 | +0.0 |
| RISK BY ARC | 154 | 147 | 47 | 1.34 | +1878 | +40.0 |
| RISK BY HIS FIGURE | 1294 | 1227 | 47 | 1.34 | +4795 | +102.0 |
| MAX FOR POSITIONING | 179 | 166 | 46 | 1.31 | +216 | +4.7 |
| MARCH CHECK | 63 | 63 | 43 | 1.23 | +1073 | +25.0 |
| CHAFF IN THE MOVE | 56 | 54 | 42 | 1.20 | +15 | +0.4 |
| STAY WORTH | 1238 | 1125 | 39 | 1.11 | +351 | +9.0 |
| HOLDS AMBUSHERS | 36 | 36 | 36 | 1.03 | +0 | +0.0 |
| FALLS SHORT | 653 | 573 | 35 | 1.00 | +262 | +7.5 |
| RESERVE FALL BACK | 35 | 35 | 35 | 1.00 | +2278 | +65.1 |
| MARCH BY THE SUM | 34 | 34 | 34 | 0.97 | +2568 | +75.5 |
| CHARGE NOW FIRST | 130 | 130 | 32 | 0.91 | -1259 | -39.3 |
| LONE WIZARD KEPT IN | 31 | 31 | 31 | 0.89 | +2181 | +70.3 |
| COVER ONCE | 294 | 202 | 29 | 0.83 | +659 | +22.7 |
| SHOTS IN THE MOVE | 884 | 676 | 26 | 0.74 | +660 | +25.4 |
| NEXT CHARGE BY LIST | 367 | 337 | 25 | 0.71 | +404 | +16.2 |
| SCOUT WAITS | 25 | 25 | 25 | 0.71 | +0 | +0.0 |
| MISSILES IN THE MOVE | 284 | 184 | 24 | 0.69 | +357 | +14.9 |
| SHOTS AFTER THE MOVES | 162 | 162 | 24 | 0.69 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 141 | 138 | 24 | 0.69 | +565 | +23.6 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.66 | +0 | +0.0 |
| PATHS CROSS | 22 | 22 | 22 | 0.63 | +1769 | +80.4 |
| SHOOTERS IN TWO RANKS | 22 | 22 | 22 | 0.63 | +53 | +2.4 |
| WHO HITS BACK | 20 | 20 | 20 | 0.57 | +1198 | +59.9 |
| CANNON PLANNED TARGET | 217 | 217 | 18 | 0.51 | +135 | +7.5 |
| HIS TURN DENIED | 102 | 100 | 18 | 0.51 | +553 | +30.7 |
| NEARER NOT NEEDED | 496 | 480 | 17 | 0.49 | +702 | +41.3 |
| REDIRECT COUNTER | 120 | 91 | 17 | 0.49 | +1452 | +85.4 |
| SEARCH SPOT | 21 | 21 | 16 | 0.46 | +643 | +40.2 |
| ONE OBJECTIVE FORMULA | 306 | 237 | 15 | 0.43 | +958 | +63.9 |
| STUCK PIVOT | 15 | 15 | 15 | 0.43 | +0 | +0.0 |
| CASTING BLOCK | 19 | 19 | 13 | 0.37 | +262 | +20.2 |
| FEATURE BUFFS | 131 | 131 | 13 | 0.37 | +147 | +11.3 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.34 | +0 | +0.0 |
| SECOND LOOK | 12 | 12 | 12 | 0.34 | +677 | +56.4 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.31 | +1729 | +157.2 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -24 | -2.2 |
| EDGE GIVE GROUND | 24 | 24 | 11 | 0.31 | +341 | +31.0 |
| PROMISE SHOT AWAY | 11 | 11 | 11 | 0.31 | -455 | -41.3 |
| REDIRECT WEIGHED | 11 | 11 | 11 | 0.31 | +411 | +37.4 |
| FIRE IN ORDER | 10 | 10 | 10 | 0.29 | +0 | +0.0 |
| OPENS UP | 17 | 16 | 10 | 0.29 | +249 | +24.9 |
| PROMISE KNOWS THE FIGHT | 43 | 35 | 10 | 0.29 | -90 | -9.0 |
| BEST PRIZE | 9 | 9 | 9 | 0.26 | -380 | -42.2 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.26 | +0 | +0.0 |
| HIS FIGHT TOGETHER | 106 | 106 | 9 | 0.26 | +497 | +55.2 |
| MARCH OF THE TABLE | 9 | 9 | 9 | 0.26 | -286 | -31.8 |
| WHO GETS IN | 9 | 9 | 9 | 0.26 | +0 | +0.0 |
| GUN MASK | 53 | 53 | 8 | 0.23 | +124 | +15.5 |
| HIS CHARGE DENIED | 30 | 27 | 8 | 0.23 | +259 | +32.4 |
| REFUSING RETIRES | 23 | 23 | 8 | 0.23 | -3 | -0.3 |
| SURE REACH TOGETHER | 9 | 9 | 8 | 0.23 | +58 | +7.3 |
| CHARGE NOT DECLARED | 7 | 7 | 7 | 0.20 | -688 | -98.3 |
| FIGHT TO THE END | 69 | 64 | 7 | 0.20 | +262 | +37.4 |
| MANOEUVRE | 57 | 57 | 7 | 0.20 | +174 | +24.8 |
| MISSILES NEXT TURN | 382 | 264 | 7 | 0.20 | +52 | +7.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.20 | +141 | +20.1 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.20 | -121 | -17.3 |
| AFTERMATH WITH FRIENDS | 6 | 6 | 6 | 0.17 | +517 | +86.2 |
| ONE FIGHT FORMULA | 283 | 128 | 6 | 0.17 | +180 | +30.1 |
| OVERRUNS AWAY | 33 | 32 | 6 | 0.17 | +244 | +40.8 |
| SUPPORT NARROWED | 18 | 18 | 6 | 0.17 | -689 | -114.9 |
| FALL BACK GOOD ORDER | 153 | 145 | 5 | 0.14 | +234 | +46.8 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.14 | +231 | +46.3 |
| HIS MOVE AND SHOT | 270 | 251 | 5 | 0.14 | +80 | +15.9 |
| NO DOUBLE ROUNDS | 183 | 176 | 5 | 0.14 | +192 | +38.5 |
| NO RALLY LEFT | 5 | 5 | 5 | 0.14 | +238 | +47.7 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 25 | 24 | 5 | 0.14 | +39 | +7.9 |
| WHOLE FIGHT GAIN | 8 | 7 | 5 | 0.14 | +149 | +29.7 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +87 | +21.8 |
| LOST AFTER ESCAPE | 124 | 118 | 4 | 0.11 | +5 | +1.4 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 0.11 | -100 | -25.0 |
| PROMISE READS THE TABLE | 22 | 22 | 4 | 0.11 | -194 | -48.5 |
| WALKS ON ITS ROUTE | 4 | 4 | 4 | 0.11 | -151 | -37.7 |
| WHAT THE JOINER ADDS | 17 | 13 | 4 | 0.11 | +350 | +87.5 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.09 | +0 | +0.1 |
| HONEST WORTH | 221 | 213 | 3 | 0.09 | +45 | +15.0 |
| HORN WORTH | 3 | 3 | 3 | 0.09 | +70 | +23.2 |
| HUNT IN PAIRS | 26 | 12 | 3 | 0.09 | +516 | +172.0 |
| MODEL FACING | 3 | 3 | 3 | 0.09 | +430 | +143.3 |
| OWN CAST FIRST | 3 | 3 | 3 | 0.09 | -11 | -3.8 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.09 | -117 | -38.9 |
| ROUNDS AFTER TERROR | 84 | 81 | 3 | 0.09 | +77 | +25.8 |
| BEST OVERALL | 2 | 2 | 2 | 0.06 | +76 | +38.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +43 | +21.3 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.06 | +278 | +139.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| FACES THE THREAT | 2 | 2 | 2 | 0.06 | +375 | +187.3 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +156 | +78.0 |
| PROMISE HOLDS THE SPOT | 2 | 2 | 2 | 0.06 | +52 | +26.2 |
| REDIRECT BY WHAT IT STOPS | 53 | 53 | 2 | 0.06 | +0 | +0.0 |
| SAFER THAN THE JOB | 2 | 2 | 2 | 0.06 | +76 | +38.0 |
| DEFENSIVE ARMY | 1 | 1 | 1 | 0.03 | -8 | -7.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +96 | +96.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +3 | +2.9 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.03 | +87 | +87.4 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MARCH ODDS | 1 | 1 | 1 | 0.03 | -35 | -34.9 |
| MOVE SPELL IN RANGE | 10 | 5 | 1 | 0.03 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.03 | +21 | +21.0 |
| RUN DOWN | 162 | 155 | 1 | 0.03 | +12 | +12.3 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +62 | +62.1 |
| WHOLE FIGHT | 9 | 7 | 1 | 0.03 | +10 | +10.5 |
| WIDER SPREAD | 166 | 159 | 1 | 0.03 | +9 | +9.4 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 9 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 21 | 21 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 16 | 16 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 51 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 82 | 70 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 12 | 12 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 70 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 32 | 29 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 250 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 30 | 26 | 0 | 0.00 | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| GIVES UP | 16 | 14 | 0 | 0.00 | - | - |
| GUN FIGURES | 47 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 197 | 193 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 416 | 393 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 286 | 260 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 218 | 197 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 107 | 107 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 310 | 280 | 0 | 0.00 | - | - |
| HOLD ODDS | 1225 | 1222 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 174 | 171 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 9 | 9 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 8 | 7 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 10 | trace | - | - | - | - |
| MARCH OVER CASTS | 52 | 52 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 57 | 57 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 12 | trace | - | - | - | - |
| MOVE SPELL SPOT | 20 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 6 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 52 | 50 | 0 | 0.00 | - | - |
| NOT TURNED | 7 | 7 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 35 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 270 | 261 | 0 | 0.00 | - | - |
| ONE ROUTE | 57 | 57 | 0 | 0.00 | - | - |
| OPENS A LANE | 6 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 2833 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 18 | 18 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 57 | 57 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 99 | 90 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 24 | 23 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET UP TOGETHER | 24 | 17 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 18 | 18 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 119 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 561 | 540 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 42 | 41 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 82 | 73 | 0 | 0.00 | - | - |
| STANDS STILL | 2540 | 2477 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 25 | 25 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 103 | not checked | - | - | - | - |
| THE PROMISE ADDS | 8 | 7 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2238 | not checked | - | - | - | - |
| WAITS AGAIN | 89 | 78 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: base-s2-882d875-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.26 | 3.00 | 71.3 |
| JOB FIRST | gate | 2.31 | 2.86 | 44.2 |
| ARMY TABLE | rule | 0.97 | 2.06 | 59.8 |
| HOLDER ASSIGNMENT | rule | 0.63 | 0.63 | 19.8 |
| NO REASON | gate | 0.60 | 0.60 | 56.9 |
| CHARGE NOW FIRST | rule | 0.49 | 0.43 | 39.3 |
| JOINT CHARGE NOW | rule | 0.29 | 0.29 | 73.2 |
| PROMISE SHOT AWAY | rule | 0.29 | - | 45.4 |
| CHAFF PASSED | rule | 0.20 | 0.06 | 2.7 |
| BEST PRIZE | rule | 0.03 | 0.20 | 47.5 |
| CHARGE NOT DECLARED | rule | 0.09 | 0.11 | 98.3 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.14 | 17.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.11 | 137.9 |
| MARCH OF THE TABLE | rule | 0.03 | 0.14 | 47.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.09 | 0.09 | 14.8 |
| SUPPORT NARROWED | rule | 0.11 | 0.06 | 114.9 |
| AFTERMATH BAND | gate | 0.06 | 0.09 | 3.0 |
| DEPLOY BY FIGURES | rule | 0.06 | 0.03 | 5.9 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 2.3 |
| ONE PROMISE A TARGET | rule | 0.06 | 0.03 | 52.3 |
| OWN CAST FIRST | rule | 0.03 | 0.06 | 3.8 |
| PURSUES BIG PREY | rule | 0.03 | 0.06 | 38.9 |
| REDIRECT WEIGHED | rule | - | 0.09 | 46.6 |
| WHO GETS IN | rule | - | 0.09 | 173.0 |
| PATHS CROSS | rule | 0.03 | 0.03 | 16.5 |
| PROMISE READS THE TABLE | rule | 0.06 | - | 98.7 |
| WALKS ON ITS ROUTE | rule | 0.03 | 0.03 | 86.8 |
| DEFENSIVE ARMY | rule | 0.03 | - | 7.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | - | 10.7 |
| MARCH ODDS | rule | 0.03 | - | 34.9 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| RESERVE FALL BACK | rule | 0.03 | - | 25.0 |
| TURN GATE | gate | - | 0.03 | 42.1 |
| WHO HITS BACK | rule | - | 0.03 | 1.8 |

### Plans: base-s2-882d875-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.8 | 74% | 425 | 290 | 68% |
| Mine | join | 0.5 | 100% | 13 | 0 | 0% |
| Mine | move | 28.9 | 97% | 1472 | 0 | 0% |
| Mine | shoot | 8.2 | 52% | 301 | 387 | 129% |
| Mine | support | 0.5 | 83% | 26 | 0 | 0% |
| Opponent | charge | 2.7 | 57% | 445 | 252 | 57% |
| Opponent | join | 0.6 | 100% | 24 | 0 | 0% |
| Opponent | move | 32.7 | 95% | 1484 | 0 | 0% |
| Opponent | shoot | 3.3 | 62% | 251 | 263 | 105% |
| Opponent | support | 0.7 | 62% | 3 | 0 | 0% |

### Battle groups: base-s2-882d875-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.1 | 35% | 64% | 0% | - | 14% | 7% | 0% | 57% | 21% |
| Opponent | REDIRECT COUNTER | 2.3 | 36% | 83% | 21% | 50% | 9% | 0% | 30% | 61% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s2-882d875-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 32 | 44 (32) | 23 | 21 | 33 | 53% | 3.1 | 26 (16) | 63 (9) | 60 (7) | 61 (25) | 0 (7) |
| Mine | Character | 115 | 44 (115) | 44 | 0 | 21 | 23% | 2.3 | 48 (48) | 53 (42) | 34 (13) | 44 (60) | 52 (43) |
| Mine | Clean-up | 19 | 97 (19) | 22 | 75 | 25 | 37% | 2.7 | 122 (7) | 91 (8) | 56 (4) | 108 (15) | 64 (4) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 43 | 29 (43) | 18 | 12 | 32 | 26% | 3.1 | 18 (19) | 35 (17) | 43 (7) | 32 (30) | 20 (13) |
| Mine | Hammer | 47 | 31 (47) | 18 | 13 | 18 | 28% | 2.8 | 29 (16) | 35 (22) | 24 (9) | 35 (31) | 24 (16) |
| Mine | Holder | 24 | 42 (24) | 0 | 42 | 14 | 67% | 2.5 | 4 (12) | 83 (10) | 0 (2) | 58 (12) | 13 (12) |
| Mine | Shooter | 40 | 70 (40) | 20 | 50 | 19 | 15% | 1.5 | 40 (14) | 93 (19) | 62 (7) | 88 (27) | 39 (13) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 0 | 75% | 4.0 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Mine | War machine | 52 | 16 (52) | 16 | 0 | 44 | 6% | 1.6 | 12 (28) | 30 (15) | 0 (9) | 13 (23) | 18 (29) |
| Mine | Wizard | 16 | 35 (16) | 25 | 10 | 31 | 6% | 2.4 | 21 (6) | 28 (5) | 86 (3) | 27 (8) | 64 (6) |
| Opponent | Chaff | 65 | 60 (65) | 12 | 48 | 56 | 46% | 2.9 | 56 (29) | 111 (19) | 9 (17) | 85 (42) | 23 (23) |
| Opponent | Character | 99 | 35 (99) | 34 | 1 | 22 | 36% | 2.3 | 27 (41) | 31 (38) | 65 (14) | 30 (61) | 46 (32) |
| Opponent | Clean-up | 12 | 37 (12) | 8 | 29 | 18 | 50% | 2.8 | 0 (3) | 57 (6) | 25 (3) | 50 (9) | 0 (3) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 59 | 29 (59) | 9 | 20 | 35 | 53% | 2.6 | 20 (23) | 45 (25) | 12 (11) | 39 (34) | 16 (25) |
| Opponent | Hammer | 47 | 33 (47) | 23 | 9 | 34 | 36% | 3.7 | 11 (17) | 47 (26) | 24 (4) | 40 (33) | 18 (14) |
| Opponent | Holder | 39 | 83 (39) | 8 | 76 | 33 | 49% | 2.8 | 70 (14) | 90 (14) | 107 (10) | 101 (26) | 47 (12) |
| Opponent | Shooter | 29 | 23 (29) | 10 | 13 | 49 | 7% | 1.6 | 43 (11) | 12 (15) | 0 (3) | 21 (19) | 26 (10) |
| Opponent | Support | 5 | 0 (5) | 0 | 0 | 43 | 60% | 3.0 | 0 (2) | 0 (1) | 0 (2) | - | 0 (5) |
| Opponent | War machine | 17 | 36 (17) | 36 | 0 | 30 | 6% | 1.7 | 0 (8) | 61 (7) | 52 (2) | 45 (7) | 31 (10) |
| Opponent | Wizard | 31 | 5 (31) | 5 | 0 | 27 | 29% | 2.6 | 0 (12) | 16 (12) | 0 (1) | 13 (14) | 0 (11) |

### Charged fights: base-s2-882d875-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 26 | 92 | 1.0 | 1.0 | 92 | 100 | -8 | 1 of 4 | 4 of 4 | - | -8 |
| Mine | Chaos Dwarfs | 4 | 310 | 119 | 1.0 | 1.0 | 119 | 0 | +119 | 1 of 4 | 4 of 4 | - | +119 |
| Mine | Dwarfen Mountain Holds | 3 | 273 | 86 | 0.7 | 1.0 | 129 | 0 | +129 | 0 of 2 | 2 of 2 | - | +129 |
| Mine | Empire of Man | 5 | 175 | 140 | 1.4 | 1.0 | 100 | 0 | +100 | 1 of 7 | 6 of 7 | - | +100 |
| Mine | Grand Cathay | 5 | 234 | 358 | 4.6 | 1.0 | 78 | 16 | +61 | 4 of 23 | 19 of 23 | +173 | +56 |
| Mine | High Elf Realms | 4 | 77 | 747 | 4.2 | 1.1 | 176 | 17 | +159 | 7 of 17 | 16 of 17 | +60 | +172 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 236 | 3.0 | 1.0 | 79 | 92 | -13 | 1 of 3 | 1 of 3 | - | -13 |
| Mine | Lizardmen | 1 | 116 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Ogre Kingdoms | 1 | 340 | 144 | 1.0 | 1.0 | 144 | 0 | +144 | 0 of 1 | 1 of 1 | - | +144 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 507 | 5.0 | 1.0 | 101 | 11 | +90 | 1 of 5 | 5 of 5 | - | +90 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1233 | 6.5 | 1.2 | 190 | 0 | +190 | 4 of 13 | 10 of 13 | +329 | +148 |
| Mine | Vampire Counts | 2 | 0 | 501 | 3.5 | 1.3 | 143 | 0 | +143 | 2 of 7 | 7 of 7 | +136 | +146 |
| Mine | Warriors of Chaos | 1 | 0 | 200 | 2.0 | 1.0 | 100 | 0 | +100 | 1 of 2 | 2 of 2 | - | +100 |
| **Mine** | all armies | 35 | 142 | 318 | 2.5 | 1.1 | 127 | 16 | +111 | 23 of 88 | 77 of 88 | +194 | +102 |
| Opponent | Empire of Man | 1 | 569 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 3 | 303 | 228 | 2.3 | 1.4 | 98 | 19 | +78 | 3 of 7 | 3 of 7 | +112 | +65 |
| Opponent | High Elf Realms | 3 | 68 | 88 | 1.0 | 1.0 | 88 | 42 | +46 | 2 of 3 | 1 of 3 | - | +46 |
| Opponent | Kingdom of Bretonnia | 2 | 80 | 84 | 1.5 | 1.0 | 56 | 0 | +56 | 1 of 3 | 2 of 3 | - | +56 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 55 | -55 | 0 of 2 | 1 of 2 | - | -55 |
| Opponent | Skaven | 1 | 120 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 51 | 702 | 5.2 | 1.0 | 134 | 0 | +134 | 10 of 21 | 14 of 21 | +0 | +140 |
| Opponent | Vampire Counts | 6 | 0 | 257 | 2.2 | 1.2 | 119 | 0 | +119 | 5 of 13 | 11 of 13 | +0 | +140 |
| Opponent | Warriors of Chaos | 9 | 0 | 311 | 1.6 | 1.1 | 200 | 45 | +155 | 7 of 14 | 10 of 14 | +722 | +60 |
| Opponent | Wood Elf Realms | 5 | 13 | 72 | 2.0 | 1.0 | 36 | 32 | +4 | 6 of 10 | 3 of 10 | - | +4 |
| **Opponent** | all armies | 35 | 64 | 246 | 2.1 | 1.1 | 117 | 18 | +99 | 35 of 74 | 46 of 74 | +239 | +84 |

### Effective charges: base-s2-882d875-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net +0) | 0 | 0 | 1 (net +40) | 0 | 0 | 2 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 4 | 0 | 0 | 2 (net +216) | 0 | 0 | 1 (net +45) | 1 | 67% (2 of 3) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 1 (net +258) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Empire of Man | 7 | 2 (net +0) | 0 | 1 (net +122) | 2 (net +52) | 1 (net +299) | 1 (net +176) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 23 | 2 (net -86) | 0 | 1 (net +139) | 2 (net +138) | 5 (net +60) | 8 (net +56) | 5 | 6% (1 of 18) |
| Mine | High Elf Realms | 17 | 2 (net +620) | 0 | 2 (net +366) | 1 (net +122) | 6 (net +121) | 3 (net -2) | 3 | 14% (2 of 14) |
| Mine | Kingdom of Bretonnia | 3 | 2 (net -138) | 0 | 0 | 0 | 0 | 1 (net +236) | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 0 | 1 (net +144) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 1 (net +63) | 2 (net +68) | 2 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 13 | 1 (net +233) | 0 | 1 (net +571) | 3 (net +287) | 4 (net +110) | 3 (net +101) | 1 | 8% (1 of 12) |
| Mine | Vampire Counts | 7 | 2 (net +312) | 0 | 0 | 0 | 2 (net +103) | 2 (net +86) | 1 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +100) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 7 | 1 (net +0) | 0 | 0 | 1 (net +52) | 2 (net +26) | 3 (net +148) | 0 | 0% (0 of 7) |
| Opponent | High Elf Realms | 3 | 0 | 0 | 2 (net -63) | 0 | 0 | 1 (net +265) | 0 | 67% (2 of 3) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 1 (net +73) | 1 (net +0) | 1 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 21 | 5 (net +214) | 0 | 2 (net +256) | 2 (net +195) | 5 (net +36) | 5 (net +85) | 2 | 11% (2 of 19) |
| Opponent | Vampire Counts | 13 | 4 (net +169) | 0 | 1 (net +0) | 3 (net +180) | 2 (net +75) | 2 (net +26) | 1 | 8% (1 of 12) |
| Opponent | Warriors of Chaos | 14 | 2 (net -244) | 0 | 1 (net +0) | 2 (net +167) | 1 (net +345) | 7 (net +283) | 1 | 8% (1 of 13) |
| Opponent | Wood Elf Realms | 10 | 1 (net -109) | 0 | 1 (net +0) | 0 | 0 | 0 | 8 | 50% (1 of 2) |

### Charged fights, damage counted: base-s2-882d875-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 240 | 259 | +137 | 207 | 59 | +147 | +61.6 |
| Mine | Effective (55-75%) | 7 | 261 | 210 | +285 | 293 | 2 | +291 | +111.5 |
| Mine | 76-89% | 11 | 267 | 168 | +164 | 166 | 20 | +146 | +54.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 298 | 147 | +71 | 102 | 16 | +86 | +28.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 19 | 459 | 88 | +107 | 113 | 12 | +101 | +21.9 |
| Mine | No odds | 15 | 333 | 205 | +37 | 103 | 59 | +44 | +13.1 |
| Mine | All fights | 88 | 324 | 167 | +111 | 142 | 28 | +114 | +35.2 |
| Opponent | Long shot (under 50%) | 14 | 353 | 298 | +82 | 168 | 57 | +111 | +31.5 |
| Opponent | Effective (55-75%) | 7 | 349 | 360 | +55 | 144 | 83 | +61 | +17.5 |
| Opponent | 76-89% | 8 | 357 | 158 | +164 | 164 | 6 | +158 | +44.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 453 | 228 | +167 | 221 | 55 | +167 | +36.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 417 | 71 | +73 | 73 | 0 | +73 | +17.4 |
| Opponent | No odds | 15 | 159 | 190 | +33 | 60 | 29 | +31 | +19.8 |
| Opponent | All fights | 74 | 349 | 215 | +99 | 143 | 39 | +104 | +29.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s2-882d875-p3 | move | 196 | 53 (27%) | 38 (19%) | 26 (13%) | 117 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: base-s1-882d875-p7

### Scorecard: base-s1-882d875-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0112 | 4 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0112 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 165 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0212 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 255 |
| L0212 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0228 | 6 | 1 | Mine | no | 0 | 2 | 2 | 4 | 1 | 0 | 0 | 307 |
| L0228 | 6 | 1 | Opponent | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 5 | - | 0 | 3 | 0 | 0 | 0 | 461 |
| L0313 | 1 | 1 | Opponent | no | 6 | 3 | 1 | 0 | 0 | 0 | 0 | 70 |
| L0329 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0329 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 1 | 0 | 0 | 170 |
| L0415 | 1 | 1 | Mine | no | 4 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Opponent | no | 2 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 310 |
| L0432 | 6 | 1 | Opponent | no | 2 | 2 | 7 | 1 | 2 | 0 | 0 | 170 |
| L0518 | 2 | 1 | Mine | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 445 |
| L0518 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 234 |
| L0535 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 377 |
| L0535 | 1 | 1 | Opponent | yes | 3 | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0622 | 4 | 1 | Mine | no | 5 | - | 1 | 1 | 0 | 0 | 0 | 693 |
| L0622 | 4 | 1 | Opponent | no | 0 | 2 | 8 | 0 | 0 | 0 | 0 | 72 |
| L0711 | 3 | 1 | Mine | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 125 |
| L0711 | 3 | 1 | Opponent | no | 11 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0727 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 295 |
| L0727 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0833 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 632 |
| L0833 | 5 | 1 | Opponent | no | - | 2 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0924 | 6 | 1 | Mine | no | 4 | 6 | 1 | 1 | 0 | 0 | 0 | 125 |
| L0924 | 6 | 1 | Opponent | no | 7 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1015 | 1 | 1 | Mine | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1015 | 1 | 1 | Opponent | no | 1 | 3 | 6 | 2 | 0 | 0 | 0 | 115 |
| L1032 | 6 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 291 |
| L1032 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1124 | 2 | 1 | Mine | - | - | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1124 | 2 | 1 | Opponent | - | - | - | 3 | 3 | 0 | 0 | 0 | 0 |
| L1218 | 6 | 1 | Mine | no | 4 | 4 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1218 | 6 | 1 | Opponent | no | 6 | - | 2 | 1 | 0 | 0 | 0 | 234 |
| L1234 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1234 | 4 | 1 | Opponent | no | 0 | 5 | 6 | 3 | 0 | 0 | 0 | 198 |
| L1329 | 3 | 1 | Mine | no | 12 | 2 | 0 | 1 | 0 | 0 | 0 | 140 |
| L1329 | 3 | 1 | Opponent | no | 12 | 2 | 2 | 2 | 1 | 0 | 0 | 170 |
| L1424 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 143 |
| L1424 | 2 | 1 | Opponent | - | - | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1521 | 3 | 1 | Mine | no | 5 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1521 | 3 | 1 | Opponent | no | 4 | - | 2 | 1 | 1 | 0 | 0 | 577 |
| L1618 | 4 | 1 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1618 | 4 | 1 | Opponent | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 185 |
| L1635 | 3 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1635 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 667 |
| L1833 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 2 | 0 | 0 | 77 |
| L1833 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 4 | 0 | 0 | 0 | 236 |
| L1934 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1934 | 2 | 1 | Opponent | - | - | 2 | 3 | 5 | 0 | 0 | 0 | 389 |
| L2035 | 1 | 1 | Mine | no | 0 | - | 2 | 4 | 1 | 0 | 0 | 210 |
| L2035 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 5 | 0 | 0 | 0 | 477 |
| L2225 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2225 | 5 | 1 | Opponent | yes | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L2329 | 1 | 1 | Mine | no | 5 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2329 | 1 | 1 | Opponent | no | 4 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L2435 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L2435 | 5 | 1 | Opponent | yes | - | - | 0 | 6 | 0 | 0 | 0 | 375 |
| L2632 | 4 | 1 | Mine | no | 6 | 3 | 3 | 3 | 1 | 0 | 0 | 329 |
| L2632 | 4 | 1 | Opponent | no | 4 | 2 | 6 | 4 | 0 | 0 | 0 | 472 |
| L2834 | 2 | 1 | Mine | - | - | - | 0 | 0 | 1 | 0 | 0 | 0 |
| L2834 | 2 | 1 | Opponent | - | - | 2 | 6 | 6 | 0 | 0 | 0 | 515 |
| L3135 | 3 | 1 | Mine | no | 3 | 4 | 1 | 0 | 1 | 0 | 0 | 340 |
| L3135 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 7% | 3.2 | 2.7 | 1.5 | 1.4 | 0.3 | 0.0 | 0.0 | 173.1 |
| **Average** | | | Opponent | 15% | 3.3 | 2.5 | 3.1 | 2.5 | 0.2 | 0.0 | 0.0 | 176.2 |

### KPIs: base-s1-882d875-p7

Morten 2026-11-10; 34 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (36 of 158) | 1% (1 of 173) | 11% (37 of 331) |
| Winner chose to follow up after the loser gave ground |  | 78% (38 of 49); on the table 80% | 100% (47 of 47); on the table 100% | 89% (85 of 96); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | 62% (5 of 8); on the table 62% | 83% (5 of 6); on the table 83% | 71% (10 of 14); on the table 71% |
| Winner chose to pursue after the loser fled |  | 65% (17 of 26); on the table 69% | 56% (9 of 16); on the table 62% | 62% (26 of 42); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 72% (60 of 83); on the table 75% | 88% (61 of 69); on the table 90% | 80% (121 of 152); on the table 82% |
| Magic missiles tried each own turn | 50%+ | 33% (112 of 342) | 33% (52 of 156) | 33% (164 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (112 of 263) | 46% (52 of 114) | 44% (164 of 377) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 45% (10 of 22) | 54% (27 of 50) | 51% (37 of 72) |
| Points that never fought | lower | 48% (32186 of 67555) | 47% (32017 of 67979) | 47% (64203 of 135534) |
|   infantry points that never fought | lower | 62% (8883 of 14255) | 70% (9111 of 12956) | 66% (17994 of 27211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (164 of 265) | 61% (171 of 279) | 62% (335 of 544) |
| Bound items with a magic missile used (at least once a game) |  | 96% (22 of 23); 1.8 uses a game | 73% (19 of 26); 1.7 uses a game | 84% (41 of 49); 1.7 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.4 uses a game | 0% (0 of 2); 0.0 uses a game | 44% (7 of 16); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 22% (2 of 9); 0.1 uses a game | 45% (13 of 29); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (33418 of 57831) | 53% (33300 of 62518) | 55% (66718 of 120349) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.6 (38%) | 0.8 (26%) | 3.4 (34%) |
| MARCHED: its unit marched | 1.3 (19%) | 0.6 (21%) | 1.9 (20%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.4 (20%) | 0.6 (21%) | 2.0 (21%) |
| REAR RANK: in a rear rank | 0.3 (4%) | 0.1 (5%) | 0.4 (4%) |
| FLEEING: fleeing | 0.1 (2%) | 0.2 (7%) | 0.4 (4%) |
| GONE: slain | 0.6 (9%) | 0.3 (9%) | 0.9 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (4%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (6%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 2.1 | 2.2 | 4.8 | 1.0 | 2.0 |
| not cast | 3.1 | 4.6 | 2.8 | 9.8 | 1.6 | 21.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.6 (55%) | 0.1 (3%) | 3.4 (34%) | 0.3 (16%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (20%) | 0.4 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.3 (6%) | 0.3 (11%) | 2.0 (21%) | 0.4 (23%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (11%) | 0.4 (9%) | 0.3 (10%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (6%) | 0.0 (1%) | 0.4 (4%) | 0.0 (0%) | 0.5 (2%) |
| GONE: slain | 0.5 (16%) | 0.2 (5%) | 0.5 (17%) | 0.9 (9%) | 0.0 (2%) | 2.5 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.1 (3%) | 0.2 (6%) | 0.3 (3%) | 0.1 (4%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.4 (27%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (58%) | 0.4 (9%) | 1.4 (52%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.6 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 1.2 a game | 1.2 a game |
| stood (cast and not dispelled) | 68% (23 of 34) | 74% (23 of 31) | 71% (46 of 65) |
| the unit moved after it | 61% (14 of 23) | 43% (10 of 23) | 52% (24 of 46) |
| it charged on its next turn | 0% (0 of 23) | 0% (0 of 23) | 0% (0 of 46) |
| the enemy charged it first | 13% (3 of 23) | 4% (1 of 23) | 9% (4 of 46) |
| it fought by the end of its next turn | 0% (0 of 23) | 4% (1 of 23) | 2% (1 of 46) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 23) | 0% (0 of 23) | 0% (0 of 46) |
| none of these (no charge, no fight, no charge escaped) | 87% (20 of 23) | 96% (22 of 23) | 91% (42 of 46) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (480 of 759) | 52% (349 of 667) | 58% (829 of 1426) |
|   cavalry | 68% (46 of 68) | 65% (111 of 170) | 66% (157 of 238) |
|   character | 51% (53 of 104) | 29% (45 of 153) | 38% (98 of 257) |
|   chariot | 58% (54 of 93) | 67% (34 of 51) | 61% (88 of 144) |
|   infantry | 62% (134 of 216) | 53% (127 of 238) | 57% (261 of 454) |
|   monster | 84% (16 of 19) | 55% (12 of 22) | 68% (28 of 41) |
|   war machine | 68% (177 of 259) | 61% (20 of 33) | 67% (197 of 292) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.4 (16%) | 1.8 (19%) | 3.2 (18%) |
| CHARGED: it charged | 0.6 (7%) | 1.9 (20%) | 2.5 (14%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.2 (3%) | 1.1 (6%) |
| MOVED: a war machine that moved | 1.7 (21%) | 0.3 (3%) | 2.0 (11%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.1 (26%) | 2.4 (25%) | 4.5 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (1%) | 0.5 (5%) | 0.6 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (14%) | 1.7 (18%) | 2.8 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.2 (3%) | 0.3 (3%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.7 | 1.2 | 85% | 3.6 pts | 24 pts |
| character | 3.3 | 1.3 | 71% | 7.9 pts | 26 pts |
| chariot | 2.6 | 1.3 | 70% | 14.5 pts | 38 pts |
| infantry | 10.8 | 2.8 | 80% | 7.7 pts | 83 pts |
| monster | 0.9 | 0.2 | 88% | 2.5 pts | 2 pts |
| war machine | 5.8 | 4.6 | 63% | 26.7 pts | 155 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 4.5 | 3.7 |
| Charges that made contact a game | 2.1 | 3.4 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.65 declared, 0.54 contact (26 units) | 0.85 declared, 0.77 contact (13 units) | 0.72 declared, 0.62 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.33 declared, 0.33 contact (3 units) | 1.10 declared, 0.90 contact (10 units) | 1.15 declared, 0.77 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.25 contact (228 units) | 0.46 declared, 0.33 contact (290 units) | 0.40 declared, 0.30 contact (518 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (44 of 79) | 65% (11 of 17) | 42% (5 of 12) | 56% (60 of 108) |
| Character in a unit | 90% (28 of 31) | 78% (18 of 23) | 40% (2 of 5) | 81% (48 of 59) |
| Character on its own | 91% (20 of 22) | 50% (21 of 42) | 29% (19 of 65) | 47% (60 of 129) |
| Chariot | 76% (13 of 17) | 90% (9 of 10) | - | 81% (22 of 27) |
| Infantry | 54% (43 of 79) | 63% (24 of 38) | 100% (2 of 2) | 58% (69 of 119) |
| Monster | 67% (14 of 21) | 71% (5 of 7) | - | 68% (19 of 28) |
| Monstrous | 95% (20 of 21) | 58% (7 of 12) | - | 82% (27 of 33) |
| War Machines | 72% (28 of 39) | 100% (2 of 2) | - | 73% (30 of 41) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 67% (2 of 3); on the table 67% | 36% (37 of 102) | 63% | 64% (14 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 1.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 75% (6 of 8); on the table 88% | 53% (16 of 30) | 44% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 29% (2 of 7); on the table 29% | - | 70% | 79% (19 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 4 | 67% (2 of 3); on the table 67% | 75% (9 of 12) | 74% | 64% (27 of 42) | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game | 33% (1 of 3); 0.2 uses a game |
| Grand Cathay | 8 | 88% (23 of 26); on the table 92% | 29% (52 of 180) | 45% | 53% (38 of 72) | 100% (20 of 20); 7.1 uses a game | 50% (1 of 2); 0.1 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 6 | 76% (13 of 17); on the table 82% | 33% (8 of 24) | 38% | 43% (20 of 46) | 88% (7 of 8); 3.5 uses a game | 20% (2 of 10); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 62% (8 of 13); on the table 62% | - | 54% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Ogre Kingdoms | 4 | 100% (6 of 6); on the table 100% | 4% (1 of 24) | 66% | 75% (21 of 28) | 100% (4 of 4); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 12) | 16% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 100% (3 of 3); on the table 100% | 25% (3 of 12) | 42% | 56% (9 of 16) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 3 | 92% (11 of 12); on the table 92% | - | 18% | 33% (5 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 7 | 83% (10 of 12); on the table 83% | 44% (21 of 48) | 47% | 80% (36 of 45) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 75% (12 of 16); on the table 75% | 33% (8 of 24) | 30% | 55% (43 of 78) | 100% (1 of 1); 0.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 10 | 88% (23 of 26); on the table 88% | 30% (9 of 30) | 55% | 70% (73 of 104) | 44% (4 of 9); 1.7 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s1-882d875-p7, 34 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (42) | 54% (25) | 54% (67) |
| ...free all their last turn and able to turn (per game) | 0.85 | 0.62 | 1.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.26 | 0.09 | 0.35 |
| ...with the charger already in that arc before they moved (per game) | 0.59 | 0.38 | 0.97 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.09 | 0.00 | 0.09 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.21 | 0.21 | 0.41 |

### Quality by phase: base-s1-882d875-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.4 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 58% (47 of 81) | 55% (72 of 130) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (146 of 386) | 47% (73 of 154) |
| Strategy | Support requests answered (helper made contact too) | 40% (4 of 10) | 17% (1 of 6) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 42% (8 of 19) | 38% (6 of 16) |
| Strategy | Joined characters whose unit fought | 26% (14 of 53) | 36% (9 of 25) |
| Strategy | Lone characters that fought | 67% (56 of 83) | 72% (53 of 74) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.4 | 2.5 |
| Movement | Points that never moved of their own | 173.1 | 176.2 |
| Movement | Fights charged into per game | 1.9 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 51, net +131 | 22 of 89, net +58 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 51, net +140 | 12 of 89, net +143 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 51, net +84 | 14 of 89, net +100 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 of 51, net +179 | 19 of 89, net +133 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.5 | 10.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (160 of 324) | 42% (150 of 360) |
| Shooting | Points destroyed by shooting units | 60.2 | 35.8 |
| Shooting | War machine shots | 5.2 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (101 of 177) | 75% (15 of 20) |
| Shooting | Points destroyed by war machines | 65.1 | 3.4 |
| Magic | Magic missiles cast | 1.9 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (24 of 64) | 28% (11 of 40) |
| Magic | Wounds caused by magic missiles | 3.1 | 1.2 |
| Magic | Wounds caused by other spells | 1.1 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 49.0 | 24.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.6 / 0.6 / 0.2 | 2.0 / 0.6 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 209.6 | 374.8 |
| Combat | Points run down | 44.8 | 49.7 |
| Combat | Net points per charged fight, damage counted | +102 | +101 |
| Combat | Net per 100 charger points, damage counted | +33.3 | +32.6 |
| Combat | First round won (charged fights) | 77% | 68% |
| Combat | Net points per charged fight | +104 | +104 |
| Combat | Net points per supported fight / lone fight | +115 / +103 | +109 / +104 |
| Combat | Charged fights on a top-3 enemy unit | 18 of 66 | 42 of 110 |
| Game | Points lost | 581.1 | 523.2 |
| Game | VP from objectives | 554.4 | 702.6 |
| Game | Lone holders (player turns) | 3.2 | 3.3 |

- Mine won / drew / lost: 10 / 10 / 14 of 34 ended games (of 34); mean margin (Mine - Opponent) -215 VP
- The side that went first won 9 of 24 games with a winner
- Points traded per game (both sides' losses): 1104
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: base-s1-882d875-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.4 | +36.2 | 0.0 | 1.8 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 15.3 | +229.9 | 0.0 | 141.3 | 21.5 | +460.4 | 0.0 | 223.8 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +3.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 32.8 | 0.1 | +0.0 | 0.0 | 4.9 |
| BACKUP TARGETS | 0.1 | +0.6 | 0.0 | 0.0 | 0.1 | +1.5 | 0.0 | 0.0 |
| BEST OVERALL | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.1 | -1.7 | 15.5 | 0.0 | 0.1 | -1.2 | 5.1 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -1.3 | 20.5 | 1.5 | 0.3 | -71.2 | 5.0 | 6.4 |
| BOMBING RUN | 0.1 | +1.4 | 1.8 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.2 | +0.0 | 27.1 | 2.8 | - | - | - | - |
| CANNON PLANNED TARGET | 5.1 | +97.6 | 251.0 | 92.9 | 0.6 | +14.0 | 18.3 | 9.7 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.6 | +37.8 | 75.3 | 5.0 | 0.6 | +3.5 | 10.0 | 11.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +43.2 | 18.5 | 0.0 | 0.4 | +7.9 | 7.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 25.9 | 0.7 | +0.0 | 0.0 | 13.8 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.5 | +33.3 | 0.0 | 20.9 | 1.5 | +55.1 | 0.0 | 19.3 |
| CHAFF PASSED | 0.3 | -0.1 | 0.0 | 0.0 | 0.2 | -0.4 | 9.3 | 11.8 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -0.4 | 0.0 | 14.2 | 0.1 | -2.3 | 6.0 | 0.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.1 | +5.6 | 4.3 | 14.2 | - | - | - | - |
| CHARGE LOSSES | 10.7 | -479.7 | 0.0 | 285.0 | 11.0 | -626.0 | 0.0 | 416.8 |
| CHARGE NOT DECLARED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 19.3 | 2.0 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 175.8 | 48.9 | 2.4 | +0.0 | 239.7 | 47.5 |
| CHARGER SLAIN LOST | 0.1 | -4.7 | 13.4 | 4.0 | 0.3 | -3.6 | 37.4 | 3.8 |
| COMBAT PIVOT | 0.5 | +0.0 | 8.6 | 72.6 | 0.3 | +0.0 | 12.2 | 28.8 |
| CONVEYANCE SEARCH | 0.9 | +152.4 | 11.8 | 35.1 | 0.9 | +84.8 | 43.6 | 43.6 |
| COVER ONCE | 5.7 | -408.9 | 0.0 | 70.7 | 4.4 | -304.1 | 0.0 | 99.4 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.0 | 7.6 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.4 | -3.4 | 38.9 | 14.2 | 0.7 | -3.7 | 51.8 | 7.4 |
| DEPLOY BY FIGURES | 7.6 | +23.6 | 0.0 | 2.4 | 8.0 | +45.0 | 0.0 | 26.0 |
| EDGE GIVE GROUND | 0.1 | +4.1 | 21.4 | 0.0 | 0.4 | +27.1 | 63.5 | 1.8 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.2 | +16.2 | 214.1 | 52.9 | 3.1 | +5.6 | 291.1 | 42.9 |
| FALLBACK BY WORTH | 0.2 | +2.8 | 0.0 | 2.5 | 0.2 | +2.8 | 0.0 | 4.1 |
| FALLS SHORT | 5.4 | +82.1 | 0.0 | 69.3 | 14.6 | +219.9 | 0.0 | 241.7 |
| FEATURE BUFFS | 2.8 | +78.7 | 0.0 | 44.8 | 1.1 | +36.5 | 0.0 | 6.5 |
| FIGHT LIFT | 0.1 | +1.5 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.6 | +7.7 | 55.7 | 6.0 | 0.9 | +40.3 | 51.1 | 16.1 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.0 | 0.0 | 2.5 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 5.4 | 0.2 | +0.0 | 3.1 | 0.0 |
| FIVE ACTION | 86.9 | +5016.2 | 1184.0 | 965.8 | 87.4 | +5846.5 | 646.9 | 1103.3 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 107.9 | 4.6 | +0.0 | 0.0 | 108.6 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.3 | 1.9 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +148.8 | 0.0 | 31.9 | 1.1 | +186.9 | 0.0 | 10.9 |
| FOUR ROUNDS | 2.7 | +191.4 | 252.6 | 52.9 | 4.2 | +391.7 | 410.4 | 66.5 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -2.3 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -14.5 | 13.8 | 0.0 | 0.4 | -9.1 | 3.3 | 2.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +4.7 | 0.0 | 32.4 | 0.1 | +8.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -3.8 | 13.7 | 0.0 | 0.2 | -3.1 | 22.8 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| GUN FIGURES | 0.9 | +1.5 | 15.3 | 7.4 | 0.3 | +7.7 | 1.9 | 5.4 |
| GUN MASK | 1.1 | +18.7 | 0.0 | 4.7 | 0.3 | +6.7 | 0.0 | 8.6 |
| HARD STAY DROPPED | 2.4 | +0.0 | 0.0 | 4.5 | 1.8 | +0.0 | 0.0 | 16.2 |
| HE SHOOTS OR CHARGES | 4.1 | +0.0 | 0.0 | 136.8 | 3.1 | +0.0 | 0.0 | 100.1 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 16.3 | 2.0 |
| HIS CHARGE DENIED | 0.2 | +10.5 | 28.2 | 0.0 | 0.4 | +24.0 | 40.4 | 3.5 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 25.3 | 5.3 | +0.0 | 0.0 | 79.7 |
| HIS FIGHT TOGETHER | 2.3 | -22.0 | 0.0 | 64.3 | 1.4 | -20.1 | 0.0 | 45.3 |
| HIS LEGAL MOVES | 3.8 | +0.0 | 0.0 | 68.6 | 4.1 | +0.0 | 0.0 | 70.5 |
| HIS MOVE AND SHOT | 3.9 | -61.0 | 0.0 | 88.2 | 3.3 | -72.4 | 0.0 | 68.5 |
| HIS MOVE AS HE DECIDES | 40.3 | +14.9 | 505.2 | 0.0 | 34.1 | +12.5 | 460.4 | 0.0 |
| HIS MOVE WHY | 33.8 | +0.0 | 0.0 | 329.3 | 40.1 | +0.0 | 0.0 | 419.0 |
| HIS ONE MOVE | 16.4 | +45.5 | 0.0 | 152.8 | 19.7 | +40.5 | 7.6 | 101.8 |
| HIS ONE QUARTER | 3.9 | +0.0 | 0.0 | 39.4 | 3.8 | +0.0 | 0.0 | 39.1 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 3.3 | 1.8 | +0.0 | 0.0 | 32.1 |
| HIS RANDOM MOVE | 4.4 | +0.0 | 0.0 | 45.9 | 2.3 | +0.0 | 0.0 | 9.8 |
| HIS SHOT LIST | 37.5 | +1047.9 | 0.0 | 436.7 | 43.7 | +2106.1 | 0.0 | 699.8 |
| HIS TURN DENIED | 0.9 | +20.7 | 110.7 | 7.8 | 2.1 | +61.6 | 188.1 | 35.7 |
| HOLD ODDS | 17.6 | +0.0 | 0.0 | 194.2 | 15.8 | +0.0 | 0.0 | 134.5 |
| HOLDER ASSIGNMENT | 9.6 | +907.8 | 0.0 | 84.4 | 10.0 | +986.2 | 0.0 | 72.5 |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.5 | -93.8 | 233.1 | 48.9 | 3.7 | -172.5 | 353.1 | 51.6 |
| HUNT IN PAIRS | 0.4 | +8.1 | 0.0 | 14.7 | 0.3 | +9.9 | 0.0 | 13.7 |
| HUNT RESULT | - | - | - | - | 0.1 | +26.8 | 4.9 | 1.8 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +44.2 | 9.7 | 3.5 |
| IDLE COST | 3.7 | -65.5 | 0.0 | 44.7 | 9.7 | -159.1 | 0.0 | 213.7 |
| JOINT CHARGE NOW | 0.6 | +7.1 | 48.6 | 0.0 | 0.5 | -9.0 | 52.3 | 1.2 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.9 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| JOINT ON THE TABLE | 0.0 | +5.1 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +2.6 | 0.0 | 5.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.8 | +0.0 | 0.0 | 21.4 | 2.5 | +0.0 | 0.0 | 25.6 |
| LANE BY FIGURES | 0.8 | +30.2 | 0.0 | 0.0 | 1.0 | +46.1 | 0.0 | 13.7 |
| LATE ONLY FROM HERE | 0.2 | +0.0 | 0.0 | 5.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.8 | +0.0 | 195.6 | 521.3 | 5.3 | +0.0 | 217.2 | 137.4 |
| LONE WIZARD KEPT IN | 0.6 | +38.3 | 0.0 | 0.0 | 0.1 | +12.3 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +2.2 | 10.1 | 0.0 | 0.4 | -0.8 | 31.4 | 2.8 |
| LOST AFTER ESCAPE | 1.4 | +0.7 | 152.7 | 47.1 | 2.3 | +4.4 | 252.6 | 55.4 |
| LOST CHARGE | 0.1 | -0.3 | 17.9 | 0.0 | 0.0 | -0.0 | 5.4 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -4.7 | 0.0 | 0.0 | 0.0 | -7.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +0.3 | 0.0 | 10.5 | 0.2 | +0.7 | 0.0 | 6.7 |
| MANOEUVRE | 1.0 | +1.7 | 0.0 | 11.6 | 0.6 | -1.5 | 0.0 | 3.3 |
| MARCH AT ESCAPER | 0.2 | +1.6 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.6 | +26.8 | 0.0 | 4.9 | 0.4 | +15.3 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +49.4 | 0.0 | 14.1 | 0.6 | +28.5 | 0.0 | 8.7 |
| MARCH OF THE TABLE | 0.2 | +3.3 | 0.0 | 0.0 | 0.2 | +1.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.1 | +23.2 | 0.0 | 4.9 | 0.8 | +26.1 | 0.0 | 11.9 |
| MARCH WHEELS ONLY | 0.6 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.8 | +82.7 | 0.0 | 72.1 | 3.1 | +64.4 | 0.0 | 42.4 |
| MISSILES IN THE MOVE | 4.9 | +156.7 | 0.0 | 65.8 | 3.5 | +53.0 | 0.0 | 77.9 |
| MISSILES NEXT TURN | 6.3 | +117.9 | 0.0 | 82.4 | 4.6 | +48.0 | 0.0 | 103.2 |
| MISSILES ON ONE TARGET | 0.4 | -19.6 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | 0.2 | +47.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.6 | +0.0 | 26.6 | 19.7 | 1.9 | +0.0 | 20.8 | 37.9 |
| MOVE SPELL IN RANGE | 0.1 | +1.6 | 0.0 | 2.5 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -33.1 | 2.4 | 20.9 | 0.3 | -8.1 | 0.0 | 11.9 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 11.8 | 0.4 | +0.0 | 0.0 | 13.8 |
| MOVE TO CHARGE COMPUTED | 5.2 | +405.2 | 0.0 | 42.6 | 7.4 | +814.0 | 0.0 | 79.6 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.4 | +263.8 | 0.0 | 43.9 | 5.9 | +247.7 | 0.0 | 43.1 |
| NEXT CHARGE BY LIST | 4.9 | -178.8 | 26.9 | 19.8 | 7.6 | -370.3 | 24.2 | 29.6 |
| NEXT OBJECTIVE NEARER | 0.1 | -0.5 | 0.0 | 0.0 | 0.1 | -4.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.4 | -92.9 | 213.2 | 40.2 | 3.0 | -161.2 | 276.6 | 52.5 |
| NO LATE CUT | 0.6 | +0.0 | 0.0 | 11.3 | 1.0 | +0.0 | 0.0 | 4.5 |
| NO RALLY LEFT | 0.0 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.2 | -0.7 | 0.0 | 6.1 | 0.2 | +0.3 | 0.0 | 10.1 |
| NOT WORTH A CAST | 0.6 | -0.5 | 0.0 | 21.6 | 0.5 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -102.7 | 0.0 | 24.5 | 4.6 | -152.8 | 25.4 | 42.6 |
| ONE CHARGE A CHARGER | 5.1 | +0.0 | 0.0 | 145.2 | 4.4 | +0.0 | 0.0 | 126.2 |
| ONE FIGHT FORMULA | 4.7 | -84.6 | 0.0 | 38.6 | 5.5 | -121.3 | 0.0 | 82.9 |
| ONE OBJECTIVE FORMULA | 4.4 | -12.0 | 0.0 | 57.3 | 3.9 | -36.9 | 0.0 | 39.6 |
| ONE PROMISE A TARGET | 0.1 | -4.2 | 0.0 | 0.0 | 0.2 | -3.0 | 0.0 | 0.0 |
| ONE ROUTE | 0.6 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 28.5 | +517.0 | 0.0 | 379.4 | 30.7 | +746.9 | 0.0 | 464.5 |
| OPENS A LANE | 0.2 | +0.7 | 17.1 | 0.0 | 0.1 | +0.1 | 2.4 | 0.0 |
| OPENS UP | 0.3 | +16.4 | 19.2 | 12.8 | 0.4 | +22.4 | 26.4 | 0.0 |
| OVERRUNS AWAY | 0.3 | +7.6 | 36.6 | 14.2 | 0.6 | +31.1 | 49.0 | 1.8 |
| OWN CAST FIRST | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.4 | +16.2 | 0.0 | 0.0 | 0.3 | +12.3 | 0.0 | 10.5 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.0 | -0.6 | 0.0 | 1.8 | 0.1 | -3.7 | 0.0 | 0.0 |
| PLAN RESULT | 40.3 | +790.7 | 424.9 | 809.9 | 41.7 | +468.4 | 258.1 | 690.4 |
| PROMISE BELOW ZERO | 0.2 | +0.0 | 0.0 | 1.8 | 0.4 | +0.0 | 0.0 | 2.0 |
| PROMISE BY ITS OWN SUM | 8.2 | -238.6 | 0.0 | 24.9 | 9.5 | -262.3 | 0.0 | 86.4 |
| PROMISE HOLDS THE SPOT | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | -0.2 | 0.0 | 13.2 |
| PROMISE READS THE TABLE | 0.4 | -12.2 | 0.0 | 0.0 | 0.3 | -2.0 | 0.0 | 1.0 |
| PROMISE SHOT AWAY | 0.1 | -0.8 | 2.0 | 0.0 | 0.2 | -1.6 | 27.0 | 0.0 |
| PURSUES BIG PREY | 0.0 | -0.2 | 0.0 | 0.0 | 0.0 | -4.2 | 0.0 | 0.0 |
| QUARTER ODDS | 15.0 | +1483.1 | 171.2 | 222.4 | 16.4 | +1979.9 | 113.1 | 114.8 |
| RANDOM MOVE BY FIGURES | 0.6 | +8.7 | 0.0 | 43.5 | 1.5 | +16.1 | 0.0 | 59.0 |
| REAL GROUND | 0.6 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.5 | +7.3 | 0.0 | 24.7 | 1.7 | -44.4 | 0.0 | 19.2 |
| REDIRECT COUNTER | 2.1 | +157.7 | 0.0 | 40.4 | 2.9 | +158.1 | 0.0 | 39.1 |
| REDIRECT WEIGHED | 0.3 | +2.1 | 14.8 | 0.0 | 0.2 | +6.1 | 17.6 | 0.0 |
| REFORMS TO MEET IT | 1.1 | -31.5 | 0.0 | 12.5 | 1.2 | -105.6 | 0.0 | 2.8 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 30.9 | 0.3 | +0.0 | 0.0 | 25.1 |
| RESERVE FALL BACK | 0.5 | +34.5 | 0.0 | 18.1 | 0.5 | +29.7 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +70.3 | 187.6 | 52.9 | 3.0 | +0.7 | 272.5 | 55.6 |
| RISK BY HIS FIGURE | 21.7 | -371.1 | 0.0 | 471.9 | 20.3 | -370.9 | 0.0 | 453.9 |
| RISK ON THE WAY | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.6 | -15.1 | 79.4 | 0.0 | 1.3 | -39.5 | 152.5 | 24.0 |
| RUN DOWN | 2.1 | -17.1 | 181.4 | 20.2 | 2.9 | -55.3 | 295.0 | 43.4 |
| SAFER THAN THE JOB | 0.1 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -0.4 | 1.2 | 0.0 |
| SCOUT SPOT | 0.4 | +1.2 | 0.0 | 0.0 | 0.2 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.4 | -3.8 | 0.0 | 2.4 | 0.5 | -30.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.3 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +23.2 | 10.6 | 0.0 | 0.3 | +12.5 | 33.2 | 0.0 |
| SELF MOVE SPELL | 0.3 | +11.2 | 0.0 | 32.8 | 0.4 | +48.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.8 | +32.1 | 11.6 | 11.8 | 2.9 | +54.7 | 17.1 | 6.1 |
| SET UP TOGETHER | 0.1 | +1.3 | 0.0 | 22.3 | 0.2 | +1.8 | 0.0 | 6.7 |
| SET-UP ANY TARGET | 0.2 | +37.2 | 11.8 | 14.3 | 0.1 | +15.0 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.1 | +12.3 | 5.3 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.6 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.4 | +162.5 | 105.7 | 0.0 | 2.3 | +64.2 | 19.4 | 10.3 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.2 | -2.6 | 23.4 | 2.5 | 0.1 | -1.7 | 14.6 | 3.1 |
| SHOT RISK POINTS | 16.1 | +48.4 | 0.0 | 266.5 | 20.6 | -124.1 | 0.0 | 466.7 |
| SHOTS AFTER THE MOVES | 3.4 | +0.0 | 0.0 | 0.0 | 2.2 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.9 | +506.0 | 0.0 | 199.9 | 10.8 | +288.7 | 0.0 | 127.5 |
| SPELL OFF EDGE | 0.0 | +3.1 | 4.9 | 10.4 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +64.7 | 11.8 | 14.3 | 0.1 | +15.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +34.8 | 69.0 | 66.7 | 2.5 | +41.7 | 51.2 | 51.2 |
| SPELLS IN THE FIGHT | 0.5 | +5.1 | 46.2 | 26.9 | 0.6 | -8.6 | 126.0 | 1.3 |
| SPOT AS THE GAME MOVES | 6.8 | +0.0 | 0.0 | 110.9 | 9.7 | +0.0 | 0.0 | 187.1 |
| STAND AND SHOOT | 0.4 | -4.4 | 32.1 | 15.9 | 0.5 | -6.8 | 39.6 | 7.0 |
| STANDS FOR A REASON | 0.6 | +0.0 | 0.0 | 41.2 | 1.3 | +0.0 | 3.1 | 75.9 |
| STANDS STILL | 43.6 | +0.0 | 931.4 | 368.8 | 31.4 | +0.0 | 236.4 | 247.9 |
| STAY WORTH | 23.8 | -26.0 | 646.7 | 222.4 | 13.0 | +83.8 | 188.7 | 186.1 |
| STOPS | - | - | - | - | 0.1 | +4.6 | 9.7 | 3.5 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 6.2 | 0.2 | +0.0 | 0.0 | 4.3 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.6 | +742.5 | 0.0 | 79.7 | 10.1 | +709.6 | 0.0 | 64.9 |
| SUPPORT NARROWED | 0.6 | +0.0 | 26.5 | 0.0 | 0.2 | +0.0 | 20.4 | 9.4 |
| SUPPORT WORKED OUT | 8.6 | +742.5 | 0.0 | 79.7 | 10.1 | +709.6 | 0.0 | 64.9 |
| SURE REACH TOGETHER | 0.5 | +3.7 | 0.0 | 3.4 | 0.2 | +2.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 8.3 | 1.1 | +0.0 | 0.0 | 19.6 |
| THE PROMISE ADDS | 0.1 | -6.7 | 0.0 | 1.3 | 0.1 | -14.2 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 29.0 | +0.0 | 0.0 | 289.5 | 35.6 | +0.0 | 0.0 | 427.6 |
| TIED UP BY THE SUM | 0.9 | +104.2 | 87.3 | 14.2 | 0.9 | +110.3 | 81.5 | 4.0 |
| TIME ON OUR SIDE | 33.3 | +393.4 | 49.8 | 178.1 | 22.0 | +163.0 | 21.2 | 124.2 |
| TWO OR MORE ARRIVE | 0.0 | +0.0 | 0.0 | 11.8 | - | - | - | - |
| WAITS AGAIN | 2.1 | +0.0 | 0.0 | 11.4 | 2.0 | +0.0 | 0.0 | 28.1 |
| WALKS ON ITS ROUTE | 0.0 | -1.2 | 0.0 | 0.0 | 0.0 | -0.4 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 8.0 | 0.0 | 0.3 | +0.0 | 7.6 | 0.0 |
| WHAT THE JOINER ADDS | 0.1 | +3.0 | 4.0 | 0.0 | 0.6 | -35.3 | 128.8 | 2.6 |
| WHO GETS IN | 0.1 | +9.9 | 9.9 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.2 | +16.2 | 0.0 | 2.4 | 0.4 | +42.4 | 0.0 | 18.6 |
| WHOLE FIGHT | 0.1 | +1.8 | 4.0 | 0.0 | 0.3 | +15.9 | 64.4 | 1.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.1 | +3.9 | 16.3 | 0.0 |
| WIDER SPREAD | 1.8 | -2.4 | 140.6 | 38.8 | 2.8 | -10.0 | 308.3 | 23.1 |
| WOUNDS ON THE RANKS | 1.8 | +53.3 | 0.0 | 71.7 | 1.5 | +95.1 | 0.0 | 48.2 |

### Rule changes: base-s1-882d875-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2530 | 2530 | 1599 | 47.03 | +0 | +0.0 |
| HIS MOVE WHY | 2515 | 2515 | 1407 | 41.38 | +0 | +0.0 |
| ARMY TABLE | 1249 | 1249 | 847 | 24.91 | +19760 | +23.3 |
| HIS SHOT LIST | 2761 | 2619 | 737 | 21.68 | +12752 | +17.3 |
| HOLDER ASSIGNMENT | 669 | 669 | 621 | 18.26 | +40058 | +64.5 |
| LEGAL CHARGES ONLY | 412 | 412 | 412 | 12.12 | +0 | +0.0 |
| ONE TARGET A SHOOTER | 2013 | 1924 | 379 | 11.15 | +4535 | +12.0 |
| TIME ON OUR SIDE | 1880 | 1690 | 323 | 9.50 | +1079 | +3.3 |
| DEPLOY BY FIGURES | 531 | 531 | 321 | 9.44 | +4867 | +15.2 |
| THE TABLE AGAIN | 407 | 407 | 274 | 8.06 | +0 | +0.0 |
| OFF BEST | 261 | 261 | 261 | 7.68 | -8685 | -33.3 |
| HIS ONE MOVE | 1228 | 1179 | 255 | 7.50 | +0 | +0.0 |
| FIVE ACTION | 5928 | 5692 | 242 | 7.12 | +14277 | +59.0 |
| PROMISE BY ITS OWN SUM | 603 | 603 | 227 | 6.68 | -17031 | -75.0 |
| SUPPORT ADDS | 636 | 606 | 226 | 6.65 | +10920 | +48.3 |
| SUPPORT WORKED OUT | 636 | 606 | 226 | 6.65 | +10920 | +48.3 |
| MOVE TO CHARGE COMPUTED | 429 | 356 | 208 | 6.12 | +12491 | +60.1 |
| SHOT RISK POINTS | 1247 | 1196 | 157 | 4.62 | +4746 | +30.2 |
| QUARTER ODDS | 1068 | 1023 | 152 | 4.47 | +12898 | +84.9 |
| HARD STAY DROPPED | 142 | 142 | 142 | 4.18 | +0 | +0.0 |
| MOVE ORDER | 120 | 120 | 120 | 3.53 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 194 | 194 | 116 | 3.41 | +1935 | +16.7 |
| FOUR ROUNDS | 235 | 223 | 111 | 3.26 | +4768 | +43.0 |
| ADVANCE LANE KEPT | 68 | 68 | 68 | 2.00 | +0 | +0.0 |
| SET UP BY THE SET | 157 | 151 | 66 | 1.94 | +3670 | +55.6 |
| IDLE COST | 456 | 353 | 65 | 1.91 | +684 | +10.5 |
| FOLLOW UP WEIGHED | 63 | 63 | 63 | 1.85 | +11414 | +181.2 |
| STAY WORTH | 1251 | 1125 | 62 | 1.82 | +942 | +15.2 |
| CHAFF IN THE MOVE | 70 | 67 | 60 | 1.76 | +176 | +2.9 |
| LANE BY FIGURES | 60 | 60 | 60 | 1.76 | +2593 | +43.2 |
| CHARGE LOSSES | 740 | 694 | 58 | 1.71 | +6590 | +113.6 |
| CAST JOB | 75 | 75 | 53 | 1.56 | +150 | +2.8 |
| RISK BY HIS FIGURE | 1428 | 1349 | 51 | 1.50 | +4180 | +82.0 |
| CHARGE NOW FIRST | 145 | 145 | 49 | 1.44 | -2808 | -57.3 |
| FALLS SHORT | 679 | 585 | 49 | 1.44 | +465 | +9.5 |
| MAX FOR POSITIONING | 235 | 207 | 49 | 1.44 | +271 | +5.5 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.38 | +0 | +0.0 |
| TIED UP BY THE SUM | 60 | 55 | 47 | 1.38 | +1648 | +35.1 |
| RISK BY ARC | 170 | 160 | 43 | 1.26 | +1184 | +27.5 |
| ARTILLERY RE-ROLL WEIGHED | 40 | 40 | 40 | 1.18 | +0 | +0.0 |
| COVER ONCE | 343 | 229 | 39 | 1.15 | +884 | +22.7 |
| MARCH CHECK | 55 | 54 | 38 | 1.12 | +768 | +20.2 |
| RANDOM MOVE BY FIGURES | 72 | 72 | 37 | 1.09 | +845 | +22.8 |
| JOINT CHARGE NOW | 36 | 36 | 36 | 1.06 | -65 | -1.8 |
| RESERVE FALL BACK | 36 | 36 | 36 | 1.06 | +2183 | +60.6 |
| NEXT CHARGE BY LIST | 428 | 392 | 34 | 1.00 | +845 | +24.8 |
| HOLDS AMBUSHERS | 33 | 33 | 33 | 0.97 | +0 | +0.0 |
| MARCH BY THE SUM | 32 | 32 | 32 | 0.94 | +1432 | +44.7 |
| COMBAT PIVOT | 27 | 27 | 27 | 0.79 | +0 | +0.0 |
| MISSILES IN THE MOVE | 285 | 204 | 26 | 0.76 | +441 | +17.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.76 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 24 | 24 | 24 | 0.71 | +1722 | +71.7 |
| PATHS CROSS | 23 | 23 | 23 | 0.68 | +969 | +42.1 |
| HIS TURN DENIED | 103 | 103 | 21 | 0.62 | +535 | +25.5 |
| WOUNDS ON THE RANKS | 112 | 112 | 21 | 0.62 | +1012 | +48.2 |
| NEARER NOT NEEDED | 417 | 399 | 20 | 0.59 | +731 | +36.5 |
| SHOOTERS IN TWO RANKS | 20 | 20 | 20 | 0.59 | +34 | +1.7 |
| SHOTS IN THE MOVE | 875 | 664 | 20 | 0.59 | +658 | +32.9 |
| CASTING BLOCK | 34 | 34 | 19 | 0.56 | +745 | +39.2 |
| SECOND LOOK | 19 | 19 | 19 | 0.56 | +1211 | +63.8 |
| SHOTS AFTER THE MOVES | 189 | 189 | 19 | 0.56 | +0 | +0.0 |
| WHO HITS BACK | 19 | 19 | 19 | 0.56 | +1358 | +71.5 |
| REDIRECT COUNTER | 170 | 141 | 18 | 0.53 | +510 | +28.3 |
| CANNON PLANNED TARGET | 193 | 193 | 17 | 0.50 | -53 | -3.1 |
| SUPPORT NARROWED | 26 | 26 | 17 | 0.50 | -2312 | -136.0 |
| CHAFF PASSED | 15 | 15 | 15 | 0.44 | -18 | -1.2 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.44 | +862 | +57.5 |
| SURE REACH TOGETHER | 25 | 23 | 15 | 0.44 | +72 | +4.8 |
| CASTER AWAY FROM SCREEN | 14 | 14 | 14 | 0.41 | +0 | +0.0 |
| AFTERMATH IN POINTS | 13 | 13 | 13 | 0.38 | +1230 | +94.6 |
| FIRE IN ORDER | 13 | 13 | 13 | 0.38 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.38 | +440 | +33.8 |
| ONE OBJECTIVE FORMULA | 280 | 217 | 13 | 0.38 | +574 | +44.1 |
| FEATURE BUFFS | 134 | 134 | 12 | 0.35 | +314 | +26.2 |
| MARCH OF THE TABLE | 12 | 12 | 12 | 0.35 | -161 | -13.4 |
| OPENS UP | 23 | 19 | 12 | 0.35 | +268 | +22.3 |
| HIS FIGHT TOGETHER | 127 | 124 | 11 | 0.32 | +1206 | +109.7 |
| SEARCH SPOT | 14 | 14 | 11 | 0.32 | +160 | +14.5 |
| GUN MASK | 49 | 48 | 10 | 0.29 | +268 | +26.8 |
| MANOEUVRE | 53 | 53 | 10 | 0.29 | +112 | +11.2 |
| WAR ENGINE JOBS | 30 | 30 | 10 | 0.29 | -202 | -20.2 |
| HIS CHARGE DENIED | 22 | 20 | 9 | 0.26 | +373 | +41.4 |
| HIS MOVE AND SHOT | 243 | 231 | 9 | 0.26 | +56 | +6.2 |
| MISSILES NEXT TURN | 371 | 266 | 9 | 0.26 | +61 | +6.7 |
| NO DOUBLE ROUNDS | 183 | 175 | 9 | 0.26 | +158 | +17.6 |
| ONE PROMISE A TARGET | 9 | 9 | 9 | 0.26 | -244 | -27.1 |
| REFUSING RETIRES | 23 | 23 | 9 | 0.26 | -4 | -0.4 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.24 | +0 | +0.0 |
| EDGE GIVE GROUND | 17 | 17 | 8 | 0.24 | +356 | +44.5 |
| MODEL FACING | 8 | 8 | 8 | 0.24 | +1601 | +200.1 |
| OVERRUNS AWAY | 30 | 29 | 8 | 0.24 | +156 | +19.5 |
| PROMISE SHOT AWAY | 8 | 8 | 8 | 0.24 | -80 | -10.0 |
| REDIRECT BY WHAT IT STOPS | 75 | 75 | 8 | 0.24 | +152 | +19.0 |
| STUCK PIVOT | 8 | 8 | 8 | 0.24 | +0 | +0.0 |
| BEST PRIZE | 7 | 7 | 7 | 0.21 | -194 | -27.7 |
| FIGHT TO THE END | 51 | 49 | 7 | 0.21 | +190 | +27.1 |
| HONEST WORTH | 212 | 200 | 7 | 0.21 | +63 | +9.0 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.18 | +136 | +22.7 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.18 | -147 | -24.5 |
| PROMISE READS THE TABLE | 24 | 24 | 6 | 0.18 | +62 | +10.2 |
| BOMBING RUN | 5 | 5 | 5 | 0.15 | +95 | +19.1 |
| CHARGE NOT DECLARED | 5 | 5 | 5 | 0.15 | -548 | -109.5 |
| KEEP FALLS | 5 | 5 | 5 | 0.15 | +214 | +42.9 |
| ONE FIGHT FORMULA | 347 | 182 | 5 | 0.15 | +44 | +8.7 |
| SPELLS IN THE FIGHT | 36 | 32 | 5 | 0.15 | +58 | +11.7 |
| WHO GETS IN | 5 | 5 | 5 | 0.15 | +338 | +67.7 |
| FALLBACK BY WORTH | 14 | 14 | 4 | 0.12 | +189 | +47.3 |
| SHORT GUN FORWARD | 4 | 4 | 4 | 0.12 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 179 | 170 | 3 | 0.09 | +30 | +10.1 |
| HUNT IN PAIRS | 25 | 15 | 3 | 0.09 | +173 | +57.7 |
| LOST AFTER ESCAPE | 125 | 119 | 3 | 0.09 | +40 | +13.3 |
| PROMISE KNOWS THE FIGHT | 40 | 26 | 3 | 0.09 | -7 | -2.2 |
| ROUNDS AFTER TERROR | 65 | 61 | 3 | 0.09 | +5 | +1.7 |
| SAFER THAN THE JOB | 3 | 3 | 3 | 0.09 | +78 | +26.2 |
| WIDER SPREAD | 155 | 145 | 3 | 0.09 | +24 | +8.1 |
| BEST OVERALL | 2 | 2 | 2 | 0.06 | +19 | +9.5 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.06 | +189 | +94.7 |
| LONG SHOT | 19 | 18 | 2 | 0.06 | +77 | +38.5 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.06 | -7 | -3.4 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -151 | -75.3 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +18 | +9.2 |
| SCREEN BY WHAT IT SAVES | 30 | 30 | 2 | 0.06 | +3 | +1.6 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.06 | -52 | -25.9 |
| WHOLE FIGHT | 12 | 10 | 2 | 0.06 | +64 | +31.9 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.06 | +76 | +38.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.03 | +6 | +5.9 |
| DENIED BY THE FIGHT | 38 | 38 | 1 | 0.03 | +3 | +2.7 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +0 | +0.3 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +10 | +10.5 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.03 | +175 | +174.6 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +36 | +36.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.03 | +33 | +33.2 |
| SET UP TOGETHER | 13 | 10 | 1 | 0.03 | +10 | +10.4 |
| STOPS | 3 | 3 | 1 | 0.03 | +23 | +23.2 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 7 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 15 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 48 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 6 | 6 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 42 | 37 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 15 | 15 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 60 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 6 | 6 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 317 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 38 | 35 | 0 | 0.00 | - | - |
| GIVES UP | 12 | 10 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | not checked | - | - | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GUN FIGURES | 40 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 247 | 240 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 351 | 337 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 269 | 244 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 261 | 238 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 105 | 105 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 225 | 210 | 0 | 0.00 | - | - |
| HOLD ODDS | 1137 | 1130 | 0 | 0.00 | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 144 | 137 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 9 | 9 | 0 | 0.00 | - | - |
| LOST CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 11 | trace | - | - | - | - |
| MARCH OVER CASTS | 62 | 62 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 66 | 60 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 15 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 30 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 6 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 55 | 52 | 0 | 0.00 | - | - |
| NOT TURNED | 14 | 14 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 37 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 321 | 314 | 0 | 0.00 | - | - |
| ONE ROUTE | 66 | 60 | 0 | 0.00 | - | - |
| OPENS A LANE | 8 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 2790 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 19 | 19 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 66 | 60 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 77 | 63 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 13 | 11 | 0 | 0.00 | - | - |
| RUN DOWN | 168 | 157 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 22 | 22 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 12 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOT OR CHARGE | 12 | 12 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 129 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 559 | 529 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 31 | 30 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 63 | 59 | 0 | 0.00 | - | - |
| STANDS STILL | 2552 | 2485 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 98 | not checked | - | - | - | - |
| THE PROMISE ADDS | 8 | 8 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2194 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 139 | 125 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 23 | 19 | 0 | 0.00 | - | - |

### Off best figure: base-s1-882d875-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.24 | 3.44 | 75.0 |
| JOB FIRST | gate | 2.44 | 3.65 | 32.2 |
| ARMY TABLE | rule | 1.29 | 2.09 | 50.9 |
| CHARGE NOW FIRST | rule | 0.71 | 0.74 | 57.3 |
| NO REASON | gate | 0.38 | 0.88 | 40.3 |
| HOLDER ASSIGNMENT | rule | 0.29 | 0.71 | 19.4 |
| SUPPORT NARROWED | rule | 0.41 | 0.09 | 136.0 |
| JOINT CHARGE NOW | rule | 0.21 | 0.24 | 96.3 |
| MARCH OF THE TABLE | rule | 0.18 | 0.18 | 13.4 |
| WAR ENGINE JOBS | rule | 0.26 | 0.03 | 20.2 |
| ONE PROMISE A TARGET | rule | 0.09 | 0.15 | 39.5 |
| BEST PRIZE | rule | 0.12 | 0.09 | 27.7 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.15 | 24.5 |
| CHARGE NOT DECLARED | rule | 0.03 | 0.12 | 109.5 |
| PROMISE SHOT AWAY | rule | 0.06 | 0.09 | 15.8 |
| AFTERMATH BAND | gate | 0.06 | 0.06 | 2.9 |
| CANNON PLANNED TARGET | rule | 0.12 | - | 28.6 |
| CHAFF PASSED | rule | 0.03 | 0.09 | 4.2 |
| SET UP BY THE SET | rule | 0.06 | 0.06 | 101.9 |
| DEPLOY BY FIGURES | rule | 0.06 | 0.03 | 7.3 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 1.6 |
| PATHS CROSS | rule | 0.03 | 0.06 | 28.9 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.09 | 2.2 |
| PURSUES BIG PREY | rule | 0.03 | 0.03 | 75.3 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 36.8 |
| REFUSING RETIRES | rule | 0.06 | - | 0.9 |
| TURN GATE | gate | 0.03 | 0.03 | 18.8 |
| WALKS ON ITS ROUTE | rule | 0.03 | 0.03 | 25.9 |
| WHO GETS IN | rule | 0.06 | - | 91.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 213.3 |
| FALLBACK | gate | 0.03 | - | 23.2 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 3.8 |
| OWN CAST FIRST | rule | - | 0.03 | 6.3 |
| PROMISE READS THE TABLE | rule | 0.03 | - | 80.1 |

### Plans: base-s1-882d875-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.4 | 74% | 346 | 238 | 69% |
| Mine | join | 0.4 | 100% | 12 | 0 | 0% |
| Mine | move | 27.4 | 94% | 1486 | 0 | 0% |
| Mine | shoot | 9.8 | 53% | 538 | 553 | 103% |
| Mine | support | 0.5 | 81% | 10 | 0 | 0% |
| Opponent | charge | 3.5 | 59% | 653 | 328 | 50% |
| Opponent | join | 0.5 | 94% | 24 | 0 | 0% |
| Opponent | move | 33.3 | 95% | 1777 | 0 | 0% |
| Opponent | shoot | 3.4 | 45% | 197 | 140 | 71% |
| Opponent | support | 1.1 | 81% | 2 | 0 | 0% |

### Packages: hunt the guns, base-s1-882d875-p7

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 2 |
| Opponent | 0.1 | 3 | 0 | 67% | 67% | 0% | 2.0 | 501 | 304 | 67% | 75 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 86 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 545 | 469 | 100% | 168 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 478 | 222 | 50% | 19 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 38 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |

### Battle groups: base-s1-882d875-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 32% | 57% | 4% | 0% | 9% | 0% | 14% | 68% | 9% |
| Opponent | REDIRECT COUNTER | 2.9 | 18% | 88% | 24% | 25% | 8% | 0% | 15% | 69% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s1-882d875-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 74 (34) | 24 | 50 | 61 | 38% | 2.0 | 90 (16) | 96 (11) | 0 (7) | 73 (28) | 79 (6) |
| Mine | Character | 118 | 43 (118) | 43 | 0 | 24 | 22% | 2.5 | 39 (45) | 47 (55) | 57 (11) | 33 (66) | 57 (45) |
| Mine | Clean-up | 22 | 49 (22) | 0 | 49 | 42 | 41% | 3.7 | 36 (11) | 64 (8) | 41 (3) | 46 (17) | 66 (5) |
| Mine | Fast Hammer | 41 | 34 (41) | 11 | 22 | 26 | 39% | 2.7 | 40 (13) | 32 (19) | 29 (9) | 39 (29) | 23 (12) |
| Mine | Hammer | 48 | 19 (48) | 3 | 16 | 26 | 38% | 2.3 | 4 (15) | 32 (26) | 4 (7) | 15 (32) | 27 (16) |
| Mine | Holder | 33 | 61 (33) | 11 | 50 | 22 | 24% | 3.4 | 4 (8) | 92 (14) | 55 (10) | 61 (17) | 63 (15) |
| Mine | Shooter | 31 | 81 (31) | 37 | 44 | 38 | 10% | 1.8 | 94 (13) | 86 (14) | 0 (4) | 91 (23) | 55 (8) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 53 | 39 (53) | 39 | 0 | 50 | 2% | 1.5 | 28 (17) | 42 (23) | 47 (13) | 33 (15) | 41 (38) |
| Mine | Wizard | 18 | 0 (18) | 0 | 0 | 61 | 17% | 2.1 | 0 (3) | 0 (5) | 0 (3) | 0 (3) | 0 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 77 | 69 (77) | 16 | 54 | 36 | 49% | 3.0 | 27 (31) | 138 (25) | 36 (21) | 71 (61) | 64 (16) |
| Opponent | Character | 86 | 53 (86) | 53 | 1 | 21 | 16% | 2.0 | 44 (21) | 58 (46) | 68 (13) | 61 (48) | 49 (32) |
| Opponent | Clean-up | 12 | 72 (12) | 3 | 69 | 0 | 17% | 1.8 | 0 (5) | 121 (6) | 114 (1) | 81 (6) | 62 (6) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 47 | 40 (47) | 19 | 20 | 31 | 38% | 2.6 | 15 (8) | 43 (28) | 52 (11) | 39 (23) | 40 (24) |
| Opponent | Fragile | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.0 | - | 0 (1) | 0 (3) | 0 (3) | 0 (1) |
| Opponent | Hammer | 66 | 23 (66) | 16 | 7 | 43 | 45% | 3.0 | 45 (20) | 15 (28) | 14 (18) | 31 (39) | 12 (27) |
| Opponent | Holder | 28 | 42 (28) | 2 | 40 | 29 | 39% | 3.1 | 57 (10) | 43 (11) | 20 (7) | 50 (19) | 23 (9) |
| Opponent | Shooter | 30 | 70 (30) | 13 | 57 | 33 | 7% | 1.7 | 70 (14) | 75 (15) | 0 (1) | 70 (16) | 70 (14) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 8 | 5 (8) | 5 | 0 | 58 | 25% | 2.5 | 0 (2) | 0 (2) | 8 (4) | - | 5 (8) |
| Opponent | Wizard | 13 | 0 (13) | 0 | 0 | 16 | 8% | 2.0 | 0 (4) | 0 (5) | 0 (3) | 0 (5) | 0 (7) |

### Charged fights: base-s1-882d875-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 224 | 0 | 0.5 | 1.0 | 0 | 68 | -68 | 2 of 2 | 0 of 2 | - | -68 |
| Mine | Chaos Dwarfs | 4 | 166 | 235 | 1.5 | 1.2 | 157 | 0 | +157 | 1 of 6 | 6 of 6 | +126 | +163 |
| Mine | Dwarfen Mountain Holds | 3 | 479 | 24 | 0.3 | 1.0 | 72 | 60 | +12 | 0 of 1 | 1 of 1 | - | +12 |
| Mine | Empire of Man | 4 | 228 | 97 | 1.0 | 1.0 | 97 | 0 | +97 | 1 of 4 | 2 of 4 | - | +97 |
| Mine | Grand Cathay | 5 | 184 | 221 | 2.4 | 1.0 | 92 | 0 | +92 | 2 of 12 | 11 of 12 | - | +92 |
| Mine | High Elf Realms | 3 | 260 | 656 | 3.7 | 1.1 | 179 | 44 | +135 | 3 of 11 | 9 of 11 | +161 | +132 |
| Mine | Kingdom of Bretonnia | 2 | 92 | 594 | 4.0 | 1.4 | 149 | 0 | +149 | 2 of 8 | 8 of 8 | +94 | +181 |
| Mine | Ogre Kingdoms | 1 | 19 | 109 | 2.0 | 1.0 | 54 | 17 | +38 | 0 of 2 | 1 of 2 | - | +38 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 187 | 2.0 | 1.5 | 94 | 0 | +94 | 1 of 2 | 2 of 2 | +27 | +160 |
| Mine | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 56 | 972 | 4.5 | 1.1 | 216 | 0 | +216 | 3 of 9 | 7 of 9 | +205 | +218 |
| Mine | Vampire Counts | 2 | 0 | 70 | 2.0 | 1.0 | 35 | 150 | -115 | 2 of 4 | 1 of 4 | - | -115 |
| Mine | Warriors of Chaos | 2 | 0 | 62 | 1.5 | 1.0 | 42 | 0 | +42 | 0 of 3 | 3 of 3 | - | +42 |
| **Mine** | all armies | 34 | 174 | 240 | 1.9 | 1.1 | 124 | 20 | +104 | 18 of 66 | 51 of 66 | +115 | +103 |
| Opponent | Grand Cathay | 3 | 181 | 302 | 4.3 | 1.0 | 70 | 0 | +70 | 5 of 13 | 11 of 13 | - | +70 |
| Opponent | High Elf Realms | 3 | 0 | 655 | 3.7 | 1.0 | 179 | 11 | +167 | 3 of 11 | 10 of 11 | - | +167 |
| Opponent | Ogre Kingdoms | 3 | 146 | 108 | 2.3 | 1.1 | 46 | 6 | +41 | 1 of 7 | 2 of 7 | -40 | +54 |
| Opponent | Skaven | 1 | 0 | 60 | 1.0 | 1.0 | 60 | 0 | +60 | 0 of 1 | 0 of 1 | - | +60 |
| Opponent | Tomb Kings of Khemri | 1 | 105 | 1207 | 10.0 | 1.0 | 121 | 0 | +121 | 8 of 10 | 3 of 10 | - | +121 |
| Opponent | Vampire Counts | 5 | 0 | 416 | 3.4 | 1.1 | 122 | 10 | +113 | 6 of 17 | 12 of 17 | +176 | +104 |
| Opponent | Warriors of Chaos | 8 | 24 | 320 | 2.8 | 1.1 | 116 | 8 | +109 | 8 of 22 | 17 of 22 | +116 | +108 |
| Opponent | Wood Elf Realms | 10 | 87 | 371 | 2.9 | 1.0 | 128 | 29 | +99 | 11 of 29 | 20 of 29 | - | +99 |
| **Opponent** | all armies | 34 | 63 | 377 | 3.2 | 1.0 | 117 | 12 | +104 | 42 of 110 | 75 of 110 | +109 | +104 |

### Effective charges: base-s1-882d875-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 2 (net -68) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 6 | 1 (net +137) | 0 | 0 | 1 (net +139) | 2 (net +130) | 0 | 2 | 0% (0 of 4) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net +12) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 4 | 1 (net +95) | 0 | 1 (net +233) | 0 | 1 (net +60) | 0 | 1 | 33% (1 of 3) |
| Mine | Grand Cathay | 12 | 0 | 0 | 1 (net +0) | 2 (net +0) | 0 | 7 (net +149) | 2 | 10% (1 of 10) |
| Mine | High Elf Realms | 11 | 1 (net +622) | 0 | 2 (net +366) | 2 (net -241) | 0 | 2 (net +188) | 4 | 29% (2 of 7) |
| Mine | Kingdom of Bretonnia | 8 | 0 | 0 | 0 | 2 (net +118) | 2 (net +79) | 2 (net +218) | 2 | 0% (0 of 6) |
| Mine | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 0 | 1 (net +27) | 1 (net +160) | 0 | 0% (0 of 2) |
| Mine | Skaven | 2 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 9 | 3 (net +244) | 0 | 2 (net +76) | 1 (net +205) | 0 | 3 (net +285) | 0 | 22% (2 of 9) |
| Mine | Vampire Counts | 4 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Warriors of Chaos | 3 | 1 (net +125) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Grand Cathay | 13 | 2 (net +166) | 0 | 1 (net +0) | 2 (net +62) | 3 (net +22) | 2 (net +42) | 3 | 10% (1 of 10) |
| Opponent | High Elf Realms | 11 | 1 (net +0) | 0 | 0 | 3 (net +113) | 2 (net +264) | 2 (net +120) | 3 | 0% (0 of 8) |
| Opponent | Ogre Kingdoms | 7 | 1 (net +165) | 0 | 2 (net +20) | 0 | 0 | 0 | 4 | 67% (2 of 3) |
| Opponent | Tomb Kings of Khemri | 10 | 4 (net +56) | 0 | 1 (net +185) | 4 (net +200) | 0 | 1 (net +0) | 0 | 10% (1 of 10) |
| Opponent | Vampire Counts | 17 | 4 (net +15) | 1 (net +72) | 4 (net +261) | 2 (net +140) | 2 (net +64) | 4 (net +83) | 0 | 24% (4 of 17) |
| Opponent | Warriors of Chaos | 22 | 3 (net -56) | 2 (net +81) | 1 (net +0) | 2 (net +155) | 7 (net +97) | 6 (net +235) | 1 | 5% (1 of 21) |
| Opponent | Wood Elf Realms | 29 | 7 (net +95) | 1 (net -429) | 3 (net +149) | 5 (net -1) | 0 | 4 (net +113) | 9 | 15% (3 of 20) |

### Charged fights, damage counted: base-s1-882d875-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 210 | 299 | +131 | 164 | 29 | +136 | +64.5 |
| Mine | Effective (55-75%) | 8 | 324 | 234 | +140 | 176 | 58 | +119 | +36.6 |
| Mine | 76-89% | 9 | 270 | 171 | +12 | 79 | 74 | +5 | +1.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 320 | 177 | +179 | 188 | 23 | +165 | +51.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 522 | 105 | +84 | 102 | 0 | +102 | +19.6 |
| Mine | No odds | 15 | 289 | 150 | +45 | 102 | 46 | +56 | +19.3 |
| Mine | All fights | 66 | 305 | 192 | +104 | 140 | 38 | +102 | +33.3 |
| Opponent | Long shot (under 50%) | 22 | 228 | 266 | +58 | 95 | 60 | +35 | +15.4 |
| Opponent | 50-54% | 4 | 294 | 234 | -49 | 185 | 164 | +21 | +7.0 |
| Opponent | Effective (55-75%) | 12 | 340 | 241 | +143 | 154 | 33 | +121 | +35.5 |
| Opponent | 76-89% | 18 | 301 | 176 | +103 | 131 | 27 | +104 | +34.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 336 | 216 | +133 | 174 | 21 | +153 | +45.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 462 | 90 | +100 | 113 | 31 | +82 | +17.7 |
| Opponent | No odds | 21 | 259 | 140 | +139 | 151 | 16 | +136 | +52.3 |
| Opponent | All fights | 110 | 309 | 192 | +104 | 137 | 37 | +101 | +32.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s1-882d875-p7 | move | 238 | 46 (19%) | 34 (14%) | 32 (13%) | 160 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0112, L0128, L2435, L2632 |
| Charmed Shield | Opponent | L0727, L0924, L1124, L1234, L1424, L1934, L2225, L2834 |
| Clockwork Compass | Mine | L1218, L1234 |
| Clockwork Compass | Opponent | L0112, L0212 |
| Elixir of Power | Mine | L1124, L1934 |
| Elixir of Power | Opponent | L0711 |
| Fistful of Laurels | Mine | L1833 |
| Fistful of Laurels | Opponent | L0518, L1218, L1618 |
| Horn of the Wild Hunt | Opponent | L0833, L1833 |
| Invocation of Nehek | Mine | L2435 |
| Invocation of Nehek | Opponent | L0727, L0924, L1124, L1424, L2225 |
| Opal Amulet | Mine | L1424 |
| Periapt of Soul Exchange | Mine | L2035 |
| Periapt of Soul Exchange | Opponent | L1521 |
| Ring of Doom | Mine | L0212, L0228, L1124, L1218, L1234, L1521, L3135 |
| Ring of Doom | Opponent | L0112, L0212, L0415, L0711, L0833, L1015, L1833 |
| Ring of Jet | Mine | L1015, L1032, L1124, L1218, L1234 |
| Ring of Jet | Opponent | L0112, L0212, L0711 |
| Standard of the Fell Warrior | Mine | L1329 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L1521 |
| Twice-Blessed Armour | Mine | L0711, L0727, L1015, L1032 |
| Witch Hunter's Ward | Mine | L0711, L0727, L0833 |

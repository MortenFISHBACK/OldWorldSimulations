# Doctrine scorecard: base-s1-882d875-p3

### Scorecard: base-s1-882d875-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 165 |
| L0126 | 6 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 3 | - | 0 | 5 | 0 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 11 | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Mine | no | 0 | 6 | 1 | 2 | 1 | 0 | 0 | 336 |
| L0226 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 1090 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 2 | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0327 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 263 |
| L0413 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Mine | yes | 9 | 3 | 2 | 2 | 0 | 0 | 0 | 495 |
| L0429 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0516 | 6 | 1 | Opponent | no | 7 | - | 2 | 1 | 0 | 0 | 0 | 100 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 640 |
| L0533 | 5 | 1 | Opponent | no | - | - | 0 | 6 | 0 | 0 | 0 | 19 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 398 |
| L0620 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 6 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 45 |
| L0725 | 5 | 1 | Mine | no | - | 3 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0725 | 5 | 1 | Opponent | yes | - | 4 | 3 | 3 | 0 | 0 | 0 | 147 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 3 | 6 | 0 | 1 | 0 | 0 | 0 | 36 |
| L0831 | 3 | 1 | Opponent | no | 6 | - | 0 | 4 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 626 |
| L0922 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 1 | 0 | 0 | 195 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Opponent | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 70 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 7 | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 1 | 5 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 1 | 2 | 0 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 471 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 6 | 5 | 1 | 0 | 0 | 135 |
| L1327 | 1 | 1 | Mine | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Opponent | no | 1 | 4 | 3 | 3 | 1 | 0 | 0 | 451 |
| L1422 | 6 | 1 | Mine | no | 1 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 332 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 598 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 1 | 0 | 4 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | yes | 7 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Opponent | no | 4 | 1 | 3 | 3 | 0 | 0 | 0 | 144 |
| L1831 | 1 | 1 | Mine | no | 9 | - | 4 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 1 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 235 |
| L1932 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 0 | 0 | 0 | 135 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 7 | 1 | 0 | 0 | 275 |
| L2033 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 144 |
| L2223 | 3 | 1 | Opponent | no | 1 | 2 | 7 | 2 | 0 | 0 | 0 | 72 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 2 | 0 | 0 | 311 |
| L2327 | 5 | 1 | Opponent | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 186 |
| L2433 | 3 | 1 | Mine | no | 7 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 15 | 2 | 3 | 4 | 0 | 0 | 0 | 395 |
| L3133 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 0 | 4 | 5 | 3 | 0 | 0 | 0 | 253 |
| **Average** | | | Mine | 26% | 3.0 | 2.8 | 1.9 | 1.6 | 0.3 | 0.0 | 0.0 | 172.0 |
| **Average** | | | Opponent | 26% | 3.5 | 2.5 | 2.6 | 2.4 | 0.2 | 0.0 | 0.0 | 146.7 |

### KPIs: base-s1-882d875-p3

Morten 2026-11-10; 35 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (42 of 148) | 8% (13 of 163) | 18% (55 of 311) |
| Winner chose to follow up after the loser gave ground |  | 82% (33 of 40); on the table 90% | 95% (39 of 41); on the table 95% | 89% (72 of 81); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 71% (5 of 7); on the table 86% | 91% (10 of 11); on the table 91% | 83% (15 of 18); on the table 89% |
| Winner chose to pursue after the loser fled |  | 71% (12 of 17); on the table 71% | 79% (15 of 19); on the table 89% | 75% (27 of 36); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 78% (50 of 64); on the table 84% | 90% (64 of 71); on the table 93% | 84% (114 of 135); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 36% (120 of 336) | 22% (41 of 186) | 31% (161 of 522) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (120 of 262) | 30% (41 of 138) | 40% (161 of 400) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 48% (15 of 31) | 63% (36 of 57) | 58% (51 of 88) |
| Points that never fought | lower | 51% (34353 of 66801) | 54% (37732 of 69990) | 53% (72085 of 136791) |
|   infantry points that never fought | lower | 62% (8619 of 13801) | 66% (9250 of 13984) | 64% (17869 of 27785) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (165 of 265) | 65% (178 of 273) | 64% (343 of 538) |
| Bound items with a magic missile used (at least once a game) |  | 80% (20 of 25); 1.7 uses a game | 83% (19 of 23); 1.9 uses a game | 81% (39 of 48); 1.8 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 0.4 uses a game | 33% (2 of 6); 0.1 uses a game | 30% (6 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (4 of 14); 0.1 uses a game | 44% (15 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (32966 of 57776) | 59% (36681 of 62043) | 58% (69647 of 119819) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.4 (38%) | 1.7 (40%) | 4.0 (39%) |
| MARCHED: its unit marched | 1.5 (24%) | 1.0 (25%) | 2.5 (24%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.1 (18%) | 0.7 (18%) | 1.9 (18%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.9 (14%) | 0.4 (10%) | 1.3 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.2 (6%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.6 | 1.1 | 2.8 | 4.6 | 0.8 | 1.3 |
| not cast | 3.5 | 1.7 | 3.5 | 10.3 | 2.5 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.9 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (66%) | 0.4 (11%) | 4.0 (39%) | 0.4 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (24%) | 0.4 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (7%) | 0.4 (12%) | 1.9 (18%) | 0.5 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.6 (18%) | 0.3 (17%) | 0.6 (18%) | 1.3 (12%) | 0.2 (9%) | 1.8 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.1 (7%) | 0.3 (7%) | 0.3 (3%) | 0.3 (11%) | 1.3 (6%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.7 (26%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (67%) | 0.1 (3%) | 1.4 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.9 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 1.3 a game | 1.5 a game |
| stood (cast and not dispelled) | 66% (35 of 53) | 66% (25 of 38) | 66% (60 of 91) |
| the unit moved after it | 57% (20 of 35) | 76% (19 of 25) | 65% (39 of 60) |
| it charged on its next turn | 3% (1 of 35) | 0% (0 of 25) | 2% (1 of 60) |
| the enemy charged it first | 11% (4 of 35) | 4% (1 of 25) | 8% (5 of 60) |
| it fought by the end of its next turn | 9% (3 of 35) | 0% (0 of 25) | 5% (3 of 60) |
| it moved out of a charge the enemy had planned (not charged first) | 6% (2 of 35) | 0% (0 of 25) | 3% (2 of 60) |
| none of these (no charge, no fight, no charge escaped) | 80% (28 of 35) | 96% (24 of 25) | 87% (52 of 60) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (468 of 774) | 56% (376 of 675) | 58% (844 of 1449) |
|   cavalry | 61% (41 of 67) | 64% (67 of 105) | 63% (108 of 172) |
|   character | 49% (45 of 92) | 30% (45 of 149) | 37% (90 of 241) |
|   chariot | 67% (70 of 104) | 76% (32 of 42) | 70% (102 of 146) |
|   infantry | 60% (123 of 204) | 64% (181 of 282) | 63% (304 of 486) |
|   monster | 67% (16 of 24) | 17% (1 of 6) | 57% (17 of 30) |
|   war machine | 61% (173 of 283) | 55% (50 of 91) | 60% (223 of 374) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.1 (13%) | 1.3 (16%) | 2.5 (14%) |
| CHARGED: it charged | 0.8 (9%) | 1.6 (19%) | 2.4 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.5 (6%) | 0.8 (4%) |
| MOVED: a war machine that moved | 1.5 (18%) | 0.9 (11%) | 2.5 (14%) |
| NO TARGET IN RANGE | 2.0 (23%) | 2.1 (25%) | 4.1 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.3 (4%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (22%) | 1.5 (18%) | 3.5 (20%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.3 (1%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.1 | 1.1 | 85% | 5.8 pts | 29 pts |
| character | 2.8 | 0.9 | 78% | 8.5 pts | 24 pts |
| chariot | 2.9 | 1.9 | 65% | 17.0 pts | 50 pts |
| infantry | 13.2 | 4.2 | 78% | 8.5 pts | 112 pts |
| monster | 0.6 | 0.2 | 75% | 3.9 pts | 2 pts |
| war machine | 6.5 | 6.7 | 56% | 32.4 pts | 210 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 4.2 | 3.5 |
| Charges that made contact a game | 1.8 | 3.0 | 2.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.78 declared, 0.59 contact (27 units) | 0.84 declared, 0.79 contact (19 units) | 0.80 declared, 0.67 contact (46 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | 0.69 declared, 0.38 contact (13 units) | 0.67 declared, 0.33 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.20 contact (228 units) | 0.45 declared, 0.31 contact (271 units) | 0.39 declared, 0.26 contact (499 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 65% (49 of 75) | 57% (8 of 14) | 60% (6 of 10) | 64% (63 of 99) |
| Character in a unit | 93% (42 of 45) | 79% (11 of 14) | 50% (3 of 6) | 86% (56 of 65) |
| Character on its own | 93% (25 of 27) | 64% (27 of 42) | 32% (21 of 66) | 54% (73 of 135) |
| Chariot | 82% (9 of 11) | 75% (9 of 12) | - | 78% (18 of 23) |
| Infantry | 58% (39 of 67) | 45% (19 of 42) | 40% (2 of 5) | 53% (60 of 114) |
| Monster | 62% (18 of 29) | 57% (4 of 7) | - | 61% (22 of 36) |
| Monstrous | 90% (9 of 10) | 82% (9 of 11) | - | 86% (18 of 21) |
| War Machines | 74% (32 of 43) | 50% (1 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (2 of 2); on the table 100% | 47% (45 of 96) | 64% | 68% (15 of 22) | 100% (6 of 6); 3.2 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 80% (4 of 5); on the table 80% | 42% (15 of 36) | 65% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 0% (0 of 3); on the table 67% | - | 83% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (4 of 5); on the table 80% | 30% (9 of 30) | 72% | 69% (41 of 59) | 0.0 uses a game | 50% (1 of 2); 1.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 65% (13 of 20); on the table 75% | 27% (52 of 192) | 48% | 64% (47 of 74) | 72% (13 of 18); 4.8 uses a game | 25% (1 of 4); 0.1 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 86% (12 of 14); on the table 86% | 12% (5 of 42) | 58% | 50% (27 of 54) | 78% (7 of 9); 4.3 uses a game | 17% (2 of 12); 0.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 50% (2 of 4); on the table 50% | - | 67% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 15% | 86% (6 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (6 of 6); on the table 100% | 17% (2 of 12) | 9% | 81% (13 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 67% (4 of 6); on the table 100% | 33% (4 of 12) | 62% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 100% (9 of 9); on the table 100% | 0% (0 of 6) | 45% | 58% (15 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (22 of 22); on the table 100% | 31% (17 of 54) | 41% | 67% (31 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 88% (23 of 26); on the table 88% | 29% (7 of 24) | 45% | 54% (45 of 84) | 100% (3 of 3); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (12 of 12); on the table 100% | 8% (1 of 12) | 50% | 76% (47 of 62) | 91% (10 of 11); 4.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s1-882d875-p3, 35 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (31) | 47% (20) | 47% (51) |
| ...free all their last turn and able to turn (per game) | 0.63 | 0.51 | 1.14 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.03 | 0.20 |
| ...with the charger already in that arc before they moved (per game) | 0.37 | 0.37 | 0.74 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.09 | 0.00 | 0.09 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.03 | 0.06 | 0.09 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.17 | 0.34 | 0.51 |

### Quality by phase: base-s1-882d875-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 60% (46 of 77) | 57% (65 of 115) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (150 of 398) | 41% (61 of 149) |
| Strategy | Support requests answered (helper made contact too) | 50% (3 of 6) | 71% (10 of 14) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (4 of 7) | 83% (5 of 6) |
| Strategy | Joined characters whose unit fought | 20% (10 of 50) | 17% (7 of 41) |
| Strategy | Lone characters that fought | 72% (59 of 82) | 66% (58 of 88) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.6 | 2.4 |
| Movement | Points that never moved of their own | 172.0 | 146.7 |
| Movement | Fights charged into per game | 1.8 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 45, net +58 | 14 of 71, net -33 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 45, net +112 | 6 of 71, net +36 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 45, net +74 | 9 of 71, net +114 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 of 45, net +78 | 19 of 71, net +232 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.9 | 10.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (149 of 313) | 43% (161 of 374) |
| Shooting | Points destroyed by shooting units | 54.0 | 53.3 |
| Shooting | War machine shots | 4.9 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (83 of 173) | 44% (24 of 54) |
| Shooting | Points destroyed by war machines | 77.6 | 10.5 |
| Magic | Magic missiles cast | 2.4 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (28 of 85) | 23% (6 of 26) |
| Magic | Wounds caused by magic missiles | 4.0 | 1.4 |
| Magic | Wounds caused by other spells | 1.6 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 45.6 | 33.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.2 / 0.6 / 0.2 | 1.9 / 0.4 / 0.3 / 0.4 |
| Combat | Points destroyed in combat | 148.3 | 243.4 |
| Combat | Points run down | 36.4 | 127.9 |
| Combat | Net points per charged fight, damage counted | +108 | +114 |
| Combat | Net per 100 charger points, damage counted | +35.8 | +40.1 |
| Combat | First round won (charged fights) | 84% | 71% |
| Combat | Net points per charged fight | +99 | +118 |
| Combat | Net points per supported fight / lone fight | +100 / +99 | +240 / +105 |
| Combat | Charged fights on a top-3 enemy unit | 14 of 62 | 43 of 91 |
| Game | Points lost | 573.5 | 504.3 |
| Game | VP from objectives | 572.9 | 664.9 |
| Game | Lone holders (player turns) | 3.0 | 3.5 |

- Mine won / drew / lost: 14 / 6 / 15 of 35 ended games (of 35); mean margin (Mine - Opponent) -151 VP
- The side that went first won 13 of 29 games with a winner
- Points traded per game (both sides' losses): 1078
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: base-s1-882d875-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +35.6 | 0.0 | 11.4 | 0.1 | +3.4 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.1 | +2.5 | 0.0 | 3.3 | 0.1 | +2.5 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 21.3 | 2.7 | - | - | - | - |
| ARMY TABLE | 15.5 | +227.4 | 0.0 | 165.3 | 18.8 | +289.1 | 0.0 | 181.3 |
| ARRIVAL HUNT | 0.0 | +0.2 | 0.0 | 2.6 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 15.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.3 | 0.0 | 17.1 | 0.3 | +2.4 | 0.0 | 12.2 |
| BEST FACING | 0.0 | +2.0 | 0.0 | 3.2 | - | - | - | - |
| BEST OVERALL | - | - | - | - | 0.0 | +2.7 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | -5.6 | 0.0 | 0.0 | 0.1 | -6.3 | 2.2 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -10.8 | 14.1 | 13.5 | 0.2 | -24.6 | 9.8 | 5.6 |
| BOMBING RUN | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.3 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 19.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.0 | +75.2 | 325.3 | 55.0 | 1.2 | +32.9 | 17.1 | 21.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 2.0 |
| CAST JOB | 1.5 | +67.6 | 114.0 | 0.0 | 0.5 | +14.0 | 64.3 | 21.1 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +32.1 | 3.4 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 56.4 | 0.8 | +0.0 | 0.0 | 16.9 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.6 | +27.8 | 0.0 | 19.3 | 1.6 | +78.3 | 0.0 | 41.8 |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 8.5 | 0.2 | -0.3 | 0.0 | 5.1 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.7 | 0.0 | 5.9 |
| CHARACTER GUNS | 0.7 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 10.1 | -471.5 | 0.0 | 312.7 | 10.9 | -578.1 | 0.0 | 240.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.1 | +0.0 | 0.0 | 1.4 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 171.4 | 53.3 | 1.8 | +0.0 | 212.5 | 11.9 |
| CHARGER SLAIN LOST | 0.2 | -3.1 | 3.7 | 1.7 | 0.3 | -3.5 | 31.1 | 8.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 5.6 | 28.1 | 0.2 | +0.0 | 13.8 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 5.6 |
| CONVEYANCE SEARCH | 1.5 | +232.1 | 79.0 | 61.9 | 0.7 | +60.9 | 29.7 | 36.1 |
| COVER ONCE | 6.9 | -531.2 | 0.0 | 145.1 | 3.8 | -350.1 | 0.0 | 76.0 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 4.1 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.2 | -2.1 | 4.5 | 5.0 | 0.7 | -5.3 | 125.3 | 4.9 |
| DEPLOY BY FIGURES | 7.7 | +32.0 | 0.0 | 3.5 | 7.6 | +37.7 | 0.0 | 25.9 |
| EDGE GIVE GROUND | 0.2 | +18.7 | 38.4 | 36.3 | 0.2 | +1.8 | 15.0 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.1 | +3.9 | 0.0 | 6.6 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +2.5 | 114.3 | 72.9 | 2.7 | +4.3 | 294.5 | 22.1 |
| FALLBACK BY WORTH | 0.1 | +1.3 | 0.0 | 1.3 | 0.3 | +6.6 | 0.0 | 7.9 |
| FALLS SHORT | 5.6 | +107.8 | 0.0 | 130.4 | 13.6 | +168.7 | 0.0 | 268.4 |
| FEATURE BUFFS | 3.0 | +87.4 | 0.0 | 56.3 | 1.5 | +37.8 | 0.0 | 23.8 |
| FIGHT LIFT | 0.0 | +0.2 | 3.0 | 0.0 | 0.1 | +0.5 | 3.4 | 0.0 |
| FIGHT TO THE END | 0.7 | +9.5 | 40.6 | 39.1 | 0.8 | +24.4 | 40.3 | 11.4 |
| FIRE AND FLEE | 0.0 | +1.4 | 0.0 | 2.3 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 5.1 | 0.0 | 0.2 | +0.0 | 3.5 | 0.0 |
| FIVE ACTION | 87.9 | +5537.0 | 1511.0 | 1230.2 | 82.3 | +4964.9 | 775.7 | 882.0 |
| FLANK NOT WEIGHED | 4.6 | +0.0 | 0.0 | 138.4 | 4.0 | +0.0 | 0.0 | 96.5 |
| FOLLOW UP WEIGHED | 0.8 | +105.6 | 0.0 | 17.4 | 0.9 | +152.2 | 0.0 | 6.0 |
| FOUR ROUNDS | 2.7 | +180.6 | 183.8 | 84.3 | 3.6 | +269.8 | 357.7 | 32.4 |
| FRIEND CHARGES FIRST | 0.1 | -2.7 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.8 | -13.7 | 0.0 | 8.3 | 0.4 | -4.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +2.2 | 0.0 | 0.0 | 0.1 | +1.5 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -3.9 | 26.1 | 26.6 | 0.4 | -3.5 | 35.5 | 5.9 |
| GROUND FLIERS | - | - | - | - | 0.0 | +1.2 | 0.0 | 0.0 |
| GUN FIGURES | 1.1 | +25.5 | 42.7 | 5.3 | 0.2 | +1.7 | 8.1 | 7.4 |
| GUN MASK | 1.7 | +47.8 | 0.0 | 11.5 | 0.9 | +28.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.1 | +0.0 | 0.0 | 13.0 | 1.1 | +0.0 | 0.0 | 17.9 |
| HE SHOOTS OR CHARGES | 2.3 | +0.0 | 0.0 | 100.7 | 4.5 | +0.0 | 0.0 | 100.9 |
| HELPER UNSEEN | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.1 | +3.0 | 2.4 | 0.0 | 0.4 | +25.8 | 9.1 | 1.9 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 48.7 | 4.7 | +0.0 | 0.0 | 38.5 |
| HIS FIGHT TOGETHER | 1.5 | -21.7 | 0.0 | 85.0 | 1.6 | -31.5 | 0.0 | 62.3 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 117.0 | 4.4 | +0.0 | 0.0 | 97.5 |
| HIS MOVE AND SHOT | 3.5 | -53.0 | 0.0 | 141.1 | 3.1 | -73.9 | 0.0 | 76.4 |
| HIS MOVE AS HE DECIDES | 38.1 | +12.5 | 551.7 | 0.0 | 33.5 | +13.1 | 554.9 | 0.0 |
| HIS MOVE WHY | 33.0 | +0.0 | 0.0 | 490.2 | 38.1 | +0.0 | 0.0 | 391.5 |
| HIS ONE MOVE | 17.5 | -24.1 | 2.6 | 99.6 | 20.6 | +22.0 | 6.3 | 80.1 |
| HIS ONE QUARTER | 3.9 | +0.0 | 0.0 | 90.7 | 3.7 | +0.0 | 0.0 | 27.9 |
| HIS OWN BEST MOVE | 1.9 | +0.0 | 0.0 | 50.9 | 1.9 | +0.0 | 0.0 | 60.4 |
| HIS RANDOM MOVE | 4.6 | +0.0 | 0.0 | 73.7 | 2.3 | +0.0 | 0.0 | 35.4 |
| HIS SHOT LIST | 33.6 | +1236.5 | 0.0 | 534.5 | 43.0 | +2271.3 | 0.0 | 545.8 |
| HIS TURN DENIED | 1.1 | +33.9 | 77.2 | 35.3 | 1.8 | +67.8 | 260.2 | 22.1 |
| HOLD ODDS | 17.5 | +0.0 | 0.0 | 299.2 | 16.2 | +0.0 | 0.0 | 112.8 |
| HOLDER ASSIGNMENT | 9.9 | +954.2 | 0.0 | 134.7 | 9.8 | +966.5 | 0.0 | 53.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.4 | -97.5 | 161.7 | 67.3 | 3.2 | -139.2 | 331.5 | 14.9 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.1 | +2.2 | 0.0 | 0.0 | 0.5 | +28.8 | 0.0 | 5.6 |
| HUNT KEPT | - | - | - | - | 0.0 | +1.1 | 3.6 | 1.7 |
| HUNT RESULT | - | - | - | - | 0.1 | +17.2 | 0.0 | 2.1 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +22.7 | 8.3 | 3.8 |
| IDLE COST | 3.8 | -58.9 | 0.0 | 68.1 | 10.7 | -183.6 | 0.0 | 114.7 |
| JOINT CHARGE NOW | 0.4 | -4.6 | 27.4 | 1.7 | 0.8 | +39.1 | 126.3 | 9.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -3.4 | 31.5 | 0.0 |
| JOINT LOOK BACK | 0.0 | +0.9 | 0.0 | 0.0 | 0.1 | +4.7 | 1.9 | 0.0 |
| JOINT ON THE TABLE | 0.0 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.8 | +0.0 | 0.0 | 8.2 | 2.7 | +0.0 | 0.0 | 11.1 |
| LANE BY FIGURES | 0.8 | +29.5 | 0.0 | 0.0 | 1.0 | +39.4 | 0.0 | 13.5 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 2.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.5 | +0.0 | 148.4 | 217.4 | 5.0 | +0.0 | 165.7 | 134.2 |
| LONE CHARACTER SAFE SPOT | 0.1 | +1.4 | 0.0 | 0.0 | 0.1 | +8.7 | 0.0 | 3.3 |
| LONE WIZARD KEPT IN | 0.6 | +38.4 | 0.0 | 0.0 | 0.4 | +26.1 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.3 | 30.1 | 1.7 | 0.2 | +0.3 | 2.6 | 3.4 |
| LOST AFTER ESCAPE | 1.5 | +1.1 | 109.9 | 67.5 | 2.0 | -8.1 | 216.0 | 13.2 |
| LURE BY WHAT IT DRAWS | 0.2 | -17.4 | 0.0 | 0.0 | 0.1 | -7.7 | 0.0 | 3.1 |
| MAKE SURE TOGETHER | - | - | - | - | 0.1 | +2.4 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +0.2 | 0.0 | 21.5 | 0.5 | +0.4 | 0.0 | 2.0 |
| MARCH AT ESCAPER | 0.2 | +0.8 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +48.9 | 0.0 | 0.0 | 0.4 | +31.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +27.8 | 0.0 | 13.9 | 0.9 | +57.0 | 0.0 | 20.0 |
| MARCH OF THE TABLE | 0.2 | +3.1 | 0.0 | 0.0 | 0.2 | +5.3 | 0.0 | 4.5 |
| MARCH OVER CASTS | 0.7 | +5.4 | 0.0 | 11.6 | 0.8 | +9.2 | 0.0 | 27.1 |
| MARCH WHEELS ONLY | 1.5 | +0.0 | 0.0 | 8.2 | 0.8 | +0.0 | 0.0 | 1.7 |
| MAX FOR POSITIONING | 2.7 | +61.2 | 0.0 | 30.1 | 2.9 | +66.3 | 0.0 | 38.9 |
| MISSILES IN THE MOVE | 4.5 | +167.3 | 0.0 | 100.6 | 3.3 | +44.9 | 0.0 | 52.9 |
| MISSILES NEXT TURN | 6.0 | +123.0 | 0.0 | 140.1 | 4.8 | +40.5 | 0.0 | 96.2 |
| MISSILES ON ONE TARGET | 0.2 | -4.2 | 0.0 | 4.9 | - | - | - | - |
| MODEL FACING | 0.2 | +62.4 | 0.0 | 1.7 | - | - | - | - |
| MOVE ORDER | 1.6 | +0.0 | 16.2 | 14.6 | 2.7 | +0.0 | 29.0 | 23.3 |
| MOVE SPELL IN RANGE | 0.2 | +8.7 | 0.0 | 10.9 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -7.5 | 0.0 | 32.6 | 0.3 | -14.8 | 3.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 24.8 | 0.3 | +0.0 | 0.0 | 11.4 |
| MOVE TO CHARGE COMPUTED | 5.9 | +545.5 | 0.0 | 64.1 | 7.0 | +720.1 | 0.0 | 92.5 |
| MOVES UNITS SPELL | 0.1 | +3.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.4 | +314.1 | 0.0 | 106.1 | 6.6 | +273.7 | 0.0 | 89.0 |
| NEXT CHARGE BY LIST | 5.2 | -208.3 | 29.9 | 99.3 | 6.4 | -319.7 | 13.1 | 133.1 |
| NEXT OBJECTIVE NEARER | 0.1 | -3.4 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.1 | -72.5 | 143.6 | 84.3 | 3.1 | -124.0 | 334.3 | 28.1 |
| NO LATE CUT | 0.9 | +0.0 | 0.0 | 5.3 | 0.7 | +0.0 | 0.0 | 1.7 |
| NO RALLY LEFT | 0.1 | +4.1 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| NOT TURNED | 0.2 | -0.2 | 0.0 | 6.0 | 0.3 | -2.0 | 0.0 | 4.4 |
| NOT WORTH A CAST | 0.5 | -0.2 | 0.0 | 0.0 | 0.7 | -0.8 | 0.0 | 6.7 |
| OFF BEST | 3.6 | -168.4 | 1.9 | 37.1 | 4.2 | -135.8 | 7.2 | 40.3 |
| ONE CHARGE A CHARGER | 4.0 | +0.0 | 0.0 | 204.1 | 3.5 | +0.0 | 0.0 | 67.2 |
| ONE FIGHT FORMULA | 3.9 | -73.7 | 0.0 | 53.0 | 4.1 | -107.5 | 0.0 | 66.6 |
| ONE OBJECTIVE FORMULA | 4.4 | +57.1 | 0.0 | 84.3 | 3.8 | +55.1 | 0.0 | 32.4 |
| ONE PROMISE A TARGET | 0.1 | -6.5 | 0.0 | 0.0 | 0.1 | -10.7 | 0.0 | 0.0 |
| ONE ROUTE | 1.5 | +0.0 | 0.0 | 8.2 | 0.8 | +0.0 | 0.0 | 1.7 |
| ONE TARGET A SHOOTER | 23.1 | +496.0 | 0.0 | 393.5 | 32.5 | +905.8 | 0.0 | 366.9 |
| OPENS A LANE | 0.3 | +0.7 | 56.6 | 0.0 | 0.2 | +1.0 | 26.7 | 10.5 |
| OPENS UP | 0.3 | +23.0 | 11.5 | 0.0 | 0.5 | +36.2 | 22.2 | 0.0 |
| OVERRUNS AWAY | 0.6 | +19.4 | 48.3 | 27.9 | 0.5 | +25.0 | 44.3 | 3.8 |
| OWN CAST FIRST | 0.1 | -0.3 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 5.7 |
| PATHS CROSS | 0.3 | +17.2 | 0.0 | 1.6 | 0.5 | +13.7 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.1 | -0.9 | 0.0 | 13.7 | 0.1 | -3.2 | 0.0 | 2.1 |
| PLAN RESULT | 40.3 | +879.2 | 420.9 | 834.5 | 40.1 | +481.7 | 274.1 | 682.7 |
| PROMISE BELOW ZERO | 0.2 | +0.0 | 0.0 | 1.7 | 0.1 | +0.0 | 0.0 | 3.3 |
| PROMISE BY ITS OWN SUM | 8.7 | -250.6 | 0.0 | 11.3 | 9.1 | -301.3 | 0.0 | 26.8 |
| PROMISE IN STEPS | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.5 | -1.6 | 0.0 | 0.0 | 0.6 | -0.9 | 0.0 | 12.1 |
| PROMISE READS THE TABLE | 0.3 | -5.1 | 0.0 | 8.1 | 0.2 | -7.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.2 | -2.5 | 21.5 | 0.0 | - | - | - | - |
| QUARTER ODDS | 18.8 | +1847.4 | 123.9 | 199.9 | 14.6 | +1754.1 | 43.5 | 76.7 |
| RANDOM MOVE BY FIGURES | 0.9 | +10.1 | 0.0 | 16.9 | 1.6 | +30.1 | 0.0 | 34.0 |
| REAL GROUND | 1.5 | +0.0 | 0.0 | 8.2 | 0.8 | +0.0 | 0.0 | 1.7 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -9.9 | 0.0 | 15.6 | 1.7 | -63.8 | 0.0 | 42.3 |
| REDIRECT COUNTER | 1.7 | +91.2 | 0.0 | 42.0 | 2.9 | +162.4 | 0.0 | 48.5 |
| REDIRECT WEIGHED | 0.2 | +3.4 | 1.9 | 3.4 | 0.2 | -2.4 | 4.1 | 8.7 |
| REFORMS TO MEET IT | 1.4 | -36.9 | 0.0 | 46.9 | 1.5 | -57.0 | 0.0 | 12.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 13.8 | 0.3 | +0.0 | 0.0 | 21.8 |
| RESERVE FALL BACK | 0.5 | +19.2 | 0.0 | 6.6 | 0.8 | +27.9 | 0.0 | 15.9 |
| RESTRAINS TO SHOOT | 0.1 | +2.1 | 0.0 | 0.0 | 0.0 | +3.8 | 0.0 | 2.1 |
| RISK BY ARC | 2.0 | +49.2 | 143.5 | 82.6 | 2.3 | +28.4 | 251.0 | 29.1 |
| RISK BY HIS FIGURE | 20.4 | -305.3 | 0.0 | 536.4 | 19.1 | -282.9 | 0.0 | 387.1 |
| RISK ON THE WAY | 0.6 | +0.0 | 0.0 | 5.3 | 0.4 | +0.0 | 0.0 | 1.7 |
| ROUNDS AFTER TERROR | 0.3 | -6.8 | 11.4 | 0.0 | 1.2 | -26.6 | 132.4 | 1.4 |
| RUN DOWN | 1.7 | -13.6 | 101.9 | 36.3 | 2.5 | -35.8 | 272.2 | 22.6 |
| SAFER THAN THE JOB | 0.0 | +0.5 | 0.0 | 0.0 | 0.1 | +5.4 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.0 | -1.0 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -4.5 | 0.0 | 2.3 | 0.5 | -27.8 | 0.0 | 7.1 |
| SEARCH SPOT | 0.5 | +4.9 | 0.0 | 2.2 | 0.3 | +3.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.4 | +21.2 | 16.5 | 13.5 | 0.3 | +46.8 | 35.9 | 0.0 |
| SELF MOVE SPELL | 0.5 | +29.4 | 0.0 | 9.3 | 0.3 | +61.4 | 0.0 | 18.6 |
| SET UP BY THE SET | 1.9 | +87.1 | 8.1 | 11.1 | 2.1 | +44.6 | 0.0 | 13.6 |
| SET UP TOGETHER | 0.2 | +1.9 | 0.0 | 0.0 | 0.3 | +4.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +58.9 | 35.3 | 26.6 | 0.0 | +1.9 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +8.2 | 0.0 | 0.0 | 0.0 | +4.6 | 4.5 | 7.8 |
| SHOOTER COUNTED ONCE | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.9 | +97.0 | 75.3 | 33.3 | 1.7 | +53.2 | 66.6 | 3.9 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.2 | -14.3 | 30.9 | 3.6 | 0.3 | -6.1 | 26.3 | 7.4 |
| SHOT RISK POINTS | 18.7 | +74.5 | 0.0 | 354.0 | 22.9 | -77.2 | 0.0 | 379.0 |
| SHOTS AFTER THE MOVES | 3.2 | +0.0 | 0.0 | 0.0 | 1.9 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +615.3 | 0.0 | 206.1 | 11.1 | +261.8 | 0.0 | 139.6 |
| SPELL SETS UP CHARGE | 0.4 | +65.8 | 46.1 | 37.4 | 0.0 | +1.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.6 | +26.7 | 86.5 | 93.0 | 2.4 | +30.1 | 52.2 | 43.3 |
| SPELLS IN THE FIGHT | 0.4 | +3.2 | 33.2 | 16.0 | 0.5 | -7.7 | 58.8 | 1.9 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 128.0 | 10.1 | +0.0 | 0.0 | 166.8 |
| STAND AND SHOOT | 0.5 | -6.8 | 16.2 | 8.5 | 0.5 | -5.0 | 31.5 | 10.6 |
| STANDS FOR A REASON | 0.5 | +0.0 | 1.6 | 19.6 | 1.7 | +0.0 | 19.1 | 34.1 |
| STANDS STILL | 43.7 | +0.0 | 1327.2 | 445.9 | 26.8 | +0.0 | 418.0 | 241.1 |
| STAY WORTH | 24.1 | -66.7 | 937.5 | 222.3 | 13.2 | +58.5 | 232.4 | 134.3 |
| STOPS | - | - | - | - | 0.1 | +2.3 | 11.9 | 5.5 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 9.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.1 | +440.2 | 0.0 | 89.3 | 6.4 | +371.3 | 0.0 | 40.9 |
| SUPPORT NARROWED | 0.3 | +0.0 | 24.0 | 16.8 | 0.2 | +0.0 | 19.5 | 0.0 |
| SUPPORT WORKED OUT | 6.1 | +440.2 | 0.0 | 89.3 | 6.4 | +371.3 | 0.0 | 40.9 |
| SURE REACH TOGETHER | 0.1 | +0.3 | 0.0 | 0.0 | 0.3 | +2.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.5 | +0.0 | 0.0 | 1.6 | 1.5 | +0.0 | 0.0 | 10.5 |
| THE PROMISE ADDS | 0.1 | -8.0 | 0.0 | 4.8 | 0.1 | -10.7 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.9 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 28.3 | +0.0 | 0.0 | 410.8 | 33.1 | +0.0 | 0.0 | 326.5 |
| TIED UP BY THE SUM | 0.7 | +66.8 | 33.3 | 0.0 | 1.1 | +118.6 | 98.1 | 0.0 |
| TIME ON OUR SIDE | 29.8 | +365.7 | 46.5 | 310.3 | 15.7 | +166.2 | 64.2 | 113.4 |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 18.1 | 1.5 | +0.0 | 0.0 | 10.3 |
| WALKS ON ITS ROUTE | 0.1 | -0.4 | 0.0 | 3.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 6.1 | 8.9 | 0.1 | +0.0 | 10.6 | 0.0 |
| WHAT THE JOINER ADDS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +1.7 | 11.1 | 1.4 |
| WHO GETS IN | 0.0 | +1.7 | 0.0 | 0.0 | 0.1 | +5.5 | 0.0 | 1.9 |
| WHO HITS BACK | 0.1 | +23.9 | 0.0 | 0.0 | 0.3 | +15.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +0.6 | 0.0 | 0.0 | 0.1 | +1.1 | 5.6 | 1.4 |
| WHOLE FIGHT GAIN | 0.1 | +1.1 | 2.0 | 0.0 | 0.1 | +3.1 | 17.4 | 0.0 |
| WIDER SPREAD | 1.7 | -4.5 | 120.7 | 37.2 | 2.3 | -6.4 | 207.5 | 27.4 |
| WOUNDS ON THE RANKS | 2.2 | +52.6 | 0.0 | 115.3 | 2.5 | +96.3 | 0.0 | 12.5 |

### Rule changes: base-s1-882d875-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2507 | 2507 | 1609 | 45.97 | +0 | +0.0 |
| HIS MOVE WHY | 2487 | 2487 | 1402 | 40.06 | +0 | +0.0 |
| ARMY TABLE | 1201 | 1201 | 812 | 23.20 | +17415 | +21.4 |
| HIS SHOT LIST | 2680 | 2558 | 656 | 18.74 | +11784 | +18.0 |
| HOLDER ASSIGNMENT | 692 | 692 | 642 | 18.34 | +40225 | +62.7 |
| ONE TARGET A SHOOTER | 1946 | 1833 | 384 | 10.97 | +3998 | +10.4 |
| LEGAL CHARGES ONLY | 335 | 335 | 335 | 9.57 | +0 | +0.0 |
| DEPLOY BY FIGURES | 537 | 537 | 323 | 9.23 | +4414 | +13.7 |
| HIS ONE MOVE | 1336 | 1279 | 288 | 8.23 | +224 | +0.8 |
| THE TABLE AGAIN | 417 | 417 | 275 | 7.86 | +0 | +0.0 |
| OFF BEST | 271 | 271 | 271 | 7.74 | -10645 | -39.3 |
| FIVE ACTION | 5959 | 5726 | 252 | 7.20 | +13261 | +52.6 |
| PROMISE BY ITS OWN SUM | 620 | 620 | 232 | 6.63 | -19315 | -83.3 |
| TIME ON OUR SIDE | 1592 | 1424 | 231 | 6.60 | +1257 | +5.4 |
| MOVE TO CHARGE COMPUTED | 452 | 380 | 221 | 6.31 | +12032 | +54.4 |
| SHOT RISK POINTS | 1454 | 1387 | 174 | 4.97 | +4538 | +26.1 |
| MOVE ORDER | 152 | 152 | 152 | 4.34 | +0 | +0.0 |
| QUARTER ODDS | 1168 | 1100 | 150 | 4.29 | +13562 | +90.4 |
| SUPPORT ADDS | 435 | 427 | 145 | 4.14 | +6511 | +44.9 |
| SUPPORT WORKED OUT | 435 | 427 | 145 | 4.14 | +6511 | +44.9 |
| HARD STAY DROPPED | 114 | 114 | 114 | 3.26 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 158 | 158 | 97 | 2.77 | +1062 | +10.9 |
| FOUR ROUNDS | 220 | 202 | 95 | 2.71 | +3649 | +38.4 |
| IDLE COST | 510 | 388 | 73 | 2.09 | +658 | +9.0 |
| ADVANCE LANE KEPT | 66 | 66 | 66 | 1.89 | +0 | +0.0 |
| LANE BY FIGURES | 64 | 64 | 64 | 1.83 | +2412 | +37.7 |
| CHAFF IN THE MOVE | 75 | 71 | 63 | 1.80 | +244 | +3.9 |
| ARTILLERY RE-ROLL WEIGHED | 62 | 62 | 62 | 1.77 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 58 | 58 | 58 | 1.66 | +9026 | +155.6 |
| STAY WORTH | 1304 | 1203 | 58 | 1.66 | +1304 | +22.5 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 1.63 | +0 | +0.0 |
| CHARGE LOSSES | 734 | 698 | 56 | 1.60 | +5945 | +106.2 |
| MAX FOR POSITIONING | 196 | 180 | 55 | 1.57 | +478 | +8.7 |
| RANDOM MOVE BY FIGURES | 88 | 88 | 51 | 1.46 | +1407 | +27.6 |
| RISK BY HIS FIGURE | 1385 | 1314 | 50 | 1.43 | +5457 | +109.1 |
| SET UP BY THE SET | 139 | 138 | 50 | 1.43 | +4414 | +88.3 |
| COVER ONCE | 374 | 252 | 48 | 1.37 | +1224 | +25.5 |
| TIED UP BY THE SUM | 63 | 52 | 46 | 1.31 | +1417 | +30.8 |
| FALLS SHORT | 673 | 573 | 44 | 1.26 | +289 | +6.6 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.26 | +1647 | +37.4 |
| JOINT CHARGE NOW | 43 | 43 | 43 | 1.23 | +1206 | +28.1 |
| CAST JOB | 69 | 69 | 40 | 1.14 | +459 | +11.5 |
| MARCH CHECK | 53 | 50 | 38 | 1.09 | +784 | +20.6 |
| FEATURE BUFFS | 155 | 154 | 36 | 1.03 | +916 | +25.4 |
| HOLDS AMBUSHERS | 36 | 36 | 36 | 1.03 | +0 | +0.0 |
| RISK BY ARC | 152 | 140 | 35 | 1.00 | +641 | +18.3 |
| CHARGE NOW FIRST | 120 | 120 | 34 | 0.97 | -2383 | -70.1 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.94 | +2259 | +68.5 |
| REDIRECT COUNTER | 159 | 128 | 31 | 0.89 | +2249 | +72.6 |
| MISSILES IN THE MOVE | 272 | 171 | 28 | 0.80 | +830 | +29.6 |
| PATHS CROSS | 28 | 28 | 28 | 0.80 | +1083 | +38.7 |
| SHOTS IN THE MOVE | 937 | 717 | 28 | 0.80 | +1008 | +36.0 |
| MARCH BY THE SUM | 27 | 27 | 27 | 0.77 | +2822 | +104.5 |
| CANNON PLANNED TARGET | 218 | 218 | 26 | 0.74 | +32 | +1.2 |
| NEARER NOT NEEDED | 491 | 477 | 26 | 0.74 | +728 | +28.0 |
| NEXT CHARGE BY LIST | 405 | 370 | 26 | 0.74 | +804 | +30.9 |
| SCOUT WAITS | 25 | 25 | 25 | 0.71 | +0 | +0.0 |
| SECOND LOOK | 24 | 24 | 24 | 0.69 | +2378 | +99.1 |
| SHOOTERS IN TWO RANKS | 21 | 21 | 21 | 0.60 | +49 | +2.3 |
| WOUNDS ON THE RANKS | 164 | 157 | 21 | 0.60 | +245 | +11.7 |
| HIS TURN DENIED | 100 | 91 | 20 | 0.57 | +976 | +48.8 |
| SHOTS AFTER THE MOVES | 177 | 177 | 20 | 0.57 | +0 | +0.0 |
| SEARCH SPOT | 26 | 26 | 19 | 0.54 | +302 | +15.9 |
| COMBAT PIVOT | 18 | 18 | 18 | 0.51 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 287 | 229 | 17 | 0.49 | +1188 | +69.9 |
| FIRE IN ORDER | 16 | 16 | 16 | 0.46 | +0 | +0.0 |
| GUN MASK | 93 | 89 | 16 | 0.46 | +586 | +36.6 |
| OPENS UP | 27 | 24 | 16 | 0.46 | +480 | +30.0 |
| CHAFF PASSED | 15 | 15 | 15 | 0.43 | -21 | -1.4 |
| MARCH OF THE TABLE | 13 | 13 | 13 | 0.37 | -294 | -22.6 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.37 | +1104 | +84.9 |
| STUCK PIVOT | 13 | 13 | 13 | 0.37 | +0 | +0.0 |
| WHO HITS BACK | 13 | 13 | 13 | 0.37 | +1004 | +77.2 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.34 | +0 | +0.0 |
| CASTING BLOCK | 17 | 17 | 12 | 0.34 | +269 | +22.4 |
| OVERRUNS AWAY | 37 | 34 | 12 | 0.34 | +490 | +40.8 |
| HIS FIGHT TOGETHER | 111 | 107 | 10 | 0.29 | +101 | +10.1 |
| AFTERMATH IN POINTS | 9 | 9 | 9 | 0.26 | +1366 | +151.7 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.26 | +0 | +0.0 |
| MISSILES NEXT TURN | 379 | 241 | 9 | 0.26 | +47 | +5.2 |
| EDGE GIVE GROUND | 14 | 14 | 8 | 0.23 | +280 | +35.0 |
| HONEST WORTH | 197 | 179 | 8 | 0.23 | +82 | +10.3 |
| MODEL FACING | 8 | 8 | 8 | 0.23 | +2186 | +273.2 |
| PROMISE KNOWS THE FIGHT | 36 | 31 | 8 | 0.23 | -88 | -10.9 |
| HIS CHARGE DENIED | 16 | 16 | 7 | 0.20 | +431 | +61.6 |
| LOST AFTER ESCAPE | 121 | 115 | 7 | 0.20 | +31 | +4.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.20 | +141 | +20.1 |
| ONE FIGHT FORMULA | 281 | 128 | 7 | 0.20 | +13 | +1.9 |
| ONE PROMISE A TARGET | 7 | 7 | 7 | 0.20 | -602 | -86.0 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.20 | -146 | -20.8 |
| PROMISE SHOT AWAY | 7 | 7 | 7 | 0.20 | -88 | -12.6 |
| FALLBACK BY WORTH | 14 | 14 | 5 | 0.14 | +278 | +55.6 |
| FIGHT TO THE END | 53 | 48 | 5 | 0.14 | +176 | +35.2 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.14 | +128 | +25.5 |
| HIS MOVE AND SHOT | 228 | 220 | 5 | 0.14 | +44 | +8.8 |
| HUNT IN PAIRS | 19 | 10 | 5 | 0.14 | +131 | +26.1 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +189 | +37.9 |
| MANOEUVRE | 41 | 41 | 5 | 0.14 | +71 | +14.3 |
| REFUSING RETIRES | 16 | 16 | 5 | 0.14 | -1 | -0.2 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SURE REACH TOGETHER | 16 | 14 | 5 | 0.14 | +16 | +3.2 |
| AFTERMATH WITH FRIENDS | 4 | 4 | 4 | 0.11 | +177 | +44.2 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -416 | -104.0 |
| OWN CAST FIRST | 4 | 4 | 4 | 0.11 | -12 | -3.1 |
| WHAT THE JOINER ADDS | 11 | 9 | 4 | 0.11 | +87 | +21.7 |
| WHO GETS IN | 4 | 4 | 4 | 0.11 | +251 | +62.8 |
| FACES THE THREAT | 3 | 3 | 3 | 0.09 | +136 | +45.2 |
| FALL BACK GOOD ORDER | 155 | 140 | 3 | 0.09 | +20 | +6.7 |
| JOINT LOOK BACK | 3 | 3 | 3 | 0.09 | +198 | +65.9 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.09 | +110 | +36.6 |
| PROMISE READS THE TABLE | 19 | 19 | 3 | 0.09 | +138 | +46.0 |
| REFORMS TO MEET IT | 102 | 84 | 3 | 0.09 | +54 | +18.1 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.09 | +207 | +69.1 |
| SAFER THAN THE JOB | 3 | 3 | 3 | 0.09 | +206 | +68.7 |
| SPELLS IN THE FIGHT | 31 | 29 | 3 | 0.09 | +30 | +10.1 |
| SUPPORT NARROWED | 18 | 18 | 3 | 0.09 | -132 | -44.1 |
| WAR ENGINE JOBS | 13 | 13 | 3 | 0.09 | -45 | -14.9 |
| CHARGE NOT DECLARED | 2 | 2 | 2 | 0.06 | -136 | -67.8 |
| NO DOUBLE ROUNDS | 182 | 167 | 2 | 0.06 | +13 | +6.6 |
| RUN DOWN | 145 | 130 | 2 | 0.06 | +16 | +7.9 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.06 | -13 | -6.5 |
| WHOLE FIGHT | 6 | 5 | 2 | 0.06 | +11 | +5.4 |
| WHOLE FIGHT GAIN | 5 | 5 | 2 | 0.06 | +23 | +11.7 |
| WIDER SPREAD | 142 | 130 | 2 | 0.06 | +10 | +4.9 |
| BACKUP TARGETS | 18 | 7 | 1 | 0.03 | +3 | +2.6 |
| BEST FACING | 1 | 1 | 1 | 0.03 | +68 | +68.4 |
| BEST OVERALL | 1 | 1 | 1 | 0.03 | +93 | +93.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +21 | +21.3 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DENIED BY THE FIGHT | 32 | 31 | 1 | 0.03 | +29 | +28.9 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +24 | +23.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +48 | +47.5 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +4.8 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.03 | +58 | +58.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 17 | 12 | 1 | 0.03 | +4 | +4.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +56 | +56.5 |
| ROUNDS AFTER TERROR | 50 | 46 | 1 | 0.03 | +3 | +3.1 |
| ALREADY CARRIED | 7 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 11 | 10 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 64 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 74 | 67 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 17 | 17 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 77 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 6 | 6 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 300 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 43 | 40 | 0 | 0.00 | - | - |
| GIVES UP | 24 | 21 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 45 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 238 | 234 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 303 | 292 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 328 | 294 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 265 | 240 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 132 | 131 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 240 | 233 | 0 | 0.00 | - | - |
| HOLD ODDS | 1178 | 1169 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 194 | 189 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 10 | 10 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 4 | not checked | - | - | - | - |
| LONG SHOT | 12 | 12 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 10 | 10 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 54 | 54 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 80 | 75 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 6 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 8 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 30 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 54 | 51 | 0 | 0.00 | - | - |
| NOT TURNED | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 39 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 262 | 255 | 0 | 0.00 | - | - |
| ONE ROUTE | 80 | 75 | 0 | 0.00 | - | - |
| PLAN RESULT | 2814 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 9 | 9 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 6 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 80 | 75 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 72 | 72 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 35 | 30 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 22 | 22 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 25 | not checked | - | - | - | - |
| SET UP TOGETHER | 16 | 12 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 19 | 19 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 15 | not checked | - | - | - | - |
| SPELL WORTH | 141 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 586 | 549 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 38 | 32 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 77 | 71 | 0 | 0.00 | - | - |
| STANDS STILL | 2467 | 2391 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 23 | 21 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 102 | not checked | - | - | - | - |
| THE PROMISE ADDS | 7 | 7 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2152 | not checked | - | - | - | - |
| WAITS AGAIN | 115 | 104 | 0 | 0.00 | - | - |

### Off best figure: base-s1-882d875-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.40 | 3.23 | 83.3 |
| JOB FIRST | gate | 2.66 | 3.40 | 35.6 |
| ARMY TABLE | rule | 1.51 | 1.66 | 50.9 |
| NO REASON | gate | 0.77 | 0.57 | 59.1 |
| HOLDER ASSIGNMENT | rule | 0.69 | 0.51 | 29.0 |
| CHARGE NOW FIRST | rule | 0.43 | 0.49 | 74.4 |
| JOINT CHARGE NOW | rule | 0.23 | 0.29 | 74.2 |
| MARCH OF THE TABLE | rule | 0.17 | 0.20 | 22.6 |
| CHAFF PASSED | rule | 0.17 | 0.09 | 2.3 |
| PROMISE KNOWS THE FIGHT | rule | 0.09 | 0.14 | 10.9 |
| ONE PROMISE A TARGET | rule | 0.09 | 0.11 | 86.0 |
| PIVOT GUARDS FLANK | rule | 0.09 | 0.11 | 20.8 |
| PROMISE SHOT AWAY | rule | 0.20 | - | 12.6 |
| AFTERMATH BAND | gate | 0.06 | 0.09 | 2.6 |
| BEST PRIZE | rule | 0.06 | 0.06 | 104.0 |
| OWN CAST FIRST | rule | 0.06 | 0.06 | 3.1 |
| PATHS CROSS | rule | 0.03 | 0.06 | 71.6 |
| SUPPORT NARROWED | rule | 0.06 | 0.03 | 44.1 |
| TURN GATE | gate | 0.03 | 0.06 | 25.6 |
| WAR ENGINE JOBS | rule | - | 0.09 | 14.9 |
| CHARGE NOT DECLARED | rule | - | 0.06 | 67.8 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.03 | 6.5 |
| FALLBACK | gate | - | 0.06 | 46.9 |
| CANNON PLANNED TARGET | rule | 0.03 | - | 16.8 |
| FIGHT ORDER BAND | gate | 0.03 | - | 4.3 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 3.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | - | 127.3 |
| WALKS ON ITS ROUTE | rule | 0.03 | - | 69.9 |

### Plans: base-s1-882d875-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.2 | 60% | 273 | 159 | 58% |
| Mine | join | 0.6 | 95% | 20 | 0 | 0% |
| Mine | move | 27.6 | 94% | 1672 | 0 | 0% |
| Mine | shoot | 9.5 | 58% | 535 | 721 | 135% |
| Mine | support | 0.3 | 58% | 3 | 0 | 0% |
| Opponent | charge | 3.0 | 66% | 570 | 297 | 52% |
| Opponent | join | 1.0 | 94% | 54 | 0 | 0% |
| Opponent | move | 31.5 | 94% | 1523 | 0 | 0% |
| Opponent | shoot | 3.5 | 41% | 189 | 184 | 97% |
| Opponent | support | 1.1 | 60% | 3 | 0 | 0% |

### Packages: hunt the guns, base-s1-882d875-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 14 |
| Opponent | 0.1 | 2 | 0 | 100% | 100% | 0% | 2.5 | 398 | 301 | 100% | 81 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 94 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 501 | 351 | 100% | 10 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 406 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 295 | 252 | 100% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |

### Battle groups: base-s1-882d875-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 36% | 62% | 5% | 0% | 5% | 0% | 5% | 75% | 15% |
| Opponent | REDIRECT COUNTER | 2.9 | 22% | 73% | 9% | 0% | 0% | 0% | 15% | 80% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s1-882d875-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | Chaff | 32 | 33 (32) | 4 | 29 | 62 | 41% | 2.8 | 50 (15) | 13 (9) | 15 (8) | 39 (24) | 16 (8) |
| Mine | Character | 117 | 30 (117) | 30 | 0 | 27 | 23% | 2.4 | 36 (48) | 31 (45) | 24 (12) | 35 (70) | 26 (35) |
| Mine | Clean-up | 19 | 30 (19) | 5 | 25 | 30 | 58% | 3.0 | 24 (7) | 38 (9) | 17 (3) | 44 (12) | 7 (7) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 43 | 37 (43) | 22 | 15 | 39 | 44% | 2.5 | 28 (18) | 15 (17) | 105 (8) | 48 (28) | 14 (15) |
| Mine | Hammer | 52 | 25 (52) | 12 | 13 | 28 | 21% | 2.6 | 36 (17) | 23 (26) | 13 (9) | 27 (36) | 22 (16) |
| Mine | Holder | 26 | 53 (26) | 6 | 47 | 27 | 54% | 3.2 | 2 (11) | 88 (9) | 98 (5) | 43 (14) | 72 (11) |
| Mine | Infantry | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Shooter | 33 | 61 (33) | 27 | 33 | 34 | 15% | 1.9 | 47 (12) | 75 (16) | 46 (5) | 61 (27) | 60 (6) |
| Mine | Support | 1 | 18 (1) | 18 | 0 | 0 | 0% | 3.0 | - | 18 (1) | - | - | 18 (1) |
| Mine | War machine | 52 | 43 (52) | 43 | 0 | 27 | 4% | 1.7 | 41 (28) | 46 (24) | - | 47 (14) | 42 (38) |
| Mine | Wizard | 15 | 10 (15) | 10 | 0 | 60 | 27% | 2.5 | 36 (5) | 0 (6) | - | 31 (5) | 0 (6) |
| Opponent | Chaff | 68 | 57 (68) | 11 | 47 | 60 | 54% | 2.5 | 33 (28) | 68 (26) | 88 (14) | 68 (53) | 14 (15) |
| Opponent | Character | 97 | 48 (97) | 46 | 2 | 16 | 26% | 2.2 | 31 (35) | 49 (40) | 86 (16) | 59 (49) | 40 (42) |
| Opponent | Clean-up | 13 | 33 (13) | 2 | 30 | 16 | 62% | 3.0 | 0 (6) | 58 (6) | 47 (1) | 40 (9) | 22 (4) |
| Opponent | Fast | 1 | 208 (1) | 208 | 0 | 100 | 0% | 3.0 | - | 208 (1) | - | 208 (1) | - |
| Opponent | Fast Hammer | 58 | 24 (58) | 9 | 15 | 40 | 40% | 2.7 | 17 (19) | 27 (30) | 31 (9) | 37 (29) | 11 (29) |
| Opponent | Hammer | 46 | 27 (46) | 16 | 11 | 24 | 48% | 3.4 | 6 (12) | 36 (27) | 6 (7) | 18 (29) | 41 (17) |
| Opponent | Holder | 37 | 92 (37) | 3 | 90 | 11 | 46% | 2.5 | 84 (13) | 151 (14) | 26 (9) | 114 (25) | 46 (11) |
| Opponent | Shooter | 30 | 62 (30) | 30 | 32 | 33 | 0% | 1.5 | 58 (12) | 41 (14) | 147 (4) | 53 (22) | 88 (8) |
| Opponent | Support | 5 | 0 (5) | 0 | 0 | 28 | 100% | - | - | 0 (2) | 0 (2) | - | 0 (4) |
| Opponent | War machine | 17 | 24 (17) | 24 | 0 | 40 | 6% | 1.6 | 28 (11) | 0 (4) | 50 (2) | 0 (3) | 27 (14) |
| Opponent | Wizard | 32 | 0 (32) | 0 | 0 | 42 | 22% | 2.5 | 0 (11) | 0 (12) | 0 (1) | 0 (10) | 0 (14) |

### Charged fights: base-s1-882d875-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 26 | 26 | 0.5 | 1.0 | 52 | 0 | +52 | 0 of 2 | 2 of 2 | - | +52 |
| Mine | Chaos Dwarfs | 4 | 245 | 68 | 0.8 | 1.0 | 90 | 0 | +90 | 1 of 3 | 2 of 3 | - | +90 |
| Mine | Dwarfen Mountain Holds | 3 | 468 | 161 | 0.7 | 1.0 | 242 | 0 | +242 | 0 of 2 | 2 of 2 | - | +242 |
| Mine | Empire of Man | 5 | 279 | 25 | 1.0 | 1.0 | 25 | 0 | +25 | 1 of 5 | 3 of 5 | - | +25 |
| Mine | Grand Cathay | 5 | 236 | 138 | 2.0 | 1.1 | 69 | 0 | +69 | 1 of 10 | 10 of 10 | +0 | +77 |
| Mine | High Elf Realms | 4 | 149 | 607 | 3.2 | 1.0 | 187 | 0 | +187 | 5 of 13 | 12 of 13 | - | +187 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 464 | 2.0 | 1.0 | 232 | 0 | +232 | 1 of 2 | 1 of 2 | - | +232 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 579 | 4.0 | 1.0 | 145 | 0 | +145 | 1 of 4 | 4 of 4 | - | +145 |
| Mine | Skaven | 1 | 104 | 0 | 1.0 | 1.0 | 0 | 35 | -35 | 0 of 1 | 0 of 1 | - | -35 |
| Mine | Tomb Kings of Khemri | 2 | 98 | 242 | 4.0 | 1.1 | 60 | 0 | +60 | 1 of 8 | 7 of 8 | +45 | +63 |
| Mine | Vampire Counts | 2 | 104 | 178 | 3.5 | 1.3 | 51 | 0 | +51 | 1 of 7 | 6 of 7 | +178 | +0 |
| Mine | Warriors of Chaos | 2 | 10 | 104 | 2.0 | 1.0 | 52 | 0 | +52 | 2 of 4 | 3 of 4 | - | +52 |
| **Mine** | all armies | 35 | 177 | 177 | 1.8 | 1.1 | 100 | 1 | +99 | 14 of 62 | 52 of 62 | +100 | +99 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 179 | 718 | 3.3 | 1.3 | 215 | 0 | +215 | 5 of 10 | 10 of 10 | +493 | +146 |
| Opponent | High Elf Realms | 3 | 235 | 151 | 2.0 | 1.0 | 75 | 35 | +40 | 4 of 6 | 3 of 6 | - | +40 |
| Opponent | Kingdom of Bretonnia | 2 | 141 | 162 | 2.0 | 1.0 | 81 | 0 | +81 | 1 of 4 | 3 of 4 | - | +81 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 1079 | 2.0 | 1.0 | 540 | 0 | +540 | 2 of 2 | 1 of 2 | - | +540 |
| Opponent | Skaven | 1 | 60 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 120 | 495 | 3.0 | 1.2 | 165 | 6 | +159 | 6 of 12 | 9 of 12 | +222 | +146 |
| Opponent | Vampire Counts | 6 | 14 | 226 | 2.7 | 1.2 | 85 | 43 | +42 | 11 of 16 | 11 of 16 | +127 | +22 |
| Opponent | Warriors of Chaos | 8 | 34 | 477 | 3.2 | 1.1 | 147 | 17 | +130 | 10 of 26 | 19 of 26 | +172 | +126 |
| Opponent | Wood Elf Realms | 6 | 166 | 226 | 2.2 | 1.0 | 104 | 26 | +79 | 4 of 13 | 8 of 13 | - | +79 |
| **Opponent** | all armies | 35 | 98 | 358 | 2.6 | 1.1 | 138 | 19 | +118 | 43 of 91 | 65 of 91 | +240 | +105 |

### Effective charges: base-s1-882d875-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 1 (net +60) | 1 (net +45) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Chaos Dwarfs | 3 | 0 | 0 | 0 | 0 | 1 (net +120) | 0 | 2 | 0% (0 of 1) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 1 (net +287) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Empire of Man | 5 | 1 (net +0) | 0 | 0 | 2 (net +62) | 0 | 1 (net +0) | 1 | 0% (0 of 4) |
| Mine | Grand Cathay | 10 | 0 | 0 | 0 | 2 (net +118) | 3 (net +105) | 2 (net +36) | 3 | 0% (0 of 7) |
| Mine | High Elf Realms | 13 | 2 (net +190) | 0 | 3 (net +155) | 2 (net +0) | 3 (net +73) | 0 | 3 | 30% (3 of 10) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +135) | 3 | 0% (0 of 1) |
| Mine | Skaven | 1 | 1 (net -35) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 8 | 2 (net +0) | 0 | 0 | 1 (net +66) | 3 (net +55) | 1 (net +66) | 1 | 0% (0 of 7) |
| Mine | Vampire Counts | 7 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 3 (net +118) | 1 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 2 (net +104) | 2 (net +0) | 0 | 0 | 0 | 50% (2 of 4) |
| Opponent | Grand Cathay | 10 | 0 | 0 | 1 (net +0) | 2 (net +65) | 2 (net +75) | 4 (net +468) | 1 | 11% (1 of 9) |
| Opponent | High Elf Realms | 6 | 3 (net +22) | 0 | 1 (net +0) | 1 (net -151) | 0 | 1 (net +327) | 0 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 2 (net +106) | 1 (net +113) | 0 | 0 | 0 | 1 | 33% (1 of 3) |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 1 (net +482) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 12 | 2 (net +46) | 1 (net +122) | 0 | 3 (net +244) | 2 (net +222) | 4 (net +129) | 0 | 0% (0 of 12) |
| Opponent | Vampire Counts | 16 | 5 (net -59) | 1 (net -68) | 0 | 3 (net +127) | 2 (net +78) | 4 (net +104) | 1 | 0% (0 of 15) |
| Opponent | Warriors of Chaos | 26 | 2 (net -102) | 1 (net +0) | 2 (net +20) | 6 (net +294) | 3 (net +93) | 5 (net +161) | 7 | 11% (2 of 19) |
| Opponent | Wood Elf Realms | 13 | 1 (net -126) | 0 | 1 (net +60) | 1 (net +60) | 0 | 1 (net +470) | 9 | 25% (1 of 4) |

### Charged fights, damage counted: base-s1-882d875-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 288 | 296 | +58 | 79 | 6 | +73 | +25.5 |
| Mine | 50-54% | 1 | 52 | 60 | +60 | 60 | 0 | +60 | +115.4 |
| Mine | Effective (55-75%) | 9 | 245 | 184 | +112 | 141 | 0 | +141 | +57.6 |
| Mine | 76-89% | 10 | 260 | 185 | +43 | 74 | 33 | +41 | +15.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 356 | 139 | +78 | 107 | 6 | +101 | +28.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 414 | 73 | +74 | 97 | 5 | +92 | +22.3 |
| Mine | No odds | 17 | 276 | 140 | +167 | 184 | 26 | +157 | +57.2 |
| Mine | All fights | 62 | 301 | 155 | +99 | 122 | 15 | +108 | +35.8 |
| Opponent | Long shot (under 50%) | 14 | 185 | 250 | -33 | 46 | 85 | -39 | -21.0 |
| Opponent | 50-54% | 6 | 261 | 242 | +125 | 138 | 36 | +102 | +39.1 |
| Opponent | Effective (55-75%) | 6 | 269 | 159 | +36 | 58 | 58 | -0 | -0.1 |
| Opponent | 76-89% | 17 | 303 | 246 | +172 | 198 | 26 | +173 | +57.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 306 | 214 | +232 | 279 | 48 | +231 | +75.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 510 | 110 | +114 | 114 | 8 | +106 | +20.8 |
| Opponent | No odds | 20 | 230 | 244 | +96 | 138 | 36 | +102 | +44.4 |
| Opponent | All fights | 91 | 285 | 220 | +118 | 157 | 43 | +114 | +40.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s1-882d875-p3 | move | 211 | 51 (24%) | 31 (15%) | 29 (14%) | 131 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: base-s2-882d875-p6

### Scorecard: base-s2-882d875-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 2 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0108 | 6 | 2 | Opponent | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 211 |
| L0124 | 4 | 2 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 322 |
| L0124 | 4 | 2 | Opponent | no | 0 | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0208 | 4 | 2 | Mine | no | 0 | 4 | 0 | 5 | 1 | 0 | 0 | 104 |
| L0208 | 4 | 2 | Opponent | no | 2 | 4 | 1 | 1 | 0 | 0 | 0 | 81 |
| L0224 | 2 | 2 | Mine | - | - | - | 4 | 3 | 0 | 0 | 0 | 170 |
| L0224 | 2 | 2 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0309 | 3 | 2 | Mine | no | 4 | - | 2 | 3 | 0 | 0 | 0 | 230 |
| L0309 | 3 | 2 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 250 |
| L0325 | 1 | 2 | Mine | no | 6 | 4 | 0 | 1 | 0 | 0 | 0 | 315 |
| L0325 | 1 | 2 | Opponent | no | 5 | 3 | 3 | 4 | 1 | 0 | 0 | 75 |
| L0411 | 3 | 2 | Mine | yes | 20 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 2 | Opponent | no | 10 | 4 | 1 | 0 | 1 | 0 | 0 | 165 |
| L0427 | 1 | 2 | Mine | no | 5 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 2 | Opponent | yes | 0 | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0514 | 4 | 2 | Mine | no | 3 | 6 | 1 | 1 | 0 | 0 | 0 | 1068 |
| L0514 | 4 | 2 | Opponent | yes | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0530 | 2 | 2 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 408 |
| L0530 | 2 | 2 | Opponent | - | - | - | 0 | 6 | 0 | 0 | 0 | 0 |
| L0618 | 6 | 2 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 779 |
| L0618 | 6 | 2 | Opponent | no | 9 | - | 1 | 1 | 0 | 0 | 0 | 225 |
| L0635 | 5 | 2 | Mine | no | - | - | 1 | 4 | 0 | 0 | 0 | 1077 |
| L0635 | 5 | 2 | Opponent | yes | - | 6 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0723 | 3 | 2 | Mine | no | 11 | 3 | 4 | 0 | 0 | 0 | 0 | 77 |
| L0723 | 3 | 2 | Opponent | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0813 | 3 | 2 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 170 |
| L0813 | 3 | 2 | Opponent | yes | 13 | 2 | 2 | 0 | 2 | 0 | 0 | 0 |
| L0829 | 1 | 2 | Mine | yes | 0 | - | 0 | 1 | 0 | 0 | 0 | 345 |
| L0829 | 1 | 2 | Opponent | no | 3 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0920 | 2 | 2 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 227 |
| L0920 | 2 | 2 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 275 |
| L1011 | 3 | 2 | Mine | yes | 11 | 2 | 4 | 0 | 0 | 0 | 0 | 165 |
| L1011 | 3 | 2 | Opponent | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1028 | 2 | 2 | Mine | - | - | 1 | 5 | 2 | 1 | 0 | 0 | 165 |
| L1028 | 2 | 2 | Opponent | - | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1120 | 4 | 2 | Mine | yes | 8 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1120 | 4 | 2 | Opponent | no | 0 | - | 4 | 2 | 2 | 0 | 0 | 0 |
| L1214 | 2 | 2 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 165 |
| L1214 | 2 | 2 | Opponent | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 286 |
| L1230 | 6 | 2 | Mine | no | 7 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1230 | 6 | 2 | Opponent | no | 7 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1325 | 5 | 2 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 412 |
| L1325 | 5 | 2 | Opponent | yes | - | 2 | 4 | 6 | 0 | 0 | 0 | 0 |
| L1420 | 4 | 2 | Mine | yes | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 151 |
| L1420 | 4 | 2 | Opponent | no | 1 | - | 0 | 1 | 1 | 0 | 0 | 1101 |
| L1517 | 5 | 2 | Mine | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1517 | 5 | 2 | Opponent | yes | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1533 | 3 | 2 | Mine | no | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1533 | 3 | 2 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 371 |
| L1631 | 5 | 2 | Mine | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 336 |
| L1631 | 5 | 2 | Opponent | yes | - | 2 | 2 | 2 | 1 | 0 | 0 | 170 |
| L1829 | 5 | 2 | Mine | yes | - | 6 | 2 | 1 | 0 | 0 | 0 | 111 |
| L1829 | 5 | 2 | Opponent | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 170 |
| L1929 | 3 | 2 | Mine | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 499 |
| L1929 | 3 | 2 | Opponent | no | 7 | 2 | 5 | 2 | 0 | 0 | 0 | 665 |
| L2031 | 3 | 2 | Mine | no | 4 | - | 1 | 2 | 1 | 0 | 0 | 485 |
| L2031 | 3 | 2 | Opponent | no | 0 | 6 | 2 | 0 | 2 | 0 | 0 | 170 |
| L2134 | 4 | 2 | Mine | no | 1 | - | 0 | 4 | 0 | 0 | 0 | 500 |
| L2134 | 4 | 2 | Opponent | no | 0 | 3 | 3 | 5 | 0 | 0 | 0 | 160 |
| L2325 | 3 | 2 | Mine | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 255 |
| L2325 | 3 | 2 | Opponent | no | 4 | 4 | 3 | 0 | 1 | 0 | 0 | 75 |
| L2431 | 1 | 2 | Mine | yes | 9 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2431 | 1 | 2 | Opponent | no | 3 | 3 | 2 | 1 | 1 | 0 | 0 | 927 |
| L2628 | 6 | 2 | Mine | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 60 |
| L2628 | 6 | 2 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 41 |
| L2830 | 4 | 2 | Mine | no | 12 | 5 | 1 | 1 | 0 | 0 | 0 | 168 |
| L2830 | 4 | 2 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 366 |
| L3035 | 5 | 2 | Mine | no | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L3035 | 5 | 2 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 352 |
| **Average** | | | Mine | 30% | 4.7 | 2.8 | 2.3 | 1.9 | 0.1 | 0.0 | 0.0 | 250.4 |
| **Average** | | | Opponent | 30% | 3.2 | 3.2 | 1.9 | 2.2 | 0.4 | 0.0 | 0.0 | 175.3 |

### KPIs: base-s2-882d875-p6

Morten 2026-11-10; 35 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (44 of 158) | 6% (10 of 161) | 17% (54 of 319) |
| Winner chose to follow up after the loser gave ground |  | 72% (33 of 46); on the table 80% | 95% (42 of 44); on the table 100% | 83% (75 of 90); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | 93% (14 of 15); on the table 93% | 0% (0 of 1); on the table 0% | 88% (14 of 16); on the table 88% |
| Winner chose to pursue after the loser fled |  | 69% (18 of 26); on the table 77% | 44% (7 of 16); on the table 50% | 60% (25 of 42); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 75% (65 of 87); on the table 82% | 80% (49 of 61); on the table 85% | 77% (114 of 148); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 25% (81 of 323) | 26% (41 of 157) | 25% (122 of 480) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 31% (75 of 243) | 39% (41 of 106) | 33% (116 of 349) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 42% (10 of 24) | 64% (41 of 64) | 58% (51 of 88) |
| Points that never fought | lower | 49% (33659 of 68457) | 49% (34531 of 69982) | 49% (68190 of 138439) |
|   infantry points that never fought | lower | 62% (9479 of 15282) | 62% (8543 of 13684) | 62% (18022 of 28966) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (170 of 268) | 71% (200 of 283) | 67% (370 of 551) |
| Bound items with a magic missile used (at least once a game) |  | 84% (21 of 25); 2.1 uses a game | 92% (12 of 13); 1.0 uses a game | 87% (33 of 38); 1.6 uses a game |
| Bound items with another spell used |  | 62% (8 of 13); 0.5 uses a game | 7% (1 of 14); 0.0 uses a game | 33% (9 of 27); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 52% (11 of 21); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 55% (18 of 33); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (33551 of 58430) | 65% (40969 of 62766) | 61% (74520 of 121196) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.9 (42%) | 1.0 (30%) | 3.9 (38%) |
| MARCHED: its unit marched | 1.2 (17%) | 0.7 (22%) | 1.9 (19%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.0 (1%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.5 (22%) | 0.5 (16%) | 2.0 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.5 (8%) | 0.9 (28%) | 1.5 (15%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.1 (2%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.1 | 2.5 | 3.5 | 0.5 | 1.4 |
| not cast | 4.1 | 2.5 | 3.7 | 10.2 | 2.3 | 20.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (55%) | 0.5 (15%) | 3.9 (38%) | 0.6 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (19%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.3 (12%) | 0.7 (18%) | 2.0 (20%) | 0.5 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.2 (7%) | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (1%) | 0.3 (2%) |
| GONE: slain | 1.1 (26%) | 0.2 (8%) | 0.7 (18%) | 1.5 (15%) | 0.3 (15%) | 2.8 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (3%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (7%) | 0.0 (1%) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (58%) | 0.1 (4%) | 1.3 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.5 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 0.9 a game | 1.3 a game |
| stood (cast and not dispelled) | 52% (28 of 54) | 65% (20 of 31) | 56% (48 of 85) |
| the unit moved after it | 50% (14 of 28) | 85% (17 of 20) | 65% (31 of 48) |
| it charged on its next turn | 4% (1 of 28) | 0% (0 of 20) | 2% (1 of 48) |
| the enemy charged it first | 18% (5 of 28) | 10% (2 of 20) | 15% (7 of 48) |
| it fought by the end of its next turn | 4% (1 of 28) | 5% (1 of 20) | 4% (2 of 48) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (4 of 28) | 0% (0 of 20) | 8% (4 of 48) |
| none of these (no charge, no fight, no charge escaped) | 64% (18 of 28) | 90% (18 of 20) | 75% (36 of 48) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (493 of 841) | 56% (302 of 542) | 57% (795 of 1383) |
|   cavalry | 54% (39 of 72) | 65% (75 of 115) | 61% (114 of 187) |
|   character | 49% (45 of 91) | 23% (19 of 84) | 37% (64 of 175) |
|   chariot | 58% (61 of 106) | 83% (24 of 29) | 63% (85 of 135) |
|   infantry | 54% (135 of 248) | 60% (118 of 197) | 57% (253 of 445) |
|   monster | 77% (23 of 30) | 55% (11 of 20) | 68% (34 of 50) |
|   war machine | 65% (190 of 294) | 57% (55 of 97) | 63% (245 of 391) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.2 (12%) | 1.1 (15%) | 2.3 (14%) |
| CHARGED: it charged | 0.9 (9%) | 0.8 (12%) | 1.7 (10%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.4 (4%) | 0.3 (5%) | 0.8 (5%) |
| MOVED: a war machine that moved | 1.7 (17%) | 0.8 (12%) | 2.5 (15%) |
| NO TARGET IN RANGE | 2.8 (28%) | 1.9 (28%) | 4.7 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (7%) | 0.4 (6%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (16%) | 1.0 (15%) | 2.6 (15%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.1 (1%) | 0.3 (2%) |
| OTHER BAR | 0.4 (4%) | 0.3 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.7 | 78% | 6.3 pts | 32 pts |
| character | 2.1 | 0.5 | 82% | 5.1 pts | 11 pts |
| chariot | 2.5 | 1.7 | 67% | 19.0 pts | 47 pts |
| infantry | 10.5 | 4.1 | 75% | 9.9 pts | 105 pts |
| monster | 1.2 | 0.3 | 76% | 6.6 pts | 8 pts |
| war machine | 7.0 | 5.5 | 68% | 21.5 pts | 150 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 3.0 | 3.3 |
| Charges that made contact a game | 2.9 | 2.2 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.21 declared, 0.92 contact (24 units) | 0.58 declared, 0.47 contact (19 units) | 0.93 declared, 0.72 contact (43 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.33 declared, 1.17 contact (6 units) | 1.46 declared, 1.00 contact (13 units) | 1.42 declared, 1.05 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.37 declared, 0.31 contact (236 units) | 0.28 declared, 0.21 contact (261 units) | 0.33 declared, 0.25 contact (497 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (46 of 69) | 88% (21 of 24) | 58% (7 of 12) | 70% (74 of 105) |
| Character in a unit | 89% (34 of 38) | 72% (21 of 29) | 100% (3 of 3) | 83% (58 of 70) |
| Character on its own | 88% (30 of 34) | 57% (16 of 28) | 34% (21 of 62) | 54% (67 of 124) |
| Chariot | 75% (9 of 12) | 79% (11 of 14) | - | 77% (20 of 26) |
| Infantry | 60% (50 of 83) | 61% (20 of 33) | 40% (2 of 5) | 60% (72 of 121) |
| Monster | 62% (13 of 21) | 67% (10 of 15) | - | 64% (23 of 36) |
| Monstrous | 100% (7 of 7) | 78% (7 of 9) | - | 88% (14 of 16) |
| War Machines | 78% (40 of 51) | 100% (2 of 2) | - | 79% (42 of 53) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 67% (4 of 6); on the table 83% | 26% (28 of 108) | 52% | 50% (11 of 22) | 83% (5 of 6); 4.5 uses a game | 100% (2 of 2); 2.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (11 of 11); on the table 100% | 19% (7 of 36) | 54% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 4 | 67% (2 of 3); on the table 67% | - | 75% | 82% (28 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 67% (4 of 6); on the table 83% | 43% (13 of 30) | 64% | 69% (51 of 74) | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game | 40% (2 of 5); 0.3 uses a game |
| Grand Cathay | 7 | 69% (11 of 16); on the table 69% | 23% (30 of 132) | 33% | 56% (32 of 57) | 81% (13 of 16); 6.0 uses a game | 50% (1 of 2); 0.4 uses a game | 14% (1 of 7); 0.3 uses a game |
| High Elf Realms | 7 | 81% (13 of 16); on the table 88% | 7% (2 of 30) | 44% | 54% (31 of 57) | 100% (6 of 6); 3.7 uses a game | 23% (5 of 22); 0.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 33% (1 of 3); on the table 67% | - | 52% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 59% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 67% (2 of 3); on the table 67% | 0% (0 of 6) | 65% | 64% (9 of 14) | 100% (2 of 2); 3.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 0% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 5 | 86% (6 of 7); on the table 86% | 25% (9 of 36) | 41% | 68% (25 of 37) | 100% (1 of 1); 0.2 uses a game | 0.0 uses a game | 100% (5 of 5); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 91% (10 of 11); on the table 100% | - | 25% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 70% (14 of 20); on the table 90% | 30% (16 of 54) | 53% | 74% (37 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 13 | 78% (28 of 36); on the table 78% | 36% (13 of 36) | 47% | 72% (73 of 101) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 100% (4 of 4); 0.3 uses a game |
| Wood Elf Realms | 4 | 67% (4 of 6); on the table 67% | 0% (0 of 6) | 49% | 79% (33 of 42) | 75% (3 of 4); 1.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s2-882d875-p6, 35 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (25) | 47% (31) | 47% (56) |
| ...free all their last turn and able to turn (per game) | 0.40 | 0.66 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.00 | 0.17 |
| ...with the charger already in that arc before they moved (per game) | 0.34 | 0.51 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.03 | 0.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 0.06 | 0.17 |

### Quality by phase: base-s2-882d875-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 70% (75 of 107) | 51% (48 of 94) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (121 of 398) | 38% (72 of 190) |
| Strategy | Support requests answered (helper made contact too) | 56% (5 of 9) | 57% (4 of 7) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (8 of 12) | 45% (5 of 11) |
| Strategy | Joined characters whose unit fought | 36% (20 of 55) | 26% (11 of 42) |
| Strategy | Lone characters that fought | 73% (57 of 78) | 66% (54 of 82) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.9 | 2.2 |
| Movement | Points that never moved of their own | 250.4 | 175.3 |
| Movement | Fights charged into per game | 2.7 | 1.9 |
| Movement | Charges with odds: long shots (under 50%) | 17 of 81, net +59 | 17 of 60, net +29 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 81, net +158 | 16 of 60, net +51 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 81, net +91 | 2 of 60, net +111 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 81, net +92 | 15 of 60, net +122 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.2 | 7.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (172 of 322) | 49% (137 of 277) |
| Shooting | Points destroyed by shooting units | 48.8 | 12.0 |
| Shooting | War machine shots | 5.4 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (105 of 190) | 56% (31 of 55) |
| Shooting | Points destroyed by war machines | 44.4 | 20.4 |
| Magic | Magic missiles cast | 1.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (13 of 47) | 13% (3 of 23) |
| Magic | Wounds caused by magic missiles | 2.6 | 1.1 |
| Magic | Wounds caused by other spells | 1.4 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 65.3 | 26.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.4 / 0.5 / 0.1 | 1.3 / 0.7 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 252.5 | 261.8 |
| Combat | Points run down | 87.2 | 38.1 |
| Combat | Net points per charged fight, damage counted | +97 | +72 |
| Combat | Net per 100 charger points, damage counted | +32.1 | +24.0 |
| Combat | First round won (charged fights) | 74% | 66% |
| Combat | Net points per charged fight | +91 | +72 |
| Combat | Net points per supported fight / lone fight | +98 / +90 | +260 / +53 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 93 | 35 of 68 |
| Game | Points lost | 444.3 | 603.7 |
| Game | VP from objectives | 696.6 | 599.1 |
| Game | Lone holders (player turns) | 4.7 | 3.2 |

- Mine won / drew / lost: 15 / 9 / 11 of 35 ended games (of 35); mean margin (Mine - Opponent) +266 VP
- The side that went first won 17 of 26 games with a winner
- Points traded per game (both sides' losses): 1048
- Games not ended: 0; findings 6, warnings 0

### Opponent rules: base-s2-882d875-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +42.9 | 0.0 | 0.0 | 0.1 | +4.2 | 0.0 | 1.9 |
| AFTERMATH WITH FRIENDS | 0.1 | +5.0 | 0.0 | 1.4 | 0.1 | +5.5 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 14.1 | +170.4 | 0.0 | 137.2 | 19.0 | +180.2 | 0.0 | 197.1 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.7 | 0.0 | 2.4 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 20.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.7 | 0.0 | 0.0 | 0.3 | +2.3 | 0.0 | 0.0 |
| BEST PRIZE | 0.0 | -0.3 | 0.0 | 0.0 | 0.1 | -10.6 | 9.5 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -10.7 | 46.6 | 3.6 | 0.3 | -58.1 | 25.3 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.0 | +0.7 | 0.0 | 4.3 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 42.7 | 0.0 | 0.1 | +0.0 | 1.0 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +107.7 | 250.1 | 73.7 | 1.5 | +97.3 | 64.0 | 20.3 |
| CANNON SIGHT KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | -2.2 | 2.1 | 0.0 |
| CAST JOB | 1.2 | +19.5 | 43.2 | 24.3 | 0.9 | +9.5 | 21.3 | 30.9 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.9 | +105.8 | 39.5 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 11.4 | 0.6 | +0.0 | 0.0 | 11.4 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.5 | +14.2 | 0.0 | 3.7 | 0.8 | +23.4 | 0.0 | 12.1 |
| CHAFF PASSED | 0.2 | -0.1 | 0.0 | 0.0 | 0.1 | -0.5 | 18.8 | 6.7 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -0.9 | 10.1 | 4.6 | 0.1 | -0.7 | 5.8 | 0.0 |
| CHARACTER GUNS | 1.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 7.8 |
| CHARGE LOSSES | 9.2 | -513.9 | 0.0 | 186.5 | 11.6 | -672.3 | 0.0 | 336.2 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 8.3 | 0.0 | 0.1 | +0.0 | 13.5 | 0.0 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 233.0 | 42.4 | 1.5 | +0.0 | 141.3 | 21.5 |
| CHARGER SLAIN LOST | 0.2 | -12.5 | 0.0 | 13.8 | 0.3 | -10.2 | 34.4 | 10.1 |
| COMBAT PIVOT | 0.4 | +0.0 | 9.6 | 4.9 | 0.2 | +0.0 | 2.4 | 23.1 |
| CONVEYANCE SEARCH | 1.2 | +164.5 | 11.4 | 11.4 | 0.7 | +72.9 | 7.3 | 20.8 |
| COVER ONCE | 4.3 | -210.6 | 0.0 | 81.7 | 5.1 | -418.1 | 0.0 | 143.8 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.5 | -4.0 | 76.9 | 0.0 | 0.7 | -5.3 | 74.9 | 10.5 |
| DEPLOY BY FIGURES | 7.9 | -2.8 | 0.0 | 20.5 | 7.3 | +37.3 | 0.0 | 5.8 |
| EDGE GIVE GROUND | 0.3 | +13.2 | 31.9 | 1.7 | 0.2 | +2.3 | 19.9 | 0.0 |
| ELIXIR WORTH | 0.0 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +6.3 | 246.8 | 59.2 | 2.1 | +8.4 | 196.1 | 10.5 |
| FALLBACK BY WORTH | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.3 |
| FALLS SHORT | 4.5 | +88.6 | 0.0 | 12.8 | 14.7 | +208.6 | 0.0 | 212.3 |
| FEATURE BUFFS | 2.6 | +71.4 | 0.0 | 9.0 | 1.6 | +31.4 | 0.0 | 19.5 |
| FIGHT LIFT | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.8 | +9.5 | 75.3 | 17.2 | 0.6 | +14.5 | 57.9 | 2.7 |
| FIRE AND FLEE | 0.1 | +1.2 | 0.0 | 2.3 | 0.0 | +1.5 | 0.0 | 5.8 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 4.7 | 0.1 | +0.0 | 19.6 | 0.0 |
| FIVE ACTION | 89.9 | +5305.3 | 1224.1 | 903.3 | 79.6 | +4886.8 | 540.4 | 1011.7 |
| FLANK NOT WEIGHED | 3.5 | +0.0 | 0.0 | 87.7 | 3.9 | +0.0 | 0.0 | 112.9 |
| FLEE LOSES BLESSING | 0.0 | +1.2 | 0.0 | 7.9 | - | - | - | - |
| FOCUS FIRE | 0.0 | +0.1 | 0.9 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +100.6 | 0.0 | 6.5 | 0.6 | +94.9 | 0.0 | 4.9 |
| FOUR ROUNDS | 3.5 | +322.1 | 343.7 | 74.6 | 2.9 | +256.5 | 231.2 | 37.7 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -3.8 | 0.0 | 8.5 |
| FRIEND SHOOTS FIRST | 0.4 | -4.7 | 0.0 | 0.0 | 0.4 | -8.4 | 8.3 | 11.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +4.3 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -3.7 | 10.5 | 0.0 | 0.1 | -3.9 | 5.6 | 5.8 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| GUN FIGURES | 1.2 | +8.6 | 27.1 | 7.1 | 0.8 | +14.5 | 2.7 | 21.9 |
| GUN MASK | 0.7 | +4.0 | 0.0 | 11.5 | 0.8 | +16.4 | 0.0 | 19.8 |
| HARD STAY DROPPED | 2.1 | +0.0 | 0.0 | 8.9 | 1.9 | +0.0 | 0.0 | 26.4 |
| HE SHOOTS OR CHARGES | 1.9 | +0.0 | 0.0 | 49.5 | 3.1 | +0.0 | 0.0 | 140.9 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 1.4 | - | - | - | - |
| HIS CHARGE DENIED | 0.5 | +10.7 | 60.2 | 3.6 | 0.3 | +15.8 | 30.1 | 0.0 |
| HIS CHARGE LIST | 2.6 | +0.0 | 0.0 | 42.2 | 4.5 | +0.0 | 0.0 | 110.9 |
| HIS FIGHT TOGETHER | 1.4 | -14.6 | 0.0 | 40.0 | 2.6 | -98.4 | 0.0 | 94.1 |
| HIS LEGAL MOVES | 3.6 | +0.0 | 0.0 | 44.1 | 4.0 | +0.0 | 0.0 | 69.3 |
| HIS MOVE AND SHOT | 2.7 | -49.6 | 0.0 | 80.3 | 3.7 | -73.4 | 0.0 | 122.5 |
| HIS MOVE AS HE DECIDES | 35.3 | +12.4 | 618.1 | 0.0 | 34.5 | +13.5 | 465.3 | 0.0 |
| HIS MOVE WHY | 34.7 | +0.0 | 0.0 | 359.7 | 34.5 | +0.0 | 0.0 | 418.2 |
| HIS ONE MOVE | 17.3 | -9.0 | 2.6 | 115.8 | 18.0 | +6.2 | 2.6 | 67.1 |
| HIS ONE QUARTER | 3.5 | +0.0 | 0.0 | 16.3 | 2.5 | +0.0 | 0.0 | 48.5 |
| HIS OWN BEST MOVE | 1.4 | +0.0 | 0.0 | 12.6 | 1.7 | +0.0 | 0.0 | 27.7 |
| HIS RANDOM MOVE | 5.7 | +0.0 | 0.0 | 52.7 | 2.2 | +0.0 | 0.0 | 21.1 |
| HIS SHOT LIST | 29.5 | +937.0 | 0.0 | 255.4 | 44.8 | +2174.0 | 0.0 | 543.9 |
| HIS TURN DENIED | 1.4 | +33.6 | 179.0 | 23.0 | 1.6 | +81.3 | 134.9 | 21.8 |
| HOLD ODDS | 17.4 | +0.0 | 0.0 | 118.9 | 14.5 | +0.0 | 0.0 | 153.4 |
| HOLDER ASSIGNMENT | 9.8 | +941.2 | 0.0 | 60.2 | 9.0 | +828.8 | 0.0 | 74.6 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.9 | -116.3 | 288.6 | 52.8 | 2.3 | -117.3 | 185.0 | 18.7 |
| HUNT DROPPED | 0.0 | +0.0 | 4.7 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.2 | +6.0 | 0.0 | 0.0 | 0.4 | +24.5 | 0.0 | 5.0 |
| HUNT RESULT | 0.0 | +0.0 | 4.7 | 0.0 | 0.1 | +17.7 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.0 | +13.5 | 4.7 | 0.0 | 0.1 | +32.6 | 6.4 | 5.3 |
| IDLE COST | 3.1 | -49.6 | 0.0 | 29.1 | 12.1 | -207.7 | 0.0 | 158.6 |
| JOINT CHARGE NOW | 0.6 | +37.9 | 47.8 | 5.3 | 0.4 | +30.8 | 49.6 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -3.6 | 0.0 | 0.0 | - | - | - | - |
| JOINT LOOK BACK | 0.1 | +0.8 | 8.3 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.0 | +2.5 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 6.3 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.4 | +0.0 | 0.0 | 13.2 | 2.3 | +0.0 | 0.0 | 10.0 |
| LANE BY FIGURES | 0.7 | +27.9 | 0.0 | 0.0 | 0.7 | +44.9 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.1 | +0.0 | 146.8 | 181.9 | 4.4 | +0.0 | 150.8 | 212.5 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.0 | +1.2 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.5 | +35.0 | 0.0 | 0.0 | 0.3 | +24.3 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.9 | 10.6 | 0.0 | 0.3 | +0.1 | 15.7 | 4.0 |
| LOST AFTER ESCAPE | 1.8 | -2.3 | 169.1 | 36.7 | 1.6 | +4.5 | 109.1 | 29.6 |
| LOST CHARGE | 0.1 | -0.1 | 0.0 | 4.8 | 0.1 | -0.2 | 16.3 | 3.3 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -6.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +6.5 | 0.0 | 0.0 | 0.1 | +4.1 | 0.0 | 2.6 |
| MANOEUVRE | 0.7 | +10.2 | 0.0 | 6.6 | 0.5 | +7.4 | 0.0 | 7.7 |
| MARCH AT ESCAPER | 0.1 | +0.8 | 0.0 | 15.4 | 0.1 | +0.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +31.4 | 0.0 | 0.0 | 0.2 | +7.7 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +50.4 | 0.0 | 4.8 | 0.6 | +34.9 | 0.0 | 11.6 |
| MARCH OF THE TABLE | 0.1 | +2.8 | 0.0 | 0.0 | 0.1 | +3.4 | 0.0 | 11.4 |
| MARCH OVER CASTS | 0.7 | +17.7 | 0.0 | 15.4 | 0.6 | -1.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.2 | +0.0 | 0.0 | 7.1 | 0.6 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.8 | +67.0 | 0.0 | 20.9 | 2.1 | +56.9 | 0.0 | 57.8 |
| MISSILES IN THE MOVE | 4.5 | +122.1 | 0.0 | 58.6 | 2.7 | +33.4 | 0.0 | 107.6 |
| MISSILES NEXT TURN | 5.7 | +94.4 | 0.0 | 80.5 | 3.4 | +23.9 | 0.0 | 112.7 |
| MISSILES ON ONE TARGET | 0.3 | -12.2 | 0.0 | 0.0 | 0.0 | -0.7 | 0.0 | 0.0 |
| MODEL FACING | 0.3 | +29.4 | 0.0 | 1.7 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 1.0 | 3.2 | 2.4 | +0.0 | 27.6 | 9.6 |
| MOVE SPELL IN RANGE | 0.2 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -16.0 | 0.0 | 0.0 | 0.3 | -8.8 | 0.0 | 6.7 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 11.4 | 0.4 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.6 | +431.0 | 0.0 | 59.5 | 5.9 | +629.5 | 0.0 | 41.9 |
| MOVES UNITS SPELL | 0.1 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.3 | +310.8 | 0.0 | 61.8 | 5.2 | +203.7 | 0.0 | 68.8 |
| NEXT CHARGE BY LIST | 4.2 | -171.2 | 11.1 | 43.8 | 6.8 | -281.8 | 21.8 | 107.0 |
| NEXT OBJECTIVE NEARER | 0.1 | -1.1 | 0.0 | 0.0 | 0.2 | -9.8 | 0.0 | 4.2 |
| NO DOUBLE ROUNDS | 2.9 | -155.7 | 306.7 | 70.3 | 2.2 | -133.4 | 183.7 | 33.0 |
| NO LATE CUT | 0.4 | +0.0 | 0.0 | 6.1 | 0.8 | +0.0 | 0.0 | 1.7 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 11.4 | 0.5 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 3.5 | -186.8 | 17.3 | 41.1 | 3.1 | -136.9 | 2.3 | 49.8 |
| ONE CHARGE A CHARGER | 3.9 | +0.0 | 0.0 | 105.6 | 4.2 | +0.0 | 0.0 | 81.0 |
| ONE FIGHT FORMULA | 3.8 | -80.0 | 0.0 | 46.6 | 4.6 | -114.8 | 0.0 | 90.6 |
| ONE OBJECTIVE FORMULA | 4.3 | +10.6 | 0.0 | 41.9 | 3.7 | -18.5 | 0.0 | 56.9 |
| ONE PROMISE A TARGET | 0.2 | -1.4 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 5.6 |
| ONE ROUTE | 1.2 | +0.0 | 0.0 | 7.1 | 0.6 | +0.0 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 20.9 | +552.7 | 0.0 | 275.0 | 33.0 | +874.7 | 0.0 | 422.3 |
| OPENS A LANE | 0.1 | +0.6 | 19.8 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +8.8 | 9.4 | 0.0 | 0.2 | +15.3 | 7.6 | 0.0 |
| OVERRUNS AWAY | 0.5 | +22.9 | 62.3 | 0.0 | 0.3 | +23.5 | 32.8 | 3.3 |
| OWN CAST FIRST | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | -0.4 | 0.0 | 0.0 |
| PATHS CROSS | 0.5 | +21.4 | 0.0 | 2.4 | 0.3 | +12.0 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.1 | +3.3 | 0.0 | 15.4 | 0.1 | +7.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -6.9 | 0.0 | 0.0 | 0.1 | -2.1 | 0.0 | 0.0 |
| PLAN RESULT | 41.0 | +842.3 | 466.9 | 667.0 | 38.1 | +372.0 | 277.1 | 771.5 |
| PROMISE BELOW ZERO | 0.2 | +0.0 | 0.0 | 7.9 | 0.3 | +0.0 | 0.0 | 4.6 |
| PROMISE BY ITS OWN SUM | 6.9 | -249.6 | 0.0 | 48.2 | 7.3 | -280.0 | 0.0 | 7.8 |
| PROMISE IN STEPS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.5 | -0.6 | 0.0 | 0.0 | 0.5 | -0.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -8.2 | 0.0 | 0.0 | 0.3 | -9.1 | 0.0 | 3.4 |
| PROMISE SHOT AWAY | 0.1 | -5.1 | 22.9 | 2.9 | 0.2 | -0.3 | 3.4 | 0.0 |
| PURSUES BIG PREY | 0.1 | -6.6 | 0.0 | 0.0 | 0.1 | -2.7 | 0.0 | 0.0 |
| QUARTER ODDS | 17.6 | +1823.9 | 342.7 | 173.9 | 15.8 | +1807.9 | 197.3 | 202.5 |
| RANDOM MOVE BY FIGURES | 0.7 | +7.6 | 0.0 | 33.4 | 1.8 | +67.5 | 0.0 | 53.1 |
| REAL GROUND | 1.2 | +0.0 | 0.0 | 7.1 | 0.6 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -9.2 | 0.0 | 0.0 | 0.4 | -8.2 | 0.0 | 8.9 |
| REDIRECT COUNTER | 1.6 | +72.8 | 0.0 | 21.3 | 2.0 | +162.3 | 0.0 | 40.7 |
| REDIRECT WEIGHED | 0.1 | +0.9 | 0.0 | 14.1 | 0.1 | +6.7 | 21.8 | 0.0 |
| REFORMS TO MEET IT | 1.1 | -38.8 | 0.0 | 15.4 | 1.1 | -30.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 20.3 | 0.2 | +0.0 | 0.0 | 4.1 |
| RESERVE FALL BACK | 0.2 | +9.1 | 0.0 | 5.5 | 0.4 | +21.0 | 0.0 | 18.0 |
| RESTRAINS TO SHOOT | 0.1 | +3.8 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | +58.3 | 233.2 | 66.4 | 1.9 | +11.4 | 177.5 | 13.4 |
| RISK BY HIS FIGURE | 17.4 | -333.4 | 0.0 | 360.6 | 19.6 | -444.8 | 0.0 | 516.2 |
| RISK ON THE WAY | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.6 | -20.7 | 84.8 | 0.0 | 0.9 | -31.9 | 104.6 | 12.6 |
| RUN DOWN | 2.4 | -26.6 | 255.2 | 66.3 | 2.1 | -34.8 | 176.7 | 22.8 |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -0.9 | 3.5 | 0.0 |
| SCOUT SPOT | 0.3 | +1.1 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.4 | -32.8 | 0.0 | 4.3 | 0.5 | -22.4 | 0.0 | 9.1 |
| SEARCH SPOT | 0.5 | +6.7 | 0.0 | 14.3 | 0.3 | +4.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +20.6 | 29.7 | 0.0 | 0.1 | +2.0 | 5.8 | 0.0 |
| SELF MOVE SPELL | 0.5 | +67.4 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.5 | +41.0 | 14.3 | 9.9 | 1.3 | +22.9 | 11.4 | 17.5 |
| SET UP TOGETHER | 0.2 | +8.2 | 0.0 | 0.0 | 0.2 | +5.5 | 0.0 | 2.6 |
| SET-UP ANY TARGET | 0.3 | +34.3 | 0.0 | 0.0 | 0.1 | +9.0 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +6.8 | 0.0 | 0.0 | 0.1 | +8.2 | 11.4 | 11.4 |
| SHOOTER COUNTED ONCE | 0.1 | -1.7 | 0.0 | 2.1 | 0.1 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +109.2 | 87.3 | 38.4 | 2.7 | +117.3 | 73.7 | 62.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.5 | -37.4 | 122.0 | 2.4 | 0.2 | -10.2 | 15.4 | 1.3 |
| SHOT RISK POINTS | 15.6 | +50.2 | 0.0 | 238.5 | 21.1 | -94.8 | 0.0 | 371.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 1.8 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.8 | +605.7 | 0.0 | 184.5 | 9.8 | +421.7 | 0.0 | 153.3 |
| SPELL OFF EDGE | 0.0 | +0.9 | 4.1 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +45.5 | 0.0 | 0.0 | 0.1 | +16.5 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +18.5 | 89.9 | 89.9 | 2.0 | +32.9 | 81.9 | 99.4 |
| SPELLS IN THE FIGHT | 0.5 | +3.2 | 93.1 | 6.0 | 0.8 | -8.9 | 39.6 | 11.9 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 131.1 | 9.3 | +0.0 | 0.0 | 178.4 |
| STAND AND SHOOT | 0.6 | -4.5 | 64.0 | 12.4 | 0.4 | -8.1 | 39.4 | 1.4 |
| STANDS FOR A REASON | 0.2 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 3.4 | 40.9 |
| STANDS STILL | 47.5 | +0.0 | 880.5 | 395.3 | 29.5 | +0.0 | 309.2 | 283.3 |
| STAY WORTH | 25.3 | +14.6 | 607.9 | 216.7 | 13.1 | +177.0 | 183.2 | 156.8 |
| STOPS | 0.0 | +2.4 | 4.7 | 0.0 | 0.1 | +5.9 | 6.4 | 5.3 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 6.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.9 | +502.8 | 0.0 | 42.7 | 6.3 | +486.2 | 0.0 | 84.6 |
| SUPPORT NARROWED | 0.5 | +0.0 | 43.9 | 6.3 | 0.4 | +0.0 | 30.0 | 6.6 |
| SUPPORT WORKED OUT | 5.9 | +502.8 | 0.0 | 42.7 | 6.3 | +486.2 | 0.0 | 84.6 |
| SURE REACH TOGETHER | 0.1 | +3.8 | 0.0 | 0.0 | 0.3 | +2.8 | 0.0 | 2.6 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 20.0 | 1.2 | +0.0 | 0.0 | 15.7 |
| THE PROMISE ADDS | 0.2 | -14.8 | 0.0 | 0.0 | 0.2 | -21.9 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 29.5 | +0.0 | 0.0 | 242.2 | 31.3 | +0.0 | 0.0 | 362.7 |
| TIED UP BY THE SUM | 0.9 | +98.1 | 89.8 | 48.9 | 0.3 | +37.2 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 35.9 | +378.6 | 12.9 | 332.7 | 11.1 | +116.0 | 0.0 | 78.5 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 14.1 | 1.9 | +0.0 | 0.0 | 11.8 |
| WALKS ON ITS ROUTE | 0.0 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +2.0 | 3.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 33.1 | 17.7 | 0.0 | +0.0 | 0.0 | 5.3 |
| WHAT THE JOINER ADDS | 0.4 | +0.7 | 10.6 | 5.7 | 0.2 | -1.2 | 2.9 | 6.6 |
| WHO GETS IN | 0.1 | -1.7 | 4.9 | 0.0 | 0.1 | +7.0 | 11.5 | 0.0 |
| WHO HITS BACK | 0.3 | +39.6 | 0.0 | 21.5 | 0.2 | +45.2 | 0.0 | 24.8 |
| WHOLE FIGHT | 0.2 | +7.7 | 5.3 | 2.9 | 0.1 | -0.7 | 1.4 | 3.3 |
| WHOLE FIGHT GAIN | 0.1 | +9.3 | 9.5 | 0.0 | - | - | - | - |
| WIDER SPREAD | 2.2 | -0.9 | 225.7 | 49.7 | 1.9 | -6.8 | 168.4 | 19.3 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 6.7 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.3 | +127.4 | 0.0 | 11.5 | 2.5 | +68.8 | 0.0 | 19.8 |

### Rule changes: base-s2-882d875-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2445 | 2445 | 1538 | 43.94 | +0 | +0.0 |
| HIS MOVE WHY | 2423 | 2423 | 1336 | 38.17 | +0 | +0.0 |
| ARMY TABLE | 1156 | 1156 | 779 | 22.26 | +9940 | +12.8 |
| HIS SHOT LIST | 2600 | 2501 | 639 | 18.26 | +12025 | +18.8 |
| HOLDER ASSIGNMENT | 658 | 658 | 612 | 17.49 | +36648 | +59.9 |
| ONE TARGET A SHOOTER | 1888 | 1810 | 373 | 10.66 | +3893 | +10.4 |
| DEPLOY BY FIGURES | 531 | 531 | 302 | 8.63 | +5001 | +16.6 |
| LEGAL CHARGES ONLY | 298 | 298 | 298 | 8.51 | +0 | +0.0 |
| TIME ON OUR SIDE | 1643 | 1499 | 288 | 8.23 | +740 | +2.6 |
| HIS ONE MOVE | 1233 | 1204 | 281 | 8.03 | +0 | +0.0 |
| THE TABLE AGAIN | 419 | 419 | 250 | 7.14 | +0 | +0.0 |
| FIVE ACTION | 5932 | 5752 | 249 | 7.11 | +13127 | +52.7 |
| OFF BEST | 232 | 232 | 232 | 6.63 | -11330 | -48.8 |
| PROMISE BY ITS OWN SUM | 498 | 498 | 178 | 5.09 | -18536 | -104.1 |
| MOVE TO CHARGE COMPUTED | 365 | 322 | 176 | 5.03 | +8707 | +49.5 |
| SHOT RISK POINTS | 1285 | 1238 | 165 | 4.71 | +4515 | +27.4 |
| QUARTER ODDS | 1170 | 1117 | 161 | 4.60 | +13937 | +86.6 |
| HARD STAY DROPPED | 138 | 138 | 138 | 3.94 | +0 | +0.0 |
| SUPPORT ADDS | 427 | 419 | 137 | 3.91 | +8322 | +60.7 |
| SUPPORT WORKED OUT | 427 | 419 | 137 | 3.91 | +8322 | +60.7 |
| SHOOTS FROM THE BEST SPOT | 209 | 209 | 130 | 3.71 | +1476 | +11.4 |
| MOVE ORDER | 120 | 120 | 120 | 3.43 | +0 | +0.0 |
| FOUR ROUNDS | 221 | 206 | 106 | 3.03 | +7738 | +73.0 |
| IDLE COST | 529 | 436 | 83 | 2.37 | +1018 | +12.3 |
| STAY WORTH | 1347 | 1247 | 73 | 2.09 | +613 | +8.4 |
| ADVANCE LANE KEPT | 62 | 62 | 62 | 1.77 | +0 | +0.0 |
| SHOTS IN THE MOVE | 898 | 704 | 57 | 1.63 | +2240 | +39.3 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.57 | +0 | +0.0 |
| CAST JOB | 72 | 72 | 52 | 1.49 | +258 | +5.0 |
| CHARGE LOSSES | 727 | 697 | 51 | 1.46 | +4702 | +92.2 |
| RANDOM MOVE BY FIGURES | 88 | 88 | 51 | 1.46 | +2628 | +51.5 |
| FALLS SHORT | 674 | 570 | 50 | 1.43 | +337 | +6.7 |
| LANE BY FIGURES | 50 | 50 | 50 | 1.43 | +2547 | +50.9 |
| FOLLOW UP WEIGHED | 48 | 48 | 48 | 1.37 | +6842 | +142.5 |
| MARCH CHECK | 56 | 55 | 47 | 1.34 | +715 | +15.2 |
| COVER ONCE | 326 | 242 | 45 | 1.29 | +1189 | +26.4 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.20 | +0 | +0.0 |
| RISK BY ARC | 155 | 143 | 42 | 1.20 | +1092 | +26.0 |
| NEXT CHARGE BY LIST | 386 | 363 | 38 | 1.09 | +1171 | +30.8 |
| JOINT CHARGE NOW | 37 | 37 | 37 | 1.06 | +2407 | +65.0 |
| CHARGE NOW FIRST | 120 | 120 | 35 | 1.00 | -2394 | -68.4 |
| MAX FOR POSITIONING | 173 | 163 | 35 | 1.00 | +243 | +7.0 |
| RISK BY HIS FIGURE | 1296 | 1242 | 33 | 0.94 | +3349 | +101.5 |
| TIED UP BY THE SUM | 44 | 42 | 33 | 0.94 | +1032 | +31.3 |
| HOLDS AMBUSHERS | 32 | 32 | 32 | 0.91 | +0 | +0.0 |
| SET UP BY THE SET | 99 | 98 | 32 | 0.91 | +1913 | +59.8 |
| LONE WIZARD KEPT IN | 29 | 29 | 29 | 0.83 | +2075 | +71.5 |
| PATHS CROSS | 29 | 29 | 29 | 0.83 | +1170 | +40.4 |
| CHAFF IN THE MOVE | 45 | 41 | 27 | 0.77 | +2 | +0.1 |
| MISSILES IN THE MOVE | 253 | 165 | 26 | 0.74 | +478 | +18.4 |
| HIS TURN DENIED | 105 | 99 | 24 | 0.69 | +701 | +29.2 |
| CANNON PLANNED TARGET | 236 | 236 | 23 | 0.66 | +67 | +2.9 |
| CASTING BLOCK | 30 | 30 | 23 | 0.66 | +1092 | +47.5 |
| COMBAT PIVOT | 22 | 22 | 22 | 0.63 | +0 | +0.0 |
| MARCH BY THE SUM | 22 | 22 | 22 | 0.63 | +1369 | +62.2 |
| RESERVE FALL BACK | 22 | 22 | 22 | 0.63 | +1054 | +47.9 |
| FEATURE BUFFS | 147 | 147 | 20 | 0.57 | +200 | +10.0 |
| NEARER NOT NEEDED | 437 | 419 | 20 | 0.57 | +931 | +46.6 |
| SHOTS AFTER THE MOVES | 169 | 169 | 20 | 0.57 | +0 | +0.0 |
| WHO HITS BACK | 20 | 20 | 20 | 0.57 | +1848 | +92.4 |
| REDIRECT COUNTER | 128 | 98 | 19 | 0.54 | +1282 | +67.5 |
| SHOOTERS IN TWO RANKS | 19 | 19 | 19 | 0.54 | +40 | +2.1 |
| SCOUT WAITS | 18 | 18 | 18 | 0.51 | +0 | +0.0 |
| SEARCH SPOT | 28 | 28 | 17 | 0.49 | +383 | +22.5 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.46 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 134 | 126 | 16 | 0.46 | +599 | +37.4 |
| AFTERMATH IN POINTS | 14 | 14 | 14 | 0.40 | +1647 | +117.6 |
| FIRE IN ORDER | 14 | 14 | 14 | 0.40 | +0 | +0.0 |
| SECOND LOOK | 14 | 14 | 14 | 0.40 | +791 | +56.5 |
| MANOEUVRE | 42 | 42 | 13 | 0.37 | +754 | +58.0 |
| SUPPORT NARROWED | 32 | 32 | 13 | 0.37 | -811 | -62.4 |
| CHAFF PASSED | 12 | 12 | 12 | 0.34 | -20 | -1.7 |
| CASTS FROM BEHIND | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| OVERRUNS AWAY | 28 | 26 | 10 | 0.29 | +443 | +44.3 |
| REDIRECT WEIGHED | 10 | 10 | 10 | 0.29 | +1207 | +120.7 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.29 | +0 | +0.0 |
| MARCH OF THE TABLE | 9 | 9 | 9 | 0.26 | -215 | -23.9 |
| MODEL FACING | 9 | 9 | 9 | 0.26 | +1030 | +114.4 |
| NO DOUBLE ROUNDS | 177 | 168 | 9 | 0.26 | +370 | +41.1 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.26 | -314 | -34.8 |
| PROMISE SHOT AWAY | 9 | 9 | 9 | 0.26 | -192 | -21.3 |
| SURE REACH TOGETHER | 14 | 13 | 9 | 0.26 | +117 | +13.0 |
| FRIENDS SHOTS CHECKED | 8 | 8 | 8 | 0.23 | +176 | +22.0 |
| HIS CHARGE DENIED | 31 | 28 | 8 | 0.23 | +188 | +23.5 |
| STUCK PIVOT | 8 | 8 | 8 | 0.23 | +0 | +0.0 |
| WHAT THE JOINER ADDS | 20 | 18 | 8 | 0.23 | +141 | +17.6 |
| AFTERMATH WITH FRIENDS | 7 | 7 | 7 | 0.20 | +366 | +52.3 |
| HIS MOVE AND SHOT | 224 | 218 | 7 | 0.20 | +50 | +7.2 |
| ONE OBJECTIVE FORMULA | 280 | 219 | 7 | 0.20 | +238 | +34.1 |
| ONE PROMISE A TARGET | 7 | 7 | 7 | 0.20 | -39 | -5.6 |
| ONE FIGHT FORMULA | 296 | 163 | 6 | 0.17 | +106 | +17.6 |
| PROMISE KNOWS THE FIGHT | 38 | 31 | 6 | 0.17 | -22 | -3.7 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -382 | -76.5 |
| EDGE GIVE GROUND | 15 | 14 | 5 | 0.14 | +83 | +16.7 |
| HIS FIGHT TOGETHER | 141 | 137 | 5 | 0.14 | +241 | +48.3 |
| HONEST WORTH | 181 | 168 | 5 | 0.14 | +37 | +7.3 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +224 | +44.8 |
| MISSILES NEXT TURN | 321 | 222 | 5 | 0.14 | +12 | +2.4 |
| MOVES UNITS SPELL | 5 | 5 | 5 | 0.14 | +129 | +25.8 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +369 | +73.8 |
| PROMISE READS THE TABLE | 19 | 19 | 5 | 0.14 | -149 | -29.7 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -326 | -65.2 |
| WHO GETS IN | 5 | 5 | 5 | 0.14 | +187 | +37.3 |
| CHARGE NOT DECLARED | 4 | 4 | 4 | 0.11 | -849 | -212.3 |
| FIGHT TO THE END | 50 | 47 | 4 | 0.11 | +136 | +34.0 |
| GUN MASK | 53 | 51 | 4 | 0.11 | +96 | +24.0 |
| JOINT LOOK BACK | 4 | 4 | 4 | 0.11 | +39 | +9.8 |
| LOST AFTER ESCAPE | 121 | 110 | 4 | 0.11 | +12 | +3.1 |
| REFUSING RETIRES | 16 | 16 | 4 | 0.11 | -1 | -0.1 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +148 | +36.9 |
| WAR ENGINE JOBS | 27 | 27 | 4 | 0.11 | -50 | -12.5 |
| FALL BACK GOOD ORDER | 154 | 146 | 3 | 0.09 | +61 | +20.3 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.09 | +93 | +30.9 |
| OPENS UP | 13 | 11 | 3 | 0.09 | +57 | +19.1 |
| OWN CAST FIRST | 3 | 3 | 3 | 0.09 | -19 | -6.2 |
| SET UP TOGETHER | 12 | 10 | 3 | 0.09 | +42 | +14.2 |
| WIDER SPREAD | 145 | 136 | 3 | 0.09 | +17 | +5.5 |
| BLOWS WHERE AIMED | 20 | 19 | 2 | 0.06 | +41 | +20.6 |
| FALLBACK BY WORTH | 8 | 8 | 2 | 0.06 | +3 | +1.4 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +30 | +15.0 |
| HUNT IN PAIRS | 21 | 10 | 2 | 0.06 | +151 | +75.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OPENS A LANE | 6 | 6 | 2 | 0.06 | +1 | +0.3 |
| SCREEN BY WHAT IT SAVES | 31 | 31 | 2 | 0.06 | +7 | +3.6 |
| SPELLS IN THE FIGHT | 46 | 40 | 2 | 0.06 | +15 | +7.3 |
| WHOLE FIGHT | 10 | 9 | 2 | 0.06 | +146 | +72.8 |
| BACKUP TARGETS | 16 | 8 | 1 | 0.03 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +26 | +26.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.03 | -78 | -77.7 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -5 | -5.0 |
| CHARGER SLAIN LOST | 17 | 17 | 1 | 0.03 | +8 | +7.6 |
| DENIED BY THE FIGHT | 42 | 38 | 1 | 0.03 | +26 | +26.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +78 | +77.7 |
| FACES THE THREAT | 1 | 1 | 1 | 0.03 | +7 | +6.8 |
| FLEE LOSES BLESSING | 1 | 1 | 1 | 0.03 | +9 | +9.2 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.03 | +88 | +87.9 |
| MOVE SPELL IN RANGE | 6 | 3 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +10 | +9.8 |
| RUN DOWN | 158 | 146 | 1 | 0.03 | +4 | +4.0 |
| SAME CHARGE LATER | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| STOPS | 4 | 4 | 1 | 0.03 | +42 | +42.2 |
| THE PROMISE ADDS | 14 | 13 | 1 | 0.03 | +21 | +21.2 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.03 | -43 | -43.2 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +72 | +72.0 |
| WHOLE FIGHT GAIN | 4 | 3 | 1 | 0.03 | +3 | +3.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 13 | 13 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 54 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 7 | 7 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 47 | 44 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 65 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 258 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 27 | 26 | 0 | 0.00 | - | - |
| GIVES UP | 11 | 9 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 70 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 173 | 170 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 246 | 241 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 267 | 250 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 210 | 196 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 106 | 106 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 274 | 265 | 0 | 0.00 | - | - |
| HOLD ODDS | 1119 | 1112 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 164 | 158 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 22 | 22 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 16 | 14 | 0 | 0.00 | - | - |
| LOST CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 44 | 44 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 62 | 58 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 11 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 33 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 42 | 41 | 0 | 0.00 | - | - |
| NOT TURNED | 6 | 6 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 284 | 272 | 0 | 0.00 | - | - |
| ONE ROUTE | 62 | 58 | 0 | 0.00 | - | - |
| PLAN RESULT | 2768 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 16 | 16 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 62 | 58 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 25 | 25 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 76 | 72 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 23 | 19 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 55 | 51 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 23 | 23 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 109 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 581 | 545 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 35 | 31 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 51 | 45 | 0 | 0.00 | - | - |
| STANDS STILL | 2694 | 2639 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 15 | 14 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 101 | not checked | - | - | - | - |
| THE TABLE BINDS | 2128 | not checked | - | - | - | - |
| WAITS AGAIN | 113 | 104 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: base-s2-882d875-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.80 | 2.29 | 104.1 |
| JOB FIRST | gate | 2.43 | 2.60 | 50.7 |
| ARMY TABLE | rule | 1.43 | 2.46 | 62.4 |
| NO REASON | gate | 0.80 | 0.43 | 53.6 |
| CHARGE NOW FIRST | rule | 0.49 | 0.51 | 68.4 |
| HOLDER ASSIGNMENT | rule | 0.34 | 0.54 | 34.1 |
| SUPPORT NARROWED | rule | 0.20 | 0.17 | 62.4 |
| JOINT CHARGE NOW | rule | 0.20 | 0.09 | 66.4 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.09 | 34.8 |
| AFTERMATH BAND | gate | 0.20 | 0.03 | 3.5 |
| MARCH OF THE TABLE | rule | 0.14 | 0.09 | 26.9 |
| PROMISE SHOT AWAY | rule | 0.09 | 0.14 | 24.0 |
| BEST PRIZE | rule | 0.03 | 0.11 | 76.5 |
| CANNON PLANNED TARGET | rule | 0.14 | - | 39.9 |
| CHAFF PASSED | rule | 0.06 | 0.09 | 4.0 |
| PURSUES BIG PREY | rule | 0.09 | 0.06 | 65.2 |
| CHARGE NOT DECLARED | rule | 0.06 | 0.06 | 212.3 |
| DEPLOY BY FIGURES | rule | 0.06 | 0.06 | 9.0 |
| ONE PROMISE A TARGET | rule | 0.11 | - | 33.8 |
| PATHS CROSS | rule | 0.09 | 0.03 | 9.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.06 | 0.06 | 5.4 |
| PROMISE READS THE TABLE | rule | 0.09 | 0.03 | 49.9 |
| WAR ENGINE JOBS | rule | 0.11 | - | 12.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 24.0 |
| FRIENDS SHOTS CHECKED | rule | 0.09 | - | 3.1 |
| OWN CAST FIRST | rule | 0.03 | 0.06 | 6.2 |
| SET UP BY THE SET | rule | 0.03 | 0.03 | 4.5 |
| WHO GETS IN | rule | 0.03 | 0.03 | 106.1 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 77.7 |
| CATCH ODDS | rule | 0.03 | - | 5.0 |
| FALLBACK | gate | 0.03 | - | 0.9 |
| FIGHT ORDER BAND | gate | - | 0.03 | 4.2 |
| RESERVE FALL BACK | rule | 0.03 | - | 9.1 |
| WALKS ON ITS ROUTE | rule | 0.03 | - | 43.2 |
| WHO HITS BACK | rule | 0.03 | - | 4.3 |

### Plans: base-s2-882d875-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.9 | 65% | 474 | 259 | 55% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 27.8 | 96% | 1528 | 0 | 0% |
| Mine | shoot | 9.6 | 50% | 423 | 583 | 138% |
| Mine | support | 0.3 | 100% | 1 | 0 | 0% |
| Opponent | charge | 2.3 | 49% | 457 | 221 | 48% |
| Opponent | join | 1.1 | 95% | 51 | 0 | 0% |
| Opponent | move | 29.8 | 93% | 1330 | 0 | 0% |
| Opponent | shoot | 4.4 | 42% | 353 | 151 | 43% |
| Opponent | support | 0.5 | 65% | 2 | 0 | 0% |

### Packages: hunt the guns, base-s2-882d875-p6

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 472 | 0 | 0% | 18 |
| Opponent | 0.1 | 3 | 1 | 100% | 100% | 0% | 2.0 | 369 | 309 | 100% | 47 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| Chaos Dwarfs | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 472 | 0 | 0% | 105 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 171 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 13 |
| Tomb Kings of Khemri | 1.0 | 2 | 1 | 100% | 100% | 0% | 2.0 | 255 | 212 | 100% | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 483 | 407 | 100% | 7 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: base-s2-882d875-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 12% | 71% | 0% | - | 14% | 0% | 14% | 43% | 29% |
| Opponent | REDIRECT COUNTER | 2.0 | 34% | 83% | 29% | 14% | 24% | 6% | 6% | 65% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s2-882d875-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 34 | 68 (34) | 20 | 49 | 28 | 59% | 2.4 | 45 (13) | 130 (11) | 34 (10) | 56 (25) | 96 (9) |
| Mine | Character | 119 | 53 (119) | 52 | 1 | 23 | 29% | 2.4 | 62 (48) | 59 (48) | 6 (17) | 50 (61) | 60 (52) |
| Mine | Clean-up | 27 | 52 (27) | 5 | 47 | 17 | 63% | 2.7 | 48 (9) | 46 (15) | 99 (3) | 58 (17) | 45 (10) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | Fast Hammer | 37 | 31 (37) | 7 | 24 | 35 | 38% | 2.3 | 15 (15) | 48 (18) | 12 (4) | 38 (20) | 25 (17) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 53 | 21 (53) | 12 | 10 | 18 | 30% | 2.5 | 30 (14) | 16 (29) | 22 (10) | 32 (32) | 8 (21) |
| Mine | Holder | 26 | 92 (26) | 9 | 84 | 16 | 42% | 3.3 | 85 (6) | 124 (13) | 42 (3) | 136 (12) | 49 (10) |
| Mine | Shooter | 40 | 67 (40) | 24 | 42 | 23 | 10% | 1.9 | 40 (14) | 90 (20) | 63 (5) | 92 (26) | 25 (13) |
| Mine | War machine | 56 | 24 (56) | 24 | 0 | 30 | 11% | 1.4 | 26 (23) | 13 (17) | 35 (16) | 8 (11) | 27 (45) |
| Mine | Wizard | 14 | 5 (14) | 5 | 0 | 14 | 14% | 2.4 | 11 (6) | 0 (6) | 0 (1) | 0 (6) | 11 (7) |
| Opponent | Chaff | 59 | 67 (59) | 3 | 64 | 43 | 54% | 2.5 | 79 (21) | 47 (23) | 79 (15) | 83 (47) | 0 (12) |
| Opponent | Character | 100 | 44 (100) | 44 | 0 | 27 | 33% | 2.7 | 30 (38) | 63 (44) | 30 (9) | 43 (55) | 47 (36) |
| Opponent | Clean-up | 26 | 30 (26) | 7 | 23 | 34 | 35% | 3.1 | 4 (10) | 46 (12) | 60 (4) | 42 (17) | 13 (9) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 50 | 17 (50) | 5 | 11 | 30 | 50% | 2.8 | 0 (12) | 29 (27) | 1 (11) | 11 (30) | 26 (20) |
| Opponent | Hammer | 53 | 27 (53) | 10 | 17 | 34 | 30% | 3.0 | 30 (20) | 22 (28) | 46 (5) | 38 (31) | 10 (22) |
| Opponent | Holder | 31 | 65 (31) | 19 | 46 | 33 | 42% | 3.1 | 73 (10) | 85 (13) | 15 (6) | 104 (16) | 22 (13) |
| Opponent | Shooter | 31 | 23 (31) | 3 | 20 | 37 | 6% | 1.7 | 23 (11) | 28 (15) | 0 (5) | 22 (18) | 23 (13) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | - | 0 (4) | - | - | 0 (4) |
| Opponent | War machine | 17 | 28 (17) | 28 | 0 | 33 | 0% | 1.6 | 42 (8) | 17 (4) | 16 (5) | 90 (4) | 11 (13) |
| Opponent | Wizard | 24 | 1 (24) | 1 | 0 | 48 | 12% | 2.2 | 0 (6) | 2 (9) | 0 (4) | 2 (10) | 0 (9) |

### Charged fights: base-s2-882d875-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 224 | 148 | 1.2 | 1.2 | 118 | 27 | +91 | 3 of 5 | 3 of 5 | +60 | +98 |
| Mine | Chaos Dwarfs | 4 | 254 | 358 | 3.2 | 1.2 | 110 | 0 | +110 | 3 of 13 | 12 of 13 | +283 | +79 |
| Mine | Dwarfen Mountain Holds | 4 | 123 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 1 of 4 | 1 of 4 | - | +55 |
| Mine | Empire of Man | 4 | 246 | 15 | 1.0 | 1.0 | 15 | 0 | +15 | 2 of 4 | 4 of 4 | - | +15 |
| Mine | Grand Cathay | 5 | 138 | 396 | 4.4 | 1.2 | 90 | 33 | +57 | 7 of 22 | 14 of 22 | -9 | +67 |
| Mine | High Elf Realms | 4 | 236 | 713 | 3.8 | 1.1 | 190 | 0 | +190 | 4 of 15 | 12 of 15 | +287 | +183 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 314 | 2.0 | 1.0 | 157 | 0 | +157 | 0 of 2 | 2 of 2 | - | +157 |
| Mine | Ogre Kingdoms | 1 | 0 | 85 | 2.0 | 1.0 | 42 | 17 | +26 | 0 of 2 | 2 of 2 | - | +26 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 582 | 5.0 | 1.0 | 116 | 22 | +94 | 1 of 5 | 4 of 5 | - | +94 |
| Mine | Skaven | 2 | 111 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 1359 | 4.0 | 1.0 | 340 | 0 | +340 | 2 of 4 | 3 of 4 | - | +340 |
| Mine | Vampire Counts | 2 | 156 | 744 | 6.0 | 1.2 | 124 | 74 | +50 | 4 of 12 | 8 of 12 | +0 | +60 |
| Mine | Warriors of Chaos | 2 | 0 | 63 | 1.5 | 1.0 | 42 | 240 | -198 | 0 of 3 | 3 of 3 | - | -198 |
| **Mine** | all armies | 35 | 159 | 317 | 2.7 | 1.1 | 119 | 28 | +91 | 27 of 93 | 69 of 93 | +98 | +90 |
| Opponent | Empire of Man | 3 | 225 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 2 | 81 | 208 | 2.5 | 1.0 | 83 | 0 | +83 | 1 of 5 | 5 of 5 | - | +83 |
| Opponent | High Elf Realms | 3 | 12 | 552 | 3.0 | 1.0 | 184 | 49 | +135 | 5 of 9 | 6 of 9 | - | +135 |
| Opponent | Lizardmen | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 1 | 95 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Skaven | 3 | 0 | 32 | 1.7 | 1.0 | 19 | 88 | -69 | 3 of 5 | 3 of 5 | - | -69 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 437 | 9.0 | 1.0 | 49 | 22 | +27 | 4 of 9 | 7 of 9 | - | +27 |
| Opponent | Vampire Counts | 6 | 125 | 296 | 2.3 | 1.1 | 127 | 14 | +113 | 7 of 14 | 8 of 14 | +195 | +107 |
| Opponent | Warriors of Chaos | 11 | 0 | 179 | 1.5 | 1.2 | 123 | 63 | +60 | 9 of 16 | 11 of 16 | +157 | +38 |
| Opponent | Wood Elf Realms | 4 | 82 | 323 | 1.5 | 1.3 | 215 | 84 | +131 | 3 of 6 | 4 of 6 | +448 | -27 |
| **Opponent** | all armies | 35 | 58 | 218 | 1.9 | 1.1 | 112 | 41 | +72 | 35 of 68 | 45 of 68 | +260 | +53 |

### Effective charges: base-s2-882d875-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 3 (net +111) | 0 | 0 | 1 (net +60) | 0 | 1 (net +60) | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 13 | 2 (net +0) | 0 | 0 | 4 (net +142) | 2 (net +148) | 3 (net +85) | 2 | 0% (0 of 11) |
| Mine | Dwarfen Mountain Holds | 4 | 2 (net +92) | 0 | 1 (net +0) | 0 | 1 (net +34) | 0 | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 4 | 0 | 0 | 0 | 3 (net +0) | 0 | 0 | 1 | 0% (0 of 3) |
| Mine | Grand Cathay | 22 | 5 (net -59) | 0 | 2 (net +48) | 4 (net +49) | 2 (net +84) | 7 (net +180) | 2 | 10% (2 of 20) |
| Mine | High Elf Realms | 15 | 0 | 0 | 1 (net +392) | 2 (net +0) | 3 (net +132) | 6 (net +234) | 3 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +157) | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net -34) | 0 | 0 | 1 (net +85) | 0 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 2 (net +145) | 0 | 0 | 3 | 0% (0 of 2) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 2 (net +515) | 1 (net +254) | 0 | 1 (net +75) | 0 | 50% (2 of 4) |
| Mine | Vampire Counts | 12 | 4 (net +194) | 0 | 2 (net -30) | 0 | 2 (net +56) | 4 (net -57) | 0 | 17% (2 of 12) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net -721) | 1 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 2 (net +146) | 2 (net +0) | 0 | 0 | 1 | 50% (2 of 4) |
| Opponent | High Elf Realms | 9 | 2 (net +368) | 0 | 2 (net +48) | 2 (net +84) | 0 | 1 (net +0) | 2 | 29% (2 of 7) |
| Opponent | Ogre Kingdoms | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Skaven | 5 | 1 (net -35) | 0 | 1 (net +95) | 1 (net -407) | 0 | 2 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 9 | 2 (net -98) | 0 | 1 (net +125) | 1 (net +125) | 1 (net +110) | 4 (net +19) | 0 | 11% (1 of 9) |
| Opponent | Vampire Counts | 14 | 7 (net +70) | 0 | 3 (net +142) | 1 (net +442) | 0 | 2 (net +115) | 1 | 23% (3 of 13) |
| Opponent | Warriors of Chaos | 16 | 2 (net +0) | 0 | 4 (net -52) | 3 (net +151) | 0 | 5 (net +126) | 2 | 29% (4 of 14) |
| Opponent | Wood Elf Realms | 6 | 1 (net -505) | 0 | 2 (net +0) | 0 | 1 (net +112) | 1 (net +895) | 1 | 40% (2 of 5) |

### Charged fights, damage counted: base-s2-882d875-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 17 | 269 | 357 | +59 | 152 | 91 | +61 | +22.8 |
| Mine | Effective (55-75%) | 9 | 259 | 156 | +158 | 175 | 40 | +135 | +52.2 |
| Mine | 76-89% | 17 | 301 | 167 | +80 | 116 | 19 | +98 | +32.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 275 | 166 | +92 | 143 | 47 | +95 | +34.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 460 | 86 | +91 | 109 | 0 | +109 | +23.7 |
| Mine | No odds | 12 | 305 | 204 | +98 | 164 | 53 | +111 | +36.5 |
| Mine | All fights | 93 | 303 | 196 | +91 | 142 | 44 | +97 | +32.1 |
| Opponent | Long shot (under 50%) | 17 | 214 | 303 | +29 | 120 | 98 | +22 | +10.1 |
| Opponent | Effective (55-75%) | 16 | 340 | 221 | +51 | 116 | 72 | +44 | +12.9 |
| Opponent | 76-89% | 10 | 346 | 179 | +78 | 119 | 41 | +78 | +22.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 301 | 207 | +122 | 169 | 33 | +136 | +45.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 470 | 111 | +111 | 111 | 0 | +111 | +23.6 |
| Opponent | No odds | 8 | 311 | 208 | +89 | 131 | 32 | +98 | +31.5 |
| Opponent | All fights | 68 | 301 | 227 | +72 | 131 | 59 | +72 | +24.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s2-882d875-p6 | move | 209 | 54 (26%) | 44 (21%) | 25 (12%) | 130 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0124, L2431, L2628 |
| Charmed Shield | Opponent | L0124, L0224, L0325, L0427, L1325, L2134, L2325 |
| Clockwork Compass | Mine | L1214, L1230 |
| Elixir of Power | Mine | L1120, L1929 |
| Elixir of Power | Opponent | L0411, L1011 |
| Fistful of Laurels | Mine | L1829 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L1533 |
| Invocation of Nehek | Mine | L2431 |
| Invocation of Nehek | Opponent | L0124, L0224, L0325, L0427, L1325, L2325 |
| Opal Amulet | Mine | L1420 |
| Opal Amulet | Opponent | L0514, L1214 |
| Periapt of Soul Exchange | Mine | L2031, L2134 |
| Periapt of Soul Exchange | Opponent | L0920, L1120, L1420 |
| Ring of Doom | Mine | L0208, L0224, L1120, L1214, L1230, L1517, L1533 |
| Ring of Doom | Opponent | L0411, L1011, L1533, L1631, L2031, L2431 |
| Ring of Jet | Mine | L1011, L1028, L1120, L1214, L1230 |
| Ring of Jet | Opponent | L0411, L1011 |
| Standard of the Fell Warrior | Mine | L1325 |
| Standard of the Fell Warrior | Opponent | L0813 |
| Storm Daemon (Renegade 2.0) | Mine | L2134 |
| Twice-Blessed Armour | Mine | L0723, L1011, L1028 |
| Witch Hunter's Ward | Mine | L0723, L0813, L0829 |
| Witch Hunter's Ward | Opponent | L0108, L0208 |

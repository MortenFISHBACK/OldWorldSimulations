# Doctrine scorecard: base-s1-882d875-p2

### Scorecard: base-s1-882d875-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 4 | 0 | 3 | 0 | 0 | 0 | 643 |
| L0122 | 2 | 1 | Mine | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 7 | 0 | 0 | 0 | 145 |
| L0206 | 2 | 1 | Opponent | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 115 |
| L0222 | 6 | 1 | Mine | no | 7 | 1 | 4 | 5 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 7 | 1 | 5 | 0 | 0 | 0 | 0 | 72 |
| L0307 | 1 | 1 | Mine | yes | 0 | - | 0 | 1 | 0 | 0 | 0 | 310 |
| L0307 | 1 | 1 | Opponent | yes | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 125 |
| L0323 | 5 | 1 | Mine | no | - | 1 | 1 | 0 | 0 | 0 | 0 | 424 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 185 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 5 | 4 | 0 | 0 | 0 | 263 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 646 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 218 |
| L0528 | 6 | 1 | Opponent | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 832 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 0 | 0 | 2 | 0 | 0 | 100 |
| L0632 | 2 | 1 | Mine | - | - | - | 2 | 2 | 0 | 0 | 0 | 495 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 0 | 5 | 1 | 0 | 0 | 340 |
| L0721 | 1 | 1 | Mine | yes | 4 | 1 | 3 | 1 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Opponent | yes | 6 | - | 0 | 3 | 2 | 0 | 0 | 290 |
| L0810 | 6 | 1 | Mine | no | 2 | 5 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 17 | 4 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 4 | 1 | 2 | 0 | 0 | 0 | 753 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 5 | 0 | 0 | 0 | 75 |
| L0918 | 6 | 1 | Mine | no | 7 | 3 | 1 | 1 | 0 | 0 | 0 | 367 |
| L0918 | 6 | 1 | Opponent | no | 7 | 4 | 4 | 2 | 0 | 0 | 0 | 34 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 632 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 5 | 0 | 0 | 0 | 91 |
| L1026 | 6 | 1 | Mine | no | 1 | 6 | 1 | 0 | 1 | 0 | 0 | 126 |
| L1026 | 6 | 1 | Opponent | no | 8 | 2 | 3 | 3 | 0 | 0 | 0 | 60 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 165 |
| L1118 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 7 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Opponent | yes | 4 | 3 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 177 |
| L1323 | 3 | 1 | Opponent | no | 14 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 6 | 2 | 0 | 1 | 0 | 0 | 297 |
| L1435 | 1 | 1 | Mine | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 371 |
| L1629 | 3 | 1 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 436 |
| L1629 | 3 | 1 | Opponent | no | 3 | 4 | 1 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 973 |
| L1727 | 5 | 1 | Opponent | no | - | 6 | 2 | 7 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 4 | 0 | 0 | 0 | 0 | 234 |
| L1827 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 190 |
| L1927 | 1 | 1 | Mine | no | 6 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 3 | 0 | 0 | 0 | 133 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 407 |
| L2029 | 1 | 1 | Opponent | no | 4 | 2 | 5 | 3 | 0 | 0 | 0 | 122 |
| L2131 | 1 | 1 | Mine | no | 0 | 4 | 1 | 4 | 0 | 0 | 0 | 330 |
| L2131 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 3 | 0 | 0 | 0 | 72 |
| L2235 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 624 |
| L2429 | 5 | 1 | Mine | no | - | 5 | 4 | 2 | 0 | 0 | 0 | 235 |
| L2429 | 5 | 1 | Opponent | yes | - | 1 | 3 | 5 | 0 | 0 | 0 | 205 |
| L2535 | 3 | 1 | Mine | no | 3 | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 5 | 0 | 0 | 0 | 125 |
| L2735 | 5 | 1 | Mine | no | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 5 | 4 | 0 | 0 | 0 | 751 |
| L3033 | 3 | 1 | Mine | no | 4 | 2 | 4 | 4 | 0 | 0 | 0 | 98 |
| L3033 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 3 | 0 | 0 | 0 | 255 |
| **Average** | | | Mine | 20% | 2.6 | 2.8 | 1.9 | 1.9 | 0.1 | 0.0 | 0.0 | 266.8 |
| **Average** | | | Opponent | 27% | 4.0 | 2.9 | 2.0 | 2.5 | 0.3 | 0.0 | 0.0 | 166.2 |

### KPIs: base-s1-882d875-p2

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (42 of 165) | 8% (13 of 161) | 17% (55 of 326) |
| Winner chose to follow up after the loser gave ground |  | 80% (37 of 46); on the table 80% | 90% (45 of 50); on the table 92% | 85% (82 of 96); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (4 of 6); on the table 67% | 57% (4 of 7); on the table 57% | 62% (8 of 13); on the table 62% |
| Winner chose to pursue after the loser fled |  | 52% (11 of 21); on the table 62% | 75% (15 of 20); on the table 75% | 63% (26 of 41); on the table 68% |
| Winner chose to follow up or pursue (all three) |  | 71% (52 of 73); on the table 74% | 83% (64 of 77); on the table 84% | 77% (116 of 150); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 32% (108 of 342) | 27% (42 of 156) | 30% (150 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (108 of 266) | 33% (42 of 126) | 38% (150 of 392) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 65% (24 of 37) | 55% (28 of 51) | 59% (52 of 88) |
| Points that never fought | lower | 52% (37514 of 71583) | 54% (39193 of 71989) | 53% (76707 of 143572) |
|   infantry points that never fought | lower | 63% (10224 of 16324) | 79% (11056 of 14029) | 70% (21280 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (185 of 284) | 68% (201 of 297) | 66% (386 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 85% (17 of 20); 1.5 uses a game | 83% (15 of 18); 0.8 uses a game | 84% (32 of 38); 1.2 uses a game |
| Bound items with another spell used |  | 44% (8 of 18); 0.4 uses a game | 50% (1 of 2); 0.0 uses a game | 45% (9 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (38137 of 60231) | 61% (38789 of 63281) | 62% (76926 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (36%) | 1.2 (38%) | 3.5 (36%) |
| MARCHED: its unit marched | 1.4 (21%) | 0.7 (21%) | 2.0 (21%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.9 (15%) | 0.3 (11%) | 1.3 (13%) |
| REAR RANK: in a rear rank | 0.3 (5%) | 0.2 (5%) | 0.5 (5%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.8 (12%) | 0.4 (12%) | 1.2 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (4%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.1 (2%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.4 | 2.1 | 4.2 | 0.7 | 1.4 |
| not cast | 3.7 | 3.6 | 2.9 | 9.7 | 1.6 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.1 (60%) | 0.4 (13%) | 3.5 (36%) | 0.2 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (21%) | 0.2 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.2 (5%) | 0.5 (16%) | 1.3 (13%) | 0.2 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.3 (9%) | 0.3 (9%) | 0.5 (5%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (6%) | 0.0 (0%) | 0.2 (2%) | 0.1 (7%) | 0.2 (1%) |
| GONE: slain | 0.6 (16%) | 0.0 (1%) | 0.4 (14%) | 1.2 (12%) | 0.2 (16%) | 1.8 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.4 (12%) | 0.4 (14%) | 0.3 (3%) | 0.0 (0%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.1 (3%) | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (4%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.5 (33%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (62%) | 0.2 (5%) | 0.8 (28%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.7 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.9 a game | 1.1 a game |
| stood (cast and not dispelled) | 54% (25 of 46) | 52% (16 of 31) | 53% (41 of 77) |
| the unit moved after it | 60% (15 of 25) | 75% (12 of 16) | 66% (27 of 41) |
| it charged on its next turn | 0% (0 of 25) | 6% (1 of 16) | 2% (1 of 41) |
| the enemy charged it first | 28% (7 of 25) | 6% (1 of 16) | 20% (8 of 41) |
| it fought by the end of its next turn | 8% (2 of 25) | 6% (1 of 16) | 7% (3 of 41) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (2 of 25) | 0% (0 of 16) | 5% (2 of 41) |
| none of these (no charge, no fight, no charge escaped) | 64% (16 of 25) | 88% (14 of 16) | 73% (30 of 41) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (519 of 883) | 53% (437 of 818) | 56% (956 of 1701) |
|   cavalry | 60% (53 of 88) | 58% (97 of 167) | 59% (150 of 255) |
|   character | 54% (55 of 101) | 28% (34 of 120) | 40% (89 of 221) |
|   chariot | 61% (57 of 93) | 67% (39 of 58) | 64% (96 of 151) |
|   infantry | 50% (134 of 269) | 53% (161 of 301) | 52% (295 of 570) |
|   monster | 52% (25 of 48) | 69% (34 of 49) | 61% (59 of 97) |
|   war machine | 69% (195 of 284) | 59% (72 of 123) | 66% (267 of 407) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.4 (14%) | 1.3 (13%) | 2.8 (13%) |
| CHARGED: it charged | 0.8 (8%) | 1.6 (15%) | 2.5 (12%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (5%) | 0.6 (6%) | 1.1 (5%) |
| MOVED: a war machine that moved | 1.5 (15%) | 0.5 (4%) | 2.0 (10%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| NO TARGET IN RANGE | 3.3 (33%) | 2.8 (27%) | 6.1 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.8 (7%) | 1.2 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (15%) | 1.7 (16%) | 3.2 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.4 (4%) | 0.7 (3%) |
| OTHER BAR | 0.2 (2%) | 0.7 (7%) | 0.9 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 1.2 | 84% | 4.0 pts | 25 pts |
| character | 2.5 | 1.1 | 73% | 9.9 pts | 25 pts |
| chariot | 2.7 | 1.4 | 68% | 18.1 pts | 48 pts |
| infantry | 11.2 | 3.7 | 76% | 7.7 pts | 86 pts |
| monster | 2.0 | 0.6 | 79% | 7.7 pts | 15 pts |
| war machine | 7.4 | 6.6 | 58% | 25.8 pts | 192 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.6 | 3.8 | 3.2 |
| Charges that made contact a game | 1.9 | 2.8 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.54 declared, 0.38 contact (26 units) | 0.69 declared, 0.46 contact (13 units) | 0.59 declared, 0.41 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.83 contact (6 units) | 0.79 declared, 0.64 contact (14 units) | 0.80 declared, 0.70 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.22 contact (253 units) | 0.38 declared, 0.28 contact (305 units) | 0.35 declared, 0.25 contact (558 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (46 of 73) | 72% (13 of 18) | 58% (7 of 12) | 64% (66 of 103) |
| Character in a unit | 80% (32 of 40) | 84% (16 of 19) | 100% (4 of 4) | 83% (52 of 63) |
| Character on its own | 84% (27 of 32) | 60% (21 of 35) | 44% (27 of 62) | 58% (75 of 129) |
| Chariot | 59% (10 of 17) | 85% (11 of 13) | - | 70% (21 of 30) |
| Infantry | 67% (63 of 94) | 53% (18 of 34) | 33% (1 of 3) | 63% (82 of 131) |
| Monster | 55% (16 of 29) | 44% (4 of 9) | - | 53% (20 of 38) |
| Monstrous | 86% (12 of 14) | 79% (11 of 14) | - | 82% (23 of 28) |
| War Machines | 81% (46 of 57) | 50% (1 of 2) | - | 80% (47 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 69% (9 of 13); on the table 69% | 37% (38 of 102) | 44% | 45% (10 of 22) | 100% (6 of 6); 5.2 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 75% (6 of 8); on the table 75% | 33% (12 of 36) | 46% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 62% (5 of 8); on the table 75% | - | 72% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 67% (6 of 9); on the table 67% | 44% (21 of 48) | 64% | 64% (49 of 76) | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 100% (5 of 5); on the table 100% | 26% (36 of 138) | 61% | 67% (36 of 54) | 86% (12 of 14); 4.8 uses a game | 50% (1 of 2); 0.5 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 67% (6 of 9); on the table 78% | 11% (2 of 18) | 57% | 64% (21 of 33) | 100% (3 of 3); 2.2 uses a game | 36% (5 of 14); 1.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 83% (5 of 6); on the table 83% | - | 62% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | - | - | 56% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 78% (7 of 9); on the table 78% | 6% (1 of 18) | 46% | 68% (19 of 28) | 75% (3 of 4); 1.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 89% (8 of 9); on the table 89% | 33% (4 of 12) | 16% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 100% (2 of 2); on the table 100% | 28% (5 of 18) | 46% | 52% (13 of 25) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 50% (8 of 16); on the table 50% | - | 48% | 56% (14 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 93% (26 of 28); on the table 96% | 21% (14 of 66) | 42% | 74% (40 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 77% (10 of 13); on the table 77% | 28% (5 of 18) | 51% | 74% (54 of 73) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 87% (13 of 15); on the table 87% | 50% (12 of 24) | 60% | 72% (56 of 78) | 57% (4 of 7); 0.9 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s1-882d875-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 55% (37) | 54% (22) | 55% (59) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.53 | 1.31 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.00 | 0.17 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.33 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.03 | 0.00 | 0.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.06 | 0.06 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.19 | 0.31 | 0.50 |

### Quality by phase: base-s1-882d875-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.4 |
| Strategy | Charge objectives carried out (made contact) | 53% (41 of 77) | 52% (63 of 121) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (144 of 377) | 37% (80 of 217) |
| Strategy | Support requests answered (helper made contact too) | 57% (4 of 7) | 45% (10 of 22) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 25% (3 of 12) | 40% (4 of 10) |
| Strategy | Joined characters whose unit fought | 34% (20 of 59) | 17% (7 of 42) |
| Strategy | Lone characters that fought | 59% (51 of 86) | 67% (54 of 81) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.9 | 2.5 |
| Movement | Points that never moved of their own | 266.8 | 166.2 |
| Movement | Fights charged into per game | 1.8 | 2.4 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 50, net +1 | 21 of 76, net +54 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 50, net +13 | 8 of 76, net +189 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 50, net +98 | 10 of 76, net +33 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 13 of 50, net +55 | 20 of 76, net +112 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 10.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (143 of 348) | 48% (185 of 382) |
| Shooting | Points destroyed by shooting units | 74.6 | 60.1 |
| Shooting | War machine shots | 5.4 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 66% (128 of 195) | 58% (42 of 72) |
| Shooting | Points destroyed by war machines | 56.5 | 31.4 |
| Magic | Magic missiles cast | 1.8 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (21 of 63) | 30% (8 of 27) |
| Magic | Wounds caused by magic missiles | 3.5 | 0.8 |
| Magic | Wounds caused by other spells | 0.8 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 23.1 | 22.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.5 / 0.5 / 0.1 | 2.1 / 0.3 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 173.9 | 302.0 |
| Combat | Points run down | 31.7 | 74.1 |
| Combat | Net points per charged fight, damage counted | +67 | +110 |
| Combat | Net per 100 charger points, damage counted | +25.8 | +34.2 |
| Combat | First round won (charged fights) | 77% | 72% |
| Combat | Net points per charged fight | +62 | +106 |
| Combat | Net points per supported fight / lone fight | -112 / +73 | +101 / +107 |
| Combat | Charged fights on a top-3 enemy unit | 15 of 66 | 37 of 88 |
| Game | Points lost | 591.7 | 491.2 |
| Game | VP from objectives | 590.3 | 696.7 |
| Game | Lone holders (player turns) | 2.6 | 4.0 |

- Mine won / drew / lost: 12 / 5 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -234 VP
- The side that went first won 14 of 31 games with a winner
- Points traded per game (both sides' losses): 1083
- Games not ended: 0; findings 6, warnings 0

### Opponent rules: base-s1-882d875-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 5.6 |
| AFTERMATH IN POINTS | 0.3 | +34.9 | 0.0 | 6.2 | 0.0 | +2.8 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.1 | +6.3 | 0.0 | 0.0 | 0.2 | +16.8 | 0.0 | 14.5 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 15.2 | +195.3 | 0.0 | 293.3 | 21.5 | +243.6 | 0.0 | 177.8 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 26.5 | 0.3 | +0.0 | 0.0 | 9.2 |
| BACKUP TARGETS | 0.2 | +1.2 | 0.0 | 2.7 | 0.2 | +1.6 | 0.0 | 0.0 |
| BEST PRIZE | 0.0 | -2.3 | 0.5 | 0.0 | 0.1 | -4.6 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -14.7 | 11.4 | 0.0 | 0.3 | -54.9 | 25.0 | 5.4 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 3.5 | - | - | - | - |
| CANNON PLAN MISSED | 0.4 | +0.0 | 130.1 | 3.5 | 0.1 | +0.0 | 17.5 | 3.2 |
| CANNON PLANNED TARGET | 5.3 | +196.8 | 414.2 | 82.5 | 1.9 | +73.2 | 127.9 | 31.2 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 7.5 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.0 | -4.1 | 0.0 | 0.0 |
| CAST JOB | 0.9 | +15.2 | 35.7 | 9.4 | 0.4 | +3.4 | 10.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +15.0 | 3.3 | 0.0 | 0.1 | +3.9 | 19.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 16.5 | 0.5 | +0.0 | 0.0 | 16.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +27.1 | 0.0 | 17.2 | 1.1 | +54.9 | 0.0 | 34.4 |
| CHAFF PASSED | 0.2 | -0.4 | 3.1 | 0.0 | 0.3 | -0.5 | 4.7 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -2.5 | 0.0 | 0.0 | 0.1 | -1.0 | 3.2 | 5.7 |
| CHARACTER GUNS | 1.3 | +0.0 | 0.0 | 13.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 10.7 | -579.4 | 0.0 | 318.3 | 10.8 | -674.7 | 0.0 | 414.1 |
| CHARGE NOT DECLARED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 86.1 | 34.1 | 2.1 | +0.0 | 201.9 | 68.4 |
| CHARGER SLAIN LOST | 0.2 | -8.7 | 21.5 | 7.2 | 0.2 | -4.4 | 23.1 | 1.9 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 9.4 | 31.1 | 0.2 | +0.0 | 19.1 | 14.2 |
| CONVEYANCE SEARCH | 1.1 | +235.0 | 62.8 | 55.6 | 0.7 | +101.4 | 15.8 | 24.1 |
| COVER ONCE | 6.2 | -530.4 | 0.0 | 153.7 | 4.1 | -264.8 | 0.0 | 37.1 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.4 | -2.3 | 29.4 | 11.3 | 1.1 | -17.8 | 85.1 | 47.2 |
| DEPLOY BY FIGURES | 8.0 | +9.4 | 0.0 | 23.6 | 7.9 | +54.1 | 0.0 | 11.1 |
| EDGE GIVE GROUND | 0.1 | +1.2 | 16.5 | 0.0 | 0.1 | +1.4 | 10.6 | 14.2 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.9 | +6.3 | 134.4 | 58.9 | 3.1 | +13.7 | 245.2 | 76.3 |
| FALLBACK BY WORTH | 0.2 | +0.2 | 0.0 | 1.2 | 0.2 | +0.0 | 0.0 | 6.2 |
| FALLS SHORT | 7.3 | +114.9 | 0.0 | 102.0 | 13.9 | +195.4 | 0.0 | 132.6 |
| FEATURE BUFFS | 2.3 | +50.7 | 0.0 | 22.3 | 1.1 | +19.7 | 0.0 | 3.8 |
| FIGHT TO THE END | 0.6 | +20.5 | 20.4 | 32.3 | 1.3 | +54.6 | 89.4 | 44.0 |
| FIRE IN ORDER | 0.1 | +0.0 | 14.0 | 0.0 | 0.2 | +0.0 | 10.4 | 0.0 |
| FIVE ACTION | 88.2 | +4866.4 | 1285.8 | 1114.1 | 93.0 | +5539.3 | 1013.6 | 963.8 |
| FLANK NOT WEIGHED | 4.6 | +0.0 | 0.0 | 136.4 | 4.5 | +0.0 | 0.0 | 109.9 |
| FOCUS FIRE | 0.0 | +0.2 | 0.9 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.5 | +67.3 | 0.0 | 15.2 | 0.9 | +160.2 | 0.0 | 8.9 |
| FOUR ROUNDS | 2.4 | +208.7 | 155.4 | 78.9 | 3.8 | +350.4 | 321.4 | 83.4 |
| FRIEND CHARGES FIRST | 0.0 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.4 | -14.9 | 0.0 | 0.9 | 0.5 | -3.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +3.8 | 0.0 | 9.5 | 0.1 | +2.5 | 0.0 | 6.5 |
| GIVES UP | 0.1 | -1.0 | 4.4 | 3.2 | 0.4 | -18.4 | 25.6 | 0.0 |
| GROUND FLIERS | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.0 | +10.8 | 32.0 | 12.2 | 0.9 | +37.7 | 15.6 | 11.9 |
| GUN MASK | 0.6 | +24.5 | 0.0 | 0.0 | 0.6 | +18.2 | 0.0 | 26.2 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 22.8 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.5 | +0.0 | 0.0 | 88.4 | 3.6 | +0.0 | 0.0 | 123.7 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.4 |
| HIS CHARGE DENIED | 0.2 | +3.3 | 9.2 | 17.8 | 0.3 | +14.0 | 43.5 | 5.4 |
| HIS CHARGE LIST | 5.2 | +0.0 | 0.0 | 48.1 | 4.9 | +0.0 | 0.0 | 45.6 |
| HIS FIGHT TOGETHER | 1.9 | -73.3 | 0.0 | 90.5 | 1.6 | -49.1 | 0.0 | 108.7 |
| HIS LEGAL MOVES | 4.9 | +0.0 | 0.0 | 93.5 | 3.8 | +0.0 | 0.0 | 18.0 |
| HIS MOVE AND SHOT | 4.0 | -58.4 | 0.0 | 117.0 | 3.6 | -66.2 | 0.0 | 88.4 |
| HIS MOVE AS HE DECIDES | 41.4 | +14.8 | 510.7 | 0.0 | 33.1 | +13.3 | 553.1 | 0.0 |
| HIS MOVE WHY | 34.4 | +0.0 | 0.0 | 410.7 | 40.5 | +0.0 | 0.0 | 402.6 |
| HIS ONE MOVE | 18.1 | +28.8 | 0.0 | 210.9 | 19.8 | -27.1 | 4.7 | 89.1 |
| HIS ONE QUARTER | 2.5 | +0.0 | 0.0 | 17.1 | 3.7 | +0.0 | 0.0 | 75.2 |
| HIS OWN BEST MOVE | 2.1 | +0.0 | 0.0 | 43.5 | 1.5 | +0.0 | 0.0 | 10.6 |
| HIS RANDOM MOVE | 6.1 | +0.0 | 0.0 | 52.8 | 2.8 | +0.0 | 0.0 | 28.9 |
| HIS SHOT LIST | 35.6 | +1285.2 | 0.0 | 516.4 | 48.4 | +2151.2 | 0.0 | 502.0 |
| HIS TURN DENIED | 1.1 | +16.6 | 86.4 | 29.6 | 2.3 | +102.1 | 213.2 | 56.9 |
| HOLD ODDS | 17.4 | +0.0 | 0.0 | 104.9 | 16.4 | +0.0 | 0.0 | 111.6 |
| HOLDER ASSIGNMENT | 10.0 | +942.2 | 0.0 | 55.9 | 10.0 | +951.3 | 0.0 | 75.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.1 | -73.6 | 131.9 | 66.1 | 3.3 | -159.9 | 274.4 | 71.6 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 4.6 | 0.0 |
| HUNT IN PAIRS | 0.3 | +14.0 | 0.0 | 29.8 | 0.6 | +15.8 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +5.5 | 5.3 | 0.0 | 0.1 | +13.1 | 4.6 | 0.0 |
| HUNT THE GUNS | 0.0 | +5.6 | 5.3 | 0.0 | 0.1 | +32.0 | 7.4 | 0.0 |
| IDLE COST | 4.8 | -65.3 | 0.0 | 59.0 | 11.2 | -159.3 | 0.0 | 161.7 |
| JOINT CHARGE NOW | 0.4 | +12.8 | 33.9 | 20.8 | 1.1 | +53.5 | 82.8 | 12.5 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.2 | 0.0 | 0.0 | 0.0 | -0.1 | 2.7 | 0.0 |
| JOINT ON THE TABLE | 0.0 | +0.1 | 2.0 | 0.0 | 0.0 | +6.2 | 6.6 | 0.0 |
| KEEP FALLS | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.9 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 14.6 |
| LANE BY FIGURES | 0.7 | +26.2 | 0.0 | 0.0 | 0.9 | +44.5 | 0.0 | 16.6 |
| LATE ONLY FROM HERE | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.2 | +0.0 | 154.7 | 185.6 | 6.2 | +0.0 | 273.2 | 239.6 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +1.7 | 4.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +24.1 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.3 | 5.5 | 6.6 | 0.3 | -0.4 | 31.2 | 1.4 |
| LOST AFTER ESCAPE | 1.4 | -0.8 | 106.2 | 39.4 | 2.1 | -0.6 | 178.9 | 39.0 |
| LOST CHARGE | 0.0 | -0.2 | 3.2 | 0.0 | 0.0 | -0.1 | 10.1 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -28.6 | 0.0 | 4.9 | 0.2 | -15.4 | 0.0 | 7.1 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +2.1 | 0.0 | 7.1 |
| MANOEUVRE | 1.0 | -1.2 | 0.0 | 4.2 | 0.7 | +1.3 | 0.0 | 5.6 |
| MARCH AT ESCAPER | 0.1 | +1.4 | 0.0 | 9.0 | 0.1 | +2.0 | 0.0 | 15.0 |
| MARCH BY THE SUM | 0.2 | +26.2 | 0.0 | 0.0 | 0.4 | +27.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +34.3 | 0.0 | 24.9 | 0.8 | +42.3 | 0.0 | 17.1 |
| MARCH ODDS | 0.0 | +0.2 | 0.0 | 10.2 | - | - | - | - |
| MARCH OF THE TABLE | 0.2 | +6.7 | 0.0 | 0.0 | 0.1 | +1.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +44.3 | 0.0 | 52.5 | 0.6 | +23.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.2 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 11.6 |
| MAX FOR POSITIONING | 2.6 | +40.9 | 0.0 | 102.3 | 3.2 | +54.9 | 0.0 | 23.4 |
| MISSILES IN THE MOVE | 4.0 | +83.1 | 0.0 | 74.9 | 2.7 | +47.8 | 0.0 | 41.4 |
| MISSILES NEXT TURN | 5.5 | +68.2 | 0.0 | 142.1 | 3.7 | +40.8 | 0.0 | 71.6 |
| MISSILES ON ONE TARGET | 0.3 | -6.0 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | 0.3 | +39.6 | 0.0 | 1.7 | 0.2 | +69.5 | 0.0 | 1.7 |
| MOVE ORDER | 1.2 | +0.0 | 1.8 | 18.1 | 2.6 | +0.0 | 8.9 | 43.6 |
| MOVE SPELL IN RANGE | 0.2 | +7.4 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.2 | -8.4 | 0.0 | 2.6 | 0.2 | -15.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 29.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.7 | +567.4 | 0.0 | 140.7 | 7.2 | +684.0 | 0.0 | 62.6 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.2 | +298.2 | 0.0 | 64.0 | 6.1 | +248.0 | 0.0 | 61.2 |
| NEXT CHARGE BY LIST | 5.4 | -152.8 | 20.3 | 67.2 | 7.6 | -314.3 | 9.4 | 92.9 |
| NEXT OBJECTIVE NEARER | 0.1 | -1.7 | 0.0 | 0.0 | 0.1 | -13.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.2 | -90.2 | 152.0 | 70.3 | 2.8 | -132.6 | 238.7 | 71.7 |
| NO LATE CUT | 0.8 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 14.6 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| NOT TURNED | 0.2 | -1.7 | 0.0 | 6.5 | 0.3 | -1.5 | 0.0 | 10.1 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 12.1 | 0.7 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -178.0 | 8.8 | 48.2 | 4.3 | -178.4 | 19.9 | 63.0 |
| ONE CHARGE A CHARGER | 4.0 | +0.0 | 0.0 | 109.8 | 3.7 | +0.0 | 0.0 | 77.4 |
| ONE FIGHT FORMULA | 4.5 | -81.5 | 0.0 | 98.6 | 5.1 | -109.8 | 0.0 | 57.2 |
| ONE OBJECTIVE FORMULA | 4.6 | +43.2 | 0.0 | 48.4 | 3.8 | +31.7 | 0.0 | 39.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.2 | -11.3 | 0.0 | 0.0 |
| ONE ROUTE | 1.2 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 11.6 |
| ONE TARGET A SHOOTER | 25.8 | +603.3 | 0.0 | 373.1 | 35.4 | +936.7 | 0.0 | 327.6 |
| OPENS A LANE | 0.0 | +0.4 | 6.5 | 0.0 | 0.1 | +2.1 | 12.9 | 0.0 |
| OPENS UP | 0.1 | +12.9 | 4.4 | 0.0 | 0.4 | +22.9 | 30.6 | 0.0 |
| OVERRUNS AWAY | 0.2 | +4.5 | 20.0 | 14.5 | 0.6 | +32.9 | 48.1 | 33.4 |
| OWN CAST FIRST | 0.1 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +7.3 | 0.0 | 3.1 | 0.3 | +11.8 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.0 | -0.5 | 0.0 | 0.0 | 0.1 | -3.9 | 0.0 | 0.0 |
| PLAN RESULT | 40.8 | +730.7 | 430.8 | 815.1 | 43.6 | +601.8 | 392.7 | 634.5 |
| PROMISE BELOW ZERO | 0.2 | +0.0 | 0.0 | 14.4 | 0.2 | +0.0 | 0.0 | 1.4 |
| PROMISE BY ITS OWN SUM | 7.4 | -185.8 | 0.0 | 56.6 | 8.9 | -258.6 | 0.0 | 18.3 |
| PROMISE HOLDS THE SPOT | 0.0 | +0.4 | 0.0 | 3.4 | - | - | - | - |
| PROMISE IN STEPS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.6 | -0.1 | 0.0 | 4.7 | 0.5 | -0.2 | 0.0 | 12.8 |
| PROMISE READS THE TABLE | 0.3 | -13.8 | 0.0 | 3.4 | 0.2 | -6.6 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.0 | -0.0 | 0.0 | 2.4 | 0.0 | -0.0 | 0.0 | 3.0 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -13.7 | 0.0 | 0.0 |
| QUARTER ODDS | 16.1 | +1660.8 | 60.1 | 152.6 | 18.2 | +1886.1 | 142.6 | 137.7 |
| RANDOM MOVE BY FIGURES | 1.0 | +22.8 | 0.0 | 17.5 | 1.4 | +38.2 | 0.0 | 32.8 |
| REAL GROUND | 1.2 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 11.6 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -1.5 | 0.0 | 8.6 | 1.0 | -19.4 | 0.0 | 26.4 |
| REDIRECT COUNTER | 1.8 | +71.0 | 0.0 | 24.9 | 2.3 | +128.8 | 0.0 | 47.1 |
| REDIRECT WEIGHED | 0.1 | +3.6 | 0.0 | 0.0 | 0.2 | +3.4 | 7.4 | 1.4 |
| REFORMS TO MEET IT | 1.1 | -39.3 | 0.0 | 13.6 | 1.8 | -30.8 | 0.0 | 21.5 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 38.6 | 0.2 | +0.0 | 0.0 | 8.7 |
| RESERVE FALL BACK | 0.4 | +19.3 | 0.0 | 2.2 | 0.7 | +41.1 | 0.0 | 16.0 |
| RESTRAINS TO SHOOT | 0.1 | +3.0 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 3.2 |
| RISK BY ARC | 1.7 | +55.6 | 109.9 | 53.1 | 2.6 | +18.0 | 210.5 | 64.0 |
| RISK BY HIS FIGURE | 20.1 | -459.3 | 0.0 | 477.8 | 18.2 | -353.8 | 0.0 | 408.2 |
| RISK ON THE WAY | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -7.5 | 36.9 | 0.0 | 1.4 | -33.0 | 128.5 | 32.7 |
| RUN DOWN | 1.6 | -19.3 | 112.8 | 36.3 | 2.4 | -25.6 | 189.7 | 46.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.1 | +2.9 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.1 | -1.1 | 3.1 | 0.0 | 0.0 | -0.7 | 2.4 | 0.0 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.5 | +1.2 | 0.0 | 3.8 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 3.8 |
| SCREEN BY WHAT IT SAVES | 0.2 | -4.5 | 0.0 | 5.8 | 0.7 | -29.9 | 0.0 | 2.5 |
| SEARCH SPOT | 0.5 | +8.0 | 0.0 | 1.2 | 0.4 | +4.0 | 0.0 | 3.9 |
| SECOND LOOK | 0.2 | +29.8 | 16.6 | 0.0 | 0.3 | +25.5 | 39.9 | 11.4 |
| SELF MOVE SPELL | 0.2 | +10.5 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.5 | +39.3 | 4.0 | 21.9 | 2.2 | +44.8 | 4.7 | 32.4 |
| SET UP TOGETHER | - | - | - | - | 0.5 | +3.0 | 0.0 | 12.2 |
| SET-UP ANY TARGET | 0.1 | +8.1 | 0.0 | 0.0 | 0.1 | +12.2 | 4.4 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +7.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.4 | +112.2 | 57.8 | 15.6 | 1.9 | +84.1 | 120.5 | 11.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -13.9 | 22.6 | 3.5 | 0.2 | -7.4 | 34.8 | 0.0 |
| SHOT RISK POINTS | 16.1 | -31.1 | 0.0 | 329.4 | 21.4 | -117.0 | 0.0 | 509.6 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 1.8 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.1 | +635.6 | 0.0 | 209.8 | 13.5 | +440.4 | 0.0 | 131.9 |
| SPELL OFF EDGE | 0.0 | +1.9 | 2.9 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +68.6 | 0.0 | 0.0 | 0.3 | +49.4 | 4.4 | 0.0 |
| SPELL WORTH | 0.9 | +11.6 | 65.3 | 48.9 | 1.6 | +20.6 | 54.2 | 54.2 |
| SPELLS IN THE FIGHT | 0.4 | -1.5 | 47.4 | 9.7 | 0.8 | -10.0 | 60.3 | 13.0 |
| SPOT AS THE GAME MOVES | 8.1 | +0.0 | 0.0 | 121.1 | 9.9 | +0.0 | 0.0 | 144.9 |
| STAND AND SHOOT | 0.4 | -5.4 | 37.9 | 17.8 | 0.7 | -8.2 | 47.9 | 9.6 |
| STANDS FOR A REASON | 0.9 | +0.0 | 3.9 | 1.9 | 1.7 | +0.0 | 25.7 | 0.0 |
| STANDS STILL | 43.9 | +0.0 | 1130.4 | 439.3 | 33.7 | +0.0 | 692.2 | 235.7 |
| STANDS TO CAST | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 21.5 | -98.8 | 478.2 | 185.2 | 18.3 | +136.1 | 347.5 | 158.7 |
| STOPS | 0.0 | +0.1 | 5.3 | 0.0 | 0.1 | +1.6 | 7.4 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.1 | +445.6 | 0.0 | 79.6 | 7.6 | +458.5 | 0.0 | 22.6 |
| SUPPORT NARROWED | 0.3 | +0.0 | 6.7 | 0.0 | 0.2 | +0.0 | 21.9 | 3.8 |
| SUPPORT WORKED OUT | 7.1 | +445.6 | 0.0 | 79.6 | 7.6 | +458.5 | 0.0 | 22.6 |
| SURE REACH TOGETHER | 0.1 | +3.2 | 0.0 | 0.0 | 0.4 | +2.3 | 0.0 | 6.8 |
| THE DEARER SUM KEEPS ITS PLAN | 1.4 | +0.0 | 0.0 | 6.5 | 1.2 | +0.0 | 0.0 | 12.7 |
| THE PROMISE ADDS | 0.2 | -7.1 | 0.0 | 3.4 | 0.1 | -7.1 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.9 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.4 | +0.0 | 0.0 | 369.4 | 37.1 | +0.0 | 0.0 | 362.5 |
| TIED UP BY THE SUM | 0.8 | +71.9 | 55.8 | 16.0 | 0.8 | +91.2 | 52.1 | 14.0 |
| TIME ON OUR SIDE | 31.6 | +344.1 | 14.0 | 317.3 | 18.5 | +176.9 | 16.1 | 86.1 |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 36.3 | 2.4 | +0.0 | 0.0 | 9.3 |
| WALKS ON ITS ROUTE | 0.1 | +0.2 | 0.0 | 0.0 | 0.0 | -2.1 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +5.0 | 0.0 | 17.2 | 0.1 | +4.2 | 3.5 | 3.8 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 1.8 | 12.2 | 0.4 | +0.0 | 13.9 | 0.0 |
| WHAT THE JOINER ADDS | 0.1 | +0.5 | 5.8 | 6.4 | 0.4 | +0.1 | 15.6 | 10.3 |
| WHO GETS IN | - | - | - | - | 0.0 | +6.2 | 6.6 | 0.0 |
| WHO HITS BACK | 0.3 | +35.9 | 0.0 | 0.0 | 0.2 | +29.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +0.7 | 5.8 | 3.2 | 0.2 | +1.6 | 11.1 | 5.2 |
| WHOLE FIGHT GAIN | 0.1 | +1.8 | 6.5 | 0.0 | 0.2 | +11.7 | 34.5 | 0.0 |
| WIDER SPREAD | 1.6 | -4.3 | 98.6 | 23.9 | 2.7 | -5.8 | 241.4 | 50.4 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +128.2 | 0.0 | 45.4 | 3.1 | +132.2 | 0.0 | 107.0 |

### Rule changes: base-s1-882d875-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2681 | 2681 | 1670 | 46.39 | +0 | +0.0 |
| HIS MOVE WHY | 2697 | 2697 | 1486 | 41.28 | +0 | +0.0 |
| ARMY TABLE | 1320 | 1320 | 930 | 25.83 | +16333 | +17.6 |
| HIS SHOT LIST | 3026 | 2896 | 823 | 22.86 | +18897 | +23.0 |
| HOLDER ASSIGNMENT | 719 | 719 | 673 | 18.69 | +41821 | +62.1 |
| ONE TARGET A SHOOTER | 2205 | 2106 | 453 | 12.58 | +5569 | +12.3 |
| LEGAL CHARGES ONLY | 374 | 374 | 374 | 10.39 | +0 | +0.0 |
| DEPLOY BY FIGURES | 575 | 575 | 348 | 9.67 | +4604 | +13.2 |
| OFF BEST | 273 | 273 | 273 | 7.58 | -12833 | -47.0 |
| HIS ONE MOVE | 1364 | 1323 | 266 | 7.39 | +0 | +0.0 |
| THE TABLE AGAIN | 430 | 430 | 263 | 7.31 | +0 | +0.0 |
| TIME ON OUR SIDE | 1802 | 1626 | 259 | 7.19 | +934 | +3.6 |
| FIVE ACTION | 6524 | 6284 | 236 | 6.56 | +13145 | +55.7 |
| MOVE TO CHARGE COMPUTED | 464 | 399 | 216 | 6.00 | +13154 | +60.9 |
| PROMISE BY ITS OWN SUM | 587 | 587 | 211 | 5.86 | -16000 | -75.8 |
| SHOT RISK POINTS | 1350 | 1289 | 193 | 5.36 | +7129 | +36.9 |
| SUPPORT ADDS | 530 | 512 | 190 | 5.28 | +7745 | +40.8 |
| SUPPORT WORKED OUT | 530 | 512 | 190 | 5.28 | +7745 | +40.8 |
| HARD STAY DROPPED | 145 | 145 | 145 | 4.03 | +0 | +0.0 |
| MOVE ORDER | 135 | 135 | 135 | 3.75 | +0 | +0.0 |
| FOUR ROUNDS | 222 | 211 | 114 | 3.17 | +4952 | +43.4 |
| QUARTER ODDS | 1237 | 1169 | 112 | 3.11 | +11087 | +99.0 |
| SHOOTS FROM THE BEST SPOT | 154 | 154 | 98 | 2.72 | +3321 | +33.9 |
| IDLE COST | 575 | 472 | 96 | 2.67 | +744 | +7.7 |
| ADVANCE LANE KEPT | 65 | 65 | 65 | 1.81 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 62 | 62 | 62 | 1.72 | +0 | +0.0 |
| CHARGE LOSSES | 775 | 737 | 62 | 1.72 | +5790 | +93.4 |
| LANE BY FIGURES | 57 | 57 | 57 | 1.58 | +2544 | +44.6 |
| JOINT CHARGE NOW | 55 | 55 | 55 | 1.53 | +2387 | +43.4 |
| CANNON PLANNED TARGET | 260 | 260 | 54 | 1.50 | -150 | -2.8 |
| RANDOM MOVE BY FIGURES | 88 | 88 | 52 | 1.44 | +2195 | +42.2 |
| STAY WORTH | 1433 | 1334 | 51 | 1.42 | +287 | +5.6 |
| RISK BY ARC | 157 | 152 | 50 | 1.39 | +1090 | +21.8 |
| COVER ONCE | 371 | 263 | 49 | 1.36 | +890 | +18.2 |
| CANNON SIGHT KEPT | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 48 | 48 | 48 | 1.33 | +8193 | +170.7 |
| SHOTS IN THE MOVE | 1031 | 846 | 48 | 1.33 | +2452 | +51.1 |
| CHAFF IN THE MOVE | 66 | 62 | 47 | 1.31 | +73 | +1.6 |
| FALLS SHORT | 761 | 655 | 46 | 1.28 | +364 | +7.9 |
| TIED UP BY THE SUM | 56 | 52 | 42 | 1.17 | +1206 | +28.7 |
| MAX FOR POSITIONING | 210 | 182 | 41 | 1.14 | +96 | +2.3 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RESERVE FALL BACK | 40 | 40 | 40 | 1.11 | +2174 | +54.4 |
| CHARGE NOW FIRST | 130 | 130 | 38 | 1.06 | -1688 | -44.4 |
| RISK BY HIS FIGURE | 1379 | 1301 | 37 | 1.03 | +3454 | +93.4 |
| SET UP BY THE SET | 132 | 129 | 36 | 1.00 | +2147 | +59.6 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2288 | +69.3 |
| MARCH CHECK | 52 | 47 | 33 | 0.92 | +722 | +21.9 |
| NEXT CHARGE BY LIST | 468 | 419 | 33 | 0.92 | +1191 | +36.1 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 175 | 175 | 31 | 0.86 | +0 | +0.0 |
| CAST JOB | 44 | 44 | 30 | 0.83 | +86 | +2.9 |
| HIS TURN DENIED | 124 | 120 | 28 | 0.78 | +929 | +33.2 |
| WOUNDS ON THE RANKS | 211 | 206 | 28 | 0.78 | +1007 | +36.0 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +49 | +2.0 |
| MARCH BY THE SUM | 22 | 22 | 22 | 0.61 | +1925 | +87.5 |
| PATHS CROSS | 22 | 22 | 22 | 0.61 | +687 | +31.2 |
| REDIRECT COUNTER | 146 | 124 | 22 | 0.61 | +1476 | +67.1 |
| CHAFF PASSED | 20 | 20 | 20 | 0.56 | -30 | -1.5 |
| MODEL FACING | 20 | 20 | 20 | 0.56 | +3928 | +196.4 |
| SECOND LOOK | 20 | 20 | 20 | 0.56 | +1991 | +99.5 |
| COMBAT PIVOT | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| NEARER NOT NEEDED | 478 | 468 | 18 | 0.50 | +743 | +41.3 |
| SEARCH SPOT | 32 | 32 | 18 | 0.50 | +434 | +24.1 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +1663 | +92.4 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| FIGHT TO THE END | 67 | 64 | 14 | 0.39 | +407 | +29.1 |
| GUN MASK | 41 | 38 | 14 | 0.39 | +684 | +48.9 |
| REDIRECT WEIGHED | 14 | 14 | 14 | 0.39 | +537 | +38.4 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| SURE REACH TOGETHER | 20 | 18 | 14 | 0.39 | +9 | +0.6 |
| MANOEUVRE | 61 | 61 | 13 | 0.36 | +183 | +14.1 |
| SUPPORT NARROWED | 19 | 19 | 13 | 0.36 | -1156 | -88.9 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.31 | +1356 | +123.2 |
| AFTERMATH WITH FRIENDS | 11 | 11 | 11 | 0.31 | +834 | +75.8 |
| CASTING BLOCK | 20 | 20 | 11 | 0.31 | +208 | +18.9 |
| ONE FIGHT FORMULA | 348 | 193 | 11 | 0.31 | +189 | +17.2 |
| OVERRUNS AWAY | 29 | 28 | 11 | 0.31 | +396 | +36.0 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| FIRE IN ORDER | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| MISSILES IN THE MOVE | 240 | 167 | 10 | 0.28 | +153 | +15.3 |
| ONE OBJECTIVE FORMULA | 300 | 231 | 10 | 0.28 | +662 | +66.2 |
| MARCH OF THE TABLE | 9 | 9 | 9 | 0.25 | -296 | -32.9 |
| MISSILES NEXT TURN | 331 | 240 | 9 | 0.25 | +29 | +3.2 |
| FEATURE BUFFS | 122 | 122 | 8 | 0.22 | +121 | +15.1 |
| REFUSING RETIRES | 20 | 20 | 8 | 0.22 | -3 | -0.3 |
| WAR ENGINE JOBS | 31 | 31 | 8 | 0.22 | -207 | -25.9 |
| FRIENDS SHOTS CHECKED | 7 | 7 | 7 | 0.19 | +226 | +32.4 |
| OPENS UP | 19 | 16 | 7 | 0.19 | +94 | +13.4 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 0.17 | -408 | -68.0 |
| CHARGE NOT DECLARED | 5 | 5 | 5 | 0.14 | -652 | -130.3 |
| PROMISE KNOWS THE FIGHT | 38 | 28 | 5 | 0.14 | -8 | -1.6 |
| PROMISE READS THE TABLE | 18 | 18 | 5 | 0.14 | +118 | +23.6 |
| FALL BACK GOOD ORDER | 182 | 174 | 4 | 0.11 | +174 | +43.5 |
| HIS FIGHT TOGETHER | 128 | 117 | 4 | 0.11 | +239 | +59.7 |
| HIS MOVE AND SHOT | 275 | 262 | 4 | 0.11 | +174 | +43.4 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONG SHOT | 17 | 17 | 4 | 0.11 | +3 | +0.9 |
| LOST AFTER ESCAPE | 126 | 122 | 4 | 0.11 | +7 | +1.8 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -160 | -40.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| SCREEN BY WHAT IT SAVES | 30 | 30 | 4 | 0.11 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 11 | 11 | 4 | 0.11 | +85 | +21.3 |
| WIDER SPREAD | 152 | 143 | 4 | 0.11 | +28 | +7.1 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -267 | -89.0 |
| HONEST WORTH | 195 | 184 | 3 | 0.08 | +35 | +11.6 |
| HUNT IN PAIRS | 31 | 17 | 3 | 0.08 | +172 | +57.4 |
| OWN CAST FIRST | 3 | 3 | 3 | 0.08 | -10 | -3.5 |
| WALKS ON ITS ROUTE | 3 | 3 | 3 | 0.08 | -69 | -22.9 |
| WHAT THE JOINER ADDS | 18 | 12 | 3 | 0.08 | +63 | +21.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.1 |
| EDGE GIVE GROUND | 10 | 9 | 2 | 0.06 | +5 | +2.7 |
| HIS CHARGE DENIED | 19 | 19 | 2 | 0.06 | +132 | +65.8 |
| JOINT ON THE TABLE | 2 | 2 | 2 | 0.06 | +227 | +113.4 |
| NO DOUBLE ROUNDS | 180 | 174 | 2 | 0.06 | +114 | +56.8 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +246 | +122.8 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.06 | -1 | -0.7 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -494 | -246.9 |
| REFORMS TO MEET IT | 105 | 83 | 2 | 0.06 | +1 | +0.3 |
| SAFER THAN THE JOB | 2 | 2 | 2 | 0.06 | +106 | +52.9 |
| WAR ENGINE CHARGES | 4 | 4 | 2 | 0.06 | +91 | +45.7 |
| WOUNDED STAYS OUT | 2 | 2 | 2 | 0.06 | -23 | -11.7 |
| BACKUP TARGETS | 12 | 5 | 1 | 0.03 | +3 | +3.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.03 | -148 | -147.9 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -81 | -81.2 |
| FACES THE THREAT | 1 | 1 | 1 | 0.03 | +18 | +17.9 |
| FALLBACK BY WORTH | 14 | 14 | 1 | 0.03 | +6 | +5.7 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +8 | +7.9 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +58 | +57.7 |
| MARCH ODDS | 1 | 1 | 1 | 0.03 | -5 | -5.3 |
| NEXT OBJECTIVE NEARER | 9 | 9 | 1 | 0.03 | +13 | +12.8 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +3 | +2.7 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.03 | +15 | +15.2 |
| SPELLS IN THE FIGHT | 43 | 42 | 1 | 0.03 | +9 | +8.8 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -1 | -0.6 |
| WHO GETS IN | 1 | 1 | 1 | 0.03 | +223 | +222.8 |
| WHOLE FIGHT | 10 | 7 | 1 | 0.03 | +13 | +13.4 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 17 | 16 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 17 | 17 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 43 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 92 | 83 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 18 | 18 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 64 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 54 | 54 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 330 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 32 | 29 | 0 | 0.00 | - | - |
| GIVES UP | 21 | 18 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GUN FIGURES | 69 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 218 | 213 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 363 | 354 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 315 | 295 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 222 | 210 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 127 | 127 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 322 | 304 | 0 | 0.00 | - | - |
| HOLD ODDS | 1216 | 1210 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 215 | 209 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 12 | 12 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 4 | not checked | - | - | - | - |
| LOST CHARGE | 2 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 13 | 13 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 11 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 45 | 45 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 93 | 90 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 11 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 9 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NO LATE CUT | 68 | 67 | 0 | 0.00 | - | - |
| NOT TURNED | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 54 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 278 | 260 | 0 | 0.00 | - | - |
| ONE ROUTE | 93 | 90 | 0 | 0.00 | - | - |
| OPENS A LANE | 6 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 3039 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 14 | 14 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 93 | 90 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 54 | 54 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 29 | 27 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 59 | 56 | 0 | 0.00 | - | - |
| RUN DOWN | 146 | 141 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET UP TOGETHER | 18 | 12 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 20 | 20 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 87 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 646 | 618 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 39 | 37 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 96 | 87 | 0 | 0.00 | - | - |
| STANDS STILL | 2791 | 2696 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 30 | 24 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 96 | not checked | - | - | - | - |
| THE PROMISE ADDS | 11 | 10 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2427 | not checked | - | - | - | - |
| WAITS AGAIN | 143 | 128 | 0 | 0.00 | - | - |

### Off best figure: base-s1-882d875-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 3.19 | 75.8 |
| JOB FIRST | gate | 2.53 | 3.17 | 38.6 |
| ARMY TABLE | rule | 1.58 | 2.00 | 52.7 |
| NO REASON | gate | 0.69 | 0.94 | 78.0 |
| HOLDER ASSIGNMENT | rule | 0.39 | 0.72 | 26.4 |
| CHARGE NOW FIRST | rule | 0.50 | 0.50 | 46.9 |
| JOINT CHARGE NOW | rule | 0.14 | 0.39 | 47.5 |
| SUPPORT NARROWED | rule | 0.22 | 0.08 | 105.1 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.14 | 29.8 |
| MARCH OF THE TABLE | rule | 0.14 | 0.08 | 37.0 |
| WAR ENGINE JOBS | rule | 0.06 | 0.17 | 25.9 |
| ONE PROMISE A TARGET | rule | - | 0.17 | 68.0 |
| CHAFF PASSED | rule | 0.06 | 0.08 | 6.0 |
| CHARGE NOT DECLARED | rule | - | 0.14 | 130.3 |
| PATHS CROSS | rule | 0.08 | 0.03 | 17.6 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.08 | 40.0 |
| TURN GATE | gate | 0.06 | 0.06 | 34.5 |
| BEST PRIZE | rule | 0.03 | 0.06 | 89.0 |
| OWN CAST FIRST | rule | 0.08 | - | 3.5 |
| AFTERMATH BAND | gate | - | 0.06 | 4.0 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.03 | 5.9 |
| PROMISE KNOWS THE FIGHT | rule | 0.03 | 0.03 | 3.8 |
| PROMISE READS THE TABLE | rule | 0.03 | 0.03 | 32.1 |
| PURSUES BIG PREY | rule | - | 0.06 | 246.9 |
| REFUSING RETIRES | rule | 0.06 | - | 0.7 |
| WOUNDED STAYS OUT | rule | 0.06 | - | 11.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 155.1 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 147.9 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 81.2 |
| FALLBACK | gate | - | 0.03 | 6.9 |
| FIGHT ORDER BAND | gate | 0.03 | - | 4.2 |
| MARCH ODDS | rule | 0.03 | - | 5.3 |
| PROMISE SHOT AWAY | rule | 0.03 | - | 1.3 |
| REDIRECT WEIGHED | rule | - | 0.03 | 153.7 |
| RESERVE FALL BACK | rule | 0.03 | - | 24.3 |
| STANDS TO CAST | rule | 0.03 | - | 0.6 |
| WALKS ON ITS ROUTE | rule | - | 0.03 | 76.4 |
| WHO HITS BACK | rule | - | 0.03 | 4.4 |

### Plans: base-s1-882d875-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 54% | 258 | 116 | 45% |
| Mine | join | 0.6 | 100% | 26 | 0 | 0% |
| Mine | move | 29.1 | 95% | 1487 | 0 | 0% |
| Mine | shoot | 8.8 | 53% | 490 | 615 | 125% |
| Mine | support | 0.4 | 69% | 4 | 0 | 0% |
| Opponent | charge | 3.2 | 57% | 599 | 288 | 48% |
| Opponent | join | 0.9 | 94% | 37 | 0 | 0% |
| Opponent | move | 33.6 | 96% | 1598 | 0 | 0% |
| Opponent | shoot | 5.0 | 61% | 284 | 314 | 111% |
| Opponent | support | 0.9 | 81% | 12 | 0 | 0% |

### Packages: hunt the guns, base-s1-882d875-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 202 | 199 | 100% | 27 |
| Opponent | 0.1 | 3 | 0 | 67% | 67% | 0% | 2.0 | 384 | 157 | 67% | 67 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 68 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 112 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 6 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 188 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.8 | 3 | 0 | 67% | 67% | 0% | 2.0 | 385 | 173 | 67% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 202 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 15 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 198 | 149 | 100% | 75 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: base-s1-882d875-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 27% | 71% | 12% | 0% | 40% | 0% | 0% | 53% | 7% |
| Opponent | REDIRECT COUNTER | 2.3 | 33% | 74% | 7% | 0% | 16% | 0% | 8% | 64% | 12% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s1-882d875-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 8 (5) | 8 | 0 | 0 | 40% | 3.0 | - | 15 (3) | - | - | 15 (3) |
| Mine | Chaff | 36 | 57 (36) | 9 | 49 | 41 | 50% | 2.7 | 82 (21) | 47 (7) | 0 (8) | 65 (27) | 34 (9) |
| Mine | Character | 124 | 33 (124) | 33 | 0 | 31 | 35% | 2.2 | 34 (42) | 26 (51) | 37 (16) | 48 (59) | 15 (50) |
| Mine | Clean-up | 19 | 34 (19) | 5 | 28 | 37 | 32% | 2.7 | 29 (4) | 6 (10) | 77 (5) | 52 (13) | 1 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 47 | 25 (47) | 15 | 10 | 30 | 40% | 2.5 | 12 (17) | 42 (22) | 6 (8) | 30 (29) | 17 (18) |
| Mine | Hammer | 58 | 29 (58) | 14 | 15 | 28 | 31% | 2.6 | 11 (14) | 32 (32) | 44 (12) | 25 (34) | 34 (24) |
| Mine | Holder | 29 | 41 (29) | 3 | 38 | 6 | 59% | 2.9 | 28 (13) | 63 (11) | 26 (4) | 50 (18) | 26 (10) |
| Mine | Shooter | 45 | 104 (45) | 35 | 69 | 40 | 7% | 1.6 | 35 (10) | 174 (23) | 33 (12) | 127 (34) | 42 (11) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 34 (59) | 34 | 0 | 47 | 3% | 1.5 | 42 (22) | 46 (19) | 12 (18) | 16 (13) | 39 (46) |
| Mine | Wizard | 21 | 5 (21) | 5 | 0 | 33 | 14% | 2.6 | 0 (8) | 13 (8) | 0 (1) | 0 (8) | 13 (9) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 38 | 50% | 6.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 76 | 61 (76) | 32 | 29 | 39 | 51% | 2.2 | 33 (33) | 47 (23) | 124 (20) | 47 (61) | 112 (15) |
| Opponent | Character | 97 | 43 (97) | 42 | 1 | 24 | 31% | 2.7 | 48 (39) | 36 (39) | 65 (11) | 45 (59) | 48 (30) |
| Opponent | Clean-up | 16 | 29 (16) | 3 | 26 | 32 | 44% | 2.3 | 48 (6) | 9 (8) | 0 (2) | 36 (12) | 0 (4) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Fast Hammer | 51 | 35 (51) | 17 | 18 | 29 | 35% | 2.6 | 24 (15) | 37 (27) | 47 (9) | 44 (31) | 22 (20) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 67% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Hammer | 70 | 30 (70) | 24 | 5 | 24 | 44% | 2.5 | 17 (21) | 37 (33) | 30 (16) | 43 (43) | 11 (27) |
| Opponent | Holder | 34 | 74 (34) | 5 | 70 | 16 | 41% | 3.2 | 62 (10) | 120 (11) | 72 (7) | 86 (19) | 94 (9) |
| Opponent | Shooter | 36 | 61 (36) | 17 | 45 | 29 | 6% | 1.5 | 49 (12) | 93 (16) | 16 (8) | 94 (22) | 21 (14) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 50 | 33% | 4.5 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 24 | 35 (24) | 35 | 0 | 31 | 8% | 1.7 | 57 (11) | 25 (4) | 11 (9) | 0 (3) | 39 (21) |
| Opponent | Wizard | 26 | 11 (26) | 11 | 0 | 28 | 15% | 1.6 | 0 (14) | 23 (9) | - | 20 (10) | 0 (13) |

### Charged fights: base-s1-882d875-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 100 | 50 | 1.0 | 1.0 | 50 | 0 | +50 | 0 of 4 | 4 of 4 | - | +50 |
| Mine | Chaos Dwarfs | 4 | 62 | 223 | 1.8 | 1.0 | 128 | 44 | +83 | 5 of 7 | 5 of 7 | - | +83 |
| Mine | Dwarfen Mountain Holds | 4 | 569 | 47 | 1.2 | 1.0 | 37 | 0 | +37 | 0 of 5 | 3 of 5 | - | +37 |
| Mine | Empire of Man | 5 | 288 | 113 | 1.2 | 1.2 | 94 | 32 | +63 | 3 of 6 | 3 of 6 | +145 | +46 |
| Mine | Grand Cathay | 4 | 70 | 57 | 1.5 | 1.2 | 38 | 106 | -68 | 1 of 6 | 3 of 6 | -639 | +46 |
| Mine | High Elf Realms | 4 | 78 | 322 | 2.2 | 1.0 | 143 | 29 | +114 | 1 of 9 | 8 of 9 | - | +114 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 375 | 5.0 | 1.0 | 75 | 0 | +75 | 0 of 5 | 5 of 5 | - | +75 |
| Mine | Lizardmen | 1 | 0 | 95 | 2.0 | 1.5 | 48 | 0 | +48 | 0 of 2 | 2 of 2 | +45 | +50 |
| Mine | Ogre Kingdoms | 1 | 45 | 0 | 4.0 | 1.0 | 0 | 8 | -8 | 1 of 4 | 2 of 4 | - | -8 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 809 | 5.0 | 1.2 | 162 | 0 | +162 | 2 of 5 | 4 of 5 | +0 | +202 |
| Mine | Skaven | 2 | 158 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 239 | 439 | 6.0 | 1.0 | 73 | 20 | +53 | 0 of 6 | 6 of 6 | - | +53 |
| Mine | Vampire Counts | 3 | 0 | 173 | 1.3 | 1.0 | 130 | 21 | +109 | 2 of 4 | 3 of 4 | - | +109 |
| Mine | Warriors of Chaos | 1 | 0 | 128 | 2.0 | 1.0 | 64 | 0 | +64 | 0 of 2 | 2 of 2 | - | +64 |
| **Mine** | all armies | 36 | 154 | 159 | 1.8 | 1.1 | 87 | 25 | +62 | 15 of 66 | 51 of 66 | -112 | +73 |
| Opponent | Dwarfen Mountain Holds | 2 | 247 | 0 | 1.0 | 1.5 | 0 | 30 | -30 | 1 of 2 | 0 of 2 | +0 | -60 |
| Opponent | Empire of Man | 2 | 225 | 55 | 2.0 | 1.0 | 28 | 0 | +28 | 2 of 4 | 2 of 4 | - | +28 |
| Opponent | Grand Cathay | 2 | 90 | 484 | 2.5 | 1.4 | 194 | 0 | +194 | 2 of 5 | 4 of 5 | +250 | +156 |
| Opponent | Kingdom of Bretonnia | 1 | 220 | 115 | 1.0 | 1.0 | 115 | 0 | +115 | 0 of 1 | 1 of 1 | - | +115 |
| Opponent | Ogre Kingdoms | 3 | 305 | 262 | 2.3 | 1.1 | 112 | 10 | +102 | 0 of 7 | 3 of 7 | -68 | +131 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 186 | 1018 | 5.2 | 1.1 | 194 | 66 | +127 | 12 of 21 | 15 of 21 | +69 | +137 |
| Opponent | Vampire Counts | 6 | 82 | 183 | 2.5 | 1.1 | 73 | 25 | +48 | 8 of 15 | 10 of 15 | +92 | +41 |
| Opponent | Warriors of Chaos | 8 | 34 | 149 | 1.8 | 1.1 | 85 | 37 | +48 | 3 of 14 | 11 of 14 | +183 | +38 |
| Opponent | Wood Elf Realms | 7 | 45 | 487 | 2.7 | 1.1 | 180 | 0 | +180 | 9 of 19 | 17 of 19 | +104 | +184 |
| **Opponent** | all armies | 36 | 114 | 326 | 2.4 | 1.1 | 133 | 27 | +106 | 37 of 88 | 63 of 88 | +101 | +107 |

### Effective charges: base-s1-882d875-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 3 (net +42) | 0 | 0 | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 7 | 1 (net +559) | 1 (net +268) | 2 (net -155) | 0 | 1 (net +66) | 2 (net +0) | 0 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 1 (net +107) | 0 | 0 | 2 (net +40) | 1 | 25% (1 of 4) |
| Mine | Empire of Man | 6 | 3 (net +77) | 0 | 1 (net +0) | 0 | 0 | 2 (net +72) | 0 | 17% (1 of 6) |
| Mine | Grand Cathay | 6 | 2 (net -320) | 0 | 1 (net +0) | 0 | 2 (net +114) | 1 (net +0) | 0 | 17% (1 of 6) |
| Mine | High Elf Realms | 9 | 1 (net -143) | 0 | 3 (net +48) | 0 | 0 | 3 (net +112) | 2 | 43% (3 of 7) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 1 (net +0) | 2 | 33% (1 of 3) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 1 (net +50) | 1 (net +45) | 0 | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 1 (net +190) | 0 | 0 | 2 (net +94) | 0 | 2 | 0% (0 of 3) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +204) | 0 | 2 (net +118) | 1 (net -122) | 2 | 25% (1 of 4) |
| Mine | Vampire Counts | 4 | 0 | 0 | 0 | 1 (net +41) | 1 (net +122) | 1 (net +272) | 1 | 0% (0 of 3) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 1 (net -60) | 1 (net +0) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Empire of Man | 4 | 2 (net +0) | 0 | 0 | 1 (net +110) | 1 (net +0) | 0 | 0 | 0% (0 of 4) |
| Opponent | Grand Cathay | 5 | 2 (net +250) | 0 | 0 | 3 (net +156) | 0 | 0 | 0 | 0% (0 of 5) |
| Opponent | Ogre Kingdoms | 7 | 4 (net +153) | 0 | 0 | 1 (net +104) | 0 | 1 (net +0) | 1 | 0% (0 of 6) |
| Opponent | Tomb Kings of Khemri | 21 | 4 (net -79) | 1 (net +401) | 2 (net +174) | 3 (net +229) | 0 | 7 (net +107) | 4 | 12% (2 of 17) |
| Opponent | Vampire Counts | 15 | 5 (net +22) | 0 | 3 (net +134) | 2 (net +107) | 1 (net -190) | 3 (net +62) | 1 | 21% (3 of 14) |
| Opponent | Warriors of Chaos | 14 | 2 (net -8) | 0 | 0 | 1 (net +0) | 6 (net +61) | 2 (net +41) | 3 | 0% (0 of 11) |
| Opponent | Wood Elf Realms | 19 | 2 (net +116) | 0 | 2 (net +383) | 4 (net +194) | 2 (net +74) | 7 (net +175) | 2 | 12% (2 of 17) |

### Charged fights, damage counted: base-s1-882d875-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 262 | 241 | +1 | 151 | 190 | -39 | -14.9 |
| Mine | 50-54% | 3 | 368 | 204 | +153 | 226 | 23 | +204 | +55.3 |
| Mine | Effective (55-75%) | 11 | 216 | 218 | +13 | 79 | 58 | +21 | +9.6 |
| Mine | 76-89% | 6 | 197 | 79 | +36 | 50 | 15 | +36 | +18.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 13 | 219 | 135 | +55 | 93 | 25 | +68 | +31.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 357 | 83 | +98 | 98 | 5 | +93 | +26.1 |
| Mine | No odds | 16 | 277 | 171 | +104 | 130 | 6 | +124 | +44.8 |
| Mine | All fights | 66 | 261 | 161 | +62 | 110 | 42 | +67 | +25.8 |
| Opponent | Long shot (under 50%) | 21 | 244 | 246 | +54 | 136 | 80 | +56 | +22.9 |
| Opponent | 50-54% | 2 | 466 | 181 | +170 | 214 | 30 | +184 | +39.4 |
| Opponent | Effective (55-75%) | 8 | 291 | 275 | +189 | 259 | 18 | +241 | +82.7 |
| Opponent | 76-89% | 15 | 329 | 180 | +157 | 166 | 24 | +142 | +43.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 343 | 218 | +112 | 190 | 40 | +149 | +43.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 477 | 88 | +33 | 77 | 103 | -26 | -5.5 |
| Opponent | No odds | 12 | 290 | 183 | +119 | 146 | 30 | +116 | +39.9 |
| Opponent | All fights | 88 | 323 | 203 | +106 | 161 | 51 | +110 | +34.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s1-882d875-p2 | move | 267 | 58 (22%) | 42 (16%) | 36 (13%) | 173 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: base-s1-882d875-p6

### Scorecard: base-s1-882d875-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0108 | 6 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 81 |
| L0124 | 4 | 1 | Mine | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0124 | 4 | 1 | Opponent | no | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 60 |
| L0208 | 4 | 1 | Mine | no | 7 | - | 2 | 4 | 0 | 0 | 0 | 170 |
| L0208 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 662 |
| L0224 | 2 | 1 | Mine | - | - | 1 | 3 | 4 | 0 | 0 | 0 | 200 |
| L0224 | 2 | 1 | Opponent | - | - | 5 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0309 | 3 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 140 |
| L0309 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 45 |
| L0325 | 1 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0325 | 1 | 1 | Opponent | no | 7 | 2 | 1 | 4 | 0 | 0 | 0 | 143 |
| L0411 | 3 | 1 | Mine | no | 4 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0427 | 1 | 1 | Mine | no | 4 | 2 | 7 | 2 | 0 | 0 | 0 | 65 |
| L0427 | 1 | 1 | Opponent | no | 8 | 3 | 3 | 3 | 0 | 0 | 0 | 380 |
| L0514 | 4 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 391 |
| L0514 | 4 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0530 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 884 |
| L0530 | 2 | 1 | Opponent | - | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 0 | 6 | 0 | 2 | 0 | 0 | 0 | 458 |
| L0618 | 6 | 1 | Opponent | no | 0 | 5 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0635 | 5 | 1 | Mine | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 874 |
| L0635 | 5 | 1 | Opponent | yes | - | 3 | 3 | 6 | 0 | 0 | 0 | 0 |
| L0723 | 3 | 1 | Mine | yes | 9 | 2 | 4 | 1 | 0 | 0 | 0 | 424 |
| L0723 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 257 |
| L0813 | 3 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 90 |
| L0813 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 2 | 0 | 0 | 0 | 70 |
| L0829 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L0829 | 1 | 1 | Opponent | no | 4 | - | 0 | 5 | 1 | 0 | 0 | 445 |
| L0920 | 2 | 1 | Mine | - | - | 4 | 1 | 3 | 0 | 0 | 0 | 45 |
| L0920 | 2 | 1 | Opponent | - | - | - | 0 | 7 | 1 | 0 | 0 | 210 |
| L1011 | 3 | 1 | Mine | no | 1 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1011 | 3 | 1 | Opponent | no | 7 | 4 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1028 | 2 | 1 | Mine | - | - | 1 | 2 | 1 | 0 | 0 | 0 | 165 |
| L1028 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1120 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1120 | 4 | 1 | Opponent | no | 0 | 6 | 2 | 5 | 2 | 0 | 0 | 245 |
| L1214 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 1 | 0 | 0 | 165 |
| L1214 | 2 | 1 | Opponent | - | - | 1 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1230 | 6 | 1 | Mine | no | 5 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1230 | 6 | 1 | Opponent | no | 3 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1325 | 5 | 1 | Mine | yes | - | 3 | 0 | 2 | 0 | 0 | 0 | 177 |
| L1325 | 5 | 1 | Opponent | yes | - | 2 | 2 | 6 | 1 | 0 | 0 | 0 |
| L1420 | 4 | 1 | Mine | no | 4 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1420 | 4 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 100 |
| L1517 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 126 |
| L1517 | 5 | 1 | Opponent | yes | - | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1533 | 3 | 1 | Mine | yes | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1533 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 955 |
| L1631 | 5 | 1 | Mine | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 650 |
| L1631 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 170 |
| L1829 | 5 | 1 | Mine | yes | - | - | 1 | 2 | 0 | 0 | 0 | 311 |
| L1829 | 5 | 1 | Opponent | yes | - | 5 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1929 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1929 | 3 | 1 | Opponent | no | 2 | 3 | 2 | 3 | 0 | 0 | 0 | 493 |
| L2031 | 3 | 1 | Mine | no | 0 | 6 | 1 | 1 | 1 | 0 | 0 | 647 |
| L2031 | 3 | 1 | Opponent | yes | 3 | 6 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2134 | 4 | 1 | Mine | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 565 |
| L2134 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2325 | 3 | 1 | Mine | no | 5 | 2 | 6 | 2 | 0 | 0 | 0 | 185 |
| L2325 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2431 | 1 | 1 | Mine | no | 8 | - | 1 | 2 | 1 | 0 | 0 | 0 |
| L2431 | 1 | 1 | Opponent | no | 13 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2628 | 6 | 1 | Mine | no | 8 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L2628 | 6 | 1 | Opponent | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L2830 | 4 | 1 | Mine | no | 6 | - | 1 | 0 | 0 | 0 | 0 | 0 |
| L2830 | 4 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L3035 | 5 | 1 | Mine | yes | - | 4 | 0 | 4 | 0 | 0 | 0 | 0 |
| L3035 | 5 | 1 | Opponent | yes | - | 1 | 7 | 4 | 0 | 0 | 0 | 375 |
| **Average** | | | Mine | 20% | 3.5 | 2.7 | 1.8 | 1.6 | 0.1 | 0.0 | 0.0 | 205.1 |
| **Average** | | | Opponent | 23% | 2.5 | 3.2 | 2.0 | 2.6 | 0.3 | 0.0 | 0.0 | 143.5 |

### KPIs: base-s1-882d875-p6

Morten 2026-11-10; 35 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (47 of 163) | 6% (10 of 162) | 18% (57 of 325) |
| Winner chose to follow up after the loser gave ground |  | 92% (47 of 51); on the table 98% | 93% (28 of 30); on the table 97% | 93% (75 of 81); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | 69% (9 of 13); on the table 77% | 67% (10 of 15); on the table 73% |
| Winner chose to pursue after the loser fled |  | 54% (7 of 13); on the table 69% | 74% (14 of 19); on the table 79% | 66% (21 of 32); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 83% (55 of 66); on the table 91% | 82% (51 of 62); on the table 87% | 83% (106 of 128); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 28% (88 of 311) | 35% (65 of 187) | 31% (153 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (88 of 242) | 42% (59 of 142) | 38% (147 of 384) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (9 of 27) | 55% (34 of 62) | 48% (43 of 89) |
| Points that never fought | lower | 52% (35451 of 68457) | 54% (37866 of 69982) | 53% (73317 of 138439) |
|   infantry points that never fought | lower | 64% (9731 of 15282) | 71% (9732 of 13684) | 67% (19463 of 28966) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (158 of 268) | 70% (199 of 283) | 65% (357 of 551) |
| Bound items with a magic missile used (at least once a game) |  | 100% (25 of 25); 2.4 uses a game | 69% (9 of 13); 0.8 uses a game | 89% (34 of 38); 1.6 uses a game |
| Bound items with another spell used |  | 31% (4 of 13); 0.3 uses a game | 43% (6 of 14); 0.3 uses a game | 37% (10 of 27); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 52% (11 of 21); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 55% (18 of 33); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30004 of 58430) | 65% (40865 of 62766) | 58% (70869 of 121196) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.1 (48%) | 1.3 (37%) | 4.3 (44%) |
| MARCHED: its unit marched | 0.9 (14%) | 0.8 (24%) | 1.7 (17%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.0 (1%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.4 (22%) | 0.5 (14%) | 1.9 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.5 (7%) | 0.5 (15%) | 1.0 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.5 | 2.8 | 4.4 | 0.8 | 1.9 |
| not cast | 3.3 | 2.7 | 3.2 | 9.9 | 2.3 | 21.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (55%) | 0.2 (6%) | 4.3 (44%) | 0.4 (19%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (17%) | 0.3 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (8%) | 0.7 (21%) | 1.9 (19%) | 0.4 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.1 (5%) | 0.3 (10%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) | 0.1 (4%) | 0.2 (1%) |
| GONE: slain | 0.6 (19%) | 0.4 (14%) | 0.5 (14%) | 1.0 (10%) | 0.1 (4%) | 2.6 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.1 (2%) | 0.1 (4%) | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.0 (0%) | 0.1 (1%) | 0.9 (37%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (64%) | 0.1 (5%) | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.5 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 1.3 a game | 1.5 a game |
| stood (cast and not dispelled) | 78% (38 of 49) | 50% (22 of 44) | 65% (60 of 93) |
| the unit moved after it | 47% (18 of 38) | 50% (11 of 22) | 48% (29 of 60) |
| it charged on its next turn | 8% (3 of 38) | 0% (0 of 22) | 5% (3 of 60) |
| the enemy charged it first | 8% (3 of 38) | 9% (2 of 22) | 8% (5 of 60) |
| it fought by the end of its next turn | 5% (2 of 38) | 5% (1 of 22) | 5% (3 of 60) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (4 of 38) | 0% (0 of 22) | 7% (4 of 60) |
| none of these (no charge, no fight, no charge escaped) | 74% (28 of 38) | 91% (20 of 22) | 80% (48 of 60) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (480 of 845) | 55% (306 of 555) | 56% (786 of 1400) |
|   cavalry | 49% (48 of 97) | 60% (72 of 120) | 55% (120 of 217) |
|   character | 47% (44 of 93) | 29% (24 of 82) | 39% (68 of 175) |
|   chariot | 58% (58 of 100) | 89% (31 of 35) | 66% (89 of 135) |
|   infantry | 59% (140 of 238) | 61% (130 of 212) | 60% (270 of 450) |
|   monster | 46% (12 of 26) | 50% (12 of 24) | 48% (24 of 50) |
|   war machine | 61% (178 of 291) | 45% (37 of 82) | 58% (215 of 373) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (13%) | 1.1 (16%) | 2.5 (14%) |
| CHARGED: it charged | 0.6 (6%) | 1.0 (14%) | 1.6 (9%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.4 (4%) | 0.3 (4%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.8 (18%) | 0.9 (12%) | 2.7 (15%) |
| NO TARGET IN RANGE | 3.1 (30%) | 2.3 (33%) | 5.5 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (7%) | 0.4 (5%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (15%) | 0.7 (10%) | 2.3 (13%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 0.1 (1%) | 0.3 (2%) |
| OTHER BAR | 0.4 (4%) | 0.2 (3%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 2.1 | 77% | 7.4 pts | 42 pts |
| character | 2.2 | 1.1 | 68% | 11.8 pts | 26 pts |
| chariot | 2.7 | 2.6 | 59% | 17.8 pts | 48 pts |
| infantry | 11.6 | 3.8 | 78% | 7.9 pts | 92 pts |
| monster | 0.9 | 0.2 | 81% | 4.5 pts | 4 pts |
| war machine | 6.2 | 7.1 | 61% | 34.0 pts | 210 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 3.3 | 3.1 |
| Charges that made contact a game | 2.1 | 2.4 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.22 declared, 0.87 contact (23 units) | 0.56 declared, 0.44 contact (18 units) | 0.93 declared, 0.68 contact (41 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.80 declared, 0.60 contact (5 units) | 0.67 declared, 0.60 contact (15 units) | 0.70 declared, 0.60 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.21 contact (238 units) | 0.37 declared, 0.26 contact (260 units) | 0.34 declared, 0.23 contact (498 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (46 of 69) | 75% (18 of 24) | 33% (4 of 12) | 65% (68 of 105) |
| Character in a unit | 84% (38 of 45) | 60% (15 of 25) | 80% (4 of 5) | 76% (57 of 75) |
| Character on its own | 85% (23 of 27) | 53% (17 of 32) | 33% (20 of 60) | 50% (60 of 119) |
| Chariot | 75% (9 of 12) | 64% (9 of 14) | - | 69% (18 of 26) |
| Infantry | 65% (54 of 83) | 58% (19 of 33) | 20% (1 of 5) | 61% (74 of 121) |
| Monster | 62% (13 of 21) | 73% (11 of 15) | - | 67% (24 of 36) |
| Monstrous | 100% (7 of 7) | 67% (6 of 9) | - | 81% (13 of 16) |
| War Machines | 80% (41 of 51) | 100% (2 of 2) | - | 81% (43 of 53) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (13 of 13); on the table 100% | 33% (34 of 102) | 37% | 45% (10 of 22) | 100% (6 of 6); 6.2 uses a game | 100% (2 of 2); 1.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (6 of 6); on the table 100% | 29% (7 of 24) | 61% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 4 | 57% (4 of 7); on the table 86% | - | 59% | 74% (25 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 75% (6 of 8); on the table 75% | 39% (14 of 36) | 80% | 68% (50 of 74) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 60% (3 of 5); 0.4 uses a game |
| Grand Cathay | 7 | 77% (10 of 13); on the table 85% | 28% (38 of 138) | 47% | 58% (33 of 57) | 100% (16 of 16); 6.7 uses a game | 50% (1 of 2); 0.1 uses a game | 14% (1 of 7); 0.1 uses a game |
| High Elf Realms | 7 | 76% (13 of 17); on the table 82% | 17% (6 of 36) | 54% | 49% (28 of 57) | 100% (6 of 6); 3.6 uses a game | 32% (7 of 22); 1.6 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 81% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | 100% (6 of 6) | 72% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 69% | 86% (12 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 30% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 5 | 67% (4 of 6); on the table 83% | 27% (8 of 30) | 56% | 76% (28 of 37) | 100% (1 of 1); 0.8 uses a game | 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| Tomb Kings of Khemri | 2 | 100% (9 of 9); on the table 100% | - | 41% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 86% (18 of 21); on the table 95% | 40% (19 of 48) | 48% | 74% (37 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 13 | 74% (14 of 19); on the table 79% | 26% (11 of 42) | 43% | 66% (67 of 101) | 67% (2 of 3); 0.4 uses a game | 0.0 uses a game | 100% (4 of 4); 0.3 uses a game |
| Wood Elf Realms | 4 | 100% (5 of 5); on the table 100% | 44% (8 of 18) | 45% | 76% (32 of 42) | 50% (2 of 4); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s1-882d875-p6, 35 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (28) | 38% (17) | 45% (45) |
| ...free all their last turn and able to turn (per game) | 0.54 | 0.46 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.03 | 0.20 |
| ...with the charger already in that arc before they moved (per game) | 0.40 | 0.34 | 0.74 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.03 | 0.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 0.34 | 0.46 |

### Quality by phase: base-s1-882d875-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 56% (53 of 94) | 48% (48 of 101) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (134 of 420) | 41% (64 of 156) |
| Strategy | Support requests answered (helper made contact too) | 67% (4 of 6) | 59% (10 of 17) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (6 of 6) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (4 of 8) | 29% (2 of 7) |
| Strategy | Joined characters whose unit fought | 42% (25 of 60) | 24% (11 of 46) |
| Strategy | Lone characters that fought | 62% (45 of 73) | 63% (49 of 78) |
| Movement | Charges halted short of contact | 0.3 | 0.1 |
| Movement | Idle units | 1.6 | 2.6 |
| Movement | Points that never moved of their own | 205.1 | 143.5 |
| Movement | Fights charged into per game | 1.9 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 61, net +20 | 15 of 59, net -15 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 61, net +116 | 11 of 59, net +108 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 61, net +59 | 6 of 59, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 of 61, net +95 | 16 of 59, net +116 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.4 | 8.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (168 of 328) | 52% (160 of 310) |
| Shooting | Points destroyed by shooting units | 71.5 | 21.4 |
| Shooting | War machine shots | 5.1 | 1.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (93 of 178) | 47% (18 of 38) |
| Shooting | Points destroyed by war machines | 48.0 | 20.7 |
| Magic | Magic missiles cast | 1.5 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 48% (25 of 52) | 45% (18 of 40) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.3 |
| Magic | Wounds caused by other spells | 1.1 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 62.9 | 27.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 0.7 / 0.2 | 1.5 / 0.5 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 305.5 | 224.2 |
| Combat | Points run down | 49.0 | 56.4 |
| Combat | Net points per charged fight, damage counted | +57 | +75 |
| Combat | Net per 100 charger points, damage counted | +18.3 | +22.6 |
| Combat | First round won (charged fights) | 70% | 69% |
| Combat | Net points per charged fight | +79 | +63 |
| Combat | Net points per supported fight / lone fight | +84 / +79 | +44 / +65 |
| Combat | Charged fights on a top-3 enemy unit | 21 of 68 | 37 of 75 |
| Game | Points lost | 435.7 | 591.1 |
| Game | VP from objectives | 716.0 | 587.4 |
| Game | Lone holders (player turns) | 3.5 | 2.5 |

- Mine won / drew / lost: 15 / 9 / 11 of 35 ended games (of 35); mean margin (Mine - Opponent) +256 VP
- The side that went first won 10 of 26 games with a winner
- Points traded per game (both sides' losses): 1027
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: base-s1-882d875-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +4.1 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 4.1 |
| AFTERMATH WITH FRIENDS | 0.0 | +1.6 | 0.0 | 0.0 | 0.1 | +3.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 14.9 | +236.4 | 0.0 | 101.9 | 19.4 | +220.9 | 0.0 | 136.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 11.4 | 0.2 | +0.0 | 0.0 | 8.4 |
| BACKUP TARGETS | 0.1 | +1.3 | 0.0 | 0.0 | 0.2 | +1.0 | 0.0 | 0.0 |
| BEST OVERALL | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | -2.5 | 14.6 | 16.6 | 0.1 | -14.0 | 3.8 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -1.0 | 3.7 | 0.0 | 0.2 | -15.5 | 13.1 | 13.7 |
| BOMBING RUN | 0.0 | +2.5 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 4.3 |
| CANNON PLAN MISSED | 0.2 | +0.0 | 50.3 | 2.7 | - | - | - | - |
| CANNON PLANNED TARGET | 5.0 | +116.3 | 363.0 | 67.1 | 1.0 | +37.2 | 81.2 | 32.4 |
| CANNON SIGHT KEPT | 0.9 | +0.0 | 0.0 | 10.3 | 0.2 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.1 | +11.8 | 58.5 | 0.0 | 0.8 | +9.5 | 94.8 | 34.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +45.1 | 49.9 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.2 | +0.0 | 0.0 | 33.7 | 0.6 | +0.0 | 0.0 | 21.0 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +27.0 | 0.0 | 9.0 | 1.0 | +43.7 | 0.0 | 26.5 |
| CHAFF PASSED | 0.1 | -0.0 | 0.0 | 3.6 | 0.3 | -0.3 | 3.3 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.0 | -0.5 | 10.2 | 0.0 | 0.1 | -1.6 | 10.3 | 4.6 |
| CHARACTER GUNS | 1.0 | +0.0 | 0.0 | 16.5 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 8.7 | -450.0 | 0.0 | 147.0 | 11.8 | -818.3 | 0.0 | 313.7 |
| CHARGE NOT DECLARED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.6 | 4.9 |
| CHARGE NOW FIRST | 1.4 | +0.0 | 136.5 | 15.9 | 1.5 | +0.0 | 134.6 | 36.7 |
| CHARGER SLAIN LOST | 0.3 | -5.1 | 0.0 | 3.2 | 0.3 | -5.4 | 29.8 | 27.3 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 3.4 | 0.0 | 0.0 | +0.0 | 0.0 | 13.4 |
| COMBAT PIVOT | 0.1 | +0.0 | 4.9 | 0.0 | 0.5 | +0.0 | 15.4 | 46.3 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 6.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.3 | +183.3 | 33.7 | 33.7 | 1.2 | +98.9 | 42.0 | 45.8 |
| COVER ONCE | 4.5 | -281.3 | 0.0 | 77.1 | 4.4 | -348.8 | 0.0 | 113.6 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.6 | -11.8 | 31.5 | 14.2 | 0.5 | -7.9 | 36.7 | 50.9 |
| DEPLOY BY FIGURES | 7.9 | +0.8 | 0.0 | 13.4 | 7.2 | +50.1 | 0.0 | 12.6 |
| EDGE GIVE GROUND | 0.3 | +11.7 | 15.3 | 3.4 | 0.1 | +1.0 | 15.8 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.9 | +3.5 | 194.0 | 41.3 | 2.2 | +3.9 | 166.9 | 103.7 |
| FALLBACK BY WORTH | 0.2 | +0.3 | 0.0 | 1.7 | 0.3 | +0.0 | 0.0 | 1.3 |
| FALLS SHORT | 5.3 | +91.4 | 0.0 | 24.3 | 15.2 | +202.2 | 0.0 | 156.2 |
| FEATURE BUFFS | 2.3 | +65.2 | 0.0 | 38.0 | 0.9 | +24.0 | 0.0 | 15.4 |
| FIGHT LIFT | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.4 | +11.7 | 44.9 | 24.9 | 0.6 | +5.2 | 23.1 | 36.2 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 1.6 | 0.0 |
| FIVE ACTION | 91.7 | +5705.5 | 1661.4 | 882.2 | 81.3 | +4300.0 | 649.8 | 1105.5 |
| FLANK NOT WEIGHED | 3.5 | +0.0 | 0.0 | 79.6 | 3.3 | +0.0 | 0.0 | 97.2 |
| FOCUS FIRE | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +159.2 | 0.0 | 22.4 | 0.5 | +74.2 | 0.0 | 6.0 |
| FOUR ROUNDS | 2.8 | +200.8 | 237.9 | 44.5 | 3.1 | +203.6 | 226.8 | 134.2 |
| FRIEND CHARGES FIRST | 0.1 | -4.1 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.4 | -4.9 | 0.0 | 0.0 | 0.2 | -4.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +4.6 | 0.0 | 24.8 | 0.1 | +0.4 | 0.0 | 0.0 |
| GIVES UP | 0.4 | -17.2 | 18.3 | 10.5 | 0.3 | -7.7 | 9.7 | 25.9 |
| GROUND FLIERS | - | - | - | - | 0.0 | +1.4 | 0.0 | 0.0 |
| GUN FIGURES | 0.8 | +10.9 | 32.4 | 1.9 | 0.8 | +15.0 | 9.7 | 7.4 |
| GUN MASK | 0.9 | +24.2 | 0.0 | 5.5 | 0.7 | +42.2 | 0.0 | 13.4 |
| HARD STAY DROPPED | 3.2 | +0.0 | 0.0 | 12.6 | 1.9 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.4 | +0.0 | 0.0 | 61.7 | 2.5 | +0.0 | 0.0 | 113.2 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 14.9 | 27.1 |
| HIS CHARGE DENIED | 0.3 | +9.6 | 11.8 | 2.6 | 0.4 | +25.8 | 11.4 | 10.9 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 66.9 | 6.2 | +0.0 | 0.0 | 73.7 |
| HIS FIGHT TOGETHER | 1.1 | -25.8 | 0.0 | 32.8 | 1.9 | -50.8 | 0.0 | 171.2 |
| HIS LEGAL MOVES | 2.9 | +0.0 | 0.0 | 39.6 | 3.8 | +0.0 | 0.0 | 102.4 |
| HIS MOVE AND SHOT | 2.6 | -83.0 | 0.0 | 66.6 | 3.2 | -97.1 | 0.0 | 85.1 |
| HIS MOVE AS HE DECIDES | 38.5 | +14.3 | 672.7 | 0.0 | 35.3 | +13.9 | 377.0 | 0.0 |
| HIS MOVE WHY | 34.8 | +0.0 | 0.0 | 271.9 | 38.5 | +0.0 | 0.0 | 467.8 |
| HIS ONE MOVE | 18.8 | -4.1 | 0.0 | 136.8 | 18.8 | -6.1 | 2.6 | 139.6 |
| HIS ONE QUARTER | 4.1 | +0.0 | 0.0 | 30.3 | 3.5 | +0.0 | 0.0 | 81.7 |
| HIS OWN BEST MOVE | 0.9 | +0.0 | 0.0 | 4.0 | 1.3 | +0.0 | 0.0 | 57.1 |
| HIS RANDOM MOVE | 4.1 | +0.0 | 0.0 | 37.3 | 2.9 | +0.0 | 0.0 | 78.7 |
| HIS SHOT LIST | 32.1 | +1191.9 | 0.0 | 299.0 | 46.7 | +2377.1 | 0.0 | 608.3 |
| HIS TURN DENIED | 1.2 | +53.4 | 104.2 | 23.8 | 1.3 | +73.2 | 123.7 | 90.7 |
| HOLD ODDS | 18.0 | +0.0 | 0.0 | 127.8 | 13.6 | +0.0 | 0.0 | 157.8 |
| HOLDER ASSIGNMENT | 10.2 | +1011.3 | 0.0 | 62.8 | 8.5 | +808.1 | 0.0 | 98.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.5 | -103.5 | 226.7 | 40.2 | 2.6 | -126.5 | 185.0 | 108.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +18.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +8.9 | 0.0 | 0.0 | 0.0 | +9.0 | 0.0 | 1.3 |
| HUNT THE GUNS | 0.0 | +10.2 | 3.9 | 0.0 | 0.0 | +10.3 | 4.0 | 0.0 |
| IDLE COST | 3.1 | -54.7 | 0.0 | 32.3 | 12.1 | -197.2 | 0.0 | 192.2 |
| JOINT CHARGE NOW | 0.4 | +40.5 | 33.6 | 18.3 | 0.9 | +55.5 | 39.1 | 42.5 |
| JOINT KNOWS CHALLENGE | 0.0 | -2.2 | 15.5 | 0.0 | 0.1 | -7.2 | 6.3 | 9.8 |
| JOINT LOOK BACK | - | - | - | - | 0.0 | +1.7 | 3.3 | 0.0 |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.8 | +0.0 | 0.0 | 0.0 | 3.1 | +0.0 | 0.0 | 15.0 |
| LANE BY FIGURES | 0.7 | +31.7 | 0.0 | 0.0 | 0.8 | +35.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 8.6 |
| LEGAL CHARGES ONLY | 3.5 | +0.0 | 194.1 | 216.8 | 4.9 | +0.0 | 171.8 | 192.6 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.5 | +33.6 | 0.0 | 0.0 | 0.3 | +22.0 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.6 | 9.0 | 0.0 | 0.1 | +2.5 | 4.7 | 0.0 |
| LOST AFTER ESCAPE | 1.2 | -2.5 | 135.7 | 23.8 | 1.7 | +0.2 | 133.7 | 64.6 |
| LOST CHARGE | 0.1 | -0.0 | 7.1 | 0.0 | 0.1 | -0.2 | 0.0 | 16.5 |
| LURE BY WHAT IT DRAWS | 0.3 | -6.3 | 0.0 | 1.2 | - | - | - | - |
| MAKE SURE TOGETHER | 0.1 | +4.0 | 0.0 | 5.9 | 0.1 | +9.7 | 0.0 | 5.1 |
| MANOEUVRE | 0.9 | +3.9 | 0.0 | 18.3 | 0.8 | +0.5 | 0.0 | 10.2 |
| MARCH AT ESCAPER | 0.1 | +0.6 | 0.0 | 0.0 | 0.2 | +3.8 | 0.0 | 11.4 |
| MARCH BY THE SUM | 0.3 | +35.1 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 14.3 |
| MARCH CHECK | 0.7 | +39.1 | 0.0 | 4.9 | 0.8 | +39.3 | 0.0 | 14.3 |
| MARCH ODDS | - | - | - | - | 0.0 | +1.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +17.4 | 0.0 | 6.7 | 0.1 | +4.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.9 | +35.3 | 0.0 | 28.9 | 0.6 | +11.3 | 0.0 | 39.2 |
| MARCH WHEELS ONLY | 1.2 | +0.0 | 0.0 | 0.0 | 1.5 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.9 | +61.3 | 0.0 | 35.5 | 2.5 | +43.8 | 0.0 | 21.2 |
| MISSILES IN THE MOVE | 4.4 | +135.4 | 0.0 | 40.6 | 3.1 | +46.8 | 0.0 | 53.0 |
| MISSILES NEXT TURN | 5.7 | +107.0 | 0.0 | 81.0 | 4.3 | +40.1 | 0.0 | 106.5 |
| MISSILES ON ONE TARGET | 0.2 | -6.9 | 0.0 | 0.0 | 0.0 | -0.6 | 0.0 | 0.0 |
| MODEL FACING | 0.4 | +67.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.4 | +0.0 | 8.9 | 20.2 | 2.4 | +0.0 | 17.8 | 14.6 |
| MOVE SPELL IN RANGE | 0.1 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -15.0 | 8.7 | 0.0 | 0.3 | -6.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 33.7 | 0.3 | +0.0 | 0.0 | 14.3 |
| MOVE TO CHARGE COMPUTED | 5.1 | +483.7 | 0.0 | 53.6 | 5.9 | +548.7 | 0.0 | 141.6 |
| MOVES UNITS SPELL | 0.1 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.3 | +302.1 | 0.0 | 48.8 | 6.2 | +257.3 | 0.0 | 34.9 |
| NEXT CHARGE BY LIST | 4.9 | -215.9 | 49.3 | 13.7 | 5.5 | -213.1 | 0.0 | 132.5 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.1 | -6.4 | 8.9 | 4.1 |
| NO DOUBLE ROUNDS | 2.1 | -86.7 | 180.1 | 32.5 | 2.3 | -116.5 | 157.5 | 128.6 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +5.0 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 1.0 |
| NOT TURNED | 0.1 | +1.8 | 0.0 | 2.8 | 0.3 | +0.5 | 0.0 | 14.7 |
| NOT WORTH A CAST | 0.9 | -0.8 | 0.0 | 11.4 | 0.5 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 3.5 | -164.7 | 7.4 | 58.5 | 3.5 | -153.0 | 10.2 | 29.3 |
| ONE CHARGE A CHARGER | 3.8 | +0.0 | 0.0 | 73.3 | 3.4 | +0.0 | 0.0 | 75.6 |
| ONE FIGHT FORMULA | 3.4 | -83.1 | 0.0 | 20.7 | 3.9 | -106.9 | 0.0 | 108.7 |
| ONE OBJECTIVE FORMULA | 4.5 | +32.8 | 0.0 | 50.4 | 2.9 | +1.2 | 0.0 | 57.8 |
| ONE PROMISE A TARGET | 0.1 | -10.0 | 0.0 | 0.0 | 0.2 | -10.2 | 0.0 | 0.0 |
| ONE ROUTE | 1.2 | +0.0 | 0.0 | 0.0 | 1.5 | +0.0 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 25.6 | +571.8 | 0.0 | 236.2 | 30.3 | +821.9 | 0.0 | 333.7 |
| OPENS A LANE | 0.5 | +1.4 | 225.8 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.4 | +23.4 | 16.9 | 10.5 | 0.3 | +18.8 | 17.6 | 0.0 |
| OVERRUNS AWAY | 0.3 | +11.5 | 26.3 | 10.5 | 0.3 | +8.2 | 32.3 | 19.5 |
| PATHS CROSS | 0.4 | +21.0 | 0.0 | 0.0 | 0.6 | +30.6 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +6.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.0 | -0.9 | 0.0 | 0.0 | 0.2 | -4.3 | 0.0 | 14.1 |
| PLAN RESULT | 42.1 | +907.1 | 570.3 | 629.3 | 39.9 | +435.6 | 208.5 | 943.9 |
| PROMISE BELOW ZERO | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 13.9 |
| PROMISE BY ITS OWN SUM | 7.2 | -216.7 | 0.0 | 27.1 | 7.9 | -259.4 | 0.0 | 77.1 |
| PROMISE IN STEPS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.2 | +0.0 | 0.0 | 0.0 | 1.1 | -0.4 | 0.0 | 62.6 |
| PROMISE READS THE TABLE | 0.3 | -4.0 | 0.0 | 0.0 | 0.2 | -8.3 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.1 | -1.3 | 13.3 | 5.1 | 0.1 | -0.2 | 0.0 | 0.0 |
| PURSUES BIG PREY | 0.0 | -5.4 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 18.1 | +1864.6 | 343.4 | 165.4 | 16.1 | +1773.9 | 169.9 | 176.1 |
| RANDOM MOVE BY FIGURES | 0.8 | +7.3 | 0.0 | 26.3 | 1.8 | +23.9 | 0.0 | 50.6 |
| REAL GROUND | 1.2 | +0.0 | 0.0 | 0.0 | 1.5 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.8 | -26.5 | 0.0 | 12.2 | 0.8 | -25.1 | 0.0 | 24.0 |
| REDIRECT COUNTER | 1.4 | +84.8 | 0.0 | 20.0 | 2.4 | +155.2 | 0.0 | 38.7 |
| REDIRECT WEIGHED | 0.1 | -2.5 | 14.6 | 16.6 | 0.2 | +2.3 | 9.1 | 0.0 |
| REFORMS TO MEET IT | 1.4 | -27.2 | 0.0 | 14.1 | 1.1 | -19.5 | 0.0 | 26.5 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 60.3 | 0.3 | +0.0 | 0.0 | 38.3 |
| RESERVE FALL BACK | 0.3 | +7.1 | 0.0 | 0.0 | 0.3 | +15.1 | 0.0 | 3.1 |
| RESTRAINS TO SHOOT | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +5.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +63.8 | 185.2 | 44.5 | 1.8 | +20.9 | 114.8 | 101.5 |
| RISK BY HIS FIGURE | 17.3 | -326.7 | 0.0 | 323.8 | 18.1 | -591.9 | 0.0 | 484.1 |
| RISK ON THE WAY | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -9.6 | 41.4 | 16.6 | 0.9 | -20.8 | 105.7 | 18.3 |
| RUN DOWN | 1.5 | -16.4 | 153.7 | 35.2 | 2.1 | -29.9 | 157.6 | 66.3 |
| SAFER THAN THE JOB | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +1.0 | 0.0 | 0.0 | 0.2 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.7 | 0.0 | 0.0 | 0.7 | -39.3 | 0.0 | 2.6 |
| SEARCH SPOT | 0.5 | +19.5 | 0.0 | 0.0 | 0.4 | +8.2 | 0.0 | 1.8 |
| SECOND LOOK | 0.1 | +8.3 | 8.5 | 0.0 | 0.2 | +8.8 | 19.0 | 6.7 |
| SELF MOVE SPELL | 0.5 | +81.0 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.5 | +57.5 | 6.1 | 22.0 | 1.8 | +65.5 | 0.0 | 25.4 |
| SET UP TOGETHER | 0.2 | +4.4 | 0.0 | 5.9 | 0.3 | +14.1 | 0.0 | 5.1 |
| SET-UP ANY TARGET | 0.2 | +25.6 | 11.4 | 11.4 | 0.1 | +14.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +4.9 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.2 | +197.4 | 75.1 | 39.4 | 2.0 | +42.8 | 24.9 | 1.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.5 | -16.2 | 38.5 | 1.7 | 0.2 | -4.2 | 4.7 | 0.0 |
| SHOT RISK POINTS | 16.2 | +76.2 | 0.0 | 181.5 | 23.1 | +88.7 | 0.0 | 370.8 |
| SHOTS AFTER THE MOVES | 3.4 | +0.0 | 0.0 | 0.0 | 1.8 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.9 | +675.7 | 0.0 | 208.1 | 9.5 | +369.8 | 0.0 | 135.3 |
| SPELL SETS UP CHARGE | 0.3 | +64.3 | 11.4 | 11.4 | 0.2 | +41.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +22.5 | 55.4 | 55.4 | 1.7 | +41.7 | 86.6 | 80.6 |
| SPELLS IN THE FIGHT | 0.7 | -2.8 | 81.5 | 18.9 | 0.3 | +0.7 | 42.6 | 6.7 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 111.4 | 8.5 | +0.0 | 0.0 | 197.5 |
| STAND AND SHOOT | 0.8 | -10.2 | 40.8 | 19.8 | 0.5 | -7.8 | 30.4 | 2.8 |
| STANDS FOR A REASON | 0.3 | +0.0 | 3.2 | 0.0 | 1.4 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 49.3 | +0.0 | 1423.5 | 453.1 | 29.2 | +0.0 | 423.0 | 269.3 |
| STAY WORTH | 27.2 | +58.8 | 984.9 | 360.5 | 11.5 | +70.5 | 333.2 | 143.6 |
| STOPS | 0.0 | +1.2 | 3.9 | 0.0 | 0.0 | +0.3 | 4.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 12.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.6 | +471.3 | 0.0 | 47.7 | 6.5 | +336.4 | 0.0 | 49.1 |
| SUPPORT NARROWED | 0.3 | +0.0 | 6.4 | 3.2 | 0.2 | +0.0 | 13.7 | 4.6 |
| SUPPORT WORKED OUT | 7.6 | +471.3 | 0.0 | 47.7 | 6.5 | +336.4 | 0.0 | 49.1 |
| SURE REACH TOGETHER | 0.4 | +6.8 | 0.0 | 0.0 | 0.5 | +7.4 | 0.0 | 12.5 |
| THE DEARER SUM KEEPS ITS PLAN | 1.5 | +0.0 | 0.0 | 11.1 | 1.1 | +0.0 | 0.0 | 7.1 |
| THE PROMISE ADDS | 0.4 | -11.2 | 0.0 | 0.0 | 0.1 | -11.2 | 0.0 | 1.4 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 29.9 | +0.0 | 0.0 | 210.1 | 32.8 | +0.0 | 0.0 | 380.2 |
| TIED UP BY THE SUM | 0.8 | +72.1 | 52.0 | 0.0 | 0.7 | +92.4 | 38.9 | 21.9 |
| TIME ON OUR SIDE | 36.8 | +386.5 | 44.5 | 253.2 | 13.3 | +146.2 | 43.7 | 139.5 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 24.4 | 1.5 | +0.0 | 0.0 | 33.0 |
| WALKS ON ITS ROUTE | 0.0 | -1.4 | 0.0 | 0.0 | 0.0 | -0.6 | 0.0 | 3.0 |
| WAR ENGINE CHARGES | 0.0 | +4.4 | 10.5 | 0.0 | 0.0 | +3.7 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 20.1 | 17.7 | 0.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.3 | -16.9 | 40.2 | 0.0 | 0.3 | -22.5 | 30.9 | 19.6 |
| WHO GETS IN | 0.0 | -8.6 | 3.1 | 0.0 | 0.1 | +18.0 | 0.0 | 9.8 |
| WHO HITS BACK | 0.2 | +24.6 | 0.0 | 0.0 | 0.2 | +44.7 | 0.0 | 4.9 |
| WHOLE FIGHT | 0.1 | -10.7 | 20.1 | 0.0 | 0.1 | -0.5 | 15.4 | 9.8 |
| WHOLE FIGHT GAIN | 0.1 | +1.3 | 3.0 | 0.0 | 0.3 | +12.8 | 20.1 | 0.0 |
| WIDER SPREAD | 1.7 | -2.4 | 141.5 | 26.2 | 1.9 | -2.4 | 151.9 | 33.7 |
| WOUNDS ON THE RANKS | 2.2 | +212.1 | 0.0 | 26.1 | 3.7 | +196.9 | 0.0 | 46.7 |

### Rule changes: base-s1-882d875-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2583 | 2583 | 1595 | 45.57 | +0 | +0.0 |
| HIS MOVE WHY | 2567 | 2567 | 1372 | 39.20 | +0 | +0.0 |
| ARMY TABLE | 1202 | 1202 | 845 | 24.14 | +16547 | +19.6 |
| HIS SHOT LIST | 2757 | 2621 | 709 | 20.26 | +17622 | +24.9 |
| HOLDER ASSIGNMENT | 653 | 653 | 606 | 17.31 | +37771 | +62.3 |
| ONE TARGET A SHOOTER | 1958 | 1869 | 379 | 10.83 | +4421 | +11.7 |
| DEPLOY BY FIGURES | 529 | 529 | 332 | 9.49 | +5050 | +15.2 |
| HIS ONE MOVE | 1315 | 1284 | 297 | 8.49 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 296 | 296 | 296 | 8.46 | +0 | +0.0 |
| TIME ON OUR SIDE | 1753 | 1589 | 279 | 7.97 | +1054 | +3.8 |
| FIVE ACTION | 6054 | 5843 | 243 | 6.94 | +11402 | +46.9 |
| OFF BEST | 243 | 243 | 243 | 6.94 | -11122 | -45.8 |
| THE TABLE AGAIN | 420 | 420 | 242 | 6.91 | +0 | +0.0 |
| SHOT RISK POINTS | 1378 | 1308 | 211 | 6.03 | +8152 | +38.6 |
| PROMISE BY ITS OWN SUM | 526 | 526 | 199 | 5.69 | -16663 | -83.7 |
| MOVE TO CHARGE COMPUTED | 388 | 328 | 183 | 5.23 | +6735 | +36.8 |
| HARD STAY DROPPED | 179 | 179 | 179 | 5.11 | +0 | +0.0 |
| SUPPORT ADDS | 493 | 474 | 146 | 4.17 | +5397 | +37.0 |
| SUPPORT WORKED OUT | 493 | 474 | 146 | 4.17 | +5397 | +37.0 |
| QUARTER ODDS | 1198 | 1130 | 135 | 3.86 | +11681 | +86.5 |
| MOVE ORDER | 132 | 132 | 132 | 3.77 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 215 | 215 | 127 | 3.63 | +2091 | +16.5 |
| FOUR ROUNDS | 207 | 200 | 90 | 2.57 | +4565 | +50.7 |
| IDLE COST | 530 | 426 | 84 | 2.40 | +715 | +8.5 |
| ADVANCE LANE KEPT | 61 | 61 | 61 | 1.74 | +0 | +0.0 |
| MAX FOR POSITIONING | 187 | 170 | 58 | 1.66 | +261 | +4.5 |
| LANE BY FIGURES | 50 | 50 | 50 | 1.43 | +2361 | +47.2 |
| ARTILLERY RE-ROLL WEIGHED | 48 | 48 | 48 | 1.37 | +0 | +0.0 |
| CAST JOB | 65 | 65 | 48 | 1.37 | +133 | +2.8 |
| CHARGE LOSSES | 715 | 671 | 47 | 1.34 | +3000 | +63.8 |
| CHAFF IN THE MOVE | 58 | 57 | 46 | 1.31 | +58 | +1.3 |
| JOINT CHARGE NOW | 46 | 46 | 46 | 1.31 | +3360 | +73.0 |
| SHOTS IN THE MOVE | 889 | 707 | 45 | 1.29 | +1572 | +34.9 |
| FOLLOW UP WEIGHED | 44 | 44 | 44 | 1.26 | +8168 | +185.6 |
| RANDOM MOVE BY FIGURES | 89 | 89 | 43 | 1.23 | +1093 | +25.4 |
| STAY WORTH | 1354 | 1249 | 43 | 1.23 | +447 | +10.4 |
| FALLS SHORT | 717 | 600 | 42 | 1.20 | +309 | +7.3 |
| SET UP BY THE SET | 115 | 110 | 40 | 1.14 | +2828 | +70.7 |
| RISK BY ARC | 140 | 137 | 39 | 1.11 | +1002 | +25.7 |
| CANNON SIGHT KEPT | 38 | 38 | 38 | 1.09 | +0 | +0.0 |
| RISK BY HIS FIGURE | 1242 | 1180 | 36 | 1.03 | +2513 | +69.8 |
| TIED UP BY THE SUM | 52 | 49 | 36 | 1.03 | +1680 | +46.7 |
| WOUNDS ON THE RANKS | 205 | 198 | 36 | 1.03 | +1415 | +39.3 |
| COVER ONCE | 311 | 228 | 33 | 0.94 | +1011 | +30.6 |
| PATHS CROSS | 33 | 33 | 33 | 0.94 | +1805 | +54.7 |
| HOLDS AMBUSHERS | 32 | 32 | 32 | 0.91 | +0 | +0.0 |
| MARCH CHECK | 53 | 50 | 31 | 0.89 | +463 | +14.9 |
| MISSILES IN THE MOVE | 264 | 187 | 31 | 0.89 | +744 | +24.0 |
| CHARGE NOW FIRST | 101 | 101 | 28 | 0.80 | -1797 | -64.2 |
| SHOTS AFTER THE MOVES | 181 | 181 | 28 | 0.80 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 0.77 | +1945 | +72.1 |
| HIS TURN DENIED | 87 | 84 | 25 | 0.71 | +1160 | +46.4 |
| MARCH BY THE SUM | 24 | 24 | 24 | 0.69 | +1775 | +73.9 |
| REDIRECT COUNTER | 133 | 105 | 24 | 0.69 | +1660 | +69.2 |
| SEARCH SPOT | 32 | 32 | 24 | 0.69 | +972 | +40.5 |
| NEARER NOT NEEDED | 472 | 456 | 21 | 0.60 | +766 | +36.5 |
| COMBAT PIVOT | 20 | 20 | 20 | 0.57 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 363 | 327 | 20 | 0.57 | +344 | +17.2 |
| RESERVE FALL BACK | 20 | 20 | 20 | 0.57 | +777 | +38.8 |
| CANNON PLANNED TARGET | 212 | 212 | 19 | 0.54 | +127 | +6.7 |
| SHOOTERS IN TWO RANKS | 19 | 19 | 19 | 0.54 | +40 | +2.1 |
| SCOUT WAITS | 18 | 18 | 18 | 0.51 | +0 | +0.0 |
| CHAFF PASSED | 16 | 16 | 16 | 0.46 | -10 | -0.6 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.43 | +0 | +0.0 |
| MANOEUVRE | 58 | 58 | 15 | 0.43 | +337 | +22.5 |
| WHO HITS BACK | 14 | 14 | 14 | 0.40 | +1772 | +126.6 |
| FEATURE BUFFS | 111 | 110 | 13 | 0.37 | +287 | +22.1 |
| MARCH OF THE TABLE | 13 | 13 | 13 | 0.37 | -749 | -57.6 |
| MODEL FACING | 13 | 13 | 13 | 0.37 | +2344 | +180.3 |
| ONE OBJECTIVE FORMULA | 258 | 183 | 13 | 0.37 | +560 | +43.1 |
| OPENS UP | 24 | 24 | 12 | 0.34 | +257 | +21.4 |
| STUCK PIVOT | 12 | 12 | 12 | 0.34 | +0 | +0.0 |
| CASTS FROM BEHIND | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| MISSILES NEXT TURN | 353 | 256 | 11 | 0.31 | +112 | +10.2 |
| SURE REACH TOGETHER | 34 | 31 | 11 | 0.31 | +97 | +8.9 |
| FIRE IN ORDER | 10 | 10 | 10 | 0.29 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.29 | +175 | +17.5 |
| HIS FIGHT TOGETHER | 105 | 101 | 10 | 0.29 | +595 | +59.5 |
| REDIRECT WEIGHED | 10 | 10 | 10 | 0.29 | +405 | +40.5 |
| SECOND LOOK | 10 | 10 | 10 | 0.29 | +597 | +59.7 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.29 | +0 | +0.0 |
| GUN MASK | 57 | 57 | 9 | 0.26 | +230 | +25.5 |
| HIS CHARGE DENIED | 23 | 23 | 9 | 0.26 | +248 | +27.5 |
| HIS MOVE AND SHOT | 202 | 193 | 9 | 0.26 | +75 | +8.4 |
| OVERRUNS AWAY | 20 | 18 | 9 | 0.26 | +160 | +17.8 |
| ONE PROMISE A TARGET | 8 | 8 | 8 | 0.23 | -706 | -88.2 |
| BEST PRIZE | 7 | 7 | 7 | 0.20 | -850 | -121.5 |
| FIGHT TO THE END | 36 | 34 | 7 | 0.20 | +146 | +20.8 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.20 | -184 | -26.2 |
| PROMISE SHOT AWAY | 7 | 7 | 7 | 0.20 | -52 | -7.4 |
| SUPPORT NARROWED | 16 | 16 | 7 | 0.20 | -156 | -22.2 |
| WAR ENGINE JOBS | 27 | 27 | 7 | 0.20 | -171 | -24.5 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.17 | +177 | +29.6 |
| CASTING BLOCK | 16 | 16 | 6 | 0.17 | +365 | +60.8 |
| AFTERMATH WITH FRIENDS | 5 | 5 | 5 | 0.14 | +160 | +32.0 |
| CHARGE NOT DECLARED | 5 | 5 | 5 | 0.14 | -482 | -96.4 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +112 | +22.5 |
| MOVES UNITS SPELL | 5 | 5 | 5 | 0.14 | +129 | +25.8 |
| SPELLS IN THE FIGHT | 36 | 35 | 5 | 0.14 | +56 | +11.1 |
| WHOLE FIGHT GAIN | 12 | 12 | 5 | 0.14 | +77 | +15.3 |
| WIDER SPREAD | 125 | 120 | 5 | 0.14 | +28 | +5.6 |
| PROMISE READS THE TABLE | 16 | 16 | 4 | 0.11 | +97 | +24.3 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +201 | +50.3 |
| WHO GETS IN | 4 | 4 | 4 | 0.11 | +330 | +82.4 |
| BOMBING RUN | 3 | 3 | 3 | 0.09 | +150 | +50.1 |
| CHARIOT NO STATIC JOB | 3 | 3 | 3 | 0.09 | -296 | -98.7 |
| EDGE GIVE GROUND | 13 | 13 | 3 | 0.09 | +96 | +32.1 |
| FALL BACK GOOD ORDER | 143 | 139 | 3 | 0.09 | +17 | +5.8 |
| HONEST WORTH | 176 | 169 | 3 | 0.09 | +28 | +9.4 |
| HUNT IN PAIRS | 15 | 9 | 3 | 0.09 | +162 | +54.0 |
| NO DOUBLE ROUNDS | 157 | 151 | 3 | 0.09 | +320 | +106.6 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.09 | +230 | +76.8 |
| PROMISE KNOWS THE FIGHT | 44 | 28 | 3 | 0.09 | -15 | -4.9 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| FALLBACK BY WORTH | 19 | 19 | 2 | 0.06 | +10 | +5.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LOST AFTER ESCAPE | 101 | 97 | 2 | 0.06 | +15 | +7.4 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +89 | +44.5 |
| REFUSING RETIRES | 19 | 19 | 2 | 0.06 | -0 | -0.2 |
| RUN DOWN | 128 | 123 | 2 | 0.06 | +23 | +11.4 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.06 | -72 | -36.0 |
| WHAT THE JOINER ADDS | 19 | 19 | 2 | 0.06 | +17 | +8.5 |
| BEST OVERALL | 1 | 1 | 1 | 0.03 | +45 | +45.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +20 | +19.6 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +6 | +6.5 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +17 | +16.8 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.03 | +61 | +61.1 |
| MARCH ODDS | 1 | 1 | 1 | 0.03 | -12 | -12.3 |
| MOVE SPELL IN RANGE | 5 | 5 | 1 | 0.03 | +25 | +24.8 |
| ONE FIGHT FORMULA | 253 | 127 | 1 | 0.03 | +2 | +2.0 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -189 | -189.4 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.03 | +45 | +45.3 |
| STOPS | 2 | 2 | 1 | 0.03 | +7 | +7.2 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +95 | +95.4 |
| WHOLE FIGHT | 10 | 10 | 1 | 0.03 | +8 | +8.5 |
| ALREADY CARRIED | 5 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 10 | 5 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 9 | 9 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 63 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 6 | 6 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 59 | 59 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 20 | 20 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 85 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 37 | 36 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 240 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 21 | 20 | 0 | 0.00 | - | - |
| GIVES UP | 23 | 20 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 58 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 174 | 171 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 366 | 348 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 232 | 208 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 268 | 236 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 78 | 78 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 245 | 233 | 0 | 0.00 | - | - |
| HOLD ODDS | 1106 | 1100 | 0 | 0.00 | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 206 | 202 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 24 | 24 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 8 | 8 | 0 | 0.00 | - | - |
| LOST CHARGE | 4 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 10 | 10 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 10 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 11 | trace | - | - | - | - |
| MARCH OVER CASTS | 53 | 53 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 93 | 90 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 9 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 26 | trace | - | - | - | - |
| MOVE SPELL SPOT | 33 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 58 | 56 | 0 | 0.00 | - | - |
| NOT TURNED | 16 | 16 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 51 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 254 | 245 | 0 | 0.00 | - | - |
| ONE ROUTE | 93 | 90 | 0 | 0.00 | - | - |
| OPENS A LANE | 19 | 16 | 0 | 0.00 | - | - |
| PLAN RESULT | 2869 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 15 | 15 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 93 | 90 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 54 | 54 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 88 | 79 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 31 | 29 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 42 | 39 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 27 | 27 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET UP TOGETHER | 17 | 8 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOT OR CHARGE | 23 | 22 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 110 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 552 | 525 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 44 | 43 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 59 | 56 | 0 | 0.00 | - | - |
| STANDS STILL | 2745 | 2660 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 17 | 16 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 91 | not checked | - | - | - | - |
| THE PROMISE ADDS | 19 | 19 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2195 | not checked | - | - | - | - |
| WAITS AGAIN | 101 | 85 | 0 | 0.00 | - | - |

### Off best figure: base-s1-882d875-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.89 | 2.80 | 83.7 |
| JOB FIRST | gate | 2.71 | 2.71 | 40.7 |
| ARMY TABLE | rule | 1.60 | 1.97 | 37.6 |
| HOLDER ASSIGNMENT | rule | 0.54 | 0.71 | 21.6 |
| NO REASON | gate | 0.57 | 0.63 | 56.8 |
| CHARGE NOW FIRST | rule | 0.46 | 0.34 | 64.2 |
| JOINT CHARGE NOW | rule | 0.11 | 0.26 | 70.4 |
| MARCH OF THE TABLE | rule | 0.26 | 0.09 | 62.4 |
| BEST PRIZE | rule | 0.06 | 0.14 | 121.5 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.17 | 26.2 |
| SUPPORT NARROWED | rule | 0.09 | 0.11 | 22.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.06 | 164.7 |
| ONE PROMISE A TARGET | rule | 0.06 | 0.11 | 117.7 |
| CHARGE NOT DECLARED | rule | 0.03 | 0.11 | 96.4 |
| WAR ENGINE JOBS | rule | 0.11 | 0.03 | 34.2 |
| DEPLOY BY FIGURES | rule | 0.06 | 0.06 | 8.3 |
| PROMISE SHOT AWAY | rule | 0.06 | 0.06 | 12.8 |
| REDIRECT WEIGHED | rule | 0.03 | 0.09 | 80.6 |
| CHARIOT NO STATIC JOB | rule | 0.06 | 0.03 | 98.7 |
| FALLBACK | gate | 0.09 | - | 2.7 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.09 | 4.9 |
| AFTERMATH BAND | gate | - | 0.06 | 2.4 |
| CANNON PLANNED TARGET | rule | 0.06 | - | 6.2 |
| CHAFF PASSED | rule | - | 0.06 | 4.7 |
| PROMISE READS THE TABLE | rule | - | 0.06 | 46.5 |
| WALKS ON ITS ROUTE | rule | 0.03 | 0.03 | 36.0 |
| MARCH ODDS | rule | - | 0.03 | 12.3 |
| PURSUES BIG PREY | rule | 0.03 | - | 189.4 |
| SET UP BY THE SET | rule | - | 0.03 | 86.7 |
| WHO GETS IN | rule | 0.03 | - | 301.2 |
| WHO HITS BACK | rule | - | 0.03 | 3.4 |

### Plans: base-s1-882d875-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 57% | 337 | 180 | 53% |
| Mine | join | 0.5 | 100% | 15 | 0 | 0% |
| Mine | move | 28.7 | 97% | 1552 | 0 | 0% |
| Mine | shoot | 9.9 | 53% | 634 | 728 | 115% |
| Mine | support | 0.6 | 90% | 25 | 0 | 0% |
| Opponent | charge | 2.4 | 54% | 426 | 188 | 44% |
| Opponent | join | 1.7 | 98% | 58 | 0 | 0% |
| Opponent | move | 31.5 | 94% | 1346 | 0 | 0% |
| Opponent | shoot | 3.7 | 57% | 250 | 248 | 99% |
| Opponent | support | 0.6 | 77% | 4 | 0 | 0% |

### Packages: hunt the guns, base-s1-882d875-p6

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 358 | 313 | 100% | 18 |
| Opponent | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 360 | 316 | 100% | 68 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 358 | 313 | 100% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 155 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 124 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 134 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 42 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 132 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 360 | 316 | 100% | 9 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 53 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: base-s1-882d875-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.4 | 26% | 38% | 8% | 0% | 25% | 8% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 2.4 | 25% | 90% | 14% | 67% | 6% | 0% | 0% | 94% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s1-882d875-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Chaff | 34 | 37 (34) | 3 | 34 | 34 | 56% | 3.5 | 21 (21) | 93 (7) | 18 (6) | 34 (25) | 43 (9) |
| Mine | Character | 117 | 42 (117) | 41 | 1 | 21 | 30% | 2.4 | 26 (45) | 53 (52) | 49 (16) | 35 (65) | 51 (48) |
| Mine | Clean-up | 27 | 52 (27) | 11 | 40 | 29 | 56% | 3.2 | 65 (11) | 22 (11) | 65 (5) | 70 (20) | 11 (7) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Fast Hammer | 39 | 47 (39) | 20 | 27 | 6 | 36% | 2.5 | 49 (15) | 46 (16) | 47 (8) | 45 (19) | 50 (20) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 53 | 36 (53) | 23 | 13 | 24 | 25% | 2.9 | 31 (14) | 37 (33) | 41 (6) | 51 (37) | 8 (16) |
| Mine | Holder | 25 | 104 (25) | 0 | 104 | 26 | 48% | 3.5 | 64 (7) | 145 (13) | 54 (3) | 147 (15) | 39 (8) |
| Mine | Shooter | 39 | 59 (39) | 15 | 45 | 33 | 8% | 1.8 | 15 (10) | 87 (19) | 36 (10) | 75 (27) | 26 (12) |
| Mine | War machine | 56 | 35 (56) | 35 | 0 | 34 | 2% | 1.4 | 22 (22) | 65 (18) | 17 (16) | 45 (10) | 33 (46) |
| Mine | Wizard | 16 | 5 (16) | 5 | 0 | 43 | 31% | 2.9 | 14 (6) | 3 (7) | 0 (1) | 3 (5) | 11 (9) |
| Opponent | Chaff | 57 | 48 (57) | 4 | 44 | 42 | 46% | 3.1 | 9 (21) | 109 (15) | 50 (21) | 55 (43) | 26 (14) |
| Opponent | Character | 101 | 41 (101) | 41 | 0 | 26 | 36% | 2.6 | 36 (39) | 41 (40) | 55 (15) | 46 (53) | 35 (41) |
| Opponent | Clean-up | 26 | 23 (26) | 0 | 23 | 26 | 69% | 3.5 | 0 (5) | 46 (12) | 0 (9) | 40 (15) | 3 (11) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 51 | 30 (51) | 12 | 17 | 37 | 41% | 3.0 | 8 (15) | 38 (28) | 36 (8) | 34 (31) | 23 (20) |
| Opponent | Hammer | 53 | 27 (53) | 7 | 20 | 32 | 42% | 2.8 | 22 (20) | 27 (26) | 36 (7) | 38 (29) | 12 (24) |
| Opponent | Holder | 32 | 27 (32) | 1 | 26 | 24 | 56% | 2.9 | 53 (9) | 42 (11) | 6 (7) | 60 (11) | 15 (16) |
| Opponent | Shooter | 31 | 41 (31) | 14 | 27 | 46 | 10% | 1.5 | 60 (6) | 40 (17) | 29 (8) | 69 (17) | 13 (14) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | - | 0 (4) | - | - | 0 (4) |
| Opponent | War machine | 17 | 28 (17) | 28 | 0 | 61 | 12% | 1.9 | 44 (11) | 0 (5) | 0 (1) | 0 (2) | 31 (15) |
| Opponent | Wizard | 23 | 6 (23) | 6 | 0 | 20 | 9% | 3.0 | 0 (7) | 0 (6) | 18 (8) | 13 (10) | 0 (11) |

### Charged fights: base-s1-882d875-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 246 | 117 | 1.8 | 1.0 | 67 | 15 | +52 | 1 of 7 | 5 of 6 | - | +52 |
| Mine | Chaos Dwarfs | 4 | 152 | 307 | 2.2 | 1.1 | 137 | 64 | +72 | 2 of 9 | 9 of 9 | -211 | +108 |
| Mine | Dwarfen Mountain Holds | 4 | 386 | 8 | 1.0 | 1.0 | 8 | 15 | -6 | 1 of 4 | 1 of 4 | - | -6 |
| Mine | Empire of Man | 4 | 453 | 228 | 1.2 | 1.0 | 182 | 0 | +182 | 2 of 5 | 2 of 5 | - | +182 |
| Mine | Grand Cathay | 5 | 146 | 163 | 2.2 | 1.1 | 74 | 0 | +74 | 4 of 11 | 8 of 11 | +227 | +59 |
| Mine | High Elf Realms | 4 | 117 | 630 | 3.0 | 1.2 | 210 | 0 | +210 | 3 of 12 | 12 of 12 | +159 | +220 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 170 | 2.0 | 1.0 | 85 | 0 | +85 | 1 of 2 | 0 of 2 | - | +85 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 376 | -376 | 1 of 2 | 0 of 2 | - | -376 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 292 | 3.0 | 1.0 | 97 | 37 | +61 | 1 of 3 | 2 of 3 | - | +61 |
| Mine | Skaven | 2 | 118 | 60 | 1.0 | 1.0 | 60 | 19 | +41 | 1 of 2 | 1 of 2 | - | +41 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 211 | 4.0 | 1.0 | 53 | 0 | +53 | 1 of 4 | 4 of 4 | - | +53 |
| Mine | Vampire Counts | 2 | 0 | 328 | 2.5 | 1.0 | 131 | 100 | +31 | 3 of 5 | 2 of 5 | - | +31 |
| Mine | Warriors of Chaos | 2 | 0 | 51 | 1.0 | 1.0 | 51 | 0 | +51 | 0 of 2 | 1 of 2 | - | +51 |
| **Mine** | all armies | 35 | 182 | 215 | 1.9 | 1.1 | 111 | 32 | +79 | 21 of 68 | 47 of 67 | +84 | +79 |
| Opponent | Empire of Man | 3 | 103 | 0 | 0.3 | 1.0 | 0 | 102 | -102 | 1 of 1 | 0 of 1 | - | -102 |
| Opponent | Grand Cathay | 2 | 218 | 32 | 2.0 | 1.0 | 16 | 0 | +16 | 2 of 4 | 3 of 4 | - | +16 |
| Opponent | High Elf Realms | 3 | 118 | 607 | 3.0 | 1.0 | 202 | 16 | +186 | 3 of 9 | 6 of 9 | - | +186 |
| Opponent | Lizardmen | 1 | 60 | 0 | 1.0 | 1.0 | 0 | 316 | -316 | 1 of 1 | 0 of 1 | - | -316 |
| Opponent | Ogre Kingdoms | 1 | 105 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Skaven | 3 | 161 | 123 | 0.7 | 1.0 | 184 | 32 | +152 | 2 of 2 | 1 of 2 | - | +152 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 662 | 5.0 | 1.2 | 132 | 0 | +132 | 3 of 5 | 4 of 5 | +348 | +78 |
| Opponent | Vampire Counts | 6 | 0 | 240 | 3.3 | 1.1 | 72 | 62 | +10 | 8 of 20 | 12 of 20 | -19 | +15 |
| Opponent | Warriors of Chaos | 11 | 24 | 172 | 1.7 | 1.3 | 99 | 93 | +7 | 11 of 19 | 12 of 19 | -4 | +10 |
| Opponent | Wood Elf Realms | 4 | 108 | 518 | 3.2 | 1.1 | 159 | 0 | +159 | 5 of 13 | 13 of 13 | +126 | +162 |
| **Opponent** | all armies | 35 | 70 | 238 | 2.1 | 1.1 | 111 | 48 | +63 | 37 of 75 | 52 of 75 | +44 | +65 |

### Effective charges: base-s1-882d875-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 0 | 3 (net +99) | 1 (net +0) | 0 | 2 (net +34) | 1 | 50% (3 of 6) |
| Mine | Chaos Dwarfs | 9 | 0 | 0 | 0 | 3 (net +142) | 3 (net +60) | 3 (net +14) | 0 | 0% (0 of 9) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +0) | 1 (net -60) | 0 | 0 | 0 | 2 (net +17) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 5 | 2 (net +338) | 1 (net +235) | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0% (0 of 5) |
| Mine | Grand Cathay | 11 | 2 (net +114) | 1 (net +0) | 2 (net +76) | 1 (net +0) | 1 (net +80) | 2 (net +104) | 2 | 22% (2 of 9) |
| Mine | High Elf Realms | 12 | 0 | 0 | 1 (net +505) | 3 (net +250) | 5 (net +55) | 2 (net +366) | 1 | 9% (1 of 11) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +170) | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 1 (net -752) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 1 (net +122) | 0 | 0 | 0 | 2 | 100% (1 of 1) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 1 (net +82) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 4 | 2 (net +34) | 0 | 0 | 1 (net +68) | 0 | 1 (net +75) | 0 | 0% (0 of 4) |
| Mine | Vampire Counts | 5 | 3 (net +15) | 0 | 0 | 0 | 1 (net +111) | 1 (net +0) | 0 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Empire of Man | 1 | 1 (net -102) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 4 | 0 | 0 | 0 | 0 | 1 (net +65) | 2 (net +0) | 1 | 0% (0 of 3) |
| Opponent | High Elf Realms | 9 | 0 | 0 | 2 (net +69) | 3 (net +291) | 0 | 2 (net +286) | 2 | 29% (2 of 7) |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 1 (net +304) | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net +348) | 1 (net +125) | 0 | 3 (net +63) | 0 | 20% (1 of 5) |
| Opponent | Vampire Counts | 20 | 6 (net -82) | 0 | 5 (net -25) | 0 | 4 (net +53) | 3 (net +159) | 2 | 28% (5 of 18) |
| Opponent | Warriors of Chaos | 19 | 6 (net -15) | 1 (net -228) | 0 | 3 (net +64) | 0 | 4 (net +124) | 5 | 0% (0 of 14) |
| Opponent | Wood Elf Realms | 13 | 1 (net +145) | 0 | 3 (net +277) | 1 (net +220) | 1 (net +145) | 2 (net +63) | 5 | 38% (3 of 8) |

### Charged fights, damage counted: base-s1-882d875-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 295 | 353 | +20 | 158 | 136 | +22 | +7.5 |
| Mine | 50-54% | 3 | 258 | 234 | +58 | 85 | 94 | -9 | -3.4 |
| Mine | Effective (55-75%) | 10 | 204 | 128 | +116 | 132 | 62 | +70 | +34.5 |
| Mine | 76-89% | 10 | 376 | 175 | +124 | 127 | 43 | +84 | +22.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 243 | 130 | +95 | 148 | 78 | +70 | +28.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 406 | 70 | +59 | 59 | 7 | +52 | +12.8 |
| Mine | No odds | 7 | 418 | 222 | +81 | 97 | 23 | +73 | +17.5 |
| Mine | All fights | 68 | 312 | 183 | +79 | 122 | 65 | +57 | +18.3 |
| Opponent | Long shot (under 50%) | 15 | 230 | 323 | -15 | 156 | 135 | +21 | +9.0 |
| Opponent | 50-54% | 2 | 563 | 298 | -114 | 149 | 240 | -90 | -16.0 |
| Opponent | Effective (55-75%) | 11 | 332 | 241 | +108 | 180 | 74 | +106 | +31.9 |
| Opponent | 76-89% | 9 | 361 | 201 | +157 | 183 | 28 | +156 | +43.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 332 | 237 | +116 | 134 | 20 | +114 | +34.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 338 | 82 | +70 | 74 | 0 | +74 | +22.0 |
| Opponent | No odds | 16 | 382 | 178 | +17 | 87 | 44 | +42 | +11.0 |
| Opponent | All fights | 75 | 332 | 227 | +63 | 137 | 61 | +75 | +22.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s1-882d875-p6 | move | 173 | 40 (23%) | 27 (16%) | 19 (11%) | 114 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0124, L2431, L2628 |
| Charmed Shield | Opponent | L0124, L0224, L0325, L0427, L1325, L2134, L2325 |
| Clockwork Compass | Mine | L1214, L1230 |
| Elixir of Power | Mine | L1120, L1929 |
| Elixir of Power | Opponent | L0411, L1011 |
| Fistful of Laurels | Mine | L1829 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L1533 |
| Invocation of Nehek | Mine | L2431 |
| Invocation of Nehek | Opponent | L0124, L0224, L0325, L0427, L1325, L2325 |
| Opal Amulet | Mine | L1420 |
| Opal Amulet | Opponent | L0514, L1214 |
| Periapt of Soul Exchange | Mine | L2031, L2134 |
| Periapt of Soul Exchange | Opponent | L0920, L1120, L1420 |
| Ring of Doom | Mine | L0208, L0224, L1120, L1214, L1230, L1517, L1533 |
| Ring of Doom | Opponent | L0411, L1011, L1533, L1631, L2031, L2431 |
| Ring of Jet | Mine | L1011, L1028, L1120, L1214, L1230 |
| Ring of Jet | Opponent | L0411, L1011 |
| Standard of the Fell Warrior | Mine | L1325 |
| Standard of the Fell Warrior | Opponent | L0813 |
| Storm Daemon (Renegade 2.0) | Mine | L2134 |
| Twice-Blessed Armour | Mine | L0723, L1011, L1028 |
| Witch Hunter's Ward | Mine | L0723, L0813, L0829 |
| Witch Hunter's Ward | Opponent | L0108, L0208 |

# Doctrine scorecard: base-s2-882d875-p4

### Scorecard: base-s2-882d875-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 2 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 2 | Opponent | no | 4 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 2 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 2 | Opponent | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 70 |
| L0214 | 4 | 2 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 2 | Opponent | yes | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 2 | Mine | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 2 | Opponent | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 2 | Mine | no | 4 | 4 | 0 | 0 | 0 | 0 | 0 | 110 |
| L0315 | 3 | 2 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 2 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 140 |
| L0332 | 2 | 2 | Opponent | - | - | 2 | 2 | 8 | 0 | 0 | 0 | 170 |
| L0417 | 3 | 2 | Mine | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 65 |
| L0417 | 3 | 2 | Opponent | no | 8 | 4 | 0 | 0 | 2 | 0 | 0 | 185 |
| L0434 | 2 | 2 | Mine | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 189 |
| L0434 | 2 | 2 | Opponent | - | - | 4 | 3 | 5 | 0 | 0 | 0 | 590 |
| L0520 | 4 | 2 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 1185 |
| L0520 | 4 | 2 | Opponent | no | 0 | - | 0 | 7 | 0 | 0 | 0 | 420 |
| L0608 | 2 | 2 | Mine | - | - | - | 1 | 6 | 1 | 0 | 0 | 490 |
| L0608 | 2 | 2 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 250 |
| L0624 | 6 | 2 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 873 |
| L0624 | 6 | 2 | Opponent | no | 2 | 5 | 3 | 1 | 1 | 0 | 0 | 205 |
| L0713 | 5 | 2 | Mine | no | - | 3 | 1 | 2 | 2 | 0 | 0 | 425 |
| L0713 | 5 | 2 | Opponent | yes | - | 3 | 1 | 2 | 1 | 0 | 0 | 70 |
| L0729 | 3 | 2 | Mine | no | 5 | 3 | 0 | 0 | 0 | 0 | 0 | 125 |
| L0729 | 3 | 2 | Opponent | no | 13 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 2 | Mine | no | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 206 |
| L0819 | 3 | 2 | Opponent | no | 11 | 2 | 1 | 3 | 0 | 0 | 0 | 55 |
| L0835 | 1 | 2 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 206 |
| L0835 | 1 | 2 | Opponent | no | 1 | 6 | 1 | 5 | 0 | 0 | 0 | 337 |
| L0926 | 2 | 2 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 477 |
| L0926 | 2 | 2 | Opponent | - | - | 2 | 5 | 7 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 2 | Mine | no | 6 | 3 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1017 | 3 | 2 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 497 |
| L1034 | 2 | 2 | Mine | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1034 | 2 | 2 | Opponent | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 107 |
| L1126 | 4 | 2 | Mine | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 2 | Opponent | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 2 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 2 | Opponent | - | - | - | 0 | 4 | 1 | 0 | 0 | 650 |
| L1314 | 6 | 2 | Mine | no | 1 | 2 | 1 | 1 | 2 | 0 | 0 | 0 |
| L1314 | 6 | 2 | Opponent | no | 3 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 2 | Mine | no | - | 2 | 4 | 1 | 0 | 0 | 0 | 221 |
| L1331 | 5 | 2 | Opponent | yes | - | 6 | 1 | 1 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 2 | Mine | no | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 2 | Opponent | yes | - | 5 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 2 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 2 | Opponent | yes | - | 2 | 5 | 0 | 2 | 0 | 0 | 245 |
| L1621 | 1 | 2 | Mine | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 336 |
| L1621 | 1 | 2 | Opponent | no | 7 | - | 0 | 4 | 0 | 0 | 0 | 420 |
| L1719 | 3 | 2 | Mine | no | 2 | 4 | 1 | 0 | 1 | 0 | 0 | 580 |
| L1719 | 3 | 2 | Opponent | no | 0 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 2 | Mine | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 311 |
| L1819 | 1 | 2 | Opponent | no | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 2 | Mine | yes | - | 2 | 2 | 6 | 0 | 0 | 0 | 145 |
| L1835 | 5 | 2 | Opponent | no | - | 6 | 2 | 1 | 0 | 0 | 0 | 639 |
| L2021 | 5 | 2 | Mine | yes | - | - | 0 | 4 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 2 | Opponent | yes | - | - | 0 | 4 | 0 | 0 | 0 | 715 |
| L2123 | 5 | 2 | Mine | yes | - | - | 3 | 6 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 2 | Opponent | yes | - | 1 | 0 | 2 | 0 | 0 | 0 | 501 |
| L2227 | 1 | 2 | Mine | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L2227 | 1 | 2 | Opponent | no | 0 | 1 | 10 | 1 | 0 | 0 | 0 | 380 |
| L2331 | 3 | 2 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 2 | Opponent | no | 0 | 3 | 2 | 1 | 3 | 0 | 0 | 340 |
| L2527 | 1 | 2 | Mine | no | 5 | 2 | 0 | 3 | 1 | 0 | 0 | 591 |
| L2527 | 1 | 2 | Opponent | yes | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 2 | Mine | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 2 | Opponent | no | 0 | 2 | 4 | 5 | 0 | 0 | 0 | 389 |
| L2930 | 2 | 2 | Mine | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 615 |
| L2930 | 2 | 2 | Opponent | - | - | 2 | 0 | 4 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 2 | Mine | no | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 2 | Opponent | no | 2 | 3 | 3 | 1 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 14% | 3.2 | 2.4 | 1.9 | 1.7 | 0.2 | 0.0 | 0.0 | 250.8 |
| **Average** | | | Opponent | 29% | 2.8 | 2.9 | 2.5 | 2.8 | 0.3 | 0.0 | 0.0 | 212.0 |

### KPIs: base-s2-882d875-p4

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 34% (54 of 161) | 0% (0 of 166) | 17% (54 of 327) |
| Winner chose to follow up after the loser gave ground |  | 87% (27 of 31); on the table 90% | 93% (40 of 43); on the table 95% | 91% (67 of 74); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (4 of 5); on the table 80% | 83% (5 of 6); on the table 83% | 82% (9 of 11); on the table 82% |
| Winner chose to pursue after the loser fled |  | 65% (11 of 17); on the table 71% | 72% (18 of 25); on the table 72% | 69% (29 of 42); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 79% (42 of 53); on the table 83% | 85% (63 of 74); on the table 86% | 83% (105 of 127); on the table 85% |
| Magic missiles tried each own turn | 50%+ | 28% (82 of 290) | 29% (41 of 140) | 29% (123 of 430) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (82 of 208) | 34% (41 of 120) | 38% (123 of 328) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (26 of 45) | 64% (41 of 64) | 61% (67 of 109) |
| Points that never fought | lower | 44% (29636 of 67942) | 49% (35261 of 71984) | 46% (64897 of 139926) |
|   infantry points that never fought | lower | 56% (8530 of 15347) | 70% (9680 of 13804) | 62% (18210 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (158 of 270) | 60% (167 of 280) | 59% (325 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.6 uses a game | 78% (7 of 9); 0.5 uses a game | 90% (28 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 38% (6 of 16); 0.3 uses a game | 20% (4 of 20); 0.2 uses a game | 28% (10 of 36); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 74% (14 of 19); 0.4 uses a game | 80% (12 of 15); 0.3 uses a game | 76% (26 of 34); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (29385 of 57750) | 53% (33860 of 63347) | 52% (63245 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (34%) | 1.5 (54%) | 3.4 (40%) |
| MARCHED: its unit marched | 1.3 (22%) | 0.5 (17%) | 1.8 (21%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.2 (8%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.2 (21%) | 0.4 (14%) | 1.6 (19%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (0%) | 0.2 (3%) |
| GONE: slain | 0.8 (14%) | 0.2 (6%) | 1.0 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.6 | 2.0 | 3.4 | 0.5 | 1.2 |
| not cast | 3.7 | 2.6 | 3.0 | 8.5 | 1.5 | 19.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (53%) | 0.3 (11%) | 3.4 (40%) | 0.4 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (21%) | 0.2 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (3%) | 0.4 (15%) | 1.6 (19%) | 0.2 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.3 (13%) | 0.6 (19%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.6 (3%) |
| GONE: slain | 0.5 (14%) | 0.3 (13%) | 0.5 (16%) | 1.0 (12%) | 0.1 (7%) | 2.3 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.3 (13%) | 0.0 (0%) | 0.0 (0%) | 0.6 (38%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (66%) | 0.2 (6%) | 1.1 (37%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.2 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 1.2 a game | 1.1 a game |
| stood (cast and not dispelled) | 68% (19 of 28) | 55% (21 of 38) | 61% (40 of 66) |
| the unit moved after it | 42% (8 of 19) | 43% (9 of 21) | 42% (17 of 40) |
| it charged on its next turn | 0% (0 of 19) | 0% (0 of 21) | 0% (0 of 40) |
| the enemy charged it first | 26% (5 of 19) | 0% (0 of 21) | 12% (5 of 40) |
| it fought by the end of its next turn | 16% (3 of 19) | 10% (2 of 21) | 12% (5 of 40) |
| it moved out of a charge the enemy had planned (not charged first) | 5% (1 of 19) | 5% (1 of 21) | 5% (2 of 40) |
| none of these (no charge, no fight, no charge escaped) | 58% (11 of 19) | 86% (18 of 21) | 72% (29 of 40) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (556 of 930) | 57% (320 of 561) | 59% (876 of 1491) |
|   cavalry | 70% (71 of 102) | 76% (93 of 123) | 73% (164 of 225) |
|   character | 39% (42 of 107) | 21% (29 of 139) | 29% (71 of 246) |
|   chariot | 71% (84 of 119) | 44% (8 of 18) | 67% (92 of 137) |
|   infantry | 58% (163 of 279) | 67% (163 of 242) | 63% (326 of 521) |
|   monster | 49% (17 of 35) | 54% (7 of 13) | 50% (24 of 48) |
|   war machine | 62% (179 of 288) | 77% (20 of 26) | 63% (199 of 314) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (15%) | 1.1 (16%) | 2.6 (15%) |
| CHARGED: it charged | 0.8 (8%) | 1.4 (21%) | 2.2 (13%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.4 (6%) | 1.1 (7%) |
| MOVED: a war machine that moved | 1.7 (16%) | 0.2 (2%) | 1.9 (11%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.8 (27%) | 2.0 (30%) | 4.8 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (3%) | 0.6 (9%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (18%) | 0.9 (13%) | 2.8 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.1 | 1.5 | 82% | 5.2 pts | 37 pts |
| character | 2.3 | 0.7 | 80% | 6.2 pts | 14 pts |
| chariot | 2.6 | 2.1 | 62% | 22.7 pts | 59 pts |
| infantry | 13.5 | 4.6 | 76% | 9.4 pts | 128 pts |
| monster | 0.7 | 0.2 | 83% | 8.0 pts | 5 pts |
| war machine | 5.5 | 4.8 | 63% | 27.8 pts | 154 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 4.4 | 3.7 |
| Charges that made contact a game | 2.1 | 3.1 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.04 declared, 0.91 contact (23 units) | 0.62 declared, 0.31 contact (16 units) | 0.87 declared, 0.67 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.60 declared, 0.40 contact (5 units) | 1.14 declared, 0.79 contact (14 units) | 1.00 declared, 0.68 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.31 declared, 0.20 contact (257 units) | 0.43 declared, 0.31 contact (311 units) | 0.37 declared, 0.26 contact (568 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (43 of 81) | 56% (9 of 16) | 67% (4 of 6) | 54% (56 of 103) |
| Character in a unit | 83% (25 of 30) | 60% (9 of 15) | - | 76% (34 of 45) |
| Character on its own | 77% (27 of 35) | 48% (13 of 27) | 35% (27 of 78) | 48% (67 of 140) |
| Chariot | 80% (12 of 15) | 42% (5 of 12) | - | 63% (17 of 27) |
| Infantry | 60% (50 of 83) | 48% (12 of 25) | 17% (1 of 6) | 55% (63 of 114) |
| Monster | 71% (24 of 34) | 50% (7 of 14) | - | 65% (31 of 48) |
| Monstrous | 100% (14 of 14) | 64% (9 of 14) | - | 82% (23 of 28) |
| War Machines | 77% (33 of 43) | 50% (1 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 64% (7 of 11); on the table 73% | 38% (36 of 96) | 25% | 45% (10 of 22) | 100% (6 of 6); 5.0 uses a game | 100% (2 of 2); 1.5 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 78% (7 of 9); on the table 89% | 33% (10 of 30) | 37% | 44% (14 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 75% (3 of 4); on the table 75% | - | 80% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 75% (3 of 4); on the table 100% | 33% (8 of 24) | 63% | 73% (45 of 62) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 100% (5 of 5); on the table 100% | 26% (23 of 90) | 45% | 57% (21 of 37) | 100% (9 of 9); 5.2 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 86% (12 of 14); on the table 86% | 11% (4 of 36) | 43% | 53% (37 of 70) | 100% (7 of 7); 2.8 uses a game | 20% (6 of 30); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 38% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (10 of 10); on the table 100% | 17% (1 of 6) | 32% | 67% (14 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (2 of 2); on the table 100% | - | 61% | 71% (10 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (5 of 5); on the table 100% | 17% (4 of 24) | 31% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 6 | 100% (4 of 4); on the table 100% | 24% (10 of 42) | 59% | 80% (36 of 45) | 67% (2 of 3); 0.3 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 89% (8 of 9); on the table 89% | - | 36% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 81% (13 of 16); on the table 81% | 33% (19 of 58) | 44% | 52% (22 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 80% (12 of 15); on the table 80% | 17% (3 of 18) | 43% | 64% (46 of 72) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 67% (10 of 15); on the table 67% | 83% (5 of 6) | 54% | 61% (34 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (base-s2-882d875-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (37) | 45% (22) | 49% (59) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.50 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.06 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.36 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.03 | 0.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.06 | 0.06 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.17 | 0.53 | 0.69 |

### Quality by phase: base-s2-882d875-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.6 |
| Strategy | Charge objectives carried out (made contact) | 48% (48 of 99) | 45% (56 of 124) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (137 of 412) | 38% (42 of 112) |
| Strategy | Support requests answered (helper made contact too) | 50% (4 of 8) | 31% (4 of 13) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 33% (2 of 6) |
| Strategy | Hexes on a unit its side charged or shot that turn | 71% (10 of 14) | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 48% (21 of 44) | 33% (8 of 24) |
| Strategy | Lone characters that fought | 70% (55 of 79) | 64% (59 of 92) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.7 | 2.8 |
| Movement | Points that never moved of their own | 250.8 | 212.0 |
| Movement | Fights charged into per game | 2.0 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 58, net -12 | 11 of 78, net -102 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 58, net +49 | 20 of 78, net +199 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 58, net +13 | 9 of 78, net +173 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 of 58, net +224 | 22 of 78, net +131 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.1 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (182 of 398) | 41% (140 of 338) |
| Shooting | Points destroyed by shooting units | 100.1 | 36.3 |
| Shooting | War machine shots | 5.0 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (108 of 179) | 50% (10 of 20) |
| Shooting | Points destroyed by war machines | 70.3 | 3.3 |
| Magic | Magic missiles cast | 1.5 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (14 of 54) | 30% (9 of 30) |
| Magic | Wounds caused by magic missiles | 3.9 | 0.9 |
| Magic | Wounds caused by other spells | 0.9 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 62.4 | 17.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.4 / 0.4 / 0.1 | 2.1 / 0.4 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 207.7 | 379.0 |
| Combat | Points run down | 96.5 | 100.5 |
| Combat | Net points per charged fight, damage counted | +52 | +102 |
| Combat | Net per 100 charger points, damage counted | +15.1 | +30.4 |
| Combat | First round won (charged fights) | 79% | 83% |
| Combat | Net points per charged fight | +52 | +107 |
| Combat | Net points per supported fight / lone fight | -63 / +59 | +261 / +95 |
| Combat | Charged fights on a top-3 enemy unit | 20 of 73 | 50 of 104 |
| Game | Points lost | 671.2 | 617.0 |
| Game | VP from objectives | 611.4 | 618.9 |
| Game | Lone holders (player turns) | 3.2 | 2.8 |

- Mine won / drew / lost: 11 / 10 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -82 VP
- The side that went first won 9 of 26 games with a winner
- Points traded per game (both sides' losses): 1288
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: base-s2-882d875-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +28.1 | 0.0 | 24.1 | 0.1 | +4.7 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.1 | +4.6 | 0.0 | 9.4 | 0.0 | +0.9 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.7 | +124.5 | 0.0 | 256.3 | 21.6 | +261.1 | 0.0 | 181.5 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 26.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.1 | 0.0 | 10.2 | 0.2 | +1.2 | 0.0 | 10.3 |
| BEST PRIZE | 0.1 | -1.0 | 7.1 | 0.0 | 0.2 | -12.0 | 10.5 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -23.0 | 28.5 | 28.4 | 0.2 | -63.8 | 25.2 | 0.0 |
| BOMBING RUN | 0.1 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | 0.0 | +0.0 | 0.0 | 4.2 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 37.2 | 7.6 | 0.0 | +0.0 | 10.6 | 0.0 |
| CANNON PLANNED TARGET | 4.7 | +103.5 | 253.0 | 67.5 | 0.5 | +26.1 | 27.9 | 3.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | -1.7 | 2.5 | 0.0 |
| CAST JOB | 1.3 | +31.2 | 41.2 | 30.0 | 0.5 | +5.6 | 26.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +48.4 | 34.3 | 0.0 | 0.0 | +0.1 | 2.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 30.4 | 0.6 | +0.0 | 0.0 | 48.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +28.2 | 0.0 | 8.3 | 2.2 | +111.4 | 0.0 | 44.2 |
| CHAFF PASSED | 0.2 | -0.0 | 0.0 | 0.0 | 0.2 | -0.6 | 0.0 | 1.6 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -1.6 | 13.4 | 0.0 | 0.2 | -4.7 | 16.0 | 9.9 |
| CHARACTER GUNS | 1.2 | +0.0 | 0.0 | 18.5 | 0.6 | +0.0 | 0.0 | 12.3 |
| CHARGE LIST READ AGAIN | 0.0 | +3.9 | 3.0 | 0.0 | 0.1 | +3.0 | 0.9 | 0.0 |
| CHARGE LOSSES | 9.4 | -496.4 | 0.0 | 328.6 | 10.1 | -644.4 | 0.0 | 323.1 |
| CHARGE NOT DECLARED | 0.0 | +0.0 | 3.0 | 0.0 | 0.1 | +0.0 | 9.2 | 9.7 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 229.4 | 92.8 | 2.0 | +0.0 | 263.6 | 48.4 |
| CHARGER SLAIN LOST | 0.2 | -9.4 | 4.0 | 18.5 | 0.6 | -9.1 | 52.9 | 16.8 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 4.9 | 46.7 | 0.3 | +0.0 | 11.8 | 17.6 |
| CONVEYANCE SEARCH | 0.9 | +194.8 | 13.8 | 29.7 | 0.7 | +80.8 | 26.1 | 26.1 |
| COVER ONCE | 6.6 | -344.7 | 0.0 | 168.6 | 4.9 | -329.0 | 0.0 | 100.5 |
| DEFENSIVE FLOOR | 0.0 | +1.2 | 0.0 | 0.0 | 0.0 | +0.6 | 3.8 | 0.0 |
| DENIED BY THE FIGHT | 0.5 | -2.2 | 34.4 | 51.4 | 1.0 | -8.5 | 153.8 | 35.4 |
| DEPLOY BY FIGURES | 8.1 | +14.9 | 0.0 | 7.2 | 7.9 | +61.0 | 0.0 | 28.4 |
| EDGE GIVE GROUND | 0.1 | +10.9 | 21.7 | 5.4 | 0.2 | +10.6 | 38.1 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.0 | +3.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.1 | +2.0 | 199.3 | 143.1 | 2.8 | +7.9 | 332.6 | 53.3 |
| FALLBACK BY WORTH | 0.3 | +0.9 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 1.7 |
| FALLS SHORT | 4.2 | +56.6 | 0.0 | 117.0 | 15.2 | +207.1 | 0.0 | 202.8 |
| FEATURE BUFFS | 2.1 | +66.5 | 0.0 | 44.0 | 1.7 | +35.3 | 0.0 | 24.4 |
| FIGHT TO THE END | 0.5 | +15.1 | 62.6 | 15.9 | 0.9 | +18.6 | 133.2 | 24.0 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.9 | 0.0 | 5.9 |
| FIRE IN ORDER | 0.4 | +0.0 | 18.0 | 1.9 | 0.1 | +0.0 | 11.8 | 8.2 |
| FIVE ACTION | 93.2 | +5480.8 | 1565.1 | 1439.9 | 82.5 | +4803.3 | 738.8 | 964.4 |
| FLANK NOT WEIGHED | 4.6 | +0.0 | 0.0 | 169.3 | 4.5 | +0.0 | 0.0 | 118.6 |
| FOLLOW UP WEIGHED | 0.6 | +123.4 | 0.0 | 37.4 | 0.9 | +135.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +187.5 | 284.2 | 155.9 | 3.9 | +313.8 | 445.5 | 76.1 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -5.3 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -9.3 | 2.5 | 18.1 | 0.2 | -5.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +4.9 | 0.0 | 13.6 | 0.0 | +4.1 | 0.0 | 0.0 |
| GIVES UP | 0.4 | -5.7 | 37.5 | 19.3 | 0.4 | -7.4 | 70.1 | 13.9 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.1 | +2.7 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| GUN FIGURES | 1.2 | +23.9 | 73.2 | 5.6 | 0.4 | +4.7 | 4.6 | 1.8 |
| GUN MASK | 0.8 | +7.6 | 0.0 | 21.1 | - | - | - | - |
| HARD STAY DROPPED | 2.5 | +0.0 | 0.0 | 22.0 | 1.2 | +0.0 | 0.0 | 5.1 |
| HE SHOOTS OR CHARGES | 2.6 | +0.0 | 0.0 | 58.5 | 3.5 | +0.0 | 0.0 | 176.2 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 10.8 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +14.8 | 21.2 | 27.3 | 0.6 | +25.3 | 94.4 | 6.7 |
| HIS CHARGE LIST | 3.9 | +0.0 | 0.0 | 78.8 | 5.9 | +0.0 | 0.0 | 147.9 |
| HIS FIGHT TOGETHER | 2.1 | -61.4 | 0.0 | 101.4 | 1.6 | -45.0 | 0.0 | 148.4 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 103.4 | 4.4 | +0.0 | 0.0 | 63.3 |
| HIS MOVE AND SHOT | 2.5 | -31.4 | 0.0 | 106.1 | 4.0 | -93.4 | 0.0 | 100.4 |
| HIS MOVE AS HE DECIDES | 40.1 | +13.1 | 704.5 | 0.0 | 35.9 | +14.0 | 639.1 | 0.0 |
| HIS MOVE WHY | 34.4 | +0.0 | 0.0 | 539.9 | 40.6 | +0.0 | 0.0 | 503.5 |
| HIS ONE MOVE | 18.0 | +20.9 | 1.2 | 172.1 | 18.5 | +1.1 | 2.4 | 94.9 |
| HIS ONE QUARTER | 3.8 | +0.0 | 0.0 | 29.6 | 2.8 | +0.0 | 0.0 | 36.2 |
| HIS OWN BEST MOVE | 1.6 | +0.0 | 0.0 | 43.2 | 2.1 | +0.0 | 0.0 | 45.6 |
| HIS RANDOM MOVE | 5.6 | +0.0 | 0.0 | 102.2 | 5.7 | +0.0 | 0.0 | 83.5 |
| HIS SHOT LIST | 32.6 | +774.0 | 0.0 | 499.7 | 46.3 | +1984.3 | 0.0 | 622.6 |
| HIS TURN DENIED | 1.1 | +23.7 | 75.4 | 42.8 | 1.9 | +78.6 | 223.4 | 49.8 |
| HOLD ODDS | 16.4 | +0.0 | 0.0 | 196.2 | 16.2 | +0.0 | 0.0 | 131.0 |
| HOLDER ASSIGNMENT | 10.1 | +898.0 | 0.0 | 83.8 | 9.4 | +888.7 | 0.0 | 67.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.6 | -107.1 | 254.6 | 124.0 | 3.2 | -161.5 | 391.1 | 53.8 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 4.6 | 0.0 |
| HUNT IN PAIRS | 0.2 | +4.1 | 0.0 | 25.0 | 0.2 | +8.1 | 0.0 | 10.0 |
| HUNT RESULT | - | - | - | - | 0.0 | +0.0 | 4.6 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.0 | +9.2 | 0.0 | 0.0 |
| IDLE COST | 2.7 | -34.3 | 0.0 | 41.1 | 12.6 | -203.8 | 0.0 | 173.0 |
| JOINT CHARGE NOW | 0.5 | +69.4 | 54.0 | 16.8 | 0.7 | +24.5 | 80.7 | 17.9 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -4.1 | 12.3 | 5.7 |
| JOINT LOOK BACK | - | - | - | - | 0.0 | +2.6 | 2.7 | 0.0 |
| JOINT ON THE TABLE | 0.1 | +1.0 | 5.9 | 0.0 | 0.1 | -1.2 | 0.9 | 4.5 |
| KEEP FALLS | 0.1 | +2.7 | 0.0 | 6.1 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 20.7 | 3.0 | +0.0 | 0.0 | 17.6 |
| LANE BY FIGURES | 0.9 | +34.3 | 0.0 | 0.0 | 1.1 | +62.0 | 0.0 | 33.3 |
| LATE ONLY FROM HERE | 0.2 | +0.0 | 0.0 | 3.3 | 0.4 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.5 | +0.0 | 274.6 | 319.1 | 6.0 | +0.0 | 271.8 | 131.7 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.3 | 0.0 | 2.5 | 0.1 | +0.0 | 0.0 | 3.2 |
| LONE WIZARD KEPT IN | 0.6 | +22.8 | 0.0 | 0.0 | 0.2 | +18.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +1.7 | 3.0 | 3.6 | 0.3 | +1.4 | 29.5 | 0.0 |
| LOST AFTER ESCAPE | 1.8 | -0.3 | 181.4 | 101.6 | 2.1 | -1.9 | 252.4 | 56.4 |
| LOST CHARGE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.2 | -10.1 | 0.0 | 0.0 | 0.3 | -27.4 | 0.0 | 7.2 |
| MAKE SURE TOGETHER | 0.1 | +0.3 | 0.0 | 10.6 | 0.1 | +0.4 | 0.0 | 0.0 |
| MANOEUVRE | 0.9 | +8.3 | 0.0 | 13.9 | 0.5 | +0.3 | 0.0 | 1.1 |
| MARCH AT ESCAPER | 0.1 | +0.2 | 0.0 | 4.6 | 0.2 | +0.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +15.7 | 0.0 | 22.6 | 0.2 | +9.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +21.6 | 0.0 | 21.2 | 0.3 | +17.3 | 0.0 | 4.0 |
| MARCH OF THE TABLE | 0.1 | +2.1 | 0.0 | 16.7 | 0.1 | +2.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +45.7 | 0.0 | 15.2 | 0.5 | +33.6 | 0.0 | 4.4 |
| MARCH WHEELS ONLY | 1.2 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 11.4 |
| MAX FOR POSITIONING | 3.2 | +63.3 | 0.0 | 90.4 | 2.2 | +45.3 | 0.0 | 44.7 |
| MISSILES IN THE MOVE | 3.8 | +132.9 | 0.0 | 136.5 | 2.0 | +34.3 | 0.0 | 46.6 |
| MISSILES NEXT TURN | 5.3 | +92.3 | 0.0 | 173.9 | 2.8 | +28.2 | 0.0 | 47.3 |
| MISSILES ON ONE TARGET | 0.3 | -14.5 | 0.0 | 8.9 | 0.0 | -0.9 | 0.0 | 0.0 |
| MODEL FACING | 0.2 | +58.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.4 | +0.0 | 16.9 | 25.2 | 2.3 | +0.0 | 22.1 | 15.9 |
| MOVE SPELL IN RANGE | 0.4 | +10.2 | 0.0 | 4.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -55.9 | 9.9 | 13.6 | - | - | - | - |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 26.1 |
| MOVE TO CHARGE COMPUTED | 5.9 | +464.6 | 0.0 | 115.1 | 6.9 | +755.8 | 0.0 | 39.1 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.7 | +333.0 | 0.0 | 100.6 | 6.1 | +238.2 | 0.0 | 74.3 |
| NEXT CHARGE BY LIST | 4.9 | -133.0 | 34.2 | 54.2 | 7.5 | -363.9 | 15.1 | 124.7 |
| NEXT OBJECTIVE NEARER | 0.1 | -5.6 | 0.0 | 2.3 | 0.1 | -0.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.2 | -88.1 | 230.8 | 108.9 | 2.9 | -155.1 | 329.2 | 64.7 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 6.1 |
| NO RALLY LEFT | 0.0 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 3.8 | 0.5 | +0.0 | 0.0 | 20.2 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 33.2 | 0.6 | -0.3 | 0.0 | 21.7 |
| OFF BEST | 3.5 | -124.1 | 9.2 | 92.0 | 4.3 | -198.4 | 15.5 | 47.7 |
| ONE CHARGE A CHARGER | 3.4 | +0.0 | 0.0 | 158.8 | 4.2 | +0.0 | 0.0 | 82.9 |
| ONE FIGHT FORMULA | 4.3 | -75.7 | 0.0 | 81.1 | 4.7 | -125.7 | 0.0 | 59.2 |
| ONE OBJECTIVE FORMULA | 4.8 | +5.6 | 0.0 | 71.1 | 3.7 | -21.2 | 0.0 | 40.6 |
| ONE PROMISE A TARGET | 0.1 | -2.9 | 0.0 | 0.0 | 0.1 | -6.0 | 0.0 | 0.0 |
| ONE ROUTE | 1.2 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 11.4 |
| ONE TARGET A SHOOTER | 21.7 | +368.9 | 0.0 | 363.1 | 32.8 | +966.8 | 0.0 | 369.2 |
| OPENS A LANE | 0.1 | +0.2 | 6.4 | 2.6 | 0.2 | +1.0 | 0.0 | 6.3 |
| OPENS UP | 0.7 | +43.3 | 45.3 | 60.8 | 0.2 | +13.8 | 10.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +56.6 | 36.8 | 31.2 | 0.6 | +50.2 | 52.6 | 11.4 |
| OWN CAST FIRST | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.4 | +19.9 | 0.0 | 3.8 | 0.3 | +7.5 | 0.0 | 1.5 |
| PERIAPT WORTH | 0.1 | +4.3 | 0.0 | 15.0 | 0.1 | +7.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -6.7 | 0.0 | 6.1 | 0.1 | -4.7 | 0.0 | 27.2 |
| PLAN RESULT | 43.4 | +686.2 | 467.9 | 1025.2 | 40.8 | +546.1 | 408.7 | 852.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 12.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.5 | -239.3 | 0.0 | 74.6 | 8.1 | -284.4 | 0.0 | 12.8 |
| PROMISE IN STEPS | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.5 | -0.6 | 0.0 | 0.0 | 0.5 | -0.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -5.1 | 0.0 | 15.6 | 0.1 | -7.6 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.2 | -1.7 | 14.6 | 0.0 | 0.1 | -3.5 | 7.8 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -3.7 | 0.0 | 0.0 |
| QUARTER ODDS | 15.7 | +1618.3 | 429.1 | 164.0 | 13.9 | +1580.3 | 205.4 | 153.8 |
| RANDOM MOVE BY FIGURES | 1.2 | +36.8 | 0.0 | 36.1 | 1.8 | +31.1 | 0.0 | 63.5 |
| REAL GROUND | 1.2 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 11.4 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +9.9 | 0.0 | 14.8 | 2.3 | -59.1 | 0.0 | 59.0 |
| REDIRECT COUNTER | 1.8 | +101.0 | 0.0 | 27.9 | 3.1 | +155.9 | 0.0 | 77.4 |
| REDIRECT WEIGHED | 0.1 | +3.6 | 9.2 | 0.0 | 0.3 | -5.9 | 12.5 | 9.5 |
| REFORMS TO MEET IT | 1.2 | -23.3 | 0.0 | 67.4 | 1.2 | -80.7 | 0.0 | 9.7 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 34.9 | 0.5 | +0.0 | 0.0 | 42.9 |
| RESERVE FALL BACK | 0.6 | +11.7 | 0.0 | 5.9 | 0.4 | +26.3 | 0.0 | 8.6 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | -6.7 | 189.2 | 132.8 | 2.5 | -19.4 | 325.7 | 31.5 |
| RISK BY HIS FIGURE | 21.1 | -408.1 | 0.0 | 629.9 | 21.3 | -419.6 | 0.0 | 542.9 |
| RISK ON THE WAY | 0.6 | +0.0 | 0.0 | 2.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -12.2 | 54.9 | 50.6 | 1.4 | -32.9 | 152.9 | 27.5 |
| RUN DOWN | 2.1 | -19.2 | 189.6 | 87.3 | 2.8 | -31.9 | 259.7 | 72.9 |
| SAFER THAN THE JOB | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -2.3 | 2.2 | 0.0 |
| SCOUT SPOT | 0.4 | +0.4 | 0.0 | 0.9 | 0.1 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.4 | -29.5 | 0.0 | 1.9 | 0.8 | -63.1 | 0.0 | 12.1 |
| SEARCH SPOT | 0.5 | +14.8 | 0.0 | 3.7 | 0.2 | +0.3 | 0.0 | 3.3 |
| SECOND LOOK | 0.3 | +16.7 | 24.2 | 12.1 | 0.3 | +23.5 | 35.2 | 4.5 |
| SELF MOVE SPELL | 0.2 | +5.7 | 0.0 | 0.0 | 0.6 | +19.8 | 0.0 | 40.1 |
| SET UP BY THE SET | 1.6 | +12.6 | 2.5 | 15.9 | 1.8 | +16.9 | 7.6 | 23.9 |
| SET UP TOGETHER | 0.2 | +2.1 | 0.0 | 10.6 | 0.1 | +0.6 | 0.0 | 5.2 |
| SET-UP ANY TARGET | 0.2 | +18.2 | 0.0 | 0.0 | 0.1 | +3.4 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.6 | +198.5 | 286.2 | 52.9 | 1.6 | +61.3 | 35.9 | 13.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -5.8 | 16.5 | 12.0 | 0.1 | -2.8 | 15.2 | 0.0 |
| SHOT RISK POINTS | 13.5 | +5.6 | 0.0 | 263.9 | 23.1 | -32.4 | 0.0 | 406.2 |
| SHOTS AFTER THE MOVES | 3.6 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.5 | +662.3 | 0.0 | 232.7 | 9.2 | +273.0 | 0.0 | 95.9 |
| SPELL SETS UP CHARGE | 0.2 | +18.2 | 0.0 | 0.0 | 0.1 | +3.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +16.5 | 75.3 | 69.8 | 2.3 | +42.3 | 53.5 | 53.5 |
| SPELLS IN THE FIGHT | 0.5 | +2.1 | 33.5 | 36.2 | 0.4 | -2.6 | 49.0 | 9.9 |
| SPOT AS THE GAME MOVES | 6.6 | +0.0 | 0.0 | 195.6 | 10.3 | +0.0 | 0.0 | 247.4 |
| STAND AND SHOOT | 0.5 | -6.4 | 29.3 | 6.9 | 0.6 | -6.6 | 62.9 | 23.6 |
| STANDS FOR A REASON | 0.6 | +0.0 | 5.8 | 57.3 | 1.6 | +0.0 | 2.0 | 33.3 |
| STANDS STILL | 48.8 | +0.0 | 1280.9 | 574.4 | 25.7 | +0.0 | 293.2 | 121.2 |
| STAY WORTH | 25.1 | -114.3 | 526.2 | 281.9 | 10.3 | +104.9 | 172.6 | 68.4 |
| STOPS | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 8.1 | 0.2 | +0.0 | 0.0 | 12.1 |
| STUPIDITY NEXT TURN | 0.1 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.2 | +607.1 | 0.0 | 99.9 | 8.1 | +502.8 | 0.0 | 54.1 |
| SUPPORT NARROWED | 0.4 | +0.0 | 54.0 | 12.3 | 0.4 | +0.0 | 66.1 | 5.9 |
| SUPPORT WORKED OUT | 8.2 | +607.1 | 0.0 | 99.9 | 8.1 | +502.8 | 0.0 | 54.1 |
| SURE REACH TOGETHER | 0.4 | +3.4 | 0.0 | 2.2 | 0.4 | +2.6 | 0.0 | 7.6 |
| THE DEARER SUM KEEPS ITS PLAN | 1.6 | +0.0 | 0.0 | 33.7 | 0.9 | +0.0 | 0.0 | 4.5 |
| THE PROMISE ADDS | 0.2 | -14.5 | 0.0 | 0.0 | 0.1 | -10.8 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.7 | +0.0 | 0.0 | 433.8 | 34.7 | +0.0 | 0.0 | 377.6 |
| TIED UP BY THE SUM | 0.9 | +100.7 | 72.8 | 64.4 | 0.8 | +111.7 | 81.6 | 11.0 |
| TIME ON OUR SIDE | 40.0 | +423.9 | 9.7 | 445.2 | 14.2 | +106.2 | 8.1 | 52.1 |
| WAITS AGAIN | 1.5 | +0.0 | 0.0 | 25.3 | 1.8 | +0.0 | 0.0 | 30.7 |
| WALKS ON ITS ROUTE | 0.1 | +1.6 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.0 | +2.1 | 13.4 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 58.0 | 22.4 | 0.0 | +0.0 | 0.0 | 4.0 |
| WHAT THE JOINER ADDS | 0.1 | -9.3 | 39.4 | 0.0 | 0.3 | +9.3 | 43.9 | 3.3 |
| WHO GETS IN | 0.1 | +47.2 | 0.0 | 3.9 | 0.1 | +10.3 | 6.2 | 0.0 |
| WHO HITS BACK | 0.2 | +55.5 | 0.0 | 9.4 | 0.3 | +37.4 | 0.0 | 17.4 |
| WHOLE FIGHT | 0.1 | +4.2 | 19.7 | 0.0 | 0.1 | +3.5 | 21.9 | 1.7 |
| WHOLE FIGHT GAIN | 0.1 | +4.3 | 3.0 | 0.0 | 0.2 | +12.3 | 15.3 | 17.9 |
| WIDER SPREAD | 1.9 | -7.1 | 189.6 | 120.9 | 2.6 | -11.5 | 301.3 | 38.9 |
| WOUNDS ON THE RANKS | 1.7 | +46.1 | 0.0 | 69.9 | 1.5 | +193.0 | 0.0 | 38.8 |

### Rule changes: base-s2-882d875-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2734 | 2734 | 1760 | 48.89 | +0 | +0.0 |
| HIS MOVE WHY | 2700 | 2700 | 1552 | 43.11 | +0 | +0.0 |
| ARMY TABLE | 1377 | 1377 | 965 | 26.81 | +14885 | +15.4 |
| HIS SHOT LIST | 2840 | 2725 | 654 | 18.17 | +13356 | +20.4 |
| HOLDER ASSIGNMENT | 701 | 701 | 644 | 17.89 | +40704 | +63.2 |
| LEGAL CHARGES ONLY | 413 | 413 | 413 | 11.47 | +0 | +0.0 |
| ONE TARGET A SHOOTER | 1962 | 1883 | 398 | 11.06 | +4711 | +11.8 |
| DEPLOY BY FIGURES | 575 | 575 | 363 | 10.08 | +4324 | +11.9 |
| TIME ON OUR SIDE | 1952 | 1752 | 301 | 8.36 | +1133 | +3.8 |
| OFF BEST | 279 | 279 | 279 | 7.75 | -11611 | -41.6 |
| HIS ONE MOVE | 1314 | 1276 | 274 | 7.61 | +0 | +0.0 |
| THE TABLE AGAIN | 432 | 432 | 273 | 7.58 | +0 | +0.0 |
| FIVE ACTION | 6326 | 6110 | 248 | 6.89 | +10832 | +43.7 |
| MOVE TO CHARGE COMPUTED | 461 | 402 | 214 | 5.94 | +9253 | +43.2 |
| SUPPORT ADDS | 588 | 571 | 208 | 5.78 | +9062 | +43.6 |
| SUPPORT WORKED OUT | 588 | 571 | 208 | 5.78 | +9062 | +43.6 |
| PROMISE BY ITS OWN SUM | 560 | 560 | 206 | 5.72 | -18853 | -91.5 |
| SHOT RISK POINTS | 1319 | 1267 | 175 | 4.86 | +5224 | +29.9 |
| HARD STAY DROPPED | 136 | 136 | 136 | 3.78 | +0 | +0.0 |
| MOVE ORDER | 132 | 132 | 132 | 3.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 185 | 185 | 122 | 3.39 | +2362 | +19.4 |
| FOUR ROUNDS | 249 | 232 | 114 | 3.17 | +5135 | +45.0 |
| QUARTER ODDS | 1066 | 1010 | 110 | 3.06 | +10300 | +93.6 |
| CHAFF IN THE MOVE | 104 | 103 | 95 | 2.64 | +16 | +0.2 |
| ADVANCE LANE KEPT | 80 | 80 | 80 | 2.22 | +0 | +0.0 |
| IDLE COST | 551 | 442 | 78 | 2.17 | +721 | +9.2 |
| LANE BY FIGURES | 70 | 70 | 70 | 1.94 | +3467 | +49.5 |
| RANDOM MOVE BY FIGURES | 109 | 109 | 67 | 1.86 | +2445 | +36.5 |
| RISK BY HIS FIGURE | 1527 | 1457 | 60 | 1.67 | +5514 | +91.9 |
| MAX FOR POSITIONING | 198 | 176 | 57 | 1.58 | +244 | +4.3 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| CHARGE LOSSES | 701 | 664 | 54 | 1.50 | +5018 | +92.9 |
| FOLLOW UP WEIGHED | 54 | 54 | 54 | 1.50 | +9335 | +172.9 |
| TIED UP BY THE SUM | 62 | 57 | 52 | 1.44 | +1343 | +25.8 |
| RISK BY ARC | 163 | 152 | 49 | 1.36 | +1278 | +26.1 |
| SHOTS IN THE MOVE | 924 | 730 | 49 | 1.36 | +1662 | +33.9 |
| COVER ONCE | 412 | 286 | 48 | 1.33 | +1220 | +25.4 |
| SET UP BY THE SET | 120 | 119 | 47 | 1.31 | +2667 | +56.8 |
| CAST JOB | 67 | 67 | 45 | 1.25 | +266 | +5.9 |
| JOINT CHARGE NOW | 45 | 45 | 45 | 1.25 | +3379 | +75.1 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| CHARGE NOW FIRST | 141 | 141 | 39 | 1.08 | -1854 | -47.5 |
| STAY WORTH | 1274 | 1157 | 38 | 1.06 | +479 | +12.6 |
| RESERVE FALL BACK | 36 | 36 | 36 | 1.00 | +1368 | +38.0 |
| FALLS SHORT | 698 | 604 | 35 | 0.97 | +71 | +2.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 446 | 413 | 31 | 0.86 | +882 | +28.5 |
| NEARER NOT NEEDED | 495 | 480 | 29 | 0.81 | +1059 | +36.5 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1489 | +53.2 |
| MISSILES IN THE MOVE | 207 | 135 | 27 | 0.75 | +710 | +26.3 |
| REDIRECT COUNTER | 174 | 141 | 26 | 0.72 | +1517 | +58.4 |
| PATHS CROSS | 25 | 25 | 25 | 0.69 | +987 | +39.5 |
| SHOTS AFTER THE MOVES | 176 | 176 | 24 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 106 | 101 | 23 | 0.64 | +775 | +33.7 |
| COMBAT PIVOT | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| SECOND LOOK | 21 | 21 | 21 | 0.58 | +1447 | +68.9 |
| WOUNDS ON THE RANKS | 114 | 111 | 21 | 0.58 | +2111 | +100.5 |
| FIRE IN ORDER | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| OPENS UP | 33 | 30 | 20 | 0.56 | +393 | +19.7 |
| MARCH CHECK | 26 | 25 | 19 | 0.53 | +430 | +22.6 |
| SHOOTERS IN TWO RANKS | 19 | 19 | 19 | 0.53 | +46 | +2.4 |
| HIS MOVE AND SHOT | 233 | 227 | 18 | 0.50 | +373 | +20.7 |
| MARCH BY THE SUM | 18 | 18 | 18 | 0.50 | +903 | +50.2 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +2527 | +140.4 |
| CANNON PLANNED TARGET | 187 | 187 | 17 | 0.47 | -234 | -13.7 |
| OVERRUNS AWAY | 37 | 37 | 17 | 0.47 | +965 | +56.7 |
| SEARCH SPOT | 24 | 24 | 16 | 0.44 | +542 | +33.9 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -23 | -1.5 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.42 | +1210 | +80.7 |
| CASTING BLOCK | 14 | 14 | 14 | 0.39 | +924 | +66.0 |
| HIS CHARGE DENIED | 31 | 31 | 14 | 0.39 | +516 | +36.9 |
| SUPPORT NARROWED | 32 | 32 | 14 | 0.39 | -946 | -67.6 |
| ONE OBJECTIVE FORMULA | 303 | 235 | 13 | 0.36 | +664 | +51.0 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| REFUSING RETIRES | 34 | 34 | 12 | 0.33 | -4 | -0.4 |
| SURE REACH TOGETHER | 26 | 25 | 12 | 0.33 | +38 | +3.2 |
| PROMISE SHOT AWAY | 11 | 11 | 11 | 0.31 | -186 | -16.9 |
| MANOEUVRE | 50 | 50 | 10 | 0.28 | +469 | +46.9 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -411 | -41.1 |
| BEST PRIZE | 9 | 9 | 9 | 0.25 | -466 | -51.7 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| HONEST WORTH | 210 | 197 | 9 | 0.25 | +431 | +47.8 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +2098 | +233.1 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| AFTERMATH IN POINTS | 8 | 8 | 8 | 0.22 | +1180 | +147.6 |
| FEATURE BUFFS | 134 | 134 | 8 | 0.22 | +114 | +14.2 |
| MARCH OF THE TABLE | 8 | 8 | 8 | 0.22 | -155 | -19.4 |
| FRIENDS SHOTS CHECKED | 7 | 7 | 7 | 0.19 | +325 | +46.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| ONE PROMISE A TARGET | 7 | 7 | 7 | 0.19 | -320 | -45.8 |
| WHO GETS IN | 7 | 7 | 7 | 0.19 | +2071 | +295.8 |
| HIS FIGHT TOGETHER | 132 | 128 | 6 | 0.17 | +237 | +39.5 |
| NO DOUBLE ROUNDS | 185 | 174 | 6 | 0.17 | +66 | +11.0 |
| PROMISE READS THE TABLE | 14 | 14 | 6 | 0.17 | -139 | -23.1 |
| WHOLE FIGHT GAIN | 9 | 8 | 6 | 0.17 | +124 | +20.7 |
| GUN MASK | 29 | 29 | 5 | 0.14 | +14 | +2.8 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +193 | +38.6 |
| MISSILES NEXT TURN | 289 | 201 | 5 | 0.14 | +11 | +2.2 |
| ONE FIGHT FORMULA | 324 | 162 | 5 | 0.14 | +18 | +3.6 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +435 | +87.1 |
| CHARGE NOT DECLARED | 4 | 4 | 4 | 0.11 | -405 | -101.2 |
| HUNT IN PAIRS | 13 | 8 | 4 | 0.11 | +28 | +7.0 |
| JOINT ON THE TABLE | 4 | 4 | 4 | 0.11 | -5 | -1.2 |
| PROMISE KNOWS THE FIGHT | 35 | 28 | 4 | 0.11 | -28 | -6.9 |
| WALKS ON ITS ROUTE | 4 | 4 | 4 | 0.11 | +97 | +24.1 |
| WHAT THE JOINER ADDS | 14 | 10 | 4 | 0.11 | +201 | +50.3 |
| AFTERMATH WITH FRIENDS | 3 | 3 | 3 | 0.08 | +197 | +65.7 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +104 | +34.6 |
| CHARGE LIST READ AGAIN | 3 | 3 | 3 | 0.08 | +251 | +83.6 |
| EDGE GIVE GROUND | 13 | 12 | 3 | 0.08 | +314 | +104.7 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +42 | +13.9 |
| FIGHT TO THE END | 50 | 49 | 3 | 0.08 | +100 | +33.3 |
| LONG SHOT | 21 | 21 | 3 | 0.08 | +21 | +6.8 |
| REDIRECT BY WHAT IT STOPS | 108 | 108 | 3 | 0.08 | +24 | +7.9 |
| ROUNDS AFTER TERROR | 78 | 75 | 3 | 0.08 | +14 | +4.6 |
| SPELLS IN THE FIGHT | 33 | 32 | 3 | 0.08 | +27 | +9.1 |
| WHOLE FIGHT | 7 | 5 | 3 | 0.08 | +89 | +29.8 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| FALL BACK GOOD ORDER | 177 | 166 | 2 | 0.06 | +37 | +18.5 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +31 | +15.3 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LOST AFTER ESCAPE | 140 | 133 | 2 | 0.06 | +3 | +1.7 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.06 | -2 | -0.8 |
| RUN DOWN | 174 | 166 | 2 | 0.06 | +12 | +6.2 |
| SAFER THAN THE JOB | 2 | 2 | 2 | 0.06 | +18 | +9.2 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.03 | -62 | -62.1 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -75 | -75.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.03 | +108 | +107.6 |
| FALLBACK BY WORTH | 23 | 23 | 1 | 0.03 | +32 | +31.8 |
| FRIEND SHOOTS FIRST | 33 | 31 | 1 | 0.03 | +36 | +36.2 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.03 | +92 | +92.0 |
| MOVE SPELL IN RANGE | 14 | 9 | 1 | 0.03 | +0 | +0.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +57 | +56.7 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -133 | -133.4 |
| REFORMS TO MEET IT | 85 | 73 | 1 | 0.03 | +0 | +0.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.03 | +23 | +23.1 |
| WAR ENGINE JOBS | 23 | 23 | 1 | 0.03 | -55 | -54.9 |
| WIDER SPREAD | 164 | 151 | 1 | 0.03 | +10 | +9.8 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| BACKUP TARGETS | 10 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 17 | 17 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 12 | 12 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 8 | 8 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 63 | 61 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 29 | 28 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 56 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 54 | 53 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 326 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 29 | 25 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| GUN FIGURES | 59 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 221 | 219 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 353 | 347 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 327 | 305 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 235 | 215 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 132 | 132 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 406 | 388 | 0 | 0.00 | - | - |
| HOLD ODDS | 1172 | 1165 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 216 | 210 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 20 | 20 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 6 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 17 | 17 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 43 | 43 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 77 | 71 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 11 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 28 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 7 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 53 | 49 | 0 | 0.00 | - | - |
| NOT TURNED | 25 | 25 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 36 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 273 | 263 | 0 | 0.00 | - | - |
| ONE ROUTE | 77 | 71 | 0 | 0.00 | - | - |
| OPENS A LANE | 11 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 3032 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 18 | 18 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 77 | 71 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 25 | 24 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 43 | 43 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 28 | not checked | - | - | - | - |
| SET UP TOGETHER | 13 | 9 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 14 | 14 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 127 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 606 | 581 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 39 | 37 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 76 | 71 | 0 | 0.00 | - | - |
| STANDS STILL | 2682 | 2600 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 29 | 25 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 91 | not checked | - | - | - | - |
| THE PROMISE ADDS | 9 | 9 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2354 | not checked | - | - | - | - |
| WAITS AGAIN | 119 | 109 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: base-s2-882d875-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.39 | 3.42 | 41.6 |
| PROMISE BY ITS OWN SUM | rule | 3.03 | 2.69 | 91.5 |
| ARMY TABLE | rule | 1.92 | 1.89 | 65.6 |
| NO REASON | gate | 0.83 | 0.69 | 41.2 |
| HOLDER ASSIGNMENT | rule | 0.69 | 0.42 | 20.9 |
| CHARGE NOW FIRST | rule | 0.78 | 0.31 | 47.5 |
| JOINT CHARGE NOW | rule | 0.22 | 0.19 | 66.2 |
| SUPPORT NARROWED | rule | 0.19 | 0.19 | 67.6 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.14 | 41.1 |
| BEST PRIZE | rule | 0.08 | 0.17 | 51.7 |
| MARCH OF THE TABLE | rule | 0.11 | 0.11 | 19.4 |
| DEPLOY BY FIGURES | rule | 0.06 | 0.14 | 11.3 |
| ONE PROMISE A TARGET | rule | 0.06 | 0.11 | 54.6 |
| CANNON PLANNED TARGET | rule | 0.14 | - | 62.3 |
| CHAFF PASSED | rule | - | 0.14 | 4.2 |
| FIGHT ORDER BAND | gate | 0.11 | 0.03 | 2.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.08 | 114.3 |
| CHARGE NOT DECLARED | rule | 0.03 | 0.08 | 101.2 |
| PROMISE KNOWS THE FIGHT | rule | 0.03 | 0.08 | 6.9 |
| PROMISE READS THE TABLE | rule | 0.08 | 0.03 | 37.6 |
| PROMISE SHOT AWAY | rule | 0.08 | 0.03 | 46.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.06 | 40.9 |
| REFUSING RETIRES | rule | 0.06 | 0.03 | 0.8 |
| AFTERMATH BAND | gate | 0.06 | - | 4.5 |
| OWN CAST FIRST | rule | 0.06 | - | 0.8 |
| REDIRECT WEIGHED | rule | - | 0.06 | 39.0 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 62.1 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 75.0 |
| FALLBACK | gate | 0.03 | - | 59.4 |
| JOINT ON THE TABLE | rule | - | 0.03 | 63.7 |
| PATHS CROSS | rule | - | 0.03 | 13.1 |
| PURSUES BIG PREY | rule | - | 0.03 | 133.4 |
| WALKS ON ITS ROUTE | rule | 0.03 | - | 6.7 |
| WAR ENGINE JOBS | rule | 0.03 | - | 54.9 |
| WHO GETS IN | rule | - | 0.03 | 178.2 |

### Plans: base-s2-882d875-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.5 | 66% | 396 | 230 | 58% |
| Mine | join | 0.4 | 94% | 10 | 0 | 0% |
| Mine | move | 30.5 | 96% | 1509 | 0 | 0% |
| Mine | shoot | 9.4 | 53% | 581 | 457 | 79% |
| Mine | support | 0.6 | 80% | 21 | 0 | 0% |
| Opponent | charge | 3.2 | 71% | 542 | 414 | 76% |
| Opponent | join | 0.9 | 91% | 39 | 0 | 0% |
| Opponent | move | 32.9 | 94% | 1563 | 0 | 0% |
| Opponent | shoot | 2.3 | 45% | 173 | 132 | 76% |
| Opponent | support | 1.6 | 68% | 5 | 0 | 0% |

### Packages: hunt the guns, base-s2-882d875-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 11 |
| Opponent | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 331 | 0 | 0% | 59 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 68 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 98 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 331 | 0 | 0% | 22 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |

### Battle groups: base-s2-882d875-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 32% | 75% | 20% | 0% | 19% | 0% | 12% | 56% | 12% |
| Opponent | REDIRECT COUNTER | 3.1 | 26% | 72% | 31% | 22% | 5% | 0% | 10% | 85% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s2-882d875-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 66 (4) | 66 | 0 | 62 | 0% | 3.8 | - | - | 0 (1) | 0 (1) | - |
| Mine | Chaff | 31 | 54 (31) | 4 | 51 | 38 | 55% | 2.6 | 79 (10) | 72 (10) | 16 (11) | 72 (23) | 0 (8) |
| Mine | Character | 106 | 37 (106) | 36 | 1 | 37 | 24% | 2.4 | 38 (38) | 33 (38) | 50 (16) | 52 (50) | 25 (42) |
| Mine | Clean-up | 28 | 119 (28) | 66 | 53 | 34 | 50% | 4.0 | 113 (13) | 129 (12) | 115 (3) | 140 (19) | 76 (9) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 50 | 25% | 2.0 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 40 | 23 (40) | 9 | 15 | 39 | 32% | 2.6 | 20 (16) | 25 (19) | 27 (5) | 29 (18) | 19 (22) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 66 | 48 (66) | 35 | 14 | 35 | 23% | 2.5 | 56 (29) | 50 (29) | 18 (8) | 49 (37) | 47 (29) |
| Mine | Holder | 30 | 61 (30) | 3 | 58 | 25 | 33% | 3.5 | 49 (9) | 83 (15) | 72 (2) | 123 (12) | 20 (14) |
| Mine | Shooter | 35 | 82 (35) | 46 | 36 | 35 | 6% | 1.7 | 35 (15) | 136 (15) | 51 (5) | 91 (24) | 59 (11) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | War machine | 56 | 31 (56) | 31 | 0 | 38 | 11% | 1.3 | 44 (26) | 17 (25) | 25 (5) | 45 (12) | 27 (44) |
| Mine | Wizard | 17 | 18 (17) | 18 | 0 | 33 | 24% | 2.8 | 28 (5) | 0 (4) | 29 (7) | 8 (4) | 28 (12) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 72 | 54 (72) | 8 | 46 | 43 | 58% | 2.7 | 40 (30) | 90 (26) | 3 (16) | 59 (55) | 39 (17) |
| Opponent | Character | 96 | 55 (96) | 55 | 0 | 23 | 29% | 2.4 | 44 (31) | 65 (33) | 64 (24) | 59 (49) | 56 (39) |
| Opponent | Clean-up | 14 | 57 (14) | 11 | 47 | 40 | 29% | 3.7 | 51 (4) | 67 (9) | 0 (1) | 66 (11) | 26 (3) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 51 (58) | 38 | 14 | 42 | 45% | 2.6 | 41 (18) | 55 (30) | 55 (10) | 74 (29) | 32 (29) |
| Opponent | Fragile | 11 | 34 (11) | 34 | 0 | 10 | 18% | 3.3 | - | 41 (9) | 0 (2) | 0 (5) | 66 (6) |
| Opponent | Hammer | 65 | 26 (65) | 13 | 13 | 46 | 46% | 3.3 | 19 (24) | 32 (34) | 13 (7) | 28 (32) | 23 (33) |
| Opponent | Holder | 31 | 65 (31) | 11 | 54 | 32 | 55% | 4.4 | 141 (5) | 58 (13) | 51 (13) | 123 (14) | 13 (17) |
| Opponent | Shooter | 43 | 66 (43) | 21 | 45 | 27 | 7% | 1.7 | 48 (16) | 75 (20) | 93 (7) | 82 (26) | 45 (17) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 6 | 61 (6) | 61 | 0 | 30 | 17% | 1.4 | 62 (2) | 401 (1) | 0 (3) | 100 (4) | 0 (2) |
| Opponent | Wizard | 20 | 16 (20) | 16 | 0 | 31 | 20% | 2.2 | 24 (8) | 0 (6) | 0 (1) | 13 (6) | 13 (9) |

### Charged fights: base-s2-882d875-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 238 | 44 | 0.8 | 1.0 | 59 | 0 | +59 | 0 of 3 | 3 of 3 | - | +59 |
| Mine | Chaos Dwarfs | 4 | 390 | 210 | 2.0 | 1.1 | 105 | 66 | +39 | 3 of 8 | 7 of 8 | +482 | -24 |
| Mine | Dwarfen Mountain Holds | 3 | 500 | 0 | 0.3 | 1.0 | 0 | 60 | -60 | 1 of 1 | 0 of 1 | - | -60 |
| Mine | Empire of Man | 5 | 173 | 0 | 0.6 | 1.0 | 0 | 0 | +0 | 1 of 3 | 3 of 3 | - | +0 |
| Mine | Grand Cathay | 4 | 203 | 446 | 3.2 | 1.0 | 137 | 49 | +88 | 3 of 13 | 10 of 13 | - | +88 |
| Mine | High Elf Realms | 4 | 222 | 397 | 3.0 | 1.0 | 132 | 37 | +96 | 2 of 12 | 11 of 12 | - | +96 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 541 | 5.0 | 1.2 | 108 | 0 | +108 | 1 of 5 | 4 of 5 | +0 | +135 |
| Mine | Lizardmen | 1 | 110 | 0 | 2.0 | 1.5 | 0 | 134 | -134 | 2 of 2 | 0 of 2 | -268 | +0 |
| Mine | Ogre Kingdoms | 2 | 362 | 136 | 2.5 | 1.0 | 54 | 0 | +54 | 0 of 5 | 3 of 5 | - | +54 |
| Mine | Skaven | 2 | 178 | 0 | 1.0 | 1.0 | 0 | 20 | -20 | 2 of 2 | 0 of 2 | - | -20 |
| Mine | Tomb Kings of Khemri | 2 | 138 | 500 | 3.5 | 1.0 | 143 | 0 | +143 | 2 of 7 | 7 of 7 | - | +143 |
| Mine | Vampire Counts | 2 | 28 | 60 | 2.5 | 1.0 | 24 | 100 | -76 | 1 of 5 | 4 of 5 | - | -76 |
| Mine | Warriors of Chaos | 2 | 142 | 217 | 3.5 | 1.1 | 62 | 66 | -4 | 2 of 7 | 6 of 7 | -465 | +72 |
| **Mine** | all armies | 36 | 233 | 188 | 2.0 | 1.1 | 93 | 40 | +52 | 20 of 73 | 58 of 73 | -63 | +59 |
| Opponent | Empire of Man | 1 | 225 | 233 | 1.0 | 2.0 | 233 | 0 | +233 | 1 of 1 | 0 of 1 | +233 | - |
| Opponent | High Elf Realms | 5 | 143 | 572 | 3.4 | 1.1 | 168 | 9 | +159 | 12 of 17 | 13 of 16 | +280 | +152 |
| Opponent | Lizardmen | 2 | 0 | 580 | 4.0 | 1.0 | 145 | 0 | +145 | 2 of 8 | 7 of 8 | - | +145 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 735 | 3.3 | 1.0 | 220 | 51 | +170 | 5 of 10 | 10 of 10 | - | +170 |
| Opponent | Skaven | 4 | 41 | 25 | 0.2 | 1.0 | 100 | 0 | +100 | 0 of 1 | 1 of 1 | - | +100 |
| Opponent | Tomb Kings of Khemri | 2 | 72 | 532 | 2.5 | 1.2 | 213 | 14 | +199 | 2 of 5 | 3 of 5 | +750 | +61 |
| Opponent | Vampire Counts | 6 | 35 | 541 | 3.7 | 1.0 | 148 | 33 | +115 | 12 of 22 | 19 of 22 | - | +115 |
| Opponent | Warriors of Chaos | 7 | 28 | 223 | 2.9 | 1.1 | 78 | 86 | -8 | 10 of 20 | 15 of 20 | +148 | -25 |
| Opponent | Wood Elf Realms | 6 | 66 | 384 | 3.3 | 1.1 | 115 | 25 | +91 | 6 of 20 | 18 of 20 | +136 | +86 |
| **Opponent** | all armies | 36 | 57 | 409 | 2.9 | 1.1 | 142 | 35 | +107 | 50 of 104 | 86 of 103 | +261 | +95 |

### Effective charges: base-s2-882d875-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 1 (net +80) | 1 (net +98) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 8 | 0 | 0 | 1 (net +175) | 1 (net -189) | 2 (net +0) | 1 (net +482) | 3 | 20% (1 of 5) |
| Mine | Dwarfen Mountain Holds | 1 | 1 (net -60) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 3 | 2 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Grand Cathay | 13 | 1 (net +185) | 1 (net +0) | 1 (net +0) | 3 (net +96) | 1 (net +83) | 3 (net +390) | 3 | 10% (1 of 10) |
| Mine | High Elf Realms | 12 | 1 (net -191) | 0 | 3 (net +170) | 1 (net +0) | 4 (net +80) | 1 (net +195) | 2 | 30% (3 of 10) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 0 | 2 (net +20) | 2 (net +250) | 1 | 0% (0 of 4) |
| Mine | Lizardmen | 2 | 1 (net +0) | 0 | 1 (net -268) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 5 | 0 | 1 (net +55) | 1 (net +0) | 0 | 0 | 1 (net +0) | 2 | 33% (1 of 3) |
| Mine | Skaven | 2 | 2 (net -20) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net +0) | 0 | 1 (net +430) | 1 (net +170) | 1 (net +0) | 2 (net +170) | 1 | 17% (1 of 6) |
| Mine | Vampire Counts | 5 | 0 | 0 | 1 (net +75) | 1 (net +0) | 3 (net -152) | 0 | 0 | 20% (1 of 5) |
| Mine | Warriors of Chaos | 7 | 0 | 0 | 1 (net -465) | 1 (net +0) | 2 (net +104) | 0 | 3 | 25% (1 of 4) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +233) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | High Elf Realms | 17 | 3 (net +212) | 1 (net +355) | 5 (net +259) | 2 (net +35) | 0 | 3 (net +118) | 3 | 36% (5 of 14) |
| Opponent | Lizardmen | 8 | 0 | 0 | 2 (net +165) | 2 (net +63) | 0 | 3 (net +213) | 1 | 29% (2 of 7) |
| Opponent | Orc & Goblin Tribes | 10 | 0 | 1 (net +0) | 1 (net -350) | 0 | 1 (net +34) | 1 (net +535) | 6 | 25% (1 of 4) |
| Opponent | Tomb Kings of Khemri | 5 | 1 (net +45) | 0 | 1 (net +750) | 1 (net +0) | 0 | 1 (net +0) | 1 | 25% (1 of 4) |
| Opponent | Vampire Counts | 22 | 2 (net +0) | 2 (net +0) | 2 (net +98) | 2 (net +72) | 5 (net +251) | 6 (net +144) | 3 | 11% (2 of 19) |
| Opponent | Warriors of Chaos | 20 | 4 (net -386) | 0 | 3 (net +132) | 3 (net +69) | 0 | 2 (net +81) | 8 | 25% (3 of 12) |
| Opponent | Wood Elf Realms | 20 | 1 (net -265) | 0 | 5 (net +225) | 2 (net +63) | 3 (net +90) | 6 (net +55) | 3 | 29% (5 of 17) |

### Charged fights, damage counted: base-s2-882d875-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 179 | 254 | -12 | 48 | 92 | -44 | -24.4 |
| Mine | 50-54% | 2 | 134 | 82 | +28 | 55 | 32 | +23 | +17.1 |
| Mine | Effective (55-75%) | 11 | 407 | 195 | +49 | 142 | 98 | +44 | +10.9 |
| Mine | 76-89% | 9 | 304 | 156 | +41 | 103 | 23 | +80 | +26.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 327 | 209 | +224 | 224 | 14 | +210 | +64.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 436 | 79 | +13 | 51 | 33 | +17 | +3.9 |
| Mine | No odds | 15 | 354 | 183 | +6 | 74 | 65 | +9 | +2.4 |
| Mine | All fights | 73 | 341 | 171 | +52 | 104 | 52 | +52 | +15.1 |
| Opponent | Long shot (under 50%) | 11 | 277 | 259 | -102 | 142 | 235 | -93 | -33.6 |
| Opponent | 50-54% | 4 | 350 | 213 | +89 | 117 | 0 | +117 | +33.4 |
| Opponent | Effective (55-75%) | 20 | 426 | 264 | +199 | 224 | 75 | +149 | +35.0 |
| Opponent | 76-89% | 12 | 323 | 196 | +56 | 141 | 38 | +103 | +31.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 286 | 227 | +131 | 150 | 13 | +137 | +48.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 362 | 91 | +173 | 183 | 34 | +149 | +41.2 |
| Opponent | No odds | 26 | 333 | 173 | +107 | 142 | 41 | +101 | +30.3 |
| Opponent | All fights | 104 | 337 | 208 | +107 | 162 | 60 | +102 | +30.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s2-882d875-p4 | move | 237 | 51 (22%) | 36 (15%) | 30 (13%) | 156 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

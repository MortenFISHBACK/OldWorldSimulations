# Doctrine scorecard: base-s1-882d875-p4

### Scorecard: base-s1-882d875-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 317 |
| L0130 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 4 | 0 | 0 | 0 | 70 |
| L0214 | 4 | 1 | Mine | no | 1 | - | 2 | 4 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 85 |
| L0230 | 2 | 1 | Opponent | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 544 |
| L0315 | 3 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 1174 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 1 | 6 | 0 | 0 | 0 | 370 |
| L0417 | 3 | 1 | Mine | yes | 11 | 2 | 3 | 3 | 1 | 0 | 0 | 499 |
| L0417 | 3 | 1 | Opponent | no | 3 | 5 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 160 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 855 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 0 | 6 | 2 | 0 | 0 | 809 |
| L0608 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 1 | 0 | 0 | 805 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 135 |
| L0624 | 6 | 1 | Mine | no | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 235 |
| L0624 | 6 | 1 | Opponent | no | 4 | - | 3 | 2 | 0 | 0 | 0 | 205 |
| L0713 | 5 | 1 | Mine | no | - | 6 | 0 | 4 | 0 | 0 | 0 | 238 |
| L0713 | 5 | 1 | Opponent | no | - | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0729 | 3 | 1 | Mine | no | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 439 |
| L0729 | 3 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 225 |
| L0819 | 3 | 1 | Opponent | no | 3 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 265 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 713 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 126 |
| L1017 | 3 | 1 | Opponent | yes | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 190 |
| L1034 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 5 | 7 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 8 | 4 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1126 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 60 |
| L1220 | 2 | 1 | Mine | - | - | 5 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1220 | 2 | 1 | Opponent | - | - | 3 | 1 | 4 | 1 | 0 | 0 | 402 |
| L1314 | 6 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 0 | 3 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 6 | 4 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 2 | 0 | 0 | 0 |
| L1621 | 1 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 1 | - | 0 | 5 | 0 | 0 | 0 | 210 |
| L1719 | 3 | 1 | Mine | no | 7 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | yes | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 255 |
| L1835 | 5 | 1 | Mine | no | - | - | 3 | 1 | 0 | 0 | 0 | 185 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 4 | 5 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | 4 | 2 | 6 | 0 | 0 | 0 | 532 |
| L2021 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 0 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Mine | no | - | - | 0 | 7 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 202 |
| L2227 | 1 | 1 | Mine | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 2 | 2 | 6 | 2 | 1 | 0 | 0 | 325 |
| L2331 | 3 | 1 | Opponent | yes | 4 | 2 | 1 | 1 | 2 | 0 | 0 | 340 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 50 |
| L2527 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 0 | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 2 | 3 | 3 | 5 | 0 | 0 | 0 | 251 |
| L2930 | 2 | 1 | Mine | - | - | 1 | 8 | 3 | 0 | 0 | 0 | 292 |
| L2930 | 2 | 1 | Opponent | - | - | 5 | 2 | 0 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 3 | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 4 | 2 | 4 | 4 | 0 | 0 | 0 | 365 |
| **Average** | | | Mine | 21% | 2.5 | 2.8 | 1.9 | 1.9 | 0.2 | 0.0 | 0.0 | 250.8 |
| **Average** | | | Opponent | 29% | 2.5 | 2.6 | 2.6 | 2.6 | 0.3 | 0.0 | 0.0 | 140.0 |

### KPIs: base-s1-882d875-p4

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (38 of 170) | 0% (0 of 169) | 11% (38 of 339) |
| Winner chose to follow up after the loser gave ground |  | 85% (33 of 39); on the table 90% | 89% (31 of 35); on the table 97% | 86% (64 of 74); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 62% (5 of 8); on the table 62% | 78% (7 of 9); on the table 78% | 71% (12 of 17); on the table 71% |
| Winner chose to pursue after the loser fled |  | 85% (17 of 20); on the table 90% | 79% (15 of 19); on the table 79% | 82% (32 of 39); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 82% (55 of 67); on the table 87% | 84% (53 of 63); on the table 89% | 83% (108 of 130); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 33% (90 of 276) | 32% (54 of 168) | 32% (144 of 444) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (90 of 222) | 37% (54 of 145) | 39% (144 of 367) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 55% (23 of 42) | 65% (52 of 80) | 61% (75 of 122) |
| Points that never fought | lower | 47% (31898 of 67942) | 47% (33696 of 71984) | 47% (65594 of 139926) |
|   infantry points that never fought | lower | 64% (9753 of 15347) | 70% (9713 of 13804) | 67% (19466 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (174 of 270) | 66% (186 of 280) | 65% (360 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.5 uses a game | 78% (7 of 9); 0.8 uses a game | 87% (27 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.2 uses a game | 20% (4 of 20); 0.2 uses a game | 25% (9 of 36); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 80% (12 of 15); 0.3 uses a game | 68% (23 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (32767 of 57750) | 58% (36511 of 63347) | 57% (69278 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.5 (49%) | 1.6 (52%) | 4.2 (50%) |
| MARCHED: its unit marched | 0.8 (15%) | 0.6 (20%) | 1.4 (17%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.2 (6%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 0.9 (17%) | 0.4 (12%) | 1.2 (15%) |
| REAR RANK: in a rear rank | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.4 (8%) | 0.2 (7%) | 0.6 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (1%) | 0.2 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.6 | 2.3 | 4.0 | 0.5 | 1.9 |
| not cast | 2.6 | 2.5 | 2.5 | 8.3 | 1.5 | 21.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.8 (71%) | 0.2 (10%) | 4.2 (50%) | 0.6 (42%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (17%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.1 (3%) | 0.4 (18%) | 1.2 (15%) | 0.2 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (12%) | 0.2 (7%) | 0.3 (12%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.3 (11%) | 0.1 (2%) | 0.1 (3%) | 0.6 (8%) | 0.1 (9%) | 1.4 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.2 (3%) | 0.0 (0%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.3 (11%) | 0.0 (1%) | 0.1 (1%) | 0.3 (22%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (70%) | 0.1 (6%) | 1.3 (53%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 0.8 a game | 1.2 a game |
| stood (cast and not dispelled) | 58% (33 of 57) | 71% (15 of 21) | 62% (48 of 78) |
| the unit moved after it | 48% (16 of 33) | 67% (10 of 15) | 54% (26 of 48) |
| it charged on its next turn | 0% (0 of 33) | 0% (0 of 15) | 0% (0 of 48) |
| the enemy charged it first | 6% (2 of 33) | 0% (0 of 15) | 4% (2 of 48) |
| it fought by the end of its next turn | 12% (4 of 33) | 13% (2 of 15) | 12% (6 of 48) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 33) | 0% (0 of 15) | 0% (0 of 48) |
| none of these (no charge, no fight, no charge escaped) | 88% (29 of 33) | 87% (13 of 15) | 88% (42 of 48) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (526 of 898) | 51% (301 of 592) | 56% (827 of 1490) |
|   cavalry | 61% (52 of 85) | 61% (75 of 122) | 61% (127 of 207) |
|   character | 34% (31 of 92) | 19% (27 of 144) | 25% (58 of 236) |
|   chariot | 65% (72 of 110) | 79% (22 of 28) | 68% (94 of 138) |
|   infantry | 54% (147 of 270) | 63% (150 of 237) | 59% (297 of 507) |
|   monster | 55% (27 of 49) | 17% (5 of 29) | 41% (32 of 78) |
|   war machine | 67% (197 of 292) | 69% (22 of 32) | 68% (219 of 324) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.4 (14%) | 1.1 (14%) | 2.5 (14%) |
| CHARGED: it charged | 0.9 (9%) | 1.9 (23%) | 2.8 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (5%) | 0.3 (3%) | 0.8 (4%) |
| MOVED: a war machine that moved | 1.6 (15%) | 0.3 (3%) | 1.8 (10%) |
| NO TARGET IN RANGE | 3.1 (30%) | 2.9 (35%) | 5.9 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (5%) | 0.5 (7%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (17%) | 1.0 (12%) | 2.7 (15%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.6 | 81% | 5.2 pts | 30 pts |
| character | 2.1 | 0.4 | 87% | 3.6 pts | 7 pts |
| chariot | 2.6 | 1.2 | 67% | 15.2 pts | 40 pts |
| infantry | 12.6 | 3.0 | 82% | 5.8 pts | 73 pts |
| monster | 1.0 | 0.1 | 89% | 3.0 pts | 3 pts |
| war machine | 6.1 | 5.6 | 66% | 34.1 pts | 207 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 4.5 | 3.7 |
| Charges that made contact a game | 2.5 | 2.7 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.89 declared, 0.78 contact (18 units) | 0.94 declared, 0.61 contact (18 units) | 0.92 declared, 0.69 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.20 declared, 1.00 contact (10 units) | 1.07 declared, 0.80 contact (15 units) | 1.12 declared, 0.88 contact (25 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.25 contact (256 units) | 0.42 declared, 0.24 contact (306 units) | 0.37 declared, 0.25 contact (562 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (51 of 81) | 69% (11 of 16) | 83% (5 of 6) | 65% (67 of 103) |
| Character in a unit | 91% (32 of 35) | 79% (15 of 19) | 100% (2 of 2) | 88% (49 of 56) |
| Character on its own | 97% (29 of 30) | 52% (12 of 23) | 24% (18 of 76) | 46% (59 of 129) |
| Chariot | 80% (12 of 15) | 67% (8 of 12) | - | 74% (20 of 27) |
| Infantry | 65% (54 of 83) | 56% (14 of 25) | 67% (4 of 6) | 63% (72 of 114) |
| Monster | 53% (18 of 34) | 86% (12 of 14) | - | 62% (30 of 48) |
| Monstrous | 100% (14 of 14) | 50% (7 of 14) | - | 75% (21 of 28) |
| War Machines | 93% (40 of 43) | 100% (2 of 2) | - | 93% (42 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 75% (3 of 4); on the table 75% | 39% (40 of 102) | 53% | 68% (15 of 22) | 100% (6 of 6); 3.8 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 67% (2 of 3); on the table 67% | 58% (14 of 24) | 46% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 90% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 58% (7 of 12); on the table 75% | 17% (3 of 18) | 46% | 77% (48 of 62) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 82% (9 of 11); on the table 82% | 35% (29 of 84) | 38% | 57% (21 of 37) | 78% (7 of 9); 4.8 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 78% (14 of 18); on the table 78% | 17% (6 of 36) | 52% | 54% (38 of 70) | 100% (7 of 7); 3.3 uses a game | 17% (5 of 30); 0.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 23% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 45% | 57% (12 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 61% | 71% (10 of 14) | 100% (2 of 2); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (2 of 2); on the table 100% | 48% (20 of 42) | 51% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 82% (14 of 17); on the table 100% | 19% (8 of 42) | 53% | 84% (38 of 45) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 85% (11 of 13); on the table 85% | 0% (0 of 6) | 39% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (12 of 12); on the table 100% | 27% (16 of 60) | 39% | 64% (27 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 84% (16 of 19); on the table 89% | 42% (5 of 12) | 35% | 64% (46 of 72) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 92% (12 of 13); on the table 92% | 0% (0 of 6) | 47% | 70% (39 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (base-s1-882d875-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (29) | 48% (26) | 48% (55) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.61 | 1.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.03 | 0.14 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.39 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.06 | 0.03 | 0.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.03 | 0.00 | 0.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.25 | 0.22 | 0.47 |

### Quality by phase: base-s1-882d875-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 67% (62 of 92) | 36% (53 of 146) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (119 of 387) | 29% (41 of 139) |
| Strategy | Support requests answered (helper made contact too) | 86% (6 of 7) | 31% (4 of 13) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 44% (4 of 9) | 42% (5 of 12) |
| Strategy | Joined characters whose unit fought | 41% (17 of 41) | 32% (13 of 40) |
| Strategy | Lone characters that fought | 60% (49 of 82) | 67% (51 of 76) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.9 | 2.6 |
| Movement | Points that never moved of their own | 250.8 | 140.0 |
| Movement | Fights charged into per game | 2.2 | 2.4 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 67, net +2 | 20 of 73, net -26 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 67, net +57 | 9 of 73, net +63 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 67, net +61 | 9 of 73, net +56 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 of 67, net +49 | 18 of 73, net +120 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (196 of 361) | 32% (103 of 318) |
| Shooting | Points destroyed by shooting units | 39.1 | 36.6 |
| Shooting | War machine shots | 5.5 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (104 of 197) | 23% (5 of 22) |
| Shooting | Points destroyed by war machines | 34.9 | 0.0 |
| Magic | Magic missiles cast | 1.6 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 23% (13 of 57) | 23% (6 of 26) |
| Magic | Wounds caused by magic missiles | 3.2 | 1.3 |
| Magic | Wounds caused by other spells | 1.3 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 70.2 | 13.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.3 / 0.7 / 0.4 | 2.2 / 0.7 / 0.4 / 0.0 |
| Combat | Points destroyed in combat | 250.7 | 261.8 |
| Combat | Points run down | 33.6 | 55.4 |
| Combat | Net points per charged fight, damage counted | +57 | +67 |
| Combat | Net per 100 charger points, damage counted | +19.0 | +18.3 |
| Combat | First round won (charged fights) | 76% | 69% |
| Combat | Net points per charged fight | +57 | +54 |
| Combat | Net points per supported fight / lone fight | +20 / +62 | +101 / +52 |
| Combat | Charged fights on a top-3 enemy unit | 22 of 81 | 50 of 88 |
| Game | Points lost | 563.2 | 504.6 |
| Game | VP from objectives | 650.8 | 611.7 |
| Game | Lone holders (player turns) | 2.5 | 2.5 |

- Mine won / drew / lost: 16 / 7 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -36 VP
- The side that went first won 13 of 29 games with a winner
- Points traded per game (both sides' losses): 1068
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: base-s1-882d875-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +30.4 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 3.1 |
| AFTERMATH WITH FRIENDS | 0.1 | +1.1 | 0.0 | 0.0 | 0.1 | +4.3 | 0.0 | 6.2 |
| ALREADY CARRIED | 0.2 | +0.0 | 20.2 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.9 | +96.0 | 0.0 | 232.9 | 21.8 | +197.2 | 0.0 | 283.7 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 14.7 | 0.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.1 | 0.0 | 0.0 | 0.3 | +2.1 | 0.0 | 3.2 |
| BEST PRIZE | 0.1 | -1.0 | 6.6 | 0.0 | 0.2 | -6.3 | 8.2 | 16.6 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -5.0 | 5.8 | 7.5 | 0.3 | -68.2 | 52.0 | 13.9 |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 37.2 | 0.0 | 0.1 | +0.0 | 14.2 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +78.5 | 190.0 | 81.2 | 0.6 | +32.1 | 44.6 | 7.1 |
| CANNON SIGHT KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +18.8 | 92.6 | 15.0 | 0.4 | +1.5 | 3.7 | 20.3 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +30.1 | 41.7 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.1 | +0.0 | 0.0 | 20.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +9.0 | 0.0 | 6.0 | 1.3 | +43.6 | 0.0 | 19.9 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 2.3 | 0.2 | -0.5 | 0.0 | 1.8 |
| CHAMPION KNOWS CHALLENGE | 0.0 | -0.2 | 6.2 | 0.0 | 0.1 | -5.2 | 16.9 | 4.0 |
| CHARACTER GUNS | 0.8 | +0.0 | 0.0 | 12.3 | 0.4 | +0.0 | 0.0 | 12.3 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.1 | +5.9 | 0.0 | 0.0 |
| CHARGE LOSSES | 8.1 | -418.4 | 0.0 | 236.3 | 10.6 | -643.9 | 0.0 | 268.2 |
| CHARGE NOT DECLARED | - | - | - | - | 0.1 | +0.0 | 4.9 | 11.4 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 182.0 | 67.0 | 2.3 | +0.0 | 226.0 | 49.6 |
| CHARGER SLAIN LOST | 0.4 | -18.1 | 37.3 | 19.1 | 0.4 | -9.0 | 21.1 | 10.7 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 2.7 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 39.1 | 0.3 | +0.0 | 13.8 | 27.8 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.6 | +275.2 | 61.2 | 30.2 | 0.5 | +34.0 | 0.0 | 0.0 |
| COVER ONCE | 5.4 | -304.4 | 0.0 | 103.4 | 4.8 | -379.2 | 0.0 | 83.4 |
| DENIED BY THE FIGHT | 0.8 | -8.6 | 61.2 | 29.4 | 0.8 | -3.4 | 62.2 | 3.3 |
| DEPLOY BY FIGURES | 8.2 | +11.2 | 0.0 | 16.0 | 7.8 | +48.3 | 0.0 | 6.9 |
| EDGE GIVE GROUND | 0.0 | +0.4 | 3.6 | 2.9 | 0.3 | +2.3 | 16.4 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.1 | +6.8 | 0.0 | 9.9 | 0.0 | +6.2 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.2 | +8.2 | 210.3 | 73.3 | 3.1 | +9.5 | 248.9 | 71.4 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 2.1 | 0.3 | +1.9 | 0.0 | 2.0 |
| FALLS SHORT | 2.9 | +44.8 | 0.0 | 66.1 | 16.5 | +231.0 | 0.0 | 182.0 |
| FEATURE BUFFS | 2.5 | +85.0 | 0.0 | 33.1 | 1.6 | +22.5 | 0.0 | 27.6 |
| FIGHT LIFT | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.5 | +8.5 | 50.8 | 12.1 | 0.9 | +25.3 | 72.8 | 22.2 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 3.1 | - | - | - | - |
| FIRE IN ORDER | 0.2 | +0.0 | 1.9 | 6.4 | 0.2 | +0.0 | 0.8 | 0.0 |
| FIVE ACTION | 91.9 | +5064.2 | 1110.2 | 1104.8 | 85.4 | +4888.2 | 684.2 | 943.2 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 103.6 | 4.7 | +0.0 | 0.0 | 125.1 |
| FOCUS FIRE | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +1.1 | 3.4 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +66.0 | 0.0 | 13.4 | 0.9 | +206.6 | 0.0 | 16.6 |
| FOUR ROUNDS | 2.9 | +230.5 | 262.9 | 77.5 | 4.3 | +356.0 | 324.4 | 80.1 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -5.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -17.9 | 0.0 | 3.3 | 0.2 | -1.3 | 15.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +4.8 | 0.0 | 5.4 | 0.1 | +0.4 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.8 | 41.5 | 0.0 | 0.3 | -6.1 | 23.4 | 13.9 |
| GROUND FLIERS | 0.1 | +2.7 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +6.7 | 9.2 | 22.9 | 0.4 | +3.2 | 0.0 | 9.0 |
| GUN MASK | 1.6 | +44.7 | 0.0 | 20.8 | 0.3 | +10.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 17.4 | 1.0 | +0.0 | 0.0 | 13.9 |
| HE SHOOTS OR CHARGES | 2.6 | +0.0 | 0.0 | 67.4 | 3.7 | +0.0 | 0.0 | 128.7 |
| HELPER UNSEEN | 0.1 | +0.0 | 9.7 | 1.4 | - | - | - | - |
| HIS CHARGE DENIED | 0.5 | +26.2 | 33.0 | 19.3 | 0.3 | +10.3 | 11.0 | 3.2 |
| HIS CHARGE LIST | 4.4 | +0.0 | 0.0 | 72.9 | 6.3 | +0.0 | 0.0 | 83.8 |
| HIS FIGHT TOGETHER | 2.3 | -64.5 | 0.0 | 109.6 | 1.9 | -27.6 | 0.0 | 71.0 |
| HIS LEGAL MOVES | 3.8 | +0.0 | 0.0 | 74.2 | 4.7 | +0.0 | 0.0 | 41.1 |
| HIS MOVE AND SHOT | 3.4 | -55.1 | 0.0 | 129.2 | 3.6 | -86.8 | 0.0 | 90.9 |
| HIS MOVE AS HE DECIDES | 40.4 | +14.4 | 571.8 | 0.0 | 35.4 | +13.4 | 523.1 | 0.0 |
| HIS MOVE WHY | 35.2 | +0.0 | 0.0 | 420.6 | 40.0 | +0.0 | 0.0 | 408.1 |
| HIS ONE MOVE | 17.3 | +39.1 | 2.5 | 78.9 | 19.7 | +79.4 | 5.0 | 118.0 |
| HIS ONE QUARTER | 3.6 | +0.0 | 0.0 | 46.0 | 3.1 | +0.0 | 0.0 | 48.3 |
| HIS OWN BEST MOVE | 1.4 | +0.0 | 0.0 | 48.4 | 1.9 | +0.0 | 0.0 | 4.9 |
| HIS RANDOM MOVE | 6.4 | +0.0 | 0.0 | 24.3 | 3.9 | +0.0 | 0.0 | 54.7 |
| HIS SHOT LIST | 32.4 | +805.3 | 0.0 | 399.1 | 46.6 | +2288.4 | 0.0 | 565.3 |
| HIS TURN DENIED | 1.0 | +20.5 | 86.2 | 14.2 | 2.6 | +101.0 | 177.9 | 35.1 |
| HOLD ODDS | 17.2 | +0.0 | 0.0 | 204.6 | 16.2 | +0.0 | 0.0 | 138.2 |
| HOLDER ASSIGNMENT | 9.5 | +923.2 | 0.0 | 93.4 | 9.3 | +860.1 | 0.0 | 63.6 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -87.1 | 190.9 | 61.3 | 3.7 | -196.7 | 311.9 | 65.2 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.4 | +18.0 | 0.0 | 0.0 | 0.3 | +11.3 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.0 | 3.5 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.1 | +18.5 | 3.5 | 0.0 |
| HUNT THE GUNS | 0.0 | +5.8 | 3.6 | 2.9 | 0.1 | +31.2 | 11.5 | 0.0 |
| IDLE COST | 2.4 | -32.9 | 0.0 | 26.3 | 13.9 | -221.6 | 0.0 | 137.8 |
| JOINT CHARGE NOW | 0.6 | +0.8 | 73.2 | 25.8 | 0.8 | +43.4 | 84.0 | 15.1 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -1.7 | 0.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.1 | +18.4 | 10.3 | 13.9 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 5.2 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.2 | +0.0 | 0.0 | 23.4 | 2.6 | +0.0 | 0.0 | 21.4 |
| LANE BY FIGURES | 0.8 | +27.8 | 0.0 | 0.0 | 1.1 | +59.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.1 | +0.0 | 270.3 | 230.6 | 4.8 | +0.0 | 137.3 | 165.5 |
| LONE CHARACTER SAFE SPOT | 0.1 | +1.3 | 0.0 | 1.2 | 0.0 | +5.1 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.7 | 21.4 | 0.0 | 0.1 | +1.1 | 6.6 | 0.0 |
| LOST AFTER ESCAPE | 1.6 | +1.3 | 144.4 | 49.4 | 2.1 | +0.2 | 154.7 | 29.9 |
| LOST CHARGE | 0.1 | -0.1 | 6.5 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.2 | -7.3 | 0.0 | 4.7 | 0.1 | -49.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +1.4 | 0.0 | 0.0 | 0.2 | +4.6 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | -1.3 | 0.0 | 10.8 | 0.7 | +0.7 | 0.0 | 7.1 |
| MARCH AT ESCAPER | 0.1 | +1.4 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 5.4 |
| MARCH BY THE SUM | 0.3 | +25.4 | 0.0 | 3.1 | 0.2 | +11.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +35.2 | 0.0 | 19.7 | 0.4 | +21.3 | 0.0 | 9.7 |
| MARCH OF THE TABLE | 0.1 | +1.9 | 0.0 | 0.0 | 0.1 | +5.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.9 | +29.6 | 0.0 | 7.8 | 0.5 | +6.7 | 0.0 | 5.4 |
| MARCH WHEELS ONLY | 1.1 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +51.0 | 0.0 | 29.9 | 2.6 | +55.3 | 0.0 | 48.6 |
| MISSILES IN THE MOVE | 3.8 | +123.8 | 0.0 | 104.8 | 2.4 | +28.9 | 0.0 | 29.8 |
| MISSILES NEXT TURN | 5.4 | +91.8 | 0.0 | 104.2 | 3.2 | +22.5 | 0.0 | 40.6 |
| MISSILES ON ONE TARGET | 0.1 | -4.4 | 0.0 | 7.6 | - | - | - | - |
| MODEL FACING | 0.3 | +56.7 | 0.0 | 1.7 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 16.1 | 27.6 | 2.6 | +0.0 | 26.4 | 29.9 |
| MOVE SPELL IN RANGE | 0.6 | +19.7 | 0.0 | 19.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -10.8 | 6.6 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 20.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +408.6 | 0.0 | 41.0 | 6.7 | +606.8 | 0.0 | 66.7 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.2 | +364.0 | 0.0 | 74.2 | 6.3 | +272.5 | 0.0 | 47.9 |
| NEXT CHARGE BY LIST | 4.6 | -176.4 | 9.3 | 61.2 | 6.6 | -317.5 | 16.9 | 55.7 |
| NEXT OBJECTIVE NEARER | 0.1 | -3.6 | 0.0 | 0.0 | 0.2 | -5.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -100.2 | 219.3 | 76.2 | 3.2 | -152.9 | 260.9 | 72.4 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 10.4 | 0.4 | +0.0 | 0.0 | 6.8 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +1.7 | 0.0 | 0.0 |
| NOT TURNED | 0.2 | -0.1 | 0.0 | 5.6 | 0.2 | -0.2 | 0.0 | 5.2 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 9.9 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 3.2 | -142.1 | 24.1 | 43.0 | 3.3 | -123.7 | 9.1 | 39.5 |
| ONE CHARGE A CHARGER | 5.0 | +0.0 | 0.0 | 139.4 | 4.3 | +0.0 | 0.0 | 109.2 |
| ONE FIGHT FORMULA | 3.9 | -91.9 | 0.0 | 49.8 | 4.2 | -97.8 | 0.0 | 64.2 |
| ONE OBJECTIVE FORMULA | 4.4 | -15.5 | 0.0 | 69.2 | 3.8 | +21.9 | 0.0 | 50.0 |
| ONE PROMISE A TARGET | 0.1 | -3.7 | 0.0 | 0.0 | 0.2 | -2.3 | 0.0 | 0.0 |
| ONE ROUTE | 1.1 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 22.2 | +378.2 | 0.0 | 306.3 | 29.3 | +833.8 | 0.0 | 308.8 |
| OPENS A LANE | 0.2 | +0.5 | 27.3 | 0.0 | 0.0 | +0.0 | 2.1 | 0.0 |
| OPENS UP | 0.2 | +11.1 | 15.4 | 0.0 | 0.5 | +31.6 | 24.4 | 16.6 |
| OVERRUNS AWAY | 0.2 | +10.9 | 31.6 | 8.6 | 0.7 | +54.2 | 61.5 | 44.4 |
| OWN CAST FIRST | 0.0 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +9.2 | 0.0 | 10.7 | 0.4 | +14.2 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.0 | +3.6 | 0.0 | 0.0 | 0.1 | +4.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.0 | -0.3 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| PLAN RESULT | 42.6 | +718.6 | 362.5 | 812.2 | 41.8 | +454.4 | 285.6 | 776.2 |
| PROMISE BELOW ZERO | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 17.4 |
| PROMISE BY ITS OWN SUM | 7.5 | -230.3 | 0.0 | 0.0 | 7.6 | -180.3 | 0.0 | 38.9 |
| PROMISE IN STEPS | 0.1 | +0.0 | 0.0 | 1.7 | 0.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.5 | -0.8 | 3.0 | 0.0 | 0.5 | -1.0 | 15.0 | 5.0 |
| PROMISE READS THE TABLE | 0.3 | -14.8 | 0.0 | 1.7 | 0.3 | -10.2 | 0.0 | 13.9 |
| PROMISE SHOT AWAY | 0.2 | -2.8 | 10.6 | 0.0 | 0.1 | -2.5 | 11.7 | 0.0 |
| PURSUES BIG PREY | 0.0 | -3.9 | 0.0 | 0.0 | 0.1 | -17.7 | 0.0 | 0.0 |
| QUARTER ODDS | 15.9 | +1582.0 | 253.7 | 145.2 | 14.2 | +1682.4 | 105.1 | 153.7 |
| RANDOM MOVE BY FIGURES | 1.2 | +10.1 | 0.0 | 18.6 | 2.2 | +63.1 | 0.0 | 74.3 |
| REAL GROUND | 1.1 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -10.6 | 0.0 | 10.4 | 1.5 | -42.7 | 0.0 | 25.4 |
| REDIRECT COUNTER | 2.1 | +111.2 | 0.0 | 45.9 | 3.0 | +166.3 | 0.0 | 70.7 |
| REDIRECT WEIGHED | 0.1 | +0.9 | 4.0 | 0.0 | 0.2 | +2.1 | 19.4 | 17.9 |
| REFORMS TO MEET IT | 1.2 | -17.8 | 0.0 | 1.7 | 1.7 | -41.4 | 0.0 | 7.9 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 12.0 | 0.2 | +0.0 | 0.0 | 12.5 |
| RESERVE FALL BACK | 0.4 | +34.6 | 0.0 | 17.1 | 0.3 | +21.5 | 0.0 | 8.9 |
| RESTRAINS TO SHOOT | 0.1 | +0.4 | 0.0 | 5.2 | 0.1 | +3.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +79.8 | 177.8 | 77.5 | 2.7 | -56.5 | 231.1 | 67.3 |
| RISK BY HIS FIGURE | 20.2 | -343.2 | 0.0 | 519.6 | 20.9 | -394.5 | 0.0 | 475.2 |
| RISK ON THE WAY | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 6.8 |
| ROUNDS AFTER TERROR | 0.6 | -9.9 | 57.8 | 5.1 | 1.7 | -38.5 | 138.4 | 0.0 |
| RUN DOWN | 1.9 | -18.1 | 156.6 | 52.8 | 3.0 | -38.2 | 224.4 | 37.9 |
| SAFER THAN THE JOB | 0.0 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 0.0 | -0.4 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.1 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -14.6 | 0.0 | 2.1 | 0.6 | -36.4 | 0.0 | 6.4 |
| SEARCH SPOT | 0.4 | +7.3 | 0.0 | 0.0 | 0.4 | +2.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.2 | +15.3 | 26.5 | 9.4 | 0.2 | +21.3 | 14.8 | 0.0 |
| SELF MOVE SPELL | 0.2 | +40.7 | 0.0 | 0.0 | 0.7 | +51.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.8 | +30.2 | 15.5 | 39.2 | 2.3 | +35.2 | 0.0 | 21.3 |
| SET UP TOGETHER | 0.3 | +6.7 | 0.0 | 0.0 | 0.3 | +5.5 | 0.0 | 10.1 |
| SET-UP ANY TARGET | 0.2 | +38.0 | 20.9 | 10.5 | 0.1 | +11.9 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +9.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +107.8 | 117.2 | 32.5 | 1.8 | +37.3 | 32.4 | 10.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -4.6 | 42.3 | 9.2 | 0.4 | -5.6 | 15.4 | 4.8 |
| SHOT RISK POINTS | 12.6 | -20.3 | 0.0 | 173.9 | 23.4 | -58.1 | 0.0 | 373.4 |
| SHOTS AFTER THE MOVES | 3.1 | +0.0 | 0.0 | 0.0 | 1.6 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.2 | +533.9 | 0.0 | 226.2 | 7.8 | +209.5 | 0.0 | 102.9 |
| SPELL SETS UP CHARGE | 0.2 | +38.0 | 20.9 | 10.5 | 0.1 | +23.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +19.0 | 37.3 | 24.9 | 2.6 | +43.5 | 15.0 | 15.0 |
| SPELLS IN THE FIGHT | 0.6 | +0.7 | 45.4 | 10.4 | 0.4 | -5.1 | 27.2 | 10.9 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 204.3 | 10.6 | +0.0 | 0.0 | 130.1 |
| STAND AND SHOOT | 0.6 | -6.5 | 45.3 | 6.2 | 0.8 | -8.0 | 46.0 | 7.6 |
| STANDS FOR A REASON | 0.5 | +0.0 | 26.9 | 31.8 | 2.0 | +0.0 | 17.7 | 49.4 |
| STANDS STILL | 47.4 | +0.0 | 847.3 | 472.9 | 27.7 | +0.0 | 359.8 | 233.1 |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.3 | 0.0 | 3.2 |
| STAY WORTH | 25.2 | -86.4 | 492.8 | 255.2 | 10.5 | +78.5 | 225.7 | 88.8 |
| STOPS | 0.0 | +0.5 | 3.6 | 2.9 | 0.1 | +6.6 | 11.5 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 9.9 | 0.1 | +0.0 | 0.0 | 9.9 |
| STUPIDITY NEXT TURN | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.3 | +671.6 | 0.0 | 143.7 | 9.3 | +579.7 | 0.0 | 94.1 |
| SUPPORT NARROWED | 0.3 | +0.0 | 33.3 | 4.1 | 0.3 | +0.0 | 16.9 | 0.0 |
| SUPPORT WORKED OUT | 9.3 | +671.6 | 0.0 | 143.7 | 9.3 | +579.7 | 0.0 | 94.1 |
| SURE REACH TOGETHER | 0.2 | +2.1 | 0.0 | 1.7 | 0.4 | +5.9 | 0.0 | 3.4 |
| THE DEARER SUM KEEPS ITS PLAN | 1.5 | +0.0 | 0.0 | 15.4 | 1.1 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.1 | -2.7 | 0.0 | 0.0 | 0.3 | -17.4 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.3 | +0.0 | 0.0 | 336.8 | 35.4 | +0.0 | 0.0 | 358.9 |
| TIED UP BY THE SUM | 0.8 | +74.6 | 59.8 | 4.0 | 1.1 | +123.4 | 76.4 | 16.6 |
| TIME ON OUR SIDE | 41.5 | +457.4 | 22.6 | 375.7 | 12.8 | +81.7 | 26.7 | 90.5 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 6.5 |
| WALKS ON ITS ROUTE | 0.1 | +0.3 | 0.0 | 6.2 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 35.8 | 33.3 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.1 | -9.3 | 33.3 | 0.0 | 0.4 | -21.2 | 41.3 | 34.0 |
| WHO GETS IN | 0.0 | -3.1 | 3.8 | 0.0 | 0.1 | +18.3 | 41.3 | 13.9 |
| WHO HITS BACK | 0.4 | +58.2 | 0.0 | 4.7 | 0.2 | +56.2 | 0.0 | 13.9 |
| WHOLE FIGHT | 0.1 | +2.7 | 16.6 | 0.0 | 0.2 | +25.4 | 20.7 | 17.0 |
| WHOLE FIGHT GAIN | 0.2 | +16.8 | 7.2 | 11.0 | 0.2 | +8.9 | 8.2 | 0.0 |
| WIDER SPREAD | 2.0 | -2.0 | 171.2 | 34.8 | 2.7 | -6.8 | 199.3 | 75.4 |
| WOUNDS ON THE RANKS | 1.1 | +23.7 | 0.0 | 53.8 | 1.6 | +124.1 | 0.0 | 7.5 |

### Rule changes: base-s1-882d875-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2726 | 2726 | 1725 | 47.92 | +0 | +0.0 |
| HIS MOVE WHY | 2709 | 2709 | 1532 | 42.56 | +0 | +0.0 |
| ARMY TABLE | 1392 | 1392 | 953 | 26.47 | +10890 | +11.4 |
| HIS SHOT LIST | 2844 | 2731 | 672 | 18.67 | +13314 | +19.8 |
| HOLDER ASSIGNMENT | 677 | 677 | 629 | 17.47 | +38030 | +60.5 |
| ONE TARGET A SHOOTER | 1856 | 1775 | 393 | 10.92 | +4307 | +11.0 |
| LEGAL CHARGES ONLY | 390 | 390 | 390 | 10.83 | +0 | +0.0 |
| DEPLOY BY FIGURES | 577 | 577 | 371 | 10.31 | +4788 | +12.9 |
| THE TABLE AGAIN | 432 | 432 | 281 | 7.81 | +0 | +0.0 |
| HIS ONE MOVE | 1331 | 1296 | 280 | 7.78 | +0 | +0.0 |
| TIME ON OUR SIDE | 1954 | 1766 | 277 | 7.69 | +824 | +3.0 |
| SUPPORT ADDS | 668 | 641 | 256 | 7.11 | +13071 | +51.1 |
| SUPPORT WORKED OUT | 668 | 641 | 256 | 7.11 | +13071 | +51.1 |
| FIVE ACTION | 6383 | 6166 | 243 | 6.75 | +10765 | +44.3 |
| OFF BEST | 234 | 234 | 234 | 6.50 | -9571 | -40.9 |
| MOVE TO CHARGE COMPUTED | 432 | 367 | 195 | 5.42 | +8547 | +43.8 |
| PROMISE BY ITS OWN SUM | 544 | 544 | 190 | 5.28 | -14782 | -77.8 |
| SHOT RISK POINTS | 1294 | 1246 | 181 | 5.03 | +3958 | +21.9 |
| QUARTER ODDS | 1083 | 1028 | 147 | 4.08 | +15069 | +102.5 |
| HARD STAY DROPPED | 145 | 145 | 145 | 4.03 | +0 | +0.0 |
| MOVE ORDER | 139 | 139 | 139 | 3.86 | +0 | +0.0 |
| FOUR ROUNDS | 259 | 246 | 116 | 3.22 | +5468 | +47.1 |
| SHOOTS FROM THE BEST SPOT | 174 | 174 | 116 | 3.22 | +1692 | +14.6 |
| IDLE COST | 586 | 473 | 104 | 2.89 | +953 | +9.2 |
| RANDOM MOVE BY FIGURES | 122 | 122 | 75 | 2.08 | +2636 | +35.1 |
| ADVANCE LANE KEPT | 74 | 74 | 74 | 2.06 | +0 | +0.0 |
| LANE BY FIGURES | 70 | 70 | 70 | 1.94 | +3132 | +44.7 |
| FOLLOW UP WEIGHED | 53 | 53 | 53 | 1.47 | +9813 | +185.1 |
| CHAFF IN THE MOVE | 56 | 55 | 51 | 1.42 | +33 | +0.7 |
| JOINT CHARGE NOW | 51 | 51 | 51 | 1.42 | +1591 | +31.2 |
| CHARGE LOSSES | 672 | 632 | 50 | 1.39 | +3306 | +66.1 |
| STAY WORTH | 1286 | 1180 | 50 | 1.39 | +523 | +10.5 |
| TIED UP BY THE SUM | 68 | 63 | 49 | 1.36 | +1679 | +34.3 |
| MAX FOR POSITIONING | 192 | 175 | 45 | 1.25 | +246 | +5.5 |
| RISK BY ARC | 177 | 168 | 45 | 1.25 | +1383 | +30.7 |
| SET UP BY THE SET | 146 | 143 | 45 | 1.25 | +3005 | +66.8 |
| COVER ONCE | 366 | 269 | 43 | 1.19 | +742 | +17.3 |
| FALLS SHORT | 699 | 612 | 41 | 1.14 | +296 | +7.2 |
| NEXT CHARGE BY LIST | 405 | 379 | 41 | 1.14 | +1323 | +32.3 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| SHOTS IN THE MOVE | 864 | 683 | 38 | 1.06 | +1282 | +33.7 |
| RISK BY HIS FIGURE | 1479 | 1404 | 37 | 1.03 | +2280 | +61.6 |
| CHARGE NOW FIRST | 152 | 152 | 36 | 1.00 | -1722 | -47.8 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CAST JOB | 61 | 61 | 34 | 0.94 | +142 | +4.2 |
| CANNON SIGHT KEPT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| HIS TURN DENIED | 128 | 126 | 30 | 0.83 | +819 | +27.3 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MARCH CHECK | 43 | 41 | 28 | 0.78 | +470 | +16.8 |
| REDIRECT COUNTER | 184 | 146 | 28 | 0.78 | +1796 | +64.2 |
| MISSILES IN THE MOVE | 224 | 149 | 27 | 0.75 | +415 | +15.4 |
| RESERVE FALL BACK | 27 | 27 | 27 | 0.75 | +2018 | +74.8 |
| CANNON PLANNED TARGET | 213 | 213 | 25 | 0.69 | +20 | +0.8 |
| PATHS CROSS | 25 | 25 | 25 | 0.69 | +843 | +33.7 |
| FEATURE BUFFS | 145 | 143 | 24 | 0.67 | +495 | +20.6 |
| WHO HITS BACK | 23 | 23 | 23 | 0.64 | +3211 | +139.6 |
| COMBAT PIVOT | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| NEARER NOT NEEDED | 524 | 502 | 22 | 0.61 | +778 | +35.4 |
| SHOTS AFTER THE MOVES | 169 | 169 | 22 | 0.61 | +0 | +0.0 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| GUN MASK | 67 | 67 | 19 | 0.53 | +612 | +32.2 |
| MARCH BY THE SUM | 19 | 19 | 19 | 0.53 | +1336 | +70.3 |
| ONE OBJECTIVE FORMULA | 296 | 221 | 19 | 0.53 | +957 | +50.4 |
| CASTER AWAY FROM SCREEN | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CHAFF PASSED | 17 | 17 | 17 | 0.47 | -27 | -1.6 |
| SECOND LOOK | 17 | 17 | 17 | 0.47 | +1317 | +77.5 |
| SEARCH SPOT | 29 | 29 | 16 | 0.44 | +334 | +20.9 |
| SURE REACH TOGETHER | 22 | 19 | 15 | 0.42 | +20 | +1.4 |
| WOUNDS ON THE RANKS | 99 | 96 | 15 | 0.42 | +648 | +43.2 |
| CASTING BLOCK | 28 | 28 | 14 | 0.39 | +115 | +8.2 |
| FIRE IN ORDER | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| OVERRUNS AWAY | 33 | 33 | 13 | 0.36 | +282 | +21.7 |
| OPENS UP | 26 | 23 | 12 | 0.33 | +285 | +23.8 |
| REDIRECT WEIGHED | 12 | 12 | 12 | 0.33 | +459 | +38.3 |
| HIS CHARGE DENIED | 29 | 27 | 11 | 0.31 | +248 | +22.6 |
| PROMISE SHOT AWAY | 11 | 11 | 11 | 0.31 | -191 | -17.4 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| AFTERMATH IN POINTS | 10 | 10 | 10 | 0.28 | +1206 | +120.6 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +2042 | +204.2 |
| ONE FIGHT FORMULA | 291 | 163 | 10 | 0.28 | +138 | +13.8 |
| ONE PROMISE A TARGET | 10 | 10 | 10 | 0.28 | -216 | -21.6 |
| BEST PRIZE | 9 | 9 | 9 | 0.25 | -547 | -60.7 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MARCH OF THE TABLE | 9 | 9 | 9 | 0.25 | -249 | -27.7 |
| PROMISE KNOWS THE FIGHT | 37 | 26 | 9 | 0.25 | -66 | -7.4 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 191 | 181 | 8 | 0.22 | +104 | +13.0 |
| NO DOUBLE ROUNDS | 199 | 187 | 8 | 0.22 | +232 | +29.0 |
| PROMISE READS THE TABLE | 23 | 23 | 8 | 0.22 | -63 | -7.9 |
| AFTERMATH WITH FRIENDS | 7 | 7 | 7 | 0.19 | +195 | +27.9 |
| HONEST WORTH | 215 | 203 | 7 | 0.19 | +188 | +26.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| SUPPORT NARROWED | 23 | 23 | 7 | 0.19 | -414 | -59.1 |
| HIS FIGHT TOGETHER | 152 | 150 | 6 | 0.17 | +262 | +43.6 |
| WHOLE FIGHT GAIN | 14 | 14 | 6 | 0.17 | +325 | +54.2 |
| HIS MOVE AND SHOT | 251 | 238 | 5 | 0.14 | +155 | +31.0 |
| WHO GETS IN | 5 | 5 | 5 | 0.14 | +547 | +109.3 |
| CHARGE NOT DECLARED | 4 | 4 | 4 | 0.11 | -513 | -128.3 |
| FIGHT TO THE END | 52 | 49 | 4 | 0.11 | +84 | +20.9 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +54 | +13.4 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.11 | +189 | +47.3 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +119 | +29.8 |
| MANOEUVRE | 50 | 50 | 4 | 0.11 | +127 | +31.8 |
| MISSILES NEXT TURN | 309 | 207 | 4 | 0.11 | +41 | +10.2 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +292 | +73.1 |
| REFORMS TO MEET IT | 104 | 88 | 4 | 0.11 | +0 | +0.0 |
| REFUSING RETIRES | 15 | 15 | 4 | 0.11 | -1 | -0.2 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +133 | +33.2 |
| WIDER SPREAD | 169 | 163 | 4 | 0.11 | +34 | +8.4 |
| FACES THE THREAT | 3 | 3 | 3 | 0.08 | +466 | +155.2 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.08 | -18 | -5.8 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -775 | -258.3 |
| WALKS ON ITS ROUTE | 3 | 3 | 3 | 0.08 | +10 | +3.3 |
| WAR ENGINE JOBS | 20 | 20 | 3 | 0.08 | -362 | -120.5 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.06 | +211 | +105.3 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +98 | +48.8 |
| FALLBACK BY WORTH | 16 | 16 | 2 | 0.06 | +68 | +33.8 |
| JOINT ON THE TABLE | 2 | 2 | 2 | 0.06 | +663 | +331.3 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LOST AFTER ESCAPE | 133 | 127 | 2 | 0.06 | +6 | +3.0 |
| SET UP TOGETHER | 23 | 16 | 2 | 0.06 | +52 | +25.9 |
| SPELLS IN THE FIGHT | 35 | 33 | 2 | 0.06 | +66 | +33.1 |
| WHAT THE JOINER ADDS | 18 | 16 | 2 | 0.06 | +5 | +2.4 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BLOWS WHERE AIMED | 18 | 18 | 1 | 0.03 | +358 | +358.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +37 | +37.4 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -22 | -21.9 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DENIED BY THE FIGHT | 56 | 55 | 1 | 0.03 | +8 | +8.0 |
| EDGE GIVE GROUND | 11 | 10 | 1 | 0.03 | +5 | +5.2 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +4 | +4.3 |
| FRIEND SHOOTS FIRST | 27 | 25 | 1 | 0.03 | +15 | +15.4 |
| MOVE SPELL IN RANGE | 20 | 17 | 1 | 0.03 | +14 | +13.5 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +48 | +48.1 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.03 | -74 | -73.9 |
| RUN DOWN | 177 | 169 | 1 | 0.03 | +8 | +8.2 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.03 | +182 | +181.7 |
| SCREEN BY WHAT IT SAVES | 29 | 29 | 1 | 0.03 | +20 | +19.9 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -8 | -7.7 |
| STOPS | 5 | 5 | 1 | 0.03 | +5 | +5.2 |
| WHOLE FIGHT | 9 | 8 | 1 | 0.03 | +358 | +358.5 |
| ALREADY CARRIED | 6 | not checked | - | - | - | - |
| BACKUP TARGETS | 13 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 16 | 16 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 56 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 41 | 39 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 30 | 30 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 74 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 324 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 23 | 19 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| GUN FIGURES | 62 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 226 | 223 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 385 | 374 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 307 | 276 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 238 | 218 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 116 | 115 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 372 | 346 | 0 | 0.00 | - | - |
| HOLD ODDS | 1202 | 1193 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT IN PAIRS | 26 | 9 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 172 | 169 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LONG SHOT | 9 | 9 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 14 | 14 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 11 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 50 | 50 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 63 | 62 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 4 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 30 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 10 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 42 | 42 | 0 | 0.00 | - | - |
| NOT TURNED | 17 | 17 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 40 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 336 | 324 | 0 | 0.00 | - | - |
| ONE ROUTE | 63 | 62 | 0 | 0.00 | - | - |
| OPENS A LANE | 9 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 3035 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 11 | 11 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 63 | 62 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 69 | 69 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 26 | 25 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 82 | 79 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 30 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOT OR CHARGE | 23 | 23 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 10 | not checked | - | - | - | - |
| SPELL WORTH | 134 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 621 | 593 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 48 | 48 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 89 | 81 | 0 | 0.00 | - | - |
| STANDS STILL | 2702 | 2628 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 24 | 22 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 93 | not checked | - | - | - | - |
| THE PROMISE ADDS | 15 | 14 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2400 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 108 | 96 | 0 | 0.00 | - | - |

### Off best figure: base-s1-882d875-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.03 | 2.25 | 77.8 |
| JOB FIRST | gate | 2.31 | 2.33 | 44.5 |
| ARMY TABLE | rule | 1.92 | 2.56 | 48.0 |
| NO REASON | gate | 0.69 | 0.78 | 32.8 |
| HOLDER ASSIGNMENT | rule | 0.64 | 0.58 | 28.9 |
| CHARGE NOW FIRST | rule | 0.44 | 0.53 | 49.2 |
| JOINT CHARGE NOW | rule | 0.25 | 0.31 | 92.4 |
| PROMISE SHOT AWAY | rule | 0.19 | 0.11 | 17.4 |
| BEST PRIZE | rule | 0.06 | 0.19 | 60.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.11 | 0.14 | 7.4 |
| MARCH OF THE TABLE | rule | 0.08 | 0.14 | 31.2 |
| ONE PROMISE A TARGET | rule | 0.08 | 0.14 | 28.4 |
| CHAFF PASSED | rule | 0.08 | 0.11 | 3.7 |
| SUPPORT NARROWED | rule | 0.11 | 0.08 | 59.1 |
| CANNON PLANNED TARGET | rule | 0.14 | - | 15.3 |
| CHARGE NOT DECLARED | rule | - | 0.11 | 128.3 |
| DEPLOY BY FIGURES | rule | 0.06 | 0.06 | 5.4 |
| FALLBACK | gate | 0.06 | 0.06 | 34.0 |
| TURN GATE | gate | 0.08 | 0.03 | 29.2 |
| AFTERMATH BAND | gate | 0.03 | 0.06 | 2.2 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.06 | 5.8 |
| PROMISE READS THE TABLE | rule | 0.03 | 0.06 | 108.1 |
| PURSUES BIG PREY | rule | 0.03 | 0.06 | 258.3 |
| WAR ENGINE JOBS | rule | 0.08 | - | 120.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 69.7 |
| PATHS CROSS | rule | 0.06 | - | 203.6 |
| REDIRECT WEIGHED | rule | - | 0.06 | 171.3 |
| WHO GETS IN | rule | 0.03 | 0.03 | 153.4 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 21.9 |
| FIGHT ORDER BAND | gate | - | 0.03 | 0.5 |
| OWN CAST FIRST | rule | 0.03 | - | 73.9 |
| REFUSING RETIRES | rule | - | 0.03 | 0.6 |
| SET UP BY THE SET | rule | - | 0.03 | 68.9 |
| STANDS TO CAST | rule | - | 0.03 | 7.7 |
| WALKS ON ITS ROUTE | rule | 0.03 | - | 65.7 |

### Plans: base-s1-882d875-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.4 | 74% | 288 | 248 | 86% |
| Mine | join | 0.5 | 95% | 17 | 0 | 0% |
| Mine | move | 30.0 | 94% | 1574 | 0 | 0% |
| Mine | shoot | 9.1 | 49% | 405 | 470 | 116% |
| Mine | support | 0.5 | 84% | 10 | 0 | 0% |
| Opponent | charge | 3.5 | 60% | 694 | 336 | 48% |
| Opponent | join | 0.8 | 97% | 47 | 0 | 0% |
| Opponent | move | 33.5 | 94% | 1452 | 0 | 0% |
| Opponent | shoot | 2.9 | 58% | 138 | 118 | 86% |
| Opponent | support | 1.0 | 77% | 0 | 0 | - |

### Packages: hunt the guns, base-s1-882d875-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 1 | - | - | - | - | - | - | - | 9 |
| Opponent | 0.1 | 4 | 0 | 100% | 75% | 0% | 2.0 | 281 | 166 | 50% | 35 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 113 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 57 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 47 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 101 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.5 | 4 | 0 | 100% | 75% | 0% | 2.0 | 281 | 166 | 50% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: base-s1-882d875-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 27% | 60% | 10% | 0% | 11% | 0% | 6% | 67% | 17% |
| Opponent | REDIRECT COUNTER | 3.0 | 22% | 83% | 8% | 0% | 27% | 5% | 5% | 55% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s1-882d875-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | 0 (3) | 0 (1) | - | - | 0 (4) |
| Mine | Chaff | 31 | 90 (31) | 0 | 90 | 33 | 55% | 2.0 | 107 (12) | 61 (14) | 126 (5) | 102 (27) | 0 (4) |
| Mine | Character | 107 | 34 (107) | 34 | 0 | 23 | 26% | 2.6 | 34 (44) | 36 (36) | 41 (15) | 36 (57) | 36 (38) |
| Mine | Clean-up | 28 | 86 (28) | 61 | 25 | 28 | 54% | 3.0 | 121 (11) | 72 (13) | 28 (4) | 149 (17) | 0 (11) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 46 | 50% | 2.5 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 40 | 33 (40) | 17 | 16 | 45 | 32% | 2.6 | 29 (14) | 37 (19) | 32 (7) | 47 (19) | 22 (21) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 65 | 31 (65) | 16 | 15 | 33 | 23% | 2.9 | 7 (25) | 58 (32) | 15 (8) | 39 (38) | 20 (27) |
| Mine | Holder | 30 | 111 (30) | 2 | 108 | 25 | 40% | 2.7 | 60 (10) | 165 (16) | 17 (4) | 153 (19) | 35 (11) |
| Mine | Shooter | 36 | 65 (36) | 20 | 45 | 28 | 3% | 1.9 | 11 (12) | 116 (16) | 33 (8) | 88 (23) | 19 (13) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | War machine | 56 | 18 (56) | 18 | 0 | 39 | 5% | 1.6 | 21 (29) | 19 (21) | 0 (6) | 0 (12) | 23 (44) |
| Mine | Wizard | 16 | 16 (16) | 16 | 0 | 24 | 19% | 2.9 | 0 (5) | 46 (3) | 0 (4) | 21 (4) | 0 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 74 | 50 (74) | 5 | 45 | 49 | 51% | 2.8 | 58 (33) | 76 (17) | 17 (24) | 44 (54) | 64 (20) |
| Opponent | Character | 97 | 48 (97) | 46 | 2 | 20 | 31% | 2.7 | 49 (43) | 47 (37) | 48 (12) | 60 (50) | 37 (42) |
| Opponent | Clean-up | 15 | 41 (15) | 20 | 20 | 5 | 40% | 3.4 | 0 (7) | 73 (5) | 54 (3) | 34 (9) | 45 (6) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 55 | 31 (55) | 10 | 21 | 32 | 49% | 2.7 | 31 (20) | 39 (26) | 8 (9) | 45 (31) | 15 (24) |
| Opponent | Fragile | 11 | 0 (11) | 0 | 0 | 61 | 9% | 2.1 | 0 (1) | 0 (3) | 0 (3) | 0 (3) | 0 (4) |
| Opponent | Hammer | 66 | 19 (66) | 9 | 11 | 34 | 44% | 3.5 | 10 (23) | 30 (33) | 6 (10) | 11 (42) | 33 (24) |
| Opponent | Holder | 28 | 65 (28) | 15 | 49 | 16 | 61% | 4.3 | 47 (12) | 78 (15) | 0 (1) | 143 (12) | 6 (16) |
| Opponent | Shooter | 45 | 55 (45) | 18 | 37 | 25 | 4% | 1.8 | 41 (14) | 53 (24) | 87 (7) | 63 (25) | 46 (20) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 6 | 52 (6) | 52 | 0 | 50 | 0% | 1.5 | 88 (3) | 0 (3) | - | 88 (3) | 0 (3) |
| Opponent | Wizard | 19 | 6 (19) | 6 | 0 | 20 | 21% | 2.3 | 10 (11) | 0 (6) | 0 (2) | 0 (10) | 12 (9) |

### Charged fights: base-s1-882d875-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 91 | 80 | 1.2 | 1.6 | 64 | 27 | +36 | 0 of 5 | 4 of 5 | +56 | +6 |
| Mine | Chaos Dwarfs | 4 | 150 | 112 | 1.8 | 1.1 | 64 | 93 | -29 | 3 of 7 | 4 of 7 | -310 | +18 |
| Mine | Dwarfen Mountain Holds | 3 | 368 | 43 | 1.0 | 1.7 | 43 | 62 | -19 | 1 of 3 | 2 of 3 | -186 | +65 |
| Mine | Empire of Man | 5 | 137 | 75 | 0.8 | 1.0 | 94 | 0 | +94 | 1 of 4 | 2 of 4 | - | +94 |
| Mine | Grand Cathay | 4 | 275 | 141 | 2.8 | 1.3 | 51 | 34 | +17 | 2 of 11 | 10 of 11 | +60 | +0 |
| Mine | High Elf Realms | 4 | 213 | 88 | 2.8 | 1.0 | 32 | 13 | +19 | 3 of 11 | 8 of 11 | - | +19 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 708 | 3.0 | 1.0 | 236 | 0 | +236 | 1 of 3 | 3 of 3 | - | +236 |
| Mine | Lizardmen | 1 | 0 | 60 | 3.0 | 1.0 | 20 | 62 | -42 | 1 of 3 | 2 of 3 | - | -42 |
| Mine | Ogre Kingdoms | 2 | 28 | 292 | 3.0 | 1.2 | 98 | 21 | +77 | 3 of 6 | 2 of 5 | +350 | +22 |
| Mine | Skaven | 2 | 170 | 128 | 1.0 | 1.0 | 128 | 0 | +128 | 1 of 2 | 2 of 2 | - | +128 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 711 | 5.0 | 1.0 | 142 | 0 | +142 | 3 of 10 | 9 of 10 | - | +142 |
| Mine | Vampire Counts | 2 | 14 | 103 | 2.5 | 1.2 | 41 | 0 | +41 | 1 of 5 | 5 of 5 | +0 | +52 |
| Mine | Warriors of Chaos | 2 | 0 | 850 | 5.5 | 1.0 | 154 | 64 | +91 | 2 of 11 | 8 of 11 | - | +91 |
| **Mine** | all armies | 36 | 144 | 198 | 2.2 | 1.1 | 88 | 31 | +57 | 22 of 81 | 61 of 80 | +20 | +62 |
| Opponent | Empire of Man | 1 | 503 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 114 | 207 | 2.0 | 1.1 | 104 | 79 | +24 | 9 of 10 | 6 of 10 | +0 | +27 |
| Opponent | Lizardmen | 2 | 100 | 166 | 1.5 | 1.3 | 111 | 0 | +111 | 1 of 3 | 2 of 3 | +165 | +84 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 156 | 2.3 | 1.0 | 67 | 58 | +9 | 2 of 7 | 6 of 7 | - | +9 |
| Opponent | Skaven | 4 | 0 | 0 | 0.5 | 1.0 | 0 | 56 | -56 | 1 of 2 | 1 of 2 | - | -56 |
| Opponent | Tomb Kings of Khemri | 2 | 60 | 791 | 5.0 | 1.0 | 158 | 43 | +115 | 5 of 10 | 8 of 10 | - | +115 |
| Opponent | Vampire Counts | 6 | 21 | 307 | 4.0 | 1.1 | 77 | 25 | +52 | 13 of 24 | 14 of 24 | +240 | +43 |
| Opponent | Warriors of Chaos | 7 | 0 | 207 | 1.9 | 1.0 | 111 | 28 | +83 | 5 of 13 | 11 of 13 | - | +83 |
| Opponent | Wood Elf Realms | 6 | 48 | 319 | 3.2 | 1.1 | 101 | 61 | +40 | 14 of 19 | 13 of 19 | +0 | +42 |
| **Opponent** | all armies | 36 | 50 | 240 | 2.4 | 1.1 | 98 | 44 | +54 | 50 of 88 | 61 of 88 | +101 | +52 |

### Effective charges: base-s1-882d875-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net -85) | 0 | 2 (net +49) | 0 | 0 | 2 (net +84) | 0 | 40% (2 of 5) |
| Mine | Chaos Dwarfs | 7 | 0 | 1 (net +0) | 2 (net -106) | 0 | 2 (net +117) | 1 (net +115) | 1 | 33% (2 of 6) |
| Mine | Dwarfen Mountain Holds | 3 | 2 (net -28) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Empire of Man | 4 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 2 (net +188) | 0 | 25% (1 of 4) |
| Mine | Grand Cathay | 11 | 0 | 1 (net -379) | 1 (net +175) | 1 (net +0) | 4 (net +76) | 2 (net +0) | 2 | 11% (1 of 9) |
| Mine | High Elf Realms | 11 | 1 (net +0) | 0 | 1 (net +0) | 3 (net +39) | 1 (net -98) | 4 (net +47) | 1 | 10% (1 of 10) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 1 (net +522) | 1 (net +41) | 0 | 1 | 0% (0 of 2) |
| Mine | Lizardmen | 3 | 1 (net -185) | 0 | 0 | 1 (net +0) | 1 (net +60) | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 6 | 2 (net +0) | 0 | 1 (net +235) | 1 (net +350) | 0 | 0 | 2 | 25% (1 of 4) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 10 | 0 | 0 | 4 (net +146) | 2 (net +143) | 0 | 1 (net +116) | 3 | 57% (4 of 7) |
| Mine | Vampire Counts | 5 | 1 (net +99) | 0 | 0 | 3 (net +36) | 0 | 1 (net +0) | 0 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 11 | 1 (net +251) | 0 | 1 (net -82) | 0 | 3 (net +65) | 3 (net -42) | 3 | 12% (1 of 8) |
| Opponent | High Elf Realms | 10 | 2 (net -147) | 1 (net +583) | 0 | 1 (net +372) | 0 | 3 (net +0) | 3 | 0% (0 of 7) |
| Opponent | Lizardmen | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +84) | 1 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 7 | 1 (net -55) | 0 | 1 (net -350) | 1 (net +175) | 0 | 1 (net +175) | 3 | 25% (1 of 4) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 2 (net -56) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 10 | 2 (net +241) | 1 (net -431) | 1 (net +0) | 1 (net +145) | 1 (net +60) | 2 (net +342) | 2 | 12% (1 of 8) |
| Opponent | Vampire Counts | 24 | 8 (net -48) | 0 | 5 (net +97) | 4 (net +122) | 4 (net +93) | 3 (net +93) | 0 | 21% (5 of 24) |
| Opponent | Warriors of Chaos | 13 | 3 (net +0) | 0 | 0 | 1 (net +420) | 4 (net +17) | 4 (net +148) | 1 | 0% (0 of 12) |
| Opponent | Wood Elf Realms | 19 | 4 (net -64) | 0 | 2 (net +217) | 5 (net -56) | 0 | 3 (net +89) | 5 | 14% (2 of 14) |

### Charged fights, damage counted: base-s1-882d875-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 168 | 282 | +2 | 68 | 62 | +6 | +3.6 |
| Mine | 50-54% | 2 | 359 | 348 | -190 | 31 | 231 | -200 | -55.7 |
| Mine | Effective (55-75%) | 14 | 285 | 236 | +57 | 136 | 73 | +63 | +22.0 |
| Mine | 76-89% | 12 | 362 | 157 | +115 | 138 | 33 | +105 | +29.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 252 | 132 | +49 | 88 | 41 | +47 | +18.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 389 | 83 | +61 | 87 | 20 | +66 | +17.1 |
| Mine | No odds | 14 | 331 | 223 | +87 | 121 | 33 | +88 | +26.6 |
| Mine | All fights | 81 | 300 | 186 | +57 | 105 | 48 | +57 | +19.0 |
| Opponent | Long shot (under 50%) | 20 | 201 | 316 | -26 | 92 | 107 | -15 | -7.3 |
| Opponent | 50-54% | 2 | 468 | 406 | +76 | 374 | 243 | +131 | +28.0 |
| Opponent | Effective (55-75%) | 9 | 343 | 262 | +63 | 155 | 97 | +58 | +16.8 |
| Opponent | 76-89% | 15 | 453 | 252 | +81 | 184 | 88 | +95 | +21.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 403 | 220 | +120 | 158 | 18 | +140 | +34.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 423 | 90 | +56 | 111 | 41 | +71 | +16.7 |
| Opponent | No odds | 15 | 422 | 232 | +45 | 102 | 47 | +56 | +13.2 |
| Opponent | All fights | 88 | 366 | 245 | +54 | 138 | 71 | +67 | +18.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s1-882d875-p4 | move | 210 | 53 (25%) | 38 (18%) | 32 (15%) | 125 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

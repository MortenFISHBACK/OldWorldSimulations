# Doctrine scorecard: base-s2-882d875-p2

### Scorecard: base-s2-882d875-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 2 | Mine | no | 4 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 2 | Opponent | no | 0 | 4 | 4 | 2 | 0 | 0 | 0 | 768 |
| L0122 | 2 | 2 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 317 |
| L0122 | 2 | 2 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 2 | Mine | - | - | 1 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 2 | Opponent | - | - | - | 0 | 2 | 1 | 0 | 0 | 892 |
| L0222 | 6 | 2 | Mine | no | 0 | 3 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 2 | Opponent | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 72 |
| L0307 | 1 | 2 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 235 |
| L0307 | 1 | 2 | Opponent | no | 4 | 4 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0323 | 5 | 2 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 91 |
| L0323 | 5 | 2 | Opponent | yes | - | 2 | 0 | 5 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 2 | Mine | no | 0 | 5 | 2 | 2 | 0 | 0 | 0 | 65 |
| L0409 | 1 | 2 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 537 |
| L0425 | 5 | 2 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 2 | Opponent | yes | - | 2 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 2 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 167 |
| L0512 | 2 | 2 | Opponent | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 165 |
| L0528 | 6 | 2 | Mine | no | 15 | 6 | 1 | 2 | 0 | 0 | 0 | 445 |
| L0528 | 6 | 2 | Opponent | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 232 |
| L0616 | 4 | 2 | Mine | no | 0 | - | 1 | 2 | 1 | 0 | 0 | 964 |
| L0616 | 4 | 2 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0632 | 2 | 2 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 526 |
| L0632 | 2 | 2 | Opponent | - | - | 4 | 1 | 6 | 1 | 0 | 0 | 170 |
| L0721 | 1 | 2 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 45 |
| L0721 | 1 | 2 | Opponent | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 993 |
| L0810 | 6 | 2 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 310 |
| L0810 | 6 | 2 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 165 |
| L0827 | 5 | 2 | Mine | no | - | 4 | 2 | 2 | 1 | 0 | 0 | 506 |
| L0827 | 5 | 2 | Opponent | yes | - | 2 | 4 | 6 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 2 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 2 | Opponent | no | 5 | - | 1 | 2 | 1 | 0 | 0 | 111 |
| L0934 | 4 | 2 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 494 |
| L0934 | 4 | 2 | Opponent | no | 0 | 3 | 2 | 5 | 0 | 0 | 0 | 206 |
| L1026 | 6 | 2 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 2 | Opponent | no | 5 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 2 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1118 | 2 | 2 | Opponent | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 2 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1135 | 1 | 2 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 2 | Mine | no | 2 | 1 | 2 | 1 | 1 | 0 | 0 | 205 |
| L1228 | 4 | 2 | Opponent | yes | 6 | - | 0 | 2 | 0 | 0 | 0 | 41 |
| L1323 | 3 | 2 | Mine | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 2 | Opponent | no | 3 | 2 | 3 | 2 | 2 | 0 | 0 | 0 |
| L1418 | 2 | 2 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 177 |
| L1418 | 2 | 2 | Opponent | - | - | 5 | 2 | 1 | 0 | 0 | 0 | 34 |
| L1435 | 1 | 2 | Mine | no | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 2 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 2 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 432 |
| L1531 | 1 | 2 | Opponent | no | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L1629 | 3 | 2 | Mine | no | 2 | 3 | 0 | 0 | 0 | 0 | 0 | 100 |
| L1629 | 3 | 2 | Opponent | no | 11 | 1 | 5 | 2 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 2 | Mine | yes | - | - | 1 | 0 | 0 | 0 | 0 | 175 |
| L1727 | 5 | 2 | Opponent | yes | - | 2 | 7 | 7 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 2 | Mine | no | 7 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 2 | Opponent | yes | 2 | 2 | 2 | 5 | 0 | 0 | 0 | 190 |
| L1927 | 1 | 2 | Mine | no | 0 | 1 | 2 | 1 | 0 | 0 | 0 | 55 |
| L1927 | 1 | 2 | Opponent | yes | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 2 | Mine | yes | 2 | - | 0 | 1 | 2 | 0 | 0 | 682 |
| L2029 | 1 | 2 | Opponent | no | 0 | 2 | 7 | 2 | 1 | 0 | 0 | 0 |
| L2131 | 1 | 2 | Mine | no | 5 | - | 2 | 2 | 1 | 0 | 0 | 500 |
| L2131 | 1 | 2 | Opponent | no | 9 | 3 | 2 | 0 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 2 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 72 |
| L2235 | 3 | 2 | Opponent | no | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 2 | Mine | no | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 2 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 733 |
| L2535 | 3 | 2 | Mine | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 85 |
| L2535 | 3 | 2 | Opponent | no | 0 | 1 | 2 | 4 | 0 | 0 | 0 | 125 |
| L2735 | 5 | 2 | Mine | no | - | 4 | 5 | 3 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 2 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 250 |
| L3033 | 3 | 2 | Mine | no | 12 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 2 | Opponent | no | 0 | 1 | 3 | 3 | 0 | 0 | 0 | 387 |
| **Average** | | | Mine | 10% | 3.4 | 2.7 | 1.8 | 1.4 | 0.2 | 0.0 | 0.0 | 202.4 |
| **Average** | | | Opponent | 30% | 2.6 | 2.5 | 2.4 | 2.6 | 0.3 | 0.0 | 0.0 | 182.8 |

### KPIs: base-s2-882d875-p2

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (50 of 174) | 8% (14 of 166) | 19% (64 of 340) |
| Winner chose to follow up after the loser gave ground |  | 79% (34 of 43); on the table 81% | 80% (28 of 35); on the table 86% | 79% (62 of 78); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (4 of 5); on the table 80% | 86% (12 of 14); on the table 86% | 84% (16 of 19); on the table 84% |
| Winner chose to pursue after the loser fled |  | 57% (12 of 21); on the table 62% | 61% (11 of 18); on the table 78% | 59% (23 of 39); on the table 69% |
| Winner chose to follow up or pursue (all three) |  | 72% (50 of 69); on the table 75% | 76% (51 of 67); on the table 84% | 74% (101 of 136); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 36% (112 of 312) | 15% (23 of 150) | 29% (135 of 462) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (106 of 244) | 21% (23 of 110) | 36% (129 of 354) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (15 of 30) | 56% (28 of 50) | 54% (43 of 80) |
| Points that never fought | lower | 50% (35567 of 71583) | 55% (39751 of 71989) | 52% (75318 of 143572) |
|   infantry points that never fought | lower | 55% (8918 of 16324) | 77% (10840 of 14029) | 65% (19758 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (184 of 284) | 68% (201 of 297) | 66% (385 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.6 uses a game | 89% (16 of 18); 1.2 uses a game | 92% (35 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 44% (8 of 18); 0.4 uses a game | 100% (2 of 2); 0.1 uses a game | 50% (10 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 14% (1 of 7); 0.0 uses a game | 52% (14 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (36107 of 60231) | 61% (38434 of 63281) | 60% (74541 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.5 (46%) | 1.4 (40%) | 3.9 (43%) |
| MARCHED: its unit marched | 1.0 (18%) | 0.7 (19%) | 1.7 (18%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (4%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 0.9 (17%) | 0.5 (15%) | 1.5 (16%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.4 (8%) | 0.5 (15%) | 1.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (6%) | 0.1 (2%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.1 | 1.5 | 2.7 | 3.8 | 0.6 | 1.1 |
| not cast | 4.4 | 3.5 | 4.0 | 9.1 | 1.5 | 19.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.9 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.2 (62%) | 0.5 (13%) | 3.9 (43%) | 0.4 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (18%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.2 (7%) | 0.6 (16%) | 1.5 (16%) | 0.3 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (5%) | 0.2 (6%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.9 (20%) | 0.3 (9%) | 0.6 (14%) | 1.0 (11%) | 0.3 (18%) | 1.8 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.2 (7%) | 0.4 (10%) | 0.4 (4%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (4%) | 0.1 (1%) | 0.1 (1%) | 0.1 (9%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (57%) | 0.2 (6%) | 1.5 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 1.0 a game | 1.4 a game |
| stood (cast and not dispelled) | 72% (47 of 65) | 58% (21 of 36) | 67% (68 of 101) |
| the unit moved after it | 55% (26 of 47) | 38% (8 of 21) | 50% (34 of 68) |
| it charged on its next turn | 6% (3 of 47) | 5% (1 of 21) | 6% (4 of 68) |
| the enemy charged it first | 30% (14 of 47) | 5% (1 of 21) | 22% (15 of 68) |
| it fought by the end of its next turn | 13% (6 of 47) | 0% (0 of 21) | 9% (6 of 68) |
| it moved out of a charge the enemy had planned (not charged first) | 4% (2 of 47) | 0% (0 of 21) | 3% (2 of 68) |
| none of these (no charge, no fight, no charge escaped) | 60% (28 of 47) | 90% (19 of 21) | 69% (47 of 68) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (566 of 922) | 56% (462 of 830) | 59% (1028 of 1752) |
|   cavalry | 67% (56 of 83) | 65% (112 of 171) | 66% (168 of 254) |
|   character | 53% (57 of 108) | 33% (38 of 116) | 42% (95 of 224) |
|   chariot | 60% (64 of 106) | 63% (38 of 60) | 61% (102 of 166) |
|   infantry | 63% (172 of 274) | 53% (167 of 314) | 58% (339 of 588) |
|   monster | 43% (16 of 37) | 52% (23 of 44) | 48% (39 of 81) |
|   war machine | 64% (201 of 314) | 67% (84 of 125) | 65% (285 of 439) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (13%) | 1.3 (12%) | 2.6 (13%) |
| CHARGED: it charged | 0.8 (8%) | 1.4 (14%) | 2.2 (11%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.4 (4%) | 0.3 (3%) | 0.6 (3%) |
| MOVED: a war machine that moved | 2.1 (21%) | 0.6 (6%) | 2.7 (13%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.2 (23%) | 3.5 (35%) | 5.8 (29%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.4 (4%) | 1.0 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (20%) | 1.6 (15%) | 3.5 (18%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (2%) | 0.4 (2%) |
| OTHER BAR | 0.3 (3%) | 0.8 (8%) | 1.1 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.9 | 1.7 | 79% | 5.8 pts | 40 pts |
| character | 2.8 | 1.4 | 68% | 10.8 pts | 30 pts |
| chariot | 2.8 | 1.6 | 68% | 15.3 pts | 43 pts |
| infantry | 12.9 | 4.2 | 75% | 7.1 pts | 91 pts |
| monster | 1.2 | 0.4 | 84% | 7.4 pts | 9 pts |
| war machine | 7.9 | 5.8 | 64% | 23.3 pts | 185 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 4.1 | 3.5 |
| Charges that made contact a game | 2.1 | 2.9 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.61 declared, 0.39 contact (23 units) | 0.92 declared, 0.69 contact (13 units) | 0.72 declared, 0.50 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.38 contact (8 units) | 1.50 declared, 1.20 contact (10 units) | 1.17 declared, 0.83 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.34 declared, 0.25 contact (255 units) | 0.39 declared, 0.27 contact (307 units) | 0.37 declared, 0.26 contact (562 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (47 of 73) | 61% (11 of 18) | 58% (7 of 12) | 63% (65 of 103) |
| Character in a unit | 77% (34 of 44) | 73% (16 of 22) | 0% (0 of 1) | 75% (50 of 67) |
| Character on its own | 86% (24 of 28) | 59% (19 of 32) | 38% (25 of 65) | 54% (68 of 125) |
| Chariot | 71% (12 of 17) | 85% (11 of 13) | - | 77% (23 of 30) |
| Infantry | 68% (64 of 94) | 62% (21 of 34) | 33% (1 of 3) | 66% (86 of 131) |
| Monster | 62% (18 of 29) | 78% (7 of 9) | - | 66% (25 of 38) |
| Monstrous | 79% (11 of 14) | 71% (10 of 14) | - | 75% (21 of 28) |
| War Machines | 81% (46 of 57) | 50% (1 of 2) | - | 80% (47 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (4 of 4); on the table 100% | 34% (33 of 96) | 41% | 55% (12 of 22) | 100% (6 of 6); 5.5 uses a game | 100% (2 of 2); 1.0 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 83% (5 of 6); on the table 83% | 42% (10 of 24) | 56% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 6 | 71% (5 of 7); on the table 86% | - | 81% | 76% (41 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 56% (5 of 9); on the table 56% | 58% (21 of 36) | 54% | 72% (55 of 76) | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 79% (15 of 19); on the table 79% | 16% (22 of 138) | 56% | 56% (30 of 54) | 86% (12 of 14); 5.2 uses a game | 50% (1 of 2); 0.2 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 75% (6 of 8); on the table 75% | 28% (5 of 18) | 44% | 48% (16 of 33) | 100% (3 of 3); 1.2 uses a game | 36% (5 of 14); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (6 of 6); on the table 100% | - | 62% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 61% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | - | 0% (0 of 6) | 63% | 75% (21 of 28) | 100% (4 of 4); 3.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 12% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 55% (6 of 11); on the table 91% | 46% (11 of 24) | 41% | 60% (15 of 25) | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 5 | 62% (10 of 16); on the table 62% | 6% (1 of 18) | 51% | 56% (14 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 40% (2 of 5); on the table 40% | 27% (16 of 60) | 44% | 76% (41 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 74% (17 of 23); on the table 83% | 33% (8 of 24) | 45% | 55% (40 of 73) | 100% (2 of 2); 1.1 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 89% (17 of 19); on the table 89% | 17% (1 of 6) | 54% | 74% (58 of 78) | 86% (6 of 7); 2.1 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s2-882d875-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (37) | 51% (25) | 51% (62) |
| ...free all their last turn and able to turn (per game) | 0.89 | 0.47 | 1.36 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.14 | 0.22 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.36 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.03 | 0.03 | 0.06 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 0.14 | 0.25 |

### Quality by phase: base-s2-882d875-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 62% (56 of 90) | 47% (64 of 136) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (148 of 413) | 38% (92 of 240) |
| Strategy | Support requests answered (helper made contact too) | 14% (1 of 7) | 35% (6 of 17) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 17% (1 of 6) | 65% (13 of 20) |
| Strategy | Joined characters whose unit fought | 38% (23 of 61) | 26% (11 of 43) |
| Strategy | Lone characters that fought | 62% (52 of 84) | 55% (44 of 80) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.4 | 2.6 |
| Movement | Points that never moved of their own | 202.4 | 182.8 |
| Movement | Fights charged into per game | 2.1 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 63, net +54 | 19 of 84, net +54 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 63, net +73 | 5 of 84, net +150 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 63, net +72 | 8 of 84, net +80 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 63, net +127 | 30 of 84, net +196 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.8 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (198 of 389) | 46% (186 of 407) |
| Shooting | Points destroyed by shooting units | 54.8 | 42.8 |
| Shooting | War machine shots | 5.6 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (131 of 201) | 49% (41 of 84) |
| Shooting | Points destroyed by war machines | 66.2 | 52.3 |
| Magic | Magic missiles cast | 1.7 | 0.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (21 of 62) | 53% (8 of 15) |
| Magic | Wounds caused by magic missiles | 2.7 | 1.3 |
| Magic | Wounds caused by other spells | 0.4 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 32.4 | 33.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.2 / 0.3 / 0.1 | 1.0 / 0.6 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 252.8 | 304.2 |
| Combat | Points run down | 32.4 | 48.1 |
| Combat | Net points per charged fight, damage counted | +84 | +125 |
| Combat | Net per 100 charger points, damage counted | +33.8 | +38.1 |
| Combat | First round won (charged fights) | 73% | 71% |
| Combat | Net points per charged fight | +86 | +124 |
| Combat | Net points per supported fight / lone fight | +38 / +88 | +133 / +124 |
| Combat | Charged fights on a top-3 enemy unit | 18 of 74 | 48 of 95 |
| Game | Points lost | 622.9 | 523.3 |
| Game | VP from objectives | 576.7 | 683.6 |
| Game | Lone holders (player turns) | 3.4 | 2.6 |

- Mine won / drew / lost: 12 / 5 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -185 VP
- The side that went first won 14 of 31 games with a winner
- Points traded per game (both sides' losses): 1146
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: base-s2-882d875-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 3.5 |
| AFTERMATH IN POINTS | 0.2 | +32.1 | 0.0 | 15.6 | 0.2 | +12.7 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.1 | +5.4 | 0.0 | 0.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 17.9 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.5 | +50.2 | 0.0 | 161.2 | 21.6 | +400.4 | 0.0 | 307.9 |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 19.2 | 0.4 | +0.0 | 0.0 | 8.1 |
| BACKUP TARGETS | 0.2 | +0.6 | 0.0 | 1.4 | 0.2 | +0.9 | 0.0 | 0.0 |
| BEST PRIZE | 0.0 | -3.1 | 0.0 | 0.0 | 0.1 | -5.1 | 16.4 | 0.8 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | -18.1 | 15.2 | 3.2 | 0.2 | -24.7 | 48.4 | 0.0 |
| BOMBING RUN | 0.1 | +4.1 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 3.4 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 78.4 | 6.4 | 0.1 | +0.0 | 15.6 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +179.1 | 335.2 | 55.1 | 2.3 | +103.8 | 185.4 | 44.6 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.6 | +36.2 | 86.6 | 77.2 | 0.9 | +17.3 | 69.1 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +29.1 | 26.9 | 17.6 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.2 | +0.0 | 0.0 | 70.4 | 0.6 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +2.9 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.5 | +13.1 | 0.0 | 7.7 | 0.8 | +34.0 | 0.0 | 7.5 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | -0.4 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -0.2 | 2.1 | 3.1 | 0.1 | -2.9 | 6.3 | 2.5 |
| CHARACTER GUNS | 1.4 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.1 | +10.9 | 16.1 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.4 | -678.2 | 0.0 | 221.4 | 13.9 | -746.2 | 0.0 | 412.4 |
| CHARGE NOT DECLARED | 0.0 | +0.0 | 0.0 | 4.8 | - | - | - | - |
| CHARGE NOW FIRST | 1.3 | +0.0 | 105.9 | 12.3 | 2.3 | +0.0 | 296.7 | 60.4 |
| CHARGER SLAIN LOST | 0.2 | -3.2 | 13.0 | 6.2 | 0.2 | -6.4 | 17.2 | 4.2 |
| COMBAT PIVOT | 0.2 | +0.0 | 4.7 | 27.1 | 0.3 | +0.0 | 24.8 | 11.5 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.6 | +233.2 | 119.7 | 86.4 | 0.9 | +73.6 | 5.3 | 12.9 |
| COVER ONCE | 7.2 | -546.9 | 0.0 | 104.2 | 4.2 | -239.0 | 0.0 | 89.3 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 39.7 | 0.0 | 0.1 | +0.0 | 8.8 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | -0.9 | 0.0 | 5.7 | - | - | - | - |
| DENIED BY THE FIGHT | 0.5 | -1.9 | 26.2 | 8.8 | 1.1 | -11.4 | 144.0 | 30.1 |
| DEPLOY BY FIGURES | 8.1 | +11.4 | 0.0 | 13.4 | 7.8 | +51.2 | 0.0 | 22.4 |
| EDGE GIVE GROUND | 0.1 | +5.8 | 2.0 | 1.4 | 0.1 | +5.1 | 23.5 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.9 | +11.4 | 141.0 | 25.1 | 3.0 | +5.2 | 350.2 | 48.7 |
| FALLBACK BY WORTH | 0.3 | +3.0 | 0.0 | 1.7 | 0.2 | +0.5 | 0.0 | 0.0 |
| FALLS SHORT | 6.9 | +113.1 | 0.0 | 73.4 | 15.2 | +198.2 | 0.0 | 223.1 |
| FEATURE BUFFS | 2.4 | +59.7 | 0.0 | 44.4 | 0.9 | +17.8 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.1 | +1.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.9 | +21.8 | 42.4 | 11.4 | 1.0 | +17.7 | 130.4 | 24.6 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.2 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 6.4 | 0.2 | +0.0 | 17.7 | 0.0 |
| FIVE ACTION | 89.6 | +5472.4 | 1381.6 | 1154.2 | 95.0 | +5320.0 | 1171.4 | 1109.8 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 144.4 | 3.7 | +0.0 | 0.0 | 70.1 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.8 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.5 | +75.4 | 0.0 | 10.3 | 0.7 | +92.5 | 0.0 | 9.4 |
| FOUR ROUNDS | 2.8 | +170.3 | 199.9 | 40.6 | 4.0 | +308.9 | 433.7 | 84.4 |
| FRIEND CHARGES FIRST | 0.1 | -3.5 | 0.0 | 0.0 | 0.0 | -2.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -23.8 | 0.0 | 1.5 | 0.5 | -16.8 | 0.0 | 3.5 |
| FRIENDS SHOTS CHECKED | 0.2 | +8.7 | 0.0 | 10.7 | 0.1 | +2.6 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -2.7 | 2.0 | 4.6 | 0.2 | -3.5 | 20.2 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 2.9 | 0.0 | 0.0 | -0.2 | 6.3 | 2.5 |
| GROUND FLIERS | 0.0 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.4 | +20.2 | 15.7 | 16.5 | 0.7 | +19.3 | 30.0 | 5.1 |
| GUN MASK | 0.8 | +19.8 | 0.0 | 22.1 | 0.6 | +12.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.9 | +0.0 | 0.0 | 12.3 | 1.8 | +0.0 | 0.0 | 15.5 |
| HE SHOOTS OR CHARGES | 2.3 | +0.0 | 0.0 | 56.1 | 3.6 | +0.0 | 0.0 | 76.8 |
| HELPER UNSEEN | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +9.2 | 6.3 | 4.0 | 0.4 | +18.3 | 30.3 | 7.9 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 36.5 | 5.1 | +0.0 | 0.0 | 75.2 |
| HIS FIGHT TOGETHER | 2.6 | -57.7 | 0.0 | 79.8 | 1.8 | -29.2 | 0.0 | 57.9 |
| HIS LEGAL MOVES | 3.9 | +0.0 | 0.0 | 126.7 | 4.6 | +0.0 | 0.0 | 82.1 |
| HIS MOVE AND SHOT | 3.0 | -60.1 | 0.0 | 67.4 | 3.8 | -80.0 | 0.0 | 118.5 |
| HIS MOVE AS HE DECIDES | 41.4 | +15.8 | 553.7 | 0.0 | 34.1 | +12.8 | 556.8 | 0.0 |
| HIS MOVE WHY | 35.0 | +0.0 | 0.0 | 410.8 | 41.2 | +0.0 | 0.0 | 453.3 |
| HIS ONE MOVE | 17.1 | +33.6 | 0.0 | 91.0 | 19.2 | +24.3 | 9.1 | 75.1 |
| HIS ONE QUARTER | 4.9 | +0.0 | 0.0 | 46.3 | 3.7 | +0.0 | 0.0 | 21.5 |
| HIS OWN BEST MOVE | 1.4 | +0.0 | 0.0 | 71.0 | 1.5 | +0.0 | 0.0 | 28.6 |
| HIS RANDOM MOVE | 5.9 | +0.0 | 0.0 | 105.2 | 3.2 | +0.0 | 0.0 | 46.2 |
| HIS SHOT LIST | 36.6 | +1346.2 | 0.0 | 380.4 | 49.8 | +2252.7 | 0.0 | 624.9 |
| HIS TURN DENIED | 1.4 | +29.5 | 89.6 | 27.2 | 2.1 | +83.7 | 255.0 | 63.2 |
| HOLD ODDS | 17.5 | +0.0 | 0.0 | 168.4 | 16.1 | +0.0 | 0.0 | 67.4 |
| HOLDER ASSIGNMENT | 9.9 | +1006.3 | 0.0 | 88.2 | 10.0 | +879.1 | 0.0 | 48.3 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.5 | -84.9 | 189.9 | 28.1 | 3.5 | -165.7 | 404.0 | 73.6 |
| HUNT IN PAIRS | 0.1 | +3.8 | 0.0 | 0.0 | 0.3 | +16.7 | 0.0 | 6.0 |
| IDLE COST | 4.3 | -54.5 | 0.0 | 54.2 | 11.8 | -165.7 | 0.0 | 150.2 |
| JOINT CHARGE NOW | 0.5 | -7.6 | 36.5 | 0.0 | 0.8 | +96.2 | 120.6 | 36.2 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -1.0 | 0.0 | 0.0 |
| JOINT ON THE TABLE | 0.1 | +1.7 | 3.9 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 20.9 | 3.3 | +0.0 | 0.0 | 24.0 |
| LANE BY FIGURES | 0.6 | +28.9 | 0.0 | 0.0 | 1.0 | +60.5 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.4 | +0.0 | 208.3 | 245.7 | 5.1 | +0.0 | 239.7 | 201.9 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +41.7 | 0.0 | 0.0 | 0.3 | +22.8 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.6 | 12.7 | 6.3 | 0.2 | +4.2 | 10.5 | 1.4 |
| LOST AFTER ESCAPE | 1.6 | +1.9 | 97.6 | 23.2 | 2.1 | +2.5 | 261.9 | 31.2 |
| LOST CHARGE | 0.1 | -0.4 | 13.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -12.6 | 0.0 | 4.0 | 0.3 | -30.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +2.7 | 0.0 | 4.9 |
| MANOEUVRE | 0.8 | +10.4 | 0.0 | 22.4 | 0.7 | +1.6 | 0.0 | 9.8 |
| MARCH AT ESCAPER | 0.2 | +3.6 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +12.8 | 0.0 | 0.0 | 0.1 | +11.2 | 0.0 | 9.9 |
| MARCH CHECK | 0.8 | +34.5 | 0.0 | 9.3 | 0.8 | +41.8 | 0.0 | 19.0 |
| MARCH OF THE TABLE | 0.1 | +5.6 | 0.0 | 0.0 | 0.2 | +7.3 | 0.0 | 4.7 |
| MARCH OVER CASTS | 0.6 | +21.1 | 0.0 | 13.1 | 0.5 | +28.9 | 0.0 | 14.3 |
| MARCH WHEELS ONLY | 0.9 | +0.0 | 0.0 | 2.0 | 1.3 | +0.0 | 0.0 | 9.3 |
| MAX FOR POSITIONING | 2.4 | +43.3 | 0.0 | 44.2 | 3.0 | +66.3 | 0.0 | 29.6 |
| MISSILES IN THE MOVE | 4.6 | +114.2 | 0.0 | 121.0 | 2.8 | +50.8 | 0.0 | 43.8 |
| MISSILES NEXT TURN | 5.2 | +76.1 | 0.0 | 124.8 | 3.7 | +41.6 | 0.0 | 92.2 |
| MISSILES ON ONE TARGET | 0.2 | -5.2 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | 0.3 | +68.4 | 0.0 | 1.7 | 0.4 | +174.2 | 0.0 | 3.3 |
| MOVE ORDER | 1.4 | +0.0 | 19.6 | 18.2 | 2.1 | +0.0 | 26.6 | 25.0 |
| MOVE SPELL IN RANGE | 0.2 | +6.1 | 0.0 | 9.3 | 0.1 | +3.2 | 0.0 | 10.6 |
| MOVE SPELL OUT OF RANGE | 0.2 | -8.5 | 0.0 | 0.0 | 0.4 | -14.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 78.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +448.7 | 0.0 | 115.8 | 6.5 | +707.1 | 0.0 | 73.4 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.2 | +291.4 | 0.0 | 113.5 | 7.1 | +308.6 | 0.0 | 81.9 |
| NEXT CHARGE BY LIST | 5.6 | -216.4 | 26.6 | 63.2 | 6.6 | -321.7 | 21.0 | 126.6 |
| NEXT OBJECTIVE NEARER | 0.1 | -3.2 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.2 | -66.4 | 179.8 | 31.0 | 3.3 | -168.3 | 400.4 | 66.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 5.3 | 0.8 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +1.1 | 0.0 | 2.9 |
| NOT TURNED | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 43.5 | 0.6 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 3.6 | -128.2 | 8.9 | 21.6 | 3.8 | -106.8 | 1.2 | 77.1 |
| ONE CHARGE A CHARGER | 5.9 | +0.0 | 0.0 | 145.9 | 4.0 | +0.0 | 0.0 | 123.2 |
| ONE FIGHT FORMULA | 4.6 | -78.4 | 0.0 | 120.7 | 5.0 | -113.2 | 0.0 | 133.5 |
| ONE OBJECTIVE FORMULA | 4.3 | +16.5 | 0.0 | 51.5 | 4.3 | +20.8 | 0.0 | 19.4 |
| ONE PROMISE A TARGET | 0.1 | +1.3 | 0.0 | 1.4 | 0.1 | -14.2 | 0.0 | 5.4 |
| ONE ROUTE | 0.9 | +0.0 | 0.0 | 2.0 | 1.3 | +0.0 | 0.0 | 9.3 |
| ONE TARGET A SHOOTER | 28.1 | +664.1 | 0.0 | 338.0 | 33.9 | +891.8 | 0.0 | 344.0 |
| OPENS A LANE | 0.2 | +0.3 | 8.2 | 0.0 | 0.1 | +0.9 | 3.8 | 0.0 |
| OPENS UP | 0.2 | +14.3 | 9.3 | 0.0 | 0.3 | +27.1 | 12.6 | 0.0 |
| OVERRUNS AWAY | 0.3 | +9.0 | 20.8 | 1.4 | 0.6 | +34.3 | 81.2 | 10.6 |
| OWN CAST FIRST | - | - | - | - | 0.1 | -0.6 | 0.0 | 0.0 |
| PATHS CROSS | 0.5 | +31.7 | 0.0 | 0.0 | 0.3 | +3.7 | 0.0 | 3.2 |
| PERIAPT WORTH | 0.1 | +6.2 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -5.9 | 0.0 | 7.4 | 0.0 | -1.4 | 0.0 | 0.0 |
| PLAN RESULT | 41.6 | +771.0 | 559.4 | 877.2 | 44.7 | +587.2 | 522.5 | 717.9 |
| PROMISE BELOW ZERO | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 15.5 |
| PROMISE BY ITS OWN SUM | 7.2 | -202.9 | 0.0 | 100.4 | 8.1 | -211.6 | 0.0 | 13.8 |
| PROMISE IN STEPS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.5 | -0.2 | 0.0 | 15.8 | 0.4 | -0.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.5 | -24.0 | 0.0 | 0.0 | 0.4 | -5.1 | 0.0 | 3.5 |
| PROMISE SHOT AWAY | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| PURSUES BIG PREY | 0.0 | -0.4 | 0.0 | 0.0 | 0.1 | -10.5 | 0.0 | 0.0 |
| QUARTER ODDS | 16.1 | +1579.9 | 148.0 | 273.0 | 19.1 | +1962.3 | 517.3 | 134.8 |
| RANDOM MOVE BY FIGURES | 0.8 | +14.7 | 0.0 | 21.5 | 1.4 | +21.3 | 0.0 | 44.4 |
| REAL GROUND | 0.9 | +0.0 | 0.0 | 2.0 | 1.3 | +0.0 | 0.0 | 9.3 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -8.8 | 0.0 | 7.9 | 0.7 | -13.1 | 0.0 | 5.8 |
| REDIRECT COUNTER | 1.7 | +76.2 | 0.0 | 17.9 | 2.4 | +146.4 | 0.0 | 19.9 |
| REDIRECT WEIGHED | 0.1 | +1.7 | 3.5 | 5.2 | 0.2 | +0.4 | 13.1 | 10.6 |
| REFORMS TO MEET IT | 1.1 | -13.6 | 0.0 | 33.4 | 1.2 | -22.2 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 3.1 | 0.2 | +0.0 | 0.0 | 26.4 |
| RESERVE FALL BACK | 0.3 | +10.5 | 0.0 | 14.3 | 1.0 | +50.0 | 0.0 | 10.5 |
| RESTRAINS TO SHOOT | 0.1 | +1.7 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| RISK BY ARC | 1.8 | +44.0 | 124.5 | 32.2 | 2.9 | -15.0 | 335.7 | 44.0 |
| RISK BY HIS FIGURE | 22.7 | -558.9 | 0.0 | 408.5 | 20.2 | -425.8 | 0.0 | 409.6 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 13.8 |
| ROUNDS AFTER TERROR | 0.5 | -8.3 | 45.6 | 1.4 | 1.4 | -32.1 | 221.3 | 67.3 |
| RUN DOWN | 1.8 | -16.2 | 150.6 | 25.6 | 2.8 | -31.7 | 329.6 | 67.1 |
| SAFER THAN THE JOB | 0.0 | +0.6 | 0.0 | 0.0 | 0.0 | +1.9 | 0.0 | 5.3 |
| SAME CHARGE LATER | - | - | - | - | 0.0 | -3.7 | 4.2 | 0.0 |
| SCOUT SPOT | 0.3 | +0.3 | 0.0 | 0.0 | 0.5 | +2.0 | 0.0 | 2.8 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 2.8 |
| SCREEN BY WHAT IT SAVES | 0.2 | -19.6 | 0.0 | 1.5 | 0.8 | -43.3 | 0.0 | 3.8 |
| SEARCH SPOT | 0.4 | +4.2 | 0.0 | 1.4 | 0.4 | +6.3 | 0.0 | 2.1 |
| SECOND LOOK | 0.2 | +28.3 | 15.3 | 1.7 | 0.2 | +13.5 | 6.3 | 0.0 |
| SELF MOVE SPELL | 0.3 | -0.3 | 0.0 | 9.1 | - | - | - | - |
| SET UP BY THE SET | 1.2 | +21.7 | 16.0 | 27.8 | 1.1 | -2.9 | 0.8 | 15.4 |
| SET UP TOGETHER | - | - | - | - | 0.6 | +4.6 | 0.0 | 11.4 |
| SET-UP ANY TARGET | 0.1 | +15.8 | 0.0 | 0.0 | 0.1 | +6.9 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +6.3 | 0.0 | 13.9 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.1 | -0.4 | 0.0 | 1.5 | 0.1 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.4 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.6 | +69.6 | 54.6 | 83.0 | 2.2 | +88.2 | 50.4 | 71.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -9.7 | 31.5 | 3.2 | 0.2 | -5.9 | 29.4 | 0.0 |
| SHOT RISK POINTS | 18.1 | +42.8 | 0.0 | 179.6 | 25.2 | -170.9 | 0.0 | 487.2 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 2.2 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.2 | +794.3 | 0.0 | 205.3 | 14.5 | +485.4 | 0.0 | 173.5 |
| SPELL SETS UP CHARGE | 0.2 | +49.0 | 0.0 | 0.0 | 0.2 | +51.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +20.1 | 64.4 | 66.4 | 1.3 | +19.6 | 42.3 | 42.3 |
| SPELLS IN THE FIGHT | 0.4 | -1.4 | 28.9 | 1.4 | 0.6 | -4.8 | 98.6 | 0.0 |
| SPOT AS THE GAME MOVES | 7.5 | +0.0 | 0.0 | 142.1 | 9.0 | +0.0 | 0.0 | 148.6 |
| STAND AND SHOOT | 0.6 | -4.8 | 66.0 | 9.2 | 0.6 | -7.6 | 65.0 | 2.2 |
| STANDS FOR A REASON | 0.2 | +0.0 | 2.1 | 0.0 | 2.3 | +0.0 | 7.8 | 10.9 |
| STANDS STILL | 43.8 | +0.0 | 1181.7 | 497.4 | 36.7 | +0.0 | 737.6 | 368.0 |
| STAY WORTH | 25.2 | +66.4 | 809.4 | 270.2 | 18.2 | +130.9 | 331.2 | 229.9 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| STUPIDITY NEXT TURN | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.3 | +779.4 | 0.0 | 101.9 | 7.5 | +408.0 | 0.0 | 35.2 |
| SUPPORT NARROWED | 0.5 | +0.0 | 27.0 | 4.1 | 0.3 | +0.0 | 31.1 | 5.4 |
| SUPPORT WORKED OUT | 9.3 | +779.4 | 0.0 | 101.9 | 7.5 | +408.0 | 0.0 | 35.2 |
| SURE REACH TOGETHER | 0.2 | +1.2 | 0.0 | 3.4 | 0.4 | +2.9 | 0.0 | 8.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.9 | +0.0 | 0.0 | 17.9 | 1.3 | +0.0 | 0.0 | 4.5 |
| THE PROMISE ADDS | 0.1 | -3.2 | 0.0 | 0.0 | 0.1 | -10.6 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 29.1 | +0.0 | 0.0 | 358.2 | 37.4 | +0.0 | 0.0 | 368.9 |
| TIED UP BY THE SUM | 0.7 | +61.9 | 44.2 | 8.1 | 0.8 | +87.3 | 70.3 | 5.2 |
| TIME ON OUR SIDE | 31.7 | +356.6 | 39.3 | 353.6 | 17.2 | +151.8 | 8.4 | 126.0 |
| WAITS AGAIN | 1.4 | +0.0 | 0.0 | 21.1 | 1.5 | +0.0 | 0.0 | 1.2 |
| WALKS ON ITS ROUTE | 0.1 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +9.5 | 20.8 | 1.8 | 0.0 | +2.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 8.6 | 23.1 | 0.3 | +0.0 | 29.4 | 5.1 |
| WHAT THE JOINER ADDS | 0.2 | -15.1 | 43.6 | 0.0 | 0.1 | -2.8 | 18.4 | 0.0 |
| WHO GETS IN | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | -7.0 | 16.9 | 0.0 |
| WHO HITS BACK | 0.2 | +42.1 | 0.0 | 13.1 | 0.3 | +43.9 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +2.5 | 21.8 | 0.0 | 0.1 | +2.4 | 14.3 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +6.4 | 11.5 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| WIDER SPREAD | 1.8 | -5.2 | 125.2 | 31.6 | 2.7 | -9.2 | 293.4 | 39.8 |
| WOUNDS ON THE RANKS | 2.9 | +126.3 | 0.0 | 26.8 | 2.7 | +203.0 | 0.0 | 55.3 |

### Rule changes: base-s2-882d875-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2720 | 2720 | 1691 | 46.97 | +0 | +0.0 |
| HIS MOVE WHY | 2742 | 2742 | 1534 | 42.61 | +0 | +0.0 |
| ARMY TABLE | 1372 | 1372 | 927 | 25.75 | +14470 | +15.6 |
| HIS SHOT LIST | 3111 | 2975 | 772 | 21.44 | +16138 | +20.9 |
| HOLDER ASSIGNMENT | 715 | 715 | 672 | 18.67 | +42289 | +62.9 |
| ONE TARGET A SHOOTER | 2232 | 2130 | 457 | 12.69 | +4823 | +10.6 |
| LEGAL CHARGES ONLY | 343 | 343 | 343 | 9.53 | +0 | +0.0 |
| DEPLOY BY FIGURES | 574 | 574 | 339 | 9.42 | +4769 | +14.1 |
| HIS ONE MOVE | 1307 | 1263 | 279 | 7.75 | +22 | +0.1 |
| FIVE ACTION | 6643 | 6421 | 269 | 7.47 | +16189 | +60.2 |
| OFF BEST | 268 | 268 | 268 | 7.44 | -8460 | -31.6 |
| THE TABLE AGAIN | 432 | 432 | 265 | 7.36 | +0 | +0.0 |
| TIME ON OUR SIDE | 1761 | 1616 | 242 | 6.72 | +806 | +3.3 |
| SUPPORT ADDS | 607 | 591 | 211 | 5.86 | +10523 | +49.9 |
| SUPPORT WORKED OUT | 607 | 591 | 211 | 5.86 | +10523 | +49.9 |
| MOVE TO CHARGE COMPUTED | 425 | 359 | 207 | 5.75 | +10772 | +52.0 |
| PROMISE BY ITS OWN SUM | 550 | 550 | 203 | 5.64 | -14921 | -73.5 |
| SHOT RISK POINTS | 1561 | 1489 | 186 | 5.17 | +6364 | +34.2 |
| QUARTER ODDS | 1268 | 1200 | 142 | 3.94 | +12585 | +88.6 |
| HARD STAY DROPPED | 131 | 131 | 131 | 3.64 | +0 | +0.0 |
| MOVE ORDER | 128 | 128 | 128 | 3.56 | +0 | +0.0 |
| FOUR ROUNDS | 244 | 233 | 101 | 2.81 | +4524 | +44.8 |
| SHOOTS FROM THE BEST SPOT | 173 | 173 | 96 | 2.67 | +1517 | +15.8 |
| IDLE COST | 579 | 456 | 72 | 2.00 | +739 | +10.3 |
| COVER ONCE | 408 | 312 | 67 | 1.86 | +1813 | +27.1 |
| ARTILLERY RE-ROLL WEIGHED | 66 | 66 | 66 | 1.83 | +0 | +0.0 |
| ADVANCE LANE KEPT | 65 | 65 | 65 | 1.81 | +0 | +0.0 |
| CHARGE LOSSES | 914 | 864 | 61 | 1.69 | +5353 | +87.8 |
| CAST JOB | 91 | 91 | 60 | 1.67 | +632 | +10.5 |
| CANNON SIGHT KEPT | 59 | 59 | 59 | 1.64 | +0 | +0.0 |
| LANE BY FIGURES | 59 | 59 | 59 | 1.64 | +3219 | +54.6 |
| SHOTS IN THE MOVE | 1142 | 934 | 51 | 1.42 | +2330 | +45.7 |
| CANNON PLANNED TARGET | 270 | 270 | 49 | 1.36 | +55 | +1.1 |
| MAX FOR POSITIONING | 193 | 175 | 48 | 1.33 | +159 | +3.3 |
| JOINT CHARGE NOW | 47 | 47 | 47 | 1.31 | +3190 | +67.9 |
| RESERVE FALL BACK | 47 | 47 | 47 | 1.31 | +2177 | +46.3 |
| FALLS SHORT | 797 | 678 | 45 | 1.25 | +363 | +8.1 |
| FOLLOW UP WEIGHED | 44 | 44 | 44 | 1.22 | +6043 | +137.3 |
| MARCH CHECK | 58 | 57 | 44 | 1.22 | +902 | +20.5 |
| RANDOM MOVE BY FIGURES | 80 | 80 | 43 | 1.19 | +1296 | +30.1 |
| HOLDS AMBUSHERS | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| RISK BY ARC | 170 | 164 | 41 | 1.14 | +969 | +23.6 |
| RISK BY HIS FIGURE | 1547 | 1477 | 41 | 1.14 | +3318 | +80.9 |
| STAY WORTH | 1564 | 1443 | 40 | 1.11 | +530 | +13.2 |
| TIED UP BY THE SUM | 52 | 50 | 40 | 1.11 | +1368 | +34.2 |
| CHAFF IN THE MOVE | 48 | 46 | 37 | 1.03 | +94 | +2.5 |
| SET UP BY THE SET | 85 | 82 | 34 | 0.94 | +2373 | +69.8 |
| HIS TURN DENIED | 125 | 123 | 33 | 0.92 | +947 | +28.7 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2322 | +70.4 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CHARGE NOW FIRST | 131 | 131 | 30 | 0.83 | -1706 | -56.9 |
| NEXT CHARGE BY LIST | 439 | 405 | 30 | 0.83 | +727 | +24.2 |
| PATHS CROSS | 29 | 29 | 29 | 0.81 | +1277 | +44.0 |
| SHOTS AFTER THE MOVES | 197 | 197 | 28 | 0.78 | +0 | +0.0 |
| MODEL FACING | 27 | 27 | 27 | 0.75 | +8735 | +323.5 |
| REDIRECT COUNTER | 148 | 125 | 27 | 0.75 | +1536 | +56.9 |
| SHOOTERS IN TWO RANKS | 27 | 27 | 27 | 0.75 | +58 | +2.1 |
| WOUNDS ON THE RANKS | 204 | 199 | 27 | 0.75 | +1793 | +66.4 |
| MISSILES IN THE MOVE | 265 | 187 | 24 | 0.67 | +514 | +21.4 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +2399 | +119.9 |
| NEARER NOT NEEDED | 515 | 501 | 19 | 0.53 | +664 | +34.9 |
| CHAFF PASSED | 18 | 18 | 18 | 0.50 | -14 | -0.8 |
| COMBAT PIVOT | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| MARCH BY THE SUM | 17 | 17 | 17 | 0.47 | +864 | +50.8 |
| SECOND LOOK | 16 | 16 | 16 | 0.44 | +1505 | +94.1 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| AFTERMATH IN POINTS | 14 | 14 | 14 | 0.39 | +1610 | +115.0 |
| FEATURE BUFFS | 120 | 118 | 14 | 0.39 | +307 | +21.9 |
| FIRE IN ORDER | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| SEARCH SPOT | 28 | 28 | 14 | 0.39 | +378 | +27.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| CASTING BLOCK | 15 | 15 | 13 | 0.36 | +305 | +23.5 |
| HIS FIGHT TOGETHER | 158 | 152 | 13 | 0.36 | +286 | +22.0 |
| MANOEUVRE | 51 | 51 | 12 | 0.33 | +558 | +46.5 |
| REDIRECT WEIGHED | 12 | 12 | 12 | 0.33 | +862 | +71.8 |
| SURE REACH TOGETHER | 25 | 25 | 12 | 0.33 | +3 | +0.2 |
| OPENS UP | 19 | 17 | 11 | 0.31 | +280 | +25.5 |
| OVERRUNS AWAY | 34 | 33 | 11 | 0.31 | +356 | +32.4 |
| SUPPORT NARROWED | 30 | 30 | 11 | 0.31 | -1020 | -92.8 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +407 | +40.7 |
| MARCH OF THE TABLE | 10 | 10 | 10 | 0.28 | -466 | -46.6 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| GUN MASK | 48 | 48 | 9 | 0.25 | +232 | +25.8 |
| ONE FIGHT FORMULA | 348 | 207 | 9 | 0.25 | +16 | +1.7 |
| ONE OBJECTIVE FORMULA | 310 | 234 | 8 | 0.22 | +784 | +98.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -264 | -33.0 |
| FIGHT TO THE END | 67 | 63 | 7 | 0.19 | +160 | +22.8 |
| HONEST WORTH | 216 | 205 | 7 | 0.19 | +124 | +17.8 |
| NO DOUBLE ROUNDS | 197 | 191 | 7 | 0.19 | +376 | +53.8 |
| PROMISE READS THE TABLE | 31 | 31 | 7 | 0.19 | -176 | -25.1 |
| REFUSING RETIRES | 18 | 18 | 7 | 0.19 | -2 | -0.3 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 0.17 | -463 | -77.2 |
| WIDER SPREAD | 159 | 151 | 6 | 0.17 | +38 | +6.4 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -321 | -64.2 |
| FALL BACK GOOD ORDER | 178 | 171 | 5 | 0.14 | +102 | +20.5 |
| HIS CHARGE DENIED | 20 | 20 | 5 | 0.14 | +192 | +38.5 |
| MISSILES NEXT TURN | 322 | 233 | 5 | 0.14 | +19 | +3.9 |
| PROMISE SHOT AWAY | 5 | 5 | 5 | 0.14 | -8 | -1.6 |
| WHO GETS IN | 5 | 5 | 5 | 0.14 | -239 | -47.9 |
| AFTERMATH WITH FRIENDS | 4 | 4 | 4 | 0.11 | +271 | +67.8 |
| BOMBING RUN | 4 | 4 | 4 | 0.11 | +157 | +39.3 |
| EDGE GIVE GROUND | 8 | 8 | 4 | 0.11 | +104 | +26.1 |
| FALLBACK BY WORTH | 18 | 18 | 4 | 0.11 | +129 | +32.3 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| PROMISE KNOWS THE FIGHT | 30 | 23 | 4 | 0.11 | -15 | -3.9 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -392 | -98.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +73 | +18.1 |
| WHOLE FIGHT GAIN | 7 | 7 | 4 | 0.11 | +31 | +7.9 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +277 | +92.4 |
| WALKS ON ITS ROUTE | 3 | 3 | 3 | 0.08 | -133 | -44.3 |
| WAR ENGINE CHARGES | 3 | 3 | 3 | 0.08 | +178 | +59.4 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -96 | -47.9 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.06 | +394 | +196.9 |
| HUNT IN PAIRS | 16 | 7 | 2 | 0.06 | +56 | +28.0 |
| JOINT ON THE TABLE | 2 | 2 | 2 | 0.06 | +60 | +30.2 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +49 | +24.6 |
| LOST AFTER ESCAPE | 133 | 129 | 2 | 0.06 | +98 | +48.8 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.06 | -21 | -10.4 |
| SAFER THAN THE JOB | 2 | 2 | 2 | 0.06 | +90 | +44.8 |
| SET UP TOGETHER | 22 | 20 | 2 | 0.06 | +14 | +6.9 |
| WAR ENGINE JOBS | 24 | 24 | 2 | 0.06 | -54 | -26.9 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.03 | -225 | -225.2 |
| DENIED BY THE FIGHT | 55 | 55 | 1 | 0.03 | +7 | +6.7 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +30 | +29.8 |
| GIVES UP | 17 | 15 | 1 | 0.03 | +11 | +10.9 |
| HIS MOVE AND SHOT | 245 | 231 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 17 | 15 | 1 | 0.03 | +2 | +2.1 |
| NEXT OBJECTIVE NEARER | 7 | 7 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +12 | +12.2 |
| REDIRECT BY WHAT IT STOPS | 43 | 43 | 1 | 0.03 | +5 | +4.6 |
| REFORMS TO MEET IT | 80 | 65 | 1 | 0.03 | +0 | +0.0 |
| ROUNDS AFTER TERROR | 68 | 68 | 1 | 0.03 | +5 | +5.2 |
| SPELLS IN THE FIGHT | 35 | 33 | 1 | 0.03 | +4 | +4.5 |
| WHOLE FIGHT | 6 | 4 | 1 | 0.03 | +4 | +3.7 |
| ALREADY CARRIED | 7 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 15 | 5 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 15 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 15 | 15 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 66 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 7 | 7 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 89 | 84 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 17 | 17 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 90 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 17 | 17 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 318 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 37 | 33 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 75 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 215 | 207 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 390 | 375 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 305 | 281 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 309 | 290 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 107 | 107 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 327 | 310 | 0 | 0.00 | - | - |
| HOLD ODDS | 1210 | 1203 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 217 | 214 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 11 | 11 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 4 | not checked | - | - | - | - |
| LOST CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 14 | 14 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 12 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 39 | 39 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 79 | 78 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 8 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 9 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 34 | not checked | - | - | - | - |
| NO LATE CUT | 54 | 52 | 0 | 0.00 | - | - |
| NOT TURNED | 9 | 9 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 48 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 356 | 345 | 0 | 0.00 | - | - |
| ONE ROUTE | 79 | 78 | 0 | 0.00 | - | - |
| OPENS A LANE | 10 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 3108 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 7 | 7 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 79 | 78 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 21 | 21 | 0 | 0.00 | - | - |
| RUN DOWN | 165 | 158 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 36 | 36 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 10 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 18 | 18 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 594 | 554 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 42 | 41 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 91 | 83 | 0 | 0.00 | - | - |
| STANDS STILL | 2899 | 2811 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 20 | 17 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 113 | not checked | - | - | - | - |
| THE PROMISE ADDS | 8 | 7 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2394 | not checked | - | - | - | - |
| WAITS AGAIN | 103 | 92 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 11 | 7 | 0 | 0.00 | - | - |

### Off best figure: base-s2-882d875-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.83 | 3.03 | 33.5 |
| PROMISE BY ITS OWN SUM | rule | 2.92 | 2.72 | 73.5 |
| ARMY TABLE | rule | 1.94 | 1.92 | 52.8 |
| HOLDER ASSIGNMENT | rule | 0.58 | 0.81 | 19.4 |
| NO REASON | gate | 0.61 | 0.69 | 28.4 |
| CHARGE NOW FIRST | rule | 0.33 | 0.44 | 60.9 |
| JOINT CHARGE NOW | rule | 0.33 | 0.28 | 82.9 |
| CANNON PLANNED TARGET | rule | 0.39 | 0.14 | 9.5 |
| SUPPORT NARROWED | rule | 0.25 | 0.06 | 92.8 |
| MARCH OF THE TABLE | rule | 0.08 | 0.17 | 51.8 |
| PIVOT GUARDS FLANK | rule | 0.19 | 0.03 | 33.0 |
| CHAFF PASSED | rule | - | 0.19 | 1.9 |
| PROMISE READS THE TABLE | rule | 0.06 | 0.11 | 30.1 |
| BEST PRIZE | rule | 0.03 | 0.11 | 64.2 |
| ONE PROMISE A TARGET | rule | 0.03 | 0.11 | 104.2 |
| PROMISE KNOWS THE FIGHT | rule | 0.06 | 0.06 | 3.9 |
| PROMISE SHOT AWAY | rule | 0.06 | 0.06 | 2.0 |
| PURSUES BIG PREY | rule | 0.03 | 0.08 | 98.0 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.06 | 5.2 |
| FALLBACK | gate | 0.03 | 0.06 | 9.7 |
| WHO GETS IN | rule | 0.03 | 0.06 | 95.5 |
| AFTERMATH BAND | gate | 0.03 | 0.03 | 2.7 |
| CATCH ODDS | rule | - | 0.06 | 47.9 |
| FIGHT ORDER BAND | gate | 0.06 | - | 2.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | - | 12.1 |
| OWN CAST FIRST | rule | - | 0.06 | 10.4 |
| PATHS CROSS | rule | - | 0.06 | 8.1 |
| SET UP BY THE SET | rule | - | 0.06 | 45.6 |
| WALKS ON ITS ROUTE | rule | 0.06 | - | 67.5 |
| WAR ENGINE JOBS | rule | 0.03 | 0.03 | 26.9 |
| CHARGE NOT DECLARED | rule | 0.03 | - | 225.2 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 4.4 |
| TURN GATE | gate | 0.03 | - | 4.6 |

### Plans: base-s2-882d875-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.2 | 60% | 298 | 171 | 57% |
| Mine | join | 0.9 | 100% | 30 | 0 | 0% |
| Mine | move | 28.6 | 95% | 1625 | 0 | 0% |
| Mine | shoot | 9.5 | 56% | 604 | 600 | 99% |
| Mine | support | 0.5 | 71% | 6 | 0 | 0% |
| Opponent | charge | 3.4 | 55% | 694 | 327 | 47% |
| Opponent | join | 1.1 | 97% | 39 | 0 | 0% |
| Opponent | move | 34.1 | 96% | 1402 | 0 | 0% |
| Opponent | shoot | 5.3 | 54% | 324 | 261 | 80% |
| Opponent | support | 0.9 | 88% | 12 | 0 | 0% |

### Battle groups: base-s2-882d875-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 16% | 60% | 0% | - | 0% | 0% | 30% | 70% | 0% |
| Opponent | REDIRECT COUNTER | 2.4 | 17% | 80% | 20% | 33% | 25% | 0% | 17% | 58% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s2-882d875-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 62 | 25% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 36 | 46 (36) | 0 | 46 | 50 | 42% | 3.1 | 44 (22) | 79 (8) | 0 (6) | 42 (26) | 56 (10) |
| Mine | Character | 123 | 39 (123) | 39 | 0 | 27 | 24% | 2.6 | 58 (34) | 40 (51) | 21 (24) | 38 (67) | 47 (42) |
| Mine | Clean-up | 19 | 21 (19) | 9 | 12 | 39 | 42% | 3.2 | 53 (5) | 5 (11) | 31 (3) | 32 (9) | 14 (10) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 100 | 50% | 6.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Fast Hammer | 46 | 34 (46) | 11 | 23 | 38 | 35% | 2.3 | 23 (16) | 41 (23) | 43 (7) | 31 (33) | 42 (13) |
| Mine | Hammer | 57 | 38 (57) | 16 | 22 | 40 | 25% | 2.5 | 37 (16) | 34 (33) | 56 (8) | 45 (38) | 23 (19) |
| Mine | Holder | 29 | 51 (29) | 2 | 49 | 34 | 48% | 3.0 | 8 (6) | 76 (16) | 33 (7) | 81 (18) | 6 (11) |
| Mine | Shooter | 45 | 66 (45) | 26 | 41 | 30 | 0% | 1.5 | 85 (13) | 67 (21) | 35 (11) | 78 (32) | 37 (13) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 0 | 67% | 4.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | Tough | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 59 | 35 (59) | 35 | 0 | 29 | 5% | 1.5 | 22 (15) | 50 (29) | 19 (15) | 32 (12) | 36 (47) |
| Mine | Wizard | 22 | 10 (22) | 10 | 0 | 33 | 27% | 2.4 | 25 (9) | 0 (6) | 0 (3) | 19 (11) | 0 (7) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 62 | 50% | 4.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 66 (76) | 7 | 59 | 33 | 58% | 2.5 | 52 (32) | 95 (25) | 48 (19) | 77 (59) | 32 (17) |
| Opponent | Character | 96 | 52 (96) | 52 | 0 | 26 | 30% | 2.4 | 61 (35) | 55 (39) | 41 (15) | 44 (60) | 69 (29) |
| Opponent | Clean-up | 20 | 83 (20) | 35 | 48 | 18 | 50% | 2.1 | 139 (6) | 70 (11) | 0 (3) | 107 (16) | 0 (4) |
| Opponent | Early | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |
| Opponent | Fast Hammer | 48 | 18 (48) | 8 | 10 | 30 | 38% | 2.2 | 10 (15) | 17 (23) | 36 (10) | 21 (28) | 13 (20) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 29 | 67% | 1.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Hammer | 70 | 27 (70) | 18 | 8 | 33 | 33% | 3.0 | 16 (25) | 26 (32) | 43 (13) | 31 (38) | 21 (32) |
| Opponent | Holder | 33 | 61 (33) | 17 | 44 | 12 | 48% | 3.0 | 35 (9) | 84 (18) | 18 (6) | 56 (21) | 70 (12) |
| Opponent | Shooter | 35 | 57 (35) | 15 | 42 | 25 | 11% | 1.7 | 20 (12) | 113 (16) | 14 (7) | 76 (20) | 38 (15) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | War machine | 24 | 47 (24) | 47 | 0 | 36 | 4% | 1.7 | 80 (7) | 16 (10) | 56 (7) | 22 (7) | 57 (17) |
| Opponent | Wizard | 27 | 5 (27) | 5 | 0 | 29 | 41% | 1.8 | 0 (9) | 7 (7) | 0 (7) | 3 (12) | 0 (11) |

### Charged fights: base-s2-882d875-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 84 | 212 | 2.2 | 1.0 | 94 | 0 | +94 | 2 of 9 | 8 of 9 | - | +94 |
| Mine | Chaos Dwarfs | 4 | 172 | 383 | 1.8 | 1.0 | 219 | 0 | +219 | 4 of 7 | 5 of 6 | - | +219 |
| Mine | Dwarfen Mountain Holds | 4 | 554 | 93 | 1.5 | 1.2 | 62 | 0 | +62 | 0 of 6 | 5 of 6 | +0 | +74 |
| Mine | Empire of Man | 5 | 88 | 50 | 1.2 | 1.0 | 42 | 78 | -36 | 1 of 6 | 5 of 6 | - | -36 |
| Mine | Grand Cathay | 4 | 98 | 305 | 1.8 | 1.0 | 174 | 57 | +117 | 1 of 7 | 4 of 7 | - | +117 |
| Mine | High Elf Realms | 4 | 104 | 536 | 3.8 | 1.1 | 143 | 12 | +131 | 4 of 15 | 12 of 15 | +77 | +135 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 375 | 3.0 | 1.0 | 125 | 0 | +125 | 0 of 3 | 3 of 3 | - | +125 |
| Mine | Lizardmen | 1 | 231 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Ogre Kingdoms | 1 | 376 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 186 | 3.0 | 1.0 | 62 | 18 | +44 | 1 of 3 | 2 of 3 | - | +44 |
| Mine | Skaven | 2 | 213 | 0 | 1.0 | 1.0 | 0 | 102 | -102 | 1 of 2 | 0 of 2 | - | -102 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 250 | 4.0 | 1.0 | 62 | 0 | +62 | 0 of 4 | 4 of 4 | - | +62 |
| Mine | Vampire Counts | 3 | 0 | 152 | 2.7 | 1.0 | 57 | 14 | +43 | 3 of 8 | 3 of 8 | - | +43 |
| Mine | Warriors of Chaos | 1 | 0 | 334 | 2.0 | 1.0 | 167 | 86 | +80 | 0 of 2 | 1 of 2 | - | +80 |
| **Mine** | all armies | 36 | 153 | 221 | 2.1 | 1.0 | 108 | 21 | +86 | 18 of 74 | 53 of 73 | +38 | +88 |
| Opponent | Dwarfen Mountain Holds | 2 | 396 | 0 | 1.5 | 1.0 | 0 | 0 | +0 | 3 of 3 | 0 of 3 | - | +0 |
| Opponent | Empire of Man | 2 | 281 | 115 | 1.0 | 1.0 | 115 | 0 | +115 | 0 of 2 | 2 of 2 | - | +115 |
| Opponent | Grand Cathay | 2 | 178 | 588 | 4.0 | 1.0 | 147 | 0 | +147 | 3 of 8 | 8 of 8 | - | +147 |
| Opponent | Kingdom of Bretonnia | 1 | 120 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 3 | 226 | 0 | 1.3 | 1.0 | 0 | 31 | -31 | 2 of 4 | 0 of 4 | - | -31 |
| Opponent | Skaven | 1 | 380 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 122 | 693 | 3.8 | 1.3 | 185 | 97 | +88 | 6 of 15 | 13 of 15 | +60 | +95 |
| Opponent | Vampire Counts | 6 | 62 | 478 | 3.0 | 1.1 | 160 | 0 | +160 | 10 of 18 | 14 of 18 | +326 | +150 |
| Opponent | Warriors of Chaos | 8 | 25 | 373 | 2.4 | 1.1 | 157 | 22 | +135 | 10 of 19 | 13 of 19 | +202 | +131 |
| Opponent | Wood Elf Realms | 7 | 100 | 589 | 3.6 | 1.1 | 165 | 13 | +152 | 13 of 25 | 17 of 25 | +114 | +155 |
| **Opponent** | all armies | 36 | 129 | 393 | 2.6 | 1.1 | 149 | 25 | +124 | 48 of 95 | 67 of 95 | +133 | +124 |

### Effective charges: base-s2-882d875-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 1 (net +0) | 0 | 2 (net +82) | 1 (net +72) | 0 | 3 (net +104) | 2 | 29% (2 of 7) |
| Mine | Chaos Dwarfs | 7 | 2 (net +453) | 0 | 0 | 0 | 2 (net +0) | 2 (net +22) | 1 | 0% (0 of 6) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 3 (net +124) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 6 | 0 | 0 | 3 (net -63) | 1 (net -136) | 0 | 2 (net +54) | 0 | 50% (3 of 6) |
| Mine | Grand Cathay | 7 | 1 (net -48) | 0 | 0 | 0 | 2 (net +153) | 4 (net +141) | 0 | 0% (0 of 7) |
| Mine | High Elf Realms | 15 | 1 (net -115) | 1 (net -60) | 3 (net +226) | 0 | 6 (net +76) | 3 (net +294) | 1 | 21% (3 of 14) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 1 (net +205) | 0 | 1 (net +0) | 1 | 0% (0 of 2) |
| Mine | Skaven | 2 | 2 (net -102) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 0 | 3 (net +42) | 0 | 1 | 0% (0 of 3) |
| Mine | Vampire Counts | 8 | 5 (net +23) | 0 | 1 (net +0) | 1 (net +102) | 1 (net +125) | 0 | 0 | 12% (1 of 8) |
| Mine | Warriors of Chaos | 2 | 2 (net +80) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 3 | 3 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +230) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 8 | 0 | 0 | 1 (net +0) | 4 (net +177) | 0 | 3 (net +156) | 0 | 12% (1 of 8) |
| Opponent | Ogre Kingdoms | 4 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 3 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 15 | 2 (net -180) | 0 | 1 (net +310) | 2 (net +181) | 0 | 8 (net +224) | 2 | 8% (1 of 13) |
| Opponent | Vampire Counts | 18 | 2 (net +0) | 0 | 0 | 9 (net +217) | 1 (net +55) | 6 (net +144) | 0 | 0% (0 of 18) |
| Opponent | Warriors of Chaos | 19 | 4 (net +35) | 0 | 1 (net +210) | 3 (net +210) | 3 (net +115) | 6 (net +173) | 2 | 6% (1 of 17) |
| Opponent | Wood Elf Realms | 25 | 8 (net +156) | 0 | 1 (net +0) | 2 (net +89) | 4 (net +61) | 6 (net +285) | 4 | 5% (1 of 21) |

### Charged fights, damage counted: base-s2-882d875-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 189 | 202 | +54 | 150 | 98 | +52 | +27.7 |
| Mine | 50-54% | 1 | 60 | 144 | -60 | 62 | 60 | +2 | +2.9 |
| Mine | Effective (55-75%) | 9 | 188 | 165 | +73 | 123 | 52 | +71 | +37.8 |
| Mine | 76-89% | 6 | 214 | 120 | +40 | 104 | 47 | +58 | +26.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 245 | 171 | +127 | 141 | 3 | +138 | +56.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 377 | 100 | +72 | 83 | 0 | +83 | +21.9 |
| Mine | No odds | 11 | 264 | 217 | +130 | 139 | 64 | +75 | +28.2 |
| Mine | All fights | 74 | 250 | 166 | +86 | 125 | 41 | +84 | +33.8 |
| Opponent | Long shot (under 50%) | 19 | 232 | 293 | +54 | 108 | 61 | +47 | +20.2 |
| Opponent | 50-54% | 2 | 194 | 298 | +0 | 36 | 88 | -52 | -27.0 |
| Opponent | Effective (55-75%) | 5 | 339 | 232 | +150 | 186 | 11 | +175 | +51.6 |
| Opponent | 76-89% | 20 | 325 | 211 | +191 | 209 | 23 | +186 | +57.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 391 | 220 | +196 | 232 | 28 | +204 | +52.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 433 | 79 | +80 | 91 | 38 | +53 | +12.3 |
| Opponent | No odds | 11 | 275 | 280 | -27 | 109 | 112 | -4 | -1.3 |
| Opponent | All fights | 95 | 329 | 230 | +124 | 169 | 44 | +125 | +38.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s2-882d875-p2 | move | 253 | 59 (23%) | 45 (18%) | 34 (13%) | 160 (63%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

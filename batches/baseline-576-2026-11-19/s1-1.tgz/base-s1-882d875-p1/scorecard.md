# Doctrine scorecard: base-s1-882d875-p1

### Scorecard: base-s1-882d875-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 10 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 0 | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 4 | 3 | 3 | 4 | 1 | 0 | 0 | 595 |
| L0135 | 3 | 1 | Mine | no | 15 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 6 | 2 | 5 | 0 | 0 | 0 | 200 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 8 | 2 | 1 | 3 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 450 |
| L0319 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 15 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 2 | - | 1 | 1 | 0 | 0 | 0 | 829 |
| L0421 | 1 | 1 | Mine | no | 0 | 1 | 6 | 2 | 0 | 0 | 0 | 65 |
| L0421 | 1 | 1 | Opponent | no | 5 | - | 0 | 3 | 0 | 0 | 0 | 447 |
| L0508 | 4 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 662 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 899 |
| L0524 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 451 |
| L0524 | 2 | 1 | Opponent | - | - | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 426 |
| L0612 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 521 |
| L0628 | 4 | 1 | Opponent | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 2 | 4 | 2 | 1 | 0 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 144 |
| L0823 | 1 | 1 | Mine | no | 14 | - | 0 | 2 | 1 | 0 | 0 | 206 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 212 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 250 |
| L0913 | 1 | 1 | Opponent | no | 18 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 4 | 1 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 6 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 10 | 2 | 5 | 0 | 0 | 0 | 0 | 165 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Opponent | no | 3 | - | 0 | 3 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 5 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1224 | 6 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 4 | 2 | 3 | 0 | 2 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 1 | - | 2 | 1 | 1 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 50 |
| L1625 | 5 | 1 | Mine | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 3 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 1 | 0 | 0 | 72 |
| L1923 | 3 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | yes | 2 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | no | 4 | - | 0 | 2 | 1 | 0 | 0 | 677 |
| L2025 | 3 | 1 | Opponent | no | 0 | 3 | 7 | 3 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 11 | - | 1 | 5 | 0 | 0 | 0 | 65 |
| L2127 | 3 | 1 | Opponent | no | 10 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 7 | 1 | 0 | 0 | 0 | 267 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 0 | 3 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 2 | 3 | 7 | 2 | 0 | 0 | 0 | 114 |
| L2531 | 5 | 1 | Mine | no | - | 2 | 1 | 4 | 0 | 0 | 0 | 168 |
| L2531 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | 3 | 2 | 1 | 0 | 0 | 0 | 633 |
| L2934 | 6 | 1 | Mine | no | 6 | 2 | 3 | 3 | 2 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 4 | 1 | 5 | 5 | 0 | 0 | 0 | 458 |
| **Average** | | | Mine | 19% | 4.0 | 2.5 | 2.1 | 1.7 | 0.3 | 0.0 | 0.0 | 169.6 |
| **Average** | | | Opponent | 12% | 3.0 | 2.3 | 2.2 | 2.5 | 0.4 | 0.0 | 0.0 | 175.1 |

### KPIs: base-s1-882d875-p1

Morten 2026-11-10; 34 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (44 of 157) | 3% (5 of 167) | 15% (49 of 324) |
| Winner chose to follow up after the loser gave ground |  | 84% (36 of 43); on the table 86% | 75% (30 of 40); on the table 82% | 80% (66 of 83); on the table 84% |
| Winner chose to pursue after the loser fell back in good order |  | 64% (9 of 14); on the table 71% | 87% (13 of 15); on the table 87% | 76% (22 of 29); on the table 79% |
| Winner chose to pursue after the loser fled |  | 58% (11 of 19); on the table 58% | 65% (11 of 17); on the table 76% | 61% (22 of 36); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 74% (56 of 76); on the table 76% | 75% (54 of 72); on the table 82% | 74% (110 of 148); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 30% (97 of 324) | 34% (71 of 210) | 31% (168 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (97 of 255) | 41% (71 of 175) | 39% (168 of 430) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 63% (19 of 30) | 56% (33 of 59) | 58% (52 of 89) |
| Points that never fought | lower | 46% (31213 of 67485) | 50% (33950 of 67889) | 48% (65163 of 135374) |
|   infantry points that never fought | lower | 61% (10007 of 16336) | 70% (8870 of 12598) | 65% (18877 of 28934) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (158 of 262) | 66% (188 of 283) | 63% (346 of 545) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 2.0 uses a game | 75% (15 of 20); 1.4 uses a game | 83% (35 of 42); 1.7 uses a game |
| Bound items with another spell used |  | 27% (4 of 15); 0.4 uses a game | 25% (2 of 8); 0.1 uses a game | 26% (6 of 23); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 44% (8 of 18); 0.2 uses a game | 67% (8 of 12); 0.2 uses a game | 53% (16 of 30); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (30727 of 56251) | 61% (36148 of 59638) | 58% (66875 of 115889) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.5 (38%) | 1.9 (45%) | 4.4 (41%) |
| MARCHED: its unit marched | 1.2 (18%) | 0.5 (13%) | 1.7 (16%) |
| CHARGED: its unit charged | 0.5 (8%) | 0.0 (0%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.4 (22%) | 0.5 (13%) | 2.0 (18%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.4 (11%) | 0.7 (6%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| GONE: slain | 0.5 (7%) | 0.3 (7%) | 0.8 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (4%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (1%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 1.7 | 2.2 | 4.9 | 0.8 | 1.7 |
| not cast | 2.8 | 3.0 | 2.7 | 10.8 | 1.7 | 22.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (48%) | 0.4 (14%) | 4.4 (41%) | 0.4 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (16%) | 0.3 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.3 (11%) | 0.6 (21%) | 2.0 (18%) | 0.5 (28%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (8%) | 0.4 (12%) | 0.7 (26%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.1 (4%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.5 (17%) | 0.1 (4%) | 0.1 (2%) | 0.8 (7%) | 0.1 (5%) | 1.3 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (4%) | 0.1 (4%) | 0.3 (3%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) | 0.1 (1%) | 0.3 (17%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (61%) | 0.3 (10%) | 0.7 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.9 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.9 a game | 0.7 a game | 1.3 a game |
| stood (cast and not dispelled) | 71% (44 of 62) | 68% (15 of 22) | 70% (59 of 84) |
| the unit moved after it | 50% (22 of 44) | 33% (5 of 15) | 46% (27 of 59) |
| it charged on its next turn | 5% (2 of 44) | 7% (1 of 15) | 5% (3 of 59) |
| the enemy charged it first | 11% (5 of 44) | 13% (2 of 15) | 12% (7 of 59) |
| it fought by the end of its next turn | 5% (2 of 44) | 0% (0 of 15) | 3% (2 of 59) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (3 of 44) | 7% (1 of 15) | 7% (4 of 59) |
| none of these (no charge, no fight, no charge escaped) | 77% (34 of 44) | 73% (11 of 15) | 76% (45 of 59) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (520 of 874) | 56% (320 of 567) | 58% (840 of 1441) |
|   cavalry | 66% (51 of 77) | 71% (84 of 118) | 69% (135 of 195) |
|   character | 57% (66 of 115) | 37% (49 of 134) | 46% (115 of 249) |
|   chariot | 68% (60 of 88) | 39% (9 of 23) | 62% (69 of 111) |
|   infantry | 55% (157 of 284) | 56% (114 of 204) | 56% (271 of 488) |
|   monster | 70% (23 of 33) | 77% (17 of 22) | 73% (40 of 55) |
|   war machine | 59% (163 of 277) | 71% (47 of 66) | 61% (210 of 343) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (17%) | 1.2 (17%) | 2.9 (17%) |
| CHARGED: it charged | 0.6 (6%) | 1.4 (19%) | 1.9 (11%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: it fought this turn or the last | 0.4 (4%) | 0.3 (4%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.4 (13%) | 0.4 (6%) | 1.8 (10%) |
| NO TARGET IN RANGE | 2.7 (26%) | 2.2 (31%) | 4.9 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.4 (6%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (22%) | 1.2 (16%) | 3.5 (20%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.1 (1%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.0 | 84% | 5.0 pts | 27 pts |
| character | 3.8 | 1.6 | 69% | 8.7 pts | 33 pts |
| chariot | 2.1 | 1.1 | 68% | 16.0 pts | 33 pts |
| infantry | 11.8 | 3.8 | 78% | 6.6 pts | 78 pts |
| monster | 1.3 | 0.3 | 89% | 1.9 pts | 2 pts |
| war machine | 6.2 | 4.5 | 66% | 20.5 pts | 127 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.2 | 4.4 | 3.8 |
| Charges that made contact a game | 2.3 | 3.1 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.14 declared, 0.71 contact (21 units) | 0.44 declared, 0.38 contact (16 units) | 0.84 declared, 0.57 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (5 units) | 1.56 declared, 1.00 contact (9 units) | 1.36 declared, 1.00 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.23 contact (246 units) | 0.46 declared, 0.32 contact (276 units) | 0.39 declared, 0.28 contact (522 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (33 of 67) | 80% (16 of 20) | 38% (3 of 8) | 55% (52 of 95) |
| Character in a unit | 80% (32 of 40) | 81% (22 of 27) | 75% (3 of 4) | 80% (57 of 71) |
| Character on its own | 86% (37 of 43) | 52% (17 of 33) | 27% (15 of 55) | 53% (69 of 131) |
| Chariot | 81% (13 of 16) | 90% (9 of 10) | - | 85% (22 of 26) |
| Infantry | 60% (52 of 86) | 50% (18 of 36) | 50% (1 of 2) | 57% (71 of 124) |
| Monster | 58% (14 of 24) | 100% (10 of 10) | - | 71% (24 of 34) |
| Monstrous | 91% (10 of 11) | 71% (10 of 14) | - | 80% (20 of 25) |
| War Machines | 79% (30 of 38) | 100% (1 of 1) | - | 79% (31 of 39) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 85% (11 of 13); on the table 92% | 43% (60 of 138) | 43% | 61% (20 of 33) | 100% (9 of 9); 5.2 uses a game | 100% (3 of 3); 1.8 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 67% (4 of 6); on the table 67% | 38% (9 of 24) | 53% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 33% (2 of 6); on the table 50% | - | 70% | 71% (29 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 100% (4 of 4); on the table 100% | 37% (11 of 30) | 61% | 70% (38 of 54) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 5 | 70% (7 of 10); on the table 80% | 22% (24 of 108) | 47% | 50% (22 of 44) | 83% (10 of 12); 6.2 uses a game | 0% (0 of 1); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 77% (10 of 13); on the table 77% | 20% (6 of 30) | 39% | 41% (20 of 49) | 100% (5 of 5); 2.8 uses a game | 17% (3 of 18); 0.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 80% (4 of 5); on the table 80% | - | 50% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 3 | 67% (2 of 3); on the table 67% | 33% (4 of 12) | 50% | 81% (17 of 21) | 67% (2 of 3); 2.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (6 of 6); on the table 100% | 6% (2 of 36) | 34% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 50% (3 of 6); on the table 67% | 13% (4 of 30) | 42% | 76% (26 of 34) | 100% (3 of 3); 2.2 uses a game | 0.0 uses a game | 75% (3 of 4); 0.8 uses a game |
| Tomb Kings of Khemri | 5 | 60% (9 of 15); on the table 60% | 0% (0 of 12) | 38% | 44% (11 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 77% (23 of 30); on the table 87% | 37% (20 of 54) | 42% | 70% (35 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 78% (14 of 18); on the table 78% | 33% (10 of 30) | 56% | 78% (58 of 74) | 100% (4 of 4); 1.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 85% (11 of 13); on the table 85% | 60% (18 of 30) | 48% | 62% (41 of 66) | 33% (2 of 6); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s1-882d875-p1, 34 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (37) | 58% (26) | 59% (63) |
| ...free all their last turn and able to turn (per game) | 0.74 | 0.50 | 1.24 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.24 | 0.12 | 0.35 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.26 | 0.82 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.03 | 0.06 | 0.09 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.03 | 0.00 | 0.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.09 | 0.32 | 0.41 |

### Quality by phase: base-s1-882d875-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.6 |
| Strategy | Charge objectives carried out (made contact) | 46% (41 of 89) | 42% (56 of 134) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (133 of 365) | 39% (59 of 152) |
| Strategy | Support requests answered (helper made contact too) | 58% (7 of 12) | 58% (11 of 19) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 33% (1 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (5 of 8) | 75% (12 of 16) |
| Strategy | Joined characters whose unit fought | 45% (28 of 62) | 31% (13 of 42) |
| Strategy | Lone characters that fought | 75% (58 of 77) | 66% (58 of 88) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.7 | 2.5 |
| Movement | Points that never moved of their own | 169.6 | 175.1 |
| Movement | Fights charged into per game | 2.0 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 56, net +165 | 26 of 77, net +27 |
| Movement | Charges with odds: sweet spot (55-75%) | 6 of 56, net +227 | 10 of 77, net +47 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 56, net +112 | 4 of 77, net +36 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 of 56, net +111 | 27 of 77, net +231 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.1 | 8.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (176 of 378) | 52% (158 of 303) |
| Shooting | Points destroyed by shooting units | 43.3 | 42.6 |
| Shooting | War machine shots | 4.8 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (76 of 163) | 40% (19 of 47) |
| Shooting | Points destroyed by war machines | 56.5 | 18.4 |
| Magic | Magic missiles cast | 1.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 47% (27 of 58) | 47% (20 of 43) |
| Magic | Wounds caused by magic missiles | 4.3 | 1.8 |
| Magic | Wounds caused by other spells | 1.0 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 70.9 | 21.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.9 / 0.3 / 0.9 / 0.2 | 1.8 / 0.7 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 298.6 | 337.1 |
| Combat | Points run down | 34.4 | 95.6 |
| Combat | Net points per charged fight, damage counted | +115 | +100 |
| Combat | Net per 100 charger points, damage counted | +34.2 | +32.3 |
| Combat | First round won (charged fights) | 80% | 61% |
| Combat | Net points per charged fight | +112 | +102 |
| Combat | Net points per supported fight / lone fight | +95 / +113 | +165 / +92 |
| Combat | Charged fights on a top-3 enemy unit | 34 of 69 | 52 of 90 |
| Game | Points lost | 552.0 | 580.0 |
| Game | VP from objectives | 665.0 | 664.4 |
| Game | Lone holders (player turns) | 4.0 | 3.0 |

- Mine won / drew / lost: 14 / 7 / 13 of 34 ended games (of 34); mean margin (Mine - Opponent) +13 VP
- The side that went first won 5 of 27 games with a winner
- Points traded per game (both sides' losses): 1132
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: base-s1-882d875-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 5.4 |
| AFTERMATH IN POINTS | 0.2 | +21.3 | 0.0 | 21.9 | 0.3 | +28.5 | 0.0 | 11.6 |
| AFTERMATH WITH FRIENDS | 0.2 | +7.3 | 0.0 | 0.0 | 0.1 | +8.7 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 17.6 | +209.4 | 0.0 | 191.4 | 20.9 | +283.3 | 0.0 | 309.2 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.6 | +0.0 | 0.0 | 4.9 | 0.5 | +0.0 | 0.0 | 7.5 |
| BACKUP TARGETS | 0.2 | +1.5 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 13.0 |
| BEST PRIZE | 0.1 | +4.6 | 7.5 | 0.0 | 0.1 | -7.0 | 5.6 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -26.8 | 26.0 | 36.3 | 0.4 | -64.6 | 31.2 | 2.1 |
| BOMBING RUN | 0.1 | +2.1 | 0.0 | 4.4 | - | - | - | - |
| CANNON PLAN MISSED | 0.2 | +0.0 | 14.0 | 0.0 | 0.1 | +0.0 | 8.6 | 3.7 |
| CANNON PLANNED TARGET | 4.6 | +108.8 | 175.7 | 47.1 | 1.4 | +38.4 | 42.5 | 14.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 2.8 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 19.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.1 | +57.9 | 106.3 | 25.4 | 0.9 | +9.3 | 45.0 | 15.9 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.0 | +143.0 | 40.6 | 0.0 | 0.1 | +2.7 | 5.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 11.6 | 0.4 | +0.0 | 0.0 | 22.8 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +3.8 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.5 | +17.3 | 0.0 | 14.4 | 1.2 | +65.2 | 0.0 | 22.9 |
| CHAFF PASSED | 0.1 | -0.4 | 0.0 | 0.0 | 0.4 | -0.4 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -1.7 | 12.6 | 0.0 | 0.2 | -17.9 | 14.4 | 8.4 |
| CHARACTER GUNS | 1.6 | +0.0 | 0.0 | 15.2 | 1.2 | +0.0 | 0.0 | 26.4 |
| CHARGE LIST READ AGAIN | 0.0 | +1.6 | 14.1 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.9 | -526.8 | 0.0 | 336.7 | 11.6 | -736.2 | 0.0 | 392.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.1 | +0.0 | 0.0 | 6.2 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 170.5 | 47.9 | 2.1 | +0.0 | 250.6 | 51.7 |
| CHARGER SLAIN LOST | 0.3 | -16.4 | 33.5 | 1.5 | 0.5 | -26.1 | 39.2 | 19.4 |
| COMBAT PIVOT | 0.4 | +0.0 | 3.7 | 46.1 | 0.3 | +0.0 | 10.9 | 57.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.5 | +130.7 | 1.0 | 0.0 | 0.6 | +96.8 | 14.7 | 30.8 |
| COVER ONCE | 6.2 | -493.4 | 0.0 | 128.3 | 4.3 | -322.9 | 0.0 | 103.3 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | -5.9 | 0.0 | 3.7 |
| DENIED BY THE FIGHT | 0.4 | -8.4 | 60.7 | 27.7 | 1.0 | -12.1 | 91.2 | 9.2 |
| DEPLOY BY FIGURES | 8.0 | +17.5 | 0.0 | 5.6 | 7.6 | +71.2 | 0.0 | 37.9 |
| EDGE GIVE GROUND | 0.1 | +1.7 | 10.4 | 4.4 | 0.1 | +1.0 | 11.8 | 13.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.0 | +5.5 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.8 | +6.4 | 195.3 | 44.1 | 3.1 | +8.7 | 331.9 | 35.8 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 3.5 | 0.3 | +0.2 | 0.0 | 0.6 |
| FALLS SHORT | 4.7 | +70.9 | 0.0 | 60.4 | 16.3 | +229.3 | 0.0 | 207.9 |
| FEATURE BUFFS | 2.6 | +84.0 | 0.0 | 19.9 | 0.9 | +26.6 | 0.0 | 3.2 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.5 | +10.0 | 18.3 | 10.4 | 0.8 | +10.3 | 60.8 | 14.7 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 36.7 | 4.8 | 0.2 | +0.0 | 2.8 | 3.7 |
| FIVE ACTION | 91.9 | +5917.8 | 1302.2 | 1151.8 | 87.7 | +5204.9 | 777.5 | 1159.4 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 217.5 | 4.3 | +0.0 | 0.0 | 137.6 |
| FOLLOW UP WEIGHED | 0.8 | +130.5 | 0.0 | 13.6 | 0.9 | +122.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +272.2 | 342.6 | 68.9 | 4.2 | +296.2 | 403.1 | 102.3 |
| FRIEND CHARGES FIRST | 0.1 | -17.1 | 18.9 | 0.0 | 0.1 | -1.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.9 | -39.3 | 0.0 | 1.5 | 0.3 | -3.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +5.0 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| GIVES UP | 0.5 | -6.9 | 50.9 | 28.6 | 0.3 | -5.4 | 26.8 | 5.7 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.4 | 10.2 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| GUN FIGURES | 1.1 | +13.1 | 9.1 | 28.4 | 0.2 | +2.7 | 0.0 | 20.1 |
| GUN MASK | 1.8 | +103.0 | 0.0 | 0.0 | 0.5 | +18.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 18.2 | 1.9 | +0.0 | 0.0 | 23.1 |
| HE SHOOTS OR CHARGES | 2.4 | +0.0 | 0.0 | 26.8 | 3.8 | +0.0 | 0.0 | 104.5 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.6 | 0.0 | 0.2 | +0.0 | 0.0 | 10.5 |
| HIS CHARGE DENIED | 0.3 | +10.1 | 55.7 | 7.0 | 0.8 | +38.7 | 67.0 | 57.4 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 150.6 | 5.1 | +0.0 | 0.0 | 75.7 |
| HIS FIGHT TOGETHER | 2.0 | -54.1 | 0.0 | 133.4 | 2.3 | -50.8 | 0.0 | 94.6 |
| HIS LEGAL MOVES | 4.6 | +0.0 | 0.0 | 86.6 | 4.7 | +0.0 | 0.0 | 66.3 |
| HIS MOVE AND SHOT | 2.9 | -37.0 | 0.0 | 54.1 | 3.6 | -71.7 | 0.0 | 199.8 |
| HIS MOVE AS HE DECIDES | 39.8 | +13.7 | 573.9 | 0.0 | 35.4 | +13.7 | 512.7 | 0.0 |
| HIS MOVE WHY | 34.8 | +0.0 | 0.0 | 422.9 | 40.6 | +0.0 | 0.0 | 536.8 |
| HIS ONE MOVE | 18.5 | -32.2 | 1.3 | 70.8 | 19.6 | +9.0 | 5.1 | 110.6 |
| HIS ONE QUARTER | 3.6 | +0.0 | 0.0 | 71.0 | 3.9 | +0.0 | 0.0 | 123.4 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 52.3 | 1.8 | +0.0 | 0.0 | 14.7 |
| HIS RANDOM MOVE | 5.7 | +0.0 | 0.0 | 81.4 | 4.0 | +0.0 | 0.0 | 43.9 |
| HIS SHOT LIST | 36.2 | +1086.3 | 0.0 | 433.6 | 49.0 | +2408.8 | 0.0 | 715.8 |
| HIS TURN DENIED | 1.4 | +17.5 | 150.8 | 57.0 | 2.1 | +126.1 | 193.4 | 27.6 |
| HOLD ODDS | 19.6 | +0.0 | 0.0 | 249.4 | 17.3 | +0.0 | 0.0 | 132.7 |
| HOLDER ASSIGNMENT | 10.9 | +1014.3 | 0.0 | 123.9 | 11.0 | +1028.7 | 0.0 | 81.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.5 | -96.8 | 292.4 | 42.4 | 3.4 | -145.5 | 339.6 | 73.9 |
| HORN WORTH | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.1 | +2.2 | 0.0 | 0.0 | 0.3 | +14.3 | 0.0 | 5.7 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.0 | +12.1 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 4.4 | -53.4 | 0.0 | 30.9 | 11.2 | -158.9 | 0.0 | 139.4 |
| JOINT CHARGE NOW | 0.7 | +9.0 | 151.0 | 25.0 | 1.4 | +31.3 | 144.6 | 13.1 |
| JOINT KNOWS CHALLENGE | 0.1 | -1.3 | 20.1 | 3.3 | 0.1 | -2.0 | 0.0 | 0.0 |
| JOINT LOOK BACK | 0.0 | +0.1 | 1.2 | 0.0 | 0.0 | +0.9 | 7.5 | 0.0 |
| JOINT ON THE TABLE | 0.0 | +1.5 | 14.1 | 0.0 | 0.1 | +7.1 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 12.9 | 2.8 | +0.0 | 0.0 | 13.8 |
| LANE BY FIGURES | 0.8 | +25.7 | 0.0 | 0.0 | 0.7 | +43.9 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 4.2 |
| LEGAL CHARGES ONLY | 4.4 | +0.0 | 181.5 | 371.2 | 4.3 | +0.0 | 246.1 | 222.4 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.0 | 0.0 | 1.3 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.8 | +53.8 | 0.0 | 0.0 | 0.2 | +25.2 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -1.7 | 5.5 | 7.0 | 0.3 | +1.6 | 4.0 | 6.9 |
| LOST AFTER ESCAPE | 1.7 | +6.0 | 217.5 | 51.0 | 2.1 | +1.0 | 186.4 | 39.9 |
| LOST CHARGE | 0.1 | -0.1 | 12.8 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -3.4 | 0.0 | 3.2 | 0.1 | -20.3 | 0.0 | 2.2 |
| MAKE SURE TOGETHER | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 3.4 |
| MANOEUVRE | 0.8 | -3.3 | 0.0 | 20.5 | 0.7 | +1.6 | 0.0 | 4.2 |
| MARCH AT ESCAPER | 0.1 | +0.8 | 0.0 | 2.5 | 0.2 | +2.8 | 0.0 | 15.9 |
| MARCH BY THE SUM | 0.3 | +22.5 | 0.0 | 0.0 | 0.3 | +15.8 | 0.0 | 7.4 |
| MARCH CHECK | 0.9 | +39.5 | 0.0 | 4.8 | 0.7 | +39.3 | 0.0 | 25.6 |
| MARCH OF THE TABLE | 0.2 | +12.2 | 0.0 | 0.0 | 0.2 | +3.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -8.5 | 0.0 | 27.5 | 0.9 | +93.2 | 0.0 | 42.3 |
| MARCH WHEELS ONLY | 1.6 | +0.0 | 0.0 | 12.9 | 1.1 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +67.8 | 0.0 | 48.9 | 3.2 | +58.6 | 0.0 | 26.1 |
| MISSILES IN THE MOVE | 4.2 | +196.6 | 0.0 | 58.2 | 3.9 | +53.4 | 0.0 | 51.8 |
| MISSILES NEXT TURN | 5.4 | +141.7 | 0.0 | 104.1 | 5.1 | +46.1 | 0.0 | 90.2 |
| MISSILES ON ONE TARGET | 0.5 | -30.4 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 0.0 |
| MODEL FACING | 0.4 | +133.1 | 0.0 | 5.3 | - | - | - | - |
| MOVE ORDER | 1.8 | +0.0 | 11.6 | 11.8 | 2.5 | +0.0 | 45.9 | 39.1 |
| MOVE SPELL IN RANGE | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -40.3 | 0.0 | 10.4 | 0.2 | -3.2 | 0.0 | 16.1 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 14.7 |
| MOVE TO CHARGE COMPUTED | 6.7 | +613.5 | 0.0 | 24.5 | 5.9 | +526.4 | 0.0 | 44.9 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.4 | +316.3 | 0.0 | 96.5 | 7.3 | +296.8 | 0.0 | 55.5 |
| NEXT CHARGE BY LIST | 5.4 | -208.2 | 53.5 | 42.2 | 6.2 | -290.9 | 7.4 | 72.1 |
| NEXT OBJECTIVE NEARER | 0.1 | -1.1 | 0.0 | 0.0 | 0.1 | -5.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.5 | -139.8 | 292.4 | 47.4 | 3.4 | -189.5 | 358.9 | 65.6 |
| NO LATE CUT | 1.1 | +0.0 | 0.0 | 5.4 | 0.7 | +0.0 | 0.0 | 1.9 |
| NO RALLY LEFT | 0.1 | +1.3 | 0.0 | 4.4 | 0.0 | +0.9 | 0.0 | 0.0 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 1.6 | 0.3 | -2.0 | 0.0 | 21.4 |
| NOT WORTH A CAST | 0.8 | -0.9 | 0.0 | 27.5 | 0.0 | -0.0 | 0.0 | 0.0 |
| OFF BEST | 3.9 | -169.3 | 8.9 | 38.6 | 4.6 | -151.7 | 0.0 | 70.9 |
| ONE CHARGE A CHARGER | 5.5 | +0.0 | 0.0 | 207.1 | 4.2 | +0.0 | 0.0 | 91.6 |
| ONE FIGHT FORMULA | 4.7 | -89.2 | 0.0 | 50.2 | 5.5 | -115.8 | 0.0 | 109.4 |
| ONE OBJECTIVE FORMULA | 4.6 | +33.8 | 0.0 | 95.3 | 3.9 | +22.4 | 0.0 | 57.6 |
| ONE PROMISE A TARGET | 0.2 | -8.5 | 0.0 | 0.0 | 0.1 | -3.9 | 0.0 | 0.0 |
| ONE ROUTE | 1.6 | +0.0 | 0.0 | 12.9 | 1.1 | +0.0 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 26.9 | +506.7 | 0.0 | 299.7 | 35.9 | +994.7 | 0.0 | 402.9 |
| OPENS A LANE | 0.2 | +1.2 | 7.2 | 7.7 | 0.2 | +2.5 | 19.4 | 0.0 |
| OPENS UP | 0.5 | +30.9 | 25.0 | 14.5 | 0.3 | +17.0 | 15.2 | 5.7 |
| OVERRUNS AWAY | 0.2 | +9.9 | 22.2 | 0.0 | 0.4 | +21.8 | 33.4 | 22.6 |
| PATHS CROSS | 0.5 | +21.5 | 0.0 | 7.7 | 0.5 | +15.6 | 0.0 | 3.4 |
| PERIAPT WORTH | 0.0 | +2.9 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 15.9 |
| PIVOT GUARDS FLANK | 0.1 | -0.5 | 0.0 | 0.0 | 0.2 | -4.9 | 0.0 | 2.9 |
| PLAN RESULT | 42.3 | +773.0 | 571.7 | 791.8 | 42.2 | +434.5 | 402.7 | 818.3 |
| PROMISE BELOW ZERO | 0.1 | +0.0 | 0.0 | 2.1 | 0.2 | +0.0 | 0.0 | 5.7 |
| PROMISE BY ITS OWN SUM | 8.7 | -339.5 | 0.0 | 9.4 | 7.8 | -202.6 | 0.0 | 9.6 |
| PROMISE HOLDS THE SPOT | 0.0 | +1.2 | 0.0 | 4.4 | - | - | - | - |
| PROMISE IN STEPS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.8 | -0.5 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.6 | -42.1 | 0.0 | 1.5 | 0.1 | -8.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.1 | -0.6 | 7.0 | 4.9 | - | - | - | - |
| PURSUES BIG PREY | 0.0 | -10.3 | 0.0 | 0.0 | 0.1 | -11.2 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| QUARTER ODDS | 18.6 | +1828.3 | 373.1 | 206.3 | 19.0 | +2037.4 | 341.9 | 322.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +6.7 | 0.0 | 40.1 | 1.7 | +52.4 | 0.0 | 62.9 |
| REAL GROUND | 1.6 | +0.0 | 0.0 | 12.9 | 1.1 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -11.8 | 0.0 | 10.1 | 0.9 | -31.7 | 0.0 | 20.6 |
| REDIRECT COUNTER | 1.4 | +67.2 | 0.0 | 26.8 | 2.9 | +192.1 | 0.0 | 31.5 |
| REDIRECT WEIGHED | 0.3 | +4.2 | 7.1 | 0.0 | 0.2 | +1.6 | 11.6 | 0.0 |
| REFORMS TO MEET IT | 1.5 | -35.8 | 0.0 | 10.6 | 1.1 | -31.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 23.8 | 0.6 | +0.0 | 0.0 | 21.6 |
| RESERVE FALL BACK | 0.5 | +19.1 | 0.0 | 8.7 | 0.4 | +36.4 | 0.0 | 5.1 |
| RESTRAINS TO SHOOT | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +9.8 | 0.0 | 0.0 |
| RISK BY ARC | 1.9 | +42.5 | 181.1 | 60.4 | 2.6 | +23.3 | 251.6 | 71.9 |
| RISK BY HIS FIGURE | 22.0 | -438.4 | 0.0 | 535.1 | 20.3 | -471.1 | 0.0 | 466.6 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 7.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.6 | -6.9 | 70.9 | 27.7 | 1.3 | -33.2 | 149.3 | 15.9 |
| RUN DOWN | 2.0 | -24.4 | 266.6 | 53.7 | 2.9 | -28.3 | 255.6 | 46.2 |
| SAFER THAN THE JOB | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 0.1 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 2.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 2.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -9.7 | 0.0 | 3.0 | 0.5 | -22.8 | 0.0 | 2.3 |
| SEARCH SPOT | 0.4 | +8.2 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 24.6 |
| SECOND LOOK | 0.3 | +17.8 | 27.7 | 0.0 | 0.1 | +3.4 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.1 | +1.6 | 0.0 | 23.2 | 0.2 | +2.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.6 | +20.3 | 6.8 | 9.6 | 2.5 | +60.8 | 23.1 | 20.4 |
| SET UP TOGETHER | 0.1 | +0.4 | 0.0 | 0.0 | 0.5 | +3.3 | 0.0 | 17.7 |
| SET-UP ANY TARGET | 0.3 | +27.6 | 1.0 | 0.0 | 0.1 | +3.6 | 0.0 | 8.1 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +109.1 | 138.2 | 47.0 | 1.6 | +32.7 | 19.7 | 35.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -9.7 | 35.5 | 0.0 | 0.3 | -2.7 | 27.9 | 7.9 |
| SHOT RISK POINTS | 17.7 | +142.5 | 0.0 | 264.7 | 26.7 | +277.0 | 0.0 | 537.3 |
| SHOTS AFTER THE MOVES | 3.1 | +0.0 | 0.0 | 0.0 | 1.6 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.1 | +586.5 | 0.0 | 246.4 | 10.4 | +269.8 | 0.0 | 124.1 |
| SPELL SETS UP CHARGE | 0.3 | +63.2 | 1.0 | 0.0 | 0.1 | +16.1 | 0.0 | 8.1 |
| SPELL WORTH | 1.5 | +23.5 | 62.1 | 62.1 | 2.3 | +43.6 | 94.0 | 97.7 |
| SPELLS IN THE FIGHT | 0.6 | -3.5 | 76.9 | 25.2 | 0.6 | -8.3 | 40.9 | 9.2 |
| SPOT AS THE GAME MOVES | 7.1 | +0.0 | 0.0 | 99.8 | 11.2 | +0.0 | 0.0 | 250.6 |
| STAND AND SHOOT | 0.5 | -3.6 | 41.7 | 19.0 | 0.6 | -4.3 | 67.6 | 2.6 |
| STANDS FOR A REASON | 0.3 | +0.0 | 24.4 | 0.0 | 2.5 | +0.0 | 8.8 | 14.8 |
| STANDS STILL | 45.1 | +0.0 | 959.6 | 456.5 | 31.6 | +0.0 | 374.4 | 344.2 |
| STAY WORTH | 25.1 | -81.8 | 472.2 | 221.0 | 13.0 | +107.6 | 154.1 | 134.3 |
| STOPS | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.3 | 0.2 | +0.0 | 0.0 | 14.3 |
| STUPIDITY NEXT TURN | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.8 | +418.8 | 0.0 | 101.5 | 8.6 | +511.2 | 0.0 | 73.0 |
| SUPPORT NARROWED | 0.4 | +0.0 | 28.9 | 20.4 | 0.6 | +0.0 | 47.7 | 16.9 |
| SUPPORT WORKED OUT | 6.8 | +418.8 | 0.0 | 101.5 | 8.6 | +511.2 | 0.0 | 73.0 |
| SURE REACH TOGETHER | 0.1 | +0.6 | 0.0 | 0.0 | 0.5 | +4.0 | 0.0 | 5.4 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 9.4 | 1.4 | +0.0 | 0.0 | 7.0 |
| THE PROMISE ADDS | 0.2 | -21.1 | 0.0 | 0.0 | - | - | - | - |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.7 | +0.0 | 0.0 | 366.1 | 35.7 | +0.0 | 0.0 | 438.0 |
| TIED UP BY THE SUM | 0.9 | +94.8 | 68.8 | 14.5 | 0.8 | +75.4 | 74.0 | 27.0 |
| TIME ON OUR SIDE | 31.7 | +385.9 | 20.5 | 378.4 | 16.3 | +137.8 | 4.0 | 133.7 |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 33.6 | 1.5 | +0.0 | 0.0 | 1.3 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.1 | -1.1 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 32.1 | 5.4 | 0.1 | +0.0 | 3.4 | 4.4 |
| WHAT THE JOINER ADDS | 0.2 | -3.1 | 56.4 | 0.0 | 0.2 | -8.1 | 30.6 | 4.4 |
| WHO GETS IN | 0.1 | -2.9 | 46.5 | 0.0 | 0.2 | +8.5 | 25.9 | 0.0 |
| WHO HITS BACK | 0.3 | +48.0 | 0.0 | 0.0 | 0.1 | +6.3 | 0.0 | 5.7 |
| WHOLE FIGHT | 0.1 | +1.5 | 28.2 | 0.0 | 0.1 | +0.9 | 15.3 | 2.2 |
| WHOLE FIGHT GAIN | 0.2 | +15.2 | 40.6 | 18.0 | 0.2 | +11.6 | 3.4 | 0.0 |
| WIDER SPREAD | 2.1 | -6.5 | 235.3 | 65.6 | 2.5 | -1.1 | 287.7 | 83.2 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.7 |
| WOUNDS ON THE RANKS | 2.5 | +95.9 | 0.0 | 89.8 | 1.9 | +134.1 | 0.0 | 86.1 |

### Rule changes: base-s1-882d875-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2556 | 2556 | 1623 | 47.74 | +0 | +0.0 |
| HIS MOVE WHY | 2564 | 2564 | 1441 | 42.38 | +0 | +0.0 |
| ARMY TABLE | 1308 | 1308 | 855 | 25.15 | +14753 | +17.3 |
| HOLDER ASSIGNMENT | 746 | 746 | 692 | 20.35 | +41587 | +60.1 |
| HIS SHOT LIST | 2898 | 2746 | 664 | 19.53 | +13491 | +20.3 |
| ONE TARGET A SHOOTER | 2138 | 2016 | 427 | 12.56 | +5021 | +11.8 |
| DEPLOY BY FIGURES | 529 | 529 | 328 | 9.65 | +4232 | +12.9 |
| FIVE ACTION | 6107 | 5852 | 312 | 9.18 | +20083 | +64.4 |
| LEGAL CHARGES ONLY | 293 | 293 | 293 | 8.62 | +0 | +0.0 |
| OFF BEST | 286 | 286 | 286 | 8.41 | -10916 | -38.2 |
| THE TABLE AGAIN | 408 | 408 | 284 | 8.35 | +0 | +0.0 |
| HIS ONE MOVE | 1298 | 1254 | 266 | 7.82 | +0 | +0.0 |
| TIME ON OUR SIDE | 1634 | 1454 | 248 | 7.29 | +986 | +4.0 |
| PROMISE BY ITS OWN SUM | 561 | 561 | 206 | 6.06 | -18431 | -89.5 |
| MOVE TO CHARGE COMPUTED | 431 | 360 | 203 | 5.97 | +9856 | +48.6 |
| SUPPORT ADDS | 522 | 483 | 183 | 5.38 | +9208 | +50.3 |
| SUPPORT WORKED OUT | 522 | 483 | 183 | 5.38 | +9208 | +50.3 |
| SHOT RISK POINTS | 1510 | 1420 | 179 | 5.26 | +7312 | +40.8 |
| MOVE ORDER | 145 | 145 | 145 | 4.26 | +0 | +0.0 |
| HARD STAY DROPPED | 133 | 133 | 133 | 3.91 | +0 | +0.0 |
| QUARTER ODDS | 1278 | 1211 | 126 | 3.71 | +10058 | +79.8 |
| FOUR ROUNDS | 244 | 235 | 112 | 3.29 | +6543 | +58.4 |
| SHOOTS FROM THE BEST SPOT | 146 | 146 | 94 | 2.76 | +1229 | +13.1 |
| CHARGE LOSSES | 766 | 725 | 78 | 2.29 | +6871 | +88.1 |
| RISK BY HIS FIGURE | 1436 | 1339 | 76 | 2.24 | +8377 | +110.2 |
| JOINT CHARGE NOW | 71 | 71 | 71 | 2.09 | +1371 | +19.3 |
| IDLE COST | 530 | 416 | 69 | 2.03 | +445 | +6.4 |
| ADVANCE LANE KEPT | 57 | 57 | 57 | 1.68 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 57 | 57 | 57 | 1.68 | +8589 | +150.7 |
| CAST JOB | 70 | 70 | 55 | 1.62 | +461 | +8.4 |
| SET UP BY THE SET | 140 | 134 | 54 | 1.59 | +3785 | +70.1 |
| RANDOM MOVE BY FIGURES | 89 | 89 | 52 | 1.53 | +2010 | +38.7 |
| LANE BY FIGURES | 51 | 51 | 51 | 1.50 | +2366 | +46.4 |
| STAY WORTH | 1296 | 1171 | 47 | 1.38 | +690 | +14.7 |
| CANNON SIGHT KEPT | 46 | 46 | 46 | 1.35 | +0 | +0.0 |
| MAX FOR POSITIONING | 211 | 199 | 46 | 1.35 | +212 | +4.6 |
| CHAFF IN THE MOVE | 56 | 56 | 45 | 1.32 | +64 | +1.4 |
| RISK BY ARC | 153 | 146 | 45 | 1.32 | +1231 | +27.4 |
| COVER ONCE | 358 | 238 | 43 | 1.26 | +685 | +15.9 |
| FALLS SHORT | 715 | 589 | 43 | 1.26 | +302 | +7.0 |
| HOLDS AMBUSHERS | 43 | 43 | 43 | 1.26 | +0 | +0.0 |
| TIED UP BY THE SUM | 57 | 54 | 43 | 1.26 | +1107 | +25.7 |
| MARCH CHECK | 53 | 53 | 42 | 1.24 | +780 | +18.6 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 1.12 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 1.00 | +2686 | +79.0 |
| SHOTS IN THE MOVE | 902 | 692 | 34 | 1.00 | +1606 | +47.2 |
| CHARGE NOW FIRST | 137 | 137 | 33 | 0.97 | -2714 | -82.3 |
| PATHS CROSS | 33 | 33 | 33 | 0.97 | +1261 | +38.2 |
| RESERVE FALL BACK | 32 | 32 | 32 | 0.94 | +1887 | +59.0 |
| NEXT CHARGE BY LIST | 397 | 361 | 31 | 0.91 | +1179 | +38.0 |
| WOUNDS ON THE RANKS | 150 | 143 | 30 | 0.88 | +671 | +22.4 |
| NEARER NOT NEEDED | 502 | 485 | 29 | 0.85 | +1004 | +34.6 |
| CANNON PLANNED TARGET | 205 | 205 | 27 | 0.79 | -426 | -15.8 |
| CASTING BLOCK | 38 | 38 | 27 | 0.79 | +1583 | +58.6 |
| HIS TURN DENIED | 117 | 115 | 27 | 0.79 | +1227 | +45.4 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.76 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.76 | +0 | +0.0 |
| COMBAT PIVOT | 25 | 25 | 25 | 0.74 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 160 | 160 | 25 | 0.74 | +0 | +0.0 |
| GUN MASK | 79 | 75 | 23 | 0.68 | +665 | +28.9 |
| OPENS UP | 27 | 25 | 21 | 0.62 | +394 | +18.8 |
| REDIRECT COUNTER | 147 | 114 | 21 | 0.62 | +1148 | +54.7 |
| MARCH BY THE SUM | 20 | 20 | 20 | 0.59 | +1302 | +65.1 |
| SHOOTERS IN TWO RANKS | 20 | 20 | 20 | 0.59 | +40 | +2.0 |
| MISSILES IN THE MOVE | 273 | 183 | 18 | 0.53 | +651 | +36.2 |
| CHAFF PASSED | 17 | 17 | 17 | 0.50 | -28 | -1.6 |
| FIRE IN ORDER | 17 | 17 | 17 | 0.50 | +0 | +0.0 |
| REDIRECT WEIGHED | 16 | 16 | 16 | 0.47 | +998 | +62.4 |
| AFTERMATH IN POINTS | 15 | 15 | 15 | 0.44 | +1694 | +112.9 |
| WHO HITS BACK | 15 | 15 | 15 | 0.44 | +1075 | +71.6 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.41 | +0 | +0.0 |
| HIS FIGHT TOGETHER | 147 | 138 | 14 | 0.41 | +546 | +39.0 |
| MARCH OF THE TABLE | 14 | 14 | 14 | 0.41 | -526 | -37.6 |
| MODEL FACING | 13 | 13 | 13 | 0.38 | +4526 | +348.1 |
| HONEST WORTH | 199 | 190 | 12 | 0.35 | +254 | +21.1 |
| ONE FIGHT FORMULA | 348 | 179 | 12 | 0.35 | +144 | +12.0 |
| SEARCH SPOT | 22 | 22 | 12 | 0.35 | +312 | +26.0 |
| SUPPORT NARROWED | 34 | 34 | 12 | 0.35 | -777 | -64.8 |
| FEATURE BUFFS | 118 | 115 | 11 | 0.32 | +398 | +36.2 |
| HIS CHARGE DENIED | 38 | 38 | 11 | 0.32 | +414 | +37.6 |
| REFUSING RETIRES | 35 | 35 | 11 | 0.32 | -5 | -0.4 |
| SECOND LOOK | 11 | 11 | 11 | 0.32 | +722 | +65.6 |
| STUCK PIVOT | 11 | 11 | 11 | 0.32 | +0 | +0.0 |
| WHO GETS IN | 11 | 11 | 11 | 0.32 | +191 | +17.4 |
| AFTERMATH WITH FRIENDS | 10 | 10 | 10 | 0.29 | +545 | +54.5 |
| ONE OBJECTIVE FORMULA | 289 | 209 | 10 | 0.29 | +889 | +88.9 |
| ONE PROMISE A TARGET | 10 | 10 | 10 | 0.29 | -423 | -42.3 |
| SURE REACH TOGETHER | 21 | 19 | 10 | 0.29 | +41 | +4.1 |
| MANOEUVRE | 52 | 52 | 9 | 0.26 | +135 | +15.0 |
| BEST PRIZE | 8 | 8 | 8 | 0.24 | -365 | -45.6 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.24 | -184 | -23.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.24 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.21 | +186 | +26.5 |
| PROMISE KNOWS THE FIGHT | 38 | 31 | 6 | 0.18 | -26 | -4.4 |
| WHOLE FIGHT GAIN | 14 | 13 | 6 | 0.18 | +273 | +45.6 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.15 | +175 | +35.1 |
| HIS MOVE AND SHOT | 218 | 202 | 5 | 0.15 | +95 | +18.9 |
| PROMISE READS THE TABLE | 26 | 26 | 5 | 0.15 | -208 | -41.5 |
| CHARGE NOT DECLARED | 4 | 4 | 4 | 0.12 | -1159 | -289.7 |
| FIGHT TO THE END | 46 | 44 | 4 | 0.12 | +31 | +7.9 |
| MISSILES NEXT TURN | 357 | 244 | 4 | 0.12 | +136 | +34.0 |
| PROMISE SHOT AWAY | 4 | 4 | 4 | 0.12 | -21 | -5.2 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.12 | -729 | -182.2 |
| WIDER SPREAD | 154 | 149 | 4 | 0.12 | +18 | +4.6 |
| FACES THE THREAT | 3 | 3 | 3 | 0.09 | +268 | +89.2 |
| FALL BACK GOOD ORDER | 165 | 159 | 3 | 0.09 | +23 | +7.6 |
| JOINT ON THE TABLE | 3 | 3 | 3 | 0.09 | +294 | +98.0 |
| LOST AFTER ESCAPE | 132 | 129 | 3 | 0.09 | +6 | +2.1 |
| NO DOUBLE ROUNDS | 201 | 193 | 3 | 0.09 | +33 | +11.1 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.09 | +42 | +14.2 |
| OVERRUNS AWAY | 20 | 20 | 3 | 0.09 | +57 | +18.9 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.09 | +185 | +61.6 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.09 | +346 | +115.2 |
| RUN DOWN | 166 | 162 | 3 | 0.09 | +23 | +7.6 |
| BLOWS WHERE AIMED | 23 | 23 | 2 | 0.06 | +172 | +86.1 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +71 | +35.3 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +21 | +10.4 |
| JOINT LOOK BACK | 2 | 2 | 2 | 0.06 | +36 | +17.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 45 | 45 | 2 | 0.06 | +0 | +0.0 |
| REFORMS TO MEET IT | 87 | 76 | 2 | 0.06 | +66 | +33.0 |
| ROUNDS AFTER TERROR | 67 | 66 | 2 | 0.06 | +52 | +26.0 |
| SPELLS IN THE FIGHT | 40 | 39 | 2 | 0.06 | +14 | +6.8 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.06 | -36 | -17.9 |
| WAR ENGINE JOBS | 16 | 16 | 2 | 0.06 | -76 | -38.0 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.03 | +54 | +53.7 |
| CHARGER SLAIN LOST | 28 | 28 | 1 | 0.03 | +10 | +9.6 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DENIED BY THE FIGHT | 48 | 48 | 1 | 0.03 | +81 | +81.4 |
| EDGE GIVE GROUND | 9 | 9 | 1 | 0.03 | +17 | +17.4 |
| FALLBACK BY WORTH | 17 | 17 | 1 | 0.03 | +8 | +8.4 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +18 | +18.4 |
| FRIEND CHARGES FIRST | 5 | 5 | 1 | 0.03 | +96 | +96.4 |
| GIVES UP | 26 | 24 | 1 | 0.03 | +18 | +17.7 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +23 | +23.2 |
| HUNT IN PAIRS | 12 | 5 | 1 | 0.03 | +41 | +40.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +2 | +2.0 |
| LONG SHOT | 17 | 17 | 1 | 0.03 | +42 | +41.8 |
| OPENS A LANE | 16 | 11 | 1 | 0.03 | +7 | +7.1 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.03 | +39 | +39.1 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +30 | +29.9 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.03 | +20 | +19.5 |
| SET UP TOGETHER | 19 | 13 | 1 | 0.03 | +4 | +3.5 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 14 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 58 | trace | - | - | - | - |
| CATCH FLIERS | 4 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 12 | 12 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 94 | 88 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 73 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 6 | 6 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 321 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 41 | 35 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 43 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 211 | 201 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 9 | 9 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 310 | 286 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 318 | 282 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 253 | 229 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 120 | 119 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 330 | 308 | 0 | 0.00 | - | - |
| HOLD ODDS | 1253 | 1240 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 197 | 190 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 17 | 17 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LOST CHARGE | 2 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 9 | 9 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 10 | trace | - | - | - | - |
| MARCH OVER CASTS | 54 | 54 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 90 | 88 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 20 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 4 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 28 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 9 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 62 | 61 | 0 | 0.00 | - | - |
| NOT TURNED | 14 | 14 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 28 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 328 | 305 | 0 | 0.00 | - | - |
| ONE ROUTE | 90 | 88 | 0 | 0.00 | - | - |
| PLAN RESULT | 2872 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 12 | 12 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 90 | 88 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 16 | 14 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 22 | 22 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SHOT OR CHARGE | 20 | 20 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 14 | not checked | - | - | - | - |
| SPELL WORTH | 131 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 622 | 590 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 40 | 38 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 97 | 85 | 0 | 0.00 | - | - |
| STANDS STILL | 2607 | 2513 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 24 | 21 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 115 | not checked | - | - | - | - |
| THE PROMISE ADDS | 7 | 6 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2258 | not checked | - | - | - | - |
| WAITS AGAIN | 107 | 94 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 13 | 13 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: base-s1-882d875-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.12 | 3.53 | 36.1 |
| PROMISE BY ITS OWN SUM | rule | 3.50 | 2.56 | 89.5 |
| ARMY TABLE | rule | 1.79 | 2.00 | 44.7 |
| HOLDER ASSIGNMENT | rule | 0.91 | 0.79 | 21.0 |
| NO REASON | gate | 0.65 | 0.68 | 56.4 |
| CHARGE NOW FIRST | rule | 0.41 | 0.56 | 82.3 |
| JOINT CHARGE NOW | rule | 0.32 | 0.47 | 64.0 |
| CHAFF PASSED | rule | 0.09 | 0.26 | 2.3 |
| MARCH OF THE TABLE | rule | 0.21 | 0.15 | 43.9 |
| SUPPORT NARROWED | rule | 0.09 | 0.26 | 64.8 |
| ONE PROMISE A TARGET | rule | 0.21 | 0.06 | 60.5 |
| BEST PRIZE | rule | 0.09 | 0.15 | 45.6 |
| CANNON PLANNED TARGET | rule | 0.12 | 0.12 | 53.7 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.18 | 23.0 |
| PROMISE KNOWS THE FIGHT | rule | 0.12 | 0.06 | 4.4 |
| FIGHT ORDER BAND | gate | 0.06 | 0.09 | 2.1 |
| SET UP BY THE SET | rule | 0.03 | 0.12 | 118.8 |
| WHO GETS IN | rule | 0.09 | 0.06 | 86.2 |
| CHARGE NOT DECLARED | rule | - | 0.12 | 289.7 |
| DEPLOY BY FIGURES | rule | 0.06 | 0.06 | 13.0 |
| PATHS CROSS | rule | - | 0.12 | 15.7 |
| PURSUES BIG PREY | rule | 0.03 | 0.09 | 182.2 |
| TURN GATE | gate | - | 0.12 | 21.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.09 | 31.9 |
| PROMISE READS THE TABLE | rule | 0.06 | 0.03 | 82.8 |
| PROMISE SHOT AWAY | rule | 0.09 | - | 6.9 |
| REFUSING RETIRES | rule | - | 0.09 | 0.9 |
| FALLBACK | gate | - | 0.06 | 7.8 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 9.8 |
| WAR ENGINE JOBS | rule | 0.06 | - | 38.0 |
| AFTERMATH BAND | gate | 0.03 | - | 3.7 |
| WALKS ON ITS ROUTE | rule | - | 0.03 | 35.7 |
| WHO HITS BACK | rule | 0.03 | - | 3.7 |

### Plans: base-s1-882d875-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.4 | 69% | 383 | 242 | 63% |
| Mine | join | 0.6 | 95% | 18 | 0 | 0% |
| Mine | move | 29.9 | 95% | 1576 | 0 | 0% |
| Mine | shoot | 9.0 | 55% | 611 | 531 | 87% |
| Mine | support | 0.4 | 69% | 0 | 0 | 0% |
| Opponent | charge | 3.1 | 51% | 481 | 309 | 64% |
| Opponent | join | 1.4 | 100% | 88 | 0 | 0% |
| Opponent | move | 33.5 | 95% | 1606 | 0 | 0% |
| Opponent | shoot | 3.3 | 52% | 201 | 125 | 62% |
| Opponent | support | 0.9 | 86% | 5 | 0 | 0% |

### Packages: hunt the guns, base-s1-882d875-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 413 | 0 | 0% | 18 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 103 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 413 | 0 | 0% | 63 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 62 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 157 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |

### Battle groups: base-s1-882d875-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.4 | 22% | 64% | 9% | 100% | 0% | 0% | 10% | 90% | 0% |
| Opponent | REDIRECT COUNTER | 2.9 | 20% | 85% | 15% | 33% | 12% | 0% | 0% | 76% | 12% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s1-882d875-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 81 (3) | 81 | 0 | 19 | 67% | 5.0 | - | 217 (1) | 0 (1) | - | 144 (2) |
| Mine | Chaff | 37 | 47 (37) | 11 | 36 | 38 | 57% | 2.1 | 60 (13) | 70 (15) | 0 (9) | 63 (27) | 15 (10) |
| Mine | Character | 116 | 48 (116) | 48 | 0 | 30 | 17% | 2.5 | 47 (37) | 47 (47) | 67 (19) | 54 (53) | 47 (50) |
| Mine | Clean-up | 21 | 50 (21) | 28 | 22 | 24 | 43% | 3.7 | 12 (10) | 109 (9) | 0 (2) | 30 (12) | 75 (9) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 47 | 25% | 2.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 36 | 50 (36) | 34 | 16 | 43 | 36% | 3.2 | 62 (16) | 44 (16) | 51 (4) | 54 (22) | 45 (14) |
| Mine | Hammer | 58 | 26 (58) | 6 | 20 | 37 | 28% | 2.7 | 24 (24) | 31 (27) | 12 (7) | 33 (37) | 15 (21) |
| Mine | Holder | 25 | 78 (25) | 0 | 78 | 13 | 56% | 3.2 | 137 (8) | 59 (12) | 31 (3) | 109 (14) | 37 (9) |
| Mine | Shooter | 44 | 75 (44) | 27 | 48 | 27 | 11% | 1.5 | 30 (9) | 83 (27) | 103 (8) | 85 (26) | 62 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | War machine | 53 | 30 (53) | 30 | 0 | 29 | 13% | 1.6 | 49 (20) | 18 (25) | 24 (8) | 0 (5) | 33 (48) |
| Mine | Wizard | 23 | 8 (23) | 8 | 0 | 11 | 13% | 2.4 | 8 (11) | 13 (6) | 0 (3) | 11 (9) | 6 (11) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 65 | 59 (65) | 13 | 46 | 37 | 60% | 2.9 | 81 (24) | 84 (22) | 2 (19) | 63 (47) | 45 (18) |
| Opponent | Character | 109 | 51 (109) | 51 | 0 | 27 | 34% | 2.3 | 51 (33) | 63 (53) | 37 (13) | 49 (58) | 62 (41) |
| Opponent | Clean-up | 15 | 34 (15) | 10 | 23 | 32 | 40% | 2.9 | 16 (5) | 47 (9) | 0 (1) | 38 (10) | 26 (5) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 52 | 30 (52) | 10 | 20 | 41 | 48% | 2.6 | 18 (17) | 37 (29) | 20 (6) | 26 (33) | 36 (19) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | 0 (2) | 0 (1) | 0 (2) |
| Opponent | Hammer | 62 | 23 (62) | 14 | 9 | 35 | 31% | 3.2 | 38 (17) | 16 (28) | 19 (17) | 29 (40) | 12 (22) |
| Opponent | Holder | 37 | 58 (37) | 6 | 52 | 18 | 57% | 3.4 | 62 (10) | 74 (18) | 44 (5) | 109 (14) | 35 (19) |
| Opponent | Shooter | 31 | 56 (31) | 15 | 41 | 32 | 13% | 1.9 | 62 (11) | 58 (12) | 40 (8) | 75 (21) | 15 (10) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 43 (13) | 43 | 0 | 33 | 8% | 1.2 | 57 (9) | 18 (2) | 0 (2) | 0 (2) | 50 (11) |
| Opponent | Wizard | 21 | 5 (21) | 5 | 0 | 25 | 14% | 2.3 | 0 (6) | 12 (9) | 0 (3) | 7 (9) | 5 (9) |

### Charged fights: base-s1-882d875-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 167 | 71 | 0.8 | 1.0 | 88 | 13 | +76 | 2 of 4 | 3 of 4 | - | +76 |
| Mine | Chaos Dwarfs | 3 | 147 | 774 | 3.3 | 1.1 | 232 | 0 | +232 | 6 of 10 | 7 of 10 | +145 | +242 |
| Mine | Dwarfen Mountain Holds | 4 | 369 | 15 | 0.5 | 1.0 | 30 | 0 | +30 | 1 of 2 | 2 of 2 | - | +30 |
| Mine | Empire of Man | 4 | 146 | 86 | 0.5 | 1.0 | 171 | 270 | -98 | 1 of 2 | 1 of 2 | - | -98 |
| Mine | Grand Cathay | 4 | 517 | 138 | 2.2 | 1.2 | 62 | 23 | +39 | 5 of 9 | 7 of 9 | +152 | +6 |
| Mine | High Elf Realms | 4 | 54 | 239 | 2.8 | 1.1 | 87 | 10 | +76 | 7 of 11 | 8 of 11 | +0 | +84 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 922 | 2.0 | 1.0 | 461 | 40 | +421 | 1 of 2 | 1 of 2 | - | +421 |
| Mine | Ogre Kingdoms | 1 | 140 | 195 | 2.0 | 1.0 | 98 | 0 | +98 | 1 of 2 | 2 of 2 | - | +98 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 469 | 5.0 | 1.0 | 94 | 21 | +73 | 2 of 5 | 4 of 5 | - | +73 |
| Mine | Skaven | 2 | 25 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1178 | 4.5 | 1.0 | 262 | 60 | +202 | 4 of 9 | 8 of 9 | - | +202 |
| Mine | Vampire Counts | 2 | 0 | 507 | 4.0 | 1.5 | 127 | 54 | +73 | 3 of 8 | 8 of 8 | +73 | +73 |
| Mine | Warriors of Chaos | 1 | 0 | 216 | 4.0 | 1.0 | 54 | 0 | +54 | 1 of 4 | 4 of 4 | - | +54 |
| **Mine** | all armies | 34 | 171 | 287 | 2.0 | 1.1 | 141 | 30 | +112 | 34 of 69 | 55 of 69 | +95 | +113 |
| Opponent | Beastmen Brayherds | 1 | 55 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Dwarfen Mountain Holds | 1 | 422 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 255 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 120 | 705 | 6.0 | 1.0 | 118 | 0 | +118 | 2 of 6 | 5 of 6 | - | +118 |
| Opponent | High Elf Realms | 2 | 190 | 260 | 4.0 | 1.0 | 65 | 36 | +29 | 3 of 8 | 5 of 8 | - | +29 |
| Opponent | Ogre Kingdoms | 2 | 42 | 0 | 2.0 | 1.2 | 0 | 0 | +0 | 4 of 4 | 1 of 4 | +0 | +0 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 518 | 3.0 | 1.0 | 172 | 9 | +163 | 3 of 6 | 5 of 6 | - | +163 |
| Opponent | Skaven | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 3 | 111 | 559 | 3.7 | 1.3 | 152 | 12 | +141 | 8 of 11 | 10 of 11 | -8 | +173 |
| Opponent | Vampire Counts | 6 | 34 | 520 | 3.5 | 1.3 | 148 | 12 | +137 | 9 of 21 | 10 of 21 | +135 | +138 |
| Opponent | Warriors of Chaos | 7 | 18 | 239 | 1.1 | 1.0 | 210 | 107 | +102 | 5 of 8 | 4 of 8 | - | +102 |
| Opponent | Wood Elf Realms | 6 | 136 | 484 | 4.0 | 1.1 | 121 | 36 | +85 | 16 of 24 | 15 of 24 | +405 | +39 |
| **Opponent** | all armies | 34 | 82 | 342 | 2.6 | 1.2 | 129 | 27 | +102 | 52 of 90 | 55 of 90 | +165 | +92 |

### Effective charges: base-s1-882d875-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 3 (net +101) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 10 | 2 (net +253) | 1 (net +210) | 1 (net +691) | 0 | 3 (net +110) | 2 (net +292) | 1 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 1 (net +0) | 1 (net +60) | 0 | 0 | 0% (0 of 2) |
| Mine | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net -539) | 1 | 0% (0 of 1) |
| Mine | Grand Cathay | 9 | 0 | 0 | 1 (net +0) | 5 (net +9) | 1 (net +116) | 1 (net +188) | 1 | 12% (1 of 8) |
| Mine | High Elf Realms | 11 | 2 (net +78) | 0 | 2 (net -28) | 1 (net +0) | 1 (net +0) | 4 (net +166) | 1 | 20% (2 of 10) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net +479) | 0 | 0 | 0 | 1 (net +363) | 0 | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 2 (net +101) | 0 | 3 | 0% (0 of 2) |
| Mine | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net +367) | 0 | 1 (net +725) | 2 (net +246) | 0 | 2 (net +301) | 3 | 17% (1 of 6) |
| Mine | Vampire Counts | 8 | 0 | 0 | 1 (net +0) | 1 (net +365) | 2 (net +85) | 4 (net +12) | 0 | 12% (1 of 8) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 1 (net +109) | 1 (net +107) | 0 | 2 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 6 | 2 (net +140) | 0 | 0 | 3 (net +107) | 0 | 1 (net +105) | 0 | 0% (0 of 6) |
| Opponent | High Elf Realms | 8 | 0 | 0 | 1 (net +0) | 1 (net +125) | 0 | 2 (net +62) | 4 | 25% (1 of 4) |
| Opponent | Ogre Kingdoms | 4 | 3 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 0 | 1 (net +347) | 0 | 1 (net +110) | 1 (net +177) | 3 | 33% (1 of 3) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 11 | 2 (net +328) | 0 | 1 (net +0) | 0 | 2 (net +17) | 4 (net +214) | 2 | 11% (1 of 9) |
| Opponent | Vampire Counts | 21 | 7 (net -28) | 2 (net +210) | 4 (net +60) | 0 | 0 | 7 (net +324) | 1 | 20% (4 of 20) |
| Opponent | Warriors of Chaos | 8 | 2 (net +215) | 1 (net +259) | 2 (net -60) | 0 | 0 | 2 (net +270) | 1 | 29% (2 of 7) |
| Opponent | Wood Elf Realms | 24 | 8 (net -58) | 1 (net +347) | 1 (net +0) | 2 (net +0) | 1 (net +0) | 9 (net +242) | 2 | 5% (1 of 22) |

### Charged fights, damage counted: base-s1-882d875-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 239 | 212 | +165 | 189 | 24 | +165 | +68.9 |
| Mine | 50-54% | 1 | 339 | 222 | +210 | 210 | 0 | +210 | +61.9 |
| Mine | Effective (55-75%) | 6 | 227 | 241 | +227 | 246 | 27 | +219 | +96.5 |
| Mine | 76-89% | 12 | 365 | 263 | +84 | 104 | 34 | +70 | +19.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 356 | 322 | +111 | 228 | 103 | +125 | +35.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 468 | 90 | +112 | 132 | 7 | +126 | +26.8 |
| Mine | No odds | 13 | 303 | 226 | +31 | 96 | 57 | +39 | +12.9 |
| Mine | All fights | 69 | 337 | 227 | +112 | 160 | 45 | +115 | +34.2 |
| Opponent | Long shot (under 50%) | 26 | 228 | 280 | +27 | 96 | 77 | +19 | +8.5 |
| Opponent | 50-54% | 4 | 464 | 222 | +256 | 258 | 0 | +258 | +55.7 |
| Opponent | Effective (55-75%) | 10 | 315 | 237 | +47 | 75 | 24 | +51 | +16.1 |
| Opponent | 76-89% | 6 | 333 | 166 | +74 | 80 | 12 | +68 | +20.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 393 | 209 | +231 | 254 | 28 | +226 | +57.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 310 | 68 | +36 | 51 | 15 | +36 | +11.6 |
| Opponent | No odds | 13 | 245 | 231 | +13 | 84 | 57 | +27 | +11.1 |
| Opponent | All fights | 90 | 311 | 227 | +102 | 144 | 43 | +100 | +32.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s1-882d875-p1 | move | 258 | 47 (18%) | 32 (12%) | 45 (17%) | 166 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0733, L1021 |
| Witch Hunter's Ward | Mine | L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

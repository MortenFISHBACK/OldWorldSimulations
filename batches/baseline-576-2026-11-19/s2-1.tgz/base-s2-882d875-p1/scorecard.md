# Doctrine scorecard: base-s2-882d875-p1

### Scorecard: base-s2-882d875-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 2 | Mine | no | 4 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 2 | Opponent | no | 2 | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 2 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 2 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 77 |
| L0135 | 3 | 2 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 2 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 2 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 2 | Opponent | - | - | - | 4 | 0 | 0 | 0 | 0 | 77 |
| L0235 | 1 | 2 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 2 | Opponent | yes | 0 | 5 | 0 | 6 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 2 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 501 |
| L0319 | 1 | 2 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 2 | Mine | no | 8 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 2 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 963 |
| L0421 | 1 | 2 | Mine | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 65 |
| L0421 | 1 | 2 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 500 |
| L0508 | 4 | 2 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 190 |
| L0508 | 4 | 2 | Opponent | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 515 |
| L0524 | 2 | 2 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 797 |
| L0524 | 2 | 2 | Opponent | - | - | 3 | 2 | 6 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 2 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 390 |
| L0612 | 6 | 2 | Opponent | no | 6 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L0628 | 4 | 2 | Mine | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 568 |
| L0628 | 4 | 2 | Opponent | no | 11 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0733 | 1 | 2 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 45 |
| L0733 | 1 | 2 | Opponent | no | 1 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 2 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 717 |
| L0823 | 1 | 2 | Opponent | no | 0 | 2 | 5 | 5 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 2 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 221 |
| L0913 | 1 | 2 | Opponent | yes | 6 | 2 | 2 | 1 | 2 | 0 | 0 | 0 |
| L0930 | 6 | 2 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 516 |
| L0930 | 6 | 2 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 2 | Mine | no | 0 | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 2 | Opponent | yes | 6 | - | 0 | 5 | 0 | 0 | 0 | 565 |
| L1114 | 4 | 2 | Mine | no | 10 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1114 | 4 | 2 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 2 | Mine | no | 10 | - | 3 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 2 | Opponent | yes | 8 | 3 | 2 | 2 | 1 | 0 | 0 | 340 |
| L1224 | 6 | 2 | Mine | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1224 | 6 | 2 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 2 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 177 |
| L1319 | 5 | 2 | Opponent | no | - | 2 | 3 | 3 | 0 | 0 | 0 | 398 |
| L1335 | 3 | 2 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 2 | Opponent | no | 3 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 2 | Mine | no | 1 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 2 | Opponent | no | 0 | 3 | 5 | 1 | 1 | 0 | 0 | 484 |
| L1527 | 3 | 2 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 176 |
| L1527 | 3 | 2 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 2 | Mine | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 336 |
| L1625 | 5 | 2 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 2 | Mine | yes | - | - | 3 | 1 | 0 | 0 | 0 | 225 |
| L1823 | 5 | 2 | Opponent | yes | - | 2 | 6 | 3 | 0 | 0 | 0 | 60 |
| L1923 | 3 | 2 | Mine | no | 2 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 2 | Opponent | no | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 162 |
| L2025 | 3 | 2 | Mine | no | 12 | - | 0 | 3 | 0 | 0 | 0 | 617 |
| L2025 | 3 | 2 | Opponent | no | 0 | 6 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 2 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 290 |
| L2127 | 3 | 2 | Opponent | no | 12 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 2 | Mine | yes | - | 1 | 7 | 1 | 0 | 0 | 0 | 144 |
| L2231 | 5 | 2 | Opponent | no | - | 2 | 3 | 1 | 1 | 0 | 0 | 456 |
| L2335 | 1 | 2 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 2 | Opponent | no | 4 | 1 | 3 | 0 | 0 | 0 | 0 | 235 |
| L2531 | 5 | 2 | Mine | no | - | 5 | 3 | 4 | 0 | 0 | 0 | 50 |
| L2531 | 5 | 2 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 2 | Mine | no | 2 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 2 | Opponent | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 168 |
| L2934 | 6 | 2 | Mine | no | 12 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L2934 | 6 | 2 | Opponent | no | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 358 |
| **Average** | | | Mine | 12% | 2.8 | 2.5 | 2.0 | 1.5 | 0.1 | 0.0 | 0.0 | 192.2 |
| **Average** | | | Opponent | 22% | 2.7 | 2.6 | 2.6 | 2.3 | 0.3 | 0.0 | 0.0 | 164.6 |

### KPIs: base-s2-882d875-p1

Morten 2026-11-10; 34 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (47 of 150) | 4% (6 of 151) | 18% (53 of 301) |
| Winner chose to follow up after the loser gave ground |  | 89% (39 of 44); on the table 95% | 89% (33 of 37); on the table 92% | 89% (72 of 81); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 43% (3 of 7); on the table 43% | 85% (11 of 13); on the table 85% | 70% (14 of 20); on the table 70% |
| Winner chose to pursue after the loser fled |  | 70% (16 of 23); on the table 83% | 61% (11 of 18); on the table 67% | 66% (27 of 41); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 78% (58 of 74); on the table 86% | 81% (55 of 68); on the table 84% | 80% (113 of 142); on the table 85% |
| Magic missiles tried each own turn | 50%+ | 32% (113 of 348) | 34% (63 of 186) | 33% (176 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (113 of 295) | 40% (63 of 158) | 39% (176 of 453) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 52% (15 of 29) | 46% (19 of 41) | 49% (34 of 70) |
| Points that never fought | lower | 49% (32861 of 67485) | 50% (34203 of 67889) | 50% (67064 of 135374) |
|   infantry points that never fought | lower | 65% (10687 of 16336) | 65% (8203 of 12598) | 65% (18890 of 28934) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (164 of 262) | 69% (195 of 283) | 66% (359 of 545) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.7 uses a game | 75% (15 of 20); 1.6 uses a game | 81% (34 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 33% (5 of 15); 0.5 uses a game | 25% (2 of 8); 0.1 uses a game | 30% (7 of 23); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 44% (8 of 18); 0.2 uses a game | 75% (9 of 12); 0.3 uses a game | 57% (17 of 30); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (31864 of 56251) | 62% (37007 of 59638) | 59% (68871 of 115889) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.5 (51%) | 1.7 (47%) | 5.2 (49%) |
| MARCHED: its unit marched | 1.1 (16%) | 0.7 (20%) | 1.8 (17%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.1 (2%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 0.8 (11%) | 0.3 (8%) | 1.1 (10%) |
| REAR RANK: in a rear rank | 0.4 (6%) | 0.0 (1%) | 0.4 (4%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.4 (6%) | 0.3 (9%) | 0.7 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.2 (5%) | 0.5 (5%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.8 | 3.2 | 5.2 | 0.6 | 0.8 |
| not cast | 3.7 | 2.9 | 2.8 | 10.5 | 1.7 | 21.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (61%) | 0.3 (9%) | 5.2 (49%) | 0.4 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (17%) | 0.3 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.1 (2%) | 0.2 (6%) | 1.1 (10%) | 0.2 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (14%) | 0.4 (14%) | 0.7 (24%) | 0.4 (4%) | 0.2 (11%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.0 (2%) | 0.2 (1%) |
| GONE: slain | 0.3 (8%) | 0.1 (3%) | 0.4 (15%) | 0.7 (7%) | 0.0 (0%) | 1.1 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (6%) | 0.1 (5%) | 0.5 (5%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (4%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.4 (26%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.6 (70%) | 0.2 (8%) | 1.0 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.1 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 1.5 a game | 1.8 a game |
| stood (cast and not dispelled) | 78% (51 of 65) | 60% (31 of 52) | 70% (82 of 117) |
| the unit moved after it | 41% (21 of 51) | 61% (19 of 31) | 49% (40 of 82) |
| it charged on its next turn | 0% (0 of 51) | 3% (1 of 31) | 1% (1 of 82) |
| the enemy charged it first | 10% (5 of 51) | 6% (2 of 31) | 9% (7 of 82) |
| it fought by the end of its next turn | 4% (2 of 51) | 3% (1 of 31) | 4% (3 of 82) |
| it moved out of a charge the enemy had planned (not charged first) | 4% (2 of 51) | 3% (1 of 31) | 4% (3 of 82) |
| none of these (no charge, no fight, no charge escaped) | 86% (44 of 51) | 87% (27 of 31) | 87% (71 of 82) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (544 of 901) | 60% (338 of 567) | 60% (882 of 1468) |
|   cavalry | 61% (48 of 79) | 64% (85 of 133) | 63% (133 of 212) |
|   character | 53% (67 of 126) | 43% (51 of 118) | 48% (118 of 244) |
|   chariot | 52% (48 of 92) | 82% (28 of 34) | 60% (76 of 126) |
|   infantry | 55% (160 of 291) | 57% (116 of 204) | 56% (276 of 495) |
|   monster | 59% (19 of 32) | 62% (15 of 24) | 61% (34 of 56) |
|   war machine | 72% (202 of 281) | 80% (43 of 54) | 73% (245 of 335) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (14%) | 1.2 (18%) | 2.7 (16%) |
| CHARGED: it charged | 0.8 (7%) | 1.2 (17%) | 1.9 (11%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (5%) | 0.1 (2%) | 0.6 (4%) |
| MOVED: a war machine that moved | 1.6 (15%) | 0.3 (4%) | 1.9 (11%) |
| NO TARGET IN RANGE | 2.8 (27%) | 2.3 (34%) | 5.1 (29%) |
| ONLY IN COMBAT: the only targets were in combat | 0.9 (8%) | 0.5 (7%) | 1.4 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (18%) | 1.0 (14%) | 2.9 (17%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (3%) | 0.1 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 1.3 | 81% | 4.6 pts | 26 pts |
| character | 3.8 | 0.8 | 81% | 4.4 pts | 17 pts |
| chariot | 2.2 | 1.6 | 58% | 12.9 pts | 29 pts |
| infantry | 11.8 | 3.7 | 77% | 7.7 pts | 91 pts |
| monster | 1.2 | 0.3 | 82% | 6.6 pts | 8 pts |
| war machine | 7.2 | 4.9 | 66% | 20.1 pts | 145 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.3 | 3.7 |
| Charges that made contact a game | 2.3 | 2.9 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.77 declared, 0.55 contact (22 units) | 0.57 declared, 0.43 contact (14 units) | 0.69 declared, 0.50 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.50 declared, 1.25 contact (4 units) | 1.00 declared, 0.86 contact (7 units) | 1.18 declared, 1.00 contact (11 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.25 contact (243 units) | 0.47 declared, 0.31 contact (280 units) | 0.40 declared, 0.28 contact (523 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (39 of 67) | 80% (16 of 20) | 50% (4 of 8) | 62% (59 of 95) |
| Character in a unit | 84% (36 of 43) | 69% (20 of 29) | 60% (3 of 5) | 77% (59 of 77) |
| Character on its own | 88% (35 of 40) | 61% (19 of 31) | 26% (14 of 54) | 54% (68 of 125) |
| Chariot | 88% (14 of 16) | 90% (9 of 10) | - | 88% (23 of 26) |
| Infantry | 64% (55 of 86) | 50% (18 of 36) | 50% (1 of 2) | 60% (74 of 124) |
| Monster | 67% (16 of 24) | 80% (8 of 10) | - | 71% (24 of 34) |
| Monstrous | 73% (8 of 11) | 86% (12 of 14) | - | 80% (20 of 25) |
| War Machines | 82% (31 of 38) | 100% (1 of 1) | - | 82% (32 of 39) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 82% (9 of 11); on the table 82% | 31% (50 of 162) | 54% | 64% (21 of 33) | 89% (8 of 9); 4.3 uses a game | 100% (3 of 3); 2.2 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 60% (3 of 5); on the table 80% | 42% (10 of 24) | 60% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 83% (5 of 6); on the table 83% | - | 70% | 83% (34 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 33% (1 of 3); on the table 67% | 54% (13 of 24) | 63% | 74% (40 of 54) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 5 | 64% (9 of 14); on the table 79% | 36% (43 of 120) | 46% | 50% (22 of 44) | 92% (11 of 12); 5.6 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 92% (12 of 13); on the table 92% | 17% (5 of 30) | 39% | 47% (23 of 49) | 100% (5 of 5); 3.5 uses a game | 22% (4 of 18); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 80% (4 of 5); on the table 100% | - | 39% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 3 | 100% (1 of 1); on the table 100% | - | 66% | 81% (17 of 21) | 67% (2 of 3); 1.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (2 of 2); on the table 100% | 17% (4 of 24) | 38% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 4 | 80% (8 of 10); on the table 90% | 17% (5 of 30) | 51% | 76% (26 of 34) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 5 | 75% (15 of 20); on the table 80% | - | 41% | 28% (7 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 85% (28 of 33); on the table 88% | 42% (28 of 66) | 49% | 72% (36 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 77% (10 of 13); on the table 77% | 23% (7 of 30) | 35% | 76% (56 of 74) | 100% (4 of 4); 2.5 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (6 of 6); on the table 100% | 46% (11 of 24) | 52% | 68% (45 of 66) | 33% (2 of 6); 1.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (base-s2-882d875-p1, 34 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 54% (31) | 39% (21) | 47% (52) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.38 | 0.94 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.18 | 0.15 | 0.32 |
| ...with the charger already in that arc before they moved (per game) | 0.32 | 0.32 | 0.65 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.15 | 0.15 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.26 | 0.32 | 0.59 |

### Quality by phase: base-s2-882d875-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 55% (47 of 86) | 51% (63 of 123) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (153 of 374) | 52% (80 of 154) |
| Strategy | Support requests answered (helper made contact too) | 25% (1 of 4) | 47% (9 of 19) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 43% (6 of 14) | 47% (7 of 15) |
| Strategy | Joined characters whose unit fought | 37% (22 of 60) | 31% (15 of 49) |
| Strategy | Lone characters that fought | 68% (54 of 79) | 67% (54 of 81) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.5 | 2.3 |
| Movement | Points that never moved of their own | 192.2 | 164.6 |
| Movement | Fights charged into per game | 2.1 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 16 of 61, net +115 | 16 of 66, net +152 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 61, net -21 | 11 of 66, net +27 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 61, net +13 | 6 of 66, net +294 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 of 61, net +138 | 16 of 66, net +134 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.6 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (176 of 360) | 45% (144 of 318) |
| Shooting | Points destroyed by shooting units | 64.9 | 9.4 |
| Shooting | War machine shots | 5.9 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (124 of 202) | 42% (18 of 43) |
| Shooting | Points destroyed by war machines | 52.5 | 18.9 |
| Magic | Magic missiles cast | 2.0 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (20 of 69) | 32% (12 of 38) |
| Magic | Wounds caused by magic missiles | 3.9 | 0.9 |
| Magic | Wounds caused by other spells | 0.2 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 41.5 | 23.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.9 / 0.5 / 0.2 / 0.3 | 1.8 / 0.6 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 188.5 | 283.6 |
| Combat | Points run down | 36.9 | 73.9 |
| Combat | Net points per charged fight, damage counted | +81 | +109 |
| Combat | Net per 100 charger points, damage counted | +26.5 | +39.4 |
| Combat | First round won (charged fights) | 69% | 72% |
| Combat | Net points per charged fight | +80 | +109 |
| Combat | Net points per supported fight / lone fight | +121 / +76 | +227 / +92 |
| Combat | Charged fights on a top-3 enemy unit | 22 of 72 | 39 of 88 |
| Game | Points lost | 544.6 | 549.5 |
| Game | VP from objectives | 682.1 | 659.4 |
| Game | Lone holders (player turns) | 2.8 | 2.7 |

- Mine won / drew / lost: 13 / 9 / 12 of 34 ended games (of 34); mean margin (Mine - Opponent) +38 VP
- The side that went first won 13 of 25 games with a winner
- Points traded per game (both sides' losses): 1094
- Games not ended: 0; findings 12, warnings 0

### Opponent rules: base-s2-882d875-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +12.6 | 0.0 | 10.9 | 0.1 | +32.8 | 0.0 | 17.7 |
| AFTERMATH WITH FRIENDS | 0.1 | +4.3 | 0.0 | 0.0 | 0.2 | +10.1 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 18.2 | +236.9 | 0.0 | 193.0 | 22.1 | +227.9 | 0.0 | 263.8 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 8.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.9 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 2.7 |
| BEST OVERALL | - | - | - | - | 0.0 | +2.1 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | -4.3 | 0.0 | 10.9 | 0.3 | -15.7 | 23.6 | 5.5 |
| BLOWS WHERE AIMED | 0.3 | -43.7 | 20.0 | 1.5 | 0.2 | -18.4 | 37.7 | 5.7 |
| BOMBING RUN | 0.1 | +5.9 | 0.0 | 8.8 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.4 | - | - | - | - |
| CANNON PLAN MISSED | 0.2 | +0.0 | 55.4 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.4 | +128.9 | 394.7 | 72.4 | 1.2 | +33.7 | 34.9 | 16.9 |
| CANNON SIGHT KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.9 | +13.0 | 18.3 | 5.0 | 0.4 | +12.8 | 7.2 | 22.3 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.8 | +82.4 | 0.0 | 0.0 | 0.2 | +8.5 | 3.2 | 0.0 |
| CASTS AFTER FRIENDS | 1.4 | +0.0 | 0.0 | 32.6 | 0.9 | +0.0 | 0.0 | 35.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.2 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.8 | +23.4 | 0.0 | 8.0 | 1.5 | +76.6 | 0.0 | 43.3 |
| CHAFF PASSED | 0.1 | -0.5 | 0.0 | 0.0 | 0.2 | -0.4 | 7.5 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.1 | +0.6 | 0.0 | 8.4 | 0.1 | -2.2 | 10.9 | 3.7 |
| CHARACTER GUNS | 1.7 | +0.0 | 0.0 | 41.2 | 0.9 | +0.0 | 0.0 | 26.1 |
| CHARGE LOSSES | 10.2 | -450.0 | 0.0 | 220.5 | 11.4 | -720.5 | 0.0 | 292.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.1 | +0.0 | 1.3 | 0.0 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 169.7 | 86.5 | 1.7 | +0.0 | 229.8 | 36.6 |
| CHARGER SLAIN LOST | 0.2 | -6.5 | 5.2 | 7.3 | 0.3 | -7.3 | 37.1 | 23.3 |
| COMBAT PIVOT | 0.4 | +0.0 | 14.1 | 7.8 | 0.2 | +0.0 | 7.5 | 10.0 |
| CONVEYANCE SEARCH | 1.7 | +254.9 | 11.8 | 25.0 | 1.4 | +135.4 | 63.5 | 47.3 |
| COVER ONCE | 5.6 | -400.0 | 0.0 | 142.4 | 4.0 | -272.8 | 0.0 | 108.2 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | -2.7 | 0.0 | 0.0 | 0.0 | -0.4 | 17.1 | 0.0 |
| DENIED BY THE FIGHT | 0.2 | -1.7 | 15.5 | 3.8 | 0.9 | -9.6 | 111.9 | 39.1 |
| DEPLOY BY FIGURES | 8.0 | +19.8 | 0.0 | 5.6 | 7.6 | +66.8 | 0.0 | 19.6 |
| EDGE GIVE GROUND | 0.2 | +2.8 | 26.3 | 11.2 | 0.3 | +9.3 | 46.6 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +1.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.9 | +2.5 | 145.1 | 105.9 | 2.9 | +9.9 | 289.7 | 58.5 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.2 | 0.0 | 14.3 |
| FALLS SHORT | 5.7 | +81.0 | 0.0 | 70.9 | 16.0 | +230.0 | 0.0 | 239.9 |
| FEATURE BUFFS | 1.9 | +72.4 | 0.0 | 19.8 | 0.8 | +44.8 | 0.0 | 10.8 |
| FIGHT LIFT | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +26.5 | 31.8 | 20.7 | 0.8 | +16.5 | 75.4 | 3.8 |
| FIRE IN ORDER | 0.2 | +0.0 | 5.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 90.0 | +5797.3 | 1465.9 | 891.4 | 85.1 | +4877.0 | 594.3 | 1228.7 |
| FLANK NOT WEIGHED | 4.5 | +0.0 | 0.0 | 83.0 | 3.6 | +0.0 | 0.0 | 166.1 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 1.6 | 6.9 |
| FOLLOW UP WEIGHED | 0.6 | +89.4 | 0.0 | 37.7 | 0.6 | +77.1 | 0.0 | 14.9 |
| FOUR ROUNDS | 2.8 | +248.3 | 208.5 | 105.9 | 3.9 | +285.3 | 387.4 | 85.0 |
| FRIEND CHARGES FIRST | 0.0 | -0.3 | 0.0 | 0.0 | 0.0 | -1.8 | 0.0 | 17.6 |
| FRIEND SHOOTS FIRST | 0.5 | -21.5 | 5.7 | 0.0 | 0.4 | -2.4 | 0.0 | 17.6 |
| FRIENDS SHOTS CHECKED | 0.1 | +2.0 | 0.0 | 0.0 | 0.1 | +6.0 | 0.0 | 6.4 |
| GIVES UP | 0.2 | -5.1 | 17.4 | 1.5 | 0.5 | -7.7 | 41.1 | 3.4 |
| GUN FIGURES | 1.1 | +9.1 | 31.4 | 21.0 | 0.7 | +11.4 | 13.3 | 14.7 |
| GUN MASK | 1.5 | +34.6 | 0.0 | 14.2 | 0.2 | +1.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 19.2 | 2.0 | +0.0 | 0.0 | 13.9 |
| HE SHOOTS OR CHARGES | 2.5 | +0.0 | 0.0 | 92.9 | 2.7 | +0.0 | 0.0 | 104.2 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 2.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.4 | +21.5 | 18.4 | 23.8 | 0.4 | +26.6 | 47.1 | 24.7 |
| HIS CHARGE LIST | 5.2 | +0.0 | 0.0 | 105.5 | 5.2 | +0.0 | 0.0 | 115.3 |
| HIS FIGHT TOGETHER | 1.6 | -68.7 | 0.0 | 64.5 | 1.7 | -73.1 | 0.0 | 82.1 |
| HIS LEGAL MOVES | 4.8 | +0.0 | 0.0 | 74.1 | 4.6 | +0.0 | 0.0 | 75.7 |
| HIS MOVE AND SHOT | 3.0 | -43.3 | 0.0 | 88.4 | 4.1 | -88.5 | 0.0 | 117.1 |
| HIS MOVE AS HE DECIDES | 38.9 | +13.6 | 582.5 | 0.0 | 35.5 | +13.0 | 545.0 | 0.0 |
| HIS MOVE WHY | 36.4 | +0.0 | 0.0 | 351.9 | 37.8 | +0.0 | 0.0 | 558.4 |
| HIS ONE MOVE | 17.9 | -8.4 | 0.0 | 108.2 | 18.5 | +47.7 | 2.5 | 142.5 |
| HIS ONE QUARTER | 3.1 | +0.0 | 0.0 | 18.5 | 4.0 | +0.0 | 0.0 | 103.7 |
| HIS OWN BEST MOVE | 1.8 | +0.0 | 0.0 | 35.3 | 1.6 | +0.0 | 0.0 | 23.2 |
| HIS RANDOM MOVE | 4.1 | +0.0 | 0.0 | 8.1 | 4.0 | +0.0 | 0.0 | 28.3 |
| HIS SHOT LIST | 33.6 | +838.4 | 0.0 | 433.9 | 48.0 | +2135.9 | 0.0 | 695.8 |
| HIS TURN DENIED | 1.0 | +18.7 | 95.6 | 21.0 | 2.0 | +82.2 | 218.4 | 55.5 |
| HOLD ODDS | 17.4 | +0.0 | 0.0 | 72.7 | 16.5 | +0.0 | 0.0 | 146.9 |
| HOLDER ASSIGNMENT | 10.3 | +948.4 | 0.0 | 33.4 | 10.2 | +987.4 | 0.0 | 73.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -94.1 | 203.1 | 100.5 | 3.4 | -136.3 | 338.5 | 55.3 |
| HUNT IN PAIRS | 0.3 | +6.7 | 0.0 | 0.0 | 0.4 | +33.5 | 0.0 | 11.5 |
| HUNT RESULT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.0 | +16.1 | 0.0 | 3.4 |
| IDLE COST | 4.4 | -53.9 | 0.0 | 68.4 | 11.6 | -168.1 | 0.0 | 163.5 |
| JOINT CHARGE NOW | 0.4 | -10.5 | 31.1 | 1.5 | 0.9 | +41.1 | 106.4 | 50.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -1.8 | 21.7 | 5.5 |
| JOINT LOOK BACK | 0.0 | +0.3 | 2.2 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 3.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 10.8 | 3.0 | +0.0 | 0.0 | 23.1 |
| LANE BY FIGURES | 0.8 | +29.5 | 0.0 | 0.0 | 0.7 | +35.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 1.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.5 | +0.0 | 172.1 | 265.4 | 5.3 | +0.0 | 301.7 | 170.8 |
| LONE CHARACTER SAFE SPOT | 0.0 | +0.0 | 1.1 | 1.3 | 0.0 | +3.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.9 | 0.0 | 2.8 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -2.0 | 4.2 | 2.3 | 0.2 | +0.9 | 21.0 | 3.7 |
| LOST AFTER ESCAPE | 1.8 | +5.9 | 119.3 | 62.1 | 2.3 | +1.1 | 251.1 | 56.2 |
| LOST CHARGE | 0.1 | -0.1 | 4.1 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -3.7 | 0.0 | 0.0 | 0.1 | -10.3 | 0.0 | 6.7 |
| MAKE SURE TOGETHER | 0.2 | +30.8 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 3.4 |
| MANOEUVRE | 0.9 | +6.4 | 0.0 | 0.0 | 0.6 | +2.6 | 0.0 | 10.5 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 8.1 |
| MARCH BY THE SUM | 0.3 | +17.6 | 0.0 | 0.0 | 0.2 | +14.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +38.8 | 0.0 | 2.4 | 0.7 | +38.6 | 0.0 | 35.1 |
| MARCH OF THE TABLE | 0.2 | +2.9 | 0.0 | 0.0 | 0.2 | +10.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.9 | +33.6 | 0.0 | 0.0 | 0.6 | +51.9 | 0.0 | 27.5 |
| MARCH WHEELS ONLY | 1.1 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 14.8 |
| MAX FOR POSITIONING | 2.8 | +89.5 | 0.0 | 22.9 | 3.1 | +75.7 | 0.0 | 76.9 |
| MISSILES IN THE MOVE | 4.9 | +169.4 | 0.0 | 41.8 | 3.6 | +41.4 | 0.0 | 83.0 |
| MISSILES NEXT TURN | 5.9 | +110.4 | 0.0 | 41.8 | 4.7 | +37.3 | 0.0 | 113.2 |
| MISSILES ON ONE TARGET | 0.4 | -17.9 | 0.0 | 0.0 | 0.1 | -1.6 | 0.0 | 0.0 |
| MODEL FACING | 0.3 | +52.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.8 | +0.0 | 22.7 | 0.0 | 2.7 | +0.0 | 26.5 | 21.3 |
| MOVE SPELL IN RANGE | - | - | - | - | 0.1 | +1.2 | 0.0 | 16.1 |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -22.0 | 0.0 | 0.0 | 0.2 | -12.5 | 35.2 | 8.1 |
| MOVE SPELL SPOT | 0.9 | +0.0 | 0.0 | 11.8 | 0.4 | +0.0 | 0.0 | 13.8 |
| MOVE TO CHARGE COMPUTED | 6.6 | +740.3 | 0.0 | 77.5 | 7.0 | +622.4 | 0.0 | 127.1 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.9 | +279.6 | 0.0 | 64.4 | 7.2 | +302.8 | 0.0 | 89.1 |
| NEXT CHARGE BY LIST | 5.9 | -206.1 | 5.7 | 90.2 | 6.6 | -312.5 | 22.1 | 99.1 |
| NEXT OBJECTIVE NEARER | 0.2 | -7.5 | 0.0 | 1.9 | 0.1 | -0.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.4 | -124.7 | 181.3 | 102.0 | 3.2 | -138.0 | 335.0 | 73.3 |
| NO LATE CUT | 0.9 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 8.2 |
| NO RALLY LEFT | 0.0 | +0.1 | 0.0 | 2.1 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 1.3 | 0.3 | -3.3 | 0.0 | 18.9 |
| NOT WORTH A CAST | 0.9 | -0.4 | 0.0 | 22.4 | 0.4 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 3.8 | -149.5 | 0.0 | 45.9 | 5.1 | -199.9 | 0.0 | 70.4 |
| ONE CHARGE A CHARGER | 4.1 | +0.0 | 0.0 | 79.6 | 4.0 | +0.0 | 0.0 | 114.2 |
| ONE FIGHT FORMULA | 4.6 | -93.7 | 0.0 | 41.1 | 5.0 | -106.7 | 0.0 | 118.0 |
| ONE OBJECTIVE FORMULA | 3.9 | +59.3 | 0.0 | 21.8 | 4.2 | +20.3 | 0.0 | 53.8 |
| ONE PROMISE A TARGET | 0.2 | -8.5 | 0.0 | 0.0 | 0.3 | -16.5 | 0.0 | 10.5 |
| ONE ROUTE | 1.1 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 14.8 |
| ONE TARGET A SHOOTER | 26.8 | +483.2 | 0.0 | 325.3 | 34.1 | +845.3 | 0.0 | 502.4 |
| OPENS A LANE | 0.1 | +0.2 | 1.5 | 0.0 | 0.1 | +0.3 | 9.4 | 5.7 |
| OPENS UP | 0.3 | +15.8 | 24.1 | 0.0 | 0.3 | +21.5 | 16.7 | 0.0 |
| OVERRUNS AWAY | 0.4 | +20.5 | 18.2 | 46.4 | 0.6 | +19.8 | 83.0 | 32.8 |
| OWN CAST FIRST | 0.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.4 | +16.2 | 0.0 | 1.1 | 0.3 | +8.9 | 0.0 | 4.2 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +3.6 | 0.0 | 15.9 |
| PIVOT GUARDS FLANK | 0.1 | -5.2 | 0.0 | 5.0 | - | - | - | - |
| PLAN RESULT | 41.9 | +784.3 | 500.1 | 774.3 | 41.8 | +457.4 | 205.2 | 776.9 |
| PROMISE BELOW ZERO | 0.1 | +0.0 | 0.0 | 3.2 | 0.3 | +0.0 | 0.0 | 7.1 |
| PROMISE BY ITS OWN SUM | 7.2 | -250.1 | 0.0 | 28.3 | 8.7 | -240.2 | 0.0 | 19.8 |
| PROMISE IN STEPS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.4 | -1.2 | 0.0 | 0.0 | 0.7 | -1.3 | 0.0 | 5.5 |
| PROMISE READS THE TABLE | 0.4 | -26.6 | 0.0 | 0.0 | 0.2 | -8.7 | 0.0 | 1.3 |
| PROMISE SHOT AWAY | 0.1 | -6.6 | 15.7 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | 0.0 | -1.6 | 0.0 | 0.0 | 0.1 | -2.6 | 0.0 | 0.0 |
| QUARTER ODDS | 18.0 | +1929.4 | 210.9 | 140.8 | 16.5 | +1848.8 | 166.8 | 235.4 |
| RANDOM MOVE BY FIGURES | 0.9 | +17.5 | 0.0 | 24.3 | 1.2 | +35.8 | 0.0 | 92.2 |
| REAL GROUND | 1.1 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 14.8 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -17.1 | 0.0 | 13.0 | 1.4 | -32.1 | 0.0 | 34.6 |
| REDIRECT COUNTER | 1.7 | +93.4 | 0.0 | 25.9 | 2.8 | +142.3 | 0.0 | 62.4 |
| REDIRECT WEIGHED | 0.1 | -3.9 | 0.0 | 15.1 | 0.3 | -6.4 | 13.7 | 8.5 |
| REFORMS TO MEET IT | 1.4 | -41.1 | 0.0 | 21.5 | 1.1 | -35.3 | 0.0 | 36.6 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 18.9 | 0.3 | +0.0 | 0.0 | 21.9 |
| RESERVE FALL BACK | 0.4 | +16.1 | 0.0 | 12.5 | 0.4 | +25.9 | 0.0 | 14.9 |
| RESTRAINS TO SHOOT | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +37.5 | 127.2 | 85.7 | 2.8 | +21.6 | 264.2 | 80.8 |
| RISK BY HIS FIGURE | 20.1 | -339.0 | 0.0 | 398.9 | 19.1 | -455.9 | 0.0 | 452.4 |
| RISK ON THE WAY | 0.5 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 3.5 |
| ROUNDS AFTER TERROR | 0.7 | -15.6 | 55.4 | 22.8 | 1.4 | -39.4 | 178.5 | 19.1 |
| RUN DOWN | 2.0 | -37.4 | 136.0 | 76.2 | 2.9 | -27.7 | 301.1 | 70.4 |
| SAFER THAN THE JOB | - | - | - | - | 0.1 | +10.1 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.0 | -0.1 | 5.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.5 | -34.8 | 0.0 | 2.1 | 0.3 | -50.5 | 0.0 | 4.2 |
| SEARCH SPOT | 0.2 | +2.4 | 0.0 | 0.0 | 0.4 | +0.4 | 0.0 | 3.4 |
| SECOND LOOK | 0.2 | +12.8 | 13.4 | 27.0 | 0.2 | +4.5 | 10.2 | 1.3 |
| SELF MOVE SPELL | 0.1 | +11.4 | 0.0 | 0.0 | 0.4 | -0.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.8 | +54.6 | 14.4 | 24.8 | 2.7 | +52.1 | 11.4 | 50.5 |
| SET UP TOGETHER | 0.2 | +30.8 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 15.1 |
| SET-UP ANY TARGET | 0.1 | +15.6 | 0.0 | 0.0 | 0.1 | +16.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +3.0 | 1.9 | 0.0 | 0.0 | +4.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.4 | +117.3 | 137.7 | 0.0 | 1.7 | +18.2 | 27.6 | 41.4 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -6.7 | 22.5 | 0.0 | 0.3 | -2.3 | 27.9 | 17.6 |
| SHOT RISK POINTS | 17.1 | -9.6 | 0.0 | 234.4 | 26.1 | -13.6 | 0.0 | 454.9 |
| SHOTS AFTER THE MOVES | 3.1 | +0.0 | 0.0 | 0.0 | 1.6 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.8 | +628.7 | 0.0 | 203.9 | 10.1 | +201.9 | 0.0 | 170.1 |
| SPELL SETS UP CHARGE | 0.2 | +92.0 | 0.0 | 0.0 | 0.1 | +28.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +16.2 | 16.8 | 27.2 | 1.7 | +37.1 | 99.1 | 99.1 |
| SPELLS IN THE FIGHT | 0.4 | -2.2 | 19.5 | 16.6 | 0.6 | +0.7 | 76.9 | 7.6 |
| SPOT AS THE GAME MOVES | 6.8 | +0.0 | 0.0 | 152.3 | 11.2 | +0.0 | 0.0 | 154.3 |
| STAND AND SHOOT | 0.4 | -3.3 | 30.2 | 2.5 | 0.9 | -9.6 | 63.5 | 9.8 |
| STANDS FOR A REASON | 0.6 | +0.0 | 0.0 | 32.2 | 2.4 | +0.0 | 0.0 | 73.0 |
| STANDS STILL | 43.8 | +0.0 | 1257.4 | 309.6 | 26.9 | +0.0 | 206.9 | 359.7 |
| STAY WORTH | 25.0 | -61.2 | 704.5 | 162.6 | 13.3 | +77.6 | 131.7 | 192.4 |
| STOPS | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.4 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.4 | +443.7 | 0.0 | 63.2 | 9.2 | +611.5 | 0.0 | 83.5 |
| SUPPORT NARROWED | 0.3 | +0.0 | 29.4 | 8.8 | 0.4 | +0.0 | 48.6 | 3.4 |
| SUPPORT WORKED OUT | 6.4 | +443.7 | 0.0 | 63.2 | 9.2 | +611.5 | 0.0 | 83.5 |
| SURE REACH TOGETHER | 0.3 | +13.1 | 0.0 | 13.7 | 0.3 | +1.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.4 | +0.0 | 0.0 | 1.1 | 1.4 | +0.0 | 0.0 | 11.9 |
| THE PROMISE ADDS | 0.3 | -27.0 | 0.0 | 0.0 | 0.1 | -8.7 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.1 | +0.0 | 0.0 | 260.9 | 34.7 | +0.0 | 0.0 | 441.8 |
| TIED UP BY THE SUM | 0.8 | +82.8 | 70.4 | 52.5 | 0.7 | +61.1 | 61.8 | 3.4 |
| TIME ON OUR SIDE | 31.7 | +374.9 | 50.2 | 207.1 | 15.2 | +143.8 | 0.0 | 215.7 |
| TWO OR MORE ARRIVE | 0.1 | +0.3 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| WAITS AGAIN | 2.1 | +0.0 | 0.0 | 19.9 | 2.0 | +0.0 | 0.0 | 6.2 |
| WALKS ON ITS ROUTE | 0.1 | -0.1 | 0.0 | 0.0 | 0.0 | +1.7 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +10.1 | 13.2 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.5 | +0.0 | 13.7 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.3 | -0.1 | 8.5 | 0.0 | 0.3 | -1.2 | 34.1 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.1 | -4.5 | 34.6 | 29.4 |
| WHO HITS BACK | 0.2 | +13.2 | 0.0 | 0.0 | 0.4 | +44.1 | 0.0 | 2.7 |
| WHOLE FIGHT | 0.1 | +1.4 | 4.2 | 0.0 | 0.2 | +0.3 | 17.1 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.2 | +12.6 | 13.9 | 0.0 |
| WIDER SPREAD | 1.9 | -2.5 | 157.9 | 48.6 | 2.6 | -6.1 | 271.9 | 41.4 |
| WOUNDS ON THE RANKS | 2.5 | +97.2 | 0.0 | 30.9 | 2.7 | +231.7 | 0.0 | 27.9 |

### Rule changes: base-s2-882d875-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2528 | 2528 | 1622 | 47.71 | +0 | +0.0 |
| HIS MOVE WHY | 2521 | 2521 | 1453 | 42.74 | +0 | +0.0 |
| ARMY TABLE | 1370 | 1370 | 932 | 27.41 | +13789 | +14.8 |
| HIS SHOT LIST | 2773 | 2628 | 700 | 20.59 | +12021 | +17.2 |
| HOLDER ASSIGNMENT | 697 | 697 | 648 | 19.06 | +39154 | +60.4 |
| ONE TARGET A SHOOTER | 2068 | 1954 | 454 | 13.35 | +4382 | +9.7 |
| LEGAL CHARGES ONLY | 367 | 367 | 367 | 10.79 | +0 | +0.0 |
| DEPLOY BY FIGURES | 531 | 531 | 319 | 9.38 | +4933 | +15.5 |
| OFF BEST | 302 | 302 | 302 | 8.88 | -11878 | -39.3 |
| FIVE ACTION | 5953 | 5704 | 277 | 8.15 | +14360 | +51.8 |
| THE TABLE AGAIN | 407 | 407 | 264 | 7.76 | +0 | +0.0 |
| HIS ONE MOVE | 1237 | 1202 | 254 | 7.47 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 460 | 394 | 229 | 6.74 | +14059 | +61.4 |
| TIME ON OUR SIDE | 1596 | 1413 | 208 | 6.12 | +854 | +4.1 |
| PROMISE BY ITS OWN SUM | 542 | 542 | 201 | 5.91 | -16668 | -82.9 |
| SUPPORT ADDS | 530 | 509 | 193 | 5.68 | +7959 | +41.2 |
| SUPPORT WORKED OUT | 530 | 509 | 193 | 5.68 | +7959 | +41.2 |
| SHOT RISK POINTS | 1472 | 1402 | 190 | 5.59 | +3323 | +17.5 |
| MOVE ORDER | 152 | 152 | 152 | 4.47 | +0 | +0.0 |
| HARD STAY DROPPED | 136 | 136 | 136 | 4.00 | +0 | +0.0 |
| QUARTER ODDS | 1174 | 1105 | 124 | 3.65 | +10607 | +85.5 |
| FOUR ROUNDS | 227 | 218 | 105 | 3.09 | +5054 | +48.1 |
| SHOOTS FROM THE BEST SPOT | 176 | 176 | 97 | 2.85 | +684 | +7.1 |
| IDLE COST | 546 | 417 | 73 | 2.15 | +366 | +5.0 |
| CHAFF IN THE MOVE | 78 | 70 | 61 | 1.79 | +448 | +7.3 |
| SET UP BY THE SET | 153 | 149 | 55 | 1.62 | +2944 | +53.5 |
| ADVANCE LANE KEPT | 54 | 54 | 54 | 1.59 | +0 | +0.0 |
| LANE BY FIGURES | 49 | 49 | 49 | 1.44 | +2193 | +44.8 |
| RISK BY ARC | 155 | 148 | 46 | 1.35 | +1212 | +26.3 |
| RISK BY HIS FIGURE | 1335 | 1258 | 45 | 1.32 | +4501 | +100.0 |
| CHARGE LOSSES | 734 | 689 | 44 | 1.29 | +4857 | +110.4 |
| HOLDS AMBUSHERS | 43 | 43 | 43 | 1.26 | +0 | +0.0 |
| JOINT CHARGE NOW | 43 | 43 | 43 | 1.26 | +1040 | +24.2 |
| COVER ONCE | 329 | 231 | 41 | 1.21 | +916 | +22.3 |
| FOLLOW UP WEIGHED | 41 | 41 | 41 | 1.21 | +5660 | +138.1 |
| MAX FOR POSITIONING | 201 | 183 | 41 | 1.21 | +187 | +4.6 |
| STAY WORTH | 1301 | 1171 | 41 | 1.21 | +630 | +15.4 |
| WOUNDS ON THE RANKS | 177 | 175 | 41 | 1.21 | +1568 | +38.3 |
| CANNON SIGHT KEPT | 40 | 40 | 40 | 1.18 | +0 | +0.0 |
| FALLS SHORT | 737 | 597 | 38 | 1.12 | +190 | +5.0 |
| ARTILLERY RE-ROLL WEIGHED | 35 | 35 | 35 | 1.03 | +0 | +0.0 |
| MARCH CHECK | 47 | 43 | 35 | 1.03 | +588 | +16.8 |
| RANDOM MOVE BY FIGURES | 70 | 70 | 34 | 1.00 | +1813 | +53.3 |
| CHARGE NOW FIRST | 111 | 111 | 33 | 0.97 | -1926 | -58.4 |
| LONE WIZARD KEPT IN | 32 | 32 | 32 | 0.94 | +2428 | +75.9 |
| TIED UP BY THE SUM | 49 | 44 | 32 | 0.94 | +1204 | +37.6 |
| NEXT CHARGE BY LIST | 425 | 391 | 29 | 0.85 | +854 | +29.5 |
| RESERVE FALL BACK | 28 | 28 | 28 | 0.82 | +1429 | +51.0 |
| CANNON PLANNED TARGET | 227 | 227 | 26 | 0.76 | -9 | -0.4 |
| SCOUT WAITS | 26 | 26 | 26 | 0.76 | +0 | +0.0 |
| SHOTS IN THE MOVE | 915 | 729 | 25 | 0.74 | +741 | +29.7 |
| CASTING BLOCK | 36 | 36 | 24 | 0.71 | +1086 | +45.2 |
| SHOTS AFTER THE MOVES | 161 | 161 | 24 | 0.71 | +0 | +0.0 |
| NEARER NOT NEEDED | 481 | 456 | 22 | 0.65 | +855 | +38.9 |
| COMBAT PIVOT | 21 | 21 | 21 | 0.62 | +0 | +0.0 |
| PATHS CROSS | 21 | 21 | 21 | 0.62 | +853 | +40.6 |
| SHOOTERS IN TWO RANKS | 21 | 21 | 21 | 0.62 | +45 | +2.1 |
| WHO HITS BACK | 21 | 21 | 21 | 0.62 | +1138 | +54.2 |
| CAST JOB | 44 | 44 | 20 | 0.59 | +85 | +4.2 |
| MISSILES IN THE MOVE | 288 | 182 | 20 | 0.59 | +478 | +23.9 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.56 | +0 | +0.0 |
| HIS TURN DENIED | 102 | 98 | 19 | 0.56 | +616 | +32.4 |
| MARCH BY THE SUM | 19 | 19 | 19 | 0.56 | +1082 | +56.9 |
| REDIRECT COUNTER | 152 | 112 | 18 | 0.53 | +1395 | +77.5 |
| FEATURE BUFFS | 90 | 90 | 17 | 0.50 | +731 | +43.0 |
| HIS CHARGE DENIED | 29 | 29 | 15 | 0.44 | +734 | +48.9 |
| MANOEUVRE | 48 | 48 | 15 | 0.44 | +409 | +27.3 |
| MARCH OF THE TABLE | 15 | 15 | 15 | 0.44 | -447 | -29.8 |
| ONE PROMISE A TARGET | 15 | 15 | 15 | 0.44 | -850 | -56.7 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.41 | +0 | +0.0 |
| BEST PRIZE | 13 | 13 | 13 | 0.38 | -706 | -54.3 |
| CHAFF PASSED | 13 | 13 | 13 | 0.38 | -28 | -2.2 |
| OPENS UP | 20 | 19 | 13 | 0.38 | +439 | +33.8 |
| SEARCH SPOT | 19 | 19 | 13 | 0.38 | +100 | +7.7 |
| AFTERMATH IN POINTS | 12 | 12 | 12 | 0.35 | +1545 | +128.8 |
| OVERRUNS AWAY | 35 | 34 | 12 | 0.35 | +207 | +17.3 |
| SECOND LOOK | 12 | 12 | 12 | 0.35 | +588 | +49.0 |
| GUN MASK | 59 | 59 | 11 | 0.32 | +527 | +47.9 |
| HIS MOVE AND SHOT | 240 | 224 | 11 | 0.32 | +201 | +18.2 |
| ONE FIGHT FORMULA | 327 | 178 | 11 | 0.32 | +147 | +13.3 |
| REDIRECT WEIGHED | 11 | 11 | 11 | 0.32 | +351 | +31.9 |
| SUPPORT NARROWED | 24 | 24 | 11 | 0.32 | -566 | -51.5 |
| MODEL FACING | 10 | 10 | 10 | 0.29 | +1784 | +178.4 |
| ONE OBJECTIVE FORMULA | 274 | 199 | 10 | 0.29 | +241 | +24.1 |
| AFTERMATH WITH FRIENDS | 9 | 9 | 9 | 0.26 | +490 | +54.4 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.26 | +274 | +30.4 |
| SURE REACH TOGETHER | 18 | 16 | 9 | 0.26 | +109 | +12.1 |
| FIRE IN ORDER | 8 | 8 | 8 | 0.24 | +0 | +0.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.24 | +0 | +0.0 |
| HIS FIGHT TOGETHER | 110 | 110 | 7 | 0.21 | +81 | +11.6 |
| HONEST WORTH | 194 | 185 | 7 | 0.21 | +70 | +10.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.21 | +186 | +26.5 |
| FIGHT TO THE END | 52 | 50 | 6 | 0.18 | +114 | +19.0 |
| NO DOUBLE ROUNDS | 190 | 183 | 6 | 0.18 | +85 | +14.2 |
| WHAT THE JOINER ADDS | 21 | 21 | 6 | 0.18 | +54 | +9.0 |
| CHARGE NOT DECLARED | 5 | 5 | 5 | 0.15 | -366 | -73.3 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.15 | -176 | -35.2 |
| PROMISE KNOWS THE FIGHT | 38 | 29 | 5 | 0.15 | -83 | -16.5 |
| SAFER THAN THE JOB | 5 | 5 | 5 | 0.15 | +344 | +68.9 |
| WIDER SPREAD | 155 | 150 | 5 | 0.15 | +43 | +8.7 |
| BOMBING RUN | 4 | 4 | 4 | 0.12 | +202 | +50.4 |
| HUNT IN PAIRS | 21 | 14 | 4 | 0.12 | +115 | +28.9 |
| MISSILES NEXT TURN | 362 | 240 | 4 | 0.12 | +9 | +2.1 |
| PROMISE READS THE TABLE | 20 | 20 | 4 | 0.12 | +2 | +0.4 |
| REDIRECT BY WHAT IT STOPS | 68 | 68 | 4 | 0.12 | +126 | +31.4 |
| REFUSING RETIRES | 18 | 18 | 4 | 0.12 | -1 | -0.2 |
| WHO GETS IN | 4 | 4 | 4 | 0.12 | -154 | -38.5 |
| EDGE GIVE GROUND | 15 | 13 | 3 | 0.09 | +67 | +22.4 |
| KEEP FALLS | 3 | 3 | 3 | 0.09 | +44 | +14.8 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 0.09 | -223 | -74.4 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.09 | -142 | -47.3 |
| STUCK PIVOT | 3 | 3 | 3 | 0.09 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 3 | 3 | 3 | 0.09 | +54 | +17.8 |
| FALL BACK GOOD ORDER | 164 | 156 | 2 | 0.06 | +32 | +16.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +121 | +60.4 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +64 | +31.9 |
| ROUNDS AFTER TERROR | 69 | 66 | 2 | 0.06 | +22 | +11.0 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.06 | +83 | +41.4 |
| WHOLE FIGHT GAIN | 6 | 6 | 2 | 0.06 | +102 | +51.1 |
| BEST OVERALL | 1 | 1 | 1 | 0.03 | +72 | +71.6 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CHARGER SLAIN LOST | 18 | 18 | 1 | 0.03 | +0 | +0.2 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +61 | +61.4 |
| FALLBACK BY WORTH | 19 | 19 | 1 | 0.03 | +7 | +7.2 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +12 | +12.0 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.03 | +9 | +8.8 |
| LONG SHOT | 15 | 15 | 1 | 0.03 | +5 | +4.6 |
| LOST AFTER ESCAPE | 139 | 134 | 1 | 0.03 | +10 | +9.8 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.03 | -8 | -8.5 |
| REFORMS TO MEET IT | 86 | 76 | 1 | 0.03 | +6 | +6.3 |
| RUN DOWN | 164 | 158 | 1 | 0.03 | +3 | +3.0 |
| WAR ENGINE JOBS | 20 | 20 | 1 | 0.03 | -141 | -140.9 |
| WHOLE FIGHT | 11 | 11 | 1 | 0.03 | +7 | +6.7 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 11 | 5 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 17 | 17 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 8 | 8 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 80 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 7 | 6 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 89 | 80 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 104 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 38 | 37 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 273 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 31 | 30 | 0 | 0.00 | - | - |
| GIVES UP | 25 | 24 | 0 | 0.00 | - | - |
| GUN FIGURES | 60 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 177 | 174 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 6 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 353 | 333 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 318 | 280 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 241 | 221 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 117 | 117 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 277 | 252 | 0 | 0.00 | - | - |
| HOLD ODDS | 1151 | 1134 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 202 | 190 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 12 | 12 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 9 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 51 | 51 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 74 | 68 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 16 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 2 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 41 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 9 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 51 | 45 | 0 | 0.00 | - | - |
| NOT TURNED | 20 | 20 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 273 | 263 | 0 | 0.00 | - | - |
| ONE ROUTE | 74 | 68 | 0 | 0.00 | - | - |
| OPENS A LANE | 9 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 2847 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 16 | 16 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 74 | 68 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 29 | 28 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 27 | 27 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET UP TOGETHER | 10 | 9 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 23 | 23 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 100 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 35 | 34 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 611 | 581 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 41 | 39 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 100 | 89 | 0 | 0.00 | - | - |
| STANDS STILL | 2402 | 2312 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 29 | 25 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 95 | not checked | - | - | - | - |
| THE PROMISE ADDS | 14 | 13 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE TABLE BINDS | 2204 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 4 | not checked | - | - | - | - |
| WAITS AGAIN | 138 | 126 | 0 | 0.00 | - | - |

### Off best figure: base-s2-882d875-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.62 | 3.85 | 42.3 |
| PROMISE BY ITS OWN SUM | rule | 2.82 | 3.09 | 82.9 |
| ARMY TABLE | rule | 2.21 | 2.35 | 49.5 |
| NO REASON | gate | 0.79 | 0.74 | 41.0 |
| HOLDER ASSIGNMENT | rule | 0.71 | 0.68 | 22.7 |
| CHARGE NOW FIRST | rule | 0.50 | 0.47 | 58.4 |
| JOINT CHARGE NOW | rule | 0.18 | 0.29 | 97.1 |
| ONE PROMISE A TARGET | rule | 0.18 | 0.26 | 56.7 |
| BEST PRIZE | rule | 0.06 | 0.32 | 54.3 |
| MARCH OF THE TABLE | rule | 0.21 | 0.18 | 34.3 |
| AFTERMATH BAND | gate | 0.18 | 0.15 | 2.7 |
| SUPPORT NARROWED | rule | 0.06 | 0.24 | 56.6 |
| TURN GATE | gate | 0.12 | 0.12 | 20.3 |
| CANNON PLANNED TARGET | rule | 0.03 | 0.18 | 13.3 |
| CHAFF PASSED | rule | 0.06 | 0.15 | 4.0 |
| CHARGE NOT DECLARED | rule | - | 0.15 | 73.3 |
| FALLBACK | gate | 0.03 | 0.12 | 26.9 |
| PIVOT GUARDS FLANK | rule | 0.15 | - | 35.2 |
| PROMISE KNOWS THE FIGHT | rule | 0.06 | 0.09 | 16.5 |
| FRIENDS SHOTS CHECKED | rule | 0.09 | 0.03 | 3.0 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.06 | 13.3 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 1.0 |
| PROMISE SHOT AWAY | rule | 0.09 | - | 74.4 |
| PURSUES BIG PREY | rule | 0.03 | 0.06 | 47.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.06 | 54.6 |
| PATHS CROSS | rule | 0.03 | 0.03 | 14.8 |
| PROMISE READS THE TABLE | rule | 0.03 | 0.03 | 60.2 |
| REDIRECT WEIGHED | rule | - | 0.06 | 39.4 |
| SET UP BY THE SET | rule | - | 0.06 | 70.6 |
| AFTERMATH WITH FRIENDS | rule | - | 0.03 | 4.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | - | 9.4 |
| OWN CAST FIRST | rule | 0.03 | - | 8.5 |
| WALKS ON ITS ROUTE | rule | 0.03 | - | 23.0 |
| WAR ENGINE JOBS | rule | 0.03 | - | 140.9 |
| WHO GETS IN | rule | - | 0.03 | 354.1 |

### Plans: base-s2-882d875-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 61% | 355 | 193 | 54% |
| Mine | join | 0.8 | 96% | 29 | 0 | 0% |
| Mine | move | 29.0 | 96% | 1653 | 0 | 0% |
| Mine | shoot | 9.1 | 55% | 478 | 591 | 124% |
| Mine | support | 0.6 | 86% | 0 | 0 | 0% |
| Opponent | charge | 3.0 | 67% | 481 | 311 | 65% |
| Opponent | join | 1.6 | 98% | 67 | 0 | 0% |
| Opponent | move | 32.8 | 94% | 1561 | 0 | 0% |
| Opponent | shoot | 3.6 | 50% | 206 | 147 | 71% |
| Opponent | support | 0.9 | 65% | 12 | 0 | 0% |

### Packages: hunt the guns, base-s2-882d875-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 17 |
| Opponent | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 546 | 0 | 0% | 70 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 103 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 76 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 46 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 14 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 59 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 546 | 0 | 0% | 21 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 118 |

### Battle groups: base-s2-882d875-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 30% | 53% | 6% | 0% | 25% | 0% | 0% | 69% | 6% |
| Opponent | REDIRECT COUNTER | 2.8 | 25% | 54% | 29% | 29% | 35% | 0% | 0% | 59% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s2-882d875-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 19 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Mine | Chaff | 38 | 63 (38) | 17 | 46 | 32 | 45% | 2.3 | 83 (13) | 78 (16) | 0 (9) | 71 (27) | 44 (11) |
| Mine | Character | 115 | 36 (115) | 36 | 0 | 28 | 22% | 2.6 | 44 (37) | 31 (56) | 65 (10) | 28 (52) | 49 (51) |
| Mine | Clean-up | 21 | 75 (21) | 22 | 54 | 12 | 48% | 3.4 | 50 (8) | 131 (9) | 10 (4) | 81 (12) | 71 (9) |
| Mine | Fast | 4 | 79 (4) | 79 | 0 | 53 | 0% | 1.5 | - | 0 (1) | 168 (3) | 79 (4) | - |
| Mine | Fast Hammer | 37 | 17 (37) | 14 | 3 | 47 | 32% | 3.3 | 17 (18) | 19 (14) | 0 (5) | 7 (23) | 28 (14) |
| Mine | Hammer | 55 | 20 (55) | 5 | 16 | 36 | 25% | 2.5 | 16 (15) | 25 (32) | 6 (8) | 27 (35) | 8 (20) |
| Mine | Holder | 27 | 68 (27) | 0 | 68 | 10 | 56% | 2.8 | 75 (14) | 70 (8) | 55 (3) | 81 (12) | 61 (13) |
| Mine | Shooter | 43 | 76 (43) | 44 | 32 | 27 | 5% | 1.9 | 72 (10) | 85 (24) | 54 (9) | 109 (26) | 18 (17) |
| Mine | Support | 2 | 85 (2) | 85 | 0 | 27 | 0% | 3.0 | 116 (1) | - | 0 (1) | 85 (2) | - |
| Mine | War machine | 53 | 38 (53) | 38 | 0 | 32 | 4% | 1.5 | 90 (15) | 13 (20) | 23 (18) | 80 (8) | 33 (45) |
| Mine | Wizard | 24 | 16 (24) | 16 | 0 | 12 | 4% | 2.0 | 19 (8) | 20 (11) | 0 (2) | 13 (8) | 20 (13) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 64 | 64 (64) | 3 | 61 | 41 | 45% | 2.9 | 34 (20) | 108 (31) | 0 (13) | 65 (44) | 63 (20) |
| Opponent | Character | 105 | 50 (105) | 50 | 0 | 27 | 30% | 2.3 | 48 (39) | 52 (45) | 67 (13) | 57 (63) | 44 (34) |
| Opponent | Clean-up | 15 | 34 (15) | 24 | 10 | 18 | 47% | 2.9 | 47 (8) | 0 (5) | 0 (2) | 37 (10) | 29 (5) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 41 (54) | 22 | 19 | 24 | 35% | 2.9 | 41 (19) | 44 (25) | 33 (10) | 39 (38) | 45 (16) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 67% | 1.0 | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 63 | 12 (63) | 3 | 10 | 41 | 38% | 2.4 | 10 (29) | 16 (24) | 11 (10) | 15 (40) | 8 (23) |
| Opponent | Holder | 36 | 63 (36) | 3 | 59 | 23 | 53% | 3.3 | 25 (6) | 102 (18) | 41 (8) | 128 (16) | 11 (16) |
| Opponent | Shooter | 29 | 56 (29) | 9 | 47 | 29 | 10% | 1.5 | 48 (15) | 68 (11) | 58 (3) | 72 (20) | 17 (9) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 40 (13) | 40 | 0 | 42 | 8% | 1.1 | 71 (5) | 0 (5) | 40 (3) | 0 (1) | 45 (12) |
| Opponent | Wizard | 25 | 18 (25) | 18 | 0 | 17 | 28% | 1.8 | 0 (9) | 23 (12) | 42 (3) | 16 (13) | 24 (11) |

### Charged fights: base-s2-882d875-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 55 | 51 | 0.6 | 1.3 | 85 | 0 | +85 | 1 of 3 | 2 of 3 | +114 | +70 |
| Mine | Chaos Dwarfs | 3 | 102 | 759 | 1.7 | 1.2 | 455 | 0 | +455 | 5 of 5 | 4 of 5 | +540 | +434 |
| Mine | Dwarfen Mountain Holds | 4 | 422 | 38 | 0.5 | 1.0 | 76 | 0 | +76 | 0 of 2 | 1 of 2 | - | +76 |
| Mine | Empire of Man | 4 | 297 | 0 | 1.0 | 1.2 | 0 | 95 | -95 | 0 of 4 | 1 of 4 | +0 | -127 |
| Mine | Grand Cathay | 4 | 239 | 173 | 3.0 | 1.0 | 58 | 8 | +50 | 3 of 12 | 8 of 12 | - | +50 |
| Mine | High Elf Realms | 4 | 128 | 452 | 3.2 | 1.0 | 139 | 67 | +72 | 6 of 13 | 9 of 13 | - | +72 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | +0 | +0 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 56 | -56 | 1 of 2 | 0 of 2 | - | -56 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 716 | 4.0 | 1.2 | 179 | 115 | +64 | 1 of 4 | 3 of 4 | -25 | +94 |
| Mine | Skaven | 2 | 25 | 93 | 1.0 | 1.0 | 93 | 0 | +93 | 0 of 2 | 2 of 2 | - | +93 |
| Mine | Tomb Kings of Khemri | 2 | 216 | 729 | 5.0 | 1.0 | 146 | 0 | +146 | 3 of 10 | 9 of 10 | - | +146 |
| Mine | Vampire Counts | 2 | 0 | 296 | 5.5 | 1.1 | 54 | 79 | -25 | 1 of 11 | 8 of 11 | +98 | -37 |
| Mine | Warriors of Chaos | 1 | 0 | 406 | 2.0 | 1.0 | 203 | 0 | +203 | 0 of 2 | 2 of 2 | - | +203 |
| **Mine** | all armies | 34 | 159 | 251 | 2.1 | 1.1 | 119 | 39 | +80 | 22 of 72 | 50 of 72 | +121 | +76 |
| Opponent | Beastmen Brayherds | 1 | 0 | 195 | 2.0 | 1.0 | 98 | 0 | +98 | 1 of 2 | 1 of 2 | - | +98 |
| Opponent | Dwarfen Mountain Holds | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 95 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 306 | 175 | 3.0 | 1.0 | 58 | 0 | +58 | 1 of 3 | 3 of 3 | - | +58 |
| Opponent | High Elf Realms | 2 | 62 | 908 | 4.0 | 1.2 | 227 | 18 | +209 | 3 of 8 | 6 of 8 | +418 | +140 |
| Opponent | Ogre Kingdoms | 2 | 111 | 0 | 2.5 | 1.0 | 0 | 20 | -20 | 2 of 5 | 1 of 5 | - | -20 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 220 | 3.0 | 1.0 | 73 | 18 | +55 | 1 of 6 | 3 of 6 | - | +55 |
| Opponent | Skaven | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 3 | 37 | 881 | 4.7 | 1.3 | 189 | 0 | +189 | 9 of 14 | 11 of 14 | +279 | +153 |
| Opponent | Vampire Counts | 6 | 56 | 320 | 3.8 | 1.1 | 84 | 9 | +74 | 10 of 23 | 17 of 23 | +178 | +64 |
| Opponent | Warriors of Chaos | 7 | 0 | 266 | 2.1 | 1.1 | 124 | 33 | +91 | 8 of 15 | 12 of 15 | +25 | +101 |
| Opponent | Wood Elf Realms | 6 | 45 | 281 | 2.0 | 1.1 | 140 | 9 | +132 | 4 of 12 | 9 of 12 | +136 | +131 |
| **Opponent** | all armies | 34 | 52 | 316 | 2.6 | 1.1 | 122 | 13 | +109 | 39 of 88 | 63 of 88 | +227 | +92 |

### Effective charges: base-s2-882d875-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 1 (net +0) | 0 | 1 (net +140) | 0 | 1 (net +114) | 0 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 5 | 3 (net +509) | 0 | 0 | 0 | 0 | 2 (net +375) | 0 | 0% (0 of 5) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 1 (net +111) | 1 (net +41) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Empire of Man | 4 | 1 (net +0) | 0 | 1 (net -380) | 0 | 0 | 2 (net +0) | 0 | 25% (1 of 4) |
| Mine | Grand Cathay | 12 | 2 (net +0) | 0 | 3 (net +60) | 2 (net +46) | 0 | 4 (net +81) | 1 | 27% (3 of 11) |
| Mine | High Elf Realms | 13 | 4 (net +63) | 0 | 1 (net +0) | 3 (net -27) | 2 (net +60) | 1 (net +613) | 2 | 9% (1 of 11) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net +0) | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 1 (net -77) | 0 | 1 (net -34) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 1 (net -25) | 0 | 3 | 0% (0 of 1) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 1 (net +186) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 10 | 2 (net +98) | 1 (net +492) | 0 | 1 (net +170) | 3 (net +117) | 2 (net +62) | 1 | 0% (0 of 9) |
| Mine | Vampire Counts | 11 | 2 (net -27) | 0 | 1 (net -45) | 3 (net +89) | 2 (net -164) | 1 (net +0) | 2 | 11% (1 of 9) |
| Opponent | Beastmen Brayherds | 2 | 1 (net +130) | 0 | 0 | 0 | 0 | 1 (net +65) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 0 | 2 (net +58) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | High Elf Realms | 8 | 1 (net +296) | 1 (net -143) | 0 | 2 (net +267) | 2 (net +285) | 0 | 2 | 0% (0 of 6) |
| Opponent | Ogre Kingdoms | 5 | 0 | 0 | 2 (net -17) | 0 | 0 | 0 | 3 | 100% (2 of 2) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 1 (net +0) | 0 | 2 (net +150) | 0 | 0 | 3 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 14 | 2 (net +135) | 0 | 2 (net +92) | 1 (net +297) | 1 (net +630) | 5 (net +227) | 3 | 18% (2 of 11) |
| Opponent | Vampire Counts | 23 | 7 (net +113) | 0 | 5 (net +0) | 2 (net +306) | 0 | 5 (net +42) | 4 | 26% (5 of 19) |
| Opponent | Warriors of Chaos | 15 | 3 (net +159) | 0 | 1 (net +0) | 3 (net +89) | 2 (net +25) | 3 (net +222) | 3 | 8% (1 of 12) |
| Opponent | Wood Elf Realms | 12 | 2 (net +232) | 1 (net +115) | 1 (net +151) | 2 (net +110) | 1 (net +515) | 2 (net +33) | 3 | 11% (1 of 9) |

### Charged fights, damage counted: base-s2-882d875-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 16 | 235 | 288 | +115 | 144 | 44 | +101 | +43.0 |
| Mine | 50-54% | 2 | 232 | 180 | +246 | 356 | 0 | +356 | +153.6 |
| Mine | Effective (55-75%) | 8 | 246 | 129 | -21 | 43 | 66 | -23 | -9.3 |
| Mine | 76-89% | 12 | 267 | 148 | +68 | 122 | 54 | +68 | +25.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 333 | 211 | +138 | 156 | 19 | +136 | +40.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 497 | 96 | +13 | 146 | 115 | +31 | +6.2 |
| Mine | No odds | 11 | 306 | 163 | +66 | 114 | 53 | +61 | +19.8 |
| Mine | All fights | 72 | 304 | 186 | +80 | 133 | 52 | +81 | +26.5 |
| Opponent | Long shot (under 50%) | 16 | 268 | 300 | +152 | 209 | 34 | +175 | +65.3 |
| Opponent | 50-54% | 3 | 108 | 121 | -9 | 45 | 85 | -39 | -36.5 |
| Opponent | Effective (55-75%) | 11 | 216 | 212 | +27 | 76 | 9 | +67 | +31.2 |
| Opponent | 76-89% | 14 | 333 | 179 | +168 | 182 | 28 | +155 | +46.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 285 | 176 | +134 | 141 | 12 | +129 | +45.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 550 | 103 | +294 | 294 | 23 | +271 | +49.3 |
| Opponent | No odds | 22 | 221 | 240 | +28 | 72 | 57 | +15 | +6.8 |
| Opponent | All fights | 88 | 277 | 213 | +109 | 142 | 33 | +109 | +39.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s2-882d875-p1 | move | 244 | 49 (20%) | 37 (15%) | 42 (17%) | 153 (63%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0733, L1021 |
| Witch Hunter's Ward | Mine | L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

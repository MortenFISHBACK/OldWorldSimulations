# Doctrine scorecard: base-s1-882d875-p8

### Scorecard: base-s1-882d875-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0116 | 2 | 1 | Mine | - | - | 4 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0116 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 100 |
| L0132 | 6 | 1 | Mine | no | 14 | 4 | 1 | 2 | 0 | 0 | 0 | 55 |
| L0132 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 6 | 0 | 0 | 0 | 30 |
| L0216 | 6 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 494 |
| L0216 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 2 | 0 | 0 | 0 | 100 |
| L0233 | 5 | 1 | Mine | yes | - | 1 | 1 | 8 | 0 | 0 | 0 | 255 |
| L0233 | 5 | 1 | Opponent | no | - | 2 | 0 | 4 | 0 | 0 | 0 | 405 |
| L0317 | 5 | 1 | Mine | no | - | 4 | 1 | 3 | 0 | 0 | 0 | 834 |
| L0317 | 5 | 1 | Opponent | yes | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0334 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 450 |
| L0334 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 6 | 0 | 0 | 0 | 0 |
| L0419 | 5 | 1 | Mine | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 546 |
| L0419 | 5 | 1 | Opponent | no | - | 2 | 5 | 1 | 1 | 0 | 0 | 343 |
| L0506 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 190 |
| L0506 | 2 | 1 | Opponent | - | - | - | 2 | 5 | 0 | 0 | 0 | 220 |
| L0522 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 606 |
| L0522 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0610 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 646 |
| L0610 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0626 | 2 | 1 | Mine | - | - | 6 | 2 | 0 | 0 | 0 | 0 | 791 |
| L0626 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0715 | 1 | 1 | Mine | no | 1 | 3 | 4 | 1 | 1 | 0 | 0 | 77 |
| L0715 | 1 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0731 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 360 |
| L0731 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 1 | 0 | 0 | 340 |
| L0821 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 386 |
| L0821 | 5 | 1 | Opponent | yes | - | - | 0 | 8 | 1 | 0 | 0 | 355 |
| L0911 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0911 | 5 | 1 | Opponent | no | - | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0928 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 596 |
| L0928 | 4 | 1 | Opponent | no | 8 | - | 0 | 3 | 2 | 0 | 0 | 41 |
| L1019 | 5 | 1 | Mine | yes | - | 4 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1019 | 5 | 1 | Opponent | no | - | 3 | 4 | 5 | 0 | 0 | 0 | 0 |
| L1112 | 2 | 1 | Mine | - | - | 5 | 2 | 0 | 1 | 0 | 0 | 165 |
| L1112 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1128 | 6 | 1 | Mine | no | 8 | 6 | 0 | 0 | 0 | 0 | 0 | 0 |
| L1128 | 6 | 1 | Opponent | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 41 |
| L1222 | 4 | 1 | Mine | no | 5 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1222 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 72 |
| L1333 | 1 | 1 | Mine | no | 10 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1333 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 144 |
| L1429 | 1 | 1 | Mine | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 500 |
| L1429 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 170 |
| L1525 | 1 | 1 | Mine | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 432 |
| L1525 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1623 | 3 | 1 | Mine | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1623 | 3 | 1 | Opponent | yes | 11 | 1 | 5 | 2 | 0 | 0 | 0 | 72 |
| L1721 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 175 |
| L1721 | 5 | 1 | Opponent | no | - | - | 0 | 4 | 0 | 0 | 0 | 500 |
| L1821 | 3 | 1 | Mine | yes | 6 | - | 2 | 0 | 0 | 0 | 0 | 0 |
| L1821 | 3 | 1 | Opponent | no | 1 | - | 0 | 5 | 1 | 0 | 0 | 795 |
| L1921 | 1 | 1 | Mine | no | 11 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1921 | 1 | 1 | Opponent | yes | 10 | 6 | 1 | 2 | 1 | 0 | 0 | 210 |
| L2023 | 1 | 1 | Mine | no | 0 | - | 1 | 3 | 2 | 0 | 0 | 210 |
| L2023 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 2 | 0 | 0 | 0 | 397 |
| L2125 | 1 | 1 | Mine | no | 0 | - | 1 | 6 | 0 | 0 | 0 | 210 |
| L2125 | 1 | 1 | Opponent | no | 0 | 6 | 3 | 4 | 0 | 0 | 0 | 68 |
| L2229 | 3 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2229 | 3 | 1 | Opponent | no | 3 | 2 | 5 | 1 | 1 | 0 | 0 | 200 |
| L2333 | 5 | 1 | Mine | yes | - | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2333 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 19 |
| L2529 | 3 | 1 | Mine | no | 3 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2529 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L2728 | 4 | 1 | Mine | no | 3 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2728 | 4 | 1 | Opponent | no | 6 | - | 1 | 0 | 0 | 0 | 0 | 41 |
| L2932 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2932 | 4 | 1 | Opponent | yes | 5 | 3 | 3 | 1 | 0 | 0 | 0 | 538 |
| L3334 | 4 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 368 |
| L3334 | 4 | 1 | Opponent | no | 0 | 1 | 5 | 7 | 0 | 0 | 0 | 163 |
| **Average** | | | Mine | 19% | 3.1 | 2.9 | 1.8 | 1.9 | 0.2 | 0.0 | 0.0 | 243.3 |
| **Average** | | | Opponent | 23% | 2.6 | 2.6 | 2.4 | 2.9 | 0.3 | 0.0 | 0.0 | 158.1 |

### KPIs: base-s1-882d875-p8

Morten 2026-11-10; 35 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (41 of 151) | 3% (4 of 152) | 15% (45 of 303) |
| Winner chose to follow up after the loser gave ground |  | 86% (30 of 35); on the table 89% | 89% (33 of 37); on the table 89% | 88% (63 of 72); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (5 of 5); on the table 100% | 91% (10 of 11); on the table 91% | 94% (15 of 16); on the table 94% |
| Winner chose to pursue after the loser fled |  | 79% (11 of 14); on the table 86% | 52% (14 of 27); on the table 63% | 61% (25 of 41); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 85% (46 of 54); on the table 89% | 76% (57 of 75); on the table 80% | 80% (103 of 129); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 26% (76 of 292) | 33% (54 of 164) | 29% (130 of 456) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% (76 of 238) | 42% (54 of 129) | 35% (130 of 367) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 52% (14 of 27) | 58% (47 of 81) | 56% (61 of 108) |
| Points that never fought | lower | 55% (36736 of 67031) | 54% (37527 of 69983) | 54% (74263 of 137014) |
|   infantry points that never fought | lower | 59% (8897 of 14970) | 76% (10647 of 14004) | 67% (19544 of 28974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 69% (184 of 265) | 65% (175 of 268) | 67% (359 of 533) |
| Bound items with a magic missile used (at least once a game) |  | 77% (17 of 22); 1.7 uses a game | 80% (16 of 20); 1.4 uses a game | 79% (33 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 31% (4 of 13); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 29% (4 of 14); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 50% (8 of 16); 0.2 uses a game | 53% (19 of 36); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (35529 of 55738) | 59% (36450 of 61501) | 61% (71979 of 117239) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (60%) | 1.4 (45%) | 5.1 (55%) |
| MARCHED: its unit marched | 0.7 (12%) | 0.5 (17%) | 1.3 (14%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (3%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.6 (10%) | 0.7 (24%) | 1.4 (15%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.7 (12%) | 0.3 (8%) | 1.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.6 | 1.1 | 1.9 | 3.7 | 0.7 | 1.1 |
| not cast | 5.0 | 2.5 | 3.1 | 9.3 | 1.7 | 20.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.5 (57%) | 0.4 (14%) | 5.1 (55%) | 0.6 (36%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (14%) | 0.2 (10%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (4%) | 0.2 (7%) | 1.4 (15%) | 0.1 (5%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.1 (6%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.7 (15%) | 0.4 (15%) | 0.2 (6%) | 1.0 (11%) | 0.1 (8%) | 1.6 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (6%) | 0.0 (0%) | 0.0 (0%) | 0.5 (31%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.4 (68%) | 0.2 (7%) | 2.1 (68%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.9 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.5 a game | 1.0 a game |
| stood (cast and not dispelled) | 65% (32 of 49) | 36% (4 of 11) | 60% (36 of 60) |
| the unit moved after it | 56% (18 of 32) | 50% (2 of 4) | 56% (20 of 36) |
| it charged on its next turn | 6% (2 of 32) | 0% (0 of 4) | 6% (2 of 36) |
| the enemy charged it first | 6% (2 of 32) | 0% (0 of 4) | 6% (2 of 36) |
| it fought by the end of its next turn | 0% (0 of 32) | 0% (0 of 4) | 0% (0 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 32) | 0% (0 of 4) | 0% (0 of 36) |
| none of these (no charge, no fight, no charge escaped) | 88% (28 of 32) | 100% (4 of 4) | 89% (32 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (534 of 889) | 50% (324 of 654) | 56% (858 of 1543) |
|   cavalry | 59% (43 of 73) | 56% (73 of 130) | 57% (116 of 203) |
|   character | 50% (57 of 114) | 26% (29 of 111) | 38% (86 of 225) |
|   chariot | 65% (67 of 103) | 57% (25 of 44) | 63% (92 of 147) |
|   infantry | 58% (162 of 281) | 54% (151 of 282) | 56% (313 of 563) |
|   monster | 51% (23 of 45) | 8% (1 of 13) | 41% (24 of 58) |
|   war machine | 67% (182 of 273) | 61% (45 of 74) | 65% (227 of 347) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (10%) | 0.7 (8%) | 1.7 (9%) |
| CHARGED: it charged | 0.7 (7%) | 1.5 (16%) | 2.2 (11%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.2 (2%) | 0.8 (4%) |
| MOVED: a war machine that moved | 1.7 (17%) | 0.5 (5%) | 2.2 (11%) |
| NO TARGET IN RANGE | 3.8 (38%) | 3.9 (42%) | 7.8 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.5 (6%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (13%) | 1.6 (17%) | 3.0 (15%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.5 | 0.9 | 85% | 3.3 pts | 15 pts |
| character | 2.7 | 1.2 | 67% | 8.7 pts | 23 pts |
| chariot | 2.6 | 1.4 | 68% | 17.9 pts | 47 pts |
| infantry | 13.5 | 4.9 | 75% | 8.5 pts | 115 pts |
| monster | 0.8 | 0.3 | 63% | 11.9 pts | 9 pts |
| war machine | 6.5 | 5.3 | 59% | 24.4 pts | 160 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 4.2 | 3.5 |
| Charges that made contact a game | 2.0 | 2.8 | 2.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.47 declared, 0.26 contact (19 units) | 1.31 declared, 1.12 contact (16 units) | 0.86 declared, 0.66 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.89 declared, 0.67 contact (9 units) | 1.33 declared, 0.83 contact (6 units) | 1.07 declared, 0.73 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.24 contact (245 units) | 0.42 declared, 0.27 contact (278 units) | 0.37 declared, 0.25 contact (523 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (32 of 51) | 86% (18 of 21) | 67% (8 of 12) | 69% (58 of 84) |
| Character in a unit | 89% (47 of 53) | 82% (18 of 22) | 83% (5 of 6) | 86% (70 of 81) |
| Character on its own | 81% (17 of 21) | 59% (16 of 27) | 35% (24 of 68) | 49% (57 of 116) |
| Chariot | 63% (12 of 19) | 67% (6 of 9) | - | 64% (18 of 28) |
| Infantry | 71% (50 of 70) | 61% (25 of 41) | 50% (1 of 2) | 67% (76 of 113) |
| Monster | 59% (20 of 34) | 50% (4 of 8) | - | 57% (24 of 42) |
| Monstrous | 100% (10 of 10) | 64% (7 of 11) | - | 81% (17 of 21) |
| War Machines | 80% (37 of 46) | 100% (2 of 2) | - | 81% (39 of 48) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (1 of 1); on the table 100% | 25% (25 of 102) | 66% | 64% (14 of 22) | 83% (5 of 6); 4.5 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 3 | 100% (3 of 3); on the table 100% | 27% (8 of 30) | 65% | 83% (20 of 24) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (5 of 5); on the table 100% | - | 62% | 72% (29 of 40) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 73% (8 of 11); on the table 73% | 29% (7 of 24) | 60% | 74% (40 of 54) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
| Grand Cathay | 7 | 83% (5 of 6); on the table 83% | 30% (45 of 150) | 61% | 67% (39 of 58) | 62% (10 of 16); 5.3 uses a game | 0% (0 of 2); 0.0 uses a game | 43% (3 of 7); 0.4 uses a game |
| High Elf Realms | 4 | 90% (9 of 10); on the table 90% | 33% (2 of 6) | 50% | 45% (14 of 31) | 100% (5 of 5); 4.5 uses a game | 25% (2 of 8); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (6 of 6); on the table 100% | - | 53% | 67% (12 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 2 | 100% (3 of 3); on the table 100% | - | 73% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 62% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 50% (1 of 2); on the table 50% | 17% (3 of 18) | 56% | 92% (22 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 88% (14 of 16); on the table 94% | 28% (15 of 54) | 61% | 67% (35 of 52) | 80% (4 of 5); 1.2 uses a game | 0.0 uses a game | 83% (5 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 6 | 87% (13 of 15); on the table 87% | - | 43% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 70% (16 of 23); on the table 83% | 33% (12 of 36) | 40% | 72% (21 of 29) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 58% (11 of 19); on the table 63% | 46% (11 of 24) | 43% | 61% (46 of 76) | 100% (1 of 1); 0.4 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 6 | 89% (8 of 9); on the table 89% | 17% (2 of 12) | 53% | 80% (43 of 54) | 88% (7 of 8); 3.8 uses a game | 0.0 uses a game | 0% (0 of 6); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (base-s1-882d875-p8, 35 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 61% (38) | 55% (28) | 58% (66) |
| ...free all their last turn and able to turn (per game) | 0.80 | 0.54 | 1.34 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.20 | 0.11 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.49 | 0.43 | 0.91 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.03 | 0.03 | 0.06 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 0.29 | 0.40 |

### Quality by phase: base-s1-882d875-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 60% (49 of 81) | 54% (66 of 123) |
| Strategy | Shoot objectives carried out (shot that target) | 34% (145 of 422) | 36% (49 of 135) |
| Strategy | Support requests answered (helper made contact too) | 100% (5 of 5) | 62% (5 of 8) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | 20% (1 of 5) |
| Strategy | Joined characters whose unit fought | 26% (15 of 58) | 17% (9 of 52) |
| Strategy | Lone characters that fought | 57% (45 of 79) | 76% (51 of 67) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.9 | 2.9 |
| Movement | Points that never moved of their own | 243.3 | 158.1 |
| Movement | Fights charged into per game | 1.9 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 53, net +146 | 16 of 76, net +216 |
| Movement | Charges with odds: sweet spot (55-75%) | 7 of 53, net +265 | 9 of 76, net +118 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 53, net +58 | 15 of 76, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 of 53, net +106 | 18 of 76, net +129 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (165 of 362) | 48% (156 of 324) |
| Shooting | Points destroyed by shooting units | 84.3 | 25.1 |
| Shooting | War machine shots | 5.2 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (82 of 182) | 38% (18 of 47) |
| Shooting | Points destroyed by war machines | 61.2 | 15.3 |
| Magic | Magic missiles cast | 1.4 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 48% (23 of 48) | 24% (9 of 37) |
| Magic | Wounds caused by magic missiles | 3.9 | 1.1 |
| Magic | Wounds caused by other spells | 0.6 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 49.5 | 7.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.2 / 0.3 / 0.1 | 1.4 / 0.2 / 0.2 / 0.3 |
| Combat | Points destroyed in combat | 160.3 | 302.1 |
| Combat | Points run down | 78.2 | 52.2 |
| Combat | Net points per charged fight, damage counted | +114 | +116 |
| Combat | Net per 100 charger points, damage counted | +39.4 | +34.9 |
| Combat | First round won (charged fights) | 77% | 74% |
| Combat | Net points per charged fight | +112 | +114 |
| Combat | Net points per supported fight / lone fight | +113 / +112 | -19 / +124 |
| Combat | Charged fights on a top-3 enemy unit | 19 of 65 | 34 of 87 |
| Game | Points lost | 572.9 | 495.9 |
| Game | VP from objectives | 629.7 | 662.3 |
| Game | Lone holders (player turns) | 3.1 | 2.6 |

- Mine won / drew / lost: 13 / 6 / 16 of 35 ended games (of 35); mean margin (Mine - Opponent) -141 VP
- The side that went first won 10 of 29 games with a winner
- Points traded per game (both sides' losses): 1069
- Games not ended: 0; findings 6, warnings 0

### Opponent rules: base-s1-882d875-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +23.2 | 0.0 | 21.7 | 0.1 | +11.4 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.1 | +2.3 | 0.0 | 0.0 | 0.2 | +9.6 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 15.4 | +140.7 | 0.0 | 143.2 | 17.3 | +121.4 | 0.0 | 208.0 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 28.1 | 0.3 | +0.0 | 0.0 | 4.7 |
| BACKUP TARGETS | 0.1 | +0.4 | 0.0 | 2.3 | 0.3 | +1.1 | 0.0 | 10.2 |
| BEST PRIZE | 0.1 | -3.7 | 0.0 | 0.0 | 0.2 | -14.6 | 16.5 | 16.7 |
| BLOWS WHERE AIMED | 0.2 | -16.8 | 11.2 | 3.3 | 0.3 | -56.9 | 23.0 | 0.0 |
| BOMBING RUN | 0.1 | +1.3 | 12.4 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.2 | +0.0 | 36.8 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.3 | +105.5 | 335.2 | 101.0 | 1.2 | +21.0 | 18.3 | 4.7 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 5.1 | 0.4 | +0.0 | 0.0 | 6.3 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | -3.8 | 19.3 | 0.0 |
| CAST JOB | 2.1 | +34.8 | 101.4 | 57.8 | 0.9 | +6.3 | 6.0 | 20.1 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.8 | +115.2 | 24.3 | 0.0 | 0.1 | +1.3 | 1.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 10.8 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.8 | 0.0 | 6.8 | 0.0 | +0.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +10.8 | 0.0 | 7.4 | 1.2 | +42.6 | 0.0 | 29.7 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 3.3 | 0.2 | -0.1 | 0.0 | 1.6 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.1 | -3.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 1.5 | +0.0 | 0.0 | 10.5 | 2.1 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.1 | +10.5 | 3.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 8.7 | -406.0 | 0.0 | 268.3 | 9.9 | -587.1 | 0.0 | 294.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.1 | +0.0 | 5.6 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 198.3 | 39.0 | 2.1 | +0.0 | 207.3 | 32.1 |
| CHARGER SLAIN LOST | 0.1 | -5.4 | 1.3 | 3.3 | 0.2 | -5.5 | 26.3 | 6.1 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 10.1 | 0.4 | +0.0 | 21.7 | 31.0 |
| CONVEYANCE SEARCH | 1.2 | +115.2 | 13.9 | 10.8 | 0.2 | +9.1 | 12.4 | 12.4 |
| COVER ONCE | 6.1 | -564.8 | 0.0 | 179.9 | 4.0 | -287.2 | 0.0 | 66.3 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 40.5 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -4.1 | 23.3 | 0.0 | 0.5 | -4.1 | 40.7 | 0.0 |
| DEPLOY BY FIGURES | 7.9 | +19.5 | 0.0 | 10.5 | 7.5 | +67.2 | 0.0 | 16.3 |
| EDGE GIVE GROUND | 0.1 | +0.8 | 13.5 | 0.0 | 0.1 | +0.4 | 14.4 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +5.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.8 | +15.4 | 148.3 | 4.3 | 2.4 | +19.5 | 238.9 | 65.3 |
| FALLBACK BY WORTH | 0.2 | +0.3 | 0.0 | 1.3 | 0.2 | +0.0 | 0.0 | 5.0 |
| FALLS SHORT | 4.4 | +84.1 | 0.0 | 116.5 | 13.1 | +176.6 | 0.0 | 163.9 |
| FEATURE BUFFS | 1.9 | +45.8 | 0.0 | 87.8 | 1.1 | +14.4 | 0.0 | 2.3 |
| FIGHT TO THE END | 0.5 | +6.8 | 67.9 | 1.0 | 0.8 | +13.2 | 105.6 | 8.9 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 2.3 | 0.0 | +0.1 | 0.0 | 2.3 |
| FIRE IN ORDER | 0.3 | +0.0 | 3.1 | 0.0 | 0.1 | +0.0 | 0.0 | 3.1 |
| FIVE ACTION | 91.2 | +5193.7 | 1708.0 | 1182.1 | 81.9 | +4863.4 | 597.7 | 913.4 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 105.0 | 3.9 | +0.0 | 0.0 | 86.6 |
| FOCUS FIRE | 0.0 | +0.2 | 0.9 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.5 | +95.6 | 0.0 | 16.1 | 0.7 | +89.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.5 | +181.2 | 217.9 | 8.2 | 3.8 | +298.5 | 343.9 | 66.4 |
| FRIEND CHARGES FIRST | 0.1 | -3.1 | 0.0 | 0.0 | 0.0 | -2.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.8 | -32.8 | 21.6 | 6.6 | 0.2 | -34.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +5.8 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -3.7 | 34.5 | 0.0 | 0.3 | -4.3 | 26.1 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.7 | 0.0 | 0.9 |
| GROUND FLIERS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 0.9 | +34.6 | 81.7 | 3.7 | 0.3 | +3.3 | 0.0 | 3.7 |
| GUN MASK | 1.1 | +40.0 | 0.0 | 8.9 | 0.3 | +13.8 | 0.0 | 4.6 |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 40.1 | 1.0 | +0.0 | 0.0 | 31.5 |
| HE SHOOTS OR CHARGES | 2.4 | +0.0 | 0.0 | 133.3 | 3.4 | +0.0 | 0.0 | 108.4 |
| HELPER UNSEEN | 0.1 | +0.0 | 19.6 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.3 | +6.9 | 22.0 | 4.6 | 0.4 | +7.4 | 35.9 | 3.8 |
| HIS CHARGE LIST | 5.6 | +0.0 | 0.0 | 81.3 | 5.5 | +0.0 | 0.0 | 130.9 |
| HIS FIGHT TOGETHER | 1.6 | -25.4 | 0.0 | 131.1 | 1.6 | -35.3 | 0.0 | 92.3 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 53.8 | 4.0 | +0.0 | 0.0 | 21.3 |
| HIS MOVE AND SHOT | 3.2 | -63.1 | 0.0 | 141.0 | 3.3 | -78.4 | 0.0 | 94.3 |
| HIS MOVE AS HE DECIDES | 37.5 | +13.5 | 614.4 | 0.0 | 35.1 | +14.7 | 419.9 | 0.0 |
| HIS MOVE WHY | 34.9 | +0.0 | 0.0 | 327.3 | 36.6 | +0.0 | 0.0 | 398.6 |
| HIS ONE MOVE | 17.5 | +24.9 | 0.0 | 37.6 | 18.5 | +35.5 | 4.9 | 91.9 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 56.1 | 5.0 | +0.0 | 0.0 | 78.6 |
| HIS OWN BEST MOVE | 1.6 | +0.0 | 0.0 | 29.6 | 1.5 | +0.0 | 0.0 | 11.3 |
| HIS RANDOM MOVE | 6.7 | +0.0 | 0.0 | 88.6 | 2.7 | +0.0 | 0.0 | 16.8 |
| HIS SHOT LIST | 34.4 | +970.5 | 0.0 | 437.2 | 44.1 | +1796.3 | 0.0 | 520.3 |
| HIS TURN DENIED | 0.8 | +16.3 | 63.5 | 0.0 | 2.0 | +47.3 | 171.2 | 14.4 |
| HOLD ODDS | 14.6 | +0.0 | 0.0 | 258.7 | 14.9 | +0.0 | 0.0 | 69.3 |
| HOLDER ASSIGNMENT | 8.5 | +853.1 | 0.0 | 110.0 | 8.8 | +906.5 | 0.0 | 33.5 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.2 | -86.7 | 191.6 | 3.6 | 3.3 | -168.9 | 312.3 | 47.1 |
| HORN WORTH | - | - | - | - | 0.1 | +0.9 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.1 | +4.1 | 0.0 | 0.0 | 0.5 | +19.9 | 0.0 | 2.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.0 | 3.3 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.1 | +21.0 | 0.0 | 1.3 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +25.2 | 10.4 | 0.0 |
| IDLE COST | 4.3 | -55.0 | 0.0 | 54.7 | 10.9 | -172.6 | 0.0 | 133.0 |
| JOINT CHARGE NOW | 0.4 | +15.2 | 34.1 | 0.0 | 0.6 | +0.8 | 28.7 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -3.6 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +0.4 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.5 | +0.0 | 0.0 | 15.4 | 2.3 | +0.0 | 0.0 | 4.9 |
| LANE BY FIGURES | 0.7 | +26.1 | 0.0 | 0.0 | 1.0 | +50.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 180.8 | 228.4 | 5.2 | +0.0 | 182.1 | 183.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.1 | +1.0 | 0.0 | 7.7 |
| LONE WIZARD KEPT IN | 0.7 | +44.2 | 0.0 | 0.0 | 0.4 | +31.2 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.1 | 1.8 | 0.0 | 0.2 | +0.6 | 4.1 | 6.7 |
| LOST AFTER ESCAPE | 1.3 | -0.4 | 119.5 | 1.3 | 2.1 | +1.6 | 207.0 | 12.6 |
| LOST CHARGE | 0.0 | -0.0 | 1.6 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -6.4 | 0.0 | 0.8 | 0.1 | -4.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.0 | +0.2 | 0.0 | 0.0 | 0.4 | +9.1 | 0.0 | 35.0 |
| MANOEUVRE | 0.8 | +8.2 | 0.0 | 16.2 | 0.5 | -0.6 | 0.0 | 10.6 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 4.9 | 0.1 | +1.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +14.6 | 0.0 | 0.0 | 0.3 | +20.8 | 0.0 | 10.2 |
| MARCH CHECK | 0.7 | +24.7 | 0.0 | 5.5 | 0.7 | +35.7 | 0.0 | 15.9 |
| MARCH ODDS | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.1 | +2.4 | 0.0 | 5.5 | 0.1 | +0.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +31.7 | 0.0 | 21.0 | 0.4 | +10.2 | 0.0 | 25.6 |
| MARCH WHEELS ONLY | 0.5 | +0.0 | 0.0 | 2.3 | 0.9 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.1 | +38.9 | 0.0 | 70.3 | 2.8 | +59.8 | 0.0 | 79.3 |
| MISSILES IN THE MOVE | 4.1 | +137.1 | 0.0 | 70.9 | 3.3 | +50.0 | 0.0 | 72.2 |
| MISSILES NEXT TURN | 5.4 | +91.6 | 0.0 | 104.3 | 4.2 | +38.0 | 0.0 | 97.9 |
| MISSILES ON ONE TARGET | 0.2 | -8.1 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | 0.3 | +105.9 | 0.0 | 6.9 | 0.1 | +25.6 | 0.0 | 1.7 |
| MOVE ORDER | 1.4 | +0.0 | 11.5 | 4.4 | 1.7 | +0.0 | 12.3 | 1.9 |
| MOVE SPELL IN RANGE | 0.2 | +9.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -18.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 10.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.8 | +445.4 | 0.0 | 11.7 | 5.9 | +621.1 | 0.0 | 78.8 |
| MOVES UNITS SPELL | 0.1 | +3.5 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.2 | +299.1 | 0.0 | 113.8 | 6.3 | +269.4 | 0.0 | 39.8 |
| NEXT CHARGE BY LIST | 5.5 | -251.3 | 39.5 | 19.3 | 5.2 | -224.3 | 14.0 | 159.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.1 | -1.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.9 | -87.3 | 171.2 | 5.5 | 2.8 | -113.1 | 268.7 | 42.4 |
| NO LATE CUT | 0.5 | +0.0 | 0.0 | 3.9 | 0.5 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.1 | -0.1 | 0.0 | 2.4 | 0.3 | +0.0 | 0.0 | 5.4 |
| NOT WORTH A CAST | 1.0 | -0.5 | 0.0 | 32.6 | 0.9 | -1.1 | 0.0 | 10.0 |
| OFF BEST | 3.0 | -136.4 | 5.9 | 27.7 | 3.0 | -102.0 | 0.0 | 39.8 |
| ONE CHARGE A CHARGER | 3.9 | +0.0 | 0.0 | 139.3 | 2.7 | +0.0 | 0.0 | 69.5 |
| ONE FIGHT FORMULA | 4.3 | -86.7 | 0.0 | 43.1 | 4.3 | -110.8 | 0.0 | 100.1 |
| ONE OBJECTIVE FORMULA | 4.1 | +17.0 | 0.0 | 82.6 | 3.7 | +36.1 | 0.0 | 20.9 |
| ONE PROMISE A TARGET | 0.1 | -2.6 | 0.0 | 0.0 | 0.1 | -3.9 | 0.0 | 0.0 |
| ONE ROUTE | 0.5 | +0.0 | 0.0 | 2.3 | 0.9 | +0.0 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 22.7 | +348.0 | 0.0 | 323.2 | 33.6 | +878.6 | 0.0 | 415.5 |
| OPENS A LANE | 0.5 | +4.8 | 111.1 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +10.4 | 7.7 | 0.0 | 0.5 | +29.3 | 30.1 | 17.1 |
| OVERRUNS AWAY | 0.3 | +28.6 | 28.4 | 0.0 | 0.7 | +52.6 | 64.3 | 27.5 |
| OWN CAST FIRST | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.5 | +10.5 | 0.0 | 11.4 | 0.3 | +9.7 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.1 | +3.1 | 0.0 | 0.0 | 0.1 | +9.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.0 | -0.9 | 0.0 | 10.5 | 0.1 | -1.3 | 0.0 | 0.0 |
| PLAN RESULT | 41.7 | +883.7 | 610.9 | 791.9 | 39.4 | +468.2 | 213.7 | 792.4 |
| PROMISE BELOW ZERO | 0.1 | +0.0 | 0.0 | 1.3 | 0.3 | +0.0 | 0.0 | 16.7 |
| PROMISE BY ITS OWN SUM | 7.9 | -235.4 | 0.0 | 5.9 | 7.1 | -158.3 | 0.0 | 22.0 |
| PROMISE IN STEPS | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.4 | -1.9 | 0.0 | 0.0 | 0.4 | -0.5 | 0.0 | 4.3 |
| PROMISE READS THE TABLE | 0.4 | -4.7 | 0.0 | 3.3 | 0.2 | -39.5 | 0.0 | 4.3 |
| PROMISE SHOT AWAY | 0.1 | -2.7 | 8.3 | 7.1 | 0.3 | -22.3 | 123.4 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -2.7 | 0.0 | 0.0 |
| QUARTER ODDS | 19.5 | +1804.3 | 454.9 | 246.4 | 16.9 | +1941.5 | 126.9 | 172.6 |
| RANDOM MOVE BY FIGURES | 0.8 | +11.9 | 0.0 | 24.7 | 2.3 | +53.4 | 0.0 | 101.0 |
| REAL GROUND | 0.5 | +0.0 | 0.0 | 2.3 | 0.9 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -4.4 | 0.0 | 7.4 | 1.2 | -41.5 | 0.0 | 38.1 |
| REDIRECT COUNTER | 1.1 | +53.5 | 0.0 | 28.9 | 2.0 | +129.3 | 0.0 | 25.5 |
| REDIRECT WEIGHED | 0.2 | +5.4 | 10.1 | 0.0 | 0.3 | +3.7 | 23.5 | 0.0 |
| REFORMS TO MEET IT | 1.2 | -33.9 | 0.0 | 0.0 | 0.9 | -24.6 | 0.0 | 14.6 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 27.3 | 0.2 | +0.0 | 0.0 | 7.9 |
| RESERVE FALL BACK | 0.4 | +18.4 | 0.0 | 6.2 | 0.9 | +34.9 | 0.0 | 11.6 |
| RISK BY ARC | 1.5 | +23.2 | 113.5 | 4.3 | 2.5 | -28.1 | 234.3 | 49.0 |
| RISK BY HIS FIGURE | 18.2 | -310.1 | 0.0 | 442.7 | 18.0 | -415.4 | 0.0 | 415.9 |
| RISK ON THE WAY | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.6 | -13.7 | 61.1 | 0.0 | 1.3 | -30.7 | 175.5 | 5.6 |
| RUN DOWN | 1.7 | -11.7 | 136.3 | 2.3 | 2.9 | -30.7 | 299.0 | 26.2 |
| SAME CHARGE LATER | 0.0 | -0.3 | 0.0 | 0.0 | 0.0 | -0.2 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +1.1 | 0.0 | 0.0 | 0.2 | +1.1 | 0.0 | 2.1 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 2.1 |
| SCREEN BY WHAT IT SAVES | 0.3 | -13.2 | 0.0 | 0.0 | 0.7 | -32.5 | 0.0 | 7.5 |
| SEARCH SPOT | 0.3 | +11.0 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 1.2 |
| SECOND LOOK | 0.2 | +10.9 | 15.6 | 0.0 | 0.3 | +37.3 | 10.4 | 0.0 |
| SELF MOVE SPELL | 0.3 | +7.9 | 0.0 | 0.0 | 0.5 | +42.6 | 0.0 | 18.6 |
| SET UP BY THE SET | 2.0 | +85.0 | 5.9 | 30.5 | 2.0 | +75.2 | 5.5 | 5.6 |
| SET UP TOGETHER | 0.1 | +0.9 | 0.0 | 0.0 | 0.6 | +22.7 | 0.0 | 35.0 |
| SET-UP ANY TARGET | 0.2 | +30.4 | 0.0 | 0.0 | 0.1 | +11.4 | 12.4 | 12.4 |
| SET-UP MISSED | 0.1 | +5.2 | 0.0 | 0.0 | 0.0 | +3.1 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.4 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.2 | +160.9 | 170.9 | 29.4 | 1.5 | +50.7 | 52.6 | 32.4 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.3 |
| SHOT OR CHARGE | 0.1 | -1.6 | 8.2 | 5.0 | 0.1 | -0.1 | 0.0 | 1.6 |
| SHOT RISK POINTS | 16.7 | +91.8 | 0.0 | 192.8 | 21.0 | +56.6 | 0.0 | 417.9 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 1.8 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.9 | +681.4 | 0.0 | 259.1 | 9.8 | +238.5 | 0.0 | 117.0 |
| SPELL SETS UP CHARGE | 0.2 | +30.4 | 0.0 | 0.0 | 0.1 | +11.4 | 12.4 | 12.4 |
| SPELL WORTH | 1.3 | +16.4 | 68.5 | 48.9 | 1.0 | +15.0 | 15.4 | 25.5 |
| SPELLS IN THE FIGHT | 0.4 | +0.1 | 38.1 | 3.3 | 0.5 | +2.3 | 65.1 | 0.9 |
| SPOT AS THE GAME MOVES | 6.6 | +0.0 | 0.0 | 100.9 | 9.3 | +0.0 | 0.0 | 148.5 |
| STAND AND SHOOT | 0.6 | -8.3 | 49.8 | 1.3 | 0.9 | -9.0 | 70.5 | 1.1 |
| STANDS FOR A REASON | 0.6 | +0.0 | 0.0 | 61.7 | 2.0 | +0.0 | 0.0 | 36.7 |
| STANDS STILL | 49.3 | +0.0 | 1490.1 | 636.8 | 29.3 | +0.0 | 253.8 | 302.9 |
| STAY WORTH | 26.9 | +45.5 | 854.0 | 306.5 | 11.9 | +135.4 | 176.8 | 117.1 |
| STOPS | - | - | - | - | 0.1 | +10.0 | 10.4 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 13.1 |
| STUPIDITY NEXT TURN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.7 | +361.1 | 0.0 | 92.5 | 6.1 | +303.3 | 0.0 | 52.9 |
| SUPPORT NARROWED | 0.1 | +0.0 | 0.0 | 14.8 | 0.3 | +0.0 | 13.4 | 6.5 |
| SUPPORT WORKED OUT | 5.7 | +361.1 | 0.0 | 92.5 | 6.1 | +303.3 | 0.0 | 52.9 |
| SURE REACH TOGETHER | 0.3 | +7.0 | 0.0 | 2.1 | 0.3 | +6.0 | 0.0 | 3.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 45.9 | 0.8 | +0.0 | 0.0 | 1.3 |
| THE PROMISE ADDS | 0.1 | -5.2 | 0.0 | 0.0 | 0.1 | -9.6 | 0.0 | 4.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.9 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.2 | +0.0 | 0.0 | 327.1 | 33.0 | +0.0 | 0.0 | 291.5 |
| TIED UP BY THE SUM | 0.9 | +97.6 | 80.6 | 1.0 | 1.0 | +109.3 | 85.0 | 16.9 |
| TIME ON OUR SIDE | 34.2 | +385.4 | 69.4 | 333.5 | 13.6 | +143.0 | 0.0 | 58.0 |
| WAITS AGAIN | 0.9 | +0.0 | 0.0 | 11.7 | 1.0 | +0.0 | 0.0 | 6.6 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 39.5 | 35.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.1 | +6.0 | 26.6 | 0.0 | 0.4 | -6.5 | 51.7 | 3.8 |
| WHO GETS IN | 0.1 | +3.5 | 8.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.2 | +30.8 | 0.0 | 5.6 | 0.5 | +59.4 | 0.0 | 19.0 |
| WHOLE FIGHT | 0.1 | +0.0 | 13.3 | 0.0 | 0.2 | +7.8 | 27.2 | 1.9 |
| WHOLE FIGHT GAIN | 0.1 | +0.3 | 4.1 | 0.0 | 0.3 | +20.8 | 16.5 | 0.0 |
| WIDER SPREAD | 1.5 | +0.6 | 114.3 | 5.5 | 2.3 | -5.9 | 211.6 | 27.1 |
| WOUNDS ON THE RANKS | 1.5 | +31.1 | 0.0 | 42.7 | 1.5 | +103.0 | 0.0 | 47.1 |

### Rule changes: base-s1-882d875-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 2542 | 2542 | 1554 | 44.40 | +0 | +0.0 |
| HIS MOVE WHY | 2503 | 2503 | 1311 | 37.46 | +0 | +0.0 |
| ARMY TABLE | 1144 | 1144 | 764 | 21.83 | +8380 | +11.0 |
| HIS SHOT LIST | 2748 | 2637 | 636 | 18.17 | +10304 | +16.2 |
| HOLDER ASSIGNMENT | 605 | 605 | 557 | 15.91 | +34540 | +62.0 |
| ONE TARGET A SHOOTER | 1969 | 1882 | 355 | 10.14 | +3874 | +10.9 |
| LEGAL CHARGES ONLY | 334 | 334 | 334 | 9.54 | +0 | +0.0 |
| DEPLOY BY FIGURES | 542 | 542 | 323 | 9.23 | +3565 | +11.0 |
| TIME ON OUR SIDE | 1673 | 1525 | 280 | 8.00 | +1305 | +4.7 |
| HIS ONE MOVE | 1261 | 1224 | 273 | 7.80 | +0 | +0.0 |
| FIVE ACTION | 6060 | 5865 | 267 | 7.63 | +16821 | +63.0 |
| THE TABLE AGAIN | 418 | 418 | 241 | 6.89 | +0 | +0.0 |
| OFF BEST | 211 | 211 | 211 | 6.03 | -8343 | -39.5 |
| MOVE TO CHARGE COMPUTED | 411 | 356 | 204 | 5.83 | +9929 | +48.7 |
| PROMISE BY ITS OWN SUM | 526 | 526 | 188 | 5.37 | -13778 | -73.3 |
| SHOT RISK POINTS | 1317 | 1255 | 186 | 5.31 | +6065 | +32.6 |
| HARD STAY DROPPED | 151 | 151 | 151 | 4.31 | +0 | +0.0 |
| SUPPORT ADDS | 414 | 403 | 135 | 3.86 | +5397 | +40.0 |
| SUPPORT WORKED OUT | 414 | 403 | 135 | 3.86 | +5397 | +40.0 |
| QUARTER ODDS | 1274 | 1209 | 129 | 3.69 | +11125 | +86.2 |
| FOUR ROUNDS | 222 | 213 | 112 | 3.20 | +5450 | +48.7 |
| MOVE ORDER | 108 | 108 | 108 | 3.09 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 130 | 130 | 83 | 2.37 | +1562 | +18.8 |
| IDLE COST | 532 | 430 | 82 | 2.34 | +1040 | +12.7 |
| STAY WORTH | 1361 | 1266 | 67 | 1.91 | +944 | +14.1 |
| ARTILLERY RE-ROLL WEIGHED | 66 | 66 | 66 | 1.89 | +0 | +0.0 |
| CAST JOB | 104 | 104 | 65 | 1.86 | +289 | +4.4 |
| RANDOM MOVE BY FIGURES | 108 | 108 | 61 | 1.74 | +2287 | +37.5 |
| CANNON SIGHT KEPT | 59 | 59 | 59 | 1.69 | +0 | +0.0 |
| LANE BY FIGURES | 59 | 59 | 59 | 1.69 | +2670 | +45.2 |
| COVER ONCE | 356 | 259 | 56 | 1.60 | +1288 | +23.0 |
| TIED UP BY THE SUM | 68 | 65 | 56 | 1.60 | +1932 | +34.5 |
| FALLS SHORT | 613 | 534 | 48 | 1.37 | +526 | +11.0 |
| CHARGE NOW FIRST | 133 | 133 | 46 | 1.31 | -2764 | -60.1 |
| SET UP BY THE SET | 140 | 136 | 46 | 1.31 | +3780 | +82.2 |
| ADVANCE LANE KEPT | 45 | 45 | 45 | 1.29 | +0 | +0.0 |
| MAX FOR POSITIONING | 173 | 157 | 44 | 1.26 | +237 | +5.4 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.26 | +1863 | +42.3 |
| RISK BY HIS FIGURE | 1268 | 1211 | 44 | 1.26 | +4781 | +108.7 |
| CHAFF IN THE MOVE | 54 | 50 | 43 | 1.23 | +14 | +0.3 |
| FOLLOW UP WEIGHED | 42 | 42 | 42 | 1.20 | +6485 | +154.4 |
| RISK BY ARC | 142 | 136 | 40 | 1.14 | +1258 | +31.4 |
| CHARGE LOSSES | 650 | 613 | 38 | 1.09 | +2639 | +69.4 |
| HOLDS AMBUSHERS | 38 | 38 | 38 | 1.09 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 36 | 36 | 36 | 1.03 | +2639 | +73.3 |
| JOINT CHARGE NOW | 35 | 35 | 35 | 1.00 | +563 | +16.1 |
| SHOTS IN THE MOVE | 937 | 754 | 33 | 0.94 | +1659 | +50.3 |
| MARCH CHECK | 48 | 47 | 32 | 0.91 | +689 | +21.5 |
| CANNON PLANNED TARGET | 229 | 229 | 31 | 0.89 | -62 | -2.0 |
| PATHS CROSS | 28 | 28 | 28 | 0.80 | +708 | +25.3 |
| NEXT CHARGE BY LIST | 376 | 348 | 27 | 0.77 | +448 | +16.6 |
| WHO HITS BACK | 26 | 26 | 26 | 0.74 | +1490 | +57.3 |
| MISSILES IN THE MOVE | 258 | 183 | 25 | 0.71 | +566 | +22.7 |
| NEARER NOT NEEDED | 473 | 460 | 24 | 0.69 | +866 | +36.1 |
| SCOUT WAITS | 24 | 24 | 24 | 0.69 | +0 | +0.0 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.66 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 22 | 22 | 22 | 0.63 | +53 | +2.4 |
| CASTING BLOCK | 31 | 31 | 21 | 0.60 | +1623 | +77.3 |
| SEARCH SPOT | 27 | 27 | 19 | 0.54 | +458 | +24.1 |
| ONE OBJECTIVE FORMULA | 273 | 221 | 18 | 0.51 | +735 | +40.9 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.51 | +1478 | +82.1 |
| SHOTS AFTER THE MOVES | 179 | 179 | 18 | 0.51 | +0 | +0.0 |
| MARCH BY THE SUM | 17 | 17 | 17 | 0.49 | +1238 | +72.8 |
| CHAFF PASSED | 16 | 16 | 16 | 0.46 | -10 | -0.6 |
| MODEL FACING | 16 | 16 | 16 | 0.46 | +4602 | +287.6 |
| PROMISE SHOT AWAY | 16 | 16 | 16 | 0.46 | -874 | -54.6 |
| GUN MASK | 51 | 51 | 15 | 0.43 | +690 | +46.0 |
| SECOND LOOK | 15 | 15 | 15 | 0.43 | +1686 | +112.4 |
| WOUNDS ON THE RANKS | 106 | 100 | 15 | 0.43 | +389 | +25.9 |
| HIS TURN DENIED | 98 | 94 | 14 | 0.40 | +497 | +35.5 |
| OPENS UP | 26 | 24 | 13 | 0.37 | +294 | +22.6 |
| OVERRUNS AWAY | 35 | 35 | 13 | 0.37 | +573 | +44.1 |
| REDIRECT COUNTER | 109 | 88 | 13 | 0.37 | +1155 | +88.9 |
| FIRE IN ORDER | 12 | 12 | 12 | 0.34 | +0 | +0.0 |
| STUCK PIVOT | 12 | 12 | 12 | 0.34 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| SURE REACH TOGETHER | 19 | 19 | 11 | 0.31 | +79 | +7.2 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.29 | +0 | +0.0 |
| AFTERMATH IN POINTS | 9 | 9 | 9 | 0.26 | +1211 | +134.5 |
| BEST PRIZE | 9 | 9 | 9 | 0.26 | -780 | -86.6 |
| HIS MOVE AND SHOT | 230 | 218 | 9 | 0.26 | +169 | +18.8 |
| HONEST WORTH | 192 | 184 | 9 | 0.26 | +188 | +20.9 |
| WAR ENGINE JOBS | 19 | 19 | 9 | 0.26 | -111 | -12.3 |
| AFTERMATH WITH FRIENDS | 8 | 8 | 8 | 0.23 | +417 | +52.1 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.23 | +0 | +0.0 |
| HIS FIGHT TOGETHER | 112 | 107 | 8 | 0.23 | +143 | +17.9 |
| MANOEUVRE | 44 | 44 | 8 | 0.23 | +367 | +45.8 |
| ONE PROMISE A TARGET | 8 | 8 | 8 | 0.23 | -228 | -28.4 |
| REFUSING RETIRES | 22 | 22 | 8 | 0.23 | -2 | -0.3 |
| FIGHT TO THE END | 47 | 46 | 7 | 0.20 | +163 | +23.2 |
| HIS CHARGE DENIED | 22 | 21 | 7 | 0.20 | +147 | +21.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.20 | +138 | +19.7 |
| ONE FIGHT FORMULA | 300 | 152 | 7 | 0.20 | +275 | +39.3 |
| FALL BACK GOOD ORDER | 146 | 139 | 6 | 0.17 | +558 | +93.0 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.17 | +244 | +40.7 |
| WHOLE FIGHT GAIN | 11 | 11 | 6 | 0.17 | +240 | +39.9 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 0.14 | -93 | -18.6 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +432 | +86.4 |
| PROMISE KNOWS THE FIGHT | 28 | 26 | 5 | 0.14 | -84 | -16.8 |
| WHO GETS IN | 5 | 5 | 5 | 0.14 | +122 | +24.5 |
| MISSILES NEXT TURN | 338 | 246 | 4 | 0.11 | +16 | +4.0 |
| NO DOUBLE ROUNDS | 167 | 160 | 4 | 0.11 | +76 | +19.0 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -78 | -19.4 |
| SUPPORT NARROWED | 14 | 14 | 4 | 0.11 | -574 | -143.4 |
| WHAT THE JOINER ADDS | 17 | 17 | 4 | 0.11 | +519 | +129.6 |
| CHARGE LIST READ AGAIN | 3 | 3 | 3 | 0.09 | +367 | +122.3 |
| FEATURE BUFFS | 105 | 105 | 3 | 0.09 | +49 | +16.5 |
| HUNT IN PAIRS | 22 | 13 | 3 | 0.09 | +69 | +23.1 |
| KEEP FALLS | 3 | 3 | 3 | 0.09 | +109 | +36.4 |
| KEEPS SCOUTS OR AMBUSH | 3 | 3 | 3 | 0.09 | +0 | +0.0 |
| LOST AFTER ESCAPE | 121 | 116 | 3 | 0.09 | +10 | +3.3 |
| PROMISE READS THE TABLE | 21 | 21 | 3 | 0.09 | -176 | -58.7 |
| SET UP TOGETHER | 26 | 18 | 3 | 0.09 | +23 | +7.8 |
| STOPS | 3 | 3 | 3 | 0.09 | +207 | +68.9 |
| WIDER SPREAD | 132 | 127 | 3 | 0.09 | +1 | +0.4 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +45 | +22.3 |
| CARRIES OUT SET-UP | 3 | 3 | 2 | 0.06 | -134 | -67.2 |
| CHARGE NOT DECLARED | 2 | 2 | 2 | 0.06 | -292 | -146.2 |
| FACES THE THREAT | 2 | 2 | 2 | 0.06 | +231 | +115.5 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +7 | +3.3 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +18 | +8.9 |
| GIVES UP | 19 | 14 | 2 | 0.06 | +74 | +37.2 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +31 | +15.6 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.06 | -6 | -3.2 |
| ROUNDS AFTER TERROR | 65 | 62 | 2 | 0.06 | +25 | +12.4 |
| WHOLE FIGHT | 9 | 9 | 2 | 0.06 | +6 | +3.0 |
| BACKUP TARGETS | 13 | 8 | 1 | 0.03 | +6 | +5.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +3 | +2.8 |
| FALLBACK BY WORTH | 15 | 15 | 1 | 0.03 | +11 | +11.2 |
| FRIEND CHARGES FIRST | 3 | 3 | 1 | 0.03 | +5 | +4.9 |
| MARCH ODDS | 1 | 1 | 1 | 0.03 | -15 | -15.1 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -94 | -93.5 |
| REDIRECT BY WHAT IT STOPS | 52 | 52 | 1 | 0.03 | +10 | +10.0 |
| RUN DOWN | 162 | 155 | 1 | 0.03 | +6 | +6.2 |
| SAME CHARGE LATER | 2 | 2 | 1 | 0.03 | +3 | +2.8 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 18 | 17 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 129 | 129 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 12 | 12 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 48 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 6 | 6 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 29 | 27 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 4 | 4 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 279 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 37 | 35 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 43 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 202 | 198 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 387 | 365 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 269 | 255 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 315 | 289 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 109 | 109 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 328 | 308 | 0 | 0.00 | - | - |
| HOLD ODDS | 1030 | 1027 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 135 | 132 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 10 | 10 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 16 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 36 | 36 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 47 | 46 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 8 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 8 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 20 | trace | - | - | - | - |
| MOVE SPELL SPOT | 24 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 32 | 32 | 0 | 0.00 | - | - |
| NOT TURNED | 14 | 14 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 66 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 232 | 228 | 0 | 0.00 | - | - |
| ONE ROUTE | 47 | 46 | 0 | 0.00 | - | - |
| OPENS A LANE | 21 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 2841 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 15 | 15 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 6 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 47 | 46 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 73 | 65 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 11 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 33 | 33 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 28 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 7 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 10 | not checked | - | - | - | - |
| SPELL WORTH | 81 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 30 | 30 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 555 | 528 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 52 | 49 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 91 | 86 | 0 | 0.00 | - | - |
| STANDS STILL | 2750 | 2673 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 25 | 24 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 85 | not checked | - | - | - | - |
| THE PROMISE ADDS | 8 | 7 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 2211 | not checked | - | - | - | - |
| WAITS AGAIN | 68 | 61 | 0 | 0.00 | - | - |

### Off best figure: base-s1-882d875-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.86 | 2.49 | 73.7 |
| JOB FIRST | gate | 2.29 | 2.17 | 41.7 |
| ARMY TABLE | rule | 1.60 | 1.57 | 55.8 |
| CHARGE NOW FIRST | rule | 0.37 | 0.94 | 60.1 |
| NO REASON | gate | 0.60 | 0.63 | 34.8 |
| HOLDER ASSIGNMENT | rule | 0.23 | 0.46 | 17.1 |
| JOINT CHARGE NOW | rule | 0.20 | 0.29 | 75.4 |
| PROMISE SHOT AWAY | rule | 0.14 | 0.29 | 58.3 |
| BEST PRIZE | rule | 0.09 | 0.17 | 86.6 |
| WAR ENGINE JOBS | rule | 0.20 | 0.06 | 12.3 |
| ONE PROMISE A TARGET | rule | 0.14 | 0.06 | 33.7 |
| PATHS CROSS | rule | 0.17 | - | 7.4 |
| MARCH OF THE TABLE | rule | 0.09 | 0.06 | 18.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.09 | 0.06 | 16.8 |
| AFTERMATH BAND | gate | 0.06 | 0.06 | 3.4 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.09 | 19.4 |
| SUPPORT NARROWED | rule | 0.09 | 0.03 | 143.4 |
| CANNON PLANNED TARGET | rule | 0.06 | 0.03 | 53.7 |
| FALLBACK | gate | 0.06 | 0.03 | 25.9 |
| REDIRECT WEIGHED | rule | 0.03 | 0.06 | 54.6 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 67.2 |
| CHAFF PASSED | rule | 0.03 | 0.03 | 4.5 |
| CHARGE NOT DECLARED | rule | - | 0.06 | 146.2 |
| DEPLOY BY FIGURES | rule | - | 0.06 | 19.3 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.06 | 99.2 |
| OWN CAST FIRST | rule | - | 0.06 | 3.2 |
| PROMISE READS THE TABLE | rule | - | 0.06 | 88.7 |
| TURN GATE | gate | 0.03 | 0.03 | 14.7 |
| WHO GETS IN | rule | 0.06 | - | 113.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 23.0 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 0.8 |
| MARCH ODDS | rule | 0.03 | - | 15.1 |
| PURSUES BIG PREY | rule | - | 0.03 | 93.5 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| WHO HITS BACK | rule | - | 0.03 | 4.1 |

### Plans: base-s1-882d875-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 61% | 277 | 197 | 71% |
| Mine | join | 0.5 | 100% | 13 | 0 | 0% |
| Mine | move | 28.5 | 94% | 1487 | 0 | 0% |
| Mine | shoot | 10.5 | 55% | 607 | 687 | 113% |
| Mine | support | 0.3 | 70% | 1 | 0 | 0% |
| Opponent | charge | 3.0 | 68% | 462 | 295 | 64% |
| Opponent | join | 0.4 | 93% | 24 | 0 | 0% |
| Opponent | move | 32.1 | 94% | 1449 | 0 | 0% |
| Opponent | shoot | 3.0 | 47% | 208 | 173 | 83% |
| Opponent | support | 1.0 | 65% | 1 | 0 | 0% |

### Packages: hunt the guns, base-s1-882d875-p8

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |
| Opponent | 0.1 | 3 | 0 | 100% | 100% | 0% | 2.3 | 295 | 245 | 100% | 65 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 136 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 204 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 29 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 24 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Vampire Counts | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 232 | 173 | 100% | 0 |
| Warriors of Chaos | 0.2 | 2 | 0 | 100% | 100% | 0% | 2.0 | 326 | 281 | 100% | 23 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |

### Battle groups: base-s1-882d875-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.1 | 36% | 64% | 7% | 0% | 23% | 0% | 15% | 54% | 8% |
| Opponent | REDIRECT COUNTER | 2.0 | 17% | 83% | 17% | 0% | 40% | 0% | 0% | 60% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: base-s1-882d875-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Mine | Chaff | 34 | 73 (34) | 26 | 47 | 59 | 35% | 2.5 | 101 (14) | 63 (17) | 0 (3) | 80 (25) | 53 (9) |
| Mine | Character | 115 | 37 (115) | 37 | 0 | 25 | 31% | 2.6 | 51 (50) | 31 (36) | 22 (14) | 47 (59) | 30 (41) |
| Mine | Clean-up | 20 | 36 (20) | 7 | 28 | 36 | 60% | 3.1 | 27 (10) | 34 (9) | 250 (1) | 44 (12) | 20 (8) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 100 | 0% | 2.7 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Mine | Fast Hammer | 47 | 28 (47) | 15 | 13 | 28 | 43% | 2.7 | 27 (19) | 51 (15) | 1 (13) | 23 (36) | 46 (11) |
| Mine | Hammer | 55 | 40 (55) | 21 | 19 | 26 | 31% | 2.9 | 27 (26) | 46 (23) | 75 (6) | 56 (35) | 17 (20) |
| Mine | Holder | 23 | 48 (23) | 0 | 48 | 34 | 43% | 3.2 | 39 (5) | 72 (12) | 0 (4) | 53 (12) | 50 (9) |
| Mine | Shooter | 44 | 38 (44) | 8 | 30 | 37 | 14% | 1.5 | 51 (9) | 37 (28) | 33 (6) | 47 (33) | 15 (10) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | - | 0 (3) | 0 (1) | - | 0 (4) |
| Mine | War machine | 56 | 34 (56) | 34 | 0 | 48 | 0% | 1.5 | 36 (20) | 41 (29) | 0 (7) | 11 (13) | 42 (43) |
| Mine | Wizard | 22 | 26 (22) | 26 | 0 | 15 | 41% | 2.5 | 9 (11) | 60 (5) | 0 (2) | 41 (8) | 8 (10) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |
| Opponent | Chaff | 65 | 68 (65) | 12 | 56 | 36 | 58% | 2.9 | 56 (22) | 99 (22) | 47 (21) | 88 (46) | 27 (19) |
| Opponent | Character | 93 | 48 (93) | 47 | 1 | 16 | 25% | 2.4 | 41 (35) | 61 (30) | 50 (21) | 59 (56) | 33 (30) |
| Opponent | Clean-up | 22 | 26 (22) | 0 | 26 | 42 | 59% | 4.0 | 3 (6) | 43 (14) | 0 (2) | 39 (15) | 0 (7) |
| Opponent | Fast | 4 | 0 (4) | 0 | 0 | 58 | 25% | 2.0 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 43 | 26 (43) | 13 | 14 | 37 | 40% | 3.1 | 11 (16) | 39 (18) | 22 (9) | 28 (28) | 22 (15) |
| Opponent | Fragile | 7 | 0 (7) | 0 | 0 | 27 | 71% | 2.5 | 0 (1) | 0 (4) | 0 (2) | 0 (4) | 0 (3) |
| Opponent | Hammer | 52 | 28 (52) | 22 | 6 | 28 | 46% | 3.1 | 20 (22) | 41 (24) | 6 (6) | 36 (31) | 15 (21) |
| Opponent | Holder | 36 | 77 (36) | 11 | 66 | 22 | 39% | 2.9 | 26 (7) | 134 (17) | 25 (9) | 125 (20) | 2 (13) |
| Opponent | Shooter | 37 | 80 (37) | 22 | 58 | 44 | 11% | 1.6 | 41 (12) | 123 (19) | 21 (6) | 89 (23) | 65 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | War machine | 16 | 35 (16) | 35 | 0 | 39 | 19% | 2.1 | 23 (6) | 69 (5) | 0 (5) | 69 (6) | 13 (10) |
| Opponent | Wizard | 27 | 4 (27) | 4 | 0 | 25 | 22% | 1.9 | 0 (8) | 12 (8) | 0 (6) | 0 (12) | 13 (10) |

### Charged fights: base-s1-882d875-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 119 | 77 | 0.8 | 1.0 | 103 | 0 | +103 | 0 of 3 | 1 of 3 | - | +103 |
| Mine | Chaos Dwarfs | 3 | 95 | 405 | 1.0 | 1.0 | 405 | 0 | +405 | 2 of 3 | 3 of 3 | - | +405 |
| Mine | Dwarfen Mountain Holds | 4 | 474 | 11 | 1.0 | 1.0 | 11 | 0 | +11 | 0 of 4 | 3 of 4 | - | +11 |
| Mine | Empire of Man | 5 | 471 | 136 | 0.8 | 1.2 | 170 | 0 | +170 | 1 of 4 | 3 of 4 | +0 | +227 |
| Mine | Grand Cathay | 4 | 129 | 123 | 1.8 | 1.1 | 70 | 0 | +70 | 1 of 7 | 6 of 7 | +0 | +82 |
| Mine | High Elf Realms | 3 | 152 | 640 | 3.7 | 1.1 | 175 | 10 | +164 | 4 of 11 | 9 of 11 | +85 | +172 |
| Mine | Kingdom of Bretonnia | 1 | 70 | 60 | 1.0 | 1.0 | 60 | 0 | +60 | 0 of 1 | 1 of 1 | - | +60 |
| Mine | Lizardmen | 1 | 0 | 586 | 6.0 | 1.5 | 98 | 0 | +98 | 0 of 6 | 5 of 6 | +250 | +22 |
| Mine | Ogre Kingdoms | 1 | 440 | 41 | 2.0 | 1.0 | 20 | 37 | -16 | 0 of 2 | 1 of 2 | - | -16 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 355 | 4.0 | 1.0 | 89 | 29 | +60 | 2 of 4 | 2 of 4 | - | +60 |
| Mine | Skaven | 2 | 22 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 2 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 19 | 616 | 3.0 | 1.0 | 206 | 0 | +206 | 3 of 6 | 5 of 6 | - | +206 |
| Mine | Vampire Counts | 2 | 0 | 335 | 3.0 | 1.2 | 112 | 8 | +104 | 2 of 6 | 4 of 6 | +205 | +84 |
| Mine | Warriors of Chaos | 1 | 0 | 505 | 4.0 | 1.0 | 126 | 0 | +126 | 1 of 4 | 4 of 4 | - | +126 |
| Mine | Wood Elf Realms | 1 | 254 | 0 | 2.0 | 1.5 | 0 | 252 | -252 | 1 of 2 | 1 of 2 | +0 | -505 |
| **Mine** | all armies | 35 | 195 | 232 | 1.9 | 1.1 | 125 | 13 | +112 | 19 of 65 | 50 of 65 | +113 | +112 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 3 | 178 | 138 | 2.7 | 1.4 | 52 | 0 | +52 | 4 of 8 | 7 of 8 | +0 | +69 |
| Opponent | High Elf Realms | 1 | 250 | 906 | 3.0 | 1.0 | 302 | 0 | +302 | 3 of 3 | 3 of 3 | - | +302 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 616 | 4.5 | 1.0 | 137 | 0 | +137 | 1 of 9 | 9 of 9 | - | +137 |
| Opponent | Lizardmen | 1 | 0 | 85 | 1.0 | 1.0 | 85 | 0 | +85 | 0 of 1 | 1 of 1 | - | +85 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 0 | 2.0 | 1.0 | 0 | 106 | -106 | 2 of 4 | 1 of 4 | - | -106 |
| Opponent | Skaven | 4 | 8 | 59 | 0.2 | 1.0 | 235 | 0 | +235 | 0 of 1 | 1 of 1 | - | +235 |
| Opponent | Tomb Kings of Khemri | 4 | 135 | 911 | 3.5 | 1.1 | 260 | 19 | +242 | 7 of 14 | 7 of 14 | +173 | +247 |
| Opponent | Vampire Counts | 3 | 18 | 569 | 5.3 | 1.1 | 107 | 2 | +104 | 4 of 16 | 13 of 16 | +0 | +111 |
| Opponent | Warriors of Chaos | 9 | 0 | 227 | 2.3 | 1.0 | 97 | 6 | +92 | 8 of 21 | 16 of 21 | +0 | +96 |
| Opponent | Wood Elf Realms | 5 | 56 | 244 | 1.8 | 1.1 | 136 | 78 | +57 | 5 of 9 | 5 of 9 | -289 | +101 |
| **Opponent** | all armies | 35 | 48 | 328 | 2.5 | 1.1 | 132 | 18 | +114 | 34 of 87 | 64 of 87 | -19 | +124 |

### Effective charges: base-s1-882d875-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 3 | 1 (net +979) | 0 | 0 | 0 | 0 | 2 (net +118) | 0 | 0% (0 of 3) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +0) | 0 | 2 (net +0) | 0 | 0 | 1 (net +45) | 0 | 50% (2 of 4) |
| Mine | Empire of Man | 4 | 0 | 0 | 1 (net +482) | 2 (net +100) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Grand Cathay | 7 | 1 (net +0) | 0 | 1 (net +365) | 2 (net +0) | 3 (net +42) | 0 | 0 | 14% (1 of 7) |
| Mine | High Elf Realms | 11 | 2 (net -58) | 0 | 2 (net +442) | 0 | 2 (net +116) | 4 (net +158) | 1 | 20% (2 of 10) |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 0 | 1 (net +60) | 0 | 0 | 0% (0 of 1) |
| Mine | Lizardmen | 6 | 0 | 0 | 0 | 3 (net +182) | 1 (net +41) | 0 | 2 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net -33) | 1 | 0% (0 of 1) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 6 | 2 (net +232) | 0 | 1 (net +122) | 0 | 0 | 2 (net +220) | 1 | 20% (1 of 5) |
| Mine | Vampire Counts | 6 | 3 (net +140) | 0 | 0 | 0 | 1 (net +0) | 2 (net +102) | 0 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 1 (net +63) | 2 (net +136) | 1 | 0% (0 of 3) |
| Mine | Wood Elf Realms | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 8 | 2 (net +0) | 0 | 1 (net +186) | 3 (net +0) | 0 | 2 (net +114) | 0 | 12% (1 of 8) |
| Opponent | High Elf Realms | 3 | 0 | 1 (net +238) | 0 | 1 (net +380) | 0 | 1 (net +288) | 0 | 0% (0 of 3) |
| Opponent | Kingdom of Bretonnia | 9 | 1 (net +807) | 0 | 0 | 0 | 6 (net +57) | 0 | 2 | 0% (0 of 7) |
| Opponent | Lizardmen | 1 | 0 | 1 (net +85) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 1 (net -261) | 0 | 1 (net +0) | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +235) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 14 | 2 (net +595) | 1 (net +0) | 2 (net +389) | 2 (net +174) | 0 | 3 (net +131) | 4 | 20% (2 of 10) |
| Opponent | Vampire Counts | 16 | 7 (net +134) | 0 | 0 | 1 (net +0) | 3 (net +73) | 4 (net +83) | 1 | 0% (0 of 15) |
| Opponent | Warriors of Chaos | 21 | 4 (net +133) | 0 | 2 (net +0) | 2 (net +62) | 6 (net +71) | 7 (net +121) | 0 | 10% (2 of 21) |
| Opponent | Wood Elf Realms | 9 | 0 | 1 (net +0) | 4 (net +24) | 2 (net +228) | 0 | 0 | 2 | 57% (4 of 7) |

### Charged fights, damage counted: base-s1-882d875-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 213 | 277 | +146 | 172 | 50 | +122 | +57.1 |
| Mine | Effective (55-75%) | 7 | 218 | 162 | +265 | 267 | 3 | +264 | +121.3 |
| Mine | 76-89% | 8 | 374 | 156 | +93 | 131 | 13 | +118 | +31.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 256 | 183 | +106 | 152 | 23 | +129 | +50.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 384 | 71 | +58 | 67 | 24 | +43 | +11.3 |
| Mine | No odds | 12 | 324 | 184 | +49 | 120 | 73 | +47 | +14.5 |
| Mine | All fights | 65 | 289 | 179 | +112 | 148 | 34 | +114 | +39.4 |
| Opponent | Long shot (under 50%) | 16 | 229 | 239 | +216 | 247 | 31 | +216 | +94.4 |
| Opponent | 50-54% | 5 | 318 | 273 | +12 | 111 | 89 | +22 | +6.8 |
| Opponent | Effective (55-75%) | 9 | 420 | 266 | +118 | 191 | 89 | +101 | +24.1 |
| Opponent | 76-89% | 13 | 370 | 201 | +101 | 123 | 7 | +116 | +31.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 314 | 177 | +129 | 144 | 24 | +119 | +38.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 405 | 78 | +66 | 69 | 0 | +69 | +17.1 |
| Opponent | No odds | 11 | 297 | 203 | +67 | 136 | 56 | +81 | +27.3 |
| Opponent | All fights | 87 | 331 | 193 | +114 | 149 | 33 | +116 | +34.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| base-s1-882d875-p8 | move | 219 | 60 (27%) | 46 (21%) | 28 (13%) | 131 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0116, L0132, L2529, L2728 |
| Charmed Shield | Opponent | L0334, L0626, L1525, L2125, L3334 |
| Clockwork Compass | Mine | L1222 |
| Clockwork Compass | Opponent | L1112 |
| Elixir of Power | Mine | L1112, L1128, L1921 |
| Elixir of Power | Opponent | L0419, L0911, L1019 |
| Fistful of Laurels | Mine | L1821 |
| Horn of the Wild Hunt | Mine | L3334 |
| Horn of the Wild Hunt | Opponent | L0233, L1333, L2333 |
| Invocation of Nehek | Mine | L2529, L2728 |
| Invocation of Nehek | Opponent | L1525, L2125 |
| Opal Amulet | Mine | L1429 |
| Periapt of Soul Exchange | Mine | L2023, L2125 |
| Periapt of Soul Exchange | Opponent | L0821, L1721, L1821, L1921 |
| Ring of Doom | Mine | L0216, L0233, L1112, L1128, L1222, L1525, L3334 |
| Ring of Doom | Opponent | L0233, L0715, L0731, L0911, L1112, L1333, L2333 |
| Ring of Jet | Mine | L1019, L1112, L1128, L1222 |
| Ring of Jet | Opponent | L0610, L0911, L1112 |
| Standard of the Fell Warrior | Mine | L1333 |
| Storm Daemon (Renegade 2.0) | Mine | L2125 |
| Storm Daemon (Renegade 2.0) | Opponent | L0821, L1721, L1821, L1921 |
| Twice-Blessed Armour | Mine | L0715, L0731, L1019 |
| Twice-Blessed Armour | Opponent | L0610 |
| Witch Hunter's Ward | Mine | L0715, L0731, L0821 |

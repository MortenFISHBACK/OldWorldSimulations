# Doctrine scorecard: fafix-opp-5e477c5-p4

### Scorecard: fafix-opp-5e477c5-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | yes | 6 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 2 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 0 | 4 | 0 | 4 | 0 | 0 | 0 | 200 |
| L0214 | 4 | 1 | Opponent | yes | 5 | 1 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | 1 | 1 | 0 | 1 | 0 | 0 | 709 |
| L0315 | 3 | 1 | Opponent | yes | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 3 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 3 | 3 | 4 | 0 | 1 | 0 | 0 | 147 |
| L0434 | 2 | 1 | Mine | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 4 | 3 | 5 | 0 | 0 | 0 | 115 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1193 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 1 | 7 | 2 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 6 | 1 | 5 | 1 | 0 | 0 | 984 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 480 |
| L0624 | 6 | 1 | Mine | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 8 | - | 1 | 3 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 877 |
| L0713 | 5 | 1 | Opponent | no | - | - | 0 | 1 | 1 | 0 | 0 | 70 |
| L0729 | 3 | 1 | Mine | no | 8 | 4 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 4 | 4 | 1 | 0 | 0 | 0 | 0 | 641 |
| L0819 | 3 | 1 | Opponent | yes | 5 | 2 | 1 | 2 | 0 | 0 | 0 | 255 |
| L0835 | 1 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 125 |
| L0926 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 726 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | no | 2 | 5 | 3 | 0 | 2 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 6 | 1 | 6 | 0 | 0 | 0 | 500 |
| L1126 | 4 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 1 | 6 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 2 | 0 | 0 | 340 |
| L1314 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 317 |
| L1314 | 6 | 1 | Opponent | no | 12 | 5 | 1 | 1 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | no | - | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | no | - | - | 0 | 4 | 1 | 0 | 0 | 314 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 133 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 2 | - | 1 | 2 | 1 | 0 | 0 | 500 |
| L1719 | 3 | 1 | Mine | yes | 1 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 5 | 5 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 5 | 7 | 3 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 1 | 0 | 5 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | no | - | - | 1 | 2 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 5 | 2 | 2 | 0 | 0 | 0 | 420 |
| L2123 | 5 | 1 | Mine | yes | - | 5 | 3 | 5 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 1 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 2 | 3 | 3 | 0 | 2 | 0 | 0 | 314 |
| L2527 | 1 | 1 | Mine | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 6 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 1 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 6 | 2 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | yes | 12 | 2 | 1 | 3 | 0 | 0 | 0 | 340 |
| L3234 | 6 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 39% | 2.2 | 2.9 | 2.4 | 1.5 | 0.2 | 0.0 | 0.0 | 286.3 |
| **Average** | | | Opponent | 36% | 2.4 | 3.0 | 1.7 | 2.5 | 0.4 | 0.0 | 0.0 | 117.2 |

### KPIs: fafix-opp-5e477c5-p4

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE; both sides: LIKELY CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 21% (36 of 174) | 3% (6 of 184) | 12% (42 of 358) |
| Winner chose to follow up after the loser gave ground |  | 98% (41 of 42); on the table 98% | 93% (14 of 15); on the table 93% | 96% (55 of 57); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 78% (7 of 9); on the table 78% | 78% (7 of 9); on the table 89% | 78% (14 of 18); on the table 83% |
| Winner chose to pursue after the loser fled |  | 81% (13 of 16); on the table 100% | 85% (11 of 13); on the table 100% | 83% (24 of 29); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 91% (61 of 67); on the table 96% | 86% (32 of 37); on the table 95% | 89% (93 of 104); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 33% (89 of 266) | 39% (67 of 172) | 36% (156 of 438) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (89 of 194) | 48% (67 of 140) | 47% (156 of 334) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 65% (32 of 49) | 69% (44 of 64) | 67% (76 of 113) |
| Points that never fought | lower | 47% (31693 of 67942) | 48% (34555 of 71984) | 47% (66248 of 139926) |
|   infantry points that never fought | lower | 53% (8183 of 15347) | 65% (8935 of 13804) | 59% (17118 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (158 of 270) | 66% (186 of 280) | 63% (344 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.6 uses a game | 89% (8 of 9); 0.7 uses a game | 94% (29 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.6 uses a game | 40% (8 of 20); 0.3 uses a game | 44% (16 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 80% (12 of 15); 0.3 uses a game | 68% (23 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (29885 of 57750) | 61% (38917 of 63347) | 57% (68802 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (27%) | 0.7 (25%) | 2.0 (26%) |
| MARCHED: its unit marched | 1.4 (29%) | 0.7 (25%) | 2.1 (27%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.2 (6%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.1 (23%) | 0.4 (12%) | 1.5 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (10%) | 0.3 (4%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 0.8 (16%) | 0.4 (14%) | 1.2 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.2 | 2.1 | 4.3 | 0.4 | 1.6 |
| not cast | 3.0 | 2.7 | 2.7 | 7.8 | 1.6 | 21.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (64%) | 0.1 (4%) | 2.0 (26%) | 0.4 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (27%) | 0.4 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (4%) | 0.4 (14%) | 1.5 (19%) | 0.2 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.1 (4%) | 0.3 (10%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.7 (22%) | 0.3 (11%) | 0.2 (6%) | 1.2 (16%) | 0.2 (11%) | 2.2 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.1 (2%) | 0.1 (5%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (9%) | 0.0 (1%) | 0.0 (0%) | 0.3 (21%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (61%) | 0.1 (5%) | 1.6 (57%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.5 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 0.5 a game | 1.1 a game |
| stood (cast and not dispelled) | 64% (37 of 58) | 25% (3 of 12) | 57% (40 of 70) |
| the unit moved after it | 84% (31 of 37) | 67% (2 of 3) | 82% (33 of 40) |
| it charged on its next turn | 3% (1 of 37) | 0% (0 of 3) | 2% (1 of 40) |
| the enemy charged it first | 11% (4 of 37) | 0% (0 of 3) | 10% (4 of 40) |
| it fought by the end of its next turn | 8% (3 of 37) | 0% (0 of 3) | 8% (3 of 40) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 37) | 0% (0 of 3) | 0% (0 of 40) |
| none of these (no charge, no fight, no charge escaped) | 86% (32 of 37) | 100% (3 of 3) | 88% (35 of 40) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (628 of 947) | 61% (305 of 497) | 65% (933 of 1444) |
|   cavalry | 69% (67 of 97) | 71% (75 of 106) | 70% (142 of 203) |
|   character | 50% (58 of 115) | 26% (31 of 117) | 38% (89 of 232) |
|   chariot | 52% (61 of 117) | 65% (15 of 23) | 54% (76 of 140) |
|   infantry | 65% (181 of 280) | 75% (152 of 202) | 69% (333 of 482) |
|   monster | 49% (25 of 51) | 35% (7 of 20) | 45% (32 of 71) |
|   war machine | 82% (236 of 287) | 86% (25 of 29) | 83% (261 of 316) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (26%) | 1.4 (26%) | 3.6 (26%) |
| CHARGED: it charged | 1.1 (12%) | 1.0 (19%) | 2.1 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (3%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.4 (5%) | 0.4 (7%) | 0.8 (6%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| NO TARGET IN RANGE | 2.5 (28%) | 1.6 (31%) | 4.1 (29%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.2 (4%) | 0.4 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (21%) | 0.5 (10%) | 2.4 (17%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.2 (2%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 1.8 | 79% | 6.0 pts | 38 pts |
| character | 3.0 | 0.8 | 78% | 7.4 pts | 22 pts |
| chariot | 2.1 | 1.3 | 66% | 15.2 pts | 32 pts |
| infantry | 14.0 | 4.5 | 76% | 9.7 pts | 136 pts |
| monster | 0.9 | 0.2 | 85% | 2.8 pts | 3 pts |
| war machine | 7.2 | 7.1 | 64% | 36.1 pts | 262 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 3.6 | 4.0 |
| Charges that made contact a game | 2.9 | 2.3 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.94 declared, 0.76 contact (17 units) | 0.24 declared, 0.18 contact (17 units) | 0.59 declared, 0.47 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.22 declared, 0.89 contact (9 units) | 0.64 declared, 0.29 contact (14 units) | 0.87 declared, 0.52 contact (23 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.34 contact (247 units) | 0.38 declared, 0.26 contact (300 units) | 0.45 declared, 0.29 contact (547 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (49 of 81) | 62% (10 of 16) | 50% (3 of 6) | 60% (62 of 103) |
| Character in a unit | 81% (29 of 36) | 78% (14 of 18) | 100% (1 of 1) | 80% (44 of 55) |
| Character on its own | 83% (24 of 29) | 58% (14 of 24) | 36% (28 of 77) | 51% (66 of 130) |
| Chariot | 67% (10 of 15) | 33% (4 of 12) | - | 52% (14 of 27) |
| Infantry | 65% (54 of 83) | 44% (11 of 25) | 50% (3 of 6) | 60% (68 of 114) |
| Monster | 74% (25 of 34) | 79% (11 of 14) | - | 75% (36 of 48) |
| Monstrous | 79% (11 of 14) | 64% (9 of 14) | - | 71% (20 of 28) |
| War Machines | 74% (32 of 43) | 100% (2 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 91% (10 of 11); on the table 100% | 27% (28 of 102) | 15% | 59% (13 of 22) | 100% (6 of 6); 3.0 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 83% (10 of 12); on the table 83% | 50% (12 of 24) | 26% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 86% | 59% (16 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (1 of 1); on the table 100% | 50% (9 of 18) | 66% | 69% (43 of 62) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 100% (4 of 4); on the table 100% | 31% (26 of 84) | 56% | 43% (16 of 37) | 100% (9 of 9); 6.8 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 96% (22 of 23); on the table 100% | 36% (13 of 36) | 40% | 50% (35 of 70) | 100% (7 of 7); 3.1 uses a game | 40% (12 of 30); 2.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 43% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (4 of 4); on the table 100% | 100% (6 of 6) | 55% | 71% (15 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 60% (3 of 5); on the table 100% | 67% (4 of 6) | 65% | 93% (13 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (4 of 4); on the table 100% | 26% (11 of 42) | 34% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 6 | 78% (7 of 9); on the table 89% | 28% (11 of 40) | 43% | 71% (32 of 45) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 100% (6 of 6); on the table 100% | 33% (2 of 6) | 51% | 60% (12 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (5 of 5); on the table 100% | 50% (28 of 56) | 47% | 71% (30 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 100% (9 of 9); on the table 100% | 33% (4 of 12) | 47% | 71% (51 of 72) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 78% (7 of 9); on the table 89% | 33% (2 of 6) | 49% | 62% (35 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (fafix-opp-5e477c5-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (26) | 40% (20) | 44% (46) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.47 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.06 | 0.19 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.39 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.31 | 0.03 | 2.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.08 | 0.06 | 1.14 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.33 | 0.42 | 6.75 |

### Quality by phase: fafix-opp-5e477c5-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 43% (60 of 141) | 41% (39 of 96) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (198 of 455) | 48% (41 of 86) |
| Strategy | Close-in objectives charged next turn | 15% (30 of 206) | - |
| Strategy | Support requests answered (helper made contact too) | 73% (11 of 15) | 57% (8 of 14) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (4 of 6) | 56% (5 of 9) |
| Strategy | Joined characters whose unit fought | 45% (21 of 47) | 34% (11 of 32) |
| Strategy | Lone characters that fought | 66% (50 of 76) | 61% (51 of 84) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.5 | 2.5 |
| Movement | Points that never moved of their own | 286.3 | 117.2 |
| Movement | Fights charged into per game | 2.4 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 77, net -11 | 12 of 58, net +59 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 77, net -50 | 4 of 58, net -45 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 77, net +95 | 5 of 58, net +88 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 77, net +71 | 14 of 58, net +76 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 9.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (173 of 420) | 44% (153 of 347) |
| Shooting | Points destroyed by shooting units | 84.6 | 39.9 |
| Shooting | War machine shots | 6.6 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (139 of 236) | 16% (4 of 25) |
| Shooting | Points destroyed by war machines | 82.1 | 14.3 |
| Magic | Magic missiles cast | 1.7 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (15 of 61) | 12% (6 of 51) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.3 |
| Magic | Wounds caused by other spells | 1.4 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 112.4 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.2 / 0.6 / 0.2 | 1.7 / 0.5 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 228.5 | 281.7 |
| Combat | Points run down | 44.9 | 64.2 |
| Combat | Net points per charged fight, damage counted | +66 | +87 |
| Combat | Net per 100 charger points, damage counted | +22.0 | +27.8 |
| Combat | First round won (charged fights) | 80% | 68% |
| Combat | Net points per charged fight | +58 | +98 |
| Combat | Net points per supported fight / lone fight | +93 / +51 | -25 / +113 |
| Combat | Charged fights on a top-3 enemy unit | 24 of 88 | 33 of 75 |
| Game | Points lost | 479.2 | 692.0 |
| Game | VP from objectives | 675.3 | 392.5 |
| Game | Lone holders (player turns) | 2.2 | 2.4 |

- Mine won / drew / lost: 19 / 11 / 6 of 36 ended games (of 36); mean margin (Mine - Opponent) +519 VP
- The side that went first won 16 of 25 games with a winner
- Points traded per game (both sides' losses): 1171
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fafix-opp-5e477c5-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 4.0 |
| ADVANCE WORTH | 6.1 | -176.1 | 245.7 | 93.8 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 11.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.4 | +1.2 | 0.0 | 0.0 | 0.7 | +3.0 | 0.0 | 16.6 |
| BEST FACING | 0.7 | +15.7 | 0.0 | 0.0 | - | - | - | - |
| BEST FIRST | 1.4 | +75.1 | 66.7 | 14.1 | - | - | - | - |
| BEST OVERALL | 0.4 | +21.4 | 0.0 | 0.0 | - | - | - | - |
| BEST PREY | 0.7 | +35.8 | 24.3 | 22.1 | - | - | - | - |
| BEST PRIZE | 0.2 | -11.7 | 5.3 | 0.0 | 0.1 | -4.2 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.3 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | -16.6 | 18.8 | 10.6 | 0.1 | -33.5 | 30.3 | 0.0 |
| BOMBING RUN | 0.0 | +0.2 | 1.7 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.2 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 179.1 | 14.6 | 0.1 | +0.0 | 8.4 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +134.3 | 467.3 | 104.0 | 0.6 | +39.0 | 66.7 | 3.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -2.7 | 51.4 | 7.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.9 | +35.1 | 69.7 | 29.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +23.1 | 12.3 | 10.3 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.1 | +0.0 | 0.0 | 9.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.2 | +65.1 | 0.0 | 29.7 | 1.1 | +54.2 | 0.0 | 16.6 |
| CHAFF PASSED | 0.3 | -0.6 | 5.0 | 3.5 | 0.1 | -0.3 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 10.4 | -503.1 | 0.0 | 368.3 |
| CHARGE NOW FIRST | 2.8 | +0.0 | 269.5 | 77.4 | 1.1 | +0.0 | 169.8 | 49.0 |
| CHARGE NOW WEIGHED | 0.5 | -34.6 | 17.3 | 7.0 | - | - | - | - |
| CHARGER SLAIN LOST | 0.5 | -11.6 | 82.4 | 21.9 | 0.4 | -7.5 | 21.7 | 1.1 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 7.4 | 0.0 | 0.1 | +0.0 | 3.8 | 1.2 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 34.0 | 0.4 | +0.0 | 20.8 | 21.8 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +107.9 | 40.8 | 33.6 | 0.2 | +28.4 | 5.3 | 2.6 |
| COVER ONCE | 9.2 | -514.4 | 0.0 | 93.5 | 4.9 | -297.9 | 0.0 | 122.6 |
| DEFENSIVE ARMY | 0.1 | -0.0 | 0.0 | 1.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +6.0 | 35.4 | 16.7 | 0.1 | +7.7 | 17.9 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +3.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.3 | +147.5 | 0.0 | 28.0 | 0.0 | +2.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.7 | +7.0 | 193.2 | 37.9 |
| FALLBACK BY WORTH | 5.1 | +65.1 | 0.0 | 47.9 | 0.2 | +4.4 | 0.0 | 0.8 |
| FALLS SHORT | - | - | - | - | 0.6 | -6.3 | 0.9 | 0.0 |
| FEATURE BUFFS | - | - | - | - | 0.6 | +12.8 | 0.0 | 14.2 |
| FIGHT LIFT | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 2.4 | 0.1 | +0.7 | 0.0 | 9.4 |
| FIVE ACTION | - | - | - | - | 43.4 | +1331.3 | 387.7 | 709.5 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 93.0 | 6.0 | +0.0 | 0.0 | 176.7 |
| FOCUS FIRE | 0.0 | +1.2 | 1.2 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +63.5 | 0.0 | 16.9 | 0.4 | +58.8 | 0.0 | 5.4 |
| FOUR ROUNDS | - | - | - | - | 2.6 | +138.1 | 253.9 | 56.2 |
| FRIENDS SHOTS CHECKED | 0.1 | +5.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.1 | -1.2 | 26.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.1 | 6.5 | 0.0 |
| GROUND FLIERS | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 15.9 | 6.2 | 0.2 | +0.0 | 25.4 | 5.7 |
| HILL BY ITS CHANCE | 0.9 | -76.5 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 9.2 | -159.3 | 558.0 | 81.6 | 2.1 | -96.0 | 207.8 | 49.1 |
| HUNT ADVANCE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| HUNT DROPPED | 0.1 | +0.0 | 13.1 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.5 | +13.9 | 0.0 | 0.0 | 0.4 | +15.8 | 0.0 | 9.9 |
| HUNT RESULT | 0.1 | +0.0 | 13.1 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.1 | +15.9 | 13.1 | 0.0 | - | - | - | - |
| IDLE COST | 18.2 | -311.8 | 0.0 | 97.4 | 23.1 | -382.0 | 0.0 | 296.6 |
| INVITES THE FIGHT | 1.4 | +8.2 | 79.3 | 28.6 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +1.4 | 15.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -1.0 | 10.3 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +0.5 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.3 | 4.2 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 2.0 | +60.0 | 199.4 | 39.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +37.1 | 120.1 | 37.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT NEXT TURN | 5.6 | +141.9 | 297.4 | 37.6 | - | - | - | - |
| LINE HITS NO ONE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | 0.4 | +17.2 | 0.0 | 1.2 | 0.1 | +3.0 | 0.0 | 5.3 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +1.1 | 10.8 | 2.1 | 0.2 | +2.6 | 1.4 | 3.1 |
| LOST CHARGE | 3.1 | -46.1 | 212.0 | 46.0 | 0.1 | -0.1 | 0.0 | 3.1 |
| LURE BY WHAT IT DRAWS | 0.1 | -25.5 | 0.0 | 5.8 | - | - | - | - |
| MAKE SURE TOGETHER | 0.8 | +65.4 | 67.3 | 0.0 | 0.1 | +1.6 | 0.0 | 2.1 |
| MANOEUVRE | 0.3 | +7.5 | 0.0 | 0.0 | 1.1 | +13.5 | 0.0 | 17.8 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 15.0 |
| MARCH CHECK | 0.4 | +24.4 | 0.0 | 0.0 | 0.2 | +16.0 | 0.0 | 6.4 |
| MARCH ODDS | 0.3 | +19.1 | 25.8 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.5 | +32.1 | 0.0 | 27.8 | 0.5 | +50.5 | 0.0 | 62.5 |
| MAX FOR POSITIONING | 7.1 | +127.2 | 0.0 | 76.3 | 7.8 | +92.0 | 0.0 | 137.3 |
| MISSILES IN THE MOVE | 4.3 | +143.2 | 0.0 | 60.2 | 2.4 | +33.7 | 0.0 | 71.2 |
| MISSILES NEXT TURN | 5.0 | +105.3 | 0.0 | 74.1 | 3.3 | +25.9 | 0.0 | 133.7 |
| MODEL FACING | 0.1 | +22.6 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 28.7 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.4 | +13.8 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.4 | +14.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -55.8 | 10.1 | 31.0 | 0.1 | -3.6 | 0.0 | 2.6 |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE | 4.2 | +199.0 | 236.3 | 15.6 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 17.2 | -333.1 | 24.5 | 286.8 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 3.7 | -255.3 | 18.5 | 47.6 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.7 | -84.4 | 192.5 | 48.8 |
| NO RALLY LEFT | 0.1 | +2.5 | 0.0 | 3.9 | 0.0 | +0.9 | 0.0 | 15.0 |
| NOT NEEDED | 0.4 | -12.2 | 50.6 | 8.6 | - | - | - | - |
| NOT TURNED | 6.3 | +104.8 | 0.0 | 139.8 | 0.4 | +2.1 | 0.0 | 8.1 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 22.1 | 0.4 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 17.4 | -689.1 | 4.7 | 238.3 | 1.3 | -57.8 | 0.0 | 29.8 |
| ONE FIGHT FORMULA | 10.3 | -162.8 | 75.3 | 92.9 | 8.3 | -187.1 | 0.0 | 192.3 |
| ONE OBJECTIVE FORMULA | 3.4 | -190.4 | 0.0 | 27.9 | 2.1 | -41.8 | 0.0 | 53.8 |
| OPENS A LANE | 0.2 | +3.2 | 20.0 | 10.6 | - | - | - | - |
| OPENS UP | 0.4 | +27.5 | 30.4 | 5.1 | 0.2 | +31.9 | 9.4 | 5.4 |
| OVERRUNS AWAY | 0.6 | +17.9 | 33.1 | 16.1 | 0.4 | +15.6 | 49.8 | 15.4 |
| PATHS CROSS | 2.4 | +186.0 | 0.0 | 16.4 | 3.6 | +323.7 | 0.0 | 56.5 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | 0.1 | +8.1 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.6 | 0.0 | 3.9 | 0.1 | -0.5 | 0.0 | 11.2 |
| PLAN RESULT | 42.4 | +1686.4 | 1860.3 | 723.9 | 39.7 | +232.0 | 241.4 | 1074.7 |
| PURSUES BIG PREY | 0.1 | -6.0 | 0.0 | 5.1 | 0.0 | -0.4 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.4 | +30.7 | 0.0 | 23.3 | 1.8 | +40.1 | 0.0 | 68.9 |
| RANDOM MOVER NO PROMISE | 0.3 | -8.7 | 10.5 | 8.8 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 1.0 | -30.0 | 0.0 | 21.6 | 0.9 | -22.5 | 0.0 | 13.2 |
| REDIRECT COUNTER | 2.6 | +169.4 | 0.0 | 46.0 | 5.5 | +384.7 | 0.0 | 79.6 |
| REDIRECT WEIGHED | 0.2 | -1.5 | 0.0 | 9.4 | 0.1 | +0.8 | 4.0 | 5.4 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 26.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.6 | +17.9 | 0.0 | 4.8 | 0.8 | +29.7 | 0.0 | 15.7 |
| RESTRAINS TO SHOOT | 0.2 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.5 | +81.5 | 233.5 | 88.1 | 1.6 | +18.2 | 188.1 | 38.7 |
| RISK ONCE | 1.8 | +19.3 | 4.7 | 75.3 | - | - | - | - |
| RUN DOWN | - | - | - | - | 1.8 | -15.5 | 129.4 | 55.1 |
| SAFE SURE CHARGE | 0.1 | -0.6 | 3.3 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.1 | +74.7 | 0.0 | 13.8 | 0.1 | +1.4 | 0.0 | 0.0 |
| SCALED CHANCE | - | - | - | - | 5.3 | +55.4 | 8.1 | 107.3 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -12.9 | 0.0 | 0.0 | 0.2 | -13.7 | 0.0 | 1.7 |
| SEARCH SPOT | 2.3 | +96.7 | 0.0 | 13.8 | 8.2 | +278.9 | 0.0 | 204.8 |
| SELF MOVE SPELL | 0.2 | +24.6 | 0.0 | 0.0 | 0.5 | +11.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +74.7 | 67.3 | 0.0 | 0.3 | +9.4 | 0.0 | 16.9 |
| SET-UP ANY TARGET | 0.6 | +94.6 | 29.4 | 13.9 | - | - | - | - |
| SET-UP MISSED | 0.1 | +17.3 | 0.0 | 0.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +79.5 | 78.4 | 6.2 | 0.5 | +14.2 | 0.0 | 15.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.7 | +0.0 | 183.9 | 10.0 | 0.4 | +0.0 | 50.2 | 1.8 |
| SHOTS IN THE MOVE | 16.1 | +573.3 | 0.0 | 177.2 | 8.6 | +231.7 | 0.0 | 100.9 |
| SPELL SETS UP CHARGE | 0.6 | +103.4 | 29.4 | 13.9 | - | - | - | - |
| SPELL WORTH | 1.5 | +17.9 | 27.8 | 27.8 | 2.0 | +36.0 | 135.1 | 132.4 |
| SPELLS IN THE FIGHT | 1.0 | -0.6 | 168.0 | 18.1 | 0.4 | -6.7 | 48.9 | 9.3 |
| STABLE ROLE | 12.9 | +0.0 | 481.8 | 159.0 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.5 | -2.8 | 46.4 | 6.1 |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +13.2 | 0.0 | 1.8 | - | - | - | - |
| STOPS | 0.0 | +0.0 | 13.1 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.5 | +32.8 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 8.8 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 6.4 | -64.1 | 278.4 | 69.2 | 0.9 | +0.0 | 68.9 | 40.6 |
| SUPPORTS | 4.4 | +65.5 | 71.5 | 35.4 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.3 | 10.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.4 | +0.9 | 7.3 | 1.7 | 0.4 | +5.6 | 0.0 | 21.4 |
| THROUGH LINE OF FIRE | 0.3 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 2.2 | +0.0 | 3.1 | 19.4 |
| TURN WORTH | 0.5 | -34.9 | 33.1 | 21.1 | 0.1 | -3.1 | 7.6 | 0.0 |
| TWO OR MORE ARRIVE | 0.4 | +2.1 | 61.9 | 0.0 | 0.2 | +0.4 | 0.0 | 7.1 |
| WAIT AFTER COSTS | 8.2 | -345.9 | 412.9 | 65.9 | - | - | - | - |
| WALKS TO THE FIGHT | 1.9 | +10.9 | 64.4 | 24.2 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 25.8 | 16.1 | - | - | - | - |
| WEARS DOWN | 1.2 | +40.5 | 124.2 | 44.9 | - | - | - | - |
| WHO HITS BACK | 0.3 | +9.8 | 0.0 | 6.5 | 0.3 | +13.9 | 0.0 | 6.2 |
| WHOLE FIGHT | 0.1 | +7.1 | 8.5 | 7.6 | 0.1 | +2.7 | 5.2 | 0.8 |
| WHOLE FIGHT GAIN | 0.3 | +22.1 | 53.5 | 0.0 | 0.3 | +21.1 | 19.7 | 1.1 |
| WIDER SPREAD | 2.8 | -6.8 | 290.1 | 48.6 | 1.8 | -3.7 | 180.3 | 16.6 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 10.1 | 0.0 |

### Rule changes: fafix-opp-5e477c5-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 675 | 675 | 675 | 18.75 | -26888 | -39.8 |
| SEARCH SPOT | 378 | 378 | 356 | 9.89 | +13522 | +38.0 |
| PATHS CROSS | 216 | 216 | 216 | 6.00 | +18349 | +84.9 |
| IDLE COST | 1489 | 991 | 123 | 3.42 | +1384 | +11.3 |
| SHOTS IN THE MOVE | 888 | 716 | 99 | 2.75 | +1779 | +18.0 |
| CHARGE LOSSES | 376 | 376 | 89 | 2.47 | +7318 | +82.2 |
| FIVE ACTION | 1561 | 1561 | 88 | 2.44 | +2630 | +29.9 |
| MOVE TO CHARGE | 150 | 150 | 88 | 2.44 | +2410 | +27.4 |
| FACES THE THREAT | 84 | 84 | 84 | 2.33 | +5379 | +64.0 |
| MAX FOR POSITIONING | 537 | 433 | 81 | 2.25 | +288 | +3.6 |
| SUPPORTS | 159 | 159 | 80 | 2.22 | +913 | +11.4 |
| COVER ONCE | 508 | 327 | 78 | 2.17 | +2233 | +28.6 |
| REDIRECT COUNTER | 291 | 227 | 77 | 2.14 | +5709 | +74.1 |
| RANDOM MOVE BY FIGURES | 113 | 113 | 76 | 2.11 | +2551 | +33.6 |
| KILLS COUNT NEXT TURN | 202 | 202 | 64 | 1.78 | +852 | +13.3 |
| CHAFF IN THE MOVE | 83 | 82 | 60 | 1.67 | +1070 | +17.8 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 621 | 621 | 53 | 1.47 | +451 | +8.5 |
| BEST FIRST | 52 | 52 | 52 | 1.44 | +2705 | +52.0 |
| WAIT AFTER COSTS | 297 | 297 | 50 | 1.39 | +786 | +15.7 |
| RESERVE FALL BACK | 49 | 49 | 49 | 1.36 | +1715 | +35.0 |
| FALLBACK BY WORTH | 192 | 192 | 47 | 1.31 | +2502 | +53.2 |
| ADVANCE WORTH | 219 | 219 | 45 | 1.25 | +559 | +12.4 |
| MISSILES IN THE MOVE | 241 | 172 | 45 | 1.25 | +851 | +18.9 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| ONE FIGHT FORMULA | 670 | 472 | 42 | 1.17 | +344 | +8.2 |
| FOLLOW UP WEIGHED | 41 | 41 | 41 | 1.14 | +4404 | +107.4 |
| SAFER THAN THE JOB | 41 | 41 | 41 | 1.14 | +2737 | +66.8 |
| ARTILLERY RE-ROLL WEIGHED | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RISK BY ARC | 146 | 144 | 40 | 1.11 | +1093 | +27.3 |
| SHOT REPLANNED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 70 | 70 | 37 | 1.03 | +1162 | +31.4 |
| FOUR ROUNDS | 93 | 93 | 35 | 0.97 | +1956 | +55.9 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CANNON PLANNED TARGET | 214 | 214 | 31 | 0.86 | -865 | -27.9 |
| CHARGE NOW FIRST | 140 | 140 | 30 | 0.83 | -1708 | -56.9 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MANOEUVRE | 51 | 51 | 28 | 0.78 | +763 | +27.2 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| WALKS TO THE FIGHT | 68 | 68 | 26 | 0.72 | +85 | +3.3 |
| BEST FACING | 24 | 24 | 24 | 0.67 | +565 | +23.5 |
| HONEST WORTH | 408 | 407 | 22 | 0.61 | +223 | +10.1 |
| CAST JOB | 33 | 33 | 21 | 0.58 | +456 | +21.7 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| WHO HITS BACK | 21 | 21 | 21 | 0.58 | +539 | +25.7 |
| MARCH CHECK | 23 | 23 | 20 | 0.56 | +685 | +34.3 |
| CHARGE NOW WEIGHED | 19 | 19 | 19 | 0.53 | +1119 | +58.9 |
| KEEPS ITS TARGET | 72 | 72 | 19 | 0.53 | +260 | +13.7 |
| STOPS SHORT OF THE FLANK | 19 | 19 | 19 | 0.53 | +1181 | +62.2 |
| SCALED CHANCE | 190 | 190 | 18 | 0.50 | +112 | +6.2 |
| SET UP TOGETHER | 49 | 42 | 18 | 0.50 | +496 | +27.6 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 134 | 134 | 16 | 0.44 | +300 | +18.8 |
| WHOLE FIGHT GAIN | 24 | 23 | 16 | 0.44 | +288 | +18.0 |
| BEST OVERALL | 15 | 15 | 15 | 0.42 | +769 | +51.3 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +495 | +33.0 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -33 | -2.4 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| KILLS COUNT | 58 | 58 | 13 | 0.36 | +175 | +13.4 |
| WAR ENGINE JOBS | 24 | 24 | 13 | 0.36 | -148 | -11.3 |
| INVITES THE FIGHT | 51 | 51 | 12 | 0.33 | +77 | +6.4 |
| OPENS UP | 23 | 23 | 11 | 0.31 | +643 | +58.5 |
| RISK ONCE | 66 | 49 | 11 | 0.31 | +134 | +12.2 |
| BLOCKED WHEEL | 10 | 10 | 10 | 0.28 | +240 | +24.0 |
| MARCH ODDS | 10 | 10 | 10 | 0.28 | +188 | +18.8 |
| REDIRECT WEIGHED | 10 | 10 | 10 | 0.28 | -204 | -20.4 |
| THROUGH LINE OF FIRE | 10 | 10 | 10 | 0.28 | +315 | +31.5 |
| BIG CHARACTER SAFETY | 9 | 9 | 9 | 0.25 | +4 | +0.5 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MISSILES NEXT TURN | 300 | 207 | 9 | 0.25 | +38 | +4.2 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE REACH TOGETHER | 31 | 29 | 9 | 0.25 | +52 | +5.8 |
| BEST PREY | 24 | 24 | 8 | 0.22 | +420 | +52.5 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -846 | -105.7 |
| MAKE SURE TOGETHER | 33 | 21 | 8 | 0.22 | +237 | +29.6 |
| ONE OBJECTIVE FORMULA | 197 | 121 | 8 | 0.22 | +325 | +40.6 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -114 | -14.2 |
| SUPPORT NARROWED | 264 | 264 | 8 | 0.22 | -77 | -9.7 |
| FEATURE BUFFS | 20 | 20 | 7 | 0.19 | +127 | +18.2 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| OVERRUNS AWAY | 34 | 34 | 7 | 0.19 | +211 | +30.1 |
| CASTING BLOCK | 12 | 12 | 6 | 0.17 | +406 | +67.7 |
| REFUSING RETIRES | 13 | 13 | 6 | 0.17 | -2 | -0.4 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +288 | +48.0 |
| WEARS DOWN | 42 | 41 | 6 | 0.17 | +182 | +30.3 |
| FIRE AND FLEE | 5 | 5 | 5 | 0.14 | +29 | +5.9 |
| MODEL FACING | 5 | 5 | 5 | 0.14 | +813 | +162.6 |
| STAY WEIGHED | 5 | 5 | 5 | 0.14 | +476 | +95.1 |
| WHOLE FIGHT | 7 | 7 | 5 | 0.14 | +264 | +52.8 |
| WIDER SPREAD | 163 | 160 | 5 | 0.14 | +13 | +2.6 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.11 | +183 | +45.8 |
| HUNT IN PAIRS | 33 | 23 | 4 | 0.11 | +174 | +43.6 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +171 | +42.7 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +28 | +7.0 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +391 | +97.7 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -231 | -57.8 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +112 | +37.2 |
| LONG SHOT | 20 | 20 | 3 | 0.08 | +20 | +6.6 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 60 | 60 | 2 | 0.06 | +59 | +29.5 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +63 | +31.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OPENS A LANE | 9 | 3 | 2 | 0.06 | +3 | +1.7 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +119 | +59.6 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -44 | -22.0 |
| SPELLS IN THE FIGHT | 48 | 47 | 2 | 0.06 | +18 | +9.0 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.06 | -46 | -23.0 |
| TWO OR MORE ARRIVE | 21 | 12 | 2 | 0.06 | +2 | +1.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.03 | +13 | +13.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +6 | +5.5 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CARRIES OUT SET-UP | 7 | 7 | 1 | 0.03 | -98 | -98.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -4 | -4.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| EDGE GIVE GROUND | 14 | 14 | 1 | 0.03 | +76 | +75.8 |
| FALLS SHORT | 20 | 20 | 1 | 0.03 | +27 | +27.4 |
| LINE HITS NO ONE | 1 | 1 | 1 | 0.03 | +4 | +4.3 |
| LOST CHARGE | 112 | 112 | 1 | 0.03 | +30 | +30.0 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +24 | +23.9 |
| RUN DOWN | 63 | 63 | 1 | 0.03 | +2 | +1.6 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -1 | -0.9 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 40 | 30 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 12 | 11 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 33 | 33 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 46 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 32 | 31 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 43 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 5 | 5 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 442 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 16 | 15 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 31 | 31 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 1 | 1 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 2 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 36 | 36 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 9 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 15 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 26 | trace | - | - | - | - |
| MOVE SPELL SPOT | 28 | not checked | - | - | - | - |
| NEEDED THERE | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 61 | 61 | 0 | 0.00 | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 243 | 243 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| PLAN RESULT | 2954 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 10 | 10 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 69 | 69 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 21 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 22 | not checked | - | - | - | - |
| SPELL WORTH | 127 | not checked | - | - | - | - |
| STABLE ROLE | 464 | 464 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 19 | 19 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 81 | 81 | 0 | 0.00 | - | - |
| TURN WORTH | 21 | 21 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: fafix-opp-5e477c5-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.78 | 1.14 | 41.0 |
| CHARGE NOW FIRST | rule | 0.58 | 0.25 | 56.9 |
| TURN GATE | gate | 0.67 | - | 32.7 |
| FALLBACK | gate | 0.61 | 0.03 | 31.3 |
| WAR ENGINE JOBS | rule | 0.36 | - | 11.3 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 2.4 |
| BEST PRIZE | rule | 0.17 | 0.06 | 105.7 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.06 | 14.2 |
| CHAFF PASSED | rule | 0.11 | 0.08 | 4.7 |
| SUPPORT NARROWED | rule | 0.14 | 0.06 | 11.0 |
| CANNON PLANNED TARGET | rule | 0.11 | 0.06 | 146.3 |
| PATHS CROSS | rule | 0.11 | - | 4.0 |
| PURSUES BIG PREY | rule | 0.08 | 0.03 | 57.8 |
| RULE SWITCHED OFF | gate | 0.06 | 0.06 | 9.9 |
| BIG CHARACTER SAFETY | rule | 0.08 | - | 4.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | - | 21.8 |
| REDIRECT WEIGHED | rule | 0.06 | 0.03 | 123.0 |
| FIGHT ORDER BAND | gate | 0.06 | - | 1.4 |
| REFUSING RETIRES | rule | 0.06 | - | 0.7 |
| SAFE SURE CHARGE | rule | 0.06 | - | 22.0 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | - | 2.5 |
| SUPPORT REQUEST | gate | 0.06 | - | 157.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | - | 23.0 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 98.1 |
| CATCH ODDS | rule | 0.03 | - | 4.5 |
| CHARGE NOW WEIGHED | rule | 0.03 | - | 13.4 |
| FACES THE THREAT | rule | 0.03 | - | 7.2 |
| MARCH ODDS | rule | 0.03 | - | 3.3 |
| STANDS TO CAST | rule | - | 0.03 | 0.9 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 21.9 |

### Plans: fafix-opp-5e477c5-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.1 | 22% | 152 | 364 | 239% |
| Mine | charge | 3.1 | 65% | 191 | 272 | 142% |
| Mine | close in | 5.7 | 28% | 256 | 162 | 63% |
| Mine | hold | 6.0 | 36% | 349 | 0 | 0% |
| Mine | join | 0.6 | 100% | 9 | 0 | 0% |
| Mine | shoot | 10.6 | 59% | 341 | 889 | 261% |
| Mine | support | 5.4 | 93% | 52 | 0 | 0% |
| Opponent | charge | 1.7 | 56% | 186 | 144 | 77% |
| Opponent | join | 0.6 | 91% | 30 | 0 | 0% |
| Opponent | move | 34.6 | 91% | 1012 | 0 | 0% |
| Opponent | shoot | 1.8 | 61% | 76 | 88 | 115% |
| Opponent | support | 0.9 | 79% | 3 | 0 | 0% |

### Packages: hunt the guns, fafix-opp-5e477c5-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 286 | 0 | 0% | 21 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 487 | 0 | 0% | 152 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 84 | 0 | 0% | 75 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 182 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 136 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 59 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: fafix-opp-5e477c5-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.6 | 27% | 76% | 12% | 33% | 0% | 0% | 18% | 77% | 5% |
| Opponent | REDIRECT COUNTER | 5.5 | 21% | 71% | 5% | 50% | 12% | 0% | 10% | 75% | 2% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fafix-opp-5e477c5-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 38 | 75% | 4.0 | - | 0 (4) | - | - | 0 (4) |
| Mine | Chaff | 34 | 32 (34) | 11 | 22 | 49 | 38% | 2.4 | 19 (14) | 9 (7) | 56 (13) | 36 (22) | 26 (12) |
| Mine | Character | 106 | 39 (106) | 39 | 0 | 19 | 18% | 2.5 | 29 (35) | 51 (56) | 0 (7) | 46 (47) | 36 (51) |
| Mine | Clean-up | 22 | 84 (22) | 40 | 44 | 35 | 32% | 4.0 | 0 (2) | 81 (16) | 135 (4) | 71 (10) | 91 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 110 (4) | 110 | 0 | 46 | 50% | 3.0 | 0 (2) | 220 (2) | - | 0 (3) | 409 (1) |
| Mine | Fast Hammer | 41 | 52 (41) | 38 | 14 | 17 | 32% | 3.0 | 36 (27) | 109 (9) | 33 (5) | 56 (25) | 45 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 2.7 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 65 | 37 (65) | 24 | 13 | 35 | 20% | 2.7 | 34 (13) | 38 (45) | 32 (7) | 36 (40) | 38 (25) |
| Mine | Holder | 31 | 147 (31) | 26 | 121 | 16 | 42% | 3.1 | 65 (8) | 283 (15) | 17 (8) | 253 (18) | 28 (13) |
| Mine | Shooter | 34 | 80 (34) | 38 | 42 | 10 | 3% | 1.8 | 12 (8) | 125 (21) | 5 (5) | 74 (25) | 99 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 38 (56) | 38 | 0 | 43 | 5% | 1.5 | 34 (16) | 42 (30) | 36 (10) | 11 (9) | 43 (47) |
| Mine | Wizard | 17 | 15 (17) | 15 | 0 | 46 | 6% | 2.0 | 49 (5) | 8 (7) | 0 (1) | 44 (7) | 0 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 75 | 32 (75) | 10 | 22 | 54 | 47% | 3.2 | 32 (31) | 48 (17) | 19 (27) | 32 (56) | 29 (19) |
| Opponent | Character | 97 | 39 (97) | 38 | 1 | 28 | 33% | 2.3 | 39 (45) | 40 (38) | 34 (6) | 31 (50) | 49 (39) |
| Opponent | Clean-up | 11 | 22 (11) | 0 | 22 | 31 | 45% | 3.7 | 0 (3) | 30 (6) | 8 (2) | 0 (6) | 34 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 27 (60) | 13 | 14 | 43 | 42% | 3.4 | 24 (26) | 21 (25) | 59 (9) | 14 (39) | 49 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 68 | 18% | 2.4 | 0 (4) | 0 (8) | 0 (4) | 0 (13) | 0 (3) |
| Opponent | Hammer | 65 | 20 (65) | 12 | 8 | 40 | 45% | 3.3 | 12 (20) | 21 (38) | 40 (7) | 25 (41) | 12 (24) |
| Opponent | Holder | 29 | 9 (29) | 0 | 9 | 39 | 59% | 3.7 | 0 (8) | 16 (13) | 5 (7) | 17 (13) | 3 (15) |
| Opponent | Shooter | 33 | 74 (33) | 32 | 43 | 46 | 0% | 1.5 | 38 (9) | 90 (21) | 78 (3) | 96 (18) | 51 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 67 | 33% | 3.8 | 0 (4) | 0 (1) | - | 0 (3) | 0 (2) |
| Opponent | War machine | 6 | 117 (6) | 117 | 0 | 40 | 17% | 1.0 | 91 (3) | 155 (3) | - | 91 (3) | 155 (3) |
| Opponent | Wizard | 19 | 2 (19) | 2 | 0 | 21 | 11% | 2.6 | 4 (11) | 0 (2) | 0 (2) | 4 (10) | 0 (5) |

### Charged fights: fafix-opp-5e477c5-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 217 | 128 | 1.5 | 1.3 | 85 | 0 | +85 | 0 of 6 | 6 of 6 | +96 | +80 |
| Mine | Chaos Dwarfs | 4 | 198 | 165 | 2.2 | 1.4 | 73 | 38 | +36 | 2 of 9 | 8 of 9 | +162 | -1 |
| Mine | Dwarfen Mountain Holds | 3 | 876 | 20 | 1.0 | 1.0 | 20 | 0 | +20 | 2 of 3 | 2 of 3 | - | +20 |
| Mine | Empire of Man | 5 | 236 | 137 | 2.0 | 1.2 | 68 | 32 | +37 | 2 of 10 | 6 of 10 | +60 | +31 |
| Mine | Grand Cathay | 4 | 518 | 171 | 2.8 | 1.1 | 62 | 34 | +28 | 1 of 11 | 11 of 11 | -379 | +68 |
| Mine | High Elf Realms | 4 | 340 | 254 | 2.5 | 1.4 | 102 | 0 | +102 | 0 of 10 | 10 of 10 | +248 | +65 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1105 | 7.0 | 1.0 | 158 | 0 | +158 | 4 of 7 | 5 of 7 | - | +158 |
| Mine | Lizardmen | 1 | 0 | 365 | 4.0 | 1.2 | 91 | 82 | +10 | 2 of 4 | 3 of 4 | +0 | +13 |
| Mine | Ogre Kingdoms | 2 | 63 | 28 | 2.5 | 1.2 | 11 | 0 | +11 | 2 of 5 | 3 of 5 | +0 | +14 |
| Mine | Skaven | 2 | 60 | 130 | 2.5 | 1.2 | 52 | 9 | +43 | 2 of 5 | 4 of 5 | +150 | +16 |
| Mine | Tomb Kings of Khemri | 2 | 338 | 593 | 4.0 | 1.2 | 148 | 24 | +124 | 2 of 8 | 5 of 8 | +197 | +100 |
| Mine | Vampire Counts | 2 | 112 | 230 | 2.5 | 1.0 | 92 | 90 | +1 | 3 of 5 | 4 of 5 | - | +1 |
| Mine | Warriors of Chaos | 2 | 0 | 142 | 2.5 | 1.0 | 57 | 43 | +14 | 2 of 5 | 3 of 5 | - | +14 |
| **Mine** | all armies | 36 | 279 | 204 | 2.4 | 1.2 | 83 | 26 | +58 | 24 of 88 | 70 of 88 | +93 | +51 |
| Opponent | Empire of Man | 1 | 575 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 245 | 453 | 2.2 | 1.2 | 206 | 104 | +102 | 7 of 11 | 6 of 11 | -222 | +174 |
| Opponent | Lizardmen | 2 | 82 | 211 | 2.0 | 1.0 | 106 | 35 | +70 | 3 of 4 | 3 of 4 | - | +70 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 776 | 3.7 | 1.1 | 212 | 5 | +207 | 2 of 11 | 10 of 11 | +83 | +219 |
| Opponent | Skaven | 4 | 16 | 52 | 1.0 | 1.0 | 52 | 128 | -76 | 2 of 4 | 2 of 4 | - | -76 |
| Opponent | Tomb Kings of Khemri | 2 | 105 | 358 | 2.0 | 1.0 | 179 | 0 | +179 | 1 of 4 | 3 of 4 | - | +179 |
| Opponent | Vampire Counts | 6 | 21 | 110 | 2.3 | 1.3 | 47 | 34 | +13 | 7 of 14 | 8 of 14 | +12 | +13 |
| Opponent | Warriors of Chaos | 7 | 0 | 280 | 1.7 | 1.0 | 163 | 36 | +127 | 7 of 12 | 7 of 12 | - | +127 |
| Opponent | Wood Elf Realms | 6 | 51 | 282 | 2.5 | 1.1 | 113 | 7 | +106 | 4 of 15 | 12 of 15 | +110 | +105 |
| **Opponent** | all armies | 36 | 74 | 285 | 2.1 | 1.1 | 137 | 38 | +98 | 33 of 75 | 51 of 75 | -25 | +113 |

### Effective charges: fafix-opp-5e477c5-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 0 | 0 | 0 | 4 (net +97) | 2 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 9 | 0 | 1 (net -339) | 1 (net +0) | 0 | 2 (net +162) | 4 (net +44) | 1 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 1 (net +60) | 0 | 33% (1 of 3) |
| Mine | Empire of Man | 10 | 1 (net -36) | 0 | 2 (net +0) | 2 (net +55) | 1 (net +60) | 3 (net +40) | 1 | 22% (2 of 9) |
| Mine | Grand Cathay | 11 | 0 | 0 | 1 (net -379) | 6 (net +72) | 1 (net +60) | 3 (net +63) | 0 | 9% (1 of 11) |
| Mine | High Elf Realms | 10 | 0 | 0 | 2 (net +33) | 3 (net +165) | 2 (net +60) | 2 (net +132) | 1 | 22% (2 of 9) |
| Mine | Kingdom of Bretonnia | 7 | 1 (net +0) | 0 | 0 | 3 (net +277) | 1 (net +65) | 1 (net +210) | 1 | 0% (0 of 6) |
| Mine | Lizardmen | 4 | 1 (net -185) | 0 | 1 (net +0) | 2 (net +112) | 0 | 0 | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 1 (net +55) | 0 | 2 (net +0) | 2 | 0% (0 of 3) |
| Mine | Skaven | 5 | 0 | 0 | 1 (net +66) | 1 (net +0) | 2 (net +0) | 1 (net +150) | 0 | 20% (1 of 5) |
| Mine | Tomb Kings of Khemri | 8 | 2 (net +77) | 0 | 1 (net +170) | 1 (net +75) | 3 (net +149) | 1 (net +144) | 0 | 12% (1 of 8) |
| Mine | Vampire Counts | 5 | 0 | 0 | 1 (net -452) | 1 (net +190) | 1 (net +160) | 0 | 2 | 33% (1 of 3) |
| Mine | Warriors of Chaos | 5 | 0 | 0 | 2 (net -61) | 1 (net +285) | 0 | 1 (net -63) | 1 | 50% (2 of 4) |
| Opponent | High Elf Realms | 11 | 2 (net -294) | 2 (net +768) | 1 (net -302) | 2 (net -29) | 1 (net +140) | 1 (net +310) | 2 | 11% (1 of 9) |
| Opponent | Lizardmen | 4 | 1 (net +0) | 0 | 0 | 1 (net +310) | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 11 | 0 | 0 | 0 | 2 (net +204) | 2 (net +78) | 2 (net +62) | 5 | 0% (0 of 6) |
| Opponent | Skaven | 4 | 1 (net -112) | 0 | 0 | 0 | 0 | 2 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 4 | 1 (net +350) | 0 | 0 | 0 | 0 | 2 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 14 | 3 (net +56) | 0 | 2 (net +62) | 3 (net +42) | 2 (net +74) | 3 (net +17) | 1 | 15% (2 of 13) |
| Opponent | Warriors of Chaos | 12 | 3 (net +296) | 2 (net +155) | 0 | 4 (net +112) | 0 | 0 | 3 | 0% (0 of 9) |
| Opponent | Wood Elf Realms | 15 | 1 (net +0) | 2 (net -54) | 1 (net +0) | 5 (net +171) | 0 | 4 (net +143) | 2 | 8% (1 of 13) |

### Charged fights, damage counted: fafix-opp-5e477c5-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 213 | 286 | -11 | 119 | 69 | +50 | +23.3 |
| Mine | 50-54% | 1 | 339 | 399 | -339 | 114 | 339 | -225 | -66.4 |
| Mine | Effective (55-75%) | 13 | 262 | 215 | -50 | 50 | 95 | -45 | -17.3 |
| Mine | 76-89% | 21 | 312 | 182 | +128 | 145 | 17 | +129 | +41.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 203 | 141 | +71 | 113 | 27 | +86 | +42.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 483 | 83 | +95 | 102 | 8 | +94 | +19.4 |
| Mine | No odds | 11 | 367 | 122 | +50 | 66 | 24 | +42 | +11.4 |
| Mine | All fights | 88 | 302 | 164 | +58 | 104 | 38 | +66 | +22.0 |
| Opponent | Long shot (under 50%) | 12 | 260 | 305 | +59 | 148 | 128 | +19 | +7.5 |
| Opponent | 50-54% | 6 | 398 | 354 | +289 | 341 | 52 | +289 | +72.5 |
| Opponent | Effective (55-75%) | 4 | 219 | 219 | -45 | 117 | 167 | -50 | -22.9 |
| Opponent | 76-89% | 17 | 356 | 170 | +123 | 161 | 32 | +129 | +36.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 257 | 161 | +76 | 98 | 23 | +75 | +29.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 464 | 87 | +88 | 92 | 0 | +92 | +19.8 |
| Opponent | No odds | 17 | 304 | 214 | +90 | 148 | 84 | +64 | +20.9 |
| Opponent | All fights | 75 | 314 | 212 | +98 | 152 | 64 | +87 | +27.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fafix-opp-5e477c5-p4 | move | 421 | 67 (16%) | 46 (11%) | 37 (9%) | 317 (75%) |
| fafix-opp-5e477c5-p4 | objective | 206 | 30 (15%) | 19 (9%) | 19 (9%) | 157 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

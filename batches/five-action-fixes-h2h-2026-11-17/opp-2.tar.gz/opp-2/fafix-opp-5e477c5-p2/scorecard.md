# Doctrine scorecard: fafix-opp-5e477c5-p2

### Scorecard: fafix-opp-5e477c5-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 1 | 0 | 0 | 761 |
| L0122 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 5 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 418 |
| L0222 | 6 | 1 | Mine | no | 3 | 4 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 10 | 4 | 3 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 5 | 1 | 1 | 0 | 0 | 0 | 295 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 4 | 3 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 2 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 3 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 170 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 715 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 0 | 0 | 0 | 0 | 165 |
| L0528 | 6 | 1 | Mine | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 2 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 1 | 5 | 2 | 1 | 0 | 0 | 0 | 1176 |
| L0616 | 4 | 1 | Opponent | no | 2 | - | 0 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 826 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 433 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 1 | 3 | 0 | 0 | 0 | 367 |
| L0810 | 6 | 1 | Mine | no | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 769 |
| L0810 | 6 | 1 | Opponent | no | 7 | 2 | 1 | 1 | 1 | 0 | 0 | 165 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 762 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 2 | 7 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 11 | 3 | 5 | 1 | 0 | 0 | 0 | 604 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1033 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 3 | 0 | 0 | 0 | 56 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 4 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 2 | 1 | 0 | 0 | 0 | 185 |
| L1135 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1135 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1228 | 4 | 1 | Mine | no | 2 | 5 | 0 | 1 | 0 | 0 | 0 | 858 |
| L1228 | 4 | 1 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 3 | 0 | 0 | 616 |
| L1435 | 1 | 1 | Mine | no | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 4 | - | 1 | 2 | 2 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 90 |
| L1827 | 3 | 1 | Opponent | no | 10 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 4 | 5 | 1 | 1 | 1 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 1 | 4 | 4 | 0 | 0 | 0 | 0 | 115 |
| L2131 | 1 | 1 | Mine | yes | 0 | - | 0 | 4 | 1 | 0 | 0 | 500 |
| L2131 | 1 | 1 | Opponent | no | 2 | 2 | 0 | 2 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | no | 10 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 274 |
| L2429 | 5 | 1 | Mine | no | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 4 | 3 | 3 | 0 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 1 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | yes | 1 | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 9 | 4 | 5 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | yes | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 24% | 2.8 | 2.9 | 2.0 | 1.5 | 0.1 | 0.0 | 0.0 | 315.1 |
| **Average** | | | Opponent | 31% | 2.2 | 2.8 | 2.1 | 2.0 | 0.4 | 0.0 | 0.0 | 159.3 |

### KPIs: fafix-opp-5e477c5-p2

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE; both sides: LIKELY CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (50 of 167) | 13% (24 of 178) | 21% (74 of 345) |
| Winner chose to follow up after the loser gave ground |  | 98% (52 of 53); on the table 98% | 100% (39 of 39); on the table 100% | 99% (91 of 92); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 60% (3 of 5); on the table 80% | 60% (3 of 5); on the table 80% | 60% (6 of 10); on the table 80% |
| Winner chose to pursue after the loser fled |  | 81% (17 of 21); on the table 81% | 72% (18 of 25); on the table 80% | 76% (35 of 46); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 91% (72 of 79); on the table 92% | 87% (60 of 69); on the table 91% | 89% (132 of 148); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 39% (131 of 332) | 35% (55 of 155) | 38% (186 of 487) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (131 of 273) | 45% (55 of 122) | 47% (186 of 395) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 70% (23 of 33) | 56% (28 of 50) | 61% (51 of 83) |
| Points that never fought | lower | 46% (32300 of 69584) | 49% (34606 of 69989) | 48% (66906 of 139573) |
|   infantry points that never fought | lower | 59% (9449 of 16056) | 60% (8014 of 13404) | 59% (17463 of 29460) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (156 of 276) | 64% (181 of 285) | 60% (337 of 561) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.8 uses a game | 72% (13 of 18); 1.2 uses a game | 84% (32 of 38); 1.5 uses a game |
| Bound items with another spell used |  | 44% (8 of 18); 0.6 uses a game | 0% (0 of 2); 0.0 uses a game | 40% (8 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (30992 of 58424) | 60% (36726 of 61281) | 57% (67718 of 119705) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (35%) | 1.1 (40%) | 3.1 (37%) |
| MARCHED: its unit marched | 1.1 (20%) | 0.4 (16%) | 1.6 (19%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.1 (2%) | 0.4 (5%) |
| IN COMBAT: engaged in combat | 0.8 (14%) | 0.1 (5%) | 0.9 (11%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.1 (3%) | 0.3 (3%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| GONE: slain | 0.7 (13%) | 0.6 (22%) | 1.3 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (5%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (2%) | 0.1 (2%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (4%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.5 | 1.3 | 5.2 | 0.3 | 1.5 |
| not cast | 3.6 | 3.4 | 3.6 | 8.4 | 1.9 | 20.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.9 (56%) | 0.2 (7%) | 3.1 (37%) | 0.6 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (19%) | 0.3 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.2 (7%) | 0.1 (4%) | 0.9 (11%) | 0.1 (6%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (7%) | 0.4 (11%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.3 (8%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.5 (2%) |
| GONE: slain | 0.9 (25%) | 0.2 (6%) | 0.7 (18%) | 1.3 (16%) | 0.4 (20%) | 3.3 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.2 (5%) | 0.1 (2%) | 0.2 (3%) | 0.0 (0%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (5%) | 0.0 (1%) | 0.1 (2%) | 0.4 (23%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (58%) | 0.2 (6%) | 1.8 (49%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.6 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.8 a game | 0.8 a game |
| stood (cast and not dispelled) | 62% (16 of 26) | 67% (20 of 30) | 64% (36 of 56) |
| the unit moved after it | 62% (10 of 16) | 40% (8 of 20) | 50% (18 of 36) |
| it charged on its next turn | 6% (1 of 16) | 0% (0 of 20) | 3% (1 of 36) |
| the enemy charged it first | 12% (2 of 16) | 10% (2 of 20) | 11% (4 of 36) |
| it fought by the end of its next turn | 0% (0 of 16) | 10% (2 of 20) | 6% (2 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 31% (5 of 16) | 10% (2 of 20) | 19% (7 of 36) |
| none of these (no charge, no fight, no charge escaped) | 50% (8 of 16) | 80% (16 of 20) | 67% (24 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (582 of 894) | 59% (445 of 752) | 62% (1027 of 1646) |
|   cavalry | 64% (56 of 88) | 68% (99 of 146) | 66% (155 of 234) |
|   character | 66% (67 of 101) | 39% (42 of 109) | 52% (109 of 210) |
|   chariot | 50% (55 of 109) | 61% (27 of 44) | 54% (82 of 153) |
|   infantry | 56% (150 of 268) | 58% (171 of 294) | 57% (321 of 562) |
|   monster | 48% (23 of 48) | 57% (16 of 28) | 51% (39 of 76) |
|   war machine | 82% (231 of 280) | 69% (90 of 131) | 78% (321 of 411) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (28%) | 2.2 (26%) | 4.6 (27%) |
| CHARGED: it charged | 0.7 (8%) | 1.2 (15%) | 2.0 (11%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.5 (6%) | 1.1 (6%) |
| MOVED: a war machine that moved | 0.1 (2%) | 0.1 (2%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.6 (18%) | 1.8 (21%) | 3.4 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.3 (4%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (23%) | 1.5 (18%) | 3.5 (20%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (3%) | 0.5 (3%) |
| OTHER BAR | 0.3 (4%) | 0.4 (5%) | 0.8 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.5 | 1.8 | 79% | 6.4 pts | 42 pts |
| character | 3.2 | 1.0 | 77% | 7.9 pts | 25 pts |
| chariot | 2.3 | 1.4 | 70% | 12.6 pts | 29 pts |
| infantry | 12.1 | 5.9 | 66% | 10.8 pts | 130 pts |
| monster | 1.5 | 0.4 | 79% | 5.3 pts | 8 pts |
| war machine | 8.9 | 7.5 | 63% | 28.8 pts | 257 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 3.6 | 3.6 |
| Charges that made contact a game | 2.4 | 2.5 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.54 declared, 0.29 contact (24 units) | 0.21 declared, 0.14 contact (14 units) | 0.42 declared, 0.24 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.43 declared, 0.43 contact (7 units) | 0.80 declared, 0.73 contact (15 units) | 0.68 declared, 0.64 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.32 contact (245 units) | 0.38 declared, 0.26 contact (300 units) | 0.41 declared, 0.28 contact (545 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (44 of 70) | 61% (11 of 18) | 55% (6 of 11) | 62% (61 of 99) |
| Character in a unit | 89% (33 of 37) | 53% (9 of 17) | 75% (3 of 4) | 78% (45 of 58) |
| Character on its own | 71% (24 of 34) | 51% (18 of 35) | 38% (23 of 60) | 50% (65 of 129) |
| Chariot | 62% (10 of 16) | 77% (10 of 13) | - | 69% (20 of 29) |
| Infantry | 55% (48 of 88) | 65% (22 of 34) | 33% (1 of 3) | 57% (71 of 125) |
| Monster | 66% (19 of 29) | 89% (8 of 9) | - | 71% (27 of 38) |
| Monstrous | 50% (6 of 12) | 64% (9 of 14) | - | 58% (15 of 26) |
| War Machines | 60% (33 of 55) | 0% (0 of 2) | - | 58% (33 of 57) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (5 of 5); on the table 100% | 40% (41 of 102) | 28% | 59% (13 of 22) | 100% (6 of 6); 5.0 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 75% (6 of 8); on the table 75% | 47% (17 of 36) | 70% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (4 of 4); on the table 100% | - | 71% | 74% (40 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 43% (3 of 7); on the table 57% | 35% (17 of 48) | 52% | 57% (43 of 76) | 0.0 uses a game | 50% (1 of 2); 0.4 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 5 | 100% (9 of 9); on the table 100% | 43% (46 of 108) | 64% | 39% (18 of 46) | 92% (11 of 12); 8.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |
| High Elf Realms | 4 | 100% (18 of 18); on the table 100% | 11% (2 of 18) | 41% | 55% (18 of 33) | 100% (3 of 3); 3.8 uses a game | 36% (5 of 14); 2.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (4 of 4); on the table 100% | - | 60% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (8 of 8); on the table 100% | - | 39% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (4 of 4); on the table 100% | 0% (0 of 18) | 37% | 75% (21 of 28) | 75% (3 of 4); 1.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 33% (4 of 12) | 0% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 78% (7 of 9); on the table 89% | 44% (8 of 18) | 38% | 52% (13 of 25) | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 75% (3 of 4); on the table 75% | - | 49% | 48% (12 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 83% (25 of 30); on the table 87% | 42% (28 of 66) | 40% | 72% (39 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 95% (21 of 22); on the table 100% | 33% (6 of 18) | 44% | 62% (45 of 73) | 100% (2 of 2); 1.1 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 6 | 93% (14 of 15); on the table 93% | 22% (4 of 18) | 44% | 64% (42 of 66) | 67% (4 of 6); 1.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fafix-opp-5e477c5-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (27) | 60% (33) | 50% (60) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.61 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.17 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.42 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.72 | 0.03 | 1.75 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.11 | 0.03 | 1.14 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.64 | 0.08 | 6.72 |

### Quality by phase: fafix-opp-5e477c5-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 47% (54 of 115) | 49% (59 of 121) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (154 of 406) | 50% (98 of 195) |
| Strategy | Close-in objectives charged next turn | 17% (30 of 181) | - |
| Strategy | Support requests answered (helper made contact too) | 57% (4 of 7) | 33% (6 of 18) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 38% (3 of 8) | 54% (7 of 13) |
| Strategy | Joined characters whose unit fought | 45% (25 of 55) | 42% (16 of 38) |
| Strategy | Lone characters that fought | 65% (56 of 86) | 60% (50 of 83) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.5 | 2.0 |
| Movement | Points that never moved of their own | 315.1 | 159.3 |
| Movement | Fights charged into per game | 2.3 | 2.4 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 70, net +136 | 13 of 72, net +106 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 70, net +170 | 17 of 72, net +111 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 70, net +169 | 3 of 72, net +62 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 of 70, net +80 | 15 of 72, net +146 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.5 | 10.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (138 of 379) | 45% (175 of 392) |
| Shooting | Points destroyed by shooting units | 117.4 | 37.8 |
| Shooting | War machine shots | 6.4 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (123 of 231) | 48% (43 of 90) |
| Shooting | Points destroyed by war machines | 115.5 | 55.8 |
| Magic | Magic missiles cast | 2.1 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (26 of 74) | 50% (21 of 42) |
| Magic | Wounds caused by magic missiles | 3.9 | 1.3 |
| Magic | Wounds caused by other spells | 1.3 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 57.1 | 22.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.4 / 0.5 / 0.1 | 1.9 / 0.4 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 224.7 | 249.3 |
| Combat | Points run down | 58.5 | 93.0 |
| Combat | Net points per charged fight, damage counted | +80 | +99 |
| Combat | Net per 100 charger points, damage counted | +30.7 | +37.9 |
| Combat | First round won (charged fights) | 84% | 58% |
| Combat | Net points per charged fight | +79 | +101 |
| Combat | Net points per supported fight / lone fight | +46 / +82 | +159 / +97 |
| Combat | Charged fights on a top-3 enemy unit | 29 of 80 | 35 of 84 |
| Game | Points lost | 578.8 | 732.9 |
| Game | VP from objectives | 595.7 | 519.4 |
| Game | Lone holders (player turns) | 2.8 | 2.2 |

- Mine won / drew / lost: 16 / 7 / 12 of 35 ended games (of 36); mean margin (Mine - Opponent) +239 VP
- The side that went first won 15 of 28 games with a winner
- Points traded per game (both sides' losses): 1312
- Games not ended: 1 (L1135-1); findings 2, warnings 1

### Opponent rules: fafix-opp-5e477c5-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.2 | -181.1 | 148.6 | 86.7 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.1 | +10.9 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 5.7 | 0.2 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.6 | +2.3 | 0.0 | 18.5 | 0.6 | +3.6 | 0.0 | 7.1 |
| BEST FACING | 0.4 | +20.8 | 0.0 | 46.7 | - | - | - | - |
| BEST FIRST | 1.2 | +63.4 | 14.3 | 8.2 | - | - | - | - |
| BEST OVERALL | 0.4 | +15.0 | 0.0 | 13.1 | - | - | - | - |
| BEST PREY | 0.9 | +53.0 | 17.2 | 4.7 | - | - | - | - |
| BEST PRIZE | 0.1 | -4.4 | 6.4 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.2 | -0.8 | 0.0 | 9.4 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 15.9 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.3 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | -12.9 | 38.4 | 0.0 | 0.2 | -34.4 | 30.8 | 5.4 |
| BOMBING RUN | 0.1 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 143.3 | 3.1 | 0.2 | +0.0 | 4.1 | 0.0 |
| CANNON PLANNED TARGET | 4.9 | +208.1 | 423.2 | 73.2 | 2.0 | +130.6 | 196.1 | 20.6 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.8 | 0.6 | +0.0 | 0.0 | 4.6 |
| CARRIES OUT COUNTER | 0.1 | -1.5 | 11.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 6.8 | 0.0 | 0.2 | -14.1 | 17.9 | 0.0 |
| CAST JOB | 0.8 | +21.1 | 51.2 | 15.3 | 0.4 | +6.5 | 46.3 | 20.2 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +29.8 | 36.2 | 0.0 | 0.1 | +4.4 | 0.0 | 8.2 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 49.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.9 | +47.0 | 0.0 | 26.1 | 0.9 | +38.2 | 0.0 | 3.1 |
| CHAFF PASSED | 0.3 | -0.6 | 20.2 | 0.0 | 0.5 | -0.7 | 0.0 | 12.0 |
| CHARACTER GUNS | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 8.9 | -464.7 | 0.0 | 338.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 220.9 | 35.2 | 1.6 | +0.0 | 157.3 | 64.8 |
| CHARGE NOW WEIGHED | 0.5 | -15.7 | 0.0 | 7.1 | - | - | - | - |
| CHARGER SLAIN LOST | 0.5 | -5.7 | 62.0 | 8.6 | 0.2 | -23.8 | 11.3 | 2.9 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.0 | +0.0 | 1.2 | 0.0 | 0.1 | +0.0 | 11.7 | 0.9 |
| COMBAT PIVOT | 0.4 | +0.0 | 4.0 | 22.2 | 0.3 | +0.0 | 16.1 | 0.0 |
| CONVEYANCE SEARCH | 0.4 | +44.3 | 0.0 | 0.0 | 0.7 | +54.5 | 27.0 | 37.8 |
| COVER ONCE | 10.8 | -719.6 | 0.0 | 143.6 | 5.7 | -356.0 | 0.0 | 151.4 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +4.2 | 10.1 | 0.0 | 0.2 | +1.2 | 11.2 | 0.9 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +94.1 | 0.0 | 79.5 | 0.0 | +1.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 2.6 | +9.6 | 235.3 | 79.3 |
| FALLBACK BY WORTH | 4.6 | +42.7 | 0.0 | 24.9 | 0.3 | +0.1 | 0.0 | 1.5 |
| FALLS SHORT | - | - | - | - | 0.3 | -2.6 | 0.0 | 14.6 |
| FEATURE BUFFS | - | - | - | - | 0.8 | +16.3 | 0.0 | 4.3 |
| FIGHT LIFT | 0.1 | +1.7 | 14.9 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.5 | 0.0 | 4.7 |
| FIVE ACTION | - | - | - | - | 47.0 | +1884.2 | 711.4 | 849.8 |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 78.5 | 4.7 | +0.0 | 0.0 | 143.0 |
| FOCUS FIRE | 0.0 | +1.4 | 0.0 | 0.0 | 0.0 | +0.1 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +148.4 | 0.0 | 49.4 | 0.8 | +98.4 | 0.0 | 10.3 |
| FOUR ROUNDS | - | - | - | - | 3.3 | +243.8 | 307.3 | 97.6 |
| FRIENDS SHOTS CHECKED | 0.1 | +4.5 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.6 | 6.4 | 0.0 | 0.1 | -2.3 | 12.4 | 14.2 |
| GROUND FLIERS | 0.0 | +0.7 | 0.0 | 7.5 | - | - | - | - |
| GUN MASK | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 11.5 | 0.0 | 0.2 | +0.0 | 0.0 | 5.4 |
| HILL BY ITS CHANCE | 0.3 | -31.9 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.8 | -120.0 | 330.9 | 177.2 | 2.6 | -112.2 | 276.9 | 79.3 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 3.2 | 0.1 | +0.0 | 0.0 | 1.9 |
| HUNT IN PAIRS | 0.3 | +32.6 | 0.0 | 0.0 | 0.7 | +44.5 | 0.0 | 27.6 |
| HUNT KEPT | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 3.2 | 0.1 | +11.9 | 3.5 | 2.8 |
| HUNT THE GUNS | 0.0 | +6.5 | 0.0 | 0.0 | 0.1 | +49.2 | 3.5 | 0.9 |
| IDLE COST | 15.9 | -267.7 | 0.0 | 143.3 | 19.9 | -307.3 | 0.0 | 325.6 |
| INVITES THE FIGHT | 1.4 | +7.5 | 58.1 | 38.1 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +6.4 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -1.3 | 8.2 | 0.0 |
| KEEP FALLS | 0.1 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.3 | 4.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 2.1 | +61.7 | 143.2 | 69.3 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.4 | +58.6 | 128.5 | 24.0 | - | - | - | - |
| KILLS COUNT NEXT TURN | 5.3 | +185.4 | 142.1 | 127.4 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.1 | +10.3 | 0.0 | 0.0 | 0.2 | +5.7 | 0.0 | 1.7 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -1.6 | 31.1 | 3.1 | 0.5 | -1.3 | 30.6 | 7.7 |
| LOST CHARGE | 2.5 | -33.5 | 60.9 | 54.9 | 0.1 | -0.4 | 15.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -19.6 | 0.0 | 0.0 | 0.1 | -5.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +24.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 3.3 |
| MANOEUVRE | 0.2 | +4.6 | 0.0 | 2.1 | 0.9 | +24.7 | 0.0 | 27.7 |
| MARCH AT ESCAPER | 0.1 | +0.1 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +8.1 | 0.0 | 12.4 | 0.7 | +25.2 | 0.0 | 3.2 |
| MARCH ODDS | 0.1 | +11.5 | 1.7 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.4 | +33.5 | 0.0 | 11.1 | 0.5 | +70.8 | 0.0 | 38.9 |
| MAX FOR POSITIONING | 6.9 | +100.6 | 0.0 | 108.1 | 7.2 | +93.7 | 0.0 | 217.2 |
| MISSILES IN THE MOVE | 4.2 | +103.1 | 0.0 | 86.7 | 3.6 | +58.0 | 0.0 | 124.0 |
| MISSILES NEXT TURN | 5.1 | +78.8 | 0.0 | 120.4 | 3.8 | +44.5 | 0.0 | 139.2 |
| MODEL FACING | 0.5 | +118.4 | 0.0 | 1.7 | 0.4 | +113.6 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 15.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.4 | +29.6 | 0.0 | 2.2 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.2 | +10.1 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -7.9 | 0.0 | 0.0 | 0.2 | -2.8 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 24.1 |
| MOVE TO CHARGE | 3.4 | +163.9 | 115.1 | 112.2 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.0 | +2.7 | 4.1 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 16.6 | -306.0 | 78.9 | 421.5 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 4.0 | -315.9 | 67.6 | 27.6 |
| NO DOUBLE ROUNDS | - | - | - | - | 2.4 | -96.7 | 211.9 | 80.3 |
| NO RALLY LEFT | 0.1 | +1.8 | 0.0 | 2.6 | - | - | - | - |
| NOT NEEDED | 0.2 | -6.9 | 19.8 | 2.5 | - | - | - | - |
| NOT TURNED | 6.6 | +95.9 | 0.0 | 89.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 0.0 | 0.6 | -0.4 | 0.0 | 7.6 |
| OFF BEST | 17.2 | -680.0 | 8.2 | 232.2 | 1.6 | -67.1 | 0.0 | 39.9 |
| ONE FIGHT FORMULA | 10.3 | -147.9 | 50.3 | 236.5 | 8.2 | -181.5 | 0.0 | 334.9 |
| ONE OBJECTIVE FORMULA | 2.6 | -126.7 | 0.0 | 25.1 | 3.1 | -39.0 | 0.0 | 36.7 |
| OPENS A LANE | 0.1 | +0.1 | 3.1 | 1.7 | 0.1 | +0.2 | 3.4 | 9.6 |
| OPENS UP | 0.2 | +13.7 | 9.8 | 0.0 | 0.3 | +30.3 | 19.1 | 0.0 |
| OVERRUNS AWAY | 0.6 | +15.5 | 42.5 | 6.7 | 0.6 | +18.9 | 45.3 | 38.1 |
| PATHS CROSS | 1.8 | +128.1 | 0.0 | 41.9 | 3.6 | +297.2 | 0.0 | 83.0 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 12.4 | 0.1 | -3.5 | 0.0 | 18.2 |
| PLAN RESULT | 38.5 | +1430.8 | 1494.2 | 756.5 | 42.6 | +551.1 | 352.1 | 1006.8 |
| PURSUES BIG PREY | 0.1 | -12.6 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +1.7 | 0.0 | 3.4 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.9 | +19.8 | 0.0 | 11.7 | 1.4 | +22.1 | 0.0 | 39.7 |
| RANDOM MOVER NO PROMISE | 0.2 | -6.2 | 8.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.5 | -7.4 | 0.0 | 23.6 | 0.1 | -6.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.7 | +177.9 | 0.0 | 49.9 | 4.3 | +343.7 | 0.0 | 85.2 |
| REDIRECT WEIGHED | 0.1 | +3.0 | 5.7 | 0.0 | 0.4 | +4.2 | 6.5 | 11.1 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 31.8 |
| RESERVE FALL BACK | 0.6 | +13.5 | 0.0 | 0.0 | 1.2 | +42.2 | 0.0 | 46.9 |
| RESTRAINS TO SHOOT | 0.2 | +8.8 | 0.0 | 3.8 | 0.0 | +1.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +84.8 | 200.8 | 36.0 | 2.2 | +27.9 | 190.2 | 94.1 |
| RISK ONCE | 4.4 | +150.7 | 14.9 | 115.0 | - | - | - | - |
| RUN DOWN | - | - | - | - | 2.2 | -20.7 | 207.1 | 56.6 |
| SAFE SURE CHARGE | 0.0 | -0.2 | 0.0 | 8.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.1 | +50.0 | 0.0 | 11.1 | 0.0 | +0.5 | 0.0 | 3.2 |
| SCALED CHANCE | - | - | - | - | 4.9 | +48.6 | 12.8 | 180.3 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.3 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.4 | -20.7 | 0.0 | 2.5 | 0.3 | -24.7 | 0.0 | 3.1 |
| SEARCH SPOT | 2.6 | +104.0 | 0.0 | 34.9 | 7.7 | +276.6 | 0.0 | 132.3 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.9 |
| SELF MOVE SPELL | 0.2 | -0.2 | 0.0 | 31.0 | - | - | - | - |
| SET UP TOGETHER | 0.6 | +37.6 | 0.0 | 9.4 | 0.3 | +4.6 | 0.0 | 3.3 |
| SET-UP ANY TARGET | 0.2 | +29.8 | 0.0 | 0.0 | 0.1 | +9.0 | 12.1 | 12.1 |
| SET-UP MISSED | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +53.1 | 86.3 | 13.9 | 0.3 | +6.2 | 22.0 | 5.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 1.1 | +0.0 | 199.0 | 17.1 | 0.6 | +0.0 | 103.7 | 3.8 |
| SHOTS IN THE MOVE | 15.2 | +666.0 | 0.0 | 204.9 | 13.1 | +444.6 | 0.0 | 184.3 |
| SPELL CATCH ODDS | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +38.0 | 0.0 | 0.0 | 0.1 | +9.0 | 12.1 | 12.1 |
| SPELL WORTH | 0.9 | +17.2 | 80.7 | 54.7 | 1.7 | +28.0 | 87.7 | 87.7 |
| SPELLS IN THE FIGHT | 0.7 | +1.9 | 95.7 | 7.6 | 0.5 | -6.9 | 56.3 | 13.8 |
| STABLE ROLE | 12.3 | +0.0 | 377.6 | 124.6 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.4 | -1.8 | 17.9 | 0.8 |
| STOPS | - | - | - | - | 0.1 | +5.3 | 3.5 | 0.9 |
| STOPS SHORT OF THE FLANK | 0.6 | +23.2 | 0.0 | 9.4 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 7.4 | -66.8 | 294.1 | 62.4 | 1.2 | +0.0 | 98.7 | 44.6 |
| SUPPORTS | 5.4 | +73.2 | 163.3 | 45.7 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.2 | -6.5 | 15.8 | 16.1 | - | - | - | - |
| SURE REACH TOGETHER | 0.3 | -0.1 | 0.0 | 16.1 | 0.6 | +9.5 | 0.0 | 16.9 |
| THROUGH LINE OF FIRE | 0.2 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 2.0 | +0.0 | 33.8 | 4.0 |
| TURN WORTH | 0.4 | -36.0 | 38.8 | 4.2 | 0.0 | -0.7 | 2.7 | 2.9 |
| TWO OR MORE ARRIVE | 0.3 | +3.7 | 0.0 | 9.4 | - | - | - | - |
| WAIT AFTER COSTS | 6.7 | -307.2 | 216.0 | 176.0 | - | - | - | - |
| WALKS TO THE FIGHT | 1.2 | +12.7 | 26.1 | 21.8 | - | - | - | - |
| WAR ENGINE CHARGES | 0.2 | +12.6 | 3.7 | 17.2 | 0.0 | +0.1 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 40.3 | 3.9 | 0.1 | +0.0 | 0.0 | 9.2 |
| WEARS DOWN | 0.9 | +26.1 | 85.4 | 13.2 | - | - | - | - |
| WHO HITS BACK | 0.2 | +10.5 | 0.0 | 19.3 | 0.2 | +28.5 | 0.0 | 21.4 |
| WHOLE FIGHT | 0.2 | +2.3 | 34.9 | 0.0 | 0.3 | +1.6 | 56.8 | 17.2 |
| WHOLE FIGHT GAIN | 0.2 | +9.8 | 15.3 | 1.2 | 0.4 | +16.2 | 19.9 | 9.2 |
| WIDER SPREAD | 2.4 | -9.7 | 220.1 | 29.5 | 2.5 | -7.8 | 213.7 | 35.3 |

### Rule changes: fafix-opp-5e477c5-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 676 | 676 | 676 | 18.78 | -26891 | -39.8 |
| SEARCH SPOT | 368 | 368 | 351 | 9.75 | +13730 | +39.1 |
| PATHS CROSS | 195 | 195 | 195 | 5.42 | +15311 | +78.5 |
| SHOTS IN THE MOVE | 1018 | 816 | 131 | 3.64 | +3971 | +30.3 |
| IDLE COST | 1290 | 835 | 114 | 3.17 | +1108 | +9.7 |
| COVER ONCE | 591 | 387 | 95 | 2.64 | +1729 | +18.2 |
| KILLS COUNT NEXT TURN | 191 | 191 | 83 | 2.31 | +2017 | +24.3 |
| CHARGE LOSSES | 322 | 322 | 78 | 2.17 | +5959 | +76.4 |
| FIVE ACTION | 1693 | 1691 | 77 | 2.14 | +3294 | +42.8 |
| MAX FOR POSITIONING | 510 | 401 | 75 | 2.08 | +275 | +3.7 |
| SUPPORTS | 196 | 196 | 72 | 2.00 | +785 | +10.9 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 70 | 70 | 70 | 1.94 | +8885 | +126.9 |
| ARTILLERY RE-ROLL WEIGHED | 64 | 64 | 64 | 1.78 | +0 | +0.0 |
| RESERVE FALL BACK | 64 | 64 | 64 | 1.78 | +2004 | +31.3 |
| FACES THE THREAT | 63 | 63 | 63 | 1.75 | +3426 | +54.4 |
| MOVE TO CHARGE | 122 | 122 | 61 | 1.69 | +1578 | +25.9 |
| MISSILES IN THE MOVE | 281 | 209 | 60 | 1.67 | +1065 | +17.8 |
| REDIRECT COUNTER | 253 | 183 | 60 | 1.67 | +3947 | +65.8 |
| SHOT REPLANNED | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 83 | 83 | 51 | 1.42 | +1509 | +29.6 |
| BEST FIRST | 45 | 45 | 45 | 1.25 | +2284 | +50.8 |
| FALLBACK BY WORTH | 175 | 175 | 45 | 1.25 | +1541 | +34.2 |
| NEXT CHARGE BY LIST | 599 | 599 | 45 | 1.25 | +315 | +7.0 |
| WAIT AFTER COSTS | 241 | 241 | 45 | 1.25 | +716 | +15.9 |
| ONE FIGHT FORMULA | 664 | 450 | 44 | 1.22 | +252 | +5.7 |
| MARCH CHECK | 45 | 45 | 43 | 1.19 | +932 | +21.7 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| ADVANCE WORTH | 189 | 189 | 41 | 1.14 | +498 | +12.2 |
| CHAFF IN THE MOVE | 65 | 61 | 41 | 1.14 | +1007 | +24.6 |
| SAFER THAN THE JOB | 41 | 41 | 41 | 1.14 | +1816 | +44.3 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| FOUR ROUNDS | 118 | 116 | 39 | 1.08 | +3349 | +85.9 |
| RISK BY ARC | 159 | 157 | 38 | 1.06 | +877 | +23.1 |
| CANNON PLANNED TARGET | 249 | 249 | 36 | 1.00 | -661 | -18.4 |
| SHOOTS FROM THE BEST SPOT | 66 | 66 | 35 | 0.97 | +689 | +19.7 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MODEL FACING | 30 | 30 | 30 | 0.83 | +8352 | +278.4 |
| CHAFF PASSED | 29 | 29 | 29 | 0.81 | -44 | -1.5 |
| CHARGE NOW FIRST | 137 | 137 | 26 | 0.72 | -1084 | -41.7 |
| MANOEUVRE | 39 | 39 | 26 | 0.72 | +1068 | +41.1 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| COMBAT PIVOT | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| RISK ONCE | 158 | 99 | 23 | 0.64 | +531 | +23.1 |
| CAST JOB | 43 | 43 | 21 | 0.58 | +342 | +16.3 |
| HONEST WORTH | 372 | 369 | 21 | 0.58 | +149 | +7.1 |
| SCALED CHANCE | 177 | 177 | 21 | 0.58 | +152 | +7.2 |
| STOPS SHORT OF THE FLANK | 21 | 21 | 21 | 0.58 | +836 | +39.8 |
| WALKS TO THE FIGHT | 42 | 42 | 21 | 0.58 | +184 | +8.8 |
| INVITES THE FIGHT | 52 | 52 | 19 | 0.53 | +101 | +5.3 |
| NEXT OBJECTIVE NEARER | 144 | 144 | 19 | 0.53 | +275 | +14.5 |
| BEST PREY | 33 | 33 | 18 | 0.50 | +732 | +40.7 |
| CHARGE NOW WEIGHED | 18 | 18 | 18 | 0.50 | +852 | +47.3 |
| HUNT IN PAIRS | 38 | 33 | 17 | 0.47 | +1457 | +85.7 |
| REDIRECT WEIGHED | 17 | 17 | 17 | 0.47 | +656 | +38.6 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| MOVE AND CAST | 16 | 16 | 16 | 0.44 | +1067 | +66.7 |
| BEST FACING | 15 | 15 | 15 | 0.42 | +749 | +50.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| BEST OVERALL | 14 | 14 | 14 | 0.39 | +539 | +38.5 |
| KEEPS ITS TARGET | 74 | 74 | 14 | 0.39 | +250 | +17.9 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +1040 | +74.3 |
| WHOLE FIGHT GAIN | 20 | 20 | 13 | 0.36 | +258 | +19.8 |
| SUPPORT NARROWED | 310 | 310 | 12 | 0.33 | -113 | -9.5 |
| WAR ENGINE JOBS | 29 | 29 | 12 | 0.33 | -339 | -28.3 |
| MISSILES NEXT TURN | 323 | 223 | 11 | 0.31 | +86 | +7.8 |
| SURE REACH TOGETHER | 33 | 30 | 11 | 0.31 | +52 | +4.7 |
| BLOCKED WHEEL | 10 | 10 | 10 | 0.28 | +143 | +14.3 |
| KILLS COUNT | 50 | 50 | 10 | 0.28 | +362 | +36.2 |
| OVERRUNS AWAY | 40 | 40 | 10 | 0.28 | +256 | +25.6 |
| CASTING BLOCK | 23 | 23 | 9 | 0.25 | +209 | +23.3 |
| OPENS UP | 19 | 19 | 9 | 0.25 | +438 | +48.7 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -188 | -20.9 |
| SET UP TOGETHER | 33 | 27 | 9 | 0.25 | +646 | +71.8 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 9 | 9 | 9 | 0.25 | +238 | +26.5 |
| BIG CHARACTER SAFETY | 8 | 8 | 8 | 0.22 | -30 | -3.7 |
| ONE OBJECTIVE FORMULA | 205 | 146 | 8 | 0.22 | +254 | +31.7 |
| REFUSING RETIRES | 21 | 21 | 7 | 0.19 | -2 | -0.3 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +374 | +53.5 |
| FALL BACK GOOD ORDER | 93 | 92 | 6 | 0.17 | +35 | +5.8 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.17 | +174 | +29.0 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.17 | -233 | -38.8 |
| MAKE SURE TOGETHER | 25 | 10 | 5 | 0.14 | +433 | +86.7 |
| WEARS DOWN | 33 | 33 | 5 | 0.14 | +112 | +22.4 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +302 | +75.4 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| SPELLS IN THE FIGHT | 41 | 39 | 4 | 0.11 | +6 | +1.6 |
| WHOLE FIGHT | 19 | 18 | 4 | 0.11 | +72 | +18.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.08 | +393 | +131.0 |
| FEATURE BUFFS | 27 | 27 | 3 | 0.08 | +34 | +11.2 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +18 | +5.9 |
| LOST CHARGE | 93 | 93 | 3 | 0.08 | +44 | +14.6 |
| MARCH ODDS | 3 | 3 | 3 | 0.08 | +106 | +35.5 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -454 | -151.4 |
| BACKUP TARGETS | 43 | 31 | 2 | 0.06 | +2 | +1.1 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -157 | -78.6 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +84 | +41.8 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 8 | 8 | 2 | 0.06 | -507 | -253.5 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +52 | +25.8 |
| LONG SHOT | 30 | 29 | 2 | 0.06 | +19 | +9.7 |
| NO DOUBLE ROUNDS | 85 | 83 | 2 | 0.06 | +11 | +5.5 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +16 | +8.1 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +176 | +88.0 |
| WAR ENGINE CHARGES | 9 | 9 | 2 | 0.06 | +255 | +127.5 |
| WIDER SPREAD | 178 | 174 | 2 | 0.06 | +22 | +10.8 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BLOWS WHERE AIMED | 17 | 15 | 1 | 0.03 | +90 | +89.7 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.03 | -55 | -54.8 |
| CHARGER SLAIN LOST | 27 | 27 | 1 | 0.03 | +0 | +0.4 |
| CHARIOT NO STATIC JOB | 2 | 2 | 1 | 0.03 | -140 | -140.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +11 | +10.9 |
| EDGE GIVE GROUND | 10 | 10 | 1 | 0.03 | +29 | +29.3 |
| GUN MASK | 4 | 4 | 1 | 0.03 | +14 | +14.3 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| JOINT CHARGE PLAN | 4 | 4 | 1 | 0.03 | +4 | +4.2 |
| KEEPS ITS PREY | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 3 | 3 | 1 | 0.03 | -40 | -40.5 |
| MOVE SPELL IN RANGE | 6 | 5 | 1 | 0.03 | +1 | +1.1 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +16 | +16.5 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -7 | -7.3 |
| STOPS | 3 | 3 | 1 | 0.03 | +23 | +23.4 |
| TWO OR MORE ARRIVE | 10 | 10 | 1 | 0.03 | +4 | +4.2 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 37 | 37 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 42 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLS SHORT | 11 | 11 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 381 | not checked | - | - | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 9 | 9 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 12 | 12 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 2 | 2 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 12 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 34 | 34 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT NEEDED | 8 | 8 | 0 | 0.00 | - | - |
| NOT TURNED | 242 | 242 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 39 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2922 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 23 | 23 | 0 | 0.00 | - | - |
| RUN DOWN | 80 | 78 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 7 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| STABLE ROLE | 444 | 443 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 13 | 12 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 71 | 71 | 0 | 0.00 | - | - |
| TURN WORTH | 17 | 17 | 0 | 0.00 | - | - |

### Off best figure: fafix-opp-5e477c5-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.67 | 1.28 | 40.4 |
| TURN GATE | gate | 0.75 | - | 39.0 |
| CHARGE NOW FIRST | rule | 0.31 | 0.42 | 41.7 |
| FALLBACK | gate | 0.58 | - | 26.9 |
| CHAFF PASSED | rule | 0.17 | 0.25 | 3.0 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.11 | 75.3 |
| SUPPORT NARROWED | rule | 0.25 | 0.08 | 9.5 |
| WAR ENGINE JOBS | rule | 0.33 | - | 28.3 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.14 | 20.9 |
| AFTERMATH BAND | gate | 0.14 | 0.08 | 3.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | - | 38.8 |
| BIG CHARACTER SAFETY | rule | 0.14 | - | 7.0 |
| PATHS CROSS | rule | 0.06 | 0.08 | 11.2 |
| RULE SWITCHED OFF | gate | 0.03 | 0.11 | 14.1 |
| PURSUES BIG PREY | rule | 0.08 | - | 151.4 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | - | 5.5 |
| BEST PRIZE | rule | 0.06 | - | 78.6 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 253.5 |
| CHARGE NOW WEIGHED | rule | 0.06 | - | 28.8 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | - | 3.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.03 | 15.0 |
| SAFER THAN THE JOB | rule | 0.06 | - | 9.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 507.9 |
| BLOCKED WHEEL | rule | 0.03 | - | 57.8 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 54.8 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 140.0 |
| FIGHT ORDER BAND | gate | - | 0.03 | 0.6 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 3.0 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | - | 40.5 |
| MOVE AND CAST | rule | 0.03 | - | 3.3 |
| REFUSING RETIRES | rule | 0.03 | - | 0.6 |
| SAFE SURE CHARGE | rule | 0.03 | - | 7.3 |
| SUPPORT REQUEST | gate | 0.03 | - | 1.0 |

### Plans: fafix-opp-5e477c5-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.4 | 12% | 197 | 218 | 111% |
| Mine | charge | 2.8 | 69% | 206 | 270 | 131% |
| Mine | close in | 5.0 | 21% | 245 | 141 | 58% |
| Mine | hold | 5.2 | 32% | 340 | 0 | 0% |
| Mine | join | 0.7 | 100% | 21 | 0 | 0% |
| Mine | shoot | 9.2 | 66% | 336 | 802 | 239% |
| Mine | support | 6.3 | 93% | 56 | 0 | 0% |
| Opponent | charge | 2.7 | 48% | 326 | 201 | 62% |
| Opponent | join | 1.0 | 89% | 41 | 0 | 0% |
| Opponent | move | 34.1 | 92% | 1168 | 0 | 0% |
| Opponent | shoot | 4.3 | 66% | 245 | 350 | 143% |
| Opponent | support | 0.5 | 94% | 5 | 0 | 0% |

### Packages: hunt the guns, fafix-opp-5e477c5-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 233 | 0 | 0% | 56 |
| Opponent | 0.1 | 3 | 0 | 33% | 33% | 0% | 2.0 | 590 | 143 | 33% | 161 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 257 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 66 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 157 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 136 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 286 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.8 | 3 | 0 | 33% | 33% | 0% | 2.0 | 590 | 143 | 33% | 160 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 54 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 53 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 82 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 154 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |

### Battle groups: fafix-opp-5e477c5-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 20% | 40% | 0% | - | 25% | 0% | 10% | 65% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 21% | 50% | 0% | - | 16% | 0% | 9% | 72% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fafix-opp-5e477c5-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 32 | 20% | 3.0 | 0 (1) | 0 (4) | - | 0 (1) | 0 (4) |
| Mine | Chaff | 34 | 39 (34) | 2 | 37 | 52 | 53% | 2.6 | 58 (19) | 34 (7) | 5 (8) | 54 (23) | 5 (11) |
| Mine | Character | 119 | 45 (119) | 44 | 1 | 28 | 22% | 2.5 | 65 (40) | 33 (49) | 29 (17) | 53 (52) | 39 (54) |
| Mine | Clean-up | 21 | 60 (21) | 21 | 40 | 29 | 57% | 2.7 | 35 (5) | 50 (13) | 176 (3) | 104 (13) | 16 (8) |
| Mine | Fast | 1 | 240 (1) | 240 | 0 | 0 | 100% | - | - | 240 (1) | - | 240 (1) | - |
| Mine | Fast Hammer | 46 | 37 (46) | 24 | 14 | 39 | 30% | 3.1 | 38 (21) | 35 (16) | 41 (9) | 47 (27) | 24 (19) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.6 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 26 (57) | 18 | 8 | 34 | 19% | 2.7 | 30 (18) | 28 (29) | 14 (10) | 32 (38) | 17 (19) |
| Mine | Holder | 27 | 67 (27) | 1 | 66 | 14 | 52% | 3.3 | 73 (9) | 80 (9) | 44 (9) | 83 (19) | 36 (8) |
| Mine | Shooter | 40 | 107 (40) | 48 | 60 | 27 | 0% | 1.8 | 250 (5) | 92 (29) | 95 (6) | 162 (24) | 25 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | War machine | 57 | 82 (57) | 82 | 0 | 34 | 4% | 1.1 | 34 (10) | 83 (35) | 118 (12) | 30 (10) | 93 (47) |
| Mine | Wizard | 22 | 3 (22) | 3 | 0 | 36 | 14% | 2.1 | 0 (5) | 0 (6) | 10 (5) | 0 (6) | 5 (10) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 38 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Chaff | 73 | 37 (73) | 7 | 30 | 49 | 37% | 2.9 | 32 (31) | 28 (18) | 54 (24) | 47 (51) | 17 (22) |
| Opponent | Character | 95 | 43 (95) | 43 | 0 | 45 | 28% | 2.6 | 50 (42) | 45 (40) | 0 (5) | 43 (58) | 50 (29) |
| Opponent | Clean-up | 19 | 14 (19) | 9 | 5 | 27 | 58% | 2.6 | 15 (9) | 13 (10) | - | 17 (14) | 5 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 46 | 20 (46) | 10 | 10 | 37 | 37% | 2.6 | 18 (21) | 20 (15) | 26 (10) | 23 (26) | 15 (20) |
| Opponent | Fragile | 5 | 99 (5) | 99 | 0 | 65 | 40% | 3.0 | - | 0 (3) | 255 (2) | 0 (3) | 284 (2) |
| Opponent | Hammer | 67 | 29 (67) | 27 | 2 | 39 | 25% | 3.2 | 16 (17) | 30 (40) | 45 (10) | 35 (43) | 20 (24) |
| Opponent | Holder | 35 | 70 (35) | 14 | 56 | 31 | 37% | 2.8 | 31 (7) | 99 (16) | 52 (11) | 81 (19) | 60 (15) |
| Opponent | Shooter | 31 | 70 (31) | 21 | 50 | 30 | 3% | 1.7 | 85 (8) | 73 (18) | 38 (5) | 110 (21) | 7 (10) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | War machine | 24 | 69 (24) | 69 | 0 | 19 | 12% | 1.7 | 21 (6) | 79 (14) | 92 (4) | 0 (3) | 79 (21) |
| Opponent | Wizard | 26 | 8 (26) | 8 | 0 | 39 | 15% | 1.6 | 0 (9) | 21 (8) | 5 (6) | 16 (8) | 3 (15) |

### Charged fights: fafix-opp-5e477c5-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 204 | 68 | 1.0 | 1.0 | 68 | 0 | +68 | 2 of 4 | 4 of 4 | - | +68 |
| Mine | Chaos Dwarfs | 4 | 348 | 33 | 2.5 | 1.0 | 13 | 31 | -18 | 5 of 10 | 7 of 10 | - | -18 |
| Mine | Dwarfen Mountain Holds | 4 | 852 | 88 | 2.0 | 1.1 | 44 | 0 | +44 | 0 of 8 | 6 of 8 | +63 | +41 |
| Mine | Empire of Man | 5 | 583 | 132 | 1.4 | 1.0 | 94 | 81 | +13 | 5 of 7 | 4 of 7 | - | +13 |
| Mine | Grand Cathay | 3 | 318 | 332 | 1.7 | 1.0 | 199 | 0 | +199 | 2 of 5 | 5 of 5 | - | +199 |
| Mine | High Elf Realms | 4 | 94 | 361 | 3.0 | 1.1 | 120 | 24 | +96 | 3 of 12 | 11 of 12 | +185 | +88 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1045 | 4.0 | 1.0 | 261 | 0 | +261 | 2 of 4 | 4 of 4 | - | +261 |
| Mine | Lizardmen | 1 | 186 | 976 | 4.0 | 1.0 | 244 | 0 | +244 | 1 of 4 | 4 of 4 | - | +244 |
| Mine | Ogre Kingdoms | 1 | 0 | 494 | 4.0 | 1.2 | 124 | 8 | +115 | 1 of 4 | 3 of 4 | +75 | +128 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 289 | 5.0 | 1.2 | 58 | 270 | -212 | 2 of 5 | 3 of 5 | +45 | -276 |
| Mine | Skaven | 2 | 72 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 224 | 423 | 3.0 | 1.0 | 141 | 0 | +141 | 1 of 3 | 3 of 3 | - | +141 |
| Mine | Vampire Counts | 3 | 10 | 423 | 3.0 | 1.2 | 141 | 10 | +131 | 2 of 9 | 8 of 9 | -45 | +181 |
| Mine | Warriors of Chaos | 1 | 0 | 650 | 3.0 | 1.0 | 217 | 0 | +217 | 2 of 3 | 3 of 3 | - | +217 |
| **Mine** | all armies | 35 | 298 | 257 | 2.3 | 1.1 | 112 | 33 | +79 | 29 of 80 | 67 of 80 | +46 | +82 |
| Opponent | Dwarfen Mountain Holds | 2 | 204 | 0 | 1.5 | 1.3 | 0 | 35 | -35 | 2 of 3 | 0 of 3 | +0 | -52 |
| Opponent | Empire of Man | 2 | 670 | 155 | 1.0 | 1.0 | 155 | 0 | +155 | 1 of 2 | 2 of 2 | - | +155 |
| Opponent | Grand Cathay | 2 | 358 | 138 | 2.0 | 1.0 | 69 | 0 | +69 | 1 of 4 | 3 of 4 | - | +69 |
| Opponent | Kingdom of Bretonnia | 1 | 280 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 3 | 41 | 237 | 4.0 | 1.0 | 59 | 49 | +10 | 2 of 12 | 5 of 12 | - | +10 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 161 | 322 | 2.2 | 1.0 | 143 | 105 | +38 | 4 of 9 | 5 of 9 | - | +38 |
| Opponent | Vampire Counts | 6 | 9 | 502 | 3.3 | 1.1 | 151 | 11 | +139 | 9 of 20 | 13 of 20 | +234 | +123 |
| Opponent | Warriors of Chaos | 8 | 32 | 368 | 2.0 | 1.1 | 184 | 30 | +154 | 11 of 16 | 8 of 16 | +92 | +159 |
| Opponent | Wood Elf Realms | 6 | 58 | 398 | 2.8 | 1.0 | 141 | 6 | +134 | 5 of 17 | 12 of 17 | - | +134 |
| **Opponent** | all armies | 35 | 119 | 312 | 2.4 | 1.1 | 130 | 29 | +101 | 35 of 84 | 49 of 84 | +159 | +97 |

### Effective charges: fafix-opp-5e477c5-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net +128) | 0 | 2 (net +72) | 1 (net +0) | 0 | 0 | 0 | 50% (2 of 4) |
| Mine | Chaos Dwarfs | 10 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 4 (net -44) | 0 | 2 (net +0) | 1 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 8 | 0 | 0 | 2 (net +15) | 2 (net +0) | 0 | 3 (net +31) | 1 | 29% (2 of 7) |
| Mine | Empire of Man | 7 | 1 (net +0) | 0 | 0 | 4 (net +165) | 0 | 1 (net +0) | 1 | 0% (0 of 6) |
| Mine | Grand Cathay | 5 | 0 | 1 (net +702) | 0 | 1 (net +60) | 0 | 3 (net +78) | 0 | 0% (0 of 5) |
| Mine | High Elf Realms | 12 | 0 | 0 | 1 (net +234) | 1 (net +251) | 2 (net +113) | 6 (net +97) | 2 | 10% (1 of 10) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +635) | 2 (net +102) | 0 | 1 (net +205) | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 2 (net +308) | 1 (net +310) | 0 | 0 | 1 | 67% (2 of 3) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 2 (net +100) | 1 (net +75) | 1 (net +186) | 0 | 0% (0 of 4) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +45) | 0 | 0 | 1 (net +190) | 3 | 50% (1 of 2) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +141) | 0 | 0% (0 of 3) |
| Mine | Vampire Counts | 9 | 0 | 0 | 0 | 2 (net +277) | 2 (net +273) | 4 (net +20) | 1 | 0% (0 of 8) |
| Mine | Warriors of Chaos | 3 | 1 (net +414) | 0 | 0 | 0 | 0 | 2 (net +118) | 0 | 0% (0 of 3) |
| Opponent | Dwarfen Mountain Holds | 3 | 2 (net -52) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +310) | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 4 | 0 | 0 | 2 (net +90) | 1 (net +0) | 0 | 0 | 1 | 67% (2 of 3) |
| Opponent | Ogre Kingdoms | 12 | 1 (net +125) | 0 | 1 (net +0) | 3 (net -61) | 0 | 2 (net +270) | 5 | 14% (1 of 7) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 9 | 2 (net -304) | 1 (net +130) | 2 (net +174) | 2 (net +55) | 0 | 1 (net +280) | 1 | 25% (2 of 8) |
| Opponent | Vampire Counts | 20 | 4 (net +269) | 0 | 5 (net +119) | 6 (net +202) | 2 (net +48) | 3 (net -62) | 0 | 25% (5 of 20) |
| Opponent | Warriors of Chaos | 16 | 1 (net +435) | 2 (net +0) | 4 (net +107) | 2 (net +235) | 1 (net +92) | 4 (net +187) | 2 | 29% (4 of 14) |
| Opponent | Wood Elf Realms | 17 | 3 (net +152) | 0 | 2 (net +166) | 6 (net +148) | 0 | 4 (net +124) | 2 | 13% (2 of 15) |

### Charged fights, damage counted: fafix-opp-5e477c5-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 271 | 221 | +136 | 176 | 93 | +83 | +30.8 |
| Mine | 50-54% | 2 | 340 | 322 | +351 | 351 | 26 | +325 | +95.6 |
| Mine | Effective (55-75%) | 10 | 216 | 177 | +170 | 172 | 2 | +170 | +78.8 |
| Mine | 76-89% | 21 | 248 | 202 | +98 | 133 | 35 | +98 | +39.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 251 | 176 | +80 | 108 | 23 | +85 | +33.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 411 | 91 | +169 | 169 | 0 | +169 | +41.2 |
| Mine | No odds | 10 | 254 | 183 | -173 | 56 | 216 | -160 | -63.0 |
| Mine | All fights | 80 | 260 | 184 | +79 | 129 | 50 | +80 | +30.7 |
| Opponent | Long shot (under 50%) | 13 | 287 | 330 | +106 | 217 | 127 | +90 | +31.5 |
| Opponent | 50-54% | 3 | 255 | 330 | +43 | 97 | 53 | +44 | +17.3 |
| Opponent | Effective (55-75%) | 17 | 250 | 200 | +111 | 127 | 17 | +111 | +44.2 |
| Opponent | 76-89% | 21 | 244 | 220 | +119 | 147 | 36 | +111 | +45.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 326 | 198 | +146 | 204 | 60 | +144 | +44.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 429 | 121 | +62 | 87 | 41 | +46 | +10.7 |
| Opponent | No odds | 12 | 149 | 152 | +19 | 85 | 46 | +39 | +26.5 |
| Opponent | All fights | 84 | 260 | 220 | +101 | 151 | 53 | +99 | +37.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fafix-opp-5e477c5-p2 | move | 411 | 80 (19%) | 56 (14%) | 35 (9%) | 296 (72%) |
| fafix-opp-5e477c5-p2 | objective | 181 | 30 (17%) | 22 (12%) | 14 (8%) | 137 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: fafix-mine-5e477c5-p4

### Scorecard: fafix-mine-5e477c5-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 10 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 1 | - | 0 | 6 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 1 | 7 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 2 | 6 | 1 | 0 | 0 | 0 | 0 | 560 |
| L0315 | 3 | 1 | Opponent | yes | 6 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 480 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | no | 3 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 6 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 3 | 4 | 3 | 0 | 0 | 0 | 107 |
| L0520 | 4 | 1 | Mine | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 1193 |
| L0520 | 4 | 1 | Opponent | no | 3 | 3 | 0 | 4 | 0 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 165 |
| L0608 | 2 | 1 | Opponent | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 400 |
| L0624 | 6 | 1 | Opponent | no | 8 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 3 | 1 | 4 | 0 | 0 | 0 | 234 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 0 | 3 | 1 | 0 | 0 | 140 |
| L0717 | 3 | 1 | Mine | no | 3 | - | 0 | 3 | 0 | 0 | 0 | 295 |
| L0717 | 3 | 1 | Opponent | yes | 9 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0729 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 488 |
| L0729 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 2 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 550 |
| L0733 | 1 | 1 | Opponent | no | 0 | 4 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 341 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 417 |
| L0823 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 66 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 696 |
| L0835 | 1 | 1 | Opponent | no | 0 | - | 2 | 3 | 1 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 149 |
| L0913 | 1 | 1 | Opponent | no | 7 | 4 | 1 | 1 | 1 | 0 | 0 | 317 |
| L0926 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 3 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 45 |
| L0930 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 165 |
| L1017 | 3 | 1 | Opponent | yes | 5 | 2 | 3 | 1 | 2 | 0 | 0 | 175 |
| L1021 | 1 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 3 | 4 | 1 | 0 | 0 | 355 |
| L1034 | 2 | 1 | Mine | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 165 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1114 | 4 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1114 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 1 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 262 |
| L1126 | 4 | 1 | Opponent | no | 2 | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 165 |
| L1131 | 3 | 1 | Opponent | no | 5 | - | 1 | 1 | 0 | 0 | 0 | 757 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | 5 | 3 | 4 | 1 | 0 | 0 | 650 |
| L1224 | 6 | 1 | Mine | no | 7 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 8 | 3 | 0 | 1 | 0 | 0 | 0 | 205 |
| L1314 | 6 | 1 | Mine | no | 2 | 5 | 1 | 1 | 0 | 0 | 0 | 70 |
| L1314 | 6 | 1 | Opponent | no | 19 | 2 | 1 | 2 | 0 | 0 | 0 | 123 |
| L1319 | 5 | 1 | Mine | no | - | 5 | 1 | 2 | 0 | 0 | 0 | 317 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 70 |
| L1331 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 2 | 0 | 0 | 340 |
| L1335 | 3 | 1 | Mine | no | 5 | 6 | 1 | 0 | 0 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 7 | 3 | 0 | 0 | 0 | 126 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | no | 11 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 5 | - | 1 | 1 | 1 | 0 | 0 | 958 |
| L1523 | 5 | 1 | Mine | yes | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Mine | yes | 1 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 436 |
| L1621 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 6 | 0 | 0 | 0 | 555 |
| L1625 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 1 | 6 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Mine | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | - | 1 | 0 | 2 | 0 | 0 | 477 |
| L1723 | 1 | 1 | Opponent | no | 9 | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 1 | 1 | 0 | 0 | 0 | 185 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | 3 | 3 | 2 | 1 | 0 | 0 | 185 |
| L1835 | 5 | 1 | Opponent | no | - | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 245 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 1 | 0 | 0 | 407 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 1 | 7 | 0 | 0 | 0 | 145 |
| L2025 | 3 | 1 | Mine | no | 9 | - | 2 | 0 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 6 | 1 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 3 | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 6 | 4 | 7 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 6 | - | 2 | 0 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 5 | 6 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 5 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 5 | 3 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 3 | 3 | 1 | 2 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 4 | 2 | 5 | 1 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 20% | 2.0 | 3.3 | 1.5 | 1.6 | 0.2 | 0.0 | 0.0 | 216.5 |
| **Average** | | | Opponent | 30% | 4.2 | 2.6 | 2.8 | 2.4 | 0.4 | 0.0 | 0.0 | 123.8 |

### KPIs: fafix-mine-5e477c5-p4

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE; both sides: LIKELY CHARGE.

Morten 2026-11-10; 54 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (61 of 261) | 1% (3 of 266) | 12% (64 of 527) |
| Winner chose to follow up after the loser gave ground |  | 85% (63 of 74); on the table 89% | 98% (63 of 64); on the table 98% | 91% (126 of 138); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (15 of 18); on the table 94% | 97% (28 of 29); on the table 97% | 91% (43 of 47); on the table 96% |
| Winner chose to pursue after the loser fled |  | 79% (15 of 19); on the table 89% | 74% (35 of 47); on the table 81% | 76% (50 of 66); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 84% (93 of 111); on the table 90% | 90% (126 of 140); on the table 92% | 87% (219 of 251); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 34% (149 of 441) | 35% (96 of 273) | 34% (245 of 714) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (149 of 345) | 43% (90 of 211) | 43% (239 of 556) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 63% (29 of 46) | 64% (63 of 98) | 64% (92 of 144) |
| Points that never fought | lower | 49% (50865 of 103934) | 46% (49414 of 107979) | 47% (100279 of 211913) |
|   infantry points that never fought | lower | 54% (11888 of 22023) | 77% (15939 of 20587) | 65% (27827 of 42610) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (278 of 426) | 56% (232 of 418) | 60% (510 of 844) |
| Bound items with a magic missile used (at least once a game) |  | 92% (33 of 36); 1.6 uses a game | 88% (14 of 16); 0.8 uses a game | 90% (47 of 52); 1.2 uses a game |
| Bound items with another spell used |  | 31% (9 of 29); 0.3 uses a game | 18% (5 of 28); 0.2 uses a game | 25% (14 of 57); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 41% (12 of 29); 0.2 uses a game | 68% (13 of 19); 0.3 uses a game | 52% (25 of 48); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (56562 of 90426) | 49% (46487 of 94278) | 56% (103049 of 184704) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (38%) | 1.4 (41%) | 3.4 (39%) |
| MARCHED: its unit marched | 1.3 (24%) | 0.4 (14%) | 1.7 (20%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.2 (6%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 0.8 (15%) | 0.4 (13%) | 1.3 (14%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.2 (7%) | 0.4 (4%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.7 (13%) | 0.4 (13%) | 1.1 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.1 (3%) | 0.4 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.5 | 1.9 | 4.5 | 0.5 | 1.4 |
| not cast | 2.7 | 2.8 | 2.4 | 8.7 | 1.7 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.9 (68%) | 0.1 (4%) | 3.4 (39%) | 0.5 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (20%) | 0.4 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (1%) | 0.3 (11%) | 1.3 (14%) | 0.3 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (5%) | 0.1 (4%) | 0.3 (13%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.3 (11%) | 0.2 (9%) | 0.5 (20%) | 1.1 (13%) | 0.1 (4%) | 2.1 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (5%) | 0.1 (3%) | 0.0 (1%) | 0.4 (4%) | 0.1 (3%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) | 0.4 (21%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (74%) | 0.1 (2%) | 1.2 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.4 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 58% (35 of 60) | 65% (17 of 26) | 60% (52 of 86) |
| the unit moved after it | 80% (28 of 35) | 88% (15 of 17) | 83% (43 of 52) |
| it charged on its next turn | 6% (2 of 35) | 0% (0 of 17) | 4% (2 of 52) |
| the enemy charged it first | 17% (6 of 35) | 0% (0 of 17) | 12% (6 of 52) |
| it fought by the end of its next turn | 17% (6 of 35) | 6% (1 of 17) | 13% (7 of 52) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (7 of 35) | 0% (0 of 17) | 13% (7 of 52) |
| none of these (no charge, no fight, no charge escaped) | 51% (18 of 35) | 94% (16 of 17) | 65% (34 of 52) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (846 of 1363) | 59% (534 of 912) | 61% (1380 of 2275) |
|   cavalry | 57% (70 of 123) | 70% (143 of 203) | 65% (213 of 326) |
|   character | 51% (86 of 167) | 19% (36 of 194) | 34% (122 of 361) |
|   chariot | 61% (97 of 160) | 55% (17 of 31) | 60% (114 of 191) |
|   infantry | 58% (242 of 420) | 71% (288 of 405) | 64% (530 of 825) |
|   monster | 58% (48 of 83) | 32% (12 of 37) | 50% (60 of 120) |
|   war machine | 74% (303 of 410) | 90% (38 of 42) | 75% (341 of 452) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (25%) | 1.3 (19%) | 3.7 (22%) |
| CHARGED: it charged | 0.6 (6%) | 1.6 (23%) | 2.2 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.1 (2%) | 0.9 (5%) |
| MOVED: a war machine that moved | 1.2 (13%) | 0.0 (0%) | 1.2 (7%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.2 (3%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET IN RANGE | 2.3 (24%) | 1.8 (26%) | 4.1 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.8 (11%) | 1.2 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (14%) | 1.2 (18%) | 2.6 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.5 | 81% | 5.5 pts | 32 pts |
| character | 2.8 | 0.7 | 82% | 5.8 pts | 16 pts |
| chariot | 2.1 | 1.1 | 73% | 13.5 pts | 29 pts |
| infantry | 14.9 | 5.0 | 75% | 9.2 pts | 136 pts |
| monster | 1.3 | 0.3 | 84% | 7.9 pts | 10 pts |
| war machine | 6.3 | 4.8 | 63% | 27.7 pts | 175 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.1 | 5.7 | 3.9 |
| Charges that made contact a game | 1.7 | 3.8 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.45 declared, 0.33 contact (33 units) | 0.50 declared, 0.38 contact (26 units) | 0.47 declared, 0.36 contact (59 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.25 contact (12 units) | 1.06 declared, 0.59 contact (17 units) | 0.76 declared, 0.45 contact (29 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.26 declared, 0.21 contact (375 units) | 0.63 declared, 0.43 contact (437 units) | 0.46 declared, 0.33 contact (812 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (68 of 124) | 57% (16 of 28) | 70% (7 of 10) | 56% (91 of 162) |
| Character in a unit | 87% (46 of 53) | 82% (18 of 22) | 50% (1 of 2) | 84% (65 of 77) |
| Character on its own | 86% (44 of 51) | 61% (28 of 46) | 32% (38 of 117) | 51% (110 of 214) |
| Chariot | 70% (16 of 23) | 80% (12 of 15) | - | 74% (28 of 38) |
| Infantry | 51% (66 of 129) | 58% (22 of 38) | 57% (4 of 7) | 53% (92 of 174) |
| Monster | 58% (30 of 52) | 68% (13 of 19) | - | 61% (43 of 71) |
| Monstrous | 82% (14 of 17) | 77% (17 of 22) | - | 79% (31 of 39) |
| War Machines | 72% (48 of 67) | 100% (2 of 2) | - | 72% (50 of 69) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (7 of 7); on the table 100% | 19% (19 of 102) | 28% | 82% (18 of 22) | 83% (5 of 6); 4.2 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 55% (6 of 11); on the table 64% | 46% (11 of 24) | 39% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 83% (5 of 6); on the table 83% | - | 70% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 11 | 75% (6 of 8); on the table 88% | 50% (27 of 54) | 70% | 70% (81 of 116) | 0.0 uses a game | 25% (1 of 4); 0.1 uses a game | 62% (5 of 8); 0.5 uses a game |
| Grand Cathay | 8 | 62% (10 of 16); on the table 81% | 43% (75 of 174) | 50% | 53% (38 of 72) | 94% (17 of 18); 5.1 uses a game | 67% (2 of 3); 0.2 uses a game | 0% (0 of 8); 0.0 uses a game |
| High Elf Realms | 15 | 95% (38 of 40); on the table 100% | 26% (17 of 66) | 54% | 54% (64 of 119) | 100% (12 of 12); 2.7 uses a game | 19% (9 of 48); 1.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (1 of 1); on the table 100% | - | 71% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 5 | 86% (6 of 7); on the table 86% | 83% (5 of 6) | 39% | 54% (19 of 35) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (5 of 5); on the table 100% | 8% (1 of 12) | 61% | 90% (19 of 21) | 67% (2 of 3); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 5 | 100% (9 of 9); on the table 100% | 24% (16 of 66) | 18% | 60% (24 of 40) | 0.0 uses a game | 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| Skaven | 8 | 92% (23 of 25); on the table 96% | 41% (23 of 56) | 43% | 59% (36 of 61) | 100% (4 of 4); 0.9 uses a game | 0.0 uses a game | 62% (5 of 8); 0.8 uses a game |
| Tomb Kings of Khemri | 8 | 100% (29 of 29); on the table 100% | 6% (1 of 18) | 34% | 28% (11 of 40) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 12 | 97% (33 of 34); on the table 97% | 38% (36 of 94) | 45% | 55% (37 of 67) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 12 | 77% (20 of 26); on the table 77% | 33% (8 of 24) | 35% | 63% (64 of 102) | 100% (4 of 4); 1.2 uses a game | 0.0 uses a game | 100% (4 of 4); 0.3 uses a game |
| Wood Elf Realms | 8 | 78% (21 of 27); on the table 85% | 33% (6 of 18) | 59% | 64% (50 of 78) | 60% (3 of 5); 1.4 uses a game | 0.0 uses a game | 20% (1 of 5); 0.1 uses a game |

Flank and rear charges a unit could have turned to face (fafix-mine-5e477c5-p4, 54 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 59% (66) | 51% (36) | 56% (102) |
| ...free all their last turn and able to turn (per game) | 0.80 | 0.31 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.26 | 0.17 | 0.43 |
| ...with the charger already in that arc before they moved (per game) | 0.57 | 0.20 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 1.20 | 1.20 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.65 | 0.65 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 5.63 | 5.74 |

### Quality by phase: fafix-mine-5e477c5-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 48% (48 of 99) | 44% (113 of 255) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (193 of 506) | 44% (143 of 326) |
| Strategy | Close-in objectives charged next turn | - | 14% (56 of 411) |
| Strategy | Support requests answered (helper made contact too) | 67% (4 of 6) | 49% (21 of 43) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 67% (2 of 3) | 60% (3 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 37% (7 of 19) | 56% (5 of 9) |
| Strategy | Joined characters whose unit fought | 38% (23 of 60) | 34% (18 of 53) |
| Strategy | Lone characters that fought | 57% (73 of 129) | 66% (86 of 130) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.6 | 2.4 |
| Movement | Points that never moved of their own | 216.5 | 123.8 |
| Movement | Fights charged into per game | 1.6 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 69, net -94 | 22 of 145, net +102 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 69, net +50 | 27 of 145, net +77 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 69, net +86 | 17 of 145, net +69 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 69, net +88 | 35 of 145, net +167 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.9 | 10.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (263 of 590) | 44% (250 of 564) |
| Shooting | Points destroyed by shooting units | 65.2 | 31.9 |
| Shooting | War machine shots | 5.6 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (177 of 303) | 21% (8 of 38) |
| Shooting | Points destroyed by war machines | 85.5 | 7.6 |
| Magic | Magic missiles cast | 1.9 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (31 of 104) | 16% (12 of 73) |
| Magic | Wounds caused by magic missiles | 3.5 | 1.6 |
| Magic | Wounds caused by other spells | 1.3 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 80.6 | 29.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.4 / 0.5 / 0.2 | 2.0 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 152.1 | 340.3 |
| Combat | Points run down | 62.6 | 151.9 |
| Combat | Net points per charged fight, damage counted | +39 | +102 |
| Combat | Net per 100 charger points, damage counted | +15.3 | +31.3 |
| Combat | First round won (charged fights) | 73% | 77% |
| Combat | Net points per charged fight | +23 | +105 |
| Combat | Net points per supported fight / lone fight | +32 / +22 | +137 / +99 |
| Combat | Charged fights on a top-3 enemy unit | 35 of 86 | 67 of 171 |
| Game | Points lost | 713.8 | 515.1 |
| Game | VP from objectives | 465.9 | 714.1 |
| Game | Lone holders (player turns) | 2.0 | 4.2 |

- Mine won / drew / lost: 15 / 7 / 32 of 54 ended games (of 54); mean margin (Mine - Opponent) -451 VP
- The side that went first won 18 of 47 games with a winner
- Points traded per game (both sides' losses): 1229
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fafix-mine-5e477c5-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 5.5 | -226.6 | 202.9 | 49.0 |
| AFTERMATH IN POINTS | 0.2 | +23.5 | 0.0 | 19.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 13.4 | 0.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.2 | 0.0 | 3.8 | 0.6 | +3.5 | 0.0 | 7.4 |
| BEST FACING | - | - | - | - | 0.3 | +4.6 | 0.0 | 7.4 |
| BEST FIRST | - | - | - | - | 1.3 | +74.2 | 21.0 | 16.9 |
| BEST OVERALL | - | - | - | - | 0.2 | +15.8 | 0.0 | 10.1 |
| BEST PREY | - | - | - | - | 0.5 | +23.1 | 18.9 | 5.3 |
| BEST PRIZE | 0.1 | -7.0 | 10.0 | 0.0 | 0.1 | -1.4 | 5.9 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.3 | -2.3 | 0.0 | 10.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 0.7 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.6 | +19.5 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -12.8 | 15.6 | 0.0 | 0.2 | -15.1 | 37.7 | 7.3 |
| BOMBING RUN | 0.1 | +1.2 | 1.1 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.4 | +0.0 | 40.6 | 2.6 | 0.1 | +0.0 | 4.4 | 2.3 |
| CANNON PLANNED TARGET | 4.7 | +190.7 | 376.0 | 96.7 | 0.5 | +18.5 | 38.2 | 2.3 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 2.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -1.6 | 21.1 | 22.1 |
| CAST JOB | 0.6 | +20.3 | 22.2 | 20.9 | 0.7 | +11.1 | 14.2 | 14.6 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +16.0 | 25.8 | 0.0 | 0.1 | +2.9 | 1.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 15.7 | 0.5 | +0.0 | 0.0 | 9.3 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +5.0 | 0.0 | 3.3 | 2.0 | +109.1 | 0.0 | 29.1 |
| CHAFF PASSED | 0.3 | -1.9 | 2.5 | 2.1 | 0.1 | -0.1 | 0.0 | 2.1 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.9 | -721.5 | 0.0 | 387.2 | - | - | - | - |
| CHARGE NOW FIRST | 1.0 | +0.0 | 102.5 | 40.0 | 2.3 | +0.0 | 262.1 | 48.5 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.6 | -46.8 | 24.4 | 15.1 |
| CHARGER SLAIN LOST | 0.2 | -23.8 | 26.7 | 8.9 | 0.7 | -25.9 | 109.6 | 17.2 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | +0.0 | 6.8 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 6.4 | 0.0 | 0.1 | +0.0 | 15.6 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 14.4 | 37.3 | 0.5 | +0.0 | 72.9 | 21.3 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 1.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.9 | +80.3 | 35.3 | 37.3 | 0.2 | +18.7 | 3.9 | 3.9 |
| COVER ONCE | 7.9 | -551.0 | 0.0 | 218.9 | 7.0 | -476.7 | 0.0 | 114.7 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 2.6 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +6.7 | 10.7 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +3.4 | 5.5 | 1.1 | 0.4 | +17.2 | 54.1 | 6.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 1.2 | +77.0 | 0.0 | 30.3 |
| FALL BACK GOOD ORDER | 1.2 | +1.4 | 77.4 | 45.9 | - | - | - | - |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.0 | 6.5 | +49.1 | 0.0 | 40.1 |
| FALLS SHORT | 0.2 | -1.3 | 0.0 | 20.1 | - | - | - | - |
| FEATURE BUFFS | 1.3 | +27.4 | 0.0 | 19.4 | - | - | - | - |
| FIGHT LIFT | 0.0 | +1.0 | 2.7 | 6.6 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.0 | 0.0 | 1.5 | - | - | - | - |
| FIVE ACTION | 45.7 | +1384.4 | 824.8 | 882.3 | - | - | - | - |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 209.0 | 4.6 | +0.0 | 0.0 | 67.4 |
| FOCUS FIRE | 0.0 | +0.1 | 0.8 | 1.0 | 0.0 | +0.4 | 0.6 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +125.6 | 0.0 | 44.2 | 0.9 | +94.0 | 0.0 | 30.4 |
| FOUR ROUNDS | 1.8 | +128.5 | 164.5 | 49.4 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.2 | +14.0 | 0.0 | 14.7 | 0.1 | +12.0 | 0.0 | 1.7 |
| GIVES UP | 0.0 | -0.1 | 0.0 | 0.0 | 0.2 | -2.6 | 30.2 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.4 | 1.9 | 0.0 |
| GROUND FLIERS | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| GUN MASK | 0.7 | +11.4 | 0.0 | 11.8 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 5.6 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 24.9 | 8.9 | 0.4 | +0.0 | 37.9 | 3.8 |
| HILL BY ITS CHANCE | - | - | - | - | 0.5 | -43.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -49.4 | 101.6 | 35.5 | 10.3 | -210.8 | 602.8 | 191.5 |
| HUNT ADVANCE | - | - | - | - | 0.3 | +8.6 | 10.6 | 8.3 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 1.6 | 2.1 |
| HUNT IN PAIRS | 0.4 | +15.1 | 0.0 | 6.8 | 0.9 | +61.7 | 0.0 | 3.6 |
| HUNT KEPT | - | - | - | - | 0.1 | +3.5 | 8.1 | 2.1 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +30.7 | 4.6 | 4.3 |
| HUNT THE GUNS | 0.0 | +9.0 | 0.0 | 1.1 | 0.3 | +93.4 | 30.7 | 6.2 |
| IDLE COST | 16.9 | -294.0 | 0.0 | 203.5 | 21.5 | -353.8 | 0.0 | 248.2 |
| INVITES THE FIGHT | - | - | - | - | 1.4 | +8.3 | 71.8 | 20.5 |
| JOINT CHARGE PLAN | - | - | - | - | 0.2 | +10.4 | 9.9 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.7 | 0.0 | 4.3 | 0.1 | -9.8 | 6.5 | 10.9 |
| KEEP FALLS | 0.1 | +1.2 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.2 | 3.9 | 3.1 |
| KEEPS ITS TARGET | - | - | - | - | 2.7 | +80.0 | 247.3 | 78.6 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 1.7 | +101.7 | 186.2 | 30.4 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.3 | +280.2 | 354.0 | 157.6 |
| LONE CHARACTER SAFE SPOT | 0.0 | +2.7 | 0.0 | 0.0 | 0.3 | +10.3 | 5.8 | 2.1 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.3 | +0.0 | 0.0 | 7.4 |
| LONE WIZARD KEPT IN | 0.5 | +24.9 | 0.0 | 0.0 | 0.2 | +21.4 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -1.0 | 5.7 | 4.7 | 0.4 | +1.6 | 26.3 | 1.9 |
| LOST CHARGE | 0.1 | -0.5 | 27.3 | 3.8 | 1.9 | -34.1 | 58.3 | 30.7 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.6 | 0.0 | 0.0 | 0.1 | -4.2 | 0.0 | 1.0 |
| MAKE SURE TOGETHER | 0.1 | +5.6 | 0.0 | 0.0 | 1.0 | +59.3 | 19.9 | 34.2 |
| MANOEUVRE | 1.1 | +22.9 | 0.0 | 40.7 | 0.2 | +5.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +4.1 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +43.6 | 0.0 | 11.2 | 0.3 | +11.6 | 0.0 | 9.3 |
| MARCH ODDS | 0.0 | +0.9 | 0.0 | 0.0 | 0.2 | +9.3 | 4.4 | 0.0 |
| MARCH OVER CASTS | 1.0 | +157.2 | 0.0 | 24.0 | 0.2 | +18.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 7.1 | +113.0 | 0.0 | 170.8 | 7.7 | +113.9 | 0.0 | 113.6 |
| MISSILES IN THE MOVE | 5.0 | +171.5 | 0.0 | 132.7 | 3.0 | +49.9 | 0.0 | 47.4 |
| MISSILES NEXT TURN | 6.0 | +108.6 | 0.0 | 148.6 | 3.5 | +34.6 | 0.0 | 42.8 |
| MODEL FACING | 0.2 | +32.5 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 0.0 | 9.3 |
| MOVE AND CAST | - | - | - | - | 0.4 | +21.5 | 0.0 | 6.4 |
| MOVE SPELL IN RANGE | 0.3 | +7.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -27.3 | 0.0 | 4.1 | 0.1 | -2.2 | 3.6 | 5.1 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 21.9 | 0.2 | +0.0 | 0.0 | 9.3 |
| MOVE TO CHARGE | - | - | - | - | 5.9 | +468.5 | 288.1 | 142.4 |
| MOVES UNITS SPELL | 0.1 | +2.4 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +10.1 | 2.1 | 0.0 |
| NEXT CHARGE BY LIST | 14.1 | -211.1 | 50.0 | 350.0 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 4.1 | -250.9 | 19.0 | 64.4 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.2 | -62.1 | 117.4 | 30.2 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.4 | -20.7 | 68.0 | 4.3 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 5.6 | +74.5 | 0.0 | 89.7 |
| NOT WORTH A CAST | 0.8 | -1.4 | 0.0 | 14.1 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 1.4 | -32.8 | 0.0 | 8.8 | 17.1 | -797.7 | 3.2 | 218.3 |
| ONE FIGHT FORMULA | 7.6 | -143.0 | 0.0 | 207.5 | 10.0 | -199.5 | 45.5 | 239.4 |
| ONE OBJECTIVE FORMULA | 2.7 | -59.4 | 0.0 | 74.0 | 2.8 | -161.8 | 0.0 | 11.8 |
| OPENS A LANE | 0.2 | +1.2 | 28.4 | 0.0 | 0.2 | +0.9 | 10.8 | 0.0 |
| OPENS UP | 0.3 | +14.0 | 13.6 | 0.0 | 0.3 | +23.2 | 15.2 | 20.1 |
| OVERRUNS AWAY | 0.4 | +22.4 | 40.9 | 9.5 | 0.5 | +8.9 | 43.6 | 12.8 |
| PATHS CROSS | 2.5 | +224.7 | 0.0 | 59.3 | 3.5 | +249.9 | 0.0 | 44.0 |
| PERIAPT WORTH | 0.0 | +4.5 | 0.0 | 10.0 | 0.1 | +6.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.5 | 0.0 | 4.1 | 0.1 | -2.5 | 0.0 | 0.0 |
| PLAN RESULT | 40.6 | +731.8 | 517.7 | 1091.1 | 42.5 | +1132.5 | 1666.6 | 807.3 |
| PURSUES BIG PREY | 0.0 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +6.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +22.1 | 0.0 | 35.5 | 1.8 | +29.3 | 0.0 | 68.5 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.3 | -16.0 | 8.1 | 9.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.5 | 0.0 | 1.7 | 1.5 | -36.5 | 0.0 | 24.4 |
| REDIRECT COUNTER | 2.5 | +147.1 | 0.0 | 71.2 | 4.4 | +331.1 | 0.0 | 44.5 |
| REDIRECT WEIGHED | 0.2 | -0.3 | 1.7 | 0.0 | 0.6 | +8.7 | 17.9 | 6.3 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 10.9 |
| RESERVE FALL BACK | 0.6 | +21.8 | 0.0 | 18.1 | 0.7 | +27.4 | 0.0 | 8.0 |
| RESTRAINS TO SHOOT | 0.0 | +0.7 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| RISK BY ARC | 1.2 | +29.7 | 116.1 | 44.1 | 2.6 | +59.3 | 295.7 | 63.4 |
| RISK ONCE | - | - | - | - | 5.0 | +277.4 | 94.2 | 178.6 |
| RUN DOWN | 1.1 | -13.0 | 99.5 | 13.3 | - | - | - | - |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -3.0 | 0.0 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.6 | +23.3 | 0.0 | 10.0 |
| SCALED CHANCE | 3.9 | +29.7 | 3.7 | 106.7 | - | - | - | - |
| SCOUT SPOT | 0.4 | +0.4 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 1.2 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 1.2 |
| SCREEN BY WHAT IT SAVES | 0.0 | -1.2 | 0.0 | 1.6 | 0.4 | -15.2 | 0.0 | 0.5 |
| SEARCH SPOT | 7.2 | +308.1 | 0.0 | 173.8 | 2.9 | +134.5 | 0.0 | 14.6 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.0 | 2.6 | 0.0 |
| SELF MOVE SPELL | 0.3 | +30.2 | 0.0 | 0.0 | 0.4 | +18.1 | 0.0 | 12.1 |
| SET UP TOGETHER | 0.1 | +5.7 | 0.0 | 0.0 | 2.0 | +183.0 | 53.1 | 68.4 |
| SET-UP ANY TARGET | 0.1 | +11.9 | 0.0 | 0.0 | 0.1 | +13.7 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +8.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +57.9 | 40.4 | 14.6 | 1.2 | +26.9 | 29.7 | 13.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 2.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 132.5 | 11.3 | 0.4 | +0.0 | 32.7 | 2.5 |
| SHOTS IN THE MOVE | 16.4 | +738.6 | 0.0 | 274.9 | 9.4 | +217.9 | 0.0 | 57.4 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.1 | +11.9 | 0.0 | 0.0 | 0.1 | +28.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.5 | +24.1 | 79.1 | 95.8 | 2.2 | +45.7 | 15.1 | 15.1 |
| SPELLS IN THE FIGHT | 0.4 | -2.7 | 46.0 | 24.3 | 0.6 | -0.0 | 78.9 | 7.6 |
| STABLE ROLE | - | - | - | - | 12.8 | +0.0 | 452.6 | 101.5 |
| STAND AND SHOOT | 0.3 | -2.4 | 12.1 | 15.7 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.0 | 0.0 | 1.1 | 0.1 | +4.1 | 28.2 | 0.0 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.3 | +8.2 | 0.0 | 2.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 3.1 | 0.2 | +0.0 | 0.0 | 7.0 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 55.7 | 24.8 | 8.0 | -69.5 | 436.1 | 92.5 |
| SUPPORTS | - | - | - | - | 5.8 | +71.2 | 207.5 | 57.7 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -4.0 | 14.7 | 1.3 |
| SURE REACH TOGETHER | 0.4 | +2.2 | 0.0 | 0.0 | 0.7 | -0.9 | 25.9 | 17.4 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.3 | +17.8 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 4.0 | +0.0 | 20.3 | 47.9 | - | - | - | - |
| TURN WORTH | 0.0 | -4.1 | 5.7 | 0.0 | 0.2 | -15.2 | 16.2 | 10.9 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.6 | +3.8 | 33.7 | 27.6 |
| WAIT AFTER COSTS | - | - | - | - | 9.8 | -515.4 | 464.9 | 186.5 |
| WALKS TO THE FIGHT | - | - | - | - | 1.3 | +10.4 | 44.9 | 5.9 |
| WAR ENGINE CHARGES | 0.0 | +1.3 | 3.4 | 0.0 | 0.1 | +1.3 | 2.3 | 0.0 |
| WAR ENGINE JOBS | 0.1 | +0.0 | 19.3 | 0.0 | 0.1 | +0.0 | 0.0 | 6.8 |
| WEARS DOWN | - | - | - | - | 1.2 | +29.6 | 136.3 | 30.0 |
| WHO HITS BACK | 0.4 | +51.2 | 0.0 | 19.0 | 0.2 | +13.1 | 0.0 | 23.2 |
| WHOLE FIGHT | 0.3 | +4.2 | 38.3 | 0.0 | 0.3 | +14.0 | 68.4 | 4.4 |
| WHOLE FIGHT GAIN | 0.1 | +5.8 | 15.8 | 5.1 | 0.7 | +45.2 | 59.1 | 7.1 |
| WIDER SPREAD | 1.4 | -4.7 | 146.3 | 35.8 | 3.1 | -5.8 | 347.6 | 58.2 |

### Rule changes: fafix-mine-5e477c5-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 994 | 994 | 994 | 18.41 | -44846 | -45.1 |
| SEARCH SPOT | 544 | 544 | 528 | 9.78 | +23895 | +45.3 |
| PATHS CROSS | 324 | 324 | 324 | 6.00 | +25628 | +79.1 |
| MOVE TO CHARGE | 321 | 321 | 177 | 3.28 | +8911 | +50.3 |
| SHOTS IN THE MOVE | 1393 | 1190 | 161 | 2.98 | +4039 | +25.1 |
| IDLE COST | 2075 | 1251 | 156 | 2.89 | +1386 | +8.9 |
| KILLS COUNT NEXT TURN | 394 | 394 | 131 | 2.43 | +3715 | +28.4 |
| CHARGE LOSSES | 589 | 589 | 124 | 2.30 | +10234 | +82.5 |
| MAX FOR POSITIONING | 798 | 610 | 123 | 2.28 | +599 | +4.9 |
| COVER ONCE | 804 | 543 | 119 | 2.20 | +2542 | +21.4 |
| SUPPORTS | 311 | 311 | 119 | 2.20 | +1307 | +11.0 |
| WAIT AFTER COSTS | 528 | 528 | 112 | 2.07 | +2101 | +18.8 |
| FIVE ACTION | 2469 | 2469 | 103 | 1.91 | +2956 | +28.7 |
| RANDOM MOVE BY FIGURES | 144 | 144 | 92 | 1.70 | +2777 | +30.2 |
| MISSILES IN THE MOVE | 433 | 346 | 85 | 1.57 | +2172 | +25.5 |
| FOLLOW UP WEIGHED | 83 | 83 | 83 | 1.54 | +11858 | +142.9 |
| REDIRECT COUNTER | 371 | 232 | 83 | 1.54 | +7105 | +85.6 |
| CHAFF IN THE MOVE | 118 | 109 | 79 | 1.46 | +2150 | +27.2 |
| ADVANCE LANE KEPT | 77 | 77 | 77 | 1.43 | +0 | +0.0 |
| RESERVE FALL BACK | 74 | 74 | 74 | 1.37 | +2661 | +36.0 |
| SHOOTS FROM THE BEST SPOT | 120 | 120 | 72 | 1.33 | +585 | +8.1 |
| BEST FIRST | 71 | 71 | 71 | 1.31 | +4008 | +56.4 |
| RISK ONCE | 272 | 217 | 69 | 1.28 | +2522 | +36.5 |
| CANNON SIGHT KEPT | 67 | 67 | 67 | 1.24 | +0 | +0.0 |
| FACES THE THREAT | 65 | 65 | 65 | 1.20 | +4159 | +64.0 |
| NEXT CHARGE BY LIST | 760 | 760 | 63 | 1.17 | +612 | +9.7 |
| ONE FIGHT FORMULA | 955 | 654 | 63 | 1.17 | +330 | +5.2 |
| FALLBACK BY WORTH | 355 | 355 | 59 | 1.09 | +2653 | +45.0 |
| ARTILLERY RE-ROLL WEIGHED | 58 | 58 | 58 | 1.07 | +0 | +0.0 |
| ADVANCE WORTH | 295 | 295 | 55 | 1.02 | +1120 | +20.4 |
| RISK BY ARC | 206 | 202 | 55 | 1.02 | +1438 | +26.1 |
| MARCH CHECK | 57 | 57 | 54 | 1.00 | +1942 | +36.0 |
| SHOT REPLANNED | 54 | 54 | 54 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 53 | 53 | 53 | 0.98 | +0 | +0.0 |
| CANNON PLANNED TARGET | 281 | 281 | 52 | 0.96 | -1092 | -21.0 |
| COMBAT PIVOT | 50 | 50 | 50 | 0.93 | +0 | +0.0 |
| MANOEUVRE | 67 | 67 | 49 | 0.91 | +1564 | +31.9 |
| SET UP TOGETHER | 117 | 94 | 48 | 0.89 | +4066 | +84.7 |
| CHARGE NOW FIRST | 177 | 177 | 47 | 0.87 | -2509 | -53.4 |
| REDIRECT WEIGHED | 45 | 45 | 45 | 0.83 | +1108 | +24.6 |
| FOUR ROUNDS | 97 | 97 | 43 | 0.80 | +3056 | +71.1 |
| LONE WIZARD KEPT IN | 41 | 41 | 41 | 0.76 | +2503 | +61.0 |
| WALKS TO THE FIGHT | 69 | 69 | 38 | 0.70 | +186 | +4.9 |
| HONEST WORTH | 627 | 623 | 35 | 0.65 | +287 | +8.2 |
| SAFER THAN THE JOB | 35 | 35 | 35 | 0.65 | +1259 | +36.0 |
| SCOUT WAITS | 34 | 34 | 34 | 0.63 | +0 | +0.0 |
| WHO HITS BACK | 34 | 34 | 34 | 0.63 | +1916 | +56.4 |
| CAST JOB | 72 | 72 | 33 | 0.61 | +256 | +7.8 |
| CHARGE NOW WEIGHED | 33 | 33 | 33 | 0.61 | +2280 | +69.1 |
| KEEPS ITS TARGET | 144 | 143 | 33 | 0.61 | +542 | +16.4 |
| KILLS COUNT | 91 | 90 | 32 | 0.59 | +1767 | +55.2 |
| NEXT OBJECTIVE NEARER | 220 | 220 | 32 | 0.59 | +665 | +20.8 |
| BLOCKED WHEEL | 31 | 31 | 31 | 0.57 | +1052 | +33.9 |
| INVITES THE FIGHT | 73 | 73 | 28 | 0.52 | +149 | +5.3 |
| SHOOTERS IN TWO RANKS | 28 | 28 | 28 | 0.52 | +71 | +2.5 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.46 | +0 | +0.0 |
| CHAFF PASSED | 23 | 23 | 23 | 0.43 | -111 | -4.8 |
| MOVE AND CAST | 23 | 23 | 23 | 0.43 | +1159 | +50.4 |
| WHOLE FIGHT GAIN | 40 | 38 | 23 | 0.43 | +1120 | +48.7 |
| ONE OBJECTIVE FORMULA | 298 | 206 | 19 | 0.35 | +374 | +19.7 |
| SCALED CHANCE | 210 | 210 | 19 | 0.35 | +100 | +5.3 |
| OPENS UP | 32 | 32 | 18 | 0.33 | +573 | +31.8 |
| PIVOT GUARDS FLANK | 18 | 18 | 18 | 0.33 | -273 | -15.2 |
| STUCK PIVOT | 18 | 18 | 18 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 61 | 53 | 18 | 0.33 | +39 | +2.1 |
| BEST FACING | 17 | 17 | 17 | 0.31 | +248 | +14.6 |
| HUNT IN PAIRS | 73 | 54 | 17 | 0.31 | +949 | +55.8 |
| BIG CHARACTER SAFETY | 16 | 16 | 16 | 0.30 | -125 | -7.8 |
| CASTS FROM BEHIND | 16 | 16 | 16 | 0.30 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 16 | 16 | 16 | 0.30 | +1406 | +87.9 |
| MISSILES NEXT TURN | 512 | 387 | 16 | 0.30 | +61 | +3.8 |
| MAKE SURE TOGETHER | 62 | 41 | 15 | 0.28 | +1150 | +76.7 |
| STOPS SHORT OF THE FLANK | 15 | 15 | 15 | 0.28 | +444 | +29.6 |
| SUPPORT NARROWED | 471 | 471 | 14 | 0.26 | -352 | -25.2 |
| THROUGH LINE OF FIRE | 14 | 14 | 14 | 0.26 | +961 | +68.6 |
| BEST OVERALL | 12 | 12 | 12 | 0.22 | +851 | +70.9 |
| FEATURE BUFFS | 70 | 70 | 12 | 0.22 | +243 | +20.2 |
| OVERRUNS AWAY | 49 | 48 | 12 | 0.22 | +439 | +36.6 |
| MARCH ODDS | 11 | 11 | 11 | 0.20 | +131 | +11.9 |
| AFTERMATH IN POINTS | 10 | 10 | 10 | 0.19 | +1269 | +126.9 |
| BEST PRIZE | 10 | 10 | 10 | 0.19 | -812 | -81.2 |
| MOVES UNITS SPELL | 10 | 10 | 10 | 0.19 | +154 | +15.4 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.19 | +0 | +0.0 |
| WEARS DOWN | 66 | 64 | 10 | 0.19 | +121 | +12.1 |
| BEST PREY | 29 | 29 | 9 | 0.17 | +190 | +21.1 |
| CASTING BLOCK | 12 | 12 | 9 | 0.17 | +152 | +16.9 |
| LOST CHARGE | 109 | 109 | 9 | 0.17 | +212 | +23.5 |
| MODEL FACING | 9 | 9 | 9 | 0.17 | +1753 | +194.8 |
| KEEP FALLS | 7 | 7 | 7 | 0.13 | +247 | +35.3 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.13 | -219 | -31.2 |
| WIDER SPREAD | 244 | 237 | 7 | 0.13 | +34 | +4.8 |
| HUNT ADVANCE | 14 | 14 | 6 | 0.11 | +152 | +25.3 |
| PERIAPT WORTH | 6 | 6 | 6 | 0.11 | +597 | +99.5 |
| REFUSING RETIRES | 20 | 20 | 6 | 0.11 | -3 | -0.5 |
| GUN MASK | 39 | 39 | 5 | 0.09 | +46 | +9.2 |
| WHOLE FIGHT | 30 | 30 | 5 | 0.09 | +269 | +53.7 |
| BACKUP TARGETS | 51 | 30 | 4 | 0.07 | +2 | +0.6 |
| NEEDED THERE | 4 | 4 | 4 | 0.07 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.07 | +174 | +43.5 |
| WAR ENGINE JOBS | 10 | 10 | 4 | 0.07 | -187 | -46.7 |
| BOMBING RUN | 3 | 3 | 3 | 0.06 | +67 | +22.4 |
| CARRIES OUT SET-UP | 13 | 13 | 3 | 0.06 | -86 | -28.8 |
| EDGE GIVE GROUND | 24 | 23 | 3 | 0.06 | +174 | +57.9 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.06 | +34 | +11.3 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.06 | +64 | +21.4 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.04 | +0 | +0.0 |
| DEFENSIVE FLOOR | 2 | 2 | 2 | 0.04 | +334 | +166.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.04 | +27 | +13.7 |
| HILL BY ITS CHANCE | 27 | 27 | 2 | 0.04 | +11 | +5.4 |
| JOINT CHARGE PLAN | 9 | 9 | 2 | 0.04 | +403 | +201.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.04 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 2 | 0.04 | -3 | -1.3 |
| LONG SHOT | 29 | 29 | 2 | 0.04 | +27 | +13.3 |
| MOVE SPELL IN RANGE | 16 | 9 | 2 | 0.04 | +15 | +7.5 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.04 | -60 | -30.2 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.04 | -150 | -75.2 |
| SPELLS IN THE FIGHT | 55 | 52 | 2 | 0.04 | +22 | +11.2 |
| STANDS TO CAST | 2 | 2 | 2 | 0.04 | -3 | -1.4 |
| STOPS | 9 | 9 | 2 | 0.04 | +112 | +55.9 |
| WAR ENGINE CHARGES | 5 | 5 | 2 | 0.04 | +59 | +29.6 |
| BLOWS WHERE AIMED | 15 | 13 | 1 | 0.02 | +4 | +3.5 |
| CHARGER SLAIN LOST | 51 | 51 | 1 | 0.02 | +10 | +9.6 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.02 | +0 | +0.0 |
| DEFENSIVE ARMY | 4 | 4 | 1 | 0.02 | -139 | -138.7 |
| FALL BACK GOOD ORDER | 63 | 63 | 1 | 0.02 | +9 | +8.9 |
| FALLS SHORT | 9 | 9 | 1 | 0.02 | +22 | +22.5 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.02 | +1 | +1.3 |
| NO DOUBLE ROUNDS | 63 | 63 | 1 | 0.02 | +92 | +92.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.02 | +7 | +6.6 |
| OPENS A LANE | 22 | 19 | 1 | 0.02 | +8 | +7.5 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.02 | +18 | +17.9 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 22 | 22 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 68 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 22 | 22 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 58 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 538 | not checked | - | - | - | - |
| GIVES UP | 10 | 10 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 28 | 26 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 16 | trace | - | - | - | - |
| HUNT THE GUNS | 18 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 7 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 63 | 63 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 29 | trace | - | - | - | - |
| MOVE SPELL SPOT | 38 | not checked | - | - | - | - |
| NOT NEEDED | 24 | 24 | 0 | 0.00 | - | - |
| NOT TURNED | 310 | 310 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 61 | not checked | - | - | - | - |
| PLAN RESULT | 4487 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 15 | 15 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 93 | 93 | 0 | 0.00 | - | - |
| RUN DOWN | 61 | 61 | 0 | 0.00 | - | - |
| SCOUT SPOT | 31 | 31 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 37 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 200 | not checked | - | - | - | - |
| STABLE ROLE | 692 | 692 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 15 | 15 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 216 | 216 | 0 | 0.00 | - | - |
| TURN WORTH | 14 | 14 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 33 | 28 | 0 | 0.00 | - | - |

### Off best figure: fafix-mine-5e477c5-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.06 | 15.28 | 47.2 |
| FALLBACK | gate | - | 0.87 | 47.0 |
| CHARGE NOW FIRST | rule | 0.24 | 0.61 | 54.5 |
| TURN GATE | gate | - | 0.56 | 16.1 |
| PIVOT GUARDS FLANK | rule | 0.19 | 0.15 | 15.2 |
| CANNON PLANNED TARGET | rule | 0.31 | - | 72.4 |
| SUPPORT NARROWED | rule | 0.07 | 0.19 | 25.2 |
| BIG CHARACTER SAFETY | rule | - | 0.24 | 10.2 |
| RULE SWITCHED OFF | gate | 0.22 | 0.02 | 23.4 |
| CHAFF PASSED | rule | 0.19 | 0.04 | 9.2 |
| PATHS CROSS | rule | - | 0.20 | 14.5 |
| BEST PRIZE | rule | 0.06 | 0.13 | 81.2 |
| AFTERMATH BAND | gate | 0.04 | 0.11 | 2.4 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.13 | 31.2 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.11 | 12.2 |
| CHARGE NOW WEIGHED | rule | - | 0.09 | 14.7 |
| SAFER THAN THE JOB | rule | - | 0.09 | 12.4 |
| STOPS SHORT OF THE FLANK | rule | - | 0.09 | 9.8 |
| FIGHT ORDER BAND | gate | 0.04 | 0.04 | 3.5 |
| REDIRECT WEIGHED | rule | - | 0.07 | 85.3 |
| WAR ENGINE JOBS | rule | 0.02 | 0.06 | 46.7 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 28.8 |
| FACES THE THREAT | rule | - | 0.06 | 7.3 |
| SUPPORT REQUEST | gate | - | 0.06 | 39.7 |
| FRIENDS SHOTS CHECKED | rule | 0.04 | - | 3.8 |
| PURSUES BIG PREY | rule | 0.04 | - | 30.2 |
| SAFE SURE CHARGE | rule | - | 0.04 | 75.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.02 | 5.3 |
| DEFENSIVE ARMY | rule | 0.02 | - | 138.7 |
| LONE WIZARD HOLDS BACK | rule | - | 0.02 | 2.7 |
| MARCH ODDS | rule | 0.02 | - | 7.2 |
| REFUSING RETIRES | rule | 0.02 | - | 1.0 |
| STANDS TO CAST | rule | - | 0.02 | 3.2 |
| WHO HITS BACK | rule | - | 0.02 | 1.5 |

### Plans: fafix-mine-5e477c5-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 52% | 124 | 140 | 113% |
| Mine | join | 0.3 | 88% | 8 | 0 | 0% |
| Mine | move | 30.9 | 93% | 1093 | 0 | 0% |
| Mine | shoot | 8.0 | 54% | 360 | 592 | 164% |
| Mine | support | 0.1 | 88% | 2 | 0 | 0% |
| Opponent | advance | 12.6 | 19% | 182 | 318 | 174% |
| Opponent | charge | 3.7 | 69% | 311 | 398 | 128% |
| Opponent | close in | 7.6 | 22% | 483 | 208 | 43% |
| Opponent | hold | 5.7 | 40% | 413 | 0 | 0% |
| Opponent | join | 0.7 | 98% | 35 | 0 | 0% |
| Opponent | shoot | 4.8 | 57% | 116 | 213 | 183% |
| Opponent | support | 7.4 | 93% | 62 | 0 | 0% |

### Packages: hunt the guns, fafix-mine-5e477c5-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 486 | 0 | 0% | 12 |
| Opponent | 0.3 | 17 | 2 | 33% | 47% | 0% | 2.4 | 279 | 111 | 47% | 94 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 486 | 0 | 0% | 137 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 27 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.3 | 4 | 0 | 25% | 50% | 0% | 2.5 | 171 | 96 | 50% | 37 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 133 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |
| Tomb Kings of Khemri | 0.4 | 3 | 0 | 33% | 67% | 0% | 2.5 | 208 | 147 | 67% | 9 |
| Vampire Counts | 0.4 | 5 | 0 | 60% | 60% | 0% | 2.3 | 333 | 167 | 60% | 0 |
| Warriors of Chaos | 0.2 | 3 | 1 | 0% | 0% | 0% | - | 437 | 0 | 0% | 130 |
| Wood Elf Realms | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 329 | 0 | 0% | 104 |

### Battle groups: fafix-mine-5e477c5-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.5 | 36% | 52% | 8% | 50% | 20% | 5% | 0% | 73% | 2% |
| Opponent | REDIRECT COUNTER | 4.4 | 12% | 79% | 14% | 25% | 25% | 0% | 8% | 62% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fafix-mine-5e477c5-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 6 | 0 (6) | 0 | 0 | 100 | 50% | 4.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Mine | Chaff | 47 | 8 (47) | 3 | 5 | 72 | 36% | 2.6 | 7 (21) | 0 (9) | 12 (17) | 7 (30) | 9 (17) |
| Mine | Character | 161 | 27 (161) | 27 | 0 | 33 | 26% | 2.5 | 24 (60) | 37 (71) | 0 (12) | 28 (80) | 31 (63) |
| Mine | Clean-up | 37 | 76 (37) | 24 | 51 | 34 | 46% | 3.6 | 57 (8) | 90 (23) | 57 (6) | 112 (19) | 40 (18) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 73 | 25% | 3.7 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 65 | 33 (65) | 23 | 10 | 43 | 37% | 2.5 | 40 (41) | 31 (13) | 10 (11) | 51 (39) | 8 (26) |
| Mine | Fragile | 7 | 44 (7) | 44 | 0 | 45 | 29% | 1.6 | 223 (1) | 14 (5) | 0 (1) | 35 (2) | 48 (5) |
| Mine | Hammer | 88 | 21 (88) | 15 | 6 | 45 | 18% | 2.5 | 7 (18) | 27 (60) | 8 (10) | 14 (53) | 29 (35) |
| Mine | Holder | 34 | 73 (34) | 7 | 66 | 28 | 38% | 3.3 | 16 (11) | 133 (16) | 42 (7) | 93 (21) | 47 (13) |
| Mine | Shooter | 59 | 64 (59) | 31 | 33 | 35 | 3% | 1.7 | 21 (11) | 81 (37) | 54 (11) | 73 (36) | 48 (23) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 58 | 25% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 86 | 48 (86) | 48 | 0 | 51 | 6% | 1.3 | 68 (25) | 47 (48) | 7 (13) | 35 (18) | 51 (68) |
| Mine | Wizard | 28 | 12 (28) | 12 | 0 | 19 | 7% | 2.3 | 21 (9) | 0 (12) | 0 (2) | 23 (11) | 0 (12) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 106 | 78 (106) | 18 | 60 | 37 | 49% | 2.9 | 100 (45) | 68 (25) | 59 (36) | 101 (75) | 14 (31) |
| Opponent | Character | 151 | 57 (151) | 56 | 1 | 22 | 28% | 2.5 | 54 (66) | 61 (68) | 57 (12) | 51 (85) | 66 (61) |
| Opponent | Clean-up | 23 | 32 (23) | 17 | 15 | 36 | 57% | 3.7 | 0 (6) | 34 (13) | 61 (4) | 36 (12) | 30 (11) |
| Opponent | Fast | 1 | 233 (1) | 233 | 0 | 0 | 0% | 5.0 | - | 233 (1) | - | 233 (1) | - |
| Opponent | Fast Hammer | 96 | 53 (96) | 31 | 23 | 36 | 32% | 3.1 | 36 (43) | 63 (36) | 90 (17) | 55 (66) | 51 (30) |
| Opponent | Fragile | 23 | 0 (23) | 0 | 0 | 47 | 43% | 1.9 | 0 (7) | 0 (9) | 0 (6) | 0 (19) | 0 (3) |
| Opponent | Hammer | 85 | 29 (85) | 15 | 14 | 36 | 38% | 3.2 | 27 (26) | 31 (51) | 17 (8) | 34 (50) | 22 (35) |
| Opponent | Holder | 52 | 58 (52) | 20 | 38 | 12 | 58% | 3.4 | 23 (17) | 59 (26) | 128 (9) | 84 (27) | 29 (25) |
| Opponent | Shooter | 51 | 66 (51) | 15 | 52 | 13 | 0% | 1.4 | 63 (14) | 59 (32) | 136 (5) | 65 (28) | 68 (23) |
| Opponent | Support | 7 | 0 (7) | 0 | 0 | 0 | 57% | 4.0 | 0 (5) | 0 (2) | - | 0 (3) | 0 (4) |
| Opponent | War machine | 8 | 83 (8) | 83 | 0 | 48 | 0% | 1.2 | 91 (3) | 69 (3) | 89 (2) | 104 (4) | 54 (4) |
| Opponent | Wizard | 32 | 6 (32) | 6 | 0 | 34 | 12% | 2.0 | 7 (15) | 14 (8) | 0 (3) | 6 (12) | 10 (14) |

### Charged fights: fafix-mine-5e477c5-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 31 | 0 | 0.2 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Chaos Dwarfs | 4 | 145 | 0 | 2.2 | 1.3 | 0 | 72 | -72 | 4 of 9 | 8 of 9 | +0 | -92 |
| Mine | Dwarfen Mountain Holds | 3 | 376 | 0 | 1.7 | 1.0 | 0 | 60 | -60 | 4 of 5 | 2 of 5 | - | -60 |
| Mine | Empire of Man | 10 | 410 | 38 | 0.7 | 1.0 | 54 | 138 | -84 | 4 of 7 | 6 of 7 | - | -84 |
| Mine | Grand Cathay | 8 | 488 | 223 | 1.8 | 1.0 | 128 | 56 | +71 | 7 of 14 | 11 of 14 | - | +71 |
| Mine | High Elf Realms | 8 | 176 | 89 | 1.2 | 1.3 | 71 | 50 | +21 | 2 of 10 | 8 of 10 | +88 | +4 |
| Mine | Kingdom of Bretonnia | 2 | 205 | 72 | 1.0 | 1.0 | 72 | 0 | +72 | 1 of 2 | 2 of 2 | - | +72 |
| Mine | Lizardmen | 2 | 152 | 336 | 3.0 | 1.0 | 112 | 91 | +21 | 4 of 6 | 4 of 6 | - | +21 |
| Mine | Ogre Kingdoms | 3 | 18 | 0 | 2.0 | 1.3 | 0 | 107 | -107 | 3 of 6 | 1 of 6 | +0 | -160 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 580 | 4.0 | 1.0 | 145 | 0 | +145 | 2 of 4 | 3 of 4 | - | +145 |
| Mine | Skaven | 3 | 158 | 177 | 1.3 | 1.0 | 133 | 0 | +133 | 1 of 4 | 4 of 4 | - | +133 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 588 | 3.5 | 1.0 | 168 | 9 | +159 | 2 of 7 | 6 of 7 | - | +159 |
| Mine | Vampire Counts | 2 | 0 | 82 | 4.0 | 1.1 | 20 | 15 | +5 | 0 of 8 | 4 of 8 | +45 | -0 |
| Mine | Warriors of Chaos | 2 | 0 | 188 | 1.5 | 1.0 | 125 | 0 | +125 | 1 of 3 | 3 of 3 | - | +125 |
| **Mine** | all armies | 54 | 231 | 121 | 1.6 | 1.1 | 76 | 53 | +23 | 35 of 86 | 63 of 86 | +32 | +22 |
| Opponent | Empire of Man | 1 | 470 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 7 | 144 | 406 | 3.0 | 1.1 | 135 | 56 | +79 | 9 of 21 | 16 of 21 | +56 | +81 |
| Opponent | Lizardmen | 3 | 37 | 471 | 3.7 | 1.3 | 128 | 53 | +76 | 6 of 11 | 8 of 11 | +162 | +56 |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 238 | 3.0 | 1.2 | 79 | 5 | +75 | 4 of 12 | 9 of 12 | +102 | +72 |
| Opponent | Skaven | 5 | 116 | 193 | 1.6 | 1.0 | 120 | 25 | +96 | 3 of 8 | 7 of 8 | - | +96 |
| Opponent | Tomb Kings of Khemri | 6 | 26 | 991 | 4.7 | 1.2 | 212 | 21 | +192 | 10 of 28 | 21 of 28 | +207 | +186 |
| Opponent | Vampire Counts | 10 | 13 | 318 | 3.6 | 1.1 | 88 | 44 | +45 | 12 of 36 | 30 of 36 | +55 | +43 |
| Opponent | Warriors of Chaos | 10 | 0 | 470 | 2.6 | 1.1 | 181 | 12 | +169 | 11 of 26 | 21 of 26 | +155 | +170 |
| Opponent | Wood Elf Realms | 8 | 157 | 363 | 3.6 | 1.3 | 100 | 17 | +83 | 12 of 29 | 19 of 29 | +139 | +62 |
| **Opponent** | all armies | 54 | 69 | 424 | 3.2 | 1.2 | 134 | 29 | +105 | 67 of 171 | 131 of 171 | +137 | +99 |

### Effective charges: fafix-mine-5e477c5-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 9 | 0 | 0 | 2 (net +0) | 2 (net -290) | 0 | 3 (net -22) | 2 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 5 | 2 (net -58) | 0 | 0 | 2 (net -93) | 0 | 1 (net +0) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 7 | 4 (net -199) | 0 | 1 (net +122) | 1 (net +0) | 0 | 1 (net +85) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 14 | 0 | 1 (net +251) | 6 (net +80) | 6 (net +44) | 1 (net +0) | 0 | 0 | 43% (6 of 14) |
| Mine | High Elf Realms | 10 | 0 | 0 | 0 | 4 (net +10) | 1 (net +251) | 3 (net +62) | 2 | 0% (0 of 8) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 2 (net +72) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 6 | 0 | 1 (net +326) | 1 (net +0) | 0 | 0 | 2 (net +118) | 2 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 5 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +325) | 3 | 0% (0 of 1) |
| Mine | Skaven | 4 | 0 | 0 | 0 | 1 (net +68) | 0 | 3 (net +155) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net +251) | 0 | 3 (net +93) | 2 (net +255) | 0 | 1 (net +75) | 0 | 43% (3 of 7) |
| Mine | Vampire Counts | 8 | 0 | 0 | 3 (net -11) | 1 (net +0) | 2 (net +46) | 2 (net -8) | 0 | 38% (3 of 8) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +285) | 2 | 0% (0 of 1) |
| Opponent | High Elf Realms | 21 | 2 (net +0) | 0 | 4 (net +234) | 5 (net +105) | 2 (net +88) | 5 (net +72) | 3 | 22% (4 of 18) |
| Opponent | Lizardmen | 11 | 1 (net +0) | 0 | 1 (net +135) | 3 (net +55) | 1 (net +189) | 1 (net +582) | 4 | 14% (1 of 7) |
| Opponent | Orc & Goblin Tribes | 12 | 1 (net +0) | 0 | 0 | 1 (net +102) | 1 (net +72) | 1 (net +40) | 8 | 0% (0 of 4) |
| Opponent | Skaven | 8 | 1 (net +0) | 0 | 2 (net -98) | 1 (net +0) | 1 (net +65) | 3 (net +299) | 0 | 25% (2 of 8) |
| Opponent | Tomb Kings of Khemri | 28 | 2 (net +286) | 2 (net +284) | 6 (net +104) | 9 (net +210) | 2 (net +156) | 6 (net +212) | 1 | 22% (6 of 27) |
| Opponent | Vampire Counts | 36 | 7 (net +101) | 0 | 6 (net +89) | 10 (net -9) | 5 (net +83) | 5 (net -58) | 3 | 18% (6 of 33) |
| Opponent | Warriors of Chaos | 26 | 4 (net +277) | 2 (net +224) | 6 (net +26) | 3 (net +199) | 1 (net +65) | 7 (net +261) | 3 | 26% (6 of 23) |
| Opponent | Wood Elf Realms | 29 | 4 (net -34) | 1 (net -91) | 2 (net -51) | 7 (net +141) | 4 (net -30) | 7 (net +164) | 4 | 8% (2 of 25) |

### Charged fights, damage counted: fafix-mine-5e477c5-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 163 | 334 | -94 | 98 | 160 | -63 | -38.4 |
| Mine | 50-54% | 2 | 387 | 276 | +288 | 442 | 132 | +310 | +80.1 |
| Mine | Effective (55-75%) | 17 | 233 | 216 | +50 | 131 | 54 | +78 | +33.4 |
| Mine | 76-89% | 21 | 280 | 219 | +13 | 95 | 79 | +17 | +5.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 231 | 172 | +88 | 126 | 18 | +108 | +46.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 467 | 111 | +86 | 106 | 26 | +80 | +17.1 |
| Mine | No odds | 17 | 247 | 167 | -59 | 59 | 104 | -44 | -18.0 |
| Mine | All fights | 86 | 256 | 204 | +23 | 110 | 71 | +39 | +15.3 |
| Opponent | Long shot (under 50%) | 22 | 205 | 257 | +102 | 146 | 28 | +117 | +57.2 |
| Opponent | 50-54% | 5 | 345 | 316 | +185 | 217 | 25 | +192 | +55.8 |
| Opponent | Effective (55-75%) | 27 | 328 | 200 | +77 | 154 | 86 | +69 | +21.0 |
| Opponent | 76-89% | 39 | 318 | 184 | +107 | 144 | 36 | +108 | +33.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 358 | 198 | +167 | 192 | 51 | +140 | +39.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 17 | 444 | 103 | +69 | 90 | 14 | +76 | +17.1 |
| Opponent | No odds | 26 | 317 | 156 | +58 | 122 | 59 | +63 | +19.9 |
| Opponent | All fights | 171 | 326 | 190 | +105 | 149 | 47 | +102 | +31.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fafix-mine-5e477c5-p4 | move | 608 | 111 (18%) | 83 (14%) | 69 (11%) | 428 (70%) |
| fafix-mine-5e477c5-p4 | objective | 411 | 56 (14%) | 36 (9%) | 54 (13%) | 301 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1224, L1427, L1527, L1625, L2025, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220, L1224 |
| Elixir of Power | Mine | L1114, L1126, L1131, L1923 |
| Elixir of Power | Opponent | L0819, L1319, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1823, L1835 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1224, L1427, L1527, L1625, L2025, L2227, L2527 |
| Opal Amulet | Mine | L1427, L1431 |
| Opal Amulet | Opponent | L0114, L0214, L1114, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2025, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1021, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1114, L1126, L1131, L1220, L1224, L1523, L1527 |
| Ring of Doom | Opponent | L0315, L0733, L1131, L1331, L1431, L2331 |
| Ring of Jet | Mine | L1017, L1021, L1034, L1114, L1126, L1131, L1220, L1224 |
| Standard of the Fell Warrior | Mine | L1314, L1319, L1331, L1335 |
| Standard of the Fell Warrior | Opponent | L0713, L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021, L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0717, L0729, L0733, L1017, L1021, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0717, L0729, L0733, L0819, L0823, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

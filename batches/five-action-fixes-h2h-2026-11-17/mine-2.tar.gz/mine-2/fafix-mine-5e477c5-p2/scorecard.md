# Doctrine scorecard: fafix-mine-5e477c5-p2

### Scorecard: fafix-mine-5e477c5-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 1109 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 7 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 0 | 2 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 254 |
| L0222 | 6 | 1 | Opponent | no | 8 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 315 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 295 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 530 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 5 | 6 | 1 | 0 | 0 | 0 | 0 | 724 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 2 | 3 | 1 | 0 | 0 | 516 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 1147 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 0 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 806 |
| L0528 | 6 | 1 | Opponent | no | 5 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 429 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 606 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 5 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 295 |
| L0721 | 1 | 1 | Opponent | yes | 4 | - | 0 | 5 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 6 | - | 0 | 3 | 0 | 0 | 0 | 376 |
| L0810 | 6 | 1 | Opponent | no | 14 | 2 | 3 | 0 | 2 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1354 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | 4 | 1 | 0 | 0 | 0 | 0 | 45 |
| L0918 | 6 | 1 | Opponent | no | 12 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 518 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 2 | 4 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1026 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 6 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 0 | 6 | 2 | 0 | 0 | 0 | 0 | 359 |
| L1228 | 4 | 1 | Opponent | no | 4 | 6 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 251 |
| L1418 | 2 | 1 | Mine | - | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 4 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 2 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | yes | 7 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 394 |
| L1629 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 228 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 292 |
| L2131 | 1 | 1 | Mine | yes | 4 | - | 0 | 4 | 1 | 0 | 0 | 355 |
| L2131 | 1 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | no | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 261 |
| L2535 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 6 | 4 | 0 | 0 | 0 | 298 |
| L3033 | 3 | 1 | Mine | yes | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 17% | 1.8 | 3.2 | 1.2 | 1.5 | 0.1 | 0.0 | 0.0 | 264.0 |
| **Average** | | | Opponent | 27% | 3.5 | 2.5 | 2.2 | 2.2 | 0.2 | 0.0 | 0.0 | 176.1 |

### KPIs: fafix-mine-5e477c5-p2

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE; both sides: LIKELY CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (41 of 179) | 13% (23 of 175) | 18% (64 of 354) |
| Winner chose to follow up after the loser gave ground |  | 85% (52 of 61); on the table 90% | 100% (33 of 33); on the table 100% | 90% (85 of 94); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 40% (2 of 5); on the table 60% | 87% (13 of 15); on the table 93% | 75% (15 of 20); on the table 85% |
| Winner chose to pursue after the loser fled |  | 72% (13 of 18); on the table 78% | 87% (27 of 31); on the table 90% | 82% (40 of 49); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 80% (67 of 84); on the table 86% | 92% (73 of 79); on the table 95% | 86% (140 of 163); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 41% (139 of 342) | 35% (54 of 156) | 39% (193 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (139 of 261) | 42% (48 of 114) | 50% (187 of 375) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 63% (19 of 30) | 47% (27 of 57) | 53% (46 of 87) |
| Points that never fought | lower | 46% (32928 of 71583) | 52% (37765 of 71989) | 49% (70693 of 143572) |
|   infantry points that never fought | lower | 49% (7971 of 16324) | 80% (11287 of 14029) | 63% (19258 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (184 of 284) | 59% (174 of 297) | 62% (358 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 85% (17 of 20); 1.7 uses a game | 72% (13 of 18); 1.0 uses a game | 79% (30 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 44% (8 of 18); 0.5 uses a game | 50% (1 of 2); 0.1 uses a game | 45% (9 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 52% (14 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (36825 of 60231) | 54% (34219 of 63281) | 58% (71044 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (35%) | 1.1 (37%) | 3.1 (36%) |
| MARCHED: its unit marched | 1.1 (20%) | 0.4 (14%) | 1.5 (18%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 0.9 (16%) | 0.3 (11%) | 1.2 (14%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.9 (16%) | 0.5 (17%) | 1.4 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (8%) | 0.2 (8%) | 0.7 (8%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (8%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.6 | 1.6 | 5.4 | 0.6 | 1.0 |
| not cast | 3.7 | 3.3 | 3.4 | 8.5 | 1.8 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.9 (56%) | 0.4 (12%) | 3.1 (36%) | 0.5 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (18%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.2 (5%) | 0.3 (10%) | 1.2 (14%) | 0.1 (6%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (7%) | 0.3 (10%) | 0.3 (8%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (2%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.5 (13%) | 0.2 (8%) | 0.8 (24%) | 1.4 (16%) | 0.4 (21%) | 2.9 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.2 (5%) | 0.0 (1%) | 0.7 (8%) | 0.1 (5%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (1%) | 0.1 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.4 (21%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.6 (69%) | 0.2 (8%) | 1.4 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.7 a game | 0.8 a game |
| stood (cast and not dispelled) | 72% (23 of 32) | 62% (16 of 26) | 67% (39 of 58) |
| the unit moved after it | 57% (13 of 23) | 75% (12 of 16) | 64% (25 of 39) |
| it charged on its next turn | 0% (0 of 23) | 0% (0 of 16) | 0% (0 of 39) |
| the enemy charged it first | 17% (4 of 23) | 0% (0 of 16) | 10% (4 of 39) |
| it fought by the end of its next turn | 4% (1 of 23) | 0% (0 of 16) | 3% (1 of 39) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (3 of 23) | 0% (0 of 16) | 8% (3 of 39) |
| none of these (no charge, no fight, no charge escaped) | 70% (16 of 23) | 100% (16 of 16) | 82% (32 of 39) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (561 of 841) | 56% (465 of 830) | 61% (1026 of 1671) |
|   cavalry | 76% (54 of 71) | 61% (107 of 176) | 65% (161 of 247) |
|   character | 53% (57 of 108) | 35% (45 of 129) | 43% (102 of 237) |
|   chariot | 63% (71 of 113) | 60% (30 of 50) | 62% (101 of 163) |
|   infantry | 62% (152 of 246) | 58% (179 of 311) | 59% (331 of 557) |
|   monster | 48% (24 of 50) | 47% (18 of 38) | 48% (42 of 88) |
|   war machine | 80% (203 of 253) | 68% (86 of 126) | 76% (289 of 379) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (22%) | 2.2 (22%) | 3.9 (22%) |
| CHARGED: it charged | 0.5 (6%) | 2.0 (20%) | 2.5 (14%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.3 (3%) | 1.1 (6%) |
| MOVED: a war machine that moved | 0.9 (12%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET IN RANGE | 1.8 (22%) | 2.6 (26%) | 4.4 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (7%) | 0.3 (3%) | 0.8 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (15%) | 1.5 (15%) | 2.7 (15%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.3 (3%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (4%) | 0.6 (6%) | 0.9 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.8 | 2.3 | 73% | 6.9 pts | 47 pts |
| character | 2.9 | 1.1 | 73% | 8.1 pts | 24 pts |
| chariot | 2.8 | 1.6 | 69% | 12.9 pts | 36 pts |
| infantry | 12.8 | 5.1 | 73% | 8.9 pts | 114 pts |
| monster | 1.4 | 0.6 | 72% | 11.1 pts | 15 pts |
| war machine | 8.0 | 7.0 | 63% | 25.5 pts | 205 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.9 | 5.8 | 3.9 |
| Charges that made contact a game | 1.6 | 4.1 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.32 declared, 0.28 contact (25 units) | 0.58 declared, 0.42 contact (12 units) | 0.41 declared, 0.32 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.33 contact (6 units) | 0.92 declared, 0.75 contact (12 units) | 0.78 declared, 0.61 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.24 declared, 0.20 contact (251 units) | 0.67 declared, 0.47 contact (287 units) | 0.47 declared, 0.34 contact (538 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (42 of 73) | 50% (9 of 18) | 58% (7 of 12) | 56% (58 of 103) |
| Character in a unit | 87% (33 of 38) | 74% (14 of 19) | 60% (3 of 5) | 81% (50 of 62) |
| Character on its own | 85% (29 of 34) | 66% (23 of 35) | 34% (21 of 61) | 56% (73 of 130) |
| Chariot | 76% (13 of 17) | 54% (7 of 13) | - | 67% (20 of 30) |
| Infantry | 54% (51 of 94) | 71% (24 of 34) | 67% (2 of 3) | 59% (77 of 131) |
| Monster | 52% (15 of 29) | 44% (4 of 9) | - | 50% (19 of 38) |
| Monstrous | 64% (9 of 14) | 64% (9 of 14) | - | 64% (18 of 28) |
| War Machines | 74% (42 of 57) | 50% (1 of 2) | - | 73% (43 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (12 of 12); on the table 100% | 25% (26 of 102) | 55% | 64% (14 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 1.2 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 92% (11 of 12); on the table 92% | 53% (19 of 36) | 47% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 6 | 57% (4 of 7); on the table 71% | - | 67% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 78% (7 of 9); on the table 78% | 50% (24 of 48) | 56% | 62% (47 of 76) | 0.0 uses a game | 50% (1 of 2); 0.6 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 67% (4 of 6); on the table 100% | 46% (63 of 138) | 58% | 65% (35 of 54) | 64% (9 of 14); 4.2 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 69% (9 of 13); on the table 85% | 28% (5 of 18) | 41% | 61% (20 of 33) | 100% (3 of 3); 3.2 uses a game | 36% (5 of 14); 2.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 86% (6 of 7); on the table 86% | - | 52% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 62% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (14 of 14); on the table 100% | 11% (2 of 18) | 54% | 82% (23 of 28) | 100% (4 of 4); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 33% (4 of 12) | 15% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 100% (5 of 5); on the table 100% | 28% (5 of 18) | 59% | 56% (14 of 25) | 100% (2 of 2); 3.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 91% (10 of 11); on the table 91% | - | 43% | 24% (6 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 81% (26 of 32); on the table 81% | 45% (30 of 66) | 34% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 92% (12 of 13); on the table 92% | 56% (10 of 18) | 40% | 56% (41 of 73) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 89% (17 of 19); on the table 100% | 21% (5 of 24) | 55% | 62% (48 of 78) | 57% (4 of 7); 1.6 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fafix-mine-5e477c5-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (45) | 53% (20) | 52% (65) |
| ...free all their last turn and able to turn (per game) | 0.81 | 0.39 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.06 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.28 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.03 | 1.11 | 1.14 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.94 | 0.94 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.06 | 5.69 | 5.75 |

### Quality by phase: fafix-mine-5e477c5-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 59% (38 of 64) | 46% (94 of 205) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (131 of 318) | 46% (125 of 270) |
| Strategy | Close-in objectives charged next turn | - | 17% (42 of 254) |
| Strategy | Support requests answered (helper made contact too) | 86% (6 of 7) | 41% (16 of 39) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 2) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 26% (6 of 23) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 31% (15 of 49) | 18% (8 of 45) |
| Strategy | Lone characters that fought | 65% (62 of 96) | 67% (52 of 78) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.5 | 2.2 |
| Movement | Points that never moved of their own | 264.0 | 176.1 |
| Movement | Fights charged into per game | 1.4 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 43, net +293 | 22 of 110, net +148 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 43, net +1 | 23 of 110, net +112 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 43, net +132 | 5 of 110, net +135 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 43, net +193 | 33 of 110, net +176 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (145 of 385) | 46% (189 of 408) |
| Shooting | Points destroyed by shooting units | 88.1 | 54.2 |
| Shooting | War machine shots | 5.6 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (124 of 203) | 55% (47 of 86) |
| Shooting | Points destroyed by war machines | 59.5 | 13.9 |
| Magic | Magic missiles cast | 2.4 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 17% (15 of 88) | 44% (15 of 34) |
| Magic | Wounds caused by magic missiles | 5.4 | 1.4 |
| Magic | Wounds caused by other spells | 0.8 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 59.2 | 27.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.8 / 0.3 / 0.1 | 2.1 / 0.2 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 169.7 | 307.1 |
| Combat | Points run down | 43.4 | 123.7 |
| Combat | Net points per charged fight, damage counted | +71 | +118 |
| Combat | Net per 100 charger points, damage counted | +24.2 | +43.1 |
| Combat | First round won (charged fights) | 69% | 70% |
| Combat | Net points per charged fight | +63 | +120 |
| Combat | Net points per supported fight / lone fight | +165 / +53 | +210 / +96 |
| Combat | Charged fights on a top-3 enemy unit | 17 of 52 | 46 of 122 |
| Game | Points lost | 739.5 | 470.3 |
| Game | VP from objectives | 413.3 | 780.3 |
| Game | Lone holders (player turns) | 1.8 | 3.5 |

- Mine won / drew / lost: 9 / 6 / 21 of 36 ended games (of 36); mean margin (Mine - Opponent) -630 VP
- The side that went first won 15 of 30 games with a winner
- Points traded per game (both sides' losses): 1210
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fafix-mine-5e477c5-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 5.0 | -161.6 | 182.9 | 48.8 |
| AFTERMATH IN POINTS | 0.2 | +23.6 | 0.0 | 5.2 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +5.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 32.1 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.8 | +3.6 | 0.0 | 12.9 | 0.6 | +4.2 | 0.0 | 3.5 |
| BEST FACING | - | - | - | - | 0.4 | +14.8 | 0.0 | 7.7 |
| BEST FIRST | - | - | - | - | 1.1 | +59.8 | 9.0 | 20.8 |
| BEST OVERALL | - | - | - | - | 0.3 | +15.4 | 0.0 | 9.8 |
| BEST PREY | - | - | - | - | 0.6 | +18.5 | 11.7 | 8.2 |
| BEST PRIZE | 0.0 | -1.6 | 0.0 | 0.0 | 0.2 | -3.6 | 7.5 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 7.6 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.6 | +19.4 | 0.0 | 5.1 |
| BLOWS WHERE AIMED | 0.2 | -11.8 | 28.1 | 0.0 | 0.5 | -58.6 | 81.9 | 7.3 |
| BOMBING RUN | 0.1 | +1.8 | 2.8 | 1.7 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 99.1 | 0.0 | 0.2 | +0.0 | 4.0 | 4.6 |
| CANNON PLANNED TARGET | 4.4 | +177.0 | 230.9 | 114.2 | 1.7 | +83.6 | 29.5 | 41.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -2.9 | 24.8 | 0.0 |
| CAST JOB | 0.8 | +14.9 | 11.4 | 11.3 | 0.6 | +17.4 | 46.6 | 10.3 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +10.5 | 10.1 | 0.0 | 0.4 | +17.4 | 25.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 22.7 | 0.5 | +0.0 | 0.0 | 30.8 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +2.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +16.2 | 0.0 | 5.0 | 1.9 | +77.4 | 0.0 | 28.9 |
| CHAFF PASSED | 0.3 | -0.7 | 4.7 | 11.1 | 0.2 | -0.2 | 3.3 | 5.1 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +2.8 | 10.9 | 0.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 5.8 | - | - | - | - |
| CHARGE LOSSES | 11.9 | -714.1 | 0.0 | 329.8 | - | - | - | - |
| CHARGE NOW FIRST | 1.0 | +0.0 | 99.9 | 24.8 | 2.8 | +0.0 | 297.3 | 61.1 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.3 | -31.0 | 17.2 | 3.5 |
| CHARGER SLAIN LOST | 0.2 | -6.0 | 13.2 | 14.5 | 0.7 | -13.5 | 68.7 | 15.2 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.7 | 0.2 | +0.0 | 21.3 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 14.4 | 36.3 | 0.4 | +0.0 | 39.9 | 9.4 |
| CONVEYANCE SEARCH | 0.6 | +41.6 | 5.9 | 5.9 | 0.7 | +47.6 | 17.3 | 32.6 |
| COVER ONCE | 8.5 | -561.4 | 0.0 | 198.1 | 6.4 | -561.3 | 0.0 | 116.4 |
| DEFENSIVE ARMY | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +1.1 | 7.1 | 0.0 |
| EDGE GIVE GROUND | 0.0 | +0.1 | 1.7 | 0.0 | 0.7 | +18.8 | 92.9 | 15.8 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.0 | +0.5 | 0.0 | 0.0 | 1.1 | +79.1 | 0.0 | 18.4 |
| FALL BACK GOOD ORDER | 1.2 | +5.4 | 92.4 | 30.7 | - | - | - | - |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 1.5 | 6.2 | +52.0 | 0.0 | 68.8 |
| FALLS SHORT | 0.2 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| FEATURE BUFFS | 0.9 | +24.0 | 0.0 | 14.9 | - | - | - | - |
| FIGHT LIFT | 0.1 | +0.6 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 43.5 | +1061.0 | 575.4 | 725.6 | - | - | - | - |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 154.4 | 4.9 | +0.0 | 0.0 | 76.2 |
| FOCUS FIRE | 0.1 | +3.7 | 1.2 | 0.0 | 0.0 | +0.3 | 2.4 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +225.8 | 0.0 | 62.3 | 0.8 | +113.3 | 0.0 | 44.2 |
| FOUR ROUNDS | 1.7 | +116.6 | 126.3 | 36.1 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +13.9 | 0.0 | 7.3 | 0.1 | +3.6 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -0.8 | 19.2 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 0.0 | 1.2 |
| GUN MASK | 0.2 | +1.0 | 0.0 | 9.1 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 14.1 | 8.8 |
| HELPER UNSEEN | 0.1 | +0.0 | 14.0 | 14.3 | 0.5 | +0.0 | 57.8 | 8.9 |
| HILL BY ITS CHANCE | - | - | - | - | 0.7 | -56.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.4 | -47.1 | 102.0 | 23.1 | 11.3 | -243.8 | 684.1 | 183.6 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.5 | +2.9 | 47.9 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 21.4 | 0.0 |
| HUNT IN PAIRS | 0.5 | +27.4 | 0.0 | 0.0 | 0.6 | +40.2 | 0.0 | 12.1 |
| HUNT KEPT | - | - | - | - | 0.3 | +6.8 | 34.4 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.6 | +109.9 | 21.4 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.7 | +164.3 | 77.1 | 3.2 |
| IDLE COST | 16.4 | -260.0 | 0.0 | 196.8 | 20.9 | -323.9 | 0.0 | 160.4 |
| INVITES THE FIGHT | - | - | - | - | 0.8 | +5.4 | 21.5 | 13.7 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +4.0 | 6.4 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.8 | 9.3 | 12.9 |
| KEEP FALLS | 0.1 | +1.9 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.2 | 5.0 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.7 | +80.0 | 215.2 | 105.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | - | - | - | - | 2.0 | +75.7 | 190.5 | 44.8 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.5 | +316.9 | 282.2 | 146.6 |
| LONE CHARACTER SAFE SPOT | 0.0 | +0.5 | 0.0 | 2.4 | 0.1 | +4.5 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.2 | +0.0 | 11.1 | 16.1 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.3 | 2.0 | 11.4 | 0.6 | -0.6 | 49.2 | 5.4 |
| LOST CHARGE | 0.1 | -0.3 | 18.0 | 0.0 | 2.3 | -38.8 | 54.8 | 58.2 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | -24.7 | 0.0 | 4.4 |
| MAKE SURE TOGETHER | 0.1 | +0.5 | 0.0 | 2.0 | 0.8 | +62.1 | 36.4 | 18.3 |
| MANOEUVRE | 1.0 | +15.5 | 0.0 | 41.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.8 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +51.2 | 0.0 | 7.5 | 0.3 | +6.7 | 0.0 | 0.0 |
| MARCH ODDS | - | - | - | - | 0.2 | +17.1 | 14.8 | 25.6 |
| MARCH OVER CASTS | 0.7 | +145.4 | 0.0 | 27.9 | 0.2 | +1.3 | 0.0 | 10.3 |
| MAX FOR POSITIONING | 7.2 | +107.9 | 0.0 | 85.4 | 7.8 | +115.3 | 0.0 | 136.5 |
| MISSILES IN THE MOVE | 4.6 | +134.3 | 0.0 | 94.4 | 3.3 | +65.0 | 0.0 | 55.0 |
| MISSILES NEXT TURN | 5.5 | +80.7 | 0.0 | 126.7 | 3.7 | +46.1 | 0.0 | 87.6 |
| MODEL FACING | 0.3 | +62.9 | 0.0 | 1.7 | 0.2 | +36.9 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 0.0 | 10.2 |
| MOVE AND CAST | - | - | - | - | 0.2 | +19.8 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -19.4 | 7.1 | 12.5 | 0.2 | -5.5 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 10.2 |
| MOVE TO CHARGE | - | - | - | - | 5.7 | +391.9 | 209.1 | 126.9 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +1.7 | 0.0 | 0.0 | 0.1 | +22.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 14.6 | -276.8 | 59.8 | 261.1 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 3.8 | -207.7 | 31.7 | 56.5 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.1 | -67.8 | 95.4 | 36.1 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +10.3 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.6 | -30.5 | 83.3 | 8.8 |
| NOT TURNED | 0.1 | +0.3 | 0.0 | 5.9 | 5.7 | +87.0 | 0.0 | 109.5 |
| NOT WORTH A CAST | 0.6 | -0.5 | 0.0 | 2.4 | 1.0 | -1.0 | 0.0 | 0.0 |
| OFF BEST | 1.5 | -43.5 | 0.0 | 33.3 | 18.8 | -881.1 | 10.3 | 253.1 |
| ONE FIGHT FORMULA | 7.9 | -152.8 | 0.0 | 145.0 | 9.6 | -201.5 | 14.4 | 178.6 |
| ONE OBJECTIVE FORMULA | 2.5 | -41.3 | 0.0 | 41.0 | 2.6 | -163.2 | 0.0 | 10.3 |
| OPENS A LANE | 0.1 | +0.3 | 5.4 | 0.0 | 0.1 | +0.1 | 5.3 | 0.0 |
| OPENS UP | 0.1 | +3.0 | 1.8 | 0.0 | 0.2 | +18.3 | 13.4 | 0.0 |
| OVERRUNS AWAY | 0.1 | +6.1 | 21.7 | 0.0 | 0.6 | +10.6 | 56.0 | 11.5 |
| PATHS CROSS | 2.6 | +244.3 | 0.0 | 55.6 | 3.2 | +191.3 | 0.0 | 28.8 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.8 | 0.0 | 11.3 | 0.0 | -0.2 | 0.0 | 0.0 |
| PLAN RESULT | 38.7 | +721.9 | 349.7 | 963.6 | 43.6 | +1169.8 | 1364.9 | 681.3 |
| PURSUES BIG PREY | 0.0 | -4.7 | 0.0 | 0.0 | 0.1 | -8.4 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +24.7 | 0.0 | 15.3 | 1.6 | +22.4 | 0.0 | 45.8 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.1 | -8.1 | 9.3 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.0 | 0.0 | 1.5 | 1.1 | -26.9 | 0.0 | 16.5 |
| REDIRECT COUNTER | 2.4 | +143.8 | 0.0 | 35.9 | 4.5 | +329.5 | 0.0 | 44.5 |
| REDIRECT WEIGHED | 0.1 | +2.5 | 0.0 | 0.0 | 0.4 | -0.2 | 2.4 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 9.3 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +19.8 | 0.0 | 2.0 | 1.1 | +26.4 | 0.0 | 15.0 |
| RESTRAINS TO SHOOT | 0.1 | +2.0 | 0.0 | 0.0 | 0.1 | +1.4 | 0.0 | 0.0 |
| RISK BY ARC | 1.2 | +28.0 | 104.7 | 34.1 | 2.9 | +44.9 | 284.2 | 74.2 |
| RISK ONCE | - | - | - | - | 3.0 | +52.3 | 59.1 | 137.5 |
| RUN DOWN | 1.1 | -19.6 | 88.1 | 33.8 | - | - | - | - |
| SAFER THAN THE JOB | - | - | - | - | 0.9 | +62.1 | 0.0 | 22.9 |
| SCALED CHANCE | 4.0 | +37.6 | 6.0 | 45.9 | - | - | - | - |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 1.8 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.0 | -0.3 | 0.0 | 0.0 | 0.7 | -44.0 | 0.0 | 7.5 |
| SEARCH SPOT | 6.9 | +321.2 | 0.0 | 108.7 | 2.5 | +115.6 | 0.0 | 9.1 |
| SECOND HUNTER | - | - | - | - | 0.4 | -1.6 | 34.0 | 0.0 |
| SELF MOVE SPELL | 0.2 | +20.0 | 0.0 | 31.0 | - | - | - | - |
| SET UP TOGETHER | 0.2 | +7.5 | 0.0 | 5.4 | 2.0 | +132.0 | 61.6 | 30.3 |
| SET-UP ANY TARGET | 0.1 | +5.7 | 0.0 | 0.0 | 0.1 | +9.4 | 0.0 | 7.6 |
| SET-UP MISSED | - | - | - | - | 0.1 | +14.3 | 6.5 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +21.5 | 9.9 | 7.0 | 1.1 | +31.6 | 28.7 | 21.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 136.8 | 4.6 | 0.3 | +0.0 | 22.4 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +649.2 | 0.0 | 304.8 | 12.1 | +387.3 | 0.0 | 171.9 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.0 | 0.0 | 7.6 |
| SPELL OFF EDGE | - | - | - | - | 0.1 | +3.5 | 5.4 | 0.0 |
| SPELL SETS UP CHARGE | 0.1 | +5.7 | 0.0 | 0.0 | 0.2 | +16.9 | 12.1 | 19.7 |
| SPELL WORTH | 0.8 | +13.4 | 27.9 | 27.9 | 1.7 | +24.7 | 33.1 | 33.1 |
| SPELLS IN THE FIGHT | 0.3 | +2.6 | 25.8 | 0.0 | 0.7 | -5.9 | 55.6 | 28.6 |
| STABLE ROLE | - | - | - | - | 13.4 | +0.0 | 447.0 | 149.6 |
| STAND AND SHOOT | 0.2 | -2.1 | 18.0 | 9.6 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.1 | +4.6 | 0.0 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.0 | +2.1 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.4 | +16.2 | 61.7 | 3.2 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.3 | +11.3 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 0.8 | +0.0 | 76.6 | 12.7 | 8.6 | -72.5 | 403.9 | 74.4 |
| SUPPORTS | - | - | - | - | 6.1 | +80.9 | 168.2 | 24.2 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -2.2 | 2.6 | 1.7 |
| SURE REACH TOGETHER | 0.5 | +5.8 | 0.0 | 8.2 | 0.7 | -0.8 | 12.9 | 20.4 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.3 | +6.5 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 3.5 | +0.0 | 31.5 | 61.2 | - | - | - | - |
| TURN WORTH | 0.1 | -7.4 | 16.4 | 4.0 | 0.1 | -11.1 | 11.6 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +4.0 | 25.6 | 0.0 |
| WAIT AFTER COSTS | - | - | - | - | 9.8 | -437.7 | 349.4 | 182.5 |
| WALKS TO THE FIGHT | - | - | - | - | 2.0 | +12.6 | 72.0 | 18.8 |
| WAR ENGINE CHARGES | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 3.8 |
| WAR ENGINE JOBS | - | - | - | - | 0.4 | +0.0 | 16.7 | 23.2 |
| WEARS DOWN | 0.0 | +0.6 | 3.5 | 1.2 | 1.5 | +44.5 | 205.4 | 25.3 |
| WHO HITS BACK | 0.5 | +77.5 | 0.0 | 44.0 | 0.1 | +7.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +20.5 | 19.2 | 0.0 | 0.3 | -3.9 | 67.2 | 9.9 |
| WHOLE FIGHT GAIN | 0.2 | +8.2 | 4.7 | 0.0 | 0.8 | +57.7 | 70.1 | 9.6 |
| WIDER SPREAD | 1.4 | -6.9 | 98.6 | 34.1 | 3.9 | -7.7 | 412.9 | 47.1 |

### Rule changes: fafix-mine-5e477c5-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 729 | 729 | 729 | 20.25 | -33286 | -45.7 |
| SEARCH SPOT | 341 | 341 | 329 | 9.14 | +15833 | +48.1 |
| PATHS CROSS | 211 | 211 | 211 | 5.86 | +15682 | +74.3 |
| SHOTS IN THE MOVE | 985 | 800 | 117 | 3.25 | +3322 | +28.4 |
| MOVE TO CHARGE | 206 | 206 | 108 | 3.00 | +5492 | +50.9 |
| SUPPORTS | 218 | 218 | 102 | 2.83 | +1269 | +12.4 |
| KILLS COUNT NEXT TURN | 271 | 271 | 95 | 2.64 | +3012 | +31.7 |
| WAIT AFTER COSTS | 351 | 351 | 86 | 2.39 | +1809 | +21.0 |
| COVER ONCE | 537 | 371 | 85 | 2.36 | +1720 | +20.2 |
| IDLE COST | 1345 | 850 | 83 | 2.31 | +830 | +10.0 |
| CHARGE LOSSES | 428 | 428 | 79 | 2.19 | +7086 | +89.7 |
| MAX FOR POSITIONING | 538 | 428 | 76 | 2.11 | +255 | +3.4 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| REDIRECT COUNTER | 248 | 168 | 66 | 1.83 | +4711 | +71.4 |
| FIVE ACTION | 1565 | 1565 | 64 | 1.78 | +1115 | +17.4 |
| RESERVE FALL BACK | 58 | 58 | 58 | 1.61 | +1662 | +28.7 |
| FOLLOW UP WEIGHED | 55 | 55 | 55 | 1.53 | +12207 | +221.9 |
| ARTILLERY RE-ROLL WEIGHED | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| MISSILES IN THE MOVE | 285 | 222 | 46 | 1.28 | +1240 | +27.0 |
| RANDOM MOVE BY FIGURES | 87 | 87 | 46 | 1.28 | +1696 | +36.9 |
| RISK BY ARC | 148 | 144 | 44 | 1.22 | +1237 | +28.1 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 70 | 70 | 42 | 1.17 | +625 | +14.9 |
| BEST FIRST | 41 | 41 | 41 | 1.14 | +2152 | +52.5 |
| FACES THE THREAT | 41 | 41 | 41 | 1.14 | +2866 | +69.9 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| CHAFF IN THE MOVE | 77 | 73 | 39 | 1.08 | +902 | +23.1 |
| CANNON PLANNED TARGET | 218 | 218 | 38 | 1.06 | +78 | +2.1 |
| SHOT REPLANNED | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| FALLBACK BY WORTH | 229 | 229 | 37 | 1.03 | +1871 | +50.6 |
| NEXT CHARGE BY LIST | 525 | 525 | 37 | 1.03 | +304 | +8.2 |
| SAFER THAN THE JOB | 34 | 34 | 34 | 0.94 | +2235 | +65.7 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SET UP TOGETHER | 81 | 66 | 33 | 0.92 | +1782 | +54.0 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| FOUR ROUNDS | 61 | 61 | 31 | 0.86 | +1531 | +49.4 |
| MARCH CHECK | 33 | 33 | 31 | 0.86 | +1027 | +33.1 |
| ADVANCE WORTH | 181 | 181 | 30 | 0.83 | +553 | +18.4 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| ONE FIGHT FORMULA | 630 | 444 | 30 | 0.83 | +132 | +4.4 |
| CHARGE NOW FIRST | 136 | 136 | 27 | 0.75 | -1871 | -69.3 |
| HONEST WORTH | 460 | 457 | 25 | 0.69 | +181 | +7.2 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| WALKS TO THE FIGHT | 71 | 71 | 24 | 0.67 | +117 | +4.9 |
| WHO HITS BACK | 23 | 23 | 23 | 0.64 | +1644 | +71.5 |
| BLOCKED WHEEL | 21 | 21 | 21 | 0.58 | +700 | +33.3 |
| CAST JOB | 50 | 50 | 21 | 0.58 | +185 | +8.8 |
| WHOLE FIGHT GAIN | 34 | 34 | 21 | 0.58 | +508 | +24.2 |
| MODEL FACING | 20 | 20 | 20 | 0.56 | +3591 | +179.5 |
| CHAFF PASSED | 18 | 18 | 18 | 0.50 | -32 | -1.8 |
| KILLS COUNT | 72 | 69 | 17 | 0.47 | +616 | +36.2 |
| MANOEUVRE | 37 | 37 | 17 | 0.47 | +585 | +34.4 |
| NEXT OBJECTIVE NEARER | 138 | 138 | 17 | 0.47 | +286 | +16.8 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| MISSILES NEXT TURN | 331 | 248 | 16 | 0.44 | +80 | +5.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +632 | +42.1 |
| HUNT IN PAIRS | 38 | 31 | 15 | 0.42 | +939 | +62.6 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.42 | +621 | +41.4 |
| BEST FACING | 14 | 14 | 14 | 0.39 | +534 | +38.1 |
| MAKE SURE TOGETHER | 31 | 22 | 14 | 0.39 | +653 | +46.6 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| RISK ONCE | 107 | 79 | 13 | 0.36 | +242 | +18.6 |
| CASTING BLOCK | 21 | 21 | 12 | 0.33 | +293 | +24.4 |
| CHARGE NOW WEIGHED | 12 | 12 | 12 | 0.33 | +1082 | +90.2 |
| SCALED CHANCE | 144 | 144 | 12 | 0.33 | +102 | +8.5 |
| BEST OVERALL | 11 | 11 | 11 | 0.31 | +553 | +50.2 |
| STOPS SHORT OF THE FLANK | 11 | 11 | 11 | 0.31 | +407 | +37.0 |
| KEEPS ITS TARGET | 96 | 95 | 10 | 0.28 | +167 | +16.7 |
| THROUGH LINE OF FIRE | 10 | 10 | 10 | 0.28 | +234 | +23.4 |
| WIDER SPREAD | 190 | 186 | 10 | 0.28 | +29 | +2.9 |
| MOVE AND CAST | 9 | 9 | 9 | 0.25 | +713 | +79.3 |
| REFUSING RETIRES | 18 | 18 | 9 | 0.25 | -2 | -0.3 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -392 | -48.9 |
| MARCH ODDS | 8 | 8 | 8 | 0.22 | +234 | +29.2 |
| ONE OBJECTIVE FORMULA | 183 | 118 | 8 | 0.22 | +461 | +57.7 |
| AFTERMATH IN POINTS | 7 | 7 | 7 | 0.19 | +850 | +121.4 |
| BEST PREY | 21 | 21 | 7 | 0.19 | +141 | +20.2 |
| FEATURE BUFFS | 32 | 32 | 7 | 0.19 | +160 | +22.9 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -109 | -15.6 |
| SURE REACH TOGETHER | 44 | 34 | 7 | 0.19 | +10 | +1.4 |
| INVITES THE FIGHT | 29 | 29 | 6 | 0.17 | +37 | +6.1 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -471 | -78.5 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +120 | +20.0 |
| BACKUP TARGETS | 48 | 35 | 5 | 0.14 | +17 | +3.5 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| LOST CHARGE | 86 | 85 | 5 | 0.14 | +138 | +27.6 |
| OVERRUNS AWAY | 25 | 25 | 5 | 0.14 | +155 | +31.0 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -78 | -15.6 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +306 | +76.4 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| OPENS UP | 10 | 10 | 4 | 0.11 | +151 | +37.8 |
| STOPS | 15 | 15 | 4 | 0.11 | +162 | +40.6 |
| BIG CHARACTER SAFETY | 3 | 3 | 3 | 0.08 | -6 | -2.1 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +145 | +48.3 |
| SUPPORT NARROWED | 338 | 338 | 3 | 0.08 | -66 | -22.1 |
| WAR ENGINE JOBS | 14 | 14 | 3 | 0.08 | -154 | -51.4 |
| WEARS DOWN | 56 | 55 | 3 | 0.08 | +63 | +20.9 |
| BLOWS WHERE AIMED | 23 | 22 | 2 | 0.06 | +31 | +15.4 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +65 | +32.5 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -34 | -17.1 |
| CHARGER SLAIN LOST | 31 | 31 | 2 | 0.06 | +26 | +12.9 |
| FALL BACK GOOD ORDER | 42 | 42 | 2 | 0.06 | +33 | +16.6 |
| JOINT CHARGE PLAN | 5 | 5 | 2 | 0.06 | +75 | +37.4 |
| MOVE SPELL IN RANGE | 12 | 12 | 2 | 0.06 | +28 | +14.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +47 | +23.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +158 | +78.9 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -62 | -31.0 |
| TWO OR MORE ARRIVE | 12 | 9 | 2 | 0.06 | +13 | +6.5 |
| WHOLE FIGHT | 18 | 18 | 2 | 0.06 | +85 | +42.4 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT SET-UP | 9 | 9 | 1 | 0.03 | -106 | -105.8 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +4 | +4.0 |
| EDGE GIVE GROUND | 25 | 24 | 1 | 0.03 | +47 | +46.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +5 | +5.0 |
| GUN MASK | 8 | 8 | 1 | 0.03 | +6 | +5.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| LONG SHOT | 26 | 26 | 1 | 0.03 | +4 | +4.2 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +8 | +7.6 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +11 | +11.2 |
| SPELLS IN THE FIGHT | 36 | 36 | 1 | 0.03 | +29 | +28.8 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +77 | +76.6 |
| ALREADY CARRIED | 5 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 42 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 21 | 21 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 46 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 3 | 3 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLS SHORT | 9 | 9 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 376 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 26 | 26 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 19 | 19 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 23 | trace | - | - | - | - |
| HUNT THE GUNS | 24 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 5 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 9 | 9 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 40 | 40 | 0 | 0.00 | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 207 | 207 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 58 | not checked | - | - | - | - |
| OPENS A LANE | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 2963 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 41 | 41 | 0 | 0.00 | - | - |
| RUN DOWN | 41 | 41 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 27 | 27 | 0 | 0.00 | - | - |
| SECOND HUNTER | 13 | 13 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 9 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL OFF EDGE | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 88 | not checked | - | - | - | - |
| STABLE ROLE | 483 | 482 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 9 | 9 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 125 | 125 | 0 | 0.00 | - | - |
| TURN WORTH | 10 | 10 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: fafix-mine-5e477c5-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.19 | 17.03 | 47.0 |
| FALLBACK | gate | - | 0.94 | 33.0 |
| CHARGE NOW FIRST | rule | 0.11 | 0.64 | 69.3 |
| TURN GATE | gate | - | 0.47 | 52.1 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.08 | 21.0 |
| CHAFF PASSED | rule | 0.17 | 0.11 | 3.1 |
| AFTERMATH BAND | gate | 0.06 | 0.14 | 2.5 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.03 | 15.6 |
| RULE SWITCHED OFF | gate | 0.17 | 0.03 | 39.6 |
| BEST PRIZE | rule | 0.03 | 0.14 | 65.1 |
| PATHS CROSS | rule | 0.03 | 0.14 | 26.7 |
| PURSUES BIG PREY | rule | 0.03 | 0.14 | 78.5 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.14 | 15.6 |
| FIGHT ORDER BAND | gate | 0.03 | 0.08 | 1.9 |
| CHARGE NOW WEIGHED | rule | - | 0.08 | 22.4 |
| SUPPORT NARROWED | rule | - | 0.08 | 22.1 |
| SUPPORT REQUEST | gate | - | 0.08 | 38.3 |
| WAR ENGINE JOBS | rule | - | 0.08 | 51.4 |
| BIG CHARACTER SAFETY | rule | - | 0.06 | 3.6 |
| CATCH ODDS | rule | - | 0.06 | 17.1 |
| REFUSING RETIRES | rule | 0.06 | - | 0.8 |
| STANDS TO CAST | rule | - | 0.06 | 31.0 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 3.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 22.3 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 105.8 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 2.6 |
| REDIRECT WEIGHED | rule | - | 0.03 | 43.4 |
| WHO HITS BACK | rule | 0.03 | - | 4.3 |

### Plans: fafix-mine-5e477c5-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.4 | 51% | 175 | 132 | 76% |
| Mine | join | 0.6 | 91% | 24 | 0 | 0% |
| Mine | move | 29.1 | 93% | 903 | 0 | 0% |
| Mine | shoot | 7.4 | 60% | 279 | 590 | 211% |
| Mine | support | 0.1 | 67% | 0 | 0 | 0% |
| Opponent | advance | 12.2 | 14% | 145 | 246 | 170% |
| Opponent | charge | 4.8 | 56% | 316 | 406 | 128% |
| Opponent | close in | 7.0 | 29% | 463 | 203 | 44% |
| Opponent | hold | 5.4 | 45% | 410 | 0 | 0% |
| Opponent | join | 0.8 | 97% | 33 | 0 | 0% |
| Opponent | shoot | 5.6 | 52% | 186 | 318 | 171% |
| Opponent | support | 7.7 | 93% | 64 | 0 | 0% |

### Packages: hunt the guns, fafix-mine-5e477c5-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Opponent | 0.7 | 24 | 1 | 39% | 74% | 0% | 2.6 | 254 | 172 | 74% | 67 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 191 | 0 | 0% | 36 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 75% | 100% | 0% | 2.8 | 564 | 440 | 100% | 105 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Tomb Kings of Khemri | 2.8 | 14 | 1 | 15% | 69% | 0% | 2.7 | 115 | 73 | 69% | 0 |
| Vampire Counts | 0.2 | 2 | 0 | 100% | 100% | 0% | 2.5 | 311 | 248 | 100% | 13 |
| Warriors of Chaos | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 452 | 217 | 50% | 74 |
| Wood Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 375 | 322 | 100% | 0 |

### Battle groups: fafix-mine-5e477c5-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.4 | 24% | 71% | 14% | 33% | 39% | 0% | 11% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 4.5 | 9% | 73% | 27% | 50% | 18% | 0% | 18% | 64% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fafix-mine-5e477c5-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 52 | 20% | 2.2 | - | - | 0 (1) | - | 0 (1) |
| Mine | Chaff | 34 | 35 (34) | 3 | 32 | 69 | 41% | 2.5 | 40 (19) | 54 (7) | 11 (8) | 47 (23) | 9 (11) |
| Mine | Character | 123 | 28 (123) | 26 | 2 | 27 | 25% | 2.6 | 22 (41) | 39 (51) | 14 (13) | 36 (50) | 24 (55) |
| Mine | Clean-up | 21 | 26 (21) | 6 | 20 | 65 | 43% | 3.2 | 34 (5) | 20 (13) | 32 (3) | 39 (13) | 12 (8) |
| Mine | Fast | 1 | 70 (1) | 70 | 0 | 0 | 0% | 6.0 | - | 70 (1) | - | 70 (1) | - |
| Mine | Fast Hammer | 48 | 30 (48) | 17 | 13 | 45 | 33% | 2.9 | 15 (23) | 69 (16) | 12 (9) | 29 (29) | 31 (19) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 1.6 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 31 (57) | 23 | 9 | 38 | 23% | 2.4 | 12 (18) | 44 (29) | 32 (10) | 39 (38) | 19 (19) |
| Mine | Holder | 28 | 44 (28) | 15 | 29 | 26 | 54% | 3.2 | 58 (11) | 29 (9) | 58 (7) | 64 (18) | 11 (9) |
| Mine | Shooter | 41 | 72 (41) | 36 | 36 | 44 | 2% | 1.4 | 138 (5) | 50 (30) | 139 (6) | 104 (25) | 24 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Mine | War machine | 59 | 34 (59) | 34 | 0 | 60 | 3% | 1.3 | 27 (10) | 45 (37) | 0 (12) | 45 (10) | 32 (49) |
| Mine | Wizard | 22 | 2 (22) | 2 | 0 | 61 | 14% | 2.3 | 0 (7) | 7 (6) | 2 (5) | 3 (6) | 2 (12) |
| Opponent | Blocker | 2 | 85 (2) | 85 | 0 | 0 | 50% | 5.0 | - | 85 (2) | - | - | 85 (2) |
| Opponent | Chaff | 76 | 69 (76) | 29 | 40 | 33 | 46% | 2.6 | 91 (32) | 71 (19) | 38 (25) | 83 (54) | 37 (22) |
| Opponent | Character | 97 | 56 (97) | 55 | 1 | 14 | 30% | 2.7 | 67 (44) | 49 (47) | 17 (5) | 61 (69) | 51 (27) |
| Opponent | Clean-up | 19 | 32 (19) | 24 | 8 | 40 | 47% | 2.8 | 42 (9) | 16 (10) | - | 36 (14) | 20 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 43 (48) | 33 | 10 | 27 | 29% | 2.6 | 23 (22) | 32 (16) | 111 (10) | 30 (28) | 67 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 39 | 60% | 4.0 | - | 0 (3) | 0 (1) | 0 (4) | - |
| Opponent | Hammer | 70 | 35 (70) | 30 | 5 | 36 | 36% | 2.8 | 44 (17) | 32 (42) | 40 (11) | 39 (43) | 30 (27) |
| Opponent | Holder | 35 | 100 (35) | 2 | 98 | 23 | 51% | 2.6 | 76 (9) | 128 (19) | 49 (6) | 134 (22) | 39 (12) |
| Opponent | Shooter | 33 | 86 (33) | 14 | 72 | 15 | 0% | 1.8 | 42 (8) | 113 (19) | 47 (6) | 123 (22) | 29 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |
| Opponent | War machine | 24 | 23 (24) | 23 | 0 | 39 | 12% | 1.4 | 13 (6) | 24 (14) | 30 (4) | 0 (3) | 27 (21) |
| Opponent | Wizard | 26 | 8 (26) | 8 | 0 | 33 | 8% | 1.5 | 0 (10) | 16 (7) | 11 (6) | 18 (8) | 0 (15) |

### Charged fights: fafix-mine-5e477c5-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 33 | 64 | 1.2 | 1.0 | 51 | 0 | +51 | 1 of 5 | 4 of 5 | - | +51 |
| Mine | Chaos Dwarfs | 4 | 309 | 344 | 1.8 | 1.1 | 196 | 35 | +162 | 5 of 7 | 4 of 7 | +609 | +87 |
| Mine | Dwarfen Mountain Holds | 4 | 260 | 42 | 1.0 | 1.2 | 42 | 15 | +27 | 1 of 4 | 3 of 4 | +0 | +36 |
| Mine | Empire of Man | 5 | 575 | 18 | 0.6 | 1.0 | 31 | 76 | -45 | 1 of 3 | 1 of 3 | - | -45 |
| Mine | Grand Cathay | 4 | 262 | 82 | 1.5 | 1.0 | 55 | 0 | +55 | 1 of 6 | 6 of 6 | - | +55 |
| Mine | High Elf Realms | 4 | 104 | 291 | 1.8 | 1.1 | 166 | 0 | +166 | 3 of 7 | 6 of 7 | +170 | +166 |
| Mine | Kingdom of Bretonnia | 1 | 170 | 205 | 3.0 | 1.0 | 68 | 157 | -89 | 2 of 3 | 2 of 3 | - | -89 |
| Mine | Lizardmen | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Ogre Kingdoms | 1 | 186 | 0 | 3.0 | 1.0 | 0 | 62 | -62 | 0 of 3 | 0 of 3 | - | -62 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 295 | 4.0 | 1.2 | 74 | 0 | +74 | 1 of 4 | 2 of 4 | +45 | +83 |
| Mine | Skaven | 2 | 58 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 0 | 826 | 3.0 | 1.0 | 275 | 0 | +275 | 1 of 3 | 3 of 3 | - | +275 |
| Mine | Vampire Counts | 3 | 68 | 57 | 1.7 | 1.4 | 34 | 79 | -45 | 1 of 5 | 4 of 5 | +0 | -56 |
| Mine | Warriors of Chaos | 1 | 19 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| **Mine** | all armies | 36 | 207 | 136 | 1.4 | 1.1 | 94 | 30 | +63 | 17 of 52 | 36 of 52 | +165 | +53 |
| Opponent | Dwarfen Mountain Holds | 2 | 200 | 32 | 2.0 | 1.2 | 16 | 56 | -40 | 0 of 4 | 3 of 4 | -60 | -33 |
| Opponent | Empire of Man | 2 | 155 | 218 | 2.5 | 1.2 | 87 | 0 | +87 | 1 of 5 | 4 of 5 | +325 | +28 |
| Opponent | Grand Cathay | 2 | 190 | 401 | 2.5 | 1.6 | 160 | 27 | +133 | 2 of 5 | 3 of 5 | +306 | +18 |
| Opponent | Kingdom of Bretonnia | 1 | 120 | 286 | 2.0 | 1.0 | 143 | 0 | +143 | 1 of 2 | 2 of 2 | - | +143 |
| Opponent | Ogre Kingdoms | 3 | 0 | 227 | 3.7 | 1.2 | 62 | 27 | +35 | 2 of 11 | 6 of 10 | +217 | -6 |
| Opponent | Skaven | 1 | 281 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 180 | 1086 | 5.0 | 1.2 | 217 | 10 | +208 | 9 of 20 | 15 of 20 | +395 | +145 |
| Opponent | Vampire Counts | 6 | 54 | 382 | 3.7 | 1.2 | 104 | 13 | +91 | 10 of 22 | 12 of 22 | +56 | +102 |
| Opponent | Warriors of Chaos | 8 | 22 | 356 | 2.0 | 1.3 | 178 | 59 | +119 | 6 of 16 | 12 of 16 | +319 | +52 |
| Opponent | Wood Elf Realms | 7 | 104 | 780 | 5.3 | 1.1 | 148 | 14 | +133 | 15 of 37 | 28 of 37 | +82 | +142 |
| **Opponent** | all armies | 36 | 96 | 478 | 3.4 | 1.2 | 141 | 21 | +120 | 46 of 122 | 85 of 121 | +210 | +96 |

### Effective charges: fafix-mine-5e477c5-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 2 (net +28) | 0 | 0 | 1 (net +72) | 2 | 67% (2 of 3) |
| Mine | Chaos Dwarfs | 7 | 1 (net +509) | 0 | 1 (net -120) | 4 (net +147) | 1 (net +153) | 0 | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 1 (net +30) | 0 | 1 (net +139) | 1 | 33% (1 of 3) |
| Mine | Empire of Man | 3 | 0 | 0 | 1 (net +92) | 2 (net -114) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Grand Cathay | 6 | 0 | 0 | 1 (net +185) | 4 (net +36) | 0 | 1 (net +0) | 0 | 17% (1 of 6) |
| Mine | High Elf Realms | 7 | 0 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +121) | 2 (net +376) | 1 | 17% (1 of 6) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 1 (net -471) | 2 (net +102) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 3 | 1 (net -185) | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 1 (net +250) | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 3 | 1 (net +599) | 0 | 1 (net +102) | 1 (net +125) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Vampire Counts | 5 | 0 | 0 | 2 (net +85) | 2 (net +0) | 0 | 0 | 1 | 50% (2 of 4) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Dwarfen Mountain Holds | 4 | 2 (net -30) | 0 | 1 (net -40) | 1 (net -60) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Empire of Man | 5 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +218) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 2 (net +306) | 3 (net +18) | 0 | 0 | 0 | 40% (2 of 5) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 2 (net +143) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 11 | 2 (net +228) | 0 | 3 (net +0) | 2 (net +52) | 0 | 0 | 4 | 43% (3 of 7) |
| Opponent | Tomb Kings of Khemri | 20 | 2 (net +168) | 1 (net -65) | 6 (net +233) | 3 (net +163) | 2 (net +142) | 6 (net +284) | 0 | 30% (6 of 20) |
| Opponent | Vampire Counts | 22 | 4 (net +170) | 2 (net +0) | 4 (net -14) | 5 (net +174) | 1 (net +171) | 5 (net +69) | 1 | 19% (4 of 21) |
| Opponent | Warriors of Chaos | 16 | 3 (net +39) | 1 (net +0) | 1 (net +264) | 1 (net +0) | 1 (net +115) | 8 (net +164) | 1 | 7% (1 of 15) |
| Opponent | Wood Elf Realms | 37 | 8 (net +217) | 0 | 5 (net +80) | 4 (net +92) | 1 (net +104) | 13 (net +189) | 6 | 16% (5 of 31) |

### Charged fights, damage counted: fafix-mine-5e477c5-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 288 | 238 | +293 | 340 | 75 | +265 | +91.8 |
| Mine | Effective (55-75%) | 13 | 215 | 195 | +1 | 74 | 75 | -1 | -0.5 |
| Mine | 76-89% | 18 | 322 | 246 | +48 | 93 | 42 | +51 | +15.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 200 | 147 | +193 | 208 | 19 | +189 | +94.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 371 | 103 | +132 | 132 | 18 | +113 | +30.5 |
| Mine | No odds | 9 | 371 | 171 | -12 | 98 | 50 | +47 | +12.8 |
| Mine | All fights | 52 | 292 | 202 | +63 | 121 | 51 | +71 | +24.2 |
| Opponent | Long shot (under 50%) | 22 | 264 | 237 | +148 | 194 | 58 | +135 | +51.3 |
| Opponent | 50-54% | 4 | 193 | 307 | -16 | 74 | 80 | -5 | -2.8 |
| Opponent | Effective (55-75%) | 23 | 313 | 184 | +112 | 146 | 34 | +113 | +36.1 |
| Opponent | 76-89% | 23 | 227 | 155 | +111 | 138 | 15 | +123 | +54.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 283 | 182 | +176 | 199 | 44 | +155 | +54.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 612 | 118 | +135 | 135 | 0 | +135 | +22.0 |
| Opponent | No odds | 12 | 170 | 248 | -18 | 85 | 64 | +20 | +11.9 |
| Opponent | All fights | 122 | 274 | 195 | +120 | 158 | 40 | +118 | +43.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fafix-mine-5e477c5-p2 | move | 410 | 77 (19%) | 57 (14%) | 44 (11%) | 289 (70%) |
| fafix-mine-5e477c5-p2 | objective | 254 | 42 (17%) | 30 (12%) | 32 (13%) | 180 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

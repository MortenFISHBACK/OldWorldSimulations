# Doctrine scorecard: fafix-mine-5e477c5-p1

### Scorecard: fafix-mine-5e477c5-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 6 | 2 | 0 | 1 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 5 | 3 | 2 | 3 | 1 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 3 | 0 | 0 | 0 | 68 |
| L0135 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 322 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 3 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 2 | 4 | 2 | 0 | 0 | 0 | 0 | 195 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 6 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 4 | 3 | 2 | 2 | 0 | 0 | 0 | 881 |
| L0421 | 1 | 1 | Mine | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 375 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 1 | 6 | 1 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1003 |
| L0508 | 4 | 1 | Opponent | no | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 468 |
| L0524 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 180 |
| L0612 | 6 | 1 | Opponent | no | 6 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 1359 |
| L0628 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 414 |
| L0717 | 3 | 1 | Mine | no | 3 | - | 0 | 3 | 0 | 0 | 0 | 295 |
| L0717 | 3 | 1 | Opponent | yes | 9 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 550 |
| L0733 | 1 | 1 | Opponent | no | 0 | 4 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 417 |
| L0823 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 66 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 149 |
| L0913 | 1 | 1 | Opponent | no | 7 | 4 | 1 | 1 | 1 | 0 | 0 | 317 |
| L0930 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 45 |
| L0930 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 3 | 4 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1114 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 1 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 165 |
| L1131 | 3 | 1 | Opponent | no | 5 | - | 1 | 1 | 0 | 0 | 0 | 757 |
| L1224 | 6 | 1 | Mine | no | 7 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 8 | 3 | 0 | 1 | 0 | 0 | 0 | 205 |
| L1319 | 5 | 1 | Mine | no | - | 5 | 1 | 2 | 0 | 0 | 0 | 317 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 5 | 6 | 1 | 0 | 0 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 7 | 3 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | no | 11 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 5 | - | 1 | 1 | 1 | 0 | 0 | 958 |
| L1527 | 3 | 1 | Mine | yes | 1 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 1 | 6 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | - | 1 | 0 | 2 | 0 | 0 | 477 |
| L1723 | 1 | 1 | Opponent | no | 9 | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 1 | 1 | 0 | 0 | 0 | 185 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 245 |
| L2025 | 3 | 1 | Mine | no | 9 | - | 2 | 0 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 5 | - | 1 | 2 | 1 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 2 | 1 | 0 | 0 | 133 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 225 |
| L2231 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 1 | 0 | 0 | 340 |
| L2335 | 1 | 1 | Mine | no | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | - | 4 | 4 | 0 | 0 | 0 | 68 |
| L2531 | 5 | 1 | Opponent | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 3 | 3 | 0 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 18% | 2.8 | 3.2 | 1.3 | 1.5 | 0.1 | 0.0 | 0.0 | 238.5 |
| **Average** | | | Opponent | 21% | 3.2 | 2.7 | 2.4 | 2.1 | 0.3 | 0.0 | 0.0 | 178.9 |

### KPIs: fafix-mine-5e477c5-p1

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE; both sides: LIKELY CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (45 of 178) | 2% (4 of 169) | 14% (49 of 347) |
| Winner chose to follow up after the loser gave ground |  | 85% (39 of 46); on the table 89% | 100% (40 of 40); on the table 100% | 92% (79 of 86); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (15 of 18); on the table 94% | 92% (12 of 13); on the table 92% | 87% (27 of 31); on the table 94% |
| Winner chose to pursue after the loser fled |  | 62% (8 of 13); on the table 77% | 64% (16 of 25); on the table 76% | 63% (24 of 38); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 81% (62 of 77); on the table 88% | 87% (68 of 78); on the table 91% | 84% (130 of 155); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 40% (131 of 330) | 28% (59 of 210) | 35% (190 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (131 of 287) | 33% (53 of 162) | 41% (184 of 449) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 70% (21 of 30) | 62% (42 of 68) | 64% (63 of 98) |
| Points that never fought | lower | 48% (34352 of 71484) | 47% (34126 of 71889) | 48% (68478 of 143373) |
|   infantry points that never fought | lower | 54% (9171 of 16863) | 72% (9641 of 13348) | 62% (18812 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (167 of 279) | 57% (168 of 295) | 58% (335 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 100% (22 of 22); 1.9 uses a game | 85% (17 of 20); 1.5 uses a game | 93% (39 of 42); 1.7 uses a game |
| Bound items with another spell used |  | 38% (6 of 16); 0.4 uses a game | 12% (1 of 8); 0.1 uses a game | 29% (7 of 24); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 42% (8 of 19); 0.2 uses a game | 67% (8 of 12); 0.2 uses a game | 52% (16 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (33084 of 59666) | 52% (32748 of 62699) | 54% (65832 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.8 (50%) | 1.9 (45%) | 4.6 (48%) |
| MARCHED: its unit marched | 1.2 (23%) | 0.5 (13%) | 1.8 (18%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (2%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.7 (13%) | 0.4 (9%) | 1.1 (11%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| GONE: slain | 0.2 (5%) | 0.6 (15%) | 0.9 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (3%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.4 | 1.7 | 5.3 | 0.8 | 1.1 |
| not cast | 3.6 | 2.9 | 3.0 | 9.7 | 1.6 | 22.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.5 (51%) | 0.5 (16%) | 4.6 (48%) | 0.6 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (18%) | 0.2 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.1 (2%) | 0.3 (9%) | 1.1 (11%) | 0.2 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.4 (13%) | 0.6 (19%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.3 (9%) | 0.3 (11%) | 0.4 (13%) | 0.9 (9%) | 0.0 (2%) | 2.3 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.1 (4%) | 0.0 (1%) | 0.4 (4%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.4 (26%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.8 (79%) | 0.4 (14%) | 1.2 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.8 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.5 a game | 1.0 a game |
| stood (cast and not dispelled) | 61% (30 of 49) | 75% (12 of 16) | 65% (42 of 65) |
| the unit moved after it | 70% (21 of 30) | 83% (10 of 12) | 74% (31 of 42) |
| it charged on its next turn | 0% (0 of 30) | 0% (0 of 12) | 0% (0 of 42) |
| the enemy charged it first | 27% (8 of 30) | 0% (0 of 12) | 19% (8 of 42) |
| it fought by the end of its next turn | 17% (5 of 30) | 0% (0 of 12) | 12% (5 of 42) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (6 of 30) | 0% (0 of 12) | 14% (6 of 42) |
| none of these (no charge, no fight, no charge escaped) | 53% (16 of 30) | 100% (12 of 12) | 67% (28 of 42) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (584 of 914) | 62% (407 of 652) | 63% (991 of 1566) |
|   cavalry | 59% (47 of 80) | 71% (101 of 143) | 66% (148 of 223) |
|   character | 56% (72 of 128) | 40% (47 of 118) | 48% (119 of 246) |
|   chariot | 60% (56 of 94) | 59% (22 of 37) | 60% (78 of 131) |
|   infantry | 65% (196 of 303) | 63% (159 of 254) | 64% (355 of 557) |
|   monster | 68% (26 of 38) | 49% (17 of 35) | 59% (43 of 73) |
|   war machine | 69% (187 of 271) | 94% (61 of 65) | 74% (248 of 336) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (23%) | 1.5 (22%) | 3.6 (23%) |
| CHARGED: it charged | 0.6 (7%) | 1.3 (19%) | 1.9 (12%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.1 (2%) | 0.8 (5%) |
| MOVED: a war machine that moved | 1.4 (16%) | 0.0 (0%) | 1.4 (9%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| NO TARGET IN RANGE | 2.0 (22%) | 2.2 (33%) | 4.2 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.6 (9%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (12%) | 0.9 (13%) | 2.0 (13%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.9 | 1.2 | 83% | 3.1 pts | 18 pts |
| character | 3.9 | 1.1 | 83% | 7.0 pts | 27 pts |
| chariot | 2.2 | 1.5 | 64% | 16.8 pts | 37 pts |
| infantry | 14.5 | 4.4 | 77% | 8.5 pts | 123 pts |
| monster | 1.4 | 0.4 | 76% | 8.3 pts | 11 pts |
| war machine | 6.9 | 5.5 | 63% | 25.2 pts | 174 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.2 | 5.1 | 3.6 |
| Charges that made contact a game | 1.7 | 3.5 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.48 declared, 0.38 contact (21 units) | 0.43 declared, 0.36 contact (14 units) | 0.46 declared, 0.37 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.20 declared, 0.20 contact (5 units) | 1.30 declared, 0.90 contact (10 units) | 0.93 declared, 0.67 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.26 declared, 0.20 contact (260 units) | 0.58 declared, 0.40 contact (282 units) | 0.42 declared, 0.30 contact (542 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 51% (36 of 70) | 67% (14 of 21) | 38% (3 of 8) | 54% (53 of 99) |
| Character in a unit | 83% (39 of 47) | 67% (18 of 27) | 67% (2 of 3) | 77% (59 of 77) |
| Character on its own | 90% (36 of 40) | 58% (19 of 33) | 30% (19 of 63) | 54% (74 of 136) |
| Chariot | 69% (11 of 16) | 80% (8 of 10) | - | 73% (19 of 26) |
| Infantry | 46% (41 of 89) | 36% (13 of 36) | 50% (1 of 2) | 43% (55 of 127) |
| Monster | 62% (20 of 32) | 60% (6 of 10) | - | 62% (26 of 42) |
| Monstrous | 82% (9 of 11) | 79% (11 of 14) | - | 80% (20 of 25) |
| War Machines | 68% (28 of 41) | 100% (1 of 1) | - | 69% (29 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 75% (6 of 8); on the table 75% | 40% (55 of 138) | 57% | 58% (19 of 33) | 100% (9 of 9); 6.2 uses a game | 100% (3 of 3); 1.8 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 71% (5 of 7); on the table 71% | 42% (10 of 24) | 31% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 77% (10 of 13); on the table 77% | - | 56% | 78% (32 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (2 of 2); on the table 100% | 42% (15 of 36) | 65% | 67% (43 of 64) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 54% (7 of 13); on the table 77% | 43% (46 of 108) | 53% | 50% (22 of 44) | 100% (12 of 12); 6.4 uses a game | 100% (1 of 1); 0.2 uses a game | 0% (0 of 5); 0.0 uses a game |
| High Elf Realms | 6 | 89% (16 of 18); on the table 100% | 23% (7 of 30) | 58% | 47% (23 of 49) | 100% (5 of 5); 2.5 uses a game | 17% (3 of 18); 0.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 90% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 50% (1 of 2); on the table 50% | - | 38% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 50% (1 of 2); on the table 100% | 8% (1 of 12) | 65% | 76% (16 of 21) | 100% (3 of 3); 2.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (7 of 7); on the table 100% | 17% (6 of 36) | 12% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 83% (15 of 18); on the table 94% | 33% (10 of 30) | 35% | 41% (14 of 34) | 100% (3 of 3); 2.2 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 95% (21 of 22); on the table 100% | 8% (1 of 12) | 30% | 27% (8 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (18 of 18); on the table 100% | 39% (21 of 54) | 48% | 60% (30 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 78% (14 of 18); on the table 78% | 23% (7 of 30) | 40% | 69% (51 of 74) | 100% (4 of 4); 1.9 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (7 of 7); on the table 100% | 37% (11 of 30) | 50% | 55% (36 of 66) | 50% (3 of 6); 1.7 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (fafix-mine-5e477c5-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 62% (47) | 47% (21) | 56% (68) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.28 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.14 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.22 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 1.03 | 1.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 1.11 | 1.11 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 4.42 | 4.53 |

### Quality by phase: fafix-mine-5e477c5-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 52% (35 of 67) | 48% (77 of 159) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (152 of 339) | 48% (117 of 244) |
| Strategy | Close-in objectives charged next turn | - | 15% (40 of 272) |
| Strategy | Support requests answered (helper made contact too) | 40% (2 of 5) | 50% (7 of 14) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 50% (2 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 45% (5 of 11) | 42% (5 of 12) |
| Strategy | Joined characters whose unit fought | 38% (26 of 68) | 27% (12 of 44) |
| Strategy | Lone characters that fought | 53% (41 of 78) | 70% (64 of 92) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.5 | 2.1 |
| Movement | Points that never moved of their own | 238.5 | 178.9 |
| Movement | Fights charged into per game | 1.5 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 47, net +149 | 16 of 102, net +17 |
| Movement | Charges with odds: sweet spot (55-75%) | 7 of 47, net +68 | 18 of 102, net +81 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 47, net +457 | 7 of 102, net +142 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 of 47, net +125 | 28 of 102, net +84 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.8 | 10.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (197 of 425) | 44% (166 of 380) |
| Shooting | Points destroyed by shooting units | 51.3 | 11.9 |
| Shooting | War machine shots | 5.2 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (107 of 187) | 38% (23 of 61) |
| Shooting | Points destroyed by war machines | 71.6 | 16.3 |
| Magic | Magic missiles cast | 2.4 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (35 of 88) | 24% (10 of 41) |
| Magic | Wounds caused by magic missiles | 5.2 | 1.5 |
| Magic | Wounds caused by other spells | 1.1 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 90.1 | 37.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.4 / 0.6 / 0.2 | 1.7 / 0.4 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 246.4 | 326.0 |
| Combat | Points run down | 20.6 | 70.6 |
| Combat | Net points per charged fight, damage counted | +90 | +65 |
| Combat | Net per 100 charger points, damage counted | +30.4 | +24.0 |
| Combat | First round won (charged fights) | 72% | 77% |
| Combat | Net points per charged fight | +77 | +65 |
| Combat | Net points per supported fight / lone fight | +247 / +60 | +125 / +59 |
| Combat | Charged fights on a top-3 enemy unit | 24 of 54 | 43 of 115 |
| Game | Points lost | 606.4 | 542.2 |
| Game | VP from objectives | 576.7 | 714.4 |
| Game | Lone holders (player turns) | 2.8 | 3.2 |

- Mine won / drew / lost: 13 / 5 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -172 VP
- The side that went first won 12 of 31 games with a winner
- Points traded per game (both sides' losses): 1149
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fafix-mine-5e477c5-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 5.1 | -225.4 | 146.2 | 49.3 |
| AFTERMATH IN POINTS | 0.2 | +16.5 | 0.0 | 15.1 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 15.7 | 0.4 | +0.0 | 0.0 | 5.3 |
| BACKUP TARGETS | 0.3 | +1.6 | 0.0 | 4.2 | 0.4 | +4.1 | 0.0 | 7.2 |
| BEST FACING | - | - | - | - | 0.3 | +9.2 | 0.0 | 7.0 |
| BEST FIRST | - | - | - | - | 1.2 | +61.6 | 17.8 | 27.0 |
| BEST OVERALL | - | - | - | - | 0.3 | +16.3 | 0.0 | 10.0 |
| BEST PREY | - | - | - | - | 0.9 | +36.4 | 22.5 | 12.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -1.0 | 2.8 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.2 | -2.7 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.4 | +18.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -26.9 | 12.6 | 8.6 | 0.2 | -22.6 | 26.7 | 5.4 |
| BOMBING RUN | 0.1 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.4 | +0.0 | 57.6 | 7.2 | 0.2 | +0.0 | 6.8 | 3.6 |
| CANNON PLANNED TARGET | 4.0 | +176.0 | 279.2 | 79.2 | 1.3 | +30.7 | 49.5 | 14.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 6.1 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.1 | 8.1 | 0.0 | 0.1 | -1.4 | 19.9 | 8.0 |
| CAST JOB | 0.4 | +13.2 | 16.5 | 25.8 | 0.6 | +4.0 | 4.7 | 7.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +66.6 | 27.4 | 0.0 | 0.2 | +6.0 | 1.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 11.1 | 0.4 | +0.0 | 0.0 | 13.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +10.4 | 0.0 | 3.9 | 2.1 | +122.3 | 0.0 | 30.6 |
| CHAFF PASSED | 0.2 | -0.1 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.2 | -661.1 | 0.0 | 333.1 | - | - | - | - |
| CHARGE NOW FIRST | 1.0 | +0.0 | 102.4 | 47.3 | 2.1 | +0.0 | 205.2 | 61.2 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.7 | -49.9 | 23.4 | 19.0 |
| CHARGER SLAIN LOST | 0.2 | -26.3 | 24.8 | 11.7 | 0.6 | -13.2 | 58.6 | 10.0 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | +0.0 | 10.2 | 15.0 |
| CHEAP HELPER | 0.0 | +0.0 | 15.1 | 1.7 | 0.1 | +0.0 | 8.6 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 19.8 | 36.5 | 0.3 | +0.0 | 2.1 | 4.7 |
| CONVEYANCE SEARCH | 1.0 | +90.8 | 22.2 | 22.2 | 0.2 | +38.5 | 5.9 | 21.1 |
| COVER ONCE | 7.4 | -645.1 | 0.0 | 173.0 | 5.3 | -322.3 | 0.0 | 130.6 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 9.8 | 2.9 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +2.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +2.8 | 8.2 | 1.2 | 0.5 | +21.5 | 55.7 | 25.4 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.0 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 1.0 | +75.9 | 0.0 | 25.0 |
| FALL BACK GOOD ORDER | 1.1 | +10.5 | 66.2 | 55.0 | - | - | - | - |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 1.5 | 5.9 | +55.7 | 0.0 | 54.1 |
| FALLS SHORT | 0.3 | -2.6 | 12.5 | 18.6 | - | - | - | - |
| FEATURE BUFFS | 1.2 | +33.4 | 0.0 | 15.9 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.0 | 0.0 | 2.2 | - | - | - | - |
| FIVE ACTION | 45.5 | +1730.5 | 801.8 | 754.1 | - | - | - | - |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 172.1 | 3.5 | +0.0 | 0.0 | 33.1 |
| FOLLOW UP WEIGHED | 0.9 | +160.5 | 0.0 | 15.8 | 1.0 | +95.6 | 0.0 | 11.1 |
| FOUR ROUNDS | 1.8 | +181.0 | 163.5 | 56.4 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +5.8 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.6 | 0.0 | 0.0 | 0.1 | -1.8 | 24.4 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.6 | 2.8 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.1 | +2.2 | 0.0 | 3.2 |
| GUN MASK | 0.8 | +6.7 | 0.0 | 12.1 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 8.4 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 7.0 | 6.4 | 0.2 | +0.0 | 10.8 | 14.3 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -15.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.6 | -64.8 | 120.7 | 38.3 | 10.6 | -205.4 | 535.9 | 192.3 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +6.1 | 3.6 | 6.1 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +13.1 | 0.0 | 10.2 | 0.6 | +29.8 | 0.0 | 5.4 |
| HUNT KEPT | - | - | - | - | 0.2 | +0.1 | 3.8 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.2 | +17.0 | 0.0 | 3.2 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +56.3 | 10.1 | 6.1 |
| IDLE COST | 17.1 | -276.6 | 0.0 | 173.8 | 19.7 | -305.6 | 0.0 | 209.0 |
| INVITES THE FIGHT | - | - | - | - | 1.5 | +8.2 | 63.5 | 15.4 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +2.0 | 4.6 | 6.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -1.0 | 0.0 | 6.4 | 0.1 | -1.3 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.5 | 0.0 | 4.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.6 | +76.7 | 151.5 | 51.7 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 2.0 | +91.3 | 232.6 | 31.2 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.8 | +269.6 | 253.7 | 164.5 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +23.1 | 0.0 | 15.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 0.0 | 5.9 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +0.4 | 0.0 | 7.1 | 0.5 | +1.9 | 20.1 | 0.0 |
| LOST CHARGE | 0.1 | -0.3 | 19.2 | 0.0 | 2.6 | -39.8 | 48.4 | 64.4 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.5 | 0.0 | 1.5 | 0.2 | -21.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +1.8 | 0.0 | 0.0 | 0.7 | +20.1 | 11.8 | 42.3 |
| MANOEUVRE | 0.9 | +31.8 | 0.0 | 24.9 | 0.3 | +9.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.1 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 5.6 |
| MARCH CHECK | 0.8 | +36.6 | 0.0 | 16.8 | 0.6 | +24.2 | 0.0 | 13.9 |
| MARCH ODDS | - | - | - | - | 0.2 | +10.6 | 4.6 | 0.0 |
| MARCH OVER CASTS | 0.7 | +111.9 | 0.0 | 22.4 | 0.3 | +29.4 | 0.0 | 5.6 |
| MAX FOR POSITIONING | 5.9 | +121.5 | 0.0 | 124.2 | 6.4 | +65.2 | 0.0 | 110.8 |
| MISSILES IN THE MOVE | 4.8 | +230.3 | 0.0 | 116.1 | 4.1 | +48.2 | 0.0 | 48.7 |
| MISSILES NEXT TURN | 5.7 | +147.8 | 0.0 | 126.4 | 4.7 | +41.0 | 0.0 | 47.3 |
| MODEL FACING | 0.2 | +68.6 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.2 | +0.0 | 0.0 | 13.9 |
| MOVE AND CAST | - | - | - | - | 0.3 | +13.4 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -107.8 | 0.0 | 0.0 | 0.1 | -1.8 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 11.1 | 0.2 | +0.0 | 0.0 | 13.9 |
| MOVE TO CHARGE | - | - | - | - | 5.6 | +372.4 | 143.2 | 126.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +2.1 | 0.0 | 0.0 | 0.1 | +3.4 | 5.8 | 0.0 |
| NEXT CHARGE BY LIST | 13.9 | -261.7 | 102.7 | 245.2 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 4.8 | -265.3 | 76.2 | 63.3 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.3 | -79.2 | 104.4 | 50.0 | - | - | - | - |
| NO RALLY LEFT | - | - | - | - | 0.0 | +7.9 | 0.0 | 0.0 |
| NOT NEEDED | - | - | - | - | 0.4 | -21.0 | 61.4 | 6.4 |
| NOT TURNED | 0.1 | -0.1 | 0.0 | 3.9 | 4.4 | +79.0 | 0.0 | 63.1 |
| NOT WORTH A CAST | 1.4 | -2.4 | 0.0 | 21.1 | 0.4 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 1.6 | -39.8 | 0.0 | 9.1 | 17.2 | -840.5 | 0.0 | 208.1 |
| ONE FIGHT FORMULA | 6.6 | -142.9 | 0.0 | 142.0 | 9.5 | -179.4 | 55.5 | 208.2 |
| ONE OBJECTIVE FORMULA | 3.0 | -13.4 | 0.0 | 62.3 | 2.3 | -55.3 | 0.0 | 14.5 |
| OPENS A LANE | 0.1 | +0.7 | 1.5 | 0.0 | 0.1 | +0.7 | 8.7 | 0.0 |
| OPENS UP | 0.1 | +8.0 | 5.6 | 0.0 | 0.3 | +21.0 | 13.6 | 16.4 |
| OVERRUNS AWAY | 0.3 | +8.2 | 29.0 | 21.4 | 0.6 | +7.1 | 50.1 | 4.9 |
| PATHS CROSS | 2.3 | +181.0 | 0.0 | 29.2 | 2.9 | +232.7 | 0.0 | 68.5 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.9 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.7 | 0.0 | 0.0 | 0.2 | -2.5 | 0.0 | 0.0 |
| PLAN RESULT | 40.4 | +776.2 | 570.5 | 895.3 | 40.8 | +954.7 | 1134.1 | 737.1 |
| PURSUES BIG PREY | 0.1 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +5.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +36.4 | 0.0 | 23.3 | 1.9 | +25.4 | 0.0 | 32.8 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.3 | -7.7 | 8.4 | 9.4 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +0.1 | 0.0 | 2.4 | 1.5 | -34.0 | 0.0 | 26.1 |
| REDIRECT COUNTER | 1.9 | +116.6 | 0.0 | 51.4 | 3.6 | +231.0 | 0.0 | 34.8 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.6 | +5.7 | 7.7 | 12.9 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.6 | +16.2 | 0.0 | 10.9 | 0.7 | +29.1 | 0.0 | 10.4 |
| RESTRAINS TO SHOOT | 0.0 | +1.1 | 0.0 | 0.0 | 0.1 | +5.1 | 0.0 | 0.0 |
| RISK BY ARC | 1.1 | +12.1 | 77.1 | 41.4 | 2.5 | +70.8 | 240.2 | 95.1 |
| RISK ONCE | - | - | - | - | 5.6 | +396.7 | 71.5 | 268.4 |
| RUN DOWN | 1.2 | -13.9 | 72.0 | 23.3 | - | - | - | - |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.5 | 1.5 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 1.1 | +39.7 | 0.0 | 8.3 |
| SCALED CHANCE | 3.7 | +41.9 | 15.8 | 92.7 | - | - | - | - |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 1.5 | 0.3 | +0.6 | 0.0 | 1.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 1.5 | 0.3 | +0.0 | 0.0 | 1.9 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -13.3 | 0.0 | 1.5 |
| SEARCH SPOT | 6.4 | +270.9 | 0.0 | 109.6 | 2.5 | +115.5 | 0.0 | 22.9 |
| SELF MOVE SPELL | 0.3 | +4.8 | 0.0 | 0.0 | 0.2 | +13.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.2 | +2.0 | 0.0 | 0.0 | 1.8 | +104.2 | 31.1 | 65.9 |
| SET-UP ANY TARGET | 0.1 | +14.9 | 0.0 | 0.0 | 0.1 | +4.9 | 0.0 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +60.4 | 41.4 | 7.5 | 1.4 | +34.2 | 33.2 | 6.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 6.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 112.8 | 9.4 | 0.3 | +0.0 | 23.5 | 7.4 |
| SHOTS IN THE MOVE | 16.2 | +687.0 | 0.0 | 211.2 | 10.4 | +263.0 | 0.0 | 57.0 |
| SPELL SETS UP CHARGE | 0.2 | +28.6 | 0.0 | 0.0 | 0.1 | +21.6 | 0.0 | 7.6 |
| SPELL WORTH | 1.2 | +14.7 | 37.4 | 33.5 | 1.7 | +45.3 | 51.4 | 51.4 |
| SPELLS IN THE FIGHT | 0.2 | +3.3 | 30.4 | 10.2 | 0.3 | -6.2 | 29.9 | 5.2 |
| STABLE ROLE | - | - | - | - | 12.5 | +0.0 | 334.4 | 136.7 |
| STAND AND SHOOT | 0.1 | -1.9 | 6.2 | 7.1 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.1 | +0.9 | 0.0 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.1 | +1.4 | 10.3 | 0.0 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.4 | +10.7 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.6 | +0.0 | 50.7 | 15.7 | 6.9 | -51.3 | 326.0 | 81.8 |
| SUPPORTS | - | - | - | - | 4.9 | +51.4 | 163.4 | 35.6 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -1.4 | 3.4 | 1.9 |
| SURE REACH TOGETHER | 0.4 | +3.5 | 0.0 | 0.0 | 0.8 | -0.2 | 18.5 | 29.6 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.2 | +14.9 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 3.7 | +0.0 | 23.1 | 41.1 | - | - | - | - |
| TURN WORTH | 0.1 | -4.0 | 4.0 | 0.0 | 0.2 | -13.6 | 8.4 | 16.4 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.4 | +3.6 | 9.6 | 3.2 |
| WAIT AFTER COSTS | - | - | - | - | 9.9 | -487.8 | 329.0 | 171.6 |
| WALKS TO THE FIGHT | - | - | - | - | 1.5 | +12.1 | 35.0 | 18.9 |
| WAR ENGINE CHARGES | 0.1 | +27.7 | 15.0 | 8.6 | 0.1 | +4.1 | 2.2 | 7.2 |
| WAR ENGINE JOBS | 0.1 | +0.0 | 20.9 | 0.0 | 0.2 | +0.0 | 0.0 | 4.2 |
| WEARS DOWN | - | - | - | - | 1.1 | +30.7 | 70.8 | 46.7 |
| WHO HITS BACK | 0.2 | +22.2 | 0.0 | 0.0 | 0.1 | +4.4 | 0.0 | 8.2 |
| WHOLE FIGHT | 0.4 | +2.8 | 56.8 | 8.6 | 0.2 | +4.2 | 19.7 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +2.6 | 2.7 | 6.4 | 0.3 | +19.2 | 46.4 | 5.0 |
| WIDER SPREAD | 1.4 | -8.6 | 144.6 | 39.9 | 3.1 | -4.2 | 301.4 | 61.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: fafix-mine-5e477c5-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 676 | 676 | 676 | 18.78 | -31693 | -46.9 |
| SEARCH SPOT | 322 | 322 | 314 | 8.72 | +13942 | +44.4 |
| PATHS CROSS | 188 | 188 | 188 | 5.22 | +14892 | +79.2 |
| MOVE TO CHARGE | 202 | 202 | 123 | 3.42 | +4588 | +37.3 |
| SHOTS IN THE MOVE | 959 | 807 | 108 | 3.00 | +2556 | +23.7 |
| IDLE COST | 1322 | 778 | 104 | 2.89 | +726 | +7.0 |
| KILLS COUNT NEXT TURN | 279 | 279 | 82 | 2.28 | +2132 | +26.0 |
| FIVE ACTION | 1638 | 1637 | 74 | 2.06 | +2313 | +31.3 |
| COVER ONCE | 456 | 299 | 70 | 1.94 | +1580 | +22.6 |
| MAX FOR POSITIONING | 444 | 333 | 70 | 1.94 | +462 | +6.6 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +9220 | +133.6 |
| SUPPORTS | 175 | 175 | 69 | 1.92 | +686 | +9.9 |
| CHARGE LOSSES | 366 | 366 | 68 | 1.89 | +4758 | +70.0 |
| WAIT AFTER COSTS | 356 | 356 | 68 | 1.89 | +1490 | +21.9 |
| RANDOM MOVE BY FIGURES | 98 | 98 | 63 | 1.75 | +2227 | +35.3 |
| FALLBACK BY WORTH | 215 | 215 | 61 | 1.69 | +2007 | +32.9 |
| MISSILES IN THE MOVE | 322 | 236 | 60 | 1.67 | +1786 | +29.8 |
| RISK ONCE | 203 | 160 | 59 | 1.64 | +3531 | +59.9 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 84 | 84 | 50 | 1.39 | +502 | +10.0 |
| CHAFF IN THE MOVE | 82 | 74 | 48 | 1.33 | +1301 | +27.1 |
| MARCH CHECK | 50 | 50 | 48 | 1.33 | +1838 | +38.3 |
| NEXT CHARGE BY LIST | 500 | 500 | 48 | 1.33 | +654 | +13.6 |
| RESERVE FALL BACK | 47 | 47 | 47 | 1.31 | +1630 | +34.7 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| ONE FIGHT FORMULA | 582 | 389 | 45 | 1.25 | +281 | +6.2 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| REDIRECT COUNTER | 200 | 113 | 44 | 1.22 | +3495 | +79.4 |
| BEST FIRST | 42 | 42 | 42 | 1.17 | +2217 | +52.8 |
| SAFER THAN THE JOB | 40 | 40 | 40 | 1.11 | +1428 | +35.7 |
| FACES THE THREAT | 37 | 37 | 37 | 1.03 | +2733 | +73.9 |
| ADVANCE WORTH | 183 | 183 | 35 | 0.97 | +346 | +9.9 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| MANOEUVRE | 44 | 44 | 34 | 0.94 | +1527 | +44.9 |
| CANNON PLANNED TARGET | 192 | 192 | 33 | 0.92 | -260 | -7.9 |
| SHOT REPLANNED | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| SET UP TOGETHER | 70 | 61 | 29 | 0.81 | +1034 | +35.6 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| FOUR ROUNDS | 65 | 64 | 26 | 0.72 | +2579 | +99.2 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| REDIRECT WEIGHED | 25 | 25 | 25 | 0.69 | +654 | +26.2 |
| CHARGE NOW WEIGHED | 24 | 24 | 24 | 0.67 | +1304 | +54.3 |
| RISK BY ARC | 129 | 127 | 24 | 0.67 | +890 | +37.1 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| WALKS TO THE FIGHT | 54 | 54 | 24 | 0.67 | +104 | +4.3 |
| CHARGE NOW FIRST | 110 | 110 | 22 | 0.61 | -1441 | -65.5 |
| HONEST WORTH | 438 | 435 | 22 | 0.61 | +202 | +9.2 |
| INVITES THE FIGHT | 54 | 54 | 22 | 0.61 | +96 | +4.4 |
| KEEPS ITS TARGET | 92 | 92 | 21 | 0.58 | +420 | +20.0 |
| KILLS COUNT | 73 | 73 | 20 | 0.56 | +1111 | +55.5 |
| CASTING BLOCK | 25 | 25 | 19 | 0.53 | +446 | +23.5 |
| CAST JOB | 36 | 36 | 17 | 0.47 | +173 | +10.2 |
| ONE OBJECTIVE FORMULA | 191 | 129 | 17 | 0.47 | +441 | +25.9 |
| BLOCKED WHEEL | 16 | 16 | 16 | 0.44 | +647 | +40.4 |
| NEXT OBJECTIVE NEARER | 173 | 173 | 16 | 0.44 | +201 | +12.6 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| FEATURE BUFFS | 45 | 45 | 14 | 0.39 | +218 | +15.6 |
| MISSILES NEXT TURN | 373 | 261 | 14 | 0.39 | +46 | +3.3 |
| BEST PREY | 31 | 31 | 13 | 0.36 | +431 | +33.1 |
| OPENS UP | 15 | 15 | 13 | 0.36 | +441 | +33.9 |
| STOPS SHORT OF THE FLANK | 13 | 13 | 13 | 0.36 | +386 | +29.7 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| BEST OVERALL | 11 | 11 | 11 | 0.31 | +588 | +53.5 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -13 | -1.2 |
| MOVE AND CAST | 11 | 11 | 11 | 0.31 | +481 | +43.7 |
| SURE REACH TOGETHER | 43 | 36 | 11 | 0.31 | +18 | +1.6 |
| WHO HITS BACK | 11 | 11 | 11 | 0.31 | +854 | +77.6 |
| BEST FACING | 10 | 10 | 10 | 0.28 | +330 | +33.0 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -187 | -18.7 |
| SCALED CHANCE | 134 | 134 | 10 | 0.28 | +73 | +7.3 |
| HUNT IN PAIRS | 34 | 28 | 9 | 0.25 | +376 | +41.8 |
| MARCH ODDS | 9 | 9 | 9 | 0.25 | +140 | +15.6 |
| LOST CHARGE | 99 | 99 | 8 | 0.22 | +158 | +19.7 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +2468 | +308.5 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 267 | 267 | 8 | 0.22 | -177 | -22.1 |
| THROUGH LINE OF FIRE | 8 | 8 | 8 | 0.22 | +538 | +67.2 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | -97 | -13.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| WEARS DOWN | 40 | 38 | 7 | 0.19 | +166 | +23.7 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.17 | +595 | +99.2 |
| EDGE GIVE GROUND | 20 | 19 | 6 | 0.17 | +351 | +58.5 |
| WHOLE FIGHT | 22 | 20 | 6 | 0.17 | +83 | +13.8 |
| WHOLE FIGHT GAIN | 15 | 14 | 6 | 0.17 | +243 | +40.4 |
| MAKE SURE TOGETHER | 32 | 21 | 5 | 0.14 | +194 | +38.7 |
| REFUSING RETIRES | 13 | 13 | 5 | 0.14 | -2 | -0.3 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.11 | +256 | +63.9 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +207 | +51.8 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +221 | +55.3 |
| WAR ENGINE JOBS | 11 | 11 | 4 | 0.11 | -112 | -28.1 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -207 | -69.0 |
| HUNT ADVANCE | 5 | 5 | 3 | 0.08 | +100 | +33.4 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| OVERRUNS AWAY | 31 | 30 | 3 | 0.08 | +35 | +11.8 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -50 | -16.7 |
| WIDER SPREAD | 163 | 159 | 3 | 0.08 | +15 | +5.1 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +62 | +30.9 |
| CARRIES OUT SET-UP | 7 | 7 | 2 | 0.06 | -54 | -27.1 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -3 | -1.5 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +34 | +17.2 |
| FALL BACK GOOD ORDER | 41 | 40 | 2 | 0.06 | +82 | +41.0 |
| GUN MASK | 28 | 28 | 2 | 0.06 | +58 | +29.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +178 | +88.9 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -98 | -49.2 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +134 | +66.8 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -3 | -1.4 |
| STOPS | 4 | 4 | 2 | 0.06 | +27 | +13.4 |
| WAR ENGINE CHARGES | 6 | 6 | 2 | 0.06 | +373 | +186.4 |
| BACKUP TARGETS | 28 | 18 | 1 | 0.03 | -0 | -0.1 |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 1 | 0.03 | +1 | +0.6 |
| CHARGER SLAIN LOST | 26 | 24 | 1 | 0.03 | +10 | +9.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +1 | +1.3 |
| LONG SHOT | 22 | 22 | 1 | 0.03 | +39 | +39.1 |
| NO DOUBLE ROUNDS | 46 | 46 | 1 | 0.03 | +92 | +92.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +254 | +253.6 |
| OPENS A LANE | 9 | 8 | 1 | 0.03 | +8 | +7.5 |
| REDIRECT BY WHAT IT STOPS | 61 | 61 | 1 | 0.03 | +8 | +8.3 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -53 | -53.2 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +13 | +12.6 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +18 | +17.9 |
| TWO OR MORE ARRIVE | 16 | 15 | 1 | 0.03 | +5 | +5.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 13 | 13 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 22 | 22 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 46 | trace | - | - | - | - |
| CHARACTER GUNS | 21 | 21 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 42 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FALLS SHORT | 12 | 12 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 315 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 13 | 11 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 5 | 5 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 37 | 37 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 20 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 163 | 163 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 64 | not checked | - | - | - | - |
| PLAN RESULT | 2923 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 10 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 42 | 41 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 10 | not checked | - | - | - | - |
| SPELL WORTH | 105 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 19 | 18 | 0 | 0.00 | - | - |
| STABLE ROLE | 451 | 450 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 134 | 134 | 0 | 0.00 | - | - |
| TURN WORTH | 8 | 8 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: fafix-mine-5e477c5-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.36 | 15.86 | 48.9 |
| FALLBACK | gate | - | 0.67 | 38.6 |
| CHARGE NOW FIRST | rule | 0.19 | 0.39 | 68.6 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.19 | 18.7 |
| TURN GATE | gate | 0.03 | 0.25 | 11.0 |
| SUPPORT NARROWED | rule | 0.06 | 0.17 | 22.1 |
| RULE SWITCHED OFF | gate | 0.17 | 0.03 | 23.2 |
| BIG CHARACTER SAFETY | rule | - | 0.17 | 17.4 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.03 | 52.5 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.17 | 8.7 |
| SAFER THAN THE JOB | rule | - | 0.14 | 20.3 |
| AFTERMATH BAND | gate | 0.03 | 0.08 | 1.4 |
| CHAFF PASSED | rule | 0.06 | 0.06 | 3.2 |
| WAR ENGINE JOBS | rule | 0.06 | 0.06 | 28.1 |
| BEST PRIZE | rule | - | 0.08 | 69.0 |
| PATHS CROSS | rule | 0.03 | 0.06 | 31.4 |
| SUPPORT REQUEST | gate | - | 0.08 | 34.2 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.08 | 16.7 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 27.1 |
| CHARGE NOW WEIGHED | rule | - | 0.06 | 15.7 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 1.4 |
| PURSUES BIG PREY | rule | 0.06 | - | 49.2 |
| REDIRECT WEIGHED | rule | - | 0.06 | 100.9 |
| BLOCKED WHEEL | rule | - | 0.03 | 14.6 |
| CATCH ODDS | rule | - | 0.03 | 2.4 |
| SAFE SURE CHARGE | rule | - | 0.03 | 53.2 |
| STANDS TO CAST | rule | - | 0.03 | 3.2 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 2.7 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 35.2 |

### Plans: fafix-mine-5e477c5-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.2 | 58% | 217 | 151 | 70% |
| Mine | join | 0.5 | 100% | 24 | 0 | 0% |
| Mine | move | 30.6 | 93% | 1163 | 0 | 0% |
| Mine | shoot | 7.9 | 57% | 439 | 625 | 142% |
| Mine | support | 0.2 | 67% | 3 | 0 | 0% |
| Opponent | advance | 12.2 | 15% | 160 | 272 | 169% |
| Opponent | charge | 3.2 | 69% | 272 | 299 | 110% |
| Opponent | close in | 7.6 | 24% | 423 | 184 | 44% |
| Opponent | hold | 4.9 | 46% | 371 | 0 | 0% |
| Opponent | join | 1.1 | 100% | 52 | 0 | 0% |
| Opponent | shoot | 5.3 | 51% | 118 | 205 | 173% |
| Opponent | support | 6.5 | 93% | 47 | 0 | 0% |

### Packages: hunt the guns, fafix-mine-5e477c5-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Opponent | 0.2 | 8 | 2 | 33% | 50% | 0% | 2.3 | 258 | 102 | 50% | 80 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 107 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 130 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 74 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 35 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 33% | 67% | 0% | 2.5 | 208 | 147 | 67% | 12 |
| Vampire Counts | 0.2 | 2 | 1 | 100% | 100% | 0% | 2.0 | 210 | 173 | 100% | 0 |
| Warriors of Chaos | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 388 | 0 | 0% | 97 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 39 |

### Battle groups: fafix-mine-5e477c5-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 39% | 63% | 7% | 100% | 16% | 0% | 8% | 72% | 4% |
| Opponent | REDIRECT COUNTER | 3.6 | 12% | 62% | 44% | 43% | 22% | 0% | 0% | 67% | 11% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fafix-mine-5e477c5-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 81 | 33% | 4.5 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 37 | 5 (37) | 0 | 5 | 50 | 51% | 2.1 | 0 (16) | 0 (9) | 16 (12) | 3 (24) | 10 (13) |
| Mine | Character | 123 | 34 (123) | 34 | 0 | 27 | 29% | 2.4 | 36 (37) | 38 (62) | 16 (14) | 34 (59) | 36 (54) |
| Mine | Clean-up | 24 | 73 (24) | 29 | 44 | 17 | 46% | 3.8 | 62 (9) | 88 (11) | 71 (4) | 113 (14) | 25 (10) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 47 | 25% | 1.7 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 41 | 20 (41) | 12 | 8 | 42 | 34% | 2.9 | 20 (18) | 32 (12) | 8 (11) | 20 (28) | 20 (13) |
| Mine | Fragile | 5 | 28 (5) | 28 | 0 | 60 | 0% | 1.8 | - | 17 (4) | 69 (1) | 69 (1) | 17 (4) |
| Mine | Hammer | 58 | 32 (58) | 19 | 13 | 34 | 19% | 2.6 | 20 (10) | 36 (38) | 25 (10) | 34 (34) | 29 (24) |
| Mine | Holder | 25 | 85 (25) | 0 | 85 | 30 | 48% | 3.8 | 92 (8) | 87 (12) | 69 (5) | 91 (12) | 80 (13) |
| Mine | Shooter | 44 | 86 (44) | 35 | 51 | 27 | 2% | 1.8 | 17 (5) | 111 (31) | 57 (8) | 129 (23) | 44 (21) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 58 | 0% | 3.6 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 44 (56) | 44 | 0 | 51 | 5% | 1.4 | 29 (13) | 39 (37) | 105 (6) | 47 (11) | 43 (45) |
| Mine | Wizard | 23 | 16 (23) | 16 | 0 | 9 | 26% | 2.0 | 20 (8) | 6 (10) | 0 (3) | 44 (4) | 3 (17) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 66 | 64 (66) | 7 | 57 | 34 | 42% | 3.3 | 102 (28) | 66 (16) | 15 (22) | 84 (48) | 7 (18) |
| Opponent | Character | 114 | 44 (114) | 44 | 0 | 22 | 28% | 2.9 | 62 (39) | 35 (60) | 68 (7) | 51 (70) | 40 (36) |
| Opponent | Clean-up | 16 | 24 (16) | 24 | 0 | 41 | 56% | 3.3 | 13 (5) | 21 (8) | 51 (3) | 50 (8) | 5 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 41 (58) | 22 | 19 | 52 | 31% | 2.9 | 30 (25) | 43 (19) | 63 (14) | 47 (42) | 25 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 55 | 80% | 2.0 | 0 (3) | 0 (3) | 0 (3) | 0 (9) | - |
| Opponent | Hammer | 65 | 36 (65) | 22 | 14 | 26 | 31% | 3.0 | 11 (16) | 45 (42) | 30 (7) | 38 (40) | 34 (25) |
| Opponent | Holder | 40 | 79 (40) | 16 | 62 | 7 | 58% | 2.9 | 10 (10) | 101 (23) | 92 (7) | 112 (18) | 49 (22) |
| Opponent | Shooter | 30 | 65 (30) | 4 | 62 | 25 | 7% | 1.4 | 47 (7) | 70 (18) | 74 (5) | 60 (16) | 73 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 45 (13) | 45 | 0 | 40 | 0% | 1.1 | 17 (5) | 45 (5) | 95 (3) | 67 (3) | 39 (10) |
| Opponent | Wizard | 22 | 9 (22) | 9 | 0 | 45 | 27% | 1.6 | 21 (9) | 0 (6) | 0 (3) | 20 (8) | 0 (10) |

### Charged fights: fafix-mine-5e477c5-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 228 | 23 | 0.4 | 1.0 | 57 | 26 | +31 | 0 of 2 | 1 of 2 | - | +31 |
| Mine | Chaos Dwarfs | 3 | 131 | 634 | 3.0 | 1.0 | 211 | 0 | +211 | 7 of 9 | 6 of 9 | - | +211 |
| Mine | Dwarfen Mountain Holds | 4 | 348 | 0 | 0.2 | 2.0 | 0 | 60 | -60 | 1 of 1 | 0 of 1 | -60 | - |
| Mine | Empire of Man | 5 | 237 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 4 | 598 | 199 | 1.5 | 1.0 | 132 | 25 | +108 | 4 of 6 | 4 of 6 | - | +108 |
| Mine | High Elf Realms | 4 | 231 | 148 | 2.0 | 1.4 | 74 | 44 | +30 | 2 of 8 | 7 of 8 | +88 | +10 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Lizardmen | 1 | 195 | 0 | 1.0 | 1.0 | 0 | 141 | -141 | 1 of 1 | 0 of 1 | - | -141 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.5 | 0 | 138 | -138 | 1 of 2 | 0 of 2 | +0 | -275 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 580 | 4.0 | 1.0 | 145 | 0 | +145 | 2 of 4 | 3 of 4 | - | +145 |
| Mine | Skaven | 2 | 25 | 233 | 1.5 | 1.0 | 155 | 0 | +155 | 1 of 3 | 3 of 3 | - | +155 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 969 | 5.0 | 1.1 | 194 | 97 | +97 | 4 of 10 | 9 of 10 | +1120 | -17 |
| Mine | Vampire Counts | 2 | 0 | 172 | 2.5 | 1.0 | 69 | 86 | -17 | 1 of 5 | 3 of 5 | - | -17 |
| Mine | Warriors of Chaos | 1 | 0 | 54 | 3.0 | 1.0 | 18 | 57 | -39 | 0 of 3 | 3 of 3 | - | -39 |
| **Mine** | all armies | 36 | 213 | 188 | 1.5 | 1.1 | 126 | 48 | +77 | 24 of 54 | 39 of 54 | +247 | +60 |
| Opponent | Beastmen Brayherds | 1 | 55 | 0 | 4.0 | 1.0 | 0 | 42 | -42 | 2 of 4 | 2 of 4 | - | -42 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Opponent | Empire of Man | 1 | 255 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 1 | 590 | 95 | 3.0 | 1.3 | 32 | 0 | +32 | 3 of 3 | 2 of 3 | +95 | +0 |
| Opponent | High Elf Realms | 2 | 62 | 114 | 1.5 | 1.0 | 76 | 196 | -121 | 1 of 3 | 2 of 3 | - | -121 |
| Opponent | Lizardmen | 1 | 0 | 771 | 3.0 | 1.7 | 257 | 0 | +257 | 3 of 3 | 3 of 3 | +189 | +291 |
| Opponent | Ogre Kingdoms | 2 | 68 | 84 | 2.5 | 1.0 | 34 | 7 | +27 | 0 of 5 | 2 of 5 | - | +27 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 678 | 4.5 | 1.0 | 151 | 115 | +36 | 4 of 9 | 8 of 9 | - | +36 |
| Opponent | Skaven | 2 | 184 | 166 | 1.5 | 1.0 | 111 | 22 | +89 | 1 of 3 | 2 of 3 | - | +89 |
| Opponent | Tomb Kings of Khemri | 4 | 22 | 903 | 5.0 | 1.2 | 181 | 10 | +171 | 7 of 20 | 16 of 20 | +179 | +169 |
| Opponent | Vampire Counts | 6 | 11 | 292 | 3.7 | 1.1 | 80 | 106 | -26 | 5 of 22 | 16 of 22 | +57 | -39 |
| Opponent | Warriors of Chaos | 7 | 0 | 333 | 2.1 | 1.0 | 156 | 36 | +119 | 7 of 15 | 13 of 15 | - | +119 |
| Opponent | Wood Elf Realms | 6 | 111 | 329 | 4.2 | 1.0 | 79 | 10 | +69 | 9 of 25 | 20 of 25 | +81 | +69 |
| **Opponent** | all armies | 36 | 65 | 351 | 3.2 | 1.1 | 110 | 45 | +65 | 43 of 115 | 89 of 115 | +125 | +59 |

### Effective charges: fafix-mine-5e477c5-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 1 (net -52) | 0 | 0 | 1 (net +114) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 9 | 2 (net +504) | 0 | 1 (net +540) | 3 (net +70) | 0 | 3 (net +48) | 0 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 1 | 1 (net -60) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 6 | 0 | 1 (net +251) | 2 (net +196) | 2 (net +0) | 1 (net +0) | 0 | 0 | 33% (2 of 6) |
| Mine | High Elf Realms | 8 | 0 | 0 | 0 | 3 (net -25) | 1 (net +251) | 3 (net +62) | 1 | 0% (0 of 7) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +325) | 3 | 0% (0 of 1) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 1 (net +68) | 0 | 2 (net +199) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 10 | 0 | 0 | 3 (net -104) | 3 (net -123) | 1 (net +1120) | 3 (net +176) | 0 | 30% (3 of 10) |
| Mine | Vampire Counts | 5 | 2 (net +0) | 1 (net +170) | 0 | 1 (net -430) | 0 | 1 (net +173) | 0 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 1 (net -143) | 1 (net +27) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Beastmen Brayherds | 4 | 2 (net -85) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Grand Cathay | 3 | 2 (net +48) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +114) | 1 | 0% (0 of 2) |
| Opponent | Lizardmen | 3 | 0 | 0 | 0 | 1 (net +0) | 1 (net +189) | 1 (net +582) | 0 | 0% (0 of 3) |
| Opponent | Ogre Kingdoms | 5 | 1 (net +0) | 0 | 1 (net -34) | 0 | 0 | 2 (net +84) | 1 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 9 | 1 (net +219) | 1 (net -33) | 0 | 3 (net +137) | 0 | 0 | 4 | 0% (0 of 5) |
| Opponent | Skaven | 3 | 1 (net -65) | 0 | 1 (net +0) | 0 | 0 | 1 (net +332) | 0 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 20 | 0 | 1 (net +135) | 4 (net +104) | 7 (net +190) | 1 (net +135) | 6 (net +212) | 1 | 21% (4 of 19) |
| Opponent | Vampire Counts | 22 | 4 (net -38) | 1 (net -45) | 4 (net +22) | 7 (net -72) | 2 (net +204) | 3 (net -185) | 1 | 19% (4 of 21) |
| Opponent | Warriors of Chaos | 15 | 1 (net +125) | 1 (net +449) | 2 (net +274) | 1 (net +165) | 1 (net +54) | 7 (net +8) | 2 | 15% (2 of 13) |
| Opponent | Wood Elf Realms | 25 | 4 (net +55) | 0 | 4 (net +110) | 10 (net +41) | 2 (net +103) | 2 (net +138) | 3 | 18% (4 of 22) |

### Charged fights, damage counted: fafix-mine-5e477c5-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 219 | 282 | +149 | 187 | 59 | +128 | +58.4 |
| Mine | 50-54% | 2 | 312 | 186 | +210 | 264 | 132 | +132 | +42.4 |
| Mine | Effective (55-75%) | 7 | 283 | 260 | +68 | 186 | 93 | +93 | +32.9 |
| Mine | 76-89% | 15 | 300 | 205 | -30 | 106 | 103 | +3 | +0.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 293 | 199 | +125 | 152 | 14 | +139 | +47.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 618 | 154 | +457 | 479 | 0 | +479 | +77.5 |
| Mine | No odds | 7 | 223 | 154 | -41 | 67 | 104 | -37 | -16.5 |
| Mine | All fights | 54 | 295 | 209 | +77 | 159 | 69 | +90 | +30.4 |
| Opponent | Long shot (under 50%) | 16 | 175 | 271 | +17 | 94 | 83 | +11 | +6.4 |
| Opponent | 50-54% | 4 | 236 | 180 | +126 | 232 | 97 | +135 | +57.0 |
| Opponent | Effective (55-75%) | 18 | 251 | 185 | +81 | 128 | 56 | +73 | +28.9 |
| Opponent | 76-89% | 29 | 255 | 172 | +62 | 121 | 51 | +71 | +27.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 282 | 177 | +84 | 133 | 58 | +75 | +26.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 572 | 128 | +142 | 151 | 2 | +148 | +25.9 |
| Opponent | No odds | 13 | 276 | 155 | +2 | 126 | 105 | +21 | +7.6 |
| Opponent | All fights | 115 | 271 | 185 | +65 | 127 | 62 | +65 | +24.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fafix-mine-5e477c5-p1 | move | 371 | 74 (20%) | 53 (14%) | 36 (10%) | 261 (70%) |
| fafix-mine-5e477c5-p1 | objective | 272 | 40 (15%) | 23 (8%) | 29 (11%) | 203 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

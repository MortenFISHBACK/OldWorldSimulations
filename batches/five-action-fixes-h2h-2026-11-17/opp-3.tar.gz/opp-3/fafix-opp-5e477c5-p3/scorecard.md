# Doctrine scorecard: fafix-opp-5e477c5-p3

### Scorecard: fafix-opp-5e477c5-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 1 | 0 | 0 | 535 |
| L0110 | 2 | 1 | Opponent | - | - | 4 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Mine | yes | 4 | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 8 | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 5 | 0 | 2 | 1 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 2 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Mine | no | 0 | 2 | 0 | 4 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | - | 3 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 262 |
| L0327 | 3 | 1 | Mine | yes | 12 | - | 0 | 0 | 0 | 0 | 0 | 855 |
| L0327 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 5 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 1 | 0 | 0 | 70 |
| L0429 | 3 | 1 | Mine | no | 5 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 4 | 3 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 2 | - | 1 | 1 | 1 | 0 | 0 | 100 |
| L0533 | 5 | 1 | Mine | no | - | 5 | 1 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 2 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 3 | 4 | 1 | 1 | 0 | 0 | 0 | 170 |
| L0725 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 250 |
| L0725 | 5 | 1 | Opponent | yes | - | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 762 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | yes | 2 | - | 0 | 1 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 2 | - | 0 | 3 | 1 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 724 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 5 | 1 | 2 | 1 | 0 | 0 | 387 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 1 | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 2 | 0 | 0 | 427 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 100 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 1 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 2 | 2 | 0 | 3 | 2 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 126 |
| L1519 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 6 | 1 | 2 | 0 | 0 | 0 | 140 |
| L1633 | 1 | 1 | Mine | no | 6 | 4 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 3 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 1 | - | 0 | 2 | 2 | 0 | 0 | 170 |
| L1831 | 1 | 1 | Mine | no | 2 | 5 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | - | 0 | 3 | 1 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 5 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | 3 | 1 | 7 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | no | - | 3 | 2 | 3 | 0 | 0 | 0 | 19 |
| L2223 | 3 | 1 | Mine | yes | 0 | 1 | 8 | 0 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 3 | 3 | 4 | 0 | 2 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 4 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 5 | 1 | 0 | 0 | 0 | 40 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 3 | 2 | 2 | 0 | 2 | 0 | 0 | 710 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 34% | 2.5 | 3.1 | 2.2 | 1.2 | 0.2 | 0.0 | 0.0 | 321.2 |
| **Average** | | | Opponent | 28% | 1.5 | 3.0 | 2.0 | 2.1 | 0.5 | 0.0 | 0.0 | 88.2 |

### KPIs: fafix-opp-5e477c5-p3

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE; both sides: LIKELY CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 24% (40 of 168) | 8% (14 of 174) | 16% (54 of 342) |
| Winner chose to follow up after the loser gave ground |  | 93% (39 of 42); on the table 93% | 100% (31 of 31); on the table 100% | 96% (70 of 73); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 100% (8 of 8); on the table 100% | 94% (17 of 18); on the table 94% |
| Winner chose to pursue after the loser fled |  | 93% (14 of 15); on the table 100% | 68% (15 of 22); on the table 73% | 78% (29 of 37); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 93% (62 of 67); on the table 94% | 89% (54 of 61); on the table 90% | 91% (116 of 128); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 44% (151 of 342) | 40% (76 of 192) | 43% (227 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 55% (151 of 273) | 48% (76 of 160) | 52% (227 of 433) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (12 of 24) | 65% (39 of 60) | 61% (51 of 84) |
| Points that never fought | lower | 49% (33956 of 68801) | 50% (35744 of 71990) | 50% (69700 of 140791) |
|   infantry points that never fought | lower | 56% (7977 of 14174) | 62% (8840 of 14220) | 59% (16817 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (153 of 272) | 64% (181 of 285) | 60% (334 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 2.4 uses a game | 96% (23 of 24); 2.0 uses a game | 96% (47 of 49); 2.2 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game | 30% (6 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 50% (7 of 14); 0.2 uses a game | 56% (19 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (29961 of 59391) | 56% (36017 of 64043) | 53% (65978 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (26%) | 1.1 (33%) | 2.4 (29%) |
| MARCHED: its unit marched | 1.4 (27%) | 0.9 (27%) | 2.3 (27%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.2 (7%) | 0.5 (6%) |
| IN COMBAT: engaged in combat | 0.8 (15%) | 0.6 (20%) | 1.4 (17%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.2 (5%) | 0.2 (3%) |
| FLEEING: fleeing | 0.5 (9%) | 0.0 (0%) | 0.5 (6%) |
| GONE: slain | 0.3 (6%) | 0.1 (4%) | 0.5 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.1 (3%) | 0.4 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.1 | 2.5 | 6.3 | 0.8 | 1.3 |
| not cast | 3.9 | 1.5 | 3.7 | 8.5 | 2.5 | 19.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.8 (54%) | 0.4 (10%) | 2.4 (29%) | 0.3 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (27%) | 0.4 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (6%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.1 (6%) | 0.4 (10%) | 1.4 (17%) | 0.3 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.4 (10%) | 0.2 (3%) | 0.2 (7%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.2 (11%) | 0.1 (4%) | 0.5 (6%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.4 (12%) | 0.1 (7%) | 0.5 (14%) | 0.5 (6%) | 0.4 (15%) | 1.4 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.1 (4%) | 0.1 (2%) | 0.4 (5%) | 0.1 (4%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (6%) | 0.0 (0%) | 0.1 (1%) | 0.7 (29%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (63%) | 0.2 (13%) | 1.8 (49%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.5 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.9 a game | 1.3 a game |
| stood (cast and not dispelled) | 62% (30 of 48) | 50% (14 of 28) | 58% (44 of 76) |
| the unit moved after it | 73% (22 of 30) | 79% (11 of 14) | 75% (33 of 44) |
| it charged on its next turn | 3% (1 of 30) | 0% (0 of 14) | 2% (1 of 44) |
| the enemy charged it first | 3% (1 of 30) | 7% (1 of 14) | 5% (2 of 44) |
| it fought by the end of its next turn | 0% (0 of 30) | 7% (1 of 14) | 2% (1 of 44) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 30) | 29% (4 of 14) | 9% (4 of 44) |
| none of these (no charge, no fight, no charge escaped) | 93% (28 of 30) | 64% (9 of 14) | 84% (37 of 44) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (501 of 791) | 61% (387 of 630) | 62% (888 of 1421) |
|   cavalry | 53% (31 of 58) | 68% (71 of 105) | 63% (102 of 163) |
|   character | 55% (54 of 98) | 38% (56 of 149) | 45% (110 of 247) |
|   chariot | 55% (56 of 101) | 73% (19 of 26) | 59% (75 of 127) |
|   infantry | 53% (118 of 224) | 68% (175 of 257) | 61% (293 of 481) |
|   monster | 34% (14 of 41) | 80% (4 of 5) | 39% (18 of 46) |
|   war machine | 85% (228 of 269) | 70% (62 of 88) | 81% (290 of 357) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (33%) | 1.2 (18%) | 3.8 (26%) |
| CHARGED: it charged | 0.8 (10%) | 1.4 (21%) | 2.2 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 0.5 (7%) | 0.8 (5%) |
| MOVED: a war machine that moved | 0.2 (3%) | 0.5 (7%) | 0.7 (5%) |
| NO TARGET IN RANGE | 1.7 (21%) | 1.5 (22%) | 3.1 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.4 (5%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (17%) | 1.1 (16%) | 2.5 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (2%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.4 (4%) | 0.1 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.4 | 1.2 | 78% | 6.8 pts | 30 pts |
| character | 3.7 | 1.1 | 76% | 10.5 pts | 39 pts |
| chariot | 2.1 | 1.4 | 63% | 20.9 pts | 44 pts |
| infantry | 12.8 | 4.4 | 76% | 9.0 pts | 115 pts |
| monster | 0.6 | 0.2 | 87% | 7.5 pts | 5 pts |
| war machine | 8.4 | 6.5 | 65% | 22.2 pts | 186 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.5 | 3.7 | 3.6 |
| Charges that made contact a game | 2.6 | 2.5 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.70 declared, 0.44 contact (27 units) | 0.71 declared, 0.47 contact (17 units) | 0.70 declared, 0.45 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.00 contact (4 units) | 0.75 declared, 0.75 contact (12 units) | 0.62 declared, 0.56 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.37 contact (221 units) | 0.41 declared, 0.27 contact (274 units) | 0.44 declared, 0.31 contact (495 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 61% (47 of 77) | 53% (8 of 15) | 50% (5 of 10) | 59% (60 of 102) |
| Character in a unit | 80% (39 of 49) | 79% (15 of 19) | 57% (4 of 7) | 77% (58 of 75) |
| Character on its own | 89% (25 of 28) | 57% (21 of 37) | 29% (20 of 68) | 50% (66 of 133) |
| Chariot | 91% (10 of 11) | 83% (10 of 12) | - | 87% (20 of 23) |
| Infantry | 59% (41 of 70) | 52% (22 of 42) | 0% (0 of 5) | 54% (63 of 117) |
| Monster | 47% (16 of 34) | 57% (4 of 7) | - | 49% (20 of 41) |
| Monstrous | 90% (9 of 10) | 55% (6 of 11) | - | 71% (15 of 21) |
| War Machines | 74% (32 of 43) | 0% (0 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (3 of 3); on the table 100% | 53% (51 of 96) | 44% | 64% (14 of 22) | 100% (6 of 6); 7.0 uses a game | 100% (2 of 2); 0.8 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 100% (2 of 2); on the table 100% | 61% (22 of 36) | 64% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 87% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 85% (11 of 13); on the table 85% | 43% (13 of 30) | 53% | 59% (35 of 59) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 100% (18 of 18); on the table 100% | 34% (65 of 192) | 53% | 65% (48 of 74) | 89% (16 of 18); 6.1 uses a game | 0% (0 of 4); 0.0 uses a game | 50% (4 of 8); 0.5 uses a game |
| High Elf Realms | 7 | 86% (12 of 14); on the table 86% | 43% (18 of 42) | 39% | 50% (27 of 54) | 100% (9 of 9); 4.9 uses a game | 25% (3 of 12); 0.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 92% (12 of 13); on the table 92% | - | 57% | 56% (10 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 67% (2 of 3); on the table 67% | 33% (2 of 6) | 59% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 83% | 86% (6 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (3 of 3); on the table 100% | 33% (4 of 12) | 34% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 75% (3 of 4); on the table 75% | 33% (4 of 12) | 66% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 100% (11 of 11); on the table 100% | 0% (0 of 6) | 28% | 31% (8 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 79% (11 of 14); on the table 86% | 46% (25 of 54) | 34% | 52% (24 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 92% (23 of 25); on the table 96% | 70% (21 of 30) | 56% | 60% (58 of 96) | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (4 of 4); on the table 100% | 17% (2 of 12) | 48% | 71% (44 of 62) | 100% (11 of 11); 4.7 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fafix-opp-5e477c5-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (27) | 47% (28) | 48% (55) |
| ...free all their last turn and able to turn (per game) | 0.42 | 0.61 | 1.03 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.14 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.31 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.92 | 0.06 | 1.97 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.64 | 0.06 | 0.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.97 | 0.14 | 6.11 |

### Quality by phase: fafix-opp-5e477c5-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 62% (66 of 106) | 44% (48 of 110) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (166 of 431) | 50% (72 of 144) |
| Strategy | Close-in objectives charged next turn | 16% (32 of 195) | - |
| Strategy | Support requests answered (helper made contact too) | 40% (4 of 10) | 47% (7 of 15) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (4 of 10) | 60% (6 of 10) |
| Strategy | Joined characters whose unit fought | 32% (16 of 50) | 32% (18 of 56) |
| Strategy | Lone characters that fought | 67% (57 of 85) | 58% (45 of 78) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.2 | 2.1 |
| Movement | Points that never moved of their own | 321.2 | 88.2 |
| Movement | Fights charged into per game | 2.5 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 82, net -23 | 8 of 64, net +138 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 82, net +149 | 15 of 64, net +169 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 17 of 82, net +67 | 5 of 64, net +74 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 82, net +113 | 16 of 64, net +212 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.3 | 10.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (124 of 298) | 41% (158 of 388) |
| Shooting | Points destroyed by shooting units | 55.3 | 14.8 |
| Shooting | War machine shots | 6.3 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (118 of 228) | 28% (21 of 74) |
| Shooting | Points destroyed by war machines | 58.4 | 23.4 |
| Magic | Magic missiles cast | 2.9 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (40 of 106) | 33% (15 of 46) |
| Magic | Wounds caused by magic missiles | 5.4 | 1.8 |
| Magic | Wounds caused by other spells | 0.6 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 81.0 | 40.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.3 / 0.3 / 0.2 | 1.9 / 0.3 / 0.4 / 0.4 |
| Combat | Points destroyed in combat | 222.0 | 314.6 |
| Combat | Points run down | 46.0 | 53.4 |
| Combat | Net points per charged fight, damage counted | +63 | +134 |
| Combat | Net per 100 charger points, damage counted | +23.2 | +45.2 |
| Combat | First round won (charged fights) | 78% | 74% |
| Combat | Net points per charged fight | +59 | +145 |
| Combat | Net points per supported fight / lone fight | +119 / +53 | +323 / +133 |
| Combat | Charged fights on a top-3 enemy unit | 24 of 90 | 34 of 77 |
| Game | Points lost | 573.3 | 559.6 |
| Game | VP from objectives | 598.6 | 478.1 |
| Game | Lone holders (player turns) | 2.5 | 1.5 |

- Mine won / drew / lost: 15 / 10 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +66 VP
- The side that went first won 9 of 26 games with a winner
- Points traded per game (both sides' losses): 1133
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fafix-opp-5e477c5-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.7 | -205.3 | 150.5 | 108.3 | - | - | - | - |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 40.3 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.5 | +1.1 | 0.0 | 15.5 | 0.5 | +2.7 | 0.0 | 8.6 |
| BEST FACING | 0.4 | +23.2 | 0.0 | 11.4 | - | - | - | - |
| BEST FIRST | 1.2 | +49.4 | 17.7 | 38.9 | - | - | - | - |
| BEST OVERALL | 0.2 | +11.6 | 0.0 | 12.0 | - | - | - | - |
| BEST PREY | 0.9 | +51.4 | 25.3 | 19.2 | - | - | - | - |
| BEST PRIZE | 0.1 | -3.9 | 7.6 | 0.0 | 0.1 | -4.1 | 7.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE HANDED OVER | 0.0 | +0.9 | 2.7 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 10.7 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.6 | +4.7 | 0.0 | 19.6 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | -12.7 | 3.0 | 6.4 | 0.3 | -45.6 | 73.4 | 5.4 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 1.4 | +0.0 | 131.3 | 26.9 | 0.1 | +0.0 | 7.0 | 1.9 |
| CANNON PLANNED TARGET | 5.2 | +198.1 | 276.6 | 130.4 | 1.4 | +58.7 | 57.7 | 19.4 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -2.3 | 7.9 | 16.2 | - | - | - | - |
| CAST JOB | 1.2 | +30.7 | 35.2 | 21.8 | 0.4 | +6.6 | 16.9 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +22.2 | 3.1 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.9 | +60.5 | 0.0 | 14.9 | 0.7 | +26.9 | 0.0 | 19.8 |
| CHAFF PASSED | 0.2 | -0.1 | 5.4 | 0.0 | 0.2 | -0.5 | 12.2 | 5.6 |
| CHARACTER GUNS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 10.0 | -481.1 | 0.0 | 262.1 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 158.8 | 53.6 | 1.6 | +0.0 | 183.2 | 27.0 |
| CHARGE NOW WEIGHED | 0.7 | -35.0 | 23.4 | 15.9 | - | - | - | - |
| CHARGER SLAIN LOST | 0.3 | -10.6 | 10.0 | 17.5 | 0.2 | -4.9 | 24.8 | 10.1 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 4.6 | 2.4 | 0.1 | +0.0 | 0.0 | 1.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 20.4 | 19.2 | 0.2 | +0.0 | 30.1 | 4.7 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.8 | +150.7 | 10.6 | 10.6 | 0.5 | +49.3 | 23.8 | 30.5 |
| COVER ONCE | 9.2 | -609.6 | 0.0 | 180.6 | 5.8 | -421.3 | 0.0 | 95.4 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +3.4 | 7.2 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +7.5 | 28.1 | 13.1 | 0.1 | +4.9 | 21.6 | 5.4 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +141.3 | 0.0 | 35.2 | 0.1 | +7.1 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 2.1 | +3.1 | 247.7 | 32.1 |
| FALLBACK BY WORTH | 4.8 | +35.9 | 0.0 | 37.6 | 0.3 | +0.8 | 0.0 | 6.7 |
| FALLS SHORT | - | - | - | - | 0.2 | -0.9 | 8.3 | 0.0 |
| FEATURE BUFFS | - | - | - | - | 0.6 | +14.6 | 0.0 | 5.8 |
| FIRE AND FLEE | 0.0 | +0.4 | 0.0 | 2.2 | - | - | - | - |
| FIVE ACTION | - | - | - | - | 43.0 | +1495.7 | 449.6 | 560.8 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 138.8 | 5.0 | +0.0 | 0.0 | 151.7 |
| FOCUS FIRE | - | - | - | - | 0.1 | +2.6 | 3.4 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +92.8 | 0.0 | 38.4 | 0.5 | +101.8 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 2.9 | +293.5 | 311.9 | 46.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +14.4 | 0.0 | 11.3 | 0.0 | +2.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.6 | 7.6 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.2 | 4.5 | 1.8 |
| GROUND FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 0.4 | +9.8 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 4.6 | 4.6 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 5.9 | 10.0 | 0.2 | +0.0 | 8.3 | 0.0 |
| HILL BY ITS CHANCE | 0.2 | -20.5 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 9.0 | -137.8 | 389.3 | 124.8 | 2.5 | -109.4 | 267.0 | 32.4 |
| HORN WORTH | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +13.8 | 9.2 | 1.4 | - | - | - | - |
| HUNT DROPPED | 0.1 | +0.0 | 4.6 | 0.0 | 0.0 | +0.0 | 0.0 | 0.5 |
| HUNT IN PAIRS | 0.4 | +12.7 | 0.0 | 5.4 | 0.9 | +50.3 | 0.0 | 5.4 |
| HUNT KEPT | 0.2 | +4.8 | 18.3 | 4.9 | 0.0 | +0.1 | 0.0 | 0.5 |
| HUNT RESULT | 0.2 | +18.1 | 4.6 | 2.4 | 0.1 | +13.7 | 0.0 | 3.4 |
| HUNT THE GUNS | 0.2 | +72.4 | 4.6 | 5.4 | 0.1 | +25.9 | 13.1 | 2.9 |
| IDLE COST | 16.5 | -293.2 | 0.0 | 198.4 | 20.8 | -373.4 | 0.0 | 224.9 |
| INVITES THE FIGHT | 1.4 | +11.0 | 45.6 | 22.4 | - | - | - | - |
| JOINT CHARGE PLAN | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.2 | +2.9 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.8 | +52.5 | 116.1 | 35.9 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +68.8 | 100.1 | 32.9 | - | - | - | - |
| KILLS COUNT NEXT TURN | 5.7 | +146.5 | 261.1 | 97.4 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.3 | +19.5 | 11.3 | 11.0 | 0.2 | +17.5 | 4.0 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 5.8 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -0.8 | 14.2 | 6.3 | 0.3 | -1.9 | 20.8 | 17.5 |
| LOST CHARGE | 2.7 | -41.8 | 69.2 | 86.7 | 0.1 | -0.7 | 23.9 | 2.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -7.9 | 0.0 | 3.4 | - | - | - | - |
| MAKE SURE TOGETHER | 0.8 | +68.5 | 11.0 | 14.7 | 0.1 | +2.8 | 0.0 | 0.0 |
| MANOEUVRE | 0.2 | +3.6 | 0.0 | 0.0 | 0.9 | +10.1 | 0.0 | 14.8 |
| MARCH AT ESCAPER | 0.2 | +1.1 | 0.0 | 6.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +2.5 | 0.0 | 0.0 | 0.9 | +66.5 | 0.0 | 3.2 |
| MARCH ODDS | 0.3 | +17.2 | 10.8 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.5 | +24.3 | 0.0 | 24.0 | 0.7 | +87.1 | 0.0 | 16.9 |
| MAX FOR POSITIONING | 7.1 | +125.3 | 0.0 | 127.5 | 7.5 | +101.8 | 0.0 | 112.7 |
| MISSILES IN THE MOVE | 5.3 | +152.4 | 0.0 | 89.0 | 4.4 | +73.6 | 0.0 | 49.5 |
| MISSILES NEXT TURN | 6.1 | +102.5 | 0.0 | 129.6 | 5.3 | +48.8 | 0.0 | 55.2 |
| MODEL FACING | 0.2 | +38.4 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.8 | +30.0 | 0.0 | 9.5 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.4 | +10.6 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -18.0 | 0.0 | 32.9 | 0.1 | -1.8 | 0.0 | 13.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 4.1 | +257.4 | 161.9 | 28.4 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | - | - | - | - | 15.2 | -296.5 | 16.0 | 173.2 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 3.7 | -221.5 | 8.8 | 47.2 |
| NO DOUBLE ROUNDS | - | - | - | - | 2.1 | -132.4 | 233.3 | 24.9 |
| NOT NEEDED | 0.3 | -7.1 | 31.9 | 4.6 | - | - | - | - |
| NOT TURNED | 6.0 | +78.3 | 0.0 | 132.8 | 0.1 | +0.2 | 0.0 | 6.7 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 20.4 | 0.9 | -1.0 | 0.0 | 0.0 |
| OFF BEST | 18.1 | -788.3 | 0.0 | 253.9 | 1.9 | -70.2 | 0.0 | 10.8 |
| ONE FIGHT FORMULA | 9.9 | -164.1 | 37.6 | 206.8 | 8.6 | -205.5 | 0.0 | 85.1 |
| ONE OBJECTIVE FORMULA | 2.7 | -140.0 | 0.0 | 31.2 | 2.4 | -83.5 | 0.0 | 37.9 |
| OPENS A LANE | 0.2 | +0.7 | 13.5 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +12.1 | 10.5 | 0.0 | 0.1 | +2.3 | 2.4 | 0.0 |
| OVERRUNS AWAY | 0.6 | +7.3 | 46.2 | 5.7 | 0.5 | +11.4 | 65.1 | 2.9 |
| PATHS CROSS | 2.4 | +122.9 | 0.0 | 54.8 | 2.9 | +302.9 | 0.0 | 40.1 |
| PERIAPT WORTH | 0.0 | +2.9 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -3.7 | 0.0 | 4.2 | 0.1 | -5.5 | 0.0 | 4.0 |
| PLAN RESULT | 38.9 | +1219.1 | 1136.7 | 833.2 | 39.1 | +426.2 | 234.2 | 840.3 |
| PURSUES BIG PREY | 0.0 | -3.4 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +4.1 | 0.0 | 36.4 | 1.7 | +60.8 | 0.0 | 65.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.6 | 6.6 | 4.7 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.8 | -11.5 | 0.0 | 10.4 | 0.6 | -24.1 | 0.0 | 17.9 |
| REDIRECT COUNTER | 1.9 | +130.1 | 0.0 | 46.8 | 3.3 | +285.6 | 0.0 | 77.0 |
| REDIRECT WEIGHED | 0.1 | +1.3 | 7.8 | 4.5 | 0.3 | -0.4 | 7.6 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 1.7 |
| RESERVE FALL BACK | 0.3 | +5.5 | 0.0 | 17.7 | 0.9 | +60.6 | 0.0 | 24.3 |
| RESTRAINS TO SHOOT | 0.1 | +4.5 | 0.0 | 6.3 | - | - | - | - |
| RISK BY ARC | 2.3 | +80.4 | 183.0 | 60.6 | 1.7 | +26.8 | 169.4 | 31.7 |
| RISK ONCE | 3.8 | +117.4 | 34.7 | 103.4 | - | - | - | - |
| RUN DOWN | - | - | - | - | 2.1 | -28.1 | 220.8 | 25.1 |
| SAFE SURE CHARGE | 0.0 | -0.0 | 1.5 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.6 | +34.8 | 0.0 | 21.6 | 0.1 | +2.0 | 0.0 | 0.0 |
| SCALED CHANCE | - | - | - | - | 5.5 | +65.1 | 0.0 | 39.9 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 4.3 | 0.3 | +0.9 | 0.0 | 1.8 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 4.3 | 0.3 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -9.2 | 0.0 | 1.1 | 0.1 | -5.8 | 0.0 | 1.6 |
| SEARCH SPOT | 2.2 | +83.8 | 0.0 | 42.1 | 7.0 | +263.7 | 0.0 | 115.2 |
| SECOND HUNTER | 0.1 | -4.8 | 9.2 | 1.4 | - | - | - | - |
| SELF MOVE SPELL | 0.5 | +50.7 | 0.0 | 0.0 | 0.2 | +61.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.5 | +104.5 | 42.8 | 19.6 | 0.2 | +3.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.4 | +102.0 | 10.6 | 10.6 | - | - | - | - |
| SET-UP MISSED | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +6.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.8 | +52.5 | 47.9 | 8.7 | 0.5 | +26.1 | 4.7 | 14.9 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.7 | +0.0 | 104.2 | 12.8 | 0.1 | +0.0 | 11.6 | 6.9 |
| SHOTS IN THE MOVE | 14.8 | +585.4 | 0.0 | 295.5 | 11.1 | +318.8 | 0.0 | 131.2 |
| SPELL CATCH ODDS | 0.1 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.7 | +158.9 | 10.6 | 10.6 | - | - | - | - |
| SPELL WORTH | 1.4 | +15.5 | 29.7 | 39.5 | 2.3 | +31.4 | 58.4 | 46.6 |
| SPELLS IN THE FIGHT | 0.5 | -1.8 | 60.9 | 18.6 | 0.4 | +0.5 | 59.4 | 6.5 |
| STABLE ROLE | 11.0 | +0.0 | 314.9 | 101.6 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.3 | -3.3 | 26.7 | 13.2 |
| STAY WEIGHED | 0.1 | +2.9 | 0.0 | 4.6 | - | - | - | - |
| STOPS | 0.1 | +2.5 | 9.2 | 6.4 | 0.1 | +2.4 | 13.1 | 3.4 |
| STOPS SHORT OF THE FLANK | 0.5 | +17.1 | 0.0 | 3.2 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 9.4 | 0.2 | +0.0 | 0.0 | 5.8 |
| SUPPORT NARROWED | 6.0 | -63.0 | 242.3 | 91.8 | 1.2 | +0.0 | 136.0 | 24.9 |
| SUPPORTS | 4.4 | +68.5 | 124.6 | 43.2 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.3 | 12.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.4 | +2.8 | 35.6 | 1.7 | 0.4 | +3.3 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.6 | +17.9 | 0.0 | 11.3 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 2.9 | +0.0 | 10.6 | 8.2 |
| TURN WORTH | 0.3 | -25.6 | 37.8 | 4.5 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.3 | +2.2 | 7.9 | 3.2 | 0.1 | +0.1 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 8.3 | -367.8 | 274.5 | 103.7 | - | - | - | - |
| WALKS TO THE FIGHT | 2.0 | +17.6 | 38.5 | 42.3 | - | - | - | - |
| WAR ENGINE CHARGES | - | - | - | - | 0.1 | +2.9 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.9 | +0.0 | 26.6 | 7.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 0.8 | +21.6 | 57.4 | 38.3 | 0.0 | +0.8 | 0.0 | 2.1 |
| WHO HITS BACK | 0.3 | +34.1 | 0.0 | 19.0 | 0.3 | +39.6 | 0.0 | 6.8 |
| WHOLE FIGHT | 0.1 | +4.3 | 10.7 | 0.0 | 0.2 | +11.2 | 43.5 | 13.2 |
| WHOLE FIGHT GAIN | 0.3 | +10.1 | 19.2 | 6.2 | 0.4 | +20.1 | 31.6 | 1.2 |
| WIDER SPREAD | 2.0 | -4.9 | 149.2 | 25.4 | 2.1 | -11.2 | 218.5 | 28.6 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 3.0 | 0.0 | - | - | - | - |

### Rule changes: fafix-opp-5e477c5-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 719 | 719 | 719 | 19.97 | -30906 | -43.0 |
| SEARCH SPOT | 332 | 332 | 322 | 8.94 | +12522 | +38.9 |
| PATHS CROSS | 191 | 191 | 191 | 5.31 | +15329 | +80.3 |
| SHOTS IN THE MOVE | 934 | 742 | 103 | 2.86 | +2542 | +24.7 |
| IDLE COST | 1344 | 865 | 99 | 2.75 | +1274 | +12.9 |
| COVER ONCE | 541 | 347 | 97 | 2.69 | +2028 | +20.9 |
| MOVE TO CHARGE | 147 | 147 | 88 | 2.44 | +3290 | +37.4 |
| FIVE ACTION | 1547 | 1547 | 79 | 2.19 | +2474 | +31.3 |
| ARTILLERY RE-ROLL WEIGHED | 78 | 78 | 78 | 2.17 | +0 | +0.0 |
| MAX FOR POSITIONING | 526 | 397 | 75 | 2.08 | +276 | +3.7 |
| FACES THE THREAT | 71 | 71 | 71 | 1.97 | +5343 | +75.2 |
| SUPPORTS | 157 | 157 | 69 | 1.92 | +738 | +10.7 |
| MISSILES IN THE MOVE | 348 | 257 | 68 | 1.89 | +1430 | +21.0 |
| KILLS COUNT NEXT TURN | 206 | 206 | 63 | 1.75 | +1154 | +18.3 |
| CHARGE LOSSES | 359 | 359 | 57 | 1.58 | +4746 | +83.3 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| WAIT AFTER COSTS | 298 | 298 | 56 | 1.56 | +1015 | +18.1 |
| REDIRECT COUNTER | 186 | 133 | 54 | 1.50 | +5040 | +93.3 |
| FOUR ROUNDS | 106 | 106 | 52 | 1.44 | +5083 | +97.7 |
| RANDOM MOVE BY FIGURES | 84 | 84 | 51 | 1.42 | +2338 | +45.8 |
| FOLLOW UP WEIGHED | 48 | 48 | 48 | 1.33 | +7005 | +145.9 |
| NEXT CHARGE BY LIST | 548 | 548 | 46 | 1.28 | +479 | +10.4 |
| ONE FIGHT FORMULA | 667 | 458 | 46 | 1.28 | +147 | +3.2 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +2378 | +52.9 |
| BEST FIRST | 43 | 43 | 43 | 1.19 | +1778 | +41.3 |
| MARCH CHECK | 46 | 46 | 42 | 1.17 | +1364 | +32.5 |
| FALLBACK BY WORTH | 186 | 186 | 41 | 1.14 | +1322 | +32.2 |
| CHAFF IN THE MOVE | 56 | 55 | 40 | 1.11 | +1136 | +28.4 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 81 | 81 | 38 | 1.06 | +1301 | +34.2 |
| CANNON PLANNED TARGET | 236 | 236 | 37 | 1.03 | -548 | -14.8 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| RISK BY ARC | 143 | 141 | 35 | 0.97 | +970 | +27.7 |
| ADVANCE WORTH | 205 | 205 | 34 | 0.94 | +724 | +21.3 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| SHOT REPLANNED | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| SET UP TOGETHER | 62 | 54 | 28 | 0.78 | +1788 | +63.9 |
| CAST JOB | 56 | 56 | 27 | 0.75 | +465 | +17.2 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +1081 | +40.0 |
| CHARGE NOW WEIGHED | 26 | 26 | 26 | 0.72 | +1339 | +51.5 |
| WALKS TO THE FIGHT | 73 | 73 | 26 | 0.72 | +163 | +6.3 |
| SAFER THAN THE JOB | 25 | 25 | 25 | 0.69 | +1324 | +53.0 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| CHARGE NOW FIRST | 133 | 133 | 24 | 0.67 | -1660 | -69.2 |
| MANOEUVRE | 42 | 42 | 24 | 0.67 | +502 | +20.9 |
| WAR ENGINE JOBS | 35 | 35 | 24 | 0.67 | -580 | -24.2 |
| WHO HITS BACK | 24 | 24 | 24 | 0.67 | +1798 | +74.9 |
| BLOCKED WHEEL | 23 | 23 | 23 | 0.64 | +169 | +7.3 |
| HONEST WORTH | 416 | 413 | 22 | 0.61 | +177 | +8.0 |
| INVITES THE FIGHT | 49 | 49 | 21 | 0.58 | +124 | +5.9 |
| MISSILES NEXT TURN | 409 | 288 | 21 | 0.58 | +68 | +3.2 |
| RISK ONCE | 135 | 102 | 21 | 0.58 | +963 | +45.9 |
| THROUGH LINE OF FIRE | 21 | 21 | 21 | 0.58 | +645 | +30.7 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| COMBAT PIVOT | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 17 | 17 | 17 | 0.47 | +615 | +36.2 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -20 | -1.4 |
| BEST FACING | 14 | 14 | 14 | 0.39 | +835 | +59.6 |
| BEST PREY | 31 | 31 | 14 | 0.39 | +270 | +19.3 |
| REDIRECT WEIGHED | 14 | 14 | 14 | 0.39 | +323 | +23.0 |
| WHOLE FIGHT GAIN | 23 | 22 | 14 | 0.39 | +336 | +24.0 |
| KILLS COUNT | 54 | 53 | 13 | 0.36 | +400 | +30.7 |
| MARCH ODDS | 13 | 13 | 13 | 0.36 | +35 | +2.7 |
| SCALED CHANCE | 197 | 197 | 13 | 0.36 | +77 | +5.9 |
| HUNT IN PAIRS | 50 | 37 | 12 | 0.33 | +965 | +80.4 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 32 | 28 | 12 | 0.33 | +46 | +3.8 |
| MAKE SURE TOGETHER | 34 | 20 | 11 | 0.31 | +802 | +72.9 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +601 | +60.1 |
| NEXT OBJECTIVE NEARER | 134 | 134 | 10 | 0.28 | +151 | +15.1 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -331 | -33.1 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTING BLOCK | 13 | 13 | 9 | 0.25 | +265 | +29.5 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| KEEPS ITS TARGET | 63 | 63 | 9 | 0.25 | +178 | +19.8 |
| BEST OVERALL | 8 | 8 | 8 | 0.22 | +418 | +52.2 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | -31 | -4.4 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +264 | +37.7 |
| LOST CHARGE | 103 | 103 | 7 | 0.19 | +354 | +50.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| ONE OBJECTIVE FORMULA | 181 | 114 | 7 | 0.19 | +240 | +34.3 |
| WEARS DOWN | 30 | 28 | 7 | 0.19 | +126 | +18.0 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +1382 | +230.3 |
| OPENS UP | 8 | 8 | 6 | 0.17 | +185 | +30.8 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -346 | -69.2 |
| REFUSING RETIRES | 13 | 13 | 5 | 0.14 | -2 | -0.3 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +160 | +32.1 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SUPPORT NARROWED | 258 | 258 | 5 | 0.14 | -55 | -11.0 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -48 | -9.5 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| HORN WORTH | 4 | 4 | 4 | 0.11 | +64 | +16.0 |
| OVERRUNS AWAY | 38 | 38 | 4 | 0.11 | +48 | +11.9 |
| WHOLE FIGHT | 12 | 12 | 4 | 0.11 | +224 | +56.0 |
| CHARIOT NO STATIC JOB | 3 | 3 | 3 | 0.08 | -382 | -127.3 |
| FEATURE BUFFS | 20 | 20 | 3 | 0.08 | +85 | +28.2 |
| HUNT ADVANCE | 8 | 8 | 3 | 0.08 | +136 | +45.3 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +105 | +35.0 |
| STOPS | 8 | 8 | 3 | 0.08 | +105 | +35.0 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -13 | -6.4 |
| DEFENSIVE FLOOR | 2 | 2 | 2 | 0.06 | +58 | +28.8 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +93 | +46.5 |
| GUN MASK | 13 | 13 | 2 | 0.06 | +18 | +9.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +228 | +114.0 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -115 | -57.5 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 2 | 0.06 | +4 | +2.0 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.06 | +52 | +25.9 |
| WIDER SPREAD | 149 | 147 | 2 | 0.06 | +5 | +2.7 |
| BACKUP TARGETS | 38 | 25 | 1 | 0.03 | +7 | +7.3 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +31 | +31.3 |
| BLOWS WHERE AIMED | 19 | 19 | 1 | 0.03 | +20 | +20.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +27 | +27.1 |
| CARRIES OUT SET-UP | 6 | 6 | 1 | 0.03 | -84 | -83.8 |
| CHARGER SLAIN LOST | 18 | 18 | 1 | 0.03 | +37 | +36.7 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 6 | 6 | 1 | 0.03 | -56 | -56.2 |
| EDGE GIVE GROUND | 13 | 13 | 1 | 0.03 | +7 | +7.4 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 3 | 3 | 1 | 0.03 | -68 | -67.9 |
| LONG SHOT | 20 | 19 | 1 | 0.03 | +24 | +24.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 49 | 49 | 1 | 0.03 | +0 | +0.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -2 | -1.6 |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 1 | 0.03 | +1 | +0.9 |
| SPELLS IN THE FIGHT | 35 | 35 | 1 | 0.03 | +15 | +15.4 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 55 | 55 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 48 | trace | - | - | - | - |
| CHARACTER GUNS | 47 | 47 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 48 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 77 | 77 | 0 | 0.00 | - | - |
| FALLS SHORT | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 376 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 17 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 9 | 9 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 10 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 10 | trace | - | - | - | - |
| MARCH OVER CASTS | 41 | 41 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 13 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 24 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 76 | 76 | 0 | 0.00 | - | - |
| NOT NEEDED | 10 | 10 | 0 | 0.00 | - | - |
| NOT TURNED | 220 | 220 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| OPENS A LANE | 11 | not checked | - | - | - | - |
| PLAN RESULT | 2810 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 77 | 77 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 16 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 25 | not checked | - | - | - | - |
| SPELL WORTH | 133 | not checked | - | - | - | - |
| STABLE ROLE | 395 | 394 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 11 | 11 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 105 | 105 | 0 | 0.00 | - | - |
| TURN WORTH | 11 | 11 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 13 | 11 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: fafix-opp-5e477c5-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 16.64 | 1.47 | 43.1 |
| FALLBACK | gate | 0.75 | 0.03 | 44.5 |
| CHARGE NOW FIRST | rule | 0.47 | 0.19 | 69.2 |
| WAR ENGINE JOBS | rule | 0.67 | - | 24.2 |
| TURN GATE | gate | 0.56 | - | 53.0 |
| CANNON PLANNED TARGET | rule | 0.17 | 0.11 | 78.2 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.11 | 33.1 |
| RULE SWITCHED OFF | gate | - | 0.25 | 42.7 |
| CHAFF PASSED | rule | 0.06 | 0.17 | 2.6 |
| BEST PRIZE | rule | 0.06 | 0.08 | 69.2 |
| PATHS CROSS | rule | 0.08 | 0.06 | 23.8 |
| SUPPORT NARROWED | rule | 0.11 | 0.03 | 11.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | - | 9.5 |
| BIG CHARACTER SAFETY | rule | 0.11 | - | 10.8 |
| AFTERMATH BAND | gate | 0.03 | 0.06 | 3.0 |
| BLOCKED WHEEL | rule | 0.08 | - | 46.2 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 38.0 |
| CHARIOT NO STATIC JOB | rule | 0.08 | - | 127.3 |
| FACES THE THREAT | rule | 0.08 | - | 9.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 17.2 |
| CATCH ODDS | rule | 0.06 | - | 6.4 |
| FIGHT ORDER BAND | gate | - | 0.06 | 2.5 |
| MARCH ODDS | rule | 0.03 | 0.03 | 3.8 |
| REDIRECT WEIGHED | rule | - | 0.06 | 51.2 |
| SUPPORT REQUEST | gate | 0.06 | - | 16.2 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 3.2 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 83.8 |
| DEFENSIVE ARMY | rule | 0.03 | - | 56.2 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.03 | 8.4 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | - | 67.9 |
| PURSUES BIG PREY | rule | 0.03 | - | 123.3 |
| REFUSING RETIRES | rule | - | 0.03 | 0.7 |
| SAFE SURE CHARGE | rule | 0.03 | - | 1.6 |
| SAFER THAN THE JOB | rule | 0.03 | - | 15.5 |
| WHO HITS BACK | rule | - | 0.03 | 3.9 |

### Plans: fafix-opp-5e477c5-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.3 | 20% | 154 | 281 | 182% |
| Mine | charge | 2.3 | 58% | 181 | 184 | 102% |
| Mine | close in | 5.4 | 27% | 273 | 199 | 73% |
| Mine | hold | 5.3 | 43% | 314 | 0 | 0% |
| Mine | join | 0.5 | 88% | 16 | 0 | 0% |
| Mine | shoot | 10.0 | 57% | 275 | 555 | 202% |
| Mine | support | 5.1 | 92% | 56 | 0 | 0% |
| Opponent | charge | 2.4 | 61% | 328 | 245 | 75% |
| Opponent | join | 0.9 | 97% | 37 | 0 | 0% |
| Opponent | move | 32.1 | 93% | 998 | 0 | 0% |
| Opponent | shoot | 3.2 | 57% | 104 | 181 | 174% |
| Opponent | support | 0.6 | 50% | 3 | 0 | 0% |

### Packages: hunt the guns, fafix-opp-5e477c5-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 7 | 0 | 43% | 43% | 0% | 3.7 | 372 | 93 | 14% | 10 |
| Opponent | 0.1 | 3 | 0 | 33% | 33% | 0% | 2.0 | 311 | 164 | 33% | 64 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.5 | 6 | 0 | 50% | 50% | 0% | 3.7 | 396 | 108 | 17% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 71 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 59 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 93 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 229 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 124 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 41 |
| Wood Elf Realms | 0.5 | 3 | 0 | 33% | 33% | 0% | 2.0 | 311 | 164 | 33% | 24 |

### Battle groups: fafix-opp-5e477c5-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 19% | 54% | 15% | 0% | 27% | 0% | 9% | 64% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 25% | 79% | 17% | 20% | 0% | 4% | 17% | 79% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fafix-opp-5e477c5-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Chaff | 34 | 55 (34) | 24 | 31 | 51 | 41% | 2.4 | 56 (21) | 0 (4) | 70 (9) | 81 (24) | 0 (10) |
| Mine | Character | 118 | 33 (118) | 32 | 1 | 23 | 24% | 2.4 | 41 (39) | 35 (59) | 13 (8) | 37 (62) | 34 (44) |
| Mine | Clean-up | 18 | 70 (18) | 24 | 45 | 19 | 44% | 3.0 | 67 (3) | 55 (13) | 259 (2) | 68 (12) | 71 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 35 (44) | 24 | 11 | 43 | 20% | 3.2 | 34 (22) | 31 (14) | 44 (8) | 27 (30) | 47 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 100% | - | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 28 (52) | 14 | 14 | 29 | 15% | 2.9 | 22 (14) | 30 (35) | 35 (3) | 34 (36) | 15 (16) |
| Mine | Holder | 25 | 45 (25) | 0 | 45 | 16 | 60% | 2.9 | 14 (8) | 58 (14) | 46 (3) | 67 (13) | 22 (12) |
| Mine | Shooter | 37 | 67 (37) | 17 | 50 | 45 | 3% | 1.9 | 17 (6) | 83 (28) | 7 (3) | 91 (22) | 30 (15) |
| Mine | Support | 4 | 33 (4) | 33 | 0 | 0 | 25% | 3.0 | 0 (1) | 58 (3) | - | 0 (1) | 58 (3) |
| Mine | War machine | 52 | 35 (52) | 35 | 0 | 51 | 0% | 1.2 | 39 (13) | 32 (36) | 55 (3) | 31 (13) | 36 (39) |
| Mine | Wizard | 17 | 12 (17) | 12 | 0 | 28 | 12% | 2.1 | 21 (5) | 0 (8) | 26 (2) | 15 (9) | 9 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Chaff | 68 | 34 (68) | 13 | 21 | 63 | 49% | 2.5 | 50 (29) | 36 (11) | 21 (28) | 38 (48) | 27 (20) |
| Opponent | Character | 102 | 41 (102) | 41 | 0 | 16 | 35% | 2.1 | 35 (41) | 47 (53) | 14 (3) | 46 (54) | 37 (43) |
| Opponent | Clean-up | 11 | 31 (11) | 15 | 16 | 20 | 27% | 3.1 | 0 (4) | 38 (6) | 111 (1) | 23 (6) | 39 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 37 (60) | 26 | 12 | 37 | 33% | 3.0 | 26 (30) | 35 (20) | 80 (10) | 34 (28) | 41 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 34 (50) | 25 | 8 | 43 | 32% | 3.2 | 37 (17) | 35 (30) | 0 (3) | 46 (30) | 14 (20) |
| Opponent | Holder | 40 | 72 (40) | 4 | 68 | 21 | 45% | 2.5 | 13 (7) | 100 (23) | 58 (9) | 79 (26) | 67 (13) |
| Opponent | Shooter | 27 | 29 (27) | 11 | 18 | 52 | 4% | 1.2 | 56 (6) | 19 (19) | 58 (2) | 31 (16) | 26 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 50 | 75% | 6.0 | 0 (2) | 0 (1) | 0 (1) | - | 0 (4) |
| Opponent | War machine | 17 | 18 (17) | 18 | 0 | 39 | 0% | 1.5 | 0 (3) | 32 (10) | 0 (4) | 0 (3) | 22 (14) |
| Opponent | Wizard | 32 | 26 (32) | 26 | 0 | 19 | 19% | 2.7 | 11 (15) | 60 (12) | 0 (2) | 7 (15) | 64 (14) |

### Charged fights: fafix-opp-5e477c5-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 167 | 62 | 1.2 | 1.4 | 50 | 10 | +40 | 1 of 5 | 5 of 5 | +113 | +21 |
| Mine | Chaos Dwarfs | 4 | 327 | 54 | 2.2 | 1.0 | 24 | 10 | +14 | 4 of 9 | 4 of 9 | - | +14 |
| Mine | Dwarfen Mountain Holds | 3 | 497 | 184 | 2.3 | 1.1 | 79 | 9 | +70 | 0 of 7 | 6 of 7 | -60 | +92 |
| Mine | Empire of Man | 5 | 232 | 120 | 2.0 | 1.1 | 60 | 0 | +60 | 4 of 10 | 8 of 10 | +104 | +55 |
| Mine | Grand Cathay | 5 | 260 | 197 | 2.0 | 1.0 | 98 | 43 | +55 | 5 of 10 | 7 of 10 | - | +55 |
| Mine | High Elf Realms | 4 | 150 | 280 | 4.2 | 1.1 | 66 | 7 | +59 | 3 of 17 | 16 of 17 | +28 | +63 |
| Mine | Kingdom of Bretonnia | 1 | 104 | 448 | 3.0 | 1.3 | 149 | 0 | +149 | 0 of 3 | 3 of 3 | +190 | +129 |
| Mine | Lizardmen | 1 | 232 | 144 | 4.0 | 1.0 | 36 | 35 | +1 | 2 of 4 | 2 of 4 | - | +1 |
| Mine | Ogre Kingdoms | 1 | 0 | 116 | 2.0 | 1.0 | 58 | 45 | +13 | 0 of 2 | 1 of 2 | - | +13 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 307 | 2.0 | 1.0 | 154 | 28 | +126 | 1 of 2 | 1 of 2 | - | +126 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 998 | 5.5 | 1.1 | 181 | 6 | +175 | 3 of 11 | 10 of 11 | +663 | +127 |
| Mine | Vampire Counts | 2 | 0 | 188 | 3.0 | 1.0 | 62 | 143 | -81 | 0 of 6 | 4 of 6 | - | -81 |
| Mine | Warriors of Chaos | 2 | 71 | 152 | 1.5 | 1.3 | 102 | 39 | +63 | 1 of 3 | 2 of 3 | -116 | +152 |
| **Mine** | all armies | 36 | 195 | 206 | 2.5 | 1.1 | 82 | 23 | +59 | 24 of 90 | 70 of 90 | +119 | +53 |
| Opponent | Empire of Man | 1 | 490 | 288 | 1.0 | 1.0 | 288 | 0 | +288 | 1 of 1 | 1 of 1 | - | +288 |
| Opponent | Grand Cathay | 3 | 131 | 469 | 2.0 | 1.5 | 234 | 0 | +234 | 1 of 6 | 5 of 6 | +476 | +114 |
| Opponent | High Elf Realms | 3 | 224 | 88 | 1.3 | 1.0 | 66 | 70 | -4 | 4 of 4 | 2 of 4 | - | -4 |
| Opponent | Kingdom of Bretonnia | 2 | 188 | 36 | 0.5 | 1.0 | 73 | 0 | +73 | 0 of 1 | 1 of 1 | - | +73 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 432 | 2.0 | 1.5 | 216 | 172 | +44 | 2 of 2 | 1 of 2 | -345 | +432 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 84 | 758 | 4.2 | 1.0 | 178 | 19 | +160 | 11 of 17 | 13 of 17 | - | +160 |
| Opponent | Vampire Counts | 6 | 14 | 546 | 3.0 | 1.1 | 182 | 2 | +180 | 4 of 18 | 16 of 18 | +902 | +137 |
| Opponent | Warriors of Chaos | 9 | 22 | 377 | 2.0 | 1.0 | 188 | 4 | +185 | 7 of 18 | 12 of 18 | - | +185 |
| Opponent | Wood Elf Realms | 6 | 47 | 146 | 1.7 | 1.2 | 88 | 81 | +6 | 4 of 10 | 6 of 10 | +106 | -5 |
| **Opponent** | all armies | 36 | 79 | 362 | 2.1 | 1.1 | 169 | 24 | +145 | 34 of 77 | 57 of 77 | +323 | +133 |

### Effective charges: fafix-opp-5e477c5-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net +45) | 0 | 0 | 2 (net +76) | 0 | 0 | 2 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 9 | 2 (net -46) | 1 (net +0) | 1 (net +0) | 2 (net +85) | 0 | 3 (net +15) | 0 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 7 | 1 (net +0) | 1 (net -60) | 1 (net +342) | 2 (net +65) | 0 | 2 (net +40) | 0 | 14% (1 of 7) |
| Mine | Empire of Man | 10 | 2 (net +0) | 0 | 0 | 2 (net +62) | 2 (net +34) | 4 (net +102) | 0 | 0% (0 of 10) |
| Mine | Grand Cathay | 10 | 1 (net +0) | 1 (net -434) | 1 (net +396) | 3 (net +118) | 0 | 3 (net +45) | 1 | 11% (1 of 9) |
| Mine | High Elf Realms | 17 | 0 | 0 | 2 (net +0) | 4 (net +18) | 9 (net +64) | 2 (net +178) | 0 | 12% (2 of 17) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +190) | 0 | 1 (net +0) | 0 | 0 | 1 (net +258) | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 4 | 1 (net -141) | 1 (net +0) | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +116) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +307) | 1 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 11 | 0 | 0 | 4 (net +197) | 0 | 4 (net +98) | 3 (net +251) | 0 | 36% (4 of 11) |
| Mine | Vampire Counts | 6 | 1 (net -229) | 0 | 0 | 1 (net -631) | 2 (net +52) | 1 (net +98) | 1 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net -116) | 0 | 1 (net +170) | 1 | 0% (0 of 2) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +288) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 6 | 0 | 0 | 1 (net +230) | 3 (net +75) | 1 (net +0) | 1 (net +952) | 0 | 17% (1 of 6) |
| Opponent | High Elf Realms | 4 | 1 (net +265) | 0 | 0 | 0 | 0 | 3 (net -93) | 0 | 0% (0 of 4) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 1 (net +73) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 2 | 1 (net -345) | 1 (net +432) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 17 | 1 (net +704) | 0 | 4 (net +134) | 6 (net +177) | 0 | 4 (net +58) | 2 | 27% (4 of 15) |
| Opponent | Vampire Counts | 18 | 3 (net +274) | 1 (net +15) | 4 (net +98) | 3 (net +78) | 2 (net +72) | 4 (net +366) | 1 | 24% (4 of 17) |
| Opponent | Warriors of Chaos | 18 | 0 | 1 (net +0) | 6 (net +230) | 3 (net +167) | 2 (net +112) | 2 (net +282) | 4 | 43% (6 of 14) |
| Opponent | Wood Elf Realms | 10 | 2 (net -172) | 0 | 0 | 1 (net +0) | 0 | 1 (net +176) | 6 | 0% (0 of 4) |

### Charged fights, damage counted: fafix-opp-5e477c5-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 177 | 229 | -23 | 48 | 81 | -32 | -18.2 |
| Mine | 50-54% | 4 | 244 | 260 | -124 | 48 | 139 | -91 | -37.3 |
| Mine | Effective (55-75%) | 11 | 225 | 205 | +149 | 186 | 16 | +169 | +75.3 |
| Mine | 76-89% | 17 | 243 | 189 | +15 | 74 | 72 | +3 | +1.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 219 | 154 | +113 | 133 | 14 | +119 | +54.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 17 | 388 | 72 | +67 | 74 | 10 | +64 | +16.5 |
| Mine | No odds | 8 | 444 | 177 | +51 | 104 | 24 | +79 | +17.8 |
| Mine | All fights | 90 | 273 | 167 | +59 | 101 | 38 | +63 | +23.2 |
| Opponent | Long shot (under 50%) | 8 | 305 | 269 | +138 | 299 | 139 | +160 | +52.6 |
| Opponent | 50-54% | 3 | 198 | 266 | +149 | 195 | 79 | +116 | +58.3 |
| Opponent | Effective (55-75%) | 15 | 310 | 222 | +169 | 196 | 38 | +158 | +50.9 |
| Opponent | 76-89% | 17 | 249 | 175 | +123 | 135 | 35 | +100 | +40.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 412 | 245 | +212 | 249 | 51 | +198 | +48.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 524 | 91 | +74 | 103 | 0 | +103 | +19.7 |
| Opponent | No odds | 13 | 136 | 204 | +94 | 130 | 56 | +75 | +55.1 |
| Opponent | All fights | 77 | 297 | 212 | +145 | 187 | 53 | +134 | +45.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fafix-opp-5e477c5-p3 | move | 422 | 83 (20%) | 61 (14%) | 39 (9%) | 300 (71%) |
| fafix-opp-5e477c5-p3 | objective | 195 | 32 (16%) | 23 (12%) | 12 (6%) | 151 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

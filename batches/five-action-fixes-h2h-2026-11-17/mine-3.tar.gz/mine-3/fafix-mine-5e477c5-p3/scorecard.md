# Doctrine scorecard: fafix-mine-5e477c5-p3

### Scorecard: fafix-mine-5e477c5-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 20 | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 5 | 1 | 5 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 6 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | 6 | 0 | 2 | 0 | 0 | 0 | 85 |
| L0311 | 5 | 1 | Opponent | yes | - | 4 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 110 |
| L0327 | 3 | 1 | Opponent | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 4 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 302 |
| L0429 | 3 | 1 | Mine | yes | 3 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 95 |
| L0516 | 6 | 1 | Opponent | no | 5 | - | 1 | 1 | 1 | 0 | 0 | 477 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 521 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 698 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 1 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Mine | yes | 14 | 2 | 1 | 2 | 0 | 0 | 0 | 45 |
| L0709 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 524 |
| L0725 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0725 | 5 | 1 | Opponent | yes | - | 4 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 36 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 350 |
| L0831 | 3 | 1 | Opponent | no | 5 | 2 | 1 | 3 | 3 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 726 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 165 |
| L1013 | 5 | 1 | Opponent | yes | - | 5 | 1 | 2 | 1 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 2 | - | 2 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 2 | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 3 | 5 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1122 | 6 | 1 | Opponent | no | 7 | 3 | 3 | 2 | 2 | 0 | 0 | 144 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 165 |
| L1216 | 4 | 1 | Opponent | no | 1 | 3 | 1 | 3 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 4 | 2 | 5 | 0 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | yes | 7 | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 5 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 145 |
| L1519 | 1 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 115 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 6 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | no | 3 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 405 |
| L1731 | 3 | 1 | Mine | yes | 1 | 4 | 2 | 0 | 0 | 0 | 0 | 49 |
| L1731 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 170 |
| L1831 | 1 | 1 | Mine | no | 2 | 6 | 2 | 0 | 0 | 0 | 0 | 185 |
| L1831 | 1 | 1 | Opponent | no | 15 | 2 | 3 | 0 | 1 | 0 | 0 | 340 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 2 | 0 | 2 | 0 | 0 | 265 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | - | 0 | 6 | 2 | 0 | 0 | 485 |
| L2033 | 5 | 1 | Opponent | yes | - | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | yes | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 60 |
| L2327 | 5 | 1 | Opponent | yes | - | 3 | 2 | 6 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 1 | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 144 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 2 | 1 | 2 | 0 | 3 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 4 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 38% | 2.7 | 3.7 | 1.1 | 1.4 | 0.3 | 0.0 | 0.0 | 147.8 |
| **Average** | | | Opponent | 28% | 3.4 | 2.6 | 2.4 | 2.3 | 0.4 | 0.0 | 0.0 | 145.2 |

### KPIs: fafix-mine-5e477c5-p3

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE; both sides: LIKELY CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 24% (42 of 174) | 12% (21 of 169) | 18% (63 of 343) |
| Winner chose to follow up after the loser gave ground |  | 100% (30 of 30); on the table 100% | 90% (46 of 51); on the table 92% | 94% (76 of 81); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (8 of 8); on the table 100% | 78% (7 of 9); on the table 78% | 88% (15 of 17); on the table 88% |
| Winner chose to pursue after the loser fled |  | 83% (15 of 18); on the table 83% | 68% (15 of 22); on the table 73% | 75% (30 of 40); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 95% (53 of 56); on the table 95% | 83% (68 of 82); on the table 85% | 88% (121 of 138); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 32% (111 of 342) | 42% (80 of 192) | 36% (191 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (111 of 278) | 49% (80 of 164) | 43% (191 of 442) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 65% (11 of 17) | 52% (34 of 66) | 54% (45 of 83) |
| Points that never fought | lower | 52% (36108 of 68801) | 57% (40911 of 71990) | 55% (77019 of 140791) |
|   infantry points that never fought | lower | 56% (7888 of 14174) | 72% (10297 of 14220) | 64% (18185 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (177 of 272) | 60% (171 of 285) | 62% (348 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 100% (25 of 25); 2.1 uses a game | 100% (24 of 24); 2.3 uses a game | 100% (49 of 49); 2.2 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 0.3 uses a game | 17% (1 of 6); 0.0 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 36% (5 of 14); 0.1 uses a game | 47% (16 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (37288 of 59391) | 55% (35106 of 64043) | 59% (72394 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (34%) | 1.2 (39%) | 3.4 (36%) |
| MARCHED: its unit marched | 2.1 (32%) | 0.8 (26%) | 2.9 (30%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (4%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.5 (7%) | 0.3 (11%) | 0.8 (8%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (5%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.7 (11%) | 0.3 (10%) | 1.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (7%) | 0.1 (4%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.1 | 1.3 | 2.1 | 5.3 | 1.0 | 0.6 |
| not cast | 3.7 | 1.4 | 4.1 | 9.5 | 2.3 | 20.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (2%) | 0.8 (61%) | 0.4 (9%) | 3.4 (36%) | 0.6 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.9 (30%) | 0.3 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.2 (5%) | 0.8 (8%) | 0.0 (1%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.0 (0%) | 0.4 (9%) | 0.2 (3%) | 0.1 (5%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| GONE: slain | 0.4 (11%) | 0.1 (6%) | 0.5 (12%) | 1.0 (11%) | 0.2 (9%) | 1.4 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (12%) | 0.1 (6%) | 0.1 (3%) | 0.6 (6%) | 0.1 (6%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (5%) | 0.2 (12%) | 0.0 (0%) | 0.1 (1%) | 0.8 (37%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (65%) | 0.2 (14%) | 2.3 (58%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.8 a game | 1.1 a game |
| stood (cast and not dispelled) | 57% (27 of 47) | 60% (15 of 25) | 58% (42 of 72) |
| the unit moved after it | 81% (22 of 27) | 73% (11 of 15) | 79% (33 of 42) |
| it charged on its next turn | 0% (0 of 27) | 7% (1 of 15) | 2% (1 of 42) |
| the enemy charged it first | 4% (1 of 27) | 0% (0 of 15) | 2% (1 of 42) |
| it fought by the end of its next turn | 0% (0 of 27) | 0% (0 of 15) | 0% (0 of 42) |
| it moved out of a charge the enemy had planned (not charged first) | 41% (11 of 27) | 0% (0 of 15) | 26% (11 of 42) |
| none of these (no charge, no fight, no charge escaped) | 56% (15 of 27) | 93% (14 of 15) | 69% (29 of 42) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (509 of 762) | 62% (398 of 642) | 65% (907 of 1404) |
|   cavalry | 69% (44 of 64) | 62% (69 of 112) | 64% (113 of 176) |
|   character | 62% (60 of 97) | 27% (33 of 123) | 42% (93 of 220) |
|   chariot | 58% (55 of 95) | 60% (21 of 35) | 58% (76 of 130) |
|   infantry | 62% (124 of 199) | 72% (200 of 278) | 68% (324 of 477) |
|   monster | 53% (19 of 36) | 50% (3 of 6) | 52% (22 of 42) |
|   war machine | 76% (207 of 271) | 82% (72 of 88) | 78% (279 of 359) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (28%) | 1.7 (25%) | 3.6 (26%) |
| CHARGED: it charged | 0.4 (6%) | 1.6 (23%) | 2.0 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.4 (5%) | 0.2 (4%) | 0.6 (4%) |
| MOVED: a war machine that moved | 1.3 (18%) | 0.1 (1%) | 1.4 (10%) |
| NO TARGET IN RANGE | 1.4 (20%) | 1.2 (18%) | 2.6 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.3 (5%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.9 (13%) | 1.2 (18%) | 2.1 (15%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (5%) | 0.1 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 0.8 | 85% | 4.7 pts | 22 pts |
| character | 3.0 | 0.9 | 81% | 3.9 pts | 12 pts |
| chariot | 2.1 | 1.1 | 68% | 13.5 pts | 29 pts |
| infantry | 13.9 | 5.3 | 75% | 10.5 pts | 146 pts |
| monster | 0.7 | 0.1 | 85% | 1.7 pts | 1 pts |
| war machine | 8.1 | 7.6 | 60% | 27.9 pts | 227 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.8 | 5.0 | 3.4 |
| Charges that made contact a game | 1.4 | 3.1 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.30 contact (27 units) | 0.59 declared, 0.41 contact (17 units) | 0.43 declared, 0.34 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.78 declared, 0.56 contact (9 units) | 0.67 declared, 0.50 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.24 declared, 0.19 contact (230 units) | 0.61 declared, 0.38 contact (267 units) | 0.44 declared, 0.29 contact (497 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (44 of 77) | 53% (8 of 15) | 60% (6 of 10) | 57% (58 of 102) |
| Character in a unit | 91% (39 of 43) | 89% (17 of 19) | 80% (4 of 5) | 90% (60 of 67) |
| Character on its own | 76% (26 of 34) | 62% (23 of 37) | 44% (31 of 70) | 57% (80 of 141) |
| Chariot | 91% (10 of 11) | 58% (7 of 12) | - | 74% (17 of 23) |
| Infantry | 57% (40 of 70) | 45% (19 of 42) | 60% (3 of 5) | 53% (62 of 117) |
| Monster | 65% (22 of 34) | 43% (3 of 7) | - | 61% (25 of 41) |
| Monstrous | 90% (9 of 10) | 64% (7 of 11) | - | 76% (16 of 21) |
| War Machines | 67% (29 of 43) | 50% (1 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (2 of 2); on the table 100% | 26% (25 of 96) | 56% | 77% (17 of 22) | 100% (6 of 6); 5.8 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (15 of 15); on the table 100% | 44% (16 of 36) | 46% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | - | - | 69% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (3 of 3); on the table 100% | 47% (14 of 30) | 69% | 71% (42 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 75% (9 of 12); on the table 75% | 38% (73 of 192) | 59% | 54% (40 of 74) | 100% (18 of 18); 7.0 uses a game | 50% (2 of 4); 0.2 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 78% (7 of 9); on the table 78% | 31% (13 of 42) | 69% | 70% (38 of 54) | 100% (9 of 9); 3.7 uses a game | 25% (3 of 12); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (1 of 1); on the table 100% | - | 67% | 56% (10 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 51% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 2% | 71% (5 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (4 of 4); on the table 100% | 25% (3 of 12) | 49% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 0% (0 of 3); on the table 67% | 17% (2 of 12) | 76% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 89% (8 of 9); on the table 89% | 17% (1 of 6) | 47% | 50% (13 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 91% (21 of 23); on the table 91% | 46% (25 of 54) | 48% | 59% (27 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 88% (36 of 41); on the table 88% | 43% (13 of 30) | 41% | 56% (54 of 96) | 100% (4 of 4); 1.5 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 93% (13 of 14); on the table 93% | 8% (1 of 12) | 56% | 66% (41 of 62) | 100% (11 of 11); 5.5 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fafix-mine-5e477c5-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 54% (38) | 37% (13) | 49% (51) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.31 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.03 | 0.14 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.22 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.06 | 1.36 | 1.42 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.03 | 0.61 | 0.64 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.03 | 7.06 | 7.08 |

### Quality by phase: fafix-mine-5e477c5-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 55% (34 of 62) | 45% (65 of 146) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (143 of 333) | 50% (138 of 275) |
| Strategy | Close-in objectives charged next turn | - | 16% (42 of 263) |
| Strategy | Support requests answered (helper made contact too) | 78% (7 of 9) | 37% (10 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (4 of 12) | 75% (6 of 8) |
| Strategy | Joined characters whose unit fought | 26% (11 of 42) | 27% (15 of 55) |
| Strategy | Lone characters that fought | 57% (53 of 93) | 59% (47 of 79) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.4 | 2.3 |
| Movement | Points that never moved of their own | 147.8 | 145.2 |
| Movement | Fights charged into per game | 1.3 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 38, net -183 | 13 of 73, net +21 |
| Movement | Charges with odds: sweet spot (55-75%) | 6 of 38, net +14 | 21 of 73, net +70 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 38, net +60 | 4 of 73, net +122 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 of 38, net -22 | 15 of 73, net +114 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.2 | 10.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (122 of 331) | 47% (184 of 390) |
| Shooting | Points destroyed by shooting units | 78.4 | 66.4 |
| Shooting | War machine shots | 5.8 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (113 of 207) | 52% (45 of 86) |
| Shooting | Points destroyed by war machines | 77.0 | 14.7 |
| Magic | Magic missiles cast | 2.2 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (31 of 79) | 27% (15 of 55) |
| Magic | Wounds caused by magic missiles | 3.2 | 2.4 |
| Magic | Wounds caused by other spells | 0.7 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 45.1 | 31.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.3 / 0.3 / 0.2 | 1.9 / 0.4 / 0.1 / 0.4 |
| Combat | Points destroyed in combat | 148.8 | 310.4 |
| Combat | Points run down | 25.1 | 51.7 |
| Combat | Net points per charged fight, damage counted | +27 | +108 |
| Combat | Net per 100 charger points, damage counted | +9.8 | +38.9 |
| Combat | First round won (charged fights) | 66% | 75% |
| Combat | Net points per charged fight | +16 | +100 |
| Combat | Net points per supported fight / lone fight | -22 / +23 | +128 / +95 |
| Combat | Charged fights on a top-3 enemy unit | 10 of 47 | 35 of 93 |
| Game | Points lost | 636.0 | 408.4 |
| Game | VP from objectives | 442.5 | 685.0 |
| Game | Lone holders (player turns) | 2.7 | 3.4 |

- Mine won / drew / lost: 6 / 10 / 20 of 36 ended games (of 36); mean margin (Mine - Opponent) -503 VP
- The side that went first won 12 of 26 games with a winner
- Points traded per game (both sides' losses): 1044
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fafix-mine-5e477c5-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 4.8 | -170.6 | 124.9 | 27.8 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 2.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 7.2 | 0.2 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.7 | +2.2 | 0.0 | 8.1 | 0.6 | +3.5 | 0.0 | 5.4 |
| BEST FACING | - | - | - | - | 0.3 | +14.7 | 0.0 | 0.0 |
| BEST FIRST | - | - | - | - | 1.0 | +59.1 | 2.6 | 0.0 |
| BEST OVERALL | - | - | - | - | 0.2 | +6.6 | 0.0 | 0.0 |
| BEST PREY | - | - | - | - | 0.7 | +32.5 | 26.6 | 8.4 |
| BEST PRIZE | 0.0 | -7.7 | 4.7 | 0.0 | 0.1 | -0.5 | 6.9 | 6.5 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.2 | -2.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.4 | +12.0 | 0.0 | 11.1 |
| BLOWS WHERE AIMED | 0.0 | -1.0 | 0.0 | 5.4 | 0.5 | -63.5 | 59.8 | 11.5 |
| BOMBING RUN | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 68.2 | 8.3 | 0.2 | +0.0 | 14.8 | 4.6 |
| CANNON PLANNED TARGET | 5.1 | +142.5 | 316.8 | 97.5 | 1.3 | +66.6 | 25.2 | 15.7 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 7.7 |
| CARRIES OUT COUNTER | 0.0 | -2.2 | 6.4 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | -1.0 | 8.9 | 0.0 |
| CAST JOB | 0.5 | +12.6 | 26.3 | 4.7 | 0.7 | +21.8 | 18.5 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +30.1 | 12.3 | 0.0 | 0.1 | +0.6 | 0.0 | 3.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 9.9 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +1.0 | 0.0 | 2.4 | - | - | - | - |
| CHAFF IN THE MOVE | 0.2 | +7.4 | 0.0 | 0.0 | 2.4 | +124.1 | 0.0 | 30.8 |
| CHAFF PASSED | 0.5 | -0.5 | 5.4 | 1.7 | 0.2 | -0.6 | 0.0 | 1.8 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 5.2 | - | - | - | - |
| CHARGE LOSSES | 10.7 | -641.7 | 0.0 | 296.1 | - | - | - | - |
| CHARGE NOW FIRST | 0.6 | +0.0 | 65.8 | 27.2 | 2.2 | +0.0 | 167.2 | 29.1 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.4 | -50.9 | 0.0 | 4.7 |
| CHARGER SLAIN LOST | 0.3 | -8.3 | 14.3 | 6.4 | 0.5 | -15.3 | 38.5 | 15.0 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 6.1 | 32.8 | 0.2 | +0.0 | 0.0 | 9.4 |
| CONVEYANCE SEARCH | 1.0 | +114.0 | 19.5 | 20.4 | 0.5 | +34.3 | 3.0 | 6.5 |
| COVER ONCE | 7.5 | -558.0 | 0.0 | 188.5 | 7.0 | -579.8 | 0.0 | 69.2 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 30.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | -0.9 | 0.0 | 0.0 | 0.0 | +2.6 | 0.0 | 6.1 |
| EDGE GIVE GROUND | 0.1 | +6.7 | 5.8 | 5.4 | 0.3 | +20.3 | 53.3 | 3.2 |
| ELIXIR WORTH | 0.1 | +1.9 | 0.0 | 9.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.1 | +1.4 | 0.0 | 3.2 | 1.4 | +79.8 | 0.0 | 1.9 |
| FALL BACK GOOD ORDER | 0.9 | +1.1 | 65.3 | 13.1 | - | - | - | - |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.0 | 6.3 | +118.7 | 0.0 | 36.4 |
| FALLS SHORT | 0.1 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| FEATURE BUFFS | 1.4 | +34.6 | 0.0 | 17.5 | - | - | - | - |
| FIGHT LIFT | - | - | - | - | 0.0 | +1.1 | 7.3 | 0.0 |
| FIVE ACTION | 44.8 | +1075.7 | 669.1 | 684.6 | - | - | - | - |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 172.9 | 6.4 | +0.0 | 0.0 | 114.9 |
| FOCUS FIRE | 0.0 | +1.0 | 2.0 | 4.9 | 0.1 | +1.8 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +92.7 | 0.0 | 8.6 | 0.8 | +86.0 | 0.0 | 9.3 |
| FOUR ROUNDS | 1.6 | +55.8 | 100.6 | 28.9 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.0 | +2.3 | 0.0 | 0.0 | 0.1 | +5.5 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.4 | 6.4 | 0.0 | 0.1 | -1.0 | 6.1 | 5.4 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.7 | 11.8 | 4.5 |
| GUN MASK | 0.5 | +4.7 | 0.0 | 32.2 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 3.4 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 8.2 | 1.7 | 0.3 | +0.0 | 33.8 | 13.8 |
| HILL BY ITS CHANCE | - | - | - | - | 0.6 | -72.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.1 | -31.5 | 82.4 | 17.1 | 8.9 | -196.4 | 442.1 | 108.8 |
| HORN WORTH | - | - | - | - | 0.1 | +1.8 | 0.0 | 14.0 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +9.9 | 2.4 | 12.2 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 6.4 |
| HUNT IN PAIRS | 0.2 | +1.7 | 0.0 | 0.0 | 1.0 | +79.3 | 0.0 | 5.4 |
| HUNT KEPT | 0.1 | +2.1 | 0.0 | 0.0 | 0.1 | +2.0 | 2.4 | 6.1 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +2.6 | 8.9 | 9.7 |
| HUNT THE GUNS | 0.0 | +7.6 | 0.0 | 0.0 | 0.2 | +81.9 | 2.4 | 9.3 |
| IDLE COST | 16.2 | -276.3 | 0.0 | 139.7 | 19.8 | -370.6 | 0.0 | 157.9 |
| INVITES THE FIGHT | - | - | - | - | 1.0 | +9.1 | 48.3 | 19.9 |
| JOINT CHARGE PLAN | - | - | - | - | 0.3 | +8.6 | 20.2 | 8.4 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.6 | 7.6 | 0.0 | 0.1 | -2.5 | 20.7 | 0.0 |
| KEEP FALLS | 0.1 | +1.5 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +1.6 | 3.8 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.4 | +73.3 | 150.2 | 28.3 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 1.8 | +78.6 | 133.2 | 25.0 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.4 | +268.1 | 226.6 | 112.6 |
| LONE CHARACTER SAFE SPOT | 0.2 | -0.7 | 0.0 | 5.8 | 0.2 | +23.5 | 1.7 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.3 | +0.0 | 8.4 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +1.0 | 8.8 | 0.0 | 0.2 | +0.1 | 22.9 | 17.0 |
| LOST CHARGE | 0.1 | -0.2 | 9.3 | 0.0 | 2.1 | -32.8 | 56.2 | 7.2 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -5.9 | 0.0 | 4.0 |
| MAKE SURE TOGETHER | 0.2 | +0.9 | 0.0 | 0.0 | 1.3 | +138.9 | 41.2 | 45.7 |
| MANOEUVRE | 1.2 | +36.2 | 0.0 | 12.6 | 0.2 | +2.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +2.9 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +28.8 | 0.0 | 2.2 | 0.6 | +31.1 | 0.0 | 0.0 |
| MARCH ODDS | - | - | - | - | 0.2 | +22.9 | 12.5 | 11.0 |
| MARCH OVER CASTS | 1.1 | +206.4 | 0.0 | 51.5 | 0.4 | +15.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 7.8 | +98.7 | 0.0 | 149.2 | 7.6 | +125.9 | 0.0 | 98.8 |
| MISSILES IN THE MOVE | 4.8 | +149.9 | 0.0 | 106.0 | 4.6 | +79.6 | 0.0 | 53.2 |
| MISSILES NEXT TURN | 6.3 | +102.1 | 0.0 | 160.2 | 5.5 | +53.1 | 0.0 | 68.2 |
| MODEL FACING | 0.2 | +49.1 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 8.9 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.7 | +29.8 | 0.0 | 3.0 |
| MOVE SPELL IN RANGE | 0.3 | +8.5 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -20.5 | 17.6 | 9.9 | 0.1 | -5.2 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 5.2 | +464.0 | 226.8 | 69.5 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +0.0 | 11.1 | 0.0 |
| NEXT CHARGE BY LIST | 14.2 | -245.6 | 35.8 | 192.8 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 4.3 | -280.2 | 45.4 | 52.4 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.2 | -50.3 | 86.6 | 19.6 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +1.7 | 0.0 | 7.2 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.4 | -16.7 | 31.2 | 4.5 |
| NOT TURNED | 0.0 | +0.0 | 0.0 | 0.0 | 7.1 | +57.9 | 0.0 | 127.2 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 9.9 | 0.8 | -0.9 | 0.0 | 6.5 |
| OFF BEST | 1.3 | -40.5 | 0.0 | 16.1 | 16.9 | -746.4 | 8.8 | 177.0 |
| ONE FIGHT FORMULA | 8.5 | -161.1 | 0.0 | 147.4 | 8.9 | -190.5 | 46.1 | 146.7 |
| ONE OBJECTIVE FORMULA | 3.0 | +1.7 | 0.0 | 46.6 | 2.7 | -113.3 | 0.0 | 7.0 |
| OPENS A LANE | 0.1 | +1.1 | 4.7 | 10.6 | 0.3 | +5.4 | 5.0 | 39.6 |
| OPENS UP | 0.1 | +9.0 | 9.3 | 0.0 | 0.2 | +19.8 | 11.7 | 0.0 |
| OVERRUNS AWAY | 0.1 | +0.6 | 3.5 | 0.0 | 0.5 | +6.3 | 35.2 | 6.5 |
| PATHS CROSS | 2.5 | +208.4 | 0.0 | 16.3 | 3.1 | +250.5 | 0.0 | 17.0 |
| PERIAPT WORTH | 0.0 | +1.7 | 0.0 | 0.0 | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -6.1 | 0.0 | 0.0 | 0.1 | -1.8 | 0.0 | 1.9 |
| PLAN RESULT | 39.6 | +685.9 | 389.7 | 846.5 | 40.4 | +1191.3 | 976.6 | 586.1 |
| PURSUES BIG PREY | 0.0 | -0.1 | 0.0 | 0.0 | 0.0 | -1.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +3.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +15.3 | 0.0 | 20.0 | 1.8 | +12.4 | 0.0 | 33.1 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.6 | -28.9 | 6.2 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +0.4 | 0.0 | 0.0 | 1.9 | -39.8 | 0.0 | 25.9 |
| REDIRECT COUNTER | 2.6 | +160.2 | 0.0 | 45.9 | 4.3 | +375.5 | 0.0 | 49.1 |
| REDIRECT WEIGHED | 0.2 | -5.4 | 4.7 | 0.0 | 0.4 | +11.2 | 13.7 | 6.5 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 9.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.6 | +25.5 | 0.0 | 17.1 | 1.1 | +28.0 | 0.0 | 14.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +2.0 | 0.0 | 3.8 |
| RISK BY ARC | 1.0 | +47.9 | 78.5 | 23.5 | 2.2 | +60.9 | 170.4 | 56.2 |
| RISK ONCE | - | - | - | - | 4.2 | +143.7 | 45.7 | 153.1 |
| RUN DOWN | 1.0 | -7.5 | 63.4 | 10.9 | - | - | - | - |
| SAFER THAN THE JOB | 0.0 | +0.7 | 0.0 | 0.0 | 0.6 | +21.7 | 0.0 | 0.0 |
| SCALED CHANCE | 4.1 | +40.3 | 21.5 | 44.7 | - | - | - | - |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.9 | 0.0 | 0.0 | 0.6 | -44.5 | 0.0 | 3.2 |
| SEARCH SPOT | 6.9 | +370.7 | 0.0 | 147.1 | 2.3 | +151.8 | 0.0 | 8.1 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.4 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.4 | +46.7 | 0.0 | 40.1 | 0.1 | +43.8 | 0.0 | 11.0 |
| SET UP TOGETHER | 0.3 | +3.1 | 0.0 | 6.3 | 2.2 | +222.4 | 57.4 | 54.4 |
| SET-UP ANY TARGET | 0.3 | +42.6 | 0.0 | 0.0 | 0.2 | +24.4 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +4.9 | 0.0 | 0.0 | 0.0 | +4.4 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +69.4 | 35.2 | 41.7 | 1.3 | +57.5 | 57.8 | 7.7 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.9 | +0.0 | 150.8 | 15.7 | 0.4 | +0.0 | 78.9 | 3.8 |
| SHOTS IN THE MOVE | 15.8 | +622.7 | 0.0 | 264.0 | 10.7 | +351.5 | 0.0 | 118.3 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +42.6 | 0.0 | 0.0 | 0.2 | +24.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.6 | +19.2 | 0.0 | 19.5 | 2.5 | +33.5 | 39.1 | 30.0 |
| SPELLS IN THE FIGHT | 0.2 | -6.1 | 30.8 | 9.4 | 0.5 | -5.5 | 71.4 | 12.5 |
| STABLE ROLE | - | - | - | - | 9.8 | +0.0 | 201.2 | 107.4 |
| STAND AND SHOOT | 0.1 | -0.6 | 7.3 | 5.4 | - | - | - | - |
| STANDS TO CAST | 0.1 | +2.1 | 0.0 | 0.0 | 0.0 | +4.0 | 0.0 | 0.0 |
| STOPS | 0.1 | +2.4 | 0.0 | 0.0 | 0.1 | +5.0 | 2.4 | 3.2 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.5 | +29.1 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 52.9 | 28.9 | 6.4 | -61.2 | 161.1 | 67.4 |
| SUPPORTS | - | - | - | - | 4.2 | +61.2 | 40.8 | 25.1 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -2.7 | 10.6 | 0.0 |
| SURE REACH TOGETHER | 0.2 | +2.1 | 0.0 | 3.2 | 0.8 | +0.8 | 0.0 | 28.8 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.2 | +13.4 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 3.4 | +0.0 | 29.2 | 29.2 | - | - | - | - |
| TURN WORTH | 0.1 | -4.6 | 7.8 | 0.0 | 0.3 | -23.5 | 5.9 | 3.8 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.9 | +9.1 | 26.8 | 18.8 |
| WAIT AFTER COSTS | - | - | - | - | 8.2 | -449.6 | 295.4 | 111.4 |
| WALKS TO THE FIGHT | - | - | - | - | 1.1 | +6.4 | 14.2 | 7.9 |
| WAR ENGINE CHARGES | 0.1 | +7.8 | 5.2 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.1 | +0.0 | 6.5 | 0.0 | 0.2 | +0.0 | 2.2 | 7.5 |
| WEARS DOWN | - | - | - | - | 1.1 | +39.1 | 129.8 | 18.9 |
| WHO HITS BACK | 0.4 | +97.9 | 0.0 | 15.8 | 0.2 | +25.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +4.1 | 8.7 | 3.2 | 0.1 | +2.5 | 8.4 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +17.4 | 16.0 | 0.0 | 0.6 | +49.1 | 43.7 | 9.8 |
| WIDER SPREAD | 1.1 | -3.3 | 84.1 | 18.6 | 2.9 | -10.0 | 252.7 | 56.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 5.2 | 0.0 |

### Rule changes: fafix-mine-5e477c5-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 654 | 654 | 654 | 18.17 | -28327 | -43.3 |
| SEARCH SPOT | 329 | 329 | 315 | 8.75 | +18811 | +59.7 |
| PATHS CROSS | 199 | 199 | 199 | 5.53 | +16519 | +83.0 |
| SHOTS IN THE MOVE | 951 | 791 | 121 | 3.36 | +3123 | +25.8 |
| MOVE TO CHARGE | 188 | 188 | 97 | 2.69 | +7460 | +76.9 |
| IDLE COST | 1297 | 795 | 95 | 2.64 | +1110 | +11.7 |
| COVER ONCE | 522 | 356 | 91 | 2.53 | +2208 | +24.3 |
| FIVE ACTION | 1614 | 1613 | 87 | 2.42 | +3111 | +35.8 |
| KILLS COUNT NEXT TURN | 266 | 266 | 83 | 2.31 | +2332 | +28.1 |
| MAX FOR POSITIONING | 556 | 445 | 76 | 2.11 | +260 | +3.4 |
| MISSILES IN THE MOVE | 339 | 258 | 70 | 1.94 | +1260 | +18.0 |
| CHARGE LOSSES | 384 | 384 | 68 | 1.89 | +6302 | +92.7 |
| FALLBACK BY WORTH | 232 | 232 | 62 | 1.72 | +4272 | +68.9 |
| REDIRECT COUNTER | 247 | 159 | 62 | 1.72 | +4951 | +79.9 |
| RESERVE FALL BACK | 61 | 61 | 61 | 1.69 | +1925 | +31.6 |
| CHAFF IN THE MOVE | 94 | 89 | 60 | 1.67 | +2080 | +34.7 |
| SUPPORTS | 153 | 153 | 58 | 1.61 | +654 | +11.3 |
| ARTILLERY RE-ROLL WEIGHED | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| ONE FIGHT FORMULA | 626 | 448 | 56 | 1.56 | +407 | +7.3 |
| WAIT AFTER COSTS | 296 | 296 | 52 | 1.44 | +1360 | +26.2 |
| FACES THE THREAT | 51 | 51 | 51 | 1.42 | +2925 | +57.4 |
| FOLLOW UP WEIGHED | 50 | 50 | 50 | 1.39 | +6432 | +128.6 |
| SHOT REPLANNED | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| CANNON PLANNED TARGET | 230 | 230 | 45 | 1.25 | -299 | -6.6 |
| NEXT CHARGE BY LIST | 512 | 512 | 45 | 1.25 | +390 | +8.7 |
| RANDOM MOVE BY FIGURES | 83 | 83 | 45 | 1.25 | +995 | +22.1 |
| RISK BY ARC | 117 | 115 | 41 | 1.14 | +949 | +23.1 |
| SHOOTS FROM THE BEST SPOT | 78 | 78 | 40 | 1.11 | +1622 | +40.5 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| SET UP TOGETHER | 92 | 81 | 38 | 1.06 | +2782 | +73.2 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| BEST FIRST | 35 | 35 | 35 | 0.97 | +2128 | +60.8 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| MANOEUVRE | 48 | 48 | 32 | 0.89 | +1375 | +43.0 |
| ADVANCE WORTH | 173 | 173 | 31 | 0.86 | +447 | +14.4 |
| MARCH CHECK | 36 | 34 | 29 | 0.81 | +1439 | +49.6 |
| RISK ONCE | 153 | 111 | 28 | 0.78 | +930 | +33.2 |
| CAST JOB | 42 | 42 | 25 | 0.69 | +399 | +15.9 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| CHAFF PASSED | 24 | 24 | 24 | 0.67 | -40 | -1.7 |
| HONEST WORTH | 360 | 357 | 24 | 0.67 | +309 | +12.9 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +1071 | +44.6 |
| FOUR ROUNDS | 57 | 56 | 23 | 0.64 | +811 | +35.3 |
| SAFER THAN THE JOB | 23 | 23 | 23 | 0.64 | +806 | +35.0 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +3501 | +159.1 |
| NEXT OBJECTIVE NEARER | 156 | 156 | 21 | 0.58 | +250 | +11.9 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +265 | +12.6 |
| KILLS COUNT | 66 | 66 | 20 | 0.56 | +638 | +31.9 |
| STOPS SHORT OF THE FLANK | 19 | 19 | 19 | 0.53 | +1047 | +55.1 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| CHARGE NOW FIRST | 103 | 103 | 17 | 0.47 | -511 | -30.1 |
| WHOLE FIGHT GAIN | 26 | 25 | 17 | 0.47 | +529 | +31.1 |
| CHARGE NOW WEIGHED | 16 | 16 | 16 | 0.44 | +2292 | +143.2 |
| BLOCKED WHEEL | 15 | 15 | 15 | 0.42 | +431 | +28.7 |
| HUNT IN PAIRS | 41 | 33 | 15 | 0.42 | +879 | +58.6 |
| INVITES THE FIGHT | 37 | 37 | 15 | 0.42 | +128 | +8.5 |
| KEEPS ITS TARGET | 88 | 86 | 15 | 0.42 | +222 | +14.8 |
| COMBAT PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 14 | 14 | 14 | 0.39 | -288 | -20.5 |
| MAKE SURE TOGETHER | 53 | 33 | 13 | 0.36 | +1400 | +107.7 |
| BEST FACING | 12 | 12 | 12 | 0.33 | +530 | +44.2 |
| MISSILES NEXT TURN | 424 | 309 | 12 | 0.33 | +68 | +5.7 |
| WALKS TO THE FIGHT | 41 | 41 | 12 | 0.33 | +60 | +5.0 |
| CASTING BLOCK | 11 | 11 | 11 | 0.31 | +254 | +23.1 |
| ONE OBJECTIVE FORMULA | 204 | 139 | 10 | 0.28 | +397 | +39.7 |
| BEST OVERALL | 9 | 9 | 9 | 0.25 | +237 | +26.3 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MARCH ODDS | 9 | 9 | 9 | 0.25 | +88 | +9.8 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE REACH TOGETHER | 36 | 32 | 9 | 0.25 | +73 | +8.1 |
| SCALED CHANCE | 149 | 149 | 8 | 0.22 | +32 | +4.0 |
| BEST PREY | 24 | 24 | 7 | 0.19 | +251 | +35.9 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | -76 | -10.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| OPENS UP | 12 | 12 | 7 | 0.19 | +368 | +52.6 |
| REFUSING RETIRES | 18 | 18 | 7 | 0.19 | -2 | -0.3 |
| THROUGH LINE OF FIRE | 7 | 7 | 7 | 0.19 | +484 | +69.2 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -604 | -100.8 |
| FEATURE BUFFS | 52 | 52 | 6 | 0.17 | +114 | +19.0 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +156 | +26.0 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +1767 | +294.6 |
| HORN WORTH | 5 | 5 | 5 | 0.14 | +65 | +13.0 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| EDGE GIVE GROUND | 15 | 14 | 4 | 0.11 | +158 | +39.6 |
| HUNT ADVANCE | 8 | 8 | 4 | 0.11 | +100 | +25.0 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | -44 | -11.1 |
| WAR ENGINE JOBS | 9 | 9 | 4 | 0.11 | -180 | -44.9 |
| WEARS DOWN | 38 | 37 | 4 | 0.11 | +63 | +15.7 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +101 | +33.7 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 0.08 | +280 | +93.3 |
| LONG SHOT | 14 | 14 | 3 | 0.08 | +147 | +49.1 |
| LOST CHARGE | 80 | 79 | 3 | 0.08 | +41 | +13.8 |
| STOPS | 9 | 9 | 3 | 0.08 | +62 | +20.8 |
| SUPPORT NARROWED | 255 | 255 | 3 | 0.08 | -23 | -7.6 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -97 | -32.5 |
| WHOLE FIGHT | 8 | 8 | 3 | 0.08 | +50 | +16.8 |
| WIDER SPREAD | 144 | 141 | 3 | 0.08 | +5 | +1.6 |
| BACKUP TARGETS | 44 | 31 | 2 | 0.06 | +6 | +3.2 |
| BLOWS WHERE AIMED | 20 | 17 | 2 | 0.06 | +105 | +52.6 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +49 | +24.6 |
| CHARGER SLAIN LOST | 28 | 26 | 2 | 0.06 | +12 | +5.9 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +69 | +34.6 |
| NO DOUBLE ROUNDS | 42 | 41 | 2 | 0.06 | +47 | +23.7 |
| OPENS A LANE | 16 | 7 | 2 | 0.06 | +32 | +15.8 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +161 | +80.3 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -47 | -23.5 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +20 | +9.8 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +73 | +36.4 |
| TWO OR MORE ARRIVE | 33 | 31 | 2 | 0.06 | +12 | +5.8 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.06 | +68 | +34.0 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -80 | -79.5 |
| CARRIES OUT SET-UP | 5 | 5 | 1 | 0.03 | -38 | -37.6 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -0 | -0.1 |
| DEFENSIVE ARMY | 10 | 10 | 1 | 0.03 | -13 | -12.9 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +49 | +49.2 |
| FALL BACK GOOD ORDER | 33 | 32 | 1 | 0.03 | +3 | +3.4 |
| GUN MASK | 18 | 18 | 1 | 0.03 | +28 | +27.6 |
| HILL BY ITS CHANCE | 20 | 20 | 1 | 0.03 | +36 | +35.9 |
| KEEPS ITS PREY | 3 | 3 | 1 | 0.03 | +5 | +5.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 1 | 0.03 | -144 | -143.7 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +4 | +4.4 |
| OVERRUNS AWAY | 21 | 21 | 1 | 0.03 | +5 | +4.9 |
| SPELLS IN THE FIGHT | 27 | 27 | 1 | 0.03 | +3 | +2.6 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 40 | trace | - | - | - | - |
| CHARACTER GUNS | 15 | 15 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 55 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLS SHORT | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 427 | not checked | - | - | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 14 | 14 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 10 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 12 | 12 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 4 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 14 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 56 | 56 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NEEDED THERE | 2 | 2 | 0 | 0.00 | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 255 | 255 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 48 | not checked | - | - | - | - |
| PLAN RESULT | 2879 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 20 | 20 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 73 | 73 | 0 | 0.00 | - | - |
| RUN DOWN | 35 | 34 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 22 | 22 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 147 | not checked | - | - | - | - |
| STABLE ROLE | 354 | 354 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 123 | 123 | 0 | 0.00 | - | - |
| TURN WORTH | 15 | 15 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: fafix-mine-5e477c5-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.08 | 14.86 | 43.9 |
| TURN GATE | gate | - | 0.94 | 42.3 |
| FALLBACK | gate | - | 0.75 | 45.4 |
| CHARGE NOW FIRST | rule | 0.03 | 0.44 | 30.1 |
| CHAFF PASSED | rule | 0.28 | 0.17 | 2.5 |
| PIVOT GUARDS FLANK | rule | 0.25 | 0.14 | 20.5 |
| CANNON PLANNED TARGET | rule | 0.17 | 0.11 | 38.7 |
| PATHS CROSS | rule | 0.08 | 0.11 | 58.7 |
| BEST PRIZE | rule | 0.03 | 0.14 | 100.8 |
| BIG CHARACTER SAFETY | rule | - | 0.17 | 12.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.08 | 20.1 |
| FIGHT ORDER BAND | gate | 0.03 | 0.08 | 2.1 |
| STANDS TO CAST | rule | 0.08 | 0.03 | 11.1 |
| WAR ENGINE JOBS | rule | 0.03 | 0.08 | 44.9 |
| REDIRECT WEIGHED | rule | 0.03 | 0.06 | 126.0 |
| RULE SWITCHED OFF | gate | 0.06 | 0.03 | 13.5 |
| SAFER THAN THE JOB | rule | - | 0.08 | 11.9 |
| SUPPORT NARROWED | rule | 0.03 | 0.06 | 7.6 |
| SUPPORT REQUEST | gate | - | 0.08 | 47.7 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.08 | 32.5 |
| AFTERMATH BAND | gate | 0.03 | 0.03 | 4.0 |
| FACES THE THREAT | rule | - | 0.06 | 13.8 |
| PURSUES BIG PREY | rule | 0.03 | 0.03 | 23.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 121.3 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 79.5 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 37.6 |
| CHARGE NOW WEIGHED | rule | - | 0.03 | 6.1 |
| DEFENSIVE ARMY | rule | - | 0.03 | 12.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 143.7 |
| MARCH ODDS | rule | - | 0.03 | 9.6 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 12.8 |

### Plans: fafix-mine-5e477c5-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.2 | 59% | 74 | 97 | 131% |
| Mine | join | 0.5 | 88% | 13 | 0 | 0% |
| Mine | move | 29.9 | 94% | 1111 | 0 | 0% |
| Mine | shoot | 7.9 | 60% | 194 | 589 | 303% |
| Mine | support | 0.1 | 100% | 4 | 0 | 0% |
| Opponent | advance | 11.9 | 13% | 157 | 238 | 152% |
| Opponent | charge | 3.7 | 60% | 275 | 369 | 134% |
| Opponent | close in | 7.2 | 20% | 513 | 181 | 35% |
| Opponent | hold | 4.3 | 37% | 325 | 0 | 0% |
| Opponent | join | 0.8 | 96% | 31 | 0 | 0% |
| Opponent | shoot | 6.1 | 50% | 192 | 403 | 210% |
| Opponent | support | 6.4 | 91% | 67 | 0 | 0% |

### Packages: hunt the guns, fafix-mine-5e477c5-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 275 | 0 | 0% | 37 |
| Opponent | 0.2 | 9 | 0 | 11% | 11% | 0% | 3.0 | 328 | 10 | 11% | 82 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 275 | 0 | 0% | 26 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 180 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 47 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 91 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 283 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 44 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 100 | 94 | 100% | 6 |
| Warriors of Chaos | 0.3 | 3 | 0 | 0% | 0% | 0% | - | 314 | 0 | 0% | 52 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 278 | 0 | 0% | 60 |

### Battle groups: fafix-mine-5e477c5-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.6 | 30% | 61% | 0% | - | 14% | 4% | 4% | 79% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 8% | 62% | 8% | 100% | 8% | 0% | 0% | 83% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fafix-mine-5e477c5-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 45 (34) | 22 | 23 | 39 | 38% | 3.1 | 54 (21) | 0 (4) | 38 (9) | 42 (24) | 52 (10) |
| Mine | Character | 118 | 18 (118) | 18 | 0 | 25 | 23% | 2.4 | 25 (38) | 15 (59) | 12 (6) | 19 (58) | 18 (45) |
| Mine | Clean-up | 18 | 44 (18) | 7 | 36 | 30 | 39% | 3.0 | 115 (3) | 25 (13) | 105 (2) | 62 (12) | 16 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 21 (44) | 7 | 15 | 47 | 36% | 3.4 | 20 (22) | 25 (14) | 17 (8) | 29 (30) | 8 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.5 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 28 (52) | 21 | 7 | 35 | 23% | 2.6 | 20 (14) | 33 (35) | 4 (3) | 27 (36) | 29 (16) |
| Mine | Holder | 25 | 48 (25) | 9 | 39 | 27 | 48% | 3.2 | 35 (7) | 57 (12) | 48 (5) | 91 (12) | 10 (12) |
| Mine | Shooter | 37 | 62 (37) | 32 | 30 | 34 | 5% | 1.6 | 29 (6) | 75 (28) | 0 (3) | 75 (23) | 40 (14) |
| Mine | Support | 4 | 87 (4) | 87 | 0 | 0 | 0% | 2.2 | 97 (1) | 79 (3) | - | - | 87 (4) |
| Mine | War machine | 52 | 45 (52) | 45 | 0 | 43 | 4% | 1.3 | 34 (13) | 43 (36) | 133 (3) | 16 (13) | 56 (39) |
| Mine | Wizard | 17 | 10 (17) | 10 | 0 | 50 | 6% | 2.1 | 0 (4) | 0 (9) | 121 (1) | 24 (7) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 48 (68) | 12 | 35 | 46 | 57% | 2.6 | 49 (29) | 65 (11) | 38 (28) | 45 (48) | 54 (20) |
| Opponent | Character | 102 | 46 (102) | 46 | 0 | 15 | 26% | 2.3 | 42 (40) | 54 (52) | 25 (4) | 52 (57) | 45 (39) |
| Opponent | Clean-up | 11 | 58 (11) | 17 | 41 | 31 | 18% | 3.1 | 18 (4) | 74 (6) | 108 (1) | 39 (6) | 77 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 48 (60) | 23 | 25 | 25 | 40% | 2.8 | 37 (30) | 59 (20) | 61 (10) | 51 (28) | 45 (32) |
| Opponent | Fragile | 3 | 31 (3) | 31 | 0 | 100 | 33% | 2.0 | - | 46 (2) | 0 (1) | 46 (2) | 0 (1) |
| Opponent | Hammer | 50 | 30 (50) | 13 | 17 | 21 | 52% | 2.8 | 6 (17) | 41 (30) | 0 (3) | 30 (30) | 30 (20) |
| Opponent | Holder | 40 | 77 (40) | 14 | 63 | 32 | 45% | 2.4 | 37 (6) | 78 (21) | 98 (13) | 86 (29) | 58 (11) |
| Opponent | Shooter | 27 | 69 (27) | 40 | 29 | 19 | 0% | 1.4 | 68 (6) | 61 (19) | 188 (2) | 74 (16) | 63 (11) |
| Opponent | Support | 4 | 47 (4) | 47 | 0 | 0 | 75% | 5.0 | 0 (2) | 280 (1) | 0 (1) | 0 (2) | 140 (2) |
| Opponent | War machine | 17 | 65 (17) | 65 | 0 | 33 | 12% | 1.3 | 236 (3) | 44 (10) | 17 (4) | 190 (3) | 43 (14) |
| Opponent | Wizard | 32 | 6 (32) | 6 | 0 | 10 | 19% | 2.4 | 4 (16) | 11 (12) | 0 (3) | 5 (19) | 7 (12) |

### Charged fights: fafix-mine-5e477c5-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 80 | 10 | 1.0 | 1.5 | 10 | 42 | -32 | 0 of 4 | 2 of 4 | -22 | -42 |
| Mine | Chaos Dwarfs | 4 | 278 | 325 | 1.2 | 1.2 | 260 | 0 | +260 | 2 of 5 | 5 of 5 | +296 | +251 |
| Mine | Dwarfen Mountain Holds | 3 | 626 | 0 | 0.7 | 1.5 | 0 | 30 | -30 | 0 of 2 | 1 of 2 | -60 | +0 |
| Mine | Empire of Man | 5 | 311 | 14 | 0.4 | 1.0 | 36 | 0 | +36 | 0 of 2 | 1 of 2 | - | +36 |
| Mine | Grand Cathay | 5 | 295 | 72 | 1.8 | 1.0 | 40 | 0 | +40 | 1 of 9 | 9 of 9 | - | +40 |
| Mine | High Elf Realms | 4 | 96 | 0 | 0.8 | 1.0 | 0 | 48 | -48 | 0 of 3 | 1 of 3 | - | -48 |
| Mine | Kingdom of Bretonnia | 1 | 123 | 208 | 1.0 | 1.0 | 208 | 0 | +208 | 0 of 1 | 1 of 1 | - | +208 |
| Mine | Lizardmen | 1 | 0 | 144 | 2.0 | 1.0 | 72 | 70 | +2 | 0 of 2 | 1 of 2 | - | +2 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 87 | -87 | 1 of 3 | 1 of 3 | -228 | -17 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 170 | 2.0 | 1.0 | 85 | 258 | -172 | 2 of 2 | 1 of 2 | - | -172 |
| Mine | Skaven | 1 | 104 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 132 | 99 | 3.5 | 1.0 | 28 | 28 | +0 | 2 of 7 | 4 of 7 | - | +0 |
| Mine | Vampire Counts | 2 | 0 | 354 | 2.5 | 1.4 | 141 | 139 | +2 | 1 of 5 | 3 of 5 | -58 | +42 |
| Mine | Warriors of Chaos | 2 | 0 | 72 | 1.0 | 1.0 | 72 | 201 | -129 | 1 of 2 | 1 of 2 | - | -129 |
| **Mine** | all armies | 36 | 201 | 93 | 1.3 | 1.1 | 71 | 55 | +16 | 10 of 47 | 31 of 47 | -22 | +23 |
| Opponent | Empire of Man | 1 | 189 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 344 | 215 | 2.7 | 1.0 | 81 | 20 | +60 | 3 of 8 | 5 of 8 | - | +60 |
| Opponent | High Elf Realms | 3 | 342 | 22 | 1.3 | 1.0 | 16 | 0 | +16 | 2 of 4 | 3 of 4 | - | +16 |
| Opponent | Kingdom of Bretonnia | 2 | 48 | 156 | 1.0 | 1.5 | 156 | 132 | +24 | 1 of 2 | 2 of 2 | -47 | +95 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 547 | 2.0 | 1.0 | 274 | 0 | +274 | 1 of 2 | 2 of 2 | - | +274 |
| Opponent | Skaven | 1 | 60 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 173 | 280 | 2.8 | 1.4 | 102 | 43 | +59 | 6 of 11 | 11 of 11 | +164 | +20 |
| Opponent | Vampire Counts | 6 | 9 | 516 | 3.3 | 1.3 | 155 | 12 | +143 | 6 of 20 | 13 of 20 | +176 | +132 |
| Opponent | Warriors of Chaos | 9 | 0 | 483 | 3.1 | 1.2 | 155 | 37 | +118 | 10 of 28 | 21 of 28 | +84 | +127 |
| Opponent | Wood Elf Realms | 6 | 152 | 323 | 3.0 | 1.1 | 108 | 31 | +77 | 6 of 18 | 13 of 18 | +210 | +69 |
| **Opponent** | all armies | 36 | 113 | 335 | 2.6 | 1.2 | 130 | 29 | +100 | 35 of 93 | 70 of 93 | +128 | +95 |

### Effective charges: fafix-mine-5e477c5-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 1 (net -85) | 1 (net +40) | 0 | 2 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 1 (net +230) | 3 (net +258) | 0 | 1 (net +296) | 0 | 20% (1 of 5) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 1 (net -60) | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Empire of Man | 2 | 1 (net +0) | 0 | 0 | 0 | 1 (net +72) | 0 | 0 | 0% (0 of 2) |
| Mine | Grand Cathay | 9 | 0 | 0 | 1 (net +0) | 4 (net +76) | 3 (net +18) | 1 (net +0) | 0 | 11% (1 of 9) |
| Mine | High Elf Realms | 3 | 0 | 0 | 1 (net -143) | 0 | 0 | 1 (net +0) | 1 | 50% (1 of 2) |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 1 (net +208) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net -228) | 1 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 1 (net -195) | 3 (net +0) | 0 | 2 (net +69) | 0 | 1 | 50% (3 of 6) |
| Mine | Vampire Counts | 5 | 1 (net -407) | 0 | 0 | 1 (net +464) | 1 (net +173) | 2 (net -110) | 0 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 2 | 1 (net -142) | 0 | 0 | 1 (net -116) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 8 | 2 (net -81) | 1 (net +317) | 0 | 2 (net +164) | 0 | 3 (net +0) | 0 | 0% (0 of 8) |
| Opponent | High Elf Realms | 4 | 2 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 3) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 1 (net -47) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 11 | 1 (net -195) | 0 | 2 (net -92) | 3 (net +194) | 2 (net +162) | 1 (net +0) | 2 | 22% (2 of 9) |
| Opponent | Vampire Counts | 20 | 6 (net +105) | 0 | 3 (net +28) | 7 (net +186) | 1 (net +162) | 3 (net +227) | 0 | 15% (3 of 20) |
| Opponent | Warriors of Chaos | 28 | 1 (net +0) | 1 (net +484) | 12 (net +143) | 3 (net +41) | 1 (net +0) | 8 (net +130) | 2 | 46% (12 of 26) |
| Opponent | Wood Elf Realms | 18 | 1 (net +0) | 0 | 3 (net -36) | 2 (net +164) | 0 | 0 | 12 | 50% (3 of 6) |

### Charged fights, damage counted: fafix-mine-5e477c5-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 284 | 297 | -183 | 180 | 294 | -115 | -40.4 |
| Mine | 50-54% | 2 | 152 | 332 | -128 | 3 | 140 | -137 | -90.0 |
| Mine | Effective (55-75%) | 6 | 279 | 232 | +14 | 53 | 48 | +5 | +2.0 |
| Mine | 76-89% | 12 | 266 | 193 | +129 | 156 | 26 | +130 | +48.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 198 | 154 | -22 | 106 | 96 | +10 | +5.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 343 | 77 | +60 | 60 | 0 | +59 | +17.3 |
| Mine | No odds | 9 | 311 | 156 | -45 | 61 | 89 | -28 | -9.0 |
| Mine | All fights | 47 | 276 | 178 | +16 | 96 | 69 | +27 | +9.8 |
| Opponent | Long shot (under 50%) | 13 | 227 | 220 | +21 | 122 | 73 | +49 | +21.7 |
| Opponent | 50-54% | 2 | 416 | 337 | +400 | 538 | 137 | +400 | +96.2 |
| Opponent | Effective (55-75%) | 21 | 238 | 201 | +70 | 149 | 61 | +87 | +36.8 |
| Opponent | 76-89% | 18 | 357 | 175 | +148 | 183 | 51 | +132 | +37.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 342 | 181 | +114 | 147 | 26 | +122 | +35.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 515 | 130 | +122 | 137 | 0 | +137 | +26.6 |
| Opponent | No odds | 20 | 166 | 177 | +97 | 137 | 39 | +98 | +59.3 |
| Opponent | All fights | 93 | 276 | 190 | +100 | 157 | 49 | +108 | +38.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fafix-mine-5e477c5-p3 | move | 400 | 74 (18%) | 48 (12%) | 36 (9%) | 290 (72%) |
| fafix-mine-5e477c5-p3 | objective | 263 | 42 (16%) | 27 (10%) | 27 (10%) | 194 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

import collections,statistics as st
from load import all_games
gs=all_games(); N=len(gs)
G=collections.Counter(); P=collections.defaultdict(lambda: collections.defaultdict(float))
for g in gs:
    for r in g['jr']:
        b='five' if r['side']==g['five'] else 'off'; G[b]+=r['gain']; G[b+'_risk']+=r['risk']; G[b+'_n']+=1
        if r['job'].startswith('charge'): G[b+'_ch']+=1
    for p in g['pr']:
        b='five' if p['side']==g['five'] else 'off'
        if p['kind']=='charge':
            s=P[b]; s['n']+=1; s['h']+=p['happened']; s['pl']+=p['planned']; s['won']+=p['won']
print('games',N)
for b in ('five','off'):
    print(b,'claimed gain/game',round(G[b]/N),'risk/game',round(G[b+'_risk']/N),'jobs/game',round(G[b+'_n']/N,1),'charge picks/game',round(G[b+'_ch']/N,2))
    s=P[b]; n=s['n'] or 1; print('   charge plans',round(s['n']/N,2),'/g happened',f"{s['h']/n:.0%}",'planned',round(s['pl']/n),'won',round(s['won']/n))

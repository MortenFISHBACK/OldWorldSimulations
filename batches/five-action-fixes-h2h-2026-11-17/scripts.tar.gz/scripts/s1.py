"""SPLIT questions for the fixed five-action batch.
Q1 which part of the risk figure is too low; Q2 the 3-round fight's split v what happened; Q3 flee-as-reaction cuts."""
import re, json, collections, statistics as st
from load import all_games
import job_claims as jc
gs = all_games(); N = len(gs)
def other(s): return 'Opponent' if s == 'Mine' else 'Mine'
F = r'(-?[\d.]+)'
DRE = re.compile(r'D ' + F + r': charges ' + F + r' \[(.*?)\] shots ' + F + r' \(shot ' + F + r', charged ' + F + r'\) lost-charge ' + F)
CRE = re.compile(r'#(\d+) (\w+) (\d+)%/(\d+)% -' + F)
CH = re.compile(r'charge #(\d+) reach (\d+)% win (\d+)% \| own figure ' + F + r' \(risk there ' + F + r'\) \| kills-count ' + F + ' wears-down ' + F +
                ' removed ' + F + r' \| one-round ' + F + r' \| 3 rounds kills ' + F + ' losses ' + F + ' net ' + F +
                r' \(flee-reaction ' + F + ' ' + F + ', stand-shoot ' + F + ', falls-back-away ' + F + ', blocker ' + F + r'\) \[(.*?)\] \| rounds added ' + F +
                r' \| after-it ' + F + r' \| worth ' + F)
RND = re.compile(r'r(\d) \+?' + F + '/' + F + r' \(out \+?' + F + '/' + F + r'\)')

def flee_reacted(g, f, i, tid):
    """Did the target flee as its charge reaction (a Movement-phase 'flees with/without Swiftstride' row of the target after the declaration)?"""
    return any(a > i and a < i + 400 for a in g['_flee'].get(tid, []))

R = collections.defaultdict(lambda: collections.defaultdict(float))   # Q1
OFF = collections.defaultdict(float)
C = collections.defaultdict(float); CL = []                            # Q2
FL = collections.Counter()                                              # Q3
for g in gs:
    five = g['five']
    g['_flee'] = collections.defaultdict(list)
    for line in open(g['file'], encoding='utf-8'):
        if '"type":"Chase' in line:
            x = json.loads(line)
            g['_flee'][x['target_id']].append(x['id'])
    for r in g['jr']:
        u = g['units'].get(r['a'])
        if not u: continue
        w = jc._window(g, r['i'], r['side'], 'enemy')
        if not w: continue
        chargers = [c[2] for c in g['charges'] if w[0] <= c[0] < w[1] and c[3] == r['a']]
        lost = jc._lost(g, u, w[0], w[1])
        if r['side'] != five:
            if r['job'].startswith('charge'): continue
            OFF['n'] += 1; OFF['risk'] += r['risk']; OFF['charged'] += bool(chargers); OFF['lost'] += lost
            continue
        sp = r.get('split') or ''
        if r['job'].startswith('charge'):
            m = CH.search(sp)
            if not m: continue
            v = [float(x) for x in m.groups()[1:20] if x is not None and re.match(r'^-?[\d.]+$', x)]
            (reach, win, own, riskthere, kc, wd, removed, one, k3, l3, n3, fp, fv, ss, fba, blk) = [float(m.group(k)) for k in range(2, 18)]
            rounds = {int(a): (abs(float(b)), abs(float(c)), abs(float(d)), abs(float(e))) for a, b, c, d, e in RND.findall(m.group(18))}
            added, after, worth = float(m.group(19)), float(m.group(20)), float(m.group(21))
            tid = int(m.group(1)); tg = g['units'].get(tid)
            this = jc._window(g, r['i'], r['side'], 'this'); w1 = jc._window(g, r['i'], r['side'], 'own'); w2 = jc._window(g, w1[0], r['side'], 'own') if w1 else None
            e2 = w2[0] if w2 else g['n']
            decl = [c for c in g['charges'] if this[0] <= c[0] < this[1] and c[2] == r['a'] and c[3] == tid]
            got2 = jc._lost(g, tg, this[0], e2) if tg else 0; lost2 = jc._lost(g, u, this[0], e2)
            r1 = rounds.get(1, (0, 0, 0, 0)); r23 = [rounds.get(k, (0, 0, 0, 0)) for k in (2, 3)]
            row = dict(gain=r['gain'], own=own, kc=kc, wd=wd, removed=removed, one=one, k3=k3, l3=l3, n3=n3, fp=fp, fv=fv, ss=ss, fba=fba, added=added,
                       r1=r1[0] - r1[1], r1out=r1[2] - r1[3], r23=sum(x[0] - x[1] + x[2] - x[3] for x in r23), win=win, decl=bool(decl),
                       net=got2 - lost2, got=got2, lost=lost2, fled=bool(decl) and flee_reacted(g, g['file'], decl[0][0], tid))
            w0 = this
            wE = jc._window(g, r['i'], r['side'], 'enemy')
            wins = [w0, wE, w1]
            real = []
            for k, wk in enumerate(wins):
                if not wk or not tg: real.append((0, 0, False)); continue
                alive = not jc._gone(g, tg['id'], wk[0]) and not jc._gone(g, u['id'], wk[0])
                real.append((jc._lost(g, tg, wk[0], wk[1]), jc._lost(g, u, wk[0], wk[1]), alive))
            row['rounds'] = rounds; row['real'] = real
            CL.append(row)
            continue
        m = DRE.search(sp)
        if not m: continue
        D, chv, lst, shv, shp, chp, lc = m.groups()
        D, chv, shv, shp, chp, lc = map(float, (D, chv, shv, shp, chp, lc))
        listed = {int(a): (arc, int(p) / 100, int(q) / 100, float(pts)) for a, arc, p, q, pts in CRE.findall(lst)}
        s = R['all']
        s['n'] += 1; s['D'] += D; s['chv'] += chv; s['shv'] += shv; s['lc'] += lc
        s['exp'] += sum(x[1] for x in listed.values()); s['expfull'] += sum(x[2] for x in listed.values())
        s['chp'] += chp; s['charged'] += bool(chargers); s['nch'] += len(chargers)
        s['listed_hit'] += sum(1 for c in chargers if c in listed); s['unlisted'] += sum(1 for c in chargers if c not in listed)
        s['lost'] += lost
        if chargers:
            s['n_ch'] += 1; s['lost_ch'] += lost; s['claimed_ch'] += chv
            s['pts_of_actual'] += max([listed[c][3] for c in chargers if c in listed] or [0])
        else:
            s['n_noch'] += 1; s['lost_noch'] += lost; s['shv_noch'] += shv
        if listed and not chargers: s['listed_none'] += 1
        b = '0' if D < 0.5 else '<10' if D < 10 else '10-50' if D < 50 else '50+'
        t = R['risk ' + b]; t['n'] += 1; t['D'] += D; t['charged'] += bool(chargers); t['lost'] += lost

def p(x): return f"{x:.0%}"
s = R['all']; n = s['n']
print(f'Q1 risk, five-action non-charge picks with SPLIT: {n} ({n/N:.1f} a game)')
print(f"  claimed D {s['D']/n:.1f} = charges {s['chv']/n:.1f} + shots {s['shv']/n:.1f} + lost-charge {s['lc']/n:.1f}")
print(f"  expected charges a pick (counted) {s['exp']/n:.3f}, full {s['expfull']/n:.3f}, 'charged' p {s['chp']/n:.3f}; actual charges {s['nch']/n:.3f}, charged {p(s['charged']/n)}")
print(f"  of the real chargers: listed {s['listed_hit']}, NOT listed {s['unlisted']}")
print(f"  lost in the enemy turn {s['lost']/n:.1f}; when charged ({s['n_ch']}): lost {s['lost_ch']/max(1,s['n_ch']):.1f}, charges claimed there {s['claimed_ch']/max(1,s['n_ch']):.1f}, listed points of the real charger {s['pts_of_actual']/max(1,s['n_ch']):.1f}")
print(f"  when not charged ({s['n_noch']}): lost {s['lost_noch']/max(1,s['n_noch']):.1f} v shots claimed {s['shv_noch']/max(1,s['n_noch']):.1f}")
for k in ('risk 0', 'risk <10', 'risk 10-50', 'risk 50+'):
    t = R[k]
    if t['n']: print(f"  {k:10s} {t['n']/N:5.1f}/g claimed {t['D']/t['n']:5.1f} lost {t['lost']/t['n']:5.1f} charged {p(t['charged']/t['n'])}")
if OFF['n']: print(f"  other side: {OFF['n']/N:.1f}/g risk {OFF['risk']/OFF['n']:.1f} lost {OFF['lost']/OFF['n']:.1f} charged {p(OFF['charged']/OFF['n'])}")

print(f'\nQ2 charge picks with SPLIT: {len(CL)} ({len(CL)/N:.2f} a game), declared {sum(c["decl"] for c in CL)}')
for lab, rows in (('all picks', CL), ('declared', [c for c in CL if c['decl']])):
    if not rows: continue
    m = lambda k: st.mean(c[k] for c in rows)
    print(f"  {lab}: gain {m('gain'):.1f}; own figure {m('own'):.1f} (kills-count {m('kc'):.1f}, wears-down {m('wd'):.1f}, removed {m('removed'):.1f}); one-round {m('one'):.1f};"
          f" 3 rounds net {m('n3'):.1f} (kills {m('k3'):.1f} losses {m('l3'):.1f}; r1 {m('r1'):.1f} + r1 out {m('r1out'):.1f}, r2+r3 {m('r23'):.1f}); stand-shoot {m('ss'):.1f};"
          f" rounds added {m('added'):.1f}; real net 4 rounds {m('net'):.1f} (kills {m('got'):.1f} losses {m('lost'):.1f})")
print('\nQ3 flee as reaction')
for lab, rows in (('all picks', CL), ('declared', [c for c in CL if c['decl']])):
    if not rows: continue
    f = [c for c in rows if c['fp'] > 0]; f50 = [c for c in rows if c['fp'] >= 0.5]
    cut = [c for c in f if c['fv'] < c['one']]
    print(f"  {lab}: {len(rows)}; flee p>0 {len(f)}, p>=50% {len(f50)}; flee figure below the one-round figure {len(cut)} (by {st.mean(c['one']-c['fv'] for c in cut) if cut else 0:.1f} VP a time)")
    if lab == 'declared':
        print(f"    really fled as reaction: {sum(c['fled'] for c in rows)}; of those said p>=50%: {sum(c['fled'] for c in f50)} / {len(f50)}; said p=0 but fled {sum(c['fled'] for c in rows if c['fp']==0)}")

if __name__ == '__main__' and 'show' in __import__('sys').argv:
    import itertools
    k = 0
    for g in gs:
        for r in g['jr']:
            if r['side'] == g['five'] and r['job'].startswith('charge') and 'flee-reaction 1.00' in (r.get('split') or ''):
                tid = int(re.search(r'charge #(\d+)', r['split']).group(1))
                this = jc._window(g, r['i'], r['side'], 'this')
                for line in open(g['file']):
                    if '"kind":"action"' not in line: continue
                    x = json.loads(line)
                    if this[0] <= x['id'] < this[1] and x['phase'] in ('Movement', 'Strategy') and (x.get('target_id') == tid or x.get('actor_id') == tid) and x['type'] not in ('Candidates', 'OpponentRule', 'JobRisk'):
                        print(x['type'], x['phase'], x['summary'][:220])
                print('----'); k += 1
                break
        if k >= 3: break

for lab, rows in (('all picks', CL), ('declared', [c for c in CL if c['decl']])):
    f50 = [c for c in rows if c['fp'] >= 0.5]
    if not f50: continue
    d = [c['k3'] - c['l3'] - c['fv'] for c in f50]
    print(f"  {lab}: flee assumed {len(f50)}: fight net {st.mean(c['k3']-c['l3'] for c in f50):.1f} v flee figure {st.mean(c['fv'] for c in f50):.1f}; cut in {sum(x>0 for x in d)} (by {st.mean([x for x in d if x>0] or [0]):.1f}), raised in {sum(x<0 for x in d)}")

print('\nQ2b per round, declared charges where it did not assume a flee reaction')
rows=[c for c in CL if c['decl'] and c['fp']<0.5]
print('  n',len(rows))
for k in (1,2,3):
    ck=st.mean(c['rounds'].get(k,(0,0,0,0))[0]+c['rounds'].get(k,(0,0,0,0))[2] for c in rows)
    cl=st.mean(c['rounds'].get(k,(0,0,0,0))[1]+c['rounds'].get(k,(0,0,0,0))[3] for c in rows)
    rk=st.mean(c['real'][k-1][0] for c in rows); rl=st.mean(c['real'][k-1][1] for c in rows)
    al=st.mean(c['real'][k-1][2] for c in rows)
    print(f"  round {k}: claimed kills {ck:6.1f} losses {cl:5.1f} net {ck-cl:6.1f} | real kills {rk:6.1f} losses {rl:5.1f} net {rk-rl:6.1f} | both still on the table at its start {al:.0%}")

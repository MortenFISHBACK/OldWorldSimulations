import json,glob,os,re,collections
D='/mnt/project-files/five-action-fixes-h2h-2026-11-17'
FIVE=['FIVE ACTION','LIKELY CHARGE','FALLS SHORT','TIME ON OUR SIDE','FEATURE BUFFS','GETS AWAY CHANCE','GUN MASK','RUN DOWN','FOUR ROUNDS',
 'CHARGE LOSSES','CHARACTER GUNS','STAND AND SHOOT','FALL BACK GOOD ORDER','AFTERMATH IN POINTS']
SIMPLE=['ADVANCE WORTH','IDLE COST','RISK ONCE','ONE FIGHT FORMULA','COVER ONCE','CHAFF IN THE MOVE','ONE OBJECTIVE FORMULA']
TAGS=FIVE+SIMPLE
R=re.compile(r"^([A-Z ]+): ([+-]?[\d.]+) VP: .*?\| (SAME|CHANGED)")
JR=re.compile(r"^JOB RISK: (.+?): gain ([+-]?[\d.]+) VP, risk ([+-]?[\d.]+) VP.*?(?:; FIVE: (\w+), next turn ([+-]?[\d.]+) VP(?: on #\d+)? at (\d+)%)?$")
C=collections.Counter(); games=collections.Counter(); seen=set(); act=collections.Counter()
risk=collections.defaultdict(float); gain=collections.defaultdict(float); bsum=collections.defaultdict(float); jobs=collections.Counter()
for f in sorted(glob.glob(D+'/*/game-*.log.jsonl')+glob.glob(D+'/*/*/game-*.log.jsonl')):
  arm=os.path.relpath(f,D).split('/')[0].split('-')[0]; key=(arm,os.path.basename(f))
  if key in seen: continue
  seen.add(key); fx='Mine' if arm=='mine' else 'Opponent'; games[arm]+=1
  for l in open(f):
    if '"summary"' not in l: continue
    try: d=json.loads(l)
    except ValueError: continue
    s=d.get('summary') or ''; side=d.get('side'); b='on' if side==fx else 'off'
    m=JR.match(s)
    if m:
      jobs[b]+=1; gain[b]+=float(m.group(2)); risk[b]+=float(m.group(3))
      if m.group(4): act[(b,m.group(4))]+=1; bsum[b]+=float(m.group(5))*int(m.group(6))/100
      continue
    t=next((t for t in TAGS if s.startswith(t+':')),None)
    if not t: continue
    m=R.match(s); C[(b,t,m.group(3) if m else 'other')]+=1
n=sum(games.values())
print('games',dict(games),'total',n)
print('| Rule | on: rows a game | on: changed the pick a game | off side rows (leak if five) |\n| --- | --- | --- | --- |')
for t in TAGS:
  tot=sum(v for (b,k,_),v in C.items() if k==t and b=='on'); ch=C[('on',t,'CHANGED')]
  off=sum(v for (b,k,_),v in C.items() if k==t and b=='off')
  print(f"| {t} | {tot/n:.1f} | {ch/n:.2f} | {off} |")
print('\nJOB RISK a game: side, jobs, gain claimed, risk claimed, next-turn B claimed (x chance)')
for b in ('on','off'): print(b, f"{jobs[b]/n:.1f}", f"{gain[b]/n:.0f}", f"{risk[b]/n:.0f}", f"{bsum[b]/n:.0f}")
print('five actions picked a game:', {k[1]:round(v/n,1) for k,v in sorted(act.items()) if k[0]=='on'}, 'off-side FIVE rows:', sum(v for k,v in act.items() if k[0]=='off'))

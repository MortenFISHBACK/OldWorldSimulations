import sys,os,glob,json,re,pickle,collections
sys.path.insert(0,'/home/user/WarhammerOldWorldSimulator/scripts')
import job_claims as jc
ROOT='/home/user/fa2'
JR=re.compile(r"^JOB RISK: (.+?): gain ([+-][\d.]+) VP, risk (-?[\d.]+) VP, worth ([+-][\d.]+) VP(?:; FIVE: (\w+), next turn ([+-][\d.]+) VP(?: on #(\d+))? at (\d+)%)?(?:; SPLIT: (.*))?$",re.S)
RULE=re.compile(r"^([A-Z][A-Z0-9' \-]+): ([+-][\d.]+) VP: (.*?)(?: \| (SAME|CHANGED): ([+-][\d.]+) VP v ([+-][\d.]+) VP(?: instead of (.*))?)?$",re.S)
PR=re.compile(r"^PLAN RESULT: [+-][\d.]+ VP: happened=(yes|no) won=([\d.]+) planned=(-?[\d.]+) kind=([a-z ]+?): (.*) \(([^()]*(?:\([^()]*\)[^()]*)*)\)$")
def games():
    out=[]
    for f in sorted(glob.glob(ROOT+'/*/game-*.log.jsonl')+glob.glob(ROOT+'/*/*/game-*.log.jsonl')):
        arm=os.path.relpath(f,ROOT).split('/')[0].split('-')[0]
        out.append((arm,f))
    return out
def parse(arm,f):
    g=jc.read_game(f)
    five='Mine' if arm=='mine' else 'Opponent'
    g['five']=five; g['arm']=arm; g['file']=f
    g['jr']=[];g['rules']=[];g['pr']=[];g['cj']=[];g['cm']=[];g['acts']=[]
    for line in open(f,encoding='utf-8'):
        try:x=json.loads(line)
        except ValueError: continue
        if x.get('kind')=='board': g['board']={k:x.get(k) for k in ('mine','opponent','sc')}
        if x.get('kind')!='action': continue
        t=x.get('type'); s=x.get('summary') or ''
        base=dict(i=x.get('id'),turn=x.get('turn'),side=x.get('side'),phase=x.get('phase'),a=x.get('actor_id'),t=x.get('target_id'),actor=x.get('actor'),target=x.get('target'))
        if t=='JobRisk':
            m=JR.match(s)
            if m: g['jr'].append(dict(base,job=m.group(1),gain=float(m.group(2)),risk=float(m.group(3)),worth=float(m.group(4)),act=m.group(5),B=float(m.group(6)) if m.group(6) else None,Bt=int(m.group(7)) if m.group(7) else None,Bp=int(m.group(8))/100 if m.group(8) else None,split=m.group(9)))
            else: g.setdefault('bad',[]).append(s[:200])
        elif t=='OpponentRule':
            if s.startswith('PLAN RESULT'):
                m=PR.match(s)
                if m: g['pr'].append(dict(base,happened=m.group(1)=='yes',won=float(m.group(2)),planned=float(m.group(3)),kind=m.group(4),job=m.group(5),why=m.group(6)))
                else: g.setdefault('bad',[]).append(s[:200])
            else:
                m=RULE.match(s)
                if m: g['rules'].append(dict(base,tag=m.group(1),d=float(m.group(2)),text=m.group(3),chg=m.group(4),wa=float(m.group(5)) if m.group(5) else None,wb=float(m.group(6)) if m.group(6) else None,alt=m.group(7)))
        elif t=='Candidates':
            if s.startswith('CANDIDATES JOB') or s.startswith('CANDIDATES MOVE'):
                parts=s.split(' | ')
                opts=[]
                for p in parts[1:]:
                    m=re.match(r"^(\d+)\. ([+-][\d.]+) VP: (.*)$",p,re.S)
                    if m: opts.append((int(m.group(1)),float(m.group(2)),m.group(3)))
                n=int(re.search(r": (\d+) weighed",parts[0]).group(1))
                g['cj' if 'JOB' in parts[0] else 'cm'].append(dict(base,n=n,opts=opts,raw=s if 'JOB' in parts[0] else None))
        else:
            if t not in ('Computer','SpellNotCast','MissileNotTried','ShotNotTaken','SpellHeldBack','ArmyStance'):
                g['acts'].append(dict(base,type=t,s=s[:400]))
    return g
def all_games():
    c='/home/user/an2/games.pkl'
    if os.path.exists(c): return pickle.load(open(c,'rb'))
    gs=[parse(a,f) for a,f in games()]
    for g in gs: g['hist']=dict(g['hist'])
    pickle.dump(gs,open(c,'wb'))
    return gs
if __name__=='__main__':
    gs=all_games()
    print(len(gs),'games'); 
    print('bad',sum(len(g.get('bad',[])) for g in gs)); 
    for g in gs[:1]:
        print(g.get('bad',[])[:5]); print(len(g['jr']),len(g['rules']),len(g['pr']),len(g['cj']),len(g['cm']),len(g['units']))
        print([ (u['name'],u['points'],u['vp'],u['tt']) for u in g['units'].values()][:8])
    nopts=sum(1 for g in gs for u in g['units'].values() if not u['points'] and u['tt']!='Character')
    print('units without points',nopts, 'of', sum(len(g['units']) for g in gs))

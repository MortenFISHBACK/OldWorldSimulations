# Doctrine scorecard: fafix-opp-5e477c5-p1

### Scorecard: fafix-opp-5e477c5-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 8 | 2 | 0 | 1 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 7 | 1 | 1 | 6 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0118 | 4 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 331 |
| L0135 | 3 | 1 | Mine | yes | 6 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 1 | 1 | 1 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 4 | 0 | 2 | 0 | 0 | 0 | 110 |
| L0319 | 1 | 1 | Mine | no | 10 | 3 | 2 | 1 | 0 | 0 | 0 | 760 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 124 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 829 |
| L0421 | 1 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | - | 0 | 4 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 1075 |
| L0508 | 4 | 1 | Opponent | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 882 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 771 |
| L0524 | 2 | 1 | Opponent | - | - | 5 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | 4 | 1 | 3 | 1 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 615 |
| L0628 | 4 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 8 | 3 | 3 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 5 | 1 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0733 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 144 |
| L0823 | 1 | 1 | Mine | no | 5 | 6 | 1 | 1 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 934 |
| L0913 | 1 | 1 | Opponent | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 2 | 5 | 3 | 0 | 0 | 0 | 0 | 789 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 4 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 9 | 5 | 0 | 0 | 1 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 2 | 6 | 0 | 3 | 2 | 0 | 0 | 205 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 709 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 302 |
| L1335 | 3 | 1 | Opponent | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | no | 4 | 5 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 2 | 1 | 1 | 0 | 0 | 460 |
| L1527 | 3 | 1 | Mine | yes | 13 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 75 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 5 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 135 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 6 | 3 | 1 | 0 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 7 | 2 | 2 | 0 | 0 | 60 |
| L1923 | 3 | 1 | Mine | no | 3 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 2 | - | 2 | 0 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 3 | - | 2 | 3 | 0 | 0 | 0 | 290 |
| L2127 | 3 | 1 | Opponent | no | 2 | 3 | 2 | 3 | 1 | 0 | 0 | 133 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 657 |
| L2335 | 1 | 1 | Mine | no | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 2 | 1 | 5 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 1 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 24% | 2.9 | 2.7 | 2.6 | 1.3 | 0.2 | 0.0 | 0.0 | 316.0 |
| **Average** | | | Opponent | 9% | 1.4 | 2.9 | 1.9 | 2.0 | 0.4 | 0.0 | 0.0 | 172.3 |

### KPIs: fafix-opp-5e477c5-p1

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE; both sides: LIKELY CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (41 of 160) | 3% (5 of 163) | 14% (46 of 323) |
| Winner chose to follow up after the loser gave ground |  | 97% (61 of 63); on the table 97% | 83% (30 of 36); on the table 89% | 92% (91 of 99); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (5 of 6); on the table 83% | 57% (4 of 7); on the table 57% | 69% (9 of 13); on the table 69% |
| Winner chose to pursue after the loser fled |  | 71% (27 of 38); on the table 79% | 100% (18 of 18); on the table 100% | 80% (45 of 56); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 87% (93 of 107); on the table 90% | 85% (52 of 61); on the table 89% | 86% (145 of 168); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 35% (115 of 330) | 30% (64 of 210) | 33% (179 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (115 of 265) | 39% (64 of 164) | 42% (179 of 429) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (23 of 37) | 53% (28 of 53) | 57% (51 of 90) |
| Points that never fought | lower | 45% (31999 of 71484) | 43% (31128 of 71889) | 44% (63127 of 143373) |
|   infantry points that never fought | lower | 58% (9782 of 16863) | 67% (8931 of 13348) | 62% (18713 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (149 of 279) | 68% (200 of 295) | 61% (349 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.7 uses a game | 75% (15 of 20); 1.3 uses a game | 83% (35 of 42); 1.5 uses a game |
| Bound items with another spell used |  | 44% (7 of 16); 0.5 uses a game | 38% (3 of 8); 0.1 uses a game | 42% (10 of 24); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 67% (8 of 12); 0.2 uses a game | 55% (17 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (28678 of 59666) | 63% (39259 of 62699) | 56% (67937 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.6 (43%) | 1.4 (34%) | 3.9 (39%) |
| MARCHED: its unit marched | 1.1 (19%) | 0.8 (21%) | 1.9 (19%) |
| CHARGED: its unit charged | 0.4 (7%) | 0.0 (0%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.1 (19%) | 0.2 (5%) | 1.4 (14%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.5 (12%) | 0.5 (5%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| GONE: slain | 0.5 (9%) | 0.9 (22%) | 1.4 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.4 | 1.5 | 5.0 | 0.8 | 1.5 |
| not cast | 3.5 | 3.0 | 3.2 | 10.0 | 1.5 | 22.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (44%) | 0.4 (11%) | 3.9 (39%) | 0.4 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (19%) | 0.3 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (8%) | 0.2 (6%) | 1.4 (14%) | 0.4 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.3 (10%) | 0.5 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (2%) | 0.2 (1%) |
| GONE: slain | 0.7 (19%) | 0.4 (13%) | 0.6 (19%) | 1.4 (14%) | 0.1 (9%) | 3.0 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.3 (10%) | 0.2 (5%) | 0.2 (2%) | 0.1 (4%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.2 (5%) | 0.1 (3%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (67%) | 0.3 (10%) | 1.4 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.0 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.4 a game | 0.9 a game |
| stood (cast and not dispelled) | 69% (29 of 42) | 53% (8 of 15) | 65% (37 of 57) |
| the unit moved after it | 66% (19 of 29) | 50% (4 of 8) | 62% (23 of 37) |
| it charged on its next turn | 0% (0 of 29) | 0% (0 of 8) | 0% (0 of 37) |
| the enemy charged it first | 3% (1 of 29) | 25% (2 of 8) | 8% (3 of 37) |
| it fought by the end of its next turn | 3% (1 of 29) | 12% (1 of 8) | 5% (2 of 37) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 29) | 12% (1 of 8) | 3% (1 of 37) |
| none of these (no charge, no fight, no charge escaped) | 97% (28 of 29) | 62% (5 of 8) | 89% (33 of 37) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (545 of 940) | 64% (386 of 600) | 60% (931 of 1540) |
|   cavalry | 43% (45 of 104) | 73% (91 of 124) | 60% (136 of 228) |
|   character | 47% (52 of 111) | 30% (34 of 112) | 39% (86 of 223) |
|   chariot | 48% (45 of 93) | 82% (36 of 44) | 59% (81 of 137) |
|   infantry | 52% (164 of 314) | 68% (160 of 235) | 59% (324 of 549) |
|   monster | 45% (20 of 44) | 64% (16 of 25) | 52% (36 of 69) |
|   war machine | 80% (219 of 274) | 82% (49 of 60) | 80% (268 of 334) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.9 (26%) | 1.4 (23%) | 4.2 (25%) |
| CHARGED: it charged | 1.2 (11%) | 0.9 (15%) | 2.1 (12%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.4 (4%) | 0.4 (7%) | 0.9 (5%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.2 (3%) | 0.3 (2%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.4 (3%) | 0.0 (0%) | 0.4 (2%) |
| NO TARGET IN RANGE | 3.1 (29%) | 1.4 (23%) | 4.5 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.3 (5%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (16%) | 1.0 (17%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.2 | 82% | 3.7 pts | 20 pts |
| character | 2.7 | 0.8 | 83% | 6.9 pts | 19 pts |
| chariot | 2.3 | 1.2 | 70% | 12.6 pts | 29 pts |
| infantry | 12.8 | 5.0 | 75% | 8.1 pts | 104 pts |
| monster | 1.1 | 0.3 | 80% | 8.9 pts | 10 pts |
| war machine | 7.4 | 5.2 | 65% | 25.7 pts | 191 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 3.4 | 4.1 |
| Charges that made contact a game | 3.4 | 2.6 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.95 declared, 0.71 contact (21 units) | 0.07 declared, 0.07 contact (15 units) | 0.58 declared, 0.44 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.75 contact (4 units) | 1.20 declared, 0.90 contact (10 units) | 1.14 declared, 0.86 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.42 contact (248 units) | 0.38 declared, 0.29 contact (291 units) | 0.48 declared, 0.35 contact (539 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (40 of 70) | 57% (12 of 21) | 50% (4 of 8) | 57% (56 of 99) |
| Character in a unit | 86% (32 of 37) | 84% (21 of 25) | 100% (4 of 4) | 86% (57 of 66) |
| Character on its own | 88% (44 of 50) | 54% (19 of 35) | 31% (19 of 62) | 56% (82 of 147) |
| Chariot | 75% (12 of 16) | 50% (5 of 10) | - | 65% (17 of 26) |
| Infantry | 52% (46 of 89) | 50% (18 of 36) | 50% (1 of 2) | 51% (65 of 127) |
| Monster | 72% (23 of 32) | 70% (7 of 10) | - | 71% (30 of 42) |
| Monstrous | 91% (10 of 11) | 57% (8 of 14) | - | 72% (18 of 25) |
| War Machines | 56% (23 of 41) | 100% (1 of 1) | - | 57% (24 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 92% (11 of 12); on the table 100% | 38% (53 of 138) | 57% | 61% (20 of 33) | 100% (9 of 9); 5.8 uses a game | 100% (3 of 3); 1.5 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 90% (9 of 10); on the table 90% | 33% (8 of 24) | 55% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 73% (8 of 11); on the table 73% | - | 67% | 85% (35 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 79% (11 of 14); on the table 93% | 44% (16 of 36) | 52% | 52% (33 of 64) | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (12 of 12); on the table 100% | 38% (41 of 108) | 42% | 45% (20 of 44) | 92% (11 of 12); 7.2 uses a game | 100% (1 of 1); 0.2 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 62% (10 of 16); on the table 62% | 27% (8 of 30) | 39% | 43% (21 of 49) | 100% (5 of 5); 1.8 uses a game | 22% (4 of 18); 1.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (5 of 5); on the table 100% | - | 54% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (7 of 7); on the table 100% | - | 26% | 43% (6 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (3 of 3); on the table 100% | 17% (2 of 12) | 76% | 76% (16 of 21) | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (5 of 5); on the table 100% | 6% (2 of 36) | 7% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (15 of 15); on the table 100% | 30% (9 of 30) | 49% | 62% (21 of 34) | 100% (3 of 3); 1.5 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 82% (9 of 11); on the table 82% | 17% (2 of 12) | 35% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 72% (18 of 25); on the table 80% | 39% (21 of 54) | 32% | 60% (30 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 100% (11 of 11); on the table 100% | 30% (9 of 30) | 42% | 85% (63 of 74) | 100% (4 of 4); 1.4 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (11 of 11); on the table 100% | 27% (8 of 30) | 38% | 68% (45 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fafix-opp-5e477c5-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (24) | 52% (33) | 49% (57) |
| ...free all their last turn and able to turn (per game) | 0.42 | 0.72 | 1.14 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.08 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.44 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.06 | 0.17 | 2.22 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.78 | 0.03 | 0.81 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.86 | 0.44 | 5.31 |

### Quality by phase: fafix-opp-5e477c5-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 54% (72 of 134) | 51% (55 of 108) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (192 of 397) | 56% (75 of 134) |
| Strategy | Close-in objectives charged next turn | 16% (30 of 182) | - |
| Strategy | Support requests answered (helper made contact too) | 38% (6 of 16) | 45% (5 of 11) |
| Strategy | Hexes on a unit its side charged or shot that turn | 27% (3 of 11) | 25% (2 of 8) |
| Strategy | Joined characters whose unit fought | 30% (18 of 60) | 31% (13 of 42) |
| Strategy | Lone characters that fought | 80% (69 of 86) | 72% (68 of 94) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.3 | 2.0 |
| Movement | Points that never moved of their own | 316.0 | 172.3 |
| Movement | Fights charged into per game | 2.9 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 89, net +111 | 12 of 68, net +60 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 89, net +89 | 16 of 68, net +125 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 89, net +150 | 2 of 68, net +230 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 89, net +56 | 17 of 68, net +113 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.5 | 10.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (140 of 343) | 40% (145 of 366) |
| Shooting | Points destroyed by shooting units | 76.9 | 51.2 |
| Shooting | War machine shots | 6.1 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (97 of 219) | 35% (17 of 49) |
| Shooting | Points destroyed by war machines | 82.8 | 25.2 |
| Magic | Magic missiles cast | 2.1 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (28 of 76) | 39% (16 of 41) |
| Magic | Wounds caused by magic missiles | 5.3 | 1.2 |
| Magic | Wounds caused by other spells | 1.1 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 82.1 | 16.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.4 / 0.9 / 0.2 | 1.5 / 0.4 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 367.5 | 242.0 |
| Combat | Points run down | 46.7 | 133.9 |
| Combat | Net points per charged fight, damage counted | +90 | +98 |
| Combat | Net per 100 charger points, damage counted | +32.2 | +35.3 |
| Combat | First round won (charged fights) | 76% | 69% |
| Combat | Net points per charged fight | +96 | +98 |
| Combat | Net points per supported fight / lone fight | +160 / +85 | +295 / +78 |
| Combat | Charged fights on a top-3 enemy unit | 34 of 103 | 35 of 84 |
| Game | Points lost | 587.3 | 837.5 |
| Game | VP from objectives | 732.2 | 480.0 |
| Game | Lone holders (player turns) | 2.9 | 1.4 |

- Mine won / drew / lost: 20 / 5 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +484 VP
- The side that went first won 12 of 31 games with a winner
- Points traded per game (both sides' losses): 1425
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fafix-opp-5e477c5-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 6.5 | -154.4 | 300.0 | 111.8 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.1 | +4.7 | 0.0 | 24.5 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.9 | +0.0 | 0.0 | 7.4 | 0.3 | +0.0 | 0.0 | 2.6 |
| BACKUP TARGETS | 0.4 | +2.3 | 0.0 | 30.5 | 0.3 | +2.0 | 0.0 | 17.8 |
| BEST FACING | 0.5 | +23.4 | 0.0 | 22.4 | 0.1 | +2.4 | 0.0 | 0.0 |
| BEST FIRST | 1.2 | +48.1 | 18.0 | 58.6 | - | - | - | - |
| BEST OVERALL | 0.4 | +11.7 | 0.0 | 13.1 | - | - | - | - |
| BEST PREY | 0.6 | +37.4 | 18.4 | 28.1 | - | - | - | - |
| BEST PRIZE | 0.1 | -0.5 | 9.3 | 0.0 | 0.1 | -0.2 | 2.4 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.5 | 0.0 | 16.6 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 7.4 | 7.4 | - | - | - | - |
| BLOCKED WHEEL | 0.5 | +13.1 | 0.0 | 8.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | -32.8 | 27.3 | 0.0 | 0.2 | -22.4 | 37.6 | 0.0 |
| BOMBING RUN | 0.1 | +1.1 | 3.2 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 55.0 | 16.2 | 0.1 | +0.0 | 6.9 | 1.9 |
| CANNON PLANNED TARGET | 4.6 | +153.6 | 336.0 | 98.5 | 1.1 | +48.8 | 74.4 | 22.1 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 14.2 | 20.1 | - | - | - | - |
| CAST JOB | 0.5 | +16.5 | 36.6 | 2.4 | 0.3 | +2.7 | 3.8 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +54.4 | 20.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 11.1 | 0.2 | +0.0 | 0.0 | 28.3 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.1 | +2.7 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 3.2 |
| CHAFF IN THE MOVE | 0.8 | +38.2 | 0.0 | 5.8 | 0.7 | +38.6 | 0.0 | 13.3 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 4.0 | 0.3 | -0.4 | 9.4 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.3 | +0.0 | 0.0 | 12.3 |
| CHARGE LOSSES | - | - | - | - | 10.2 | -526.6 | 0.0 | 379.3 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 228.3 | 59.1 | 1.5 | +0.0 | 207.1 | 30.1 |
| CHARGE NOW WEIGHED | 0.4 | -15.1 | 3.7 | 36.7 | - | - | - | - |
| CHARGER SLAIN LOST | 0.4 | -11.9 | 43.6 | 6.8 | 0.3 | -13.2 | 24.6 | 11.9 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.0 | +0.0 | 4.9 | 0.0 | 0.1 | +0.0 | 20.6 | 1.9 |
| COMBAT PIVOT | 0.4 | +0.0 | 37.7 | 4.7 | 0.3 | +0.0 | 21.5 | 5.4 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.6 | +135.2 | 16.2 | 11.1 | 0.3 | +57.5 | 20.9 | 35.9 |
| COVER ONCE | 7.1 | -508.3 | 0.0 | 179.8 | 4.7 | -347.8 | 0.0 | 175.8 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 3.4 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | -0.7 | 11.9 | 7.1 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +22.6 | 71.2 | 23.2 | 0.1 | +2.5 | 12.4 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +137.8 | 0.0 | 77.5 | 0.2 | +5.9 | 0.0 | 5.4 |
| FALL BACK GOOD ORDER | - | - | - | - | 2.1 | +4.9 | 232.5 | 41.7 |
| FALLBACK BY WORTH | 4.6 | +53.4 | 0.0 | 66.4 | 0.4 | +3.7 | 0.0 | 4.2 |
| FALLS SHORT | - | - | - | - | 0.5 | -3.5 | 0.0 | 9.3 |
| FEATURE BUFFS | - | - | - | - | 0.4 | +5.7 | 0.0 | 4.2 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.6 | 0.0 | 6.1 |
| FIVE ACTION | - | - | - | - | 41.4 | +1439.6 | 568.6 | 796.5 |
| FLANK NOT WEIGHED | 4.9 | +0.0 | 0.0 | 119.6 | 5.1 | +0.0 | 0.0 | 194.8 |
| FOCUS FIRE | 0.0 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +120.3 | 0.0 | 38.6 | 0.5 | +74.5 | 0.0 | 41.7 |
| FOUR ROUNDS | - | - | - | - | 2.9 | +227.3 | 334.9 | 49.8 |
| FRIENDS SHOTS CHECKED | 0.2 | +15.3 | 0.0 | 0.0 | 0.1 | +12.7 | 0.0 | 1.8 |
| GIVES UP | 0.1 | -0.8 | 13.1 | 0.0 | 0.2 | -1.7 | 7.8 | 7.9 |
| GROUND FLIERS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 0.2 | +6.1 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 4.4 | 1.2 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 30.6 | 0.0 | 0.3 | +0.0 | 35.5 | 2.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.7 | -134.7 | 569.4 | 146.3 | 2.3 | -115.4 | 250.7 | 31.0 |
| HUNT IN PAIRS | 0.5 | +21.7 | 0.0 | 0.0 | 0.5 | +6.4 | 0.0 | 12.8 |
| HUNT RESULT | 0.0 | +6.7 | 0.0 | 1.7 | 0.0 | +14.1 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +15.6 | 9.2 | 3.3 | 0.0 | +14.2 | 13.9 | 0.0 |
| IDLE COST | 16.5 | -271.0 | 0.0 | 180.7 | 20.1 | -302.1 | 0.0 | 262.7 |
| INVITES THE FIGHT | 1.5 | +10.6 | 105.1 | 36.8 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +8.6 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -1.1 | 13.8 | 1.8 | 0.0 | -0.2 | 5.2 | 0.0 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.9 | +57.5 | 167.7 | 62.3 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +47.9 | 115.7 | 34.1 | 0.1 | +0.7 | 0.0 | 0.0 |
| KILLS COUNT NEXT TURN | 4.9 | +185.8 | 209.1 | 101.6 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.5 | +14.7 | 15.4 | 15.4 | 0.1 | +6.9 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +1.4 | 22.9 | 14.3 | 0.1 | -0.2 | 14.6 | 0.0 |
| LOST CHARGE | 3.2 | -40.1 | 176.1 | 112.9 | 0.1 | -0.5 | 19.0 | 3.2 |
| LURE BY WHAT IT DRAWS | 0.1 | -3.1 | 0.0 | 0.0 | 0.0 | -1.8 | 0.0 | 1.5 |
| MAKE SURE TOGETHER | 0.5 | +23.8 | 4.7 | 41.2 | 0.1 | +4.9 | 0.0 | 4.2 |
| MANOEUVRE | 0.2 | +4.2 | 0.0 | 0.0 | 1.1 | +15.6 | 0.0 | 24.0 |
| MARCH AT ESCAPER | 0.0 | +0.7 | 0.0 | 0.0 | 0.2 | +2.7 | 0.0 | 3.0 |
| MARCH CHECK | 0.6 | +13.7 | 0.0 | 16.4 | 0.6 | +59.8 | 0.0 | 12.9 |
| MARCH ODDS | 0.1 | +12.9 | 10.2 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.6 | +50.2 | 0.0 | 27.2 | 0.6 | +102.2 | 0.0 | 25.9 |
| MAX FOR POSITIONING | 5.8 | +100.7 | 0.0 | 121.0 | 7.5 | +92.6 | 0.0 | 180.1 |
| MISSILES IN THE MOVE | 4.2 | +167.4 | 0.0 | 65.2 | 3.6 | +58.3 | 0.0 | 67.4 |
| MISSILES NEXT TURN | 4.9 | +109.2 | 0.0 | 83.7 | 4.3 | +40.6 | 0.0 | 98.2 |
| MODEL FACING | 0.4 | +90.8 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 8.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.4 | +27.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.1 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -48.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 13.1 |
| MOVE TO CHARGE | 3.6 | +272.7 | 133.2 | 38.9 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +7.6 | 3.0 | 0.0 | 0.1 | +5.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 14.4 | -264.9 | 23.0 | 344.6 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 4.6 | -324.2 | 46.7 | 59.1 |
| NO DOUBLE ROUNDS | - | - | - | - | 2.0 | -111.1 | 270.1 | 33.3 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| NOT NEEDED | 0.3 | -30.4 | 58.1 | 8.8 | - | - | - | - |
| NOT TURNED | 4.9 | +67.9 | 0.0 | 100.3 | 0.4 | +0.4 | 0.0 | 12.9 |
| NOT WORTH A CAST | 1.2 | -1.0 | 0.0 | 21.1 | 0.2 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 18.3 | -753.9 | 18.4 | 271.2 | 2.0 | -91.7 | 0.0 | 44.4 |
| ONE FIGHT FORMULA | 8.9 | -141.2 | 82.6 | 224.1 | 7.1 | -146.2 | 0.0 | 209.7 |
| ONE OBJECTIVE FORMULA | 2.6 | -66.9 | 0.0 | 46.7 | 1.9 | -21.3 | 0.0 | 42.4 |
| OPENS A LANE | 0.1 | +0.3 | 4.7 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +15.6 | 16.2 | 0.0 | 0.3 | +25.1 | 11.6 | 7.9 |
| OVERRUNS AWAY | 0.6 | +21.0 | 67.3 | 36.1 | 0.4 | +5.4 | 65.4 | 0.0 |
| PATHS CROSS | 2.2 | +133.7 | 0.0 | 40.5 | 3.2 | +232.0 | 0.0 | 56.4 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +2.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.4 | 0.0 | 0.0 | 0.1 | -2.3 | 0.0 | 0.0 |
| PLAN RESULT | 40.1 | +1502.7 | 1445.6 | 835.9 | 38.4 | +523.4 | 294.8 | 1028.5 |
| PURSUES BIG PREY | 0.1 | -9.7 | 0.0 | 0.0 | 0.1 | -8.5 | 0.0 | 13.7 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +13.3 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.0 | +8.7 | 0.0 | 12.8 | 1.5 | +25.3 | 0.0 | 60.4 |
| RANDOM MOVER NO PROMISE | 0.1 | -6.3 | 3.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.6 | -13.1 | 0.0 | 5.8 | 0.4 | -10.2 | 0.0 | 4.0 |
| REDIRECT COUNTER | 1.7 | +118.7 | 0.0 | 12.6 | 4.4 | +375.0 | 0.0 | 87.8 |
| REDIRECT WEIGHED | 0.3 | +1.3 | 3.0 | 0.8 | 0.3 | +1.1 | 6.9 | 14.2 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +8.1 | 0.0 | 5.6 | 0.9 | +25.8 | 0.0 | 26.1 |
| RESTRAINS TO SHOOT | 0.1 | +1.8 | 0.0 | 0.0 | 0.0 | +1.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +78.9 | 239.4 | 94.7 | 2.0 | +34.7 | 234.8 | 49.0 |
| RISK ONCE | 2.6 | +38.9 | 12.9 | 64.7 | - | - | - | - |
| RUN DOWN | - | - | - | - | 2.1 | -21.4 | 230.4 | 30.6 |
| SAFER THAN THE JOB | 0.8 | +34.7 | 0.0 | 20.5 | 0.0 | +1.8 | 0.0 | 0.0 |
| SCALED CHANCE | - | - | - | - | 4.1 | +46.8 | 0.0 | 78.0 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 1.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 1.9 |
| SCREEN BY WHAT IT SAVES | 0.3 | -24.5 | 0.0 | 0.0 | 0.2 | -5.4 | 0.0 | 2.5 |
| SEARCH SPOT | 1.8 | +59.1 | 0.0 | 33.1 | 7.0 | +281.9 | 0.0 | 172.4 |
| SELF MOVE SPELL | 0.2 | +44.0 | 0.0 | 18.1 | 0.2 | -0.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.2 | +113.5 | 29.9 | 42.7 | 0.4 | +11.1 | 0.0 | 14.2 |
| SET-UP ANY TARGET | 0.2 | +16.3 | 5.1 | 0.0 | 0.1 | +13.4 | 13.1 | 13.1 |
| SET-UP MISSED | 0.1 | +9.7 | 0.0 | 0.0 | 0.0 | +1.8 | 16.6 | 7.6 |
| SHOOTER COUNTED ONCE | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +73.7 | 113.9 | 22.9 | 0.5 | +14.0 | 0.0 | 3.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 154.2 | 24.6 | 0.3 | +0.0 | 38.4 | 10.4 |
| SHOTS IN THE MOVE | 13.8 | +516.2 | 0.0 | 232.3 | 9.9 | +243.2 | 0.0 | 227.5 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 5.1 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +123.0 | 5.1 | 0.0 | 0.1 | +13.4 | 13.1 | 13.1 |
| SPELL WORTH | 1.3 | +17.8 | 27.1 | 24.6 | 1.8 | +34.2 | 75.5 | 79.5 |
| SPELLS IN THE FIGHT | 0.6 | +5.1 | 114.5 | 17.4 | 0.4 | -4.1 | 71.0 | 7.6 |
| STABLE ROLE | 11.5 | +0.0 | 432.4 | 161.3 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.6 | -4.9 | 37.7 | 2.5 |
| STANDS TO CAST | 0.1 | +1.6 | 0.0 | 10.9 | 0.0 | +0.1 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +3.4 | 9.2 | 3.3 | 0.0 | +0.1 | 13.9 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +35.4 | 0.0 | 19.1 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 1.1 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 5.3 | -48.0 | 333.1 | 70.1 | 1.1 | +0.0 | 138.8 | 27.1 |
| SUPPORTS | 3.4 | +49.7 | 142.9 | 23.9 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.3 | 9.9 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.4 | -9.9 | 0.0 | 0.0 | 0.3 | +2.8 | 0.0 | 23.8 |
| THROUGH LINE OF FIRE | 0.4 | +18.6 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 1.8 | +0.0 | 4.4 | 36.4 |
| TURN WORTH | 0.5 | -29.4 | 51.8 | 9.0 | 0.0 | -1.6 | 2.3 | 0.0 |
| TWO OR MORE ARRIVE | 0.4 | +2.5 | 0.0 | 16.4 | 0.0 | +0.0 | 0.0 | 4.2 |
| WAIT AFTER COSTS | 7.8 | -361.5 | 371.0 | 105.0 | - | - | - | - |
| WALKS TO THE FIGHT | 2.2 | +18.0 | 67.5 | 8.1 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +7.5 | 4.2 | 0.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 22.4 | 17.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 1.0 | +47.7 | 156.4 | 16.6 | - | - | - | - |
| WHO HITS BACK | 0.2 | +13.3 | 0.0 | 15.1 | 0.2 | +47.2 | 0.0 | 13.4 |
| WHOLE FIGHT | 0.2 | +9.8 | 47.5 | 1.8 | 0.3 | -6.3 | 65.9 | 6.4 |
| WHOLE FIGHT GAIN | 0.4 | +25.8 | 55.0 | 2.1 | 0.2 | +14.6 | 20.3 | 9.4 |
| WIDER SPREAD | 2.5 | -7.9 | 301.1 | 54.2 | 1.9 | -1.3 | 196.2 | 31.6 |

### Rule changes: fafix-opp-5e477c5-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 730 | 730 | 730 | 20.28 | -30444 | -41.7 |
| SEARCH SPOT | 319 | 319 | 307 | 8.53 | +12293 | +40.0 |
| PATHS CROSS | 197 | 197 | 197 | 5.47 | +13165 | +66.8 |
| SHOTS IN THE MOVE | 853 | 677 | 102 | 2.83 | +2825 | +27.7 |
| FIVE ACTION | 1492 | 1492 | 94 | 2.61 | +3084 | +32.8 |
| IDLE COST | 1318 | 859 | 91 | 2.53 | +1003 | +11.0 |
| MAX FOR POSITIONING | 478 | 382 | 86 | 2.39 | +308 | +3.6 |
| FACES THE THREAT | 80 | 80 | 80 | 2.22 | +5174 | +64.7 |
| MOVE TO CHARGE | 128 | 128 | 68 | 1.89 | +3550 | +52.2 |
| CHARGE LOSSES | 368 | 368 | 66 | 1.83 | +4651 | +70.5 |
| COVER ONCE | 425 | 272 | 63 | 1.75 | +1388 | +22.0 |
| SUPPORTS | 124 | 124 | 63 | 1.75 | +714 | +11.3 |
| KILLS COUNT NEXT TURN | 178 | 178 | 61 | 1.69 | +1650 | +27.1 |
| FOLLOW UP WEIGHED | 55 | 55 | 55 | 1.53 | +7010 | +127.5 |
| REDIRECT COUNTER | 221 | 172 | 53 | 1.47 | +4569 | +86.2 |
| ADVANCE WORTH | 234 | 234 | 52 | 1.44 | +772 | +14.8 |
| MISSILES IN THE MOVE | 279 | 199 | 52 | 1.44 | +1483 | +28.5 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 90 | 90 | 51 | 1.42 | +1223 | +24.0 |
| WAIT AFTER COSTS | 282 | 282 | 50 | 1.39 | +815 | +16.3 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| BEST FIRST | 45 | 45 | 45 | 1.25 | +1733 | +38.5 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| RESERVE FALL BACK | 43 | 43 | 43 | 1.19 | +1222 | +28.4 |
| FOUR ROUNDS | 104 | 104 | 41 | 1.14 | +2701 | +65.9 |
| ONE FIGHT FORMULA | 576 | 393 | 41 | 1.14 | +201 | +4.9 |
| SHOT REPLANNED | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| CHAFF IN THE MOVE | 54 | 53 | 40 | 1.11 | +648 | +16.2 |
| NEXT CHARGE BY LIST | 518 | 518 | 39 | 1.08 | +255 | +6.5 |
| RISK BY ARC | 159 | 157 | 37 | 1.03 | +1278 | +34.5 |
| WALKS TO THE FIGHT | 80 | 80 | 37 | 1.03 | +221 | +6.0 |
| MARCH CHECK | 41 | 38 | 36 | 1.00 | +1190 | +33.1 |
| FALLBACK BY WORTH | 179 | 179 | 35 | 0.97 | +2056 | +58.7 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SHOOTS FROM THE BEST SPOT | 79 | 79 | 34 | 0.94 | +1480 | +43.5 |
| SAFER THAN THE JOB | 29 | 29 | 29 | 0.81 | +1314 | +45.3 |
| CANNON PLANNED TARGET | 207 | 207 | 28 | 0.78 | -127 | -4.5 |
| COMBAT PIVOT | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| MANOEUVRE | 46 | 46 | 27 | 0.75 | +716 | +26.5 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CHARGE NOW FIRST | 136 | 136 | 26 | 0.72 | -1468 | -56.5 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| NEXT OBJECTIVE NEARER | 165 | 165 | 23 | 0.64 | +268 | +11.6 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +357 | +16.2 |
| RISK ONCE | 92 | 61 | 21 | 0.58 | +395 | +18.8 |
| SET UP TOGETHER | 57 | 51 | 20 | 0.56 | +1929 | +96.4 |
| STOPS SHORT OF THE FLANK | 20 | 20 | 20 | 0.56 | +1276 | +63.8 |
| BEST FACING | 19 | 19 | 19 | 0.53 | +929 | +48.9 |
| INVITES THE FIGHT | 53 | 53 | 19 | 0.53 | +171 | +9.0 |
| BLOCKED WHEEL | 18 | 18 | 18 | 0.50 | +470 | +26.1 |
| KILLS COUNT | 58 | 57 | 16 | 0.44 | +350 | +21.9 |
| SCALED CHANCE | 147 | 147 | 15 | 0.42 | +77 | +5.1 |
| THROUGH LINE OF FIRE | 15 | 15 | 15 | 0.42 | +670 | +44.6 |
| CAST JOB | 28 | 28 | 14 | 0.39 | +236 | +16.8 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| HONEST WORTH | 397 | 396 | 14 | 0.39 | +129 | +9.2 |
| MOVE AND CAST | 14 | 14 | 14 | 0.39 | +987 | +70.5 |
| BEST OVERALL | 13 | 13 | 13 | 0.36 | +421 | +32.4 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -16 | -1.2 |
| CHARGE NOW WEIGHED | 13 | 13 | 13 | 0.36 | +288 | +22.2 |
| MODEL FACING | 13 | 13 | 13 | 0.36 | +3269 | +251.5 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +1007 | +83.9 |
| WHO HITS BACK | 12 | 12 | 12 | 0.33 | +1155 | +96.3 |
| WHOLE FIGHT GAIN | 25 | 24 | 12 | 0.33 | +505 | +42.1 |
| CASTING BLOCK | 22 | 22 | 11 | 0.31 | +759 | +69.0 |
| KEEPS ITS TARGET | 69 | 69 | 11 | 0.31 | +231 | +21.0 |
| MISSILES NEXT TURN | 332 | 229 | 11 | 0.31 | +10 | +0.9 |
| ONE OBJECTIVE FORMULA | 163 | 105 | 11 | 0.31 | +259 | +23.5 |
| OPENS UP | 19 | 19 | 11 | 0.31 | +495 | +45.0 |
| WAR ENGINE JOBS | 19 | 19 | 11 | 0.31 | -540 | -49.1 |
| BEST PREY | 23 | 23 | 10 | 0.28 | +367 | +36.7 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| REFUSING RETIRES | 19 | 19 | 9 | 0.25 | -2 | -0.3 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| SURE REACH TOGETHER | 24 | 23 | 7 | 0.19 | +17 | +2.4 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -119 | -19.8 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -97 | -16.2 |
| SUPPORT NARROWED | 230 | 230 | 6 | 0.17 | -152 | -25.3 |
| EDGE GIVE GROUND | 16 | 16 | 5 | 0.14 | +369 | +73.9 |
| HUNT IN PAIRS | 34 | 29 | 5 | 0.14 | +167 | +33.4 |
| LOST CHARGE | 122 | 121 | 5 | 0.14 | +39 | +7.8 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -656 | -131.2 |
| WEARS DOWN | 37 | 36 | 5 | 0.14 | +171 | +34.2 |
| BIG CHARACTER SAFETY | 4 | 4 | 4 | 0.11 | -19 | -4.9 |
| CATCH ODDS | 4 | 4 | 4 | 0.11 | -60 | -14.9 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 4 | 0.11 | +242 | +60.4 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.08 | +170 | +56.7 |
| GUN MASK | 7 | 7 | 3 | 0.08 | +75 | +25.0 |
| LONG SHOT | 20 | 20 | 3 | 0.08 | +34 | +11.5 |
| MARCH ODDS | 4 | 4 | 3 | 0.08 | +16 | +5.3 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +110 | +36.8 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +10 | +3.3 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +192 | +63.8 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -47 | -15.7 |
| WHOLE FIGHT | 16 | 16 | 3 | 0.08 | +226 | +75.5 |
| WIDER SPREAD | 158 | 155 | 3 | 0.08 | +51 | +17.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +39 | +19.3 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +62 | +30.9 |
| FEATURE BUFFS | 15 | 15 | 2 | 0.06 | +10 | +4.8 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +23 | +11.5 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +10 | +4.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| MAKE SURE TOGETHER | 23 | 12 | 2 | 0.06 | +69 | +34.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +91 | +45.4 |
| SCREEN BY WHAT IT SAVES | 17 | 17 | 2 | 0.06 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 36 | 34 | 2 | 0.06 | +7 | +3.7 |
| BACKUP TARGETS | 27 | 14 | 1 | 0.03 | +4 | +4.1 |
| CHARIOT NO STATIC JOB | 2 | 2 | 1 | 0.03 | -46 | -46.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +103 | +103.4 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +1 | +1.0 |
| OVERRUNS AWAY | 34 | 34 | 1 | 0.03 | +2 | +2.0 |
| REDIRECT BY WHAT IT STOPS | 33 | 33 | 1 | 0.03 | +21 | +21.2 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.03 | +12 | +11.9 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 17 | 16 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 34 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 27 | 26 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 75 | 75 | 0 | 0.00 | - | - |
| FALLS SHORT | 17 | 17 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 362 | not checked | - | - | - | - |
| GIVES UP | 9 | 9 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 17 | 0 | 0.00 | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 5 | 5 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 22 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 43 | 43 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 4 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 73 | 73 | 0 | 0.00 | - | - |
| NOT NEEDED | 12 | 12 | 0 | 0.00 | - | - |
| NOT TURNED | 191 | 191 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 49 | not checked | - | - | - | - |
| OPENS A LANE | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 2826 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 74 | 74 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 14 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 12 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 17 | not checked | - | - | - | - |
| SPELL WORTH | 111 | not checked | - | - | - | - |
| STABLE ROLE | 414 | 413 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 20 | 20 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 65 | 65 | 0 | 0.00 | - | - |
| TURN WORTH | 18 | 18 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 15 | 14 | 0 | 0.00 | - | - |

### Off best figure: fafix-opp-5e477c5-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 16.72 | 1.81 | 41.7 |
| CHARGE NOW FIRST | rule | 0.42 | 0.31 | 56.5 |
| FALLBACK | gate | 0.61 | 0.03 | 47.9 |
| TURN GATE | gate | 0.50 | - | 47.5 |
| WAR ENGINE JOBS | rule | 0.31 | - | 49.1 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 2.5 |
| BEST PRIZE | rule | 0.11 | 0.06 | 19.8 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.11 | 16.2 |
| SUPPORT NARROWED | rule | 0.17 | - | 25.3 |
| CANNON PLANNED TARGET | rule | 0.14 | - | 51.4 |
| CHAFF PASSED | rule | - | 0.14 | 3.0 |
| PURSUES BIG PREY | rule | 0.08 | 0.06 | 131.2 |
| SUPPORT REQUEST | gate | 0.14 | - | 82.6 |
| BIG CHARACTER SAFETY | rule | 0.11 | - | 4.9 |
| CATCH ODDS | rule | 0.08 | 0.03 | 14.9 |
| PATHS CROSS | rule | 0.08 | 0.03 | 5.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 51.1 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 48.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | - | 20.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | - | 15.7 |
| BLOCKED WHEEL | rule | 0.06 | - | 18.2 |
| FIGHT ORDER BAND | gate | 0.06 | - | 2.1 |
| REDIRECT WEIGHED | rule | - | 0.06 | 25.0 |
| RULE SWITCHED OFF | gate | 0.03 | 0.03 | 18.3 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | - | 5.0 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 46.0 |
| FACES THE THREAT | rule | 0.03 | - | 3.7 |
| LONG SHOT | rule | 0.03 | - | 8.8 |
| REFUSING RETIRES | rule | - | 0.03 | 0.8 |
| SAFER THAN THE JOB | rule | 0.03 | - | 5.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 0.7 |
| WHO HITS BACK | rule | - | 0.03 | 4.2 |

### Plans: fafix-opp-5e477c5-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.9 | 20% | 200 | 374 | 187% |
| Mine | charge | 3.3 | 64% | 285 | 267 | 94% |
| Mine | close in | 5.0 | 30% | 311 | 200 | 64% |
| Mine | hold | 6.8 | 42% | 424 | 0 | 0% |
| Mine | join | 0.6 | 95% | 20 | 0 | 0% |
| Mine | shoot | 9.1 | 63% | 349 | 665 | 190% |
| Mine | support | 4.2 | 93% | 38 | 0 | 0% |
| Opponent | charge | 2.3 | 64% | 290 | 289 | 100% |
| Opponent | join | 1.6 | 97% | 73 | 0 | 0% |
| Opponent | move | 31.0 | 91% | 1004 | 0 | 0% |
| Opponent | shoot | 3.1 | 65% | 120 | 235 | 196% |
| Opponent | support | 0.4 | 69% | 8 | 0 | 0% |

### Packages: hunt the guns, fafix-opp-5e477c5-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 1 | 100% | 100% | 0% | 2.0 | 318 | 242 | 100% | 35 |
| Opponent | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 513 | 506 | 100% | 97 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.4 | 2 | 1 | 100% | 100% | 0% | 2.0 | 318 | 242 | 100% | 194 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 57 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 144 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 378 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 97 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 513 | 506 | 100% | 74 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 46 |

### Battle groups: fafix-opp-5e477c5-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 20% | 50% | 8% | 0% | 18% | 9% | 9% | 64% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 26% | 64% | 17% | 29% | 26% | 0% | 3% | 69% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fafix-opp-5e477c5-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 56 | 67% | 3.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 37 | 82 (37) | 57 | 25 | 27 | 38% | 2.4 | 94 (16) | 21 (9) | 112 (12) | 110 (24) | 40 (13) |
| Mine | Character | 123 | 52 (123) | 52 | 0 | 29 | 20% | 2.3 | 70 (39) | 50 (60) | 22 (12) | 62 (62) | 48 (49) |
| Mine | Clean-up | 24 | 57 (24) | 21 | 36 | 23 | 42% | 2.5 | 53 (9) | 39 (11) | 153 (4) | 65 (14) | 48 (10) |
| Mine | Fast | 4 | 34 (4) | 34 | 0 | 47 | 0% | 2.0 | 0 (1) | 0 (2) | 275 (1) | 34 (4) | - |
| Mine | Fast Hammer | 41 | 53 (41) | 40 | 13 | 49 | 32% | 2.9 | 50 (18) | 67 (12) | 44 (11) | 63 (28) | 34 (13) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 60 | 0% | 1.8 | - | 17 (4) | 0 (1) | 69 (1) | 0 (4) |
| Mine | Hammer | 58 | 37 (58) | 26 | 10 | 33 | 21% | 2.9 | 52 (10) | 33 (38) | 38 (10) | 40 (34) | 34 (24) |
| Mine | Holder | 25 | 115 (25) | 7 | 108 | 7 | 68% | 3.2 | 115 (8) | 118 (14) | 102 (3) | 135 (13) | 96 (12) |
| Mine | Shooter | 44 | 127 (44) | 42 | 86 | 33 | 9% | 1.9 | 50 (5) | 148 (32) | 113 (7) | 139 (24) | 114 (20) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 40% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 53 (56) | 53 | 0 | 41 | 7% | 1.2 | 89 (13) | 40 (37) | 57 (6) | 40 (11) | 57 (45) |
| Mine | Wizard | 23 | 22 (23) | 22 | 0 | 28 | 26% | 2.3 | 20 (6) | 42 (10) | 0 (2) | 110 (2) | 7 (16) |
| Opponent | Blocker | 1 | 94 (1) | 94 | 0 | 0 | 0% | 6.0 | - | 94 (1) | - | - | 94 (1) |
| Opponent | Chaff | 66 | 46 (66) | 21 | 25 | 60 | 39% | 2.9 | 56 (28) | 48 (16) | 31 (22) | 54 (48) | 24 (18) |
| Opponent | Character | 114 | 41 (114) | 41 | 0 | 37 | 28% | 2.5 | 51 (41) | 44 (53) | 0 (5) | 37 (65) | 63 (34) |
| Opponent | Clean-up | 16 | 26 (16) | 13 | 13 | 53 | 44% | 3.4 | 0 (5) | 10 (8) | 100 (3) | 55 (8) | 5 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 58 | 41 (58) | 28 | 14 | 52 | 29% | 2.8 | 38 (25) | 48 (19) | 40 (14) | 38 (42) | 49 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 62 | 30% | 2.3 | 0 (3) | 0 (3) | 0 (4) | 0 (8) | 0 (2) |
| Opponent | Hammer | 65 | 22 (65) | 12 | 10 | 54 | 25% | 2.5 | 2 (16) | 28 (42) | 17 (7) | 23 (40) | 19 (25) |
| Opponent | Holder | 40 | 44 (40) | 7 | 38 | 29 | 42% | 3.5 | 0 (9) | 81 (20) | 3 (9) | 76 (19) | 21 (19) |
| Opponent | Shooter | 30 | 57 (30) | 19 | 37 | 40 | 3% | 1.4 | 54 (7) | 51 (18) | 85 (5) | 65 (16) | 45 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 87 (13) | 87 | 0 | 62 | 0% | 1.3 | 12 (5) | 114 (5) | 169 (3) | 252 (3) | 38 (10) |
| Opponent | Wizard | 22 | 4 (22) | 4 | 0 | 35 | 5% | 2.6 | 6 (13) | 0 (4) | 0 (3) | 7 (11) | 0 (9) |

### Charged fights: fafix-opp-5e477c5-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 196 | 124 | 1.2 | 1.7 | 104 | 14 | +90 | 2 of 6 | 4 of 6 | +40 | +115 |
| Mine | Chaos Dwarfs | 3 | 122 | 581 | 4.0 | 1.1 | 145 | 0 | +145 | 5 of 12 | 10 of 12 | +362 | +125 |
| Mine | Dwarfen Mountain Holds | 4 | 293 | 56 | 1.8 | 1.1 | 32 | 42 | -10 | 3 of 7 | 5 of 7 | -233 | +28 |
| Mine | Empire of Man | 5 | 557 | 231 | 2.2 | 1.4 | 105 | 10 | +95 | 0 of 11 | 9 of 11 | +112 | +88 |
| Mine | Grand Cathay | 4 | 490 | 238 | 2.8 | 1.1 | 87 | 11 | +75 | 6 of 11 | 9 of 11 | +0 | +83 |
| Mine | High Elf Realms | 4 | 210 | 339 | 3.0 | 1.0 | 113 | 80 | +34 | 5 of 12 | 7 of 12 | - | +34 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1002 | 5.0 | 1.2 | 200 | 0 | +200 | 1 of 5 | 5 of 5 | +666 | +84 |
| Mine | Lizardmen | 1 | 66 | 941 | 6.0 | 1.0 | 157 | 0 | +157 | 2 of 6 | 5 of 6 | - | +157 |
| Mine | Ogre Kingdoms | 1 | 195 | 136 | 3.0 | 1.0 | 45 | 11 | +34 | 0 of 3 | 2 of 3 | - | +34 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 70 | 4.0 | 1.2 | 18 | 14 | +4 | 1 of 4 | 3 of 4 | +0 | +5 |
| Mine | Skaven | 2 | 140 | 34 | 2.0 | 1.0 | 17 | 64 | -47 | 2 of 4 | 3 of 4 | - | -47 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1039 | 3.5 | 1.3 | 297 | 0 | +297 | 2 of 7 | 6 of 7 | +278 | +304 |
| Mine | Vampire Counts | 2 | 0 | 792 | 5.0 | 1.4 | 158 | 32 | +126 | 3 of 10 | 7 of 10 | +211 | +90 |
| Mine | Warriors of Chaos | 1 | 56 | 251 | 5.0 | 1.0 | 50 | 6 | +44 | 2 of 5 | 3 of 5 | - | +44 |
| **Mine** | all armies | 36 | 242 | 338 | 2.9 | 1.2 | 118 | 22 | +96 | 34 of 103 | 78 of 103 | +160 | +85 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 817 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 645 | 286 | 4.0 | 1.0 | 72 | 0 | +72 | 3 of 4 | 1 of 4 | - | +72 |
| Opponent | High Elf Realms | 2 | 261 | 590 | 2.5 | 1.4 | 236 | 0 | +236 | 0 of 5 | 5 of 5 | +416 | +191 |
| Opponent | Lizardmen | 1 | 110 | 614 | 3.0 | 1.0 | 205 | 0 | +205 | 2 of 3 | 3 of 3 | - | +205 |
| Opponent | Ogre Kingdoms | 2 | 94 | 42 | 1.5 | 1.0 | 28 | 41 | -13 | 1 of 3 | 1 of 3 | - | -13 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 722 | 5.0 | 1.0 | 144 | 0 | +144 | 4 of 10 | 7 of 10 | - | +144 |
| Opponent | Skaven | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 71 | 718 | 4.2 | 1.1 | 169 | 8 | +161 | 7 of 17 | 11 of 17 | +620 | +100 |
| Opponent | Vampire Counts | 6 | 28 | 394 | 3.2 | 1.1 | 124 | 114 | +11 | 8 of 19 | 14 of 19 | +0 | +12 |
| Opponent | Warriors of Chaos | 7 | 0 | 114 | 1.0 | 1.0 | 114 | 0 | +114 | 4 of 7 | 6 of 7 | - | +114 |
| Opponent | Wood Elf Realms | 6 | 100 | 346 | 2.5 | 1.2 | 138 | 68 | +70 | 6 of 15 | 10 of 15 | +234 | +29 |
| **Opponent** | all armies | 36 | 93 | 325 | 2.3 | 1.1 | 139 | 41 | +98 | 35 of 84 | 58 of 84 | +295 | +78 |

### Effective charges: fafix-opp-5e477c5-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 2 (net +236) | 1 (net +58) | 1 (net +40) | 0 | 2 | 50% (2 of 4) |
| Mine | Chaos Dwarfs | 12 | 1 (net +388) | 1 (net +210) | 1 (net +0) | 1 (net +381) | 1 (net +362) | 6 (net +48) | 1 | 9% (1 of 11) |
| Mine | Dwarfen Mountain Holds | 7 | 2 (net +82) | 0 | 1 (net -233) | 1 (net -60) | 0 | 3 (net +20) | 0 | 14% (1 of 7) |
| Mine | Empire of Man | 11 | 3 (net +0) | 0 | 1 (net +0) | 2 (net +320) | 3 (net +134) | 2 (net +0) | 0 | 9% (1 of 11) |
| Mine | Grand Cathay | 11 | 1 (net +0) | 0 | 3 (net +67) | 2 (net +252) | 0 | 5 (net +25) | 0 | 27% (3 of 11) |
| Mine | High Elf Realms | 12 | 1 (net -141) | 2 (net -298) | 2 (net +216) | 2 (net +128) | 1 (net +190) | 3 (net +48) | 1 | 18% (2 of 11) |
| Mine | Kingdom of Bretonnia | 5 | 2 (net +333) | 0 | 0 | 1 (net +50) | 1 (net +75) | 1 (net +211) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 6 | 0 | 0 | 1 (net +0) | 1 (net +70) | 1 (net +70) | 2 (net +33) | 1 | 20% (1 of 5) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 1 (net -34) | 0 | 1 (net +66) | 0 | 1 | 50% (1 of 2) |
| Mine | Skaven | 4 | 1 (net -192) | 0 | 1 (net -65) | 0 | 0 | 2 (net +34) | 0 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net +809) | 0 | 0 | 2 (net +201) | 1 (net +432) | 2 (net +155) | 1 | 0% (0 of 6) |
| Mine | Vampire Counts | 10 | 2 (net +0) | 0 | 1 (net +479) | 3 (net +128) | 2 (net +77) | 1 (net +245) | 1 | 11% (1 of 9) |
| Mine | Warriors of Chaos | 5 | 1 (net -30) | 0 | 0 | 1 (net +0) | 1 (net +160) | 0 | 2 | 0% (0 of 3) |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Grand Cathay | 4 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +143) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 5 | 0 | 0 | 0 | 0 | 1 (net +416) | 2 (net +62) | 2 | 0% (0 of 3) |
| Opponent | Lizardmen | 3 | 1 (net +380) | 0 | 0 | 0 | 1 (net +45) | 0 | 1 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 3 | 1 (net +85) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 10 | 2 (net +110) | 0 | 1 (net +0) | 2 (net +78) | 0 | 1 (net +177) | 4 | 17% (1 of 6) |
| Opponent | Tomb Kings of Khemri | 17 | 1 (net +0) | 2 (net +92) | 3 (net +94) | 7 (net +272) | 0 | 2 (net +0) | 2 | 20% (3 of 15) |
| Opponent | Vampire Counts | 19 | 2 (net +71) | 2 (net -22) | 6 (net +141) | 3 (net -369) | 0 | 5 (net +150) | 1 | 33% (6 of 18) |
| Opponent | Warriors of Chaos | 7 | 1 (net +240) | 1 (net +125) | 0 | 0 | 0 | 4 (net +108) | 1 | 0% (0 of 6) |
| Opponent | Wood Elf Realms | 15 | 3 (net -117) | 1 (net -102) | 4 (net +220) | 1 (net -85) | 0 | 3 (net +146) | 3 | 33% (4 of 12) |

### Charged fights, damage counted: fafix-opp-5e477c5-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 241 | 242 | +111 | 153 | 50 | +103 | +42.8 |
| Mine | 50-54% | 3 | 410 | 221 | -129 | 70 | 199 | -129 | -31.4 |
| Mine | Effective (55-75%) | 14 | 258 | 245 | +89 | 136 | 38 | +98 | +38.0 |
| Mine | 76-89% | 17 | 250 | 166 | +158 | 173 | 41 | +132 | +52.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 205 | 164 | +56 | 83 | 24 | +59 | +28.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 490 | 111 | +150 | 177 | 45 | +132 | +27.0 |
| Mine | No odds | 14 | 299 | 147 | +88 | 106 | 21 | +85 | +28.5 |
| Mine | All fights | 103 | 279 | 179 | +96 | 130 | 40 | +90 | +32.2 |
| Opponent | Long shot (under 50%) | 12 | 233 | 316 | +60 | 136 | 102 | +34 | +14.4 |
| Opponent | 50-54% | 6 | 150 | 152 | +27 | 57 | 36 | +21 | +14.0 |
| Opponent | Effective (55-75%) | 16 | 265 | 190 | +125 | 166 | 51 | +115 | +43.4 |
| Opponent | 76-89% | 15 | 318 | 199 | +77 | 224 | 133 | +91 | +28.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 295 | 180 | +113 | 143 | 13 | +129 | +43.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 440 | 117 | +230 | 230 | 66 | +165 | +37.4 |
| Opponent | No odds | 16 | 293 | 210 | +116 | 161 | 39 | +122 | +41.8 |
| Opponent | All fights | 84 | 277 | 207 | +98 | 160 | 62 | +98 | +35.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fafix-opp-5e477c5-p1 | move | 384 | 81 (21%) | 56 (15%) | 51 (13%) | 252 (66%) |
| fafix-opp-5e477c5-p1 | objective | 182 | 30 (16%) | 18 (10%) | 27 (15%) | 125 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

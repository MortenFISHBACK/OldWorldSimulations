# Doctrine scorecard: fw-h2h-opp-e441028-p1

### Scorecard: fw-h2h-opp-e441028-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 7 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 3 | 1 | 3 | 3 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 2 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 1 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 4 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 5 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 5 | 2 | 5 | 2 | 2 | 0 | 0 | 200 |
| L0235 | 1 | 1 | Opponent | no | 1 | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 0 | 1 | 1 | 0 | 1 | 0 | 0 | 480 |
| L0319 | 1 | 1 | Opponent | no | 5 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | no | 1 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 548 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 1 | 2 | 1 | 0 | 0 | 1052 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 475 |
| L0508 | 4 | 1 | Opponent | no | 5 | - | 1 | 3 | 0 | 0 | 0 | 690 |
| L0524 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 2 | 2 | 1 | 0 | 0 | 801 |
| L0612 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 615 |
| L0628 | 4 | 1 | Opponent | no | 3 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | no | 6 | 3 | 2 | 1 | 0 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 1 | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 2 | - | 1 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 5 | 4 | 2 | 0 | 0 | 0 | 0 | 540 |
| L0913 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 2 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 479 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 497 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 473 |
| L1114 | 4 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 177 |
| L1131 | 3 | 1 | Mine | no | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 340 |
| L1224 | 6 | 1 | Mine | no | 3 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1224 | 6 | 1 | Opponent | no | 3 | 1 | 5 | 3 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 1 | 0 | 0 | 156 |
| L1335 | 3 | 1 | Mine | yes | 9 | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | yes | 1 | 3 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 1 | 6 | 0 | 0 | 1 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 0 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 3 | 3 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 2 | 8 | 1 | 2 | 0 | 0 | 274 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 2 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | yes | 4 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | no | 1 | 4 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 7 | 4 | 2 | 5 | 0 | 0 | 0 | 210 |
| L2127 | 3 | 1 | Opponent | no | 2 | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | no | - | 2 | 1 | 1 | 1 | 0 | 0 | 144 |
| L2231 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 2 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 10 | - | 5 | 0 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 5 | 1 | 2 | 0 | 0 | 0 | 0 | 98 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 24% | 2.3 | 2.5 | 2.8 | 1.1 | 0.2 | 0.0 | 0.0 | 226.2 |
| **Average** | | | Opponent | 18% | 2.5 | 2.3 | 2.4 | 1.5 | 0.4 | 0.0 | 0.0 | 139.7 |

### KPIs: fw-h2h-opp-e441028-p1

Rules off - Mine only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 181) | 16% (29 of 185) | 8% (29 of 366) |
| Winner chose to follow up after the loser gave ground |  | 100% (64 of 64); on the table 100% | 96% (51 of 53); on the table 96% | 98% (115 of 117); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 89% | 93% (14 of 15); on the table 93% | 92% (22 of 24); on the table 92% |
| Winner chose to pursue after the loser fled |  | 44% (11 of 25); on the table 56% | 66% (23 of 35); on the table 69% | 57% (34 of 60); on the table 63% |
| Winner chose to follow up or pursue (all three) |  | 85% (83 of 98); on the table 88% | 85% (88 of 103); on the table 86% | 85% (171 of 201); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 36% (119 of 330) | 33% (69 of 210) | 35% (188 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (119 of 237) | 53% (69 of 130) | 51% (188 of 367) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 54% (37 of 69) | 54% (37 of 69) |
| Points that never fought | lower | 35% (24909 of 71484) | 38% (27070 of 71889) | 36% (51979 of 143373) |
|   infantry points that never fought | lower | 46% (7800 of 16863) | 45% (6033 of 13348) | 46% (13833 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (145 of 279) | 58% (172 of 295) | 55% (317 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.1 uses a game | 65% (13 of 20); 1.1 uses a game | 81% (34 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.6 uses a game | 38% (3 of 8); 0.2 uses a game | 62% (15 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 42% (8 of 19); 0.2 uses a game | 50% (6 of 12); 0.2 uses a game | 45% (14 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (28228 of 59666) | 53% (33503 of 62699) | 50% (61731 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (21%) | 1.0 (26%) | 2.2 (23%) |
| MARCHED: its unit marched | 1.3 (22%) | 0.6 (16%) | 1.9 (20%) |
| CHARGED: its unit charged | 0.5 (8%) | 0.1 (1%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.2 (21%) | 0.5 (13%) | 1.7 (18%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (1%) | 0.2 (6%) | 0.3 (3%) |
| GONE: slain | 1.1 (18%) | 1.3 (33%) | 2.4 (24%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (5%) | 0.4 (5%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.6 | 1.6 | 1.6 | 5.2 | 0.5 | 1.5 |
| not cast | 4.4 | 2.8 | 3.0 | 9.8 | 1.9 | 22.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (40%) | 0.3 (9%) | 2.2 (23%) | 0.4 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (20%) | 0.4 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (5%) | 0.2 (8%) | 1.7 (18%) | 0.3 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (2%) | 0.1 (3%) | 0.3 (3%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 1.6 (35%) | 0.8 (27%) | 0.8 (27%) | 2.4 (24%) | 0.2 (9%) | 4.7 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (5%) | 0.1 (4%) | 0.4 (5%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (4%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.5 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (52%) | 0.3 (10%) | 1.5 (49%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.4 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.8 a game | 0.9 a game |
| stood (cast and not dispelled) | 72% (26 of 36) | 72% (18 of 25) | 72% (44 of 61) |
| the unit moved after it | 69% (18 of 26) | 72% (13 of 18) | 70% (31 of 44) |
| it charged on its next turn | 4% (1 of 26) | 0% (0 of 18) | 2% (1 of 44) |
| the enemy charged it first | 19% (5 of 26) | 6% (1 of 18) | 14% (6 of 44) |
| it fought by the end of its next turn | 12% (3 of 26) | 0% (0 of 18) | 7% (3 of 44) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 26) | 11% (2 of 18) | 5% (2 of 44) |
| none of these (no charge, no fight, no charge escaped) | 77% (20 of 26) | 83% (15 of 18) | 80% (35 of 44) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (520 of 872) | 49% (296 of 600) | 55% (816 of 1472) |
|   cavalry | 33% (20 of 60) | 38% (49 of 128) | 37% (69 of 188) |
|   character | 48% (57 of 118) | 29% (33 of 115) | 39% (90 of 233) |
|   chariot | 53% (45 of 85) | 79% (33 of 42) | 61% (78 of 127) |
|   infantry | 54% (158 of 294) | 53% (120 of 227) | 53% (278 of 521) |
|   monster | 55% (23 of 42) | 48% (11 of 23) | 52% (34 of 65) |
|   war machine | 79% (217 of 273) | 77% (50 of 65) | 79% (267 of 338) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (30%) | 2.2 (26%) | 5.2 (28%) |
| CHARGED: it charged | 1.4 (14%) | 1.6 (19%) | 3.0 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.5 (6%) | 1.3 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.7 (17%) | 1.8 (21%) | 3.5 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.8 (10%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (17%) | 1.2 (14%) | 2.9 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| OTHER BAR | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.4 | 86% | 2.9 pts | 8 pts |
| character | 2.8 | 0.7 | 79% | 6.6 pts | 19 pts |
| chariot | 2.2 | 0.8 | 81% | 7.9 pts | 17 pts |
| infantry | 11.2 | 3.8 | 75% | 9.8 pts | 110 pts |
| monster | 1.2 | 0.3 | 81% | 6.0 pts | 7 pts |
| war machine | 7.4 | 5.1 | 65% | 25.3 pts | 187 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.4 | 5.5 | 5.4 |
| Charges that made contact a game | 3.6 | 3.8 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.92 declared, 0.58 contact (24 units) | 0.24 declared, 0.17 contact (29 units) | 0.55 declared, 0.36 contact (53 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.80 declared, 0.60 contact (5 units) | 0.82 declared, 0.64 contact (11 units) | 0.81 declared, 0.62 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.67 declared, 0.45 contact (251 units) | 0.62 declared, 0.42 contact (292 units) | 0.64 declared, 0.43 contact (543 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (35 of 70) | 48% (10 of 21) | 25% (2 of 8) | 47% (47 of 99) |
| Character in a unit | 65% (22 of 34) | 71% (10 of 14) | 60% (3 of 5) | 66% (35 of 53) |
| Character on its own | 85% (45 of 53) | 57% (26 of 46) | 28% (17 of 61) | 55% (88 of 160) |
| Chariot | 56% (9 of 16) | 80% (8 of 10) | - | 65% (17 of 26) |
| Infantry | 54% (48 of 89) | 39% (14 of 36) | 50% (1 of 2) | 50% (63 of 127) |
| Monster | 38% (12 of 32) | 60% (6 of 10) | - | 43% (18 of 42) |
| Monstrous | 82% (9 of 11) | 64% (9 of 14) | - | 72% (18 of 25) |
| War Machines | 73% (30 of 41) | 100% (1 of 1) | - | 74% (31 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 88% (22 of 25); on the table 88% | 44% (61 of 138) | 36% | 42% (14 of 33) | 89% (8 of 9); 5.3 uses a game | 100% (3 of 3); 1.3 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 86% (6 of 7); on the table 100% | 25% (6 of 24) | 26% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (2 of 2); on the table 100% | - | 65% | 68% (28 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (4 of 5); on the table 80% | 36% (13 of 36) | 47% | 59% (38 of 64) | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 93% (25 of 27); on the table 96% | 23% (25 of 108) | 26% | 43% (19 of 44) | 92% (11 of 12); 6.6 uses a game | 100% (1 of 1); 0.2 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 70% (14 of 20); on the table 75% | 30% (9 of 30) | 32% | 47% (23 of 49) | 100% (5 of 5); 2.8 uses a game | 50% (9 of 18); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (11 of 11); on the table 100% | - | 33% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (6 of 6); on the table 100% | - | 36% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 33% (1 of 3); on the table 33% | 17% (2 of 12) | 50% | 57% (12 of 21) | 33% (1 of 3); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 90% (9 of 10); on the table 90% | 42% (15 of 36) | 41% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 93% (13 of 14); on the table 93% | 33% (10 of 30) | 30% | 62% (21 of 34) | 100% (3 of 3); 2.5 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| Tomb Kings of Khemri | 6 | 74% (17 of 23); on the table 74% | 33% (4 of 12) | 34% | 40% (12 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 89% (16 of 18); on the table 94% | 41% (22 of 54) | 34% | 66% (33 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 87% (20 of 23); on the table 87% | 33% (10 of 30) | 33% | 55% (41 of 74) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 71% (5 of 7); on the table 71% | 37% (11 of 30) | 25% | 55% (36 of 66) | 33% (2 of 6); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h-opp-e441028-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (38) | 33% (25) | 41% (63) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.47 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.08 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.28 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.50 | 1.17 | 2.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 1.03 | 1.94 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.92 | 8.03 | 13.94 |

### Quality by phase: fw-h2h-opp-e441028-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 0.0 |
| Strategy | Charge objectives carried out (made contact) | 49% (76 of 154) | 47% (71 of 151) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (143 of 318) | 42% (46 of 110) |
| Strategy | Close-in objectives charged next turn | 14% (26 of 183) | 14% (38 of 263) |
| Strategy | Support requests answered (helper made contact too) | 53% (8 of 15) | 39% (11 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 69% (9 of 13) | 35% (6 of 17) |
| Strategy | Joined characters whose unit fought | 32% (15 of 47) | 48% (15 of 31) |
| Strategy | Lone characters that fought | 80% (79 of 99) | 62% (65 of 105) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.1 | 1.5 |
| Movement | Points that never moved of their own | 226.2 | 139.7 |
| Movement | Fights charged into per game | 3.1 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 98, net +31 | 8 of 80, net +40 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 98, net +66 | 11 of 80, net +81 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 98, net +120 | 8 of 80, net +130 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 of 98, net +111 | 36 of 80, net +126 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.1 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (154 of 326) | 46% (132 of 288) |
| Shooting | Points destroyed by shooting units | 91.7 | 29.5 |
| Shooting | War machine shots | 6.0 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (125 of 217) | 40% (20 of 50) |
| Shooting | Points destroyed by war machines | 73.3 | 14.4 |
| Magic | Magic missiles cast | 2.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (26 of 73) | 44% (21 of 48) |
| Magic | Wounds caused by magic missiles | 4.3 | 1.2 |
| Magic | Wounds caused by other spells | 1.8 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 84.6 | 34.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.4 / 0.7 / 0.1 | 1.4 / 0.7 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 285.5 | 419.2 |
| Combat | Points run down | 98.6 | 137.9 |
| Combat | Net points per charged fight, damage counted | +72 | +121 |
| Combat | Net per 100 charger points, damage counted | +24.6 | +43.1 |
| Combat | First round won (charged fights) | 64% | 68% |
| Combat | Net points per charged fight | +65 | +112 |
| Combat | Net points per supported fight / lone fight | +112 / +56 | +154 / +101 |
| Combat | Charged fights on a top-3 enemy unit | 47 of 111 | 43 of 107 |
| Game | Points lost | 772.7 | 749.2 |
| Game | VP from objectives | 547.8 | 575.3 |
| Game | Lone holders (player turns) | 2.3 | 2.5 |

- Mine won / drew / lost: 16 / 6 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -38 VP
- The side that went first won 20 of 30 games with a winner
- Points traded per game (both sides' losses): 1522
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-h2h-opp-e441028-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 6.5 | 0.5 | +0.0 | 0.0 | 8.9 |
| BACKUP TARGETS | 1.2 | +8.2 | 0.0 | 42.8 | 1.3 | +8.6 | 0.0 | 43.7 |
| BEST FACING | - | - | - | - | 0.5 | +19.1 | 0.0 | 27.8 |
| BEST FIRST | - | - | - | - | 3.6 | +156.5 | 139.0 | 65.8 |
| BEST OVERALL | 0.4 | +15.3 | 0.0 | 18.9 | 0.6 | +51.6 | 0.0 | 18.9 |
| BEST PREY | 5.2 | +305.3 | 264.1 | 72.2 | 1.0 | +51.9 | 42.1 | 17.0 |
| BEST PRIZE | 0.0 | -1.7 | 0.0 | 0.0 | 0.1 | -4.9 | 4.0 | 9.5 |
| BIG CHARACTER SAFETY | 0.2 | -0.4 | 0.0 | 0.0 | 0.3 | -1.1 | 0.0 | 15.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 8.0 | 0.0 | 0.2 | +0.0 | 21.2 | 4.0 |
| BLOCKED WHEEL | 0.6 | +2.6 | 0.0 | 5.2 | 0.6 | +17.7 | 0.0 | 9.6 |
| BOMBING RUN | 0.1 | +2.1 | 3.2 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 80.6 | 19.0 | 0.1 | +0.0 | 6.2 | 2.6 |
| CANNON PLANNED TARGET | 4.4 | +171.9 | 302.8 | 111.4 | 1.0 | +17.3 | 15.6 | 16.8 |
| CARRIES OUT COUNTER | 0.1 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | -7.5 | 24.1 | 20.1 | 0.2 | -1.9 | 33.9 | 0.0 |
| CAST JOB | 1.0 | +42.1 | 67.0 | 2.6 | 0.4 | +11.5 | 26.7 | 28.6 |
| CASTING BLOCK | 0.4 | +35.2 | 24.8 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 22.4 | 0.5 | +0.0 | 0.0 | 26.9 |
| CATCH FLIERS | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.4 | -2.2 | 5.1 | 4.6 | 0.1 | -0.0 | 0.0 | 8.0 |
| CHAMPION TAKES THE CHALLENGE | 0.1 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.7 | -73.3 | 11.4 | 25.8 | 0.5 | -56.1 | 13.6 | 12.4 |
| CHARIOT NO STATIC JOB | 0.4 | +0.0 | 23.5 | 4.7 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.2 | -0.9 | 0.0 | 41.1 | 0.0 | -1.9 | 0.0 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 2.4 | 0.1 | +0.0 | 0.0 | 3.2 |
| COMBAT PIVOT | 0.5 | +0.0 | 15.1 | 58.7 | 0.5 | +0.0 | 26.9 | 14.2 |
| CONVEYANCE SEARCH | 0.8 | +76.2 | 22.4 | 22.4 | 0.6 | +147.9 | 15.8 | 38.5 |
| COUNTER-CHARGE COVER | 8.4 | +724.7 | 0.0 | 218.0 | 8.7 | +788.9 | 0.0 | 186.7 |
| DEFENSIVE ARMY | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.7 | 14.9 | 0.0 | 0.1 | +8.4 | 31.1 | 2.8 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.5 | +106.4 | 0.0 | 47.0 | 1.2 | +98.5 | 0.0 | 52.5 |
| FALLBACK BY WORTH | 6.5 | +87.6 | 0.0 | 37.3 | 5.1 | +45.0 | 0.0 | 50.2 |
| FIGHT LIFT | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 157.2 | 7.4 | +0.0 | 0.0 | 183.6 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.9 | 2.1 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +101.5 | 0.0 | 28.4 | 1.1 | +156.1 | 0.0 | 11.9 |
| FRIENDS SHOTS CHECKED | 0.4 | +11.8 | 0.0 | 17.9 | 0.2 | +5.0 | 0.0 | 3.5 |
| GIVES UP | 1.2 | -33.1 | 146.2 | 3.5 | 0.9 | -53.6 | 126.9 | 7.0 |
| GIVES UP ITS SCREEN | 0.7 | -15.5 | 66.5 | 18.1 | 0.1 | -1.1 | 5.9 | 0.0 |
| GROUND FLIERS | 0.0 | +1.1 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 2.7 | 2.5 | 0.1 | +0.0 | 13.4 | 0.8 |
| HELPER UNSEEN | 0.1 | +0.0 | 5.6 | 5.2 | 0.4 | +0.0 | 37.6 | 14.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.5 | +9.1 | 81.1 | 7.1 | 0.5 | +15.9 | 34.3 | 9.1 |
| HUNT DROPPED | 0.1 | +0.0 | 7.6 | 1.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +4.1 | 0.0 | 10.8 | 0.6 | +26.3 | 0.0 | 5.4 |
| HUNT KEPT | 0.2 | +8.0 | 51.6 | 3.4 | 0.2 | +4.7 | 11.8 | 0.5 |
| HUNT RESULT | 0.5 | +48.0 | 79.1 | 11.5 | 0.4 | +37.9 | 3.5 | 9.6 |
| HUNT THE GUNS | 0.5 | +201.6 | 66.7 | 8.9 | 0.4 | +167.7 | 30.6 | 9.1 |
| INVITES THE FIGHT | - | - | - | - | 2.6 | +153.7 | 97.1 | 34.8 |
| JOINT CHARGE PLAN | 0.2 | +5.5 | 12.3 | 10.5 | 0.3 | +26.6 | 11.0 | 4.0 |
| KEEP FALLS | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.4 | +2.3 | 11.3 | 8.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 2.1 | +62.5 | 196.8 | 68.1 | 2.6 | +79.2 | 205.9 | 49.9 |
| KILLS COUNT | 2.1 | +103.2 | 161.1 | 67.4 | 2.0 | +86.3 | 169.7 | 46.9 |
| KILLS COUNT NEXT TURN | 9.9 | +327.5 | 642.8 | 232.0 | 7.8 | +238.6 | 453.4 | 184.7 |
| LONE CHARACTER SAFE SPOT | 0.6 | +12.8 | 33.5 | 4.8 | 1.0 | +22.4 | 19.5 | 27.5 |
| LONE WIZARD HOLDS BACK | 0.6 | +0.0 | 35.3 | 13.9 | 2.0 | +0.0 | 48.4 | 96.1 |
| LONG SHOT | - | - | - | - | 0.6 | -1.6 | 24.9 | 13.7 |
| LOST CHARGE | - | - | - | - | 2.6 | -36.3 | 93.8 | 89.3 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -7.0 | 0.0 | 8.1 |
| MAKE SURE TOGETHER | 0.7 | +53.3 | 27.9 | 31.0 | 1.4 | +139.0 | 93.8 | 12.5 |
| MANOEUVRE | 0.1 | +3.4 | 0.0 | 4.9 | 0.2 | +7.7 | 0.0 | 4.0 |
| MARCH AT ESCAPER | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.9 | +32.7 | 0.0 | 0.0 | 0.5 | +17.0 | 0.0 | 24.0 |
| MARCH ODDS | 0.7 | +52.1 | 73.0 | 0.0 | 0.2 | +10.9 | 1.8 | 13.5 |
| MARCH OVER CASTS | 0.6 | +40.5 | 0.0 | 17.5 | 0.5 | +11.9 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 5.0 | +185.1 | 0.0 | 134.9 | 5.7 | +232.2 | 0.0 | 108.1 |
| MISSILES IN THE MOVE | 5.0 | +177.7 | 0.0 | 81.0 | 3.2 | +54.0 | 0.0 | 136.8 |
| MISSILES NEXT TURN | 5.8 | +131.8 | 0.0 | 108.0 | 3.9 | +41.0 | 0.0 | 166.8 |
| MODEL FACING | 0.3 | +93.9 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 6.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +15.5 | 0.0 | 2.6 | 0.2 | +6.7 | 0.0 | 21.2 |
| MOVE SPELL IN RANGE | 0.8 | +24.0 | 0.0 | 11.2 | 0.3 | +16.4 | 0.0 | 13.7 |
| MOVE SPELL OUT OF RANGE | 0.5 | -20.5 | 0.0 | 0.0 | 0.2 | -10.7 | 7.0 | 7.6 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 11.1 | 0.2 | +0.0 | 0.0 | 5.6 |
| MOVE TO CHARGE | - | - | - | - | 8.2 | +745.7 | 440.1 | 233.2 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.9 | 3.5 | 0.0 |
| NOT NEEDED | 0.4 | -23.9 | 53.0 | 6.6 | 0.3 | -21.4 | 28.9 | 5.0 |
| NOT TURNED | 5.9 | +118.6 | 0.0 | 119.4 | 8.0 | +159.8 | 0.0 | 171.9 |
| NOT WORTH A CAST | 1.0 | -0.7 | 0.0 | 26.1 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 18.9 | -992.4 | 53.4 | 331.3 | 17.1 | -817.1 | 22.2 | 315.4 |
| OPENS A LANE | 0.4 | +1.3 | 11.0 | 3.5 | 0.0 | +0.1 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +22.0 | 23.6 | 0.0 | 0.1 | +7.5 | 5.9 | 0.0 |
| OVERRUN THREAT | 0.0 | +7.2 | 0.0 | 8.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +18.9 | 79.4 | 24.4 | 0.5 | +6.9 | 47.2 | 22.3 |
| PATHS CROSS | 2.2 | +103.3 | 0.0 | 36.3 | 3.7 | +242.9 | 0.0 | 67.4 |
| PIVOT GUARDS FLANK | 0.1 | -2.3 | 0.0 | 0.0 | 0.1 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 39.3 | +1697.2 | 1530.0 | 1115.1 | 41.9 | +1049.3 | 1553.9 | 1189.7 |
| PURSUES BIG PREY | 0.1 | -7.6 | 0.0 | 2.4 | 0.1 | -3.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.0 | +3.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.9 | +43.6 | 0.0 | 48.9 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.5 | -27.5 | 25.6 | 10.6 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.2 | +1.1 | 0.0 | 4.0 |
| REDIRECT COUNTER | 3.1 | +179.9 | 0.0 | 29.6 | 3.7 | +334.6 | 0.0 | 51.1 |
| REDIRECT WEIGHED | 0.5 | +21.9 | 12.1 | 2.0 | 0.3 | -0.1 | 13.9 | 10.3 |
| RESERVE FALL BACK | - | - | - | - | 0.5 | +7.4 | 0.0 | 15.6 |
| RESTRAINS TO SHOOT | 0.1 | +7.6 | 0.0 | 3.4 | 0.1 | +1.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.9 | +100.1 | 242.5 | 92.4 | 2.6 | +62.7 | 175.9 | 73.6 |
| SAFER THAN THE JOB | 0.9 | +53.9 | 0.0 | 31.9 | 1.0 | +56.3 | 0.0 | 34.4 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -6.8 | 0.0 | 0.0 |
| SEARCH SPOT | 1.5 | +96.8 | 0.0 | 18.1 | 4.2 | +207.9 | 0.0 | 37.1 |
| SECOND HUNTER | 0.2 | -3.9 | 46.8 | 5.3 | 0.1 | -1.7 | 11.2 | 0.0 |
| SELF MOVE SPELL | 0.3 | +14.6 | 0.0 | 0.0 | 0.3 | +18.6 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.1 | +107.0 | 27.9 | 62.4 | 2.3 | +199.4 | 93.8 | 29.2 |
| SET-UP ANY TARGET | 0.3 | +35.2 | 0.0 | 0.0 | 0.2 | +44.9 | 5.6 | 13.7 |
| SET-UP MISSED | 0.1 | +16.2 | 0.0 | 0.0 | 0.1 | +27.1 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.5 | +8.9 | 14.9 | 16.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 73.3 | 0.0 | 0.1 | +0.0 | 7.5 | 2.6 |
| SHOTS IN THE MOVE | 13.0 | +541.2 | 0.0 | 262.9 | 7.3 | +149.9 | 0.0 | 140.4 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +49.7 | 0.0 | 0.0 | 0.4 | +119.8 | 5.6 | 13.7 |
| SPELL WORTH | 1.1 | +16.5 | 80.9 | 61.9 | 1.5 | +37.0 | 68.3 | 68.3 |
| STABLE ROLE | - | - | - | - | 11.6 | +0.0 | 462.4 | 245.4 |
| STOPS | 0.2 | +8.2 | 26.5 | 5.2 | 0.1 | +1.9 | 3.5 | 0.5 |
| STOPS SHORT OF THE FLANK | 0.4 | +9.4 | 0.0 | 22.6 | 0.5 | +40.8 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 9.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORTS | - | - | - | - | 8.8 | +325.3 | 294.4 | 115.0 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.5 | 2.5 | 0.0 | 0.2 | -14.7 | 12.9 | 0.0 |
| SURE REACH TOGETHER | 0.5 | +10.3 | 10.9 | 23.1 | 0.5 | +0.1 | 9.2 | 14.7 |
| THROUGH LINE OF FIRE | 0.4 | +16.1 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -39.2 | 71.0 | 0.0 | 0.2 | -11.0 | 17.1 | 4.0 |
| TWO OR MORE ARRIVE | 0.4 | +8.4 | 27.9 | 8.0 | 0.7 | +3.3 | 42.4 | 1.9 |
| WALKS TO THE FIGHT | - | - | - | - | 1.8 | +99.4 | 67.3 | 27.2 |
| WAR ENGINE JOBS | - | - | - | - | 0.4 | +0.0 | 2.2 | 11.7 |
| WEARS DOWN | 0.9 | +38.6 | 105.2 | 43.1 | 1.2 | +41.6 | 118.3 | 42.9 |
| WHO HITS BACK | 0.2 | +9.5 | 0.0 | 2.3 | 0.2 | +16.4 | 0.0 | 4.7 |
| WHOLE FIGHT | 0.2 | +2.2 | 19.2 | 0.0 | 0.2 | +14.6 | 48.6 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +25.1 | 9.4 | 15.3 | 0.5 | +60.3 | 32.9 | 10.3 |

### Rule changes: fw-h2h-opp-e441028-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1297 | 1297 | 1297 | 36.03 | -65141 | -50.2 |
| PATHS CROSS | 212 | 212 | 212 | 5.89 | +12461 | +58.8 |
| SEARCH SPOT | 205 | 205 | 204 | 5.67 | +10970 | +53.8 |
| SUPPORTS | 316 | 316 | 170 | 4.72 | +3692 | +21.7 |
| MOVE TO CHARGE | 297 | 297 | 163 | 4.53 | +9011 | +55.3 |
| KILLS COUNT NEXT TURN | 636 | 631 | 156 | 4.33 | +4050 | +26.0 |
| COUNTER-CHARGE COVER | 616 | 323 | 149 | 4.14 | +10462 | +70.2 |
| BEST FIRST | 131 | 131 | 131 | 3.64 | +5633 | +43.0 |
| FACES THE THREAT | 96 | 96 | 96 | 2.67 | +7375 | +76.8 |
| FALLBACK BY WORTH | 415 | 415 | 90 | 2.50 | +4776 | +53.1 |
| BEST PREY | 224 | 219 | 82 | 2.28 | +2975 | +36.3 |
| FOLLOW UP WEIGHED | 79 | 79 | 79 | 2.19 | +9271 | +117.4 |
| SAFER THAN THE JOB | 70 | 70 | 70 | 1.94 | +3968 | +56.7 |
| REDIRECT COUNTER | 247 | 129 | 53 | 1.47 | +4829 | +91.1 |
| SET UP TOGETHER | 124 | 101 | 53 | 1.47 | +3912 | +73.8 |
| MARCH CHECK | 51 | 51 | 50 | 1.39 | +3150 | +63.0 |
| RISK BY ARC | 198 | 185 | 50 | 1.39 | +1320 | +26.4 |
| KILLS COUNT | 148 | 135 | 49 | 1.36 | +1442 | +29.4 |
| WALKS TO THE FIGHT | 64 | 64 | 49 | 1.36 | +1598 | +32.6 |
| MAX FOR POSITIONING | 385 | 197 | 48 | 1.33 | +605 | +12.6 |
| SHOTS IN THE MOVE | 731 | 448 | 48 | 1.33 | +1715 | +35.7 |
| BLOCKED WHEEL | 44 | 44 | 44 | 1.22 | +729 | +16.6 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| CANNON PLANNED TARGET | 196 | 196 | 43 | 1.19 | -803 | -18.7 |
| CHARGE NOW WEIGHED | 42 | 42 | 42 | 1.17 | +3889 | +92.6 |
| LONE WIZARD HOLDS BACK | 95 | 95 | 42 | 1.17 | -2036 | -48.5 |
| ARTILLERY RE-ROLL WEIGHED | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| BEST OVERALL | 37 | 37 | 37 | 1.03 | +2408 | +65.1 |
| KEEPS ITS TARGET | 170 | 164 | 37 | 1.03 | +583 | +15.8 |
| RANDOM MOVE BY FIGURES | 69 | 69 | 37 | 1.03 | +1569 | +42.4 |
| COMBAT PIVOT | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| INVITES THE FIGHT | 95 | 95 | 34 | 0.94 | +1888 | +55.5 |
| MISSILES IN THE MOVE | 295 | 157 | 34 | 0.94 | +612 | +18.0 |
| MAKE SURE TOGETHER | 74 | 56 | 32 | 0.89 | +2489 | +77.8 |
| MARCH ODDS | 33 | 33 | 31 | 0.86 | +612 | +19.7 |
| REDIRECT WEIGHED | 31 | 31 | 31 | 0.86 | +2492 | +80.4 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1806 | +58.3 |
| CAST JOB | 48 | 46 | 28 | 0.78 | +706 | +25.2 |
| MOVE AND CAST | 23 | 23 | 23 | 0.64 | +798 | +34.7 |
| FRIENDS SHOTS CHECKED | 21 | 21 | 21 | 0.58 | +604 | +28.8 |
| WHOLE FIGHT GAIN | 30 | 29 | 21 | 0.58 | +1280 | +60.9 |
| BIG CHARACTER SAFETY | 19 | 19 | 19 | 0.53 | -52 | -2.7 |
| BEST FACING | 18 | 18 | 18 | 0.50 | +688 | +38.2 |
| RESERVE FALL BACK | 18 | 18 | 18 | 0.50 | +265 | +14.7 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +598 | +37.4 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -79 | -5.2 |
| CHARIOT NO STATIC JOB | 16 | 16 | 14 | 0.39 | -1324 | -94.6 |
| SHOT REPLANNED | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +629 | +44.9 |
| HUNT ADVANCE | 34 | 34 | 12 | 0.33 | +181 | +15.1 |
| WEARS DOWN | 78 | 72 | 12 | 0.33 | +366 | +30.5 |
| CASTING BLOCK | 13 | 11 | 11 | 0.31 | +563 | +51.2 |
| BLOCKED CHARGE SKIPPED | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| MANOEUVRE | 14 | 14 | 10 | 0.28 | +402 | +40.2 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +3380 | +337.9 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 9 | 0.25 | +117 | +13.0 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -547 | -60.8 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -401 | -50.2 |
| SURE REACH TOGETHER | 34 | 20 | 8 | 0.22 | +8 | +1.0 |
| BACKUP TARGETS | 89 | 43 | 7 | 0.19 | +15 | +2.2 |
| MISSILES NEXT TURN | 349 | 184 | 7 | 0.19 | +88 | +12.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -181 | -25.9 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +320 | +45.7 |
| OPENS UP | 15 | 12 | 6 | 0.17 | +155 | +25.9 |
| OVERRUNS AWAY | 43 | 42 | 5 | 0.14 | +82 | +16.3 |
| WAR ENGINE JOBS | 16 | 16 | 5 | 0.14 | -295 | -59.0 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -238 | -59.6 |
| CARRIES OUT SET-UP | 14 | 14 | 4 | 0.11 | -338 | -84.6 |
| LOST CHARGE | 94 | 93 | 4 | 0.11 | +7 | +1.8 |
| WHOLE FIGHT | 14 | 13 | 3 | 0.08 | +163 | +54.2 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +75 | +37.4 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +78 | +39.0 |
| HUNT IN PAIRS | 31 | 18 | 2 | 0.06 | +329 | +164.5 |
| JOINT CHARGE PLAN | 20 | 20 | 2 | 0.06 | +212 | +106.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +32 | +15.9 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +62 | +31.0 |
| STOPS | 10 | 10 | 2 | 0.06 | +8 | +4.2 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -60 | -60.4 |
| EDGE GIVE GROUND | 7 | 7 | 1 | 0.03 | +8 | +7.7 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +32 | +32.3 |
| LONG SHOT | 20 | 20 | 1 | 0.03 | +1 | +1.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 47 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 5 | 5 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 478 | not checked | - | - | - | - |
| GIVES UP | 77 | 69 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 28 | 28 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 19 | 18 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 15 | trace | - | - | - | - |
| HUNT RESULT | 30 | trace | - | - | - | - |
| HUNT THE GUNS | 32 | trace | - | - | - | - |
| KEEPS ITS PREY | 14 | 13 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 55 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 40 | 40 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 39 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 26 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT NEEDED | 26 | 24 | 0 | 0.00 | - | - |
| NOT TURNED | 502 | 502 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 47 | not checked | - | - | - | - |
| OPENS A LANE | 14 | 5 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2924 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 18 | 18 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 9 | 9 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SECOND HUNTER | 10 | 10 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 19 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 25 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| STABLE ROLE | 417 | 416 | 0 | 0.00 | - | - |
| TURN WORTH | 30 | 25 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 41 | 41 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h-opp-e441028-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 16.00 | 14.28 | 52.3 |
| FALLBACK | gate | 1.25 | 0.75 | 48.0 |
| TURN GATE | gate | 0.28 | 0.86 | 23.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.25 | 0.67 | 59.5 |
| RULE SWITCHED OFF | gate | 0.89 | - | 25.0 |
| LONE WIZARD HOLDS BACK | rule | 0.06 | 0.72 | 72.7 |
| CANNON PLANNED TARGET | rule | 0.36 | 0.11 | 64.5 |
| CHARIOT NO STATIC JOB | rule | 0.39 | - | 94.6 |
| AFTERMATH BAND | gate | 0.17 | 0.14 | 2.8 |
| PATHS CROSS | rule | 0.14 | 0.14 | 33.2 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.19 | 8.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.22 | 60.8 |
| BLOCKED WHEEL | rule | 0.14 | 0.08 | 47.7 |
| PURSUES BIG PREY | rule | 0.14 | 0.08 | 50.2 |
| SUPPORT REQUEST | gate | 0.06 | 0.17 | 82.0 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.06 | 25.9 |
| CHAFF PASSED | rule | 0.14 | - | 15.7 |
| WAR ENGINE JOBS | rule | - | 0.14 | 59.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.08 | 46.5 |
| BEST PRIZE | rule | 0.03 | 0.08 | 59.6 |
| CARRIES OUT SET-UP | rule | 0.08 | 0.03 | 84.6 |
| FIGHT ORDER BAND | gate | 0.03 | 0.08 | 1.3 |
| MARCH ODDS | rule | 0.06 | 0.06 | 11.2 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.06 | 34.0 |
| FACES THE THREAT | rule | 0.03 | 0.06 | 18.4 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 4.0 |
| STOPS SHORT OF THE FLANK | rule | - | 0.08 | 3.4 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 13.2 |
| FRIENDS SHOTS CHECKED | rule | - | 0.06 | 3.0 |
| NO REASON | gate | - | 0.06 | 20.9 |
| WHO HITS BACK | rule | 0.06 | - | 2.0 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 60.4 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 4.2 |
| REDIRECT WEIGHED | rule | 0.03 | - | 63.3 |

### Plans: fw-h2h-opp-e441028-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.7 | 22% | 515 | 532 | 103% |
| Mine | charge | 3.4 | 70% | 340 | 312 | 92% |
| Mine | close in | 5.0 | 28% | 361 | 205 | 57% |
| Mine | hold | 3.9 | 44% | 247 | 0 | 0% |
| Mine | join | 1.5 | 93% | 55 | 0 | 0% |
| Mine | shoot | 7.6 | 65% | 279 | 648 | 232% |
| Mine | support | 4.1 | 91% | 198 | 0 | 0% |
| Opponent | advance | 13.9 | 16% | 798 | 403 | 51% |
| Opponent | charge | 3.5 | 59% | 364 | 321 | 88% |
| Opponent | close in | 7.1 | 26% | 988 | 221 | 22% |
| Opponent | hold | 3.8 | 30% | 269 | 0 | 0% |
| Opponent | join | 2.3 | 93% | 143 | 0 | 0% |
| Opponent | shoot | 2.2 | 48% | 51 | 105 | 205% |
| Opponent | support | 9.1 | 91% | 270 | 0 | 0% |

### Packages: hunt the guns, fw-h2h-opp-e441028-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.5 | 17 | 0 | 18% | 35% | 24% | 2.7 | 427 | 102 | 35% | 7 |
| Opponent | 0.4 | 15 | 2 | 8% | 31% | 0% | 2.5 | 415 | 105 | 23% | 88 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2.0 | 12 | 0 | 0% | 8% | 33% | 3.0 | 448 | 38 | 8% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Dwarfen Mountain Holds | 0.4 | 2 | 0 | 50% | 50% | 0% | 3.0 | 469 | 162 | 50% | 31 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 35 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 214 | 209 | 100% | 24 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 158 |
| Ogre Kingdoms | 0.7 | 2 | 0 | 0% | 0% | 0% | - | 248 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 1.8 | 11 | 1 | 10% | 60% | 0% | 2.7 | 355 | 189 | 50% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 112 |
| Warriors of Chaos | 0.2 | 2 | 1 | 100% | 100% | 0% | 2.0 | 268 | 220 | 100% | 73 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 906 | 0 | 0% | 3 |

### Battle groups: fw-h2h-opp-e441028-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.4 | 21% | 56% | 14% | 78% | 27% | 9% | 16% | 47% | 0% |
| Mine | REDIRECT COUNTER | 3.1 | 27% | 52% | 0% | - | 13% | 0% | 19% | 68% | 0% |
| Opponent | COUNTER-CHARGE COVER | 8.7 | 24% | 53% | 17% | 31% | 39% | 11% | 11% | 39% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 23% | 77% | 10% | 0% | 11% | 0% | 14% | 68% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h-opp-e441028-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 37 | 67% | 5.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Mine | Chaff | 45 | 52 (45) | 28 | 24 | 65 | 38% | 2.5 | 43 (22) | 31 (14) | 109 (9) | 53 (26) | 50 (19) |
| Mine | Character | 120 | 43 (120) | 43 | 0 | 37 | 18% | 2.4 | 50 (34) | 36 (43) | 55 (32) | 45 (78) | 46 (31) |
| Mine | Clean-up | 19 | 36 (19) | 9 | 27 | 34 | 32% | 3.1 | 55 (10) | 14 (8) | 0 (1) | 36 (7) | 36 (12) |
| Mine | Fast | 1 | 57 (1) | 57 | 0 | 0 | 0% | 6.0 | 57 (1) | - | - | - | 57 (1) |
| Mine | Fast Hammer | 42 | 55 (42) | 39 | 16 | 62 | 24% | 3.1 | 57 (22) | 55 (10) | 46 (10) | 65 (31) | 38 (11) |
| Mine | Fragile | 7 | 50 (7) | 50 | 0 | 47 | 29% | 2.6 | 30 (3) | 108 (3) | 0 (1) | 0 (1) | 65 (6) |
| Mine | Hammer | 56 | 41 (56) | 26 | 15 | 39 | 16% | 2.6 | 38 (23) | 36 (20) | 62 (13) | 49 (36) | 27 (20) |
| Mine | Holder | 31 | 67 (31) | 18 | 49 | 44 | 32% | 2.9 | 32 (10) | 69 (15) | 162 (4) | 79 (20) | 46 (9) |
| Mine | Shooter | 38 | 92 (38) | 44 | 48 | 39 | 5% | 2.0 | 124 (15) | 133 (12) | 7 (11) | 91 (31) | 96 (7) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 100 | 75% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 48 (56) | 48 | 0 | 49 | 4% | 1.3 | 18 (22) | 19 (17) | 113 (17) | 29 (18) | 59 (38) |
| Mine | Wizard | 26 | 5 (26) | 5 | 0 | 34 | 12% | 2.1 | 8 (9) | 4 (5) | 0 (4) | 2 (11) | 13 (7) |
| Opponent | Blocker | 1 | 94 (1) | 94 | 0 | 0 | 0% | 6.0 | - | 94 (1) | - | 94 (1) | - |
| Opponent | Chaff | 68 | 73 (68) | 31 | 42 | 34 | 44% | 2.9 | 101 (28) | 32 (25) | 76 (15) | 60 (44) | 95 (24) |
| Opponent | Character | 114 | 50 (114) | 50 | 0 | 34 | 25% | 2.4 | 56 (51) | 49 (41) | 43 (19) | 52 (71) | 47 (40) |
| Opponent | Clean-up | 21 | 61 (21) | 41 | 20 | 46 | 33% | 2.6 | 102 (8) | 31 (11) | 0 (2) | 28 (14) | 99 (7) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 52 (54) | 35 | 17 | 39 | 33% | 3.0 | 54 (23) | 54 (22) | 42 (9) | 57 (42) | 40 (12) |
| Opponent | Fragile | 9 | 17 (9) | 17 | 0 | 61 | 22% | 1.9 | 44 (4) | 0 (2) | 0 (3) | 33 (5) | 0 (4) |
| Opponent | Hammer | 59 | 41 (59) | 37 | 4 | 46 | 17% | 3.0 | 40 (23) | 28 (25) | 67 (11) | 47 (35) | 32 (24) |
| Opponent | Holder | 40 | 45 (40) | 9 | 36 | 42 | 32% | 3.9 | 21 (7) | 65 (18) | 34 (15) | 53 (23) | 30 (17) |
| Opponent | Shooter | 33 | 50 (33) | 20 | 30 | 54 | 3% | 1.8 | 84 (13) | 35 (11) | 24 (9) | 58 (15) | 43 (18) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 0% | 6.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 18 (13) | 18 | 0 | 48 | 8% | 1.7 | 23 (6) | 0 (3) | 23 (4) | 22 (6) | 15 (7) |
| Opponent | Wizard | 23 | 2 (23) | 2 | 0 | 51 | 13% | 2.0 | 0 (10) | 4 (10) | 0 (3) | 2 (14) | 0 (9) |

### Charged fights: fw-h2h-opp-e441028-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 311 | 114 | 1.8 | 1.3 | 64 | 0 | +64 | 5 of 9 | 9 of 9 | +0 | +82 |
| Mine | Chaos Dwarfs | 3 | 22 | 944 | 4.0 | 1.1 | 236 | 26 | +210 | 8 of 12 | 7 of 12 | +388 | +194 |
| Mine | Dwarfen Mountain Holds | 4 | 642 | 69 | 1.5 | 1.2 | 46 | 48 | -2 | 3 of 6 | 1 of 6 | +0 | -2 |
| Mine | Empire of Man | 5 | 247 | 223 | 2.6 | 1.2 | 86 | 29 | +57 | 3 of 13 | 8 of 13 | +114 | +39 |
| Mine | Grand Cathay | 4 | 256 | 577 | 4.5 | 1.1 | 128 | 12 | +116 | 7 of 18 | 15 of 18 | +144 | +113 |
| Mine | High Elf Realms | 4 | 506 | 288 | 3.2 | 1.2 | 89 | 49 | +40 | 6 of 13 | 8 of 13 | +222 | +7 |
| Mine | Kingdom of Bretonnia | 1 | 45 | 822 | 5.0 | 1.6 | 164 | 0 | +164 | 2 of 5 | 4 of 5 | +225 | +74 |
| Mine | Lizardmen | 1 | 0 | 411 | 6.0 | 1.2 | 68 | 98 | -30 | 2 of 6 | 3 of 6 | +90 | -54 |
| Mine | Ogre Kingdoms | 1 | 70 | 126 | 4.0 | 1.0 | 32 | 88 | -56 | 2 of 4 | 3 of 4 | - | -56 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 120 | 4.0 | 1.0 | 30 | 28 | +2 | 2 of 4 | 3 of 4 | - | +2 |
| Mine | Skaven | 2 | 198 | 60 | 1.5 | 1.0 | 40 | 70 | -30 | 1 of 3 | 2 of 3 | - | -30 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 526 | 4.5 | 1.2 | 117 | 51 | +66 | 2 of 9 | 5 of 9 | +52 | +70 |
| Mine | Vampire Counts | 2 | 0 | 360 | 3.5 | 1.1 | 103 | 134 | -31 | 3 of 7 | 2 of 7 | -313 | +16 |
| Mine | Warriors of Chaos | 1 | 0 | 91 | 2.0 | 1.0 | 46 | 0 | +46 | 1 of 2 | 1 of 2 | - | +46 |
| **Mine** | all armies | 36 | 250 | 325 | 3.1 | 1.2 | 106 | 40 | +65 | 47 of 111 | 71 of 111 | +112 | +56 |
| Opponent | Beastmen Brayherds | 1 | 0 | 372 | 3.0 | 1.7 | 124 | 0 | +124 | 2 of 3 | 2 of 3 | +186 | +0 |
| Opponent | Dwarfen Mountain Holds | 1 | 112 | 0 | 1.0 | 2.0 | 0 | 65 | -65 | 0 of 1 | 0 of 1 | -65 | - |
| Opponent | Empire of Man | 1 | 95 | 239 | 1.0 | 1.0 | 239 | 0 | +239 | 1 of 1 | 1 of 1 | - | +239 |
| Opponent | Grand Cathay | 1 | 430 | 514 | 4.0 | 1.5 | 128 | 0 | +128 | 2 of 4 | 4 of 4 | +314 | +67 |
| Opponent | High Elf Realms | 2 | 62 | 174 | 3.0 | 1.2 | 58 | 83 | -25 | 3 of 6 | 3 of 6 | +245 | -79 |
| Opponent | Lizardmen | 1 | 122 | 852 | 2.0 | 1.0 | 426 | 0 | +426 | 1 of 2 | 2 of 2 | - | +426 |
| Opponent | Ogre Kingdoms | 2 | 154 | 160 | 4.0 | 1.1 | 40 | 40 | +0 | 2 of 8 | 2 of 8 | +170 | -24 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 1178 | 4.5 | 1.0 | 262 | 6 | +256 | 3 of 9 | 7 of 9 | - | +256 |
| Opponent | Skaven | 2 | 412 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 638 | 3.5 | 1.3 | 182 | 14 | +168 | 8 of 14 | 12 of 14 | +298 | +116 |
| Opponent | Vampire Counts | 6 | 80 | 391 | 2.8 | 1.4 | 138 | 41 | +97 | 6 of 17 | 12 of 17 | +166 | +68 |
| Opponent | Warriors of Chaos | 7 | 0 | 327 | 2.4 | 1.3 | 135 | 15 | +120 | 5 of 17 | 14 of 17 | +66 | +136 |
| Opponent | Wood Elf Realms | 6 | 56 | 486 | 3.8 | 1.2 | 127 | 43 | +83 | 9 of 23 | 13 of 23 | +56 | +89 |
| **Opponent** | all armies | 36 | 79 | 420 | 3.0 | 1.3 | 141 | 29 | +112 | 43 of 107 | 73 of 107 | +154 | +101 |

### Effective charges: fw-h2h-opp-e441028-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 0 | 0 | 3 (net +0) | 0 | 5 (net +114) | 1 | 0% (0 of 8) |
| Mine | Chaos Dwarfs | 12 | 1 (net +388) | 0 | 1 (net +185) | 5 (net +62) | 0 | 3 (net +546) | 2 | 10% (1 of 10) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net +30) | 0 | 1 (net +111) | 0 | 0 | 3 (net -61) | 0 | 17% (1 of 6) |
| Mine | Empire of Man | 13 | 1 (net -189) | 0 | 2 (net -94) | 2 (net +118) | 2 (net +42) | 6 (net +132) | 0 | 15% (2 of 13) |
| Mine | Grand Cathay | 18 | 1 (net +112) | 0 | 4 (net +56) | 5 (net +84) | 1 (net +350) | 6 (net +144) | 1 | 24% (4 of 17) |
| Mine | High Elf Realms | 13 | 1 (net -247) | 0 | 1 (net +190) | 4 (net +36) | 2 (net +222) | 3 (net -4) | 2 | 9% (1 of 11) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +421) | 1 (net +0) | 1 (net +0) | 2 (net +200) | 0 | 20% (1 of 5) |
| Mine | Lizardmen | 6 | 0 | 0 | 0 | 2 (net +5) | 2 (net +78) | 1 (net +60) | 1 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 0 | 2 (net +30) | 1 (net -162) | 1 | 0% (0 of 3) |
| Mine | Skaven | 3 | 0 | 0 | 1 (net -210) | 0 | 0 | 2 (net +60) | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 9 | 0 | 0 | 0 | 3 (net +77) | 2 (net +172) | 3 (net -39) | 1 | 0% (0 of 8) |
| Mine | Vampire Counts | 7 | 4 (net +55) | 1 (net -580) | 0 | 0 | 0 | 2 (net +72) | 0 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 2 | 1 (net +0) | 0 | 0 | 1 (net +91) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Beastmen Brayherds | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +186) | 0 | 33% (1 of 3) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 1 (net -65) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +239) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Grand Cathay | 4 | 1 (net +95) | 0 | 1 (net +105) | 1 (net +314) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 6 | 0 | 0 | 0 | 1 (net -151) | 2 (net +174) | 2 (net -174) | 1 | 0% (0 of 5) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +439) | 1 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 8 | 0 | 0 | 1 (net +65) | 2 (net +0) | 0 | 2 (net -29) | 3 | 20% (1 of 5) |
| Opponent | Orc & Goblin Tribes | 9 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 8 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 14 | 1 (net -70) | 1 (net +0) | 2 (net +216) | 1 (net +0) | 1 (net +420) | 7 (net +210) | 1 | 15% (2 of 13) |
| Opponent | Vampire Counts | 17 | 1 (net +52) | 0 | 3 (net -76) | 2 (net -5) | 2 (net +110) | 6 (net +244) | 3 | 21% (3 of 14) |
| Opponent | Warriors of Chaos | 17 | 1 (net +125) | 0 | 0 | 4 (net +169) | 1 (net +54) | 6 (net +90) | 5 | 0% (0 of 12) |
| Opponent | Wood Elf Realms | 23 | 4 (net +30) | 1 (net +400) | 1 (net +347) | 4 (net +120) | 2 (net +0) | 6 (net +110) | 5 | 6% (1 of 18) |

### Charged fights, damage counted: fw-h2h-opp-e441028-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 211 | 259 | +31 | 136 | 87 | +50 | +23.5 |
| Mine | 50-54% | 1 | 480 | 201 | -580 | 157 | 580 | -423 | -88.2 |
| Mine | Effective (55-75%) | 11 | 296 | 278 | +66 | 133 | 67 | +66 | +22.4 |
| Mine | 76-89% | 26 | 291 | 174 | +56 | 112 | 46 | +66 | +22.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 265 | 181 | +111 | 160 | 41 | +119 | +45.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 456 | 99 | +120 | 135 | 15 | +121 | +26.4 |
| Mine | No odds | 13 | 274 | 211 | -20 | 54 | 87 | -33 | -12.1 |
| Mine | All fights | 111 | 292 | 192 | +65 | 128 | 57 | +72 | +24.6 |
| Opponent | Long shot (under 50%) | 8 | 264 | 262 | +40 | 199 | 140 | +60 | +22.6 |
| Opponent | 50-54% | 2 | 98 | 292 | +200 | 200 | 0 | +200 | +204.1 |
| Opponent | Effective (55-75%) | 11 | 252 | 185 | +81 | 121 | 51 | +70 | +27.9 |
| Opponent | 76-89% | 15 | 261 | 149 | +87 | 144 | 31 | +113 | +43.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 | 308 | 211 | +126 | 178 | 37 | +141 | +45.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 464 | 84 | +130 | 152 | 33 | +119 | +25.8 |
| Opponent | No odds | 27 | 228 | 211 | +130 | 177 | 46 | +131 | +57.5 |
| Opponent | All fights | 107 | 280 | 195 | +112 | 167 | 47 | +121 | +43.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h-opp-e441028-p1 | move | 521 | 112 (21%) | 75 (14%) | 56 (11%) | 353 (68%) |
| fw-h2h-opp-e441028-p1 | objective | 446 | 64 (14%) | 45 (10%) | 53 (12%) | 329 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: fw-h2h-mine-e441028-p3

### Scorecard: fw-h2h-mine-e441028-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 0 | 0 | 1 | 0 | 0 | 130 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 7 | 1 | 2 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 7 | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 3 | - | 0 | 4 | 1 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 6 | 1 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 7 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 5 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 2 | 4 | 2 | 0 | 0 | 0 | 0 | 480 |
| L0327 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 6 | 2 | 1 | 0 | 0 | 0 | 302 |
| L0429 | 3 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 4 | 3 | 4 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 588 |
| L0516 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 1 | 0 | 0 | 340 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | no | - | 3 | 2 | 7 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 0 | 0 | 0 | 275 |
| L0709 | 1 | 1 | Mine | yes | 8 | 2 | 3 | 2 | 0 | 0 | 0 | 375 |
| L0709 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 540 |
| L0725 | 5 | 1 | Mine | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 755 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 3 | 1 | 0 | 0 | 0 | 780 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 515 |
| L0831 | 3 | 1 | Opponent | no | 3 | 2 | 1 | 0 | 2 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | no | - | 4 | 1 | 2 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 4 | 1 | 3 | 2 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 1 | 4 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 285 |
| L1122 | 6 | 1 | Mine | no | 1 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 369 |
| L1216 | 4 | 1 | Mine | no | 0 | 3 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | yes | 7 | 3 | 4 | 3 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Mine | no | 11 | 3 | 3 | 1 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 5 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 1 | 1 | 6 | 1 | 0 | 0 | 0 | 55 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 126 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 4 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | yes | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 3 | 0 | 0 | 0 | 236 |
| L1731 | 3 | 1 | Mine | yes | 0 | 4 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 1 | 1 | 3 | 0 | 2 | 0 | 0 | 170 |
| L1831 | 1 | 1 | Mine | no | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 6 | 5 | 2 | 0 | 1 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 3 | 3 | 1 | 2 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2033 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2223 | 3 | 1 | Mine | no | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 2 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 1 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2433 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2630 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 5 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 6 | 4 | 0 | 0 | 0 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 937 |
| **Average** | | | Mine | 23% | 2.3 | 2.8 | 2.4 | 0.9 | 0.3 | 0.0 | 0.0 | 255.5 |
| **Average** | | | Opponent | 23% | 2.5 | 2.4 | 2.9 | 1.9 | 0.6 | 0.0 | 0.0 | 172.3 |

### KPIs: fw-h2h-mine-e441028-p3

Rules off - Opponent only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 56% (88 of 158) | 0% (0 of 168) | 27% (88 of 326) |
| Winner chose to follow up after the loser gave ground |  | 93% (50 of 54); on the table 94% | 100% (38 of 38); on the table 100% | 96% (88 of 92); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (5 of 6); on the table 83% | 91% (10 of 11); on the table 91% | 88% (15 of 17); on the table 88% |
| Winner chose to pursue after the loser fled |  | 46% (11 of 24); on the table 62% | 73% (19 of 26); on the table 81% | 60% (30 of 50); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 79% (66 of 84); on the table 85% | 89% (67 of 75); on the table 92% | 84% (133 of 159); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 34% (112 of 330) | 33% (63 of 192) | 34% (175 of 522) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (112 of 228) | 49% (57 of 117) | 49% (169 of 345) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 37% (7 of 19) | - | 37% (7 of 19) |
| Points that never fought | lower | 38% (24435 of 64804) | 39% (26371 of 67990) | 38% (50806 of 132794) |
|   infantry points that never fought | lower | 36% (4659 of 12898) | 57% (7286 of 12884) | 46% (11945 of 25782) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (144 of 258) | 58% (155 of 265) | 57% (299 of 523) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.9 uses a game | 75% (18 of 24); 1.7 uses a game | 82% (40 of 49); 1.8 uses a game |
| Bound items with another spell used |  | 57% (8 of 14); 0.4 uses a game | 50% (3 of 6); 0.2 uses a game | 55% (11 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (4 of 14); 0.1 uses a game | 44% (15 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (28672 of 55927) | 51% (30890 of 60119) | 51% (59562 of 116046) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (18%) | 0.6 (16%) | 1.6 (17%) |
| MARCHED: its unit marched | 1.8 (30%) | 0.8 (22%) | 2.6 (27%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.3 (8%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.1 (19%) | 0.8 (22%) | 1.9 (20%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.8 (14%) | 1.0 (27%) | 1.8 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.9 (14%) | 0.1 (4%) | 1.0 (10%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.2 | 2.1 | 4.9 | 0.6 | 1.6 |
| not cast | 3.9 | 1.1 | 3.9 | 9.6 | 2.3 | 17.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.8 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.5 (45%) | 0.4 (10%) | 1.6 (17%) | 0.5 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.6 (27%) | 0.6 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (13%) | 0.5 (13%) | 1.9 (20%) | 0.3 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| GONE: slain | 1.3 (34%) | 0.2 (16%) | 0.3 (9%) | 1.8 (19%) | 0.4 (18%) | 2.3 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (15%) | 0.2 (21%) | 0.6 (16%) | 1.0 (10%) | 0.0 (0%) | 0.9 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (5%) | 0.0 (0%) | 0.1 (1%) | 0.5 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (44%) | 0.0 (0%) | 2.0 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.6 a game | 1.1 a game |
| stood (cast and not dispelled) | 64% (32 of 50) | 53% (9 of 17) | 61% (41 of 67) |
| the unit moved after it | 62% (20 of 32) | 78% (7 of 9) | 66% (27 of 41) |
| it charged on its next turn | 0% (0 of 32) | 0% (0 of 9) | 0% (0 of 41) |
| the enemy charged it first | 16% (5 of 32) | 11% (1 of 9) | 15% (6 of 41) |
| it fought by the end of its next turn | 6% (2 of 32) | 0% (0 of 9) | 5% (2 of 41) |
| it moved out of a charge the enemy had planned (not charged first) | 28% (9 of 32) | 11% (1 of 9) | 24% (10 of 41) |
| none of these (no charge, no fight, no charge escaped) | 56% (18 of 32) | 78% (7 of 9) | 61% (25 of 41) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (444 of 763) | 54% (319 of 595) | 56% (763 of 1358) |
|   cavalry | 60% (42 of 70) | 51% (55 of 108) | 54% (97 of 178) |
|   character | 47% (54 of 114) | 22% (25 of 112) | 35% (79 of 226) |
|   chariot | 44% (42 of 96) | 62% (24 of 39) | 49% (66 of 135) |
|   infantry | 43% (84 of 194) | 58% (144 of 248) | 52% (228 of 442) |
|   monster | 42% (15 of 36) | 0% (0 of 4) | 38% (15 of 40) |
|   war machine | 82% (207 of 253) | 85% (71 of 84) | 82% (278 of 337) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (34%) | 2.1 (28%) | 5.1 (31%) |
| CHARGED: it charged | 1.0 (12%) | 1.7 (22%) | 2.8 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.5 (7%) | 1.2 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.5 (17%) | 1.1 (14%) | 2.6 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.5 (7%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (15%) | 1.1 (14%) | 2.5 (15%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR | 0.4 (4%) | 0.3 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.4 | 0.9 | 83% | 5.4 pts | 24 pts |
| character | 2.6 | 1.2 | 71% | 9.9 pts | 25 pts |
| chariot | 1.8 | 0.8 | 68% | 11.3 pts | 21 pts |
| infantry | 9.4 | 3.1 | 74% | 8.9 pts | 83 pts |
| monster | 0.5 | 0.1 | 94% | 0.8 pts | 0 pts |
| war machine | 7.9 | 5.2 | 69% | 25.6 pts | 202 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.4 | 5.8 | 4.6 |
| Charges that made contact a game | 2.6 | 3.9 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.56 contact (27 units) | 0.88 declared, 0.59 contact (17 units) | 0.75 declared, 0.57 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.80 declared, 0.40 contact (5 units) | 0.62 declared, 0.38 contact (13 units) | 0.67 declared, 0.39 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.33 contact (232 units) | 0.65 declared, 0.43 contact (289 units) | 0.55 declared, 0.39 contact (521 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (36 of 72) | 57% (8 of 14) | 60% (6 of 10) | 52% (50 of 96) |
| Character in a unit | 81% (21 of 26) | 67% (6 of 9) | 50% (2 of 4) | 74% (29 of 39) |
| Character on its own | 82% (37 of 45) | 45% (20 of 44) | 34% (23 of 67) | 51% (80 of 156) |
| Chariot | 45% (5 of 11) | 58% (7 of 12) | - | 52% (12 of 23) |
| Infantry | 72% (48 of 67) | 44% (15 of 34) | 40% (2 of 5) | 61% (65 of 106) |
| Monster | 53% (18 of 34) | 60% (3 of 5) | - | 54% (21 of 39) |
| Monstrous | 100% (8 of 8) | 55% (6 of 11) | - | 74% (14 of 19) |
| War Machines | 63% (27 of 43) | 50% (1 of 2) | - | 62% (28 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 73% (8 of 11); on the table 73% | 31% (30 of 96) | 49% | 59% (13 of 22) | 83% (5 of 6); 4.2 uses a game | 50% (1 of 2); 1.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 90% (9 of 10); on the table 90% | 33% (12 of 36) | 48% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 60% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 50% (9 of 18); on the table 72% | 33% (10 of 30) | 43% | 64% (38 of 59) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 87% (13 of 15); on the table 87% | 31% (59 of 192) | 50% | 51% (38 of 74) | 89% (16 of 18); 6.1 uses a game | 50% (2 of 4); 0.5 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 94% (15 of 16); on the table 100% | 33% (14 of 42) | 40% | 54% (29 of 54) | 100% (9 of 9); 4.1 uses a game | 58% (7 of 12); 1.6 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (6 of 6); on the table 100% | - | 45% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (7 of 7); on the table 100% | 33% (2 of 6) | 14% | 0% (0 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 50% (3 of 6); on the table 50% | 67% (4 of 6) | 11% | 43% (3 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (3 of 3); on the table 100% | 25% (3 of 12) | 45% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 100% (6 of 6) | 16% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 85% (11 of 13); on the table 85% | 17% (1 of 6) | 19% | 38% (10 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 7 | 96% (22 of 23); on the table 96% | 35% (17 of 48) | 22% | 46% (18 of 39) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 83% (20 of 24); on the table 92% | 43% (13 of 30) | 31% | 56% (54 of 96) | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 4 | 100% (2 of 2); on the table 100% | 33% (4 of 12) | 54% | 86% (36 of 42) | 86% (6 of 7); 5.2 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h-mine-e441028-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (41) | 35% (22) | 43% (63) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.47 | 1.22 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.08 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.58 | 0.42 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.78 | 1.19 | 2.97 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.17 | 0.94 | 2.11 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.44 | 7.42 | 14.86 |

### Quality by phase: fw-h2h-mine-e441028-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 0.0 |
| Strategy | Charge objectives carried out (made contact) | 58% (58 of 100) | 43% (76 of 175) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (121 of 267) | 51% (82 of 161) |
| Strategy | Close-in objectives charged next turn | 11% (19 of 166) | 11% (22 of 207) |
| Strategy | Support requests answered (helper made contact too) | 80% (4 of 5) | 45% (9 of 20) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 20% (2 of 10) | 55% (6 of 11) |
| Strategy | Joined characters whose unit fought | 33% (12 of 36) | 45% (10 of 22) |
| Strategy | Lone characters that fought | 67% (62 of 92) | 69% (72 of 104) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 0.9 | 1.9 |
| Movement | Points that never moved of their own | 255.5 | 172.3 |
| Movement | Fights charged into per game | 2.5 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 69, net +0 | 11 of 102, net +65 |
| Movement | Charges with odds: sweet spot (55-75%) | 7 of 69, net +70 | 16 of 102, net +92 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 69, net +77 | 12 of 102, net +80 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 of 69, net +107 | 44 of 102, net +109 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.2 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (122 of 261) | 44% (131 of 300) |
| Shooting | Points destroyed by shooting units | 67.5 | 42.2 |
| Shooting | War machine shots | 5.8 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (108 of 207) | 41% (31 of 76) |
| Shooting | Points destroyed by war machines | 58.0 | 38.2 |
| Magic | Magic missiles cast | 1.9 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (22 of 68) | 25% (9 of 36) |
| Magic | Wounds caused by magic missiles | 2.9 | 1.0 |
| Magic | Wounds caused by other spells | 1.6 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 74.4 | 28.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.3 / 0.8 / 0.1 | 1.6 / 0.3 / 0.2 / 0.3 |
| Combat | Points destroyed in combat | 261.6 | 341.7 |
| Combat | Points run down | 79.2 | 107.0 |
| Combat | Net points per charged fight, damage counted | +73 | +92 |
| Combat | Net per 100 charger points, damage counted | +26.4 | +31.3 |
| Combat | First round won (charged fights) | 79% | 62% |
| Combat | Net points per charged fight | +60 | +91 |
| Combat | Net points per supported fight / lone fight | +100 / +54 | +232 / +72 |
| Combat | Charged fights on a top-3 enemy unit | 25 of 85 | 56 of 120 |
| Game | Points lost | 773.7 | 645.3 |
| Game | VP from objectives | 481.8 | 533.2 |
| Game | Lone holders (player turns) | 2.3 | 2.5 |

- Mine won / drew / lost: 9 / 10 / 15 of 34 ended games (of 36); mean margin (Mine - Opponent) -208 VP
- The side that went first won 11 of 24 games with a winner
- Points traded per game (both sides' losses): 1419
- Games not ended: 2 (L2033-1, L2433-1); findings 8, warnings 0

### Opponent rules: fw-h2h-mine-e441028-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.6 | +0.0 | 0.0 | 2.6 | 0.1 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 1.4 | +10.4 | 0.0 | 20.6 | 1.2 | +14.0 | 0.0 | 10.8 |
| BEST FACING | 0.8 | +18.2 | 0.0 | 17.1 | - | - | - | - |
| BEST FIRST | 3.6 | +160.6 | 173.0 | 47.2 | - | - | - | - |
| BEST OVERALL | 0.6 | +40.4 | 0.0 | 35.4 | 0.5 | +34.6 | 0.0 | 13.1 |
| BEST PREY | 0.7 | +36.7 | 37.9 | 0.0 | 5.2 | +310.7 | 287.9 | 123.3 |
| BEST PRIZE | 0.0 | -0.8 | 2.2 | 0.0 | 0.0 | -0.2 | 0.0 | 5.2 |
| BIG CHARACTER SAFETY | 0.3 | -0.0 | 0.0 | 0.0 | 0.3 | -0.8 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.9 | 0.0 | 0.1 | +0.0 | 8.4 | 0.0 |
| BLOCKED WHEEL | 0.3 | +6.2 | 0.0 | 0.0 | 0.4 | +2.8 | 0.0 | 12.6 |
| BOMBING RUN | - | - | - | - | 0.0 | +0.5 | 0.0 | 4.2 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 54.8 | 8.2 | 0.2 | +0.0 | 5.6 | 0.0 |
| CANNON PLANNED TARGET | 4.2 | +129.8 | 246.0 | 79.0 | 1.5 | +88.0 | 96.3 | 31.1 |
| CARRIES OUT COUNTER | 0.1 | -1.5 | 0.0 | 11.3 | 0.0 | +0.0 | 13.9 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 11.9 | 0.0 | 0.1 | -2.5 | 20.6 | 0.0 |
| CAST JOB | 0.3 | +10.8 | 12.5 | 0.0 | 0.4 | +9.0 | 9.4 | 16.3 |
| CASTING BLOCK | 0.1 | +13.6 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 29.7 | 0.3 | +0.0 | 0.0 | 11.1 |
| CATCH FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.4 | -0.6 | 10.8 | 10.3 | 0.1 | -0.3 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.5 | -43.0 | 43.2 | 11.5 | 0.5 | -42.7 | 19.4 | 20.9 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.8 | 2.4 | 0.2 | +0.0 | 0.0 | 3.2 |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.7 | 7.1 | 0.0 | 0.2 | -0.9 | 12.1 | 11.1 |
| COMBAT PIVOT | 0.5 | +0.0 | 15.8 | 3.1 | 0.3 | +0.0 | 31.3 | 2.1 |
| CONVEYANCE SEARCH | 1.1 | +136.7 | 60.2 | 52.8 | 0.4 | +31.8 | 11.7 | 11.1 |
| COUNTER-CHARGE COVER | 9.3 | +841.7 | 0.0 | 190.7 | 6.8 | +618.7 | 0.0 | 169.2 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 12.3 | 3.3 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.8 | 9.1 | 0.0 | 0.0 | +0.0 | 2.9 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +140.0 | 0.0 | 68.9 | 1.2 | +83.7 | 0.0 | 22.3 |
| FALLBACK BY WORTH | 3.8 | +53.1 | 0.0 | 67.7 | 7.7 | +121.6 | 0.0 | 49.1 |
| FIGHT LIFT | 0.1 | +1.5 | 1.7 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 187.3 | 6.8 | +0.0 | 0.0 | 133.9 |
| FOLLOW UP WEIGHED | 1.1 | +136.5 | 0.0 | 59.7 | 0.9 | +113.8 | 0.0 | 30.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +7.4 | 0.0 | 0.0 | 0.1 | +9.5 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -29.2 | 72.1 | 34.5 | 1.9 | -60.1 | 262.0 | 52.8 |
| GIVES UP ITS SCREEN | 0.0 | -0.3 | 0.0 | 1.5 | 0.8 | -18.2 | 44.4 | 9.0 |
| GROUND FLIERS | 0.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 8.1 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 17.2 | 4.8 | 0.3 | +0.0 | 20.4 | 1.1 |
| HILL BY ITS CHANCE | 0.1 | -10.8 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.4 | +10.2 | 14.6 | 8.2 | 0.3 | +24.4 | 21.0 | 11.5 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 2.6 | 2.9 |
| HUNT IN PAIRS | 0.6 | +18.4 | 0.0 | 10.5 | 0.5 | +42.5 | 0.0 | 10.2 |
| HUNT KEPT | 0.2 | +5.8 | 4.6 | 5.9 | 0.1 | +9.0 | 7.1 | 0.0 |
| HUNT RESULT | 0.2 | +16.4 | 10.0 | 2.4 | 0.3 | +43.5 | 20.0 | 11.5 |
| HUNT THE GUNS | 0.2 | +91.1 | 10.0 | 3.8 | 0.3 | +160.2 | 25.6 | 14.7 |
| INVITES THE FIGHT | 3.4 | +216.3 | 144.1 | 97.9 | - | - | - | - |
| JOINT CHARGE PLAN | 0.0 | +0.4 | 0.0 | 0.0 | 0.2 | +4.8 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +2.4 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.2 | +1.9 | 3.1 | 0.0 |
| KEEPS ITS TARGET | 1.9 | +55.8 | 146.6 | 35.9 | 2.2 | +65.0 | 207.2 | 27.8 |
| KILLS COUNT | 1.4 | +73.2 | 81.1 | 60.6 | 2.4 | +124.5 | 242.8 | 44.2 |
| KILLS COUNT NEXT TURN | 5.3 | +134.7 | 239.6 | 79.9 | 11.9 | +406.6 | 554.0 | 235.2 |
| LONE CHARACTER SAFE SPOT | 0.7 | +43.4 | 28.1 | 41.1 | 0.5 | +27.9 | 21.6 | 22.7 |
| LONE WIZARD HOLDS BACK | 0.9 | +0.0 | 23.0 | 16.7 | 0.9 | +0.0 | 23.8 | 26.7 |
| LONG SHOT | 0.4 | +5.4 | 18.0 | 8.8 | - | - | - | - |
| LOST CHARGE | 2.8 | -51.9 | 160.2 | 91.5 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.0 | -4.4 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.6 | +21.3 | 71.7 | 10.2 | 0.6 | +26.4 | 36.2 | 0.0 |
| MANOEUVRE | 0.2 | +5.3 | 0.0 | 1.4 | 0.1 | +6.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.1 | 0.0 | 9.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.9 | +59.4 | 0.0 | 34.7 | 0.8 | +33.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +6.8 | 3.8 | 23.6 | 0.7 | +55.4 | 10.4 | 10.2 |
| MARCH OVER CASTS | 1.1 | +80.3 | 0.0 | 18.6 | 0.4 | +4.7 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 5.2 | +224.1 | 0.0 | 81.8 | 4.2 | +210.8 | 0.0 | 121.7 |
| MISSILES IN THE MOVE | 4.2 | +136.9 | 0.0 | 98.5 | 3.3 | +55.7 | 0.0 | 71.8 |
| MISSILES NEXT TURN | 5.7 | +101.3 | 0.0 | 131.8 | 4.1 | +57.8 | 0.0 | 85.2 |
| MODEL FACING | 0.1 | +26.4 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 8.2 | 10.6 | 0.2 | +0.0 | 2.6 | 0.0 |
| MOVE AND CAST | 0.2 | +14.3 | 0.0 | 0.0 | 0.1 | +5.5 | 0.0 | 6.5 |
| MOVE SPELL IN RANGE | 1.0 | +35.8 | 0.0 | 51.4 | 0.2 | +5.1 | 0.0 | 6.5 |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -28.5 | 6.6 | 52.1 | 0.3 | -12.2 | 0.0 | 13.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 16.4 | 0.1 | +0.0 | 0.0 | 8.2 |
| MOVE TO CHARGE | 5.3 | +320.0 | 215.7 | 80.6 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +3.8 | 0.0 | 0.0 | 0.0 | +6.3 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -6.6 | 21.3 | 1.7 | 0.2 | -16.4 | 51.9 | 0.0 |
| NOT TURNED | 7.4 | +173.8 | 0.0 | 158.3 | 7.4 | +121.6 | 0.0 | 131.8 |
| NOT WORTH A CAST | 0.4 | -0.2 | 0.0 | 48.6 | 0.4 | -0.2 | 0.0 | 6.5 |
| OFF BEST | 15.7 | -783.3 | 0.0 | 319.1 | 17.6 | -1052.7 | 55.0 | 301.0 |
| OPENS A LANE | 0.1 | +0.4 | 8.9 | 0.0 | 0.1 | +0.6 | 3.3 | 0.0 |
| OPENS UP | 0.2 | +19.0 | 7.3 | 19.2 | 0.3 | +27.3 | 13.3 | 0.0 |
| OVERRUN THREAT | 0.0 | +2.4 | 0.0 | 11.3 | 0.0 | +1.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +6.2 | 26.4 | 9.0 | 0.5 | +7.4 | 26.4 | 28.9 |
| PATHS CROSS | 2.7 | +179.0 | 0.0 | 59.7 | 2.7 | +202.4 | 0.0 | 24.9 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.0 | 0.0 | 0.0 | 0.1 | -6.1 | 0.0 | 7.9 |
| PLAN RESULT | 36.4 | +980.2 | 1475.2 | 1085.3 | 38.9 | +1422.6 | 1574.9 | 864.4 |
| PURSUES BIG PREY | 0.1 | -3.7 | 0.0 | 7.7 | 0.1 | -12.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +7.4 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.5 | +4.0 | 0.0 | 4.7 | - | - | - | - |
| RANDOM MOVER NO PROMISE | 0.1 | -6.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.7 | 0.0 | 4.7 | - | - | - | - |
| REDIRECT COUNTER | 2.3 | +184.5 | 0.0 | 37.9 | 3.5 | +242.1 | 0.0 | 53.3 |
| REDIRECT WEIGHED | 0.2 | +4.8 | 7.2 | 4.8 | 0.5 | +13.6 | 7.5 | 5.4 |
| RESERVE FALL BACK | 0.7 | +14.5 | 0.0 | 10.2 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.2 | +4.7 | 0.0 | 11.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +84.3 | 98.7 | 53.1 | 2.5 | +51.7 | 296.8 | 69.9 |
| SAFER THAN THE JOB | 1.2 | +68.0 | 0.0 | 61.8 | 0.9 | +62.4 | 0.0 | 20.4 |
| SCREEN BY WHAT IT SAVES | 0.0 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 3.2 | +168.2 | 0.0 | 80.2 | 1.9 | +121.5 | 0.0 | 11.4 |
| SECOND HUNTER | 0.0 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.5 | +49.1 | 0.0 | 21.9 | 0.2 | +64.1 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.9 | +57.1 | 77.0 | 20.8 | 1.2 | +57.1 | 52.6 | 9.7 |
| SET-UP ANY TARGET | 0.4 | +57.5 | 25.2 | 22.5 | 0.1 | +18.7 | 8.2 | 11.1 |
| SET-UP MISSED | 0.1 | +13.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.6 | +26.0 | 59.9 | 13.6 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 55.7 | 0.0 | 0.1 | +0.0 | 16.1 | 0.0 |
| SHOTS IN THE MOVE | 11.5 | +430.6 | 0.0 | 217.0 | 8.4 | +325.5 | 0.0 | 138.8 |
| SPELL CATCH ODDS | 0.2 | -5.8 | 6.6 | 10.6 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +96.1 | 58.4 | 33.0 | 0.1 | +32.6 | 8.2 | 11.1 |
| SPELL WORTH | 1.1 | +26.8 | 54.7 | 64.4 | 2.0 | +31.5 | 60.1 | 49.7 |
| STABLE ROLE | 12.3 | +0.0 | 507.1 | 219.1 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.1 | +2.6 | 4.9 | 0.0 |
| STOPS | 0.0 | +2.0 | 0.0 | 1.5 | 0.1 | +9.6 | 11.7 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.5 | +18.2 | 0.0 | 0.0 | 0.4 | +18.0 | 0.0 | 5.7 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 7.1 | 0.0 | - | - | - | - |
| SUPPORTS | 7.0 | +287.8 | 252.2 | 131.5 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.7 | 3.8 | 0.0 | 0.2 | -7.0 | 19.1 | 0.0 |
| SURE REACH TOGETHER | 0.2 | -1.3 | 0.0 | 0.0 | 0.7 | -2.8 | 10.3 | 10.1 |
| THROUGH LINE OF FIRE | 0.3 | +10.6 | 0.0 | 2.7 | 0.2 | +22.6 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -22.1 | 30.1 | 7.9 | 0.5 | -34.7 | 42.9 | 4.5 |
| TWO OR MORE ARRIVE | 0.2 | +0.7 | 0.0 | 0.0 | 0.4 | +2.1 | 5.3 | 3.2 |
| WALKS TO THE FIGHT | 2.2 | +113.4 | 50.8 | 53.9 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 57.4 | 19.4 | - | - | - | - |
| WEARS DOWN | 0.6 | +17.5 | 47.5 | 5.5 | 1.0 | +36.0 | 155.1 | 50.1 |
| WHO HITS BACK | 0.3 | +29.3 | 0.0 | 3.1 | 0.1 | +8.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | -7.1 | 17.5 | 0.0 | 0.5 | +10.8 | 84.8 | 1.2 |
| WHOLE FIGHT GAIN | 0.1 | +12.2 | 17.2 | 3.3 | 0.5 | +44.3 | 48.4 | 7.4 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 1.8 | 0.0 | - | - | - | - |

### Rule changes: fw-h2h-mine-e441028-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1200 | 1200 | 1200 | 33.33 | -66094 | -55.1 |
| PATHS CROSS | 195 | 195 | 195 | 5.42 | +13732 | +70.4 |
| SEARCH SPOT | 185 | 185 | 184 | 5.11 | +10431 | +56.7 |
| KILLS COUNT NEXT TURN | 617 | 612 | 167 | 4.64 | +4796 | +28.7 |
| SUPPORTS | 251 | 251 | 156 | 4.33 | +3988 | +25.6 |
| COUNTER-CHARGE COVER | 578 | 302 | 155 | 4.31 | +9237 | +59.6 |
| BEST FIRST | 131 | 131 | 131 | 3.64 | +5783 | +44.1 |
| FACES THE THREAT | 107 | 107 | 107 | 2.97 | +8052 | +75.3 |
| BEST PREY | 211 | 206 | 98 | 2.72 | +3603 | +36.8 |
| MOVE TO CHARGE | 190 | 190 | 95 | 2.64 | +4392 | +46.2 |
| FALLBACK BY WORTH | 416 | 416 | 88 | 2.44 | +6289 | +71.5 |
| SAFER THAN THE JOB | 76 | 76 | 76 | 2.11 | +4692 | +61.7 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +9008 | +126.9 |
| INVITES THE FIGHT | 121 | 121 | 61 | 1.69 | +2688 | +44.1 |
| MARCH CHECK | 61 | 58 | 54 | 1.50 | +3101 | +57.4 |
| SHOTS IN THE MOVE | 715 | 436 | 54 | 1.50 | +1482 | +27.4 |
| MAX FOR POSITIONING | 342 | 182 | 52 | 1.44 | +737 | +14.2 |
| WALKS TO THE FIGHT | 78 | 78 | 49 | 1.36 | +1764 | +36.0 |
| KILLS COUNT | 138 | 130 | 40 | 1.11 | +1897 | +47.4 |
| BEST OVERALL | 39 | 39 | 39 | 1.08 | +2698 | +69.2 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| RISK BY ARC | 149 | 143 | 38 | 1.06 | +1404 | +37.0 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +2158 | +61.6 |
| REDIRECT COUNTER | 208 | 102 | 35 | 0.97 | +3198 | +91.4 |
| LONE WIZARD HOLDS BACK | 66 | 66 | 34 | 0.94 | -1878 | -55.2 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +1304 | +38.4 |
| KEEPS ITS TARGET | 145 | 142 | 32 | 0.89 | +514 | +16.1 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| MARCH ODDS | 33 | 33 | 31 | 0.86 | +641 | +20.7 |
| SET UP TOGETHER | 75 | 68 | 30 | 0.83 | +1605 | +53.5 |
| MISSILES IN THE MOVE | 269 | 141 | 29 | 0.81 | +430 | +14.8 |
| BEST FACING | 28 | 28 | 28 | 0.78 | +654 | +23.3 |
| ARTILLERY RE-ROLL WEIGHED | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| RESERVE FALL BACK | 25 | 25 | 25 | 0.69 | +522 | +20.9 |
| BLOCKED WHEEL | 24 | 24 | 24 | 0.67 | +324 | +13.5 |
| CANNON PLANNED TARGET | 206 | 206 | 24 | 0.67 | -135 | -5.6 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +1175 | +51.1 |
| THROUGH LINE OF FIRE | 21 | 21 | 21 | 0.58 | +1198 | +57.1 |
| BIG CHARACTER SAFETY | 20 | 20 | 20 | 0.56 | -28 | -1.4 |
| CHAFF PASSED | 19 | 19 | 19 | 0.53 | -32 | -1.7 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +824 | +48.5 |
| SHOT REPLANNED | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CAST JOB | 26 | 25 | 14 | 0.39 | +155 | +11.1 |
| WHOLE FIGHT GAIN | 24 | 22 | 14 | 0.39 | +725 | +51.8 |
| MANOEUVRE | 13 | 13 | 13 | 0.36 | +414 | +31.8 |
| MOVE AND CAST | 12 | 12 | 12 | 0.33 | +713 | +59.4 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +611 | +55.5 |
| OPENS UP | 20 | 17 | 11 | 0.31 | +538 | +48.9 |
| WAR ENGINE JOBS | 30 | 30 | 11 | 0.31 | -871 | -79.2 |
| WEARS DOWN | 59 | 56 | 11 | 0.31 | +235 | +21.4 |
| BACKUP TARGETS | 94 | 37 | 10 | 0.28 | +44 | +4.4 |
| HUNT IN PAIRS | 39 | 23 | 10 | 0.28 | +595 | +59.5 |
| MAKE SURE TOGETHER | 41 | 33 | 10 | 0.28 | +385 | +38.5 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 10 | 0.28 | +376 | +37.5 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -592 | -65.8 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -327 | -40.8 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -421 | -52.6 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| HUNT ADVANCE | 26 | 26 | 7 | 0.19 | +303 | +43.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| RANDOM MOVE BY FIGURES | 19 | 19 | 7 | 0.19 | +145 | +20.8 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +179 | +25.6 |
| LOST CHARGE | 101 | 101 | 6 | 0.17 | +122 | +20.3 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +223 | +44.6 |
| MISSILES NEXT TURN | 353 | 182 | 4 | 0.11 | +13 | +3.2 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +949 | +237.3 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | +21 | +5.2 |
| SURE REACH TOGETHER | 33 | 27 | 4 | 0.11 | +0 | +0.0 |
| CASTING BLOCK | 3 | 3 | 3 | 0.08 | +141 | +47.1 |
| GIVES UP | 94 | 88 | 3 | 0.08 | +33 | +11.1 |
| MOVE SPELL IN RANGE | 43 | 22 | 3 | 0.08 | +43 | +14.3 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| OVERRUNS AWAY | 32 | 32 | 3 | 0.08 | +23 | +7.6 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +126 | +41.9 |
| STOPS | 4 | 4 | 3 | 0.08 | +314 | +104.7 |
| WHOLE FIGHT | 22 | 20 | 3 | 0.08 | +111 | +36.9 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -36 | -17.9 |
| CARRIES OUT COUNTER | 4 | 4 | 2 | 0.06 | -56 | -27.8 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +45 | +22.4 |
| JOINT CHARGE PLAN | 8 | 8 | 2 | 0.06 | +96 | +48.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +17 | +17.2 |
| CARRIES OUT SET-UP | 6 | 6 | 1 | 0.03 | -90 | -90.3 |
| CHARIOT NO STATIC JOB | 11 | 11 | 1 | 0.03 | -54 | -53.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +8 | +8.2 |
| GIVES UP ITS SCREEN | 29 | 28 | 1 | 0.03 | +13 | +12.7 |
| LONG SHOT | 16 | 15 | 1 | 0.03 | -1 | -0.8 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +80 | +79.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +124 | +124.0 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | -80 | -80.3 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -31 | -31.2 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 39 | 39 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 9 | 9 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 53 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 7 | 7 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 4 | 4 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 496 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 14 | 13 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 10 | trace | - | - | - | - |
| HUNT RESULT | 19 | trace | - | - | - | - |
| HUNT THE GUNS | 20 | trace | - | - | - | - |
| KEEPS ITS PREY | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 43 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 52 | 52 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 20 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 36 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT NEEDED | 15 | 15 | 0 | 0.00 | - | - |
| NOT TURNED | 535 | 535 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 29 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 1 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 2 | not checked | - | - | - | - |
| PLAN RESULT | 2713 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 25 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 19 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL CATCH ODDS | 8 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 27 | not checked | - | - | - | - |
| SPELL WORTH | 112 | not checked | - | - | - | - |
| STABLE ROLE | 442 | 440 | 0 | 0.00 | - | - |
| TURN WORTH | 32 | 30 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 22 | 21 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h-mine-e441028-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.53 | 14.39 | 58.3 |
| FALLBACK | gate | 0.64 | 1.11 | 50.4 |
| TURN GATE | gate | 1.08 | 0.67 | 35.7 |
| RULE SWITCHED OFF | gate | - | 1.06 | 24.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | 0.22 | 47.3 |
| LONE WIZARD HOLDS BACK | rule | 0.36 | 0.08 | 117.4 |
| CHAFF PASSED | rule | 0.22 | 0.08 | 2.9 |
| WAR ENGINE JOBS | rule | 0.31 | - | 79.2 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.14 | 5.6 |
| PATHS CROSS | rule | 0.08 | 0.17 | 30.9 |
| PURSUES BIG PREY | rule | 0.14 | 0.11 | 65.8 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.14 | 40.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.17 | 52.6 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | 0.06 | 2.7 |
| CANNON PLANNED TARGET | rule | 0.08 | 0.06 | 90.8 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 1.9 |
| BLOCKED WHEEL | rule | 0.06 | 0.06 | 11.2 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.06 | 11.2 |
| MARCH ODDS | rule | 0.06 | 0.06 | 14.8 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 8.8 |
| AFTERMATH BAND | gate | 0.03 | 0.03 | 3.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 12.1 |
| BEST PRIZE | rule | 0.03 | 0.03 | 17.9 |
| CARRIES OUT COUNTER | rule | 0.06 | - | 27.8 |
| SUPPORT REQUEST | gate | - | 0.06 | 97.4 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 90.3 |
| CHARIOT NO STATIC JOB | rule | - | 0.03 | 53.8 |
| FACES THE THREAT | rule | - | 0.03 | 13.7 |
| FALLBACK BY WORTH | rule | 0.03 | - | 5.5 |
| LONG SHOT | rule | 0.03 | - | 0.8 |
| STANDS TO CAST | rule | - | 0.03 | 19.0 |
| SUPPORT JOB KEPT | rule | 0.03 | - | 80.3 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 9.8 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 31.2 |

### Plans: fw-h2h-mine-e441028-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.7 | 18% | 712 | 287 | 40% |
| Mine | charge | 1.9 | 59% | 206 | 155 | 75% |
| Mine | close in | 4.6 | 22% | 450 | 133 | 30% |
| Mine | hold | 3.3 | 26% | 182 | 0 | 0% |
| Mine | join | 1.4 | 96% | 76 | 0 | 0% |
| Mine | shoot | 6.3 | 53% | 184 | 405 | 220% |
| Mine | support | 7.1 | 91% | 215 | 0 | 0% |
| Opponent | advance | 15.1 | 18% | 641 | 505 | 79% |
| Opponent | charge | 4.1 | 61% | 423 | 516 | 122% |
| Opponent | close in | 5.6 | 19% | 351 | 144 | 41% |
| Opponent | hold | 3.5 | 31% | 362 | 0 | 0% |
| Opponent | join | 1.1 | 95% | 62 | 0 | 0% |
| Opponent | shoot | 4.0 | 66% | 138 | 258 | 187% |
| Opponent | support | 5.6 | 92% | 212 | 0 | 0% |

### Packages: hunt the guns, fw-h2h-mine-e441028-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 8 | 1 | 0% | 29% | 0% | 2.5 | 372 | 84 | 29% | 63 |
| Opponent | 0.3 | 12 | 0 | 25% | 42% | 0% | 2.4 | 481 | 131 | 33% | 80 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 1 | 0% | 33% | 0% | 3.0 | 430 | 124 | 33% | 27 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 172 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 85 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 84 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 73 |
| High Elf Realms | 0.4 | 3 | 0 | 0% | 0% | 0% | - | 383 | 0 | 0% | 123 |
| Kingdom of Bretonnia | 0.7 | 2 | 0 | 50% | 50% | 0% | 2.0 | 296 | 82 | 0% | 53 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 100% | 0% | 2.0 | 224 | 218 | 100% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 210 |
| Tomb Kings of Khemri | 1.0 | 6 | 0 | 0% | 33% | 0% | 2.5 | 409 | 119 | 33% | 54 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 76 |
| Warriors of Chaos | 0.2 | 2 | 0 | 100% | 100% | 0% | 2.5 | 454 | 346 | 100% | 36 |
| Wood Elf Realms | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 878 | 0 | 0% | 59 |

### Battle groups: fw-h2h-mine-e441028-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.3 | 27% | 53% | 13% | 42% | 29% | 8% | 14% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.3 | 23% | 58% | 11% | 0% | 6% | 0% | 24% | 65% | 6% |
| Opponent | COUNTER-CHARGE COVER | 6.8 | 16% | 59% | 13% | 40% | 24% | 12% | 21% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 25% | 84% | 26% | 12% | 13% | 0% | 17% | 61% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h-mine-e441028-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 30 | 13 (30) | 3 | 10 | 55 | 27% | 3.0 | 10 (15) | 6 (9) | 34 (6) | 15 (21) | 8 (9) |
| Mine | Character | 112 | 44 (112) | 43 | 1 | 39 | 19% | 2.3 | 27 (39) | 67 (34) | 51 (25) | 46 (75) | 53 (23) |
| Mine | Clean-up | 15 | 44 (15) | 4 | 40 | 50 | 27% | 3.1 | 77 (5) | 33 (6) | 24 (4) | 45 (14) | 0 (1) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Fast Hammer | 41 | 34 (41) | 17 | 16 | 60 | 29% | 2.9 | 13 (12) | 50 (16) | 40 (13) | 34 (35) | 33 (6) |
| Mine | Hammer | 45 | 53 (45) | 36 | 17 | 38 | 20% | 2.7 | 51 (22) | 52 (16) | 63 (7) | 66 (30) | 29 (15) |
| Mine | Holder | 28 | 29 (28) | 0 | 29 | 31 | 39% | 3.4 | 22 (14) | 47 (7) | 30 (6) | 42 (15) | 11 (12) |
| Mine | Shooter | 38 | 44 (38) | 21 | 23 | 43 | 3% | 2.2 | 12 (16) | 73 (11) | 71 (11) | 53 (21) | 33 (17) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | - | 0 (4) | - | 0 (1) | 0 (3) |
| Mine | War machine | 52 | 42 (52) | 42 | 0 | 40 | 2% | 1.1 | 39 (24) | 55 (20) | 19 (8) | 43 (30) | 40 (22) |
| Mine | Wizard | 16 | 24 (16) | 24 | 0 | 31 | 12% | 1.9 | 0 (2) | 47 (4) | 15 (8) | 29 (11) | 0 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 67 | 51 (67) | 8 | 43 | 46 | 49% | 3.0 | 37 (31) | 59 (24) | 66 (12) | 62 (45) | 25 (22) |
| Opponent | Character | 96 | 55 (96) | 55 | 0 | 26 | 16% | 2.3 | 48 (41) | 46 (35) | 86 (17) | 52 (58) | 63 (35) |
| Opponent | Clean-up | 17 | 60 (17) | 28 | 32 | 35 | 53% | 2.9 | 72 (8) | 55 (5) | 39 (4) | 48 (11) | 79 (6) |
| Opponent | Fast Hammer | 48 | 50 (48) | 37 | 13 | 48 | 29% | 2.8 | 23 (19) | 83 (18) | 59 (11) | 54 (31) | 45 (17) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 1.5 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 43 | 29 (43) | 23 | 6 | 39 | 30% | 3.2 | 15 (17) | 45 (20) | 9 (6) | 26 (30) | 35 (13) |
| Opponent | Holder | 38 | 45 (38) | 0 | 45 | 19 | 37% | 3.3 | 14 (17) | 103 (12) | 18 (8) | 56 (24) | 15 (13) |
| Opponent | Shooter | 28 | 33 (28) | 6 | 28 | 23 | 4% | 1.6 | 22 (14) | 74 (10) | 0 (4) | 33 (17) | 34 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 50 | 75% | 6.0 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | War machine | 17 | 105 (17) | 105 | 0 | 45 | 12% | 1.2 | 149 (8) | 71 (5) | 55 (4) | 47 (11) | 249 (6) |
| Opponent | Wizard | 30 | 9 (30) | 9 | 0 | 57 | 23% | 2.3 | 20 (11) | 0 (9) | 0 (2) | 19 (10) | 0 (12) |

### Charged fights: fw-h2h-mine-e441028-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 217 | 10 | 1.0 | 1.0 | 10 | 34 | -24 | 0 of 4 | 3 of 4 | - | -24 |
| Mine | Chaos Dwarfs | 4 | 156 | 252 | 2.0 | 1.1 | 126 | 12 | +114 | 2 of 8 | 6 of 8 | +70 | +121 |
| Mine | Dwarfen Mountain Holds | 3 | 309 | 139 | 2.3 | 1.1 | 60 | 18 | +41 | 1 of 7 | 7 of 7 | +0 | +48 |
| Mine | Empire of Man | 5 | 213 | 112 | 1.8 | 1.0 | 62 | 0 | +62 | 2 of 9 | 7 of 9 | - | +62 |
| Mine | Grand Cathay | 5 | 360 | 130 | 2.6 | 1.1 | 50 | 30 | +20 | 2 of 13 | 9 of 13 | +145 | +9 |
| Mine | High Elf Realms | 4 | 244 | 326 | 3.5 | 1.3 | 93 | 14 | +79 | 3 of 14 | 12 of 14 | +158 | +47 |
| Mine | Kingdom of Bretonnia | 1 | 236 | 234 | 2.0 | 1.0 | 117 | 0 | +117 | 2 of 2 | 2 of 2 | - | +117 |
| Mine | Lizardmen | 1 | 0 | 655 | 5.0 | 1.0 | 131 | 0 | +131 | 3 of 5 | 4 of 5 | - | +131 |
| Mine | Ogre Kingdoms | 1 | 317 | 0 | 5.0 | 1.0 | 0 | 7 | -7 | 2 of 5 | 4 of 5 | - | -7 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 340 | 3.0 | 1.0 | 113 | 131 | -18 | 2 of 3 | 2 of 3 | - | -18 |
| Mine | Tomb Kings of Khemri | 2 | 98 | 384 | 4.0 | 1.1 | 96 | 0 | +96 | 3 of 8 | 5 of 8 | +45 | +103 |
| Mine | Vampire Counts | 1 | 0 | 492 | 5.0 | 1.4 | 98 | 0 | +98 | 2 of 5 | 4 of 5 | +142 | +69 |
| Mine | Warriors of Chaos | 2 | 95 | 15 | 1.0 | 2.0 | 15 | 0 | +15 | 1 of 2 | 2 of 2 | +15 | - |
| **Mine** | all armies | 34 | 212 | 191 | 2.5 | 1.1 | 76 | 16 | +60 | 25 of 85 | 67 of 85 | +100 | +54 |
| Opponent | Empire of Man | 1 | 380 | 238 | 2.0 | 1.0 | 119 | 0 | +119 | 2 of 2 | 2 of 2 | - | +119 |
| Opponent | Grand Cathay | 3 | 382 | 210 | 3.3 | 1.2 | 63 | 0 | +63 | 3 of 10 | 7 of 10 | +0 | +79 |
| Opponent | High Elf Realms | 3 | 556 | 391 | 3.3 | 1.0 | 117 | 44 | +73 | 5 of 10 | 9 of 10 | - | +73 |
| Opponent | Kingdom of Bretonnia | 2 | 236 | 471 | 4.5 | 1.0 | 105 | 62 | +43 | 3 of 9 | 6 of 9 | - | +43 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 558 | 3.0 | 1.0 | 186 | 131 | +55 | 2 of 3 | 2 of 3 | - | +55 |
| Opponent | Skaven | 1 | 105 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 728 | 5.2 | 1.2 | 139 | 53 | +86 | 12 of 21 | 11 of 21 | +285 | +53 |
| Opponent | Vampire Counts | 6 | 0 | 678 | 4.3 | 1.2 | 156 | 21 | +136 | 11 of 26 | 14 of 26 | +299 | +87 |
| Opponent | Warriors of Chaos | 9 | 0 | 432 | 3.1 | 1.1 | 139 | 38 | +101 | 11 of 28 | 18 of 28 | +201 | +89 |
| Opponent | Wood Elf Realms | 4 | 41 | 195 | 2.5 | 1.0 | 78 | 21 | +57 | 6 of 10 | 4 of 10 | - | +57 |
| **Opponent** | all armies | 34 | 116 | 447 | 3.5 | 1.1 | 127 | 36 | +91 | 56 of 120 | 74 of 120 | +232 | +72 |

### Effective charges: fw-h2h-mine-e441028-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net +0) | 0 | 0 | 2 (net -68) | 0 | 1 (net +40) | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 8 | 1 (net +0) | 0 | 0 | 3 (net +48) | 2 (net +68) | 2 (net +318) | 0 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 0 | 0 | 1 (net +0) | 0 | 5 (net +45) | 1 | 0% (0 of 6) |
| Mine | Empire of Man | 9 | 1 (net +0) | 0 | 2 (net +0) | 0 | 3 (net +130) | 2 (net +22) | 1 | 25% (2 of 8) |
| Mine | Grand Cathay | 13 | 1 (net +0) | 0 | 0 | 2 (net +28) | 1 (net +145) | 4 (net +69) | 5 | 0% (0 of 8) |
| Mine | High Elf Realms | 14 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 2 (net +74) | 6 (net +162) | 3 | 9% (1 of 11) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 2 (net +117) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net +0) | 1 (net +144) | 0 | 2 (net +198) | 1 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 (net +0) | 1 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 0 | 2 (net +0) | 3 (net +50) | 3 (net +207) | 0 | 0% (0 of 8) |
| Mine | Vampire Counts | 5 | 0 | 0 | 2 (net +246) | 0 | 1 (net +0) | 1 (net +0) | 1 | 50% (2 of 4) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 1 (net +30) | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +119) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 10 | 0 | 0 | 1 (net +0) | 2 (net +112) | 0 | 6 (net +57) | 1 | 11% (1 of 9) |
| Opponent | High Elf Realms | 10 | 0 | 0 | 3 (net +39) | 2 (net +0) | 1 (net +135) | 4 (net +120) | 0 | 30% (3 of 10) |
| Opponent | Kingdom of Bretonnia | 9 | 2 (net -82) | 2 (net +130) | 0 | 1 (net +0) | 0 | 3 (net +66) | 1 | 0% (0 of 8) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 1 (net +432) | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 21 | 2 (net -270) | 0 | 3 (net +228) | 2 (net +0) | 2 (net +28) | 10 (net +125) | 2 | 16% (3 of 19) |
| Opponent | Vampire Counts | 26 | 5 (net +290) | 0 | 3 (net +128) | 1 (net +371) | 5 (net +77) | 11 (net +85) | 1 | 12% (3 of 25) |
| Opponent | Warriors of Chaos | 28 | 2 (net -15) | 1 (net -465) | 3 (net +165) | 5 (net +284) | 4 (net +94) | 8 (net +169) | 5 | 13% (3 of 23) |
| Opponent | Wood Elf Realms | 10 | 0 | 0 | 2 (net -104) | 2 (net +138) | 0 | 0 | 6 | 50% (2 of 4) |

### Charged fights, damage counted: fw-h2h-mine-e441028-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 179 | 188 | +0 | 47 | 25 | +22 | +12.5 |
| Mine | Effective (55-75%) | 7 | 313 | 233 | +70 | 128 | 30 | +98 | +31.3 |
| Mine | 76-89% | 14 | 279 | 162 | +32 | 78 | 35 | +43 | +15.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 231 | 170 | +107 | 132 | 15 | +117 | +50.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 402 | 83 | +77 | 102 | 5 | +97 | +24.2 |
| Mine | No odds | 16 | 266 | 221 | -1 | 69 | 67 | +2 | +0.7 |
| Mine | All fights | 85 | 275 | 171 | +60 | 101 | 29 | +73 | +26.4 |
| Opponent | Long shot (under 50%) | 11 | 299 | 237 | +65 | 207 | 129 | +78 | +26.2 |
| Opponent | 50-54% | 3 | 252 | 190 | -68 | 175 | 155 | +20 | +8.0 |
| Opponent | Effective (55-75%) | 16 | 279 | 246 | +92 | 163 | 77 | +86 | +31.0 |
| Opponent | 76-89% | 16 | 351 | 238 | +170 | 192 | 14 | +177 | +50.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 44 | 293 | 213 | +109 | 141 | 30 | +111 | +37.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 457 | 84 | +80 | 83 | 24 | +59 | +13.0 |
| Opponent | No odds | 18 | 164 | 193 | +23 | 85 | 66 | +19 | +11.9 |
| Opponent | All fights | 120 | 295 | 207 | +91 | 143 | 51 | +92 | +31.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h-mine-e441028-p3 | move | 481 | 105 (22%) | 76 (16%) | 44 (9%) | 332 (69%) |
| fw-h2h-mine-e441028-p3 | objective | 373 | 41 (11%) | 31 (8%) | 42 (11%) | 290 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

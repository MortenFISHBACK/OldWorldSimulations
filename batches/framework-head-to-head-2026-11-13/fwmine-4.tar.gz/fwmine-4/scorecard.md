# Doctrine scorecard: fw-h2h-mine-e441028-p4

### Scorecard: fw-h2h-mine-e441028-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 130 |
| L0114 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 6 | 3 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 1 | 2 | 6 | 3 | 0 | 0 | 0 | 442 |
| L0214 | 4 | 1 | Opponent | yes | 8 | 2 | 4 | 3 | 0 | 0 | 0 | 151 |
| L0230 | 2 | 1 | Mine | - | - | 4 | 4 | 5 | 1 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L0417 | 3 | 1 | Mine | yes | 3 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 5 | 2 | 4 | 0 | 1 | 0 | 0 | 49 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 3 | 2 | 4 | 0 | 0 | 0 | 56 |
| L0520 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0520 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 5 | 2 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 828 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0624 | 6 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 5 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 0 | 0 | 0 | 302 |
| L0729 | 3 | 1 | Mine | no | 2 | 4 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 6 | 3 | 1 | 1 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 4 | 4 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0819 | 3 | 1 | Opponent | no | 6 | 2 | 2 | 0 | 1 | 0 | 0 | 161 |
| L0835 | 1 | 1 | Mine | no | 3 | 6 | 0 | 1 | 1 | 0 | 0 | 560 |
| L0835 | 1 | 1 | Opponent | no | 7 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 479 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 6 | 0 | 3 | 0 | 0 | 497 |
| L1017 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 2 | 0 | 0 | 224 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 427 |
| L1126 | 4 | 1 | Opponent | no | 1 | 2 | 4 | 4 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 1 | 0 | 0 | 532 |
| L1314 | 6 | 1 | Mine | yes | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | no | - | 3 | 3 | 2 | 2 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 190 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 0 | 0 | 1 | 0 | 0 | 176 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 2 | 0 | 0 | 162 |
| L1621 | 1 | 1 | Mine | no | 1 | 3 | 5 | 1 | 0 | 0 | 0 | 475 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 210 |
| L1719 | 3 | 1 | Mine | yes | 1 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | no | 2 | 1 | 7 | 1 | 1 | 0 | 0 | 339 |
| L1819 | 1 | 1 | Mine | yes | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | - | 2 | 0 | 2 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 7 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | 6 | 0 | 4 | 0 | 0 | 0 | 290 |
| L2123 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 1 | 1 | 6 | 2 | 0 | 0 | 0 | 60 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 2 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 7 | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 7 | 1 | 1 | 0 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 39% | 2.0 | 3.0 | 2.1 | 1.2 | 0.3 | 0.0 | 0.0 | 261.1 |
| **Average** | | | Opponent | 18% | 2.4 | 2.3 | 3.5 | 1.9 | 0.5 | 0.0 | 0.0 | 105.3 |

### KPIs: fw-h2h-mine-e441028-p4

Rules off - Opponent only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 58% (104 of 178) | 0% (0 of 186) | 29% (104 of 364) |
| Winner chose to follow up after the loser gave ground |  | 98% (42 of 43); on the table 100% | 98% (62 of 63); on the table 98% | 98% (104 of 106); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 86% (12 of 14); on the table 100% | 88% (21 of 24); on the table 96% |
| Winner chose to pursue after the loser fled |  | 89% (17 of 19); on the table 89% | 81% (29 of 36); on the table 86% | 84% (46 of 55); on the table 87% |
| Winner chose to follow up or pursue (all three) |  | 94% (68 of 72); on the table 96% | 91% (103 of 113); on the table 95% | 92% (171 of 185); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 37% (101 of 271) | 31% (52 of 170) | 35% (153 of 441) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (101 of 187) | 46% (52 of 113) | 51% (153 of 300) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 68% (26 of 38) | - | 68% (26 of 38) |
| Points that never fought | lower | 32% (21591 of 67942) | 36% (25988 of 71984) | 34% (47579 of 139926) |
|   infantry points that never fought | lower | 42% (6389 of 15347) | 58% (8033 of 13804) | 49% (14422 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (158 of 270) | 55% (154 of 280) | 57% (312 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 82% (18 of 22); 1.3 uses a game | 89% (8 of 9); 0.7 uses a game | 84% (26 of 31); 1.0 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.6 uses a game | 40% (8 of 20); 0.4 uses a game | 44% (16 of 36); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 67% (10 of 15); 0.3 uses a game | 59% (20 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30061 of 57750) | 47% (29906 of 63347) | 50% (59967 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (24%) | 1.0 (30%) | 2.1 (26%) |
| MARCHED: its unit marched | 1.1 (23%) | 0.6 (17%) | 1.6 (20%) |
| CHARGED: its unit charged | 0.1 (3%) | 0.2 (5%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 0.8 (17%) | 0.4 (13%) | 1.2 (15%) |
| GONE: slain | 1.1 (24%) | 1.0 (31%) | 2.1 (26%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (9%) | 0.2 (5%) | 0.6 (7%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.8 | 1.9 | 4.2 | 0.4 | 1.8 |
| not cast | 2.6 | 2.2 | 2.9 | 8.0 | 1.6 | 21.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (42%) | 0.2 (7%) | 2.1 (26%) | 0.4 (26%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (20%) | 0.2 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.2 (9%) | 0.5 (18%) | 1.2 (15%) | 0.2 (16%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.1 (43%) | 0.4 (17%) | 0.8 (28%) | 2.1 (26%) | 0.2 (12%) | 3.4 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (5%) | 0.3 (14%) | 0.3 (11%) | 0.6 (7%) | 0.0 (2%) | 0.9 (4%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (12%) | 0.0 (0%) | 0.0 (0%) | 0.4 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.1 (44%) | 0.1 (5%) | 1.0 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.2 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 66% (31 of 47) | 62% (10 of 16) | 65% (41 of 63) |
| the unit moved after it | 61% (19 of 31) | 50% (5 of 10) | 59% (24 of 41) |
| it charged on its next turn | 0% (0 of 31) | 10% (1 of 10) | 2% (1 of 41) |
| the enemy charged it first | 19% (6 of 31) | 0% (0 of 10) | 15% (6 of 41) |
| it fought by the end of its next turn | 6% (2 of 31) | 0% (0 of 10) | 5% (2 of 41) |
| it moved out of a charge the enemy had planned (not charged first) | 23% (7 of 31) | 10% (1 of 10) | 20% (8 of 41) |
| none of these (no charge, no fight, no charge escaped) | 58% (18 of 31) | 90% (9 of 10) | 66% (27 of 41) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (528 of 852) | 47% (272 of 579) | 56% (800 of 1431) |
|   cavalry | 51% (44 of 87) | 52% (59 of 113) | 52% (103 of 200) |
|   character | 45% (39 of 87) | 15% (21 of 136) | 27% (60 of 223) |
|   chariot | 56% (58 of 104) | 57% (16 of 28) | 56% (74 of 132) |
|   infantry | 44% (106 of 243) | 60% (147 of 245) | 52% (253 of 488) |
|   monster | 65% (34 of 52) | 17% (4 of 24) | 50% (38 of 76) |
|   war machine | 89% (247 of 279) | 76% (25 of 33) | 87% (272 of 312) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (27%) | 2.0 (23%) | 4.5 (26%) |
| CHARGED: it charged | 0.9 (10%) | 2.2 (26%) | 3.2 (18%) |
| FLEEING: it fled or was fleeing | 0.4 (4%) | 0.1 (1%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (11%) | 0.3 (4%) | 1.3 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| NO TARGET IN RANGE | 2.1 (24%) | 1.7 (20%) | 3.8 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.4 (5%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (13%) | 1.6 (19%) | 2.8 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.6 | 1.1 | 79% | 6.2 pts | 28 pts |
| character | 2.0 | 1.0 | 71% | 12.8 pts | 26 pts |
| chariot | 2.1 | 0.9 | 77% | 7.9 pts | 16 pts |
| infantry | 10.1 | 2.9 | 77% | 8.4 pts | 85 pts |
| monster | 1.2 | 0.3 | 79% | 4.8 pts | 6 pts |
| war machine | 7.6 | 6.0 | 66% | 27.4 pts | 207 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 7.4 | 5.6 |
| Charges that made contact a game | 2.6 | 5.1 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.41 contact (22 units) | 0.67 declared, 0.52 contact (21 units) | 0.58 declared, 0.47 contact (43 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.23 declared, 0.23 contact (13 units) | 1.43 declared, 1.14 contact (14 units) | 0.85 declared, 0.70 contact (27 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.34 contact (246 units) | 0.76 declared, 0.51 contact (306 units) | 0.64 declared, 0.43 contact (552 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (46 of 81) | 62% (10 of 16) | 67% (4 of 6) | 58% (60 of 103) |
| Character in a unit | 75% (9 of 12) | 86% (6 of 7) | 100% (1 of 1) | 80% (16 of 20) |
| Character on its own | 74% (39 of 53) | 54% (19 of 35) | 22% (17 of 77) | 45% (75 of 165) |
| Chariot | 60% (9 of 15) | 58% (7 of 12) | - | 59% (16 of 27) |
| Infantry | 59% (49 of 83) | 36% (9 of 25) | 50% (3 of 6) | 54% (61 of 114) |
| Monster | 68% (23 of 34) | 64% (9 of 14) | - | 67% (32 of 48) |
| Monstrous | 64% (9 of 14) | 57% (8 of 14) | - | 61% (17 of 28) |
| War Machines | 79% (34 of 43) | 50% (1 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 77% (10 of 13); on the table 77% | 33% (34 of 102) | 22% | 64% (14 of 22) | 67% (4 of 6); 1.5 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (8 of 8); on the table 100% | 62% (15 of 24) | 33% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 46% | 52% (14 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (6 of 6); on the table 100% | 22% (4 of 18) | 41% | 66% (41 of 62) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 100% (11 of 11); on the table 100% | 44% (37 of 84) | 31% | 57% (21 of 37) | 100% (9 of 9); 7.0 uses a game | 50% (1 of 2); 1.5 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 88% (21 of 24); on the table 88% | 23% (8 of 35) | 38% | 44% (31 of 70) | 100% (7 of 7); 2.1 uses a game | 40% (12 of 30); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 41% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (17 of 17); on the table 100% | 33% (2 of 6) | 24% | 48% (10 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 75% (3 of 4); on the table 100% | 67% (4 of 6) | 43% | 86% (12 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 92% (11 of 12); on the table 100% | 7% (3 of 42) | 32% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 6 | 75% (6 of 8); on the table 88% | 43% (18 of 42) | 52% | 69% (31 of 45) | 67% (2 of 3); 1.2 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 100% (8 of 8); on the table 100% | 0% (0 of 6) | 33% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 96% (26 of 27); on the table 100% | 36% (21 of 58) | 23% | 55% (23 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 86% (19 of 22); on the table 91% | 33% (4 of 12) | 27% | 50% (36 of 72) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 100% (23 of 23); on the table 100% | 50% (3 of 6) | 36% | 61% (34 of 56) | 50% (1 of 2); 0.8 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h-mine-e441028-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (60) | 48% (32) | 49% (92) |
| ...free all their last turn and able to turn (per game) | 1.03 | 0.64 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.06 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.69 | 0.44 | 1.14 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.75 | 0.94 | 2.69 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.00 | 0.97 | 1.97 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 8.14 | 8.11 | 16.25 |

### Quality by phase: fw-h2h-mine-e441028-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 0.0 |
| Strategy | Charge objectives carried out (made contact) | 52% (59 of 114) | 47% (100 of 215) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (123 of 281) | 41% (56 of 136) |
| Strategy | Close-in objectives charged next turn | 15% (25 of 168) | 19% (38 of 200) |
| Strategy | Support requests answered (helper made contact too) | 67% (10 of 15) | 58% (15 of 26) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (8 of 16) | 36% (4 of 11) |
| Strategy | Joined characters whose unit fought | 53% (10 of 19) | 24% (4 of 17) |
| Strategy | Lone characters that fought | 72% (75 of 104) | 71% (70 of 99) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.2 | 1.9 |
| Movement | Points that never moved of their own | 261.1 | 105.3 |
| Movement | Fights charged into per game | 2.3 | 4.5 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 73, net -69 | 18 of 130, net +15 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 73, net +62 | 21 of 130, net +89 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 73, net +58 | 15 of 130, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 of 73, net +125 | 37 of 130, net +141 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.9 | 8.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (146 of 319) | 45% (133 of 297) |
| Shooting | Points destroyed by shooting units | 76.8 | 24.2 |
| Shooting | War machine shots | 6.9 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (139 of 247) | 36% (9 of 25) |
| Shooting | Points destroyed by war machines | 62.0 | 5.0 |
| Magic | Magic missiles cast | 1.9 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (27 of 70) | 33% (14 of 42) |
| Magic | Wounds caused by magic missiles | 4.5 | 1.7 |
| Magic | Wounds caused by other spells | 2.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 92.3 | 25.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.5 / 0.6 / 0.2 | 2.1 / 0.6 / 0.4 / 0.0 |
| Combat | Points destroyed in combat | 314.7 | 429.1 |
| Combat | Points run down | 56.5 | 161.8 |
| Combat | Net points per charged fight, damage counted | +79 | +104 |
| Combat | Net per 100 charger points, damage counted | +29.4 | +35.6 |
| Combat | First round won (charged fights) | 73% | 62% |
| Combat | Net points per charged fight | +81 | +96 |
| Combat | Net points per supported fight / lone fight | +139 / +71 | +89 / +97 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 84 | 76 of 162 |
| Game | Points lost | 854.0 | 679.0 |
| Game | VP from objectives | 475.3 | 596.7 |
| Game | Lone holders (player turns) | 2.0 | 2.4 |

- Mine won / drew / lost: 11 / 7 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -325 VP
- The side that went first won 14 of 29 games with a winner
- Points traded per game (both sides' losses): 1533
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: fw-h2h-mine-e441028-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 3.9 | - | - | - | - |
| BACKUP TARGETS | 1.4 | +10.3 | 0.0 | 21.1 | 1.3 | +11.1 | 0.0 | 11.9 |
| BEST FACING | 0.7 | +20.7 | 0.0 | 31.5 | - | - | - | - |
| BEST FIRST | 3.3 | +147.1 | 112.8 | 107.8 | - | - | - | - |
| BEST OVERALL | 0.6 | +26.6 | 0.0 | 47.0 | 0.4 | +17.1 | 0.0 | 13.2 |
| BEST PREY | 1.0 | +58.5 | 48.4 | 14.8 | 6.1 | +311.3 | 241.1 | 90.1 |
| BEST PRIZE | 0.1 | -3.3 | 0.0 | 0.0 | 0.1 | -8.9 | 11.6 | 13.2 |
| BIG CHARACTER SAFETY | 0.4 | -1.4 | 0.0 | 0.0 | 0.2 | -0.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.5 | +18.0 | 0.0 | 10.6 | 0.5 | -4.1 | 0.0 | 3.9 |
| BOMBING RUN | 0.1 | +3.1 | 0.0 | 1.7 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 107.4 | 9.9 | 0.1 | +0.0 | 24.0 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +157.9 | 288.9 | 119.3 | 0.5 | +13.1 | 29.0 | 13.9 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 6.9 | 4.8 |
| CARRIES OUT SET-UP | 0.2 | -0.4 | 16.3 | 0.0 | 0.1 | +0.0 | 14.6 | 0.0 |
| CAST JOB | 0.3 | +14.3 | 28.4 | 8.8 | 0.7 | +13.1 | 45.7 | 22.7 |
| CASTING BLOCK | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 46.2 | 0.3 | +0.0 | 0.0 | 20.2 |
| CATCH FLIERS | 0.1 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.1 | 0.0 | 4.1 | 0.1 | -0.2 | 9.4 | 4.9 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.6 | -42.0 | 19.6 | 10.3 | 0.7 | -38.5 | 26.2 | 27.2 |
| CHARIOT NO STATIC JOB | 0.2 | +0.0 | 9.6 | 4.7 | 0.1 | +0.0 | 6.1 | 3.2 |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.9 | 13.9 | 27.8 | 0.1 | -1.7 | 0.0 | 11.1 |
| CHEAP HELPER | 0.1 | +0.0 | 5.4 | 0.0 | 0.1 | +0.0 | 9.0 | 3.2 |
| COMBAT PIVOT | 0.4 | +0.0 | 3.2 | 67.8 | 0.5 | +0.0 | 39.5 | 12.9 |
| CONVEYANCE SEARCH | 1.1 | +170.5 | 48.1 | 63.8 | 0.2 | +65.7 | 13.9 | 25.0 |
| COUNTER-CHARGE COVER | 10.9 | +817.8 | 0.0 | 268.0 | 7.7 | +619.0 | 0.0 | 165.8 |
| DEFENSIVE ARMY | 0.6 | -0.1 | 25.6 | 9.3 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +2.1 | 13.5 | 0.0 | 0.1 | +1.1 | 20.3 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +142.7 | 0.0 | 62.7 | 0.9 | +69.7 | 0.0 | 22.9 |
| FALLBACK BY WORTH | 5.5 | +84.5 | 0.0 | 72.2 | 9.4 | +70.7 | 0.0 | 116.3 |
| FIGHT LIFT | 0.1 | +0.7 | 2.7 | 9.3 | 0.0 | +0.0 | 3.2 | 0.0 |
| FIRE AND FLEE | 0.1 | +1.3 | 0.0 | 5.9 | - | - | - | - |
| FLANK NOT WEIGHED | 7.8 | +0.0 | 0.0 | 237.2 | 7.3 | +0.0 | 0.0 | 209.5 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +128.3 | 0.0 | 58.0 | 1.1 | +132.4 | 0.0 | 30.5 |
| FRIENDS SHOTS CHECKED | 0.1 | +0.6 | 0.0 | 4.6 | 0.2 | +11.6 | 0.0 | 3.2 |
| GIVES UP | 0.7 | -26.7 | 99.3 | 29.0 | 2.0 | -84.2 | 232.6 | 30.2 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 0.0 | 0.0 | 1.1 | -19.1 | 114.9 | 27.7 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 22.6 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 5.7 | 0.0 | 0.8 | +0.0 | 57.8 | 23.2 |
| HILL BY ITS CHANCE | 0.5 | -49.0 | 0.0 | 16.8 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.1 | 5.4 | 0.0 | 0.2 | +8.0 | 18.3 | 3.2 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 15.6 | 6.0 |
| HUNT IN PAIRS | 0.9 | +20.0 | 0.0 | 0.0 | 0.6 | +9.6 | 0.0 | 13.3 |
| HUNT KEPT | 0.0 | +0.0 | 5.4 | 0.0 | 0.1 | +7.4 | 6.5 | 3.2 |
| HUNT RESULT | 0.1 | +11.1 | 0.0 | 1.8 | 0.3 | +22.4 | 19.4 | 13.9 |
| HUNT THE GUNS | 0.1 | +31.4 | 10.8 | 1.8 | 0.3 | +92.3 | 31.8 | 7.9 |
| INVITES THE FIGHT | 4.6 | +242.6 | 205.6 | 139.0 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +5.7 | 8.2 | 5.7 | 0.1 | +7.1 | 9.4 | 0.0 |
| KEEP FALLS | 0.1 | +1.8 | 0.0 | 6.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.6 | +3.7 | 28.5 | 6.9 |
| KEEPS ITS TARGET | 2.2 | +65.8 | 180.3 | 67.2 | 2.3 | +68.3 | 142.9 | 46.1 |
| KILLS COUNT | 1.4 | +61.2 | 107.6 | 20.7 | 2.6 | +143.5 | 268.4 | 54.7 |
| KILLS COUNT NEXT TURN | 6.2 | +187.8 | 270.7 | 104.8 | 11.8 | +457.4 | 500.4 | 196.1 |
| LONE CHARACTER SAFE SPOT | 0.5 | +26.8 | 12.1 | 12.1 | 0.3 | +5.1 | 11.1 | 1.4 |
| LONE WIZARD HOLDS BACK | 0.6 | +0.0 | 22.0 | 3.3 | 0.9 | +0.0 | 32.4 | 19.8 |
| LONG SHOT | 0.2 | -2.4 | 22.7 | 0.0 | - | - | - | - |
| LOST CHARGE | 2.9 | -59.0 | 131.7 | 94.9 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.0 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.6 | +25.8 | 25.2 | 3.2 | 0.5 | +29.6 | 21.4 | 8.0 |
| MANOEUVRE | 0.4 | +11.2 | 0.0 | 14.0 | 0.1 | +3.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +18.0 | 0.0 | 24.4 | 0.4 | +8.2 | 0.0 | 20.3 |
| MARCH ODDS | 0.1 | +3.1 | 0.0 | 0.0 | 0.3 | +27.1 | 7.4 | 28.9 |
| MARCH OVER CASTS | 0.5 | +31.4 | 0.0 | 31.8 | 0.4 | +34.5 | 0.0 | 26.2 |
| MAX FOR POSITIONING | 6.3 | +222.8 | 0.0 | 137.9 | 4.6 | +154.5 | 0.0 | 91.8 |
| MISSILES IN THE MOVE | 4.0 | +134.6 | 0.0 | 149.4 | 2.1 | +33.9 | 0.0 | 93.2 |
| MISSILES NEXT TURN | 4.8 | +89.3 | 0.0 | 174.9 | 3.0 | +26.4 | 0.0 | 128.4 |
| MODEL FACING | 0.3 | +67.5 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 18.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +14.6 | 0.0 | 4.5 | 0.2 | +3.3 | 0.0 | 1.7 |
| MOVE SPELL IN RANGE | 0.7 | +21.2 | 0.0 | 2.4 | 0.1 | +5.9 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.6 | -20.7 | 0.0 | 14.9 | 0.1 | -0.2 | 5.3 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 24.9 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 5.1 | +346.7 | 195.4 | 98.8 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +4.9 | 17.9 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.2 | 0.0 | 6.1 | 0.0 | +2.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -15.2 | 31.7 | 1.8 | 0.4 | -32.2 | 19.6 | 10.1 |
| NOT TURNED | 8.1 | +220.3 | 0.0 | 212.8 | 8.1 | +125.0 | 0.0 | 197.0 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 13.6 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 16.2 | -797.7 | 0.0 | 366.8 | 19.0 | -1149.5 | 98.9 | 360.9 |
| OPENS A LANE | 0.1 | +0.3 | 10.0 | 0.0 | 0.1 | +1.0 | 5.8 | 0.0 |
| OPENS UP | 0.2 | +15.3 | 11.2 | 0.0 | 0.3 | +32.2 | 10.5 | 7.9 |
| OVERRUNS AWAY | 0.6 | +12.9 | 63.4 | 5.4 | 0.8 | +11.1 | 83.7 | 27.6 |
| PATHS CROSS | 2.9 | +218.4 | 0.0 | 12.6 | 3.7 | +268.3 | 0.0 | 28.1 |
| PERIAPT WORTH | 0.1 | +6.4 | 0.0 | 0.0 | 0.1 | +7.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.3 | 0.0 | 1.0 | 0.1 | -2.4 | 0.0 | 6.2 |
| PLAN RESULT | 40.0 | +1234.1 | 1482.6 | 1175.2 | 42.4 | +1136.5 | 1502.3 | 1124.8 |
| PURSUES BIG PREY | 0.0 | -1.9 | 0.0 | 0.0 | 0.2 | -42.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 4.2 | 0.0 | +1.4 | 0.0 | 3.4 |
| RANDOM MOVE BY FIGURES | 1.1 | +18.8 | 0.0 | 26.9 | - | - | - | - |
| RANDOM MOVER NO PROMISE | 0.4 | -23.8 | 3.0 | 13.5 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.1 | -5.9 | 0.0 | 1.5 | - | - | - | - |
| REDIRECT COUNTER | 2.9 | +175.1 | 0.0 | 50.6 | 4.4 | +234.1 | 0.0 | 92.5 |
| REDIRECT WEIGHED | 0.2 | +4.4 | 2.3 | 4.1 | 0.5 | +22.2 | 17.1 | 4.2 |
| RESERVE FALL BACK | 0.6 | +10.2 | 0.0 | 6.7 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.2 | +2.1 | 0.0 | 7.2 | 0.1 | +1.9 | 0.0 | 5.1 |
| RISK BY ARC | 1.9 | +69.2 | 204.0 | 54.2 | 3.6 | +109.7 | 338.4 | 127.4 |
| SAFER THAN THE JOB | 1.0 | +66.1 | 0.0 | 33.5 | 1.0 | +64.1 | 0.0 | 26.2 |
| SCREEN BY WHAT IT SAVES | 0.2 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 3.9 | +193.5 | 0.0 | 57.6 | 1.7 | +100.5 | 0.0 | 26.1 |
| SECOND HUNTER | 0.0 | -0.1 | 5.4 | 1.8 | - | - | - | - |
| SELF MOVE SPELL | 0.1 | +14.7 | 0.0 | 11.0 | 0.5 | +41.5 | 0.0 | 27.2 |
| SET UP TOGETHER | 1.0 | +34.9 | 25.2 | 7.8 | 1.2 | +60.1 | 23.4 | 16.6 |
| SET-UP ANY TARGET | 0.6 | +103.0 | 27.3 | 32.5 | 0.1 | +16.0 | 13.9 | 25.0 |
| SET-UP MISSED | 0.0 | +2.6 | 0.0 | 0.0 | 0.1 | +30.9 | 3.5 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.6 | +20.0 | 41.9 | 9.6 | - | - | - | - |
| SHOT REPLANNED | 0.5 | +0.0 | 85.1 | 14.4 | 0.2 | +0.0 | 21.7 | 0.0 |
| SHOTS IN THE MOVE | 13.5 | +492.6 | 0.0 | 292.8 | 7.1 | +134.7 | 0.0 | 99.9 |
| SPELL CATCH ODDS | 0.0 | -0.6 | 8.4 | 11.2 | 0.0 | -0.7 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.6 | +111.1 | 35.7 | 43.8 | 0.2 | +48.2 | 13.9 | 25.0 |
| SPELL WORTH | 1.4 | +19.3 | 89.9 | 96.5 | 2.4 | +49.1 | 103.7 | 99.4 |
| STABLE ROLE | 13.3 | +0.0 | 462.5 | 293.5 | - | - | - | - |
| STANDS TO CAST | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| STOPS | 0.1 | +0.3 | 5.4 | 1.8 | 0.2 | +11.1 | 20.0 | 7.9 |
| STOPS SHORT OF THE FLANK | 0.7 | +19.7 | 0.0 | 20.9 | 0.5 | +13.6 | 0.0 | 19.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 2.9 | 0.0 |
| SUPPORTS | 7.6 | +286.3 | 298.8 | 159.9 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.2 | -13.4 | 22.2 | 13.7 | 0.1 | -1.9 | 6.1 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +1.5 | 0.0 | 2.8 | 0.9 | +4.4 | 20.2 | 6.0 |
| THROUGH LINE OF FIRE | 0.3 | +9.4 | 0.0 | 10.1 | 0.2 | +9.2 | 0.0 | 2.5 |
| TURN WORTH | 0.5 | -36.2 | 33.5 | 9.9 | 0.4 | -40.8 | 22.8 | 7.9 |
| TWO OR MORE ARRIVE | 0.3 | +1.4 | 20.3 | 1.0 | 0.4 | +3.4 | 1.0 | 4.5 |
| WALKS TO THE FIGHT | 1.9 | +86.2 | 48.2 | 12.5 | - | - | - | - |
| WAR ENGINE JOBS | 1.0 | +0.0 | 52.6 | 24.7 | - | - | - | - |
| WEARS DOWN | 0.8 | +26.1 | 124.3 | 22.6 | 1.4 | +47.6 | 122.2 | 43.8 |
| WHO HITS BACK | 0.4 | +31.4 | 0.0 | 3.2 | 0.3 | +24.8 | 0.0 | 6.0 |
| WHOLE FIGHT | 0.4 | +12.9 | 73.5 | 7.1 | 0.4 | +20.3 | 39.7 | 1.8 |
| WHOLE FIGHT GAIN | 0.2 | +18.4 | 24.7 | 0.0 | 0.6 | +58.0 | 48.1 | 11.9 |

### Rule changes: fw-h2h-mine-e441028-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1269 | 1269 | 1269 | 35.25 | -70098 | -55.2 |
| PATHS CROSS | 236 | 236 | 236 | 6.56 | +17518 | +74.2 |
| SEARCH SPOT | 200 | 200 | 199 | 5.53 | +10625 | +53.4 |
| SUPPORTS | 274 | 274 | 173 | 4.81 | +4031 | +23.3 |
| KILLS COUNT NEXT TURN | 646 | 639 | 172 | 4.78 | +4880 | +28.4 |
| COUNTER-CHARGE COVER | 670 | 364 | 161 | 4.47 | +9373 | +58.2 |
| BEST FIRST | 120 | 120 | 120 | 3.33 | +5294 | +44.1 |
| FALLBACK BY WORTH | 538 | 538 | 102 | 2.83 | +5587 | +54.8 |
| MOVE TO CHARGE | 183 | 183 | 100 | 2.78 | +4649 | +46.5 |
| FACES THE THREAT | 97 | 97 | 97 | 2.69 | +7647 | +78.8 |
| BEST PREY | 255 | 251 | 90 | 2.50 | +3352 | +37.2 |
| INVITES THE FIGHT | 167 | 167 | 86 | 2.39 | +2823 | +32.8 |
| FOLLOW UP WEIGHED | 77 | 77 | 77 | 2.14 | +9386 | +121.9 |
| SHOTS IN THE MOVE | 740 | 470 | 74 | 2.06 | +1654 | +22.4 |
| SAFER THAN THE JOB | 71 | 71 | 71 | 1.97 | +4687 | +66.0 |
| REDIRECT COUNTER | 264 | 120 | 54 | 1.50 | +3195 | +59.2 |
| CHARGE NOW WEIGHED | 48 | 48 | 48 | 1.33 | +2864 | +59.7 |
| RISK BY ARC | 199 | 188 | 47 | 1.31 | +1607 | +34.2 |
| CANNON PLANNED TARGET | 207 | 207 | 46 | 1.28 | -269 | -5.9 |
| KILLS COUNT | 146 | 141 | 46 | 1.28 | +2317 | +50.4 |
| MAX FOR POSITIONING | 390 | 219 | 44 | 1.22 | +552 | +12.6 |
| STOPS SHORT OF THE FLANK | 43 | 43 | 43 | 1.19 | +1196 | +27.8 |
| WALKS TO THE FIGHT | 67 | 67 | 39 | 1.08 | +1193 | +30.6 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| BLOCKED WHEEL | 37 | 37 | 37 | 1.03 | +501 | +13.6 |
| BEST OVERALL | 35 | 35 | 35 | 0.97 | +1570 | +44.9 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KEEPS ITS TARGET | 161 | 160 | 33 | 0.92 | +531 | +16.1 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| MARCH CHECK | 31 | 31 | 30 | 0.83 | +1792 | +59.7 |
| SET UP TOGETHER | 82 | 75 | 27 | 0.75 | +906 | +33.5 |
| WHO HITS BACK | 27 | 27 | 27 | 0.75 | +1517 | +56.2 |
| RANDOM MOVE BY FIGURES | 38 | 38 | 26 | 0.72 | +678 | +26.1 |
| BEST FACING | 25 | 25 | 25 | 0.69 | +747 | +29.9 |
| MISSILES IN THE MOVE | 220 | 110 | 25 | 0.69 | +658 | +26.3 |
| REDIRECT WEIGHED | 25 | 25 | 25 | 0.69 | +1524 | +60.9 |
| LONE WIZARD HOLDS BACK | 57 | 57 | 24 | 0.67 | -341 | -14.2 |
| SHOT REPLANNED | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 21 | 21 | 21 | 0.58 | -67 | -3.2 |
| MANOEUVRE | 21 | 21 | 21 | 0.58 | +547 | +26.0 |
| RESERVE FALL BACK | 21 | 21 | 21 | 0.58 | +369 | +17.6 |
| THROUGH LINE OF FIRE | 18 | 18 | 18 | 0.50 | +669 | +37.2 |
| WHOLE FIGHT GAIN | 28 | 27 | 18 | 0.50 | +766 | +42.6 |
| CAST JOB | 36 | 36 | 17 | 0.47 | +421 | +24.8 |
| MOVE AND CAST | 17 | 17 | 17 | 0.47 | +644 | +37.9 |
| STUCK PIVOT | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| WEARS DOWN | 79 | 76 | 17 | 0.47 | +411 | +24.2 |
| SURE REACH TOGETHER | 50 | 38 | 13 | 0.36 | +139 | +10.7 |
| MARCH ODDS | 13 | 12 | 12 | 0.33 | +293 | +24.4 |
| SURE CHARGE BEATS ADVANCE | 12 | 12 | 12 | 0.33 | -552 | -46.0 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -9 | -0.9 |
| MAKE SURE TOGETHER | 39 | 33 | 11 | 0.31 | +456 | +41.4 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +2429 | +220.8 |
| SHOOTS FROM THE BEST SPOT | 22 | 22 | 11 | 0.31 | +290 | +26.3 |
| OPENS UP | 17 | 17 | 10 | 0.28 | +751 | +75.1 |
| WHOLE FIGHT | 29 | 26 | 9 | 0.25 | +371 | +41.2 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -507 | -63.3 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 8 | 8 | 8 | 0.22 | +441 | +55.1 |
| OVERRUNS AWAY | 50 | 49 | 8 | 0.22 | +155 | +19.4 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -134 | -16.7 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -1612 | -201.5 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +144 | +18.0 |
| HUNT IN PAIRS | 53 | 26 | 7 | 0.19 | +146 | +20.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| MISSILES NEXT TURN | 280 | 137 | 6 | 0.17 | +13 | +2.1 |
| WAR ENGINE JOBS | 35 | 35 | 6 | 0.17 | -329 | -54.8 |
| HUNT ADVANCE | 11 | 11 | 5 | 0.14 | +106 | +21.3 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +213 | +42.7 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +512 | +102.3 |
| STOPS | 8 | 8 | 5 | 0.14 | +194 | +38.9 |
| KEEPS ITS PREY | 20 | 20 | 4 | 0.11 | +13 | +3.1 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| BACKUP TARGETS | 97 | 48 | 3 | 0.08 | +16 | +5.3 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +112 | +37.2 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +99 | +33.1 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -17 | -5.5 |
| CHARIOT NO STATIC JOB | 9 | 9 | 2 | 0.06 | -176 | -87.8 |
| DEFENSIVE ARMY | 20 | 20 | 2 | 0.06 | -19 | -9.3 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +46 | +22.9 |
| LOST CHARGE | 104 | 104 | 2 | 0.06 | +76 | +38.1 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +72 | +35.9 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +135 | +67.3 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.03 | -15 | -15.2 |
| CASTING BLOCK | 1 | 1 | 1 | 0.03 | +37 | +37.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +12 | +12.3 |
| HILL BY ITS CHANCE | 17 | 17 | 1 | 0.03 | +62 | +61.6 |
| JOINT CHARGE PLAN | 8 | 8 | 1 | 0.03 | +97 | +96.6 |
| MOVE SPELL IN RANGE | 29 | 16 | 1 | 0.03 | +43 | +42.7 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +32 | +32.1 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 27 | 27 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 9 | 9 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 47 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 5 | 5 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 544 | not checked | - | - | - | - |
| GIVES UP | 98 | 92 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 40 | 38 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 32 | 28 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 14 | trace | - | - | - | - |
| HUNT THE GUNS | 15 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 28 | not checked | - | - | - | - |
| LONG SHOT | 8 | 8 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT NEEDED | 25 | 25 | 0 | 0.00 | - | - |
| NOT TURNED | 585 | 585 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 31 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 2967 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 14 | 14 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 137 | not checked | - | - | - | - |
| STABLE ROLE | 480 | 480 | 0 | 0.00 | - | - |
| TURN WORTH | 31 | 28 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 28 | 28 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h-mine-e441028-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.00 | 15.03 | 57.8 |
| FALLBACK | gate | 0.75 | 1.69 | 57.8 |
| TURN GATE | gate | 1.00 | 0.69 | 36.4 |
| RULE SWITCHED OFF | gate | - | 1.08 | 22.7 |
| CANNON PLANNED TARGET | rule | 0.36 | 0.06 | 43.1 |
| PATHS CROSS | rule | 0.17 | 0.25 | 27.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.22 | 0.11 | 46.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.22 | 0.08 | 37.0 |
| BIG CHARACTER SAFETY | rule | 0.22 | 0.06 | 10.3 |
| BLOCKED WHEEL | rule | 0.08 | 0.17 | 42.3 |
| SUPPORT REQUEST | gate | 0.03 | 0.22 | 105.1 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 16.7 |
| PURSUES BIG PREY | rule | 0.03 | 0.19 | 201.5 |
| STOPS SHORT OF THE FLANK | rule | 0.17 | 0.06 | 8.3 |
| AFTERMATH BAND | gate | 0.06 | 0.14 | 1.5 |
| BEST PRIZE | rule | 0.08 | 0.11 | 72.4 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.11 | 53.8 |
| LONE WIZARD HOLDS BACK | rule | 0.11 | 0.08 | 48.7 |
| WAR ENGINE JOBS | rule | 0.17 | - | 54.8 |
| FIGHT ORDER BAND | gate | 0.06 | 0.06 | 1.6 |
| CHAFF PASSED | rule | 0.06 | 0.03 | 3.1 |
| NO REASON | gate | 0.08 | - | 7.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 71.1 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 87.8 |
| DEFENSIVE ARMY | rule | 0.06 | - | 9.3 |
| SAFER THAN THE JOB | rule | 0.06 | - | 18.0 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 24.6 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 15.2 |
| FALLBACK BY WORTH | rule | - | 0.03 | 10.5 |
| MARCH ODDS | rule | - | 0.03 | 2.7 |
| REDIRECT WEIGHED | rule | 0.03 | - | 103.4 |
| STANDS TO CAST | rule | - | 0.03 | 26.1 |

### Plans: fw-h2h-mine-e441028-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.9 | 17% | 733 | 380 | 52% |
| Mine | charge | 2.2 | 71% | 224 | 234 | 104% |
| Mine | close in | 4.7 | 26% | 486 | 136 | 28% |
| Mine | hold | 3.9 | 30% | 264 | 0 | 0% |
| Mine | join | 0.8 | 100% | 43 | 0 | 0% |
| Mine | shoot | 6.7 | 57% | 246 | 485 | 197% |
| Mine | support | 7.8 | 89% | 229 | 0 | 0% |
| Opponent | advance | 16.8 | 15% | 630 | 376 | 60% |
| Opponent | charge | 5.0 | 61% | 532 | 461 | 87% |
| Opponent | close in | 5.4 | 26% | 445 | 127 | 29% |
| Opponent | hold | 4.2 | 40% | 329 | 0 | 0% |
| Opponent | join | 1.1 | 95% | 73 | 0 | 0% |
| Opponent | shoot | 3.2 | 52% | 73 | 175 | 239% |
| Opponent | support | 6.7 | 88% | 205 | 0 | 0% |

### Packages: hunt the guns, fw-h2h-mine-e441028-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 50% | 50% | 0% | 2.5 | 283 | 100 | 50% | 5 |
| Opponent | 0.3 | 11 | 1 | 40% | 40% | 0% | 2.5 | 315 | 81 | 40% | 79 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 645 | 0 | 0% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 60 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.3 | 3 | 0 | 33% | 33% | 0% | 3.0 | 231 | 53 | 33% | 71 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 314 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Tomb Kings of Khemri | 1.0 | 4 | 0 | 50% | 50% | 0% | 2.5 | 229 | 100 | 50% | 0 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 333 | 125 | 50% | 0 |
| Warriors of Chaos | 0.4 | 4 | 1 | 67% | 67% | 0% | 2.5 | 270 | 132 | 67% | 16 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 550 | 0 | 0% | 21 |

### Battle groups: fw-h2h-mine-e441028-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.9 | 30% | 44% | 5% | 0% | 27% | 12% | 10% | 51% | 0% |
| Mine | REDIRECT COUNTER | 2.9 | 36% | 68% | 3% | 100% | 22% | 3% | 22% | 54% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.7 | 15% | 63% | 22% | 44% | 34% | 9% | 9% | 47% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 23% | 81% | 25% | 0% | 22% | 0% | 7% | 63% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h-mine-e441028-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (4) | - | - | 0 (4) |
| Mine | Chaff | 41 | 94 (41) | 62 | 31 | 66 | 32% | 3.0 | 49 (17) | 90 (17) | 225 (7) | 132 (28) | 20 (13) |
| Mine | Character | 105 | 47 (105) | 47 | 0 | 35 | 20% | 2.3 | 43 (35) | 46 (32) | 80 (16) | 51 (62) | 52 (21) |
| Mine | Clean-up | 20 | 41 (20) | 13 | 28 | 47 | 25% | 3.0 | 0 (3) | 65 (13) | 18 (4) | 44 (15) | 29 (5) |
| Mine | Early | 1 | 139 (1) | 139 | 0 | 100 | 0% | 4.0 | - | 139 (1) | - | - | 139 (1) |
| Mine | Fast | 2 | 139 (2) | 139 | 0 | 0 | 50% | 5.0 | 0 (1) | - | 279 (1) | - | 139 (2) |
| Mine | Fast Hammer | 38 | 20 (38) | 16 | 4 | 53 | 21% | 2.9 | 21 (25) | 28 (9) | 0 (4) | 19 (26) | 22 (12) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 58 | 40% | 3.3 | 0 (3) | 0 (2) | - | 0 (1) | 0 (4) |
| Mine | Hammer | 62 | 27 (62) | 15 | 12 | 53 | 15% | 2.3 | 13 (26) | 39 (23) | 34 (13) | 30 (46) | 19 (16) |
| Mine | Holder | 35 | 48 (35) | 16 | 32 | 38 | 26% | 3.1 | 41 (14) | 63 (15) | 33 (5) | 66 (19) | 23 (15) |
| Mine | Shooter | 32 | 79 (32) | 41 | 38 | 59 | 3% | 2.3 | 71 (13) | 91 (12) | 74 (7) | 83 (17) | 74 (15) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 42 (56) | 42 | 0 | 54 | 2% | 1.2 | 63 (22) | 23 (20) | 33 (14) | 56 (34) | 19 (22) |
| Mine | Wizard | 18 | 7 (18) | 7 | 0 | 73 | 11% | 1.8 | 45 (3) | 0 (6) | 0 (3) | 18 (8) | 0 (4) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 77 | 97 (77) | 18 | 79 | 57 | 39% | 3.1 | 28 (28) | 179 (36) | 24 (13) | 99 (65) | 78 (12) |
| Opponent | Character | 97 | 61 (97) | 61 | 0 | 28 | 25% | 2.2 | 55 (47) | 74 (26) | 67 (18) | 61 (53) | 64 (38) |
| Opponent | Clean-up | 20 | 55 (20) | 22 | 33 | 35 | 30% | 3.1 | 25 (9) | 90 (8) | 59 (3) | 62 (17) | 28 (3) |
| Opponent | Fast Hammer | 51 | 30 (51) | 23 | 7 | 50 | 27% | 3.0 | 22 (24) | 36 (12) | 38 (15) | 22 (37) | 48 (14) |
| Opponent | Fragile | 15 | 98 (15) | 98 | 0 | 42 | 13% | 2.6 | 56 (5) | 148 (8) | 0 (2) | 126 (11) | 26 (4) |
| Opponent | Hammer | 64 | 46 (64) | 32 | 14 | 36 | 33% | 3.2 | 36 (26) | 69 (22) | 25 (16) | 46 (46) | 44 (18) |
| Opponent | Holder | 30 | 51 (30) | 15 | 36 | 21 | 53% | 3.9 | 32 (9) | 73 (15) | 26 (5) | 60 (21) | 25 (8) |
| Opponent | Shooter | 33 | 55 (33) | 17 | 38 | 31 | 6% | 1.6 | 33 (15) | 77 (15) | 79 (3) | 45 (21) | 76 (12) |
| Opponent | Support | 6 | 70 (6) | 70 | 0 | 51 | 17% | 4.2 | 212 (2) | 0 (3) | 0 (1) | 0 (1) | 85 (5) |
| Opponent | War machine | 6 | 27 (6) | 27 | 0 | 38 | 0% | 1.7 | 0 (2) | 55 (3) | 0 (1) | 38 (3) | 18 (3) |
| Opponent | Wizard | 20 | 14 (20) | 14 | 0 | 68 | 15% | 1.8 | 0 (8) | 24 (5) | 55 (3) | 24 (8) | 12 (8) |

### Charged fights: fw-h2h-mine-e441028-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 176 | 170 | 2.0 | 1.1 | 85 | 45 | +40 | 4 of 8 | 4 of 8 | +0 | +46 |
| Mine | Chaos Dwarfs | 4 | 210 | 116 | 1.5 | 1.2 | 77 | 70 | +7 | 2 of 6 | 6 of 6 | +234 | -38 |
| Mine | Dwarfen Mountain Holds | 3 | 332 | 20 | 1.0 | 1.3 | 20 | 0 | +20 | 0 of 3 | 2 of 3 | +60 | +0 |
| Mine | Empire of Man | 5 | 407 | 116 | 1.6 | 1.1 | 73 | 63 | +10 | 1 of 8 | 5 of 8 | +60 | +2 |
| Mine | Grand Cathay | 4 | 303 | 386 | 3.8 | 1.2 | 103 | 54 | +49 | 2 of 15 | 13 of 15 | +135 | +28 |
| Mine | High Elf Realms | 4 | 400 | 338 | 2.5 | 1.1 | 135 | 0 | +135 | 4 of 10 | 7 of 10 | +540 | +90 |
| Mine | Kingdom of Bretonnia | 1 | 290 | 825 | 4.0 | 1.0 | 206 | 0 | +206 | 2 of 4 | 3 of 4 | - | +206 |
| Mine | Lizardmen | 1 | 211 | 924 | 4.0 | 1.0 | 231 | 35 | +196 | 3 of 4 | 3 of 4 | - | +196 |
| Mine | Ogre Kingdoms | 2 | 0 | 376 | 3.5 | 1.0 | 108 | 44 | +63 | 4 of 7 | 4 of 7 | - | +63 |
| Mine | Skaven | 2 | 60 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 106 | 563 | 3.0 | 1.3 | 188 | 35 | +152 | 3 of 6 | 5 of 6 | +52 | +202 |
| Mine | Vampire Counts | 2 | 54 | 68 | 2.5 | 1.0 | 27 | 0 | +27 | 1 of 5 | 2 of 5 | - | +27 |
| Mine | Warriors of Chaos | 2 | 0 | 562 | 4.0 | 1.4 | 140 | 0 | +140 | 2 of 8 | 7 of 8 | +133 | +145 |
| **Mine** | all armies | 36 | 231 | 266 | 2.3 | 1.2 | 114 | 33 | +81 | 28 of 84 | 61 of 84 | +139 | +71 |
| Opponent | Empire of Man | 1 | 240 | 594 | 2.0 | 1.0 | 297 | 0 | +297 | 2 of 2 | 2 of 2 | - | +297 |
| Opponent | High Elf Realms | 5 | 168 | 670 | 4.6 | 1.0 | 146 | 13 | +133 | 11 of 23 | 17 of 23 | - | +133 |
| Opponent | Lizardmen | 2 | 0 | 796 | 6.5 | 1.2 | 123 | 38 | +84 | 6 of 13 | 7 of 13 | +94 | +82 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 686 | 5.7 | 1.1 | 121 | 38 | +83 | 6 of 17 | 12 of 17 | +393 | +42 |
| Opponent | Skaven | 4 | 9 | 100 | 1.2 | 1.0 | 80 | 39 | +41 | 4 of 5 | 3 of 5 | - | +41 |
| Opponent | Tomb Kings of Khemri | 2 | 90 | 1216 | 6.0 | 1.1 | 203 | 27 | +176 | 5 of 12 | 5 of 12 | +210 | +172 |
| Opponent | Vampire Counts | 6 | 59 | 180 | 4.7 | 1.2 | 39 | 25 | +14 | 17 of 28 | 10 of 28 | +0 | +16 |
| Opponent | Warriors of Chaos | 7 | 0 | 696 | 4.6 | 1.1 | 152 | 14 | +138 | 13 of 32 | 24 of 32 | +98 | +140 |
| Opponent | Wood Elf Realms | 6 | 52 | 460 | 5.0 | 1.3 | 92 | 15 | +77 | 12 of 30 | 21 of 30 | +36 | +88 |
| **Opponent** | all armies | 36 | 54 | 532 | 4.5 | 1.1 | 118 | 22 | +96 | 76 of 162 | 101 of 162 | +89 | +97 |

### Effective charges: fw-h2h-mine-e441028-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 2 (net +28) | 0 | 1 (net +0) | 2 (net +0) | 0 | 2 (net +175) | 1 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 6 | 0 | 0 | 0 | 0 | 2 (net +162) | 3 (net -94) | 1 | 0% (0 of 5) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 0 | 1 (net +60) | 1 (net +0) | 1 | 0% (0 of 2) |
| Mine | Empire of Man | 8 | 0 | 0 | 3 (net -86) | 1 (net +0) | 1 (net +60) | 3 (net +92) | 0 | 38% (3 of 8) |
| Mine | Grand Cathay | 15 | 1 (net -369) | 0 | 2 (net +164) | 1 (net +540) | 4 (net -24) | 5 (net +67) | 2 | 15% (2 of 13) |
| Mine | High Elf Realms | 10 | 0 | 0 | 1 (net +540) | 1 (net +0) | 1 (net +123) | 6 (net +105) | 1 | 11% (1 of 9) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +140) | 0 | 0 | 3 (net +228) | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net -141) | 0 | 0 | 3 (net +308) | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 7 | 1 (net -34) | 0 | 1 (net -185) | 0 | 0 | 1 (net +393) | 4 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +250) | 2 (net +126) | 0 | 3 (net +138) | 0 | 17% (1 of 6) |
| Mine | Vampire Counts | 5 | 1 (net +0) | 0 | 1 (net +75) | 0 | 2 (net +30) | 0 | 1 | 25% (1 of 4) |
| Mine | Warriors of Chaos | 8 | 0 | 0 | 0 | 4 (net +155) | 2 (net +109) | 2 (net +142) | 0 | 0% (0 of 8) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +594) | 1 | 0% (0 of 1) |
| Opponent | High Elf Realms | 23 | 1 (net +0) | 0 | 3 (net +166) | 8 (net +154) | 2 (net +127) | 5 (net +136) | 4 | 16% (3 of 19) |
| Opponent | Lizardmen | 13 | 0 | 0 | 1 (net +126) | 6 (net +0) | 0 | 2 (net +155) | 4 | 11% (1 of 9) |
| Opponent | Orc & Goblin Tribes | 17 | 2 (net +78) | 0 | 1 (net +306) | 1 (net +786) | 2 (net +0) | 2 (net +68) | 9 | 12% (1 of 8) |
| Opponent | Skaven | 5 | 2 (net +105) | 1 (net -5) | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 12 | 2 (net -130) | 0 | 2 (net +241) | 1 (net +115) | 1 (net +210) | 3 (net +382) | 3 | 22% (2 of 9) |
| Opponent | Vampire Counts | 28 | 5 (net -9) | 0 | 5 (net +2) | 10 (net +52) | 4 (net -15) | 3 (net -17) | 1 | 19% (5 of 27) |
| Opponent | Warriors of Chaos | 32 | 4 (net -9) | 1 (net +0) | 5 (net +127) | 5 (net +213) | 2 (net +68) | 10 (net +153) | 5 | 19% (5 of 27) |
| Opponent | Wood Elf Realms | 30 | 2 (net +126) | 0 | 3 (net -66) | 6 (net +164) | 4 (net +112) | 10 (net +88) | 5 | 12% (3 of 25) |

### Charged fights, damage counted: fw-h2h-mine-e441028-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 118 | 218 | -69 | 91 | 135 | -44 | -37.2 |
| Mine | Effective (55-75%) | 12 | 245 | 182 | +62 | 129 | 65 | +64 | +26.2 |
| Mine | 76-89% | 11 | 219 | 217 | +128 | 138 | 16 | +122 | +55.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 275 | 192 | +125 | 156 | 40 | +116 | +42.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 437 | 87 | +58 | 98 | 53 | +46 | +10.5 |
| Mine | No odds | 11 | 188 | 202 | +22 | 69 | 33 | +37 | +19.5 |
| Mine | All fights | 84 | 268 | 181 | +81 | 126 | 47 | +79 | +29.4 |
| Opponent | Long shot (under 50%) | 18 | 148 | 245 | +15 | 68 | 58 | +9 | +6.2 |
| Opponent | 50-54% | 2 | 154 | 195 | -2 | 155 | 98 | +57 | +37.2 |
| Opponent | Effective (55-75%) | 21 | 275 | 207 | +89 | 120 | 20 | +101 | +36.6 |
| Opponent | 76-89% | 37 | 329 | 209 | +127 | 182 | 42 | +140 | +42.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 338 | 237 | +141 | 180 | 32 | +148 | +43.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 400 | 76 | +66 | 94 | 12 | +82 | +20.6 |
| Opponent | No odds | 32 | 249 | 197 | +79 | 135 | 53 | +82 | +32.8 |
| Opponent | All fights | 162 | 293 | 204 | +96 | 143 | 39 | +104 | +35.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h-mine-e441028-p4 | move | 536 | 123 (23%) | 82 (15%) | 58 (11%) | 355 (66%) |
| fw-h2h-mine-e441028-p4 | objective | 368 | 63 (17%) | 44 (12%) | 48 (13%) | 257 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

import json,os,collections,statistics,math
G=json.load(open(os.path.expanduser("~/an/stance.json")))
def ci(xs): return 1.96*statistics.stdev(xs)/math.sqrt(len(xs)) if len(xs)>1 else float('nan')
out=[]
# 1. per turn, framework side
agg=collections.defaultdict(lambda: collections.Counter())
for g in G:
  fw,off=g['fw'],g['off']
  for k,dfn in g['stance'].items():
    s,t=k.split('|')
    if s!=fw: continue
    lab="defensive" if dfn else "offensive"
    c=agg[lab]; c['turns']+=1
    c['shoot']+=g['src'].get(f"{fw}|{t}|shoot",0); c['fight']+=g['src'].get(f"{fw}|{t}|fight",0)
    c['lost_shoot']+=g['src'].get(f"{off}|{t}|shoot",0); c['lost_fight']+=g['src'].get(f"{off}|{t}|fight",0)
out+=["### Framework side, per turn by its stance that turn","","| Stance | Turns | VP won by shooting + magic a turn | VP won in fights a turn | VP lost to shooting + magic a turn | VP lost in fights a turn | Net kills a turn |","| --- | --- | --- | --- | --- | --- | --- |"]
for lab in ("defensive","offensive"):
  c=agg[lab]; n=max(1,c['turns'])
  out.append(f"| {lab} | {c['turns']} | {c['shoot']/n:.0f} | {c['fight']/n:.0f} | {c['lost_shoot']/n:.0f} | {c['lost_fight']/n:.0f} | {(c['shoot']+c['fight']-c['lost_shoot']-c['lost_fight'])/n:+.0f} |")
# 2. army label: share of framework turns defensive
lab={}
for g in G:
  ts=[v for k,v in g['stance'].items() if k.split('|')[0]==g['fw']]
  lab[(g['pair'],g['sc'],g['army'][g['fw']])]="defensive" if ts and sum(ts)/len(ts)>=0.5 else "offensive"
rows=[]
for g in G:
  fl=lab[(g['pair'],g['sc'],g['army'][g['fw']])]
  ol=lab.get((g['pair'],g['sc'],g['army'][g['off']]),"?")
  def s(side,kind): return sum(v for k,v in g['src'].items() if k.split('|')[0]==side and k.split('|')[2]==kind)
  rows.append(dict(fl=fl,ol=ol,m=g['vp'][g['fw']]-g['vp'][g['off']],fs=s(g['fw'],'shoot'),ff=s(g['fw'],'fight'),os=s(g['off'],'shoot'),of=s(g['off'],'fight'),fo=g['obj'][g['fw']],oo=g['obj'][g['off']]))
out+=["","### By army type (an army is defensive when it played defensive in half or more of its turns with the framework; the same label is used for it when it played without)","",
"| Framework army | Other army | Games | Framework VP margin a game | Framework won / drew / lost | Framework VP by shooting + magic | Framework VP in fights | Framework VP from objectives | Other VP by shooting + magic | Other VP in fights | Other VP from objectives |","| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |"]
for fl in ("defensive","offensive","all"):
  for ol in ("defensive","offensive","all"):
    rs=[r for r in rows if (fl=="all" or r['fl']==fl) and (ol=="all" or r['ol']==ol)]
    if not rs: continue
    n=len(rs); w=sum(r['m']>0 for r in rs); l=sum(r['m']<0 for r in rs)
    mm=statistics.mean(r['m'] for r in rs)
    band=f" (±{ci([r['m'] for r in rs]):.0f})" if n>1 else ""
    out.append(f"| {fl} | {ol} | {n} | {mm:+.0f}{band} | {w} / {n-w-l} / {l} | "+" | ".join(f"{statistics.mean(r[k] for r in rs):.0f}" for k in ('fs','ff','fo','os','of','oo'))+" |")
print("\n".join(out))

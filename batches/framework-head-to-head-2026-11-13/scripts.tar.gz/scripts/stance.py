"""Head-to-head: VP by source split by army stance. Usage: stance.py <root with fwmine-*/fwopp-* part folders>"""
import sys,os,glob,json,collections,statistics,math,importlib.util,csv
spec=importlib.util.spec_from_file_location("cb","/home/user/WarhammerOldWorldSimulator/scripts/compare-batches.py")
cb=importlib.util.module_from_spec(spec); sys.argv_saved=sys.argv; spec.loader.exec_module(cb)
D=sys.argv[1]
games=[]  # one per game
for arm in ("fwmine","fwopp"):
  fwside="Mine" if arm=="fwmine" else "Opponent"
  for bd in sorted(os.path.dirname(x) for x in glob.glob(f"{D}/{arm}-*/games.csv")+glob.glob(f"{D}/{arm}-*/*/games.csv")):
    if not os.path.isdir(bd): continue
    recs=cb._records_by_game(bd)
    gcsv={ (r['pair'],r['scenario']):r for r in csv.DictReader(open(f"{bd}/games.csv"))}
    for name in sorted(os.listdir(bd)):
      if not(name.startswith("game-") and name.endswith(".log.jsonl")): continue
      pair,sc=name[5:].split('-')[0],name[5:].split('-')[1]
      acts=[]; boardarm={}
      for line in open(os.path.join(bd,name)):
        try: d=json.loads(line)
        except ValueError: continue
        if d.get("kind")=="action": acts.append(d)
        elif d.get("kind")=="board": boardarm={"Mine":d.get("mine"),"Opponent":d.get("opponent")}
      names={a.get("actor") for a in acts}|{a.get("target") for a in acts}
      def fit(u):
        return min(len(names & {n for n,x in u.items() if x["side"]==s})/max(1,sum(1 for x in u.values() if x["side"]==s)) for s in ("Mine","Opponent"))
      gid,units=max(recs.items(),key=lambda kv:fit(kv[1]),default=(None,None))
      if not units or fit(units)<0.6: print("no record",bd,name,file=sys.stderr); continue
      stance={}
      for a in acts:
        t=a.get("summary") or ""
        if a.get("type")=="ArmyStance" and t.startswith("ARMY STANCE:"):
          stance.setdefault((a.get("side"),a.get("turn")),": defensive" in t[:30])
      src=collections.defaultdict(float)  # (side,round,kind)->VP won
      for u in units.values():
        if not u["gone"] or u["round"] is None: continue
        winner="Opponent" if u["side"]=="Mine" else "Mine"
        kind="shoot" if u["cause"] in cb.GONE_TO_SHOOTING else "fight" if u["cause"] in cb.GONE_IN_FIGHT else "other"
        src[(winner,u["round"],kind)]+=u["vp"]
      r=gcsv.get((pair,sc))
      if r is None: continue
      m,o=map(int,r['vp_mine_opponent'].split('-'))
      vp={"Mine":m,"Opponent":o}
      obj={"Mine":int(r['vp_objectives_mine'] or 0),"Opponent":int(r['vp_objectives_opponent'] or 0)}
      games.append(dict(arm=arm,fw=fwside,off="Opponent" if fwside=="Mine" else "Mine",pair=pair,sc=sc,stance=stance,src=src,vp=vp,obj=obj,army=boardarm))
json.dump([dict(g,stance={f"{k[0]}|{k[1]}":v for k,v in g['stance'].items()},src={f"{k[0]}|{k[1]}|{k[2]}":v for k,v in g['src'].items()}) for g in games],open(os.path.expanduser("~/an/stance.json"),"w"))
print(len(games),"games read")

import csv,glob,sys,statistics,math,collections
D='/mnt/project-files/framework-head-to-head-2026-11-13'
rows=[]
for arm in ('fwmine','fwopp'):
  for f in sorted(glob.glob(f'{D}/{arm}-*/games.csv')+glob.glob(f'{D}/{arm}-*/*/games.csv')):
    for r in csv.DictReader(open(f)):
      if r['ended']!='yes' or not r['vp_mine_opponent']: print('not ended',arm,r['pair'],r['scenario']); continue
      m,o=map(int,r['vp_mine_opponent'].split('-'))
      fw,off=(m,o) if arm=='fwmine' else (o,m)
      win={'Mine':'mine','Opponent':'opp','draw':'draw'}.get(r['winner'],r['winner'])
      res='draw' if win=='draw' else ('W' if (win=='mine')==(arm=='fwmine') else 'L')
      rows.append(dict(arm=arm,pair=r['pair'],sc=r['scenario'],margin=fw-off,res=res,ended=r['ended'],first=r['first_player'],
        fwfirst=(r['first_player']=='Mine')==(arm=='fwmine')))
def summ(rs,label):
  ms=[r['margin'] for r in rs]; n=len(ms)
  if n<2: return
  mu=statistics.mean(ms); se=statistics.stdev(ms)/math.sqrt(n)
  c=collections.Counter(r['res'] for r in rs)
  print(f"{label}: n={n} margin {mu:+.0f} VP/game (±{1.96*se:.0f} 95%), W/D/L {c['W']}/{c['draw']}/{c['L']}")
summ(rows,'ALL')
for a in ('fwmine','fwopp'): summ([r for r in rows if r['arm']==a],a)
summ([r for r in rows if r['fwfirst']],'fw went first'); summ([r for r in rows if not r['fwfirst']],'fw went second')
# matched: same pair+scenario both arms
k=collections.defaultdict(dict)
for r in rows: k[(r['pair'],r['sc'])][r['arm']]=r['margin']
mm=[v['fwmine']+v['fwopp'] for v in k.values() if len(v)==2]
if len(mm)>1: print(f"matched pairs n={len(mm)}: sum of both games {statistics.mean(mm):+.0f} (±{1.96*statistics.stdev(mm)/math.sqrt(len(mm)):.0f}) per pair")
print('not ended:',sum(r['ended']!='yes' for r in rows))

import sys,collections,statistics
sys.path.insert(0,'/home/user/WarhammerOldWorldSimulator/scripts')
import job_claims as jc
out=[]
data={}
for arm,d,fw in (("fwmine","/root/an/m/fwmine-all","Mine"),("fwopp","/root/an/m/fwopp-all","Opponent")):
  import glob,os
  games=0; rows=[]; perg=[]
  for path in sorted(glob.glob(os.path.join(d,"game-*.log.jsonl"))):
    try: g=jc.read_game(path)
    except Exception: continue
    games+=1
    kinds=collections.defaultdict(set)
    for p in g["picks"]:
      s="fw" if p["side"]==fw else "off"
      kinds[s].add(p["kind"])
      rows.append((s,jc.unit_type(g["byname"].get((p["side"],p["unit"]))),p["kind"],p["worth"],jc.happened(g,p)))
    perg.append({s:len(kinds[s]) for s in ("fw","off")})
  data[arm]=(games,rows,perg)
G=sum(v[0] for v in data.values()); rows=[r for v in data.values() for r in v[1]]; perg=[p for v in data.values() for p in v[2]]
out+=[f"{G} games read.","",
 f"Different jobs a side used in a game: framework {statistics.mean(p['fw'] for p in perg):.1f}, no framework {statistics.mean(p['off'] for p in perg):.1f}.",""]
tot={s:set(r[2] for r in rows if r[0]==s) for s in ("fw","off")}
out+=[f"Different jobs used over the batch: framework {len(tot['fw'])} ({', '.join(sorted(tot['fw']))}); no framework {len(tot['off'])} ({', '.join(sorted(tot['off']))}).","",
 "| Job | Side | Picks a game | Share of picks | Claimed (mean VP) | Claimed VP a game | Happened |","| --- | --- | --- | --- | --- | --- | --- |"]
by=collections.defaultdict(list)
for s,_,k,w,h in rows: by[(k,s)].append((w,h))
n={s:sum(1 for r in rows if r[0]==s) for s in ("fw","off")}
for kind,label in jc.JOBS:
  for s,lab in (("fw","framework"),("off","no framework")):
    v=by.get((kind,s))
    if not v: continue
    ws=[w for w,_ in v if w is not None]
    out.append(f"| {label} | {lab} | {len(v)/G:.1f} | {len(v)/n[s]:.0%} | {jc._f(jc._mean(ws),1)} | {sum(ws)/G:.0f} | {jc._happened_text(kind,[h for _,h in v if h])} |")
print("\n".join(out))

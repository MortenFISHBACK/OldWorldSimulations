# Doctrine scorecard: fw-h2h-opp-e441028-p3

### Scorecard: fw-h2h-opp-e441028-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 4 | 0 | 2 | 0 | 0 | 0 | 350 |
| L0110 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 6 | 4 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 1 | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 3 | 6 | 1 | 5 | 0 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 3 | 1 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 3 | 6 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 5 | 1 | 1 | 0 | 0 | 760 |
| L0311 | 5 | 1 | Opponent | yes | - | 4 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 2 | 3 | 5 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 5 | 1 | 2 | 1 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0516 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 475 |
| L0516 | 6 | 1 | Opponent | no | 8 | - | 1 | 0 | 1 | 0 | 0 | 260 |
| L0533 | 5 | 1 | Mine | no | - | 4 | 0 | 0 | 0 | 0 | 0 | 475 |
| L0533 | 5 | 1 | Opponent | yes | - | 4 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 1 | 4 | 3 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Mine | yes | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 375 |
| L0709 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 1 | 0 | 0 | 0 | 540 |
| L0725 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 1 | 0 | 1 | 0 | 0 | 279 |
| L0815 | 5 | 1 | Mine | yes | - | 4 | 3 | 0 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 4 | 4 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0831 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 3 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 1 | 5 | 3 | 0 | 0 | 0 | 0 | 612 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 2 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 7 | 2 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | - | 0 | 1 | 1 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 355 |
| L1122 | 6 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 170 |
| L1216 | 4 | 1 | Mine | no | 8 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 4 | - | 0 | 3 | 1 | 0 | 0 | 260 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 0 | 3 | 0 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 4 | 4 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 4 | 1 | 4 | 1 | 0 | 0 | 0 | 110 |
| L1519 | 1 | 1 | Mine | no | 4 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 3 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 1 | 7 | 0 | 0 | 0 | 0 | 140 |
| L1633 | 1 | 1 | Mine | yes | 10 | 3 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 2 | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Mine | no | 1 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | yes | 5 | 3 | 4 | 1 | 0 | 0 | 0 | 340 |
| L1932 | 6 | 1 | Mine | no | 5 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2033 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2223 | 3 | 1 | Mine | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | yes | 2 | 3 | 4 | 2 | 2 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | no | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2433 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2630 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 6 | 4 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 405 |
| **Average** | | | Mine | 28% | 3.3 | 2.9 | 3.0 | 1.0 | 0.2 | 0.0 | 0.0 | 247.2 |
| **Average** | | | Opponent | 24% | 2.8 | 2.5 | 2.9 | 1.7 | 0.6 | 0.0 | 0.0 | 170.4 |

### KPIs: fw-h2h-opp-e441028-p3

Rules off - Mine only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK.

Morten 2026-11-10; 35 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 162) | 22% (38 of 171) | 11% (38 of 333) |
| Winner chose to follow up after the loser gave ground |  | 95% (87 of 92); on the table 97% | 94% (46 of 49); on the table 96% | 94% (133 of 141); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 92% (11 of 12); on the table 92% | 67% (4 of 6); on the table 67% | 83% (15 of 18); on the table 83% |
| Winner chose to pursue after the loser fled |  | 47% (9 of 19); on the table 58% | 76% (16 of 21); on the table 86% | 62% (25 of 40); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 87% (107 of 123); on the table 90% | 87% (66 of 76); on the table 91% | 87% (173 of 199); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 29% (95 of 324) | 23% (43 of 186) | 27% (138 of 510) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (95 of 212) | 41% (43 of 106) | 43% (138 of 318) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 48% (27 of 56) | 48% (27 of 56) |
| Points that never fought | lower | 36% (22846 of 62804) | 36% (23857 of 65990) | 36% (46703 of 128794) |
|   infantry points that never fought | lower | 45% (5656 of 12525) | 52% (6624 of 12648) | 49% (12280 of 25173) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (137 of 251) | 61% (154 of 253) | 58% (291 of 504) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 2.2 uses a game | 65% (15 of 23); 1.4 uses a game | 77% (37 of 48); 1.8 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.4 uses a game | 17% (1 of 6); 0.1 uses a game | 40% (8 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 21% (3 of 14); 0.1 uses a game | 44% (15 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (26587 of 54312) | 56% (32326 of 58119) | 52% (58913 of 112431) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (19%) | 0.6 (15%) | 1.8 (17%) |
| MARCHED: its unit marched | 1.6 (24%) | 1.0 (24%) | 2.6 (24%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.2 (4%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 2.1 (31%) | 0.6 (14%) | 2.6 (25%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 1.1 (17%) | 1.3 (33%) | 2.4 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.2 | 2.5 | 3.9 | 0.7 | 1.5 |
| not cast | 4.1 | 1.1 | 3.7 | 10.6 | 2.3 | 17.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (56%) | 0.3 (8%) | 1.8 (17%) | 0.3 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.6 (24%) | 0.5 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.2 (9%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (10%) | 0.8 (21%) | 2.6 (25%) | 0.5 (23%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 1.7 (41%) | 0.2 (18%) | 1.0 (27%) | 2.4 (23%) | 0.4 (17%) | 3.7 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (9%) | 0.1 (5%) | 0.2 (5%) | 0.3 (3%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (10%) | 0.1 (2%) | 0.3 (2%) | 0.3 (15%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (41%) | 0.0 (0%) | 1.3 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.8 a game | 1.3 a game |
| stood (cast and not dispelled) | 72% (39 of 54) | 48% (11 of 23) | 65% (50 of 77) |
| the unit moved after it | 56% (22 of 39) | 82% (9 of 11) | 62% (31 of 50) |
| it charged on its next turn | 5% (2 of 39) | 0% (0 of 11) | 4% (2 of 50) |
| the enemy charged it first | 15% (6 of 39) | 0% (0 of 11) | 12% (6 of 50) |
| it fought by the end of its next turn | 8% (3 of 39) | 0% (0 of 11) | 6% (3 of 50) |
| it moved out of a charge the enemy had planned (not charged first) | 10% (4 of 39) | 18% (2 of 11) | 12% (6 of 50) |
| none of these (no charge, no fight, no charge escaped) | 69% (27 of 39) | 82% (9 of 11) | 72% (36 of 50) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (474 of 781) | 53% (300 of 568) | 57% (774 of 1349) |
|   cavalry | 52% (38 of 73) | 48% (48 of 101) | 49% (86 of 174) |
|   character | 46% (51 of 110) | 22% (26 of 119) | 34% (77 of 229) |
|   chariot | 49% (50 of 102) | 50% (16 of 32) | 49% (66 of 134) |
|   infantry | 51% (102 of 201) | 62% (145 of 234) | 57% (247 of 435) |
|   monster | 39% (7 of 18) | 33% (1 of 3) | 38% (8 of 21) |
|   war machine | 82% (226 of 277) | 81% (64 of 79) | 81% (290 of 356) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (29%) | 2.2 (28%) | 4.7 (29%) |
| CHARGED: it charged | 1.4 (16%) | 1.8 (24%) | 3.2 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.4 (5%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.1 (2%) | 0.0 (0%) | 0.2 (1%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.3 (15%) | 0.9 (11%) | 2.1 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.5 (6%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.5 (19%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| OTHER BAR | 0.4 (5%) | 0.2 (3%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 0.6 | 86% | 3.4 pts | 12 pts |
| character | 2.7 | 1.1 | 78% | 6.3 pts | 17 pts |
| chariot | 1.9 | 1.1 | 67% | 12.6 pts | 24 pts |
| infantry | 10.6 | 3.5 | 76% | 7.1 pts | 76 pts |
| monster | 0.3 | 0.1 | 73% | 10.1 pts | 3 pts |
| war machine | 8.5 | 7.1 | 62% | 23.2 pts | 196 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 6.0 | 5.3 |
| Charges that made contact a game | 3.3 | 4.0 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.23 declared, 1.00 contact (26 units) | 0.62 declared, 0.38 contact (16 units) | 1.00 declared, 0.76 contact (42 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.67 declared, 1.33 contact (3 units) | 0.50 declared, 0.36 contact (14 units) | 0.71 declared, 0.53 contact (17 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.37 contact (228 units) | 0.68 declared, 0.46 contact (281 units) | 0.62 declared, 0.42 contact (509 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (40 of 70) | 62% (8 of 13) | 50% (5 of 10) | 57% (53 of 93) |
| Character in a unit | 96% (22 of 23) | 33% (3 of 9) | 67% (2 of 3) | 77% (27 of 35) |
| Character on its own | 81% (35 of 43) | 52% (23 of 44) | 40% (26 of 65) | 55% (84 of 152) |
| Chariot | 82% (9 of 11) | 58% (7 of 12) | - | 70% (16 of 23) |
| Infantry | 62% (40 of 64) | 44% (15 of 34) | 20% (1 of 5) | 54% (56 of 103) |
| Monster | 52% (15 of 29) | 20% (1 of 5) | - | 47% (16 of 34) |
| Monstrous | 62% (5 of 8) | 36% (4 of 11) | - | 47% (9 of 19) |
| War Machines | 67% (29 of 43) | 50% (1 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 93% (14 of 15); on the table 100% | 24% (23 of 96) | 26% | 55% (12 of 22) | 83% (5 of 6); 4.5 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 94% (15 of 16); on the table 94% | 19% (7 of 36) | 37% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (4 of 4); on the table 100% | - | 73% | 79% (19 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (22 of 25); on the table 88% | 33% (10 of 30) | 47% | 61% (36 of 59) | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 76% (22 of 29); on the table 86% | 30% (57 of 192) | 51% | 50% (37 of 74) | 89% (16 of 18); 7.0 uses a game | 50% (2 of 4); 0.5 uses a game | 12% (1 of 8); 0.1 uses a game |
| High Elf Realms | 7 | 87% (20 of 23); on the table 91% | 26% (11 of 42) | 31% | 61% (33 of 54) | 100% (9 of 9); 4.0 uses a game | 25% (3 of 12); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (2 of 2); on the table 100% | - | 69% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Ogre Kingdoms | 1 | 90% (9 of 10); on the table 90% | 33% (2 of 6) | 15% | 29% (2 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (5 of 5); on the table 100% | 33% (4 of 12) | 20% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 1 | - | 33% (2 of 6) | 52% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 6 | 90% (19 of 21); on the table 95% | 17% (1 of 6) | 28% | 38% (10 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 7 | 100% (13 of 13); on the table 100% | 25% (12 of 48) | 20% | 59% (23 of 39) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 76% (26 of 34); on the table 79% | 38% (9 of 24) | 20% | 54% (45 of 84) | 100% (3 of 3); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 4 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 47% | 88% (37 of 42) | 57% (4 of 7); 3.2 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h-opp-e441028-p3, 35 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (39) | 62% (51) | 55% (90) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.83 | 1.51 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.29 | 0.26 | 0.54 |
| ...with the charger already in that arc before they moved (per game) | 0.57 | 0.63 | 1.20 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.37 | 1.17 | 2.54 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.86 | 0.77 | 1.63 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.83 | 7.51 | 14.34 |

### Quality by phase: fw-h2h-opp-e441028-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 0.0 |
| Strategy | Charge objectives carried out (made contact) | 51% (70 of 138) | 46% (68 of 149) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (142 of 316) | 60% (89 of 148) |
| Strategy | Close-in objectives charged next turn | 15% (23 of 151) | 12% (30 of 245) |
| Strategy | Support requests answered (helper made contact too) | 46% (6 of 13) | 50% (9 of 18) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (6 of 10) | 43% (3 of 7) |
| Strategy | Joined characters whose unit fought | 59% (20 of 34) | 29% (4 of 14) |
| Strategy | Lone characters that fought | 75% (68 of 91) | 72% (77 of 107) |
| Movement | Charges halted short of contact | 0.2 | 0.4 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 247.2 | 170.4 |
| Movement | Fights charged into per game | 3.3 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 96, net +204 | 11 of 90, net -92 |
| Movement | Charges with odds: sweet spot (55-75%) | 22 of 96, net +100 | 10 of 90, net +139 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 96, net +32 | 13 of 90, net +76 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 96, net +110 | 34 of 90, net +140 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.6 | 8.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (100 of 267) | 54% (158 of 295) |
| Shooting | Points destroyed by shooting units | 50.3 | 8.8 |
| Shooting | War machine shots | 6.5 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (121 of 226) | 38% (26 of 69) |
| Shooting | Points destroyed by war machines | 95.8 | 10.1 |
| Magic | Magic missiles cast | 1.9 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 48% (31 of 65) | 31% (9 of 29) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.3 |
| Magic | Wounds caused by other spells | 1.4 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 80.3 | 33.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.3 / 0.6 / 0.1 | 1.5 / 0.3 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 344.3 | 317.4 |
| Combat | Points run down | 116.7 | 52.4 |
| Combat | Net points per charged fight, damage counted | +88 | +76 |
| Combat | Net per 100 charger points, damage counted | +26.5 | +26.8 |
| Combat | First round won (charged fights) | 61% | 56% |
| Combat | Net points per charged fight | +85 | +70 |
| Combat | Net points per supported fight / lone fight | +119 / +80 | +114 / +63 |
| Combat | Charged fights on a top-3 enemy unit | 47 of 108 | 54 of 114 |
| Game | Points lost | 535.4 | 835.5 |
| Game | VP from objectives | 531.2 | 462.7 |
| Game | Lone holders (player turns) | 3.3 | 2.8 |

- Mine won / drew / lost: 18 / 6 / 9 of 33 ended games (of 35); mean margin (Mine - Opponent) +368 VP
- The side that went first won 15 of 27 games with a winner
- Points traded per game (both sides' losses): 1371
- Games not ended: 2 (L2033-1, L2433-1); findings 8, warnings 0

### Opponent rules: fw-h2h-opp-e441028-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 12.1 | 0.3 | +0.0 | 0.0 | 4.7 |
| BACKUP TARGETS | 1.0 | +7.7 | 0.0 | 17.6 | 1.2 | +11.5 | 0.0 | 11.3 |
| BEST FACING | - | - | - | - | 0.5 | +22.8 | 0.0 | 4.3 |
| BEST FIRST | - | - | - | - | 2.4 | +104.0 | 48.6 | 47.6 |
| BEST OVERALL | 0.5 | +30.0 | 0.0 | 29.2 | 0.7 | +65.0 | 0.0 | 22.1 |
| BEST PREY | 4.5 | +275.2 | 268.9 | 84.1 | 0.8 | +36.8 | 38.9 | 3.9 |
| BEST PRIZE | 0.1 | -4.8 | 4.6 | 0.0 | 0.2 | -5.9 | 7.2 | 6.6 |
| BIG CHARACTER SAFETY | 0.1 | -0.6 | 0.0 | 0.0 | 0.2 | -1.6 | 0.0 | 24.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 11.6 | 10.0 |
| BLOCKED WHEEL | 0.4 | +11.5 | 0.0 | 3.1 | 0.4 | +7.6 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 105.9 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 5.1 | +219.9 | 392.0 | 95.4 | 1.4 | +50.0 | 25.8 | 15.9 |
| CARRIES OUT SET-UP | 0.1 | -0.1 | 33.2 | 0.0 | 0.1 | -1.3 | 24.9 | 12.3 |
| CAST JOB | 0.6 | +21.7 | 31.2 | 19.7 | 0.2 | +1.7 | 23.1 | 12.6 |
| CASTING BLOCK | 0.3 | +18.5 | 14.9 | 2.7 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.1 | +0.0 | 0.0 | 69.9 | 0.3 | +0.0 | 0.0 | 7.8 |
| CATCH FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -1.1 | 0.0 | 0.0 | 0.2 | -0.7 | 5.6 | 1.9 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +1.6 | 7.2 | 0.0 |
| CHARGE NOW WEIGHED | 0.7 | -90.8 | 43.2 | 3.8 | 0.5 | -57.5 | 12.1 | 39.1 |
| CHARIOT NO STATIC JOB | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.5 | 0.0 | 0.0 | 0.1 | -2.0 | 0.0 | 34.1 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 1.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 1.4 | 26.0 | 0.6 | +0.0 | 25.0 | 73.8 |
| CONVEYANCE SEARCH | 1.1 | +194.0 | 27.0 | 69.9 | 0.6 | +62.7 | 5.4 | 13.3 |
| COUNTER-CHARGE COVER | 6.8 | +561.1 | 0.0 | 107.0 | 8.4 | +788.6 | 0.0 | 149.5 |
| DEFENSIVE ARMY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +3.1 | 18.4 | 0.0 | 0.1 | +0.7 | 3.2 | 10.5 |
| ELIXIR WORTH | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +121.2 | 0.0 | 55.2 | 1.2 | +83.8 | 0.0 | 61.0 |
| FALLBACK BY WORTH | 6.1 | +105.1 | 0.0 | 73.1 | 5.1 | +90.4 | 0.0 | 53.4 |
| FIGHT LIFT | 0.1 | +0.2 | 1.8 | 10.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.5 | 0.0 | 4.7 | - | - | - | - |
| FLANK NOT WEIGHED | 6.5 | +0.0 | 0.0 | 145.9 | 6.9 | +0.0 | 0.0 | 152.3 |
| FOCUS FIRE | 0.0 | +1.6 | 1.9 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.6 | +259.2 | 0.0 | 38.0 | 0.9 | +155.4 | 0.0 | 21.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +17.8 | 0.0 | 13.8 | 0.3 | +16.0 | 0.0 | 2.1 |
| GIVES UP | 1.5 | -37.4 | 240.7 | 14.1 | 1.1 | -59.2 | 129.6 | 51.1 |
| GIVES UP ITS SCREEN | 0.4 | -9.7 | 28.2 | 11.4 | 0.1 | -1.7 | 7.2 | 3.3 |
| GROUND FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 7.3 | 0.0 | 0.1 | +0.0 | 9.9 | 1.1 |
| HELPER UNSEEN | 0.3 | +0.0 | 78.0 | 1.3 | 0.2 | +0.0 | 27.0 | 3.1 |
| HILL BY ITS CHANCE | - | - | - | - | 0.4 | -45.0 | 0.0 | 2.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.3 | +7.7 | 29.6 | 15.1 | 0.2 | +17.3 | 3.7 | 6.6 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 3.1 | 0.1 | +0.0 | 9.9 | 3.3 |
| HUNT IN PAIRS | 0.5 | +21.4 | 0.0 | 0.0 | 0.5 | +41.4 | 0.0 | 19.9 |
| HUNT KEPT | 0.1 | +3.6 | 4.7 | 4.8 | 0.1 | +14.0 | 3.7 | 6.6 |
| HUNT RESULT | 0.2 | +35.9 | 0.0 | 5.6 | 0.2 | +13.6 | 17.0 | 6.6 |
| HUNT THE GUNS | 0.2 | +88.1 | 24.9 | 10.3 | 0.2 | +89.3 | 7.3 | 6.6 |
| INVITES THE FIGHT | - | - | - | - | 2.4 | +166.2 | 23.4 | 54.8 |
| JOINT CHARGE PLAN | 0.1 | +0.8 | 5.9 | 0.0 | 0.1 | +6.6 | 0.0 | 5.6 |
| KEEP FALLS | 0.2 | +1.6 | 0.0 | 12.5 | - | - | - | - |
| KEEPS ITS PREY | 0.2 | +1.6 | 12.5 | 5.6 | 0.1 | +0.4 | 0.0 | 3.3 |
| KEEPS ITS TARGET | 1.8 | +54.0 | 209.9 | 2.7 | 2.2 | +66.9 | 185.2 | 70.7 |
| KILLS COUNT | 1.9 | +124.4 | 208.7 | 47.5 | 1.7 | +81.8 | 124.6 | 23.1 |
| KILLS COUNT NEXT TURN | 9.7 | +293.5 | 540.6 | 132.9 | 7.7 | +235.1 | 417.1 | 236.3 |
| LONE CHARACTER SAFE SPOT | 0.7 | +35.2 | 14.4 | 3.0 | 0.5 | +13.5 | 35.7 | 21.3 |
| LONE WIZARD HOLDS BACK | 0.7 | +0.0 | 3.9 | 49.9 | 1.3 | +0.0 | 8.1 | 30.3 |
| LONG SHOT | - | - | - | - | 0.3 | +6.2 | 19.5 | 3.1 |
| LOST CHARGE | - | - | - | - | 2.3 | -46.7 | 159.0 | 72.2 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +3.5 | 17.0 | 0.0 | 1.3 | +94.1 | 53.8 | 21.2 |
| MANOEUVRE | 0.1 | +7.2 | 0.0 | 0.0 | 0.3 | +2.6 | 0.0 | 13.7 |
| MARCH AT ESCAPER | 0.2 | +2.5 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 1.1 | +57.0 | 0.0 | 0.0 | 0.3 | +25.6 | 0.0 | 12.4 |
| MARCH ODDS | 0.7 | +41.5 | 55.5 | 28.2 | 0.1 | +6.5 | 0.0 | 3.0 |
| MARCH OVER CASTS | 0.8 | +43.3 | 0.0 | 4.6 | 0.5 | +14.0 | 0.0 | 37.7 |
| MAX FOR POSITIONING | 4.2 | +151.3 | 0.0 | 62.7 | 5.4 | +267.6 | 0.0 | 136.3 |
| MISSILES IN THE MOVE | 4.2 | +106.4 | 0.0 | 82.8 | 2.9 | +42.9 | 0.0 | 95.3 |
| MISSILES NEXT TURN | 5.3 | +89.4 | 0.0 | 89.9 | 3.8 | +47.4 | 0.0 | 165.1 |
| MODEL FACING | 0.2 | +38.7 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 5.9 | 0.0 | 0.1 | +0.0 | 10.5 | 13.3 |
| MOVE AND CAST | 0.2 | +12.7 | 0.0 | 0.0 | 0.1 | +2.6 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.8 | +29.4 | 0.0 | 44.9 | 0.3 | +7.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.7 | -41.3 | 21.0 | 37.4 | 0.3 | -7.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 23.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 8.0 | +584.0 | 359.6 | 218.1 |
| MOVES UNITS SPELL | 0.1 | +3.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +8.4 | 4.3 | 0.0 | 0.1 | +10.9 | 28.7 | 0.0 |
| NOT NEEDED | 0.3 | -9.9 | 20.0 | 0.0 | 0.3 | -23.5 | 41.6 | 0.0 |
| NOT TURNED | 6.8 | +138.9 | 0.0 | 102.9 | 7.5 | +134.6 | 0.0 | 122.2 |
| NOT WORTH A CAST | 0.5 | -0.2 | 0.0 | 0.0 | 0.3 | -5.4 | 0.0 | 29.4 |
| OFF BEST | 17.9 | -967.2 | 63.7 | 268.5 | 12.9 | -718.1 | 0.0 | 252.2 |
| OPENS A LANE | 0.3 | +1.1 | 34.7 | 0.0 | 0.1 | +0.6 | 6.2 | 0.0 |
| OPENS UP | 0.2 | +6.8 | 5.0 | 0.0 | 0.1 | +13.4 | 6.1 | 8.1 |
| OVERRUNS AWAY | 0.7 | +17.8 | 99.9 | 1.0 | 0.5 | +21.9 | 46.2 | 19.7 |
| PATHS CROSS | 2.3 | +162.1 | 0.0 | 52.1 | 3.4 | +228.1 | 0.0 | 40.6 |
| PIVOT GUARDS FLANK | 0.1 | -4.3 | 0.0 | 3.2 | 0.1 | -1.9 | 0.0 | 10.2 |
| PLAN RESULT | 38.0 | +1795.4 | 1922.2 | 714.6 | 37.9 | +906.1 | 1337.9 | 1120.9 |
| PURSUES BIG PREY | 0.0 | -2.8 | 0.0 | 0.0 | 0.1 | -4.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.5 | 0.0 | 1.6 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.6 | +15.4 | 0.0 | 46.0 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.5 | -41.0 | 68.0 | 9.7 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.4 | -1.1 | 0.0 | 3.5 |
| REDIRECT COUNTER | 3.2 | +198.6 | 0.0 | 52.9 | 3.3 | +343.5 | 0.0 | 55.9 |
| REDIRECT WEIGHED | 0.3 | +10.6 | 13.2 | 0.0 | 0.7 | +15.1 | 14.4 | 16.6 |
| RESERVE FALL BACK | - | - | - | - | 0.5 | +11.5 | 0.0 | 14.9 |
| RESTRAINS TO SHOOT | 0.2 | +12.2 | 0.0 | 6.3 | 0.1 | +10.3 | 0.0 | 4.1 |
| RISK BY ARC | 2.6 | +82.6 | 320.5 | 9.1 | 2.4 | +42.3 | 239.6 | 85.5 |
| SAFER THAN THE JOB | 0.9 | +48.9 | 0.0 | 20.2 | 0.8 | +64.1 | 0.0 | 4.4 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -10.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.6 | +82.5 | 0.0 | 15.9 | 4.2 | +180.5 | 0.0 | 74.3 |
| SECOND HUNTER | 0.1 | -1.2 | 4.7 | 0.0 | 0.0 | -1.5 | 0.0 | 3.3 |
| SELF MOVE SPELL | 0.5 | +60.5 | 0.0 | 18.6 | 0.2 | +53.0 | 0.0 | 41.2 |
| SET UP TOGETHER | 0.7 | +35.1 | 22.9 | 3.3 | 2.0 | +145.6 | 93.4 | 38.2 |
| SET-UP ANY TARGET | 0.7 | +112.3 | 23.9 | 29.3 | 0.2 | +23.0 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +22.9 | 0.0 | 2.7 | 0.1 | +14.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.4 | +6.9 | 34.6 | 14.1 |
| SHOT REPLANNED | 0.4 | +0.0 | 68.9 | 2.8 | 0.1 | +0.0 | 1.5 | 0.0 |
| SHOTS IN THE MOVE | 12.9 | +604.9 | 0.0 | 160.9 | 8.6 | +181.8 | 0.0 | 151.8 |
| SPELL CATCH ODDS | 0.1 | -0.5 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.8 | +141.8 | 23.9 | 29.3 | 0.2 | +45.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +29.5 | 65.5 | 75.4 | 1.7 | +24.8 | 139.3 | 139.3 |
| STABLE ROLE | - | - | - | - | 10.9 | +0.0 | 308.3 | 179.6 |
| STANDS TO CAST | 0.0 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +25.1 | 7.3 | 6.6 |
| STOPS SHORT OF THE FLANK | 0.5 | +32.7 | 0.0 | 6.1 | 0.5 | +25.3 | 0.0 | 48.6 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORTS | - | - | - | - | 7.9 | +284.4 | 320.3 | 134.8 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.0 | 5.9 | 0.0 | 0.1 | -2.1 | 15.9 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +1.8 | 12.3 | 0.0 | 0.9 | -6.4 | 34.1 | 20.2 |
| THROUGH LINE OF FIRE | 0.4 | +15.9 | 0.0 | 0.0 | 0.2 | +5.1 | 0.0 | 9.4 |
| TURN WORTH | 0.4 | -34.0 | 42.9 | 0.0 | 0.3 | -13.5 | 21.8 | 22.4 |
| TWO OR MORE ARRIVE | 0.3 | +0.8 | 5.9 | 0.0 | 0.5 | +2.2 | 18.6 | 8.0 |
| WALKS TO THE FIGHT | - | - | - | - | 1.0 | +38.6 | 21.3 | 22.4 |
| WAR ENGINE JOBS | - | - | - | - | 0.4 | +0.0 | 3.7 | 6.4 |
| WEARS DOWN | 0.9 | +31.9 | 136.8 | 5.0 | 1.3 | +44.5 | 164.7 | 55.7 |
| WHO HITS BACK | 0.3 | +29.0 | 0.0 | 11.7 | 0.1 | +3.7 | 0.0 | 4.9 |
| WHOLE FIGHT | 0.5 | +17.4 | 74.4 | 0.0 | 0.4 | +19.0 | 83.4 | 13.9 |
| WHOLE FIGHT GAIN | 0.3 | +24.6 | 39.4 | 2.4 | 0.5 | +58.6 | 51.5 | 6.1 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |

### Rule changes: fw-h2h-opp-e441028-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1077 | 1077 | 1077 | 30.77 | -58987 | -54.8 |
| SEARCH SPOT | 204 | 204 | 202 | 5.77 | +9214 | +45.6 |
| PATHS CROSS | 198 | 198 | 198 | 5.66 | +13659 | +69.0 |
| MOVE TO CHARGE | 281 | 281 | 148 | 4.23 | +7158 | +48.4 |
| KILLS COUNT NEXT TURN | 609 | 604 | 143 | 4.09 | +3181 | +22.2 |
| COUNTER-CHARGE COVER | 530 | 293 | 140 | 4.00 | +7913 | +56.5 |
| SUPPORTS | 275 | 275 | 140 | 4.00 | +3202 | +22.9 |
| FALLBACK BY WORTH | 394 | 394 | 93 | 2.66 | +6841 | +73.6 |
| FOLLOW UP WEIGHED | 90 | 90 | 90 | 2.57 | +14510 | +161.2 |
| FACES THE THREAT | 89 | 89 | 89 | 2.54 | +7176 | +80.6 |
| BEST FIRST | 83 | 83 | 83 | 2.37 | +3639 | +43.8 |
| BEST PREY | 184 | 182 | 81 | 2.31 | +3418 | +42.2 |
| SHOTS IN THE MOVE | 752 | 490 | 62 | 1.77 | +1170 | +18.9 |
| SAFER THAN THE JOB | 57 | 57 | 57 | 1.63 | +3955 | +69.4 |
| REDIRECT COUNTER | 226 | 125 | 55 | 1.57 | +4714 | +85.7 |
| ARTILLERY RE-ROLL WEIGHED | 48 | 48 | 48 | 1.37 | +0 | +0.0 |
| BEST OVERALL | 44 | 44 | 44 | 1.26 | +3326 | +75.6 |
| CHARGE NOW WEIGHED | 44 | 44 | 44 | 1.26 | +5321 | +120.9 |
| INVITES THE FIGHT | 83 | 83 | 44 | 1.26 | +1955 | +44.4 |
| RISK BY ARC | 174 | 162 | 44 | 1.26 | +1689 | +38.4 |
| MARCH CHECK | 50 | 47 | 41 | 1.17 | +2307 | +56.3 |
| COMBAT PIVOT | 38 | 38 | 38 | 1.09 | +0 | +0.0 |
| MAX FOR POSITIONING | 337 | 189 | 38 | 1.09 | +542 | +14.3 |
| HOLDS AMBUSHERS | 36 | 36 | 36 | 1.03 | +0 | +0.0 |
| REDIRECT WEIGHED | 36 | 36 | 36 | 1.03 | +2388 | +66.3 |
| STOPS SHORT OF THE FLANK | 35 | 35 | 35 | 1.00 | +2031 | +58.0 |
| KILLS COUNT | 125 | 119 | 34 | 0.97 | +1915 | +56.3 |
| MISSILES IN THE MOVE | 249 | 129 | 34 | 0.97 | +483 | +14.2 |
| SET UP TOGETHER | 96 | 80 | 32 | 0.91 | +1700 | +53.1 |
| KEEPS ITS TARGET | 141 | 140 | 30 | 0.86 | +565 | +18.8 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.77 | +668 | +24.7 |
| MARCH ODDS | 30 | 29 | 27 | 0.77 | +439 | +16.3 |
| RANDOM MOVE BY FIGURES | 56 | 56 | 27 | 0.77 | +540 | +20.0 |
| CANNON PLANNED TARGET | 226 | 226 | 26 | 0.74 | -74 | -2.8 |
| LONE WIZARD HOLDS BACK | 71 | 71 | 26 | 0.74 | -297 | -11.4 |
| WALKS TO THE FIGHT | 36 | 36 | 25 | 0.71 | +541 | +21.6 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.63 | +736 | +33.5 |
| FRIENDS SHOTS CHECKED | 20 | 20 | 20 | 0.57 | +1180 | +59.0 |
| BEST FACING | 18 | 18 | 18 | 0.51 | +797 | +44.3 |
| WEARS DOWN | 74 | 69 | 17 | 0.49 | +497 | +29.2 |
| RESERVE FALL BACK | 16 | 16 | 16 | 0.46 | +401 | +25.1 |
| SHOT REPLANNED | 16 | 16 | 16 | 0.46 | +0 | +0.0 |
| WHO HITS BACK | 16 | 16 | 16 | 0.46 | +690 | +43.1 |
| WHOLE FIGHT GAIN | 27 | 24 | 16 | 0.46 | +1198 | +74.9 |
| CAST JOB | 30 | 30 | 15 | 0.43 | +257 | +17.1 |
| CHAFF PASSED | 12 | 12 | 12 | 0.34 | -63 | -5.2 |
| MAKE SURE TOGETHER | 56 | 32 | 12 | 0.34 | +595 | +49.6 |
| MOVE AND CAST | 12 | 12 | 12 | 0.34 | +535 | +44.6 |
| RESTRAINS TO SHOOT | 12 | 12 | 12 | 0.34 | +786 | +65.5 |
| BEST PRIZE | 10 | 10 | 10 | 0.29 | -709 | -70.9 |
| MANOEUVRE | 15 | 15 | 10 | 0.29 | +343 | +34.3 |
| BIG CHARACTER SAFETY | 9 | 9 | 9 | 0.26 | -78 | -8.7 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.26 | -217 | -24.1 |
| WHOLE FIGHT | 31 | 29 | 9 | 0.26 | +490 | +54.4 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.23 | -251 | -31.3 |
| CASTING BLOCK | 11 | 11 | 7 | 0.20 | +294 | +41.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.20 | +141 | +20.1 |
| BACKUP TARGETS | 75 | 30 | 6 | 0.17 | +18 | +3.0 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 19 | 19 | 6 | 0.17 | -712 | -118.8 |
| HUNT ADVANCE | 18 | 18 | 6 | 0.17 | +209 | +34.8 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +310 | +51.8 |
| MISSILES NEXT TURN | 319 | 166 | 6 | 0.17 | +111 | +18.4 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +1355 | +225.8 |
| OPENS UP | 11 | 10 | 6 | 0.17 | +163 | +27.2 |
| OVERRUNS AWAY | 42 | 40 | 6 | 0.17 | +213 | +35.6 |
| STUCK PIVOT | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| WAR ENGINE JOBS | 13 | 13 | 6 | 0.17 | -350 | -58.3 |
| HUNT IN PAIRS | 34 | 18 | 5 | 0.14 | +274 | +54.8 |
| NEEDED THERE | 8 | 6 | 5 | 0.14 | +0 | +0.0 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -268 | -67.0 |
| LOST CHARGE | 81 | 80 | 3 | 0.09 | +64 | +21.3 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 3 | 0.09 | +28 | +9.3 |
| STOPS | 4 | 4 | 3 | 0.09 | +650 | +216.7 |
| CARRIES OUT SET-UP | 8 | 8 | 2 | 0.06 | -48 | -23.9 |
| DEFENSIVE ARMY | 10 | 10 | 2 | 0.06 | -3 | -1.4 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +17 | +8.6 |
| GIVES UP | 89 | 81 | 2 | 0.06 | +38 | +19.2 |
| HILL BY ITS CHANCE | 13 | 13 | 2 | 0.06 | +64 | +31.9 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +12 | +6.0 |
| LONG SHOT | 11 | 11 | 2 | 0.06 | +54 | +27.2 |
| MOVE SPELL IN RANGE | 39 | 23 | 2 | 0.06 | +34 | +17.0 |
| REDIRECT BY WHAT IT STOPS | 14 | 14 | 2 | 0.06 | +84 | +42.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +27 | +27.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -10 | -9.6 |
| EDGE GIVE GROUND | 6 | 6 | 1 | 0.03 | +18 | +18.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +22 | +22.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +56 | +56.1 |
| JOINT CHARGE PLAN | 6 | 6 | 1 | 0.03 | +103 | +102.8 |
| KEEPS ITS PREY | 10 | 8 | 1 | 0.03 | +4 | +4.0 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +18 | +17.8 |
| SECOND HUNTER | 3 | 3 | 1 | 0.03 | +33 | +33.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -48 | -48.2 |
| TWO OR MORE ARRIVE | 27 | 27 | 1 | 0.03 | +1 | +0.7 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -1 | -1.3 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 50 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 60 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 469 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 18 | 18 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 19 | 19 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 14 | trace | - | - | - | - |
| HUNT THE GUNS | 15 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 42 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 45 | 45 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 35 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 502 | 502 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 29 | not checked | - | - | - | - |
| OPENS A LANE | 15 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 2658 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 18 | 18 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 30 | not checked | - | - | - | - |
| SET-UP MISSED | 9 | trace | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 36 | not checked | - | - | - | - |
| SPELL WORTH | 98 | not checked | - | - | - | - |
| STABLE ROLE | 383 | 383 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 40 | 33 | 0 | 0.00 | - | - |
| TURN WORTH | 24 | 22 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h-opp-e441028-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.29 | 11.00 | 56.5 |
| FALLBACK | gate | 0.83 | 0.66 | 51.9 |
| TURN GATE | gate | 0.23 | 0.83 | 51.4 |
| RULE SWITCHED OFF | gate | 0.77 | - | 11.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.34 | 0.26 | 71.1 |
| BEST PRIZE | rule | 0.11 | 0.17 | 70.9 |
| CHAFF PASSED | rule | 0.09 | 0.17 | 7.0 |
| PATHS CROSS | rule | 0.06 | 0.20 | 27.6 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.11 | 24.1 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.17 | 9.9 |
| SUPPORT REQUEST | gate | 0.14 | 0.09 | 71.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.09 | 31.3 |
| AFTERMATH BAND | gate | 0.17 | 0.03 | 2.6 |
| CANNON PLANNED TARGET | rule | 0.06 | 0.11 | 67.4 |
| CHARIOT NO STATIC JOB | rule | 0.17 | - | 118.8 |
| THROUGH LINE OF FIRE | rule | 0.09 | 0.09 | 46.6 |
| WAR ENGINE JOBS | rule | - | 0.17 | 58.3 |
| BLOCKED WHEEL | rule | 0.09 | 0.06 | 15.2 |
| LONE WIZARD HOLDS BACK | rule | 0.06 | 0.09 | 59.4 |
| PURSUES BIG PREY | rule | 0.03 | 0.09 | 67.0 |
| REDIRECT WEIGHED | rule | - | 0.11 | 105.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.09 | 8.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.09 | - | 13.9 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.06 | 13.6 |
| FACES THE THREAT | rule | - | 0.09 | 10.2 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 23.9 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | - | 3.3 |
| CATCH ODDS | rule | 0.03 | - | 9.6 |
| DEFENSIVE ARMY | rule | - | 0.03 | 2.3 |
| FALLBACK BY WORTH | rule | 0.03 | - | 6.0 |
| FIGHT ORDER BAND | gate | 0.03 | - | 1.2 |
| MARCH ODDS | rule | 0.03 | - | 10.0 |
| NO REASON | gate | - | 0.03 | 14.6 |
| SAFER THAN THE JOB | rule | 0.03 | - | 12.5 |
| STANDS TO CAST | rule | 0.03 | - | 48.2 |
| WHO HITS BACK | rule | 0.03 | - | 4.9 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 1.3 |

### Plans: fw-h2h-opp-e441028-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.9 | 22% | 436 | 565 | 130% |
| Mine | charge | 3.1 | 68% | 361 | 409 | 113% |
| Mine | close in | 4.3 | 28% | 257 | 138 | 54% |
| Mine | hold | 3.6 | 27% | 239 | 0 | 0% |
| Mine | join | 2.1 | 96% | 92 | 0 | 0% |
| Mine | shoot | 8.1 | 61% | 278 | 683 | 245% |
| Mine | support | 4.1 | 94% | 204 | 0 | 0% |
| Opponent | advance | 11.7 | 10% | 563 | 163 | 29% |
| Opponent | charge | 3.3 | 59% | 390 | 315 | 81% |
| Opponent | close in | 6.9 | 24% | 774 | 234 | 30% |
| Opponent | hold | 3.3 | 25% | 262 | 0 | 0% |
| Opponent | join | 1.2 | 98% | 58 | 0 | 0% |
| Opponent | shoot | 3.3 | 60% | 69 | 194 | 281% |
| Opponent | support | 8.3 | 90% | 238 | 0 | 0% |

### Packages: hunt the guns, fw-h2h-opp-e441028-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 8 | 0 | 0% | 38% | 0% | 2.3 | 385 | 157 | 38% | 14 |
| Opponent | 0.2 | 7 | 1 | 17% | 17% | 0% | 3.0 | 487 | 79 | 17% | 108 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 0 | 0% | 67% | 0% | 2.5 | 444 | 236 | 67% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 0% | 100% | 0% | 2.0 | 551 | 547 | 100% | 63 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 229 | 0 | 0% | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 68 |
| High Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 358 | 0 | 0% | 83 |
| Kingdom of Bretonnia | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 256 | 0 | 0% | 210 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 750 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 42 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 260 | 0 | 0% | 9 |
| Warriors of Chaos | 0.5 | 5 | 1 | 25% | 25% | 0% | 3.0 | 486 | 119 | 25% | 70 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 719 | 0 | 0% | 10 |

### Battle groups: fw-h2h-opp-e441028-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 6.8 | 26% | 48% | 10% | 67% | 38% | 2% | 20% | 41% | 0% |
| Mine | REDIRECT COUNTER | 3.2 | 32% | 74% | 14% | 20% | 13% | 3% | 13% | 67% | 3% |
| Opponent | COUNTER-CHARGE COVER | 8.4 | 20% | 68% | 5% | 0% | 34% | 7% | 14% | 45% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 19% | 73% | 9% | 0% | 0% | 0% | 15% | 75% | 10% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h-opp-e441028-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 140 (1) | 140 | 0 | 0 | 0% | 4.0 | - | - | 140 (1) | - | 140 (1) |
| Mine | Chaff | 32 | 29 (32) | 13 | 15 | 52 | 38% | 2.9 | 21 (15) | 49 (10) | 17 (7) | 31 (23) | 22 (9) |
| Mine | Character | 109 | 53 (109) | 53 | 0 | 21 | 15% | 2.3 | 58 (42) | 62 (37) | 32 (24) | 42 (80) | 92 (23) |
| Mine | Clean-up | 14 | 53 (14) | 18 | 34 | 23 | 36% | 4.1 | 60 (6) | 51 (5) | 46 (3) | 56 (12) | 0 (2) |
| Mine | Fast Hammer | 41 | 38 (41) | 24 | 14 | 52 | 34% | 2.7 | 48 (12) | 35 (16) | 28 (13) | 37 (35) | 42 (6) |
| Mine | Hammer | 43 | 69 (43) | 49 | 20 | 27 | 7% | 2.8 | 72 (21) | 73 (16) | 45 (6) | 79 (29) | 49 (14) |
| Mine | Holder | 27 | 47 (27) | 11 | 36 | 33 | 30% | 3.5 | 39 (14) | 69 (8) | 45 (5) | 44 (15) | 54 (12) |
| Mine | Shooter | 34 | 46 (34) | 10 | 36 | 25 | 6% | 2.3 | 12 (14) | 117 (9) | 30 (11) | 66 (20) | 23 (14) |
| Mine | Support | 1 | 97 (1) | 97 | 0 | 0 | 0% | 4.0 | 97 (1) | - | - | - | 97 (1) |
| Mine | War machine | 52 | 55 (52) | 55 | 0 | 32 | 2% | 1.2 | 53 (24) | 55 (20) | 59 (8) | 73 (30) | 28 (22) |
| Mine | Wizard | 16 | 34 (16) | 34 | 0 | 52 | 6% | 1.7 | 0 (2) | 0 (7) | 99 (6) | 50 (10) | 0 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 67 | 51 (67) | 11 | 40 | 57 | 42% | 3.0 | 20 (31) | 88 (24) | 47 (12) | 59 (45) | 32 (22) |
| Opponent | Character | 91 | 42 (91) | 41 | 1 | 38 | 16% | 2.5 | 41 (39) | 44 (32) | 46 (16) | 31 (56) | 63 (31) |
| Opponent | Clean-up | 17 | 53 (17) | 17 | 36 | 64 | 29% | 3.5 | 34 (8) | 66 (4) | 73 (5) | 69 (11) | 26 (6) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 47 | 25 (47) | 19 | 6 | 49 | 30% | 3.2 | 28 (18) | 20 (18) | 24 (11) | 34 (31) | 9 (16) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 0% | 1.7 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 40 | 34 (40) | 19 | 15 | 40 | 30% | 3.0 | 45 (15) | 19 (19) | 58 (6) | 36 (30) | 29 (10) |
| Opponent | Holder | 34 | 50 (34) | 18 | 32 | 41 | 18% | 3.5 | 54 (13) | 47 (18) | 48 (3) | 52 (23) | 44 (11) |
| Opponent | Shooter | 28 | 31 (28) | 7 | 23 | 37 | 4% | 1.6 | 24 (14) | 62 (10) | 0 (4) | 40 (17) | 14 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 75% | 6.0 | 0 (1) | 0 (1) | 0 (2) | - | 0 (4) |
| Opponent | War machine | 17 | 23 (17) | 23 | 0 | 37 | 12% | 1.4 | 24 (8) | 9 (5) | 41 (4) | 24 (11) | 21 (6) |
| Opponent | Wizard | 30 | 3 (30) | 3 | 0 | 85 | 23% | 1.9 | 0 (10) | 9 (11) | 0 (1) | 0 (10) | 8 (12) |

### Charged fights: fw-h2h-opp-e441028-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 51 | 108 | 1.2 | 1.0 | 87 | 33 | +53 | 1 of 5 | 3 of 5 | - | +53 |
| Mine | Chaos Dwarfs | 4 | 256 | 503 | 4.0 | 1.2 | 126 | 25 | +101 | 11 of 16 | 9 of 16 | +205 | +66 |
| Mine | Dwarfen Mountain Holds | 3 | 526 | 56 | 1.0 | 1.0 | 56 | 20 | +36 | 0 of 3 | 2 of 3 | - | +36 |
| Mine | Empire of Man | 5 | 321 | 166 | 2.2 | 1.1 | 75 | 0 | +75 | 5 of 11 | 8 of 11 | +0 | +83 |
| Mine | Grand Cathay | 5 | 509 | 383 | 4.2 | 1.1 | 91 | 0 | +91 | 6 of 21 | 11 of 21 | +35 | +97 |
| Mine | High Elf Realms | 4 | 102 | 674 | 4.5 | 1.2 | 150 | 6 | +143 | 7 of 18 | 15 of 18 | +221 | +121 |
| Mine | Kingdom of Bretonnia | 1 | 123 | 208 | 2.0 | 1.0 | 104 | 0 | +104 | 1 of 2 | 2 of 2 | - | +104 |
| Mine | Ogre Kingdoms | 1 | 315 | 421 | 7.0 | 1.0 | 60 | 5 | +55 | 3 of 7 | 5 of 7 | - | +55 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 339 | 6.0 | 1.2 | 56 | 57 | -1 | 1 of 6 | 5 of 6 | +0 | -1 |
| Mine | Tomb Kings of Khemri | 2 | 63 | 954 | 6.0 | 1.0 | 159 | 0 | +159 | 9 of 12 | 5 of 12 | - | +159 |
| Mine | Vampire Counts | 1 | 0 | 98 | 4.0 | 1.5 | 24 | 21 | +3 | 3 of 4 | 1 of 4 | +6 | +0 |
| Mine | Warriors of Chaos | 2 | 0 | 101 | 1.5 | 1.3 | 67 | 277 | -210 | 0 of 3 | 0 of 3 | +0 | -315 |
| **Mine** | all armies | 33 | 240 | 340 | 3.3 | 1.1 | 104 | 19 | +85 | 47 of 108 | 66 of 108 | +119 | +80 |
| Opponent | Empire of Man | 1 | 110 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 408 | 226 | 2.0 | 1.5 | 113 | 34 | +79 | 3 of 6 | 2 of 6 | +194 | +21 |
| Opponent | High Elf Realms | 3 | 55 | 132 | 2.0 | 1.0 | 66 | 74 | -8 | 4 of 6 | 4 of 6 | - | -8 |
| Opponent | Kingdom of Bretonnia | 2 | 95 | 130 | 2.0 | 1.0 | 65 | 0 | +65 | 1 of 4 | 3 of 4 | - | +65 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 1 of 3 | 1 of 3 | - | +0 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 482 | -482 | 1 of 1 | 0 of 1 | - | -482 |
| Opponent | Tomb Kings of Khemri | 4 | 36 | 544 | 4.5 | 1.1 | 121 | 15 | +106 | 8 of 18 | 9 of 18 | +0 | +112 |
| Opponent | Vampire Counts | 6 | 0 | 406 | 4.2 | 1.2 | 98 | 54 | +43 | 16 of 25 | 14 of 25 | -58 | +69 |
| Opponent | Warriors of Chaos | 8 | 0 | 620 | 4.9 | 1.2 | 127 | 21 | +106 | 17 of 39 | 26 of 39 | +215 | +77 |
| Opponent | Wood Elf Realms | 4 | 0 | 157 | 3.0 | 1.0 | 52 | 0 | +52 | 3 of 12 | 5 of 12 | - | +52 |
| **Opponent** | all armies | 33 | 55 | 349 | 3.5 | 1.2 | 101 | 31 | +70 | 54 of 114 | 64 of 114 | +114 | +63 |

### Effective charges: fw-h2h-opp-e441028-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 1 (net -52) | 1 (net +0) | 1 (net +0) | 2 (net +160) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 16 | 2 (net +0) | 0 | 1 (net +0) | 3 (net +33) | 2 (net +38) | 7 (net +205) | 1 | 7% (1 of 15) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 1 (net -60) | 0 | 2 (net +84) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 11 | 0 | 0 | 3 (net +45) | 1 (net +227) | 2 (net +100) | 3 (net +88) | 2 | 33% (3 of 9) |
| Mine | Grand Cathay | 21 | 2 (net +304) | 1 (net +70) | 4 (net +124) | 1 (net +0) | 1 (net +30) | 10 (net +53) | 2 | 21% (4 of 19) |
| Mine | High Elf Realms | 18 | 2 (net +282) | 1 (net +0) | 4 (net +172) | 1 (net +0) | 5 (net +110) | 3 (net +144) | 2 | 25% (4 of 16) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 1 (net +208) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 7 | 1 (net +170) | 0 | 1 (net +0) | 0 | 0 | 3 (net +84) | 2 | 20% (1 of 5) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 0 | 3 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 12 | 1 (net +293) | 0 | 5 (net +231) | 3 (net +0) | 0 | 3 (net +153) | 0 | 42% (5 of 12) |
| Mine | Vampire Counts | 4 | 0 | 0 | 1 (net +0) | 2 (net +6) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 1 (net -225) | 0 | 2 (net -202) | 0 | 0 | 33% (1 of 3) |
| Opponent | Grand Cathay | 6 | 0 | 0 | 0 | 1 (net +85) | 2 (net +0) | 3 (net +129) | 0 | 0% (0 of 6) |
| Opponent | High Elf Realms | 6 | 1 (net -442) | 0 | 1 (net +0) | 0 | 1 (net +81) | 3 (net +105) | 0 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 1 (net +165) | 0 | 0 | 1 (net +95) | 1 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 18 | 3 (net -24) | 0 | 3 (net +202) | 2 (net -98) | 1 (net +0) | 7 (net +169) | 2 | 19% (3 of 16) |
| Opponent | Vampire Counts | 25 | 4 (net -202) | 0 | 1 (net -45) | 9 (net +45) | 1 (net +265) | 8 (net +128) | 2 | 4% (1 of 23) |
| Opponent | Warriors of Chaos | 39 | 2 (net +155) | 0 | 3 (net +275) | 7 (net +78) | 7 (net +78) | 11 (net +156) | 9 | 10% (3 of 30) |
| Opponent | Wood Elf Realms | 12 | 1 (net +0) | 0 | 2 (net +0) | 2 (net +102) | 0 | 1 (net +144) | 6 | 33% (2 of 6) |

### Charged fights, damage counted: fw-h2h-opp-e441028-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 376 | 229 | +204 | 204 | 0 | +204 | +54.3 |
| Mine | 50-54% | 2 | 362 | 314 | +35 | 98 | 0 | +98 | +27.1 |
| Mine | Effective (55-75%) | 22 | 339 | 280 | +100 | 130 | 44 | +86 | +25.3 |
| Mine | 76-89% | 15 | 346 | 249 | +33 | 71 | 34 | +37 | +10.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 263 | 198 | +110 | 134 | 17 | +117 | +44.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 486 | 87 | +32 | 88 | 49 | +39 | +8.0 |
| Mine | No odds | 12 | 279 | 201 | +40 | 82 | 35 | +47 | +17.0 |
| Mine | All fights | 108 | 331 | 212 | +85 | 117 | 30 | +88 | +26.5 |
| Opponent | Long shot (under 50%) | 11 | 275 | 296 | -92 | 86 | 154 | -68 | -24.5 |
| Opponent | 50-54% | 1 | 275 | 165 | +165 | 165 | 0 | +165 | +60.0 |
| Opponent | Effective (55-75%) | 10 | 251 | 217 | +139 | 191 | 50 | +141 | +56.1 |
| Opponent | 76-89% | 21 | 241 | 245 | +49 | 103 | 52 | +51 | +21.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 330 | 248 | +140 | 169 | 24 | +146 | +44.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 415 | 90 | +76 | 80 | 1 | +79 | +19.0 |
| Opponent | No odds | 24 | 195 | 202 | +26 | 83 | 53 | +30 | +15.5 |
| Opponent | All fights | 114 | 282 | 221 | +70 | 123 | 47 | +76 | +26.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h-opp-e441028-p3 | move | 471 | 93 (20%) | 62 (13%) | 62 (13%) | 316 (67%) |
| fw-h2h-opp-e441028-p3 | objective | 396 | 53 (13%) | 36 (9%) | 62 (16%) | 281 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

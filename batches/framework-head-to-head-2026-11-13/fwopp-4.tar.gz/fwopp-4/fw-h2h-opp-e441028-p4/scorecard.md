# Doctrine scorecard: fw-h2h-opp-e441028-p4

### Scorecard: fw-h2h-opp-e441028-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 5 | 1 | 3 | 2 | 0 | 0 | 0 | 65 |
| L0114 | 6 | 1 | Opponent | no | 10 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 10 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 255 |
| L0214 | 4 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 2 | 0 | 0 | 255 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 10 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 900 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 233 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 3 | 3 | 3 | 0 | 0 | 0 | 0 | 475 |
| L0520 | 4 | 1 | Opponent | no | 1 | - | 0 | 3 | 1 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | - | 2 | 3 | 1 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 0 | 0 | 0 | 515 |
| L0624 | 6 | 1 | Mine | no | 4 | 3 | 4 | 0 | 0 | 0 | 0 | 743 |
| L0624 | 6 | 1 | Opponent | no | 0 | 6 | 3 | 0 | 0 | 0 | 0 | 60 |
| L0713 | 5 | 1 | Mine | no | - | 2 | 4 | 3 | 0 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 2 | 1 | 1 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 3 | 6 | 2 | 2 | 0 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 0 | 4 | 0 | 2 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | yes | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 515 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 161 |
| L0835 | 1 | 1 | Mine | no | 7 | 4 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 6 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 963 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 3 | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 3 | 1 | 4 | 2 | 0 | 0 | 0 | 350 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 60 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 4 | 0 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 1 | 1 | 4 | 1 | 0 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | yes | - | - | 1 | 1 | 2 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 471 |
| L1523 | 5 | 1 | Mine | yes | - | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | no | - | 3 | 3 | 1 | 1 | 0 | 0 | 90 |
| L1621 | 1 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 367 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 3 | 3 | 1 | 0 | 0 | 355 |
| L1719 | 3 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | no | 3 | 1 | 5 | 0 | 0 | 0 | 0 | 55 |
| L1819 | 1 | 1 | Mine | yes | 7 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 77 |
| L1835 | 5 | 1 | Opponent | no | - | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 2 | 4 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 0 | 6 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 5 | 0 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 114 |
| L2331 | 3 | 1 | Mine | no | 4 | 2 | 5 | 2 | 1 | 0 | 0 | 142 |
| L2331 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 4 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 3 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 1 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | yes | 3 | 1 | 1 | 2 | 1 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 39% | 3.3 | 2.4 | 3.1 | 1.2 | 0.3 | 0.0 | 0.0 | 277.3 |
| **Average** | | | Opponent | 25% | 2.8 | 2.2 | 3.2 | 1.7 | 0.2 | 0.0 | 0.0 | 102.2 |

### KPIs: fw-h2h-opp-e441028-p4

Rules off - Mine only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 181) | 17% (31 of 183) | 9% (31 of 364) |
| Winner chose to follow up after the loser gave ground |  | 96% (51 of 53); on the table 96% | 98% (39 of 40); on the table 98% | 97% (90 of 93); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 100% | 90% (18 of 20); on the table 90% | 90% (26 of 29); on the table 93% |
| Winner chose to pursue after the loser fled |  | 74% (17 of 23); on the table 83% | 90% (27 of 30); on the table 93% | 83% (44 of 53); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 89% (76 of 85); on the table 93% | 93% (84 of 90); on the table 94% | 91% (160 of 175); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 25% (68 of 273) | 36% (61 of 169) | 29% (129 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (68 of 158) | 48% (55 of 114) | 45% (123 of 272) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 52% (41 of 79) | 52% (41 of 79) |
| Points that never fought | lower | 35% (23505 of 67942) | 33% (23698 of 71984) | 34% (47203 of 139926) |
|   infantry points that never fought | lower | 40% (6158 of 15347) | 48% (6572 of 13804) | 44% (12730 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (163 of 270) | 59% (165 of 280) | 60% (328 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.7 uses a game | 89% (8 of 9); 0.8 uses a game | 90% (28 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.6 uses a game | 55% (11 of 20); 0.6 uses a game | 56% (20 of 36); 0.6 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 67% (10 of 15); 0.3 uses a game | 56% (19 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (31789 of 57750) | 51% (32411 of 63347) | 53% (64200 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (21%) | 0.9 (30%) | 2.1 (24%) |
| MARCHED: its unit marched | 1.1 (20%) | 0.6 (19%) | 1.7 (19%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.2 (6%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.2 (20%) | 0.4 (15%) | 1.6 (19%) |
| FLEEING: fleeing | 0.4 (6%) | 0.2 (7%) | 0.6 (7%) |
| GONE: slain | 0.8 (15%) | 0.7 (23%) | 1.5 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.8 (15%) | 0.0 (0%) | 0.8 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.0 | 1.8 | 3.6 | 0.4 | 2.1 |
| not cast | 2.9 | 1.9 | 3.0 | 8.7 | 1.6 | 20.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (49%) | 0.2 (6%) | 2.1 (24%) | 0.2 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.4 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (6%) | 0.5 (17%) | 1.6 (19%) | 0.3 (17%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.1 (6%) | 0.2 (6%) | 0.6 (7%) | 0.1 (5%) | 1.3 (6%) |
| GONE: slain | 1.0 (35%) | 0.2 (13%) | 0.9 (31%) | 1.5 (18%) | 0.1 (8%) | 2.8 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (5%) | 0.2 (9%) | 0.2 (8%) | 0.8 (10%) | 0.1 (5%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (15%) | 0.0 (0%) | 0.0 (0%) | 0.4 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (50%) | 0.1 (3%) | 0.9 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 77% (30 of 39) | 87% (13 of 15) | 80% (43 of 54) |
| the unit moved after it | 53% (16 of 30) | 62% (8 of 13) | 56% (24 of 43) |
| it charged on its next turn | 0% (0 of 30) | 0% (0 of 13) | 0% (0 of 43) |
| the enemy charged it first | 23% (7 of 30) | 0% (0 of 13) | 16% (7 of 43) |
| it fought by the end of its next turn | 13% (4 of 30) | 0% (0 of 13) | 9% (4 of 43) |
| it moved out of a charge the enemy had planned (not charged first) | 17% (5 of 30) | 0% (0 of 13) | 12% (5 of 43) |
| none of these (no charge, no fight, no charge escaped) | 53% (16 of 30) | 100% (13 of 13) | 67% (29 of 43) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (543 of 879) | 49% (276 of 568) | 57% (819 of 1447) |
|   cavalry | 53% (46 of 86) | 54% (62 of 115) | 54% (108 of 201) |
|   character | 37% (34 of 92) | 16% (23 of 143) | 24% (57 of 235) |
|   chariot | 51% (52 of 102) | 64% (16 of 25) | 54% (68 of 127) |
|   infantry | 51% (132 of 260) | 62% (143 of 230) | 56% (275 of 490) |
|   monster | 53% (25 of 47) | 25% (6 of 24) | 44% (31 of 71) |
|   war machine | 87% (254 of 292) | 84% (26 of 31) | 87% (280 of 323) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (28%) | 2.0 (25%) | 4.6 (26%) |
| CHARGED: it charged | 1.4 (15%) | 1.7 (21%) | 3.1 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (3%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.2 (3%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.8 (19%) | 1.6 (19%) | 3.3 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.5 (6%) | 0.8 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (19%) | 1.7 (21%) | 3.5 (20%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.5 | 73% | 6.4 pts | 32 pts |
| character | 2.0 | 1.2 | 70% | 12.9 pts | 26 pts |
| chariot | 1.9 | 1.1 | 71% | 9.1 pts | 17 pts |
| infantry | 11.4 | 3.9 | 74% | 9.8 pts | 112 pts |
| monster | 0.9 | 0.3 | 82% | 7.2 pts | 7 pts |
| war machine | 7.8 | 5.9 | 64% | 29.8 pts | 232 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.1 | 6.3 | 5.7 |
| Charges that made contact a game | 3.7 | 4.3 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.76 declared, 0.71 contact (21 units) | 0.62 declared, 0.52 contact (21 units) | 0.69 declared, 0.62 contact (42 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.73 declared, 0.64 contact (11 units) | 1.00 declared, 0.69 contact (13 units) | 0.88 declared, 0.67 contact (24 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.65 declared, 0.45 contact (246 units) | 0.65 declared, 0.43 contact (310 units) | 0.65 declared, 0.44 contact (556 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (43 of 81) | 69% (11 of 16) | 67% (4 of 6) | 56% (58 of 103) |
| Character in a unit | 95% (18 of 19) | 67% (6 of 9) | 0% (0 of 1) | 83% (24 of 29) |
| Character on its own | 80% (37 of 46) | 61% (20 of 33) | 34% (26 of 77) | 53% (83 of 156) |
| Chariot | 53% (8 of 15) | 58% (7 of 12) | - | 56% (15 of 27) |
| Infantry | 64% (53 of 83) | 28% (7 of 25) | 33% (2 of 6) | 54% (62 of 114) |
| Monster | 62% (21 of 34) | 86% (12 of 14) | - | 69% (33 of 48) |
| Monstrous | 86% (12 of 14) | 50% (7 of 14) | - | 68% (19 of 28) |
| War Machines | 74% (32 of 43) | 100% (2 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (7 of 7); on the table 100% | 26% (27 of 102) | 14% | 59% (13 of 22) | 100% (6 of 6); 3.5 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (5 of 5); on the table 100% | 42% (10 of 24) | 34% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 82% (9 of 11); on the table 82% | - | 60% | 59% (16 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 75% (3 of 4); on the table 75% | 28% (5 of 18) | 49% | 73% (45 of 62) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 20% (1 of 5); 0.2 uses a game |
| Grand Cathay | 4 | 100% (9 of 9); on the table 100% | 24% (20 of 84) | 45% | 59% (22 of 37) | 100% (9 of 9); 8.0 uses a game | 100% (2 of 2); 1.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 92% (23 of 25); on the table 92% | 29% (10 of 35) | 34% | 51% (36 of 70) | 86% (6 of 7); 2.9 uses a game | 50% (15 of 30); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (6 of 6); on the table 100% | - | 16% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 86% (12 of 14); on the table 93% | 17% (1 of 6) | 22% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 75% (6 of 8); on the table 100% | 67% (4 of 6) | 40% | 86% (12 of 14) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (6 of 6); on the table 100% | 31% (13 of 42) | 37% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 6 | 88% (7 of 8); on the table 88% | 17% (7 of 42) | 55% | 67% (30 of 45) | 100% (3 of 3); 1.3 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 100% (9 of 9); on the table 100% | 17% (1 of 6) | 30% | 60% (12 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (12 of 12); on the table 100% | 34% (20 of 59) | 20% | 48% (20 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 87% (34 of 39); on the table 90% | 58% (7 of 12) | 26% | 60% (43 of 72) | 100% (2 of 2); 0.3 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 100% (12 of 12); on the table 100% | 67% (4 of 6) | 26% | 61% (34 of 56) | 50% (1 of 2); 0.8 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h-opp-e441028-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 55% (48) | 54% (50) | 55% (98) |
| ...free all their last turn and able to turn (per game) | 0.86 | 1.00 | 1.86 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.08 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.69 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.69 | 1.39 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.83 | 1.78 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.81 | 7.00 | 14.81 |

### Quality by phase: fw-h2h-opp-e441028-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 0.0 |
| Strategy | Charge objectives carried out (made contact) | 45% (69 of 152) | 41% (70 of 170) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (132 of 327) | 43% (43 of 101) |
| Strategy | Close-in objectives charged next turn | 13% (22 of 174) | 16% (43 of 267) |
| Strategy | Support requests answered (helper made contact too) | 36% (4 of 11) | 52% (13 of 25) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 65% (11 of 17) | 46% (6 of 13) |
| Strategy | Joined characters whose unit fought | 32% (7 of 22) | 37% (7 of 19) |
| Strategy | Lone characters that fought | 83% (84 of 101) | 69% (67 of 97) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 277.3 | 102.2 |
| Movement | Fights charged into per game | 3.4 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 107, net -71 | 15 of 95, net +72 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 107, net +77 | 17 of 95, net +110 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 107, net +73 | 9 of 95, net +125 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 of 107, net +101 | 29 of 95, net +111 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 8.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (140 of 325) | 51% (149 of 293) |
| Shooting | Points destroyed by shooting units | 84.9 | 26.1 |
| Shooting | War machine shots | 7.1 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (148 of 254) | 42% (11 of 26) |
| Shooting | Points destroyed by war machines | 74.4 | 6.7 |
| Magic | Magic missiles cast | 1.0 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (16 of 37) | 42% (17 of 40) |
| Magic | Wounds caused by magic missiles | 3.1 | 1.8 |
| Magic | Wounds caused by other spells | 2.2 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 55.1 | 5.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.5 / 0.8 / 0.1 | 2.2 / 0.6 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 306.5 | 437.3 |
| Combat | Points run down | 86.9 | 139.8 |
| Combat | Net points per charged fight, damage counted | +52 | +94 |
| Combat | Net per 100 charger points, damage counted | +17.1 | +29.5 |
| Combat | First round won (charged fights) | 75% | 69% |
| Combat | Net points per charged fight | +48 | +91 |
| Combat | Net points per supported fight / lone fight | +90 / +41 | +78 / +93 |
| Combat | Charged fights on a top-3 enemy unit | 39 of 121 | 55 of 126 |
| Game | Points lost | 769.7 | 665.4 |
| Game | VP from objectives | 539.7 | 552.8 |
| Game | Lone holders (player turns) | 3.3 | 2.8 |

- Mine won / drew / lost: 11 / 12 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -137 VP
- The side that went first won 13 of 24 games with a winner
- Points traded per game (both sides' losses): 1435
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-h2h-opp-e441028-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 2.4 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +8.2 | 0.0 | 33.9 | 1.6 | +12.6 | 0.0 | 23.8 |
| BEST FACING | - | - | - | - | 0.7 | +35.2 | 0.0 | 21.9 |
| BEST FIRST | - | - | - | - | 2.9 | +89.9 | 94.1 | 83.2 |
| BEST OVERALL | 0.5 | +26.1 | 0.0 | 26.2 | 0.7 | +56.3 | 0.0 | 16.8 |
| BEST PREY | 5.4 | +341.7 | 203.7 | 129.2 | 0.8 | +35.8 | 17.1 | 16.3 |
| BEST PRIZE | 0.1 | -0.4 | 7.9 | 2.2 | 0.2 | +11.8 | 4.9 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -0.8 | 0.0 | 10.2 | 0.3 | -0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE HANDED OVER | 0.0 | +3.1 | 3.2 | 0.0 | 0.1 | +6.1 | 6.5 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.2 | 0.0 | 0.2 | +0.0 | 16.9 | 0.0 |
| BLOCKED WHEEL | 0.4 | +8.2 | 0.0 | 11.4 | 0.7 | +10.0 | 0.0 | 11.4 |
| BOMBING RUN | 0.1 | +1.6 | 0.0 | 4.2 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.0 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 122.9 | 6.5 | 0.0 | +0.0 | 2.9 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +208.4 | 349.2 | 57.6 | 0.4 | +11.7 | 9.6 | 10.4 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -2.9 | 7.2 | 4.7 | 0.1 | +0.0 | 13.6 | 0.0 |
| CAST JOB | 0.8 | +25.6 | 44.5 | 0.0 | 0.2 | +3.4 | 39.5 | 0.0 |
| CASTING BLOCK | 0.1 | +13.1 | 4.7 | 2.9 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 49.7 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.8 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 1.8 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +4.2 | 1.7 | 0.0 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.6 | -46.7 | 21.1 | 31.3 | 0.4 | -49.3 | 0.0 | 16.1 |
| CHARIOT NO STATIC JOB | 0.5 | +0.0 | 16.6 | 4.7 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | -0.6 | 10.5 | 30.0 |
| CHEAP HELPER | 0.0 | +0.0 | 1.8 | 2.2 | 0.1 | +0.0 | 1.9 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 8.1 | 13.5 | 0.5 | +0.0 | 9.6 | 32.2 |
| CONVEYANCE SEARCH | 0.8 | +142.6 | 48.2 | 80.0 | 0.3 | +72.1 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 8.6 | +598.9 | 0.0 | 194.8 | 8.6 | +757.5 | 0.0 | 170.1 |
| DEFENSIVE ARMY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +7.2 | 18.2 | 0.0 | 0.2 | +4.1 | 9.4 | 7.9 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +4.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +134.6 | 0.0 | 20.2 | 1.4 | +98.8 | 0.0 | 41.9 |
| FALLBACK BY WORTH | 7.1 | +101.9 | 0.0 | 149.6 | 6.4 | +46.1 | 0.0 | 88.5 |
| FIGHT LIFT | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.4 | 0.0 | 5.9 | 0.1 | +0.2 | 0.0 | 3.0 |
| FLANK NOT WEIGHED | 7.5 | +0.0 | 0.0 | 183.1 | 7.0 | +0.0 | 0.0 | 180.4 |
| FOCUS FIRE | 0.1 | +1.7 | 6.3 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +99.7 | 0.0 | 42.9 | 1.0 | +149.9 | 0.0 | 38.8 |
| FRIENDS SHOTS CHECKED | 0.4 | +31.1 | 0.0 | 0.0 | 0.0 | +4.8 | 0.0 | 0.0 |
| GIVES UP | 1.4 | -41.0 | 204.4 | 51.2 | 1.6 | -90.1 | 194.6 | 15.0 |
| GIVES UP ITS SCREEN | 0.4 | -6.1 | 28.9 | 5.3 | 0.1 | -0.4 | 13.2 | 0.8 |
| GROUND FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 1.8 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 0.0 | 33.5 | 0.3 | +0.0 | 22.8 | 3.8 |
| HILL BY ITS CHANCE | - | - | - | - | 0.7 | -89.1 | 0.0 | 6.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.3 | +6.7 | 9.6 | 3.2 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 0.0 | 6.4 |
| HUNT IN PAIRS | 0.5 | +9.3 | 0.0 | 21.0 | 0.9 | +16.0 | 0.0 | 32.1 |
| HUNT KEPT | - | - | - | - | 0.2 | +8.2 | 9.6 | 0.0 |
| HUNT RESULT | 0.0 | +7.7 | 0.0 | 1.7 | 0.2 | +11.6 | 0.0 | 6.4 |
| HUNT THE GUNS | 0.0 | +9.9 | 3.5 | 1.7 | 0.3 | +93.5 | 9.6 | 4.5 |
| INVITES THE FIGHT | - | - | - | - | 3.5 | +204.7 | 75.4 | 57.9 |
| JOINT CHARGE PLAN | 0.1 | +0.6 | 8.2 | 5.7 | 0.1 | +14.3 | 2.2 | 7.2 |
| KEEP FALLS | 0.1 | +2.5 | 0.0 | 6.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.2 | +1.1 | 6.2 | 4.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +55.0 | 192.3 | 99.8 | 2.8 | +84.2 | 147.8 | 59.3 |
| KILLS COUNT | 2.0 | +86.3 | 152.4 | 48.9 | 2.1 | +147.6 | 186.3 | 45.7 |
| KILLS COUNT NEXT TURN | 10.6 | +337.7 | 529.5 | 253.4 | 8.1 | +260.1 | 200.9 | 86.6 |
| LONE CHARACTER SAFE SPOT | 0.4 | +14.9 | 4.6 | 15.5 | 0.4 | +5.5 | 10.5 | 16.4 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 0.0 | 4.3 | 1.4 | +0.0 | 75.1 | 28.0 |
| LONG SHOT | - | - | - | - | 0.5 | +3.1 | 32.9 | 1.7 |
| LOST CHARGE | - | - | - | - | 1.4 | -23.4 | 48.5 | 23.3 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -3.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +9.0 | 21.8 | 9.9 | 0.8 | +62.7 | 17.4 | 12.1 |
| MANOEUVRE | 0.4 | +13.6 | 0.0 | 10.3 | 0.2 | +11.5 | 0.0 | 6.4 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +35.3 | 0.0 | 22.5 | 0.4 | +6.2 | 0.0 | 30.0 |
| MARCH ODDS | 0.9 | +46.5 | 53.6 | 28.0 | 0.1 | +7.7 | 4.9 | 11.1 |
| MARCH OVER CASTS | 0.6 | +18.5 | 0.0 | 14.9 | 0.3 | +16.0 | 0.0 | 9.1 |
| MAX FOR POSITIONING | 4.6 | +138.0 | 0.0 | 141.5 | 5.4 | +214.7 | 0.0 | 107.5 |
| MISSILES IN THE MOVE | 3.9 | +118.1 | 0.0 | 132.6 | 2.4 | +33.3 | 0.0 | 59.5 |
| MISSILES NEXT TURN | 4.7 | +83.0 | 0.0 | 142.0 | 3.1 | +27.0 | 0.0 | 84.0 |
| MODEL FACING | 0.4 | +160.7 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +12.0 | 0.0 | 0.0 | 0.1 | +7.9 | 0.0 | 1.7 |
| MOVE SPELL IN RANGE | 0.5 | +12.7 | 0.0 | 24.9 | 0.2 | +6.8 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -19.5 | 14.1 | 50.8 | 0.1 | -0.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 7.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 8.4 | +707.9 | 251.7 | 133.3 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +6.4 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.2 | +12.9 | 0.0 | 8.2 | - | - | - | - |
| NOT NEEDED | 0.4 | -17.9 | 42.1 | 6.7 | 0.4 | -31.4 | 50.3 | 4.3 |
| NOT TURNED | 7.8 | +142.6 | 0.0 | 221.7 | 7.0 | +145.2 | 0.0 | 154.8 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 11.2 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 19.9 | -1021.6 | 63.6 | 320.6 | 16.4 | -838.8 | 8.4 | 304.4 |
| OPENS A LANE | 0.1 | +0.3 | 0.0 | 3.2 | 0.1 | +1.2 | 5.4 | 0.0 |
| OPENS UP | 0.3 | +24.8 | 16.4 | 18.0 | 0.1 | +15.3 | 6.2 | 0.0 |
| OVERRUNS AWAY | 0.5 | +23.5 | 67.1 | 0.0 | 0.8 | +10.5 | 67.3 | 2.6 |
| PATHS CROSS | 2.3 | +158.4 | 0.0 | 34.4 | 4.2 | +301.1 | 0.0 | 66.2 |
| PERIAPT WORTH | 0.1 | +4.7 | 0.0 | 0.0 | 0.1 | +7.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 0.0 | 0.1 | -3.6 | 0.0 | 3.8 |
| PLAN RESULT | 40.6 | +1464.1 | 1295.2 | 1061.5 | 41.8 | +1043.7 | 1424.1 | 979.1 |
| PURSUES BIG PREY | 0.2 | -6.9 | 0.0 | 0.0 | 0.1 | -2.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +6.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.2 | +19.3 | 0.0 | 62.4 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -10.5 | 1.8 | 10.6 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.6 | -8.2 | 0.0 | 5.2 |
| REDIRECT COUNTER | 3.6 | +190.0 | 0.0 | 35.9 | 4.7 | +351.9 | 0.0 | 83.3 |
| REDIRECT WEIGHED | 0.5 | +7.1 | 15.2 | 14.5 | 0.7 | +35.1 | 21.5 | 26.2 |
| RESERVE FALL BACK | - | - | - | - | 0.6 | +7.6 | 0.0 | 15.1 |
| RESTRAINS TO SHOOT | 0.0 | +1.0 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.9 | +97.0 | 258.4 | 84.7 | 2.6 | +45.0 | 249.8 | 46.8 |
| SAFER THAN THE JOB | 0.9 | +45.7 | 0.0 | 50.9 | 0.8 | +65.6 | 0.0 | 10.6 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.1 | -5.4 | 0.0 | 0.0 |
| SEARCH SPOT | 2.1 | +117.4 | 0.0 | 45.5 | 4.1 | +175.5 | 0.0 | 69.0 |
| SELF MOVE SPELL | 0.2 | +43.8 | 0.0 | 0.0 | 0.5 | +47.8 | 0.0 | 18.1 |
| SET UP TOGETHER | 1.0 | +20.3 | 32.2 | 21.2 | 1.1 | +84.2 | 19.7 | 15.6 |
| SET-UP ANY TARGET | 0.4 | +81.0 | 17.0 | 24.1 | 0.1 | +31.8 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +16.9 | 5.1 | 2.4 | 0.0 | +13.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +12.7 | 15.8 | 1.7 |
| SHOT REPLANNED | 0.6 | +0.0 | 73.5 | 5.5 | 0.2 | +0.0 | 23.1 | 0.0 |
| SHOTS IN THE MOVE | 14.1 | +561.1 | 0.0 | 195.9 | 6.9 | +141.6 | 0.0 | 104.9 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -1.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.5 | +93.1 | 25.4 | 35.4 | 0.2 | +83.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +24.5 | 78.6 | 96.2 | 2.2 | +43.5 | 100.8 | 102.4 |
| STABLE ROLE | - | - | - | - | 10.4 | +0.0 | 387.1 | 158.3 |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| STOPS | 0.0 | +3.9 | 3.5 | 1.7 | 0.1 | +7.0 | 9.6 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.7 | +22.8 | 0.0 | 28.6 | 0.6 | +18.8 | 0.0 | 15.5 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.7 | 0.3 | +0.0 | 0.0 | 5.8 |
| SUPPORTS | - | - | - | - | 8.8 | +280.2 | 270.5 | 127.3 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -14.4 | 30.6 | 20.0 | 0.2 | -23.4 | 17.7 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +3.1 | 0.0 | 17.9 | 0.8 | +3.5 | 9.9 | 10.0 |
| THROUGH LINE OF FIRE | 0.3 | +8.1 | 0.0 | 15.2 | 0.2 | +10.3 | 0.0 | 0.0 |
| TURN WORTH | 0.7 | -48.6 | 59.4 | 28.9 | 0.1 | -9.2 | 8.9 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +0.7 | 16.9 | 0.0 | 0.2 | +1.5 | 9.8 | 3.2 |
| WALKS TO THE FIGHT | - | - | - | - | 1.1 | +54.0 | 15.4 | 19.6 |
| WAR ENGINE JOBS | - | - | - | - | 0.1 | +0.0 | 1.4 | 8.1 |
| WEARS DOWN | 1.0 | +43.5 | 118.4 | 30.0 | 1.2 | +29.4 | 119.8 | 28.2 |
| WHO HITS BACK | 0.2 | +18.6 | 0.0 | 2.0 | 0.1 | +15.5 | 0.0 | 5.8 |
| WHOLE FIGHT | 0.3 | +21.2 | 75.9 | 0.0 | 0.3 | +5.6 | 72.8 | 1.5 |
| WHOLE FIGHT GAIN | 0.2 | +12.2 | 8.7 | 0.0 | 0.6 | +63.1 | 68.1 | 13.5 |

### Rule changes: fw-h2h-opp-e441028-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1308 | 1308 | 1308 | 36.33 | -66974 | -51.2 |
| PATHS CROSS | 235 | 235 | 235 | 6.53 | +16543 | +70.4 |
| SEARCH SPOT | 221 | 221 | 220 | 6.11 | +10543 | +47.9 |
| KILLS COUNT NEXT TURN | 676 | 672 | 182 | 5.06 | +4768 | +26.2 |
| MOVE TO CHARGE | 304 | 304 | 174 | 4.83 | +10436 | +60.0 |
| COUNTER-CHARGE COVER | 619 | 322 | 171 | 4.75 | +9710 | +56.8 |
| SUPPORTS | 316 | 316 | 151 | 4.19 | +3158 | +20.9 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +8401 | +75.7 |
| FALLBACK BY WORTH | 485 | 485 | 110 | 3.06 | +5326 | +48.4 |
| BEST FIRST | 103 | 103 | 103 | 2.86 | +3237 | +31.4 |
| BEST PREY | 222 | 216 | 90 | 2.50 | +4133 | +45.9 |
| SHOTS IN THE MOVE | 756 | 458 | 73 | 2.03 | +1500 | +20.5 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +8983 | +126.5 |
| SAFER THAN THE JOB | 64 | 64 | 64 | 1.78 | +4007 | +62.6 |
| REDIRECT COUNTER | 298 | 141 | 60 | 1.67 | +4969 | +82.8 |
| KILLS COUNT | 146 | 134 | 52 | 1.44 | +2721 | +52.3 |
| STOPS SHORT OF THE FLANK | 47 | 47 | 47 | 1.31 | +1499 | +31.9 |
| BEST OVERALL | 45 | 45 | 45 | 1.25 | +2965 | +65.9 |
| INVITES THE FIGHT | 125 | 125 | 45 | 1.25 | +2433 | +54.1 |
| RISK BY ARC | 198 | 185 | 45 | 1.25 | +1227 | +27.3 |
| REDIRECT WEIGHED | 42 | 42 | 42 | 1.17 | +1912 | +45.5 |
| RANDOM MOVE BY FIGURES | 79 | 79 | 41 | 1.14 | +694 | +16.9 |
| BLOCKED WHEEL | 39 | 39 | 39 | 1.08 | +654 | +16.8 |
| ARTILLERY RE-ROLL WEIGHED | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +2578 | +71.6 |
| KEEPS ITS TARGET | 167 | 164 | 36 | 1.00 | +487 | +13.5 |
| MARCH CHECK | 37 | 37 | 36 | 1.00 | +1695 | +47.1 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| MARCH ODDS | 35 | 35 | 34 | 0.94 | +861 | +25.3 |
| CANNON PLANNED TARGET | 204 | 204 | 32 | 0.89 | -522 | -16.3 |
| MISSILES IN THE MOVE | 224 | 124 | 32 | 0.89 | +670 | +20.9 |
| WALKS TO THE FIGHT | 40 | 40 | 31 | 0.86 | +751 | +24.2 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| MAX FOR POSITIONING | 358 | 175 | 28 | 0.78 | +241 | +8.6 |
| SET UP TOGETHER | 76 | 66 | 28 | 0.78 | +971 | +34.7 |
| SHOT REPLANNED | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| BEST FACING | 24 | 24 | 24 | 0.67 | +1268 | +52.9 |
| MANOEUVRE | 24 | 24 | 23 | 0.64 | +902 | +39.2 |
| WEARS DOWN | 81 | 76 | 23 | 0.64 | +494 | +21.5 |
| LONE WIZARD HOLDS BACK | 55 | 55 | 22 | 0.61 | -419 | -19.0 |
| BIG CHARACTER SAFETY | 21 | 21 | 21 | 0.58 | -38 | -1.8 |
| RESERVE FALL BACK | 20 | 20 | 20 | 0.56 | +275 | +13.8 |
| STUCK PIVOT | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 27 | 24 | 19 | 0.53 | +980 | +51.6 |
| THROUGH LINE OF FIRE | 18 | 18 | 18 | 0.50 | +665 | +36.9 |
| MAKE SURE TOGETHER | 47 | 35 | 17 | 0.47 | +699 | +41.1 |
| SURE CHARGE BEATS ADVANCE | 17 | 17 | 17 | 0.47 | -1361 | -80.0 |
| CAST JOB | 36 | 36 | 16 | 0.44 | +223 | +14.0 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +1293 | +86.2 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +714 | +47.6 |
| SHOOTS FROM THE BEST SPOT | 26 | 26 | 15 | 0.42 | +140 | +9.3 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -31 | -2.2 |
| MODEL FACING | 14 | 14 | 14 | 0.39 | +5785 | +413.2 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +838 | +59.9 |
| BLOCKED CHARGE SKIPPED | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| OPENS UP | 16 | 16 | 10 | 0.28 | +313 | +31.3 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -194 | -21.5 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -345 | -38.3 |
| BACKUP TARGETS | 97 | 41 | 8 | 0.22 | +18 | +2.2 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -528 | -66.0 |
| OVERRUNS AWAY | 45 | 44 | 8 | 0.22 | +383 | +47.8 |
| CHARIOT NO STATIC JOB | 17 | 17 | 7 | 0.19 | -272 | -38.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| NO RALLY LEFT | 6 | 6 | 6 | 0.17 | +307 | +51.2 |
| SURE REACH TOGETHER | 49 | 30 | 6 | 0.17 | +37 | +6.1 |
| WHOLE FIGHT | 22 | 21 | 6 | 0.17 | +267 | +44.6 |
| HUNT ADVANCE | 10 | 10 | 5 | 0.14 | +52 | +10.4 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +197 | +39.4 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +433 | +86.7 |
| BLOCKED CHARGE HANDED OVER | 4 | 4 | 4 | 0.11 | +330 | +82.6 |
| CASTING BLOCK | 5 | 5 | 4 | 0.11 | +129 | +32.3 |
| EDGE GIVE GROUND | 9 | 9 | 4 | 0.11 | +135 | +33.8 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +22 | +5.5 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +102 | +25.5 |
| HUNT IN PAIRS | 53 | 23 | 4 | 0.11 | +46 | +11.5 |
| DEFENSIVE ARMY | 10 | 10 | 3 | 0.08 | -85 | -28.3 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +159 | +52.9 |
| NEEDED THERE | 4 | 3 | 3 | 0.08 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +145 | +48.3 |
| REDIRECT BY WHAT IT STOPS | 22 | 22 | 3 | 0.08 | +68 | +22.6 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +57 | +28.4 |
| LOST CHARGE | 52 | 52 | 2 | 0.06 | +42 | +20.9 |
| MISSILES NEXT TURN | 282 | 148 | 2 | 0.06 | +4 | +2.2 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +61 | +30.6 |
| STOPS | 6 | 6 | 2 | 0.06 | +208 | +103.8 |
| WAR ENGINE JOBS | 5 | 5 | 2 | 0.06 | -102 | -51.0 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CARRIES OUT SET-UP | 5 | 5 | 1 | 0.03 | -105 | -105.2 |
| GIVES UP | 108 | 103 | 1 | 0.03 | +2 | +1.5 |
| OPENS A LANE | 8 | 4 | 1 | 0.03 | +12 | +12.2 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -14 | -14.0 |
| TURN WORTH | 31 | 28 | 1 | 0.03 | +13 | +12.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 32 | 32 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 50 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 522 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 16 | 16 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 18 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 26 | 26 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 5 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 11 | 10 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 28 | not checked | - | - | - | - |
| LONG SHOT | 18 | 17 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 23 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT NEEDED | 29 | 28 | 0 | 0.00 | - | - |
| NOT TURNED | 533 | 533 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| PLAN RESULT | 2966 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 19 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 130 | not checked | - | - | - | - |
| STABLE ROLE | 376 | 375 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 17 | 17 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h-opp-e441028-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 16.78 | 14.50 | 52.9 |
| FALLBACK | gate | 1.17 | 0.64 | 59.3 |
| TURN GATE | gate | 0.44 | 0.75 | 29.4 |
| RULE SWITCHED OFF | gate | 1.06 | - | 22.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.22 | 0.25 | 80.0 |
| PATHS CROSS | rule | 0.19 | 0.19 | 25.1 |
| LONE WIZARD HOLDS BACK | rule | - | 0.31 | 38.1 |
| AFTERMATH BAND | gate | 0.14 | 0.14 | 2.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.22 | 63.1 |
| CANNON PLANNED TARGET | rule | 0.25 | - | 80.2 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.11 | 21.5 |
| PURSUES BIG PREY | rule | 0.17 | 0.08 | 38.3 |
| BEST PRIZE | rule | 0.06 | 0.17 | 66.0 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.11 | 10.3 |
| CHARIOT NO STATIC JOB | rule | 0.19 | - | 38.9 |
| BLOCKED WHEEL | rule | 0.06 | 0.11 | 33.3 |
| FIGHT ORDER BAND | gate | 0.11 | 0.06 | 1.6 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.08 | 8.2 |
| SUPPORT REQUEST | gate | 0.06 | 0.11 | 115.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.03 | 14.4 |
| CHARGE NOW WEIGHED | rule | 0.11 | - | 102.1 |
| REDIRECT WEIGHED | rule | 0.03 | 0.08 | 44.5 |
| DEFENSIVE ARMY | rule | - | 0.08 | 28.3 |
| CHAFF PASSED | rule | 0.03 | 0.03 | 15.4 |
| MARCH ODDS | rule | 0.06 | - | 9.4 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 22.4 |
| WAR ENGINE JOBS | rule | - | 0.06 | 51.0 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 105.2 |
| FACES THE THREAT | rule | - | 0.03 | 19.3 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 3.3 |
| SAFER THAN THE JOB | rule | 0.03 | - | 14.5 |
| STANDS TO CAST | rule | - | 0.03 | 14.0 |
| WHO HITS BACK | rule | 0.03 | - | 1.1 |

### Plans: fw-h2h-opp-e441028-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 14.9 | 19% | 479 | 395 | 82% |
| Mine | charge | 3.3 | 56% | 291 | 310 | 106% |
| Mine | close in | 4.8 | 22% | 228 | 167 | 73% |
| Mine | hold | 4.3 | 41% | 299 | 0 | 0% |
| Mine | join | 0.8 | 93% | 36 | 0 | 0% |
| Mine | shoot | 8.0 | 63% | 297 | 592 | 199% |
| Mine | support | 4.5 | 91% | 224 | 0 | 0% |
| Opponent | advance | 14.8 | 12% | 789 | 294 | 37% |
| Opponent | charge | 3.6 | 60% | 460 | 424 | 92% |
| Opponent | close in | 7.3 | 22% | 1012 | 164 | 16% |
| Opponent | hold | 4.1 | 27% | 315 | 0 | 0% |
| Opponent | join | 0.7 | 92% | 45 | 0 | 0% |
| Opponent | shoot | 2.1 | 58% | 43 | 163 | 378% |
| Opponent | support | 9.2 | 91% | 217 | 0 | 0% |

### Packages: hunt the guns, fw-h2h-opp-e441028-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 355 | 278 | 100% | 5 |
| Opponent | 0.3 | 10 | 1 | 33% | 22% | 0% | 3.0 | 361 | 46 | 11% | 98 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 355 | 278 | 100% | 60 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 23 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 23 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 252 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 296 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 182 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.5 | 4 | 0 | 50% | 50% | 0% | 3.0 | 463 | 104 | 25% | 0 |
| Warriors of Chaos | 0.7 | 6 | 1 | 20% | 0% | 0% | - | 280 | 0 | 0% | 26 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 39 |

### Battle groups: fw-h2h-opp-e441028-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.6 | 25% | 40% | 12% | 56% | 26% | 7% | 26% | 40% | 0% |
| Mine | REDIRECT COUNTER | 3.6 | 30% | 62% | 10% | 0% | 26% | 3% | 3% | 66% | 3% |
| Opponent | COUNTER-CHARGE COVER | 8.6 | 19% | 59% | 8% | 0% | 22% | 7% | 24% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 4.7 | 30% | 82% | 25% | 15% | 18% | 0% | 21% | 58% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h-opp-e441028-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 46 (4) | 46 | 0 | 0 | 25% | 2.0 | - | 46 (4) | - | 0 (1) | 75 (3) |
| Mine | Chaff | 38 | 111 (38) | 47 | 64 | 53 | 37% | 2.9 | 85 (15) | 108 (15) | 165 (8) | 129 (24) | 82 (14) |
| Mine | Character | 105 | 44 (105) | 44 | 0 | 46 | 10% | 2.5 | 42 (32) | 50 (37) | 58 (16) | 44 (64) | 58 (21) |
| Mine | Clean-up | 26 | 61 (26) | 16 | 45 | 32 | 35% | 3.6 | 10 (7) | 62 (14) | 119 (5) | 74 (19) | 11 (7) |
| Mine | Early | 1 | 156 (1) | 156 | 0 | 0 | 0% | 6.0 | - | - | 156 (1) | 156 (1) | - |
| Mine | Fast | 1 | 208 (1) | 208 | 0 | 100 | 0% | 2.0 | - | 208 (1) | - | 208 (1) | - |
| Mine | Fast Hammer | 38 | 30 (38) | 19 | 11 | 43 | 29% | 3.1 | 26 (25) | 41 (9) | 35 (4) | 37 (26) | 19 (12) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 16 | 40% | 3.3 | 0 (4) | 0 (1) | - | 0 (1) | 0 (4) |
| Mine | Hammer | 62 | 37 (62) | 24 | 13 | 46 | 8% | 2.5 | 35 (26) | 42 (23) | 30 (13) | 31 (46) | 52 (16) |
| Mine | Holder | 33 | 50 (33) | 16 | 33 | 26 | 30% | 3.0 | 54 (9) | 59 (16) | 27 (8) | 73 (19) | 8 (14) |
| Mine | Shooter | 32 | 86 (32) | 32 | 54 | 33 | 3% | 2.1 | 76 (13) | 139 (12) | 16 (7) | 70 (17) | 106 (15) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 52 (56) | 52 | 0 | 25 | 5% | 1.1 | 59 (22) | 65 (20) | 22 (14) | 56 (34) | 45 (22) |
| Mine | Wizard | 18 | 0 (18) | 0 | 0 | 82 | 6% | 2.1 | 0 (3) | 0 (6) | 0 (3) | 0 (8) | 0 (4) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 79 | 70 (79) | 15 | 55 | 49 | 37% | 3.3 | 53 (28) | 91 (38) | 39 (13) | 74 (68) | 37 (11) |
| Opponent | Character | 97 | 67 (97) | 67 | 0 | 24 | 22% | 2.5 | 53 (47) | 72 (25) | 98 (19) | 75 (54) | 60 (37) |
| Opponent | Clean-up | 15 | 69 (15) | 25 | 44 | 27 | 33% | 3.3 | 37 (8) | 141 (4) | 47 (3) | 66 (12) | 77 (3) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 51 | 21 (51) | 16 | 5 | 46 | 25% | 2.8 | 23 (24) | 19 (12) | 20 (15) | 28 (37) | 6 (14) |
| Opponent | Fragile | 17 | 59 (17) | 59 | 0 | 45 | 12% | 2.3 | 12 (9) | 123 (7) | 0 (1) | 10 (10) | 135 (7) |
| Opponent | Hammer | 64 | 36 (64) | 27 | 9 | 42 | 31% | 3.3 | 34 (26) | 41 (22) | 30 (16) | 35 (46) | 38 (18) |
| Opponent | Holder | 30 | 37 (30) | 14 | 23 | 36 | 40% | 4.1 | 18 (10) | 67 (13) | 5 (5) | 54 (17) | 7 (11) |
| Opponent | Shooter | 33 | 43 (33) | 9 | 34 | 40 | 3% | 1.8 | 24 (15) | 56 (15) | 86 (3) | 38 (21) | 54 (12) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 84 | 17% | 4.2 | - | 0 (3) | 0 (3) | - | 0 (6) |
| Opponent | War machine | 6 | 27 (6) | 27 | 0 | 38 | 0% | 1.8 | 29 (2) | 37 (3) | 0 (1) | 38 (3) | 18 (3) |
| Opponent | Wizard | 20 | 5 (20) | 5 | 0 | 55 | 10% | 2.1 | 0 (9) | 0 (4) | 28 (3) | 9 (9) | 0 (7) |

### Charged fights: fw-h2h-opp-e441028-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 150 | 125 | 1.5 | 1.2 | 84 | 9 | +75 | 1 of 6 | 4 of 6 | +151 | +60 |
| Mine | Chaos Dwarfs | 4 | 88 | 176 | 3.2 | 1.2 | 54 | 48 | +7 | 3 of 13 | 10 of 13 | +185 | -8 |
| Mine | Dwarfen Mountain Holds | 3 | 277 | 217 | 3.0 | 1.0 | 72 | 14 | +58 | 5 of 9 | 8 of 9 | - | +58 |
| Mine | Empire of Man | 5 | 389 | 186 | 2.2 | 1.1 | 85 | 58 | +26 | 6 of 11 | 7 of 11 | +400 | -11 |
| Mine | Grand Cathay | 4 | 539 | 144 | 3.2 | 1.2 | 44 | 62 | -17 | 3 of 13 | 11 of 13 | -195 | +36 |
| Mine | High Elf Realms | 4 | 248 | 624 | 5.0 | 1.2 | 125 | 39 | +85 | 6 of 20 | 13 of 20 | +133 | +69 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1007 | 5.0 | 1.2 | 201 | 16 | +185 | 2 of 5 | 3 of 5 | +540 | +97 |
| Mine | Lizardmen | 1 | 211 | 1089 | 3.0 | 1.7 | 363 | 0 | +363 | 2 of 3 | 3 of 3 | +360 | +370 |
| Mine | Ogre Kingdoms | 2 | 0 | 125 | 4.0 | 1.0 | 31 | 23 | +8 | 3 of 8 | 7 of 8 | - | +8 |
| Mine | Skaven | 2 | 220 | 72 | 1.5 | 1.0 | 48 | 0 | +48 | 0 of 3 | 3 of 3 | - | +48 |
| Mine | Tomb Kings of Khemri | 2 | 93 | 639 | 5.5 | 1.1 | 116 | 67 | +49 | 4 of 11 | 10 of 11 | -540 | +108 |
| Mine | Vampire Counts | 2 | 0 | 436 | 5.0 | 1.1 | 87 | 50 | +37 | 3 of 10 | 5 of 10 | +0 | +41 |
| Mine | Warriors of Chaos | 2 | 0 | 167 | 4.5 | 1.1 | 37 | 52 | -15 | 1 of 9 | 7 of 9 | +0 | -16 |
| **Mine** | all armies | 36 | 214 | 301 | 3.4 | 1.1 | 90 | 41 | +48 | 39 of 121 | 91 of 121 | +90 | +41 |
| Opponent | Empire of Man | 1 | 300 | 105 | 1.0 | 1.0 | 105 | 0 | +105 | 0 of 1 | 1 of 1 | - | +105 |
| Opponent | High Elf Realms | 5 | 10 | 331 | 3.6 | 1.1 | 92 | 41 | +51 | 8 of 18 | 17 of 18 | +85 | +46 |
| Opponent | Lizardmen | 2 | 0 | 764 | 3.5 | 1.0 | 218 | 0 | +218 | 3 of 7 | 5 of 7 | - | +218 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 457 | 3.7 | 1.1 | 125 | 10 | +115 | 2 of 11 | 8 of 11 | -110 | +137 |
| Opponent | Skaven | 4 | 42 | 82 | 1.8 | 1.1 | 47 | 0 | +47 | 3 of 7 | 5 of 7 | +0 | +54 |
| Opponent | Tomb Kings of Khemri | 2 | 232 | 246 | 2.5 | 1.0 | 99 | 26 | +72 | 2 of 5 | 3 of 5 | - | +72 |
| Opponent | Vampire Counts | 6 | 0 | 396 | 3.8 | 1.2 | 103 | 66 | +38 | 10 of 23 | 13 of 23 | -38 | +53 |
| Opponent | Warriors of Chaos | 7 | 0 | 359 | 3.6 | 1.2 | 101 | 8 | +92 | 11 of 25 | 18 of 25 | +90 | +93 |
| Opponent | Wood Elf Realms | 6 | 64 | 727 | 4.8 | 1.2 | 150 | 20 | +131 | 16 of 29 | 17 of 29 | +186 | +116 |
| **Opponent** | all armies | 36 | 38 | 409 | 3.5 | 1.2 | 117 | 26 | +91 | 55 of 126 | 87 of 126 | +78 | +93 |

### Effective charges: fw-h2h-opp-e441028-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 0 | 2 (net +0) | 0 | 3 (net +92) | 1 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 13 | 1 (net -620) | 0 | 0 | 1 (net +0) | 2 (net +92) | 6 (net +68) | 3 | 0% (0 of 10) |
| Mine | Dwarfen Mountain Holds | 9 | 1 (net +0) | 1 (net +125) | 0 | 2 (net +232) | 1 (net +60) | 4 (net -32) | 0 | 0% (0 of 9) |
| Mine | Empire of Man | 11 | 2 (net -320) | 0 | 2 (net +61) | 4 (net +52) | 0 | 3 (net +201) | 0 | 18% (2 of 11) |
| Mine | Grand Cathay | 13 | 1 (net -217) | 0 | 2 (net -128) | 3 (net +0) | 2 (net +30) | 3 (net +53) | 2 | 18% (2 of 11) |
| Mine | High Elf Realms | 20 | 3 (net +167) | 0 | 3 (net +30) | 4 (net -5) | 4 (net +91) | 5 (net +154) | 1 | 16% (3 of 19) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +210) | 0 | 0 | 2 (net +270) | 2 | 33% (1 of 3) |
| Mine | Lizardmen | 3 | 1 (net +370) | 0 | 2 (net +360) | 0 | 0 | 0 | 0 | 67% (2 of 3) |
| Mine | Ogre Kingdoms | 8 | 0 | 0 | 1 (net +0) | 1 (net -185) | 0 | 2 (net +55) | 4 | 25% (1 of 4) |
| Mine | Skaven | 3 | 1 (net +145) | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 11 | 0 | 1 (net -195) | 2 (net +125) | 3 (net -105) | 0 | 4 (net +172) | 1 | 20% (2 of 10) |
| Mine | Vampire Counts | 10 | 2 (net +0) | 3 (net +15) | 1 (net +99) | 0 | 3 (net +40) | 1 (net +107) | 0 | 10% (1 of 10) |
| Mine | Warriors of Chaos | 9 | 1 (net -465) | 0 | 1 (net +0) | 2 (net +0) | 2 (net +114) | 3 (net +36) | 0 | 11% (1 of 9) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 1 (net +105) | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 18 | 1 (net +452) | 0 | 1 (net +0) | 4 (net +147) | 0 | 3 (net +9) | 9 | 11% (1 of 9) |
| Opponent | Lizardmen | 7 | 0 | 0 | 2 (net +384) | 2 (net +0) | 0 | 0 | 3 | 50% (2 of 4) |
| Opponent | Orc & Goblin Tribes | 11 | 1 (net +0) | 1 (net +706) | 1 (net +185) | 0 | 1 (net -110) | 1 (net +0) | 6 | 20% (1 of 5) |
| Opponent | Skaven | 7 | 1 (net +0) | 0 | 0 | 0 | 0 | 6 (net +54) | 0 | 0% (0 of 7) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 2 (net -33) | 1 (net +222) | 0 | 1 (net +126) | 1 | 50% (2 of 4) |
| Opponent | Vampire Counts | 23 | 6 (net +76) | 0 | 3 (net +83) | 7 (net -134) | 5 (net +152) | 0 | 2 | 14% (3 of 21) |
| Opponent | Warriors of Chaos | 25 | 2 (net -104) | 0 | 4 (net +59) | 3 (net +184) | 0 | 7 (net +100) | 9 | 25% (4 of 16) |
| Opponent | Wood Elf Realms | 29 | 4 (net +97) | 0 | 4 (net +122) | 7 (net +37) | 2 (net +184) | 11 (net +187) | 1 | 14% (4 of 28) |

### Charged fights, damage counted: fw-h2h-opp-e441028-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 257 | 269 | -71 | 82 | 174 | -92 | -35.9 |
| Mine | 50-54% | 5 | 270 | 328 | -5 | 34 | 39 | -5 | -1.9 |
| Mine | Effective (55-75%) | 16 | 397 | 243 | +77 | 180 | 82 | +97 | +24.5 |
| Mine | 76-89% | 23 | 308 | 194 | +7 | 104 | 89 | +15 | +4.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 | 253 | 177 | +101 | 121 | 19 | +103 | +40.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 461 | 78 | +73 | 83 | 0 | +83 | +17.9 |
| Mine | No odds | 14 | 215 | 166 | +53 | 78 | 25 | +54 | +24.9 |
| Mine | All fights | 121 | 303 | 192 | +48 | 108 | 57 | +52 | +17.1 |
| Opponent | Long shot (under 50%) | 15 | 236 | 269 | +72 | 97 | 30 | +68 | +28.7 |
| Opponent | 50-54% | 1 | 350 | 251 | +706 | 706 | 50 | +656 | +187.4 |
| Opponent | Effective (55-75%) | 17 | 259 | 243 | +110 | 126 | 23 | +103 | +39.9 |
| Opponent | 76-89% | 24 | 351 | 224 | +28 | 125 | 98 | +27 | +7.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 341 | 238 | +111 | 151 | 29 | +122 | +35.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 449 | 97 | +125 | 158 | 12 | +146 | +32.5 |
| Opponent | No odds | 31 | 312 | 140 | +89 | 126 | 31 | +95 | +30.5 |
| Opponent | All fights | 126 | 320 | 205 | +91 | 135 | 41 | +94 | +29.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h-opp-e441028-p4 | move | 487 | 142 (29%) | 88 (18%) | 51 (10%) | 294 (60%) |
| fw-h2h-opp-e441028-p4 | objective | 441 | 65 (15%) | 39 (9%) | 57 (13%) | 319 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

# Doctrine scorecard: fw-h2h-mine-e441028-p1

### Scorecard: fw-h2h-mine-e441028-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 12 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 1 | 1 | 6 | 1 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 4 | 2 | 4 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 2 | 2 | 2 | 2 | 1 | 0 | 0 | 255 |
| L0235 | 1 | 1 | Opponent | no | 1 | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 7 | 2 | 2 | 0 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 5 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 475 |
| L0421 | 1 | 1 | Mine | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 952 |
| L0508 | 4 | 1 | Mine | no | 0 | 4 | 0 | 1 | 0 | 0 | 0 | 475 |
| L0508 | 4 | 1 | Opponent | no | 7 | 4 | 4 | 4 | 0 | 0 | 0 | 690 |
| L0524 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 16 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 1 | 3 | 3 | 1 | 0 | 0 | 0 | 693 |
| L0628 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 4 | - | 2 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 0 | 4 | 1 | 1 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 4 | 0 | 0 | 0 | 334 |
| L0823 | 1 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 730 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 4 | 3 | 0 | 0 | 90 |
| L0913 | 1 | 1 | Mine | no | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0913 | 1 | 1 | Opponent | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 619 |
| L0930 | 6 | 1 | Opponent | no | 5 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 3 | - | 4 | 2 | 1 | 0 | 0 | 210 |
| L1114 | 4 | 1 | Mine | yes | 7 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 5 | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | yes | 3 | 2 | 3 | 4 | 0 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 3 | 4 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | 1 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 1 | 1 | 0 | 0 | 156 |
| L1335 | 3 | 1 | Mine | no | 4 | 6 | 2 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 4 | 0 | 0 | 0 | 158 |
| L1431 | 3 | 1 | Mine | yes | 4 | 3 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 1 | - | 2 | 0 | 0 | 0 | 0 | 170 |
| L1527 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 2 | 3 | 2 | 1 | 2 | 0 | 0 | 83 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 90 |
| L1823 | 5 | 1 | Mine | yes | - | 3 | 11 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 7 | 1 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 72 |
| L2025 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 2 | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 7 | - | 1 | 4 | 1 | 0 | 0 | 355 |
| L2127 | 3 | 1 | Opponent | no | 4 | 4 | 2 | 4 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 4 | 0 | 2 | 3 | 0 | 0 | 144 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | - | 5 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | 1 | 5 | 1 | 0 | 0 | 0 | 98 |
| L2934 | 6 | 1 | Mine | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 26% | 3.1 | 2.8 | 2.7 | 0.9 | 0.3 | 0.0 | 0.0 | 240.6 |
| **Average** | | | Opponent | 15% | 2.6 | 2.2 | 2.9 | 1.8 | 0.4 | 0.0 | 0.0 | 128.4 |

### KPIs: fw-h2h-mine-e441028-p1

Rules off - Opponent only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 55% (94 of 170) | 0% (0 of 179) | 27% (94 of 349) |
| Winner chose to follow up after the loser gave ground |  | 98% (59 of 60); on the table 98% | 98% (62 of 63); on the table 98% | 98% (121 of 123); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (4 of 5); on the table 80% | 91% (10 of 11); on the table 91% | 88% (14 of 16); on the table 88% |
| Winner chose to pursue after the loser fled |  | 73% (27 of 37); on the table 78% | 82% (33 of 40); on the table 82% | 78% (60 of 77); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 88% (90 of 102); on the table 90% | 92% (105 of 114); on the table 92% | 90% (195 of 216); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 25% (81 of 330) | 29% (61 of 210) | 26% (142 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (81 of 209) | 45% (61 of 136) | 41% (142 of 345) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 37% (10 of 27) | - | 37% (10 of 27) |
| Points that never fought | lower | 38% (26898 of 71484) | 37% (26534 of 71889) | 37% (53432 of 143373) |
|   infantry points that never fought | lower | 33% (5625 of 16863) | 48% (6370 of 13348) | 40% (11995 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 51% (142 of 279) | 58% (170 of 295) | 54% (312 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 82% (18 of 22); 1.5 uses a game | 70% (14 of 20); 1.3 uses a game | 76% (32 of 42); 1.4 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.6 uses a game | 50% (4 of 8); 0.2 uses a game | 54% (13 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 50% (6 of 12); 0.2 uses a game | 48% (15 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (27936 of 59666) | 52% (32818 of 62699) | 50% (60754 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (21%) | 1.5 (36%) | 2.9 (27%) |
| MARCHED: its unit marched | 1.6 (23%) | 0.4 (9%) | 2.0 (18%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.2 (4%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.6 (22%) | 0.5 (11%) | 2.0 (18%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| FLEEING: fleeing | 0.3 (4%) | 0.2 (5%) | 0.5 (4%) |
| GONE: slain | 0.9 (13%) | 1.2 (28%) | 2.1 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (9%) | 0.2 (5%) | 0.9 (8%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.4 | 1.8 | 1.7 | 3.9 | 0.4 | 2.1 |
| not cast | 4.6 | 2.5 | 3.0 | 11.1 | 2.0 | 21.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (44%) | 0.2 (6%) | 2.9 (27%) | 0.4 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (18%) | 0.4 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.2 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.3 (11%) | 0.6 (19%) | 2.0 (18%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.4 (8%) | 0.0 (0%) | 0.1 (5%) | 0.5 (4%) | 0.1 (4%) | 1.0 (5%) |
| GONE: slain | 1.8 (38%) | 0.6 (22%) | 1.0 (32%) | 2.1 (19%) | 0.2 (8%) | 3.5 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (4%) | 0.1 (4%) | 0.9 (8%) | 0.0 (0%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.2 (5%) | 0.1 (2%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (9%) | 0.0 (0%) | 0.1 (1%) | 0.4 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (42%) | 0.2 (7%) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.6 a game | 1.0 a game |
| stood (cast and not dispelled) | 64% (27 of 42) | 55% (12 of 22) | 61% (39 of 64) |
| the unit moved after it | 59% (16 of 27) | 33% (4 of 12) | 51% (20 of 39) |
| it charged on its next turn | 11% (3 of 27) | 0% (0 of 12) | 8% (3 of 39) |
| the enemy charged it first | 19% (5 of 27) | 8% (1 of 12) | 15% (6 of 39) |
| it fought by the end of its next turn | 15% (4 of 27) | 0% (0 of 12) | 10% (4 of 39) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (2 of 27) | 0% (0 of 12) | 5% (2 of 39) |
| none of these (no charge, no fight, no charge escaped) | 59% (16 of 27) | 92% (11 of 12) | 69% (27 of 39) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (529 of 904) | 52% (327 of 630) | 56% (856 of 1534) |
|   cavalry | 39% (28 of 72) | 49% (65 of 134) | 45% (93 of 206) |
|   character | 45% (54 of 119) | 27% (33 of 124) | 36% (87 of 243) |
|   chariot | 54% (52 of 97) | 74% (25 of 34) | 59% (77 of 131) |
|   infantry | 48% (130 of 272) | 58% (136 of 236) | 52% (266 of 508) |
|   monster | 59% (29 of 49) | 47% (15 of 32) | 54% (44 of 81) |
|   war machine | 80% (236 of 295) | 76% (53 of 70) | 79% (289 of 365) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.2 (31%) | 2.1 (25%) | 5.4 (28%) |
| CHARGED: it charged | 1.2 (12%) | 1.6 (19%) | 2.9 (15%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.6 (7%) | 1.2 (6%) |
| NO TARGET IN RANGE | 2.1 (20%) | 1.5 (18%) | 3.6 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (7%) | 0.9 (11%) | 1.7 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (16%) | 1.2 (14%) | 2.8 (15%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (2%) | 0.3 (1%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.5 (5%) | 0.1 (1%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.4 | 0.7 | 84% | 5.0 pts | 17 pts |
| character | 2.8 | 0.8 | 75% | 9.7 pts | 28 pts |
| chariot | 2.1 | 1.4 | 68% | 14.2 pts | 30 pts |
| infantry | 11.1 | 4.0 | 75% | 9.4 pts | 104 pts |
| monster | 1.4 | 0.6 | 71% | 8.5 pts | 12 pts |
| war machine | 8.0 | 5.9 | 64% | 24.8 pts | 199 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 6.4 | 5.4 |
| Charges that made contact a game | 3.2 | 4.7 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.73 declared, 0.54 contact (26 units) | 0.41 declared, 0.26 contact (27 units) | 0.57 declared, 0.40 contact (53 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (5 units) | 1.27 declared, 1.00 contact (11 units) | 0.88 declared, 0.69 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.41 contact (251 units) | 0.72 declared, 0.52 contact (288 units) | 0.64 declared, 0.47 contact (539 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (34 of 70) | 62% (13 of 21) | 12% (1 of 8) | 48% (48 of 99) |
| Character in a unit | 72% (18 of 25) | 53% (9 of 17) | 25% (1 of 4) | 61% (28 of 46) |
| Character on its own | 87% (54 of 62) | 56% (24 of 43) | 37% (23 of 62) | 60% (101 of 167) |
| Chariot | 44% (7 of 16) | 50% (5 of 10) | - | 46% (12 of 26) |
| Infantry | 55% (49 of 89) | 28% (10 of 36) | 100% (2 of 2) | 48% (61 of 127) |
| Monster | 53% (17 of 32) | 70% (7 of 10) | - | 57% (24 of 42) |
| Monstrous | 64% (7 of 11) | 43% (6 of 14) | - | 52% (13 of 25) |
| War Machines | 59% (24 of 41) | 100% (1 of 1) | - | 60% (25 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 96% (25 of 26); on the table 96% | 28% (38 of 138) | 25% | 39% (13 of 33) | 67% (6 of 9); 2.7 uses a game | 100% (3 of 3); 1.5 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 86% (6 of 7); on the table 86% | 29% (7 of 24) | 35% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 87% (13 of 15); on the table 87% | - | 45% | 73% (30 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 70% (7 of 10); on the table 80% | 31% (11 of 36) | 51% | 53% (34 of 64) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 93% (14 of 15); on the table 93% | 17% (18 of 108) | 37% | 41% (18 of 44) | 92% (11 of 12); 7.6 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |
| High Elf Realms | 6 | 79% (11 of 14); on the table 86% | 10% (3 of 30) | 36% | 47% (23 of 49) | 100% (5 of 5); 2.8 uses a game | 56% (10 of 18); 3.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 43% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | - | - | 34% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 71% (5 of 7); on the table 71% | 17% (2 of 12) | 41% | 57% (12 of 21) | 33% (1 of 3); 1.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (16 of 16); on the table 100% | 28% (10 of 36) | 47% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (13 of 13); on the table 100% | 20% (6 of 30) | 40% | 65% (22 of 34) | 100% (3 of 3); 2.5 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Tomb Kings of Khemri | 6 | 90% (18 of 20); on the table 90% | 8% (1 of 12) | 35% | 30% (9 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 92% (23 of 25); on the table 92% | 44% (24 of 54) | 40% | 64% (32 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 93% (26 of 28); on the table 93% | 37% (11 of 30) | 27% | 61% (45 of 74) | 100% (4 of 4); 1.2 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 88% (15 of 17); on the table 88% | 37% (11 of 30) | 36% | 55% (36 of 66) | 33% (2 of 6); 0.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h-mine-e441028-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (48) | 45% (29) | 47% (77) |
| ...free all their last turn and able to turn (per game) | 0.81 | 0.53 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.11 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.39 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.36 | 1.31 | 2.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.72 | 1.00 | 1.72 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.53 | 6.72 | 13.25 |

### Quality by phase: fw-h2h-mine-e441028-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 0.0 |
| Strategy | Charge objectives carried out (made contact) | 53% (62 of 118) | 46% (92 of 201) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (119 of 285) | 46% (71 of 153) |
| Strategy | Close-in objectives charged next turn | 13% (21 of 157) | 14% (28 of 205) |
| Strategy | Support requests answered (helper made contact too) | 67% (8 of 12) | 62% (24 of 39) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 80% (4 of 5) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 64% (7 of 11) | 58% (14 of 24) |
| Strategy | Joined characters whose unit fought | 54% (21 of 39) | 52% (13 of 25) |
| Strategy | Lone characters that fought | 72% (77 of 107) | 57% (63 of 111) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 0.9 | 1.8 |
| Movement | Points that never moved of their own | 240.6 | 128.4 |
| Movement | Fights charged into per game | 2.8 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 87, net +7 | 17 of 116, net -65 |
| Movement | Charges with odds: sweet spot (55-75%) | 6 of 87, net +79 | 21 of 116, net -20 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 87, net +164 | 15 of 116, net +116 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 87, net +114 | 44 of 116, net +141 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.8 | 8.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (142 of 315) | 45% (135 of 301) |
| Shooting | Points destroyed by shooting units | 80.5 | 37.1 |
| Shooting | War machine shots | 6.6 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (132 of 236) | 45% (24 of 53) |
| Shooting | Points destroyed by war machines | 108.3 | 24.6 |
| Magic | Magic missiles cast | 1.6 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (18 of 56) | 40% (18 of 45) |
| Magic | Wounds caused by magic missiles | 4.3 | 1.8 |
| Magic | Wounds caused by other spells | 2.0 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 123.5 | 61.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.4 / 0.9 / 0.1 | 1.2 / 0.8 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 311.8 | 361.1 |
| Combat | Points run down | 77.9 | 116.4 |
| Combat | Net points per charged fight, damage counted | +74 | +60 |
| Combat | Net per 100 charger points, damage counted | +26.9 | +21.8 |
| Combat | First round won (charged fights) | 69% | 62% |
| Combat | Net points per charged fight | +72 | +62 |
| Combat | Net points per supported fight / lone fight | +139 / +59 | +9 / +74 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 99 | 62 of 135 |
| Game | Points lost | 713.9 | 819.6 |
| Game | VP from objectives | 698.1 | 498.9 |
| Game | Lone holders (player turns) | 3.1 | 2.6 |

- Mine won / drew / lost: 16 / 7 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) +319 VP
- The side that went first won 19 of 29 games with a winner
- Points traded per game (both sides' losses): 1534
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-h2h-mine-e441028-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.6 | +0.0 | 0.0 | 7.2 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.3 | +10.4 | 0.0 | 32.5 | 0.9 | +6.7 | 0.0 | 28.8 |
| BEST FACING | 0.6 | +19.3 | 0.0 | 1.8 | - | - | - | - |
| BEST FIRST | 3.9 | +202.2 | 191.9 | 45.1 | - | - | - | - |
| BEST OVERALL | 0.6 | +32.3 | 0.0 | 16.8 | 0.4 | +26.0 | 0.0 | 5.4 |
| BEST PREY | 0.6 | +32.5 | 21.4 | 14.4 | 5.2 | +307.3 | 190.2 | 140.1 |
| BEST PRIZE | 0.1 | -9.7 | 3.9 | 16.8 | 0.1 | -1.1 | 2.5 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -1.8 | 0.0 | 50.7 | 0.1 | -0.4 | 0.0 | 30.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 10.3 | 5.4 |
| BLOCKED WHEEL | 0.4 | +6.2 | 0.0 | 11.3 | 0.5 | +2.4 | 0.0 | 4.2 |
| BOMBING RUN | 0.1 | +6.8 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 100.4 | 4.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 5.0 | +232.5 | 469.8 | 74.0 | 1.1 | +17.1 | 108.1 | 7.2 |
| CARRIES OUT COUNTER | 0.1 | -1.7 | 11.9 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -1.9 | 26.1 | 5.2 | 0.2 | -1.7 | 14.1 | 0.0 |
| CAST JOB | 0.3 | +13.1 | 42.4 | 1.8 | 0.7 | +17.1 | 25.6 | 51.8 |
| CASTING BLOCK | 0.0 | +13.1 | 7.6 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 54.2 | 0.3 | +0.0 | 0.0 | 30.1 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.2 | 3.1 | 5.2 | 0.1 | -0.9 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.4 | -45.9 | 9.3 | 13.7 | 0.7 | -36.8 | 23.1 | 61.8 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.2 | +0.0 | 1.8 | 2.4 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.3 | 0.0 | 11.1 | 0.1 | -2.1 | 0.0 | 15.0 |
| CHEAP HELPER | 0.0 | +0.0 | 7.6 | 0.0 | 0.2 | +0.0 | 16.2 | 2.9 |
| COMBAT PIVOT | 0.4 | +0.0 | 14.5 | 13.2 | 0.4 | +0.0 | 20.3 | 35.8 |
| CONVEYANCE SEARCH | 0.7 | +83.9 | 32.2 | 32.2 | 0.4 | +86.1 | 21.5 | 51.6 |
| COUNTER-CHARGE COVER | 8.6 | +851.4 | 0.0 | 235.7 | 6.8 | +641.7 | 0.0 | 127.7 |
| DEFENSIVE ARMY | 0.5 | -0.0 | 38.7 | 9.1 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +10.4 | 37.3 | 0.0 | 0.1 | +2.7 | 25.7 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +0.7 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +103.0 | 0.0 | 48.9 | 1.3 | +107.8 | 0.0 | 25.5 |
| FALLBACK BY WORTH | 4.4 | +42.8 | 0.0 | 42.6 | 8.1 | +115.3 | 0.0 | 112.8 |
| FIGHT LIFT | 0.0 | +0.1 | 1.7 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.5 |
| FLANK NOT WEIGHED | 6.5 | +0.0 | 0.0 | 254.6 | 5.9 | +0.0 | 0.0 | 153.6 |
| FOCUS FIRE | 0.0 | +0.8 | 5.1 | 0.0 | 0.0 | +0.1 | 0.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +101.3 | 0.0 | 10.1 | 1.2 | +169.7 | 0.0 | 37.5 |
| FRIENDS SHOTS CHECKED | 0.2 | +12.6 | 0.0 | 10.9 | 0.2 | +10.6 | 0.0 | 3.5 |
| GIVES UP | 0.8 | -48.8 | 100.0 | 53.6 | 1.4 | -64.2 | 177.6 | 26.7 |
| GIVES UP ITS SCREEN | 0.1 | -0.0 | 11.2 | 0.0 | 1.1 | -25.7 | 58.4 | 8.9 |
| GROUND FLIERS | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 17.5 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 24.8 | 1.8 | 0.6 | +0.0 | 20.8 | 27.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.4 | +8.5 | 20.6 | 14.9 | 0.5 | +26.3 | 60.2 | 8.2 |
| HUNT DROPPED | 0.1 | +0.0 | 22.8 | 4.2 | 0.2 | +0.0 | 2.6 | 5.2 |
| HUNT IN PAIRS | 0.4 | +11.7 | 0.0 | 0.0 | 0.6 | +32.7 | 0.0 | 13.9 |
| HUNT KEPT | 0.2 | +4.0 | 22.5 | 9.8 | 0.2 | +9.0 | 37.4 | 10.3 |
| HUNT RESULT | 0.3 | +20.5 | 34.0 | 5.7 | 0.4 | +53.1 | 9.0 | 8.1 |
| HUNT THE GUNS | 0.3 | +140.0 | 30.4 | 8.1 | 0.5 | +192.2 | 36.4 | 4.3 |
| INVITES THE FIGHT | 4.1 | +314.0 | 175.0 | 118.7 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +7.7 | 0.0 | 0.0 | 0.4 | +38.3 | 16.6 | 1.4 |
| KEEP FALLS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.5 | +5.3 | 13.8 | 42.3 |
| KEEPS ITS TARGET | 1.6 | +49.2 | 201.2 | 62.8 | 2.6 | +77.5 | 223.6 | 29.9 |
| KILLS COUNT | 1.5 | +86.7 | 74.8 | 53.4 | 2.0 | +156.8 | 149.6 | 43.8 |
| KILLS COUNT NEXT TURN | 4.6 | +152.8 | 295.4 | 148.4 | 11.1 | +466.5 | 491.1 | 296.5 |
| LONE CHARACTER SAFE SPOT | 0.7 | +15.7 | 16.8 | 42.2 | 0.8 | +14.3 | 21.7 | 39.2 |
| LONE WIZARD HOLDS BACK | 0.8 | +0.0 | 22.6 | 51.1 | 1.9 | +0.0 | 15.6 | 75.4 |
| LONG SHOT | 0.5 | -1.0 | 27.3 | 15.2 | - | - | - | - |
| LOST CHARGE | 2.7 | -66.0 | 111.4 | 121.1 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -8.6 | 0.0 | 0.8 | - | - | - | - |
| MAKE SURE TOGETHER | 0.5 | +45.3 | 0.0 | 13.8 | 0.9 | +67.3 | 9.5 | 12.0 |
| MANOEUVRE | 0.3 | +6.8 | 0.0 | 1.8 | 0.2 | +3.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +17.5 | 0.0 | 41.5 | 0.7 | +29.1 | 0.0 | 35.6 |
| MARCH ODDS | 0.1 | +11.3 | 0.0 | 0.0 | 0.2 | +8.1 | 0.0 | 6.2 |
| MARCH OVER CASTS | 0.9 | +64.8 | 0.0 | 53.3 | 0.3 | +19.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.9 | +221.1 | 0.0 | 127.0 | 4.4 | +200.9 | 0.0 | 97.3 |
| MISSILES IN THE MOVE | 4.1 | +151.6 | 0.0 | 131.3 | 3.4 | +65.6 | 0.0 | 125.3 |
| MISSILES NEXT TURN | 5.4 | +128.7 | 0.0 | 184.6 | 4.2 | +48.8 | 0.0 | 154.2 |
| MODEL FACING | 0.4 | +73.2 | 0.0 | 6.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 7.9 | 0.0 | 0.2 | +0.0 | 12.9 | 0.0 |
| MOVE AND CAST | 0.3 | +14.1 | 0.0 | 1.8 | 0.3 | +10.2 | 0.0 | 31.6 |
| MOVE SPELL IN RANGE | 0.4 | +10.0 | 0.0 | 31.0 | 0.4 | +18.9 | 0.0 | 37.7 |
| MOVE SPELL OUT OF RANGE | 0.3 | -10.5 | 0.0 | 19.7 | 0.4 | -21.0 | 0.0 | 60.2 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 4.8 | +354.8 | 260.0 | 138.0 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +9.6 | 6.9 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -15.1 | 18.0 | 1.8 | 0.4 | -32.9 | 44.7 | 1.7 |
| NOT TURNED | 6.5 | +155.6 | 0.0 | 200.6 | 6.7 | +56.6 | 0.0 | 170.8 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 40.8 | 0.3 | -0.2 | 0.0 | 11.2 |
| OFF BEST | 15.1 | -734.2 | 7.6 | 305.5 | 18.9 | -1112.1 | 51.1 | 330.4 |
| OPENS A LANE | 0.2 | +0.6 | 21.6 | 0.0 | 0.1 | +1.0 | 11.4 | 0.0 |
| OPENS UP | 0.1 | +12.6 | 2.6 | 0.0 | 0.2 | +17.3 | 9.1 | 10.8 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.5 | +13.6 | 33.9 | 38.7 | 0.6 | +6.6 | 20.5 | 34.7 |
| PATHS CROSS | 2.6 | +145.2 | 0.0 | 42.4 | 3.0 | +184.7 | 0.0 | 63.8 |
| PERIAPT WORTH | 0.0 | +1.7 | 0.0 | 15.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.1 | -2.6 | 0.0 | 4.9 | 0.1 | -3.1 | 0.0 | 0.0 |
| PLAN RESULT | 39.7 | +1389.5 | 1621.8 | 1055.2 | 41.5 | +1233.4 | 1532.0 | 1201.2 |
| PURSUES BIG PREY | 0.2 | -16.3 | 0.0 | 0.0 | 0.1 | -6.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +2.8 | 0.0 | 22.9 | - | - | - | - |
| RANDOM MOVER NO PROMISE | 0.1 | -2.7 | 0.0 | 8.8 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.1 | -3.5 | 0.0 | 2.8 | - | - | - | - |
| REDIRECT COUNTER | 2.0 | +179.2 | 0.0 | 27.1 | 3.9 | +226.7 | 0.0 | 68.6 |
| REDIRECT WEIGHED | 0.3 | +3.2 | 7.7 | 23.9 | 0.6 | +4.9 | 15.8 | 7.9 |
| RESERVE FALL BACK | 0.2 | +3.2 | 0.0 | 1.8 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.2 | +6.0 | 0.0 | 0.0 | 0.1 | +5.9 | 0.0 | 6.5 |
| RISK BY ARC | 2.1 | +69.8 | 187.7 | 61.3 | 3.2 | +51.2 | 222.8 | 83.5 |
| SAFER THAN THE JOB | 0.7 | +31.0 | 0.0 | 33.5 | 1.0 | +72.2 | 0.0 | 53.8 |
| SCREEN BY WHAT IT SAVES | 0.0 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 3.4 | +113.9 | 0.0 | 63.8 | 1.7 | +68.2 | 0.0 | 34.8 |
| SECOND HUNTER | 0.1 | -1.4 | 0.0 | 2.9 | 0.1 | -0.7 | 11.2 | 0.0 |
| SELF MOVE SPELL | 0.3 | +13.5 | 0.0 | 31.0 | 0.2 | +0.1 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.9 | +89.0 | 25.1 | 16.9 | 1.7 | +127.7 | 32.7 | 18.4 |
| SET-UP ANY TARGET | 0.2 | +15.7 | 0.0 | 0.0 | 0.2 | +20.8 | 13.9 | 13.9 |
| SET-UP MISSED | 0.1 | +16.2 | 0.0 | 0.0 | 0.1 | +14.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +33.7 | 30.3 | 7.4 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 139.4 | 18.5 | 0.1 | +0.0 | 21.4 | 1.7 |
| SHOTS IN THE MOVE | 13.8 | +544.9 | 0.0 | 216.1 | 8.2 | +158.9 | 0.0 | 139.3 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +42.5 | 11.1 | 11.1 | 0.2 | +69.8 | 13.9 | 25.1 |
| SPELL WORTH | 1.0 | +15.8 | 116.5 | 114.9 | 1.4 | +31.7 | 95.5 | 102.0 |
| STABLE ROLE | 12.6 | +0.0 | 426.4 | 163.5 | - | - | - | - |
| STANDS TO CAST | 0.0 | +0.4 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 9.1 |
| STOPS | 0.1 | +0.4 | 21.0 | 1.4 | 0.1 | +7.7 | 13.6 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +26.8 | 0.0 | 45.5 | 0.3 | +5.6 | 0.0 | 12.0 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 5.8 |
| SUPPORTS | 7.1 | +344.6 | 254.6 | 108.1 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.7 | 4.7 | 6.5 | 0.1 | -4.0 | 3.6 | 24.6 |
| SURE REACH TOGETHER | 0.3 | +2.1 | 0.0 | 3.1 | 0.7 | +9.2 | 0.0 | 7.5 |
| THROUGH LINE OF FIRE | 0.2 | +9.0 | 0.0 | 8.2 | 0.3 | +5.8 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -26.8 | 35.1 | 5.2 | 0.2 | -9.3 | 27.0 | 15.1 |
| TWO OR MORE ARRIVE | 0.4 | +11.4 | 7.0 | 4.5 | 0.5 | +5.1 | 20.4 | 9.7 |
| WALKS TO THE FIGHT | 2.8 | +122.1 | 49.8 | 40.2 | - | - | - | - |
| WAR ENGINE JOBS | 1.0 | +0.0 | 55.0 | 0.0 | - | - | - | - |
| WEARS DOWN | 0.9 | +34.3 | 141.7 | 34.9 | 1.7 | +49.3 | 148.7 | 44.4 |
| WHO HITS BACK | 0.4 | +30.8 | 0.0 | 24.3 | 0.2 | +13.4 | 0.0 | 12.8 |
| WHOLE FIGHT | 0.3 | +11.0 | 36.5 | 1.2 | 0.5 | +24.3 | 33.0 | 7.8 |
| WHOLE FIGHT GAIN | 0.2 | +27.8 | 31.1 | 9.2 | 1.1 | +92.1 | 62.4 | 22.6 |

### Rule changes: fw-h2h-mine-e441028-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1226 | 1226 | 1226 | 34.06 | -66468 | -54.2 |
| PATHS CROSS | 204 | 204 | 204 | 5.67 | +11878 | +58.2 |
| SEARCH SPOT | 184 | 184 | 180 | 5.00 | +6553 | +36.4 |
| SUPPORTS | 256 | 256 | 165 | 4.58 | +5004 | +30.3 |
| BEST FIRST | 139 | 139 | 139 | 3.86 | +7281 | +52.4 |
| KILLS COUNT NEXT TURN | 565 | 560 | 139 | 3.86 | +4713 | +33.9 |
| COUNTER-CHARGE COVER | 555 | 294 | 137 | 3.81 | +9500 | +69.3 |
| FACES THE THREAT | 96 | 96 | 96 | 2.67 | +7587 | +79.0 |
| MOVE TO CHARGE | 172 | 171 | 96 | 2.67 | +5041 | +52.5 |
| FALLBACK BY WORTH | 450 | 450 | 95 | 2.64 | +5692 | +59.9 |
| BEST PREY | 210 | 204 | 82 | 2.28 | +3462 | +42.2 |
| FOLLOW UP WEIGHED | 76 | 76 | 76 | 2.11 | +9758 | +128.4 |
| INVITES THE FIGHT | 146 | 146 | 70 | 1.94 | +4075 | +58.2 |
| WALKS TO THE FIGHT | 100 | 100 | 67 | 1.86 | +1688 | +25.2 |
| SAFER THAN THE JOB | 62 | 62 | 62 | 1.72 | +3715 | +59.9 |
| SHOTS IN THE MOVE | 792 | 514 | 53 | 1.47 | +1440 | +27.2 |
| MARCH CHECK | 54 | 53 | 52 | 1.44 | +1946 | +37.4 |
| KILLS COUNT | 128 | 118 | 51 | 1.42 | +3059 | +60.0 |
| LONE WIZARD HOLDS BACK | 97 | 97 | 50 | 1.39 | -1580 | -31.6 |
| MAX FOR POSITIONING | 334 | 180 | 49 | 1.36 | +530 | +10.8 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| KEEPS ITS TARGET | 152 | 144 | 43 | 1.19 | +554 | +12.9 |
| RISK BY ARC | 191 | 172 | 43 | 1.19 | +1304 | +30.3 |
| SET UP TOGETHER | 94 | 81 | 42 | 1.17 | +2779 | +66.2 |
| BEST OVERALL | 38 | 38 | 38 | 1.06 | +2098 | +55.2 |
| CANNON PLANNED TARGET | 220 | 220 | 37 | 1.03 | -554 | -15.0 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +3019 | +81.6 |
| ARTILLERY RE-ROLL WEIGHED | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 269 | 153 | 36 | 1.00 | +899 | +25.0 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | +310 | +9.1 |
| REDIRECT COUNTER | 215 | 100 | 33 | 0.92 | +2818 | +85.4 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +1167 | +35.4 |
| REDIRECT WEIGHED | 32 | 32 | 32 | 0.89 | +717 | +22.4 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| SHOT REPLANNED | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| MOVE AND CAST | 23 | 23 | 23 | 0.64 | +878 | +38.2 |
| CAST JOB | 38 | 38 | 22 | 0.61 | +492 | +22.3 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +1129 | +51.3 |
| BEST FACING | 20 | 20 | 20 | 0.56 | +696 | +34.8 |
| WHOLE FIGHT GAIN | 46 | 33 | 20 | 0.56 | +1342 | +67.1 |
| MAKE SURE TOGETHER | 53 | 37 | 18 | 0.50 | +1242 | +69.0 |
| THROUGH LINE OF FIRE | 18 | 18 | 18 | 0.50 | +535 | +29.7 |
| BIG CHARACTER SAFETY | 16 | 16 | 16 | 0.44 | -80 | -5.0 |
| MANOEUVRE | 19 | 19 | 16 | 0.44 | +372 | +23.2 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 14 | 14 | 14 | 0.39 | +833 | +59.5 |
| MODEL FACING | 14 | 14 | 14 | 0.39 | +2636 | +188.3 |
| WAR ENGINE JOBS | 35 | 35 | 14 | 0.39 | -993 | -70.9 |
| WEARS DOWN | 93 | 81 | 14 | 0.39 | +501 | +35.8 |
| SHOOTS FROM THE BEST SPOT | 27 | 27 | 13 | 0.36 | +459 | +35.3 |
| MARCH ODDS | 11 | 11 | 11 | 0.31 | +156 | +14.2 |
| RESTRAINS TO SHOOT | 11 | 11 | 11 | 0.31 | +428 | +38.9 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -802 | -80.2 |
| RANDOM MOVE BY FIGURES | 27 | 27 | 10 | 0.28 | +101 | +10.1 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | -41 | -4.6 |
| HUNT ADVANCE | 35 | 35 | 9 | 0.25 | +349 | +38.8 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -204 | -22.7 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -277 | -30.8 |
| WHOLE FIGHT | 29 | 27 | 8 | 0.22 | +311 | +38.9 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -610 | -87.1 |
| HUNT IN PAIRS | 36 | 24 | 7 | 0.19 | +424 | +60.6 |
| LOST CHARGE | 96 | 96 | 7 | 0.19 | +102 | +14.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| OPENS UP | 12 | 12 | 7 | 0.19 | +279 | +39.9 |
| RESERVE FALL BACK | 7 | 7 | 7 | 0.19 | +116 | +16.6 |
| BACKUP TARGETS | 81 | 45 | 6 | 0.17 | +31 | +5.1 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| JOINT CHARGE PLAN | 21 | 21 | 6 | 0.17 | +440 | +73.3 |
| OVERRUNS AWAY | 37 | 35 | 6 | 0.17 | +235 | +39.2 |
| CARRIES OUT SET-UP | 11 | 11 | 5 | 0.14 | -129 | -25.8 |
| MISSILES NEXT TURN | 346 | 189 | 5 | 0.14 | +123 | +24.6 |
| BOMBING RUN | 4 | 4 | 4 | 0.11 | +244 | +61.0 |
| DEFENSIVE ARMY | 19 | 19 | 4 | 0.11 | -12 | -3.1 |
| NEEDED THERE | 6 | 6 | 4 | 0.11 | +0 | +0.0 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +48 | +15.9 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +26 | +12.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +35 | +17.6 |
| GIVES UP | 80 | 72 | 2 | 0.06 | +54 | +26.9 |
| KEEPS ITS PREY | 18 | 17 | 2 | 0.06 | +18 | +8.9 |
| LONG SHOT | 17 | 17 | 2 | 0.06 | -122 | -61.2 |
| OPENS A LANE | 12 | 4 | 2 | 0.06 | +11 | +5.7 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +35 | +17.6 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +7 | +3.4 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -60 | -60.0 |
| CASTING BLOCK | 1 | 1 | 1 | 0.03 | +301 | +300.9 |
| CHARIOT NO STATIC JOB | 6 | 6 | 1 | 0.03 | -16 | -16.3 |
| EDGE GIVE GROUND | 7 | 7 | 1 | 0.03 | +33 | +32.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +0 | +0.3 |
| MOVE SPELL IN RANGE | 28 | 17 | 1 | 0.03 | +3 | +2.8 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +61 | +61.2 |
| SURE REACH TOGETHER | 35 | 20 | 1 | 0.03 | +16 | +15.6 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 30 | 30 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 42 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 446 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 40 | 33 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 24 | 20 | 0 | 0.00 | - | - |
| HUNT DROPPED | 13 | trace | - | - | - | - |
| HUNT KEPT | 15 | trace | - | - | - | - |
| HUNT RESULT | 28 | trace | - | - | - | - |
| HUNT THE GUNS | 30 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 56 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 11 | trace | - | - | - | - |
| MARCH OVER CASTS | 44 | 44 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NOT NEEDED | 24 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 477 | 477 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2922 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SECOND HUNTER | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 19 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 8 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 19 | not checked | - | - | - | - |
| SPELL WORTH | 88 | not checked | - | - | - | - |
| STABLE ROLE | 452 | 448 | 0 | 0.00 | - | - |
| STOPS | 7 | 7 | 0 | 0.00 | - | - |
| TURN WORTH | 22 | 20 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 34 | 29 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h-mine-e441028-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.83 | 15.14 | 55.7 |
| FALLBACK | gate | 0.50 | 1.25 | 66.5 |
| TURN GATE | gate | 1.00 | 0.44 | 37.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.42 | 0.50 | 69.5 |
| RULE SWITCHED OFF | gate | - | 0.83 | 14.3 |
| LONE WIZARD HOLDS BACK | rule | 0.19 | 0.42 | 71.8 |
| SUPPORT REQUEST | gate | 0.08 | 0.47 | 71.4 |
| PATHS CROSS | rule | 0.14 | 0.28 | 33.0 |
| WAR ENGINE JOBS | rule | 0.39 | - | 70.9 |
| CANNON PLANNED TARGET | rule | 0.33 | 0.03 | 51.2 |
| AFTERMATH BAND | gate | 0.08 | 0.19 | 2.6 |
| PURSUES BIG PREY | rule | 0.17 | 0.11 | 80.2 |
| BIG CHARACTER SAFETY | rule | 0.19 | 0.06 | 11.0 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.11 | 22.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.11 | 30.8 |
| BEST PRIZE | rule | 0.14 | 0.06 | 87.1 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.14 | 30.8 |
| FIGHT ORDER BAND | gate | 0.08 | 0.08 | 2.1 |
| BLOCKED WHEEL | rule | 0.06 | 0.08 | 40.5 |
| CARRIES OUT SET-UP | rule | 0.08 | 0.06 | 25.8 |
| REDIRECT WEIGHED | rule | 0.08 | 0.06 | 80.2 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | 0.03 | 10.7 |
| SAFER THAN THE JOB | rule | 0.08 | 0.03 | 11.3 |
| CHAFF PASSED | rule | 0.03 | 0.06 | 13.7 |
| DEFENSIVE ARMY | rule | 0.08 | - | 4.1 |
| NO REASON | gate | 0.08 | - | 18.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 25.6 |
| MARCH ODDS | rule | 0.03 | 0.03 | 3.8 |
| THROUGH LINE OF FIRE | rule | - | 0.06 | 29.9 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 60.0 |
| CHARIOT NO STATIC JOB | rule | - | 0.03 | 16.3 |
| FALLBACK BY WORTH | rule | 0.03 | - | 64.8 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 2.1 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 2.4 |
| LONG SHOT | rule | 0.03 | - | 161.7 |
| STANDS TO CAST | rule | 0.03 | - | 2.8 |

### Plans: fw-h2h-mine-e441028-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.4 | 18% | 952 | 398 | 42% |
| Mine | charge | 2.7 | 58% | 319 | 239 | 75% |
| Mine | close in | 4.2 | 28% | 475 | 209 | 44% |
| Mine | hold | 4.1 | 42% | 278 | 0 | 0% |
| Mine | join | 1.6 | 97% | 59 | 0 | 0% |
| Mine | shoot | 6.4 | 61% | 280 | 543 | 194% |
| Mine | support | 7.2 | 93% | 266 | 0 | 0% |
| Opponent | advance | 14.8 | 19% | 695 | 483 | 69% |
| Opponent | charge | 4.4 | 58% | 407 | 368 | 90% |
| Opponent | close in | 5.7 | 27% | 475 | 166 | 35% |
| Opponent | hold | 3.8 | 31% | 230 | 0 | 0% |
| Opponent | join | 2.6 | 95% | 124 | 0 | 0% |
| Opponent | shoot | 3.6 | 65% | 62 | 216 | 348% |
| Opponent | support | 6.6 | 89% | 250 | 0 | 0% |

### Packages: hunt the guns, fw-h2h-mine-e441028-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 12 | 0 | 8% | 17% | 0% | 4.0 | 420 | 61 | 17% | 13 |
| Opponent | 0.5 | 18 | 2 | 6% | 38% | 12% | 2.5 | 395 | 119 | 31% | 131 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.5 | 9 | 0 | 11% | 11% | 0% | 6.0 | 425 | 50 | 11% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.4 | 2 | 0 | 0% | 0% | 0% | - | 416 | 0 | 0% | 96 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 38 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 140 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 1.3 | 4 | 0 | 0% | 50% | 50% | 2.0 | 156 | 71 | 50% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 181 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 146 |
| Tomb Kings of Khemri | 1.7 | 10 | 1 | 0% | 44% | 0% | 2.5 | 368 | 175 | 44% | 180 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Warriors of Chaos | 0.5 | 4 | 1 | 33% | 33% | 0% | 3.0 | 569 | 113 | 0% | 77 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 1061 | 0 | 0% | 42 |

### Battle groups: fw-h2h-mine-e441028-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.6 | 26% | 45% | 10% | 62% | 31% | 11% | 7% | 51% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 27% | 65% | 15% | 0% | 41% | 0% | 12% | 47% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.8 | 17% | 62% | 14% | 50% | 33% | 0% | 6% | 61% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 22% | 81% | 19% | 0% | 24% | 0% | 12% | 56% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h-mine-e441028-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 27 (3) | 27 | 0 | 19 | 67% | 6.0 | 0 (1) | 73 (1) | 0 (1) | - | 27 (3) |
| Mine | Chaff | 36 | 22 (36) | 3 | 19 | 56 | 36% | 2.3 | 15 (20) | 13 (11) | 71 (5) | 39 (19) | 5 (17) |
| Mine | Character | 120 | 53 (120) | 53 | 0 | 39 | 17% | 2.5 | 41 (34) | 73 (43) | 43 (30) | 52 (76) | 60 (31) |
| Mine | Clean-up | 24 | 68 (24) | 38 | 30 | 44 | 17% | 3.6 | 61 (11) | 89 (10) | 8 (3) | 62 (11) | 73 (13) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 47 | 0% | 2.5 | 0 (1) | 0 (1) | 0 (2) | 0 (2) | 0 (2) |
| Mine | Fast Hammer | 42 | 46 (42) | 29 | 16 | 56 | 31% | 2.9 | 32 (22) | 67 (10) | 55 (10) | 48 (31) | 41 (11) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 13 | 20% | 2.8 | 0 (3) | 0 (2) | - | 0 (1) | 0 (4) |
| Mine | Hammer | 56 | 49 (56) | 33 | 16 | 30 | 7% | 2.7 | 38 (23) | 63 (20) | 49 (13) | 52 (36) | 45 (20) |
| Mine | Holder | 34 | 78 (34) | 3 | 75 | 21 | 38% | 3.5 | 51 (12) | 84 (17) | 139 (4) | 87 (21) | 64 (12) |
| Mine | Shooter | 38 | 68 (38) | 23 | 45 | 49 | 3% | 2.1 | 105 (15) | 83 (12) | 3 (11) | 63 (31) | 94 (7) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 73 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 72 (56) | 72 | 0 | 30 | 4% | 1.3 | 45 (22) | 91 (17) | 87 (17) | 63 (18) | 76 (38) |
| Mine | Wizard | 26 | 15 (26) | 15 | 0 | 51 | 12% | 2.0 | 24 (8) | 20 (7) | - | 34 (9) | 11 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 73 | 47 (73) | 13 | 34 | 41 | 44% | 2.8 | 26 (29) | 44 (29) | 89 (15) | 61 (48) | 19 (25) |
| Opponent | Character | 114 | 44 (114) | 44 | 0 | 45 | 27% | 2.4 | 31 (51) | 60 (38) | 52 (21) | 45 (71) | 44 (39) |
| Opponent | Clean-up | 15 | 42 (15) | 24 | 18 | 42 | 33% | 3.1 | 28 (7) | 58 (7) | 0 (1) | 26 (9) | 58 (6) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 54 | 53 (54) | 30 | 23 | 39 | 20% | 2.9 | 58 (23) | 51 (22) | 41 (9) | 49 (42) | 64 (12) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 73 | 20% | 1.8 | 0 (3) | 0 (2) | 0 (4) | 0 (6) | 0 (3) |
| Opponent | Hammer | 59 | 44 (59) | 39 | 5 | 50 | 24% | 2.7 | 45 (23) | 39 (25) | 53 (11) | 48 (35) | 37 (24) |
| Opponent | Holder | 40 | 38 (40) | 10 | 28 | 43 | 32% | 3.6 | 42 (8) | 48 (16) | 29 (14) | 44 (20) | 33 (18) |
| Opponent | Shooter | 33 | 61 (33) | 34 | 26 | 41 | 6% | 1.5 | 71 (13) | 66 (11) | 41 (9) | 76 (15) | 48 (18) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 33 (13) | 33 | 0 | 20 | 15% | 1.0 | 30 (6) | 88 (3) | 0 (4) | 29 (6) | 36 (7) |
| Opponent | Wizard | 23 | 18 (23) | 18 | 0 | 54 | 22% | 2.4 | 34 (9) | 8 (8) | 0 (3) | 4 (12) | 54 (8) |

### Charged fights: fw-h2h-mine-e441028-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 221 | 25 | 1.8 | 1.1 | 14 | 0 | +14 | 4 of 9 | 7 of 9 | +126 | +0 |
| Mine | Chaos Dwarfs | 3 | 203 | 601 | 2.7 | 1.5 | 225 | 72 | +153 | 6 of 8 | 2 of 8 | +206 | +121 |
| Mine | Dwarfen Mountain Holds | 4 | 391 | 43 | 2.2 | 1.3 | 19 | 0 | +19 | 6 of 9 | 3 of 9 | +0 | +28 |
| Mine | Empire of Man | 5 | 628 | 239 | 1.8 | 1.1 | 133 | 42 | +91 | 1 of 9 | 6 of 9 | +145 | +84 |
| Mine | Grand Cathay | 4 | 746 | 300 | 3.0 | 1.5 | 100 | 0 | +100 | 5 of 12 | 10 of 12 | +128 | +72 |
| Mine | High Elf Realms | 4 | 419 | 526 | 3.2 | 1.1 | 162 | 55 | +107 | 6 of 13 | 10 of 13 | +527 | +72 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 384 | 3.0 | 1.0 | 128 | 27 | +101 | 1 of 3 | 2 of 3 | - | +101 |
| Mine | Lizardmen | 1 | 0 | 591 | 3.0 | 1.3 | 197 | 0 | +197 | 1 of 3 | 2 of 3 | +70 | +260 |
| Mine | Ogre Kingdoms | 1 | 0 | 286 | 5.0 | 1.0 | 57 | 0 | +57 | 0 of 5 | 4 of 5 | - | +57 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 445 | 5.0 | 1.0 | 89 | 22 | +67 | 2 of 5 | 4 of 5 | - | +67 |
| Mine | Skaven | 2 | 25 | 0 | 0.5 | 1.0 | 0 | 92 | -92 | 0 of 1 | 0 of 1 | - | -92 |
| Mine | Tomb Kings of Khemri | 2 | 58 | 375 | 3.5 | 1.0 | 107 | 38 | +69 | 0 of 7 | 6 of 7 | - | +69 |
| Mine | Vampire Counts | 2 | 0 | 148 | 4.5 | 1.0 | 33 | 100 | -67 | 5 of 9 | 6 of 9 | - | -67 |
| Mine | Warriors of Chaos | 1 | 0 | 943 | 6.0 | 1.2 | 157 | 0 | +157 | 1 of 6 | 6 of 6 | +109 | +167 |
| **Mine** | all armies | 36 | 312 | 286 | 2.8 | 1.2 | 104 | 32 | +72 | 38 of 99 | 68 of 99 | +139 | +59 |
| Opponent | Beastmen Brayherds | 1 | 410 | 290 | 7.0 | 1.4 | 41 | 24 | +18 | 3 of 7 | 2 of 7 | -81 | +34 |
| Opponent | Dwarfen Mountain Holds | 1 | 112 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 440 | 0 | 4.0 | 1.0 | 0 | 66 | -66 | 4 of 4 | 2 of 4 | - | -66 |
| Opponent | Grand Cathay | 1 | 689 | 661 | 4.0 | 1.8 | 165 | 0 | +165 | 4 of 4 | 2 of 4 | +428 | +78 |
| Opponent | High Elf Realms | 2 | 62 | 279 | 4.0 | 1.1 | 70 | 34 | +36 | 5 of 8 | 6 of 8 | -274 | +80 |
| Opponent | Lizardmen | 1 | 380 | 189 | 3.0 | 1.3 | 63 | 0 | +63 | 3 of 3 | 1 of 3 | +0 | +94 |
| Opponent | Ogre Kingdoms | 2 | 254 | 232 | 6.5 | 1.3 | 36 | 142 | -106 | 4 of 13 | 6 of 13 | -498 | -35 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 218 | 4.0 | 1.2 | 54 | 40 | +15 | 3 of 8 | 7 of 8 | -130 | +63 |
| Opponent | Skaven | 2 | 0 | 81 | 2.5 | 1.2 | 32 | 44 | -12 | 3 of 5 | 2 of 5 | +162 | -56 |
| Opponent | Tomb Kings of Khemri | 4 | 46 | 998 | 4.2 | 1.3 | 235 | 0 | +235 | 7 of 17 | 14 of 17 | +289 | +218 |
| Opponent | Vampire Counts | 6 | 50 | 459 | 3.7 | 1.2 | 125 | 62 | +63 | 9 of 22 | 14 of 22 | +7 | +75 |
| Opponent | Warriors of Chaos | 7 | 0 | 404 | 2.9 | 1.2 | 142 | 18 | +124 | 8 of 20 | 15 of 20 | +0 | +155 |
| Opponent | Wood Elf Realms | 6 | 212 | 360 | 3.8 | 1.2 | 94 | 56 | +38 | 9 of 23 | 12 of 23 | +16 | +42 |
| **Opponent** | all armies | 36 | 123 | 403 | 3.8 | 1.2 | 107 | 45 | +62 | 62 of 135 | 84 of 135 | +9 | +74 |

### Effective charges: fw-h2h-mine-e441028-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 0 | 1 (net +0) | 2 (net +63) | 0 | 4 (net +0) | 2 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 8 | 3 (net +175) | 0 | 0 | 2 (net -158) | 2 (net +237) | 1 (net +540) | 0 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 9 | 2 (net +0) | 0 | 1 (net +0) | 2 (net +56) | 0 | 4 (net +15) | 0 | 11% (1 of 9) |
| Mine | Empire of Man | 9 | 1 (net +274) | 0 | 0 | 3 (net +107) | 0 | 4 (net +103) | 1 | 0% (0 of 8) |
| Mine | Grand Cathay | 12 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +393) | 2 (net +46) | 6 (net +120) | 1 | 9% (1 of 11) |
| Mine | High Elf Realms | 13 | 2 (net -62) | 0 | 1 (net +0) | 2 (net -221) | 1 (net +527) | 7 (net +203) | 0 | 8% (1 of 13) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +85) | 0 | 0 | 1 (net -35) | 0 | 1 (net +254) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 3 (net +197) | 0 | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 0 | 3 (net +73) | 2 (net +33) | 0 | 0% (0 of 5) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 0 | 1 (net +325) | 4 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -92) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net -25) | 3 (net +75) | 0 | 1 (net +144) | 2 | 20% (1 of 5) |
| Mine | Vampire Counts | 9 | 3 (net -223) | 0 | 0 | 4 (net +50) | 0 | 1 (net +98) | 1 | 0% (0 of 8) |
| Mine | Warriors of Chaos | 6 | 0 | 0 | 1 (net +500) | 2 (net +180) | 0 | 2 (net +28) | 1 | 20% (1 of 5) |
| Opponent | Beastmen Brayherds | 7 | 1 (net -81) | 0 | 1 (net +0) | 2 (net +0) | 2 (net +145) | 1 (net -85) | 0 | 14% (1 of 7) |
| Opponent | Dwarfen Mountain Holds | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 4 | 1 (net -265) | 0 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 4 | 1 (net +233) | 0 | 1 (net +0) | 0 | 0 | 2 (net +214) | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 8 | 2 (net +0) | 0 | 0 | 1 (net -274) | 1 (net +0) | 3 (net +136) | 1 | 0% (0 of 7) |
| Opponent | Lizardmen | 3 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 13 | 1 (net -234) | 0 | 4 (net -164) | 0 | 1 (net +81) | 3 (net -209) | 4 | 44% (4 of 9) |
| Opponent | Orc & Goblin Tribes | 8 | 0 | 0 | 2 (net -130) | 0 | 2 (net +48) | 0 | 4 | 50% (2 of 4) |
| Opponent | Skaven | 5 | 0 | 0 | 0 | 1 (net +0) | 0 | 4 (net -15) | 0 | 0% (0 of 5) |
| Opponent | Tomb Kings of Khemri | 17 | 1 (net +0) | 0 | 2 (net +172) | 1 (net +306) | 3 (net +264) | 9 (net +239) | 1 | 12% (2 of 16) |
| Opponent | Vampire Counts | 22 | 5 (net -103) | 0 | 5 (net +89) | 5 (net +21) | 1 (net +0) | 4 (net +270) | 2 | 25% (5 of 20) |
| Opponent | Warriors of Chaos | 20 | 1 (net +0) | 0 | 1 (net -236) | 4 (net +41) | 4 (net +104) | 8 (net +228) | 2 | 6% (1 of 18) |
| Opponent | Wood Elf Realms | 23 | 1 (net -250) | 0 | 4 (net -12) | 5 (net +7) | 1 (net +65) | 8 (net +136) | 4 | 21% (4 of 19) |

### Charged fights, damage counted: fw-h2h-mine-e441028-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 229 | 210 | +7 | 90 | 75 | +14 | +6.2 |
| Mine | Effective (55-75%) | 6 | 274 | 313 | +79 | 112 | 60 | +52 | +18.8 |
| Mine | 76-89% | 25 | 257 | 214 | +61 | 134 | 68 | +66 | +25.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 251 | 178 | +114 | 135 | 22 | +113 | +45.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 430 | 120 | +164 | 209 | 22 | +188 | +43.6 |
| Mine | No odds | 12 | 318 | 173 | -20 | 25 | 50 | -25 | -7.7 |
| Mine | All fights | 99 | 273 | 194 | +72 | 120 | 46 | +74 | +26.9 |
| Opponent | Long shot (under 50%) | 17 | 187 | 272 | -65 | 45 | 115 | -70 | -37.4 |
| Opponent | Effective (55-75%) | 21 | 306 | 217 | -20 | 82 | 87 | -6 | -1.8 |
| Opponent | 76-89% | 19 | 286 | 198 | +18 | 119 | 107 | +12 | +4.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 44 | 289 | 221 | +141 | 195 | 51 | +144 | +50.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 395 | 85 | +116 | 140 | 37 | +103 | +26.1 |
| Opponent | No odds | 19 | 191 | 158 | +86 | 104 | 34 | +69 | +36.3 |
| Opponent | All fights | 135 | 276 | 200 | +62 | 129 | 69 | +60 | +21.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h-mine-e441028-p1 | move | 499 | 109 (22%) | 71 (14%) | 37 (7%) | 353 (71%) |
| fw-h2h-mine-e441028-p1 | objective | 362 | 49 (14%) | 39 (11%) | 39 (11%) | 274 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: fw-h2h-mine-e441028-p2

### Scorecard: fw-h2h-mine-e441028-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 1 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 615 |
| L0122 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 184 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 72 |
| L0206 | 2 | 1 | Mine | - | - | 3 | 2 | 4 | 0 | 0 | 0 | 251 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 1 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 0 | 4 | 1 | 0 | 0 | 592 |
| L0222 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | yes | 0 | - | 0 | 0 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 1 | 1 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 12 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0425 | 5 | 1 | Mine | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 5 | 2 | 6 | 0 | 0 | 0 | 211 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 2 | 0 | 0 | 0 | 1132 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0528 | 6 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 4 | 2 | 0 | 0 | 0 | 929 |
| L0616 | 4 | 1 | Opponent | no | 7 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | - | 1 | 0 | 0 | 0 | 0 | 615 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 4 | 2 | 1 | 0 | 0 | 340 |
| L0721 | 1 | 1 | Mine | yes | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 3 | 3 | 1 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 1 | - | 2 | 1 | 0 | 0 | 0 | 679 |
| L0810 | 6 | 1 | Opponent | no | 8 | 2 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 1 | 0 | 0 | 515 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 564 |
| L0918 | 6 | 1 | Opponent | no | 7 | 3 | 2 | 3 | 1 | 0 | 0 | 40 |
| L0934 | 4 | 1 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 736 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 1 | 0 | 0 | 56 |
| L1026 | 6 | 1 | Mine | no | 5 | 1 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 1 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 425 |
| L1118 | 2 | 1 | Opponent | - | - | 1 | 2 | 1 | 1 | 0 | 0 | 305 |
| L1135 | 1 | 1 | Mine | yes | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 773 |
| L1228 | 4 | 1 | Mine | no | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 351 |
| L1323 | 3 | 1 | Mine | no | 10 | 3 | 1 | 0 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 3 | 3 | 3 | 2 | 3 | 0 | 0 | 185 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 4 | 4 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 9 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 8 | 2 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 5 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 3 | 6 | 4 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 6 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 4 | 1 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 1 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 0 | 2 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 3 | 3 | 6 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 255 |
| L2131 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | yes | 1 | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 5 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 30 |
| L2535 | 3 | 1 | Mine | no | 0 | - | 1 | 1 | 2 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 1 | 0 | 0 | 190 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 158 |
| L3033 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L3033 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 28% | 2.1 | 3.0 | 1.9 | 1.2 | 0.3 | 0.0 | 0.0 | 312.3 |
| **Average** | | | Opponent | 21% | 1.7 | 2.6 | 3.1 | 1.9 | 0.5 | 0.0 | 0.0 | 174.6 |

### KPIs: fw-h2h-mine-e441028-p2

Rules off - Opponent only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 52% (86 of 166) | 0% (0 of 179) | 25% (86 of 345) |
| Winner chose to follow up after the loser gave ground |  | 98% (58 of 59); on the table 98% | 98% (52 of 53); on the table 98% | 98% (110 of 112); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 53% (8 of 15); on the table 67% | 80% (8 of 10); on the table 90% | 64% (16 of 25); on the table 76% |
| Winner chose to pursue after the loser fled |  | 65% (17 of 26); on the table 69% | 91% (32 of 35); on the table 91% | 80% (49 of 61); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 83% (83 of 100); on the table 86% | 94% (92 of 98); on the table 95% | 88% (175 of 198); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 38% (131 of 342) | 31% (47 of 150) | 36% (178 of 492) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (131 of 248) | 43% (47 of 109) | 50% (178 of 357) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 61% (14 of 23) | - | 61% (14 of 23) |
| Points that never fought | lower | 37% (25835 of 69583) | 40% (28314 of 69989) | 39% (54149 of 139572) |
|   infantry points that never fought | lower | 44% (6989 of 16001) | 54% (7188 of 13361) | 48% (14177 of 29362) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (165 of 278) | 57% (163 of 287) | 58% (328 of 565) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.5 uses a game | 61% (11 of 18); 1.0 uses a game | 76% (29 of 38); 1.2 uses a game |
| Bound items with another spell used |  | 50% (9 of 18); 0.4 uses a game | 50% (1 of 2); 0.1 uses a game | 50% (10 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 29% (2 of 7); 0.1 uses a game | 56% (15 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (31163 of 58577) | 49% (30256 of 61319) | 51% (61419 of 119896) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (28%) | 1.0 (36%) | 2.7 (31%) |
| MARCHED: its unit marched | 0.9 (16%) | 0.5 (17%) | 1.4 (16%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (3%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 0.7 (12%) | 0.6 (19%) | 1.3 (15%) |
| REAR RANK: in a rear rank | 0.4 (7%) | 0.1 (5%) | 0.6 (6%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 1.8 (30%) | 0.4 (14%) | 2.2 (25%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.2 (6%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.9 | 1.7 | 4.9 | 0.4 | 1.3 |
| not cast | 3.7 | 2.9 | 3.1 | 8.7 | 1.8 | 20.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.8 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (49%) | 0.3 (11%) | 2.7 (31%) | 0.2 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (16%) | 0.4 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (4%) | 0.2 (8%) | 1.3 (15%) | 0.4 (23%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.1 (4%) | 0.2 (8%) | 0.6 (6%) | 0.1 (5%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 1.1 (29%) | 0.8 (27%) | 0.8 (27%) | 2.2 (25%) | 0.2 (12%) | 3.4 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (5%) | 0.2 (6%) | 0.2 (3%) | 0.1 (6%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (9%) | 0.0 (1%) | 0.0 (0%) | 0.2 (14%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (58%) | 0.0 (1%) | 1.2 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.2 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.7 a game | 0.9 a game |
| stood (cast and not dispelled) | 61% (22 of 36) | 65% (17 of 26) | 63% (39 of 62) |
| the unit moved after it | 55% (12 of 22) | 53% (9 of 17) | 54% (21 of 39) |
| it charged on its next turn | 0% (0 of 22) | 0% (0 of 17) | 0% (0 of 39) |
| the enemy charged it first | 9% (2 of 22) | 6% (1 of 17) | 8% (3 of 39) |
| it fought by the end of its next turn | 5% (1 of 22) | 0% (0 of 17) | 3% (1 of 39) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (3 of 22) | 12% (2 of 17) | 13% (5 of 39) |
| none of these (no charge, no fight, no charge escaped) | 77% (17 of 22) | 82% (14 of 17) | 79% (31 of 39) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (545 of 847) | 49% (363 of 738) | 57% (908 of 1585) |
|   cavalry | 48% (39 of 81) | 47% (69 of 147) | 47% (108 of 228) |
|   character | 48% (39 of 81) | 17% (16 of 96) | 31% (55 of 177) |
|   chariot | 55% (56 of 102) | 69% (27 of 39) | 59% (83 of 141) |
|   infantry | 54% (141 of 263) | 48% (136 of 282) | 51% (277 of 545) |
|   monster | 57% (28 of 49) | 64% (32 of 50) | 61% (60 of 99) |
|   war machine | 89% (242 of 271) | 67% (83 of 124) | 82% (325 of 395) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.2 (39%) | 2.7 (26%) | 6.0 (32%) |
| CHARGED: it charged | 0.9 (11%) | 1.6 (15%) | 2.5 (13%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.5 (5%) | 1.4 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.5 (18%) | 1.9 (18%) | 3.4 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.4 (4%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (12%) | 2.4 (23%) | 3.4 (18%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.2 (2%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (3%) | 0.4 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.4 | 0.9 | 84% | 4.9 pts | 22 pts |
| character | 1.7 | 0.6 | 73% | 12.6 pts | 21 pts |
| chariot | 2.3 | 1.4 | 70% | 11.7 pts | 27 pts |
| infantry | 10.1 | 4.4 | 67% | 12.3 pts | 124 pts |
| monster | 2.1 | 0.3 | 88% | 3.1 pts | 7 pts |
| war machine | 9.0 | 7.3 | 62% | 24.4 pts | 220 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.5 | 6.4 | 4.9 |
| Charges that made contact a game | 2.6 | 4.5 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.48 declared, 0.36 contact (25 units) | 0.73 declared, 0.60 contact (15 units) | 0.57 declared, 0.45 contact (40 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.42 declared, 0.08 contact (12 units) | 1.25 declared, 0.88 contact (16 units) | 0.89 declared, 0.54 contact (28 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.34 contact (245 units) | 0.66 declared, 0.46 contact (300 units) | 0.57 declared, 0.41 contact (545 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (42 of 70) | 72% (13 of 18) | 42% (5 of 12) | 60% (60 of 100) |
| Character in a unit | 79% (15 of 19) | 78% (7 of 9) | 100% (1 of 1) | 79% (23 of 29) |
| Character on its own | 82% (42 of 51) | 48% (20 of 42) | 24% (15 of 63) | 49% (77 of 156) |
| Chariot | 71% (12 of 17) | 85% (11 of 13) | - | 77% (23 of 30) |
| Infantry | 55% (51 of 93) | 48% (15 of 31) | 0% (0 of 3) | 52% (66 of 127) |
| Monster | 59% (17 of 29) | 50% (4 of 8) | - | 57% (21 of 37) |
| Monstrous | 92% (12 of 13) | 50% (7 of 14) | - | 70% (19 of 27) |
| War Machines | 68% (39 of 57) | 0% (0 of 2) | - | 66% (39 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (17 of 17); on the table 100% | 36% (37 of 102) | 46% | 55% (12 of 22) | 100% (6 of 6); 4.2 uses a game | 100% (2 of 2); 1.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 71% (5 of 7); on the table 71% | 44% (16 of 36) | 52% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 6 | 80% (8 of 10); on the table 80% | - | 39% | 80% (43 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 94% (15 of 16); on the table 94% | 52% (25 of 48) | 54% | 64% (49 of 76) | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 86% (6 of 7); on the table 86% | 33% (45 of 138) | 37% | 35% (19 of 54) | 93% (13 of 14); 6.8 uses a game | 0% (0 of 2); 0.0 uses a game | 33% (2 of 6); 0.3 uses a game |
| High Elf Realms | 4 | 62% (5 of 8); on the table 62% | 28% (5 of 18) | 24% | 45% (15 of 33) | 100% (3 of 3); 1.5 uses a game | 43% (6 of 14); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 93% (13 of 14); on the table 100% | - | 32% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 16% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (8 of 8); on the table 100% | 39% (7 of 18) | 51% | 57% (16 of 28) | 25% (1 of 4); 1.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (9 of 9); on the table 100% | 33% (4 of 12) | 16% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 77% (10 of 13); on the table 85% | 44% (8 of 18) | 28% | 48% (12 of 25) | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 96% (23 of 24); on the table 96% | - | 37% | 36% (9 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 76% (22 of 29); on the table 83% | 32% (21 of 66) | 39% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 91% (20 of 22); on the table 91% | 22% (4 of 18) | 22% | 58% (39 of 67) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 6 | 100% (13 of 13); on the table 100% | 33% (6 of 18) | 52% | 62% (42 of 68) | 40% (2 of 5); 0.7 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h-mine-e441028-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (49) | 54% (30) | 51% (79) |
| ...free all their last turn and able to turn (per game) | 0.92 | 0.64 | 1.56 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.11 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.42 | 0.97 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.53 | 1.06 | 3.58 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.28 | 0.61 | 1.89 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.08 | 7.61 | 14.69 |

### Quality by phase: fw-h2h-mine-e441028-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 0.0 |
| Strategy | Charge objectives carried out (made contact) | 53% (57 of 108) | 48% (91 of 191) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (135 of 303) | 54% (105 of 195) |
| Strategy | Close-in objectives charged next turn | 14% (25 of 184) | 13% (27 of 212) |
| Strategy | Support requests answered (helper made contact too) | 62% (5 of 8) | 64% (18 of 28) |
| Strategy | Hexes on a unit its side charged or shot that turn | 41% (7 of 17) | 84% (16 of 19) |
| Strategy | Joined characters whose unit fought | 32% (13 of 40) | 16% (3 of 19) |
| Strategy | Lone characters that fought | 78% (80 of 102) | 72% (72 of 100) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.2 | 1.9 |
| Movement | Points that never moved of their own | 312.3 | 174.6 |
| Movement | Fights charged into per game | 2.4 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 69, net +69 | 15 of 114, net +84 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 69, net +61 | 21 of 114, net +113 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 69, net +142 | 11 of 114, net +163 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 69, net +73 | 40 of 114, net +167 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.2 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (150 of 331) | 46% (144 of 316) |
| Shooting | Points destroyed by shooting units | 74.9 | 42.5 |
| Shooting | War machine shots | 6.7 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (110 of 242) | 31% (26 of 83) |
| Shooting | Points destroyed by war machines | 88.7 | 52.1 |
| Magic | Magic missiles cast | 2.4 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (33 of 85) | 43% (13 of 30) |
| Magic | Wounds caused by magic missiles | 4.6 | 1.1 |
| Magic | Wounds caused by other spells | 1.4 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 81.2 | 32.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.5 / 0.6 / 0.1 | 1.9 / 0.5 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 235.9 | 454.8 |
| Combat | Points run down | 78.0 | 92.7 |
| Combat | Net points per charged fight, damage counted | +60 | +101 |
| Combat | Net per 100 charger points, damage counted | +21.6 | +32.8 |
| Combat | First round won (charged fights) | 68% | 60% |
| Combat | Net points per charged fight | +57 | +110 |
| Combat | Net points per supported fight / lone fight | +178 / +42 | +156 / +96 |
| Combat | Charged fights on a top-3 enemy unit | 25 of 83 | 56 of 130 |
| Game | Points lost | 757.6 | 641.6 |
| Game | VP from objectives | 514.6 | 631.4 |
| Game | Lone holders (player turns) | 2.1 | 1.7 |

- Mine won / drew / lost: 10 / 7 / 18 of 35 ended games (of 36); mean margin (Mine - Opponent) -254 VP
- The side that went first won 16 of 28 games with a winner
- Points traded per game (both sides' losses): 1399
- Games not ended: 1 (L3033-1); findings 4, warnings 0

### Opponent rules: fw-h2h-mine-e441028-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.8 | +0.0 | 0.0 | 12.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.3 | +7.4 | 0.0 | 34.0 | 1.1 | +7.8 | 0.0 | 12.2 |
| BEST FACING | 0.9 | +36.9 | 0.0 | 21.6 | - | - | - | - |
| BEST FIRST | 3.5 | +155.8 | 183.5 | 35.1 | - | - | - | - |
| BEST OVERALL | 0.7 | +28.6 | 0.0 | 6.6 | 0.3 | +18.8 | 0.0 | 26.5 |
| BEST PREY | 0.7 | +32.6 | 30.1 | 14.7 | 5.1 | +320.8 | 284.0 | 121.7 |
| BEST PRIZE | 0.1 | +2.3 | 3.5 | 0.0 | 0.0 | +7.3 | 8.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.8 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 11.2 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 7.0 | 0.0 | 0.2 | +0.0 | 8.7 | 0.0 |
| BLOCKED WHEEL | 0.4 | +10.7 | 0.0 | 0.0 | 0.6 | +4.6 | 0.0 | 7.7 |
| BOMBING RUN | 0.1 | +2.2 | 0.0 | 4.2 | 0.0 | +0.3 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 71.0 | 19.7 | 0.2 | +0.0 | 22.4 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +197.2 | 446.1 | 111.0 | 1.8 | +99.9 | 103.1 | 18.6 |
| CARRIES OUT COUNTER | 0.1 | -0.0 | 4.4 | 0.0 | 0.0 | -2.7 | 1.7 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.8 | 3.5 | 0.0 | 0.1 | +9.9 | 16.5 | 0.0 |
| CAST JOB | 0.4 | +10.3 | 21.9 | 4.7 | 0.6 | +13.3 | 24.9 | 59.6 |
| CASTING BLOCK | 0.1 | +13.5 | 10.5 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 39.7 | 0.5 | +0.0 | 0.0 | 45.3 |
| CATCH FLIERS | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 26.9 | 0.2 | -0.1 | 4.7 | 7.1 |
| CHARGE NOW WEIGHED | 0.5 | -32.0 | 24.1 | 5.0 | 0.6 | -48.0 | 23.6 | 10.4 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 17.8 | 2.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.0 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.4 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 11.4 | 4.7 | 0.3 | +0.0 | 22.3 | 4.2 |
| CONVEYANCE SEARCH | 0.7 | +138.5 | 22.6 | 39.7 | 0.6 | +94.2 | 17.7 | 56.6 |
| COUNTER-CHARGE COVER | 9.2 | +777.1 | 0.0 | 164.0 | 6.6 | +616.4 | 0.0 | 95.0 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 38.1 | 9.5 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +4.1 | 11.7 | 0.0 | 0.1 | +6.9 | 13.9 | 5.4 |
| ELIXIR WORTH | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.5 | +173.3 | 0.0 | 81.9 | 1.1 | +96.0 | 0.0 | 25.5 |
| FALLBACK BY WORTH | 4.8 | +63.2 | 0.0 | 57.1 | 8.1 | +68.8 | 0.0 | 64.8 |
| FIRE AND FLEE | 0.1 | +1.1 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 3.1 |
| FLANK NOT WEIGHED | 6.9 | +0.0 | 0.0 | 175.6 | 6.3 | +0.0 | 0.0 | 147.1 |
| FOLLOW UP WEIGHED | 1.0 | +87.0 | 0.0 | 28.9 | 1.5 | +173.9 | 0.0 | 30.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +11.2 | 0.0 | 14.5 | 0.1 | +4.3 | 0.0 | 0.0 |
| GIVES UP | 0.8 | -28.4 | 74.2 | 29.2 | 1.8 | -72.9 | 298.7 | 31.2 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 0.0 | 0.0 | 0.4 | -9.5 | 18.9 | 17.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 0.9 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 10.6 | 1.4 | 0.3 | +0.0 | 18.6 | 9.2 |
| HILL BY ITS CHANCE | 0.1 | -11.9 | 0.0 | 3.4 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.7 | 0.0 | 3.6 | 0.2 | +3.3 | 24.6 | 10.1 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +9.3 | 0.0 | 12.1 | 0.5 | +15.4 | 0.0 | 0.0 |
| HUNT KEPT | 0.0 | +2.5 | 2.8 | 0.0 | 0.1 | +0.6 | 11.1 | 1.9 |
| HUNT RESULT | 0.1 | +2.8 | 0.0 | 3.6 | 0.1 | +15.6 | 11.1 | 7.1 |
| HUNT THE GUNS | 0.1 | +27.7 | 2.8 | 3.6 | 0.2 | +56.7 | 13.5 | 8.2 |
| INVITES THE FIGHT | 3.7 | +208.4 | 128.8 | 64.2 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +1.3 | 0.0 | 0.0 | 0.4 | +29.3 | 0.0 | 3.8 |
| KEEP FALLS | 0.1 | +1.2 | 0.0 | 7.5 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.3 | +3.1 | 3.4 | 5.7 |
| KEEPS ITS TARGET | 1.8 | +53.3 | 137.1 | 23.3 | 2.6 | +77.5 | 255.3 | 56.5 |
| KILLS COUNT | 1.6 | +64.6 | 113.7 | 49.8 | 2.2 | +118.9 | 259.5 | 29.0 |
| KILLS COUNT NEXT TURN | 5.9 | +163.8 | 192.4 | 160.7 | 10.9 | +470.5 | 621.7 | 222.4 |
| LONE CHARACTER SAFE SPOT | 0.4 | +31.6 | 3.0 | 34.9 | 0.6 | +10.8 | 14.1 | 29.1 |
| LONE WIZARD HOLDS BACK | 0.8 | +0.0 | 25.5 | 24.9 | 1.1 | +0.0 | 55.0 | 66.3 |
| LONG SHOT | 0.4 | +2.8 | 18.9 | 18.1 | - | - | - | - |
| LOST CHARGE | 3.0 | -52.8 | 145.3 | 102.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +19.4 | 0.0 | 7.7 | 1.3 | +85.0 | 15.5 | 6.8 |
| MANOEUVRE | 0.3 | +10.1 | 0.0 | 9.4 | 0.1 | +7.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.1 | 0.0 | 1.5 | - | - | - | - |
| MARCH CHECK | 0.4 | +19.7 | 0.0 | 37.1 | 0.6 | +25.3 | 0.0 | 3.2 |
| MARCH ODDS | 0.2 | +10.5 | 0.0 | 11.1 | 0.3 | +25.9 | 13.0 | 7.0 |
| MARCH OVER CASTS | 0.8 | +56.7 | 0.0 | 13.6 | 0.3 | +25.3 | 0.0 | 7.6 |
| MAX FOR POSITIONING | 4.8 | +205.1 | 0.0 | 81.3 | 4.7 | +178.5 | 0.0 | 74.7 |
| MISSILES IN THE MOVE | 4.5 | +137.7 | 0.0 | 104.7 | 2.9 | +50.5 | 0.0 | 133.6 |
| MISSILES NEXT TURN | 5.0 | +93.8 | 0.0 | 118.3 | 3.3 | +33.2 | 0.0 | 126.2 |
| MODEL FACING | 0.2 | +56.2 | 0.0 | 3.3 | 0.2 | +66.9 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 9.8 | 12.1 | 0.4 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +7.7 | 0.0 | 2.4 | 0.2 | +5.4 | 0.0 | 14.5 |
| MOVE SPELL IN RANGE | 0.8 | +23.5 | 0.0 | 6.1 | 0.4 | +9.5 | 0.0 | 49.0 |
| MOVE SPELL OUT OF RANGE | 0.7 | -16.7 | 17.9 | 9.9 | 0.2 | -8.7 | 0.0 | 41.4 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 13.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 5.5 | +349.7 | 181.3 | 118.4 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +6.1 | 6.5 | 0.0 | 0.1 | +16.4 | 15.0 | 16.6 |
| NO RALLY LEFT | 0.0 | +0.4 | 0.0 | 2.4 | 0.1 | +1.2 | 0.0 | 6.5 |
| NOT NEEDED | 0.2 | -13.6 | 9.6 | 1.7 | 0.4 | -26.6 | 50.7 | 4.4 |
| NOT TURNED | 7.1 | +122.6 | 0.0 | 164.9 | 7.6 | +84.6 | 0.0 | 151.9 |
| NOT WORTH A CAST | 0.6 | -0.3 | 0.0 | 21.9 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 16.4 | -707.9 | 0.0 | 304.7 | 18.9 | -1068.4 | 95.8 | 306.0 |
| OPENS A LANE | 0.1 | +0.4 | 6.0 | 2.9 | 0.0 | +0.4 | 1.4 | 0.0 |
| OPENS UP | 0.1 | +8.9 | 7.1 | 0.0 | 0.2 | +26.9 | 13.1 | 0.0 |
| OVERRUNS AWAY | 0.5 | +9.3 | 36.9 | 36.5 | 0.7 | +18.0 | 110.4 | 32.2 |
| PATHS CROSS | 2.4 | +173.2 | 0.0 | 10.6 | 3.1 | +159.6 | 0.0 | 44.7 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 15.0 | 0.0 | +1.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.4 | 0.0 | 2.4 | 0.1 | -1.1 | 0.0 | 5.4 |
| PLAN RESULT | 39.5 | +1272.6 | 1673.6 | 1045.2 | 42.4 | +1341.2 | 1375.1 | 946.8 |
| PURSUES BIG PREY | 0.2 | -24.7 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.1 | +13.2 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.7 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +7.2 | 0.0 | 20.4 | - | - | - | - |
| RANDOM MOVER NO PROMISE | 0.2 | -13.7 | 15.5 | 5.8 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 2.1 | +158.3 | 0.0 | 48.8 | 3.9 | +223.7 | 0.0 | 71.1 |
| REDIRECT WEIGHED | 0.2 | +12.1 | 8.6 | 0.0 | 0.4 | +16.5 | 21.2 | 0.0 |
| RESERVE FALL BACK | 0.2 | +9.8 | 0.0 | 8.0 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.1 | +2.3 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 3.1 |
| RISK BY ARC | 2.0 | +85.8 | 148.8 | 78.2 | 3.1 | +58.1 | 361.1 | 83.2 |
| SAFER THAN THE JOB | 1.3 | +69.7 | 0.0 | 11.7 | 0.6 | +35.3 | 0.0 | 37.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.5 | 0.0 | 1.5 | - | - | - | - |
| SEARCH SPOT | 3.5 | +186.8 | 0.0 | 84.2 | 2.2 | +118.9 | 0.0 | 19.4 |
| SELF MOVE SPELL | 0.2 | +26.9 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.5 | +29.3 | 0.0 | 21.4 | 2.1 | +120.2 | 15.5 | 6.8 |
| SET-UP ANY TARGET | 0.2 | +48.6 | 13.9 | 13.9 | 0.1 | +11.5 | 2.8 | 7.6 |
| SET-UP MISSED | 0.1 | +2.8 | 7.6 | 6.1 | 0.1 | +7.6 | 0.0 | 7.6 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 1.5 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.8 | +15.8 | 28.2 | 7.7 | - | - | - | - |
| SHOT REPLANNED | 0.5 | +0.0 | 99.7 | 6.9 | 0.1 | +0.0 | 17.9 | 0.0 |
| SHOTS IN THE MOVE | 13.3 | +586.0 | 0.0 | 280.1 | 9.4 | +299.5 | 0.0 | 147.7 |
| SPELL CATCH ODDS | 0.0 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +58.2 | 13.9 | 13.9 | 0.1 | +23.4 | 2.8 | 15.2 |
| SPELL WORTH | 0.8 | +20.3 | 72.3 | 82.2 | 1.9 | +36.0 | 95.2 | 105.0 |
| STABLE ROLE | 13.9 | +0.0 | 411.2 | 202.4 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.1 | +1.4 | 0.0 | 15.0 |
| STOPS | 0.1 | +4.0 | 5.6 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.4 | +14.0 | 0.0 | 4.1 | 0.2 | +10.6 | 0.0 | 15.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORTS | 6.7 | +235.5 | 249.8 | 131.6 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.2 | -31.7 | 33.2 | 0.0 | 0.1 | -10.9 | 11.2 | 0.0 |
| SURE REACH TOGETHER | 0.5 | -0.2 | 14.3 | 13.7 | 0.9 | +0.1 | 0.0 | 6.7 |
| THROUGH LINE OF FIRE | 0.3 | +10.8 | 0.0 | 0.0 | 0.2 | +11.3 | 0.0 | 3.5 |
| TURN WORTH | 0.2 | -12.6 | 13.4 | 7.5 | 0.4 | -23.6 | 28.0 | 7.1 |
| TWO OR MORE ARRIVE | 0.1 | +0.8 | 0.0 | 13.3 | 0.7 | +4.8 | 12.8 | 0.0 |
| WALKS TO THE FIGHT | 2.6 | +118.5 | 27.8 | 36.5 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 52.2 | 22.8 | - | - | - | - |
| WEARS DOWN | 0.7 | +25.4 | 75.7 | 30.1 | 1.1 | +56.3 | 143.0 | 29.5 |
| WHO HITS BACK | 0.2 | +17.8 | 0.0 | 11.7 | 0.2 | +7.5 | 0.0 | 7.9 |
| WHOLE FIGHT | 0.2 | +5.5 | 20.1 | 1.4 | 0.4 | +28.2 | 69.8 | 10.4 |
| WHOLE FIGHT GAIN | 0.1 | +5.2 | 3.5 | 0.0 | 0.7 | +45.7 | 62.4 | 10.4 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: fw-h2h-mine-e441028-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1270 | 1270 | 1270 | 35.28 | -63950 | -50.4 |
| SEARCH SPOT | 203 | 203 | 200 | 5.56 | +11037 | +55.2 |
| PATHS CROSS | 197 | 197 | 197 | 5.47 | +11978 | +60.8 |
| KILLS COUNT NEXT TURN | 607 | 597 | 174 | 4.83 | +4833 | +27.8 |
| COUNTER-CHARGE COVER | 572 | 327 | 149 | 4.14 | +10068 | +67.6 |
| FACES THE THREAT | 129 | 129 | 129 | 3.58 | +9695 | +75.2 |
| BEST FIRST | 125 | 125 | 125 | 3.47 | +5607 | +44.9 |
| SUPPORTS | 240 | 240 | 125 | 3.47 | +2708 | +21.7 |
| MOVE TO CHARGE | 198 | 198 | 105 | 2.92 | +3618 | +34.5 |
| FALLBACK BY WORTH | 466 | 466 | 99 | 2.75 | +4754 | +48.0 |
| BEST PREY | 211 | 203 | 90 | 2.50 | +3454 | +38.4 |
| FOLLOW UP WEIGHED | 90 | 90 | 90 | 2.50 | +9392 | +104.4 |
| SAFER THAN THE JOB | 68 | 68 | 68 | 1.89 | +3778 | +55.6 |
| INVITES THE FIGHT | 133 | 133 | 62 | 1.72 | +2450 | +39.5 |
| WALKS TO THE FIGHT | 93 | 93 | 62 | 1.72 | +1829 | +29.5 |
| SHOTS IN THE MOVE | 818 | 506 | 61 | 1.69 | +1580 | +25.9 |
| CANNON PLANNED TARGET | 252 | 252 | 44 | 1.22 | -293 | -6.7 |
| RISK BY ARC | 182 | 167 | 42 | 1.17 | +1527 | +36.4 |
| CHARGE NOW WEIGHED | 40 | 40 | 40 | 1.11 | +2368 | +59.2 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| REDIRECT COUNTER | 217 | 104 | 38 | 1.06 | +3273 | +86.1 |
| SET UP TOGETHER | 94 | 79 | 38 | 1.06 | +1603 | +42.2 |
| ARTILLERY RE-ROLL WEIGHED | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| BEST OVERALL | 36 | 36 | 36 | 1.00 | +1708 | +47.4 |
| KILLS COUNT | 134 | 124 | 36 | 1.00 | +2127 | +59.1 |
| MISSILES IN THE MOVE | 267 | 148 | 36 | 1.00 | +732 | +20.3 |
| BLOCKED WHEEL | 35 | 35 | 35 | 0.97 | +550 | +15.7 |
| MAX FOR POSITIONING | 342 | 200 | 35 | 0.97 | +307 | +8.8 |
| BEST FACING | 34 | 34 | 34 | 0.94 | +1329 | +39.1 |
| MARCH CHECK | 39 | 36 | 33 | 0.92 | +2416 | +73.2 |
| LONE WIZARD HOLDS BACK | 70 | 70 | 30 | 0.83 | -472 | -15.7 |
| KEEPS ITS TARGET | 157 | 150 | 27 | 0.75 | +378 | +14.0 |
| STOPS SHORT OF THE FLANK | 24 | 24 | 24 | 0.67 | +887 | +36.9 |
| COMBAT PIVOT | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +1198 | +57.0 |
| MAKE SURE TOGETHER | 59 | 43 | 20 | 0.56 | +886 | +44.3 |
| SHOT REPLANNED | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 19 | 19 | 19 | 0.53 | +795 | +41.9 |
| MODEL FACING | 17 | 17 | 17 | 0.47 | +4434 | +260.8 |
| MANOEUVRE | 16 | 16 | 16 | 0.44 | +637 | +39.8 |
| MARCH ODDS | 17 | 17 | 16 | 0.44 | +290 | +18.2 |
| WHOLE FIGHT GAIN | 28 | 24 | 16 | 0.44 | +582 | +36.4 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +472 | +31.4 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +800 | +53.3 |
| RANDOM MOVE BY FIGURES | 23 | 23 | 14 | 0.39 | +258 | +18.4 |
| CAST JOB | 38 | 37 | 13 | 0.36 | +178 | +13.7 |
| WEARS DOWN | 66 | 61 | 13 | 0.36 | +606 | +46.6 |
| WAR ENGINE JOBS | 25 | 25 | 12 | 0.33 | -825 | -68.8 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | -23 | -2.1 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -8 | -0.8 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +558 | +50.7 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -1532 | -139.2 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -880 | -88.0 |
| SHOOTS FROM THE BEST SPOT | 28 | 28 | 10 | 0.28 | +191 | +19.1 |
| BACKUP TARGETS | 86 | 51 | 9 | 0.25 | +16 | +1.8 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| RESERVE FALL BACK | 8 | 8 | 8 | 0.22 | +353 | +44.2 |
| SURE REACH TOGETHER | 52 | 42 | 8 | 0.22 | +16 | +2.0 |
| LOST CHARGE | 107 | 107 | 7 | 0.19 | +306 | +43.6 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -88 | -14.6 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +150 | +25.0 |
| OPENS UP | 11 | 10 | 5 | 0.14 | +399 | +79.8 |
| OVERRUNS AWAY | 43 | 39 | 5 | 0.14 | +53 | +10.6 |
| BOMBING RUN | 4 | 4 | 4 | 0.11 | +90 | +22.5 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +41 | +10.3 |
| HUNT IN PAIRS | 24 | 14 | 4 | 0.11 | +68 | +17.1 |
| JOINT CHARGE PLAN | 16 | 16 | 4 | 0.11 | +450 | +112.6 |
| MISSILES NEXT TURN | 300 | 163 | 4 | 0.11 | +8 | +1.9 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NEEDED THERE | 5 | 5 | 4 | 0.11 | +0 | +0.0 |
| WHOLE FIGHT | 23 | 21 | 4 | 0.11 | +242 | +60.4 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -23 | -7.8 |
| CASTING BLOCK | 3 | 3 | 3 | 0.08 | +319 | +106.5 |
| HUNT ADVANCE | 10 | 10 | 3 | 0.08 | +51 | +17.0 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +211 | +70.3 |
| LONG SHOT | 14 | 14 | 3 | 0.08 | +78 | +25.9 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +19 | +6.3 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +105 | +35.1 |
| CARRIES OUT COUNTER | 6 | 6 | 2 | 0.06 | -99 | -49.4 |
| CARRIES OUT SET-UP | 4 | 4 | 2 | 0.06 | +326 | +162.9 |
| CHARIOT NO STATIC JOB | 5 | 5 | 2 | 0.06 | -24 | -12.0 |
| DEFENSIVE ARMY | 15 | 15 | 2 | 0.06 | -92 | -46.2 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +14 | +7.1 |
| GIVES UP | 91 | 77 | 2 | 0.06 | +73 | +36.5 |
| KEEPS ITS PREY | 11 | 10 | 2 | 0.06 | +12 | +6.1 |
| MOVE SPELL IN RANGE | 40 | 26 | 2 | 0.06 | +20 | +9.8 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +120 | +59.9 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +314 | +157.0 |
| STOPS | 2 | 2 | 2 | 0.06 | +88 | +44.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| EDGE GIVE GROUND | 6 | 6 | 1 | 0.03 | +106 | +105.6 |
| OPENS A LANE | 6 | 2 | 1 | 0.03 | +2 | +2.2 |
| STANDS TO CAST | 2 | 1 | 1 | 0.03 | -12 | -12.1 |
| TWO OR MORE ARRIVE | 31 | 24 | 1 | 0.03 | +2 | +2.2 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -420 | -420.1 |
| ARRIVAL HUNT | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 43 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 47 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 476 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 17 | 17 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 14 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 35 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 39 | 39 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 26 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 34 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 20 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 529 | 529 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 32 | not checked | - | - | - | - |
| PLAN RESULT | 2949 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 9 | 9 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 96 | not checked | - | - | - | - |
| STABLE ROLE | 499 | 498 | 0 | 0.00 | - | - |
| TURN WORTH | 22 | 20 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h-mine-e441028-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.69 | 15.42 | 52.5 |
| FALLBACK | gate | 0.50 | 1.14 | 49.4 |
| RULE SWITCHED OFF | gate | - | 1.33 | 28.4 |
| TURN GATE | gate | 0.67 | 0.61 | 31.6 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.06 | 24.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.14 | 53.6 |
| WAR ENGINE JOBS | rule | 0.33 | - | 68.8 |
| LONE WIZARD HOLDS BACK | rule | 0.19 | 0.11 | 42.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.14 | 139.2 |
| PURSUES BIG PREY | rule | 0.17 | 0.08 | 115.2 |
| PATHS CROSS | rule | 0.06 | 0.17 | 39.5 |
| BLOCKED WHEEL | rule | 0.08 | 0.08 | 42.4 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.08 | 14.6 |
| SUPPORT REQUEST | gate | 0.03 | 0.14 | 74.6 |
| AFTERMATH BAND | gate | 0.08 | 0.06 | 3.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.03 | 35.3 |
| CHAFF PASSED | rule | 0.06 | 0.08 | 1.7 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.06 | 29.5 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.03 | 13.3 |
| BEST PRIZE | rule | 0.06 | 0.03 | 7.8 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 1.6 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.03 | 49.4 |
| CHARIOT NO STATIC JOB | rule | 0.03 | 0.03 | 12.0 |
| DEFENSIVE ARMY | rule | 0.06 | - | 46.2 |
| NO REASON | gate | 0.06 | - | 4.2 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 6.4 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 6.9 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 1.8 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 29.9 |
| FACES THE THREAT | rule | 0.03 | - | 25.1 |
| FALLBACK BY WORTH | rule | 0.03 | - | 21.6 |
| MARCH ODDS | rule | 0.03 | - | 4.3 |
| STANDS TO CAST | rule | - | 0.03 | 12.1 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 14.3 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 420.1 |

### Plans: fw-h2h-mine-e441028-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.5 | 15% | 751 | 370 | 49% |
| Mine | charge | 2.3 | 53% | 269 | 165 | 61% |
| Mine | close in | 5.1 | 22% | 519 | 137 | 26% |
| Mine | hold | 3.7 | 36% | 267 | 0 | 0% |
| Mine | join | 1.2 | 91% | 59 | 0 | 0% |
| Mine | shoot | 6.9 | 60% | 266 | 601 | 226% |
| Mine | support | 6.8 | 93% | 185 | 0 | 0% |
| Opponent | advance | 14.7 | 17% | 619 | 427 | 69% |
| Opponent | charge | 4.4 | 64% | 484 | 480 | 99% |
| Opponent | close in | 5.8 | 24% | 516 | 177 | 34% |
| Opponent | hold | 4.2 | 42% | 363 | 0 | 0% |
| Opponent | join | 1.8 | 92% | 87 | 0 | 0% |
| Opponent | shoot | 4.8 | 55% | 130 | 258 | 198% |
| Opponent | support | 6.8 | 89% | 291 | 0 | 0% |

### Packages: hunt the guns, fw-h2h-mine-e441028-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 0 | 33% | 33% | 0% | 3.0 | 332 | 33 | 0% | 58 |
| Opponent | 0.2 | 6 | 1 | 0% | 40% | 0% | 2.5 | 390 | 112 | 40% | 102 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 218 | 0 | 0% | 42 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 330 | 100 | 0% | 222 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 91 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 176 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 228 |
| Tomb Kings of Khemri | 0.6 | 3 | 1 | 0% | 50% | 0% | 3.0 | 492 | 225 | 50% | 53 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 411 | 0 | 0% | 12 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 476 | 0 | 0% | 61 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 118 | 111 | 100% | 83 |

### Battle groups: fw-h2h-mine-e441028-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.2 | 24% | 52% | 14% | 45% | 34% | 9% | 9% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 38% | 69% | 14% | 0% | 28% | 0% | 12% | 60% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.6 | 17% | 61% | 32% | 8% | 32% | 14% | 11% | 43% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 20% | 75% | 36% | 20% | 11% | 0% | 6% | 72% | 11% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h-mine-e441028-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 0 | 40% | 4.0 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Mine | Chaff | 33 | 42 (33) | 12 | 30 | 51 | 39% | 3.3 | 53 (18) | 38 (11) | 0 (4) | 37 (22) | 53 (11) |
| Mine | Character | 119 | 36 (119) | 36 | 0 | 43 | 15% | 2.7 | 51 (44) | 25 (41) | 31 (22) | 40 (73) | 31 (34) |
| Mine | Clean-up | 23 | 53 (23) | 24 | 28 | 30 | 30% | 3.1 | 47 (12) | 67 (9) | 11 (2) | 61 (14) | 41 (9) |
| Mine | Fast Hammer | 43 | 43 (43) | 32 | 12 | 43 | 35% | 3.2 | 55 (17) | 27 (17) | 47 (9) | 53 (34) | 19 (9) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 0 | 0% | 2.8 | 0 (2) | 0 (2) | 0 (1) | 0 (4) | 0 (1) |
| Mine | Hammer | 56 | 43 (56) | 35 | 8 | 30 | 18% | 2.6 | 31 (23) | 56 (20) | 43 (13) | 48 (41) | 30 (15) |
| Mine | Holder | 26 | 44 (26) | 2 | 41 | 26 | 42% | 4.2 | 31 (14) | 65 (6) | 55 (6) | 65 (17) | 5 (9) |
| Mine | Shooter | 42 | 60 (42) | 29 | 31 | 56 | 0% | 1.8 | 51 (11) | 75 (16) | 50 (15) | 55 (28) | 69 (14) |
| Mine | Support | 2 | 22 (2) | 22 | 0 | 66 | 0% | 5.0 | - | 22 (2) | - | - | 22 (2) |
| Mine | War machine | 59 | 50 (59) | 50 | 0 | 57 | 3% | 1.2 | 42 (21) | 70 (22) | 28 (16) | 52 (43) | 43 (16) |
| Mine | Wizard | 23 | 5 (23) | 5 | 0 | 52 | 22% | 2.7 | 0 (10) | 0 (3) | 13 (7) | 0 (17) | 30 (3) |
| Opponent | Blocker | 2 | 105 (2) | 105 | 0 | 38 | 0% | 5.5 | - | 105 (2) | - | 168 (1) | 0 (1) |
| Opponent | Chaff | 73 | 63 (73) | 14 | 49 | 50 | 40% | 2.9 | 32 (30) | 105 (21) | 70 (22) | 62 (53) | 66 (20) |
| Opponent | Character | 91 | 66 (91) | 66 | 0 | 29 | 20% | 2.7 | 64 (36) | 62 (23) | 76 (28) | 72 (55) | 61 (32) |
| Opponent | Clean-up | 22 | 51 (22) | 23 | 28 | 29 | 59% | 2.4 | 33 (10) | 58 (8) | 75 (4) | 68 (11) | 16 (11) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 39 | 42 (39) | 34 | 7 | 34 | 26% | 2.7 | 46 (16) | 29 (18) | 95 (5) | 48 (25) | 30 (14) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 37 | 33% | 3.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Hammer | 65 | 26 (65) | 24 | 2 | 43 | 25% | 2.9 | 23 (30) | 24 (22) | 35 (13) | 30 (44) | 15 (21) |
| Opponent | Holder | 34 | 68 (34) | 10 | 58 | 27 | 35% | 4.0 | 23 (11) | 155 (12) | 43 (9) | 79 (24) | 54 (8) |
| Opponent | Shooter | 41 | 81 (41) | 13 | 68 | 33 | 2% | 1.8 | 37 (17) | 162 (16) | 31 (8) | 79 (31) | 91 (10) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 75% | 5.0 | 0 (2) | 0 (2) | - | - | 0 (4) |
| Opponent | War machine | 24 | 72 (24) | 72 | 0 | 31 | 8% | 1.3 | 165 (5) | 58 (9) | 26 (10) | 90 (16) | 40 (8) |
| Opponent | Wizard | 28 | 11 (28) | 11 | 0 | 37 | 18% | 1.7 | 26 (11) | 0 (10) | 0 (2) | 16 (15) | 0 (8) |

### Charged fights: fw-h2h-mine-e441028-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 190 | 104 | 2.2 | 1.3 | 46 | 50 | -4 | 3 of 9 | 5 of 9 | +72 | -26 |
| Mine | Chaos Dwarfs | 4 | 156 | 179 | 0.8 | 1.7 | 239 | 0 | +239 | 3 of 3 | 3 of 3 | +716 | +0 |
| Mine | Dwarfen Mountain Holds | 4 | 298 | 45 | 2.0 | 1.1 | 22 | 51 | -28 | 2 of 8 | 4 of 8 | +0 | -33 |
| Mine | Empire of Man | 5 | 510 | 190 | 1.8 | 1.0 | 105 | 64 | +42 | 3 of 9 | 6 of 9 | - | +42 |
| Mine | Grand Cathay | 4 | 421 | 352 | 3.0 | 1.0 | 118 | 0 | +118 | 4 of 12 | 9 of 12 | - | +118 |
| Mine | High Elf Realms | 4 | 232 | 364 | 2.5 | 1.2 | 146 | 50 | +96 | 2 of 10 | 7 of 10 | +180 | +75 |
| Mine | Kingdom of Bretonnia | 1 | 170 | 122 | 3.0 | 1.0 | 41 | 0 | +41 | 2 of 3 | 1 of 3 | - | +41 |
| Mine | Lizardmen | 1 | 0 | 419 | 2.0 | 1.0 | 210 | 0 | +210 | 1 of 2 | 0 of 2 | - | +210 |
| Mine | Ogre Kingdoms | 1 | 186 | 110 | 4.0 | 1.2 | 28 | 8 | +19 | 0 of 4 | 2 of 3 | +50 | +9 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 670 | 8.0 | 1.0 | 84 | 7 | +77 | 0 of 8 | 6 of 8 | - | +77 |
| Mine | Skaven | 2 | 143 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 114 | 423 | 3.0 | 1.0 | 141 | 0 | +141 | 1 of 3 | 3 of 3 | - | +141 |
| Mine | Vampire Counts | 3 | 106 | 200 | 3.7 | 1.2 | 55 | 69 | -14 | 3 of 11 | 9 of 11 | +166 | -54 |
| **Mine** | all armies | 35 | 252 | 213 | 2.4 | 1.1 | 90 | 33 | +57 | 25 of 83 | 56 of 82 | +178 | +42 |
| Opponent | Dwarfen Mountain Holds | 2 | 194 | 52 | 4.0 | 1.2 | 13 | 81 | -68 | 5 of 8 | 2 of 8 | +0 | -90 |
| Opponent | Empire of Man | 2 | 140 | 270 | 3.0 | 1.0 | 90 | 0 | +90 | 2 of 6 | 4 of 6 | - | +90 |
| Opponent | Grand Cathay | 2 | 835 | 350 | 4.0 | 1.4 | 88 | 27 | +60 | 3 of 8 | 6 of 8 | +75 | +52 |
| Opponent | Kingdom of Bretonnia | 1 | 400 | 484 | 4.0 | 1.2 | 121 | 0 | +121 | 3 of 4 | 3 of 4 | +186 | +99 |
| Opponent | Ogre Kingdoms | 3 | 114 | 318 | 4.0 | 1.2 | 80 | 6 | +74 | 4 of 12 | 9 of 12 | +49 | +82 |
| Opponent | Skaven | 1 | 0 | 238 | 1.0 | 1.0 | 238 | 0 | +238 | 1 of 1 | 0 of 1 | - | +238 |
| Opponent | Tomb Kings of Khemri | 4 | 24 | 898 | 3.0 | 1.7 | 299 | 0 | +299 | 6 of 12 | 9 of 12 | +443 | +196 |
| Opponent | Vampire Counts | 6 | 100 | 424 | 4.2 | 1.1 | 102 | 24 | +77 | 11 of 25 | 13 of 25 | -49 | +95 |
| Opponent | Warriors of Chaos | 8 | 7 | 707 | 4.2 | 1.2 | 166 | 11 | +155 | 16 of 34 | 21 of 34 | +220 | +135 |
| Opponent | Wood Elf Realms | 6 | 122 | 373 | 3.3 | 1.2 | 112 | 44 | +68 | 5 of 20 | 11 of 20 | +38 | +76 |
| **Opponent** | all armies | 35 | 130 | 487 | 3.7 | 1.2 | 131 | 21 | +110 | 56 of 130 | 78 of 130 | +156 | +96 |

### Effective charges: fw-h2h-mine-e441028-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 1 (net +43) | 1 (net +0) | 0 | 2 (net -111) | 2 (net +72) | 1 (net +0) | 2 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 3 | 0 | 0 | 0 | 0 | 1 (net +716) | 1 (net +0) | 1 | 0% (0 of 2) |
| Mine | Dwarfen Mountain Holds | 8 | 0 | 0 | 3 (net +60) | 1 (net +0) | 0 | 3 (net -136) | 1 | 43% (3 of 7) |
| Mine | Empire of Man | 9 | 0 | 1 (net -281) | 1 (net -189) | 2 (net +66) | 0 | 4 (net +172) | 1 | 12% (1 of 8) |
| Mine | Grand Cathay | 12 | 1 (net +232) | 1 (net +0) | 2 (net +302) | 4 (net +50) | 1 (net +77) | 3 (net +99) | 0 | 17% (2 of 12) |
| Mine | High Elf Realms | 10 | 1 (net +0) | 0 | 1 (net +234) | 1 (net +325) | 3 (net +120) | 3 (net +179) | 1 | 11% (1 of 9) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +0) | 0 | 1 (net +122) | 1 (net +0) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 2 | 0 | 0 | 1 (net +233) | 1 (net +186) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net -34) | 0 | 2 (net +55) | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Orc & Goblin Tribes | 8 | 0 | 0 | 0 | 0 | 2 (net +95) | 0 | 6 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 1 (net +125) | 1 (net +158) | 1 | 0% (0 of 2) |
| Mine | Vampire Counts | 11 | 0 | 0 | 1 (net -483) | 3 (net +0) | 1 (net +126) | 5 (net +83) | 1 | 10% (1 of 10) |
| Opponent | Dwarfen Mountain Holds | 8 | 1 (net +0) | 0 | 2 (net +0) | 2 (net +26) | 0 | 2 (net -323) | 1 | 29% (2 of 7) |
| Opponent | Empire of Man | 6 | 0 | 0 | 3 (net +77) | 0 | 0 | 1 (net +310) | 2 | 75% (3 of 4) |
| Opponent | Grand Cathay | 8 | 2 (net -14) | 0 | 3 (net +95) | 2 (net +112) | 0 | 1 (net +0) | 0 | 38% (3 of 8) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +0) | 0 | 0 | 0 | 1 (net +186) | 2 (net +149) | 0 | 0% (0 of 4) |
| Opponent | Ogre Kingdoms | 12 | 0 | 0 | 0 | 1 (net +0) | 1 (net +147) | 6 (net +82) | 4 | 0% (0 of 8) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +238) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 12 | 1 (net +314) | 0 | 2 (net +125) | 1 (net +400) | 1 (net +739) | 5 (net +311) | 2 | 20% (2 of 10) |
| Opponent | Vampire Counts | 25 | 5 (net +91) | 0 | 4 (net -38) | 6 (net +92) | 4 (net +103) | 5 (net +134) | 1 | 17% (4 of 24) |
| Opponent | Warriors of Chaos | 34 | 2 (net -42) | 0 | 5 (net +238) | 7 (net +27) | 2 (net +154) | 12 (net +272) | 6 | 18% (5 of 28) |
| Opponent | Wood Elf Realms | 20 | 3 (net +202) | 1 (net +0) | 2 (net +290) | 7 (net -47) | 2 (net +0) | 5 (net +100) | 0 | 10% (2 of 20) |

### Charged fights, damage counted: fw-h2h-mine-e441028-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 180 | 285 | +69 | 143 | 21 | +122 | +67.5 |
| Mine | 50-54% | 3 | 200 | 331 | -94 | 10 | 98 | -88 | -43.9 |
| Mine | Effective (55-75%) | 11 | 259 | 242 | +61 | 130 | 69 | +61 | +23.4 |
| Mine | 76-89% | 15 | 275 | 193 | +42 | 94 | 40 | +53 | +19.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 217 | 174 | +73 | 108 | 41 | +67 | +30.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 443 | 98 | +142 | 143 | 8 | +136 | +30.6 |
| Mine | No odds | 14 | 298 | 169 | -8 | 60 | 59 | +1 | +0.4 |
| Mine | All fights | 83 | 280 | 185 | +57 | 104 | 44 | +60 | +21.6 |
| Opponent | Long shot (under 50%) | 15 | 248 | 244 | +84 | 136 | 74 | +61 | +24.8 |
| Opponent | 50-54% | 1 | 125 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 21 | 311 | 212 | +113 | 142 | 44 | +98 | +31.5 |
| Opponent | 76-89% | 26 | 274 | 203 | +42 | 107 | 80 | +27 | +9.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 40 | 349 | 233 | +167 | 208 | 37 | +171 | +48.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 474 | 108 | +163 | 167 | 18 | +149 | +31.4 |
| Opponent | No odds | 16 | 216 | 191 | +66 | 90 | 25 | +65 | +30.3 |
| Opponent | All fights | 130 | 309 | 209 | +110 | 149 | 48 | +101 | +32.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h-mine-e441028-p2 | move | 516 | 103 (20%) | 74 (14%) | 64 (12%) | 349 (68%) |
| fw-h2h-mine-e441028-p2 | objective | 396 | 52 (13%) | 38 (10%) | 59 (15%) | 285 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

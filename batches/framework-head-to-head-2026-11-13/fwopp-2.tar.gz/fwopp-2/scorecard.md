# Doctrine scorecard: fw-h2h-opp-e441028-p2

### Scorecard: fw-h2h-opp-e441028-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | yes | 9 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0122 | 2 | 1 | Mine | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 7 | 0 | 0 | 0 | 307 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 1 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 3 | 2 | 1 | 3 | 0 | 0 | 0 | 251 |
| L0222 | 6 | 1 | Opponent | no | 5 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 3 | 0 | 0 | 0 | 0 | 760 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 90 |
| L0409 | 1 | 1 | Mine | no | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 692 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 1290 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 1 | 0 | 0 | 165 |
| L0528 | 6 | 1 | Mine | no | 9 | 2 | 1 | 1 | 0 | 0 | 0 | 1018 |
| L0528 | 6 | 1 | Opponent | no | 5 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 984 |
| L0616 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 307 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0632 | 2 | 1 | Opponent | - | - | 1 | 4 | 4 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | no | 2 | 3 | 6 | 0 | 0 | 0 | 0 | 375 |
| L0721 | 1 | 1 | Opponent | yes | 5 | - | 3 | 3 | 0 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 515 |
| L0810 | 6 | 1 | Opponent | no | 4 | 6 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 1 | 0 | 0 | 726 |
| L0827 | 5 | 1 | Opponent | yes | - | 5 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 375 |
| L0918 | 6 | 1 | Opponent | no | 9 | 4 | 2 | 2 | 2 | 0 | 0 | 40 |
| L0934 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 479 |
| L0934 | 4 | 1 | Opponent | no | 3 | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 2 | 3 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 5 | 6 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 1 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 5 | 3 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | yes | 3 | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 3 | 4 | 1 | 3 | 1 | 0 | 0 | 72 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 228 |
| L1435 | 1 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 140 |
| L1531 | 1 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 126 |
| L1531 | 1 | 1 | Opponent | no | 5 | 3 | 4 | 1 | 2 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 2 | 6 | 0 | 0 | 0 | 0 | 147 |
| L1727 | 5 | 1 | Opponent | no | - | 3 | 6 | 2 | 1 | 0 | 0 | 250 |
| L1827 | 3 | 1 | Mine | no | 2 | 3 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 5 | 4 | 1 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 3 | 2 | 3 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 1 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 0 | 2 | 0 | 0 | 0 | 210 |
| L2131 | 1 | 1 | Opponent | no | 2 | 3 | 1 | 1 | 2 | 0 | 0 | 340 |
| L2235 | 3 | 1 | Mine | yes | 1 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 4 | 2 | 3 | 1 | 0 | 0 | 200 |
| L2535 | 3 | 1 | Mine | no | 0 | 5 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 60 |
| L2735 | 5 | 1 | Opponent | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L3033 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 31% | 2.5 | 2.6 | 3.0 | 1.1 | 0.3 | 0.0 | 0.0 | 314.1 |
| **Average** | | | Opponent | 24% | 2.4 | 3.1 | 2.5 | 1.8 | 0.5 | 0.0 | 0.0 | 166.4 |

### KPIs: fw-h2h-opp-e441028-p2

Rules off - Mine only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 175) | 28% (51 of 184) | 14% (51 of 359) |
| Winner chose to follow up after the loser gave ground |  | 95% (70 of 74); on the table 95% | 98% (39 of 40); on the table 100% | 96% (109 of 114); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 85% (17 of 20); on the table 85% | 87% (26 of 30); on the table 87% |
| Winner chose to pursue after the loser fled |  | 65% (13 of 20); on the table 80% | 78% (25 of 32); on the table 81% | 73% (38 of 52); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 88% (92 of 104); on the table 91% | 88% (81 of 92); on the table 90% | 88% (173 of 196); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 37% (127 of 342) | 39% (58 of 150) | 38% (185 of 492) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (127 of 276) | 54% (58 of 107) | 48% (185 of 383) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 42% (22 of 52) | 42% (22 of 52) |
| Points that never fought | lower | 38% (26312 of 69583) | 38% (26388 of 69989) | 38% (52700 of 139572) |
|   infantry points that never fought | lower | 39% (6272 of 16001) | 54% (7273 of 13361) | 46% (13545 of 29362) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (159 of 278) | 61% (174 of 287) | 59% (333 of 565) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.6 uses a game | 56% (10 of 18); 1.0 uses a game | 74% (28 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 39% (7 of 18); 0.7 uses a game | 50% (1 of 2); 0.0 uses a game | 40% (8 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30615 of 58577) | 55% (33901 of 61319) | 54% (64516 of 119896) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (24%) | 0.6 (23%) | 2.0 (23%) |
| MARCHED: its unit marched | 1.5 (26%) | 0.5 (21%) | 2.1 (24%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (3%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 0.6 (11%) | 0.4 (15%) | 1.0 (12%) |
| REAR RANK: in a rear rank | 0.7 (12%) | 0.1 (4%) | 0.8 (10%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.0 (17%) | 0.6 (23%) | 1.6 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.2 (9%) | 0.3 (4%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (0%) | 0.2 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 2.4 | 1.8 | 5.1 | 0.4 | 1.1 |
| not cast | 3.7 | 2.4 | 3.0 | 8.5 | 1.8 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (57%) | 0.3 (9%) | 2.0 (23%) | 0.5 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (24%) | 0.4 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (2%) | 0.1 (5%) | 1.0 (12%) | 0.1 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (3%) | 0.3 (11%) | 0.8 (10%) | 0.2 (9%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (5%) | 0.2 (6%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.5 (40%) | 0.5 (20%) | 0.9 (31%) | 1.6 (19%) | 0.0 (0%) | 3.9 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.2 (7%) | 0.3 (4%) | 0.1 (6%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.1 (2%) | 0.2 (3%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (10%) | 0.1 (2%) | 0.1 (1%) | 0.4 (22%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (48%) | 0.0 (1%) | 0.8 (28%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.5 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 1.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 66% (21 of 32) | 69% (24 of 35) | 67% (45 of 67) |
| the unit moved after it | 67% (14 of 21) | 75% (18 of 24) | 71% (32 of 45) |
| it charged on its next turn | 0% (0 of 21) | 4% (1 of 24) | 2% (1 of 45) |
| the enemy charged it first | 19% (4 of 21) | 8% (2 of 24) | 13% (6 of 45) |
| it fought by the end of its next turn | 10% (2 of 21) | 0% (0 of 24) | 4% (2 of 45) |
| it moved out of a charge the enemy had planned (not charged first) | 33% (7 of 21) | 21% (5 of 24) | 27% (12 of 45) |
| none of these (no charge, no fight, no charge escaped) | 48% (10 of 21) | 67% (16 of 24) | 58% (26 of 45) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (562 of 869) | 54% (424 of 779) | 60% (986 of 1648) |
|   cavalry | 46% (38 of 82) | 49% (83 of 169) | 48% (121 of 251) |
|   character | 62% (52 of 84) | 31% (33 of 107) | 45% (85 of 191) |
|   chariot | 47% (52 of 110) | 78% (39 of 50) | 57% (91 of 160) |
|   infantry | 54% (141 of 261) | 55% (156 of 283) | 55% (297 of 544) |
|   monster | 48% (23 of 48) | 51% (29 of 57) | 50% (52 of 105) |
|   war machine | 90% (256 of 284) | 74% (84 of 113) | 86% (340 of 397) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (30%) | 2.7 (27%) | 5.2 (28%) |
| CHARGED: it charged | 1.3 (15%) | 1.5 (15%) | 2.8 (15%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.6 (6%) | 1.4 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.7 (20%) | 2.1 (21%) | 3.8 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.3 (3%) | 0.6 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (17%) | 1.7 (17%) | 3.1 (17%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| STUPIDITY | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (3%) | 0.4 (5%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.6 | 74% | 4.9 pts | 26 pts |
| character | 2.5 | 0.9 | 73% | 14.5 pts | 36 pts |
| chariot | 2.6 | 1.6 | 71% | 15.3 pts | 39 pts |
| infantry | 11.4 | 4.1 | 76% | 8.8 pts | 101 pts |
| monster | 1.9 | 0.6 | 75% | 6.1 pts | 11 pts |
| war machine | 9.4 | 7.5 | 61% | 23.5 pts | 222 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.8 | 5.2 | 5.0 |
| Charges that made contact a game | 3.6 | 3.6 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.59 declared, 0.41 contact (27 units) | 0.56 declared, 0.38 contact (16 units) | 0.58 declared, 0.40 contact (43 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.60 declared, 0.50 contact (10 units) | 0.80 declared, 0.53 contact (15 units) | 0.72 declared, 0.52 contact (25 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.46 contact (250 units) | 0.54 declared, 0.38 contact (307 units) | 0.57 declared, 0.42 contact (557 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (38 of 70) | 56% (10 of 18) | 67% (8 of 12) | 56% (56 of 100) |
| Character in a unit | 95% (19 of 20) | 54% (7 of 13) | 50% (1 of 2) | 77% (27 of 35) |
| Character on its own | 80% (40 of 50) | 61% (23 of 38) | 39% (24 of 62) | 58% (87 of 150) |
| Chariot | 53% (9 of 17) | 46% (6 of 13) | - | 50% (15 of 30) |
| Infantry | 59% (55 of 93) | 32% (10 of 31) | 0% (0 of 3) | 51% (65 of 127) |
| Monster | 59% (17 of 29) | 25% (2 of 8) | - | 51% (19 of 37) |
| Monstrous | 85% (11 of 13) | 64% (9 of 14) | - | 74% (20 of 27) |
| War Machines | 74% (42 of 57) | 100% (2 of 2) | - | 75% (44 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 89% (8 of 9); on the table 100% | 33% (34 of 102) | 58% | 45% (10 of 22) | 100% (6 of 6); 4.2 uses a game | 100% (2 of 2); 1.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 89% (16 of 18); on the table 89% | 58% (21 of 36) | 48% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 6 | 75% (6 of 8); on the table 88% | - | 57% | 81% (44 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 88% (22 of 25); on the table 92% | 42% (20 of 48) | 45% | 63% (48 of 76) | 0.0 uses a game | 50% (1 of 2); 0.6 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 100% (9 of 9); on the table 100% | 40% (55 of 138) | 44% | 54% (29 of 54) | 86% (12 of 14); 6.7 uses a game | 100% (2 of 2); 1.0 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 100% (9 of 9); on the table 100% | 6% (1 of 18) | 24% | 52% (17 of 33) | 100% (3 of 3); 2.2 uses a game | 21% (3 of 14); 2.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (5 of 5); on the table 100% | - | 42% | 33% (4 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 75% (6 of 8); on the table 75% | - | 17% | 14% (1 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (8 of 8); on the table 100% | 33% (6 of 18) | 41% | 54% (15 of 28) | 25% (1 of 4); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 17% (2 of 12) | 3% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 88% (7 of 8); on the table 88% | 33% (6 of 18) | 28% | 44% (11 of 25) | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 67% (4 of 6); on the table 67% | - | 47% | 48% (12 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 89% (34 of 38); on the table 89% | 38% (25 of 66) | 23% | 78% (42 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 81% (22 of 27); on the table 85% | 33% (6 of 18) | 23% | 52% (35 of 67) | 100% (2 of 2); 1.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 6 | 93% (14 of 15); on the table 100% | 50% (9 of 18) | 39% | 62% (42 of 68) | 40% (2 of 5); 1.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h-opp-e441028-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (29) | 57% (39) | 50% (68) |
| ...free all their last turn and able to turn (per game) | 0.50 | 0.86 | 1.36 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.14 | 0.22 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.56 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.97 | 1.47 | 3.44 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.97 | 0.92 | 1.89 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.19 | 7.56 | 13.75 |

### Quality by phase: fw-h2h-opp-e441028-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 0.0 |
| Strategy | Charge objectives carried out (made contact) | 55% (77 of 141) | 47% (78 of 167) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (164 of 337) | 52% (86 of 166) |
| Strategy | Close-in objectives charged next turn | 11% (18 of 163) | 14% (40 of 296) |
| Strategy | Support requests answered (helper made contact too) | 62% (8 of 13) | 44% (8 of 18) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (15 of 24) | 41% (11 of 27) |
| Strategy | Joined characters whose unit fought | 39% (19 of 49) | 19% (3 of 16) |
| Strategy | Lone characters that fought | 70% (65 of 93) | 77% (79 of 103) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.8 |
| Movement | Points that never moved of their own | 314.1 | 166.4 |
| Movement | Fights charged into per game | 3.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 99, net +52 | 11 of 85, net +1 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 99, net +28 | 18 of 85, net +76 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 22 of 99, net +82 | 11 of 85, net +76 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 of 99, net +103 | 23 of 85, net +159 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 10.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (155 of 335) | 53% (205 of 386) |
| Shooting | Points destroyed by shooting units | 75.7 | 33.8 |
| Shooting | War machine shots | 7.1 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (129 of 256) | 48% (40 of 84) |
| Shooting | Points destroyed by war machines | 58.7 | 46.3 |
| Magic | Magic missiles cast | 2.5 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 54% (49 of 90) | 41% (17 of 41) |
| Magic | Wounds caused by magic missiles | 4.0 | 1.4 |
| Magic | Wounds caused by other spells | 1.1 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 116.6 | 25.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.7 / 0.3 / 0.0 | 1.8 / 0.8 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 330.8 | 319.2 |
| Combat | Points run down | 50.1 | 163.2 |
| Combat | Net points per charged fight, damage counted | +78 | +95 |
| Combat | Net per 100 charger points, damage counted | +28.8 | +35.7 |
| Combat | First round won (charged fights) | 81% | 63% |
| Combat | Net points per charged fight | +71 | +89 |
| Combat | Net points per supported fight / lone fight | +90 / +67 | +154 / +74 |
| Combat | Charged fights on a top-3 enemy unit | 35 of 114 | 42 of 106 |
| Game | Points lost | 638.0 | 675.9 |
| Game | VP from objectives | 573.1 | 609.1 |
| Game | Lone holders (player turns) | 2.5 | 2.4 |

- Mine won / drew / lost: 13 / 6 / 16 of 35 ended games (of 36); mean margin (Mine - Opponent) -8 VP
- The side that went first won 17 of 29 games with a winner
- Points traded per game (both sides' losses): 1314
- Games not ended: 1 (L3033-1); findings 4, warnings 0

### Opponent rules: fw-h2h-opp-e441028-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +6.6 | 0.0 | 2.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.9 | +0.0 | 0.0 | 6.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +4.9 | 0.0 | 24.3 | 1.2 | +10.3 | 0.0 | 32.0 |
| BEST FACING | - | - | - | - | 0.7 | +27.2 | 0.0 | 22.0 |
| BEST FIRST | - | - | - | - | 4.0 | +192.5 | 66.0 | 28.9 |
| BEST OVERALL | 0.4 | +21.1 | 0.0 | 16.9 | 0.7 | +28.8 | 0.0 | 20.8 |
| BEST PREY | 5.2 | +301.6 | 220.2 | 82.1 | 0.7 | +38.7 | 19.8 | 12.9 |
| BEST PRIZE | 0.1 | +1.2 | 0.0 | 2.9 | 0.0 | -0.6 | 0.0 | 3.5 |
| BIG CHARACTER SAFETY | 0.2 | -1.5 | 0.0 | 16.1 | 0.2 | -1.2 | 0.0 | 22.8 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 11.1 | 0.0 |
| BLOCKED WHEEL | 0.6 | +23.5 | 0.0 | 13.8 | 0.5 | +10.6 | 0.0 | 4.1 |
| BOMBING RUN | 0.1 | +1.6 | 2.8 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 99.5 | 12.6 | 0.3 | +0.0 | 17.6 | 8.5 |
| CANNON PLANNED TARGET | 5.3 | +164.9 | 242.2 | 79.4 | 1.7 | +79.9 | 115.1 | 46.4 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | -8.2 | 7.6 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | -1.6 | 14.8 | 15.8 |
| CAST JOB | 0.7 | +31.2 | 55.8 | 12.9 | 0.2 | +4.2 | 13.6 | 11.2 |
| CASTING BLOCK | 0.3 | +22.1 | 15.8 | 0.0 | 0.0 | +1.7 | 5.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 39.0 | 0.7 | +0.0 | 0.0 | 35.0 |
| CATCH FLIERS | 0.1 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 5.6 | 0.4 | -0.2 | 0.0 | 3.4 |
| CHARGE NOW WEIGHED | 0.4 | -28.6 | 7.1 | 1.8 | 0.5 | -40.1 | 11.2 | 10.5 |
| CHARIOT NO STATIC JOB | 0.3 | +0.0 | 0.0 | 5.8 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 7.4 | 1.2 | 0.2 | +0.0 | 2.9 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 31.0 | 21.0 | 0.4 | +0.0 | 20.1 | 27.6 |
| CONVEYANCE SEARCH | 0.6 | +171.9 | 25.6 | 39.0 | 0.8 | +105.7 | 34.4 | 69.0 |
| COUNTER-CHARGE COVER | 7.9 | +669.3 | 0.0 | 159.4 | 8.3 | +766.9 | 0.0 | 159.4 |
| DEFENSIVE ARMY | - | - | - | - | 0.3 | -0.0 | 1.4 | 2.9 |
| EDGE GIVE GROUND | 0.1 | +4.5 | 30.9 | 11.1 | 0.1 | +7.3 | 3.5 | 5.4 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +202.1 | 0.0 | 57.4 | 1.5 | +122.0 | 0.0 | 39.2 |
| FALLBACK BY WORTH | 6.5 | +82.1 | 0.0 | 73.0 | 6.9 | +55.0 | 0.0 | 53.5 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.5 | 0.0 | 1.7 | 0.1 | +1.5 | 0.0 | 6.5 |
| FLANK NOT WEIGHED | 6.4 | +0.0 | 0.0 | 172.4 | 6.3 | +0.0 | 0.0 | 174.0 |
| FLEE LOSES BLESSING | - | - | - | - | 0.0 | +1.1 | 0.0 | 7.7 |
| FOCUS FIRE | 0.0 | +2.2 | 0.0 | 1.5 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +132.4 | 0.0 | 47.8 | 0.9 | +130.0 | 0.0 | 51.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +15.9 | 0.0 | 8.3 | 0.1 | +1.0 | 0.0 | 0.9 |
| GATEWAY ESCAPE | - | - | - | - | 0.0 | +2.6 | 0.0 | 0.0 |
| GIVES UP | 1.2 | -31.6 | 110.7 | 39.8 | 1.0 | -54.8 | 110.1 | 45.2 |
| GIVES UP ITS SCREEN | 0.3 | -6.6 | 33.9 | 5.8 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 5.2 |
| HELPER UNSEEN | 0.5 | +0.0 | 33.1 | 12.2 | 0.4 | +0.0 | 1.4 | 23.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.8 | -76.5 | 0.0 | 2.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.4 | 2.8 | 0.0 | 0.3 | +5.2 | 13.5 | 12.7 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 11.0 | 5.0 |
| HUNT IN PAIRS | 0.6 | +24.0 | 0.0 | 16.1 | 0.7 | +33.7 | 0.0 | 21.4 |
| HUNT KEPT | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 3.1 |
| HUNT RESULT | 0.1 | +2.8 | 0.0 | 0.0 | 0.3 | +34.8 | 13.3 | 10.2 |
| HUNT THE GUNS | 0.1 | +14.6 | 2.8 | 0.0 | 0.3 | +109.2 | 27.9 | 15.4 |
| INVITES THE FIGHT | - | - | - | - | 3.5 | +236.7 | 88.9 | 37.7 |
| JOINT CHARGE PLAN | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 10.3 |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 13.6 | - | - | - | - |
| KEEPS ITS PREY | 0.6 | +3.1 | 16.7 | 17.2 | 0.1 | +1.1 | 2.4 | 1.9 |
| KEEPS ITS TARGET | 1.6 | +48.3 | 164.9 | 51.9 | 2.9 | +86.7 | 157.7 | 99.2 |
| KILLS COUNT | 2.2 | +88.9 | 150.6 | 75.5 | 1.9 | +89.0 | 109.3 | 28.8 |
| KILLS COUNT NEXT TURN | 9.4 | +314.4 | 464.9 | 197.7 | 8.8 | +332.8 | 292.2 | 227.0 |
| LONE CHARACTER SAFE SPOT | 0.2 | +13.4 | 0.0 | 0.0 | 0.4 | +6.3 | 1.7 | 3.5 |
| LONE WIZARD HOLDS BACK | 0.3 | +0.0 | 3.4 | 5.9 | 1.7 | +0.0 | 32.0 | 77.5 |
| LONG SHOT | - | - | - | - | 0.6 | -3.5 | 18.4 | 9.5 |
| LOST CHARGE | - | - | - | - | 1.9 | -45.3 | 53.5 | 32.6 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -13.2 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +2.3 | 0.0 | 0.0 | 1.7 | +134.7 | 45.8 | 45.0 |
| MANOEUVRE | 0.2 | +2.7 | 0.0 | 1.5 | 0.4 | +14.4 | 0.0 | 5.2 |
| MARCH AT ESCAPER | 0.1 | +3.1 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 11.2 |
| MARCH CHECK | 0.7 | +34.3 | 0.0 | 9.3 | 0.5 | +14.8 | 0.0 | 11.2 |
| MARCH ODDS | 0.8 | +86.8 | 31.9 | 16.1 | 0.1 | +9.2 | 13.6 | 0.0 |
| MARCH OVER CASTS | 0.6 | +56.4 | 0.0 | 13.9 | 0.5 | +32.0 | 0.0 | 26.0 |
| MAX FOR POSITIONING | 4.7 | +191.8 | 0.0 | 120.4 | 5.3 | +247.3 | 0.0 | 170.3 |
| MISSILES IN THE MOVE | 4.2 | +134.8 | 0.0 | 102.8 | 2.7 | +54.0 | 0.0 | 90.2 |
| MISSILES NEXT TURN | 5.2 | +99.4 | 0.0 | 127.8 | 3.4 | +39.5 | 0.0 | 116.2 |
| MODEL FACING | 0.3 | +49.8 | 0.0 | 5.0 | 0.2 | +39.3 | 0.0 | 0.0 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 22.8 | 0.0 |
| MOVE AND CAST | 0.3 | +3.0 | 0.0 | 17.8 | 0.2 | +5.3 | 0.0 | 21.8 |
| MOVE SPELL IN RANGE | 0.4 | +15.7 | 0.0 | 34.9 | 0.4 | +8.4 | 0.0 | 49.0 |
| MOVE SPELL OUT OF RANGE | 0.6 | -12.8 | 0.0 | 34.9 | 0.2 | -14.4 | 0.0 | 33.8 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 13.9 | 0.1 | +0.0 | 0.0 | 10.2 |
| MOVE TO CHARGE | - | - | - | - | 8.9 | +781.6 | 291.1 | 221.6 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +10.4 | 6.9 | 0.0 | 0.1 | +26.4 | 2.8 | 0.0 |
| NOT NEEDED | 0.1 | -6.8 | 14.9 | 1.4 | 0.4 | -23.4 | 26.8 | 6.4 |
| NOT TURNED | 6.2 | +129.6 | 0.0 | 131.9 | 7.6 | +142.7 | 0.0 | 240.9 |
| NOT WORTH A CAST | 0.6 | -0.3 | 0.0 | 11.2 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 18.3 | -1015.1 | 55.4 | 306.1 | 17.3 | -929.8 | 2.9 | 279.9 |
| OPENS A LANE | 0.2 | +0.4 | 17.3 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +16.0 | 5.1 | 0.0 | 0.4 | +24.2 | 15.7 | 17.3 |
| OVERRUNS AWAY | 0.8 | +21.2 | 82.2 | 29.3 | 0.4 | +5.7 | 18.6 | 10.9 |
| PATHS CROSS | 1.7 | +110.1 | 0.0 | 8.6 | 3.7 | +304.0 | 0.0 | 51.0 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 15.0 | 0.0 | +2.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.4 | 0.0 | 4.2 | 0.1 | -2.2 | 0.0 | 6.2 |
| PLAN RESULT | 38.9 | +1444.9 | 1395.0 | 883.0 | 43.6 | +970.8 | 1306.0 | 1098.4 |
| PURSUES BIG PREY | 0.0 | -1.2 | 0.0 | 0.0 | 0.1 | -6.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.4 | +18.1 | 0.0 | 25.6 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.3 | -14.5 | 22.1 | 4.7 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.2 | +1.7 | 0.0 | 1.1 |
| REDIRECT COUNTER | 3.2 | +172.7 | 0.0 | 63.2 | 3.4 | +298.2 | 0.0 | 64.5 |
| REDIRECT WEIGHED | 0.1 | +2.4 | 2.6 | 2.9 | 0.4 | +10.0 | 15.3 | 19.8 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +16.4 | 0.0 | 17.6 |
| RESTRAINS TO SHOOT | 0.2 | +20.5 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 3.2 |
| RISK BY ARC | 2.3 | +76.9 | 190.7 | 92.6 | 2.6 | +57.1 | 185.4 | 93.0 |
| SAFER THAN THE JOB | 1.0 | +62.7 | 0.0 | 17.5 | 0.9 | +45.4 | 0.0 | 33.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.4 | -20.5 | 0.0 | 3.5 |
| SEARCH SPOT | 1.6 | +93.3 | 0.0 | 11.2 | 4.0 | +196.2 | 0.0 | 46.6 |
| SELF MOVE SPELL | 0.2 | +11.0 | 0.0 | 11.0 | - | - | - | - |
| SET UP TOGETHER | 0.5 | +5.2 | 0.0 | 0.0 | 2.4 | +185.3 | 72.4 | 45.0 |
| SET-UP ANY TARGET | 0.2 | +31.6 | 20.9 | 36.4 | 0.2 | +35.0 | 11.2 | 37.7 |
| SET-UP MISSED | 0.1 | +21.0 | 9.6 | 11.2 | 0.1 | +14.2 | 0.0 | 11.2 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.9 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.8 | +19.1 | 25.3 | 7.6 |
| SHOT REPLANNED | 0.5 | +0.0 | 98.8 | 0.0 | 0.2 | +0.0 | 43.6 | 0.0 |
| SHOTS IN THE MOVE | 13.4 | +568.7 | 0.0 | 229.6 | 10.3 | +322.1 | 0.0 | 146.7 |
| SPELL SETS UP CHARGE | 0.3 | +71.3 | 20.9 | 36.4 | 0.4 | +68.0 | 24.7 | 48.0 |
| SPELL WORTH | 0.8 | +12.8 | 74.3 | 63.5 | 1.9 | +34.8 | 115.9 | 112.6 |
| STABLE ROLE | - | - | - | - | 12.7 | +0.0 | 337.8 | 191.7 |
| STANDS TO CAST | - | - | - | - | 0.1 | +4.5 | 0.0 | 15.0 |
| STOPS | - | - | - | - | 0.1 | +3.8 | 14.4 | 5.7 |
| STOPS SHORT OF THE FLANK | 0.5 | +19.4 | 0.0 | 5.9 | 0.7 | +25.9 | 0.0 | 34.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORTS | - | - | - | - | 8.5 | +354.5 | 230.1 | 112.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.2 | 6.1 | 0.0 | 0.2 | -22.0 | 10.7 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.2 | 0.0 | 1.7 | 0.7 | +2.9 | 20.1 | 14.6 |
| THROUGH LINE OF FIRE | 0.4 | +17.4 | 0.0 | 5.2 | 0.4 | +36.4 | 0.0 | 17.4 |
| TURN WORTH | 0.4 | -35.6 | 30.4 | 11.3 | 0.4 | -18.7 | 9.6 | 13.3 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 0.0 | 0.0 | 0.9 | +5.3 | 38.6 | 13.7 |
| WALKS TO THE FIGHT | - | - | - | - | 1.5 | +66.0 | 34.8 | 45.5 |
| WAR ENGINE JOBS | - | - | - | - | 0.5 | +0.0 | 18.9 | 17.4 |
| WEARS DOWN | 0.8 | +30.2 | 67.4 | 10.0 | 1.2 | +39.6 | 86.4 | 52.8 |
| WHO HITS BACK | 0.2 | +16.8 | 0.0 | 3.5 | 0.1 | +4.8 | 0.0 | 5.7 |
| WHOLE FIGHT | 0.3 | +4.8 | 48.9 | 0.0 | 0.3 | +14.5 | 23.9 | 2.1 |
| WHOLE FIGHT GAIN | 0.2 | +15.6 | 19.8 | 7.9 | 0.6 | +55.3 | 17.1 | 12.3 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 2.9 | 0.0 |

### Rule changes: fw-h2h-opp-e441028-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1284 | 1284 | 1284 | 35.67 | -70014 | -54.5 |
| SEARCH SPOT | 202 | 202 | 201 | 5.58 | +10420 | +51.8 |
| PATHS CROSS | 195 | 195 | 195 | 5.42 | +14906 | +76.4 |
| KILLS COUNT NEXT TURN | 654 | 648 | 178 | 4.94 | +5947 | +33.4 |
| MOVE TO CHARGE | 322 | 322 | 164 | 4.56 | +10019 | +61.1 |
| SUPPORTS | 307 | 307 | 161 | 4.47 | +4367 | +27.1 |
| BEST FIRST | 145 | 145 | 145 | 4.03 | +6930 | +47.8 |
| COUNTER-CHARGE COVER | 584 | 310 | 139 | 3.86 | +7933 | +57.1 |
| FACES THE THREAT | 124 | 124 | 124 | 3.44 | +11670 | +94.1 |
| BEST PREY | 214 | 210 | 111 | 3.08 | +3796 | +34.2 |
| FALLBACK BY WORTH | 483 | 483 | 91 | 2.53 | +4937 | +54.2 |
| FOLLOW UP WEIGHED | 70 | 70 | 70 | 1.94 | +9448 | +135.0 |
| SHOTS IN THE MOVE | 854 | 527 | 70 | 1.94 | +2193 | +31.3 |
| SAFER THAN THE JOB | 68 | 68 | 68 | 1.89 | +3892 | +57.2 |
| CANNON PLANNED TARGET | 251 | 251 | 54 | 1.50 | -819 | -15.2 |
| MAX FOR POSITIONING | 360 | 192 | 53 | 1.47 | +644 | +12.1 |
| RISK BY ARC | 177 | 164 | 46 | 1.28 | +1975 | +42.9 |
| REDIRECT COUNTER | 240 | 121 | 43 | 1.19 | +2326 | +54.1 |
| STOPS SHORT OF THE FLANK | 43 | 43 | 43 | 1.19 | +1631 | +37.9 |
| INVITES THE FIGHT | 125 | 125 | 41 | 1.14 | +1675 | +40.9 |
| BEST OVERALL | 40 | 40 | 40 | 1.11 | +1798 | +44.9 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| BLOCKED WHEEL | 38 | 38 | 38 | 1.06 | +1227 | +32.3 |
| WALKS TO THE FIGHT | 55 | 55 | 38 | 1.06 | +970 | +25.5 |
| KEEPS ITS TARGET | 162 | 159 | 37 | 1.03 | +618 | +16.7 |
| KILLS COUNT | 147 | 136 | 36 | 1.00 | +1522 | +42.3 |
| MARCH CHECK | 42 | 38 | 34 | 0.94 | +1668 | +49.0 |
| MARCH ODDS | 34 | 34 | 33 | 0.92 | +1749 | +53.0 |
| SET UP TOGETHER | 106 | 86 | 33 | 0.92 | +2086 | +63.2 |
| CHARGE NOW WEIGHED | 32 | 32 | 32 | 0.89 | +2547 | +79.6 |
| THROUGH LINE OF FIRE | 31 | 31 | 31 | 0.86 | +1937 | +62.5 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| RESERVE FALL BACK | 26 | 26 | 26 | 0.72 | +589 | +22.7 |
| SHOT REPLANNED | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| BEST FACING | 25 | 25 | 25 | 0.69 | +979 | +39.2 |
| LONE WIZARD HOLDS BACK | 73 | 73 | 24 | 0.67 | -1201 | -50.1 |
| MISSILES IN THE MOVE | 249 | 127 | 22 | 0.61 | +336 | +15.3 |
| RANDOM MOVE BY FIGURES | 52 | 52 | 22 | 0.61 | +653 | +29.7 |
| MODEL FACING | 20 | 20 | 20 | 0.56 | +3207 | +160.4 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.56 | +754 | +37.7 |
| MAKE SURE TOGETHER | 69 | 47 | 17 | 0.47 | +1064 | +62.6 |
| MANOEUVRE | 20 | 20 | 17 | 0.47 | +620 | +36.5 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -8 | -0.5 |
| MOVE AND CAST | 16 | 16 | 16 | 0.44 | +301 | +18.8 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -96 | -6.9 |
| CAST JOB | 33 | 31 | 14 | 0.39 | +598 | +42.7 |
| FRIENDS SHOTS CHECKED | 14 | 14 | 14 | 0.39 | +608 | +43.5 |
| WEARS DOWN | 73 | 67 | 14 | 0.39 | +319 | +22.8 |
| WHOLE FIGHT GAIN | 29 | 25 | 13 | 0.36 | +871 | +67.0 |
| OPENS UP | 20 | 20 | 12 | 0.33 | +382 | +31.8 |
| WHO HITS BACK | 12 | 12 | 12 | 0.33 | +596 | +49.7 |
| HUNT IN PAIRS | 48 | 31 | 11 | 0.31 | +361 | +32.9 |
| PIVOT GUARDS FLANK | 11 | 11 | 11 | 0.31 | -165 | -15.0 |
| CASTING BLOCK | 11 | 11 | 10 | 0.28 | +479 | +47.9 |
| SHOOTS FROM THE BEST SPOT | 27 | 27 | 10 | 0.28 | +300 | +30.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -942 | -104.7 |
| FIRE AND FLEE | 8 | 8 | 8 | 0.22 | +70 | +8.8 |
| NEEDED THERE | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +749 | +93.6 |
| BACKUP TARGETS | 78 | 40 | 6 | 0.17 | +8 | +1.3 |
| HUNT ADVANCE | 13 | 13 | 5 | 0.14 | +85 | +17.1 |
| OVERRUNS AWAY | 42 | 39 | 5 | 0.14 | +342 | +68.4 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -260 | -51.9 |
| STUCK PIVOT | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| WHOLE FIGHT | 22 | 21 | 5 | 0.14 | +160 | +31.9 |
| LOST CHARGE | 68 | 68 | 4 | 0.11 | +139 | +34.8 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| SURE REACH TOGETHER | 38 | 24 | 4 | 0.11 | +0 | +0.0 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -31 | -10.3 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +58 | +19.5 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +131 | +43.8 |
| MISSILES NEXT TURN | 312 | 153 | 3 | 0.08 | -0 | -0.1 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -40 | -13.2 |
| TWO OR MORE ARRIVE | 37 | 30 | 3 | 0.08 | +10 | +3.2 |
| WAR ENGINE JOBS | 18 | 18 | 3 | 0.08 | -243 | -81.1 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| CARRIES OUT SET-UP | 8 | 8 | 2 | 0.06 | -56 | -28.0 |
| CHARIOT NO STATIC JOB | 11 | 11 | 2 | 0.06 | -167 | -83.4 |
| LONG SHOT | 21 | 21 | 2 | 0.06 | +15 | +7.3 |
| MOVE SPELL IN RANGE | 28 | 20 | 2 | 0.06 | +14 | +7.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +227 | +113.7 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -294 | -294.3 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -8 | -8.2 |
| DEFENSIVE ARMY | 12 | 12 | 1 | 0.03 | -115 | -115.4 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +10 | +9.9 |
| FLEE LOSES BLESSING | 1 | 1 | 1 | 0.03 | +8 | +8.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +79 | +79.4 |
| GIVES UP | 80 | 71 | 1 | 0.03 | +53 | +52.7 |
| GIVES UP ITS SCREEN | 12 | 12 | 1 | 0.03 | +20 | +20.5 |
| KEEPS ITS PREY | 22 | 19 | 1 | 0.03 | +0 | +0.2 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +78 | +78.3 |
| STOPS | 3 | 3 | 1 | 0.03 | +92 | +91.7 |
| TURN WORTH | 28 | 25 | 1 | 0.03 | +2 | +1.7 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -94 | -94.3 |
| ARRIVAL HUNT | 7 | 7 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 43 | 43 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 47 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 50 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 8 | 8 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 455 | not checked | - | - | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 31 | 27 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 27 | 27 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 13 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 25 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 41 | 41 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 32 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NOT NEEDED | 20 | 20 | 0 | 0.00 | - | - |
| NOT TURNED | 495 | 495 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 29 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 2970 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 10 | 10 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 8 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 23 | not checked | - | - | - | - |
| SPELL WORTH | 97 | not checked | - | - | - | - |
| STABLE ROLE | 457 | 454 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h-opp-e441028-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.69 | 14.78 | 56.7 |
| FALLBACK | gate | 0.92 | 1.17 | 51.2 |
| TURN GATE | gate | 0.47 | 0.72 | 26.2 |
| RULE SWITCHED OFF | gate | 0.92 | - | 34.7 |
| LONE WIZARD HOLDS BACK | rule | 0.08 | 0.39 | 70.6 |
| SUPPORT REQUEST | gate | 0.25 | 0.17 | 53.3 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.08 | 61.2 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.14 | 15.0 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.28 | 84.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.17 | 104.7 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.08 | 14.4 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | 0.08 | 13.2 |
| THROUGH LINE OF FIRE | rule | 0.11 | 0.08 | 12.6 |
| AFTERMATH BAND | gate | 0.06 | 0.11 | 2.2 |
| BLOCKED WHEEL | rule | 0.06 | 0.11 | 14.3 |
| PATHS CROSS | rule | 0.03 | 0.14 | 33.4 |
| CHAFF PASSED | rule | - | 0.14 | 1.6 |
| PURSUES BIG PREY | rule | 0.03 | 0.11 | 51.9 |
| BEST PRIZE | rule | 0.06 | 0.03 | 10.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 20.8 |
| WAR ENGINE JOBS | rule | - | 0.08 | 81.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 20.3 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 28.0 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 83.4 |
| NO REASON | gate | - | 0.06 | 19.5 |
| STANDS TO CAST | rule | - | 0.06 | 19.8 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 294.3 |
| CATCH ODDS | rule | 0.03 | - | 8.2 |
| DEFENSIVE ARMY | rule | - | 0.03 | 115.4 |
| FACES THE THREAT | rule | 0.03 | - | 22.7 |
| FIGHT ORDER BAND | gate | - | 0.03 | 1.9 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 94.3 |

### Plans: fw-h2h-opp-e441028-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 14.5 | 16% | 497 | 435 | 87% |
| Mine | charge | 3.1 | 48% | 248 | 249 | 100% |
| Mine | close in | 4.5 | 25% | 264 | 159 | 60% |
| Mine | hold | 4.0 | 41% | 290 | 0 | 0% |
| Mine | join | 1.1 | 100% | 81 | 0 | 0% |
| Mine | shoot | 8.0 | 61% | 243 | 603 | 248% |
| Mine | support | 3.6 | 88% | 249 | 0 | 0% |
| Opponent | advance | 14.0 | 12% | 854 | 261 | 31% |
| Opponent | charge | 3.3 | 56% | 363 | 223 | 61% |
| Opponent | close in | 8.2 | 21% | 1212 | 218 | 18% |
| Opponent | hold | 3.9 | 30% | 287 | 0 | 0% |
| Opponent | join | 1.5 | 100% | 96 | 0 | 0% |
| Opponent | shoot | 3.8 | 62% | 154 | 269 | 174% |
| Opponent | support | 8.9 | 95% | 324 | 0 | 0% |

### Packages: hunt the guns, fw-h2h-opp-e441028-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 50% | 0% | 2.0 | 263 | 50 | 50% | 47 |
| Opponent | 0.3 | 11 | 0 | 18% | 27% | 0% | 2.0 | 357 | 114 | 27% | 84 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 50% | 0% | 2.0 | 263 | 50 | 50% | 64 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 172 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 77 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 89 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 286 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 359 | 0 | 0% | 110 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 0.6 | 3 | 0 | 0% | 33% | 0% | 2.0 | 305 | 167 | 33% | 39 |
| Vampire Counts | 0.4 | 4 | 0 | 25% | 25% | 0% | 2.0 | 335 | 73 | 25% | 0 |
| Warriors of Chaos | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 479 | 230 | 50% | 22 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |

### Battle groups: fw-h2h-opp-e441028-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.9 | 19% | 59% | 20% | 9% | 23% | 9% | 16% | 51% | 0% |
| Mine | REDIRECT COUNTER | 3.2 | 26% | 67% | 7% | 0% | 21% | 4% | 7% | 61% | 7% |
| Opponent | COUNTER-CHARGE COVER | 8.3 | 20% | 62% | 12% | 71% | 26% | 8% | 9% | 57% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 28% | 60% | 17% | 17% | 10% | 3% | 14% | 72% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h-opp-e441028-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 39 (5) | 39 | 0 | 16 | 20% | 3.8 | 0 (2) | 76 (3) | - | 76 (3) | 0 (2) |
| Mine | Chaff | 29 | 37 (29) | 19 | 18 | 62 | 34% | 3.3 | 62 (16) | 10 (10) | 0 (3) | 39 (18) | 34 (11) |
| Mine | Character | 119 | 38 (119) | 38 | 0 | 35 | 20% | 2.5 | 47 (39) | 35 (39) | 39 (31) | 40 (75) | 40 (34) |
| Mine | Clean-up | 26 | 81 (26) | 38 | 43 | 30 | 23% | 3.1 | 67 (14) | 110 (10) | 0 (2) | 103 (17) | 49 (9) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | Fast Hammer | 43 | 31 (43) | 21 | 10 | 54 | 26% | 2.7 | 30 (17) | 32 (17) | 31 (9) | 43 (34) | 0 (9) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 2.2 | 0 (2) | 0 (2) | 0 (1) | 0 (4) | 0 (1) |
| Mine | Hammer | 56 | 62 (56) | 46 | 17 | 20 | 14% | 2.7 | 37 (23) | 48 (20) | 128 (13) | 61 (41) | 67 (15) |
| Mine | Holder | 26 | 72 (26) | 17 | 54 | 27 | 50% | 4.2 | 77 (13) | 43 (7) | 94 (6) | 104 (17) | 18 (9) |
| Mine | Shooter | 42 | 64 (42) | 28 | 36 | 39 | 5% | 1.8 | 40 (11) | 96 (16) | 46 (15) | 68 (28) | 54 (14) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (1) | 0 (1) | - | 0 (2) |
| Mine | War machine | 59 | 41 (59) | 41 | 0 | 42 | 2% | 1.2 | 21 (21) | 32 (22) | 83 (16) | 36 (43) | 55 (16) |
| Mine | Wizard | 23 | 7 (23) | 7 | 0 | 33 | 17% | 2.3 | 0 (13) | 82 (1) | 11 (7) | 9 (18) | 0 (3) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Chaff | 70 | 86 (70) | 13 | 73 | 47 | 43% | 2.7 | 47 (32) | 146 (20) | 98 (18) | 103 (47) | 55 (23) |
| Opponent | Character | 91 | 45 (91) | 45 | 0 | 32 | 16% | 2.8 | 50 (38) | 36 (23) | 45 (28) | 37 (59) | 57 (30) |
| Opponent | Clean-up | 23 | 30 (23) | 14 | 16 | 32 | 26% | 3.4 | 10 (8) | 49 (8) | 30 (7) | 29 (15) | 33 (8) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 100 | 0% | 5.5 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 39 | 21 (39) | 16 | 6 | 46 | 26% | 3.4 | 21 (16) | 25 (18) | 4 (5) | 21 (25) | 22 (14) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 37 | 67% | 3.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Opponent | Hammer | 65 | 48 (65) | 43 | 5 | 37 | 25% | 2.9 | 38 (30) | 55 (22) | 57 (13) | 63 (44) | 13 (21) |
| Opponent | Holder | 36 | 79 (36) | 8 | 71 | 20 | 33% | 3.5 | 39 (9) | 132 (16) | 33 (11) | 93 (26) | 33 (10) |
| Opponent | Shooter | 41 | 49 (41) | 18 | 32 | 29 | 2% | 1.9 | 62 (17) | 47 (16) | 29 (8) | 59 (31) | 11 (10) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 40 | 75% | 3.0 | - | 0 (3) | 0 (1) | - | 0 (4) |
| Opponent | War machine | 24 | 58 (24) | 58 | 0 | 52 | 4% | 1.3 | 61 (5) | 24 (9) | 85 (10) | 31 (16) | 105 (8) |
| Opponent | Wizard | 28 | 28 (28) | 28 | 0 | 43 | 0% | 1.9 | 67 (10) | 4 (10) | 12 (2) | 38 (18) | 0 (4) |

### Charged fights: fw-h2h-opp-e441028-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 178 | 149 | 1.5 | 1.2 | 100 | 0 | +100 | 0 of 6 | 4 of 6 | +0 | +119 |
| Mine | Chaos Dwarfs | 4 | 119 | 514 | 3.5 | 1.3 | 147 | 6 | +140 | 7 of 14 | 11 of 14 | +318 | +69 |
| Mine | Dwarfen Mountain Holds | 4 | 497 | 130 | 1.0 | 1.0 | 130 | 46 | +84 | 1 of 4 | 2 of 4 | - | +84 |
| Mine | Empire of Man | 5 | 418 | 231 | 3.4 | 1.1 | 68 | 13 | +55 | 6 of 17 | 14 of 17 | +252 | +43 |
| Mine | Grand Cathay | 4 | 555 | 268 | 3.8 | 1.3 | 71 | 14 | +57 | 5 of 15 | 13 of 15 | +92 | +39 |
| Mine | High Elf Realms | 4 | 224 | 308 | 2.8 | 1.3 | 112 | 96 | +16 | 2 of 11 | 9 of 11 | -134 | +72 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1213 | 8.0 | 1.0 | 152 | 0 | +152 | 5 of 8 | 8 of 8 | - | +152 |
| Mine | Lizardmen | 1 | 0 | 556 | 7.0 | 1.0 | 79 | 0 | +79 | 1 of 7 | 5 of 7 | - | +79 |
| Mine | Ogre Kingdoms | 1 | 369 | 225 | 7.0 | 1.1 | 32 | 50 | -17 | 1 of 7 | 5 of 7 | +0 | -20 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 1106 | 7.0 | 1.0 | 158 | 37 | +121 | 2 of 7 | 7 of 7 | - | +121 |
| Mine | Skaven | 2 | 85 | 0 | 1.0 | 1.0 | 0 | 98 | -98 | 1 of 2 | 0 of 2 | - | -98 |
| Mine | Tomb Kings of Khemri | 1 | 114 | 399 | 5.0 | 1.0 | 80 | 18 | +62 | 1 of 5 | 4 of 5 | - | +62 |
| Mine | Vampire Counts | 3 | 0 | 205 | 3.7 | 1.2 | 56 | 4 | +52 | 3 of 11 | 10 of 11 | -22 | +68 |
| **Mine** | all armies | 35 | 258 | 307 | 3.3 | 1.1 | 94 | 24 | +71 | 35 of 114 | 92 of 114 | +90 | +67 |
| Opponent | Dwarfen Mountain Holds | 2 | 128 | 52 | 2.0 | 2.2 | 26 | 73 | -47 | 2 of 4 | 3 of 4 | +15 | -233 |
| Opponent | Empire of Man | 2 | 415 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 2 | 392 | 504 | 3.0 | 1.2 | 168 | 0 | +168 | 3 of 6 | 5 of 6 | +848 | +32 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 180 | 4.0 | 1.0 | 45 | 0 | +45 | 2 of 4 | 3 of 4 | - | +45 |
| Opponent | Ogre Kingdoms | 3 | 263 | 100 | 2.7 | 1.2 | 38 | 45 | -7 | 4 of 8 | 3 of 8 | +150 | -60 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 35 | 225 | 2.8 | 1.0 | 82 | 55 | +27 | 3 of 11 | 6 of 11 | - | +27 |
| Opponent | Vampire Counts | 6 | 42 | 317 | 3.7 | 1.3 | 86 | 65 | +21 | 11 of 22 | 11 of 22 | +70 | +7 |
| Opponent | Warriors of Chaos | 8 | 22 | 664 | 3.5 | 1.3 | 190 | 4 | +185 | 12 of 28 | 22 of 28 | +162 | +192 |
| Opponent | Wood Elf Realms | 6 | 99 | 433 | 3.7 | 1.1 | 118 | 5 | +113 | 5 of 22 | 13 of 22 | +204 | +104 |
| **Opponent** | all armies | 35 | 109 | 351 | 3.0 | 1.2 | 116 | 27 | +89 | 42 of 106 | 67 of 106 | +154 | +74 |

### Effective charges: fw-h2h-opp-e441028-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 0 | 3 (net +102) | 2 (net +88) | 0 | 1 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 14 | 0 | 1 (net +0) | 3 (net +259) | 1 (net +268) | 4 (net +69) | 5 (net +129) | 0 | 21% (3 of 14) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 1 (net +92) | 0 | 2 (net +122) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 17 | 3 (net +116) | 0 | 3 (net -1) | 1 (net +145) | 1 (net +252) | 4 (net +34) | 5 | 25% (3 of 12) |
| Mine | Grand Cathay | 15 | 2 (net +67) | 1 (net +0) | 2 (net +62) | 1 (net +0) | 3 (net +89) | 6 (net +55) | 0 | 13% (2 of 15) |
| Mine | High Elf Realms | 11 | 0 | 0 | 2 (net -180) | 2 (net -118) | 2 (net +23) | 4 (net +182) | 1 | 20% (2 of 10) |
| Mine | Kingdom of Bretonnia | 8 | 2 (net +0) | 1 (net +0) | 0 | 4 (net +210) | 0 | 1 (net +373) | 0 | 0% (0 of 8) |
| Mine | Lizardmen | 7 | 1 (net +186) | 0 | 0 | 2 (net +95) | 2 (net +52) | 1 (net +75) | 1 | 0% (0 of 6) |
| Mine | Ogre Kingdoms | 7 | 0 | 0 | 0 | 2 (net -174) | 2 (net +60) | 1 (net +60) | 2 | 0% (0 of 5) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 0 | 2 (net +155) | 0 | 5 | 0% (0 of 2) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 1 (net -197) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 5 | 1 (net -90) | 0 | 0 | 0 | 3 (net +42) | 1 (net +274) | 0 | 0% (0 of 5) |
| Mine | Vampire Counts | 11 | 3 (net +34) | 0 | 0 | 3 (net +76) | 1 (net +125) | 4 (net +28) | 0 | 0% (0 of 11) |
| Opponent | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 1 (net -8) | 0 | 2 (net -90) | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 6 | 1 (net +0) | 0 | 1 (net +95) | 3 (net +304) | 0 | 1 (net +0) | 0 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +0) | 0 | 2 (net +60) | 0 | 1 (net +60) | 0 | 0 | 50% (2 of 4) |
| Opponent | Ogre Kingdoms | 8 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +300) | 6 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 11 | 2 (net -71) | 0 | 3 (net +56) | 0 | 2 (net +90) | 1 (net +196) | 3 | 38% (3 of 8) |
| Opponent | Vampire Counts | 22 | 6 (net -91) | 1 (net -186) | 4 (net +74) | 5 (net +103) | 2 (net +130) | 2 (net +67) | 2 | 20% (4 of 20) |
| Opponent | Warriors of Chaos | 28 | 0 | 0 | 3 (net +132) | 6 (net +173) | 4 (net +66) | 8 (net +276) | 7 | 14% (3 of 21) |
| Opponent | Wood Elf Realms | 22 | 1 (net +696) | 0 | 3 (net +99) | 6 (net +50) | 2 (net +34) | 8 (net +126) | 2 | 15% (3 of 20) |

### Charged fights, damage counted: fw-h2h-opp-e441028-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 240 | 294 | +52 | 110 | 35 | +75 | +31.5 |
| Mine | 50-54% | 3 | 259 | 270 | +0 | 28 | 42 | -14 | -5.4 |
| Mine | Effective (55-75%) | 12 | 232 | 248 | +28 | 96 | 71 | +25 | +10.8 |
| Mine | 76-89% | 20 | 254 | 168 | +74 | 148 | 70 | +78 | +30.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 256 | 192 | +103 | 140 | 31 | +110 | +42.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 22 | 358 | 85 | +82 | 97 | 13 | +84 | +23.5 |
| Mine | No odds | 15 | 246 | 133 | +51 | 97 | 30 | +67 | +27.3 |
| Mine | All fights | 114 | 270 | 179 | +71 | 117 | 39 | +78 | +28.8 |
| Opponent | Long shot (under 50%) | 11 | 177 | 207 | +1 | 83 | 97 | -14 | -8.0 |
| Opponent | 50-54% | 1 | 186 | 251 | -186 | 0 | 186 | -186 | -100.0 |
| Opponent | Effective (55-75%) | 18 | 267 | 208 | +76 | 128 | 25 | +103 | +38.5 |
| Opponent | 76-89% | 21 | 270 | 179 | +131 | 179 | 46 | +133 | +49.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 302 | 204 | +159 | 189 | 33 | +156 | +51.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 370 | 65 | +76 | 90 | 10 | +80 | +21.6 |
| Opponent | No odds | 21 | 221 | 205 | +45 | 117 | 53 | +64 | +28.8 |
| Opponent | All fights | 106 | 267 | 186 | +89 | 139 | 44 | +95 | +35.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h-opp-e441028-p2 | move | 552 | 103 (19%) | 63 (11%) | 41 (7%) | 408 (74%) |
| fw-h2h-opp-e441028-p2 | objective | 459 | 58 (13%) | 43 (9%) | 48 (10%) | 353 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

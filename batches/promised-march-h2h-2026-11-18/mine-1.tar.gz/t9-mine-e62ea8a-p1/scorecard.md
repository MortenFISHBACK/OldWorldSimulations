# Doctrine scorecard: t9-mine-e62ea8a-p1

### Scorecard: t9-mine-e62ea8a-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 1 | 4 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 200 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 40 |
| L0135 | 3 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | yes | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 0 | 3 | 0 | 0 | 0 | 307 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 10 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 8 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Opponent | no | 4 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | no | 5 | 2 | 3 | 4 | 0 | 0 | 0 | 139 |
| L0405 | 3 | 1 | Opponent | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 1128 |
| L0421 | 1 | 1 | Mine | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 65 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 6 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 531 |
| L0508 | 4 | 1 | Opponent | no | 5 | 5 | 1 | 1 | 0 | 0 | 0 | 971 |
| L0524 | 2 | 1 | Mine | - | - | 4 | 1 | 0 | 0 | 0 | 0 | 190 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 2 | 6 | 0 | 0 | 1 | 0 | 0 | 488 |
| L0612 | 6 | 1 | Opponent | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 524 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 2 | 3 | 0 | 0 | 0 | 1515 |
| L0628 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 7 | 2 | 4 | 0 | 1 | 0 | 0 | 360 |
| L0717 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 2 | 0 | 0 | 135 |
| L0733 | 1 | 1 | Mine | no | 12 | 1 | 2 | 1 | 1 | 0 | 0 | 125 |
| L0733 | 1 | 1 | Opponent | no | 2 | 5 | 2 | 2 | 0 | 0 | 0 | 108 |
| L0823 | 1 | 1 | Mine | no | 4 | 4 | 2 | 0 | 0 | 0 | 0 | 300 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 70 |
| L0930 | 6 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 530 |
| L0930 | 6 | 1 | Opponent | no | 9 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 14% | 3.9 | 3.2 | 1.3 | 1.4 | 0.2 | 0.0 | 0.0 | 284.4 |
| **Average** | | | Opponent | 7% | 2.2 | 2.8 | 2.2 | 1.6 | 0.4 | 0.0 | 0.0 | 220.7 |

### KPIs: t9-mine-e62ea8a-p1

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 16 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 39% (28 of 71) | 4% (3 of 73) | 22% (31 of 144) |
| Winner chose to follow up after the loser gave ground |  | 77% (10 of 13); on the table 85% | 100% (15 of 15); on the table 100% | 89% (25 of 28); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (5 of 6); on the table 83% | 83% (5 of 6); on the table 100% | 83% (10 of 12); on the table 92% |
| Winner chose to pursue after the loser fled |  | 86% (6 of 7); on the table 86% | 100% (12 of 12); on the table 100% | 95% (18 of 19); on the table 95% |
| Winner chose to follow up or pursue (all three) |  | 81% (21 of 26); on the table 85% | 97% (32 of 33); on the table 100% | 90% (53 of 59); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 40% (67 of 168) | 42% (40 of 96) | 41% (107 of 264) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (67 of 135) | 53% (40 of 76) | 51% (107 of 211) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (4 of 8) | 33% (5 of 15) | 39% (9 of 23) |
| Points that never fought | lower | 43% (13548 of 31492) | 49% (15736 of 31896) | 46% (29284 of 63388) |
|   infantry points that never fought | lower | 41% (3764 of 9158) | 58% (3608 of 6199) | 48% (7372 of 15357) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (66 of 127) | 51% (66 of 129) | 52% (132 of 256) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 1.2 uses a game | 75% (9 of 12); 2.1 uses a game | 84% (16 of 19); 1.6 uses a game |
| Bound items with another spell used |  | 100% (5 of 5); 0.8 uses a game | 0.0 uses a game | 100% (5 of 5); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (6 of 11); 0.4 uses a game | 50% (4 of 8); 0.2 uses a game | 53% (10 of 19); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (10985 of 24691) | 47% (12825 of 27539) | 46% (23810 of 52230) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.7 (43%) | 1.4 (39%) | 4.1 (41%) |
| MARCHED: its unit marched | 1.4 (23%) | 0.4 (11%) | 1.8 (18%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.2 (19%) | 0.7 (20%) | 1.9 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| GONE: slain | 0.5 (8%) | 0.6 (16%) | 1.1 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.0 (0%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (7%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.8 | 1.3 | 1.8 | 6.7 | 0.7 | 2.2 |
| not cast | 3.8 | 2.4 | 3.9 | 9.8 | 1.2 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.5 (21%) | 0.7 (18%) | 4.1 (41%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (18%) | 0.2 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (5%) | 0.6 (16%) | 1.9 (19%) | 0.1 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (10%) | 0.8 (31%) | 0.8 (19%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.9 (25%) | 0.6 (23%) | 0.1 (3%) | 1.1 (11%) | 0.2 (21%) | 1.7 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (5%) | 0.1 (3%) | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (53%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (53%) | 0.4 (15%) | 1.6 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.2 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 0.3 a game | 1.0 a game |
| stood (cast and not dispelled) | 86% (24 of 28) | 60% (3 of 5) | 82% (27 of 33) |
| the unit moved after it | 58% (14 of 24) | 0% (0 of 3) | 52% (14 of 27) |
| it charged on its next turn | 0% (0 of 24) | 0% (0 of 3) | 0% (0 of 27) |
| the enemy charged it first | 12% (3 of 24) | 0% (0 of 3) | 11% (3 of 27) |
| it fought by the end of its next turn | 8% (2 of 24) | 0% (0 of 3) | 7% (2 of 27) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (3 of 24) | 0% (0 of 3) | 11% (3 of 27) |
| none of these (no charge, no fight, no charge escaped) | 75% (18 of 24) | 100% (3 of 3) | 78% (21 of 27) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (272 of 437) | 62% (225 of 361) | 62% (497 of 798) |
|   cavalry | 61% (20 of 33) | 52% (27 of 52) | 55% (47 of 85) |
|   character | 89% (40 of 45) | 63% (38 of 60) | 74% (78 of 105) |
|   chariot | 45% (19 of 42) | 83% (30 of 36) | 63% (49 of 78) |
|   infantry | 53% (63 of 119) | 52% (68 of 131) | 52% (131 of 250) |
|   monster | 72% (13 of 18) | 60% (15 of 25) | 65% (28 of 43) |
|   war machine | 65% (117 of 180) | 82% (47 of 57) | 69% (164 of 237) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (26%) | 1.5 (18%) | 4.2 (22%) |
| CHARGED: it charged | 0.4 (4%) | 1.4 (16%) | 1.8 (10%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.5 (6%) | 1.2 (6%) |
| MOVED: a war machine that moved | 1.2 (12%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET IN RANGE | 2.1 (21%) | 3.0 (35%) | 5.1 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.3 (4%) | 0.8 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (19%) | 1.7 (20%) | 3.6 (19%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |
| OTHER BAR | 0.4 (4%) | 0.1 (1%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.2 | 1.2 | 75% | 6.2 pts | 26 pts |
| character | 5.1 | 3.3 | 60% | 17.0 pts | 86 pts |
| chariot | 3.1 | 2.9 | 58% | 19.1 pts | 60 pts |
| infantry | 12.1 | 4.7 | 74% | 9.9 pts | 119 pts |
| monster | 2.0 | 0.4 | 84% | 4.2 pts | 8 pts |
| war machine | 10.2 | 7.6 | 65% | 18.2 pts | 187 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.8 | 5.3 | 4.1 |
| Charges that made contact a game | 2.2 | 3.2 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.67 declared, 1.33 contact (6 units) | 0.33 declared, 0.33 contact (3 units) | 1.22 declared, 1.00 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.50 contact (2 units) | 1.00 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.31 declared, 0.24 contact (113 units) | 0.65 declared, 0.39 contact (126 units) | 0.49 declared, 0.32 contact (239 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (11 of 23) | 50% (3 of 6) | 50% (1 of 2) | 48% (15 of 31) |
| Character in a unit | 77% (17 of 22) | 62% (13 of 21) | 100% (2 of 2) | 71% (32 of 45) |
| Character on its own | 64% (14 of 22) | 17% (2 of 12) | 13% (2 of 15) | 37% (18 of 49) |
| Chariot | 50% (3 of 6) | 67% (6 of 9) | - | 60% (9 of 15) |
| Infantry | 47% (15 of 32) | 28% (7 of 25) | 0% (0 of 2) | 37% (22 of 59) |
| Monster | 40% (4 of 10) | 75% (3 of 4) | - | 50% (7 of 14) |
| Monstrous | 60% (3 of 5) | 43% (3 of 7) | - | 50% (6 of 12) |
| War Machines | 73% (22 of 30) | 100% (1 of 1) | - | 74% (23 of 31) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 89% (8 of 9); on the table 100% | 42% (58 of 138) | 31% | 45% (15 of 33) | 100% (9 of 9); 4.3 uses a game | 100% (3 of 3); 0.8 uses a game | 67% (6 of 9); 1.0 uses a game |
| Chaos Dwarfs | 3 | 75% (3 of 4); on the table 75% | 42% (10 of 24) | 49% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 77% (10 of 13); on the table 77% | - | 49% | 61% (25 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 80% (4 of 5); on the table 100% | 25% (6 of 24) | 46% | 52% (27 of 52) | 0.0 uses a game | 100% (2 of 2); 1.4 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 1 | 100% (3 of 3); on the table 100% | 56% (10 of 18) | 60% | 33% (3 of 9) | 100% (3 of 3); 10.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | - | 60% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 65% | 50% (7 of 14) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (5 of 5); on the table 100% | 42% (5 of 12) | 27% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 59% | 78% (7 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 34% | 0% (0 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 29% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 39% | 46% (6 of 13) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Wood Elf Realms | 3 | 100% (5 of 5); on the table 100% | 61% (11 of 18) | 64% | 50% (17 of 34) | 50% (2 of 4); 2.7 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t9-mine-e62ea8a-p1, 16 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 37% (11) | 54% (14) | 45% (25) |
| ...free all their last turn and able to turn (per game) | 0.31 | 0.56 | 0.88 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.12 | 0.12 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.12 | 0.44 | 0.56 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.81 | 0.81 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.44 | 0.44 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.31 | 3.88 | 4.19 |

### Quality by phase: t9-mine-e62ea8a-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.4 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 59% (24 of 41) | 47% (30 of 64) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (92 of 211) | 56% (66 of 117) |
| Strategy | Close-in objectives charged next turn | - | 21% (22 of 103) |
| Strategy | Support requests answered (helper made contact too) | 50% (2 of 4) | 50% (4 of 8) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (4 of 6) | 50% (3 of 6) |
| Strategy | Joined characters whose unit fought | 59% (20 of 34) | 68% (17 of 25) |
| Strategy | Lone characters that fought | 73% (30 of 41) | 56% (19 of 34) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.4 | 1.6 |
| Movement | Points that never moved of their own | 284.4 | 220.7 |
| Movement | Fights charged into per game | 2.1 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 31, net +64 | 7 of 35, net +90 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 31, net +0 | 8 of 35, net +138 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 31, net +107 | 3 of 35, net +129 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 31, net +52 | 8 of 35, net +146 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 11.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (93 of 161) | 41% (76 of 186) |
| Shooting | Points destroyed by shooting units | 65.6 | 45.2 |
| Shooting | War machine shots | 7.3 | 2.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (59 of 117) | 51% (24 of 47) |
| Shooting | Points destroyed by war machines | 92.2 | 31.5 |
| Magic | Magic missiles cast | 2.5 | 1.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (12 of 40) | 44% (11 of 25) |
| Magic | Wounds caused by magic missiles | 6.4 | 2.0 |
| Magic | Wounds caused by other spells | 1.2 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 77.6 | 50.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.4 / 1.1 / 0.1 | 1.3 / 0.4 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 290.8 | 320.2 |
| Combat | Points run down | 25.6 | 80.4 |
| Combat | Net points per charged fight, damage counted | +45 | +96 |
| Combat | Net per 100 charger points, damage counted | +16.6 | +35.3 |
| Combat | First round won (charged fights) | 70% | 69% |
| Combat | Net points per charged fight | +49 | +97 |
| Combat | Net points per supported fight / lone fight | +41 / +50 | +218 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 11 of 33 | 28 of 45 |
| Game | Points lost | 752.8 | 608.6 |
| Game | VP from objectives | 645.6 | 843.8 |
| Game | Lone holders (player turns) | 3.9 | 2.2 |

- Mine won / drew / lost: 4 / 5 / 7 of 16 ended games (of 16); mean margin (Mine - Opponent) -363 VP
- The side that went first won 4 of 11 games with a winner
- Points traded per game (both sides' losses): 1361
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t9-mine-e62ea8a-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 5.4 | -110.0 | 103.8 | 52.2 |
| AFTERMATH IN POINTS | 0.2 | +27.3 | 0.0 | 27.8 | - | - | - | - |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 28.4 | 0.8 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.5 | 0.0 | 0.0 | 0.5 | +1.4 | 0.0 | 0.0 |
| BEST FACING | - | - | - | - | 0.4 | +6.8 | 0.0 | 27.1 |
| BEST FIRST | - | - | - | - | 1.2 | +98.8 | 15.9 | 0.0 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.2 | +57.7 | 0.0 | 0.0 |
| BEST OVERALL | - | - | - | - | 0.1 | +7.8 | 0.0 | 0.0 |
| BEST PREY | - | - | - | - | 0.8 | +53.9 | 16.2 | 0.0 |
| BEST PRIZE | 0.2 | -7.1 | 7.9 | 17.6 | 0.3 | -10.4 | 15.4 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.1 | +0.3 | 0.0 | 27.1 |
| BLOCKED WHEEL | - | - | - | - | 0.3 | +5.9 | 0.0 | 6.8 |
| BLOWS WHERE AIMED | 0.1 | -16.2 | 0.0 | 0.0 | 0.4 | -27.8 | 40.1 | 21.2 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 191.1 | 0.0 | 0.1 | +0.0 | 11.6 | 0.0 |
| CANNON PLANNED TARGET | 6.5 | +206.1 | 774.9 | 143.4 | 3.1 | +62.1 | 62.6 | 44.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | +0.0 | 8.1 | 0.0 |
| CAST JOB | 0.2 | +2.2 | 10.3 | 0.0 | 0.4 | +18.0 | 34.7 | 17.1 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +131.4 | 49.8 | 0.0 | 0.3 | +8.5 | 5.3 | 0.0 |
| CASTS AFTER FRIENDS | 1.4 | +0.0 | 0.0 | 44.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.2 | +8.9 | 0.0 | 7.6 | 1.2 | +26.3 | 0.0 | 23.2 |
| CHAFF PASSED | 0.1 | -0.3 | 17.8 | 0.0 | 0.4 | -2.3 | 8.4 | 0.0 |
| CHARACTER GUNS | 0.5 | +0.0 | 0.0 | 18.1 | - | - | - | - |
| CHARGE LOSSES | 5.7 | -303.7 | 0.0 | 166.2 | - | - | - | - |
| CHARGE NOT DECLARED | 0.6 | +0.0 | 72.4 | 17.1 | 1.2 | +0.0 | 64.9 | 50.8 |
| CHARGE NOW FIRST | 0.9 | +0.0 | 92.8 | 18.8 | 2.1 | +0.0 | 128.1 | 61.8 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.4 | -29.2 | 0.0 | 7.3 |
| CHARGER SLAIN LOST | 0.4 | -8.0 | 49.4 | 2.2 | 0.4 | -12.9 | 28.6 | 20.1 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.1 | +0.0 | 0.0 | 5.3 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.3 | -0.4 | 0.0 | 29.4 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 5.3 | 0.1 | +0.0 | 8.1 | 0.0 |
| CHEAPEST HOLDER | 0.5 | -11.2 | 53.8 | 16.8 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 0.0 | 27.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.1 | +113.3 | 0.0 | 0.0 | 0.3 | +27.8 | 0.0 | 0.0 |
| COVER ONCE | 6.2 | -454.0 | 0.0 | 111.6 | 5.9 | -299.8 | 0.0 | 162.3 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.2 | +3.2 | 0.0 | 46.8 | 8.0 | +35.2 | 0.0 | 43.7 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +0.7 | 4.1 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.8 | +57.4 | 0.0 | 27.1 |
| FALL BACK GOOD ORDER | 1.6 | +8.1 | 149.5 | 2.2 | - | - | - | - |
| FALLBACK BY WORTH | 0.4 | +0.0 | 0.0 | 2.8 | 4.4 | +99.6 | 0.0 | 72.2 |
| FALLS SHORT | 5.3 | +105.5 | 0.0 | 35.7 | - | - | - | - |
| FEATURE BUFFS | 2.5 | +83.1 | 0.0 | 52.6 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +30.0 | 49.2 | 32.1 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +1.3 | 0.0 | 6.5 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 4.4 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 44.0 | +2522.0 | 1471.4 | 762.2 | - | - | - | - |
| FLANK NOT WEIGHED | 3.6 | +0.0 | 0.0 | 65.1 | 3.8 | +0.0 | 0.0 | 69.4 |
| FOCUS FIRE | 0.1 | +4.7 | 12.2 | 12.6 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.4 | +48.3 | 0.0 | 0.0 | 0.6 | +97.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.4 | +207.7 | 209.2 | 34.4 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.1 | -7.2 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.4 | -15.6 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +0.7 | 0.0 | 0.0 | 0.2 | +27.4 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -2.0 | 20.9 | 0.0 | 0.1 | -1.8 | 19.5 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.1 | 0.0 | 7.9 |
| GROUND FLIERS | 0.1 | +1.4 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| GUN FIGURES | 0.9 | +2.3 | 34.1 | 35.9 | 1.3 | +22.3 | 5.3 | 0.0 |
| GUN MASK | 0.7 | +7.4 | 0.0 | 11.8 | - | - | - | - |
| HARD STAY DROPPED | 1.2 | +0.0 | 0.0 | 6.6 | - | - | - | - |
| HE SHOOTS OR CHARGES | 2.2 | +0.0 | 0.0 | 37.2 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 4.1 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 8.4 | 0.0 | 0.1 | +0.0 | 20.1 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.6 | -47.3 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +8.9 | 15.3 | 28.4 | - | - | - | - |
| HIS CHARGE LIST | 1.6 | +0.0 | 0.0 | 42.8 | - | - | - | - |
| HIS LEGAL MOVES | 2.2 | +0.0 | 0.0 | 63.1 | - | - | - | - |
| HIS MOVE AND SHOT | 1.3 | -24.6 | 0.0 | 43.8 | - | - | - | - |
| HIS RANDOM MOVE | 1.6 | +0.0 | 0.0 | 33.7 | - | - | - | - |
| HIS SHOT LIST | 17.9 | +691.0 | 0.0 | 256.7 | - | - | - | - |
| HIS TURN DENIED | 0.9 | +40.4 | 70.9 | 0.0 | - | - | - | - |
| HOLDER AT DEPLOYMENT | 1.0 | +187.7 | 0.0 | 0.0 | 1.2 | +202.3 | 0.0 | 7.1 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -87.6 | 146.6 | 32.1 | 10.2 | -174.1 | 482.4 | 207.9 |
| HORN WORTH | - | - | - | - | 0.1 | +5.8 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.1 | +9.2 | 0.0 | 0.0 | 0.3 | +22.6 | 0.0 | 40.7 |
| HUNT RESULT | 0.1 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.1 | +11.5 | 5.9 | 0.0 | - | - | - | - |
| IDLE COST | 3.6 | -41.6 | 0.0 | 34.9 | 15.8 | -242.7 | 0.0 | 194.7 |
| INVITES THE FIGHT | - | - | - | - | 1.4 | +6.2 | 33.1 | 33.4 |
| JOINT CHARGE PLAN | - | - | - | - | 0.2 | +24.9 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -1.0 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.1 | +61.9 | 156.5 | 47.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 1.8 | +43.9 | 140.4 | 27.3 |
| KILLS COUNT NEXT TURN | - | - | - | - | 6.5 | +257.8 | 271.3 | 131.2 |
| LANE BY FIGURES | 0.4 | +22.3 | 0.0 | 0.0 | 0.5 | +33.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.9 | +0.0 | 247.1 | 268.6 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +25.1 | 10.6 | 29.4 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.4 | +0.0 | 27.8 | 0.0 |
| LONE WIZARD KEPT IN | 1.0 | +78.1 | 0.0 | 0.0 | 0.3 | +35.3 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.2 | 7.9 | 0.0 | 0.4 | -0.7 | 6.5 | 6.8 |
| LOST CHARGE | - | - | - | - | 3.4 | -56.9 | 111.2 | 54.8 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -11.0 | 0.0 | 5.1 |
| MAKE SURE TOGETHER | 0.1 | +1.0 | 0.0 | 23.8 | 1.0 | +107.1 | 12.2 | 56.2 |
| MANOEUVRE | 1.0 | +15.0 | 0.0 | 34.6 | 0.5 | +8.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.2 | +1.7 | 0.0 | 9.9 |
| MARCH BY THE SUM | 0.4 | +17.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.9 | +70.1 | 0.0 | 0.0 | 0.3 | +9.5 | 0.0 | 5.1 |
| MARCH ODDS | - | - | - | - | 0.5 | +37.7 | 5.9 | 9.9 |
| MARCH OVER CASTS | 0.4 | -4.6 | 0.0 | 0.0 | 0.3 | +21.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.8 | +98.1 | 0.0 | 65.5 | 5.8 | +59.0 | 0.0 | 163.4 |
| MISSILES IN THE MOVE | 3.9 | +318.5 | 0.0 | 43.9 | 4.2 | +77.5 | 0.0 | 118.2 |
| MISSILES NEXT TURN | 4.2 | +174.6 | 0.0 | 43.9 | 4.9 | +49.8 | 0.0 | 128.1 |
| MODEL FACING | 0.6 | +250.2 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.2 | +6.8 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +8.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.0 | -73.0 | 0.0 | 44.4 | 0.3 | -23.5 | 7.8 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE | - | - | - | - | 4.9 | +331.4 | 167.5 | 136.5 |
| MOVE TO CHARGE COMPUTED | 2.5 | +339.1 | 0.0 | 69.1 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +6.9 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.9 | +314.8 | 0.0 | 166.4 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +3.2 | 4.1 | 0.0 |
| NEXT CHARGE BY LIST | 3.9 | -127.0 | 0.0 | 113.8 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 6.5 | -313.9 | 202.5 | 174.5 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.6 | -39.8 | 92.2 | 20.3 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +1.5 | 0.0 | 7.8 | 0.1 | +17.7 | 0.0 | 0.0 |
| NOT NEEDED | - | - | - | - | 0.5 | -32.8 | 48.0 | 4.4 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 10.4 | 3.9 | +103.0 | 0.0 | 63.6 |
| NOT WORTH A CAST | 0.9 | -1.0 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -27.5 | 0.0 | 5.3 | 17.7 | -980.4 | 4.1 | 170.9 |
| ONE CHARGE A CHARGER | 2.4 | +0.0 | 0.0 | 30.9 | - | - | - | - |
| ONE FIGHT FORMULA | 4.1 | -83.7 | 0.0 | 110.4 | 8.3 | -183.4 | 26.2 | 169.2 |
| ONE OBJECTIVE FORMULA | 3.2 | -8.3 | 0.0 | 107.7 | 2.3 | -107.6 | 0.0 | 30.4 |
| ONE TARGET A SHOOTER | 15.0 | +341.4 | 0.0 | 210.9 | - | - | - | - |
| OPENS A LANE | - | - | - | - | 0.2 | +0.2 | 27.2 | 17.1 |
| OPENS UP | 0.1 | +17.3 | 12.4 | 0.0 | 0.2 | +2.8 | 12.1 | 0.0 |
| OVERRUNS AWAY | 0.5 | +12.0 | 82.0 | 11.8 | 0.7 | +17.3 | 53.6 | 11.6 |
| PATHS CROSS | 2.6 | +82.2 | 0.0 | 40.0 | 2.6 | +198.0 | 0.0 | 45.4 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| PLAN RESULT | 39.2 | +1544.3 | 935.9 | 974.6 | 38.2 | +929.8 | 800.4 | 826.8 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -18.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +3.1 | 0.0 | 10.6 | 0.9 | +10.1 | 0.0 | 40.3 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -10.7 | 11.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +0.2 | 0.0 | 5.3 | 0.6 | -29.3 | 0.0 | 16.1 |
| REDIRECT COUNTER | 1.8 | +137.0 | 0.0 | 32.8 | 2.6 | +85.8 | 0.0 | 39.1 |
| REDIRECT WEIGHED | 0.3 | -7.1 | 7.9 | 17.6 | 0.3 | -5.1 | 8.6 | 7.9 |
| REFORMS TO MEET IT | 0.6 | -9.2 | 0.0 | 8.6 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +2.1 | 0.0 | 0.0 | 0.3 | +3.9 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 14.6 |
| RISK BY ARC | 1.8 | +28.0 | 194.8 | 17.8 | 2.1 | +51.3 | 146.9 | 50.6 |
| RISK BY HIS FIGURE | 11.0 | -220.7 | 0.0 | 307.2 | - | - | - | - |
| RISK ONCE | - | - | - | - | 6.9 | +289.0 | 160.2 | 227.4 |
| RUN DOWN | 1.6 | -16.7 | 102.4 | 15.6 | - | - | - | - |
| SAFER THAN THE JOB | - | - | - | - | 0.4 | +21.8 | 0.0 | 7.9 |
| SAME CHARGE LATER | 0.1 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.3 | +0.4 | 0.0 | 0.0 | 0.4 | +1.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -5.3 | 0.0 | 2.2 | 0.5 | -35.8 | 0.0 | 2.1 |
| SEARCH SPOT | 5.2 | +203.3 | 0.0 | 71.1 | 2.7 | +127.1 | 0.0 | 16.1 |
| SELF MOVE SPELL | - | - | - | - | 0.4 | -0.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.1 | +1.0 | 0.0 | 23.8 | 1.8 | +174.8 | 12.2 | 69.8 |
| SET-UP ANY TARGET | 0.2 | +19.1 | 0.0 | 0.0 | 0.2 | +14.4 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.1 | +8.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.2 | 0.0 | 2.2 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.6 | +1.1 | 0.0 | 0.0 | 0.4 | +0.9 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +76.1 | 10.8 | 47.2 | 1.3 | +18.4 | 64.8 | 0.0 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -6.6 | 15.9 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 11.6 | +128.5 | 0.0 | 188.3 | - | - | - | - |
| SHOTS IN THE MOVE | 16.2 | +697.4 | 0.0 | 399.9 | 11.8 | +347.3 | 0.0 | 133.1 |
| SPELL SETS UP CHARGE | 0.2 | +19.1 | 0.0 | 0.0 | 0.2 | +14.4 | 0.0 | 0.0 |
| SPELL WORTH | 0.6 | +6.6 | 15.9 | 32.8 | 1.9 | +37.7 | 126.6 | 119.8 |
| SPELLS IN THE FIGHT | 0.4 | -2.0 | 41.4 | 0.0 | 0.1 | -1.1 | 20.1 | 11.6 |
| STABLE ROLE | - | - | - | - | 12.5 | +0.0 | 343.6 | 156.3 |
| STAND AND SHOOT | 0.3 | -8.7 | 9.1 | 3.8 | - | - | - | - |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 21.1 | +0.0 | 1234.5 | 349.6 | - | - | - | - |
| STAY WORTH | 22.8 | +18.4 | 881.4 | 436.5 | 16.7 | +124.1 | 127.0 | 148.8 |
| STOPS | 0.1 | +0.2 | 5.9 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.4 | +4.9 | 0.0 | 7.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.6 | +0.0 | 62.5 | 6.0 | 5.8 | -50.8 | 274.5 | 127.6 |
| SUPPORTS | - | - | - | - | 3.9 | +50.9 | 153.8 | 77.4 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -2.7 | 6.5 | 0.0 |
| SURE REACH TOGETHER | 0.2 | +4.0 | 0.0 | 23.8 | 0.7 | -1.5 | 8.1 | 13.5 |
| THE DEARER SUM KEEPS ITS PLAN | 3.6 | +0.0 | 0.0 | 57.8 | - | - | - | - |
| THE PROMISE ADDS | 0.4 | -40.6 | 0.0 | 11.8 | - | - | - | - |
| THE PROMISED MOVE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| TIED UP BY THE SUM | 0.4 | +34.0 | 40.3 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 21.9 | +357.7 | 59.9 | 333.1 | - | - | - | - |
| TURN WORTH | - | - | - | - | 0.1 | -11.4 | 11.8 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.5 | +2.5 | 0.0 | 33.1 |
| WAIT AFTER COSTS | - | - | - | - | 8.8 | -392.1 | 281.6 | 234.4 |
| WAITS AGAIN | 1.4 | +0.0 | 0.0 | 55.3 | - | - | - | - |
| WALKS TO THE FIGHT | - | - | - | - | 1.3 | +7.8 | 20.6 | 18.8 |
| WAR ENGINE CHARGES | 0.1 | +18.6 | 0.0 | 0.0 | 0.1 | +1.1 | 4.1 | 0.0 |
| WAR ENGINE JOBS | 0.2 | +0.0 | 5.9 | 19.4 | 0.8 | +0.0 | 7.0 | 9.1 |
| WEARS DOWN | - | - | - | - | 1.4 | +38.6 | 67.5 | 60.2 |
| WHO HITS BACK | 0.2 | +20.9 | 0.0 | 0.0 | 0.1 | +6.5 | 0.0 | 14.6 |
| WHOLE FIGHT | 0.4 | +6.0 | 64.8 | 2.2 | 0.1 | +13.0 | 16.6 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +1.1 | 14.6 | 0.0 | 0.8 | +66.1 | 49.0 | 20.1 |
| WIDER SPREAD | 1.7 | -6.5 | 167.6 | 22.6 | 2.8 | -4.5 | 198.1 | 56.2 |
| WOUNDS ON THE RANKS | 1.8 | +91.6 | 0.0 | 32.9 | - | - | - | - |

### Rule changes: t9-mine-e62ea8a-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 294 | 294 | 294 | 18.38 | -16127 | -54.9 |
| DEPLOY BY FIGURES | 276 | 276 | 174 | 10.88 | +2451 | +14.1 |
| SEARCH SPOT | 126 | 126 | 116 | 7.25 | +5287 | +45.6 |
| LEGAL CHARGES ONLY | 94 | 94 | 94 | 5.88 | +0 | +0.0 |
| HIS SHOT LIST | 287 | 287 | 90 | 5.62 | +1442 | +16.0 |
| PATHS CROSS | 83 | 83 | 83 | 5.19 | +4483 | +54.0 |
| ONE TARGET A SHOOTER | 240 | 240 | 62 | 3.88 | +530 | +8.5 |
| TIME ON OUR SIDE | 351 | 318 | 60 | 3.75 | +108 | +1.8 |
| FIVE ACTION | 704 | 704 | 50 | 3.12 | +2188 | +43.8 |
| CANNON PLANNED TARGET | 153 | 153 | 38 | 2.38 | -287 | -7.5 |
| COVER ONCE | 194 | 145 | 38 | 2.38 | +509 | +13.4 |
| ARTILLERY RE-ROLL WEIGHED | 37 | 37 | 37 | 2.31 | +0 | +0.0 |
| RISK ONCE | 110 | 96 | 32 | 2.00 | +979 | +30.6 |
| SHOTS IN THE MOVE | 447 | 380 | 32 | 2.00 | +1172 | +36.6 |
| KILLS COUNT NEXT TURN | 104 | 104 | 31 | 1.94 | +1340 | +43.2 |
| CANNON SIGHT KEPT | 30 | 30 | 30 | 1.88 | +0 | +0.0 |
| MOVE TO CHARGE | 78 | 78 | 30 | 1.88 | +1083 | +36.1 |
| WAIT AFTER COSTS | 140 | 140 | 30 | 1.88 | +583 | +19.4 |
| CHARGE NOT DECLARED | 28 | 28 | 28 | 1.75 | -4143 | -148.0 |
| MOVE TO CHARGE COMPUTED | 40 | 40 | 28 | 1.75 | +2009 | +71.8 |
| MAX FOR POSITIONING | 154 | 118 | 27 | 1.69 | +106 | +3.9 |
| STAY WORTH | 631 | 559 | 27 | 1.69 | +399 | +14.8 |
| ADVANCE LANE KEPT | 24 | 24 | 24 | 1.50 | +0 | +0.0 |
| MISSILES IN THE MOVE | 131 | 97 | 24 | 1.50 | +993 | +41.4 |
| SHOT RISK POINTS | 186 | 186 | 23 | 1.44 | +720 | +31.3 |
| SUPPORTS | 63 | 63 | 23 | 1.44 | +204 | +8.9 |
| FALLBACK BY WORTH | 76 | 76 | 22 | 1.38 | +1592 | +72.4 |
| FOUR ROUNDS | 39 | 39 | 22 | 1.38 | +742 | +33.7 |
| LONE WIZARD KEPT IN | 21 | 21 | 21 | 1.31 | +1815 | +86.4 |
| REDIRECT COUNTER | 69 | 44 | 21 | 1.31 | +1333 | +63.5 |
| BEST FIRST | 20 | 20 | 20 | 1.25 | +1581 | +79.0 |
| BEST MOVE FOR SHOOTERS | 20 | 20 | 20 | 1.25 | +924 | +46.2 |
| HARD STAY DROPPED | 20 | 20 | 20 | 1.25 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 42 | 42 | 20 | 1.25 | +253 | +12.6 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 1.06 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 104 | 104 | 17 | 1.06 | +154 | +9.0 |
| HOLDER AT DEPLOYMENT | 35 | 35 | 16 | 1.00 | +568 | +35.5 |
| RISK BY ARC | 62 | 61 | 16 | 1.00 | +583 | +36.4 |
| FALLS SHORT | 85 | 74 | 15 | 0.94 | +132 | +8.8 |
| FOLLOW UP WEIGHED | 15 | 15 | 15 | 0.94 | +2332 | +155.5 |
| MANOEUVRE | 24 | 24 | 15 | 0.94 | +380 | +25.3 |
| MARCH CHECK | 20 | 19 | 15 | 0.94 | +333 | +22.2 |
| SHOOTERS IN TWO RANKS | 15 | 15 | 15 | 0.94 | +33 | +2.2 |
| CASTING BLOCK | 16 | 16 | 14 | 0.88 | +462 | +33.0 |
| HOLDS AMBUSHERS | 14 | 14 | 14 | 0.88 | +0 | +0.0 |
| LANE BY FIGURES | 14 | 14 | 14 | 0.88 | +894 | +63.9 |
| SET UP TOGETHER | 30 | 29 | 14 | 0.88 | +1544 | +110.3 |
| FACES THE THREAT | 13 | 13 | 13 | 0.81 | +918 | +70.6 |
| ONE FIGHT FORMULA | 199 | 125 | 13 | 0.81 | +23 | +1.8 |
| SCOUT WAITS | 13 | 13 | 13 | 0.81 | +0 | +0.0 |
| FEATURE BUFFS | 40 | 40 | 12 | 0.75 | +356 | +29.7 |
| RISK BY HIS FIGURE | 176 | 176 | 12 | 0.75 | +486 | +40.5 |
| ADVANCE WORTH | 87 | 87 | 11 | 0.69 | +274 | +24.9 |
| CHARGE LOSSES | 91 | 91 | 11 | 0.69 | +502 | +45.6 |
| HONEST WORTH | 195 | 195 | 11 | 0.69 | +73 | +6.7 |
| WOUNDS ON THE RANKS | 28 | 28 | 11 | 0.69 | +412 | +37.5 |
| MODEL FACING | 10 | 10 | 10 | 0.62 | +4004 | +400.4 |
| REDIRECT WEIGHED | 10 | 10 | 10 | 0.62 | +479 | +47.9 |
| CHAFF IN THE MOVE | 23 | 21 | 9 | 0.56 | +141 | +15.6 |
| NEXT CHARGE BY LIST | 62 | 62 | 9 | 0.56 | +58 | +6.5 |
| RANDOM MOVE BY FIGURES | 23 | 23 | 9 | 0.56 | +211 | +23.5 |
| BEST PRIZE | 8 | 8 | 8 | 0.50 | -290 | -36.2 |
| CHAFF PASSED | 8 | 8 | 8 | 0.50 | -41 | -5.1 |
| COMBAT PIVOT | 8 | 8 | 8 | 0.50 | +0 | +0.0 |
| IDLE COST | 310 | 180 | 8 | 0.50 | +61 | +7.6 |
| INVITES THE FIGHT | 23 | 23 | 8 | 0.50 | +22 | +2.7 |
| MARCH ODDS | 8 | 8 | 8 | 0.50 | +130 | +16.3 |
| RESERVE FALL BACK | 8 | 8 | 8 | 0.50 | +96 | +12.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.50 | +0 | +0.0 |
| WALKS TO THE FIGHT | 21 | 21 | 8 | 0.50 | +40 | +5.0 |
| BEST FACING | 7 | 7 | 7 | 0.44 | +109 | +15.6 |
| CHARGE NOW WEIGHED | 7 | 7 | 7 | 0.44 | +192 | +27.4 |
| FIRE IN ORDER | 7 | 7 | 7 | 0.44 | +0 | +0.0 |
| SAFER THAN THE JOB | 7 | 7 | 7 | 0.44 | +349 | +49.9 |
| STOPS SHORT OF THE FLANK | 7 | 7 | 7 | 0.44 | +79 | +11.2 |
| BEST PREY | 12 | 12 | 6 | 0.38 | +189 | +31.5 |
| CHARGE NOW FIRST | 48 | 48 | 6 | 0.38 | -354 | -59.0 |
| KEEPS ITS TARGET | 33 | 33 | 6 | 0.38 | +158 | +26.3 |
| MARCH BY THE SUM | 6 | 6 | 6 | 0.38 | +272 | +45.3 |
| NEARER NOT NEEDED | 94 | 93 | 6 | 0.38 | +146 | +24.4 |
| WAR ENGINE JOBS | 15 | 15 | 6 | 0.38 | -444 | -74.0 |
| BLOCKED WHEEL | 5 | 5 | 5 | 0.31 | +94 | +18.9 |
| KILLS COUNT | 29 | 28 | 5 | 0.31 | +119 | +23.7 |
| MAKE SURE TOGETHER | 18 | 12 | 5 | 0.31 | +1114 | +222.8 |
| WHO HITS BACK | 5 | 5 | 5 | 0.31 | +321 | +64.2 |
| WHOLE FIGHT GAIN | 14 | 12 | 5 | 0.31 | +229 | +45.8 |
| CAST JOB | 10 | 10 | 4 | 0.25 | +105 | +26.2 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.25 | +450 | +112.5 |
| HIS TURN DENIED | 15 | 15 | 4 | 0.25 | +171 | +42.7 |
| LOST CHARGE | 54 | 54 | 4 | 0.25 | +54 | +13.6 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.25 | +170 | +42.4 |
| ONE OBJECTIVE FORMULA | 88 | 61 | 4 | 0.25 | +124 | +31.1 |
| OVERRUNS AWAY | 19 | 19 | 4 | 0.25 | +113 | +28.3 |
| REFUSING RETIRES | 8 | 8 | 4 | 0.25 | -1 | -0.2 |
| SURE REACH TOGETHER | 14 | 13 | 4 | 0.25 | +50 | +12.4 |
| TIED UP BY THE SUM | 6 | 6 | 4 | 0.25 | +142 | +35.6 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.19 | +437 | +145.5 |
| FIGHT TO THE END | 11 | 11 | 3 | 0.19 | +222 | +73.9 |
| GUN MASK | 11 | 11 | 3 | 0.19 | +9 | +3.0 |
| MISSILES NEXT TURN | 146 | 102 | 3 | 0.19 | +63 | +21.0 |
| MOVE AND CAST | 3 | 3 | 3 | 0.19 | +109 | +36.4 |
| OPENS UP | 5 | 5 | 3 | 0.19 | +238 | +79.3 |
| STUCK PIVOT | 3 | 3 | 3 | 0.19 | +0 | +0.0 |
| SUPPORT NARROWED | 103 | 103 | 3 | 0.19 | -40 | -13.5 |
| WEARS DOWN | 22 | 21 | 3 | 0.19 | +66 | +21.8 |
| BEST OVERALL | 2 | 2 | 2 | 0.12 | +124 | +62.0 |
| BIG CHARACTER SAFETY | 2 | 2 | 2 | 0.12 | +5 | +2.7 |
| FALL BACK GOOD ORDER | 26 | 26 | 2 | 0.12 | +1 | +0.5 |
| FOCUS FIRE | 2 | 2 | 2 | 0.12 | +75 | +37.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.12 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 7 | 7 | 2 | 0.12 | -161 | -80.4 |
| LONG SHOT | 10 | 9 | 2 | 0.12 | +46 | +23.1 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.12 | +288 | +143.9 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.12 | -292 | -146.2 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.12 | +24 | +12.2 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.12 | +175 | +87.6 |
| WHOLE FIGHT | 8 | 8 | 2 | 0.12 | +47 | +23.5 |
| BACKUP TARGETS | 10 | 5 | 1 | 0.06 | +3 | +2.6 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.06 | +20 | +20.2 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.06 | +32 | +31.8 |
| HIS MOVE AND SHOT | 21 | 21 | 1 | 0.06 | +18 | +17.9 |
| HORN WORTH | 1 | 1 | 1 | 0.06 | +93 | +92.7 |
| HUNT IN PAIRS | 7 | 2 | 1 | 0.06 | +65 | +65.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.06 | +5 | +5.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.06 | +54 | +54.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.06 | -4 | -3.6 |
| SAME CHARGE LATER | 2 | 2 | 1 | 0.06 | +4 | +3.7 |
| SURE CHARGE BEATS ADVANCE | 1 | 1 | 1 | 0.06 | -44 | -43.7 |
| THE PROMISE ADDS | 6 | 6 | 1 | 0.06 | +4 | +3.7 |
| WIDER SPREAD | 71 | 69 | 1 | 0.06 | +3 | +3.1 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 8 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 13 | 13 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 25 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 13 | 12 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 2 | 2 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 8 | 8 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 23 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 118 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 35 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 36 | 36 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 9 | 9 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 35 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 26 | 26 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 3 | 3 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 5 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 12 | 12 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 4 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 25 | 25 | 0 | 0.00 | - | - |
| NOT NEEDED | 8 | 8 | 0 | 0.00 | - | - |
| NOT TURNED | 67 | 67 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 20 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 38 | 38 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | not checked | - | - | - | - |
| PLAN RESULT | 1238 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 12 | 12 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 26 | 26 | 0 | 0.00 | - | - |
| SCOUT SPOT | 11 | 11 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 40 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| STABLE ROLE | 200 | 198 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 337 | 337 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 57 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| TURN WORTH | 2 | 2 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 8 | 6 | 0 | 0.00 | - | - |
| WAITS AGAIN | 22 | 22 | 0 | 0.00 | - | - |

### Off best figure: t9-mine-e62ea8a-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.25 | 16.69 | 56.7 |
| CHARGE NOT DECLARED | rule | 0.50 | 1.00 | 173.2 |
| FALLBACK | gate | - | 0.56 | 23.6 |
| BEST PRIZE | rule | 0.19 | 0.31 | 36.2 |
| CANNON PLANNED TARGET | rule | 0.44 | 0.06 | 41.4 |
| CHAFF PASSED | rule | 0.06 | 0.38 | 5.9 |
| CHARGE NOW FIRST | rule | 0.25 | 0.06 | 70.7 |
| PATHS CROSS | rule | 0.25 | 0.06 | 33.7 |
| WAR ENGINE JOBS | rule | 0.06 | 0.25 | 88.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.25 | - | 96.5 |
| REDIRECT WEIGHED | rule | 0.12 | 0.06 | 34.5 |
| AFTERMATH BAND | gate | 0.12 | - | 3.0 |
| FIGHT ORDER BAND | gate | 0.06 | 0.06 | 1.1 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.12 | 4.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.12 | 80.4 |
| PURSUES BIG PREY | rule | - | 0.12 | 146.2 |
| SUPPORT NARROWED | rule | 0.06 | 0.06 | 20.0 |
| SUPPORT REQUEST | gate | - | 0.12 | 29.9 |
| TURN GATE | gate | - | 0.12 | 42.5 |
| BIG CHARACTER SAFETY | rule | - | 0.06 | 11.1 |
| BLOCKED WHEEL | rule | - | 0.06 | 8.0 |
| CHARGE NOW WEIGHED | rule | - | 0.06 | 33.8 |
| PIVOT GUARDS FLANK | rule | - | 0.06 | 3.6 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 11.1 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.06 | 43.7 |

### Plans: t9-mine-e62ea8a-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 72% | 276 | 226 | 82% |
| Mine | join | 0.4 | 100% | 6 | 0 | 0% |
| Mine | move | 25.2 | 92% | 1543 | 0 | 0% |
| Mine | shoot | 11.3 | 63% | 660 | 1319 | 200% |
| Mine | support | 0.2 | 50% | 3 | 0 | 0% |
| Opponent | advance | 11.6 | 15% | 169 | 231 | 137% |
| Opponent | charge | 3.2 | 69% | 300 | 263 | 88% |
| Opponent | close in | 6.4 | 29% | 431 | 158 | 37% |
| Opponent | hold | 6.4 | 59% | 533 | 0 | 0% |
| Opponent | join | 0.1 | 100% | 7 | 0 | 0% |
| Opponent | shoot | 5.2 | 73% | 168 | 288 | 172% |
| Opponent | support | 5.1 | 88% | 27 | 0 | 0% |

### Packages: hunt the guns, t9-mine-e62ea8a-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 184 | 95 | 0% | 22 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 92 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 184 | 95 | 0% | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 69 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 316 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 140 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 60 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 390 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: t9-mine-e62ea8a-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 36% | 60% | 0% | - | 20% | 0% | 0% | 60% | 20% |
| Opponent | REDIRECT COUNTER | 2.6 | 24% | 80% | 30% | 0% | 14% | 0% | 0% | 86% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t9-mine-e62ea8a-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 10 | 78 (10) | 36 | 42 | 71 | 50% | 2.6 | 201 (2) | 0 (4) | 47 (4) | 88 (9) | 0 (1) |
| Mine | Character | 67 | 43 (67) | 43 | 0 | 39 | 15% | 2.6 | 58 (17) | 25 (27) | 57 (13) | 60 (32) | 26 (25) |
| Mine | Clean-up | 5 | 23 (5) | 0 | 23 | 21 | 60% | 3.5 | 0 (1) | 43 (3) | 0 (1) | 29 (4) | 0 (1) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 47 | 0% | 1.7 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Mine | Fast Hammer | 18 | 61 (18) | 36 | 25 | 74 | 50% | 3.6 | 45 (14) | 180 (2) | 20 (2) | 55 (13) | 72 (5) |
| Mine | Hammer | 34 | 32 (34) | 14 | 17 | 30 | 21% | 2.9 | 36 (11) | 33 (20) | 4 (3) | 30 (23) | 35 (11) |
| Mine | Holder | 12 | 88 (12) | 0 | 88 | 26 | 50% | 4.8 | 78 (5) | 94 (7) | - | 144 (6) | 26 (6) |
| Mine | Shooter | 23 | 103 (23) | 33 | 70 | 56 | 0% | 2.0 | 77 (6) | 99 (13) | 155 (4) | 118 (16) | 74 (7) |
| Mine | War machine | 39 | 33 (39) | 33 | 0 | 51 | 8% | 1.5 | 26 (19) | 45 (17) | 19 (3) | 0 (3) | 37 (36) |
| Mine | Wizard | 8 | 23 (8) | 23 | 0 | 21 | 25% | 3.2 | 14 (4) | 0 (1) | 0 (1) | 0 (1) | 11 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 30 | 163 (30) | 26 | 136 | 49 | 37% | 2.8 | 135 (8) | 247 (12) | 86 (10) | 141 (26) | 366 (4) |
| Opponent | Character | 51 | 54 (51) | 52 | 2 | 21 | 16% | 2.8 | 36 (14) | 59 (26) | 63 (7) | 41 (31) | 80 (16) |
| Opponent | Clean-up | 6 | 20 (6) | 20 | 0 | 64 | 50% | 2.0 | 0 (1) | 30 (4) | 0 (1) | 20 (6) | - |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 19 | 48 (19) | 38 | 9 | 55 | 21% | 3.3 | 29 (5) | 57 (11) | 31 (3) | 65 (10) | 24 (9) |
| Opponent | Fragile | 4 | 0 (4) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 35 | 50 (35) | 34 | 16 | 30 | 20% | 2.6 | 49 (7) | 48 (18) | 56 (10) | 43 (22) | 63 (13) |
| Opponent | Holder | 14 | 101 (14) | 9 | 92 | 2 | 50% | 3.6 | 90 (2) | 160 (8) | 0 (4) | 98 (9) | 107 (5) |
| Opponent | Shooter | 17 | 79 (17) | 10 | 69 | 54 | 24% | 1.8 | 43 (6) | 113 (9) | 17 (2) | 86 (10) | 68 (7) |
| Opponent | War machine | 11 | 26 (11) | 26 | 0 | 39 | 0% | 1.0 | 20 (7) | 36 (4) | - | 48 (1) | 24 (10) |
| Opponent | Wizard | 8 | 4 (8) | 4 | 0 | 25 | 0% | 2.6 | 23 (1) | 0 (4) | - | 6 (5) | - |

### Charged fights: t9-mine-e62ea8a-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 212 | 114 | 1.0 | 1.0 | 114 | 51 | +63 | 0 of 5 | 4 of 5 | - | +63 |
| Mine | Chaos Dwarfs | 3 | 55 | 393 | 4.0 | 1.1 | 98 | 0 | +98 | 6 of 12 | 10 of 12 | +210 | +88 |
| Mine | Dwarfen Mountain Holds | 4 | 418 | 25 | 1.5 | 1.2 | 17 | 110 | -94 | 1 of 6 | 4 of 6 | -128 | -87 |
| Mine | Empire of Man | 4 | 217 | 310 | 2.5 | 1.0 | 124 | 55 | +69 | 4 of 10 | 5 of 10 | - | +69 |
| **Mine** | all armies | 16 | 235 | 193 | 2.1 | 1.1 | 94 | 44 | +49 | 11 of 33 | 23 of 33 | +41 | +50 |
| Opponent | Beastmen Brayherds | 1 | 0 | 55 | 5.0 | 1.0 | 11 | 46 | -35 | 3 of 5 | 3 of 5 | - | -35 |
| Opponent | Dwarfen Mountain Holds | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 298 | 118 | 1.0 | 1.0 | 118 | 85 | +33 | 1 of 1 | 1 of 1 | - | +33 |
| Opponent | Grand Cathay | 1 | 411 | 280 | 3.0 | 1.3 | 93 | 72 | +21 | 3 of 3 | 2 of 3 | +95 | -16 |
| Opponent | Lizardmen | 1 | 77 | 613 | 4.0 | 1.0 | 153 | 0 | +153 | 2 of 4 | 4 of 4 | - | +153 |
| Opponent | Ogre Kingdoms | 2 | 111 | 210 | 3.5 | 1.0 | 60 | 58 | +2 | 3 of 7 | 3 of 7 | - | +2 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 635 | 4.0 | 1.2 | 159 | 28 | +131 | 2 of 4 | 4 of 4 | +95 | +143 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 380 | 520 | 7.0 | 1.1 | 74 | 0 | +74 | 5 of 7 | 5 of 7 | +0 | +87 |
| Opponent | Vampire Counts | 1 | 0 | 182 | 4.0 | 1.5 | 46 | 98 | -53 | 2 of 4 | 2 of 4 | +0 | -70 |
| Opponent | Warriors of Chaos | 2 | 0 | 1019 | 2.5 | 1.0 | 408 | 0 | +408 | 4 of 5 | 4 of 5 | - | +408 |
| Opponent | Wood Elf Realms | 3 | 192 | 397 | 1.7 | 1.2 | 238 | 47 | +191 | 3 of 5 | 3 of 5 | +902 | +13 |
| **Opponent** | all armies | 16 | 127 | 378 | 2.8 | 1.1 | 134 | 37 | +97 | 28 of 45 | 31 of 45 | +218 | +82 |

### Effective charges: t9-mine-e62ea8a-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net -21) | 0 | 0 | 0 | 0 | 3 (net +83) | 1 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 12 | 2 (net +106) | 1 (net +210) | 2 (net +0) | 4 (net +153) | 1 (net +145) | 2 (net +0) | 0 | 17% (2 of 12) |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 0 | 2 (net -267) | 3 (net -29) | 0 | 1 (net +60) | 0 | 33% (2 of 6) |
| Mine | Empire of Man | 10 | 0 | 1 (net +0) | 5 (net +107) | 1 (net +258) | 2 (net +88) | 0 | 1 | 56% (5 of 9) |
| Opponent | Beastmen Brayherds | 5 | 1 (net -137) | 0 | 1 (net -95) | 3 (net +18) | 0 | 0 | 0 | 20% (1 of 5) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 1 (net +33) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 3 | 1 (net -32) | 0 | 0 | 0 | 1 (net +95) | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Lizardmen | 4 | 0 | 0 | 1 (net +125) | 1 (net +110) | 0 | 1 (net +189) | 1 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 7 | 0 | 0 | 3 (net +18) | 1 (net +65) | 0 | 0 | 3 | 75% (3 of 4) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 1 (net +230) | 0 | 0 | 3 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 7 | 2 (net +42) | 0 | 0 | 1 (net +125) | 0 | 3 (net +88) | 1 | 0% (0 of 6) |
| Opponent | Vampire Counts | 4 | 0 | 0 | 2 (net +58) | 1 (net -393) | 1 (net +65) | 0 | 0 | 50% (2 of 4) |
| Opponent | Warriors of Chaos | 5 | 1 (net +949) | 0 | 0 | 0 | 1 (net +227) | 2 (net +356) | 1 | 0% (0 of 4) |
| Opponent | Wood Elf Realms | 5 | 2 (net -118) | 0 | 1 (net +902) | 0 | 0 | 1 (net +0) | 1 | 25% (1 of 4) |

### Charged fights, damage counted: t9-mine-e62ea8a-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 226 | 189 | +64 | 149 | 90 | +59 | +26.0 |
| Mine | 50-54% | 2 | 264 | 182 | +105 | 105 | 0 | +105 | +39.8 |
| Mine | Effective (55-75%) | 9 | 259 | 235 | +0 | 131 | 127 | +4 | +1.4 |
| Mine | 76-89% | 8 | 291 | 135 | +98 | 125 | 31 | +94 | +32.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 122 | 118 | +52 | 57 | 3 | +54 | +44.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 413 | 107 | +107 | 107 | 0 | +107 | +25.9 |
| Mine | No odds | 2 | 508 | 135 | -98 | 80 | 252 | -172 | -33.9 |
| Mine | All fights | 33 | 268 | 165 | +49 | 111 | 66 | +45 | +16.6 |
| Opponent | Long shot (under 50%) | 7 | 230 | 254 | +90 | 179 | 92 | +87 | +37.8 |
| Opponent | Effective (55-75%) | 8 | 291 | 289 | +138 | 217 | 76 | +142 | +48.7 |
| Opponent | 76-89% | 9 | 226 | 162 | +25 | 83 | 57 | +27 | +11.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 355 | 235 | +146 | 173 | 9 | +164 | +46.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 529 | 158 | +129 | 129 | 18 | +111 | +21.0 |
| Opponent | No odds | 10 | 187 | 230 | +86 | 122 | 52 | +71 | +37.9 |
| Opponent | All fights | 45 | 273 | 227 | +97 | 150 | 53 | +96 | +35.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t9-mine-e62ea8a-p1 | move | 136 | 40 (29%) | 21 (15%) | 15 (11%) | 81 (60%) |
| t9-mine-e62ea8a-p1 | objective | 103 | 22 (21%) | 10 (10%) | 13 (13%) | 68 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Opponent | L0524 |
| Periapt of Soul Exchange | Opponent | L0421 |
| Ring of Doom | Mine | L0218, L0235 |
| Ring of Doom | Opponent | L0102, L0612, L0733 |
| Ring of Jet | Opponent | L0612 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

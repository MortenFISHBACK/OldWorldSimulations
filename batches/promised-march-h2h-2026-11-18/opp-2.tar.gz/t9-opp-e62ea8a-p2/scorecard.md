# Doctrine scorecard: t9-opp-e62ea8a-p2

### Scorecard: t9-opp-e62ea8a-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 180 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 115 |
| L0222 | 6 | 1 | Mine | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | yes | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 650 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 4 | 1 | 3 | 1 | 0 | 0 | 125 |
| L0323 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 760 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 9 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 2 | - | 1 | 0 | 0 | 0 | 0 | 265 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 2 | 2 | 1 | 0 | 0 | 85 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 475 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 714 |
| L0528 | 6 | 1 | Opponent | no | 8 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 6 | 0 | 3 | 0 | 0 | 0 | 675 |
| L0616 | 4 | 1 | Opponent | no | 0 | 5 | 2 | 2 | 1 | 0 | 0 | 100 |
| L0632 | 2 | 1 | Mine | - | - | 1 | 2 | 1 | 0 | 0 | 0 | 893 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 0 | 5 | 1 | 0 | 0 | 170 |
| **Average** | | | Mine | 38% | 1.8 | 3.0 | 2.2 | 2.1 | 0.0 | 0.0 | 0.0 | 379.5 |
| **Average** | | | Opponent | 38% | 2.2 | 3.3 | 2.0 | 1.6 | 0.4 | 0.0 | 0.0 | 114.2 |

### KPIs: t9-opp-e62ea8a-p2

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 35% (20 of 57) | 18% (11 of 62) | 26% (31 of 119) |
| Winner chose to follow up after the loser gave ground |  | 90% (18 of 20); on the table 90% | 67% (4 of 6); on the table 67% | 85% (22 of 26); on the table 85% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 75% (3 of 4); on the table 75% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fled |  | 57% (4 of 7); on the table 57% | 80% (4 of 5); on the table 80% | 67% (8 of 12); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 79% (22 of 28); on the table 79% | 73% (11 of 15); on the table 73% | 77% (33 of 43); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 24% (33 of 138) | 29% (14 of 48) | 25% (47 of 186) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 27% (33 of 123) | 41% (14 of 34) | 30% (47 of 157) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (6 of 9) | 36% (4 of 11) | 50% (10 of 20) |
| Points that never fought | lower | 50% (11801 of 23594) | 50% (12099 of 23996) | 50% (23900 of 47590) |
|   infantry points that never fought | lower | 54% (3973 of 7332) | 69% (3438 of 4956) | 60% (7411 of 12288) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (52 of 88) | 60% (56 of 93) | 60% (108 of 181) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.4 uses a game | 100% (3 of 3); 0.4 uses a game | 89% (8 of 9); 0.9 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.5 uses a game | 100% (1 of 1); 0.1 uses a game | 100% (3 of 3); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (4 of 8); 0.3 uses a game | 33% (1 of 3); 0.1 uses a game | 45% (5 of 11); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (9335 of 17752) | 53% (10535 of 19887) | 53% (19870 of 37639) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.2 (71%) | 0.4 (15%) | 6.7 (58%) |
| MARCHED: its unit marched | 0.6 (7%) | 0.8 (29%) | 1.4 (12%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (9%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.8 (10%) | 0.3 (12%) | 1.2 (10%) |
| REAR RANK: in a rear rank | 0.5 (6%) | 0.0 (0%) | 0.5 (4%) |
| GONE: slain | 0.3 (4%) | 0.6 (21%) | 0.9 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.2 (9%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.1 (3%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 0.8 | 0.8 | 3.9 | 0.5 | 1.4 |
| not cast | 2.8 | 2.2 | 4.2 | 11.6 | 1.0 | 13.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (62%) | 0.7 (16%) | 6.7 (58%) | 0.2 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (12%) | 0.3 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.0 (0%) | 0.5 (12%) | 1.2 (10%) | 0.2 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.5 (12%) | 0.5 (4%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.8 (29%) | 0.0 (0%) | 0.4 (10%) | 0.9 (8%) | 0.2 (25%) | 2.2 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.2 (12%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (9%) | 0.2 (12%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (56%) | 0.3 (15%) | 2.2 (51%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.4 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.2 a game | 0.6 a game |
| stood (cast and not dispelled) | 54% (7 of 13) | 50% (1 of 2) | 53% (8 of 15) |
| the unit moved after it | 57% (4 of 7) | 100% (1 of 1) | 62% (5 of 8) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| the enemy charged it first | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| it fought by the end of its next turn | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| none of these (no charge, no fight, no charge escaped) | 86% (6 of 7) | 100% (1 of 1) | 88% (7 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (264 of 346) | 57% (231 of 404) | 66% (495 of 750) |
|   cavalry | 39% (7 of 18) | 67% (39 of 58) | 61% (46 of 76) |
|   character | 84% (49 of 58) | 25% (10 of 40) | 60% (59 of 98) |
|   chariot | 61% (25 of 41) | 56% (9 of 16) | 60% (34 of 57) |
|   infantry | 70% (53 of 76) | 49% (76 of 154) | 56% (129 of 230) |
|   monster | 70% (7 of 10) | 62% (8 of 13) | 65% (15 of 23) |
|   war machine | 86% (123 of 143) | 72% (89 of 123) | 80% (212 of 266) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (29%) | 3.5 (24%) | 5.5 (26%) |
| CHARGED: it charged | 1.2 (17%) | 2.3 (16%) | 3.5 (16%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (7%) | 0.3 (2%) | 0.8 (4%) |
| MOVED: a war machine that moved | 0.2 (2%) | 0.7 (5%) | 0.8 (4%) |
| NO TARGET IN RANGE | 0.4 (6%) | 3.3 (23%) | 3.8 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.8 (5%) | 0.8 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (32%) | 2.2 (16%) | 4.4 (21%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.2 (2%) | 1.1 (8%) | 1.2 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.9 | 72% | 3.3 pts | 18 pts |
| character | 5.2 | 1.7 | 79% | 9.4 pts | 49 pts |
| chariot | 2.8 | 3.9 | 38% | 31.7 pts | 90 pts |
| infantry | 17.2 | 5.8 | 75% | 6.9 pts | 118 pts |
| monster | 1.5 | 0.4 | 78% | 6.5 pts | 10 pts |
| war machine | 17.7 | 11.5 | 66% | 18.8 pts | 332 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.1 | 4.6 | 3.8 |
| Charges that made contact a game | 2.5 | 2.9 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (6 units) | 1.50 declared, 0.75 contact (4 units) | 0.90 declared, 0.60 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 1.00 contact (2 units) | 1.50 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.34 contact (79 units) | 0.49 declared, 0.32 contact (93 units) | 0.47 declared, 0.33 contact (172 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (6 of 11) | 67% (2 of 3) | 50% (1 of 2) | 56% (9 of 16) |
| Character in a unit | 85% (17 of 20) | 56% (5 of 9) | 100% (1 of 1) | 77% (23 of 30) |
| Character on its own | 83% (5 of 6) | 36% (4 of 11) | 14% (2 of 14) | 35% (11 of 31) |
| Chariot | - | 56% (5 of 9) | - | 56% (5 of 9) |
| Infantry | 61% (17 of 28) | 58% (11 of 19) | - | 60% (28 of 47) |
| Monster | 57% (8 of 14) | - | - | 57% (8 of 14) |
| Monstrous | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| War Machines | 73% (22 of 30) | 50% (1 of 2) | - | 72% (23 of 32) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (6 of 6); on the table 100% | 21% (21 of 102) | 48% | 45% (10 of 22) | 83% (5 of 6); 4.2 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 80% (12 of 15); on the table 80% | 33% (12 of 36) | 44% | 47% (15 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 67% (6 of 9); on the table 67% | - | 66% | 76% (41 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | 33% (1 of 3); on the table 33% | 56% (10 of 18) | 42% | 73% (16 of 22) | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game | 0% (0 of 1); 0.0 uses a game |
| Grand Cathay | 1 | - | 6% (1 of 18) | 35% | 44% (4 of 9) | 100% (3 of 3); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 43% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 100% (3 of 3); on the table 100% | - | 36% | 40% (6 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 65% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 67% (4 of 6); on the table 67% | 33% (2 of 6) | 54% | 47% (7 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t9-opp-e62ea8a-p2, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 61% (11) | 46% (6) | 55% (17) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.33 | 0.92 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.00 | 0.17 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.25 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.92 | 0.00 | 0.92 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.50 | 0.00 | 0.50 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.25 | 0.33 | 6.58 |

### Quality by phase: t9-opp-e62ea8a-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 72% (26 of 36) | 56% (28 of 50) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (95 of 210) | 52% (85 of 165) |
| Strategy | Close-in objectives charged next turn | 10% (3 of 30) | - |
| Strategy | Support requests answered (helper made contact too) | 50% (2 of 4) | 38% (3 of 8) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 46% (17 of 37) | 0% (0 of 14) |
| Strategy | Lone characters that fought | 53% (9 of 17) | 81% (25 of 31) |
| Movement | Charges halted short of contact | 0.0 | 0.6 |
| Movement | Idle units | 2.1 | 1.6 |
| Movement | Points that never moved of their own | 379.5 | 114.2 |
| Movement | Fights charged into per game | 2.2 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 26, net +138 | 10 of 30, net +19 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 26, net -310 | 6 of 30, net +128 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 26, net +0 | 2 of 30, net +206 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 of 26, net +124 | 5 of 30, net -80 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.2 | 13.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (74 of 147) | 24% (40 of 165) |
| Shooting | Points destroyed by shooting units | 101.6 | 34.9 |
| Shooting | War machine shots | 10.2 | 7.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (73 of 123) | 63% (56 of 89) |
| Shooting | Points destroyed by war machines | 110.5 | 76.0 |
| Magic | Magic missiles cast | 1.1 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 23% (3 of 13) | 25% (2 of 8) |
| Magic | Wounds caused by magic missiles | 2.8 | 1.8 |
| Magic | Wounds caused by other spells | 0.8 | 0.1 |
| Magic | Points destroyed by magic (all spells) | 59.5 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.4 / 0.2 / 0.7 / 0.2 | 2.3 / 0.2 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 283.5 | 297.2 |
| Combat | Points run down | 58.2 | 30.7 |
| Combat | Net points per charged fight, damage counted | +95 | +31 |
| Combat | Net per 100 charger points, damage counted | +44.6 | +10.2 |
| Combat | First round won (charged fights) | 67% | 58% |
| Combat | Net points per charged fight | +62 | +52 |
| Combat | Net points per supported fight / lone fight | +56 / +63 | +316 / +23 |
| Combat | Charged fights on a top-3 enemy unit | 12 of 27 | 15 of 31 |
| Game | Points lost | 524.8 | 640.0 |
| Game | VP from objectives | 457.5 | 769.2 |
| Game | Lone holders (player turns) | 1.8 | 2.2 |

- Mine won / drew / lost: 3 / 2 / 7 of 12 ended games (of 12); mean margin (Mine - Opponent) -121 VP
- The side that went first won 7 of 10 games with a winner
- Points traded per game (both sides' losses): 1165
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t9-opp-e62ea8a-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.3 | -128.8 | 22.2 | 105.7 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.1 | +11.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 12.8 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.2 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.4 | 0.0 | 17.1 | 0.2 | +0.7 | 0.0 | 0.0 |
| BEST FACING | 0.2 | +4.3 | 0.0 | 7.9 | - | - | - | - |
| BEST FIRST | 1.0 | +29.9 | 6.4 | 0.0 | - | - | - | - |
| BEST MOVE FOR SHOOTERS | 0.8 | +31.5 | 0.0 | 31.2 | - | - | - | - |
| BEST OVERALL | 0.2 | +13.3 | 0.0 | 0.0 | - | - | - | - |
| BEST PREY | 1.2 | +55.4 | 6.0 | 24.9 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.1 | -2.9 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.1 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | -23.7 | 39.9 | 4.3 | 0.2 | -98.2 | 0.0 | 0.0 |
| BOMBING RUN | 0.1 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.2 | +0.0 | 71.7 | 0.0 | 0.9 | +0.0 | 93.3 | 18.8 |
| CANNON PLANNED TARGET | 9.9 | +309.2 | 1126.8 | 103.8 | 7.0 | +168.7 | 126.2 | 8.3 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 5.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 19.4 | 0.0 |
| CAST JOB | 0.6 | +18.4 | 33.2 | 7.1 | 0.2 | +3.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.6 | +60.0 | 78.4 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 18.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.8 | +30.6 | 0.0 | 14.2 | 0.1 | +2.6 | 0.0 | 3.4 |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 0.5 | +0.0 | 0.0 | 21.6 |
| CHARGE LOSSES | - | - | - | - | 5.2 | -371.1 | 0.0 | 259.5 |
| CHARGE NOT DECLARED | 0.6 | +0.0 | 40.1 | 18.7 | 0.3 | +0.0 | 60.4 | 31.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 166.7 | 13.7 | 2.1 | +0.0 | 157.9 | 155.9 |
| CHARGE NOW WEIGHED | 0.1 | -5.8 | 0.0 | 0.0 | - | - | - | - |
| CHARGER SLAIN LOST | 0.7 | -18.7 | 12.8 | 9.3 | 0.2 | -2.6 | 32.9 | 10.2 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 5.0 | - | - | - | - |
| CHEAPEST HOLDER | - | - | - | - | 1.0 | -85.8 | 49.2 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.5 | +0.0 | 0.0 | 111.8 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.2 | +0.0 | 17.1 | 0.0 |
| CONVEYANCE SEARCH | 1.1 | +178.4 | 26.6 | 18.3 | 0.1 | +0.1 | 0.0 | 17.6 |
| COVER ONCE | 7.7 | -692.8 | 0.0 | 77.9 | 6.5 | -339.0 | 0.0 | 43.2 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 40.8 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.3 | +50.4 | 0.0 | 26.7 | 8.0 | +16.4 | 0.0 | 5.0 |
| EDGE GIVE GROUND | 0.1 | +1.3 | 11.4 | 0.0 | 0.2 | +26.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.9 | +38.8 | 0.0 | 15.0 | - | - | - | - |
| FALL BACK GOOD ORDER | - | - | - | - | 3.0 | +6.2 | 202.6 | 162.3 |
| FALLBACK BY WORTH | 3.8 | +42.6 | 0.0 | 17.9 | 0.3 | +13.1 | 0.0 | 3.4 |
| FALLS SHORT | - | - | - | - | 15.8 | +197.3 | 0.0 | 256.8 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +22.0 | 0.0 | 23.4 |
| FIGHT LIFT | 0.2 | +6.8 | 78.5 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.9 | +64.9 | 149.1 | 97.1 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 10.4 | 0.0 |
| FIVE ACTION | - | - | - | - | 53.2 | +2957.6 | 777.1 | 713.2 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 77.3 | 3.8 | +0.0 | 0.0 | 173.8 |
| FOCUS FIRE | 0.1 | +1.9 | 7.1 | 0.0 | 0.2 | +1.2 | 5.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +112.5 | 0.0 | 0.0 | 0.3 | +150.6 | 0.0 | 21.6 |
| FOUR ROUNDS | - | - | - | - | 4.0 | +363.3 | 313.9 | 166.1 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.2 | -6.2 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.2 | -0.2 | 0.0 | 5.8 |
| FRIENDS SHOTS CHECKED | 0.2 | +12.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -7.3 | 66.2 | 0.0 |
| GROUND FLIERS | 0.1 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.8 | +7.1 | 76.6 | 129.2 | 0.3 | +0.0 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 0.7 | +10.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | - | - | - | - | 2.0 | +0.0 | 0.0 | 50.8 |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 26.5 | 0.0 |
| HILL BY ITS CHANCE | 0.5 | -32.5 | 0.0 | 10.8 | - | - | - | - |
| HIS CHARGE DENIED | - | - | - | - | 0.2 | +9.8 | 21.2 | 0.0 |
| HIS CHARGE LIST | - | - | - | - | 2.8 | +0.0 | 0.0 | 28.7 |
| HIS LEGAL MOVES | - | - | - | - | 3.2 | +0.0 | 0.0 | 53.2 |
| HIS MOVE AND SHOT | - | - | - | - | 1.3 | -30.8 | 0.0 | 33.2 |
| HIS RANDOM MOVE | - | - | - | - | 2.3 | +0.0 | 0.0 | 14.8 |
| HIS SHOT LIST | - | - | - | - | 24.3 | +1323.9 | 0.0 | 416.6 |
| HIS TURN DENIED | - | - | - | - | 2.3 | +122.1 | 140.6 | 139.7 |
| HOLDER AT DEPLOYMENT | 0.6 | +86.1 | 0.0 | 0.0 | 0.7 | +108.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.8 | -93.9 | 290.2 | 79.9 | 3.5 | -202.5 | 253.7 | 149.8 |
| HUNT ADVANCE | 0.7 | +1.8 | 0.0 | 4.3 | - | - | - | - |
| HUNT DROPPED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.2 | +4.5 | 0.0 | 0.0 | 0.7 | +60.9 | 0.0 | 16.2 |
| HUNT KEPT | 0.5 | +1.0 | 0.0 | 8.7 | - | - | - | - |
| HUNT RESULT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.2 | +39.9 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 14.5 | -225.9 | 0.0 | 107.4 | 9.7 | -144.9 | 0.0 | 193.8 |
| INVITES THE FIGHT | 0.8 | +5.1 | 0.0 | 40.0 | - | - | - | - |
| JOINT CHARGE PLAN | 0.2 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -7.9 | 0.0 | 10.2 |
| KEEP FALLS | 0.1 | +1.3 | 0.0 | 18.2 | - | - | - | - |
| KEEPS ITS PREY | 0.2 | +0.4 | 15.8 | 14.2 | - | - | - | - |
| KEEPS ITS TARGET | 1.1 | +32.5 | 43.2 | 4.3 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.2 | +62.1 | 131.2 | 5.0 | - | - | - | - |
| KILLS COUNT NEXT TURN | 4.5 | +83.2 | 85.6 | 108.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +20.0 | 0.0 | 0.0 | 0.8 | +39.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 4.5 | +0.0 | 272.6 | 225.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +0.5 | 0.0 | 0.0 | 0.1 | +4.5 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.8 | +66.3 | 0.0 | 0.0 | 0.7 | +48.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +9.0 | 5.5 | 4.6 | 0.1 | -0.6 | 0.0 | 0.0 |
| LOST CHARGE | 2.1 | -24.2 | 48.1 | 89.3 | 0.1 | -0.7 | 25.8 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -5.7 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +3.2 | 0.0 | 7.1 | 0.3 | +10.6 | 0.0 | 0.0 |
| MANOEUVRE | 0.2 | +17.1 | 0.0 | 0.0 | 1.2 | +14.8 | 0.0 | 21.6 |
| MARCH BY THE SUM | - | - | - | - | 0.2 | +13.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.2 | +8.5 | 0.0 | 13.5 | 1.0 | +41.5 | 0.0 | 21.6 |
| MARCH ODDS | 0.2 | +4.6 | 35.9 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.2 | +2.5 | 0.0 | 0.0 | 0.4 | +30.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.6 | +63.7 | 0.0 | 71.5 | 6.1 | +66.5 | 0.0 | 83.4 |
| MISSILES IN THE MOVE | 3.7 | +126.8 | 0.0 | 41.2 | 1.7 | +18.3 | 0.0 | 44.4 |
| MISSILES NEXT TURN | 4.2 | +96.8 | 0.0 | 41.2 | 2.6 | +22.6 | 0.0 | 44.4 |
| MODEL FACING | 0.3 | +48.8 | 0.0 | 0.0 | 0.6 | +135.7 | 0.0 | 10.0 |
| MOVE AND CAST | 0.2 | +2.9 | 0.0 | 6.8 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.6 | +22.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.1 | -34.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 6.4 | - | - | - | - |
| MOVE TO CHARGE | 1.7 | +81.2 | 55.7 | 32.9 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 4.6 | +385.6 | 0.0 | 63.3 |
| MOVES UNITS SPELL | 0.2 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | - | - | - | - | 6.0 | +391.3 | 0.0 | 15.8 |
| NEEDED THERE | 0.1 | +7.4 | 21.6 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | - | - | - | - | 6.2 | -246.4 | 19.2 | 144.8 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 11.6 | -805.0 | 159.3 | 139.4 |
| NO DOUBLE ROUNDS | - | - | - | - | 2.8 | -85.3 | 212.4 | 131.8 |
| NO RALLY LEFT | - | - | - | - | 0.1 | +4.0 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -8.8 | 22.3 | 0.0 | - | - | - | - |
| NOT TURNED | 6.2 | +118.9 | 0.0 | 104.5 | 0.3 | +0.4 | 0.0 | 10.5 |
| NOT WORTH A CAST | 0.1 | -0.1 | 0.0 | 0.0 | 0.2 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 17.0 | -677.9 | 0.0 | 188.5 | 0.2 | -10.6 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | - | - | - | - | 1.3 | +0.0 | 0.0 | 19.9 |
| ONE FIGHT FORMULA | 6.6 | -90.0 | 0.0 | 150.8 | 6.4 | -135.8 | 0.0 | 139.0 |
| ONE OBJECTIVE FORMULA | 2.1 | -99.9 | 0.0 | 19.4 | 3.8 | -32.7 | 0.0 | 6.0 |
| ONE TARGET A SHOOTER | - | - | - | - | 17.0 | +529.9 | 0.0 | 241.8 |
| OPENS A LANE | 0.4 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.4 | +20.4 | 28.5 | 0.0 |
| OVERRUNS AWAY | 0.1 | +0.6 | 11.4 | 0.0 | 0.3 | +5.7 | 33.8 | 18.1 |
| PATHS CROSS | 1.6 | +70.1 | 0.0 | 40.0 | 5.2 | +176.5 | 0.0 | 33.8 |
| PIVOT GUARDS FLANK | 0.1 | -0.3 | 0.0 | 4.3 | 0.1 | -2.3 | 0.0 | 0.0 |
| PLAN RESULT | 40.7 | +1927.9 | 1492.4 | 679.4 | 46.4 | +651.9 | 371.4 | 1009.2 |
| PURSUES BIG PREY | 0.1 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.8 | +21.6 | 0.0 | 28.3 | 0.9 | +8.6 | 0.0 | 0.0 |
| RANDOM MOVER NO PROMISE | 0.2 | -7.1 | 0.0 | 28.3 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.5 | -11.5 | 0.0 | 7.1 | 0.2 | -7.6 | 0.0 | 3.4 |
| REDIRECT COUNTER | 2.2 | +148.3 | 0.0 | 44.5 | 2.0 | +128.9 | 0.0 | 37.8 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.1 | -9.4 | 0.0 | 8.8 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 42.6 |
| RESERVE FALL BACK | 0.6 | +19.2 | 0.0 | 11.0 | 2.1 | +58.3 | 0.0 | 23.7 |
| RESTRAINS TO SHOOT | 0.2 | +23.0 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +50.3 | 216.5 | 18.2 | 2.2 | +19.8 | 194.4 | 96.9 |
| RISK BY HIS FIGURE | - | - | - | - | 11.4 | -203.1 | 0.0 | 245.2 |
| RISK ONCE | 6.5 | +115.5 | 0.0 | 123.2 | - | - | - | - |
| RUN DOWN | - | - | - | - | 2.1 | -7.1 | 118.9 | 89.0 |
| SAFER THAN THE JOB | 0.5 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | - | - | - | - | 0.2 | -0.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | +0.1 | 0.0 | 0.0 | 0.8 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -2.5 | 0.0 | 7.1 | 0.1 | -8.2 | 0.0 | 0.0 |
| SEARCH SPOT | 2.8 | +135.0 | 0.0 | 36.7 | 5.9 | +283.7 | 0.0 | 51.9 |
| SECOND HUNTER | 0.2 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.4 | +4.9 | 0.0 | 7.1 | 0.5 | +10.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +19.6 | 13.8 | 0.0 | 0.1 | +9.7 | 0.0 | 17.6 |
| SHOOTER COUNTED ONCE | 0.2 | -0.4 | 0.0 | 7.1 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.6 | +1.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +42.2 | 12.4 | 13.8 | 0.4 | +0.9 | 0.0 | 6.7 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.6 | -9.8 | 87.1 | 8.3 |
| SHOT RISK POINTS | - | - | - | - | 12.9 | -209.9 | 0.0 | 353.3 |
| SHOTS IN THE MOVE | 18.5 | +726.5 | 0.0 | 284.2 | 21.4 | +550.0 | 0.0 | 164.8 |
| SPELL SETS UP CHARGE | 0.8 | +205.3 | 13.8 | 18.3 | 0.1 | +9.7 | 0.0 | 17.6 |
| SPELL WORTH | 0.3 | +13.5 | 130.7 | 0.0 | 0.8 | +15.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.2 | +4.0 | 43.7 | 0.0 | 0.8 | -7.2 | 47.1 | 0.0 |
| STABLE ROLE | 13.8 | +0.0 | 357.6 | 170.5 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.8 | -12.8 | 78.0 | 38.1 |
| STANDS FOR A REASON | - | - | - | - | 0.5 | +0.0 | 0.0 | 81.5 |
| STANDS STILL | - | - | - | - | 19.8 | +0.0 | 429.7 | 153.1 |
| STAY WEIGHED | 0.3 | +9.5 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 21.2 | +8.7 | 703.2 | 219.6 | 26.8 | +187.7 | 331.2 | 90.2 |
| STOPS SHORT OF THE FLANK | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 14.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.8 | -45.1 | 128.5 | 52.9 | 1.4 | +0.0 | 95.8 | 36.2 |
| SUPPORTS | 3.8 | +45.1 | 70.2 | 34.7 | - | - | - | - |
| SURE REACH TOGETHER | 0.2 | -7.5 | 0.0 | 0.0 | 0.5 | +1.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 5.7 | +0.0 | 0.0 | 16.2 |
| THE PROMISE ADDS | - | - | - | - | 0.1 | -1.8 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.4 | +6.7 | 0.0 | 5.4 | - | - | - | - |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +42.5 | 31.8 | 16.2 |
| TIME ON OUR SIDE | - | - | - | - | 13.4 | +167.8 | 5.4 | 68.2 |
| TURN WORTH | 0.4 | -36.9 | 46.6 | 0.0 | - | - | - | - |
| WAIT AFTER COSTS | 4.8 | -181.1 | 91.3 | 98.8 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.2 | +0.0 | 0.0 | 0.0 |
| WALKS TO THE FIGHT | 2.3 | +13.8 | 18.1 | 33.8 | - | - | - | - |
| WAR ENGINE CHARGES | 0.2 | +4.6 | 3.4 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 16.2 | 57.1 | - | - | - | - |
| WEARS DOWN | 1.3 | +28.4 | 94.5 | 13.2 | - | - | - | - |
| WHO HITS BACK | 0.1 | +0.7 | 0.0 | 0.0 | 0.2 | +27.1 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +0.0 | 18.3 | 0.0 | 0.3 | +14.1 | 53.0 | 10.2 |
| WHOLE FIGHT GAIN | 0.1 | +0.2 | 0.0 | 0.0 | 0.2 | +8.5 | 40.8 | 16.2 |
| WIDER SPREAD | 2.0 | -5.5 | 178.1 | 18.2 | 2.6 | -9.9 | 172.8 | 69.5 |
| WOUNDED STAYS OUT | - | - | - | - | 0.2 | +0.0 | 19.2 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 0.8 | +92.8 | 0.0 | 82.3 |

### Rule changes: t9-opp-e62ea8a-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 207 | 207 | 207 | 17.25 | -8262 | -39.9 |
| DEPLOY BY FIGURES | 208 | 208 | 136 | 11.33 | +1964 | +14.4 |
| SEARCH SPOT | 105 | 105 | 105 | 8.75 | +5024 | +47.9 |
| HIS SHOT LIST | 292 | 292 | 100 | 8.33 | +1842 | +18.4 |
| PATHS CROSS | 82 | 82 | 82 | 6.83 | +2960 | +36.1 |
| FIVE ACTION | 638 | 638 | 74 | 6.17 | +2421 | +32.7 |
| ONE TARGET A SHOOTER | 204 | 204 | 70 | 5.83 | +858 | +12.3 |
| LEGAL CHARGES ONLY | 54 | 54 | 54 | 4.50 | +0 | +0.0 |
| CANNON PLANNED TARGET | 203 | 203 | 41 | 3.42 | -200 | -4.9 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 3.17 | +0 | +0.0 |
| SHOTS IN THE MOVE | 479 | 425 | 38 | 3.17 | +918 | +24.2 |
| SHOT RISK POINTS | 155 | 155 | 35 | 2.92 | +1060 | +30.3 |
| CANNON SIGHT KEPT | 32 | 32 | 32 | 2.67 | +0 | +0.0 |
| RESERVE FALL BACK | 32 | 32 | 32 | 2.67 | +930 | +29.1 |
| FOUR ROUNDS | 48 | 48 | 29 | 2.42 | +1580 | +54.5 |
| MAX FOR POSITIONING | 128 | 98 | 28 | 2.33 | +106 | +3.8 |
| KILLS COUNT NEXT TURN | 54 | 54 | 25 | 2.08 | +304 | +12.1 |
| COVER ONCE | 170 | 113 | 24 | 2.00 | +261 | +10.9 |
| MOVE TO CHARGE COMPUTED | 55 | 55 | 23 | 1.92 | +828 | +36.0 |
| NEXT OBJECTIVE NEARER | 139 | 139 | 23 | 1.92 | +346 | +15.0 |
| TIME ON OUR SIDE | 161 | 153 | 23 | 1.92 | +28 | +1.2 |
| LONE WIZARD KEPT IN | 18 | 18 | 18 | 1.50 | +1377 | +76.5 |
| RISK ONCE | 78 | 51 | 18 | 1.50 | +227 | +12.6 |
| SUPPORTS | 45 | 45 | 17 | 1.42 | +185 | +10.9 |
| ADVANCE LANE KEPT | 15 | 15 | 15 | 1.25 | +0 | +0.0 |
| RISK BY ARC | 53 | 53 | 15 | 1.25 | +428 | +28.5 |
| SHOOTERS IN TWO RANKS | 15 | 15 | 15 | 1.25 | +34 | +2.3 |
| STAY WORTH | 576 | 535 | 15 | 1.25 | +261 | +17.4 |
| LANE BY FIGURES | 14 | 14 | 14 | 1.17 | +712 | +50.8 |
| ADVANCE WORTH | 64 | 64 | 13 | 1.08 | +146 | +11.2 |
| WALKS TO THE FIGHT | 28 | 28 | 13 | 1.08 | +38 | +2.9 |
| BEST FIRST | 12 | 12 | 12 | 1.00 | +359 | +29.9 |
| CHARGE NOW FIRST | 49 | 49 | 12 | 1.00 | -446 | -37.1 |
| REDIRECT COUNTER | 50 | 32 | 12 | 1.00 | +992 | +82.7 |
| SCOUT WAITS | 12 | 12 | 12 | 1.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 25 | 25 | 12 | 1.00 | +81 | +6.8 |
| SHORT GUN FORWARD | 12 | 12 | 12 | 1.00 | +0 | +0.0 |
| CHARGE NOT DECLARED | 11 | 11 | 11 | 0.92 | -533 | -48.5 |
| FACES THE THREAT | 11 | 11 | 11 | 0.92 | +465 | +42.3 |
| FALLBACK BY WORTH | 49 | 49 | 11 | 0.92 | +668 | +60.7 |
| FOLLOW UP WEIGHED | 11 | 11 | 11 | 0.92 | +3157 | +287.0 |
| HOLDS AMBUSHERS | 11 | 11 | 11 | 0.92 | +0 | +0.0 |
| MARCH CHECK | 14 | 14 | 11 | 0.92 | +240 | +21.9 |
| MODEL FACING | 11 | 11 | 11 | 0.92 | +2214 | +201.3 |
| BEST MOVE FOR SHOOTERS | 10 | 10 | 10 | 0.83 | +378 | +37.8 |
| CASTING BLOCK | 19 | 19 | 10 | 0.83 | +248 | +24.8 |
| HIS TURN DENIED | 28 | 28 | 10 | 0.83 | +400 | +40.0 |
| MISSILES IN THE MOVE | 64 | 40 | 10 | 0.83 | +293 | +29.3 |
| RANDOM MOVE BY FIGURES | 20 | 20 | 10 | 0.83 | +363 | +36.3 |
| FALLS SHORT | 189 | 169 | 9 | 0.75 | +102 | +11.3 |
| FIRE IN ORDER | 9 | 9 | 9 | 0.75 | +0 | +0.0 |
| HONEST WORTH | 112 | 112 | 9 | 0.75 | +35 | +3.9 |
| MANOEUVRE | 16 | 16 | 9 | 0.75 | +414 | +46.0 |
| WAIT AFTER COSTS | 57 | 57 | 9 | 0.75 | +62 | +6.9 |
| CHARGE LOSSES | 62 | 62 | 8 | 0.67 | +491 | +61.4 |
| IDLE COST | 290 | 186 | 8 | 0.67 | +113 | +14.2 |
| ONE FIGHT FORMULA | 156 | 85 | 8 | 0.67 | +66 | +8.2 |
| CHAFF IN THE MOVE | 11 | 10 | 7 | 0.58 | +126 | +18.0 |
| HARD STAY DROPPED | 7 | 7 | 7 | 0.58 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 15 | 15 | 7 | 0.58 | +426 | +60.8 |
| MOVE TO CHARGE | 20 | 20 | 7 | 0.58 | +264 | +37.7 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 0.50 | +0 | +0.0 |
| COMBAT PIVOT | 6 | 6 | 6 | 0.50 | +0 | +0.0 |
| KILLS COUNT | 14 | 14 | 6 | 0.50 | +309 | +51.6 |
| ONE OBJECTIVE FORMULA | 70 | 52 | 6 | 0.50 | +119 | +19.8 |
| SAFER THAN THE JOB | 6 | 6 | 6 | 0.50 | +51 | +8.5 |
| BEST PREY | 15 | 15 | 5 | 0.42 | +226 | +45.2 |
| FIGHT TO THE END | 23 | 23 | 5 | 0.42 | +122 | +24.4 |
| INVITES THE FIGHT | 9 | 9 | 5 | 0.42 | +29 | +5.7 |
| RISK BY HIS FIGURE | 137 | 137 | 5 | 0.42 | +322 | +64.3 |
| SUPPORT NARROWED | 75 | 75 | 5 | 0.42 | -109 | -21.8 |
| THROUGH LINE OF FIRE | 5 | 5 | 5 | 0.42 | +80 | +16.0 |
| WOUNDS ON THE RANKS | 10 | 10 | 5 | 0.42 | +275 | +54.9 |
| KEEPS ITS TARGET | 13 | 13 | 4 | 0.33 | +75 | +18.6 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.33 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.33 | +282 | +70.4 |
| STAY WEIGHED | 4 | 4 | 4 | 0.33 | +114 | +28.4 |
| WAR ENGINE JOBS | 8 | 8 | 4 | 0.33 | -165 | -41.2 |
| BEST FACING | 3 | 3 | 3 | 0.25 | +52 | +17.2 |
| CAST JOB | 10 | 10 | 3 | 0.25 | +27 | +9.1 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| FOCUS FIRE | 3 | 3 | 3 | 0.25 | +38 | +12.6 |
| MARCH BY THE SUM | 3 | 3 | 3 | 0.25 | +167 | +55.8 |
| MOVE AND CAST | 3 | 3 | 3 | 0.25 | +35 | +11.5 |
| NEARER NOT NEEDED | 72 | 71 | 3 | 0.25 | +129 | +43.0 |
| NEXT CHARGE BY LIST | 74 | 74 | 3 | 0.25 | +134 | +44.6 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 0.25 | +8 | +2.6 |
| STUCK PIVOT | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 0.25 | +107 | +35.6 |
| WHO HITS BACK | 3 | 3 | 3 | 0.25 | +309 | +103.1 |
| BEST OVERALL | 2 | 2 | 2 | 0.17 | +160 | +79.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| EDGE GIVE GROUND | 3 | 3 | 2 | 0.17 | +262 | +130.9 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.17 | +152 | +76.0 |
| HUNT IN PAIRS | 10 | 6 | 2 | 0.17 | +148 | +73.8 |
| JOINT CHARGE PLAN | 2 | 2 | 2 | 0.17 | +49 | +24.4 |
| LONG SHOT | 7 | 7 | 2 | 0.17 | +12 | +5.8 |
| MARCH ODDS | 2 | 2 | 2 | 0.17 | +28 | +13.8 |
| MISSILES NEXT TURN | 81 | 48 | 2 | 0.17 | +8 | +3.8 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.17 | +110 | +55.1 |
| OPENS UP | 5 | 5 | 2 | 0.17 | +32 | +15.8 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.17 | -32 | -15.8 |
| SPELLS IN THE FIGHT | 11 | 11 | 2 | 0.17 | +1 | +0.4 |
| SURE REACH TOGETHER | 9 | 9 | 2 | 0.17 | +0 | +0.0 |
| WEARS DOWN | 16 | 16 | 2 | 0.17 | +13 | +6.6 |
| WHOLE FIGHT | 6 | 6 | 2 | 0.17 | +7 | +3.5 |
| WIDER SPREAD | 55 | 55 | 2 | 0.17 | +7 | +3.6 |
| WOUNDED STAYS OUT | 2 | 2 | 2 | 0.17 | -195 | -97.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.08 | +132 | +131.5 |
| BACKUP TARGETS | 6 | 3 | 1 | 0.08 | +0 | +0.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.08 | -52 | -51.9 |
| BIG CHARACTER SAFETY | 1 | 1 | 1 | 0.08 | +3 | +3.1 |
| BLOCKED WHEEL | 1 | 1 | 1 | 0.08 | -16 | -16.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.08 | +51 | +50.9 |
| CHAFF PASSED | 1 | 1 | 1 | 0.08 | -2 | -1.7 |
| CHARGE NOW WEIGHED | 1 | 1 | 1 | 0.08 | +1 | +0.8 |
| CHARGER SLAIN LOST | 11 | 11 | 1 | 0.08 | +10 | +10.4 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.08 | +7 | +7.4 |
| GUN MASK | 8 | 8 | 1 | 0.08 | +8 | +7.6 |
| HILL BY ITS CHANCE | 6 | 6 | 1 | 0.08 | +34 | +33.6 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.08 | +14 | +14.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.08 | +57 | +56.9 |
| NEEDED THERE | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.08 | +40 | +40.5 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.08 | -15 | -14.8 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.08 | -0 | -0.1 |
| STOPS SHORT OF THE FLANK | 1 | 1 | 1 | 0.08 | +12 | +11.9 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.08 | +7 | +7.0 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.08 | +27 | +27.1 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 12 | 12 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 14 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 5 | 5 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 36 | 36 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 113 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 8 | 8 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 25 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 24 | 24 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HIS CHARGE LIST | 34 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 39 | 39 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 28 | 28 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 8 | 8 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 4 | not checked | - | - | - | - |
| LOST CHARGE | 26 | 26 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 33 | 33 | 0 | 0.00 | - | - |
| NOT NEEDED | 3 | 3 | 0 | 0.00 | - | - |
| NOT TURNED | 79 | 79 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 16 | 16 | 0 | 0.00 | - | - |
| OPENS A LANE | 5 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 1045 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 13 | 0 | 0.00 | - | - |
| RUN DOWN | 25 | 25 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 12 | 12 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 11 | 6 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 7 | 7 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| STABLE ROLE | 166 | 166 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 10 | 10 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 238 | 238 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 68 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 6 | not checked | - | - | - | - |
| TURN WORTH | 5 | 5 | 0 | 0.00 | - | - |
| WAITS AGAIN | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: t9-opp-e62ea8a-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.92 | 0.17 | 41.1 |
| CANNON PLANNED TARGET | rule | 0.67 | 0.33 | 16.7 |
| CHARGE NOW FIRST | rule | 0.08 | 0.92 | 37.1 |
| PATHS CROSS | rule | 0.17 | 0.83 | 16.9 |
| CHARGE NOT DECLARED | rule | 0.33 | 0.25 | 77.9 |
| TURN GATE | gate | 0.58 | - | 23.3 |
| FALLBACK | gate | 0.42 | - | 25.1 |
| SUPPORT NARROWED | rule | 0.08 | 0.33 | 21.8 |
| WAR ENGINE JOBS | rule | 0.33 | - | 41.2 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.08 | 15.8 |
| THROUGH LINE OF FIRE | rule | 0.17 | - | 31.1 |
| WOUNDED STAYS OUT | rule | - | 0.17 | 97.5 |
| BEST PRIZE | rule | - | 0.08 | 51.9 |
| BLOCKED WHEEL | rule | 0.08 | - | 16.1 |
| CHAFF PASSED | rule | 0.08 | - | 1.7 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.08 | 45.3 |
| PURSUES BIG PREY | rule | 0.08 | - | 14.8 |
| RULE SWITCHED OFF | gate | 0.08 | - | 1.5 |

### Plans: t9-opp-e62ea8a-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.2 | 9% | 148 | 273 | 184% |
| Mine | charge | 2.2 | 37% | 161 | 138 | 85% |
| Mine | close in | 2.2 | 15% | 104 | 31 | 30% |
| Mine | hold | 5.2 | 32% | 394 | 0 | 0% |
| Mine | join | 1.5 | 100% | 42 | 0 | 0% |
| Mine | shoot | 14.9 | 66% | 399 | 1486 | 373% |
| Mine | support | 4.4 | 92% | 27 | 0 | 0% |
| Opponent | charge | 3.5 | 55% | 553 | 251 | 45% |
| Opponent | join | 0.4 | 80% | 15 | 0 | 0% |
| Opponent | move | 30.8 | 94% | 1472 | 0 | 0% |
| Opponent | shoot | 11.5 | 60% | 504 | 401 | 80% |
| Opponent | support | 0.2 | 100% | 0 | 0 | - |

### Packages: hunt the guns, t9-opp-e62ea8a-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 3 | 1 | 0% | 0% | 0% | - | 172 | 0 | 0% | 81 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 134 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 1 | 0% | 0% | 0% | - | 172 | 0 | 0% | 82 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 190 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 217 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 377 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 47 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 244 |

### Battle groups: t9-opp-e62ea8a-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 23% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 38% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t9-opp-e62ea8a-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 7 | 11 (7) | 11 | 0 | 75 | 86% | 1.0 | 0 (2) | 0 (3) | 28 (2) | 0 (6) | 63 (1) |
| Mine | Character | 46 | 43 (46) | 43 | 0 | 15 | 26% | 2.1 | 30 (14) | 56 (13) | 49 (16) | 30 (30) | 77 (13) |
| Mine | Clean-up | 12 | 60 (12) | 30 | 30 | 27 | 50% | 3.8 | 0 (2) | 51 (8) | 123 (2) | 71 (9) | 38 (3) |
| Mine | Fast Hammer | 8 | 52 (8) | 52 | 0 | 68 | 25% | 3.3 | 0 (2) | 69 (4) | 78 (2) | 57 (5) | 45 (3) |
| Mine | Hammer | 28 | 39 (28) | 28 | 11 | 23 | 25% | 2.6 | 0 (5) | 49 (17) | 49 (6) | 21 (21) | 80 (7) |
| Mine | Holder | 10 | 29 (10) | 0 | 29 | 42 | 70% | 2.7 | 8 (4) | 63 (4) | 0 (2) | 45 (7) | 0 (3) |
| Mine | Shooter | 15 | 56 (15) | 6 | 50 | 42 | 0% | 1.5 | 0 (4) | 85 (10) | 0 (1) | 59 (14) | 0 (1) |
| Mine | War machine | 30 | 48 (30) | 48 | 0 | 33 | 7% | 1.2 | 61 (12) | 42 (9) | 31 (9) | 19 (6) | 56 (24) |
| Mine | Wizard | 8 | 23 (8) | 23 | 0 | 45 | 50% | 2.5 | 0 (4) | 229 (1) | 0 (2) | 0 (4) | 76 (3) |
| Opponent | Chaff | 20 | 104 (20) | 15 | 90 | 45 | 25% | 2.3 | 10 (6) | 179 (9) | 79 (5) | 115 (19) | 0 (1) |
| Opponent | Character | 33 | 45 (33) | 45 | 0 | 37 | 30% | 2.7 | 77 (12) | 26 (13) | 40 (6) | 39 (24) | 74 (7) |
| Opponent | Clean-up | 10 | 30 (10) | 22 | 8 | 49 | 50% | 1.8 | 0 (4) | 63 (6) | - | 32 (9) | 0 (1) |
| Opponent | Fast Hammer | 14 | 17 (14) | 5 | 11 | 55 | 43% | 2.9 | 9 (4) | 8 (9) | 84 (1) | 24 (8) | 5 (6) |
| Opponent | Hammer | 12 | 7 (12) | 3 | 4 | 34 | 50% | 2.8 | 0 (2) | 9 (9) | 0 (1) | 11 (8) | 0 (4) |
| Opponent | Holder | 15 | 108 (15) | 6 | 102 | 15 | 20% | 3.1 | 0 (2) | 142 (9) | 94 (4) | 93 (8) | 137 (7) |
| Opponent | Shooter | 15 | 74 (15) | 7 | 67 | 23 | 7% | 2.2 | 18 (6) | 163 (7) | 0 (2) | 70 (12) | 85 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 22 | 39 (22) | 39 | 0 | 9 | 9% | 1.6 | 52 (9) | 32 (5) | 28 (8) | 15 (3) | 42 (19) |
| Opponent | Wizard | 12 | 6 (12) | 6 | 0 | 35 | 0% | 1.5 | 0 (3) | 16 (4) | 0 (1) | 10 (4) | 0 (4) |

### Charged fights: t9-opp-e62ea8a-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 51 | 109 | 1.5 | 1.0 | 73 | 9 | +64 | 3 of 6 | 5 of 6 | - | +64 |
| Mine | Chaos Dwarfs | 4 | 370 | 494 | 3.5 | 1.1 | 141 | 50 | +92 | 8 of 14 | 11 of 14 | +227 | +81 |
| Mine | Dwarfen Mountain Holds | 4 | 394 | 34 | 1.8 | 1.3 | 20 | 17 | +2 | 1 of 7 | 2 of 7 | -30 | +15 |
| **Mine** | all armies | 12 | 272 | 212 | 2.2 | 1.1 | 94 | 32 | +62 | 12 of 27 | 18 of 27 | +56 | +63 |
| Opponent | Dwarfen Mountain Holds | 2 | 206 | 73 | 1.5 | 1.0 | 49 | 0 | +49 | 0 of 3 | 3 of 3 | - | +49 |
| Opponent | Empire of Man | 2 | 155 | 155 | 1.5 | 1.3 | 103 | 0 | +103 | 2 of 3 | 1 of 3 | +310 | +0 |
| Opponent | Grand Cathay | 1 | 65 | 190 | 5.0 | 1.0 | 38 | 0 | +38 | 3 of 5 | 2 of 5 | - | +38 |
| Opponent | Kingdom of Bretonnia | 1 | 265 | 471 | 4.0 | 1.0 | 118 | 0 | +118 | 1 of 4 | 4 of 4 | - | +118 |
| Opponent | Tomb Kings of Khemri | 3 | 93 | 505 | 4.3 | 1.1 | 117 | 112 | +5 | 7 of 13 | 7 of 13 | +310 | -21 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 45 | -45 | 0 of 1 | 0 of 1 | - | -45 |
| Opponent | Warriors of Chaos | 2 | 0 | 233 | 1.0 | 2.0 | 233 | 0 | +233 | 2 of 2 | 1 of 2 | +328 | +138 |
| **Opponent** | all armies | 12 | 111 | 258 | 2.6 | 1.1 | 100 | 48 | +52 | 15 of 31 | 18 of 31 | +316 | +23 |

### Effective charges: t9-opp-e62ea8a-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net -52) | 2 (net +0) | 1 (net +72) | 1 (net +0) | 0 | 1 (net +365) | 0 | 17% (1 of 6) |
| Mine | Chaos Dwarfs | 14 | 5 (net +284) | 0 | 1 (net -693) | 1 (net +68) | 2 (net +0) | 5 (net +98) | 0 | 7% (1 of 14) |
| Mine | Dwarfen Mountain Holds | 7 | 3 (net -40) | 0 | 0 | 1 (net +0) | 0 | 2 (net +68) | 1 | 0% (0 of 6) |
| Opponent | Dwarfen Mountain Holds | 3 | 0 | 0 | 1 (net +65) | 1 (net +81) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Empire of Man | 3 | 2 (net +0) | 0 | 1 (net +310) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Grand Cathay | 5 | 3 (net +0) | 0 | 0 | 2 (net +95) | 0 | 0 | 0 | 0% (0 of 5) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 1 (net +105) | 0 | 2 (net +183) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 13 | 3 (net +31) | 0 | 4 (net +99) | 1 (net -195) | 1 (net +85) | 3 (net -133) | 1 | 33% (4 of 12) |
| Opponent | Vampire Counts | 1 | 1 (net -45) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 2 | 1 (net +138) | 0 | 0 | 0 | 1 (net +328) | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: t9-opp-e62ea8a-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 250 | 234 | +138 | 202 | 27 | +175 | +70.1 |
| Mine | 50-54% | 2 | 52 | 186 | +0 | 46 | 13 | +34 | +64.4 |
| Mine | Effective (55-75%) | 2 | 181 | 252 | -310 | 132 | 346 | -215 | -118.6 |
| Mine | 76-89% | 3 | 102 | 176 | +23 | 100 | 21 | +79 | +77.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 260 | 175 | +124 | 150 | 13 | +138 | +52.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 310 | 72 | +0 | 26 | 22 | +4 | +1.2 |
| Mine | No odds | 1 | 50 | 111 | +0 | 14 | 0 | +14 | +27.8 |
| Mine | All fights | 27 | 214 | 191 | +62 | 139 | 43 | +95 | +44.6 |
| Opponent | Long shot (under 50%) | 10 | 252 | 264 | +19 | 77 | 93 | -16 | -6.4 |
| Opponent | 50-54% | 1 | 275 | 105 | +105 | 105 | 0 | +105 | +38.2 |
| Opponent | Effective (55-75%) | 6 | 434 | 200 | +128 | 161 | 32 | +128 | +29.6 |
| Opponent | 76-89% | 6 | 269 | 129 | +74 | 106 | 67 | +39 | +14.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 188 | 183 | -80 | 55 | 135 | -80 | -42.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 548 | 134 | +206 | 206 | 37 | +170 | +31.0 |
| Opponent | No odds | 1 | 431 | 81 | +81 | 81 | 0 | +81 | +18.8 |
| Opponent | All fights | 31 | 306 | 193 | +52 | 105 | 73 | +31 | +10.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t9-opp-e62ea8a-p2 | move | 101 | 17 (17%) | 12 (12%) | 17 (17%) | 67 (66%) |
| t9-opp-e62ea8a-p2 | objective | 30 | 3 (10%) | 3 (10%) | 5 (17%) | 22 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Mine | L0206, L0222 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

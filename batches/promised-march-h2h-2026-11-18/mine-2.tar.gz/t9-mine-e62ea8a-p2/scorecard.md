# Doctrine scorecard: t9-mine-e62ea8a-p2

### Scorecard: t9-mine-e62ea8a-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 55 |
| L0106 | 4 | 1 | Opponent | no | 2 | 4 | 3 | 3 | 0 | 0 | 0 | 615 |
| L0122 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 8 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 675 |
| L0222 | 6 | 1 | Mine | no | 5 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 220 |
| L0307 | 1 | 1 | Opponent | yes | 8 | 2 | 4 | 0 | 1 | 0 | 0 | 327 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 1 | 2 | 1 | 0 | 0 | 680 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 14 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 2 | - | 1 | 1 | 0 | 0 | 0 | 685 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 3 | 1 | 0 | 0 | 0 | 573 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 1 | 5 | 1 | 1 | 0 | 0 | 0 | 1282 |
| L0528 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 1312 |
| L0616 | 4 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 1 | 6 | 0 | 0 | 0 | 0 | 891 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 340 |
| L0721 | 1 | 1 | Mine | yes | 12 | 2 | 1 | 2 | 0 | 0 | 0 | 45 |
| L0721 | 1 | 1 | Opponent | no | 4 | - | 0 | 4 | 1 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 6 | - | 1 | 2 | 0 | 0 | 0 | 135 |
| L0810 | 6 | 1 | Opponent | no | 11 | 2 | 3 | 0 | 0 | 0 | 0 | 465 |
| **Average** | | | Mine | 30% | 5.1 | 3.1 | 1.7 | 2.2 | 0.1 | 0.0 | 0.0 | 375.6 |
| **Average** | | | Opponent | 20% | 4.6 | 2.1 | 2.5 | 1.5 | 0.2 | 0.0 | 0.0 | 295.5 |

### KPIs: t9-mine-e62ea8a-p2

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 14 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 49% (30 of 61) | 21% (14 of 68) | 34% (44 of 129) |
| Winner chose to follow up after the loser gave ground |  | 79% (23 of 29); on the table 90% | 100% (8 of 8); on the table 100% | 84% (31 of 37); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 86% (6 of 7); on the table 86% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fled |  | 29% (2 of 7); on the table 57% | 83% (15 of 18); on the table 83% | 68% (17 of 25); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 70% (26 of 37); on the table 84% | 88% (29 of 33); on the table 88% | 79% (55 of 70); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 35% (51 of 144) | 24% (19 of 78) | 32% (70 of 222) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (51 of 102) | 40% (19 of 48) | 47% (70 of 150) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (5 of 8) | 56% (10 of 18) | 58% (15 of 26) |
| Points that never fought | lower | 49% (13580 of 27593) | 47% (13234 of 27994) | 48% (26814 of 55587) |
|   infantry points that never fought | lower | 40% (3135 of 7893) | 85% (5034 of 5895) | 59% (8169 of 13788) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (68 of 108) | 57% (64 of 112) | 60% (132 of 220) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.4 uses a game | 100% (6 of 6); 1.1 uses a game | 100% (12 of 12); 1.3 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 0.4 uses a game | 100% (2 of 2); 0.4 uses a game | 80% (4 of 5); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (8 of 10); 0.6 uses a game | 40% (2 of 5); 0.1 uses a game | 67% (10 of 15); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (12362 of 21341) | 49% (11508 of 23522) | 53% (23870 of 44863) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (32%) | 1.0 (24%) | 3.1 (29%) |
| MARCHED: its unit marched | 0.6 (10%) | 0.8 (19%) | 1.4 (13%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.1 (16%) | 1.4 (34%) | 2.5 (23%) |
| REAR RANK: in a rear rank | 0.7 (11%) | 0.0 (0%) | 0.7 (7%) |
| FLEEING: fleeing | 0.1 (2%) | 0.3 (7%) | 0.4 (4%) |
| GONE: slain | 1.7 (26%) | 0.4 (10%) | 2.1 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.5 | 0.6 | 1.4 | 5.0 | 0.4 | 1.2 |
| not cast | 2.5 | 2.4 | 3.7 | 10.9 | 1.7 | 16.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (47%) | 0.1 (4%) | 3.1 (29%) | 0.1 (4%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (13%) | 0.3 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (6%) | 0.3 (12%) | 1.1 (31%) | 2.5 (23%) | 0.6 (38%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.5 (13%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.6 (23%) | 0.0 (0%) | 0.1 (4%) | 0.4 (4%) | 0.0 (0%) | 0.6 (3%) |
| GONE: slain | 0.5 (20%) | 0.6 (24%) | 0.9 (25%) | 2.1 (20%) | 0.1 (8%) | 2.7 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.1 (3%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.9 (6%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (6%) | 0.1 (4%) | 0.2 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (9%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (29%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.9 (37%) | 0.2 (9%) | 0.6 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.9 (65%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 53% (9 of 17) | 56% (5 of 9) | 54% (14 of 26) |
| the unit moved after it | 56% (5 of 9) | 100% (5 of 5) | 71% (10 of 14) |
| it charged on its next turn | 0% (0 of 9) | 20% (1 of 5) | 7% (1 of 14) |
| the enemy charged it first | 22% (2 of 9) | 0% (0 of 5) | 14% (2 of 14) |
| it fought by the end of its next turn | 11% (1 of 9) | 0% (0 of 5) | 7% (1 of 14) |
| it moved out of a charge the enemy had planned (not charged first) | 22% (2 of 9) | 20% (1 of 5) | 21% (3 of 14) |
| none of these (no charge, no fight, no charge escaped) | 56% (5 of 9) | 60% (3 of 5) | 57% (8 of 14) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (266 of 398) | 54% (232 of 429) | 60% (498 of 827) |
|   cavalry | 49% (18 of 37) | 46% (22 of 48) | 47% (40 of 85) |
|   character | 88% (44 of 50) | 6% (2 of 35) | 54% (46 of 85) |
|   chariot | 57% (26 of 46) | 67% (18 of 27) | 60% (44 of 73) |
|   infantry | 50% (43 of 86) | 50% (89 of 179) | 50% (132 of 265) |
|   monster | 64% (7 of 11) | 61% (11 of 18) | 62% (18 of 29) |
|   war machine | 76% (128 of 168) | 74% (90 of 122) | 75% (218 of 290) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (29%) | 2.4 (17%) | 5.1 (22%) |
| CHARGED: it charged | 0.7 (8%) | 2.4 (17%) | 3.1 (13%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.1 (11%) | 0.4 (3%) | 1.4 (6%) |
| MOVED: a war machine that moved | 1.4 (14%) | 0.1 (1%) | 1.4 (6%) |
| NO TARGET IN RANGE | 0.9 (10%) | 3.3 (23%) | 4.2 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 1.1 (8%) | 1.6 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (16%) | 2.9 (20%) | 4.4 (19%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.6 (4%) | 0.6 (3%) |
| OTHER BAR | 0.4 (5%) | 0.9 (7%) | 1.4 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.5 | 0.6 | 88% | 3.3 pts | 12 pts |
| character | 3.5 | 1.6 | 67% | 20.4 pts | 72 pts |
| chariot | 3.1 | 2.9 | 55% | 20.4 pts | 64 pts |
| infantry | 13.1 | 6.1 | 69% | 9.0 pts | 118 pts |
| monster | 1.6 | 0.5 | 73% | 5.9 pts | 9 pts |
| war machine | 15.6 | 11.6 | 64% | 22.1 pts | 344 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.6 | 6.1 | 4.4 |
| Charges that made contact a game | 1.7 | 4.6 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.43 declared, 0.43 contact (7 units) | 1.14 declared, 1.00 contact (7 units) | 0.79 declared, 0.71 contact (14 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 1.50 contact (2 units) | 1.50 declared, 1.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.34 declared, 0.22 contact (97 units) | 0.74 declared, 0.53 contact (102 units) | 0.54 declared, 0.38 contact (199 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (8 of 17) | 40% (2 of 5) | 50% (1 of 2) | 46% (11 of 24) |
| Character in a unit | 86% (12 of 14) | 50% (3 of 6) | - | 75% (15 of 20) |
| Character on its own | 79% (15 of 19) | 62% (10 of 16) | 22% (4 of 18) | 55% (29 of 53) |
| Chariot | 67% (2 of 3) | 70% (7 of 10) | - | 69% (9 of 13) |
| Infantry | 55% (17 of 31) | 40% (8 of 20) | 0% (0 of 1) | 48% (25 of 52) |
| Monster | 71% (10 of 14) | 100% (1 of 1) | - | 73% (11 of 15) |
| Monstrous | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| War Machines | 74% (29 of 39) | 50% (1 of 2) | - | 73% (30 of 41) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 75% (9 of 12); on the table 92% | 31% (32 of 102) | 53% | 64% (14 of 22) | 100% (6 of 6); 5.0 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 75% (6 of 8); on the table 100% | 47% (17 of 36) | 55% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 6 | 68% (13 of 19); on the table 74% | - | 57% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 4 | 71% (5 of 7); on the table 71% | 29% (7 of 24) | 49% | 57% (24 of 42) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 33% (1 of 3); 0.2 uses a game |
| Grand Cathay | 2 | 80% (4 of 5); on the table 80% | 21% (9 of 42) | 42% | 47% (9 of 19) | 100% (5 of 5); 7.5 uses a game | 100% (1 of 1); 1.5 uses a game | 0% (0 of 2); 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 54% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 50% | 50% (3 of 6) | 71% | 67% (6 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 100% (8 of 8); on the table 100% | - | 35% | 40% (6 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 11% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (5 of 5); on the table 100% | 0% (0 of 6) | 29% | 47% (7 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t9-mine-e62ea8a-p2, 14 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 58% (19) | 53% (10) | 56% (29) |
| ...free all their last turn and able to turn (per game) | 0.79 | 0.50 | 1.29 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.21 | 0.00 | 0.21 |
| ...with the charger already in that arc before they moved (per game) | 0.57 | 0.29 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 1.50 | 1.50 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.29 | 0.29 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 5.57 | 5.57 |

### Quality by phase: t9-mine-e62ea8a-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.4 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 41% (14 of 34) | 43% (36 of 84) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (88 of 212) | 52% (93 of 180) |
| Strategy | Close-in objectives charged next turn | - | 27% (22 of 83) |
| Strategy | Support requests answered (helper made contact too) | - | 35% (6 of 17) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 48% (11 of 23) | 18% (3 of 17) |
| Strategy | Lone characters that fought | 65% (26 of 40) | 80% (28 of 35) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 2.2 | 1.5 |
| Movement | Points that never moved of their own | 375.6 | 295.5 |
| Movement | Fights charged into per game | 1.7 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 22, net +0 | 8 of 45, net +86 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 22, net +219 | 14 of 45, net +211 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 22, net +60 | 1 of 45, net +81 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 of 22, net +220 | 12 of 45, net +163 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.5 | 11.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (81 of 147) | 24% (37 of 157) |
| Shooting | Points destroyed by shooting units | 149.9 | 42.1 |
| Shooting | War machine shots | 9.1 | 6.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (80 of 128) | 53% (48 of 90) |
| Shooting | Points destroyed by war machines | 98.2 | 84.3 |
| Magic | Magic missiles cast | 2.0 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 54% (15 of 28) | 46% (6 of 13) |
| Magic | Wounds caused by magic missiles | 3.1 | 1.4 |
| Magic | Wounds caused by other spells | 0.6 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 63.5 | 58.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.4 / 0.1 / 0.7 / 0.1 | 2.6 / 0.1 / 0.1 / 0.1 |
| Combat | Points destroyed in combat | 191.4 | 376.9 |
| Combat | Points run down | 109.9 | 184.9 |
| Combat | Net points per charged fight, damage counted | +133 | +129 |
| Combat | Net per 100 charger points, damage counted | +64.6 | +38.0 |
| Combat | First round won (charged fights) | 88% | 64% |
| Combat | Net points per charged fight | +125 | +139 |
| Combat | Net points per supported fight / lone fight | - / +125 | +252 / +107 |
| Combat | Charged fights on a top-3 enemy unit | 8 of 24 | 31 of 50 |
| Game | Points lost | 854.3 | 664.1 |
| Game | VP from objectives | 559.3 | 647.9 |
| Game | Lone holders (player turns) | 5.1 | 4.6 |

- Mine won / drew / lost: 4 / 4 / 6 of 14 ended games (of 14); mean margin (Mine - Opponent) -301 VP
- The side that went first won 4 of 10 games with a winner
- Points traded per game (both sides' losses): 1518
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t9-mine-e62ea8a-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 4.1 | -103.7 | 104.7 | 196.2 |
| AFTERMATH IN POINTS | 0.4 | +68.0 | 0.0 | 23.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.2 | +0.0 | 0.0 | 16.8 | 1.3 | +0.0 | 0.0 | 20.7 |
| BACKUP TARGETS | 0.4 | +0.9 | 0.0 | 3.7 | 0.4 | +1.6 | 0.0 | 0.0 |
| BEST FACING | - | - | - | - | 0.4 | +3.6 | 0.0 | 54.1 |
| BEST FIRST | - | - | - | - | 1.0 | +45.4 | 20.6 | 52.5 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.7 | +29.7 | 0.0 | 0.0 |
| BEST OVERALL | - | - | - | - | 0.4 | +10.6 | 0.0 | 15.5 |
| BEST PREY | - | - | - | - | 0.6 | +12.7 | 10.0 | 34.9 |
| BEST PRIZE | 0.1 | -2.0 | 3.9 | 0.0 | 0.2 | -2.5 | 8.2 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.1 | +2.3 | 0.0 | 38.6 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.3 | +11.8 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -4.0 | 34.5 | 0.0 | 1.1 | -135.4 | 171.4 | 5.1 |
| CANNON PLAN MISSED | 1.1 | +0.0 | 219.1 | 6.8 | 1.0 | +0.0 | 45.7 | 25.0 |
| CANNON PLANNED TARGET | 8.9 | +360.8 | 1074.9 | 86.4 | 5.7 | +99.5 | 201.7 | 102.9 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.7 | -7.8 | 211.5 | 0.0 |
| CAST JOB | 0.9 | +11.5 | 75.8 | 0.0 | 0.6 | +12.0 | 24.9 | 15.9 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 25.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +25.0 | 22.1 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.4 | +12.7 | 0.0 | 12.1 | 1.4 | +66.2 | 0.0 | 33.5 |
| CHAFF PASSED | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.1 | -241.6 | 0.0 | 151.1 | - | - | - | - |
| CHARGE NOT DECLARED | 0.4 | +0.0 | 11.6 | 3.7 | 1.3 | +0.0 | 267.1 | 24.9 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 125.8 | 27.9 | 3.6 | +0.0 | 456.4 | 80.6 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.5 | -47.3 | 47.2 | 19.3 |
| CHARGER SLAIN LOST | 0.7 | -31.4 | 106.0 | 3.7 | 0.6 | -10.8 | 118.7 | 9.3 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | +0.0 | 0.0 | 77.1 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 0.0 | 5.1 |
| CHEAPEST HOLDER | 0.4 | -15.2 | 25.7 | 14.4 | - | - | - | - |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 41.1 | 0.4 | +0.0 | 3.7 | 30.8 |
| CONVEYANCE SEARCH | 0.8 | +46.8 | 3.9 | 25.4 | 0.1 | +24.0 | 0.0 | 0.0 |
| COVER ONCE | 5.9 | -436.4 | 0.0 | 75.6 | 7.6 | -523.9 | 0.0 | 99.5 |
| DEFENSIVE ARMY | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.8 | +31.5 | 0.0 | 6.8 | 7.9 | +22.7 | 0.0 | 18.2 |
| EDGE GIVE GROUND | 0.2 | +19.7 | 9.9 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 1.5 | +97.0 | 0.0 | 89.0 |
| FALL BACK GOOD ORDER | 2.0 | +1.3 | 182.9 | 31.6 | - | - | - | - |
| FALLBACK BY WORTH | 0.4 | -0.7 | 0.0 | 3.9 | 5.6 | +42.2 | 0.0 | 32.0 |
| FALLS SHORT | 8.5 | +148.7 | 0.0 | 116.6 | - | - | - | - |
| FEATURE BUFFS | 2.1 | +59.6 | 0.0 | 15.9 | - | - | - | - |
| FIGHT TO THE END | 0.8 | +28.2 | 40.7 | 24.2 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 12.6 | 4.3 | 0.2 | +0.0 | 7.9 | 0.0 |
| FIVE ACTION | 45.4 | +2514.0 | 1713.1 | 585.2 | - | - | - | - |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 99.1 | 5.3 | +0.0 | 0.0 | 173.6 |
| FOCUS FIRE | 0.1 | +3.5 | 12.6 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +293.5 | 0.0 | 89.9 | 0.4 | +88.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.4 | +181.8 | 206.1 | 31.6 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.1 | -19.7 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -7.6 | 0.0 | 20.6 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.2 | +5.0 | 0.0 | 21.4 | 0.3 | +23.1 | 0.0 | 4.3 |
| GATEWAY ESCAPE | - | - | - | - | 0.1 | +9.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.4 | -4.7 | 18.7 | 13.5 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.0 | 8.1 | 0.0 |
| GUN FIGURES | 1.5 | +14.8 | 40.6 | 0.0 | 0.8 | +4.8 | 48.9 | 8.6 |
| GUN MASK | 0.4 | +35.9 | 0.0 | 27.1 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE SHOOTS OR CHARGES | 1.9 | +0.0 | 0.0 | 46.3 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.3 | +0.0 | 89.6 | 5.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 15.9 | 0.0 | 0.4 | +0.0 | 180.6 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 1.0 | -52.1 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +7.1 | 28.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 17.0 | - | - | - | - |
| HIS LEGAL MOVES | 3.4 | +0.0 | 0.0 | 83.4 | - | - | - | - |
| HIS MOVE AND SHOT | 1.3 | -12.0 | 0.0 | 15.5 | - | - | - | - |
| HIS RANDOM MOVE | 2.3 | +0.0 | 0.0 | 61.0 | - | - | - | - |
| HIS SHOT LIST | 20.5 | +772.8 | 0.0 | 352.1 | - | - | - | - |
| HIS TURN DENIED | 0.9 | +20.5 | 42.6 | 31.6 | - | - | - | - |
| HOLDER AT DEPLOYMENT | 0.6 | +97.5 | 0.0 | 0.0 | 0.9 | +135.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.9 | -65.1 | 101.1 | 31.6 | 10.1 | -269.6 | 609.4 | 227.7 |
| HUNT ADVANCE | - | - | - | - | 0.4 | +2.6 | 17.9 | 5.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 4.3 | 0.1 | +0.0 | 7.9 | 5.0 |
| HUNT IN PAIRS | 0.1 | +7.8 | 0.0 | 0.0 | 0.9 | +65.4 | 0.0 | 31.0 |
| HUNT KEPT | - | - | - | - | 0.2 | +0.9 | 7.9 | 5.0 |
| HUNT RESULT | 0.2 | +32.6 | 0.0 | 4.3 | 0.1 | +14.4 | 7.9 | 5.0 |
| HUNT THE GUNS | 0.2 | +86.8 | 31.0 | 0.0 | 0.3 | +49.9 | 10.0 | 0.0 |
| IDLE COST | 4.4 | -34.2 | 0.0 | 81.5 | 18.0 | -304.5 | 0.0 | 248.5 |
| INVITES THE FIGHT | - | - | - | - | 1.2 | +9.0 | 39.3 | 38.6 |
| JOINT CHARGE PLAN | - | - | - | - | 0.5 | +24.4 | 20.6 | 31.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -18.6 | 13.6 | 40.9 |
| KEEP FALLS | 0.2 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.2 | 13.4 | 5.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.4 | +72.9 | 347.7 | 52.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | - | - | - | - | 2.1 | +108.2 | 378.6 | 10.0 |
| KILLS COUNT NEXT TURN | - | - | - | - | 6.1 | +191.9 | 298.1 | 181.2 |
| LANE BY FIGURES | 0.4 | +20.1 | 0.0 | 41.4 | 0.9 | +38.9 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.4 | +0.0 | 341.8 | 574.9 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.2 | +2.1 | 0.0 | 0.0 | 0.2 | +8.7 | 41.4 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.6 | +0.0 | 41.4 | 6.1 |
| LONE WIZARD KEPT IN | 0.8 | +64.4 | 0.0 | 0.0 | 0.6 | +54.0 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +1.3 | 33.1 | 0.0 | 0.5 | -0.9 | 39.2 | 4.9 |
| LOST CHARGE | 0.1 | -0.3 | 0.0 | 0.0 | 1.9 | -31.7 | 38.0 | 54.9 |
| MAKE SURE TOGETHER | 0.4 | +3.0 | 0.0 | 17.0 | 0.9 | +63.9 | 41.3 | 0.0 |
| MANOEUVRE | 0.9 | +11.0 | 0.0 | 3.7 | 0.2 | +12.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.1 | +3.9 | 0.0 | 41.4 | - | - | - | - |
| MARCH CHECK | 0.6 | +40.5 | 0.0 | 41.4 | 0.4 | +17.0 | 0.0 | 31.0 |
| MARCH ODDS | - | - | - | - | 0.4 | +13.7 | 24.2 | 15.9 |
| MARCH OVER CASTS | 0.1 | -6.5 | 0.0 | 0.0 | 0.3 | +30.1 | 0.0 | 27.1 |
| MAX FOR POSITIONING | 3.8 | +41.7 | 0.0 | 84.1 | 7.1 | +115.2 | 0.0 | 122.0 |
| MISSILES IN THE MOVE | 3.7 | +116.7 | 0.0 | 38.7 | 3.2 | +67.5 | 0.0 | 114.9 |
| MISSILES NEXT TURN | 4.0 | +79.8 | 0.0 | 74.4 | 3.9 | +56.4 | 0.0 | 173.1 |
| MODEL FACING | 0.9 | +213.2 | 0.0 | 8.6 | 0.3 | +54.4 | 0.0 | 4.3 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.4 | +0.0 | 20.6 | 31.0 |
| MOVE AND CAST | - | - | - | - | 0.3 | +13.2 | 0.0 | 6.1 |
| MOVE SPELL IN RANGE | 0.1 | +5.8 | 0.0 | 41.4 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -32.6 | 0.0 | 124.3 | - | - | - | - |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 4.9 | +342.6 | 253.9 | 138.9 |
| MOVE TO CHARGE COMPUTED | 3.3 | +252.2 | 0.0 | 88.9 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.4 | +203.3 | 0.0 | 30.4 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +4.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.4 | -144.3 | 37.4 | 101.1 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 5.9 | -263.3 | 120.6 | 38.3 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.6 | -55.4 | 117.8 | 31.6 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +1.4 | 0.0 | 4.6 | 0.1 | +4.3 | 0.0 | 0.0 |
| NOT NEEDED | - | - | - | - | 0.4 | -25.4 | 11.9 | 0.0 |
| NOT TURNED | - | - | - | - | 5.6 | +106.4 | 0.0 | 116.3 |
| NOT WORTH A CAST | - | - | - | - | 0.2 | -0.3 | 0.0 | 25.1 |
| OFF BEST | 0.5 | -5.9 | 0.0 | 0.0 | 17.3 | -842.2 | 0.0 | 274.1 |
| ONE CHARGE A CHARGER | 2.9 | +0.0 | 0.0 | 45.9 | - | - | - | - |
| ONE FIGHT FORMULA | 5.3 | -72.4 | 0.0 | 181.1 | 8.0 | -136.9 | 35.4 | 224.8 |
| ONE OBJECTIVE FORMULA | 4.1 | -15.4 | 0.0 | 57.7 | 3.1 | -235.4 | 0.0 | 14.9 |
| ONE TARGET A SHOOTER | 16.7 | +438.9 | 0.0 | 205.9 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.2 | 24.3 | 0.0 | 0.1 | +0.4 | 13.0 | 0.0 |
| OPENS UP | 0.1 | +15.1 | 11.4 | 0.0 | 0.1 | +9.8 | 7.5 | 0.0 |
| OVERRUNS AWAY | 0.4 | +21.5 | 54.2 | 0.0 | 0.4 | +5.7 | 17.9 | 20.6 |
| PATHS CROSS | 2.2 | +56.9 | 0.0 | 64.0 | 2.3 | +210.1 | 0.0 | 47.1 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +8.7 | 0.0 | 0.0 |
| PLAN RESULT | 40.5 | +1458.7 | 1008.9 | 836.1 | 43.4 | +1441.8 | 1468.6 | 923.2 |
| RANDOM MOVE BY FIGURES | 0.6 | +7.0 | 0.0 | 24.3 | 1.3 | +17.4 | 0.0 | 90.0 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.1 | -3.6 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -7.9 | 0.0 | 8.2 | 0.9 | -19.8 | 0.0 | 19.2 |
| REDIRECT COUNTER | 1.5 | +66.4 | 0.0 | 37.5 | 3.2 | +251.1 | 0.0 | 54.5 |
| REDIRECT WEIGHED | 0.1 | -1.2 | 3.9 | 0.0 | 0.5 | +10.8 | 33.0 | 43.0 |
| REFORMS TO MEET IT | 0.6 | -15.9 | 0.0 | 31.4 | - | - | - | - |
| REFUSING RETIRES | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +17.8 | 0.0 | 0.0 | 0.9 | +11.2 | 0.0 | 16.0 |
| RESTRAINS TO SHOOT | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +15.1 | 187.8 | 27.9 | 2.7 | +57.3 | 211.0 | 68.6 |
| RISK BY HIS FIGURE | 11.9 | -170.8 | 0.0 | 236.9 | - | - | - | - |
| RISK ONCE | - | - | - | - | 5.5 | +293.9 | 66.1 | 435.2 |
| RUN DOWN | 1.4 | -11.3 | 107.1 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +7.0 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.2 | -16.5 | 0.0 | 27.1 | - | - | - | - |
| SCOUT SPOT | 0.3 | +1.1 | 0.0 | 0.0 | 0.7 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.4 | -25.5 | 0.0 | 11.1 |
| SEARCH SPOT | 6.2 | +289.8 | 0.0 | 110.4 | 2.9 | +119.8 | 0.0 | 18.7 |
| SET UP TOGETHER | 0.4 | +3.0 | 0.0 | 17.0 | 2.4 | +215.5 | 131.7 | 36.1 |
| SHOOTERS IN TWO RANKS | 0.6 | +1.1 | 0.0 | 0.0 | 0.5 | +1.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +20.3 | 34.8 | 0.0 | 1.1 | +39.8 | 53.1 | 6.1 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -14.4 | 57.1 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 11.0 | +59.6 | 0.0 | 227.6 | - | - | - | - |
| SHOTS IN THE MOVE | 19.0 | +1061.6 | 0.0 | 230.1 | 17.9 | +449.6 | 0.0 | 166.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.1 | +21.7 | 0.0 | 0.0 |
| SPELL WORTH | 0.2 | +2.0 | 82.9 | 82.9 | 0.7 | +23.0 | 139.1 | 139.1 |
| SPELLS IN THE FIGHT | 0.2 | -8.0 | 72.4 | 0.0 | 0.4 | -5.9 | 20.0 | 0.0 |
| STABLE ROLE | - | - | - | - | 13.3 | +0.0 | 479.0 | 129.7 |
| STAND AND SHOOT | 0.4 | -2.6 | 5.1 | 27.9 | - | - | - | - |
| STANDS FOR A REASON | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 22.6 | +0.0 | 1507.1 | 234.0 | - | - | - | - |
| STAY WORTH | 23.3 | +221.3 | 989.0 | 233.6 | 24.9 | +97.7 | 402.8 | 273.8 |
| STOPS | 0.2 | +3.6 | 31.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.1 | +4.4 | 0.0 | 35.3 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 12.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.4 | +0.0 | 144.8 | 3.7 | 7.1 | -49.8 | 515.9 | 41.2 |
| SUPPORTS | - | - | - | - | 4.6 | +49.8 | 217.6 | 8.9 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.2 | -4.4 | 30.4 | 34.9 |
| SURE REACH TOGETHER | 0.2 | +0.6 | 0.0 | 10.7 | 0.4 | +1.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.5 | +0.0 | 0.0 | 29.1 | - | - | - | - |
| THE PROMISE ADDS | 0.3 | -7.8 | 0.0 | 26.6 | - | - | - | - |
| THE PROMISED MOVE | 0.1 | +0.0 | 0.0 | 4.6 | - | - | - | - |
| THROUGH LINE OF FIRE | - | - | - | - | 0.4 | +17.9 | 0.0 | 13.9 |
| TIED UP BY THE SUM | 0.4 | +25.4 | 24.1 | 3.7 | - | - | - | - |
| TIME ON OUR SIDE | 21.0 | +291.8 | 5.0 | 210.5 | - | - | - | - |
| TURN WORTH | - | - | - | - | 0.1 | -12.1 | 13.3 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.5 | +1.9 | 42.1 | 0.0 |
| WAIT AFTER COSTS | - | - | - | - | 7.6 | -440.1 | 304.9 | 182.0 |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 53.8 | - | - | - | - |
| WALKS TO THE FIGHT | - | - | - | - | 1.0 | +5.9 | 11.7 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +11.2 | 20.6 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 32.1 | 0.0 | 0.1 | +0.0 | 0.0 | 10.4 |
| WEARS DOWN | - | - | - | - | 2.1 | +49.3 | 126.2 | 58.7 |
| WHO HITS BACK | 0.4 | +98.2 | 0.0 | 46.0 | 0.1 | +5.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +22.0 | 60.1 | 0.0 | 0.9 | -8.4 | 106.4 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.9 | +41.1 | 164.1 | 9.3 |
| WIDER SPREAD | 2.1 | -4.7 | 157.1 | 31.6 | 3.6 | -11.1 | 486.3 | 37.3 |
| WOUNDS ON THE RANKS | 1.4 | +71.8 | 0.0 | 41.2 | - | - | - | - |

### Rule changes: t9-mine-e62ea8a-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 249 | 249 | 249 | 17.79 | -11873 | -47.7 |
| DEPLOY BY FIGURES | 234 | 234 | 154 | 11.00 | +2308 | +15.0 |
| SEARCH SPOT | 127 | 127 | 120 | 8.57 | +5736 | +47.8 |
| HIS SHOT LIST | 287 | 287 | 88 | 6.29 | +1960 | +22.3 |
| LEGAL CHARGES ONLY | 75 | 75 | 75 | 5.36 | +0 | +0.0 |
| PATHS CROSS | 63 | 63 | 63 | 4.50 | +3738 | +59.3 |
| TIME ON OUR SIDE | 294 | 263 | 63 | 4.50 | +271 | +4.3 |
| ONE TARGET A SHOOTER | 234 | 234 | 56 | 4.00 | +534 | +9.5 |
| SHOTS IN THE MOVE | 517 | 443 | 52 | 3.71 | +1441 | +27.7 |
| FIVE ACTION | 636 | 636 | 51 | 3.64 | +1742 | +34.2 |
| ARTILLERY RE-ROLL WEIGHED | 49 | 49 | 49 | 3.50 | +0 | +0.0 |
| CANNON PLANNED TARGET | 204 | 204 | 39 | 2.79 | -575 | -14.7 |
| COVER ONCE | 190 | 136 | 38 | 2.71 | +453 | +11.9 |
| CANNON SIGHT KEPT | 35 | 35 | 35 | 2.50 | +0 | +0.0 |
| MOVE TO CHARGE | 69 | 69 | 35 | 2.50 | +1686 | +48.2 |
| SHOT RISK POINTS | 154 | 154 | 30 | 2.14 | +1139 | +38.0 |
| MOVE TO CHARGE COMPUTED | 46 | 46 | 29 | 2.07 | +1113 | +38.4 |
| KILLS COUNT NEXT TURN | 86 | 86 | 25 | 1.79 | +909 | +36.4 |
| SUPPORTS | 64 | 64 | 25 | 1.79 | +187 | +7.5 |
| HARD STAY DROPPED | 24 | 24 | 24 | 1.71 | +0 | +0.0 |
| CHARGE NOT DECLARED | 23 | 23 | 23 | 1.64 | -1461 | -63.5 |
| MISSILES IN THE MOVE | 97 | 63 | 22 | 1.57 | +341 | +15.5 |
| FACES THE THREAT | 21 | 21 | 21 | 1.50 | +1358 | +64.7 |
| FOLLOW UP WEIGHED | 20 | 20 | 20 | 1.43 | +5352 | +267.6 |
| LONE WIZARD KEPT IN | 20 | 20 | 20 | 1.43 | +1658 | +82.9 |
| MAX FOR POSITIONING | 152 | 117 | 20 | 1.43 | +21 | +1.0 |
| RISK ONCE | 77 | 61 | 20 | 1.43 | +450 | +22.5 |
| REDIRECT COUNTER | 66 | 41 | 19 | 1.36 | +1026 | +54.0 |
| RESERVE FALL BACK | 19 | 19 | 19 | 1.36 | +406 | +21.4 |
| WAIT AFTER COSTS | 106 | 106 | 19 | 1.36 | +383 | +20.2 |
| ADVANCE LANE KEPT | 18 | 18 | 18 | 1.29 | +0 | +0.0 |
| FALLS SHORT | 119 | 97 | 18 | 1.29 | +80 | +4.5 |
| SHOOTS FROM THE BEST SPOT | 28 | 28 | 18 | 1.29 | +379 | +21.0 |
| CHAFF IN THE MOVE | 24 | 23 | 17 | 1.21 | +410 | +24.1 |
| LANE BY FIGURES | 17 | 17 | 17 | 1.21 | +825 | +48.5 |
| MODEL FACING | 17 | 17 | 17 | 1.21 | +3747 | +220.4 |
| RISK BY ARC | 67 | 65 | 17 | 1.21 | +516 | +30.3 |
| STAY WORTH | 674 | 614 | 17 | 1.21 | +200 | +11.8 |
| CHARGE LOSSES | 85 | 85 | 16 | 1.14 | +940 | +58.8 |
| ONE FIGHT FORMULA | 186 | 118 | 16 | 1.14 | +68 | +4.2 |
| SET UP TOGETHER | 39 | 36 | 16 | 1.14 | +1746 | +109.2 |
| FOUR ROUNDS | 34 | 34 | 15 | 1.07 | +1358 | +90.6 |
| IDLE COST | 314 | 196 | 15 | 1.07 | +128 | +8.6 |
| RANDOM MOVE BY FIGURES | 26 | 26 | 15 | 1.07 | +342 | +22.8 |
| RISK BY HIS FIGURE | 166 | 166 | 15 | 1.07 | +681 | +45.4 |
| SHOOTERS IN TWO RANKS | 15 | 15 | 15 | 1.07 | +34 | +2.3 |
| BEST FIRST | 14 | 14 | 14 | 1.00 | +635 | +45.4 |
| SCOUT WAITS | 14 | 14 | 14 | 1.00 | +0 | +0.0 |
| FALLBACK BY WORTH | 85 | 85 | 13 | 0.93 | +581 | +44.7 |
| HOLDS AMBUSHERS | 13 | 13 | 13 | 0.93 | +0 | +0.0 |
| SHORT GUN FORWARD | 13 | 13 | 13 | 0.93 | +0 | +0.0 |
| CHARGE NOW FIRST | 74 | 74 | 11 | 0.79 | -226 | -20.6 |
| BEST MOVE FOR SHOOTERS | 10 | 10 | 10 | 0.71 | +415 | +41.5 |
| HOLDER AT DEPLOYMENT | 22 | 22 | 10 | 0.71 | +511 | +51.1 |
| KILLS COUNT | 29 | 28 | 10 | 0.71 | +356 | +35.6 |
| MANOEUVRE | 15 | 15 | 10 | 0.71 | +342 | +34.2 |
| MARCH CHECK | 15 | 14 | 9 | 0.64 | +227 | +25.3 |
| NEXT CHARGE BY LIST | 61 | 61 | 9 | 0.64 | +59 | +6.6 |
| COMBAT PIVOT | 8 | 8 | 8 | 0.57 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 82 | 82 | 8 | 0.57 | +285 | +35.7 |
| REDIRECT WEIGHED | 8 | 8 | 8 | 0.57 | +526 | +65.8 |
| WHO HITS BACK | 8 | 8 | 8 | 0.57 | +660 | +82.5 |
| CHARGE NOW WEIGHED | 7 | 7 | 7 | 0.50 | +418 | +59.8 |
| FIRE IN ORDER | 7 | 7 | 7 | 0.50 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 7 | 7 | 7 | 0.50 | +394 | +56.2 |
| KEEPS ITS TARGET | 34 | 32 | 7 | 0.50 | +150 | +21.4 |
| WHOLE FIGHT GAIN | 12 | 12 | 7 | 0.50 | +104 | +14.8 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.43 | +953 | +158.8 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 0.43 | +0 | +0.0 |
| HONEST WORTH | 168 | 166 | 6 | 0.43 | +47 | +7.9 |
| LONE WIZARD HOLDS BACK | 8 | 8 | 6 | 0.43 | -1 | -0.2 |
| THROUGH LINE OF FIRE | 6 | 6 | 6 | 0.43 | +251 | +41.9 |
| WOUNDS ON THE RANKS | 20 | 20 | 6 | 0.43 | +68 | +11.3 |
| BEST FACING | 5 | 5 | 5 | 0.36 | +50 | +10.1 |
| BEST OVERALL | 5 | 5 | 5 | 0.36 | +149 | +29.7 |
| BEST PRIZE | 5 | 5 | 5 | 0.36 | -497 | -99.4 |
| CAST JOB | 20 | 20 | 5 | 0.36 | +92 | +18.3 |
| CASTING BLOCK | 6 | 6 | 5 | 0.36 | +178 | +35.6 |
| INVITES THE FIGHT | 17 | 17 | 5 | 0.36 | +39 | +7.7 |
| MARCH ODDS | 5 | 5 | 5 | 0.36 | +19 | +3.9 |
| ADVANCE WORTH | 58 | 58 | 4 | 0.29 | +475 | +118.7 |
| BLOCKED WHEEL | 4 | 4 | 4 | 0.29 | +165 | +41.2 |
| FEATURE BUFFS | 30 | 30 | 4 | 0.29 | +111 | +27.8 |
| HIS TURN DENIED | 12 | 12 | 4 | 0.29 | +86 | +21.6 |
| HUNT IN PAIRS | 14 | 5 | 4 | 0.29 | +226 | +56.5 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.29 | +0 | +0.0 |
| LOST CHARGE | 27 | 27 | 4 | 0.29 | +18 | +4.5 |
| MOVE AND CAST | 4 | 4 | 4 | 0.29 | +184 | +46.0 |
| ONE OBJECTIVE FORMULA | 100 | 70 | 4 | 0.29 | +98 | +24.4 |
| OPENS UP | 4 | 4 | 4 | 0.29 | +101 | +25.4 |
| SAFER THAN THE JOB | 4 | 4 | 4 | 0.29 | +97 | +24.4 |
| SUPPORT NARROWED | 120 | 120 | 4 | 0.29 | -32 | -8.0 |
| SURE REACH TOGETHER | 9 | 9 | 4 | 0.29 | +0 | +0.0 |
| WEARS DOWN | 30 | 28 | 4 | 0.29 | +35 | +8.8 |
| WIDER SPREAD | 81 | 78 | 4 | 0.29 | +19 | +4.7 |
| JOINT CHARGE PLAN | 7 | 7 | 3 | 0.21 | +173 | +57.8 |
| KEEP FALLS | 3 | 3 | 3 | 0.21 | +110 | +36.8 |
| LONG SHOT | 10 | 10 | 3 | 0.21 | +28 | +9.5 |
| MISSILES NEXT TURN | 111 | 71 | 3 | 0.21 | +3 | +1.1 |
| REFUSING RETIRES | 10 | 10 | 3 | 0.21 | -1 | -0.4 |
| STUCK PIVOT | 3 | 3 | 3 | 0.21 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.21 | -62 | -20.6 |
| TIED UP BY THE SUM | 6 | 6 | 3 | 0.21 | +59 | +19.7 |
| WALKS TO THE FIGHT | 14 | 14 | 3 | 0.21 | +16 | +5.5 |
| CARRIES OUT SET-UP | 10 | 10 | 2 | 0.14 | -109 | -54.3 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.14 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.14 | -3 | -1.3 |
| EDGE GIVE GROUND | 4 | 4 | 2 | 0.14 | +68 | +33.8 |
| GUN MASK | 6 | 6 | 2 | 0.14 | +280 | +140.1 |
| MAKE SURE TOGETHER | 17 | 6 | 2 | 0.14 | +429 | +214.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.14 | +55 | +27.7 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.14 | +110 | +55.1 |
| NEARER NOT NEEDED | 61 | 58 | 2 | 0.14 | +140 | +70.2 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.14 | +59 | +29.5 |
| OVERRUNS AWAY | 10 | 10 | 2 | 0.14 | +74 | +37.1 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.14 | +56 | +28.0 |
| SPELLS IN THE FIGHT | 9 | 9 | 2 | 0.14 | +5 | +2.6 |
| STOPS SHORT OF THE FLANK | 2 | 2 | 2 | 0.14 | +61 | +30.5 |
| WAR ENGINE JOBS | 6 | 6 | 2 | 0.14 | -183 | -91.4 |
| WHOLE FIGHT | 15 | 14 | 2 | 0.14 | +139 | +69.5 |
| BIG CHARACTER SAFETY | 1 | 1 | 1 | 0.07 | +32 | +31.6 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.07 | +0 | +0.0 |
| BLOWS WHERE AIMED | 19 | 15 | 1 | 0.07 | +3 | +2.9 |
| CHARGER SLAIN LOST | 18 | 18 | 1 | 0.07 | +97 | +97.2 |
| DEFENSIVE ARMY | 1 | 1 | 1 | 0.07 | -50 | -49.7 |
| FIGHT TO THE END | 11 | 11 | 1 | 0.07 | +81 | +81.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.07 | +49 | +49.2 |
| HILL BY ITS CHANCE | 14 | 14 | 1 | 0.07 | +65 | +65.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.07 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.07 | +122 | +121.5 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.07 | +76 | +75.6 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 11 | 6 | 0 | 0.00 | - | - |
| BEST PREY | 9 | 9 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 14 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 7 | 7 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 6 | 6 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 13 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 28 | 28 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 140 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GATEWAY ESCAPE | 2 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 32 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 27 | 27 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 42 | 42 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 48 | 48 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 32 | 32 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 5 | 5 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 22 | 22 | 0 | 0.00 | - | - |
| NOT NEEDED | 5 | 5 | 0 | 0.00 | - | - |
| NOT TURNED | 78 | 78 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 40 | 40 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 1174 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 16 | 16 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 19 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 14 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| STABLE ROLE | 186 | 185 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 317 | 317 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 35 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| TURN WORTH | 2 | 2 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 7 | 6 | 0 | 0.00 | - | - |
| WAITS AGAIN | 22 | 22 | 0 | 0.00 | - | - |

### Off best figure: t9-mine-e62ea8a-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.29 | 15.50 | 48.4 |
| CHARGE NOT DECLARED | rule | 0.36 | 1.14 | 88.9 |
| CANNON PLANNED TARGET | rule | 0.86 | 0.36 | 36.0 |
| FALLBACK | gate | - | 0.79 | 47.2 |
| CHARGE NOW FIRST | rule | 0.14 | 0.50 | 25.1 |
| TURN GATE | gate | - | 0.64 | 43.9 |
| BEST PRIZE | rule | 0.14 | 0.21 | 99.4 |
| PATHS CROSS | rule | 0.36 | - | 34.0 |
| SUPPORT NARROWED | rule | 0.21 | 0.07 | 8.0 |
| AFTERMATH BAND | gate | 0.07 | 0.14 | 3.6 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.21 | 20.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.07 | 0.07 | 20.9 |
| CARRIES OUT SET-UP | rule | - | 0.14 | 54.3 |
| MARCH ODDS | rule | - | 0.14 | 4.2 |
| SUPPORT REQUEST | gate | - | 0.14 | 106.2 |
| WAR ENGINE JOBS | rule | 0.07 | 0.07 | 91.4 |
| CHAFF PASSED | rule | - | 0.07 | 2.2 |
| CHARGE NOW WEIGHED | rule | - | 0.07 | 78.8 |
| DEFENSIVE ARMY | rule | - | 0.07 | 49.7 |
| FALLBACK BY WORTH | rule | 0.07 | - | 9.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.07 | - | 7.6 |
| LONE WIZARD HOLDS BACK | rule | - | 0.07 | 1.1 |
| REDIRECT WEIGHED | rule | 0.07 | - | 104.5 |
| REFUSING RETIRES | rule | 0.07 | - | 0.6 |
| WHO HITS BACK | rule | 0.07 | - | 3.9 |

### Plans: t9-mine-e62ea8a-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.9 | 52% | 277 | 179 | 65% |
| Mine | join | 0.9 | 100% | 28 | 0 | 0% |
| Mine | move | 24.6 | 93% | 1275 | 0 | 0% |
| Mine | shoot | 13.0 | 62% | 728 | 1279 | 176% |
| Mine | support | 0.1 | 100% | 0 | 0 | - |
| Opponent | advance | 9.2 | 11% | 160 | 184 | 115% |
| Opponent | charge | 5.2 | 64% | 498 | 570 | 114% |
| Opponent | close in | 5.9 | 30% | 455 | 132 | 29% |
| Opponent | hold | 6.7 | 33% | 465 | 0 | 0% |
| Opponent | join | 0.3 | 100% | 16 | 0 | 0% |
| Opponent | shoot | 10.4 | 65% | 249 | 558 | 224% |
| Opponent | support | 5.6 | 92% | 32 | 0 | 0% |

### Packages: hunt the guns, t9-mine-e62ea8a-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 3 | 0 | 33% | 33% | 0% | 2.0 | 405 | 152 | 33% | 84 |
| Opponent | 0.3 | 4 | 2 | 0% | 50% | 0% | 2.0 | 209 | 101 | 50% | 178 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 14 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 145 |
| Dwarfen Mountain Holds | 0.5 | 3 | 0 | 33% | 33% | 0% | 2.0 | 405 | 152 | 33% | 45 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 66 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 280 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 685 |
| Tomb Kings of Khemri | 1.3 | 4 | 2 | 0% | 50% | 0% | 2.0 | 209 | 101 | 50% | 65 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 530 |

### Battle groups: t9-mine-e62ea8a-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.5 | 33% | 57% | 0% | - | 0% | 0% | 14% | 86% | 0% |
| Opponent | REDIRECT COUNTER | 3.2 | 40% | 72% | 6% | 0% | 12% | 0% | 6% | 82% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t9-mine-e62ea8a-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 8 | 0 (8) | 0 | 0 | 49 | 75% | 2.0 | 0 (2) | 0 (3) | 0 (3) | 0 (7) | 0 (1) |
| Mine | Character | 54 | 30 (54) | 30 | 0 | 68 | 19% | 2.5 | 35 (14) | 69 (15) | 10 (12) | 49 (28) | 13 (13) |
| Mine | Clean-up | 12 | 81 (12) | 63 | 18 | 35 | 67% | 1.5 | 0 (2) | 108 (8) | 74 (2) | 122 (9) | 0 (3) |
| Mine | Fast Hammer | 12 | 21 (12) | 14 | 7 | 63 | 58% | 3.6 | 7 (5) | 54 (4) | 22 (3) | 31 (8) | 0 (4) |
| Mine | Hammer | 30 | 56 (30) | 36 | 21 | 39 | 20% | 2.9 | 14 (5) | 64 (18) | 71 (7) | 60 (23) | 47 (7) |
| Mine | Holder | 10 | 69 (10) | 7 | 62 | 17 | 50% | 3.4 | 103 (4) | 41 (3) | 49 (3) | 135 (5) | 6 (5) |
| Mine | Shooter | 19 | 59 (19) | 6 | 53 | 55 | 0% | 2.1 | 58 (5) | 59 (12) | 61 (2) | 62 (18) | 0 (1) |
| Mine | War machine | 37 | 59 (37) | 59 | 0 | 37 | 11% | 1.0 | 70 (14) | 49 (13) | 53 (10) | 26 (7) | 67 (30) |
| Mine | Wizard | 9 | 74 (9) | 74 | 0 | 10 | 11% | 1.8 | 151 (4) | 0 (1) | 42 (3) | 41 (5) | 179 (3) |
| Opponent | Chaff | 21 | 58 (21) | 7 | 51 | 45 | 24% | 2.8 | 95 (6) | 37 (10) | 45 (5) | 49 (20) | 146 (1) |
| Opponent | Character | 40 | 76 (40) | 76 | 0 | 37 | 25% | 2.7 | 95 (11) | 104 (16) | 39 (7) | 78 (25) | 96 (9) |
| Opponent | Clean-up | 11 | 10 (11) | 0 | 10 | 25 | 36% | 2.6 | 0 (4) | 21 (7) | - | 11 (10) | 0 (1) |
| Opponent | Fast Hammer | 17 | 39 (17) | 29 | 11 | 67 | 18% | 2.6 | 52 (4) | 31 (11) | 62 (2) | 54 (10) | 15 (7) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 16 | 59 (16) | 29 | 29 | 31 | 56% | 2.9 | 0 (2) | 70 (13) | 0 (1) | 75 (10) | 32 (6) |
| Opponent | Holder | 19 | 78 (19) | 5 | 72 | 11 | 26% | 3.3 | 43 (5) | 57 (9) | 171 (5) | 77 (12) | 81 (7) |
| Opponent | Shooter | 17 | 60 (17) | 23 | 37 | 0 | 0% | 2.6 | 31 (6) | 82 (7) | 73 (4) | 72 (13) | 31 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 24 | 41 (24) | 41 | 0 | 42 | 4% | 1.5 | 63 (11) | 53 (5) | 6 (8) | 15 (3) | 45 (21) |
| Opponent | Wizard | 12 | 27 (12) | 27 | 0 | 27 | 0% | 2.2 | 0 (5) | 61 (6) | - | 63 (5) | 0 (6) |

### Charged fights: t9-mine-e62ea8a-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 108 | 82 | 1.2 | 1.0 | 65 | 0 | +65 | 1 of 5 | 5 of 5 | - | +65 |
| Mine | Chaos Dwarfs | 4 | 180 | 232 | 1.8 | 1.0 | 132 | 0 | +132 | 4 of 7 | 5 of 7 | - | +132 |
| Mine | Dwarfen Mountain Holds | 4 | 548 | 391 | 2.2 | 1.0 | 174 | 0 | +174 | 3 of 9 | 8 of 9 | - | +174 |
| Mine | Empire of Man | 2 | 508 | 95 | 1.5 | 1.0 | 63 | 0 | +63 | 0 of 3 | 3 of 3 | - | +63 |
| **Mine** | all armies | 14 | 312 | 215 | 1.7 | 1.0 | 125 | 0 | +125 | 8 of 24 | 21 of 24 | - | +125 |
| Opponent | Dwarfen Mountain Holds | 2 | 144 | 0 | 2.5 | 1.2 | 0 | 12 | -12 | 0 of 5 | 5 of 5 | -60 | +0 |
| Opponent | Empire of Man | 2 | 290 | 250 | 3.5 | 1.0 | 71 | 27 | +44 | 3 of 7 | 4 of 7 | - | +44 |
| Opponent | Grand Cathay | 2 | 382 | 537 | 5.0 | 1.3 | 107 | 0 | +107 | 8 of 10 | 5 of 10 | +132 | +101 |
| Opponent | Kingdom of Bretonnia | 1 | 270 | 401 | 4.0 | 1.2 | 100 | 0 | +100 | 2 of 4 | 3 of 4 | +186 | +72 |
| Opponent | Skaven | 1 | 490 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 3 | 64 | 1410 | 4.7 | 1.4 | 302 | 36 | +266 | 9 of 14 | 10 of 14 | +367 | +191 |
| Opponent | Vampire Counts | 1 | 0 | 580 | 3.0 | 2.0 | 193 | 245 | -51 | 3 of 3 | 1 of 3 | +182 | -168 |
| Opponent | Warriors of Chaos | 2 | 0 | 825 | 3.5 | 1.0 | 236 | 0 | +236 | 6 of 7 | 4 of 7 | - | +236 |
| **Opponent** | all armies | 14 | 184 | 602 | 3.6 | 1.3 | 169 | 30 | +139 | 31 of 50 | 32 of 50 | +252 | +107 |

### Effective charges: t9-mine-e62ea8a-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 2 (net +66) | 1 (net +0) | 0 | 1 (net +0) | 1 | 50% (2 of 4) |
| Mine | Chaos Dwarfs | 7 | 2 (net +0) | 0 | 1 (net +526) | 1 (net +85) | 2 (net +60) | 1 (net +195) | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 9 | 0 | 0 | 0 | 4 (net +35) | 0 | 5 (net +285) | 0 | 0% (0 of 9) |
| Mine | Empire of Man | 3 | 0 | 0 | 0 | 1 (net +45) | 0 | 1 (net +145) | 1 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 2 (net +0) | 0 | 2 (net -30) | 0 | 20% (1 of 5) |
| Opponent | Empire of Man | 7 | 1 (net -189) | 0 | 3 (net +32) | 0 | 0 | 3 (net +135) | 0 | 43% (3 of 7) |
| Opponent | Grand Cathay | 10 | 2 (net +0) | 0 | 4 (net +107) | 1 (net +95) | 0 | 3 (net +184) | 0 | 40% (4 of 10) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +0) | 0 | 0 | 2 (net +143) | 0 | 0 | 1 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 14 | 2 (net +280) | 2 (net +300) | 3 (net +451) | 2 (net +88) | 1 (net +81) | 3 (net +291) | 1 | 23% (3 of 13) |
| Opponent | Vampire Counts | 3 | 1 (net -68) | 0 | 1 (net +182) | 1 (net -268) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Warriors of Chaos | 7 | 1 (net +388) | 0 | 2 (net +446) | 0 | 0 | 1 (net +186) | 3 | 50% (2 of 4) |

### Charged fights, damage counted: t9-mine-e62ea8a-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 410 | 414 | +0 | 30 | 24 | +6 | +1.4 |
| Mine | Effective (55-75%) | 3 | 138 | 123 | +219 | 228 | 9 | +219 | +159.0 |
| Mine | 76-89% | 7 | 119 | 89 | +38 | 61 | 6 | +55 | +46.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 138 | 220 | +220 | 225 | 0 | +225 | +163.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 324 | 60 | +60 | 60 | 0 | +60 | +18.5 |
| Mine | No odds | 2 | 564 | 118 | +98 | 110 | 0 | +110 | +19.5 |
| Mine | All fights | 24 | 206 | 164 | +125 | 138 | 5 | +133 | +64.6 |
| Opponent | Long shot (under 50%) | 8 | 286 | 333 | +86 | 156 | 81 | +75 | +26.2 |
| Opponent | 50-54% | 2 | 303 | 297 | +300 | 300 | 0 | +300 | +99.0 |
| Opponent | Effective (55-75%) | 14 | 454 | 249 | +211 | 254 | 86 | +168 | +37.0 |
| Opponent | 76-89% | 8 | 248 | 144 | +36 | 74 | 34 | +40 | +16.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 316 | 199 | +163 | 231 | 56 | +175 | +55.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 390 | 81 | +81 | 81 | 0 | +81 | +20.8 |
| Opponent | No odds | 5 | 298 | 141 | +77 | 83 | 6 | +77 | +25.8 |
| Opponent | All fights | 50 | 338 | 222 | +139 | 185 | 56 | +129 | +38.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t9-mine-e62ea8a-p2 | move | 118 | 28 (24%) | 22 (19%) | 17 (14%) | 73 (62%) |
| t9-mine-e62ea8a-p2 | objective | 83 | 22 (27%) | 17 (20%) | 13 (16%) | 48 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512, L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810 |
| Witch Hunter's Ward | Opponent | L0307 |

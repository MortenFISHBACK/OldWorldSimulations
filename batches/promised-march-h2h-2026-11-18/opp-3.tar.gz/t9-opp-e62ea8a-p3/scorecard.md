# Doctrine scorecard: t9-opp-e62ea8a-p3

### Scorecard: t9-opp-e62ea8a-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 291 |
| L0126 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 10 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Mine | no | 3 | - | 0 | 4 | 0 | 0 | 0 | 200 |
| L0226 | 4 | 1 | Opponent | no | 4 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | 4 | 5 | 0 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 3 | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 4 | 0 | 2 | 0 | 0 | 0 | 70 |
| L0429 | 3 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0516 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 18 | 3 | 2 | 1 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | no | - | 3 | 0 | 5 | 0 | 0 | 0 | 19 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 16 | 2 | 6 | 0 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 250 |
| L0725 | 5 | 1 | Mine | no | - | 3 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Opponent | yes | - | 4 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | yes | - | - | 0 | 0 | 0 | 0 | 0 | 560 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 5 | 4 | 1 | 3 | 1 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 560 |
| L0922 | 4 | 1 | Opponent | yes | 1 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 4 | 2 | 2 | 0 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 0 | 5 | 5 | 0 | 0 | 0 | 0 | 492 |
| L1030 | 4 | 1 | Opponent | no | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 4 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 4 | 2 | 3 | 0 | 2 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 100 |
| **Average** | | | Mine | 28% | 3.2 | 3.0 | 2.0 | 1.1 | 0.1 | 0.0 | 0.0 | 375.1 |
| **Average** | | | Opponent | 28% | 4.2 | 2.8 | 1.9 | 2.3 | 0.2 | 0.0 | 0.0 | 97.5 |

### KPIs: t9-opp-e62ea8a-p3

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 20 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 45% (41 of 91) | 0% (0 of 98) | 22% (41 of 189) |
| Winner chose to follow up after the loser gave ground |  | 100% (21 of 21); on the table 100% | 89% (24 of 27); on the table 89% | 94% (45 of 48); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (3 of 6); on the table 50% | 50% (1 of 2); on the table 50% | 50% (4 of 8); on the table 50% |
| Winner chose to pursue after the loser fled |  | 50% (7 of 14); on the table 50% | 83% (10 of 12); on the table 92% | 65% (17 of 26); on the table 69% |
| Winner chose to follow up or pursue (all three) |  | 76% (31 of 41); on the table 76% | 85% (35 of 41); on the table 88% | 80% (66 of 82); on the table 82% |
| Magic missiles tried each own turn | 50%+ | 31% (77 of 246) | 35% (57 of 162) | 33% (134 of 408) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (77 of 200) | 43% (57 of 134) | 40% (134 of 334) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | 67% (18 of 27) | 62% (21 of 34) |
| Points that never fought | lower | 57% (22029 of 38695) | 57% (22970 of 39993) | 57% (44999 of 78688) |
|   infantry points that never fought | lower | 65% (5830 of 8962) | 65% (5714 of 8747) | 65% (11544 of 17709) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (106 of 162) | 62% (93 of 149) | 64% (199 of 311) |
| Bound items with a magic missile used (at least once a game) |  | 100% (15 of 15); 2.1 uses a game | 92% (12 of 13); 1.5 uses a game | 96% (27 of 28); 1.8 uses a game |
| Bound items with another spell used |  | 50% (3 of 6); 0.7 uses a game | 17% (1 of 6); 0.1 uses a game | 33% (4 of 12); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (10 of 16); 0.5 uses a game | 62% (5 of 8); 0.2 uses a game | 62% (15 of 24); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (19511 of 32385) | 55% (19483 of 35143) | 58% (38994 of 67528) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.0 (47%) | 2.1 (40%) | 6.0 (44%) |
| MARCHED: its unit marched | 1.1 (13%) | 1.1 (22%) | 2.2 (16%) |
| CHARGED: its unit charged | 0.6 (7%) | 0.3 (6%) | 0.9 (7%) |
| IN COMBAT: engaged in combat | 1.6 (20%) | 0.9 (17%) | 2.5 (19%) |
| REAR RANK: in a rear rank | 0.3 (4%) | 0.3 (6%) | 0.6 (4%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| GONE: slain | 0.5 (5%) | 0.5 (10%) | 0.9 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 1.9 | 2.8 | 6.7 | 0.8 | 1.1 |
| not cast | 2.5 | 1.3 | 4.2 | 13.7 | 2.8 | 19.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (81%) | 0.7 (17%) | 6.0 (44%) | 0.3 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (16%) | 0.3 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (7%) | 0.2 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (8%) | 0.5 (11%) | 2.5 (19%) | 0.7 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.8 (19%) | 0.6 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.3 (12%) | 0.0 (0%) | 0.1 (2%) | 0.9 (7%) | 0.1 (4%) | 1.1 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.2 (6%) | 0.2 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (6%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 1.1 (40%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (76%) | 0.1 (8%) | 1.9 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.9 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 1.3 a game | 1.6 a game |
| stood (cast and not dispelled) | 50% (18 of 36) | 50% (10 of 20) | 50% (28 of 56) |
| the unit moved after it | 61% (11 of 18) | 100% (10 of 10) | 75% (21 of 28) |
| it charged on its next turn | 0% (0 of 18) | 10% (1 of 10) | 4% (1 of 28) |
| the enemy charged it first | 11% (2 of 18) | 0% (0 of 10) | 7% (2 of 28) |
| it fought by the end of its next turn | 6% (1 of 18) | 0% (0 of 10) | 4% (1 of 28) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (2 of 18) | 20% (2 of 10) | 14% (4 of 28) |
| none of these (no charge, no fight, no charge escaped) | 78% (14 of 18) | 70% (7 of 10) | 75% (21 of 28) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (345 of 494) | 56% (222 of 395) | 64% (567 of 889) |
|   cavalry | 69% (24 of 35) | 65% (31 of 48) | 66% (55 of 83) |
|   character | 81% (39 of 48) | 36% (28 of 77) | 54% (67 of 125) |
|   chariot | 58% (42 of 72) | 50% (15 of 30) | 56% (57 of 102) |
|   infantry | 62% (62 of 100) | 61% (88 of 145) | 61% (150 of 245) |
|   monster | 44% (4 of 9) | 100% (2 of 2) | 55% (6 of 11) |
|   war machine | 76% (174 of 230) | 62% (58 of 93) | 72% (232 of 323) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.6 (22%) | 2.0 (24%) | 3.7 (23%) |
| CHARGED: it charged | 0.6 (7%) | 1.2 (14%) | 1.8 (11%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.3 (5%) | 0.2 (3%) | 0.6 (4%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.5 (6%) | 0.6 (3%) |
| NO TARGET IN RANGE | 1.1 (14%) | 1.9 (21%) | 2.9 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (5%) | 0.2 (3%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.6 (36%) | 1.9 (21%) | 4.5 (28%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.3 (4%) | 0.5 (3%) |
| OTHER BAR | 0.7 (9%) | 0.2 (3%) | 0.9 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.5 | 1.8 | 74% | 9.8 pts | 45 pts |
| character | 3.9 | 1.7 | 74% | 9.9 pts | 38 pts |
| chariot | 2.9 | 1.2 | 70% | 9.9 pts | 28 pts |
| infantry | 11.3 | 3.2 | 82% | 7.2 pts | 81 pts |
| monster | 0.5 | 0.2 | 56% | 15.4 pts | 7 pts |
| war machine | 11.7 | 9.8 | 64% | 22.7 pts | 266 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 3.6 | 3.3 |
| Charges that made contact a game | 2.2 | 2.0 | 2.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.25 declared, 0.69 contact (16 units) | 0.83 declared, 0.56 contact (18 units) | 1.03 declared, 0.62 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.00 contact (1 units) | 1.40 declared, 0.20 contact (5 units) | 1.33 declared, 0.17 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.28 contact (121 units) | 0.36 declared, 0.21 contact (140 units) | 0.34 declared, 0.25 contact (261 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 69% (22 of 32) | 56% (5 of 9) | 50% (2 of 4) | 64% (29 of 45) |
| Character in a unit | 88% (28 of 32) | 71% (10 of 14) | 100% (1 of 1) | 83% (39 of 47) |
| Character on its own | 73% (8 of 11) | 61% (14 of 23) | 31% (10 of 32) | 48% (32 of 66) |
| Chariot | 86% (6 of 7) | 75% (9 of 12) | - | 79% (15 of 19) |
| Infantry | 55% (23 of 42) | 52% (13 of 25) | 50% (2 of 4) | 54% (38 of 71) |
| Monster | 75% (9 of 12) | 33% (1 of 3) | - | 67% (10 of 15) |
| Monstrous | 100% (1 of 1) | 75% (3 of 4) | - | 80% (4 of 5) |
| War Machines | 76% (31 of 41) | 50% (1 of 2) | - | 74% (32 of 43) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 50% (3 of 6); on the table 50% | 27% (26 of 96) | 68% | 55% (12 of 22) | 100% (6 of 6); 5.5 uses a game | 100% (2 of 2); 1.8 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 83% (5 of 6); on the table 83% | 50% (18 of 36) | 49% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | - | - | 76% | 88% (21 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 53% (8 of 15); on the table 53% | 37% (11 of 30) | 49% | 69% (41 of 59) | 0.0 uses a game | 50% (1 of 2); 1.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 7 | 95% (20 of 21); on the table 95% | 34% (59 of 174) | 48% | 62% (40 of 65) | 100% (15 of 15); 5.1 uses a game | 25% (1 of 4); 0.1 uses a game | 29% (2 of 7); 0.3 uses a game |
| High Elf Realms | 3 | 60% (3 of 5); on the table 80% | 28% (5 of 18) | 55% | 74% (17 of 23) | 75% (3 of 4); 2.7 uses a game | 0% (0 of 4); 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (4 of 4); on the table 100% | - | 62% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 50% (3 of 6) | 15% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 86% (6 of 7); on the table 86% | 17% (1 of 6) | 47% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 100% (6 of 6); on the table 100% | 27% (8 of 30) | 81% | 68% (15 of 22) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 100% (11 of 11); on the table 100% | 0% (0 of 6) | 44% | 52% (13 of 25) | 100% (1 of 1); 1.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Wood Elf Realms | 1 | - | 50% (3 of 6) | 100% | 90% (9 of 10) | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t9-opp-e62ea8a-p3, 20 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (13) | 41% (12) | 44% (25) |
| ...free all their last turn and able to turn (per game) | 0.45 | 0.30 | 0.75 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.10 | 0.10 | 0.20 |
| ...with the charger already in that arc before they moved (per game) | 0.20 | 0.10 | 0.30 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.05 | 0.00 | 1.05 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.60 | 0.00 | 0.60 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.85 | 0.05 | 4.90 |

### Quality by phase: t9-opp-e62ea8a-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 2.8 |
| Strategy | Charge objectives carried out (made contact) | 52% (28 of 54) | 43% (29 of 67) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (145 of 308) | 49% (55 of 112) |
| Strategy | Close-in objectives charged next turn | 12% (11 of 93) | - |
| Strategy | Support requests answered (helper made contact too) | 40% (2 of 5) | 40% (2 of 5) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 88% (7 of 8) | 0% (0 of 5) |
| Strategy | Joined characters whose unit fought | 28% (13 of 47) | 21% (5 of 24) |
| Strategy | Lone characters that fought | 58% (23 of 40) | 59% (29 of 49) |
| Movement | Charges halted short of contact | 0.1 | 0.0 |
| Movement | Idle units | 1.1 | 2.3 |
| Movement | Points that never moved of their own | 375.1 | 97.5 |
| Movement | Fights charged into per game | 1.9 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 37, net -14 | 3 of 36, net +105 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 37, net -49 | 6 of 36, net +127 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 37, net +28 | 9 of 36, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 11 of 37, net +121 | 7 of 36, net +131 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.9 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (94 of 178) | 49% (86 of 177) |
| Shooting | Points destroyed by shooting units | 86.0 | 15.0 |
| Shooting | War machine shots | 8.7 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (74 of 174) | 35% (21 of 60) |
| Shooting | Points destroyed by war machines | 92.2 | 19.2 |
| Magic | Magic missiles cast | 2.4 | 2.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (19 of 48) | 23% (10 of 43) |
| Magic | Wounds caused by magic missiles | 5.2 | 2.5 |
| Magic | Wounds caused by other spells | 1.2 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 72.3 | 35.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.4 / 0.3 / 0.2 | 2.3 / 0.3 / 0.2 / 0.3 |
| Combat | Points destroyed in combat | 158.9 | 288.6 |
| Combat | Points run down | 31.8 | 46.7 |
| Combat | Net points per charged fight, damage counted | +74 | +113 |
| Combat | Net per 100 charger points, damage counted | +24.4 | +34.0 |
| Combat | First round won (charged fights) | 74% | 80% |
| Combat | Net points per charged fight | +68 | +107 |
| Combat | Net points per supported fight / lone fight | +95 / +63 | +265 / +103 |
| Combat | Charged fights on a top-3 enemy unit | 16 of 39 | 14 of 40 |
| Game | Points lost | 497.2 | 498.2 |
| Game | VP from objectives | 554.5 | 624.5 |
| Game | Lone holders (player turns) | 3.2 | 4.2 |

- Mine won / drew / lost: 5 / 8 / 7 of 20 ended games (of 20); mean margin (Mine - Opponent) -33 VP
- The side that went first won 5 of 12 games with a winner
- Points traded per game (both sides' losses): 995
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t9-opp-e62ea8a-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 15.7 |
| ADVANCE WORTH | 5.3 | -127.8 | 157.9 | 45.2 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.1 | +44.4 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 38.8 | 0.3 | +0.0 | 0.0 | 6.2 |
| BACKUP TARGETS | 0.5 | +3.5 | 0.0 | 6.8 | 0.2 | +0.3 | 0.0 | 0.0 |
| BEST FACING | 0.3 | +14.1 | 0.0 | 2.6 | - | - | - | - |
| BEST FIRST | 1.1 | +30.3 | 9.3 | 9.4 | - | - | - | - |
| BEST MOVE FOR SHOOTERS | 1.1 | +53.2 | 0.0 | 10.4 | - | - | - | - |
| BEST OVERALL | 0.2 | +12.5 | 0.0 | 2.6 | - | - | - | - |
| BEST PREY | 1.0 | +33.6 | 35.0 | 17.0 | - | - | - | - |
| BEST PRIZE | 0.1 | +1.2 | 0.0 | 0.0 | 0.1 | -5.9 | 3.2 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.5 | +7.4 | 0.0 | 2.6 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | -6.1 | 17.0 | 15.5 | 0.2 | -48.0 | 21.1 | 9.8 |
| BOMBING RUN | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 37.5 | 12.5 | 0.2 | +0.0 | 5.8 | 6.2 |
| CANNON PLANNED TARGET | 8.8 | +216.6 | 327.9 | 212.0 | 2.0 | +58.7 | 84.7 | 21.5 |
| CANNON SIGHT KEPT | 1.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -11.6 | 28.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.1 | +18.6 | 38.5 | 0.0 | 0.6 | +11.8 | 31.8 | 13.9 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +63.0 | 64.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.6 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.9 | +59.8 | 0.0 | 39.2 | 0.3 | +17.6 | 0.0 | 12.1 |
| CHAFF PASSED | 0.1 | -0.2 | 5.5 | 0.0 | 0.2 | -0.9 | 0.0 | 16.3 |
| CHARACTER GUNS | - | - | - | - | 0.8 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 7.0 | -407.1 | 0.0 | 206.2 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 34.6 | 3.2 | 0.5 | +0.0 | 28.8 | 0.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 194.1 | 43.6 | 1.6 | +0.0 | 126.7 | 6.3 |
| CHARGE NOW WEIGHED | 0.1 | -7.9 | 0.0 | 0.0 | - | - | - | - |
| CHARGER SLAIN LOST | 0.1 | -5.9 | 41.3 | 3.0 | 0.1 | -0.8 | 20.2 | 2.2 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CHEAPEST HOLDER | - | - | - | - | 0.3 | -31.8 | 12.5 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 33.0 | 0.2 | +0.0 | 5.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.1 | +88.2 | 0.0 | 0.0 | 0.8 | +19.9 | 0.0 | 0.0 |
| COVER ONCE | 9.4 | -705.7 | 0.0 | 124.2 | 6.5 | -487.0 | 0.0 | 160.3 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 4.0 | 4.8 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.2 | -2.0 | 0.0 | 26.5 | 7.2 | +41.5 | 0.0 | 43.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +0.8 | 10.1 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.1 | +49.9 | 0.0 | 23.6 | - | - | - | - |
| FALL BACK GOOD ORDER | - | - | - | - | 2.2 | +3.3 | 145.8 | 20.3 |
| FALLBACK BY WORTH | 4.3 | +47.8 | 0.0 | 31.9 | 0.3 | +2.2 | 0.0 | 16.9 |
| FALLS SHORT | - | - | - | - | 17.9 | +240.9 | 0.0 | 212.0 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +11.6 | 0.0 | 5.0 |
| FIGHT LIFT | 0.1 | +0.8 | 0.0 | 0.0 | 0.1 | +0.6 | 6.3 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.1 | +101.3 | 79.3 | 16.1 |
| FIRE IN ORDER | 0.1 | +0.0 | 5.8 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | - | - | - | - | 42.8 | +2294.7 | 413.6 | 559.0 |
| FLANK NOT WEIGHED | 4.5 | +0.0 | 0.0 | 92.5 | 4.8 | +0.0 | 0.0 | 112.0 |
| FOLLOW UP WEIGHED | 0.9 | +113.9 | 0.0 | 3.0 | 0.8 | +181.4 | 0.0 | 23.2 |
| FOUR ROUNDS | - | - | - | - | 3.2 | +353.1 | 238.5 | 20.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -3.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.4 | -22.2 | 0.0 | 5.8 |
| FRIENDS SHOTS CHECKED | 0.1 | +4.2 | 0.0 | 3.0 | 0.2 | +7.9 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.0 | 8.5 | 0.0 | 0.4 | -4.7 | 14.4 | 9.8 |
| GROUND FLIERS | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.1 | +13.1 | 11.7 | 15.5 | 0.3 | +16.9 | 0.0 | 3.2 |
| GUN MASK | - | - | - | - | 0.3 | +6.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 0.6 | +0.0 | 0.0 | 10.6 |
| HE SHOOTS OR CHARGES | - | - | - | - | 2.4 | +0.0 | 0.0 | 90.5 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 4.8 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 9.4 | - | - | - | - |
| HILL BY ITS CHANCE | 0.2 | -15.5 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +17.0 | 22.1 | 0.0 |
| HIS CHARGE LIST | - | - | - | - | 2.4 | +0.0 | 0.0 | 21.8 |
| HIS LEGAL MOVES | - | - | - | - | 3.8 | +0.0 | 0.0 | 50.2 |
| HIS MOVE AND SHOT | - | - | - | - | 1.6 | -38.0 | 0.0 | 36.0 |
| HIS RANDOM MOVE | - | - | - | - | 0.9 | +0.0 | 0.0 | 16.8 |
| HIS SHOT LIST | - | - | - | - | 25.6 | +1721.9 | 0.0 | 409.3 |
| HIS TURN DENIED | - | - | - | - | 1.6 | +64.4 | 149.2 | 8.6 |
| HOLDER AT DEPLOYMENT | 0.6 | +106.3 | 0.0 | 0.0 | 0.8 | +141.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.8 | -135.2 | 383.4 | 100.8 | 3.0 | -159.7 | 208.8 | 16.1 |
| HORN WORTH | - | - | - | - | 0.1 | +0.9 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.5 | +23.4 | 8.2 | 8.5 | - | - | - | - |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 8.1 | - | - | - | - |
| HUNT IN PAIRS | - | - | - | - | 0.2 | +8.1 | 0.0 | 19.5 |
| HUNT KEPT | 0.3 | +8.5 | 8.2 | 4.2 | - | - | - | - |
| HUNT RESULT | 0.2 | +11.1 | 0.0 | 8.1 | 0.1 | +9.2 | 0.0 | 2.2 |
| HUNT THE GUNS | 0.3 | +120.3 | 8.2 | 4.2 | 0.1 | +11.3 | 7.0 | 2.2 |
| IDLE COST | 15.3 | -257.3 | 0.0 | 91.4 | 11.4 | -194.8 | 0.0 | 243.2 |
| INVITES THE FIGHT | 1.1 | +4.6 | 34.5 | 24.4 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.2 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.3 | +39.0 | 155.3 | 26.5 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +80.7 | 116.4 | 6.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT NEXT TURN | 4.6 | +121.4 | 170.1 | 55.3 | - | - | - | - |
| LANE BY FIGURES | 0.6 | +21.4 | 0.0 | 0.0 | 1.2 | +52.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 4.8 | +0.0 | 202.3 | 182.5 |
| LONE CHARACTER SAFE SPOT | 0.5 | +13.1 | 17.9 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.8 | +57.8 | 0.0 | 0.0 | 0.5 | +41.3 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +2.3 | 8.5 | 3.2 | 0.1 | -4.8 | 3.2 | 6.3 |
| LOST CHARGE | 2.8 | -51.3 | 101.5 | 72.3 | 0.1 | -0.1 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.2 | -16.4 | 0.0 | 16.4 | - | - | - | - |
| MAKE SURE TOGETHER | 0.8 | +32.5 | 24.8 | 6.8 | - | - | - | - |
| MANOEUVRE | 0.2 | +4.2 | 0.0 | 0.0 | 1.1 | +9.1 | 0.0 | 19.9 |
| MARCH AT ESCAPER | 0.3 | +2.7 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.4 | +14.1 | 0.0 | 9.9 |
| MARCH CHECK | 0.2 | +0.4 | 0.0 | 0.0 | 1.1 | +65.4 | 0.0 | 39.9 |
| MARCH ODDS | 0.2 | +9.3 | 10.2 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.5 | +26.2 | 0.0 | 0.0 | 0.8 | +6.4 | 0.0 | 9.9 |
| MAX FOR POSITIONING | 6.2 | +89.2 | 0.0 | 107.2 | 5.8 | +69.2 | 0.0 | 114.0 |
| MISSILES IN THE MOVE | 6.0 | +194.9 | 0.0 | 48.2 | 4.5 | +80.2 | 0.0 | 76.8 |
| MISSILES NEXT TURN | 6.7 | +143.1 | 0.0 | 48.2 | 6.0 | +50.6 | 0.0 | 116.7 |
| MODEL FACING | 0.1 | +15.4 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.6 | +20.8 | 0.0 | 4.2 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.6 | +15.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.8 | -31.0 | 0.0 | 0.0 | 0.3 | -9.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 4.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.5 | +130.2 | 131.7 | 69.4 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 4.0 | +554.3 | 0.0 | 52.2 |
| MOVES UNITS SPELL | 0.1 | +5.5 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | - | - | - | - | 4.0 | +202.6 | 0.0 | 39.5 |
| NEEDED THERE | 0.1 | +14.6 | 0.0 | 0.0 | 0.1 | +6.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 5.2 | -208.9 | 9.5 | 75.2 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 8.3 | -364.2 | 19.9 | 81.7 |
| NO DOUBLE ROUNDS | - | - | - | - | 2.4 | -81.7 | 161.4 | 18.3 |
| NOT NEEDED | 0.1 | -3.3 | 8.2 | 0.0 | - | - | - | - |
| NOT TURNED | 4.8 | +38.4 | 0.0 | 104.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 16.6 | -649.3 | 0.0 | 193.8 | 0.6 | -15.9 | 0.0 | 21.9 |
| ONE CHARGE A CHARGER | - | - | - | - | 2.4 | +0.0 | 0.0 | 59.8 |
| ONE FIGHT FORMULA | 8.1 | -126.2 | 31.3 | 110.7 | 4.8 | -120.7 | 0.0 | 50.2 |
| ONE OBJECTIVE FORMULA | 2.6 | -132.6 | 0.0 | 23.6 | 2.8 | -1.6 | 0.0 | 25.9 |
| ONE TARGET A SHOOTER | - | - | - | - | 18.9 | +645.2 | 0.0 | 276.2 |
| OPENS A LANE | 0.3 | +1.1 | 28.6 | 0.0 | 0.2 | +1.3 | 6.2 | 0.0 |
| OPENS UP | 0.2 | +15.1 | 18.3 | 0.0 | 0.1 | +5.5 | 13.0 | 0.0 |
| OVERRUN THREAT | 0.1 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.8 | +12.8 | 52.8 | 6.0 | 0.5 | +42.3 | 46.1 | 0.0 |
| PATHS CROSS | 1.6 | +115.2 | 0.0 | 10.7 | 4.5 | +121.1 | 0.0 | 30.4 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +2.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.1 | 0.0 | 4.2 | 0.2 | -1.1 | 0.0 | 6.8 |
| PLAN RESULT | 38.7 | +1299.6 | 962.6 | 730.2 | 38.4 | +423.6 | 167.1 | 613.0 |
| PURSUES BIG PREY | 0.1 | -12.1 | 0.0 | 0.0 | 0.1 | -4.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.3 | +0.8 | 0.0 | 8.5 | 1.4 | +39.8 | 0.0 | 34.0 |
| RANDOM MOVER NO PROMISE | 0.1 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.7 | -18.3 | 0.0 | 18.9 | 0.2 | +0.4 | 0.0 | 17.0 |
| REDIRECT COUNTER | 1.6 | +96.8 | 0.0 | 50.0 | 2.6 | +282.3 | 0.0 | 37.6 |
| REDIRECT WEIGHED | 0.1 | +2.9 | 0.0 | 0.0 | 0.2 | +3.7 | 11.8 | 2.2 |
| REFORMS TO MEET IT | - | - | - | - | 0.3 | -9.9 | 0.0 | 13.8 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +23.2 | 0.0 | 7.5 | 0.8 | +33.4 | 0.0 | 7.2 |
| RESTRAINS TO SHOOT | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.2 | +75.8 | 197.7 | 34.2 | 2.1 | -31.3 | 143.6 | 20.3 |
| RISK BY HIS FIGURE | - | - | - | - | 13.3 | -283.4 | 0.0 | 317.9 |
| RISK ONCE | 5.7 | +217.6 | 63.0 | 127.7 | - | - | - | - |
| RUN DOWN | - | - | - | - | 2.6 | -27.7 | 170.4 | 18.3 |
| SAFE SURE CHARGE | 0.1 | -6.9 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.6 | +31.8 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +1.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.7 | 0.0 | 0.0 | 0.2 | -15.3 | 0.0 | 1.9 |
| SEARCH SPOT | 2.9 | +109.4 | 0.0 | 6.8 | 6.1 | +221.9 | 0.0 | 63.3 |
| SECOND HUNTER | 0.1 | -8.5 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | - | - | - | - | 0.3 | +103.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.4 | +75.2 | 24.8 | 24.4 | 0.1 | +0.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +149.2 | 0.0 | 0.0 | 0.1 | +7.0 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +25.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +57.3 | 28.4 | 8.5 | 0.8 | +36.0 | 5.2 | 3.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.2 | -8.4 | 12.3 | 8.1 |
| SHOT RISK POINTS | - | - | - | - | 12.4 | -42.3 | 0.0 | 275.3 |
| SHOTS IN THE MOVE | 16.2 | +665.0 | 0.0 | 278.9 | 11.6 | +417.7 | 0.0 | 111.5 |
| SPELL CATCH ODDS | 0.1 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.8 | +180.5 | 0.0 | 0.0 | 0.1 | +7.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +13.4 | 65.4 | 0.0 | 2.8 | +44.8 | 77.7 | 64.7 |
| SPELLS IN THE FIGHT | 0.6 | -1.9 | 52.7 | 0.0 | 0.4 | -0.1 | 14.5 | 0.0 |
| STABLE ROLE | 11.3 | +0.0 | 271.2 | 93.0 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.6 | -7.3 | 47.6 | 6.3 |
| STANDS FOR A REASON | - | - | - | - | 0.6 | +0.0 | 9.8 | 0.0 |
| STANDS STILL | - | - | - | - | 11.1 | +0.0 | 170.8 | 110.4 |
| STAY WEIGHED | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 21.6 | -25.5 | 415.2 | 259.4 | 11.2 | +82.7 | 106.6 | 112.4 |
| STOPS | - | - | - | - | 0.1 | +0.1 | 7.0 | 2.2 |
| STOPS SHORT OF THE FLANK | 0.1 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 8.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.7 | -38.0 | 201.9 | 69.8 | 0.9 | +0.0 | 65.1 | 0.0 |
| SUPPORTS | 3.4 | +55.0 | 103.8 | 25.3 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -0.1 | 2.8 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.3 | -2.1 | 0.0 | 0.0 | 0.2 | +2.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 4.8 | +0.0 | 0.0 | 30.4 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -21.0 | 0.0 | 13.8 |
| THE PROMISED MOVE | - | - | - | - | 0.6 | +0.0 | 0.0 | 13.8 |
| THROUGH LINE OF FIRE | 0.6 | +35.4 | 0.0 | 3.2 | - | - | - | - |
| TIED UP BY THE SUM | - | - | - | - | 0.8 | +91.7 | 57.5 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 5.0 | +89.0 | 2.8 | 64.5 |
| TURN WORTH | 0.3 | -18.3 | 34.4 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.3 | +1.8 | 8.2 | 0.0 | - | - | - | - |
| WAIT AFTER COSTS | 6.8 | -228.5 | 261.6 | 113.5 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 0.9 | +0.0 | 0.0 | 14.8 |
| WALKS TO THE FIGHT | 1.9 | +13.4 | 82.1 | 19.7 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +10.5 | 0.0 | 15.5 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 16.5 | 17.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 0.8 | +27.8 | 83.5 | 41.2 | - | - | - | - |
| WHO HITS BACK | 0.2 | +15.5 | 0.0 | 0.0 | 0.5 | +71.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | -11.2 | 31.8 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +12.0 | 9.6 | 6.2 | 0.2 | +12.0 | 22.8 | 2.2 |
| WIDER SPREAD | 1.8 | -9.9 | 175.8 | 44.5 | 2.5 | -8.1 | 176.2 | 12.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.5 | +77.9 | 0.0 | 9.6 |

### Rule changes: t9-opp-e62ea8a-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 344 | 344 | 344 | 17.20 | -13304 | -38.7 |
| DEPLOY BY FIGURES | 307 | 307 | 207 | 10.35 | +3316 | +16.0 |
| SEARCH SPOT | 180 | 180 | 173 | 8.65 | +6627 | +38.3 |
| HIS SHOT LIST | 513 | 513 | 146 | 7.30 | +5579 | +38.2 |
| PATHS CROSS | 123 | 123 | 123 | 6.15 | +4726 | +38.4 |
| FIVE ACTION | 855 | 855 | 102 | 5.10 | +3363 | +33.0 |
| LEGAL CHARGES ONLY | 96 | 96 | 96 | 4.80 | +0 | +0.0 |
| ONE TARGET A SHOOTER | 378 | 378 | 90 | 4.50 | +1414 | +15.7 |
| ARTILLERY RE-ROLL WEIGHED | 67 | 67 | 67 | 3.35 | +0 | +0.0 |
| SHOT RISK POINTS | 249 | 249 | 53 | 2.65 | +2326 | +43.9 |
| COVER ONCE | 318 | 206 | 51 | 2.55 | +630 | +12.4 |
| MOVE TO CHARGE COMPUTED | 79 | 79 | 47 | 2.35 | +3399 | +72.3 |
| SHOTS IN THE MOVE | 556 | 454 | 45 | 2.25 | +1144 | +25.4 |
| IDLE COST | 536 | 349 | 40 | 2.00 | +388 | +9.7 |
| FOUR ROUNDS | 65 | 65 | 38 | 1.90 | +2273 | +59.8 |
| CANNON SIGHT KEPT | 37 | 37 | 37 | 1.85 | +0 | +0.0 |
| LANE BY FIGURES | 36 | 36 | 36 | 1.80 | +1482 | +41.2 |
| MISSILES IN THE MOVE | 209 | 144 | 36 | 1.80 | +722 | +20.1 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 1.75 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 166 | 166 | 35 | 1.75 | +578 | +16.5 |
| FOLLOW UP WEIGHED | 34 | 34 | 34 | 1.70 | +5907 | +173.7 |
| MAX FOR POSITIONING | 242 | 199 | 32 | 1.60 | +131 | +4.1 |
| MOVE TO CHARGE | 70 | 70 | 32 | 1.60 | +897 | +28.0 |
| KILLS COUNT NEXT TURN | 92 | 92 | 30 | 1.50 | +802 | +26.7 |
| RISK ONCE | 113 | 88 | 29 | 1.45 | +1028 | +35.4 |
| REDIRECT COUNTER | 84 | 66 | 27 | 1.35 | +2480 | +91.9 |
| SHOOTS FROM THE BEST SPOT | 44 | 44 | 27 | 1.35 | +540 | +20.0 |
| STAY WORTH | 654 | 589 | 27 | 1.35 | +268 | +9.9 |
| RESERVE FALL BACK | 26 | 26 | 26 | 1.30 | +1132 | +43.5 |
| WAIT AFTER COSTS | 136 | 136 | 26 | 1.30 | +441 | +16.9 |
| LONE WIZARD KEPT IN | 25 | 25 | 25 | 1.25 | +1980 | +79.2 |
| CANNON PLANNED TARGET | 217 | 217 | 24 | 1.20 | +4 | +0.2 |
| BEST MOVE FOR SHOOTERS | 23 | 23 | 23 | 1.15 | +1064 | +46.3 |
| BEST FIRST | 22 | 22 | 22 | 1.10 | +606 | +27.5 |
| FALLBACK BY WORTH | 93 | 93 | 22 | 1.10 | +1000 | +45.5 |
| FACES THE THREAT | 21 | 21 | 21 | 1.05 | +999 | +47.6 |
| RANDOM MOVE BY FIGURES | 34 | 34 | 21 | 1.05 | +812 | +38.7 |
| SUPPORTS | 67 | 67 | 20 | 1.00 | +377 | +18.8 |
| ONE FIGHT FORMULA | 259 | 156 | 19 | 0.95 | +66 | +3.5 |
| MARCH CHECK | 25 | 25 | 18 | 0.90 | +315 | +17.5 |
| RISK BY ARC | 88 | 86 | 18 | 0.90 | +507 | +28.2 |
| CHAFF IN THE MOVE | 25 | 24 | 17 | 0.85 | +352 | +20.7 |
| CHARGE NOT DECLARED | 17 | 17 | 17 | 0.85 | -1693 | -99.6 |
| RISK BY HIS FIGURE | 267 | 267 | 17 | 0.85 | +1003 | +59.0 |
| HOLDS AMBUSHERS | 16 | 16 | 16 | 0.80 | +0 | +0.0 |
| CHARGE LOSSES | 140 | 140 | 15 | 0.75 | +1154 | +76.9 |
| KILLS COUNT | 32 | 30 | 15 | 0.75 | +566 | +37.8 |
| MANOEUVRE | 28 | 28 | 15 | 0.75 | +289 | +19.3 |
| TIED UP BY THE SUM | 16 | 16 | 15 | 0.75 | +489 | +32.6 |
| WHO HITS BACK | 15 | 15 | 15 | 0.75 | +1233 | +82.2 |
| CAST JOB | 33 | 33 | 14 | 0.70 | +54 | +3.8 |
| HONEST WORTH | 216 | 214 | 14 | 0.70 | +165 | +11.8 |
| SCOUT WAITS | 14 | 14 | 14 | 0.70 | +0 | +0.0 |
| WALKS TO THE FIGHT | 38 | 38 | 14 | 0.70 | +92 | +6.6 |
| ADVANCE WORTH | 107 | 107 | 13 | 0.65 | +276 | +21.3 |
| CHARGE NOW FIRST | 77 | 77 | 13 | 0.65 | -371 | -28.5 |
| FALLS SHORT | 358 | 324 | 12 | 0.60 | +90 | +7.5 |
| HARD STAY DROPPED | 12 | 12 | 12 | 0.60 | +0 | +0.0 |
| SAFER THAN THE JOB | 12 | 12 | 12 | 0.60 | +637 | +53.1 |
| SHOOTERS IN TWO RANKS | 12 | 12 | 12 | 0.60 | +26 | +2.2 |
| THROUGH LINE OF FIRE | 12 | 12 | 12 | 0.60 | +708 | +59.0 |
| HOLDER AT DEPLOYMENT | 29 | 29 | 11 | 0.55 | +562 | +51.1 |
| MOVE AND CAST | 11 | 11 | 11 | 0.55 | +416 | +37.8 |
| SET UP TOGETHER | 30 | 27 | 11 | 0.55 | +475 | +43.2 |
| BLOCKED WHEEL | 10 | 10 | 10 | 0.50 | +147 | +14.7 |
| CASTER AWAY FROM SCREEN | 10 | 10 | 10 | 0.50 | +0 | +0.0 |
| CASTING BLOCK | 13 | 13 | 10 | 0.50 | +680 | +68.0 |
| COMBAT PIVOT | 10 | 10 | 10 | 0.50 | +0 | +0.0 |
| TIME ON OUR SIDE | 99 | 77 | 10 | 0.50 | +18 | +1.8 |
| WAR ENGINE JOBS | 16 | 16 | 9 | 0.45 | -330 | -36.7 |
| CHAFF PASSED | 8 | 8 | 8 | 0.40 | -22 | -2.7 |
| MARCH BY THE SUM | 8 | 8 | 8 | 0.40 | +281 | +35.2 |
| OVERRUNS AWAY | 25 | 25 | 8 | 0.40 | +66 | +8.3 |
| LOST CHARGE | 57 | 57 | 7 | 0.35 | +111 | +15.9 |
| NEARER NOT NEEDED | 81 | 80 | 7 | 0.35 | +365 | +52.1 |
| NEXT CHARGE BY LIST | 103 | 103 | 7 | 0.35 | +349 | +49.9 |
| REDIRECT WEIGHED | 7 | 7 | 7 | 0.35 | +314 | +44.8 |
| BEST FACING | 6 | 6 | 6 | 0.30 | +282 | +46.9 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.30 | +243 | +40.5 |
| HIS TURN DENIED | 31 | 31 | 6 | 0.30 | +289 | +48.1 |
| MISSILES NEXT TURN | 252 | 169 | 6 | 0.30 | +25 | +4.1 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.30 | -44 | -7.2 |
| BEST OVERALL | 5 | 5 | 5 | 0.25 | +250 | +49.9 |
| BEST PREY | 20 | 20 | 5 | 0.25 | +86 | +17.1 |
| INVITES THE FIGHT | 21 | 21 | 5 | 0.25 | +31 | +6.2 |
| KEEP FALLS | 5 | 5 | 5 | 0.25 | +213 | +42.6 |
| MAKE SURE TOGETHER | 17 | 12 | 5 | 0.25 | +124 | +24.9 |
| OPENS UP | 7 | 7 | 5 | 0.25 | +121 | +24.1 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.25 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 30 | 30 | 5 | 0.25 | +211 | +42.1 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.20 | +0 | +0.0 |
| FIGHT TO THE END | 23 | 23 | 4 | 0.20 | +447 | +111.7 |
| FIRE IN ORDER | 4 | 4 | 4 | 0.20 | +0 | +0.0 |
| HUNT ADVANCE | 10 | 10 | 4 | 0.20 | +219 | +54.9 |
| KEEPS ITS TARGET | 26 | 26 | 4 | 0.20 | +65 | +16.2 |
| MARCH ODDS | 4 | 4 | 4 | 0.20 | +24 | +6.0 |
| ONE OBJECTIVE FORMULA | 107 | 77 | 4 | 0.20 | +78 | +19.4 |
| WEARS DOWN | 15 | 15 | 4 | 0.20 | +230 | +57.5 |
| WHOLE FIGHT GAIN | 7 | 6 | 4 | 0.20 | +143 | +35.7 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.15 | +889 | +296.3 |
| BEST PRIZE | 3 | 3 | 3 | 0.15 | -119 | -39.6 |
| HIS CHARGE DENIED | 6 | 6 | 3 | 0.15 | +188 | +62.7 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.15 | +118 | +39.2 |
| NO DOUBLE ROUNDS | 48 | 48 | 3 | 0.15 | +57 | +19.0 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.15 | -323 | -107.8 |
| STAY WEIGHED | 3 | 3 | 3 | 0.15 | +15 | +5.0 |
| STOPS SHORT OF THE FLANK | 3 | 3 | 3 | 0.15 | +86 | +28.6 |
| STUCK PIVOT | 3 | 3 | 3 | 0.15 | +0 | +0.0 |
| SUPPORT NARROWED | 111 | 111 | 3 | 0.15 | -44 | -14.5 |
| SURE REACH TOGETHER | 12 | 11 | 3 | 0.15 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 2 | 2 | 2 | 0.10 | +89 | +44.7 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.10 | +0 | +0.0 |
| DEFENSIVE ARMY | 6 | 6 | 2 | 0.10 | -8 | -3.9 |
| HIS MOVE AND SHOT | 31 | 31 | 2 | 0.10 | +11 | +5.4 |
| MODEL FACING | 2 | 2 | 2 | 0.10 | +309 | +154.3 |
| NEEDED THERE | 2 | 2 | 2 | 0.10 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.10 | +59 | +29.7 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.10 | -133 | -66.7 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.10 | +178 | +89.1 |
| BIG CHARACTER SAFETY | 1 | 1 | 1 | 0.05 | -6 | -6.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.05 | +9 | +9.2 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.05 | -232 | -231.5 |
| FALL BACK GOOD ORDER | 45 | 45 | 1 | 0.05 | +34 | +33.5 |
| FEATURE BUFFS | 7 | 7 | 1 | 0.05 | +13 | +13.1 |
| HORN WORTH | 1 | 1 | 1 | 0.05 | +18 | +17.7 |
| HUNT IN PAIRS | 5 | 4 | 1 | 0.05 | +26 | +26.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.05 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 11 | 7 | 1 | 0.05 | +6 | +6.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.05 | +54 | +54.4 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.05 | +56 | +56.2 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.05 | -0 | -0.5 |
| RUN DOWN | 53 | 53 | 1 | 0.05 | +11 | +11.3 |
| SAME CHARGE LATER | 1 | 1 | 1 | 0.05 | +2 | +2.1 |
| SURE CHARGE BEATS ADVANCE | 1 | 1 | 1 | 0.05 | -1 | -1.1 |
| THE PROMISE ADDS | 5 | 5 | 1 | 0.05 | +0 | +0.2 |
| WIDER SPREAD | 85 | 85 | 1 | 0.05 | +5 | +4.7 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 13 | 9 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 9 | 9 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 25 | 25 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 28 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 16 | 16 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 5 | 5 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 7 | 7 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 187 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 10 | 10 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 29 | not checked | - | - | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 47 | 47 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 48 | 48 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 76 | 76 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 18 | 18 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 10 | not checked | - | - | - | - |
| LONG SHOT | 6 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 3 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NOT NEEDED | 2 | 2 | 0 | 0.00 | - | - |
| NOT TURNED | 98 | 98 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 48 | 48 | 0 | 0.00 | - | - |
| OPENS A LANE | 12 | 9 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 1541 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 17 | 17 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 14 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 80 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 19 | 19 | 0 | 0.00 | - | - |
| STABLE ROLE | 226 | 226 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 11 | 11 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 221 | 221 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 96 | not checked | - | - | - | - |
| THE PROMISED MOVE | 11 | not checked | - | - | - | - |
| TURN WORTH | 6 | 6 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 6 | 6 | 0 | 0.00 | - | - |
| WAITS AGAIN | 18 | 18 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: t9-opp-e62ea8a-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.45 | 0.30 | 36.8 |
| CHARGE NOT DECLARED | rule | 0.35 | 0.45 | 105.8 |
| FALLBACK | gate | 0.55 | 0.15 | 74.2 |
| PATHS CROSS | rule | - | 0.70 | 53.1 |
| CHARGE NOW FIRST | rule | 0.35 | 0.30 | 28.5 |
| WAR ENGINE JOBS | rule | 0.40 | - | 41.2 |
| TURN GATE | gate | 0.35 | - | 49.7 |
| CHAFF PASSED | rule | 0.05 | 0.25 | 3.6 |
| PIVOT GUARDS FLANK | rule | 0.10 | 0.15 | 8.6 |
| CANNON PLANNED TARGET | rule | 0.20 | - | 38.4 |
| BEST PRIZE | rule | 0.05 | 0.10 | 39.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.15 | - | 68.3 |
| PURSUES BIG PREY | rule | 0.10 | 0.05 | 107.8 |
| SUPPORT NARROWED | rule | 0.05 | 0.10 | 14.5 |
| DEFENSIVE ARMY | rule | 0.10 | - | 3.9 |
| FIGHT ORDER BAND | gate | 0.10 | - | 2.8 |
| SAFE SURE CHARGE | rule | 0.10 | - | 66.7 |
| AFTERMATH BAND | gate | - | 0.05 | 3.8 |
| BIG CHARACTER SAFETY | rule | 0.05 | - | 6.2 |
| CARRIES OUT SET-UP | rule | 0.05 | - | 231.5 |
| FACES THE THREAT | rule | 0.05 | - | 6.2 |
| MARCH ODDS | rule | 0.05 | - | 31.7 |
| NO REASON | gate | - | 0.05 | 30.4 |
| REDIRECT WEIGHED | rule | 0.05 | - | 0.7 |
| SUPPORT REQUEST | gate | 0.05 | - | 76.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.05 | - | 1.1 |

### Plans: t9-opp-e62ea8a-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.6 | 13% | 166 | 184 | 110% |
| Mine | charge | 2.1 | 60% | 170 | 177 | 104% |
| Mine | close in | 4.7 | 24% | 200 | 169 | 84% |
| Mine | hold | 4.8 | 33% | 339 | 0 | 0% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | shoot | 12.9 | 60% | 338 | 770 | 228% |
| Mine | support | 4.2 | 90% | 36 | 0 | 0% |
| Opponent | charge | 2.9 | 61% | 418 | 230 | 55% |
| Opponent | join | 0.8 | 94% | 44 | 0 | 0% |
| Opponent | move | 29.9 | 92% | 1435 | 0 | 0% |
| Opponent | shoot | 4.3 | 48% | 184 | 196 | 107% |
| Opponent | support | 0.4 | 25% | 7 | 0 | 0% |

### Packages: hunt the guns, t9-opp-e62ea8a-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 6 | 1 | 0% | 20% | 0% | 3.0 | 391 | 44 | 0% | 19 |
| Opponent | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 226 | 183 | 100% | 93 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 1 | 0% | 25% | 0% | 3.0 | 434 | 55 | 0% | 21 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 220 | 0 | 0% | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 53 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 206 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 134 |
| Vampire Counts | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 226 | 183 | 100% | 31 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 152 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 147 |

### Battle groups: t9-opp-e62ea8a-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 25% | 75% | 0% | - | 0% | 0% | 0% | 88% | 12% |
| Opponent | REDIRECT COUNTER | 2.6 | 4% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t9-opp-e62ea8a-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 12 | 4 (12) | 0 | 4 | 73 | 42% | 3.7 | 0 (5) | 9 (6) | 0 (1) | 0 (7) | 10 (5) |
| Mine | Character | 77 | 29 (77) | 29 | 0 | 14 | 30% | 2.2 | 15 (29) | 40 (32) | 27 (11) | 21 (43) | 40 (29) |
| Mine | Clean-up | 8 | 90 (8) | 4 | 86 | 49 | 75% | 2.0 | 96 (3) | 87 (5) | - | 122 (5) | 0 (3) |
| Mine | Fast Hammer | 22 | 30 (22) | 24 | 6 | 29 | 27% | 2.5 | 13 (12) | 44 (8) | 59 (2) | 35 (15) | 17 (7) |
| Mine | Hammer | 36 | 35 (36) | 21 | 14 | 21 | 22% | 2.5 | 21 (15) | 44 (17) | 60 (4) | 36 (24) | 32 (12) |
| Mine | Holder | 15 | 43 (15) | 4 | 39 | 23 | 60% | 4.0 | 40 (10) | 40 (3) | 143 (1) | 42 (9) | 52 (5) |
| Mine | Shooter | 21 | 83 (21) | 33 | 49 | 40 | 5% | 1.5 | 91 (5) | 106 (12) | 6 (4) | 94 (18) | 30 (3) |
| Mine | War machine | 46 | 32 (46) | 32 | 0 | 54 | 2% | 1.3 | 34 (21) | 29 (25) | - | 23 (15) | 36 (31) |
| Mine | Wizard | 10 | 0 (10) | 0 | 0 | 7 | 50% | 3.2 | 0 (4) | 0 (3) | 0 (3) | 0 (2) | 0 (8) |
| Opponent | Chaff | 33 | 82 (33) | 7 | 76 | 54 | 76% | 1.6 | 67 (13) | 126 (15) | 0 (5) | 68 (22) | 118 (11) |
| Opponent | Character | 56 | 38 (56) | 38 | 0 | 12 | 21% | 2.6 | 23 (20) | 47 (28) | 45 (8) | 42 (30) | 33 (26) |
| Opponent | Clean-up | 13 | 33 (13) | 7 | 26 | 25 | 46% | 3.0 | 28 (6) | 47 (5) | 0 (2) | 34 (8) | 30 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 27 | 18 (27) | 6 | 12 | 45 | 48% | 2.7 | 2 (10) | 16 (14) | 82 (3) | 25 (14) | 9 (13) |
| Opponent | Hammer | 16 | 49 (16) | 30 | 20 | 19 | 31% | 3.1 | 33 (2) | 64 (10) | 19 (4) | 33 (9) | 71 (7) |
| Opponent | Holder | 24 | 64 (24) | 13 | 52 | 35 | 42% | 2.7 | 87 (6) | 84 (11) | 21 (7) | 66 (19) | 56 (5) |
| Opponent | Shooter | 16 | 35 (16) | 14 | 22 | 39 | 6% | 1.6 | 36 (7) | 41 (8) | 0 (1) | 45 (13) | 0 (3) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 67% | 6.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | War machine | 17 | 19 (17) | 19 | 0 | 49 | 6% | 1.8 | 29 (9) | 10 (7) | 0 (1) | 0 (4) | 23 (13) |
| Opponent | Wizard | 17 | 10 (17) | 10 | 0 | 23 | 29% | 2.0 | 0 (5) | 27 (7) | 0 (2) | 0 (4) | 17 (10) |

### Charged fights: t9-opp-e62ea8a-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 272 | 114 | 0.5 | 1.0 | 228 | 0 | +228 | 0 of 2 | 2 of 2 | - | +228 |
| Mine | Chaos Dwarfs | 4 | 130 | 289 | 2.2 | 1.1 | 128 | 50 | +78 | 6 of 9 | 6 of 9 | +280 | +53 |
| Mine | Dwarfen Mountain Holds | 3 | 216 | 151 | 2.0 | 1.5 | 75 | 20 | +55 | 2 of 6 | 4 of 6 | +97 | +13 |
| Mine | Empire of Man | 5 | 371 | 155 | 1.8 | 1.1 | 86 | 0 | +86 | 4 of 9 | 7 of 9 | +0 | +97 |
| Mine | Grand Cathay | 4 | 225 | 243 | 3.2 | 1.1 | 75 | 46 | +29 | 4 of 13 | 10 of 13 | +0 | +31 |
| **Mine** | all armies | 20 | 251 | 190 | 1.9 | 1.2 | 98 | 30 | +68 | 16 of 39 | 29 of 39 | +95 | +63 |
| Opponent | Empire of Man | 1 | 189 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 141 | 78 | 2.7 | 1.0 | 29 | 0 | +29 | 1 of 8 | 7 of 8 | - | +29 |
| Opponent | High Elf Realms | 3 | 142 | 124 | 2.0 | 1.0 | 62 | 0 | +62 | 2 of 6 | 4 of 6 | - | +62 |
| Opponent | Kingdom of Bretonnia | 2 | 150 | 174 | 1.5 | 1.0 | 116 | 0 | +116 | 0 of 3 | 3 of 3 | - | +116 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 724 | 3.5 | 1.0 | 207 | 28 | +179 | 5 of 7 | 4 of 7 | - | +179 |
| Opponent | Vampire Counts | 4 | 0 | 166 | 2.0 | 1.0 | 83 | 0 | +83 | 2 of 8 | 6 of 8 | - | +83 |
| Opponent | Warriors of Chaos | 3 | 0 | 469 | 2.7 | 1.1 | 176 | 0 | +176 | 4 of 8 | 8 of 8 | +265 | +163 |
| Opponent | Wood Elf Realms | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 20 | 70 | 223 | 2.0 | 1.0 | 112 | 5 | +107 | 14 of 40 | 32 of 40 | +265 | +103 |

### Effective charges: t9-opp-e62ea8a-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 9 | 1 (net -140) | 0 | 4 (net +39) | 3 (net +230) | 0 | 1 (net +0) | 0 | 44% (4 of 9) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +146) | 0 | 2 (net +20) | 0 | 17% (1 of 6) |
| Mine | Empire of Man | 9 | 1 (net +0) | 0 | 0 | 3 (net +84) | 1 (net +0) | 4 (net +130) | 0 | 0% (0 of 9) |
| Mine | Grand Cathay | 13 | 2 (net +35) | 0 | 4 (net -150) | 2 (net +36) | 1 (net +55) | 4 (net +194) | 0 | 31% (4 of 13) |
| Opponent | Grand Cathay | 8 | 0 | 0 | 2 (net +42) | 2 (net +0) | 1 (net +65) | 3 (net +28) | 0 | 25% (2 of 8) |
| Opponent | High Elf Realms | 6 | 0 | 2 (net +135) | 0 | 1 (net +0) | 2 (net +50) | 1 (net +0) | 0 | 0% (0 of 6) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 1 (net +165) | 0 | 1 (net +117) | 1 (net +65) | 0 | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 7 | 3 (net +105) | 0 | 0 | 2 (net +208) | 0 | 2 (net +262) | 0 | 0% (0 of 7) |
| Opponent | Vampire Counts | 8 | 0 | 0 | 2 (net +55) | 1 (net +222) | 3 (net +110) | 0 | 2 | 33% (2 of 6) |
| Opponent | Warriors of Chaos | 8 | 0 | 0 | 2 (net +284) | 1 (net +265) | 2 (net +18) | 1 (net +310) | 2 | 33% (2 of 6) |

### Charged fights, damage counted: t9-opp-e62ea8a-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 148 | 351 | -14 | 68 | 69 | -1 | -0.8 |
| Mine | Effective (55-75%) | 9 | 340 | 282 | -49 | 81 | 118 | -37 | -10.9 |
| Mine | 76-89% | 10 | 315 | 159 | +130 | 141 | 22 | +119 | +37.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 11 | 219 | 184 | +121 | 143 | 23 | +120 | +54.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 392 | 80 | +28 | 56 | 0 | +56 | +14.1 |
| Mine | No odds | 2 | 836 | 164 | +228 | 302 | 0 | +302 | +36.1 |
| Mine | All fights | 39 | 303 | 215 | +68 | 122 | 48 | +74 | +24.4 |
| Opponent | Long shot (under 50%) | 3 | 346 | 308 | +105 | 170 | 65 | +105 | +30.3 |
| Opponent | 50-54% | 3 | 299 | 233 | +145 | 172 | 86 | +86 | +28.9 |
| Opponent | Effective (55-75%) | 6 | 253 | 193 | +127 | 196 | 1 | +196 | +77.3 |
| Opponent | 76-89% | 8 | 368 | 167 | +127 | 127 | 28 | +99 | +26.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 304 | 197 | +131 | 175 | 26 | +149 | +49.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 389 | 72 | +66 | 97 | 19 | +78 | +20.1 |
| Opponent | No odds | 4 | 319 | 130 | +57 | 79 | 21 | +59 | +18.4 |
| Opponent | All fights | 40 | 333 | 167 | +107 | 141 | 28 | +113 | +34.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t9-opp-e62ea8a-p3 | move | 164 | 30 (18%) | 24 (15%) | 18 (11%) | 116 (71%) |
| t9-opp-e62ea8a-p3 | objective | 93 | 11 (12%) | 9 (10%) | 10 (11%) | 72 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725 |
| Clockwork Compass | Mine | L1216 |
| Elixir of Power | Mine | L1122 |
| Elixir of Power | Opponent | L0311 |
| Horn of the Wild Hunt | Opponent | L0533 |
| Invocation of Nehek | Opponent | L0327, L0725 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

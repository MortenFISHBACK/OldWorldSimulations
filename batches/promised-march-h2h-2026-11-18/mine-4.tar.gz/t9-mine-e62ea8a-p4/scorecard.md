# Doctrine scorecard: t9-mine-e62ea8a-p4

### Scorecard: t9-mine-e62ea8a-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 4 | - | 1 | 0 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 7 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0130 | 4 | 1 | Opponent | no | 5 | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | no | 3 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 4 | 4 | 1 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 519 |
| L0315 | 3 | 1 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 480 |
| L0315 | 3 | 1 | Opponent | no | 8 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 480 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 2 | 5 | 1 | 0 | 0 | 340 |
| L0417 | 3 | 1 | Mine | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 310 |
| L0417 | 3 | 1 | Opponent | no | 7 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 310 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1530 |
| L0520 | 4 | 1 | Opponent | no | 5 | - | 0 | 7 | 1 | 0 | 0 | 245 |
| L0608 | 2 | 1 | Mine | - | - | - | 1 | 4 | 0 | 0 | 0 | 555 |
| L0608 | 2 | 1 | Opponent | - | - | - | 2 | 1 | 0 | 0 | 0 | 470 |
| L0624 | 6 | 1 | Mine | no | 0 | 4 | 5 | 0 | 0 | 0 | 0 | 510 |
| L0624 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 1 | 1 | 1 | 0 | 0 | 0 | 45 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 479 |
| L0729 | 3 | 1 | Mine | no | 6 | 2 | 0 | 0 | 0 | 0 | 0 | 314 |
| L0729 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.1 | 2.8 | 1.7 | 1.2 | 0.1 | 0.0 | 0.0 | 366.1 |
| **Average** | | | Opponent | 11% | 4.8 | 1.8 | 1.8 | 1.5 | 0.5 | 0.0 | 0.0 | 157.9 |

### KPIs: t9-mine-e62ea8a-p4

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 13 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 41% (25 of 61) | 0% (0 of 67) | 20% (25 of 128) |
| Winner chose to follow up after the loser gave ground |  | 68% (15 of 22); on the table 82% | 95% (19 of 20); on the table 95% | 81% (34 of 42); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (6 of 6); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (7 of 7); on the table 100% | 59% (10 of 17); on the table 71% | 71% (17 of 24); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 76% (22 of 29); on the table 86% | 81% (35 of 43); on the table 86% | 79% (57 of 72); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 25% (33 of 132) | 33% (12 of 36) | 27% (45 of 168) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (33 of 84) | 43% (12 of 28) | 40% (45 of 112) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (5 of 10) | 48% (10 of 21) | 48% (15 of 31) |
| Points that never fought | lower | 45% (11464 of 25592) | 43% (11283 of 25993) | 44% (22747 of 51585) |
|   infantry points that never fought | lower | 47% (3369 of 7112) | 79% (3916 of 4948) | 60% (7285 of 12060) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (65 of 101) | 49% (49 of 99) | 57% (114 of 200) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 0.8 uses a game | 100% (3 of 3); 1.1 uses a game | 89% (8 of 9); 1.0 uses a game |
| Bound items with another spell used |  | 100% (4 of 4); 0.5 uses a game | 43% (6 of 14); 0.8 uses a game | 56% (10 of 18); 0.6 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 70% (7 of 10); 0.5 uses a game | 60% (3 of 5); 0.2 uses a game | 67% (10 of 15); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (11973 of 20100) | 41% (9505 of 23442) | 49% (21478 of 43542) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (24%) | 0.4 (21%) | 2.2 (24%) |
| MARCHED: its unit marched | 1.4 (18%) | 0.8 (42%) | 2.2 (23%) |
| CHARGED: its unit charged | 0.6 (8%) | 0.1 (4%) | 0.7 (7%) |
| IN COMBAT: engaged in combat | 1.2 (15%) | 0.3 (17%) | 1.5 (15%) |
| GONE: slain | 2.5 (33%) | 0.2 (12%) | 2.8 (29%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 1.7 | 2.8 | 3.5 | 0.5 | 1.5 |
| not cast | 1.6 | 2.9 | 3.6 | 9.5 | 2.2 | 16.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (53%) | 0.8 (23%) | 2.2 (24%) | 0.5 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (23%) | 0.5 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.6 (17%) | 1.5 (15%) | 0.4 (17%) | 0.0 (0%) |
| GONE: slain | 0.4 (24%) | 0.9 (32%) | 1.5 (40%) | 2.8 (29%) | 0.1 (3%) | 3.6 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.6 (28%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.2 (71%) | 0.2 (8%) | 0.6 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.8 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.2 a game | 0.8 a game | 1.5 a game |
| stood (cast and not dispelled) | 66% (19 of 29) | 50% (2 of 4) | 64% (21 of 33) |
| the unit moved after it | 89% (17 of 19) | 50% (1 of 2) | 86% (18 of 21) |
| it charged on its next turn | 11% (2 of 19) | 0% (0 of 2) | 10% (2 of 21) |
| the enemy charged it first | 32% (6 of 19) | 0% (0 of 2) | 29% (6 of 21) |
| it fought by the end of its next turn | 21% (4 of 19) | 0% (0 of 2) | 19% (4 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 26% (5 of 19) | 0% (0 of 2) | 24% (5 of 21) |
| none of these (no charge, no fight, no charge escaped) | 32% (6 of 19) | 100% (2 of 2) | 38% (8 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (249 of 372) | 54% (126 of 234) | 62% (375 of 606) |
|   cavalry | 38% (12 of 32) | 50% (18 of 36) | 44% (30 of 68) |
|   character | 95% (35 of 37) | 16% (11 of 67) | 44% (46 of 104) |
|   chariot | 68% (27 of 40) | 60% (6 of 10) | 66% (33 of 50) |
|   infantry | 51% (45 of 89) | 80% (61 of 76) | 64% (106 of 165) |
|   monster | 58% (7 of 12) | 30% (3 of 10) | 45% (10 of 22) |
|   war machine | 76% (123 of 162) | 77% (27 of 35) | 76% (150 of 197) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (20%) | 1.7 (20%) | 3.6 (20%) |
| CHARGED: it charged | 0.9 (10%) | 3.0 (36%) | 3.9 (22%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.3 (14%) | 0.0 (0%) | 1.3 (7%) |
| MOVED: a war machine that moved | 1.3 (14%) | 0.1 (1%) | 1.4 (8%) |
| NO TARGET IN RANGE | 1.3 (14%) | 1.7 (20%) | 3.0 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.4 (5%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (15%) | 1.2 (15%) | 2.7 (15%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.5 | 1.4 | 69% | 9.6 pts | 33 pts |
| character | 3.8 | 1.4 | 82% | 4.0 pts | 15 pts |
| chariot | 2.5 | 2.8 | 58% | 31.6 pts | 80 pts |
| infantry | 13.2 | 4.3 | 77% | 8.2 pts | 108 pts |
| monster | 0.8 | 0.1 | 90% | 0.6 pts | 0 pts |
| war machine | 11.5 | 12.5 | 63% | 36.4 pts | 420 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.2 | 6.8 | 5.0 |
| Charges that made contact a game | 2.2 | 4.1 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.25 declared, 1.00 contact (4 units) | 0.83 declared, 0.50 contact (6 units) | 1.00 declared, 0.70 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (3 units) | 0.25 declared, 0.25 contact (4 units) | 0.14 declared, 0.14 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.27 contact (91 units) | 0.88 declared, 0.53 contact (93 units) | 0.65 declared, 0.40 contact (184 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (19 of 32) | 67% (4 of 6) | 0% (0 of 1) | 59% (23 of 39) |
| Character in a unit | 73% (8 of 11) | 50% (1 of 2) | - | 69% (9 of 13) |
| Character on its own | 83% (10 of 12) | 38% (6 of 16) | 30% (7 of 23) | 45% (23 of 51) |
| Chariot | 0% (0 of 1) | 67% (6 of 9) | - | 60% (6 of 10) |
| Infantry | 59% (16 of 27) | 31% (5 of 16) | 100% (1 of 1) | 50% (22 of 44) |
| Monster | 40% (4 of 10) | 50% (2 of 4) | - | 43% (6 of 14) |
| Monstrous | 100% (3 of 3) | - | - | 100% (3 of 3) |
| War Machines | 83% (20 of 24) | 100% (2 of 2) | - | 85% (22 of 26) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (6 of 6); on the table 100% | 19% (19 of 102) | 26% | 50% (11 of 22) | 83% (5 of 6); 2.8 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 75% (6 of 8); on the table 75% | 54% (13 of 24) | 35% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 67% (6 of 9); on the table 89% | - | 76% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | 75% (6 of 8); on the table 88% | 17% (1 of 6) | 65% | 80% (24 of 30) | 0.0 uses a game | 100% (2 of 2); 1.3 uses a game | 67% (2 of 3); 0.7 uses a game |
| High Elf Realms | 4 | 67% (6 of 9); on the table 78% | 22% (4 of 18) | 44% | 36% (12 of 33) | 100% (3 of 3); 3.5 uses a game | 43% (6 of 14); 2.5 uses a game | 0.0 uses a game |
| Lizardmen | 1 | 100% (9 of 9); on the table 100% | 67% (4 of 6) | 12% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | - | 17% (1 of 6) | 89% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (9 of 9); on the table 100% | 50% (3 of 6) | 66% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 69% (9 of 13); on the table 77% | - | 25% | 33% (9 of 27) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | - | 32% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t9-mine-e62ea8a-p4, 13 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 19% (6) | 40% (8) | 27% (14) |
| ...free all their last turn and able to turn (per game) | 0.31 | 0.38 | 0.69 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.15 | 0.00 | 0.15 |
| ...with the charger already in that arc before they moved (per game) | 0.31 | 0.31 | 0.62 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.62 | 0.62 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 1.15 | 1.15 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.08 | 4.62 | 4.69 |

### Quality by phase: t9-mine-e62ea8a-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 58% (21 of 36) | 42% (33 of 79) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (92 of 208) | 53% (45 of 85) |
| Strategy | Close-in objectives charged next turn | - | 17% (19 of 109) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | 36% (5 of 14) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 20% (1 of 5) |
| Strategy | Joined characters whose unit fought | 58% (11 of 19) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 58% (21 of 36) | 74% (23 of 31) |
| Movement | Charges halted short of contact | 0.1 | 0.5 |
| Movement | Idle units | 1.2 | 1.5 |
| Movement | Points that never moved of their own | 366.1 | 157.9 |
| Movement | Fights charged into per game | 2.1 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 25, net -180 | 12 of 38, net +57 |
| Movement | Charges with odds: sweet spot (55-75%) | 7 of 25, net +63 | 6 of 38, net +291 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 25, net +160 | 1 of 38, net +91 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 25, net -4 | 8 of 38, net +171 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 9.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (78 of 130) | 42% (52 of 125) |
| Shooting | Points destroyed by shooting units | 58.5 | 70.5 |
| Shooting | War machine shots | 9.5 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (73 of 123) | 44% (12 of 27) |
| Shooting | Points destroyed by war machines | 143.2 | 0.0 |
| Magic | Magic missiles cast | 1.8 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (8 of 24) | 22% (2 of 9) |
| Magic | Wounds caused by magic missiles | 3.4 | 1.5 |
| Magic | Wounds caused by other spells | 1.2 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 60.2 | 46.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.1 / 0.8 / 0.5 | 1.6 / 0.8 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 214.8 | 536.2 |
| Combat | Points run down | 57.9 | 197.6 |
| Combat | Net points per charged fight, damage counted | +22 | +101 |
| Combat | Net per 100 charger points, damage counted | +13.1 | +28.2 |
| Combat | First round won (charged fights) | 74% | 62% |
| Combat | Net points per charged fight | +16 | +125 |
| Combat | Net points per supported fight / lone fight | +126 / +8 | +203 / +100 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 27 | 28 of 42 |
| Game | Points lost | 931.9 | 576.2 |
| Game | VP from objectives | 424.6 | 752.3 |
| Game | Lone holders (player turns) | 2.1 | 4.8 |

- Mine won / drew / lost: 2 / 1 / 10 of 13 ended games (of 13); mean margin (Mine - Opponent) -736 VP
- The side that went first won 6 of 12 games with a winner
- Points traded per game (both sides' losses): 1508
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t9-mine-e62ea8a-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 3.9 | -77.3 | 74.8 | 63.5 |
| AFTERMATH IN POINTS | 0.5 | +55.0 | 0.0 | 56.8 | - | - | - | - |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 10.8 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 1.2 | +8.1 | 0.0 | 21.9 |
| BEST FACING | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| BEST FIRST | - | - | - | - | 0.9 | +14.5 | 40.4 | 75.1 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.2 | +75.6 | 0.0 | 5.0 |
| BEST OVERALL | - | - | - | - | 0.2 | +9.7 | 0.0 | 0.0 |
| BEST PREY | - | - | - | - | 0.5 | +18.9 | 10.8 | 8.8 |
| BEST PRIZE | 0.1 | -1.9 | 7.0 | 0.0 | 0.3 | -6.0 | 8.8 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.3 | -2.4 | 0.0 | 34.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.6 | +16.8 | 0.0 | 26.9 |
| BLOWS WHERE AIMED | 0.2 | -1.9 | 15.2 | 6.5 | 0.5 | -133.1 | 76.3 | 38.5 |
| BOUND ASSAILMENT | - | - | - | - | 0.1 | +0.0 | 0.0 | 9.5 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 81.0 | 0.0 | 0.4 | +0.0 | 60.3 | 0.0 |
| CANNON PLANNED TARGET | 9.1 | +240.1 | 547.5 | 111.2 | 1.8 | +46.9 | 141.6 | 20.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -8.2 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -2.5 | 24.2 | 4.6 |
| CAST JOB | 0.6 | +17.2 | 26.5 | 0.0 | 0.4 | +12.1 | 64.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.5 | +47.7 | 31.4 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.2 | +0.0 | 0.0 | 137.7 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +11.7 | 0.0 | 0.0 | 0.1 | +1.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.5 | +87.1 | 0.0 | 36.2 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 14.1 | 0.2 | -0.6 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 5.2 | -255.4 | 0.0 | 189.5 | - | - | - | - |
| CHARGE NOT DECLARED | 0.7 | +0.0 | 73.3 | 10.5 | 1.4 | +0.0 | 118.4 | 13.3 |
| CHARGE NOW FIRST | 1.4 | +0.0 | 58.5 | 21.1 | 3.5 | +0.0 | 417.5 | 27.2 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.8 | -37.4 | 13.1 | 57.5 |
| CHARGER SLAIN LOST | 0.9 | -21.9 | 124.0 | 17.1 | 0.8 | -20.0 | 167.4 | 22.6 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.3 | +0.0 | 17.7 | 41.5 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 0.0 | 7.5 |
| CHEAPEST HOLDER | 0.4 | -43.9 | 34.5 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 47.7 | 0.4 | +0.0 | 67.0 | 38.5 |
| CONVEYANCE SEARCH | 1.7 | +154.3 | 24.8 | 137.7 | 0.1 | +25.2 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -436.9 | 0.0 | 173.7 | 6.3 | -322.2 | 0.0 | 241.7 |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +9.3 | 26.1 | 0.0 |
| DEPLOY BY FIGURES | 9.2 | +47.5 | 0.0 | 0.0 | 7.5 | +39.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +4.4 | 21.5 | 8.8 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.6 | +33.7 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.9 | +5.5 | 141.2 | 25.1 | - | - | - | - |
| FALLBACK BY WORTH | - | - | - | - | 6.1 | +54.3 | 0.0 | 78.2 |
| FALLS SHORT | 3.0 | +51.1 | 0.0 | 108.1 | - | - | - | - |
| FEATURE BUFFS | 2.3 | +74.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.2 | 4.6 | 0.0 |
| FIGHT TO THE END | 1.2 | +12.8 | 28.4 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 41.5 | 23.8 | 0.3 | +0.0 | 41.1 | 0.0 |
| FIVE ACTION | 47.2 | +2026.1 | 1211.8 | 746.5 | - | - | - | - |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 210.2 | 3.5 | +0.0 | 0.0 | 160.8 |
| FOCUS FIRE | 0.1 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.5 | +89.7 | 0.0 | 42.5 | 0.7 | +103.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.8 | +128.4 | 210.1 | 38.2 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.2 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.2 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +0.1 | 0.0 | 5.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -2.4 | 21.9 | 4.0 | 0.2 | -3.1 | 24.8 | 0.0 |
| GROUND FLIERS | 0.1 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.3 | +34.6 | 52.6 | 104.6 | 0.8 | +32.4 | 11.8 | 5.0 |
| GUN MASK | 0.6 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 23.8 | - | - | - | - |
| HE SHOOTS OR CHARGES | 2.0 | +0.0 | 0.0 | 43.9 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 21.9 | 0.0 | 0.2 | +0.0 | 30.8 | 4.6 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 68.4 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 1.1 | -126.7 | 0.0 | 8.2 |
| HIS CHARGE DENIED | 0.4 | +11.4 | 17.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 2.1 | +0.0 | 0.0 | 49.6 | - | - | - | - |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 23.8 | - | - | - | - |
| HIS MOVE AND SHOT | 1.6 | -29.1 | 0.0 | 65.8 | - | - | - | - |
| HIS RANDOM MOVE | 2.0 | +0.0 | 0.0 | 66.2 | - | - | - | - |
| HIS SHOT LIST | 15.3 | +516.3 | 0.0 | 315.2 | - | - | - | - |
| HIS TURN DENIED | 0.3 | +17.0 | 12.5 | 14.5 | - | - | - | - |
| HOLDER AT DEPLOYMENT | 0.8 | +142.5 | 0.0 | 0.0 | 0.8 | +153.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.8 | -48.7 | 78.5 | 21.1 | 11.7 | -266.1 | 670.4 | 126.3 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +6.5 | 10.8 | 13.5 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +37.4 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +4.4 | 10.8 | 8.8 |
| HUNT RESULT | 0.1 | +40.0 | 0.0 | 0.0 | 0.2 | +15.6 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +41.5 | 38.5 | 0.0 | 0.2 | +49.2 | 10.8 | 13.5 |
| IDLE COST | 1.3 | -8.3 | 0.0 | 20.8 | 20.5 | -370.5 | 0.0 | 260.8 |
| INVITES THE FIGHT | - | - | - | - | 0.5 | +3.3 | 29.2 | 0.0 |
| JOINT CHARGE PLAN | - | - | - | - | 0.3 | +33.4 | 85.8 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -16.3 | 0.0 | 0.0 |
| KEEP FALLS | 0.2 | +6.0 | 0.0 | 31.4 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.8 | +85.4 | 274.2 | 29.1 |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 2.5 | +207.2 | 299.4 | 19.9 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.3 | +275.8 | 458.2 | 40.7 |
| LANE BY FIGURES | 0.4 | +12.7 | 0.0 | 0.0 | 1.0 | +31.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.4 | +0.0 | 274.3 | 456.6 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.1 | +3.5 | 5.9 | 0.0 | 0.2 | +18.3 | 17.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.8 | +29.0 | 0.0 | 0.0 | 0.2 | +15.5 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.6 | 12.2 | 14.5 | 0.2 | +1.1 | 23.8 | 0.0 |
| LOST CHARGE | - | - | - | - | 2.4 | -38.0 | 92.1 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +0.9 | 0.0 | 0.0 | 1.4 | +125.8 | 185.3 | 0.0 |
| MANOEUVRE | 1.1 | +10.7 | 0.0 | 24.8 | 0.1 | +2.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +22.4 | 0.0 | 6.2 | - | - | - | - |
| MARCH CHECK | 0.4 | +15.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | - | - | - | - | 0.1 | +3.3 | 23.8 | 0.0 |
| MARCH OVER CASTS | 0.2 | -35.5 | 0.0 | 6.2 | 0.4 | +28.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.1 | +57.9 | 0.0 | 90.2 | 6.4 | +96.5 | 0.0 | 97.3 |
| MISSILES IN THE MOVE | 2.8 | +174.8 | 0.0 | 31.0 | 2.0 | +32.7 | 0.0 | 56.8 |
| MISSILES NEXT TURN | 3.3 | +119.0 | 0.0 | 37.2 | 2.5 | +19.1 | 0.0 | 98.4 |
| MODEL FACING | 0.6 | +177.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | - | - | - | - | 0.3 | +7.2 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.8 | +18.3 | 0.0 | 13.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.1 | -55.8 | 9.5 | 34.6 | - | - | - | - |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 6.0 | +418.3 | 369.6 | 29.1 |
| MOVE TO CHARGE COMPUTED | 2.3 | +160.0 | 0.0 | 40.9 | - | - | - | - |
| MOVES UNITS SPELL | 0.2 | +8.5 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.5 | +197.5 | 0.0 | 45.8 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +24.5 | 0.0 | 38.5 |
| NEXT CHARGE BY LIST | 3.9 | -71.0 | 2.1 | 25.7 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 6.2 | -291.7 | 92.5 | 60.9 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.1 | -49.5 | 144.0 | 17.1 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +7.3 | 0.0 | 26.1 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.7 | -23.1 | 86.5 | 13.8 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 4.6 | +62.5 | 0.0 | 162.6 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 78.8 | - | - | - | - |
| OFF BEST | 0.7 | -22.2 | 0.0 | 0.0 | 18.8 | -1074.0 | 33.4 | 236.6 |
| ONE CHARGE A CHARGER | 3.4 | +0.0 | 0.0 | 172.5 | - | - | - | - |
| ONE FIGHT FORMULA | 3.5 | -51.6 | 0.0 | 73.4 | 8.9 | -217.1 | 29.2 | 242.4 |
| ONE OBJECTIVE FORMULA | 2.5 | -23.8 | 0.0 | 76.5 | 3.2 | -218.5 | 0.0 | 23.3 |
| ONE TARGET A SHOOTER | 10.9 | +201.5 | 0.0 | 206.7 | - | - | - | - |
| OPENS A LANE | 0.2 | +0.1 | 15.3 | 23.8 | 0.1 | +0.2 | 23.8 | 0.0 |
| OPENS UP | 0.1 | +2.8 | 4.3 | 0.0 | 0.2 | +19.5 | 23.4 | 0.0 |
| OVERRUNS AWAY | 0.2 | +6.3 | 60.2 | 0.0 | 0.7 | +3.0 | 117.8 | 8.8 |
| PATHS CROSS | 2.6 | +155.8 | 0.0 | 77.0 | 2.8 | +206.1 | 0.0 | 17.1 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +9.5 | 0.0 | 0.0 |
| PLAN RESULT | 42.1 | +1126.9 | 1074.2 | 1081.8 | 40.0 | +1645.8 | 1703.6 | 906.6 |
| PURSUES BIG PREY | 0.2 | +2.7 | 0.0 | 0.0 | 0.1 | -3.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.2 | +15.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +38.9 | 0.0 | 13.1 | 1.6 | +11.6 | 0.0 | 77.7 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -12.2 | 5.9 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -0.8 | 0.0 | 6.5 | 1.2 | -35.4 | 0.0 | 36.2 |
| REDIRECT COUNTER | 2.2 | +196.7 | 0.0 | 29.9 | 3.5 | +125.7 | 0.0 | 65.5 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | -3.5 | 8.8 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -29.8 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 28.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +17.7 | 0.0 | 17.2 | 0.4 | +15.8 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.2 | +7.5 | 0.0 | 8.8 |
| RISK BY ARC | 2.2 | +51.2 | 179.9 | 31.6 | 3.5 | +72.9 | 429.8 | 87.9 |
| RISK BY HIS FIGURE | 12.9 | -188.3 | 0.0 | 388.8 | - | - | - | - |
| RISK ONCE | - | - | - | - | 5.8 | +312.8 | 237.6 | 424.7 |
| RUN DOWN | 1.5 | -10.8 | 68.6 | 6.5 | - | - | - | - |
| SAFER THAN THE JOB | - | - | - | - | 1.2 | +71.0 | 0.0 | 35.8 |
| SCOUT SPOT | 0.4 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.2 | -8.7 | 0.0 | 0.0 | 0.3 | -17.8 | 0.0 | 0.0 |
| SEARCH SPOT | 5.5 | +213.2 | 0.0 | 84.5 | 3.5 | +141.8 | 0.0 | 84.2 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | +81.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +7.1 | 0.0 | 32.5 | 1.8 | +138.6 | 199.4 | 4.6 |
| SET-UP ANY TARGET | 0.2 | +20.1 | 0.0 | 0.0 | 0.1 | +16.4 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -1.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +70.8 | 25.2 | 29.2 | 1.7 | +68.7 | 83.8 | 65.1 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -1.7 | 24.7 | 4.0 | - | - | - | - |
| SHOT RISK POINTS | 8.2 | +18.6 | 0.0 | 171.4 | - | - | - | - |
| SHOTS IN THE MOVE | 18.6 | +936.3 | 0.0 | 319.2 | 10.5 | +315.8 | 0.0 | 53.0 |
| SPELL SETS UP CHARGE | 0.2 | +20.1 | 0.0 | 0.0 | 0.1 | +16.4 | 0.0 | 0.0 |
| SPELL WORTH | 0.4 | +2.4 | 0.0 | 54.6 | 2.2 | +54.4 | 87.7 | 83.1 |
| SPELLS IN THE FIGHT | 0.4 | +2.4 | 56.2 | 0.0 | 1.2 | -6.2 | 96.9 | 67.0 |
| STABLE ROLE | - | - | - | - | 11.0 | +0.0 | 412.2 | 48.5 |
| STAND AND SHOOT | 0.5 | -14.4 | 28.0 | 0.0 | - | - | - | - |
| STANDS STILL | 24.7 | +0.0 | 1001.8 | 292.4 | - | - | - | - |
| STAY WORTH | 24.5 | +24.3 | 713.2 | 186.8 | 12.6 | +91.2 | 239.2 | 71.5 |
| STOPS | 0.1 | +0.8 | 38.5 | 0.0 | 0.1 | +4.4 | 10.8 | 8.8 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.4 | +6.9 | 0.0 | 34.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 16.2 |
| SUPPORT NARROWED | 1.3 | +0.0 | 78.7 | 27.6 | 6.2 | -38.8 | 422.8 | 68.5 |
| SUPPORTS | - | - | - | - | 3.2 | +43.4 | 52.3 | 34.3 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.2 | -19.4 | 28.6 | 0.0 |
| SURE REACH TOGETHER | 0.2 | +0.7 | 0.0 | 0.0 | 0.8 | +3.5 | 0.0 | 15.2 |
| THE DEARER SUM KEEPS ITS PLAN | 2.9 | +0.0 | 0.0 | 70.5 | - | - | - | - |
| THE PROMISE ADDS | 0.2 | -4.6 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.4 | +0.0 | 0.0 | 6.5 | - | - | - | - |
| THROUGH LINE OF FIRE | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.3 | +32.1 | 24.1 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 28.9 | +424.3 | 21.2 | 358.0 | - | - | - | - |
| TURN WORTH | - | - | - | - | 0.3 | -22.6 | 21.9 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.6 | +6.5 | 171.2 | 0.0 |
| WAIT AFTER COSTS | - | - | - | - | 8.9 | -451.7 | 434.5 | 45.5 |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 28.4 | - | - | - | - |
| WALKS TO THE FIGHT | - | - | - | - | 1.2 | +5.2 | 18.3 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 8.2 | 47.7 | - | - | - | - |
| WEARS DOWN | - | - | - | - | 1.9 | +87.1 | 142.7 | 104.1 |
| WHO HITS BACK | 0.1 | +1.8 | 0.0 | 0.0 | 0.7 | +55.7 | 0.0 | 37.2 |
| WHOLE FIGHT | 0.5 | +12.7 | 78.2 | 0.0 | 0.2 | +48.5 | 54.7 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +16.7 | 43.8 | 4.0 | 0.8 | +71.3 | 102.4 | 22.5 |
| WIDER SPREAD | 2.2 | +2.7 | 188.3 | 38.2 | 4.0 | -12.2 | 522.3 | 85.6 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 28.6 | 0.0 |
| WOUNDS ON THE RANKS | 0.5 | +26.6 | 0.0 | 48.9 | - | - | - | - |

### Rule changes: t9-mine-e62ea8a-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 253 | 253 | 253 | 19.46 | -14250 | -56.3 |
| DEPLOY BY FIGURES | 218 | 218 | 139 | 10.69 | +2218 | +16.0 |
| SEARCH SPOT | 116 | 116 | 112 | 8.62 | +4665 | +41.7 |
| LEGAL CHARGES ONLY | 83 | 83 | 83 | 6.38 | +0 | +0.0 |
| TIME ON OUR SIDE | 376 | 336 | 75 | 5.77 | +447 | +6.0 |
| PATHS CROSS | 71 | 71 | 71 | 5.46 | +4705 | +66.3 |
| HIS SHOT LIST | 199 | 199 | 60 | 4.62 | +902 | +15.0 |
| SHOTS IN THE MOVE | 378 | 328 | 49 | 3.77 | +2033 | +41.5 |
| MOVE TO CHARGE | 78 | 78 | 39 | 3.00 | +1931 | +49.5 |
| FIVE ACTION | 613 | 612 | 35 | 2.69 | +740 | +21.2 |
| HARD STAY DROPPED | 30 | 30 | 30 | 2.31 | +0 | +0.0 |
| COVER ONCE | 173 | 126 | 28 | 2.15 | +398 | +14.2 |
| KILLS COUNT NEXT TURN | 95 | 95 | 28 | 2.15 | +1172 | +41.9 |
| CHARGE NOT DECLARED | 27 | 27 | 27 | 2.08 | -1489 | -55.1 |
| ONE TARGET A SHOOTER | 142 | 142 | 27 | 2.08 | +125 | +4.6 |
| ARTILLERY RE-ROLL WEIGHED | 24 | 24 | 24 | 1.85 | +0 | +0.0 |
| ADVANCE LANE KEPT | 23 | 23 | 23 | 1.77 | +0 | +0.0 |
| CANNON PLANNED TARGET | 142 | 142 | 23 | 1.77 | +4 | +0.2 |
| SHOT RISK POINTS | 106 | 106 | 23 | 1.77 | +629 | +27.3 |
| WAIT AFTER COSTS | 116 | 116 | 22 | 1.69 | +462 | +21.0 |
| FALLBACK BY WORTH | 79 | 79 | 20 | 1.54 | +705 | +35.3 |
| FOUR ROUNDS | 36 | 35 | 20 | 1.54 | +611 | +30.6 |
| MAX FOR POSITIONING | 136 | 101 | 20 | 1.54 | +106 | +5.3 |
| MOVE TO CHARGE COMPUTED | 30 | 30 | 20 | 1.54 | +793 | +39.6 |
| REDIRECT COUNTER | 73 | 48 | 19 | 1.46 | +1819 | +95.7 |
| RISK BY ARC | 74 | 73 | 19 | 1.46 | +343 | +18.0 |
| RISK ONCE | 75 | 58 | 19 | 1.46 | +1008 | +53.1 |
| SHOOTS FROM THE BEST SPOT | 35 | 35 | 19 | 1.46 | +512 | +26.9 |
| STAY WORTH | 483 | 441 | 19 | 1.46 | +544 | +28.6 |
| LANE BY FIGURES | 18 | 18 | 18 | 1.38 | +569 | +31.6 |
| CHARGE NOW FIRST | 63 | 63 | 17 | 1.31 | -475 | -28.0 |
| MISSILES IN THE MOVE | 62 | 53 | 17 | 1.31 | +351 | +20.6 |
| SUPPORTS | 41 | 41 | 17 | 1.31 | +198 | +11.6 |
| BEST MOVE FOR SHOOTERS | 16 | 16 | 16 | 1.23 | +982 | +61.4 |
| FOLLOW UP WEIGHED | 15 | 15 | 15 | 1.15 | +2511 | +167.4 |
| ONE FIGHT FORMULA | 162 | 89 | 15 | 1.15 | +22 | +1.5 |
| RANDOM MOVE BY FIGURES | 31 | 31 | 15 | 1.15 | +656 | +43.8 |
| SAFER THAN THE JOB | 15 | 15 | 15 | 1.15 | +924 | +61.6 |
| CANNON SIGHT KEPT | 14 | 14 | 14 | 1.08 | +0 | +0.0 |
| BEST FIRST | 12 | 12 | 12 | 0.92 | +189 | +15.8 |
| CHAFF IN THE MOVE | 19 | 19 | 12 | 0.92 | +473 | +39.4 |
| KILLS COUNT | 32 | 31 | 12 | 0.92 | +964 | +80.4 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 0.92 | +578 | +48.1 |
| CASTER AWAY FROM SCREEN | 11 | 11 | 11 | 0.85 | +0 | +0.0 |
| IDLE COST | 284 | 152 | 11 | 0.85 | +252 | +22.9 |
| RISK BY HIS FIGURE | 168 | 168 | 11 | 0.85 | +718 | +65.2 |
| CHARGE NOW WEIGHED | 10 | 10 | 10 | 0.77 | +265 | +26.5 |
| KEEPS ITS TARGET | 37 | 37 | 10 | 0.77 | +217 | +21.7 |
| RESERVE FALL BACK | 10 | 10 | 10 | 0.77 | +435 | +43.5 |
| WHO HITS BACK | 10 | 10 | 10 | 0.77 | +474 | +47.4 |
| COMBAT PIVOT | 9 | 9 | 9 | 0.69 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 9 | 9 | 9 | 0.69 | +18 | +2.0 |
| BLOCKED WHEEL | 8 | 8 | 8 | 0.62 | +218 | +27.2 |
| FACES THE THREAT | 8 | 8 | 8 | 0.62 | +438 | +54.8 |
| FIRE IN ORDER | 8 | 8 | 8 | 0.62 | +0 | +0.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.62 | +0 | +0.0 |
| MODEL FACING | 8 | 8 | 8 | 0.62 | +2312 | +288.9 |
| NEXT OBJECTIVE NEARER | 80 | 80 | 8 | 0.62 | +218 | +27.2 |
| SET UP TOGETHER | 27 | 23 | 8 | 0.62 | +233 | +29.1 |
| CHARGE LOSSES | 67 | 67 | 7 | 0.54 | +388 | +55.5 |
| MANOEUVRE | 15 | 15 | 7 | 0.54 | +228 | +32.6 |
| REDIRECT WEIGHED | 7 | 7 | 7 | 0.54 | +130 | +18.5 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 0.54 | +0 | +0.0 |
| ADVANCE WORTH | 51 | 51 | 6 | 0.46 | +140 | +23.3 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.46 | +714 | +119.1 |
| CASTING BLOCK | 6 | 6 | 6 | 0.46 | +90 | +15.0 |
| CHAFF PASSED | 6 | 6 | 6 | 0.46 | -8 | -1.4 |
| HOLDER AT DEPLOYMENT | 21 | 21 | 6 | 0.46 | +241 | +40.2 |
| NEXT CHARGE BY LIST | 51 | 51 | 6 | 0.46 | +130 | +21.6 |
| WEARS DOWN | 25 | 24 | 6 | 0.46 | +153 | +25.6 |
| WHOLE FIGHT GAIN | 13 | 12 | 6 | 0.46 | +343 | +57.1 |
| BEST PRIZE | 5 | 5 | 5 | 0.38 | -132 | -26.3 |
| FEATURE BUFFS | 30 | 30 | 5 | 0.38 | +124 | +24.8 |
| HONEST WORTH | 175 | 173 | 5 | 0.38 | +52 | +10.5 |
| MAKE SURE TOGETHER | 20 | 14 | 5 | 0.38 | +205 | +41.1 |
| MISSILES NEXT TURN | 76 | 57 | 5 | 0.38 | +57 | +11.3 |
| ONE OBJECTIVE FORMULA | 75 | 43 | 5 | 0.38 | +162 | +32.3 |
| SCOUT WAITS | 5 | 5 | 5 | 0.38 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 5 | 5 | 5 | 0.38 | +90 | +17.9 |
| SUPPORT NARROWED | 97 | 97 | 5 | 0.38 | -78 | -15.7 |
| WALKS TO THE FIGHT | 15 | 15 | 5 | 0.38 | +14 | +2.9 |
| BIG CHARACTER SAFETY | 4 | 4 | 4 | 0.31 | -31 | -7.7 |
| FALLS SHORT | 39 | 37 | 4 | 0.31 | +59 | +14.7 |
| HUNT IN PAIRS | 9 | 7 | 4 | 0.31 | +78 | +19.6 |
| INVITES THE FIGHT | 6 | 6 | 4 | 0.31 | +4 | +1.1 |
| MARCH BY THE SUM | 4 | 4 | 4 | 0.31 | +292 | +72.9 |
| MOVE AND CAST | 4 | 4 | 4 | 0.31 | +93 | +23.3 |
| NEARER NOT NEEDED | 59 | 58 | 4 | 0.31 | +183 | +45.7 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 0.31 | +120 | +30.1 |
| BEST OVERALL | 3 | 3 | 3 | 0.23 | +126 | +42.0 |
| CAST JOB | 13 | 13 | 3 | 0.23 | +69 | +23.0 |
| FIGHT TO THE END | 16 | 15 | 3 | 0.23 | +9 | +2.8 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.23 | +118 | +39.2 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.23 | -14 | -4.7 |
| REFUSING RETIRES | 7 | 7 | 3 | 0.23 | -2 | -0.6 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.23 | +97 | +32.4 |
| SPELLS IN THE FIGHT | 21 | 20 | 3 | 0.23 | +70 | +23.2 |
| STUCK PIVOT | 3 | 3 | 3 | 0.23 | +0 | +0.0 |
| WHOLE FIGHT | 9 | 8 | 3 | 0.23 | +596 | +198.8 |
| WOUNDS ON THE RANKS | 7 | 7 | 3 | 0.23 | +134 | +44.6 |
| BACKUP TARGETS | 16 | 6 | 2 | 0.15 | +20 | +9.8 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.15 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.15 | +12 | +5.8 |
| GUN MASK | 8 | 8 | 2 | 0.15 | +8 | +4.2 |
| HIS CHARGE DENIED | 5 | 5 | 2 | 0.15 | +32 | +15.9 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.15 | +97 | +48.5 |
| HUNT ADVANCE | 3 | 3 | 2 | 0.15 | +31 | +15.3 |
| JOINT CHARGE PLAN | 4 | 4 | 2 | 0.15 | +122 | +60.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.15 | +113 | +56.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.15 | +0 | +0.0 |
| MARCH CHECK | 5 | 5 | 2 | 0.15 | +75 | +37.5 |
| OPENS UP | 4 | 4 | 2 | 0.15 | +110 | +55.2 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.15 | +64 | +32.2 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.15 | -253 | -126.4 |
| SURE REACH TOGETHER | 12 | 8 | 2 | 0.15 | +1 | +0.4 |
| BEST FACING | 1 | 1 | 1 | 0.08 | +16 | +15.9 |
| BEST PREY | 6 | 6 | 1 | 0.08 | +27 | +26.7 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.08 | +0 | +0.2 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.08 | -106 | -106.2 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.08 | -33 | -32.8 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| CHARGER SLAIN LOST | 23 | 23 | 1 | 0.08 | +0 | +0.4 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.08 | +73 | +73.4 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.08 | +8 | +8.0 |
| FALL BACK GOOD ORDER | 25 | 24 | 1 | 0.08 | +12 | +12.4 |
| FOCUS FIRE | 1 | 1 | 1 | 0.08 | +42 | +42.5 |
| HIS MOVE AND SHOT | 21 | 21 | 1 | 0.08 | +0 | +0.2 |
| LOST CHARGE | 31 | 31 | 1 | 0.08 | +10 | +10.2 |
| MARCH ODDS | 1 | 1 | 1 | 0.08 | +6 | +6.2 |
| NEEDED THERE | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.08 | +54 | +54.3 |
| OVERRUNS AWAY | 12 | 12 | 1 | 0.08 | +68 | +68.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +124 | +124.0 |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 1 | 0.08 | +45 | +44.9 |
| STOPS | 2 | 2 | 1 | 0.08 | +56 | +56.4 |
| THROUGH LINE OF FIRE | 1 | 1 | 1 | 0.08 | +24 | +23.5 |
| WIDER SPREAD | 81 | 76 | 1 | 0.08 | +1 | +1.3 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.08 | -18 | -18.3 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 8 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 18 | 18 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 22 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 5 | 5 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 23 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 123 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 27 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 26 | 26 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 4 | 3 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 14 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 26 | 26 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LONG SHOT | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 27 | 26 | 0 | 0.00 | - | - |
| NOT NEEDED | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 61 | 61 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 44 | 44 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 1067 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 17 | 17 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 12 | 0 | 0.00 | - | - |
| RUN DOWN | 20 | 19 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 34 | not checked | - | - | - | - |
| STABLE ROLE | 143 | 143 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 321 | 321 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 38 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 5 | not checked | - | - | - | - |
| TURN WORTH | 4 | 4 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 8 | 8 | 0 | 0.00 | - | - |
| WAITS AGAIN | 24 | 24 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: t9-mine-e62ea8a-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.08 | 16.15 | 56.0 |
| CHARGE NOT DECLARED | rule | 0.62 | 0.92 | 76.0 |
| CHARGE NOW FIRST | rule | 0.62 | 0.69 | 28.0 |
| FALLBACK | gate | - | 0.85 | 51.2 |
| TURN GATE | gate | - | 0.77 | 39.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.38 | 0.15 | 57.8 |
| SUPPORT REQUEST | gate | - | 0.46 | 168.9 |
| BEST PRIZE | rule | 0.08 | 0.31 | 26.3 |
| SUPPORT NARROWED | rule | 0.23 | 0.15 | 15.7 |
| AFTERMATH BAND | gate | 0.23 | 0.08 | 2.8 |
| BIG CHARACTER SAFETY | rule | - | 0.31 | 7.7 |
| PATHS CROSS | rule | 0.15 | 0.15 | 50.9 |
| CANNON PLANNED TARGET | rule | 0.15 | - | 4.7 |
| CHAFF PASSED | rule | - | 0.15 | 4.2 |
| DEPLOY BY FIGURES | rule | 0.08 | 0.08 | 7.6 |
| FIGHT ORDER BAND | gate | - | 0.15 | 1.9 |
| PURSUES BIG PREY | rule | 0.08 | 0.08 | 55.2 |
| REFUSING RETIRES | rule | 0.15 | - | 0.9 |
| STOPS SHORT OF THE FLANK | rule | - | 0.15 | 7.7 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.15 | 126.4 |
| CARRIES OUT COUNTER | rule | 0.08 | - | 106.2 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 32.8 |
| CHARGE NOW WEIGHED | rule | - | 0.08 | 23.3 |
| FACES THE THREAT | rule | - | 0.08 | 1.9 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.08 | 39.2 |
| REDIRECT WEIGHED | rule | - | 0.08 | 47.9 |
| RULE SWITCHED OFF | gate | - | 0.08 | 7.5 |
| SAFER THAN THE JOB | rule | - | 0.08 | 13.6 |
| WHO HITS BACK | rule | - | 0.08 | 1.6 |
| WOUNDED STAYS OUT | rule | 0.08 | - | 18.3 |

### Plans: t9-mine-e62ea8a-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 51% | 169 | 193 | 114% |
| Mine | join | 0.4 | 100% | 7 | 0 | 0% |
| Mine | move | 24.9 | 93% | 1183 | 0 | 0% |
| Mine | shoot | 13.8 | 61% | 684 | 934 | 137% |
| Mine | support | 0.2 | 100% | 0 | 0 | - |
| Opponent | advance | 10.2 | 14% | 152 | 329 | 217% |
| Opponent | charge | 5.0 | 54% | 559 | 555 | 99% |
| Opponent | close in | 8.2 | 29% | 513 | 344 | 67% |
| Opponent | hold | 6.8 | 40% | 554 | 0 | 0% |
| Opponent | shoot | 5.2 | 75% | 137 | 418 | 304% |
| Opponent | support | 4.6 | 90% | 39 | 0 | 0% |

### Packages: hunt the guns, t9-mine-e62ea8a-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 540 | 520 | 100% | 0 |
| Opponent | 0.2 | 3 | 0 | 33% | 33% | 0% | 3.0 | 213 | 68 | 33% | 143 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 540 | 520 | 100% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.8 | 3 | 0 | 33% | 33% | 0% | 3.0 | 213 | 68 | 33% | 110 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 605 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 179 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 159 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: t9-mine-e62ea8a-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 14% | 25% | 0% | - | 0% | 0% | 0% | 75% | 25% |
| Opponent | REDIRECT COUNTER | 3.5 | 22% | 80% | 40% | 25% | 33% | 0% | 17% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t9-mine-e62ea8a-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 0 (5) | 0 | 0 | 13 | 60% | 3.5 | 0 (1) | 0 (4) | - | 0 (4) | 0 (1) |
| Mine | Character | 49 | 40 (49) | 40 | 0 | 57 | 20% | 2.2 | 44 (11) | 63 (15) | 54 (6) | 43 (16) | 66 (16) |
| Mine | Clean-up | 14 | 153 (14) | 36 | 117 | 66 | 21% | 3.3 | 77 (6) | 341 (5) | 73 (3) | 202 (8) | 100 (6) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.5 | - | 0 (2) | - | 0 (2) | - |
| Mine | Fast Hammer | 12 | 2 (12) | 2 | 0 | 50 | 33% | 4.0 | 0 (5) | 6 (3) | 0 (4) | 0 (7) | 3 (5) |
| Mine | Hammer | 29 | 44 (29) | 23 | 21 | 53 | 24% | 2.1 | 18 (10) | 51 (17) | 152 (2) | 43 (20) | 46 (9) |
| Mine | Holder | 13 | 84 (13) | 0 | 84 | 33 | 54% | 2.5 | 18 (4) | 146 (7) | 0 (2) | 136 (8) | 24 (5) |
| Mine | Shooter | 13 | 34 (13) | 4 | 30 | 62 | 8% | 2.4 | 0 (1) | 35 (7) | 36 (5) | 30 (10) | 45 (3) |
| Mine | War machine | 31 | 51 (31) | 51 | 0 | 40 | 3% | 1.4 | 72 (20) | 15 (10) | 0 (1) | 72 (5) | 47 (26) |
| Mine | Wizard | 6 | 21 (6) | 21 | 0 | 54 | 17% | 2.0 | 68 (2) | 0 (2) | - | - | 34 (4) |
| Opponent | Chaff | 22 | 9 (22) | 0 | 9 | 52 | 45% | 2.8 | 0 (11) | 57 (3) | 0 (8) | 15 (15) | 0 (7) |
| Opponent | Character | 34 | 59 (34) | 59 | 0 | 29 | 15% | 2.2 | 50 (9) | 84 (16) | 23 (7) | 69 (14) | 54 (18) |
| Opponent | Clean-up | 3 | 44 (3) | 17 | 27 | 65 | 33% | 1.5 | 63 (2) | 0 (1) | - | 44 (3) | - |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 23 | 107 (23) | 83 | 24 | 34 | 26% | 3.3 | 85 (4) | 67 (12) | 174 (7) | 86 (12) | 130 (11) |
| Opponent | Fragile | 4 | 0 (4) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 16 | 43 (16) | 10 | 32 | 34 | 44% | 3.7 | 0 (1) | 64 (9) | 19 (6) | 0 (9) | 101 (7) |
| Opponent | Holder | 11 | 78 (11) | 16 | 62 | 0 | 73% | 4.3 | 20 (4) | 127 (6) | 0 (1) | 90 (8) | 58 (3) |
| Opponent | Shooter | 17 | 97 (17) | 47 | 51 | 24 | 12% | 1.5 | 109 (5) | 110 (8) | 38 (4) | 118 (9) | 72 (8) |
| Opponent | War machine | 6 | 0 (6) | 0 | 0 | 20 | 0% | 1.2 | 0 (3) | 0 (3) | - | 0 (3) | 0 (3) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | - | - | 0 (2) | 0 (1) | 0 (1) |

### Charged fights: t9-mine-e62ea8a-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 167 | 198 | 2.5 | 1.0 | 79 | 118 | -39 | 2 of 10 | 5 of 10 | - | -39 |
| Mine | Chaos Dwarfs | 4 | 176 | 192 | 2.0 | 1.1 | 96 | 24 | +72 | 2 of 8 | 8 of 8 | +91 | +70 |
| Mine | Dwarfen Mountain Holds | 3 | 375 | 86 | 2.7 | 1.1 | 32 | 0 | +32 | 0 of 8 | 6 of 8 | +161 | +14 |
| Mine | Empire of Man | 2 | 454 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 13 | 262 | 140 | 2.1 | 1.1 | 67 | 51 | +16 | 4 of 27 | 20 of 27 | +126 | +8 |
| Opponent | Empire of Man | 1 | 303 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | High Elf Realms | 4 | 193 | 686 | 3.8 | 1.3 | 183 | 33 | +149 | 7 of 15 | 11 of 15 | +346 | +78 |
| Opponent | Lizardmen | 1 | 339 | 744 | 5.0 | 1.2 | 149 | 128 | +21 | 4 of 5 | 4 of 5 | +434 | -82 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 105 | 306 | 2.0 | 1.5 | 153 | 0 | +153 | 1 of 2 | 2 of 2 | +186 | +120 |
| Opponent | Warriors of Chaos | 4 | 0 | 840 | 3.8 | 1.2 | 224 | 73 | +151 | 12 of 15 | 7 of 15 | -95 | +213 |
| Opponent | Wood Elf Realms | 1 | 0 | 310 | 4.0 | 1.5 | 78 | 0 | +78 | 4 of 4 | 2 of 4 | +310 | +0 |
| **Opponent** | all armies | 13 | 117 | 574 | 3.2 | 1.3 | 178 | 53 | +125 | 28 of 42 | 26 of 42 | +203 | +100 |

### Effective charges: t9-mine-e62ea8a-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 4 (net -225) | 0 | 2 (net +123) | 3 (net +37) | 0 | 0 | 1 | 22% (2 of 9) |
| Mine | Chaos Dwarfs | 8 | 0 | 1 (net +0) | 0 | 1 (net +175) | 3 (net +160) | 3 (net -25) | 0 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 8 | 1 (net +0) | 0 | 4 (net +49) | 1 (net +0) | 0 | 1 (net +60) | 1 | 57% (4 of 7) |
| Mine | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Empire of Man | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 15 | 3 (net +147) | 1 (net +0) | 3 (net +431) | 1 (net +95) | 1 (net +91) | 4 (net +80) | 2 | 23% (3 of 13) |
| Opponent | Lizardmen | 5 | 1 (net +0) | 0 | 1 (net +310) | 1 (net +0) | 0 | 1 (net +434) | 1 | 25% (1 of 4) |
| Opponent | Vampire Counts | 2 | 1 (net +120) | 0 | 0 | 1 (net +186) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 15 | 6 (net +20) | 3 (net +263) | 1 (net +140) | 2 (net +250) | 0 | 2 (net +307) | 1 | 7% (1 of 14) |
| Opponent | Wood Elf Realms | 4 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +310) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |

### Charged fights, damage counted: t9-mine-e62ea8a-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 67 | 267 | -180 | 86 | 253 | -167 | -249.6 |
| Mine | 50-54% | 1 | 339 | 399 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 7 | 85 | 105 | +63 | 86 | 17 | +70 | +81.7 |
| Mine | 76-89% | 5 | 152 | 102 | +57 | 76 | 24 | +52 | +34.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 155 | 124 | -4 | 61 | 47 | +14 | +8.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 583 | 94 | +160 | 160 | 0 | +160 | +27.4 |
| Mine | No odds | 2 | 78 | 94 | +76 | 76 | 0 | +76 | +96.2 |
| Mine | All fights | 27 | 169 | 146 | +16 | 85 | 63 | +22 | +13.1 |
| Opponent | Long shot (under 50%) | 12 | 237 | 305 | +57 | 225 | 207 | +18 | +7.7 |
| Opponent | 50-54% | 5 | 381 | 317 | +158 | 158 | 0 | +158 | +41.4 |
| Opponent | Effective (55-75%) | 6 | 592 | 268 | +291 | 291 | 38 | +253 | +42.7 |
| Opponent | 76-89% | 6 | 493 | 233 | +182 | 182 | 64 | +118 | +23.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 357 | 244 | +171 | 189 | 20 | +169 | +47.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 492 | 91 | +91 | 91 | 0 | +91 | +18.5 |
| Opponent | No odds | 4 | 122 | 136 | -132 | 54 | 160 | -106 | -86.7 |
| Opponent | All fights | 42 | 359 | 258 | +125 | 194 | 93 | +101 | +28.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t9-mine-e62ea8a-p4 | move | 107 | 29 (27%) | 22 (21%) | 20 (19%) | 58 (54%) |
| t9-mine-e62ea8a-p4 | objective | 109 | 19 (17%) | 9 (8%) | 15 (14%) | 75 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130 |
| Charmed Shield | Opponent | L0434, L0624 |
| Invocation of Nehek | Opponent | L0624 |
| Opal Amulet | Opponent | L0114, L0214 |
| Periapt of Soul Exchange | Opponent | L0520 |
| Ring of Doom | Mine | L0214, L0230 |
| Ring of Doom | Opponent | L0315 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Twice-Blessed Armour | Mine | L0713, L0729 |
| Witch Hunter's Ward | Mine | L0713, L0729 |
| Witch Hunter's Ward | Opponent | L0608 |

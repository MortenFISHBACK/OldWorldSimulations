# Doctrine scorecard: t9-mine-e62ea8a-p3

### Scorecard: t9-mine-e62ea8a-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 7 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 0 | 3 | 5 | 2 | 0 | 0 | 0 | 60 |
| L0210 | 6 | 1 | Mine | no | 1 | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 492 |
| L0226 | 4 | 1 | Mine | yes | 1 | 3 | 0 | 6 | 1 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Opponent | no | 4 | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | - | 0 | 2 | 1 | 0 | 0 | 360 |
| L0311 | 5 | 1 | Opponent | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 2 | 4 | 1 | 0 | 0 | 0 | 0 | 450 |
| L0327 | 3 | 1 | Opponent | no | 6 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 6 | 0 | 2 | 1 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | no | 5 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0516 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 383 |
| L0516 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 3 | 0 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 190 |
| L0533 | 5 | 1 | Opponent | no | - | - | 0 | 5 | 0 | 0 | 0 | 236 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 403 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Mine | yes | 8 | 2 | 6 | 1 | 0 | 0 | 0 | 250 |
| L0709 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 602 |
| L0725 | 5 | 1 | Mine | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 378 |
| L0725 | 5 | 1 | Opponent | yes | - | - | 4 | 2 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 2 | 1 | 3 | 0 | 0 | 0 | 289 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 0 | 6 | 2 | 2 | 0 | 0 | 0 | 355 |
| L0831 | 3 | 1 | Opponent | yes | 11 | 3 | 3 | 2 | 2 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 185 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 0 | 0 | 0 | 0 | 0 | 165 |
| L1013 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 532 |
| L1030 | 4 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 4 | 0 | 0 | 0 | 285 |
| L1122 | 6 | 1 | Mine | no | 3 | 4 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1122 | 6 | 1 | Opponent | no | 5 | 2 | 7 | 0 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 29% | 2.7 | 3.0 | 1.3 | 1.8 | 0.2 | 0.0 | 0.0 | 214.4 |
| **Average** | | | Opponent | 35% | 3.4 | 2.7 | 2.4 | 2.2 | 0.2 | 0.0 | 0.0 | 215.9 |

### KPIs: t9-mine-e62ea8a-p3

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 19 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 41% (33 of 81) | 7% (6 of 90) | 23% (39 of 171) |
| Winner chose to follow up after the loser gave ground |  | 71% (15 of 21); on the table 76% | 100% (14 of 14); on the table 100% | 83% (29 of 35); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 83% (5 of 6); on the table 83% | 56% (5 of 9); on the table 67% | 67% (10 of 15); on the table 73% |
| Winner chose to follow up or pursue (all three) |  | 75% (21 of 28); on the table 79% | 84% (21 of 25); on the table 88% | 79% (42 of 53); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 39% (88 of 228) | 33% (53 of 162) | 36% (141 of 390) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (88 of 173) | 40% (53 of 134) | 46% (141 of 307) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (2 of 5) | 70% (16 of 23) | 64% (18 of 28) |
| Points that never fought | lower | 49% (17812 of 36695) | 54% (20383 of 37993) | 51% (38195 of 74688) |
|   infantry points that never fought | lower | 39% (3412 of 8768) | 71% (5761 of 8090) | 54% (9173 of 16858) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (94 of 153) | 60% (86 of 143) | 61% (180 of 296) |
| Bound items with a magic missile used (at least once a game) |  | 92% (11 of 12); 1.8 uses a game | 85% (11 of 13); 2.4 uses a game | 88% (22 of 25); 2.1 uses a game |
| Bound items with another spell used |  | 67% (4 of 6); 0.5 uses a game | 17% (1 of 6); 0.1 uses a game | 42% (5 of 12); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (9 of 15); 0.5 uses a game | 43% (3 of 7); 0.2 uses a game | 55% (12 of 22); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (17538 of 30385) | 56% (18819 of 33563) | 57% (36357 of 63948) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (28%) | 2.0 (35%) | 4.1 (31%) |
| MARCHED: its unit marched | 2.0 (27%) | 1.5 (27%) | 3.5 (27%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.4 (6%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.5 (20%) | 1.1 (19%) | 2.6 (20%) |
| REAR RANK: in a rear rank | 0.3 (4%) | 0.3 (6%) | 0.6 (5%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| GONE: slain | 1.2 (16%) | 0.2 (4%) | 1.4 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (2%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.2 | 1.5 | 3.4 | 7.4 | 1.2 | 1.4 |
| not cast | 2.7 | 1.6 | 3.5 | 13.1 | 2.3 | 18.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (68%) | 0.3 (9%) | 4.1 (31%) | 0.2 (7%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.5 (27%) | 0.6 (27%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.2 (13%) | 0.4 (10%) | 2.6 (20%) | 0.8 (34%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.9 (27%) | 0.6 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.4 (16%) | 0.1 (6%) | 0.4 (10%) | 1.4 (11%) | 0.0 (0%) | 1.3 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.1 (3%) | 0.1 (3%) | 0.2 (1%) | 0.7 (30%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (76%) | 0.2 (10%) | 1.3 (37%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.8 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.1 a game | 1.6 a game | 1.9 a game |
| stood (cast and not dispelled) | 58% (23 of 40) | 36% (9 of 25) | 49% (32 of 65) |
| the unit moved after it | 70% (16 of 23) | 100% (9 of 9) | 78% (25 of 32) |
| it charged on its next turn | 4% (1 of 23) | 0% (0 of 9) | 3% (1 of 32) |
| the enemy charged it first | 0% (0 of 23) | 11% (1 of 9) | 3% (1 of 32) |
| it fought by the end of its next turn | 0% (0 of 23) | 11% (1 of 9) | 3% (1 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 61% (14 of 23) | 0% (0 of 9) | 44% (14 of 32) |
| none of these (no charge, no fight, no charge escaped) | 35% (8 of 23) | 89% (8 of 9) | 50% (16 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (335 of 470) | 57% (212 of 374) | 65% (547 of 844) |
|   cavalry | 76% (25 of 33) | 56% (22 of 39) | 65% (47 of 72) |
|   character | 88% (45 of 51) | 35% (21 of 60) | 59% (66 of 111) |
|   chariot | 72% (55 of 76) | 69% (22 of 32) | 71% (77 of 108) |
|   infantry | 55% (51 of 93) | 57% (89 of 156) | 56% (140 of 249) |
|   monster | 90% (9 of 10) | 100% (2 of 2) | 92% (11 of 12) |
|   war machine | 72% (150 of 207) | 66% (56 of 85) | 71% (206 of 292) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.6 (23%) | 2.1 (24%) | 3.7 (24%) |
| CHARGED: it charged | 0.4 (5%) | 1.3 (15%) | 1.6 (10%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.3 (3%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (11%) | 0.2 (2%) | 1.0 (6%) |
| MOVED: a war machine that moved | 1.4 (20%) | 0.1 (1%) | 1.5 (10%) |
| NO TARGET IN RANGE | 0.6 (9%) | 1.6 (19%) | 2.2 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (18%) | 2.1 (25%) | 3.4 (22%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.5 (6%) | 0.8 (5%) |
| OTHER BAR | 0.4 (6%) | 0.4 (4%) | 0.8 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 0.8 | 81% | 7.6 pts | 33 pts |
| character | 4.0 | 1.4 | 74% | 11.1 pts | 45 pts |
| chariot | 4.1 | 2.3 | 68% | 14.2 pts | 57 pts |
| infantry | 10.8 | 3.4 | 77% | 9.0 pts | 97 pts |
| monster | 0.8 | 0.4 | 62% | 8.5 pts | 7 pts |
| war machine | 11.1 | 9.5 | 62% | 23.0 pts | 256 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.1 | 5.2 | 3.6 |
| Charges that made contact a game | 1.6 | 3.1 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.73 declared, 0.73 contact (15 units) | 0.93 declared, 0.57 contact (14 units) | 0.83 declared, 0.66 contact (29 units) |
|   per unit a game, units carrying another wizard (or one alone) | 3.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.80 contact (5 units) | 1.33 declared, 0.67 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.21 declared, 0.17 contact (118 units) | 0.64 declared, 0.37 contact (126 units) | 0.43 declared, 0.27 contact (244 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (17 of 30) | 67% (6 of 9) | 25% (1 of 4) | 56% (24 of 43) |
| Character in a unit | 75% (21 of 28) | 82% (9 of 11) | 100% (1 of 1) | 78% (31 of 40) |
| Character on its own | 67% (10 of 15) | 48% (10 of 21) | 33% (10 of 30) | 45% (30 of 66) |
| Chariot | 100% (7 of 7) | 75% (9 of 12) | - | 84% (16 of 19) |
| Infantry | 52% (21 of 40) | 39% (9 of 23) | 75% (3 of 4) | 49% (33 of 67) |
| Monster | 83% (10 of 12) | 67% (2 of 3) | - | 80% (12 of 15) |
| Monstrous | 100% (1 of 1) | 100% (4 of 4) | - | 100% (5 of 5) |
| War Machines | 69% (27 of 39) | 100% (2 of 2) | - | 71% (29 of 41) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (1 of 1); on the table 100% | 44% (42 of 96) | 33% | 64% (14 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 1.5 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 88% (7 of 8); on the table 88% | 50% (18 of 36) | 45% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 40% (2 of 5); on the table 40% | - | 65% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (7 of 8); on the table 100% | 30% (9 of 30) | 52% | 63% (37 of 59) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 70% (7 of 10); on the table 80% | 31% (48 of 156) | 50% | 48% (27 of 56) | 75% (9 of 12); 4.8 uses a game | 25% (1 of 4); 0.2 uses a game | 33% (2 of 6); 0.3 uses a game |
| High Elf Realms | 3 | 91% (10 of 11); on the table 91% | 33% (6 of 18) | 46% | 61% (14 of 23) | 100% (4 of 4); 6.3 uses a game | 25% (1 of 4); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 34% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | - | 50% (3 of 6) | 77% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 44% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 80% (4 of 5); on the table 80% | 40% (12 of 30) | 59% | 68% (15 of 22) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 50% | 64% (16 of 25) | 100% (1 of 1); 1.7 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | - | 0% (0 of 6) | 100% | 90% (9 of 10) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t9-mine-e62ea8a-p3, 19 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 58% (18) | 35% (6) | 50% (24) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.11 | 0.68 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.05 | 0.16 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.00 | 0.42 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.05 | 1.37 | 1.42 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.32 | 0.32 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 5.89 | 6.00 |

### Quality by phase: t9-mine-e62ea8a-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.8 | 2.8 |
| Strategy | Charge objectives carried out (made contact) | 58% (22 of 38) | 35% (35 of 100) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (110 of 272) | 41% (59 of 144) |
| Strategy | Close-in objectives charged next turn | - | 20% (24 of 120) |
| Strategy | Support requests answered (helper made contact too) | 33% (1 of 3) | 39% (7 of 18) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 29% (2 of 7) | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 54% (21 of 39) | 27% (6 of 22) |
| Strategy | Lone characters that fought | 57% (25 of 44) | 62% (29 of 47) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.8 | 2.2 |
| Movement | Points that never moved of their own | 214.4 | 215.9 |
| Movement | Fights charged into per game | 1.6 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 30, net +140 | 10 of 40, net -46 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 30, net +63 | 10 of 40, net +70 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 30, net +57 | 4 of 40, net +72 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 of 30, net +98 | 7 of 40, net +109 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (92 of 193) | 48% (80 of 167) |
| Shooting | Points destroyed by shooting units | 136.7 | 47.1 |
| Shooting | War machine shots | 7.9 | 3.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (63 of 150) | 43% (26 of 61) |
| Shooting | Points destroyed by war machines | 56.5 | 33.5 |
| Magic | Magic missiles cast | 3.1 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (18 of 58) | 45% (17 of 38) |
| Magic | Wounds caused by magic missiles | 5.4 | 5.0 |
| Magic | Wounds caused by other spells | 2.1 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 70.0 | 66.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.6 / 0.3 | 2.3 / 0.3 / 0.2 / 0.3 |
| Combat | Points destroyed in combat | 212.7 | 237.6 |
| Combat | Points run down | 20.3 | 89.2 |
| Combat | Net points per charged fight, damage counted | +67 | +69 |
| Combat | Net per 100 charger points, damage counted | +29.3 | +20.5 |
| Combat | First round won (charged fights) | 83% | 64% |
| Combat | Net points per charged fight | +76 | +73 |
| Combat | Net points per supported fight / lone fight | -60 / +80 | +23 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 10 of 30 | 24 of 50 |
| Game | Points lost | 601.3 | 576.5 |
| Game | VP from objectives | 493.2 | 688.4 |
| Game | Lone holders (player turns) | 2.7 | 3.4 |

- Mine won / drew / lost: 4 / 8 / 7 of 19 ended games (of 19); mean margin (Mine - Opponent) -282 VP
- The side that went first won 8 of 11 games with a winner
- Points traded per game (both sides' losses): 1178
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t9-mine-e62ea8a-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 6.1 |
| ADVANCE WORTH | - | - | - | - | 3.4 | -117.9 | 67.5 | 31.2 |
| AFTERMATH IN POINTS | 0.3 | +31.6 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.2 | +0.0 | 0.0 | 37.9 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.4 | 0.0 | 0.0 | 0.6 | +2.0 | 0.0 | 34.5 |
| BEST FACING | - | - | - | - | 0.4 | +7.8 | 0.0 | 10.3 |
| BEST FIRST | - | - | - | - | 1.3 | +97.7 | 0.0 | 32.8 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.9 | +39.6 | 0.0 | 27.9 |
| BEST OVERALL | - | - | - | - | 0.2 | +18.4 | 0.0 | 8.5 |
| BEST PREY | - | - | - | - | 0.6 | +26.0 | 0.0 | 7.6 |
| BEST PRIZE | 0.1 | -17.5 | 6.6 | 0.0 | 0.3 | +3.7 | 24.1 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.4 | +12.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -7.3 | 17.9 | 0.0 | 0.6 | -121.3 | 53.8 | 0.0 |
| BOMBING RUN | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.2 | +0.0 | 131.2 | 12.4 | 0.3 | +0.0 | 41.7 | 10.3 |
| CANNON PLANNED TARGET | 7.8 | +98.9 | 348.5 | 131.8 | 2.4 | +73.4 | 70.5 | 20.5 |
| CANNON SIGHT KEPT | 1.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | -0.7 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.8 | 3.9 | 0.0 | 0.5 | -7.4 | 61.9 | 2.4 |
| CAST JOB | 0.7 | +28.6 | 51.4 | 4.5 | 0.9 | +15.8 | 42.9 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +25.6 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 5.7 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 37.4 | 0.8 | +0.0 | 0.0 | 32.2 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.4 | +51.0 | 0.0 | 8.9 | 1.1 | +55.7 | 0.0 | 35.5 |
| CHAFF PASSED | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | -0.9 | 18.0 | 0.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 5.4 | -263.6 | 0.0 | 199.8 | - | - | - | - |
| CHARGE NOT DECLARED | 0.5 | +0.0 | 33.1 | 0.0 | 1.1 | +0.0 | 86.4 | 45.4 |
| CHARGE NOW FIRST | 1.2 | +0.0 | 172.9 | 0.0 | 3.2 | +0.0 | 303.2 | 94.1 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.3 | -38.4 | 18.1 | 39.8 |
| CHARGER SLAIN LOST | 0.1 | -4.8 | 11.1 | 0.0 | 0.3 | -3.8 | 5.5 | 2.4 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | +0.0 | 0.0 | 21.1 |
| CHEAP HELPER | 0.1 | +0.0 | 11.1 | 3.2 | 0.1 | +0.0 | 0.0 | 2.1 |
| CHEAPEST HOLDER | 0.4 | -7.9 | 43.1 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 22.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.6 | +146.8 | 3.4 | 0.0 | 0.7 | +61.6 | 23.7 | 32.2 |
| COVER ONCE | 9.3 | -846.3 | 0.0 | 196.4 | 6.9 | -460.8 | 0.0 | 187.8 |
| DEFENSIVE FLOOR | 0.1 | +13.5 | 26.0 | 9.9 | - | - | - | - |
| DEPLOY BY FIGURES | 8.4 | +1.7 | 0.0 | 16.6 | 7.2 | +40.6 | 0.0 | 44.8 |
| EDGE GIVE GROUND | 0.2 | +26.3 | 24.5 | 0.0 | 0.3 | +31.4 | 39.1 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.1 | +1.2 | 0.0 | 0.0 | 1.4 | +112.1 | 0.0 | 10.3 |
| FALL BACK GOOD ORDER | 1.6 | +8.7 | 175.1 | 9.9 | - | - | - | - |
| FALLBACK BY WORTH | 0.2 | +1.2 | 0.0 | 2.9 | 5.3 | +72.2 | 0.0 | 70.8 |
| FALLS SHORT | 5.0 | +98.2 | 0.0 | 63.4 | - | - | - | - |
| FEATURE BUFFS | 1.4 | +32.2 | 0.0 | 56.3 | - | - | - | - |
| FIGHT LIFT | 0.1 | +0.4 | 0.0 | 0.0 | 0.2 | +4.6 | 3.2 | 0.0 |
| FIGHT TO THE END | 0.8 | +16.0 | 100.5 | 9.9 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.6 | +0.0 | 25.7 | 18.6 | 0.3 | +0.0 | 6.6 | 6.6 |
| FIVE ACTION | 44.8 | +2301.3 | 1002.1 | 713.1 | - | - | - | - |
| FLANK NOT WEIGHED | 5.8 | +0.0 | 0.0 | 114.5 | 5.2 | +0.0 | 0.0 | 121.7 |
| FOCUS FIRE | 0.1 | +0.8 | 1.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.4 | +45.6 | 0.0 | 0.0 | 0.6 | +80.8 | 0.0 | 26.0 |
| FOUR ROUNDS | 2.0 | +145.1 | 201.0 | 9.9 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.1 | -18.9 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.4 | -2.5 | 8.9 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.1 | 24.5 | 0.0 | 0.2 | -4.0 | 0.0 | 0.0 |
| GROUND FLIERS | 0.1 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.7 | +25.3 | 39.4 | 0.0 | 0.4 | +4.6 | 6.3 | 17.6 |
| GUN MASK | 0.6 | +24.6 | 0.0 | 16.7 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 19.5 | - | - | - | - |
| HE SHOOTS OR CHARGES | 1.7 | +0.0 | 0.0 | 31.7 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.3 | +0.0 | 32.4 | 2.6 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 24.8 |
| HILL BY ITS CHANCE | - | - | - | - | 0.4 | -81.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +21.4 | 24.5 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.5 | +0.0 | 0.0 | 139.6 | - | - | - | - |
| HIS LEGAL MOVES | 3.8 | +0.0 | 0.0 | 80.5 | - | - | - | - |
| HIS MOVE AND SHOT | 1.8 | -41.6 | 0.0 | 100.8 | - | - | - | - |
| HIS RANDOM MOVE | 2.5 | +0.0 | 0.0 | 3.2 | - | - | - | - |
| HIS SHOT LIST | 17.8 | +643.0 | 0.0 | 351.8 | - | - | - | - |
| HIS TURN DENIED | 0.9 | +32.8 | 85.4 | 0.0 | - | - | - | - |
| HOLDER AT DEPLOYMENT | 0.6 | +99.6 | 0.0 | 0.0 | 0.8 | +136.5 | 0.0 | 4.2 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -58.8 | 163.9 | 0.0 | 9.5 | -283.2 | 595.3 | 143.6 |
| HUNT ADVANCE | - | - | - | - | 0.3 | +13.9 | 6.6 | 13.6 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 8.7 | 9.3 |
| HUNT IN PAIRS | 0.4 | +15.8 | 0.0 | 0.0 | 0.7 | +64.9 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.7 | 5.8 | 6.2 |
| HUNT RESULT | - | - | - | - | 0.4 | +6.8 | 15.3 | 11.6 |
| HUNT THE GUNS | - | - | - | - | 0.4 | +143.1 | 12.4 | 12.2 |
| IDLE COST | 2.3 | -20.9 | 0.0 | 37.2 | 18.7 | -364.5 | 0.0 | 194.1 |
| INVITES THE FIGHT | - | - | - | - | 0.7 | +8.3 | 11.3 | 19.4 |
| JOINT CHARGE PLAN | - | - | - | - | 0.4 | +42.4 | 28.5 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -4.8 | 0.0 | 0.0 | 0.1 | -0.5 | 11.3 | 3.2 |
| KEEP FALLS | 0.2 | +1.9 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.0 | 3.4 | 3.8 |
| KEEPS ITS TARGET | - | - | - | - | 2.2 | +64.7 | 218.8 | 8.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 1.7 | +75.5 | 156.8 | 32.9 |
| KILLS COUNT NEXT TURN | - | - | - | - | 6.7 | +182.0 | 296.7 | 151.9 |
| LANE BY FIGURES | 0.5 | +21.2 | 0.0 | 0.0 | 1.2 | +50.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 309.2 | 149.6 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.1 | +3.9 | 19.5 | 2.4 | 0.4 | +5.2 | 15.3 | 16.1 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.4 | +0.0 | 20.9 | 22.2 |
| LONE WIZARD KEPT IN | 0.8 | +60.8 | 0.0 | 0.0 | 0.5 | +39.5 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -1.1 | 0.0 | 9.9 | 0.3 | -1.0 | 3.4 | 2.4 |
| LOST CHARGE | 0.1 | -0.1 | 3.8 | 0.0 | 2.1 | -34.9 | 97.4 | 55.1 |
| MAKE SURE TOGETHER | 0.2 | +2.8 | 0.0 | 3.2 | 1.3 | +82.6 | 74.6 | 18.3 |
| MANOEUVRE | 0.9 | +12.3 | 0.0 | 14.5 | 0.4 | +13.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +3.2 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.5 | +16.3 | 0.0 | 22.8 | - | - | - | - |
| MARCH CHECK | 0.9 | +71.6 | 0.0 | 17.5 | 0.4 | +13.2 | 0.0 | 0.0 |
| MARCH ODDS | - | - | - | - | 0.4 | +23.5 | 28.3 | 21.1 |
| MARCH OVER CASTS | 1.0 | +35.2 | 0.0 | 40.6 | 0.7 | +53.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.4 | +93.2 | 0.0 | 106.8 | 7.2 | +131.5 | 0.0 | 170.9 |
| MISSILES IN THE MOVE | 5.3 | +245.3 | 0.0 | 90.5 | 5.5 | +67.7 | 0.0 | 66.0 |
| MISSILES NEXT TURN | 5.9 | +151.4 | 0.0 | 108.3 | 6.4 | +52.7 | 0.0 | 78.5 |
| MODEL FACING | 0.2 | +23.2 | 0.0 | 3.2 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.3 | +0.0 | 16.3 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.5 | +37.7 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.4 | +9.1 | 0.0 | 0.0 | 0.2 | +0.8 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.9 | -53.2 | 0.0 | 0.0 | 0.3 | -20.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 21.1 |
| MOVE TO CHARGE | - | - | - | - | 5.2 | +406.5 | 276.3 | 56.1 |
| MOVE TO CHARGE COMPUTED | 3.7 | +323.9 | 0.0 | 71.7 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +5.8 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.9 | +277.4 | 0.0 | 81.1 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +15.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.3 | -162.9 | 66.3 | 74.8 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 5.9 | -270.8 | 135.7 | 86.5 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.4 | -59.1 | 162.1 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +23.9 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.2 | -7.2 | 8.7 | 2.6 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 5.9 | +78.4 | 0.0 | 136.4 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.2 | -2.2 | 0.0 | 5.8 | 17.2 | -883.9 | 0.0 | 188.8 |
| ONE CHARGE A CHARGER | 2.6 | +0.0 | 0.0 | 93.6 | - | - | - | - |
| ONE FIGHT FORMULA | 4.8 | -96.0 | 0.0 | 111.2 | 7.7 | -167.7 | 11.3 | 138.3 |
| ONE OBJECTIVE FORMULA | 2.8 | +24.4 | 0.0 | 50.8 | 1.9 | -64.5 | 0.0 | 9.3 |
| ONE TARGET A SHOOTER | 12.1 | +329.3 | 0.0 | 233.4 | - | - | - | - |
| OPENS A LANE | - | - | - | - | 0.4 | +1.2 | 14.3 | 0.0 |
| OPENS UP | 0.2 | +18.6 | 7.5 | 0.0 | 0.2 | +6.8 | 10.1 | 0.0 |
| OVERRUNS AWAY | 0.4 | +26.9 | 40.6 | 0.0 | 0.7 | +8.3 | 40.7 | 13.5 |
| PATHS CROSS | 3.3 | +82.3 | 0.0 | 30.2 | 2.7 | +180.3 | 0.0 | 13.9 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +3.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.3 | 0.0 | 0.0 | 0.1 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 39.5 | +984.3 | 652.8 | 857.2 | 39.3 | +998.3 | 1214.7 | 823.5 |
| PURSUES BIG PREY | 0.1 | -5.7 | 0.0 | 0.0 | 0.1 | -0.5 | 0.0 | 22.7 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +5.6 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.3 | +0.3 | 0.0 | 17.9 | 1.2 | +16.3 | 0.0 | 46.8 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.1 | -2.3 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -4.4 | 0.0 | 2.9 | 0.7 | -24.3 | 0.0 | 33.2 |
| REDIRECT COUNTER | 1.5 | +105.8 | 0.0 | 25.0 | 2.2 | +240.3 | 0.0 | 35.9 |
| REDIRECT WEIGHED | 0.1 | -17.5 | 6.6 | 0.0 | 0.7 | +13.6 | 23.7 | 17.1 |
| REFORMS TO MEET IT | 0.7 | -40.9 | 0.0 | 3.2 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.6 | +24.8 | 0.0 | 0.0 | 0.9 | +27.2 | 0.0 | 21.3 |
| RESTRAINS TO SHOOT | 0.1 | +12.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.6 | +3.4 | 188.1 | 9.9 | 3.1 | +79.9 | 251.0 | 109.4 |
| RISK BY HIS FIGURE | 13.0 | -228.8 | 0.0 | 292.1 | - | - | - | - |
| RISK ONCE | - | - | - | - | 5.4 | +200.2 | 90.7 | 244.9 |
| RUN DOWN | 1.3 | -16.7 | 107.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +11.0 | 0.0 | 11.9 |
| SAME CHARGE LATER | 0.1 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.2 | 0.0 | 0.0 | 0.5 | -29.9 | 0.0 | 3.4 |
| SEARCH SPOT | 5.3 | +294.6 | 0.0 | 86.7 | 2.8 | +125.8 | 0.0 | 38.3 |
| SELF MOVE SPELL | - | - | - | - | 0.3 | +116.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +4.9 | 0.0 | 3.2 | 2.3 | +181.3 | 138.8 | 36.8 |
| SET-UP ANY TARGET | 0.2 | +13.7 | 0.0 | 0.0 | 0.4 | +64.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.0 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +69.2 | 59.1 | 23.9 | 1.1 | +19.4 | 23.9 | 12.7 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -16.0 | 30.8 | 6.6 | - | - | - | - |
| SHOT RISK POINTS | 9.5 | +130.4 | 0.0 | 233.4 | - | - | - | - |
| SHOTS IN THE MOVE | 17.8 | +833.8 | 0.0 | 290.1 | 10.8 | +298.7 | 0.0 | 125.8 |
| SPELL SETS UP CHARGE | 0.2 | +28.9 | 0.0 | 0.0 | 0.4 | +64.0 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +7.7 | 8.9 | 27.6 | 2.8 | +60.6 | 55.3 | 52.1 |
| SPELLS IN THE FIGHT | 0.3 | -3.5 | 37.3 | 9.9 | 0.6 | -7.1 | 49.2 | 12.6 |
| STABLE ROLE | - | - | - | - | 9.5 | +0.0 | 287.7 | 147.7 |
| STAND AND SHOOT | 0.3 | -1.5 | 30.2 | 0.0 | - | - | - | - |
| STANDS STILL | 21.1 | +0.0 | 801.1 | 341.2 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| STAY WORTH | 20.3 | +75.8 | 406.8 | 345.7 | 11.9 | +71.4 | 199.3 | 113.5 |
| STOPS | - | - | - | - | 0.2 | +4.2 | 5.8 | 2.4 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.3 | +14.4 | 0.0 | 8.5 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 8.9 |
| SUPPORT NARROWED | 0.7 | +0.0 | 77.8 | 9.9 | 5.4 | -31.9 | 316.8 | 74.0 |
| SUPPORTS | - | - | - | - | 3.5 | +37.2 | 176.0 | 45.0 |
| SURE REACH TOGETHER | 0.3 | +0.7 | 0.0 | 0.0 | 1.1 | -0.6 | 57.1 | 9.8 |
| THE DEARER SUM KEEPS ITS PLAN | 4.2 | +0.0 | 0.0 | 88.8 | - | - | - | - |
| THE PROMISED MOVE | 0.5 | +0.0 | 0.0 | 22.8 | - | - | - | - |
| THROUGH LINE OF FIRE | - | - | - | - | 0.4 | +40.4 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.3 | +27.7 | 25.8 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 23.9 | +397.3 | 43.2 | 296.5 | - | - | - | - |
| TURN WORTH | - | - | - | - | 0.3 | -26.6 | 32.9 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.5 | +5.3 | 57.6 | 0.0 |
| WAIT AFTER COSTS | - | - | - | - | 7.3 | -411.3 | 340.5 | 85.5 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 22.8 | - | - | - | - |
| WALKS TO THE FIGHT | - | - | - | - | 0.7 | +5.3 | 39.4 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 24.5 | 0.0 | 0.2 | +0.0 | 5.8 | 7.1 |
| WEARS DOWN | - | - | - | - | 1.9 | +49.9 | 163.2 | 58.5 |
| WHO HITS BACK | 0.3 | +22.8 | 0.0 | 13.4 | 0.1 | +14.3 | 0.0 | 6.1 |
| WHOLE FIGHT | 0.2 | +11.1 | 29.2 | 0.0 | 0.3 | +7.8 | 24.9 | 2.4 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +67.0 | 73.8 | 12.9 |
| WIDER SPREAD | 1.4 | -5.1 | 148.9 | 9.9 | 3.1 | -7.7 | 297.6 | 69.0 |
| WOUNDS ON THE RANKS | 1.5 | +44.7 | 0.0 | 50.1 | - | - | - | - |

### Rule changes: t9-mine-e62ea8a-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 331 | 331 | 331 | 17.42 | -16836 | -50.9 |
| DEPLOY BY FIGURES | 296 | 296 | 199 | 10.47 | +3094 | +15.5 |
| SEARCH SPOT | 154 | 154 | 153 | 8.05 | +7991 | +52.2 |
| PATHS CROSS | 115 | 115 | 115 | 6.05 | +4990 | +43.4 |
| LEGAL CHARGES ONLY | 95 | 95 | 95 | 5.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 454 | 403 | 89 | 4.68 | +382 | +4.3 |
| HIS SHOT LIST | 338 | 338 | 82 | 4.32 | +1293 | +15.8 |
| CANNON PLANNED TARGET | 193 | 193 | 53 | 2.79 | -595 | -11.2 |
| FIVE ACTION | 852 | 851 | 53 | 2.79 | +1494 | +28.2 |
| ONE TARGET A SHOOTER | 230 | 230 | 53 | 2.79 | +864 | +16.3 |
| MOVE TO CHARGE COMPUTED | 71 | 71 | 51 | 2.68 | +2835 | +55.6 |
| ARTILLERY RE-ROLL WEIGHED | 50 | 50 | 50 | 2.63 | +0 | +0.0 |
| MOVE TO CHARGE | 99 | 99 | 48 | 2.53 | +3153 | +65.7 |
| SHOTS IN THE MOVE | 545 | 468 | 45 | 2.37 | +2021 | +44.9 |
| COVER ONCE | 308 | 224 | 43 | 2.26 | +645 | +15.0 |
| MISSILES IN THE MOVE | 204 | 152 | 38 | 2.00 | +1074 | +28.3 |
| KILLS COUNT NEXT TURN | 127 | 127 | 36 | 1.89 | +772 | +21.5 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 1.84 | +0 | +0.0 |
| CANNON SIGHT KEPT | 35 | 35 | 35 | 1.84 | +0 | +0.0 |
| SHOT RISK POINTS | 181 | 181 | 35 | 1.84 | +713 | +20.4 |
| LANE BY FIGURES | 33 | 33 | 33 | 1.74 | +1367 | +41.4 |
| HARD STAY DROPPED | 32 | 32 | 32 | 1.68 | +0 | +0.0 |
| MAX FOR POSITIONING | 258 | 207 | 30 | 1.58 | +129 | +4.3 |
| CHARGE NOT DECLARED | 29 | 29 | 29 | 1.53 | -3202 | -110.4 |
| RESERVE FALL BACK | 28 | 28 | 28 | 1.47 | +988 | +35.3 |
| FACES THE THREAT | 27 | 27 | 27 | 1.42 | +2154 | +79.8 |
| SHOOTS FROM THE BEST SPOT | 48 | 48 | 26 | 1.37 | +269 | +10.3 |
| CHARGE NOW FIRST | 83 | 83 | 25 | 1.32 | -946 | -37.8 |
| BEST FIRST | 24 | 24 | 24 | 1.26 | +1855 | +77.3 |
| FALLBACK BY WORTH | 104 | 104 | 24 | 1.26 | +1396 | +58.2 |
| LONE WIZARD KEPT IN | 24 | 24 | 24 | 1.26 | +1905 | +79.4 |
| SUPPORTS | 66 | 66 | 23 | 1.21 | +241 | +10.5 |
| ONE FIGHT FORMULA | 239 | 137 | 22 | 1.16 | +80 | +3.7 |
| STAY WORTH | 612 | 557 | 21 | 1.11 | +296 | +14.1 |
| RISK BY ARC | 89 | 82 | 20 | 1.05 | +642 | +32.1 |
| FOLLOW UP WEIGHED | 19 | 19 | 19 | 1.00 | +2401 | +126.4 |
| FOUR ROUNDS | 38 | 37 | 19 | 1.00 | +986 | +51.9 |
| FIRE IN ORDER | 18 | 18 | 18 | 0.95 | +0 | +0.0 |
| MARCH CHECK | 24 | 24 | 18 | 0.95 | +475 | +26.4 |
| RANDOM MOVE BY FIGURES | 28 | 28 | 18 | 0.95 | +316 | +17.6 |
| WAIT AFTER COSTS | 138 | 138 | 18 | 0.95 | +260 | +14.4 |
| BEST MOVE FOR SHOOTERS | 17 | 17 | 17 | 0.89 | +753 | +44.3 |
| CHAFF IN THE MOVE | 29 | 28 | 17 | 0.89 | +386 | +22.7 |
| CHARGE LOSSES | 103 | 103 | 16 | 0.84 | +821 | +51.3 |
| REDIRECT COUNTER | 69 | 45 | 16 | 0.84 | +945 | +59.0 |
| MANOEUVRE | 25 | 25 | 15 | 0.79 | +495 | +33.0 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.79 | +284 | +18.9 |
| RISK ONCE | 103 | 81 | 15 | 0.79 | +688 | +45.9 |
| CHAFF PASSED | 14 | 14 | 14 | 0.74 | -17 | -1.2 |
| NEXT OBJECTIVE NEARER | 113 | 113 | 14 | 0.74 | +298 | +21.3 |
| RISK BY HIS FIGURE | 247 | 247 | 14 | 0.74 | +588 | +42.0 |
| SCOUT WAITS | 14 | 14 | 14 | 0.74 | +0 | +0.0 |
| CAST JOB | 32 | 32 | 13 | 0.68 | +106 | +8.2 |
| HOLDS AMBUSHERS | 13 | 13 | 13 | 0.68 | +0 | +0.0 |
| IDLE COST | 400 | 256 | 13 | 0.68 | +119 | +9.1 |
| SET UP TOGETHER | 50 | 45 | 13 | 0.68 | +1073 | +82.5 |
| SHOOTERS IN TWO RANKS | 12 | 12 | 12 | 0.63 | +26 | +2.2 |
| CASTER AWAY FROM SCREEN | 10 | 10 | 10 | 0.53 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 27 | 27 | 10 | 0.53 | +492 | +49.2 |
| HONEST WORTH | 213 | 208 | 10 | 0.53 | +124 | +12.4 |
| MOVE AND CAST | 10 | 10 | 10 | 0.53 | +716 | +71.6 |
| MARCH BY THE SUM | 9 | 9 | 9 | 0.47 | +309 | +34.3 |
| BEST FACING | 8 | 8 | 8 | 0.42 | +148 | +18.5 |
| FALLS SHORT | 95 | 81 | 8 | 0.42 | +102 | +12.8 |
| FEATURE BUFFS | 27 | 27 | 8 | 0.42 | +146 | +18.3 |
| KILLS COUNT | 33 | 33 | 8 | 0.42 | +357 | +44.6 |
| ADVANCE WORTH | 64 | 64 | 7 | 0.37 | +36 | +5.2 |
| BEST PRIZE | 7 | 7 | 7 | 0.37 | -458 | -65.4 |
| BLOCKED WHEEL | 7 | 7 | 7 | 0.37 | +232 | +33.1 |
| INVITES THE FIGHT | 13 | 13 | 7 | 0.37 | +42 | +6.0 |
| KEEPS ITS TARGET | 41 | 39 | 7 | 0.37 | +125 | +17.8 |
| MARCH ODDS | 7 | 7 | 7 | 0.37 | +71 | +10.1 |
| ONE OBJECTIVE FORMULA | 90 | 66 | 7 | 0.37 | +313 | +44.7 |
| THROUGH LINE OF FIRE | 7 | 7 | 7 | 0.37 | +768 | +109.8 |
| WHO HITS BACK | 7 | 7 | 7 | 0.37 | +637 | +91.0 |
| WHOLE FIGHT GAIN | 14 | 14 | 7 | 0.37 | +394 | +56.3 |
| CHARGE NOW WEIGHED | 6 | 6 | 6 | 0.32 | +640 | +106.6 |
| NEXT CHARGE BY LIST | 81 | 81 | 6 | 0.32 | +128 | +21.4 |
| SAFER THAN THE JOB | 6 | 6 | 6 | 0.32 | +210 | +34.9 |
| AFTERMATH IN POINTS | 5 | 5 | 5 | 0.26 | +601 | +120.2 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.26 | -16 | -3.1 |
| COMBAT PIVOT | 5 | 5 | 5 | 0.26 | +0 | +0.0 |
| HIS TURN DENIED | 18 | 18 | 5 | 0.26 | +188 | +37.6 |
| HUNT IN PAIRS | 20 | 9 | 5 | 0.26 | +423 | +84.6 |
| MAKE SURE TOGETHER | 27 | 18 | 5 | 0.26 | +340 | +67.9 |
| MISSILES NEXT TURN | 233 | 154 | 5 | 0.26 | +58 | +11.6 |
| OVERRUNS AWAY | 21 | 20 | 5 | 0.26 | +102 | +20.4 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.26 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 5 | 5 | 5 | 0.26 | +273 | +54.6 |
| WALKS TO THE FIGHT | 14 | 14 | 5 | 0.26 | +17 | +3.4 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.21 | +0 | +0.0 |
| KEEP FALLS | 4 | 4 | 4 | 0.21 | +92 | +23.1 |
| OPENS UP | 6 | 6 | 4 | 0.21 | +150 | +37.6 |
| SURE REACH TOGETHER | 26 | 23 | 4 | 0.21 | +11 | +2.7 |
| TIED UP BY THE SUM | 6 | 6 | 4 | 0.21 | +96 | +24.1 |
| BACKUP TARGETS | 14 | 9 | 3 | 0.16 | +3 | +1.0 |
| BEST OVERALL | 3 | 3 | 3 | 0.16 | +349 | +116.5 |
| CARRIES OUT SET-UP | 10 | 10 | 3 | 0.16 | -155 | -51.7 |
| CASTING BLOCK | 6 | 6 | 3 | 0.16 | +89 | +29.6 |
| MODEL FACING | 3 | 3 | 3 | 0.16 | +441 | +147.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.16 | +118 | +39.2 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.16 | -57 | -18.9 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.16 | -118 | -39.5 |
| STUCK PIVOT | 3 | 3 | 3 | 0.16 | +0 | +0.0 |
| SUPPORT NARROWED | 116 | 116 | 3 | 0.16 | -50 | -16.8 |
| WEARS DOWN | 36 | 32 | 3 | 0.16 | +45 | +14.9 |
| EDGE GIVE GROUND | 9 | 9 | 2 | 0.11 | +290 | +144.8 |
| FALL BACK GOOD ORDER | 31 | 30 | 2 | 0.11 | +36 | +18.1 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.11 | +15 | +7.6 |
| HIS CHARGE DENIED | 6 | 6 | 2 | 0.11 | +98 | +49.2 |
| HIS MOVE AND SHOT | 35 | 35 | 2 | 0.11 | +15 | +7.7 |
| JOINT CHARGE PLAN | 8 | 8 | 2 | 0.11 | +405 | +202.3 |
| LONE WIZARD HOLDS BACK | 8 | 8 | 2 | 0.11 | -18 | -8.8 |
| LOST CHARGE | 41 | 41 | 2 | 0.11 | +53 | +26.6 |
| NEARER NOT NEEDED | 94 | 93 | 2 | 0.11 | +66 | +33.1 |
| NEEDED THERE | 2 | 2 | 2 | 0.11 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.11 | +439 | +219.7 |
| REFORMS TO MEET IT | 14 | 14 | 2 | 0.11 | +94 | +47.0 |
| REFUSING RETIRES | 9 | 9 | 2 | 0.11 | -1 | -0.3 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.11 | +242 | +121.2 |
| WAR ENGINE JOBS | 11 | 11 | 2 | 0.11 | -141 | -70.6 |
| WHOLE FIGHT | 8 | 7 | 2 | 0.11 | +57 | +28.6 |
| WOUNDS ON THE RANKS | 28 | 28 | 2 | 0.11 | +12 | +6.1 |
| BLOWS WHERE AIMED | 13 | 10 | 1 | 0.05 | +220 | +219.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.05 | +27 | +27.1 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.05 | -13 | -12.7 |
| FIGHT TO THE END | 15 | 14 | 1 | 0.05 | +84 | +83.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.05 | +7 | +6.6 |
| FOCUS FIRE | 1 | 1 | 1 | 0.05 | +16 | +15.7 |
| GUN MASK | 12 | 12 | 1 | 0.05 | +0 | +0.5 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.05 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 27 | 26 | 1 | 0.05 | +18 | +18.4 |
| OPENS A LANE | 7 | 2 | 1 | 0.05 | +7 | +7.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.05 | +56 | +56.5 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.05 | +12 | +12.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.05 | +1 | +0.6 |
| STOPS | 3 | 3 | 1 | 0.05 | +10 | +9.5 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.05 | +81 | +80.8 |
| WIDER SPREAD | 86 | 79 | 1 | 0.05 | +2 | +1.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BEST PREY | 11 | 11 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 34 | trace | - | - | - | - |
| CHARACTER GUNS | 11 | 11 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 8 | 8 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 7 | 7 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 44 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 209 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 41 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 32 | 32 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 85 | 85 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 73 | 73 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 47 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 10 | not checked | - | - | - | - |
| LONG SHOT | 10 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 33 | 33 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT NEEDED | 4 | 4 | 0 | 0.00 | - | - |
| NOT TURNED | 114 | 114 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 13 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 49 | 49 | 0 | 0.00 | - | - |
| PLAN RESULT | 1497 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 17 | 17 | 0 | 0.00 | - | - |
| RUN DOWN | 24 | 24 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 14 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 67 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 17 | 15 | 0 | 0.00 | - | - |
| STABLE ROLE | 180 | 178 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 400 | 400 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 79 | not checked | - | - | - | - |
| THE PROMISED MOVE | 9 | not checked | - | - | - | - |
| TURN WORTH | 5 | 5 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 10 | 9 | 0 | 0.00 | - | - |
| WAITS AGAIN | 33 | 33 | 0 | 0.00 | - | - |

### Off best figure: t9-mine-e62ea8a-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.05 | 15.58 | 53.1 |
| CHARGE NOT DECLARED | rule | 0.47 | 0.89 | 127.0 |
| CHARGE NOW FIRST | rule | 0.37 | 0.95 | 37.8 |
| PATHS CROSS | rule | 0.53 | 0.11 | 16.6 |
| TURN GATE | gate | - | 0.58 | 24.1 |
| CANNON PLANNED TARGET | rule | 0.42 | 0.11 | 89.8 |
| FALLBACK | gate | - | 0.42 | 30.4 |
| BEST PRIZE | rule | 0.05 | 0.32 | 65.4 |
| CHAFF PASSED | rule | - | 0.26 | 3.4 |
| SUPPORT REQUEST | gate | - | 0.26 | 81.0 |
| FIGHT ORDER BAND | gate | 0.05 | 0.16 | 2.9 |
| REDIRECT WEIGHED | rule | - | 0.21 | 22.6 |
| BIG CHARACTER SAFETY | rule | - | 0.16 | 10.9 |
| CARRIES OUT SET-UP | rule | 0.05 | 0.11 | 51.7 |
| CHARGE NOW WEIGHED | rule | - | 0.16 | 38.9 |
| PIVOT GUARDS FLANK | rule | 0.05 | 0.11 | 18.9 |
| PURSUES BIG PREY | rule | 0.11 | 0.05 | 39.5 |
| SUPPORT NARROWED | rule | 0.11 | 0.05 | 16.8 |
| FACES THE THREAT | rule | - | 0.11 | 16.0 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.11 | 45.8 |
| WAR ENGINE JOBS | rule | - | 0.11 | 70.6 |
| AFTERMATH BAND | gate | - | 0.05 | 3.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.05 | - | 8.7 |
| CARRIES OUT COUNTER | rule | - | 0.05 | 12.7 |
| LONE WIZARD HOLDS BACK | rule | - | 0.05 | 17.5 |
| MARCH ODDS | rule | - | 0.05 | 3.6 |
| NO REASON | gate | 0.05 | - | 28.2 |
| RULE SWITCHED OFF | gate | - | 0.05 | 6.1 |
| STOPS SHORT OF THE FLANK | rule | - | 0.05 | 0.8 |
| THROUGH LINE OF FIRE | rule | - | 0.05 | 2.3 |

### Plans: t9-mine-e62ea8a-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.6 | 63% | 220 | 179 | 81% |
| Mine | join | 0.5 | 100% | 11 | 0 | 0% |
| Mine | move | 25.1 | 92% | 1486 | 0 | 0% |
| Mine | shoot | 12.2 | 55% | 491 | 805 | 164% |
| Mine | support | 0.2 | 75% | 0 | 0 | 0% |
| Opponent | advance | 10.9 | 17% | 134 | 265 | 198% |
| Opponent | charge | 4.3 | 48% | 341 | 318 | 93% |
| Opponent | close in | 6.3 | 25% | 427 | 129 | 30% |
| Opponent | hold | 6.3 | 42% | 480 | 0 | 0% |
| Opponent | join | 1.2 | 100% | 55 | 0 | 0% |
| Opponent | shoot | 5.8 | 55% | 112 | 286 | 255% |
| Opponent | support | 4.6 | 85% | 28 | 0 | 0% |

### Packages: hunt the guns, t9-mine-e62ea8a-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Opponent | 0.4 | 8 | 0 | 12% | 12% | 0% | 3.0 | 340 | 16 | 12% | 70 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 576 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 80 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 2.0 | 4 | 0 | 0% | 0% | 0% | - | 284 | 0 | 0% | 72 |
| Vampire Counts | 0.5 | 2 | 0 | 50% | 50% | 0% | 3.0 | 354 | 64 | 50% | 72 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 238 |
| Wood Elf Realms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 108 |

### Battle groups: t9-mine-e62ea8a-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.5 | 36% | 60% | 0% | - | 20% | 0% | 0% | 70% | 10% |
| Opponent | REDIRECT COUNTER | 2.2 | 15% | 100% | 0% | - | 0% | 0% | 33% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t9-mine-e62ea8a-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 12 | 76 (12) | 55 | 21 | 37 | 67% | 2.5 | 124 (5) | 44 (6) | 0 (1) | 97 (7) | 48 (5) |
| Mine | Character | 73 | 43 (73) | 43 | 0 | 27 | 22% | 2.5 | 68 (26) | 38 (28) | 16 (10) | 42 (35) | 49 (29) |
| Mine | Clean-up | 7 | 87 (7) | 9 | 79 | 84 | 57% | 2.7 | 150 (3) | 12 (4) | - | 126 (4) | 15 (3) |
| Mine | Fast Hammer | 22 | 33 (22) | 18 | 16 | 30 | 50% | 1.8 | 21 (12) | 46 (8) | 47 (2) | 47 (15) | 0 (7) |
| Mine | Hammer | 36 | 35 (36) | 18 | 17 | 29 | 17% | 2.4 | 37 (15) | 29 (17) | 60 (4) | 35 (24) | 36 (12) |
| Mine | Holder | 15 | 50 (15) | 0 | 50 | 34 | 60% | 3.5 | 47 (10) | 57 (4) | 36 (1) | 54 (8) | 44 (7) |
| Mine | Shooter | 19 | 52 (19) | 24 | 28 | 41 | 0% | 1.6 | 80 (5) | 47 (10) | 36 (4) | 60 (17) | 0 (2) |
| Mine | War machine | 44 | 24 (44) | 24 | 0 | 52 | 7% | 1.2 | 25 (19) | 24 (25) | - | 19 (15) | 27 (29) |
| Mine | Wizard | 10 | 17 (10) | 17 | 0 | 22 | 40% | 3.5 | 15 (4) | 0 (2) | 31 (3) | 0 (2) | 22 (7) |
| Opponent | Chaff | 31 | 113 (31) | 24 | 90 | 63 | 52% | 2.6 | 70 (13) | 161 (14) | 125 (4) | 107 (20) | 128 (11) |
| Opponent | Character | 53 | 34 (53) | 34 | 0 | 22 | 28% | 2.4 | 25 (20) | 44 (25) | 32 (7) | 30 (28) | 41 (24) |
| Opponent | Clean-up | 13 | 33 (13) | 4 | 29 | 19 | 46% | 3.7 | 15 (6) | 64 (5) | 0 (2) | 60 (8) | 0 (5) |
| Opponent | Fast | 1 | 45 (1) | 45 | 0 | 100 | 0% | 2.0 | - | 45 (1) | - | 45 (1) | - |
| Opponent | Fast Hammer | 27 | 40 (27) | 33 | 7 | 36 | 41% | 3.0 | 50 (10) | 35 (14) | 20 (3) | 53 (14) | 24 (13) |
| Opponent | Hammer | 15 | 29 (15) | 23 | 6 | 48 | 40% | 2.9 | 0 (2) | 11 (9) | 80 (4) | 10 (9) | 61 (6) |
| Opponent | Holder | 23 | 70 (23) | 3 | 67 | 28 | 57% | 2.3 | 7 (4) | 126 (10) | 44 (7) | 79 (18) | 44 (3) |
| Opponent | Shooter | 16 | 55 (16) | 36 | 19 | 40 | 6% | 1.7 | 82 (7) | 38 (8) | 0 (1) | 62 (13) | 29 (3) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | War machine | 15 | 41 (15) | 41 | 0 | 21 | 7% | 1.4 | 0 (7) | 72 (7) | 100 (1) | 23 (4) | 46 (11) |
| Opponent | Wizard | 16 | 44 (16) | 44 | 0 | 30 | 31% | 2.5 | 99 (5) | 0 (6) | 0 (3) | 0 (6) | 95 (8) |

### Charged fights: t9-mine-e62ea8a-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 74 | 10 | 0.2 | 1.0 | 40 | 0 | +40 | 0 of 1 | 1 of 1 | - | +40 |
| Mine | Chaos Dwarfs | 4 | 312 | 170 | 2.0 | 1.0 | 85 | 62 | +23 | 5 of 8 | 6 of 8 | - | +23 |
| Mine | Dwarfen Mountain Holds | 3 | 453 | 70 | 1.0 | 1.3 | 70 | 63 | +7 | 2 of 3 | 2 of 3 | -60 | +41 |
| Mine | Empire of Man | 5 | 234 | 198 | 2.0 | 1.0 | 99 | 21 | +78 | 3 of 10 | 8 of 10 | - | +78 |
| Mine | Grand Cathay | 3 | 309 | 415 | 2.7 | 1.0 | 156 | 0 | +156 | 0 of 8 | 8 of 8 | - | +156 |
| **Mine** | all armies | 19 | 263 | 167 | 1.6 | 1.0 | 106 | 30 | +76 | 10 of 30 | 25 of 30 | -60 | +80 |
| Opponent | Empire of Man | 1 | 189 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 3 | 458 | 343 | 3.0 | 1.1 | 114 | 0 | +114 | 5 of 9 | 6 of 9 | +0 | +128 |
| Opponent | High Elf Realms | 3 | 358 | 647 | 3.0 | 1.3 | 216 | 0 | +216 | 4 of 9 | 8 of 9 | +74 | +287 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 92 | -92 | 3 of 3 | 1 of 3 | +0 | -138 |
| Opponent | Skaven | 1 | 60 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 398 | 3.5 | 1.1 | 114 | 89 | +24 | 3 of 7 | 4 of 7 | +332 | -27 |
| Opponent | Vampire Counts | 4 | 0 | 198 | 3.5 | 1.1 | 57 | 71 | -14 | 4 of 14 | 7 of 14 | -369 | +13 |
| Opponent | Warriors of Chaos | 3 | 0 | 328 | 2.3 | 1.1 | 141 | 0 | +141 | 4 of 7 | 5 of 7 | +0 | +164 |
| Opponent | Wood Elf Realms | 1 | 95 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 19 | 147 | 292 | 2.6 | 1.2 | 111 | 38 | +73 | 24 of 50 | 32 of 50 | +23 | +82 |

### Effective charges: t9-mine-e62ea8a-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +40) | 0 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 8 | 2 (net +247) | 0 | 1 (net -189) | 1 (net +0) | 0 | 4 (net -31) | 0 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net -60) | 0 | 0 | 0 | 1 (net +0) | 1 (net +82) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 10 | 2 (net +134) | 0 | 0 | 4 (net -12) | 0 | 4 (net +140) | 0 | 0% (0 of 10) |
| Mine | Grand Cathay | 8 | 0 | 1 (net +0) | 1 (net +315) | 2 (net +70) | 2 (net +85) | 2 (net +310) | 0 | 12% (1 of 8) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Grand Cathay | 9 | 1 (net +0) | 1 (net +583) | 4 (net +55) | 2 (net +0) | 0 | 0 | 1 | 50% (4 of 8) |
| Opponent | High Elf Realms | 9 | 0 | 0 | 1 (net +0) | 1 (net +726) | 2 (net +110) | 4 (net +217) | 1 | 12% (1 of 8) |
| Opponent | Kingdom of Bretonnia | 3 | 2 (net -138) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +332) | 1 (net +0) | 1 (net +0) | 1 (net -431) | 3 | 25% (1 of 4) |
| Opponent | Vampire Counts | 14 | 6 (net -30) | 1 (net -443) | 2 (net +75) | 1 (net -45) | 1 (net +65) | 1 (net +110) | 2 | 17% (2 of 12) |
| Opponent | Warriors of Chaos | 7 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +300) | 0 | 1 (net +214) | 2 | 20% (1 of 5) |

### Charged fights, damage counted: t9-mine-e62ea8a-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 259 | 324 | +140 | 205 | 139 | +66 | +25.6 |
| Mine | 50-54% | 1 | 233 | 170 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 2 | 186 | 268 | +63 | 158 | 94 | +63 | +33.9 |
| Mine | 76-89% | 7 | 221 | 108 | +13 | 53 | 44 | +9 | +4.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 220 | 169 | +98 | 175 | 67 | +109 | +49.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 262 | 69 | +57 | 63 | 0 | +63 | +24.1 |
| Mine | All fights | 30 | 229 | 177 | +76 | 134 | 66 | +67 | +29.3 |
| Opponent | Long shot (under 50%) | 10 | 331 | 318 | -46 | 59 | 117 | -59 | -17.7 |
| Opponent | 50-54% | 2 | 139 | 347 | +70 | 346 | 222 | +124 | +89.4 |
| Opponent | Effective (55-75%) | 10 | 330 | 236 | +70 | 163 | 103 | +60 | +18.3 |
| Opponent | 76-89% | 7 | 338 | 248 | +183 | 206 | 63 | +143 | +42.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 284 | 201 | +109 | 170 | 62 | +109 | +38.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 514 | 126 | +72 | 92 | 0 | +92 | +17.8 |
| Opponent | No odds | 10 | 357 | 156 | +93 | 107 | 0 | +107 | +30.0 |
| Opponent | All fights | 50 | 338 | 229 | +73 | 140 | 70 | +69 | +20.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t9-mine-e62ea8a-p3 | move | 156 | 29 (19%) | 16 (10%) | 29 (19%) | 98 (63%) |
| t9-mine-e62ea8a-p3 | objective | 120 | 24 (20%) | 6 (5%) | 15 (12%) | 81 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725 |
| Elixir of Power | Mine | L1122 |
| Elixir of Power | Opponent | L0311 |
| Horn of the Wild Hunt | Opponent | L0533 |
| Invocation of Nehek | Opponent | L0327, L0725 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831 |
| Ring of Jet | Mine | L1013, L1030, L1122 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

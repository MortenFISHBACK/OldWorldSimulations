# Doctrine scorecard: t9-opp-e62ea8a-p1

### Scorecard: t9-opp-e62ea8a-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 15 | 4 | 0 | 0 | 1 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 0 | 1 | 2 | 2 | 1 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 4 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 68 |
| L0135 | 3 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | yes | 8 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 200 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 8 | 2 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 4 | 4 | 1 | 3 | 0 | 0 | 0 | 55 |
| L0405 | 3 | 1 | Mine | yes | 6 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 518 |
| L0421 | 1 | 1 | Mine | no | 2 | 1 | 2 | 1 | 0 | 0 | 0 | 139 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 5 | 2 | 0 | 1 | 0 | 0 | 0 | 986 |
| L0508 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 344 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 698 |
| L0524 | 2 | 1 | Opponent | - | - | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 7 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 6 | 0 | 2 | 0 | 0 | 0 | 743 |
| L0628 | 4 | 1 | Opponent | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 10% | 4.0 | 2.8 | 0.9 | 1.4 | 0.2 | 0.0 | 0.0 | 330.9 |
| **Average** | | | Opponent | 10% | 2.7 | 2.9 | 1.7 | 2.0 | 0.1 | 0.0 | 0.0 | 125.8 |

### KPIs: t9-opp-e62ea8a-p1

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 37% (19 of 52) | 10% (6 of 58) | 23% (25 of 110) |
| Winner chose to follow up after the loser gave ground |  | 100% (19 of 19); on the table 100% | 77% (17 of 22); on the table 95% | 88% (36 of 41); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | 71% (5 of 7); on the table 86% | 67% (6 of 9); on the table 78% |
| Winner chose to pursue after the loser fled |  | 75% (6 of 8); on the table 88% | 75% (6 of 8); on the table 75% | 75% (12 of 16); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 90% (26 of 29); on the table 93% | 76% (28 of 37); on the table 89% | 82% (54 of 66); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 44% (64 of 144) | 25% (21 of 84) | 37% (85 of 228) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (64 of 113) | 31% (21 of 68) | 47% (85 of 181) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (4 of 10) | 55% (6 of 11) | 48% (10 of 21) |
| Points that never fought | lower | 45% (10622 of 23495) | 57% (13592 of 23896) | 51% (24214 of 47391) |
|   infantry points that never fought | lower | 42% (3274 of 7733) | 62% (2753 of 4458) | 49% (6027 of 12191) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 69% (59 of 85) | 57% (58 of 101) | 63% (117 of 186) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 1.8 uses a game | 60% (6 of 10); 1.8 uses a game | 71% (12 of 17); 1.8 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 0.6 uses a game | 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.4 uses a game | 83% (5 of 6); 0.4 uses a game | 71% (10 of 14); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (11669 of 17468) | 57% (11850 of 20862) | 61% (23519 of 38330) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (34%) | 2.2 (43%) | 4.5 (38%) |
| MARCHED: its unit marched | 1.6 (24%) | 0.9 (17%) | 2.5 (21%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.2 (3%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.6 (24%) | 0.8 (14%) | 2.3 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| GONE: slain | 1.0 (15%) | 0.2 (3%) | 1.2 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.4 (8%) | 0.4 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 0.7 | 1.7 | 7.1 | 0.6 | 3.0 |
| not cast | 4.0 | 3.8 | 5.8 | 11.9 | 1.4 | 24.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (2%) | 1.2 (30%) | 0.8 (14%) | 4.5 (38%) | 0.2 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (21%) | 0.2 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.2 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (8%) | 0.5 (13%) | 0.7 (11%) | 2.3 (20%) | 0.3 (24%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (12%) | 1.0 (26%) | 1.0 (17%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (2%) | 0.0 (0%) | 0.2 (1%) | 0.0 (0%) | 0.8 (3%) |
| GONE: slain | 0.7 (17%) | 0.5 (13%) | 1.2 (20%) | 1.2 (10%) | 0.3 (24%) | 0.4 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.6 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (6%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (52%) | 0.4 (11%) | 2.2 (37%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.1 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 0.5 a game | 1.1 a game |
| stood (cast and not dispelled) | 67% (14 of 21) | 67% (4 of 6) | 67% (18 of 27) |
| the unit moved after it | 64% (9 of 14) | 50% (2 of 4) | 61% (11 of 18) |
| it charged on its next turn | 0% (0 of 14) | 0% (0 of 4) | 0% (0 of 18) |
| the enemy charged it first | 50% (7 of 14) | 0% (0 of 4) | 39% (7 of 18) |
| it fought by the end of its next turn | 36% (5 of 14) | 0% (0 of 4) | 28% (5 of 18) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (1 of 14) | 0% (0 of 4) | 6% (1 of 18) |
| none of these (no charge, no fight, no charge escaped) | 43% (6 of 14) | 100% (4 of 4) | 56% (10 of 18) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 55% (191 of 346) | 51% (124 of 243) | 53% (315 of 589) |
|   cavalry | 29% (6 of 21) | 48% (16 of 33) | 41% (22 of 54) |
|   character | 81% (39 of 48) | 65% (28 of 43) | 74% (67 of 91) |
|   chariot | 41% (12 of 29) | 53% (17 of 32) | 48% (29 of 61) |
|   infantry | 55% (55 of 100) | 32% (24 of 74) | 45% (79 of 174) |
|   monster | 57% (4 of 7) | 69% (9 of 13) | 65% (13 of 20) |
|   war machine | 53% (75 of 141) | 62% (30 of 48) | 56% (105 of 189) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (21%) | 2.3 (24%) | 5.1 (22%) |
| CHARGED: it charged | 1.2 (10%) | 0.9 (9%) | 2.2 (9%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 0.6 (6%) | 1.2 (5%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.7 (7%) | 0.7 (3%) |
| NO TARGET IN RANGE | 2.2 (17%) | 2.8 (28%) | 4.9 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (4%) | 0.5 (5%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.1 (39%) | 0.7 (7%) | 5.8 (25%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.8 (8%) | 1.2 (5%) |
| OTHER BAR | 0.2 (1%) | 0.5 (5%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.8 | 0.8 | 79% | 8.1 pts | 22 pts |
| character | 5.8 | 2.3 | 77% | 8.8 pts | 51 pts |
| chariot | 2.6 | 2.3 | 65% | 12.2 pts | 32 pts |
| infantry | 10.0 | 3.6 | 71% | 8.6 pts | 86 pts |
| monster | 1.1 | 0.6 | 62% | 13.1 pts | 14 pts |
| war machine | 8.8 | 5.7 | 67% | 17.3 pts | 151 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 3.8 | 3.6 |
| Charges that made contact a game | 2.8 | 3.1 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.25 declared, 0.00 contact (4 units) | 1.00 declared, 0.75 contact (4 units) | 0.62 declared, 0.38 contact (8 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 1.50 contact (2 units) | 1.50 declared, 1.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.41 contact (81 units) | 0.41 declared, 0.33 contact (95 units) | 0.44 declared, 0.36 contact (176 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 38% (5 of 13) | 67% (2 of 3) | 50% (1 of 2) | 44% (8 of 18) |
| Character in a unit | 86% (19 of 22) | 83% (15 of 18) | 0% (0 of 1) | 83% (34 of 41) |
| Character on its own | 73% (8 of 11) | 67% (8 of 12) | 62% (5 of 8) | 68% (21 of 31) |
| Chariot | 83% (5 of 6) | 71% (5 of 7) | - | 77% (10 of 13) |
| Infantry | 44% (11 of 25) | 33% (7 of 21) | 0% (0 of 1) | 38% (18 of 47) |
| Monster | 80% (4 of 5) | 67% (2 of 3) | - | 75% (6 of 8) |
| Monstrous | 100% (4 of 4) | 67% (4 of 6) | - | 80% (8 of 10) |
| War Machines | 65% (11 of 17) | 100% (1 of 1) | - | 67% (12 of 18) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 80% (24 of 30); on the table 90% | 44% (61 of 138) | 35% | 64% (21 of 33) | 89% (8 of 9); 5.0 uses a game | 67% (2 of 3); 1.2 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 100% (3 of 3); on the table 100% | 29% (7 of 24) | 57% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (6 of 6); on the table 100% | - | 60% | 71% (29 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | 100% (1 of 1); on the table 100% | - | 72% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Grand Cathay | 1 | 86% (6 of 7); on the table 100% | 22% (4 of 18) | 61% | 44% (4 of 9) | 67% (2 of 3); 4.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 2 | 67% (6 of 9); on the table 78% | 0% (0 of 6) | 49% | 86% (12 of 14) | 100% (2 of 2); 4.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 50% (1 of 2); on the table 50% | 50% (6 of 12) | 77% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 100% | 33% (2 of 6) | 24% | 56% (5 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 52% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 45% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 56% | 58% (14 of 24) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t9-opp-e62ea8a-p1, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (11) | 20% (3) | 38% (14) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.25 | 0.92 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.00 | 0.17 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.08 | 0.50 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.92 | 0.00 | 0.92 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.17 | 0.00 | 0.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 3.00 | 0.00 | 3.00 |

### Quality by phase: t9-opp-e62ea8a-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 61% (20 of 33) | 41% (17 of 41) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (68 of 143) | 47% (35 of 75) |
| Strategy | Close-in objectives charged next turn | 17% (6 of 36) | - |
| Strategy | Support requests answered (helper made contact too) | 75% (6 of 8) | 83% (5 of 6) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 25% (1 of 4) |
| Strategy | Joined characters whose unit fought | 71% (24 of 34) | 18% (4 of 22) |
| Strategy | Lone characters that fought | 61% (14 of 23) | 50% (12 of 24) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.4 | 2.0 |
| Movement | Points that never moved of their own | 330.9 | 125.8 |
| Movement | Fights charged into per game | 2.0 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 22, net -23 | 7 of 27, net +7 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 22, net +0 | 5 of 27, net -47 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 22, net +62 | 3 of 27, net +120 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 of 22, net +126 | 8 of 27, net +193 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (57 of 124) | 56% (56 of 100) |
| Shooting | Points destroyed by shooting units | 68.8 | 55.2 |
| Shooting | War machine shots | 6.2 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (45 of 75) | 47% (14 of 30) |
| Shooting | Points destroyed by war machines | 32.7 | 98.2 |
| Magic | Magic missiles cast | 2.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (8 of 32) | 62% (10 of 16) |
| Magic | Wounds caused by magic missiles | 6.3 | 1.8 |
| Magic | Wounds caused by other spells | 1.7 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 53.7 | 62.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.1 / 1.5 / 0.2 | 1.5 / 0.3 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 168.3 | 226.2 |
| Combat | Points run down | 59.9 | 84.2 |
| Combat | Net points per charged fight, damage counted | +105 | +66 |
| Combat | Net per 100 charger points, damage counted | +39.4 | +28.1 |
| Combat | First round won (charged fights) | 88% | 73% |
| Combat | Net points per charged fight | +96 | +75 |
| Combat | Net points per supported fight / lone fight | +9 / +119 | +108 / +68 |
| Combat | Charged fights on a top-3 enemy unit | 9 of 24 | 16 of 30 |
| Game | Points lost | 568.0 | 590.2 |
| Game | VP from objectives | 621.7 | 753.3 |
| Game | Lone holders (player turns) | 4.0 | 2.7 |

- Mine won / drew / lost: 4 / 3 / 5 of 12 ended games (of 12); mean margin (Mine - Opponent) -114 VP
- The side that went first won 1 of 9 games with a winner
- Points traded per game (both sides' losses): 1158
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t9-opp-e62ea8a-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.3 | -141.2 | 73.8 | 33.8 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.6 | +40.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 28.3 | 1.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| BEST FACING | 0.2 | +7.0 | 0.0 | 24.1 | - | - | - | - |
| BEST FIRST | 0.5 | +13.1 | 0.0 | 8.8 | - | - | - | - |
| BEST MOVE FOR SHOOTERS | 1.0 | +59.1 | 0.0 | 25.8 | - | - | - | - |
| BEST PREY | 0.9 | +83.0 | 28.5 | 50.9 | - | - | - | - |
| BLOCKED WHEEL | 0.4 | +5.5 | 0.0 | 6.8 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | +0.8 | 0.0 | 0.0 | 0.2 | -6.0 | 0.0 | 19.0 |
| CANNON PLAN MISSED | 0.5 | +0.0 | 51.8 | 7.9 | 0.3 | +0.0 | 24.5 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +79.0 | 155.8 | 70.4 | 2.2 | +80.1 | 317.4 | 50.8 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.2 | +2.3 | 10.0 | 0.0 | 0.2 | +1.3 | 5.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.8 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.6 | +169.7 | 110.7 | 0.0 | 0.3 | +56.8 | 33.9 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 10.8 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.2 | +67.9 | 0.0 | 21.2 | 0.6 | +19.2 | 0.0 | 3.0 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | -0.1 | 0.0 | 51.6 |
| CHARACTER GUNS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 6.1 | -383.6 | 0.0 | 176.6 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 15.4 | 0.0 | 1.1 | +0.0 | 14.2 | 51.2 |
| CHARGE NOW FIRST | 1.1 | +0.0 | 126.0 | 47.1 | 1.8 | +0.0 | 129.5 | 19.0 |
| CHARGE NOW WEIGHED | 0.4 | -50.6 | 5.0 | 0.0 | - | - | - | - |
| CHARGER SLAIN LOST | 0.8 | -21.0 | 45.8 | 7.1 | 0.5 | -8.8 | 24.1 | 23.3 |
| CHEAP HELPER | 0.3 | +0.0 | 9.5 | 7.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.5 | -41.0 | 48.1 | 0.0 |
| COMBAT PIVOT | 0.1 | +0.0 | 0.0 | 14.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.1 | +135.7 | 0.0 | 10.8 | 0.2 | +32.9 | 0.0 | 22.8 |
| COVER ONCE | 4.7 | -339.1 | 0.0 | 58.4 | 4.9 | -268.3 | 0.0 | 56.5 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 5.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.2 | +34.8 | 0.0 | 14.2 | 8.0 | +8.9 | 0.0 | 27.9 |
| EDGE GIVE GROUND | 0.2 | +2.2 | 50.4 | 0.0 | 0.2 | +0.6 | 9.2 | 4.3 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.9 | +76.2 | 0.0 | 53.2 | - | - | - | - |
| FALL BACK GOOD ORDER | - | - | - | - | 2.7 | +1.5 | 140.8 | 61.7 |
| FALLBACK BY WORTH | 3.0 | +19.9 | 0.0 | 27.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 13.0 | +195.7 | 0.0 | 174.4 |
| FEATURE BUFFS | - | - | - | - | 0.1 | +2.5 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.3 | +16.0 | 41.9 | 17.6 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 7.9 | 0.0 |
| FIVE ACTION | - | - | - | - | 43.8 | +2899.7 | 814.8 | 666.4 |
| FLANK NOT WEIGHED | 2.9 | +0.0 | 0.0 | 105.3 | 5.0 | +0.0 | 0.0 | 60.2 |
| FOCUS FIRE | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.5 | +61.7 | 0.0 | 0.0 | 0.7 | +83.8 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 3.3 | +150.1 | 164.8 | 66.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -1.6 | 0.0 | 10.4 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.4 | -27.2 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +13.7 | 0.0 | 0.0 | 0.1 | +2.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.2 | -0.8 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.2 | -0.4 | 18.8 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.1 | +0.6 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| GUN FIGURES | 0.7 | +16.6 | 17.5 | 25.8 | 0.9 | +14.3 | 7.1 | 20.8 |
| GUN MASK | - | - | - | - | 0.7 | +7.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 1.2 | +0.0 | 0.0 | 49.3 |
| HE SHOOTS OR CHARGES | - | - | - | - | 3.0 | +0.0 | 0.0 | 52.1 |
| HELPER ALREADY ASKED | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 24.1 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.4 | +15.3 | 7.1 | 0.0 |
| HIS CHARGE LIST | - | - | - | - | 2.2 | +0.0 | 0.0 | 30.8 |
| HIS LEGAL MOVES | - | - | - | - | 4.3 | +0.0 | 0.0 | 56.2 |
| HIS MOVE AND SHOT | - | - | - | - | 1.5 | -84.8 | 0.0 | 113.4 |
| HIS RANDOM MOVE | - | - | - | - | 1.9 | +0.0 | 0.0 | 69.3 |
| HIS SHOT LIST | - | - | - | - | 20.7 | +1364.8 | 0.0 | 336.6 |
| HIS TURN DENIED | - | - | - | - | 1.8 | +132.0 | 72.6 | 66.0 |
| HOLDER AT DEPLOYMENT | 1.0 | +186.9 | 0.0 | 0.0 | 0.9 | +177.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.4 | -67.7 | 238.3 | 140.2 | 2.3 | -69.8 | 109.6 | 14.8 |
| IDLE COST | 13.6 | -224.3 | 0.0 | 131.2 | 8.2 | -157.9 | 0.0 | 165.6 |
| INVITES THE FIGHT | 1.3 | +5.4 | 5.0 | 25.0 | - | - | - | - |
| JOINT CHARGE PLAN | 0.2 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -5.3 | 0.0 | 0.0 | 0.2 | -4.4 | 0.0 | 7.1 |
| KEEP FALLS | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 0.9 | +27.5 | 18.6 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.5 | +3.5 | 32.6 | 0.0 | - | - | - | - |
| KILLS COUNT NEXT TURN | 3.0 | +96.3 | 33.2 | 78.8 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +21.8 | 0.0 | 0.0 | 0.2 | +16.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 3.0 | +0.0 | 98.4 | 128.8 |
| LONE CHARACTER SAFE SPOT | 0.1 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 1.1 | +96.7 | 0.0 | 0.0 | 0.3 | +37.7 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +2.8 | 14.5 | 7.1 | 0.5 | +3.0 | 0.0 | 51.2 |
| LOST CHARGE | 1.8 | -37.1 | 36.1 | 38.3 | 0.1 | -0.2 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +4.8 | 0.0 | 9.3 | 0.2 | +2.4 | 0.0 | 4.3 |
| MANOEUVRE | 0.2 | +4.5 | 0.0 | 0.0 | 1.5 | +66.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.4 | +10.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.2 | +0.9 | 0.0 | 0.0 | 1.2 | +80.1 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +32.5 | 25.8 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.4 | +38.3 | 0.0 | 48.3 | 1.0 | +106.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.8 | +66.4 | 0.0 | 36.2 | 6.2 | +63.2 | 0.0 | 51.3 |
| MISSILES IN THE MOVE | 4.2 | +269.0 | 0.0 | 33.6 | 3.9 | +165.2 | 0.0 | 109.9 |
| MISSILES NEXT TURN | 4.1 | +175.1 | 0.0 | 55.1 | 4.8 | +76.1 | 0.0 | 128.4 |
| MODEL FACING | 0.6 | +172.1 | 0.0 | 5.0 | - | - | - | - |
| MOVE AND CAST | 0.2 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.1 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.5 | -122.8 | 5.4 | 77.9 | 0.1 | -1.4 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.3 | +103.3 | 72.2 | 66.4 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 3.7 | +364.5 | 0.0 | 28.5 |
| MOVES UNITS SPELL | 0.2 | +9.2 | 0.0 | 0.0 | 0.2 | +5.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | - | - | - | - | 4.9 | +364.4 | 0.0 | 19.5 |
| NEXT CHARGE BY LIST | - | - | - | - | 5.3 | -210.5 | 7.1 | 35.2 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 11.2 | -735.5 | 125.6 | 75.4 |
| NO DOUBLE ROUNDS | - | - | - | - | 2.8 | -90.1 | 93.8 | 61.7 |
| NO RALLY LEFT | 0.2 | +25.1 | 0.0 | 24.1 | - | - | - | - |
| NOT NEEDED | 0.2 | -7.0 | 19.0 | 7.1 | - | - | - | - |
| NOT TURNED | 3.0 | +73.8 | 0.0 | 54.4 | - | - | - | - |
| NOT WORTH A CAST | 0.5 | -0.8 | 0.0 | 29.6 | 0.3 | -0.6 | 0.0 | 22.8 |
| OFF BEST | 18.3 | -974.4 | 10.4 | 188.2 | 0.2 | -0.7 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | - | - | - | - | 0.9 | +0.0 | 0.0 | 9.3 |
| ONE FIGHT FORMULA | 6.8 | -90.5 | 5.0 | 165.7 | 5.1 | -130.4 | 0.0 | 60.2 |
| ONE OBJECTIVE FORMULA | 1.9 | -72.7 | 0.0 | 10.4 | 2.9 | +52.0 | 0.0 | 9.5 |
| ONE TARGET A SHOOTER | - | - | - | - | 17.0 | +566.1 | 0.0 | 173.6 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +21.6 | 5.4 | 0.0 | 0.1 | +5.3 | 9.2 | 0.0 |
| OVERRUNS AWAY | 0.4 | +2.9 | 36.2 | 0.0 | 0.3 | +10.2 | 48.8 | 0.0 |
| PATHS CROSS | 0.9 | +23.0 | 0.0 | 35.6 | 5.3 | +152.6 | 0.0 | 25.1 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -0.6 | 0.0 | 0.0 |
| PLAN RESULT | 34.3 | +1127.3 | 873.4 | 699.2 | 38.2 | +619.5 | 531.3 | 756.5 |
| PURSUES BIG PREY | 0.3 | -38.1 | 0.0 | 0.0 | 0.1 | -8.1 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +5.9 | 0.0 | 14.2 | 0.9 | +23.7 | 0.0 | 53.8 |
| RANDOM MOVER NO PROMISE | 0.3 | -18.4 | 9.5 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 1.1 | -42.5 | 0.0 | 21.2 | 0.1 | -4.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.9 | +144.9 | 0.0 | 45.6 | 3.5 | +133.8 | 0.0 | 32.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.4 | -23.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 7.1 |
| RESERVE FALL BACK | 0.2 | +46.5 | 0.0 | 9.3 | 0.2 | +0.9 | 0.0 | 9.5 |
| RESTRAINS TO SHOOT | 0.1 | +1.9 | 0.0 | 0.0 | 0.2 | +18.7 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +33.8 | 135.8 | 26.7 | 2.4 | +69.1 | 121.8 | 61.7 |
| RISK BY HIS FIGURE | - | - | - | - | 12.5 | -271.0 | 0.0 | 238.1 |
| RISK ONCE | 3.7 | +125.7 | 0.0 | 184.6 | - | - | - | - |
| RUN DOWN | - | - | - | - | 2.5 | -18.9 | 92.8 | 33.8 |
| SAFER THAN THE JOB | 0.2 | +11.9 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.2 | +0.5 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 5.7 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 5.7 |
| SCREEN BY WHAT IT SAVES | 0.1 | -13.4 | 0.0 | 0.0 | 0.1 | -16.5 | 0.0 | 5.0 |
| SEARCH SPOT | 2.1 | +81.6 | 0.0 | 46.1 | 6.0 | +299.1 | 0.0 | 104.9 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | -1.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.5 | +40.7 | 0.0 | 9.3 | 0.2 | +2.4 | 0.0 | 4.3 |
| SET-UP ANY TARGET | 0.5 | +67.5 | 0.0 | 10.8 | 0.1 | +4.8 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.1 | +14.0 | 0.0 | 22.8 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +51.0 | 76.8 | 15.0 | 0.7 | +23.4 | 55.4 | 20.8 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.4 | -12.2 | 48.2 | 0.0 |
| SHOT RISK POINTS | - | - | - | - | 14.6 | +24.2 | 0.0 | 334.2 |
| SHOTS IN THE MOVE | 12.8 | +398.0 | 0.0 | 200.4 | 10.7 | +556.1 | 0.0 | 201.8 |
| SPELL CATCH ODDS | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.7 | +144.3 | 0.0 | 10.8 | 0.1 | +4.8 | 0.0 | 0.0 |
| SPELL WORTH | 0.2 | +0.9 | 0.0 | 0.0 | 2.3 | +48.8 | 90.0 | 90.0 |
| SPELLS IN THE FIGHT | 0.2 | -0.5 | 50.4 | 0.0 | 0.5 | -22.1 | 15.5 | 44.1 |
| STABLE ROLE | 12.8 | +0.0 | 266.3 | 113.1 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.6 | -3.7 | 39.3 | 4.3 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 20.9 |
| STANDS STILL | - | - | - | - | 12.0 | +0.0 | 625.8 | 114.1 |
| STANDS TO CAST | 0.2 | +27.3 | 14.2 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.2 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 20.7 | +94.9 | 423.8 | 314.3 | 13.7 | +229.7 | 425.0 | 237.8 |
| STOPS SHORT OF THE FLANK | 0.2 | +9.7 | 0.0 | 8.8 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 14.2 | 0.2 | +0.0 | 0.0 | 12.1 |
| SUPPORT NARROWED | 3.2 | -15.8 | 187.2 | 37.1 | 1.3 | +0.0 | 55.2 | 0.0 |
| SUPPORTS | 2.2 | +15.8 | 72.2 | 10.4 | - | - | - | - |
| SURE REACH TOGETHER | 0.8 | +8.4 | 0.0 | 5.4 | 0.3 | +14.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 5.1 | +0.0 | 0.0 | 34.4 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -16.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.6 | +0.0 | 0.0 | 10.4 |
| THROUGH LINE OF FIRE | 0.3 | +12.0 | 0.0 | 0.0 | - | - | - | - |
| TIED UP BY THE SUM | - | - | - | - | 0.4 | +53.9 | 44.2 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 16.2 | +219.2 | 5.4 | 156.7 |
| TURN WORTH | 0.7 | -24.1 | 71.5 | 14.2 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.4 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| WAIT AFTER COSTS | 6.1 | -273.0 | 92.1 | 125.2 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.2 | +0.0 | 0.0 | 18.1 |
| WALKS TO THE FIGHT | 2.5 | +22.9 | 23.3 | 33.8 | - | - | - | - |
| WAR ENGINE CHARGES | 0.2 | +21.1 | 17.5 | 25.8 | 0.1 | +20.9 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 94.6 | 0.0 | 0.2 | +0.0 | 7.1 | 15.4 |
| WEARS DOWN | 1.2 | +56.3 | 117.0 | 52.5 | - | - | - | - |
| WHO HITS BACK | 0.4 | +68.1 | 0.0 | 7.1 | 0.2 | +12.0 | 0.0 | 17.5 |
| WHOLE FIGHT | 0.2 | +16.4 | 15.4 | 0.0 | 0.3 | +14.2 | 22.6 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +31.0 | 9.5 | 12.5 | 0.2 | +53.2 | 48.2 | 0.0 |
| WIDER SPREAD | 2.2 | -4.3 | 165.2 | 47.1 | 2.4 | +15.5 | 125.5 | 58.9 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.8 | +157.7 | 0.0 | 18.5 |

### Rule changes: t9-opp-e62ea8a-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 222 | 222 | 222 | 18.50 | -11700 | -52.7 |
| DEPLOY BY FIGURES | 206 | 206 | 133 | 11.08 | +1848 | +13.9 |
| SEARCH SPOT | 97 | 97 | 90 | 7.50 | +4574 | +50.8 |
| HIS SHOT LIST | 248 | 248 | 87 | 7.25 | +2003 | +23.0 |
| FIVE ACTION | 526 | 526 | 83 | 6.92 | +2055 | +24.8 |
| PATHS CROSS | 75 | 75 | 75 | 6.25 | +2107 | +28.1 |
| ONE TARGET A SHOOTER | 204 | 204 | 67 | 5.58 | +991 | +14.8 |
| TIME ON OUR SIDE | 195 | 182 | 41 | 3.42 | +124 | +3.0 |
| SHOTS IN THE MOVE | 282 | 231 | 38 | 3.17 | +1061 | +27.9 |
| LEGAL CHARGES ONLY | 36 | 36 | 36 | 3.00 | +0 | +0.0 |
| SHOT RISK POINTS | 175 | 175 | 33 | 2.75 | +1005 | +30.4 |
| MOVE TO CHARGE COMPUTED | 44 | 44 | 32 | 2.67 | +2160 | +67.5 |
| STAY WORTH | 412 | 367 | 28 | 2.33 | +337 | +12.0 |
| ARTILLERY RE-ROLL WEIGHED | 26 | 26 | 26 | 2.17 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 135 | 135 | 26 | 2.17 | +228 | +8.8 |
| CANNON SIGHT KEPT | 24 | 24 | 24 | 2.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 97 | 67 | 22 | 1.83 | +952 | +43.3 |
| CANNON PLANNED TARGET | 92 | 92 | 21 | 1.75 | -91 | -4.3 |
| COVER ONCE | 115 | 80 | 19 | 1.58 | +183 | +9.6 |
| KILLS COUNT NEXT TURN | 36 | 36 | 18 | 1.50 | +577 | +32.0 |
| ADVANCE LANE KEPT | 17 | 17 | 17 | 1.42 | +0 | +0.0 |
| CASTING BLOCK | 23 | 23 | 17 | 1.42 | +871 | +51.2 |
| LONE WIZARD KEPT IN | 17 | 17 | 17 | 1.42 | +1613 | +94.9 |
| ADVANCE WORTH | 64 | 64 | 16 | 1.33 | +369 | +23.1 |
| CHARGE NOT DECLARED | 16 | 16 | 16 | 1.33 | -1866 | -116.6 |
| MANOEUVRE | 20 | 20 | 16 | 1.33 | +854 | +53.4 |
| HARD STAY DROPPED | 15 | 15 | 15 | 1.25 | +0 | +0.0 |
| IDLE COST | 261 | 168 | 15 | 1.25 | +132 | +8.8 |
| RISK ONCE | 44 | 32 | 15 | 1.25 | +528 | +35.2 |
| CASTER AWAY FROM SCREEN | 14 | 14 | 14 | 1.17 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 14 | 14 | 14 | 1.17 | +1746 | +124.7 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 14 | 1.17 | +261 | +18.6 |
| CHAFF IN THE MOVE | 21 | 20 | 13 | 1.08 | +325 | +25.0 |
| FOUR ROUNDS | 40 | 40 | 13 | 1.08 | +699 | +53.8 |
| BEST MOVE FOR SHOOTERS | 12 | 12 | 12 | 1.00 | +709 | +59.1 |
| HOLDER AT DEPLOYMENT | 23 | 23 | 12 | 1.00 | +396 | +33.0 |
| HOLDS AMBUSHERS | 12 | 12 | 12 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 18 | 18 | 12 | 1.00 | +308 | +25.7 |
| MOVE TO CHARGE | 28 | 28 | 12 | 1.00 | +347 | +28.9 |
| SHOOTERS IN TWO RANKS | 12 | 12 | 12 | 1.00 | +22 | +1.8 |
| WAIT AFTER COSTS | 73 | 73 | 12 | 1.00 | +119 | +9.9 |
| WALKS TO THE FIGHT | 30 | 30 | 12 | 1.00 | +90 | +7.5 |
| FACES THE THREAT | 11 | 11 | 11 | 0.92 | +915 | +83.2 |
| MAX FOR POSITIONING | 119 | 96 | 11 | 0.92 | +56 | +5.1 |
| NEXT CHARGE BY LIST | 64 | 64 | 11 | 0.92 | +35 | +3.2 |
| RISK BY ARC | 45 | 44 | 11 | 0.92 | +249 | +22.6 |
| SUPPORTS | 26 | 26 | 11 | 0.92 | +68 | +6.2 |
| RANDOM MOVE BY FIGURES | 21 | 21 | 10 | 0.83 | +355 | +35.5 |
| REDIRECT COUNTER | 65 | 47 | 10 | 0.83 | +754 | +75.4 |
| CHARGE LOSSES | 73 | 73 | 9 | 0.75 | +522 | +58.0 |
| SCOUT WAITS | 9 | 9 | 9 | 0.75 | +0 | +0.0 |
| FALLBACK BY WORTH | 37 | 37 | 8 | 0.67 | +238 | +29.8 |
| WHO HITS BACK | 8 | 8 | 8 | 0.67 | +865 | +108.1 |
| AFTERMATH IN POINTS | 7 | 7 | 7 | 0.58 | +481 | +68.7 |
| CHAFF PASSED | 7 | 7 | 7 | 0.58 | -2 | -0.3 |
| HIS TURN DENIED | 22 | 22 | 7 | 0.58 | +349 | +49.8 |
| LANE BY FIGURES | 7 | 7 | 7 | 0.58 | +455 | +65.0 |
| MODEL FACING | 7 | 7 | 7 | 0.58 | +2066 | +295.1 |
| SET UP TOGETHER | 20 | 17 | 7 | 0.58 | +206 | +29.4 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 0.58 | +0 | +0.0 |
| BEST FIRST | 6 | 6 | 6 | 0.50 | +157 | +26.1 |
| ONE FIGHT FORMULA | 143 | 86 | 6 | 0.50 | +24 | +4.0 |
| RISK BY HIS FIGURE | 150 | 150 | 6 | 0.50 | +357 | +59.5 |
| SURE REACH TOGETHER | 13 | 11 | 6 | 0.50 | +4 | +0.7 |
| BLOCKED WHEEL | 5 | 5 | 5 | 0.42 | +66 | +13.2 |
| CHARGE NOW WEIGHED | 5 | 5 | 5 | 0.42 | +523 | +104.6 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.42 | +198 | +39.7 |
| MARCH BY THE SUM | 5 | 5 | 5 | 0.42 | +122 | +24.5 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.42 | -555 | -110.9 |
| RESERVE FALL BACK | 5 | 5 | 5 | 0.42 | +569 | +113.7 |
| WOUNDS ON THE RANKS | 21 | 21 | 5 | 0.42 | +233 | +46.6 |
| BEST PREY | 11 | 11 | 4 | 0.33 | +339 | +84.9 |
| CHARGE NOW FIRST | 34 | 34 | 4 | 0.33 | -190 | -47.6 |
| MISSILES NEXT TURN | 107 | 73 | 4 | 0.33 | +81 | +20.4 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.33 | +170 | +42.4 |
| NEARER NOT NEEDED | 59 | 58 | 4 | 0.33 | +180 | +44.9 |
| ONE OBJECTIVE FORMULA | 58 | 34 | 4 | 0.33 | +184 | +46.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.33 | +248 | +62.0 |
| THROUGH LINE OF FIRE | 4 | 4 | 4 | 0.33 | +145 | +36.1 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 0.33 | +212 | +52.9 |
| WHOLE FIGHT | 7 | 7 | 4 | 0.33 | +141 | +35.1 |
| FIRE IN ORDER | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| GUN MASK | 8 | 8 | 3 | 0.25 | +78 | +25.9 |
| HONEST WORTH | 93 | 93 | 3 | 0.25 | +3 | +1.1 |
| KEEPS ITS TARGET | 11 | 11 | 3 | 0.25 | +76 | +25.2 |
| STAY WEIGHED | 3 | 3 | 3 | 0.25 | +95 | +31.7 |
| STOPS SHORT OF THE FLANK | 3 | 3 | 3 | 0.25 | +116 | +38.8 |
| STUCK PIVOT | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| WAR ENGINE JOBS | 11 | 11 | 3 | 0.25 | -568 | -189.5 |
| WEARS DOWN | 14 | 13 | 3 | 0.25 | +137 | +45.7 |
| BEST FACING | 2 | 2 | 2 | 0.17 | +84 | +42.1 |
| CAST JOB | 5 | 5 | 2 | 0.17 | +6 | +3.2 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| FALLS SHORT | 156 | 135 | 2 | 0.17 | +6 | +2.8 |
| HIS CHARGE DENIED | 5 | 5 | 2 | 0.17 | +76 | +38.2 |
| INVITES THE FIGHT | 16 | 16 | 2 | 0.17 | +15 | +7.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| LONG SHOT | 11 | 11 | 2 | 0.17 | +35 | +17.6 |
| MARCH ODDS | 2 | 2 | 2 | 0.17 | +13 | +6.4 |
| MOVE AND CAST | 2 | 2 | 2 | 0.17 | +55 | +27.5 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.17 | +89 | +44.6 |
| OPENS UP | 2 | 2 | 2 | 0.17 | +71 | +35.7 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.17 | +178 | +89.2 |
| SAFER THAN THE JOB | 2 | 2 | 2 | 0.17 | +143 | +71.3 |
| STANDS TO CAST | 2 | 2 | 2 | 0.17 | +101 | +50.7 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.17 | +134 | +66.9 |
| WHOLE FIGHT GAIN | 8 | 7 | 2 | 0.17 | +86 | +43.1 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.08 | +18 | +17.6 |
| FALL BACK GOOD ORDER | 32 | 32 | 1 | 0.08 | +1 | +0.9 |
| FEATURE BUFFS | 1 | 1 | 1 | 0.08 | +18 | +18.4 |
| FOCUS FIRE | 1 | 1 | 1 | 0.08 | +1 | +1.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.08 | +10 | +9.6 |
| KILLS COUNT | 6 | 6 | 1 | 0.08 | +1 | +1.2 |
| LOST CHARGE | 23 | 23 | 1 | 0.08 | +2 | +1.6 |
| MAKE SURE TOGETHER | 6 | 3 | 1 | 0.08 | +22 | +21.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +54 | +54.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.08 | -7 | -7.3 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.08 | +0 | +0.0 |
| WIDER SPREAD | 55 | 54 | 1 | 0.08 | +1 | +0.9 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 10 | 10 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 4 | 4 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 15 | 13 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 6 | 6 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 4 | 4 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 16 | 16 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 95 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 19 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 36 | 36 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 52 | 52 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 23 | 23 | 0 | 0.00 | - | - |
| JOINT CHARGE PLAN | 2 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 17 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 33 | 33 | 0 | 0.00 | - | - |
| NOT NEEDED | 3 | 3 | 0 | 0.00 | - | - |
| NOT TURNED | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 11 | 11 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 9 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 871 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 14 | 14 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 30 | 30 | 0 | 0.00 | - | - |
| SCOUT SPOT | 7 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 30 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| STABLE ROLE | 154 | 152 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 144 | 144 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 55 | 55 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 61 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 7 | not checked | - | - | - | - |
| TURN WORTH | 8 | 8 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 5 | 5 | 0 | 0.00 | - | - |
| WAITS AGAIN | 15 | 15 | 0 | 0.00 | - | - |

### Off best figure: t9-opp-e62ea8a-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 17.00 | - | 53.2 |
| CHARGE NOT DECLARED | rule | 0.25 | 1.00 | 127.2 |
| PATHS CROSS | rule | 0.08 | 0.67 | 25.7 |
| FALLBACK | gate | 0.50 | - | 15.1 |
| PURSUES BIG PREY | rule | 0.33 | 0.08 | 110.9 |
| TURN GATE | gate | 0.42 | - | 128.0 |
| CANNON PLANNED TARGET | rule | 0.08 | 0.25 | 27.9 |
| CHARGE NOW FIRST | rule | 0.08 | 0.25 | 47.6 |
| WAR ENGINE JOBS | rule | 0.17 | 0.08 | 189.5 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 2.5 |
| CHAFF PASSED | rule | - | 0.17 | 0.9 |
| SUPPORT REQUEST | gate | 0.17 | - | 32.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | - | 20.5 |
| BLOCKED WHEEL | rule | 0.08 | - | 4.4 |
| NO REASON | gate | - | 0.08 | 6.8 |
| PIVOT GUARDS FLANK | rule | - | 0.08 | 7.3 |
| RULE SWITCHED OFF | gate | 0.08 | - | 20.1 |

### Plans: t9-opp-e62ea8a-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.4 | 17% | 220 | 225 | 102% |
| Mine | charge | 2.2 | 77% | 164 | 232 | 142% |
| Mine | close in | 3.0 | 39% | 155 | 109 | 70% |
| Mine | hold | 5.2 | 58% | 372 | 0 | 0% |
| Mine | join | 0.2 | 100% | 6 | 0 | 0% |
| Mine | shoot | 10.2 | 63% | 403 | 561 | 139% |
| Mine | support | 3.2 | 82% | 12 | 0 | 0% |
| Opponent | charge | 2.6 | 58% | 326 | 185 | 57% |
| Opponent | join | 0.1 | 100% | 3 | 0 | 0% |
| Opponent | move | 30.3 | 92% | 1548 | 0 | 0% |
| Opponent | shoot | 5.1 | 62% | 397 | 435 | 110% |
| Opponent | support | 0.2 | 50% | 0 | 0 | - |

### Battle groups: t9-opp-e62ea8a-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 26% | 100% | 0% | - | 17% | 0% | 17% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 14% | 100% | 17% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t9-opp-e62ea8a-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 52 (9) | 24 | 28 | 53 | 44% | 2.2 | 165 (2) | 0 (4) | 0 (3) | 59 (8) | 0 (1) |
| Mine | Character | 52 | 21 (52) | 21 | 0 | 31 | 10% | 2.4 | 8 (18) | 10 (21) | 62 (8) | 32 (28) | 8 (19) |
| Mine | Clean-up | 3 | 18 (3) | 18 | 0 | 52 | 67% | 1.0 | 68 (1) | 0 (2) | - | 37 (2) | 0 (1) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 100 | 0% | 1.3 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Mine | Fast Hammer | 10 | 103 (10) | 103 | 0 | 52 | 30% | 3.1 | 156 (7) | 0 (1) | 0 (2) | 100 (8) | 120 (2) |
| Mine | Hammer | 29 | 31 (29) | 26 | 5 | 27 | 14% | 3.2 | 34 (11) | 26 (16) | 59 (2) | 40 (18) | 19 (11) |
| Mine | Holder | 12 | 93 (12) | 0 | 93 | 33 | 58% | 4.0 | 126 (5) | 89 (5) | 0 (2) | 130 (8) | 21 (4) |
| Mine | Shooter | 15 | 125 (15) | 20 | 105 | 31 | 0% | 1.7 | 76 (4) | 147 (10) | 113 (1) | 179 (11) | 24 (4) |
| Mine | War machine | 26 | 22 (26) | 22 | 0 | 32 | 8% | 1.8 | 23 (16) | 23 (9) | 0 (1) | 0 (2) | 24 (24) |
| Mine | Wizard | 5 | 12 (5) | 12 | 0 | 0 | 20% | 3.5 | 16 (4) | 0 (1) | - | - | 12 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 23 | 55 (23) | 2 | 53 | 54 | 35% | 3.1 | 0 (4) | 103 (12) | 0 (7) | 32 (20) | 241 (3) |
| Opponent | Character | 39 | 31 (39) | 31 | 0 | 26 | 31% | 2.3 | 23 (13) | 48 (17) | 14 (4) | 44 (24) | 8 (10) |
| Opponent | Clean-up | 3 | 35 (3) | 35 | 0 | 0 | 33% | 3.5 | 0 (1) | 55 (2) | - | 35 (3) | - |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 12 | 51 (12) | 37 | 14 | 21 | 25% | 2.9 | 34 (4) | 28 (7) | 178 (1) | 34 (6) | 80 (6) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 31 | 45 (31) | 22 | 23 | 43 | 32% | 1.8 | 47 (7) | 49 (16) | 34 (8) | 53 (21) | 28 (10) |
| Opponent | Holder | 10 | 83 (10) | 4 | 79 | 8 | 70% | 4.0 | 0 (1) | 105 (7) | 67 (2) | 105 (6) | 52 (4) |
| Opponent | Shooter | 10 | 61 (10) | 10 | 51 | 66 | 10% | 2.7 | 92 (3) | 55 (5) | 17 (2) | 74 (8) | 12 (2) |
| Opponent | War machine | 11 | 94 (11) | 94 | 0 | 32 | 9% | 1.1 | 135 (7) | 32 (4) | - | 48 (1) | 99 (10) |
| Opponent | Wizard | 7 | 3 (7) | 3 | 0 | 0 | 29% | 2.4 | 0 (1) | 5 (5) | 0 (1) | 4 (6) | 0 (1) |

### Charged fights: t9-opp-e62ea8a-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 187 | 197 | 1.4 | 1.7 | 141 | 0 | +141 | 1 of 7 | 7 of 7 | +80 | +187 |
| Mine | Chaos Dwarfs | 3 | 78 | 476 | 3.0 | 1.2 | 159 | 14 | +144 | 6 of 9 | 9 of 9 | -65 | +170 |
| Mine | Dwarfen Mountain Holds | 4 | 173 | 40 | 2.0 | 1.2 | 20 | 16 | +4 | 2 of 8 | 5 of 8 | -128 | +23 |
| **Mine** | all armies | 12 | 155 | 214 | 2.0 | 1.4 | 107 | 11 | +96 | 9 of 24 | 21 of 24 | +9 | +119 |
| Opponent | Beastmen Brayherds | 1 | 417 | 550 | 4.0 | 1.8 | 138 | 64 | +74 | 2 of 4 | 2 of 4 | +115 | +32 |
| Opponent | Dwarfen Mountain Holds | 1 | 890 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 615 | 427 | 1.0 | 1.0 | 427 | 0 | +427 | 1 of 1 | 1 of 1 | - | +427 |
| Opponent | Grand Cathay | 1 | 408 | 466 | 4.0 | 1.0 | 116 | 0 | +116 | 4 of 4 | 3 of 4 | - | +116 |
| Opponent | Ogre Kingdoms | 2 | 85 | 15 | 3.5 | 1.3 | 4 | 76 | -71 | 5 of 7 | 4 of 7 | -150 | -40 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 670 | 4.0 | 1.0 | 168 | 0 | +168 | 1 of 4 | 4 of 4 | - | +168 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 677 | 3.0 | 1.7 | 226 | 0 | +226 | 2 of 3 | 2 of 3 | +612 | +32 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 2 | 42 | 170 | 3.5 | 1.0 | 49 | 18 | +31 | 1 of 7 | 6 of 7 | - | +31 |
| **Opponent** | all armies | 12 | 215 | 263 | 2.5 | 1.2 | 105 | 30 | +75 | 16 of 30 | 22 of 30 | +108 | +68 |

### Effective charges: t9-opp-e62ea8a-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 1 (net +0) | 0 | 1 (net +125) | 0 | 3 (net +182) | 2 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 9 | 0 | 0 | 0 | 3 (net +228) | 1 (net +65) | 5 (net +109) | 0 | 0% (0 of 9) |
| Mine | Dwarfen Mountain Holds | 8 | 3 (net -23) | 0 | 2 (net +0) | 1 (net +0) | 1 (net +60) | 1 (net +41) | 0 | 25% (2 of 8) |
| Opponent | Beastmen Brayherds | 4 | 1 (net +0) | 0 | 2 (net +32) | 1 (net +230) | 0 | 0 | 0 | 50% (2 of 4) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +427) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 4 | 2 (net +140) | 0 | 1 (net +0) | 0 | 0 | 1 (net +186) | 0 | 25% (1 of 4) |
| Opponent | Ogre Kingdoms | 7 | 1 (net -228) | 0 | 2 (net -150) | 1 (net +0) | 0 | 2 (net +0) | 1 | 33% (2 of 6) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 2 (net +180) | 0 | 2 | 0% (0 of 2) |
| Opponent | Vampire Counts | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +338) | 0 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 7 | 2 (net +0) | 0 | 0 | 2 (net -20) | 1 (net +0) | 2 (net +128) | 0 | 0% (0 of 7) |

### Charged fights, damage counted: t9-opp-e62ea8a-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 172 | 207 | -23 | 33 | 84 | -52 | -30.2 |
| Mine | 50-54% | 1 | 104 | 185 | +0 | 111 | 26 | +85 | +81.7 |
| Mine | Effective (55-75%) | 2 | 55 | 156 | +0 | 82 | 0 | +82 | +149.1 |
| Mine | 76-89% | 5 | 225 | 233 | +162 | 175 | 13 | +162 | +72.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 | 254 | 173 | +126 | 158 | 17 | +141 | +55.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 289 | 62 | +62 | 62 | 0 | +62 | +21.6 |
| Mine | No odds | 2 | 836 | 79 | +158 | 167 | 60 | +107 | +12.8 |
| Mine | All fights | 24 | 266 | 172 | +96 | 130 | 26 | +105 | +39.4 |
| Opponent | Long shot (under 50%) | 7 | 239 | 236 | +7 | 66 | 67 | -1 | -0.4 |
| Opponent | Effective (55-75%) | 5 | 209 | 180 | -47 | 46 | 124 | -78 | -37.4 |
| Opponent | 76-89% | 4 | 155 | 198 | +47 | 211 | 126 | +85 | +54.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 290 | 174 | +193 | 193 | 31 | +162 | +55.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 400 | 101 | +120 | 132 | 0 | +132 | +33.0 |
| Opponent | No odds | 3 | 50 | 145 | +113 | 129 | 19 | +110 | +222.5 |
| Opponent | All fights | 30 | 234 | 183 | +75 | 129 | 63 | +66 | +28.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t9-opp-e62ea8a-p1 | move | 82 | 17 (21%) | 14 (17%) | 7 (9%) | 58 (71%) |
| t9-opp-e62ea8a-p1 | objective | 36 | 6 (17%) | 5 (14%) | 2 (6%) | 28 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Invocation of Nehek | Opponent | L0524 |
| Periapt of Soul Exchange | Opponent | L0421 |
| Ring of Doom | Mine | L0218, L0235 |
| Ring of Doom | Opponent | L0102, L0612 |
| Ring of Jet | Opponent | L0612 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

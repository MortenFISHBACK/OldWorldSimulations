# Doctrine scorecard: t9-opp-e62ea8a-p4

### Scorecard: t9-opp-e62ea8a-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 6 | 3 | 0 | 2 | 0 | 0 | 0 | 322 |
| L0114 | 6 | 1 | Opponent | no | 0 | 2 | 7 | 3 | 0 | 0 | 0 | 177 |
| L0130 | 4 | 1 | Mine | no | 1 | 4 | 1 | 1 | 1 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 6 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | 6 | 0 | 2 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 760 |
| L0315 | 3 | 1 | Opponent | yes | 8 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 1 | 0 | 0 | 709 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 3 | 0 | 0 | 0 | 56 |
| L0520 | 4 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 881 |
| L0520 | 4 | 1 | Opponent | no | 1 | - | 0 | 4 | 0 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 0 | 0 | 0 | 130 |
| L0624 | 6 | 1 | Mine | no | 1 | 4 | 4 | 0 | 0 | 0 | 0 | 743 |
| L0624 | 6 | 1 | Opponent | no | 1 | 4 | 0 | 1 | 2 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 3 | 3 | 1 | 2 | 0 | 0 | 497 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 70 |
| L0729 | 3 | 1 | Mine | yes | 6 | 2 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0729 | 3 | 1 | Opponent | no | 7 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 22% | 2.9 | 2.8 | 2.0 | 1.1 | 0.4 | 0.0 | 0.0 | 411.7 |
| **Average** | | | Opponent | 44% | 3.6 | 2.3 | 2.8 | 1.8 | 0.3 | 0.0 | 0.0 | 49.5 |

### KPIs: t9-opp-e62ea8a-p4

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 13 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (24 of 60) | 2% (1 of 66) | 20% (25 of 126) |
| Winner chose to follow up after the loser gave ground |  | 100% (17 of 17); on the table 100% | 95% (20 of 21); on the table 95% | 97% (37 of 38); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 33% (1 of 3); on the table 33% | 100% (10 of 10); on the table 100% | 85% (11 of 13); on the table 85% |
| Winner chose to pursue after the loser fled |  | 70% (7 of 10); on the table 70% | 60% (6 of 10); on the table 60% | 65% (13 of 20); on the table 65% |
| Winner chose to follow up or pursue (all three) |  | 83% (25 of 30); on the table 83% | 88% (36 of 41); on the table 88% | 86% (61 of 71); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 35% (46 of 132) | 19% (7 of 36) | 32% (53 of 168) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (46 of 109) | 33% (7 of 21) | 41% (53 of 130) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (6 of 10) | 64% (16 of 25) | 63% (22 of 35) |
| Points that never fought | lower | 38% (9645 of 25592) | 35% (9223 of 25993) | 37% (18868 of 51585) |
|   infantry points that never fought | lower | 40% (2872 of 7112) | 69% (3416 of 4948) | 52% (6288 of 12060) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (69 of 101) | 52% (51 of 99) | 60% (120 of 200) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.2 uses a game | 100% (3 of 3); 0.8 uses a game | 100% (9 of 9); 1.0 uses a game |
| Bound items with another spell used |  | 75% (3 of 4); 0.4 uses a game | 57% (8 of 14); 0.7 uses a game | 61% (11 of 18); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (8 of 10); 0.6 uses a game | 60% (3 of 5); 0.2 uses a game | 73% (11 of 15); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (12690 of 20100) | 46% (10893 of 23442) | 54% (23583 of 43542) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.5 (53%) | 0.4 (17%) | 3.9 (44%) |
| MARCHED: its unit marched | 0.8 (13%) | 0.6 (28%) | 1.5 (17%) |
| CHARGED: its unit charged | 0.5 (7%) | 0.1 (3%) | 0.5 (6%) |
| IN COMBAT: engaged in combat | 1.0 (15%) | 0.3 (14%) | 1.3 (15%) |
| FLEEING: fleeing | 0.0 (0%) | 0.4 (17%) | 0.4 (4%) |
| GONE: slain | 0.8 (12%) | 0.5 (21%) | 1.2 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 2.2 | 3.3 | 4.1 | 0.3 | 0.7 |
| not cast | 1.9 | 2.8 | 3.2 | 8.8 | 2.5 | 16.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (61%) | 0.7 (22%) | 3.9 (44%) | 0.7 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (17%) | 0.6 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (6%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.2 (6%) | 0.7 (22%) | 1.3 (15%) | 0.4 (16%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.8 (5%) |
| GONE: slain | 0.8 (40%) | 0.4 (14%) | 0.4 (12%) | 1.2 (14%) | 0.4 (16%) | 2.1 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.5 (17%) | 0.0 (0%) | 0.0 (0%) | 0.4 (16%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.1 (56%) | 0.1 (3%) | 1.4 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.5 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.8 a game | 0.8 a game | 1.8 a game |
| stood (cast and not dispelled) | 73% (27 of 37) | 50% (2 of 4) | 71% (29 of 41) |
| the unit moved after it | 74% (20 of 27) | 100% (2 of 2) | 76% (22 of 29) |
| it charged on its next turn | 11% (3 of 27) | 0% (0 of 2) | 10% (3 of 29) |
| the enemy charged it first | 33% (9 of 27) | 0% (0 of 2) | 31% (9 of 29) |
| it fought by the end of its next turn | 19% (5 of 27) | 0% (0 of 2) | 17% (5 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 27) | 0% (0 of 2) | 0% (0 of 29) |
| none of these (no charge, no fight, no charge escaped) | 56% (15 of 27) | 100% (2 of 2) | 59% (17 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (241 of 350) | 46% (108 of 234) | 60% (349 of 584) |
|   cavalry | 48% (10 of 21) | 50% (17 of 34) | 49% (27 of 55) |
|   character | 92% (23 of 25) | 16% (12 of 75) | 35% (35 of 100) |
|   chariot | 51% (18 of 35) | 57% (4 of 7) | 52% (22 of 42) |
|   infantry | 59% (55 of 93) | 71% (50 of 70) | 64% (105 of 163) |
|   monster | 83% (5 of 6) | 42% (5 of 12) | 56% (10 of 18) |
|   war machine | 76% (130 of 170) | 56% (20 of 36) | 73% (150 of 206) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (20%) | 1.2 (13%) | 2.9 (16%) |
| CHARGED: it charged | 0.4 (5%) | 2.7 (28%) | 3.1 (17%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.2 (14%) | 0.3 (3%) | 1.5 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.5 (6%) | 0.6 (3%) |
| NO TARGET IN RANGE | 1.6 (19%) | 1.7 (17%) | 3.3 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.8 (8%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.8 (34%) | 1.7 (17%) | 4.5 (25%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.3 (3%) | 0.5 (3%) |
| OTHER BAR | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.4 | 1.5 | 66% | 7.9 pts | 27 pts |
| character | 3.2 | 0.3 | 95% | 3.7 pts | 12 pts |
| chariot | 1.7 | 1.3 | 55% | 23.3 pts | 39 pts |
| infantry | 13.0 | 2.9 | 83% | 6.8 pts | 89 pts |
| monster | 0.8 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 11.5 | 11.5 | 56% | 24.8 pts | 286 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 6.6 | 5.3 |
| Charges that made contact a game | 2.3 | 3.8 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.40 declared, 0.40 contact (5 units) | 0.83 declared, 0.67 contact (6 units) | 0.64 declared, 0.55 contact (11 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (3 units) | 1.40 declared, 0.60 contact (5 units) | 0.88 declared, 0.38 contact (8 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.31 contact (91 units) | 0.72 declared, 0.42 contact (103 units) | 0.64 declared, 0.37 contact (194 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 66% (21 of 32) | 50% (3 of 6) | 100% (1 of 1) | 64% (25 of 39) |
| Character in a unit | 93% (13 of 14) | 64% (7 of 11) | - | 80% (20 of 25) |
| Character on its own | 89% (8 of 9) | 43% (3 of 7) | 39% (9 of 23) | 51% (20 of 39) |
| Chariot | 100% (1 of 1) | 89% (8 of 9) | - | 90% (9 of 10) |
| Infantry | 33% (9 of 27) | 31% (5 of 16) | 100% (1 of 1) | 34% (15 of 44) |
| Monster | 80% (8 of 10) | 25% (1 of 4) | - | 64% (9 of 14) |
| Monstrous | 33% (1 of 3) | - | - | 33% (1 of 3) |
| War Machines | 79% (19 of 24) | 100% (2 of 2) | - | 81% (21 of 26) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 62% (5 of 8); on the table 62% | 38% (39 of 102) | 22% | 64% (14 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 1.0 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 90% (9 of 10); on the table 90% | 17% (4 of 24) | 34% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (10 of 10); on the table 100% | - | 58% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | 67% (2 of 3); on the table 67% | 50% (3 of 6) | 62% | 80% (24 of 30) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 67% (2 of 3); 0.7 uses a game |
| High Elf Realms | 4 | 50% (2 of 4); on the table 50% | 28% (5 of 18) | 30% | 58% (19 of 33) | 100% (3 of 3); 2.8 uses a game | 57% (8 of 14); 2.2 uses a game | 0.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | 17% (1 of 6) | 29% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 6) | 73% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (10 of 10); on the table 100% | 17% (1 of 6) | 33% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 87% (13 of 15); on the table 87% | - | 21% | 33% (9 of 27) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Wood Elf Realms | 1 | 100% (5 of 5); on the table 100% | - | 24% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (t9-opp-e62ea8a-p4, 13 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (15) | 53% (9) | 45% (24) |
| ...free all their last turn and able to turn (per game) | 0.62 | 0.69 | 1.31 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.46 | 0.00 | 0.46 |
| ...with the charger already in that arc before they moved (per game) | 0.38 | 0.69 | 1.08 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.15 | 0.00 | 1.15 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.54 | 0.00 | 0.54 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.08 | 0.08 | 6.15 |

### Quality by phase: t9-opp-e62ea8a-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 45% (19 of 42) | 44% (32 of 72) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (86 of 194) | 53% (25 of 47) |
| Strategy | Close-in objectives charged next turn | 16% (7 of 45) | - |
| Strategy | Support requests answered (helper made contact too) | 60% (3 of 5) | 14% (1 of 7) |
| Strategy | Hexes on a unit its side charged or shot that turn | 14% (1 of 7) | 25% (1 of 4) |
| Strategy | Joined characters whose unit fought | 72% (21 of 29) | 56% (5 of 9) |
| Strategy | Lone characters that fought | 65% (17 of 26) | 78% (21 of 27) |
| Movement | Charges halted short of contact | 0.1 | 0.7 |
| Movement | Idle units | 1.1 | 1.8 |
| Movement | Points that never moved of their own | 411.7 | 49.5 |
| Movement | Fights charged into per game | 2.0 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 25, net +23 | 14 of 43, net +6 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 25, net -134 | 7 of 43, net +104 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 25, net +89 | 8 of 43, net +90 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 of 25, net +20 | 6 of 43, net +206 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.8 | 7.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (67 of 114) | 44% (45 of 103) |
| Shooting | Points destroyed by shooting units | 36.5 | 14.0 |
| Shooting | War machine shots | 10.0 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (56 of 130) | 40% (8 of 20) |
| Shooting | Points destroyed by war machines | 109.2 | 17.3 |
| Magic | Magic missiles cast | 2.3 | 0.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 47% (14 of 30) | 33% (2 of 6) |
| Magic | Wounds caused by magic missiles | 3.1 | 1.5 |
| Magic | Wounds caused by other spells | 0.3 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 38.8 | 75.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.4 / 0.5 / 0.2 / 0.2 | 1.4 / 0.8 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 163.5 | 445.3 |
| Combat | Points run down | 116.5 | 100.0 |
| Combat | Net points per charged fight, damage counted | +40 | +54 |
| Combat | Net per 100 charger points, damage counted | +19.0 | +16.3 |
| Combat | First round won (charged fights) | 65% | 65% |
| Combat | Net points per charged fight | +28 | +72 |
| Combat | Net points per supported fight / lone fight | +132 / +14 | +111 / +69 |
| Combat | Charged fights on a top-3 enemy unit | 11 of 26 | 24 of 46 |
| Game | Points lost | 665.5 | 489.4 |
| Game | VP from objectives | 624.6 | 601.5 |
| Game | Lone holders (player turns) | 2.9 | 3.6 |

- Mine won / drew / lost: 5 / 1 / 7 of 13 ended games (of 13); mean margin (Mine - Opponent) -109 VP
- The side that went first won 6 of 12 games with a winner
- Points traded per game (both sides' losses): 1155
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: t9-opp-e62ea8a-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.8 | -128.6 | 139.7 | 73.9 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 28.6 | 7.3 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.6 | +0.0 | 0.0 | 20.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.4 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| BEST FACING | 0.2 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| BEST FIRST | 2.1 | +119.5 | 8.5 | 18.1 | - | - | - | - |
| BEST MOVE FOR SHOOTERS | 0.9 | +48.1 | 0.0 | 31.9 | - | - | - | - |
| BEST OVERALL | 0.2 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| BEST PREY | 0.8 | +32.5 | 13.9 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.1 | -0.4 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.2 | +18.7 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.4 | -151.7 | 28.7 | 0.0 |
| BOUND ASSAILMENT | - | - | - | - | 0.2 | +0.0 | 0.0 | 22.0 |
| CANNON PLAN MISSED | 1.6 | +0.0 | 170.3 | 25.4 | 0.2 | +0.0 | 63.1 | 0.0 |
| CANNON PLANNED TARGET | 8.5 | +118.9 | 677.1 | 100.8 | 1.4 | +79.3 | 93.1 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 14.5 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | +0.0 | 16.7 | 7.0 | - | - | - | - |
| CAST JOB | 0.3 | +16.4 | 26.2 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.0 | +92.7 | 21.1 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 27.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.5 | 0.0 | 0.0 | 0.1 | +2.8 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.3 | +99.1 | 0.0 | 29.8 | 0.5 | +19.7 | 0.0 | 12.2 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 6.8 | -433.9 | 0.0 | 303.5 |
| CHARGE NOT DECLARED | 0.6 | +0.0 | 30.8 | 14.5 | 0.4 | +0.0 | 40.1 | 0.0 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 220.3 | 145.8 | 2.4 | +0.0 | 315.6 | 62.3 |
| CHARGE NOW WEIGHED | 0.3 | -7.8 | 0.0 | 4.6 | - | - | - | - |
| CHARGER SLAIN LOST | 0.9 | -13.9 | 115.8 | 35.0 | 0.4 | -16.7 | 23.8 | 8.8 |
| CHEAP HELPER | 0.2 | +0.0 | 23.2 | 0.0 | - | - | - | - |
| CHEAPEST HOLDER | - | - | - | - | 0.5 | -24.2 | 41.9 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 92.3 | 0.5 | +0.0 | 0.0 | 36.2 |
| CONVEYANCE SEARCH | 2.5 | +265.6 | 68.0 | 34.6 | 0.2 | +2.1 | 0.0 | 0.0 |
| COVER ONCE | 7.8 | -559.5 | 0.0 | 147.7 | 7.2 | -528.9 | 0.0 | 95.5 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.2 | 9.5 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.2 | +47.5 | 0.0 | 9.2 | 7.5 | +39.9 | 0.0 | 22.5 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +3.4 | 33.5 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.2 | +60.3 | 0.0 | 29.2 | - | - | - | - |
| FALL BACK GOOD ORDER | - | - | - | - | 4.0 | +6.7 | 357.0 | 28.0 |
| FALLBACK BY WORTH | 4.5 | +97.6 | 0.0 | 52.5 | 0.1 | +0.0 | 0.0 | 2.1 |
| FALLS SHORT | - | - | - | - | 20.0 | +260.3 | 0.0 | 251.3 |
| FEATURE BUFFS | - | - | - | - | 0.2 | +8.2 | 0.0 | 0.0 |
| FIGHT LIFT | 0.2 | +1.1 | 18.9 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 2.3 | +172.6 | 272.2 | 57.7 |
| FIRE AND FLEE | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 4.6 | 0.0 |
| FIVE ACTION | - | - | - | - | 44.2 | +3557.3 | 820.3 | 651.7 |
| FLANK NOT WEIGHED | 4.5 | +0.0 | 0.0 | 78.0 | 4.8 | +0.0 | 0.0 | 163.7 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.8 | 4.6 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +119.6 | 0.0 | 57.2 | 1.0 | +269.0 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 5.4 | +577.9 | 507.1 | 77.5 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.2 | -43.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.1 | -6.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.4 | +22.4 | 0.0 | 11.6 | 0.1 | +0.9 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -6.3 | 28.8 | 0.0 |
| GROUND FLIERS | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.7 | +1.8 | 6.4 | 47.7 | 0.7 | +14.1 | 47.8 | 0.0 |
| GUN MASK | - | - | - | - | 0.2 | +0.5 | 0.0 | 11.6 |
| HARD STAY DROPPED | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | - | - | - | - | 1.9 | +0.0 | 0.0 | 28.1 |
| HELPER UNSEEN | 0.1 | +0.0 | 9.4 | 14.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| HILL BY ITS CHANCE | 1.2 | -122.2 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +9.5 | 12.8 | 0.0 |
| HIS CHARGE LIST | - | - | - | - | 3.3 | +0.0 | 0.0 | 14.8 |
| HIS LEGAL MOVES | - | - | - | - | 5.6 | +0.0 | 0.0 | 103.1 |
| HIS MOVE AND SHOT | - | - | - | - | 2.2 | -86.6 | 0.0 | 86.3 |
| HIS RANDOM MOVE | - | - | - | - | 1.8 | +0.0 | 0.0 | 58.9 |
| HIS SHOT LIST | - | - | - | - | 25.2 | +1644.9 | 0.0 | 312.3 |
| HIS TURN DENIED | - | - | - | - | 3.2 | +205.9 | 239.2 | 68.7 |
| HOLDER AT DEPLOYMENT | 0.8 | +142.5 | 0.0 | 0.0 | 0.8 | +153.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.1 | -80.2 | 241.0 | 161.3 | 4.5 | -208.9 | 394.2 | 57.7 |
| HUNT ADVANCE | 0.2 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | - | - | - | - | 0.2 | +2.9 | 0.0 | 14.2 |
| HUNT KEPT | 0.1 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +13.4 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +23.8 | 0.0 | 0.0 | 0.1 | +17.1 | 9.6 | 0.0 |
| IDLE COST | 16.0 | -235.9 | 0.0 | 133.6 | 11.2 | -176.6 | 0.0 | 210.5 |
| INVITES THE FIGHT | 2.0 | +10.1 | 53.0 | 43.8 | - | - | - | - |
| JOINT CHARGE PLAN | 0.2 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.2 | 7.3 | 0.0 |
| KEEP FALLS | 0.2 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.2 | +1.3 | 9.5 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.2 | +36.9 | 80.2 | 59.2 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +81.5 | 116.2 | 115.4 | - | - | - | - |
| KILLS COUNT NEXT TURN | 4.2 | +70.5 | 169.2 | 157.5 | - | - | - | - |
| LANE BY FIGURES | 0.4 | +12.7 | 0.0 | 0.0 | 1.0 | +31.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 5.8 | +0.0 | 330.5 | 295.0 |
| LONE CHARACTER SAFE SPOT | 0.2 | +9.2 | 7.5 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.8 | +29.0 | 0.0 | 0.0 | 0.2 | +15.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -0.8 | 18.9 | 5.0 | 0.4 | +8.2 | 51.4 | 0.0 |
| LOST CHARGE | 2.2 | -25.0 | 86.2 | 54.2 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -11.4 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.7 | +15.8 | 0.0 | 50.8 | - | - | - | - |
| MANOEUVRE | 0.2 | +9.3 | 0.0 | 0.0 | 1.2 | +19.6 | 0.0 | 2.9 |
| MARCH BY THE SUM | - | - | - | - | 0.2 | +4.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.2 | +0.0 | 0.0 | 29.2 | 0.4 | +12.9 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +8.5 | 14.2 | 44.6 | - | - | - | - |
| MARCH OVER CASTS | 0.2 | +5.2 | 0.0 | 28.6 | 0.3 | +8.5 | 0.0 | 36.2 |
| MAX FOR POSITIONING | 5.4 | +67.0 | 0.0 | 132.7 | 5.5 | +63.2 | 0.0 | 139.6 |
| MISSILES IN THE MOVE | 3.0 | +203.5 | 0.0 | 35.5 | 1.8 | +46.5 | 0.0 | 50.4 |
| MISSILES NEXT TURN | 3.2 | +127.5 | 0.0 | 64.1 | 2.1 | +21.9 | 0.0 | 86.5 |
| MODEL FACING | 0.5 | +150.6 | 0.0 | 13.8 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 29.2 | - | - | - | - |
| MOVE AND CAST | 0.2 | +12.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 1.1 | +22.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.1 | -48.7 | 56.0 | 69.2 | - | - | - | - |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 6.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.0 | +107.3 | 76.7 | 50.5 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 4.8 | +796.6 | 0.0 | 73.2 |
| MOVES UNITS SPELL | 0.2 | +8.5 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | - | - | - | - | 4.2 | +263.9 | 0.0 | 19.9 |
| NEXT CHARGE BY LIST | - | - | - | - | 6.4 | -119.2 | 6.5 | 146.2 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 8.5 | -448.6 | 27.7 | 79.5 |
| NO DOUBLE ROUNDS | - | - | - | - | 4.2 | -175.1 | 347.8 | 68.7 |
| NO RALLY LEFT | - | - | - | - | 0.2 | +13.4 | 0.0 | 0.0 |
| NOT NEEDED | 0.4 | -16.2 | 25.3 | 0.0 | - | - | - | - |
| NOT TURNED | 6.1 | +129.7 | 0.0 | 96.0 | 0.1 | +0.0 | 0.0 | 7.5 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 18.1 | -774.8 | 11.6 | 127.2 | 0.2 | -1.4 | 0.0 | 7.5 |
| ONE CHARGE A CHARGER | - | - | - | - | 2.4 | +0.0 | 0.0 | 45.8 |
| ONE FIGHT FORMULA | 8.3 | -99.4 | 45.5 | 213.8 | 5.9 | -140.9 | 0.0 | 145.5 |
| ONE OBJECTIVE FORMULA | 3.2 | -228.6 | 0.0 | 0.0 | 2.5 | -33.0 | 0.0 | 86.5 |
| ONE TARGET A SHOOTER | - | - | - | - | 18.3 | +642.8 | 0.0 | 297.8 |
| OPENS A LANE | 0.2 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.1 | +4.3 | 0.0 | 0.0 | 0.4 | +32.2 | 26.1 | 0.0 |
| OVERRUNS AWAY | 0.3 | +4.2 | 12.4 | 0.0 | 0.6 | +29.5 | 24.5 | 0.0 |
| PATHS CROSS | 1.5 | +129.8 | 0.0 | 53.6 | 4.5 | +212.7 | 0.0 | 24.6 |
| PIVOT GUARDS FLANK | 0.2 | -1.7 | 0.0 | 6.5 | 0.2 | -4.1 | 0.0 | 10.5 |
| PLAN RESULT | 39.8 | +1545.6 | 1225.4 | 1023.5 | 38.9 | +678.7 | 461.6 | 797.1 |
| PURSUES BIG PREY | 0.1 | -2.4 | 0.0 | 0.0 | 0.1 | -22.8 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +11.2 | 0.0 | 26.2 | 1.9 | +40.6 | 0.0 | 45.4 |
| RANDOM MOVER NO PROMISE | 0.3 | -14.5 | 0.0 | 26.2 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 1.0 | -1.8 | 0.0 | 25.6 | 0.4 | +0.2 | 0.0 | 9.6 |
| REDIRECT COUNTER | 3.3 | +303.1 | 0.0 | 52.2 | 3.0 | +154.1 | 0.0 | 90.5 |
| REDIRECT WEIGHED | 0.5 | +0.0 | 0.0 | 28.0 | 0.3 | +6.6 | 5.9 | 12.4 |
| REFORMS TO MEET IT | - | - | - | - | 0.5 | -6.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.6 | +0.0 | 0.0 | 6.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +23.8 | 0.0 | 8.6 | 0.1 | +2.7 | 0.0 | 8.2 |
| RISK BY ARC | 2.1 | +79.4 | 177.2 | 50.0 | 3.2 | +19.9 | 265.6 | 19.1 |
| RISK BY HIS FIGURE | - | - | - | - | 15.0 | -263.4 | 0.0 | 280.5 |
| RISK ONCE | 3.0 | +120.1 | 12.9 | 170.2 | - | - | - | - |
| RUN DOWN | - | - | - | - | 3.5 | -22.9 | 310.9 | 0.0 |
| SAFER THAN THE JOB | 0.5 | +15.7 | 0.0 | 10.0 | - | - | - | - |
| SCOUT SPOT | 0.4 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.4 | -50.6 | 0.0 | 4.2 | 0.2 | -8.5 | 0.0 | 2.7 |
| SEARCH SPOT | 3.6 | +150.0 | 0.0 | 124.8 | 6.1 | +324.6 | 0.0 | 58.2 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | +110.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.7 | +59.5 | 6.2 | 84.7 | 0.2 | +4.9 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 1.1 | +213.3 | 63.8 | 7.3 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.1 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +24.0 | 20.4 | 0.0 | 0.3 | +10.7 | 16.5 | 0.0 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.2 | -22.7 | 58.5 | 11.0 |
| SHOT RISK POINTS | - | - | - | - | 13.7 | -32.4 | 0.0 | 314.8 |
| SHOTS IN THE MOVE | 16.4 | +496.1 | 0.0 | 239.0 | 9.3 | +371.4 | 0.0 | 82.8 |
| SPELL SETS UP CHARGE | 1.1 | +213.3 | 63.8 | 7.3 | - | - | - | - |
| SPELL WORTH | 0.8 | +9.9 | 147.8 | 116.5 | 1.8 | +50.9 | 214.6 | 214.6 |
| SPELLS IN THE FIGHT | 0.8 | -24.3 | 122.6 | 11.2 | 0.5 | -12.3 | 57.8 | 11.0 |
| STABLE ROLE | 14.5 | +0.0 | 316.3 | 118.8 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.8 | -9.2 | 62.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | - | - | - | - | 8.5 | +0.0 | 284.8 | 92.0 |
| STANDS TO CAST | 0.1 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 22.7 | -116.5 | 716.1 | 217.1 | 9.2 | +88.1 | 95.0 | 63.5 |
| STOPS | - | - | - | - | 0.1 | +1.6 | 9.6 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.2 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.4 | +0.0 | 0.0 | 16.2 |
| SUPPORT NARROWED | 5.4 | -45.7 | 267.3 | 108.5 | 1.6 | +0.0 | 172.9 | 47.4 |
| SUPPORTS | 3.6 | +65.0 | 104.2 | 82.8 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.2 | -1.5 | 18.8 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.5 | -0.8 | 6.2 | 8.1 | 0.3 | +5.9 | 0.0 | 8.2 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 3.8 | +0.0 | 0.0 | 27.4 |
| THE PROMISE ADDS | - | - | - | - | 0.5 | -75.3 | 22.2 | 45.3 |
| THE PROMISED MOVE | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.1 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| TIED UP BY THE SUM | - | - | - | - | 1.2 | +128.8 | 95.9 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 3.8 | +53.3 | 0.0 | 88.4 |
| TURN WORTH | 0.2 | -2.8 | 15.1 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.3 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| WAIT AFTER COSTS | 6.5 | -210.6 | 162.2 | 94.4 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.0 | +0.0 | 0.0 | 45.3 |
| WALKS TO THE FIGHT | 1.2 | +6.4 | 32.5 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.2 | +6.5 | 2.7 | 23.8 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 16.7 | 47.7 | - | - | - | - |
| WEARS DOWN | 1.5 | +46.6 | 147.8 | 30.4 | - | - | - | - |
| WHO HITS BACK | 0.2 | +9.9 | 0.0 | 14.5 | 0.4 | +29.9 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.5 | +76.8 | 140.8 | 6.7 |
| WHOLE FIGHT GAIN | 0.5 | +36.4 | 61.3 | 6.5 | 0.3 | +30.2 | 7.3 | 2.1 |
| WIDER SPREAD | 2.7 | -4.1 | 220.8 | 145.8 | 4.1 | -12.7 | 407.7 | 32.2 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 5.4 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 0.5 | +5.5 | 0.0 | 0.0 |

### Rule changes: t9-opp-e62ea8a-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 238 | 238 | 238 | 18.31 | -10092 | -42.4 |
| DEPLOY BY FIGURES | 218 | 218 | 139 | 10.69 | +2218 | +16.0 |
| HIS SHOT LIST | 328 | 328 | 118 | 9.08 | +3994 | +33.8 |
| SEARCH SPOT | 126 | 126 | 115 | 8.85 | +6187 | +53.8 |
| FIVE ACTION | 574 | 574 | 83 | 6.38 | +3268 | +39.4 |
| PATHS CROSS | 78 | 78 | 78 | 6.00 | +4453 | +57.1 |
| LEGAL CHARGES ONLY | 75 | 75 | 75 | 5.77 | +0 | +0.0 |
| ONE TARGET A SHOOTER | 238 | 238 | 62 | 4.77 | +1095 | +17.7 |
| COVER ONCE | 194 | 131 | 40 | 3.08 | +461 | +11.5 |
| MOVE TO CHARGE COMPUTED | 62 | 62 | 38 | 2.92 | +3461 | +91.1 |
| ARTILLERY RE-ROLL WEIGHED | 37 | 37 | 37 | 2.85 | +0 | +0.0 |
| SHOT RISK POINTS | 178 | 178 | 35 | 2.69 | +1351 | +38.6 |
| FOUR ROUNDS | 70 | 70 | 31 | 2.38 | +2411 | +77.8 |
| BEST FIRST | 27 | 27 | 27 | 2.08 | +1554 | +57.5 |
| SHOTS IN THE MOVE | 334 | 264 | 26 | 2.00 | +737 | +28.4 |
| FOLLOW UP WEIGHED | 25 | 25 | 25 | 1.92 | +5052 | +202.1 |
| MOVE TO CHARGE | 39 | 39 | 24 | 1.85 | +381 | +15.9 |
| ADVANCE LANE KEPT | 23 | 23 | 23 | 1.77 | +0 | +0.0 |
| MAX FOR POSITIONING | 141 | 117 | 23 | 1.77 | +63 | +2.7 |
| IDLE COST | 353 | 224 | 22 | 1.69 | +220 | +10.0 |
| RANDOM MOVE BY FIGURES | 35 | 35 | 22 | 1.69 | +673 | +30.6 |
| FALLBACK BY WORTH | 59 | 59 | 19 | 1.46 | +1269 | +66.8 |
| SUPPORTS | 47 | 47 | 19 | 1.46 | +375 | +19.7 |
| LANE BY FIGURES | 18 | 18 | 18 | 1.38 | +569 | +31.6 |
| CANNON PLANNED TARGET | 128 | 128 | 16 | 1.23 | -227 | -14.2 |
| FACES THE THREAT | 15 | 15 | 15 | 1.15 | +783 | +52.2 |
| RISK BY ARC | 68 | 67 | 15 | 1.15 | +247 | +16.5 |
| STAY WORTH | 414 | 365 | 15 | 1.15 | +119 | +7.9 |
| TIED UP BY THE SUM | 15 | 15 | 15 | 1.15 | +514 | +34.3 |
| WAIT AFTER COSTS | 84 | 84 | 15 | 1.15 | +251 | +16.8 |
| CANNON SIGHT KEPT | 14 | 14 | 14 | 1.08 | +0 | +0.0 |
| CHARGE NOW FIRST | 56 | 56 | 14 | 1.08 | -403 | -28.8 |
| KILLS COUNT NEXT TURN | 55 | 55 | 14 | 1.08 | +128 | +9.1 |
| MISSILES IN THE MOVE | 62 | 39 | 14 | 1.08 | +779 | +55.6 |
| ADVANCE WORTH | 75 | 75 | 13 | 1.00 | +160 | +12.3 |
| CHAFF IN THE MOVE | 23 | 21 | 13 | 1.00 | +421 | +32.4 |
| CHARGE NOT DECLARED | 13 | 13 | 13 | 1.00 | -1703 | -131.0 |
| ONE FIGHT FORMULA | 185 | 113 | 13 | 1.00 | +73 | +5.6 |
| REDIRECT COUNTER | 82 | 51 | 13 | 1.00 | +1134 | +87.2 |
| BEST MOVE FOR SHOOTERS | 12 | 12 | 12 | 0.92 | +626 | +52.1 |
| FALLS SHORT | 260 | 228 | 12 | 0.92 | +55 | +4.6 |
| HIS TURN DENIED | 42 | 42 | 12 | 0.92 | +556 | +46.3 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 0.92 | +578 | +48.1 |
| RISK ONCE | 39 | 29 | 12 | 0.92 | +207 | +17.3 |
| CASTER AWAY FROM SCREEN | 11 | 11 | 11 | 0.85 | +0 | +0.0 |
| MANOEUVRE | 18 | 18 | 11 | 0.85 | +376 | +34.2 |
| RISK BY HIS FIGURE | 195 | 195 | 11 | 0.85 | +755 | +68.6 |
| COMBAT PIVOT | 10 | 10 | 10 | 0.77 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 83 | 83 | 10 | 0.77 | +280 | +28.0 |
| NEXT OBJECTIVE NEARER | 111 | 111 | 10 | 0.77 | +213 | +21.3 |
| REDIRECT WEIGHED | 10 | 10 | 10 | 0.77 | +290 | +29.0 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 10 | 0.77 | +113 | +11.3 |
| CASTING BLOCK | 13 | 13 | 9 | 0.69 | +433 | +48.1 |
| SHOOTERS IN TWO RANKS | 9 | 9 | 9 | 0.69 | +18 | +2.0 |
| CHARGE LOSSES | 89 | 89 | 8 | 0.62 | +568 | +71.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.62 | +0 | +0.0 |
| TIME ON OUR SIDE | 49 | 44 | 8 | 0.62 | +14 | +1.7 |
| CHAFF PASSED | 7 | 7 | 7 | 0.54 | -9 | -1.2 |
| MARCH CHECK | 8 | 8 | 7 | 0.54 | +400 | +57.2 |
| RESERVE FALL BACK | 7 | 7 | 7 | 0.54 | +345 | +49.3 |
| SAFER THAN THE JOB | 7 | 7 | 7 | 0.54 | +204 | +29.1 |
| SET UP TOGETHER | 24 | 20 | 7 | 0.54 | +169 | +24.2 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 0.54 | +0 | +0.0 |
| WHO HITS BACK | 7 | 7 | 7 | 0.54 | +239 | +34.1 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.46 | +304 | +50.6 |
| HOLDER AT DEPLOYMENT | 21 | 21 | 6 | 0.46 | +241 | +40.2 |
| INVITES THE FIGHT | 26 | 26 | 6 | 0.46 | +45 | +7.6 |
| KILLS COUNT | 17 | 17 | 6 | 0.46 | +229 | +38.1 |
| MODEL FACING | 6 | 6 | 6 | 0.46 | +1958 | +326.4 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.46 | -75 | -12.5 |
| BEST PREY | 10 | 10 | 5 | 0.38 | +154 | +30.9 |
| FIRE IN ORDER | 5 | 5 | 5 | 0.38 | +0 | +0.0 |
| NEARER NOT NEEDED | 55 | 50 | 5 | 0.38 | +120 | +24.1 |
| SCOUT WAITS | 5 | 5 | 5 | 0.38 | +0 | +0.0 |
| STUCK PIVOT | 5 | 5 | 5 | 0.38 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 4 | 4 | 4 | 0.31 | +11 | +2.8 |
| FIGHT TO THE END | 30 | 30 | 4 | 0.31 | +152 | +38.0 |
| OPENS UP | 6 | 6 | 4 | 0.31 | +84 | +21.0 |
| SURE REACH TOGETHER | 11 | 9 | 4 | 0.31 | +16 | +4.0 |
| WALKS TO THE FIGHT | 16 | 16 | 4 | 0.31 | +6 | +1.6 |
| WEARS DOWN | 20 | 18 | 4 | 0.31 | +69 | +17.3 |
| WHOLE FIGHT | 7 | 7 | 4 | 0.31 | +490 | +122.4 |
| WHOLE FIGHT GAIN | 10 | 9 | 4 | 0.31 | +220 | +55.0 |
| BEST FACING | 3 | 3 | 3 | 0.23 | +86 | +28.8 |
| BLOCKED WHEEL | 3 | 3 | 3 | 0.23 | +243 | +81.0 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.23 | +1 | +0.2 |
| HARD STAY DROPPED | 3 | 3 | 3 | 0.23 | +0 | +0.0 |
| HONEST WORTH | 138 | 137 | 3 | 0.23 | +50 | +16.7 |
| KEEPS ITS TARGET | 16 | 16 | 3 | 0.23 | +67 | +22.2 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.23 | +118 | +39.2 |
| OVERRUNS AWAY | 12 | 12 | 3 | 0.23 | +77 | +25.7 |
| REFUSING RETIRES | 9 | 9 | 3 | 0.23 | -1 | -0.3 |
| STOPS SHORT OF THE FLANK | 3 | 3 | 3 | 0.23 | +96 | +32.0 |
| WAR ENGINE JOBS | 9 | 9 | 3 | 0.23 | -136 | -45.4 |
| BEST OVERALL | 2 | 2 | 2 | 0.15 | +68 | +34.1 |
| BIG CHARACTER SAFETY | 2 | 2 | 2 | 0.15 | +9 | +4.5 |
| HIS CHARGE DENIED | 4 | 4 | 2 | 0.15 | +21 | +10.5 |
| KEEP FALLS | 2 | 2 | 2 | 0.15 | +80 | +40.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.15 | +0 | +0.0 |
| LOST CHARGE | 29 | 28 | 2 | 0.15 | +49 | +24.4 |
| MAKE SURE TOGETHER | 9 | 6 | 2 | 0.15 | +10 | +4.8 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.15 | +59 | +29.6 |
| MOVE AND CAST | 2 | 2 | 2 | 0.15 | +158 | +79.2 |
| NO DOUBLE ROUNDS | 54 | 54 | 2 | 0.15 | +24 | +12.1 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.15 | +20 | +10.2 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.15 | -327 | -163.6 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.15 | -20 | -10.0 |
| WIDER SPREAD | 88 | 87 | 2 | 0.15 | +15 | +7.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.08 | +10 | +9.5 |
| BACKUP TARGETS | 7 | 4 | 1 | 0.08 | +0 | +0.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.08 | -5 | -5.1 |
| CAST JOB | 4 | 4 | 1 | 0.08 | +58 | +57.7 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| CHARGER SLAIN LOST | 17 | 16 | 1 | 0.08 | +6 | +5.5 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.08 | +5 | +5.3 |
| FOCUS FIRE | 1 | 1 | 1 | 0.08 | +23 | +23.3 |
| GUN MASK | 2 | 2 | 1 | 0.08 | +4 | +4.4 |
| HIS MOVE AND SHOT | 28 | 28 | 1 | 0.08 | +45 | +45.0 |
| HUNT ADVANCE | 2 | 2 | 1 | 0.08 | +18 | +17.7 |
| HUNT IN PAIRS | 3 | 1 | 1 | 0.08 | +1 | +1.0 |
| JOINT CHARGE PLAN | 2 | 2 | 1 | 0.08 | +0 | +0.4 |
| LONG SHOT | 11 | 11 | 1 | 0.08 | -11 | -11.2 |
| MARCH ODDS | 1 | 1 | 1 | 0.08 | +47 | +46.8 |
| MISSILES NEXT TURN | 69 | 43 | 1 | 0.08 | +11 | +10.9 |
| ONE OBJECTIVE FORMULA | 73 | 43 | 1 | 0.08 | +71 | +71.3 |
| REDIRECT BY WHAT IT STOPS | 18 | 18 | 1 | 0.08 | +40 | +40.2 |
| SPELLS IN THE FIGHT | 16 | 15 | 1 | 0.08 | +13 | +13.1 |
| STANDS TO CAST | 1 | 1 | 1 | 0.08 | +8 | +7.6 |
| STAY WEIGHED | 1 | 1 | 1 | 0.08 | +23 | +23.2 |
| STOPS | 1 | 1 | 1 | 0.08 | +20 | +20.0 |
| SUPPORT NARROWED | 91 | 91 | 1 | 0.08 | -5 | -5.0 |
| THROUGH LINE OF FIRE | 1 | 1 | 1 | 0.08 | +93 | +93.0 |
| TWO OR MORE ARRIVE | 4 | 4 | 1 | 0.08 | +0 | +0.4 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.08 | -14 | -14.0 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 30 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 6 | 6 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 35 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 4 | 4 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 52 | 52 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 121 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 31 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 25 | 25 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 15 | 15 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 43 | 43 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 73 | 73 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 3 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 14 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT NEEDED | 5 | 5 | 0 | 0.00 | - | - |
| NOT TURNED | 80 | 80 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 11 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 31 | 31 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 1024 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 46 | 46 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 14 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 14 | not checked | - | - | - | - |
| SPELL WORTH | 34 | not checked | - | - | - | - |
| STABLE ROLE | 188 | 186 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 11 | 11 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 110 | 110 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 50 | not checked | - | - | - | - |
| THE PROMISE ADDS | 6 | 6 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| TURN WORTH | 2 | 2 | 0 | 0.00 | - | - |
| WAITS AGAIN | 13 | 13 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 3 | 3 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: t9-opp-e62ea8a-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 17.00 | 0.08 | 42.4 |
| CHARGE NOW FIRST | rule | 0.46 | 0.62 | 28.8 |
| CHARGE NOT DECLARED | rule | 0.62 | 0.38 | 131.0 |
| FALLBACK | gate | 0.46 | - | 80.0 |
| PATHS CROSS | rule | 0.08 | 0.38 | 20.9 |
| PIVOT GUARDS FLANK | rule | 0.23 | 0.23 | 12.5 |
| TURN GATE | gate | 0.38 | - | 33.5 |
| CANNON PLANNED TARGET | rule | 0.31 | - | 60.4 |
| CHAFF PASSED | rule | 0.08 | 0.15 | 2.9 |
| WAR ENGINE JOBS | rule | 0.23 | - | 45.4 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 3.5 |
| DEPLOY BY FIGURES | rule | 0.08 | 0.08 | 7.6 |
| PURSUES BIG PREY | rule | 0.08 | 0.08 | 163.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.15 | - | 10.0 |
| BEST PRIZE | rule | - | 0.08 | 5.1 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 16.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | - | 7.4 |
| LONG SHOT | rule | 0.08 | - | 11.2 |
| NO REASON | gate | - | 0.08 | 1.8 |
| REFUSING RETIRES | rule | 0.08 | - | 0.7 |
| SUPPORT NARROWED | rule | 0.08 | - | 5.0 |
| SUPPORT REQUEST | gate | 0.08 | - | 18.4 |
| WHO HITS BACK | rule | - | 0.08 | 3.3 |
| WOUNDED STAYS OUT | rule | 0.08 | - | 14.0 |

### Plans: t9-opp-e62ea8a-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.8 | 21% | 156 | 195 | 125% |
| Mine | charge | 2.4 | 71% | 151 | 178 | 117% |
| Mine | close in | 3.5 | 31% | 109 | 94 | 86% |
| Mine | hold | 6.2 | 25% | 466 | 0 | 0% |
| Mine | join | 0.2 | 100% | 5 | 0 | 0% |
| Mine | shoot | 12.8 | 66% | 264 | 1079 | 409% |
| Mine | support | 5.0 | 86% | 69 | 0 | 0% |
| Opponent | charge | 4.6 | 65% | 984 | 439 | 45% |
| Opponent | move | 31.1 | 92% | 1966 | 0 | 0% |
| Opponent | shoot | 2.8 | 81% | 200 | 240 | 120% |
| Opponent | support | 0.4 | 60% | 13 | 0 | 0% |

### Packages: hunt the guns, t9-opp-e62ea8a-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 310 | 0 | 0% | 17 |
| Opponent | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 223 | 174 | 100% | 112 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 310 | 0 | 0% | 75 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 12 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 605 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 470 |
| Warriors of Chaos | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 223 | 174 | 100% | 42 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: t9-opp-e62ea8a-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 28% | 67% | 0% | - | 8% | 0% | 0% | 67% | 25% |
| Opponent | REDIRECT COUNTER | 3.0 | 31% | 83% | 8% | 0% | 27% | 0% | 18% | 55% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: t9-opp-e62ea8a-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 0 (5) | 0 | 0 | 47 | 80% | 4.0 | 0 (1) | 0 (4) | - | 0 (4) | 0 (1) |
| Mine | Character | 49 | 16 (49) | 16 | 0 | 35 | 18% | 2.8 | 12 (14) | 16 (23) | 25 (8) | 11 (27) | 23 (18) |
| Mine | Clean-up | 14 | 173 (14) | 39 | 134 | 51 | 36% | 3.1 | 111 (6) | 347 (5) | 60 (3) | 285 (8) | 50 (6) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | Fast Hammer | 12 | 57 (12) | 51 | 6 | 46 | 33% | 2.9 | 0 (5) | 128 (3) | 97 (4) | 79 (7) | 34 (5) |
| Mine | Hammer | 29 | 45 (29) | 26 | 19 | 44 | 14% | 3.1 | 42 (10) | 53 (17) | 0 (2) | 41 (20) | 55 (9) |
| Mine | Holder | 13 | 39 (13) | 3 | 36 | 13 | 38% | 3.0 | 79 (5) | 16 (5) | 31 (3) | 54 (8) | 22 (5) |
| Mine | Shooter | 13 | 63 (13) | 0 | 63 | 24 | 0% | 1.6 | 0 (1) | 70 (7) | 59 (5) | 64 (10) | 62 (3) |
| Mine | War machine | 31 | 40 (31) | 40 | 0 | 32 | 3% | 1.2 | 35 (20) | 14 (10) | 470 (1) | 0 (5) | 48 (26) |
| Mine | Wizard | 6 | 0 (6) | 0 | 0 | 0 | 33% | 2.0 | 0 (2) | 0 (4) | - | 0 (2) | 0 (4) |
| Opponent | Chaff | 22 | 77 (22) | 31 | 46 | 76 | 41% | 3.4 | 29 (11) | 292 (3) | 55 (8) | 57 (15) | 104 (7) |
| Opponent | Character | 34 | 45 (34) | 45 | 0 | 21 | 21% | 2.2 | 28 (10) | 53 (17) | 54 (7) | 33 (14) | 51 (20) |
| Opponent | Clean-up | 3 | 54 (3) | 38 | 16 | 29 | 33% | 5.5 | 47 (2) | 71 (1) | - | 54 (3) | - |
| Opponent | Fast | 1 | 345 (1) | 345 | 0 | 100 | 0% | 4.0 | 345 (1) | - | - | 345 (1) | - |
| Opponent | Fast Hammer | 23 | 31 (23) | 11 | 20 | 29 | 39% | 3.9 | 39 (4) | 38 (12) | 17 (7) | 26 (12) | 37 (11) |
| Opponent | Fragile | 4 | 0 (4) | 0 | 0 | 28 | 75% | 1.0 | 0 (3) | 0 (1) | - | 0 (1) | 0 (3) |
| Opponent | Hammer | 16 | 66 (16) | 41 | 26 | 21 | 44% | 2.8 | 0 (1) | 121 (9) | 0 (6) | 29 (9) | 118 (7) |
| Opponent | Holder | 11 | 38 (11) | 9 | 29 | 19 | 45% | 4.0 | 14 (4) | 50 (4) | 44 (3) | 58 (7) | 10 (4) |
| Opponent | Shooter | 17 | 71 (17) | 27 | 44 | 25 | 18% | 1.5 | 63 (5) | 93 (8) | 15 (4) | 59 (9) | 85 (8) |
| Opponent | War machine | 6 | 34 (6) | 34 | 0 | 0 | 0% | 1.2 | 58 (3) | 0 (3) | - | 58 (3) | 0 (3) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | - | - | 0 (2) | 0 (1) | 0 (1) |

### Charged fights: t9-opp-e62ea8a-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 100 | 106 | 1.0 | 1.5 | 106 | 0 | +106 | 0 of 4 | 3 of 4 | +137 | +75 |
| Mine | Chaos Dwarfs | 4 | 142 | 194 | 3.0 | 1.0 | 65 | 74 | -10 | 5 of 12 | 7 of 12 | - | -10 |
| Mine | Dwarfen Mountain Holds | 3 | 477 | 161 | 2.0 | 1.0 | 80 | 116 | -35 | 4 of 6 | 5 of 6 | - | -35 |
| Mine | Empire of Man | 2 | 0 | 310 | 2.0 | 1.5 | 155 | 0 | +155 | 2 of 4 | 2 of 4 | +122 | +166 |
| **Mine** | all armies | 13 | 185 | 177 | 2.0 | 1.2 | 89 | 61 | +28 | 11 of 26 | 17 of 26 | +132 | +14 |
| Opponent | Empire of Man | 1 | 225 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | High Elf Realms | 4 | 263 | 214 | 4.0 | 1.0 | 53 | 55 | -1 | 11 of 16 | 6 of 16 | - | -1 |
| Opponent | Lizardmen | 1 | 0 | 310 | 3.0 | 1.0 | 103 | 0 | +103 | 1 of 3 | 2 of 3 | - | +103 |
| Opponent | Skaven | 1 | 0 | 95 | 2.0 | 1.0 | 48 | 0 | +48 | 0 of 2 | 1 of 2 | - | +48 |
| Opponent | Vampire Counts | 1 | 105 | 60 | 2.0 | 2.0 | 30 | 0 | +30 | 1 of 2 | 2 of 2 | +30 | - |
| Opponent | Warriors of Chaos | 4 | 0 | 651 | 4.2 | 1.1 | 153 | 0 | +153 | 7 of 17 | 15 of 17 | +192 | +148 |
| Opponent | Wood Elf Realms | 1 | 0 | 310 | 5.0 | 1.0 | 62 | 5 | +57 | 4 of 5 | 3 of 5 | - | +57 |
| **Opponent** | all armies | 13 | 106 | 326 | 3.5 | 1.1 | 92 | 20 | +72 | 24 of 46 | 30 of 46 | +111 | +69 |

### Effective charges: t9-opp-e62ea8a-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net +151) | 1 (net +80) | 1 (net +70) | 1 (net +123) | 0 | 0 | 0 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 12 | 1 (net +0) | 0 | 3 (net -297) | 2 (net +92) | 1 (net +56) | 4 (net +78) | 1 | 27% (3 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net -30) | 0 | 0 | 0 | 0 | 4 (net -38) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 4 | 0 | 1 (net +347) | 1 (net +151) | 1 (net +0) | 1 (net +122) | 0 | 0 | 25% (1 of 4) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | High Elf Realms | 16 | 7 (net -60) | 0 | 2 (net +0) | 3 (net +103) | 2 (net +55) | 1 (net +125) | 1 | 13% (2 of 15) |
| Opponent | Lizardmen | 3 | 1 (net +0) | 0 | 0 | 1 (net +310) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +95) | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 1 (net +0) | 1 (net +60) | 0 | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 17 | 2 (net +110) | 1 (net +0) | 4 (net +182) | 0 | 5 (net +111) | 4 (net +254) | 1 | 25% (4 of 16) |
| Opponent | Wood Elf Realms | 5 | 3 (net +94) | 0 | 0 | 2 (net +0) | 0 | 0 | 0 | 0% (0 of 5) |

### Charged fights, damage counted: t9-opp-e62ea8a-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 141 | 366 | +23 | 94 | 19 | +75 | +53.1 |
| Mine | 50-54% | 2 | 120 | 164 | +214 | 214 | 13 | +200 | +166.4 |
| Mine | Effective (55-75%) | 5 | 224 | 263 | -134 | 115 | 199 | -84 | -37.6 |
| Mine | 76-89% | 4 | 218 | 195 | +77 | 109 | 14 | +95 | +43.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 178 | 175 | +20 | 115 | 116 | -1 | -0.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 474 | 89 | +89 | 89 | 0 | +89 | +18.8 |
| Mine | No odds | 1 | 339 | 115 | +222 | 222 | 0 | +222 | +65.5 |
| Mine | All fights | 26 | 212 | 214 | +28 | 120 | 80 | +40 | +19.0 |
| Opponent | Long shot (under 50%) | 14 | 256 | 328 | +6 | 67 | 127 | -60 | -23.4 |
| Opponent | 50-54% | 1 | 30 | 85 | +0 | 0 | 15 | -15 | -50.0 |
| Opponent | Effective (55-75%) | 7 | 283 | 211 | +104 | 135 | 33 | +102 | +35.9 |
| Opponent | 76-89% | 7 | 389 | 257 | +89 | 124 | 29 | +96 | +24.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 454 | 214 | +206 | 206 | 9 | +197 | +43.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 450 | 88 | +90 | 113 | 6 | +107 | +23.8 |
| Opponent | No odds | 3 | 240 | 131 | -19 | 44 | 68 | -24 | -10.1 |
| Opponent | All fights | 46 | 334 | 225 | +72 | 109 | 55 | +54 | +16.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| t9-opp-e62ea8a-p4 | move | 118 | 35 (30%) | 21 (18%) | 13 (11%) | 70 (59%) |
| t9-opp-e62ea8a-p4 | objective | 45 | 7 (16%) | 6 (13%) | 6 (13%) | 32 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130 |
| Charmed Shield | Opponent | L0434, L0624 |
| Invocation of Nehek | Opponent | L0624 |
| Opal Amulet | Opponent | L0114, L0214 |
| Periapt of Soul Exchange | Opponent | L0520 |
| Ring of Doom | Mine | L0214, L0230 |
| Ring of Doom | Opponent | L0315 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Twice-Blessed Armour | Mine | L0713, L0729 |
| Witch Hunter's Ward | Mine | L0713, L0729 |
| Witch Hunter's Ward | Opponent | L0608 |

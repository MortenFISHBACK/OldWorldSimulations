# Doctrine scorecard: fw-on-db7ca9c-p2c

### Scorecard: fw-on-db7ca9c-p2c

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 732 |
| L1629 | 3 | 1 | Mine | no | 2 | 4 | 1 | 0 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 4 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 4 | 1 | 3 | 1 | 0 | 0 | 0 | 491 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 2 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 0 | 0 | 1 | 0 | 0 | 355 |
| L2131 | 1 | 1 | Opponent | no | 5 | 4 | 3 | 0 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 5 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 1 | 2 | 7 | 1 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 3 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 8 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 2 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.7 | 3.0 | 1.9 | 0.8 | 0.4 | 0.0 | 0.0 | 150.2 |
| **Average** | | | Opponent | 25% | 2.1 | 2.4 | 3.8 | 0.9 | 0.1 | 0.0 | 0.0 | 114.0 |

### KPIs: fw-on-db7ca9c-p2c

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 49% (31 of 63) | 41% (26 of 64) | 45% (57 of 127) |
| Winner chose to follow up after the loser gave ground |  | 100% (30 of 30); on the table 100% | 100% (23 of 23); on the table 100% | 100% (53 of 53); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (2 of 4); on the table 50% | 100% (6 of 6); on the table 100% | 80% (8 of 10); on the table 80% |
| Winner chose to pursue after the loser fled |  | 62% (5 of 8); on the table 75% | 86% (6 of 7); on the table 86% | 73% (11 of 15); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 88% (37 of 42); on the table 90% | 97% (35 of 36); on the table 97% | 92% (72 of 78); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 35% (21 of 60) | 52% (22 of 42) | 42% (43 of 102) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (21 of 45) | 59% (22 of 37) | 52% (43 of 82) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 68% (15 of 22) | 60% (15 of 25) | 64% (30 of 47) |
| Points that never fought | lower | 17% (4084 of 23995) | 30% (7298 of 23997) | 24% (11382 of 47992) |
|   infantry points that never fought | lower | 35% (1666 of 4780) | 50% (2454 of 4872) | 43% (4120 of 9652) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 51% (41 of 81) | 61% (67 of 109) | 57% (108 of 190) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 1.2 uses a game | 71% (5 of 7); 1.4 uses a game | 82% (9 of 11); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (4 of 6); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (9456 of 19960) | 52% (11606 of 22252) | 50% (21062 of 42212) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.5 (15%) | 1.1 (65%) | 1.6 (32%) |
| MARCHED: its unit marched | 0.8 (26%) | 0.2 (10%) | 1.0 (20%) |
| CHARGED: its unit charged | 0.2 (8%) | 0.0 (0%) | 0.2 (5%) |
| IN COMBAT: engaged in combat | 0.7 (21%) | 0.1 (5%) | 0.8 (15%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) |
| GONE: slain | 0.5 (15%) | 0.3 (20%) | 0.8 (17%) |
| STUPIDITY: Stupidity | 0.2 (5%) | 0.0 (0%) | 0.2 (3%) |
| NOT OFFERED: not in the cast list | 0.2 (8%) | 0.0 (0%) | 0.2 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.5 | 1.4 | 1.9 | 3.6 | 0.6 | 1.9 |
| not cast | 6.5 | 1.8 | 3.1 | 4.9 | 1.9 | 23.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 1.5 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (38%) | 0.0 (0%) | 1.6 (32%) | 0.9 (48%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (20%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.2 (10%) | 0.2 (5%) | 0.8 (15%) | 0.1 (4%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.1 (2%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 1.7 (26%) | 0.2 (10%) | 0.2 (8%) | 0.8 (17%) | 0.2 (9%) | 3.4 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (19%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.8 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.4 (24%) | 0.0 (0%) | 0.0 (0%) | 0.5 (26%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.2 (65%) | 0.0 (0%) | 2.0 (65%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.4 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 1.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 40% (2 of 5) | 67% (8 of 12) | 59% (10 of 17) |
| the unit moved after it | 50% (1 of 2) | 25% (2 of 8) | 30% (3 of 10) |
| it charged on its next turn | 0% (0 of 2) | 0% (0 of 8) | 0% (0 of 10) |
| the enemy charged it first | 50% (1 of 2) | 12% (1 of 8) | 20% (2 of 10) |
| it fought by the end of its next turn | 0% (0 of 2) | 0% (0 of 8) | 0% (0 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 38% (3 of 8) | 30% (3 of 10) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | 50% (4 of 8) | 50% (5 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (121 of 209) | 54% (75 of 138) | 56% (196 of 347) |
|   cavalry | 87% (20 of 23) | 56% (38 of 68) | 64% (58 of 91) |
|   character | 27% (6 of 22) | 12% (3 of 26) | 19% (9 of 48) |
|   chariot | 47% (15 of 32) | - | 47% (15 of 32) |
|   infantry | 61% (57 of 93) | 77% (34 of 44) | 66% (91 of 137) |
|   monster | 47% (14 of 30) | - | 47% (14 of 30) |
|   war machine | 100% (9 of 9) | - | 100% (9 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (20%) | 1.3 (25%) | 2.8 (23%) |
| CHARGED: it charged | 1.1 (15%) | 1.8 (35%) | 2.9 (23%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (12%) | 0.2 (5%) | 1.2 (9%) |
| NO TARGET IN RANGE | 2.1 (28%) | 0.8 (14%) | 2.8 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (5%) | 0.1 (2%) | 0.4 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (14%) | 0.8 (14%) | 1.8 (14%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.2 | 1.5 | 85% | 4.8 pts | 34 pts |
| character | 1.0 | 0.2 | 83% | 7.7 pts | 8 pts |
| chariot | 1.2 | 0.1 | 93% | 0.7 pts | 1 pts |
| infantry | 10.1 | 2.8 | 78% | 9.9 pts | 100 pts |
| monster | 1.2 | 0.2 | 86% | 1.1 pts | 1 pts |
| war machine | 0.8 | 1.0 | 33% | 38.8 pts | 29 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.1 | 6.8 | 5.9 |
| Charges that made contact a game | 3.7 | 4.2 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.33 contact (6 units) | 0.00 declared, 0.00 contact (4 units) | 0.30 declared, 0.20 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.71 declared, 0.71 contact (7 units) | 1.14 declared, 0.71 contact (7 units) | 0.93 declared, 0.71 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.40 contact (93 units) | 0.75 declared, 0.46 contact (97 units) | 0.66 declared, 0.43 contact (190 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (15 of 26) | 58% (7 of 12) | 60% (3 of 5) | 58% (25 of 43) |
| Character in a unit | 80% (4 of 5) | 40% (2 of 5) | 50% (1 of 2) | 58% (7 of 12) |
| Character on its own | 77% (17 of 22) | 50% (4 of 8) | 19% (5 of 27) | 46% (26 of 57) |
| Chariot | 40% (2 of 5) | - | - | 40% (2 of 5) |
| Infantry | 65% (22 of 34) | 82% (9 of 11) | - | 69% (31 of 45) |
| Monster | 67% (8 of 12) | 80% (4 of 5) | - | 71% (12 of 17) |
| Monstrous | 43% (3 of 7) | 50% (2 of 4) | - | 45% (5 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 50% (1 of 2); on the table 50% | - | 0% | 29% (2 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 75% (3 of 4); on the table 75% | - | 18% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (8 of 8); on the table 100% | - | 15% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (4 of 4); on the table 100% | 17% (1 of 6) | 17% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (5 of 5); on the table 100% | 17% (2 of 12) | 3% | 0% (0 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 2 | 71% (5 of 7); on the table 86% | 33% (4 of 12) | 28% | 69% (11 of 16) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 1 | 67% (2 of 3); on the table 67% | - | 38% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 100% (23 of 23); on the table 100% | 48% (23 of 48) | 20% | 65% (24 of 37) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 93% (13 of 14); on the table 93% | 83% (5 of 6) | 23% | 59% (30 of 51) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 4 | 100% (8 of 8); on the table 100% | 44% (8 of 18) | 42% | 59% (27 of 46) | 60% (3 of 5); 2.8 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-on-db7ca9c-p2c, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 58% (19) | 47% (14) | 52% (33) |
| ...free all their last turn and able to turn (per game) | 1.25 | 0.92 | 2.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.17 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.67 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.33 | 1.83 | 4.17 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.83 | 0.58 | 1.42 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 11.83 | 8.33 | 20.17 |

### Quality by phase: fw-on-db7ca9c-p2c

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.4 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 51% (30 of 59) | 49% (37 of 76) |
| Strategy | Shoot objectives carried out (shot that target) | 52% (14 of 27) | 44% (12 of 27) |
| Strategy | Close-in objectives charged next turn | 11% (5 of 45) | 20% (16 of 79) |
| Strategy | Support requests answered (helper made contact too) | 11% (1 of 9) | 43% (3 of 7) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | 71% (5 of 7) |
| Strategy | Joined characters whose unit fought | 100% (10 of 10) | 33% (3 of 9) |
| Strategy | Lone characters that fought | 82% (28 of 34) | 66% (23 of 35) |
| Movement | Charges halted short of contact | 0.3 | 0.4 |
| Movement | Idle units | 0.8 | 0.9 |
| Movement | Points that never moved of their own | 150.2 | 114.0 |
| Movement | Fights charged into per game | 3.1 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 31, net +178 | 8 of 41, net +11 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 31, net -76 | 4 of 41, net +52 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 31, net +216 | 4 of 41, net +106 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 of 31, net +110 | 15 of 41, net +209 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 7.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (45 of 128) | 52% (44 of 85) |
| Shooting | Points destroyed by shooting units | 47.9 | 25.4 |
| Shooting | War machine shots | 0.8 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 100% (9 of 9) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.1 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 23% (3 of 13) | 23% (3 of 13) |
| Magic | Wounds caused by magic missiles | 1.2 | 1.4 |
| Magic | Wounds caused by other spells | 0.4 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 15.5 | 44.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.5 / 0.6 / 0.1 | 0.4 / 0.6 / 0.6 / 0.4 |
| Combat | Points destroyed in combat | 329.9 | 603.4 |
| Combat | Points run down | 145.0 | 133.2 |
| Combat | Net points per charged fight, damage counted | +58 | +112 |
| Combat | Net per 100 charger points, damage counted | +22.6 | +47.1 |
| Combat | First round won (charged fights) | 78% | 66% |
| Combat | Net points per charged fight | +59 | +117 |
| Combat | Net points per supported fight / lone fight | +97 / +52 | +334 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 10 of 37 | 18 of 44 |
| Game | Points lost | 855.8 | 680.7 |
| Game | VP from objectives | 562.5 | 539.2 |
| Game | Lone holders (player turns) | 2.7 | 2.1 |

- Mine won / drew / lost: 4 / 3 / 5 of 12 ended games (of 12); mean margin (Mine - Opponent) -171 VP
- The side that went first won 5 of 9 games with a winner
- Points traded per game (both sides' losses): 1536
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-on-db7ca9c-p2c

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.3 | +11.0 | 0.0 | 0.0 | 1.1 | +21.1 | 0.0 | 10.5 |
| BEST FACING | 1.0 | +12.6 | 0.0 | 20.9 | 0.8 | +41.5 | 0.0 | 37.9 |
| BEST FIRST | 5.4 | +209.3 | 134.6 | 136.1 | 2.6 | +171.2 | 31.2 | 9.7 |
| BEST OVERALL | 1.1 | +74.8 | 0.0 | 60.1 | 0.8 | +59.4 | 0.0 | 20.8 |
| BEST PREY | 0.2 | +8.6 | 24.0 | 17.5 | 0.7 | +20.4 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | +16.1 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.8 | +20.8 | 0.0 | 39.9 | 0.8 | +3.8 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 0.6 | +22.9 | 0.0 | 8.3 | - | - | - | - |
| CANNON SIGHT KEPT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 15.5 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -9.5 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 0.2 | +1.1 | 15.4 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +5.1 | 0.0 | 0.0 | 0.2 | +15.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 126.8 | 0.7 | +0.0 | 0.0 | 45.7 |
| CASTS FROM BEHIND | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | -0.3 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.2 | -11.8 | 9.7 | 0.0 | 1.0 | -68.8 | 110.5 | 98.6 |
| CHARIOT WIZARD CAREFUL | 0.2 | -1.4 | 0.0 | 39.2 | - | - | - | - |
| CHEAP HELPER | 0.2 | +0.0 | 20.5 | 11.2 | 0.2 | +0.0 | 18.0 | 9.5 |
| COMBAT PIVOT | 0.4 | +0.0 | 0.0 | 39.2 | 0.6 | +0.0 | 91.2 | 14.2 |
| CONVEYANCE SEARCH | 0.3 | +19.3 | 49.8 | 41.7 | 1.0 | +81.9 | 8.5 | 45.7 |
| COUNTER-CHARGE COVER | 14.1 | +1152.8 | 0.0 | 363.9 | 9.6 | +902.1 | 0.0 | 160.5 |
| DEFENSIVE ARMY | 0.1 | -0.2 | 0.0 | 0.0 | 0.5 | -0.1 | 79.8 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +15.9 | 26.3 | 6.6 | 0.1 | +0.7 | 0.0 | 0.0 |
| ELIXIR WORTH | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.3 | +180.8 | 0.0 | 60.1 | 1.8 | +120.4 | 0.0 | 97.0 |
| FALLBACK BY WORTH | 4.2 | +33.8 | 0.0 | 27.8 | 3.3 | +49.2 | 0.0 | 69.8 |
| FIGHT LIFT | 0.1 | +8.0 | 0.0 | 32.9 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.4 | 0.0 | 6.7 | - | - | - | - |
| FLANK NOT WEIGHED | 10.5 | +0.0 | 0.0 | 327.7 | 7.5 | +0.0 | 0.0 | 171.2 |
| FOCUS FIRE | 0.1 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.4 | +84.0 | 0.0 | 51.0 | 1.6 | +248.5 | 0.0 | 67.1 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.1 | -0.3 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -26.2 | 75.8 | 2.8 | 1.7 | -95.6 | 334.0 | 74.9 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.5 | 11.8 | 3.8 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 39.2 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 12.0 | 19.7 | 0.2 | +0.0 | 24.0 | 3.8 |
| HOLDS AMBUSHERS | 0.6 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.3 | +1.5 | 0.0 | 2.8 | - | - | - | - |
| HUNT DROPPED | 0.2 | +0.0 | 0.0 | 9.6 | - | - | - | - |
| HUNT IN PAIRS | 0.1 | +0.1 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| HUNT KEPT | 0.2 | +1.1 | 0.0 | 2.8 | - | - | - | - |
| HUNT RESULT | 0.2 | +0.0 | 0.0 | 9.6 | - | - | - | - |
| HUNT THE GUNS | 0.2 | +51.8 | 0.0 | 2.8 | - | - | - | - |
| INVITES THE FIGHT | 4.8 | +215.9 | 64.5 | 83.4 | 2.8 | +115.7 | 132.0 | 90.2 |
| JOINT CHARGE PLAN | 0.1 | +0.5 | 0.0 | 0.0 | 0.2 | +16.7 | 32.8 | 4.5 |
| KEEPS ITS TARGET | 2.1 | +62.5 | 134.6 | 48.3 | 2.7 | +80.0 | 318.8 | 149.9 |
| KILLS COUNT | 2.4 | +66.2 | 106.2 | 72.7 | 2.8 | +163.9 | 323.0 | 26.8 |
| KILLS COUNT NEXT TURN | 5.4 | +148.7 | 222.7 | 57.1 | 8.4 | +413.4 | 231.5 | 199.1 |
| LONE CHARACTER SAFE SPOT | 0.3 | +15.2 | 9.5 | 33.8 | 0.3 | +2.9 | 39.2 | 0.0 |
| LONE WIZARD HOLDS BACK | 1.2 | +0.0 | 0.0 | 65.8 | 1.6 | +0.0 | 0.0 | 16.2 |
| LONE WIZARD KEPT IN | 0.4 | +16.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.2 | -4.6 | 15.5 | 8.9 | 0.8 | +1.1 | 62.4 | 17.7 |
| LOST CHARGE | 2.4 | -44.3 | 51.1 | 120.0 | 2.1 | -34.7 | 59.2 | 83.7 |
| MAKE SURE TOGETHER | 0.2 | +1.4 | 0.0 | 0.0 | 0.4 | +7.7 | 32.8 | 15.5 |
| MANOEUVRE | 0.6 | +17.9 | 0.0 | 29.2 | 0.3 | +17.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.8 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +25.8 | 0.0 | 0.0 | 0.5 | +26.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.8 | +75.3 | 0.0 | 33.8 | 0.1 | +12.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.8 | +324.2 | 0.0 | 238.6 | 6.1 | +225.3 | 0.0 | 99.3 |
| MISSILES IN THE MOVE | 3.1 | +53.3 | 0.0 | 156.8 | 3.6 | +71.6 | 0.0 | 68.5 |
| MISSILES NEXT TURN | 3.7 | +34.6 | 0.0 | 156.8 | 3.7 | +44.2 | 0.0 | 68.5 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.2 | +5.5 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +1.8 | 0.0 | 33.8 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.1 | -0.4 | 0.0 | 0.0 | 0.5 | -15.2 | 17.3 | 0.0 |
| MOVE TO CHARGE | 4.3 | +282.8 | 142.0 | 55.9 | 6.8 | +663.2 | 293.4 | 140.2 |
| MOVES UNITS SPELL | 0.2 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.2 | +31.5 | 18.9 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.4 | -40.1 | 38.3 | 6.0 | 0.8 | -52.2 | 140.8 | 38.8 |
| NOT TURNED | 11.8 | +288.5 | 0.0 | 255.6 | 8.3 | +66.7 | 0.0 | 258.9 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 0.0 | 1.5 | -0.9 | 0.0 | 0.0 |
| OFF BEST | 13.6 | -699.2 | 63.6 | 265.0 | 13.5 | -743.8 | 45.2 | 234.1 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.2 | 8.2 | 0.0 |
| OPENS UP | 0.2 | +19.9 | 0.0 | 16.2 | 0.2 | +28.1 | 23.7 | 0.0 |
| OVERRUNS AWAY | 0.8 | +9.8 | 73.0 | 31.1 | 0.7 | +9.1 | 106.4 | 0.0 |
| PATHS CROSS | 2.8 | +222.2 | 0.0 | 26.6 | 2.8 | +195.5 | 0.0 | 30.2 |
| PERIAPT WORTH | 0.1 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.5 | -12.5 | 0.0 | 6.2 | 0.2 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 41.1 | +647.2 | 1324.2 | 1335.3 | 41.5 | +927.6 | 1687.8 | 1009.6 |
| PURSUES BIG PREY | 0.1 | -1.3 | 0.0 | 0.0 | 0.1 | -1.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +19.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +9.9 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.8 | +47.3 | 0.0 | 70.0 | 2.1 | +18.4 | 0.0 | 70.8 |
| RANDOM MOVER NO PROMISE | 0.7 | -53.0 | 12.0 | 17.5 | 0.3 | -31.3 | 0.0 | 14.2 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -4.6 | 0.0 | 0.0 | 0.6 | +12.7 | 0.0 | 12.0 |
| REDIRECT COUNTER | 3.8 | +343.9 | 0.0 | 78.6 | 3.6 | +269.6 | 0.0 | 42.7 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 3.8 |
| RESERVE FALL BACK | 1.1 | +52.9 | 0.0 | 12.7 | 0.7 | +37.5 | 0.0 | 13.2 |
| RESTRAINS TO SHOOT | 0.2 | +5.0 | 0.0 | 38.9 | 0.1 | +2.5 | 0.0 | 13.2 |
| RISK BY ARC | 3.0 | +96.6 | 331.2 | 112.8 | 4.0 | +130.5 | 461.2 | 97.0 |
| SAFER THAN THE JOB | 0.8 | +58.0 | 0.0 | 16.4 | 0.6 | +36.0 | 0.0 | 35.7 |
| SCOUT SPOT | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.2 | -10.2 | 0.0 | 0.0 | 0.2 | -9.2 | 0.0 | 2.5 |
| SEARCH SPOT | 4.5 | +228.8 | 0.0 | 42.9 | 4.5 | +188.8 | 0.0 | 61.0 |
| SECOND HUNTER | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.9 | +78.9 | 0.0 | 120.2 | - | - | - | - |
| SET UP TOGETHER | 0.4 | +11.1 | 31.1 | 39.2 | 1.4 | +90.3 | 98.2 | 24.5 |
| SET-UP ANY TARGET | - | - | - | - | 0.4 | +37.4 | 8.5 | 22.8 |
| SET-UP MISSED | 0.1 | +4.5 | 0.0 | 33.8 | 0.1 | +4.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.4 | +24.1 | 31.0 | 18.7 | 0.3 | +6.3 | 16.2 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 6.0 | - | - | - | - |
| SHOTS IN THE MOVE | 8.6 | +198.1 | 0.0 | 115.7 | 6.1 | +105.5 | 0.0 | 148.8 |
| SPELL CATCH ODDS | - | - | - | - | 0.1 | -1.6 | 0.0 | 22.8 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.5 | +55.0 | 8.5 | 22.8 |
| SPELL WORTH | 1.5 | +32.9 | 189.2 | 222.1 | 0.8 | +13.5 | 38.7 | 38.7 |
| STABLE ROLE | 11.3 | +0.0 | 405.1 | 59.6 | 12.9 | +0.0 | 308.7 | 237.3 |
| STOPS | 0.1 | +0.3 | 0.0 | 2.8 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.6 | +16.1 | 0.0 | 56.8 | 0.8 | +22.6 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORTS | 11.7 | +588.0 | 335.2 | 207.9 | 11.5 | +403.4 | 224.2 | 197.3 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -15.6 | 20.8 | 0.0 | 0.4 | -32.2 | 38.6 | 9.7 |
| SURE REACH TOGETHER | - | - | - | - | 0.8 | +2.5 | 32.8 | 0.0 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -25.2 | 25.8 | 0.0 | 0.3 | -8.6 | 15.2 | 0.0 |
| WALKS TO THE FIGHT | 1.5 | +61.7 | 17.1 | 0.0 | 1.7 | +35.4 | 42.9 | 60.8 |
| WAR ENGINE JOBS | 1.1 | +0.0 | 39.2 | 6.2 | 0.2 | +0.0 | 19.7 | 6.2 |
| WEARS DOWN | 1.2 | +46.4 | 180.2 | 61.9 | 2.2 | +94.2 | 308.5 | 76.5 |
| WHO HITS BACK | 0.4 | +49.3 | 0.0 | 39.2 | 0.1 | +0.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +1.1 | 0.0 | 0.0 | 0.2 | +14.4 | 37.7 | 15.5 |
| WHOLE FIGHT GAIN | 0.7 | +85.9 | 94.8 | 56.2 | 0.1 | +1.2 | 11.8 | 3.8 |

### Rule changes: fw-on-db7ca9c-p2c

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 325 | 325 | 325 | 27.08 | -17316 | -53.3 |
| SUPPORTS | 278 | 278 | 160 | 13.33 | +4427 | +27.7 |
| SEARCH SPOT | 108 | 108 | 108 | 9.00 | +5011 | +46.4 |
| BEST FIRST | 96 | 96 | 96 | 8.00 | +4566 | +47.6 |
| COUNTER-CHARGE COVER | 284 | 200 | 83 | 6.92 | +4106 | +49.5 |
| MOVE TO CHARGE | 133 | 133 | 79 | 6.58 | +5194 | +65.7 |
| PATHS CROSS | 67 | 67 | 67 | 5.58 | +5011 | +74.8 |
| FACES THE THREAT | 50 | 50 | 50 | 4.17 | +3614 | +72.3 |
| KILLS COUNT NEXT TURN | 166 | 166 | 47 | 3.92 | +1064 | +22.6 |
| FOLLOW UP WEIGHED | 36 | 36 | 36 | 3.00 | +3990 | +110.8 |
| INVITES THE FIGHT | 91 | 91 | 33 | 2.75 | +1034 | +31.3 |
| RANDOM MOVE BY FIGURES | 47 | 47 | 30 | 2.50 | +789 | +26.3 |
| WALKS TO THE FIGHT | 38 | 38 | 27 | 2.25 | +394 | +14.6 |
| RISK BY ARC | 84 | 79 | 24 | 2.00 | +851 | +35.5 |
| BEST OVERALL | 22 | 22 | 22 | 1.83 | +1609 | +73.2 |
| KILLS COUNT | 62 | 59 | 22 | 1.83 | +631 | +28.7 |
| BEST FACING | 21 | 21 | 21 | 1.75 | +650 | +30.9 |
| RESERVE FALL BACK | 21 | 21 | 21 | 1.75 | +1085 | +51.7 |
| BLOCKED WHEEL | 19 | 19 | 19 | 1.58 | +295 | +15.5 |
| FALLBACK BY WORTH | 91 | 91 | 19 | 1.58 | +997 | +52.5 |
| HOLDS AMBUSHERS | 19 | 19 | 19 | 1.58 | +0 | +0.0 |
| MAX FOR POSITIONING | 155 | 99 | 18 | 1.50 | +237 | +13.1 |
| REDIRECT COUNTER | 89 | 59 | 18 | 1.50 | +946 | +52.5 |
| SAFER THAN THE JOB | 17 | 17 | 17 | 1.42 | +1127 | +66.3 |
| SHOTS IN THE MOVE | 176 | 120 | 17 | 1.42 | +255 | +15.0 |
| ADVANCE LANE KEPT | 16 | 16 | 16 | 1.33 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 16 | 16 | 16 | 1.33 | +465 | +29.0 |
| CHARGE NOW WEIGHED | 15 | 15 | 15 | 1.25 | +1591 | +106.0 |
| COMBAT PIVOT | 12 | 12 | 12 | 1.00 | +0 | +0.0 |
| KEEPS ITS TARGET | 57 | 55 | 12 | 1.00 | +193 | +16.1 |
| CASTS FROM BEHIND | 11 | 11 | 11 | 0.92 | +0 | +0.0 |
| MARCH CHECK | 13 | 12 | 11 | 0.92 | +574 | +52.1 |
| MANOEUVRE | 11 | 11 | 9 | 0.75 | +428 | +47.5 |
| MISSILES IN THE MOVE | 80 | 59 | 9 | 0.75 | +177 | +19.6 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.75 | -182 | -20.2 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.67 | -573 | -71.7 |
| WEARS DOWN | 41 | 39 | 8 | 0.67 | +393 | +49.2 |
| SHOOTERS IN TWO RANKS | 7 | 7 | 7 | 0.58 | +13 | +1.9 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 6 | 0.50 | +78 | +13.0 |
| WHO HITS BACK | 6 | 6 | 6 | 0.50 | +386 | +64.3 |
| WHOLE FIGHT GAIN | 9 | 8 | 6 | 0.50 | +344 | +57.4 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 0.42 | +195 | +39.1 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 0.42 | +84 | +16.7 |
| SCOUT WAITS | 5 | 5 | 5 | 0.42 | +0 | +0.0 |
| SET UP TOGETHER | 22 | 18 | 5 | 0.42 | +205 | +40.9 |
| BIG CHARACTER SAFETY | 4 | 4 | 4 | 0.33 | -0 | -0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 0.33 | +170 | +42.5 |
| SHOT REPLANNED | 4 | 4 | 4 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 4 | 4 | 4 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 0.25 | -3 | -1.1 |
| LONE WIZARD HOLDS BACK | 33 | 33 | 3 | 0.25 | -48 | -16.1 |
| LONG SHOT | 13 | 12 | 3 | 0.25 | +63 | +21.0 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.25 | +90 | +29.9 |
| WAR ENGINE JOBS | 16 | 16 | 3 | 0.25 | -126 | -42.1 |
| BACKUP TARGETS | 29 | 15 | 2 | 0.17 | +9 | +4.5 |
| BEST PREY | 11 | 11 | 2 | 0.17 | +56 | +28.1 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| CARRIES OUT SET-UP | 3 | 3 | 2 | 0.17 | -114 | -56.8 |
| EDGE GIVE GROUND | 4 | 4 | 2 | 0.17 | +46 | +22.9 |
| JOINT CHARGE PLAN | 4 | 4 | 2 | 0.17 | +69 | +34.6 |
| LOST CHARGE | 54 | 54 | 2 | 0.17 | +69 | +34.5 |
| MOVE AND CAST | 2 | 2 | 2 | 0.17 | +66 | +32.9 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.17 | +12 | +5.8 |
| NEEDED THERE | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| OPENS UP | 5 | 5 | 2 | 0.17 | +100 | +49.9 |
| OVERRUNS AWAY | 17 | 16 | 2 | 0.17 | +59 | +29.5 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.17 | -37 | -18.3 |
| SURE REACH TOGETHER | 9 | 6 | 2 | 0.17 | +23 | +11.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.08 | -4 | -4.1 |
| CANNON PLANNED TARGET | 7 | 7 | 1 | 0.08 | +0 | +0.0 |
| CAST JOB | 2 | 2 | 1 | 0.08 | +2 | +2.4 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.08 | +25 | +25.3 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.08 | +5 | +5.2 |
| FOCUS FIRE | 1 | 1 | 1 | 0.08 | +42 | +41.8 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.08 | -4 | -4.0 |
| HORN WORTH | 1 | 1 | 1 | 0.08 | +5 | +4.6 |
| MARCH ODDS | 1 | 1 | 1 | 0.08 | +54 | +54.0 |
| MISSILES NEXT TURN | 88 | 66 | 1 | 0.08 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.08 | +15 | +14.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +101 | +101.3 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.08 | +192 | +191.9 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.08 | +113 | +112.8 |
| REDIRECT BY WHAT IT STOPS | 9 | 9 | 1 | 0.08 | +65 | +64.8 |
| THROUGH LINE OF FIRE | 1 | 1 | 1 | 0.08 | +6 | +6.3 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 15 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 216 | not checked | - | - | - | - |
| GIVES UP | 28 | 26 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 8 | 8 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT IN PAIRS | 5 | 2 | 0 | 0.00 | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 8 | not checked | - | - | - | - |
| MAKE SURE TOGETHER | 7 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 11 | 11 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| NOT NEEDED | 15 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 242 | 242 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 28 | not checked | - | - | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 991 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 11 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 28 | not checked | - | - | - | - |
| STABLE ROLE | 291 | 288 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TURN WORTH | 9 | 9 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: fw-on-db7ca9c-p2c

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 11.50 | 11.92 | 53.3 |
| TURN GATE | gate | 0.83 | 0.50 | 31.1 |
| FALLBACK | gate | 0.33 | 0.42 | 79.4 |
| PIVOT GUARDS FLANK | rule | 0.50 | 0.25 | 20.2 |
| SUPPORT REQUEST | gate | 0.42 | 0.33 | 85.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.25 | 0.42 | 71.7 |
| BLOCKED WHEEL | rule | 0.33 | 0.17 | 22.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.17 | 85.2 |
| FIGHT ORDER BAND | gate | 0.25 | - | 2.3 |
| WAR ENGINE JOBS | rule | 0.17 | 0.08 | 42.1 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 3.0 |
| CARRIES OUT SET-UP | rule | - | 0.17 | 56.8 |
| CHAFF PASSED | rule | - | 0.17 | 1.7 |
| PURSUES BIG PREY | rule | 0.08 | 0.08 | 18.3 |
| BEST PRIZE | rule | - | 0.08 | 4.1 |
| BIG CHARACTER SAFETY | rule | - | 0.08 | 18.8 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 34.8 |
| FRIENDS SHOTS CHECKED | rule | - | 0.08 | 4.0 |
| LONE WIZARD HOLDS BACK | rule | 0.08 | - | 48.4 |
| NO REASON | gate | - | 0.08 | 2.3 |
| PATHS CROSS | rule | 0.08 | - | 0.8 |
| STOPS SHORT OF THE FLANK | rule | - | 0.08 | 18.8 |

### Plans: fw-on-db7ca9c-p2c

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 15.3 | 9% | 853 | 179 | 21% |
| Mine | charge | 3.2 | 55% | 243 | 214 | 88% |
| Mine | close in | 3.8 | 29% | 379 | 132 | 35% |
| Mine | hold | 4.0 | 19% | 269 | 0 | 0% |
| Mine | join | 1.0 | 92% | 44 | 0 | 0% |
| Mine | shoot | 1.9 | 65% | 91 | 122 | 134% |
| Mine | support | 11.9 | 91% | 490 | 0 | 0% |
| Opponent | advance | 12.6 | 9% | 585 | 209 | 36% |
| Opponent | charge | 4.6 | 55% | 594 | 441 | 74% |
| Opponent | close in | 6.6 | 29% | 1001 | 170 | 17% |
| Opponent | hold | 2.5 | 37% | 194 | 0 | 0% |
| Opponent | join | 1.8 | 95% | 88 | 0 | 0% |
| Opponent | shoot | 1.6 | 32% | 14 | 107 | 748% |
| Opponent | support | 11.8 | 93% | 326 | 0 | 0% |

### Packages: hunt the guns, fw-on-db7ca9c-p2c

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 3 | 0 | 0% | 0% | 0% | - | 207 | 0 | 0% | 0 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 2.0 | 2 | 0 | 0% | 0% | 0% | - | 194 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: fw-on-db7ca9c-p2c

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 14.1 | 21% | 54% | 20% | 14% | 46% | 0% | 29% | 25% | 0% |
| Mine | REDIRECT COUNTER | 3.8 | 35% | 56% | 6% | 0% | 27% | 0% | 7% | 60% | 7% |
| Opponent | COUNTER-CHARGE COVER | 9.6 | 19% | 64% | 23% | 40% | 29% | 24% | 0% | 47% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 26% | 64% | 0% | - | 9% | 0% | 9% | 82% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-on-db7ca9c-p2c

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 51 (5) | 51 | 0 | 52 | 20% | 3.8 | 320 (1) | 0 (1) | - | 320 (1) | 0 (1) |
| Mine | Chaff | 24 | 71 (24) | 24 | 47 | 65 | 21% | 3.2 | 68 (14) | 139 (4) | 34 (6) | 91 (17) | 29 (7) |
| Mine | Character | 34 | 44 (34) | 44 | 0 | 46 | 9% | 2.8 | 48 (23) | 38 (9) | - | 70 (15) | 26 (17) |
| Mine | Clean-up | 7 | 27 (7) | 10 | 17 | 47 | 14% | 2.8 | 30 (3) | 8 (3) | 94 (1) | 80 (3) | 0 (4) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 13 | 44 (13) | 30 | 13 | 58 | 8% | 2.2 | 43 (9) | 46 (4) | - | 47 (6) | 40 (7) |
| Mine | Fragile | 5 | 143 (5) | 143 | 0 | 60 | 0% | 2.4 | - | 238 (3) | 0 (2) | 143 (5) | - |
| Mine | Hammer | 17 | 55 (17) | 40 | 15 | 35 | 18% | 2.1 | 43 (8) | 45 (8) | 285 (1) | 76 (11) | 19 (6) |
| Mine | Holder | 13 | 18 (13) | 0 | 18 | 34 | 38% | 3.9 | 41 (7) | 0 (3) | 0 (3) | 22 (10) | 8 (3) |
| Mine | Shooter | 11 | 134 (11) | 76 | 58 | 31 | 0% | 2.4 | 106 (4) | 169 (6) | 0 (1) | 120 (6) | 153 (5) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 66 | 0% | 4.5 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 10 | 2 (10) | 2 | 0 | 55 | 0% | 1.8 | 2 (6) | 4 (1) | 0 (1) | 4 (5) | 0 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 18 | 37 (18) | 24 | 13 | 32 | 33% | 3.4 | 49 (8) | 134 (2) | 0 (8) | 66 (7) | 22 (11) |
| Opponent | Character | 35 | 83 (35) | 83 | 0 | 29 | 29% | 2.9 | 99 (22) | 61 (8) | - | 84 (21) | 107 (9) |
| Opponent | Clean-up | 2 | 56 (2) | 18 | 38 | 0 | 0% | 2.0 | 56 (2) | - | - | 83 (1) | 33 (1) |
| Opponent | Fast Hammer | 23 | 24 (23) | 14 | 10 | 47 | 13% | 3.2 | 36 (14) | 0 (5) | 14 (4) | 30 (12) | 17 (11) |
| Opponent | Hammer | 28 | 26 (28) | 25 | 1 | 48 | 21% | 3.0 | 42 (13) | 15 (13) | 33 (2) | 46 (16) | 6 (12) |
| Opponent | Holder | 12 | 55 (12) | 21 | 33 | 20 | 33% | 4.8 | 53 (5) | 67 (6) | 0 (1) | 66 (9) | 18 (3) |
| Opponent | Shooter | 11 | 31 (11) | 16 | 16 | 37 | 0% | 1.5 | 27 (3) | 36 (7) | 0 (1) | 23 (5) | 36 (6) |
| Opponent | Support | 2 | 71 (2) | 71 | 0 | 0 | 50% | 5.0 | - | 71 (2) | - | - | 71 (2) |
| Opponent | Wizard | 9 | 4 (9) | 4 | 0 | 43 | 22% | 2.0 | 0 (4) | - | 7 (4) | 0 (3) | 8 (5) |

### Charged fights: fw-on-db7ca9c-p2c

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 251 | 1.0 | 2.0 | 251 | 395 | -144 | 1 of 1 | 0 of 1 | -144 | - |
| Mine | Kingdom of Bretonnia | 1 | 0 | 578 | 4.0 | 1.2 | 144 | 0 | +144 | 1 of 4 | 3 of 4 | +578 | +0 |
| Mine | Lizardmen | 1 | 186 | 853 | 4.0 | 1.2 | 213 | 0 | +213 | 2 of 4 | 3 of 4 | +0 | +284 |
| Mine | Ogre Kingdoms | 1 | 0 | 311 | 5.0 | 1.0 | 62 | 44 | +18 | 1 of 5 | 4 of 4 | - | +18 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 442 | 6.0 | 1.2 | 74 | 129 | -55 | 1 of 6 | 5 of 6 | +45 | -75 |
| Mine | Skaven | 2 | 232 | 0 | 1.0 | 1.5 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | +0 | +0 |
| Mine | Tomb Kings of Khemri | 1 | 110 | 352 | 3.0 | 1.0 | 117 | 0 | +117 | 0 of 3 | 3 of 3 | - | +117 |
| Mine | Vampire Counts | 3 | 0 | 366 | 3.7 | 1.1 | 100 | 83 | +17 | 4 of 11 | 8 of 11 | +102 | +9 |
| Mine | Warriors of Chaos | 1 | 0 | 608 | 1.0 | 1.0 | 608 | 0 | +608 | 0 of 1 | 1 of 1 | - | +608 |
| **Mine** | all armies | 12 | 63 | 374 | 3.1 | 1.2 | 121 | 62 | +59 | 10 of 37 | 28 of 36 | +97 | +52 |
| Opponent | Vampire Counts | 3 | 18 | 409 | 3.3 | 1.1 | 123 | 4 | +118 | 6 of 10 | 5 of 10 | +575 | +67 |
| Opponent | Warriors of Chaos | 5 | 13 | 467 | 2.8 | 1.1 | 167 | 0 | +167 | 8 of 14 | 14 of 14 | +610 | +93 |
| Opponent | Wood Elf Realms | 4 | 180 | 464 | 5.0 | 1.1 | 93 | 12 | +81 | 4 of 20 | 10 of 20 | +70 | +83 |
| **Opponent** | all armies | 12 | 70 | 451 | 3.7 | 1.1 | 123 | 6 | +117 | 18 of 44 | 29 of 44 | +334 | +82 |

### Effective charges: fw-on-db7ca9c-p2c

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 0 | 1 (net -144) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +578) | 2 (net +0) | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 1 (net +853) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 1 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 5 | 0 | 1 (net -34) | 0 | 1 (net +0) | 1 (net +0) | 2 (net +63) | 0 | 0% (0 of 5) |
| Mine | Orc & Goblin Tribes | 6 | 1 (net +233) | 0 | 1 (net +45) | 0 | 0 | 0 | 4 | 50% (1 of 2) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 3 | 0 | 0 | 1 (net +102) | 0 | 0 | 1 (net +125) | 1 | 50% (1 of 2) |
| Mine | Vampire Counts | 11 | 4 (net -104) | 0 | 1 (net -385) | 1 (net +102) | 1 (net +432) | 4 (net +114) | 0 | 9% (1 of 11) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +608) | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 10 | 2 (net +45) | 0 | 0 | 2 (net +0) | 0 | 6 (net +182) | 0 | 0% (0 of 10) |
| Opponent | Warriors of Chaos | 14 | 1 (net +0) | 0 | 4 (net +52) | 1 (net +0) | 1 (net +100) | 6 (net +318) | 1 | 31% (4 of 13) |
| Opponent | Wood Elf Realms | 20 | 5 (net -1) | 1 (net +0) | 0 | 6 (net +101) | 3 (net +108) | 3 (net +47) | 2 | 0% (0 of 18) |

### Charged fights, damage counted: fw-on-db7ca9c-p2c

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 214 | 336 | +178 | 272 | 90 | +182 | +85.1 |
| Mine | 50-54% | 3 | 195 | 200 | -11 | 0 | 11 | -11 | -5.8 |
| Mine | Effective (55-75%) | 5 | 342 | 148 | -76 | 91 | 166 | -76 | -22.2 |
| Mine | 76-89% | 2 | 306 | 74 | +51 | 58 | 0 | +58 | +19.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 214 | 121 | +110 | 145 | 38 | +107 | +50.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 332 | 106 | +216 | 225 | 0 | +225 | +67.7 |
| Mine | No odds | 6 | 321 | 139 | -81 | 58 | 150 | -92 | -28.6 |
| Mine | All fights | 37 | 258 | 171 | +59 | 135 | 77 | +58 | +22.6 |
| Opponent | Long shot (under 50%) | 8 | 253 | 395 | +11 | 59 | 46 | +13 | +5.2 |
| Opponent | 50-54% | 1 | 110 | 72 | +0 | 0 | 55 | -55 | -50.0 |
| Opponent | Effective (55-75%) | 4 | 174 | 198 | +52 | 104 | 56 | +48 | +27.6 |
| Opponent | 76-89% | 9 | 128 | 209 | +67 | 118 | 23 | +95 | +74.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 294 | 210 | +209 | 231 | 40 | +191 | +65.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 462 | 74 | +106 | 114 | 0 | +114 | +24.6 |
| Opponent | No odds | 3 | 73 | 166 | +222 | 222 | 54 | +168 | +229.1 |
| Opponent | All fights | 44 | 238 | 224 | +117 | 149 | 37 | +112 | +47.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-on-db7ca9c-p2c | move | 193 | 39 (20%) | 26 (13%) | 19 (10%) | 135 (70%) |
| fw-on-db7ca9c-p2c | objective | 124 | 21 (17%) | 13 (10%) | 18 (15%) | 85 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429, L2535, L2735 |
| Charmed Shield | Opponent | L1727, L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L1727, L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531, L2131, L3033 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

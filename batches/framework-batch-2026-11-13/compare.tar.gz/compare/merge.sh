#!/bin/bash
# Merge the four parts of one arm into one batch folder compare-batches.py can read. A part may be copied flat into <arm>-N/ or as <arm>-N/<batch>/.
D=/mnt/project-files/framework-batch-2026-11-13; OUT=${OUT:-$HOME/fw-merged}
for arm in on off; do
  M=$OUT/fw-$arm-db7ca9c-all; rm -rf $M; mkdir -p $M
  first=1; dbs=()
  parts="1 2 3 4"; [ $arm = on ] && parts="1 2 2b 2c 3 4"
  for n in $parts; do
    P=$D/$arm-$n/fw-$arm-db7ca9c-p$n; [ -f $P/games.csv ] || P=$D/$arm-$n
    [ -d $D/$arm-$n ] || continue
    [ -f $P/games.csv ] || { echo "$arm-$n missing"; continue; }
    for f in games.csv plays.csv; do [ -f $P/$f ] || continue
      if [ $first = 1 ]; then cat $P/$f >> $M/$f; else tail -n +2 $P/$f >> $M/$f; fi; done
    first=0
    ln -s $P/game-* $M/
    mkdir -p $M/parts; [ -d $P/parts ] && ln -s $P/parts/* $M/parts/
    [ -f $P/units.jsonl ] && cat $P/units.jsonl >> $M/units.jsonl
    for f in commit.txt look-for.md rules-off.txt; do [ -f $P/$f ] && cp $P/$f $M/; done
    dbs+=($P/records.db)
  done
  python3 $D/compare/merge-records.py $M/records.db "${dbs[@]}"
  echo "$arm: $(($(wc -l < $M/games.csv)-1)) games"
done

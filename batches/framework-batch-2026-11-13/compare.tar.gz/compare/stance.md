### on

| Stance | Sides | Turns defensive a game | VP a game | Margin a game | Kills by shooting + war machines | by magic | by charge + combat (incl. run down) | fled off the table | Shooting+magic share of kills (shoot+magic+combat) |
| --- | --: | --: | --: | --: | --: | --: | --: | --: | --: |
| Defensive | 113 | 4.86 | 1439 | +213 | 163 | 75 | 447 | 76 | 35% |
| Offensive | 175 | 0.25 | 1289 | -137 | 59 | 27 | 454 | 121 | 16% |
| All | 288 | 2.06 | 1348 | +0 | 100 | 46 | 451 | 104 | 24% |
### off (stance from the on arm's same game)

| Stance | Sides | Turns defensive a game | VP a game | Margin a game | Kills by shooting + war machines | by magic | by charge + combat (incl. run down) | fled off the table | Shooting+magic share of kills (shoot+magic+combat) |
| --- | --: | --: | --: | --: | --: | --: | --: | --: | --: |
| Defensive | 113 | 4.86 | 1483 | +63 | 193 | 79 | 443 | 110 | 38% |
| Offensive | 175 | 0.25 | 1426 | -41 | 63 | 39 | 534 | 164 | 16% |
| All | 288 | 2.06 | 1448 | +0 | 114 | 55 | 498 | 143 | 25% |

# on vs off

A = on: fw-on-db7ca9c-all, 144 of 144 games ended
B = off: fw-off-db7ca9c-all, 144 of 144 games ended

## Game by game (Victory Points Mine-Opponent; margin = Mine minus Opponent)

| Match-up | Scenario | Seed | A | B | Margin A | Margin B | A minus B | Cost A | Cost B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine 1789-265 | Mine 1372-470 | +1524 | +902 | +622 | 0.00 | 0.00 |
| L0106 | 4 | 1 | draw 954-1057 | Mine 1523-924 | -103 | +599 | -702 | 0.00 | 0.00 |
| L0110 | 2 | 1 | Opponent 300-2504 | Opponent 465-1782 | -2204 | -1317 | -887 | 0.00 | 0.00 |
| L0114 | 6 | 1 | Opponent 968-2249 | Opponent 1466-2087 | -1281 | -621 | -660 | 0.00 | 0.00 |
| L0118 | 4 | 1 | Opponent 969-1293 | Mine 1648-915 | -324 | +733 | -1057 | 0.00 | 0.00 |
| L0122 | 2 | 1 | Mine 1959-1215 | Opponent 1167-2344 | +744 | -1177 | +1921 | 0.00 | 0.00 |
| L0126 | 6 | 1 | Opponent 445-2007 | Opponent 955-2012 | -1562 | -1057 | -505 | 0.00 | 0.00 |
| L0130 | 4 | 1 | Opponent 798-1825 | Opponent 1361-1854 | -1027 | -493 | -534 | 0.00 | 0.00 |
| L0135 | 3 | 1 | Opponent 400-3910 | Mine 2198-365 | -3510 | +1833 | -5343 | 0.00 | 0.00 |
| L0206 | 2 | 1 | Opponent 510-1422 | Opponent 788-1322 | -912 | -534 | -378 | 0.00 | 0.00 |
| L0210 | 6 | 1 | draw 887-1060 | draw 890-927 | -173 | -37 | -136 | 0.00 | 0.00 |
| L0214 | 4 | 1 | Mine 2743-859 | Mine 1876-711 | +1884 | +1165 | +719 | 0.00 | 0.00 |
| L0218 | 2 | 1 | draw 1692-1878 | Opponent 1177-1842 | -186 | -665 | +479 | 0.00 | 0.00 |
| L0222 | 6 | 1 | Mine 2238-673 | Opponent 918-1522 | +1565 | -604 | +2169 | 0.00 | 0.00 |
| L0226 | 4 | 1 | Mine 1980-1420 | draw 1744-1613 | +560 | +131 | +429 | 0.00 | 0.00 |
| L0230 | 2 | 1 | draw 889-1042 | Opponent 806-2081 | -153 | -1275 | +1122 | 0.00 | 0.00 |
| L0235 | 1 | 1 | Opponent 1101-1599 | draw 1612-1621 | -498 | -9 | -489 | 0.00 | 0.00 |
| L0307 | 1 | 1 | Opponent 825-1641 | draw 1505-1686 | -816 | -181 | -635 | 0.00 | 0.00 |
| L0311 | 5 | 1 | draw 1317-1076 | draw 748-1045 | +241 | -297 | +538 | 0.00 | 0.00 |
| L0315 | 3 | 1 | Opponent 693-1471 | Opponent 1319-2418 | -778 | -1099 | +321 | 0.00 | 0.00 |
| L0319 | 1 | 1 | Opponent 350-2989 | Mine 3071-449 | -2639 | +2622 | -5261 | 0.00 | 0.00 |
| L0323 | 5 | 1 | Opponent 206-2503 | Opponent 833-2153 | -2297 | -1320 | -977 | 0.00 | 0.00 |
| L0327 | 3 | 1 | draw 970-1105 | Opponent 852-2278 | -135 | -1426 | +1291 | 0.00 | 0.00 |
| L0332 | 2 | 1 | Opponent 739-1489 | Opponent 430-2039 | -750 | -1609 | +859 | 0.00 | 0.00 |
| L0405 | 3 | 1 | Mine 2589-317 | Mine 3507-685 | +2272 | +2822 | -550 | 0.00 | 0.00 |
| L0409 | 1 | 1 | Mine 2327-1232 | Mine 2420-1800 | +1095 | +620 | +475 | 0.00 | 0.00 |
| L0413 | 5 | 1 | Mine 1900-0 | draw 1070-1300 | +1900 | -230 | +2130 | 0.00 | 0.00 |
| L0417 | 3 | 1 | Opponent 847-1676 | draw 1639-1553 | -829 | +86 | -915 | 0.00 | 0.00 |
| L0421 | 1 | 1 | Mine 1833-1207 | Mine 2049-820 | +626 | +1229 | -603 | 0.00 | 0.00 |
| L0425 | 5 | 1 | Mine 1772-150 | Mine 2909-150 | +1622 | +2759 | -1137 | 0.00 | 0.00 |
| L0429 | 3 | 1 | draw 1500-1215 | draw 1157-1371 | +285 | -214 | +499 | 0.00 | 0.00 |
| L0434 | 2 | 1 | Opponent 452-1399 | Mine 1047-536 | -947 | +511 | -1458 | 0.00 | 0.00 |
| L0508 | 4 | 1 | Mine 1554-717 | Opponent 1240-1734 | +837 | -494 | +1331 | 0.00 | 0.00 |
| L0512 | 2 | 1 | Opponent 919-3052 | Opponent 109-3600 | -2133 | -3491 | +1358 | 0.00 | 0.00 |
| L0516 | 6 | 1 | Opponent 507-1020 | Mine 1188-788 | -513 | +400 | -913 | 0.00 | 0.00 |
| L0520 | 4 | 1 | Opponent 1172-1602 | Mine 1628-1157 | -430 | +471 | -901 | 0.00 | 0.00 |
| L0524 | 2 | 1 | Opponent 160-1478 | Opponent 60-872 | -1318 | -812 | -506 | 0.00 | 0.00 |
| L0528 | 6 | 1 | Mine 1563-230 | draw 1384-1100 | +1333 | +284 | +1049 | 0.00 | 0.00 |
| L0533 | 5 | 1 | Mine 1467-510 | Opponent 615-1779 | +957 | -1164 | +2121 | 0.00 | 0.00 |
| L0608 | 2 | 1 | Opponent 569-1325 | Opponent 439-2453 | -756 | -2014 | +1258 | 0.00 | 0.00 |
| L0612 | 6 | 1 | Opponent 987-1555 | Opponent 300-2704 | -568 | -2404 | +1836 | 0.00 | 0.00 |
| L0616 | 4 | 1 | Mine 1793-690 | Mine 2261-998 | +1103 | +1263 | -160 | 0.00 | 0.00 |
| L0620 | 2 | 1 | Opponent 1060-1851 | Opponent 842-1473 | -791 | -631 | -160 | 0.00 | 0.00 |
| L0624 | 6 | 1 | draw 1288-1582 | Mine 1673-830 | -294 | +843 | -1137 | 0.00 | 0.00 |
| L0628 | 4 | 1 | Mine 1993-660 | Mine 1640-1334 | +1333 | +306 | +1027 | 0.00 | 0.00 |
| L0632 | 2 | 1 | draw 1483-1714 | Opponent 1394-2354 | -231 | -960 | +729 | 0.00 | 0.00 |
| L0709 | 1 | 1 | Mine 1798-743 | Opponent 742-2391 | +1055 | -1649 | +2704 | 0.00 | 0.00 |
| L0713 | 5 | 1 | draw 1310-1191 | Mine 2111-856 | +119 | +1255 | -1136 | 0.00 | 0.00 |
| L0717 | 3 | 1 | draw 1205-1384 | Mine 1620-677 | -179 | +943 | -1122 | 0.00 | 0.00 |
| L0721 | 1 | 1 | draw 2093-2341 | Opponent 1420-2003 | -248 | -583 | +335 | 0.00 | 0.00 |
| L0725 | 5 | 1 | Opponent 528-1136 | draw 1145-929 | -608 | +216 | -824 | 0.00 | 0.00 |
| L0729 | 3 | 1 | draw 835-1124 | Mine 3022-833 | -289 | +2189 | -2478 | 0.00 | 0.00 |
| L0733 | 1 | 1 | draw 1361-1267 | draw 1473-1444 | +94 | +29 | +65 | 0.00 | 0.00 |
| L0810 | 6 | 1 | Opponent 332-2600 | Opponent 296-2244 | -2268 | -1948 | -320 | 0.00 | 0.00 |
| L0815 | 5 | 1 | Opponent 551-1743 | draw 874-940 | -1192 | -66 | -1126 | 0.00 | 0.00 |
| L0819 | 3 | 1 | Mine 2305-1306 | Mine 2258-1836 | +999 | +422 | +577 | 0.00 | 0.00 |
| L0823 | 1 | 1 | Opponent 1010-2913 | Opponent 565-3765 | -1903 | -3200 | +1297 | 0.00 | 0.00 |
| L0827 | 5 | 1 | Opponent 481-2185 | Opponent 295-1469 | -1704 | -1174 | -530 | 0.00 | 0.00 |
| L0831 | 3 | 1 | Opponent 1262-1703 | Mine 1525-1005 | -441 | +520 | -961 | 0.00 | 0.00 |
| L0835 | 1 | 1 | Mine 2048-1340 | Opponent 1090-2334 | +708 | -1244 | +1952 | 0.00 | 0.00 |
| L0913 | 1 | 1 | Mine 2012-1299 | Opponent 1523-3295 | +713 | -1772 | +2485 | 0.00 | 0.00 |
| L0918 | 6 | 1 | Mine 1646-1227 | Mine 2335-830 | +419 | +1505 | -1086 | 0.00 | 0.00 |
| L0922 | 4 | 1 | Opponent 799-2145 | Opponent 709-2518 | -1346 | -1809 | +463 | 0.00 | 0.00 |
| L0926 | 2 | 1 | Opponent 85-2393 | Opponent 355-2616 | -2308 | -2261 | -47 | 0.00 | 0.00 |
| L0930 | 6 | 1 | Opponent 932-1475 | draw 1208-1381 | -543 | -173 | -370 | 0.00 | 0.00 |
| L0934 | 4 | 1 | Opponent 1614-2192 | Opponent 1108-2752 | -578 | -1644 | +1066 | 0.00 | 0.00 |
| L1013 | 5 | 1 | Mine 1950-869 | Mine 1778-451 | +1081 | +1327 | -246 | 0.00 | 0.00 |
| L1017 | 3 | 1 | Opponent 1512-2430 | Mine 1704-1355 | -918 | +349 | -1267 | 0.00 | 0.00 |
| L1021 | 1 | 1 | Mine 2952-748 | Mine 3402-669 | +2204 | +2733 | -529 | 0.00 | 0.00 |
| L1026 | 6 | 1 | draw 1054-982 | draw 914-1090 | +72 | -176 | +248 | 0.00 | 0.00 |
| L1030 | 4 | 1 | Mine 2403-786 | Mine 2494-930 | +1617 | +1564 | +53 | 0.00 | 0.00 |
| L1034 | 2 | 1 | Opponent 792-1315 | Mine 1962-1157 | -523 | +805 | -1328 | 0.00 | 0.00 |
| L1114 | 4 | 1 | Mine 2621-629 | Mine 1827-1477 | +1992 | +350 | +1642 | 0.00 | 0.00 |
| L1118 | 2 | 1 | Mine 1927-1161 | Mine 2917-679 | +766 | +2238 | -1472 | 0.00 | 0.00 |
| L1122 | 6 | 1 | Mine 1846-775 | Opponent 1348-1747 | +1071 | -399 | +1470 | 0.00 | 0.00 |
| L1126 | 4 | 1 | Opponent 1184-1513 | Opponent 1214-2172 | -329 | -958 | +629 | 0.00 | 0.00 |
| L1131 | 3 | 1 | Mine 1906-916 | Mine 2888-383 | +990 | +2505 | -1515 | 0.00 | 0.00 |
| L1135 | 1 | 1 | Opponent 1192-1713 | draw 1622-1361 | -521 | +261 | -782 | 0.00 | 0.00 |
| L1216 | 4 | 1 | Mine 1940-589 | Mine 1906-834 | +1351 | +1072 | +279 | 0.00 | 0.00 |
| L1220 | 2 | 1 | draw 1163-938 | Mine 3051-300 | +225 | +2751 | -2526 | 0.00 | 0.00 |
| L1224 | 6 | 1 | Mine 2068-1103 | Opponent 562-2308 | +965 | -1746 | +2711 | 0.00 | 0.00 |
| L1228 | 4 | 1 | Mine 1176-635 | Opponent 1181-1513 | +541 | -332 | +873 | 0.00 | 0.00 |
| L1232 | 2 | 1 | Mine 1303-644 | draw 1671-1489 | +659 | +182 | +477 | 0.00 | 0.00 |
| L1314 | 6 | 1 | Mine 1364-820 | Opponent 937-1351 | +544 | -414 | +958 | 0.00 | 0.00 |
| L1319 | 5 | 1 | Opponent 688-1690 | Opponent 1121-1583 | -1002 | -462 | -540 | 0.00 | 0.00 |
| L1323 | 3 | 1 | draw 1534-1517 | Opponent 1147-1876 | +17 | -729 | +746 | 0.00 | 0.00 |
| L1327 | 1 | 1 | Opponent 548-2520 | Opponent 826-1994 | -1972 | -1168 | -804 | 0.00 | 0.00 |
| L1331 | 5 | 1 | Opponent 912-1230 | draw 826-895 | -318 | -69 | -249 | 0.00 | 0.00 |
| L1335 | 3 | 1 | Mine 2718-972 | Mine 1948-1281 | +1746 | +667 | +1079 | 0.00 | 0.00 |
| L1418 | 2 | 1 | Mine 2725-697 | Mine 1581-774 | +2028 | +807 | +1221 | 0.00 | 0.00 |
| L1422 | 6 | 1 | draw 1016-1085 | Mine 1783-1077 | -69 | +706 | -775 | 0.00 | 0.00 |
| L1427 | 5 | 1 | Mine 2475-313 | Mine 1984-1494 | +2162 | +490 | +1672 | 0.00 | 0.00 |
| L1431 | 3 | 1 | Mine 1629-1088 | Mine 2035-1638 | +541 | +397 | +144 | 0.00 | 0.00 |
| L1435 | 1 | 1 | Mine 1622-647 | draw 1173-1116 | +975 | +57 | +918 | 0.00 | 0.00 |
| L1519 | 1 | 1 | Mine 1947-650 | Mine 2475-286 | +1297 | +2189 | -892 | 0.00 | 0.00 |
| L1523 | 5 | 1 | draw 939-1142 | Opponent 1349-1704 | -203 | -355 | +152 | 0.00 | 0.00 |
| L1527 | 3 | 1 | draw 1101-872 | Opponent 1307-1738 | +229 | -431 | +660 | 0.00 | 0.00 |
| L1531 | 1 | 1 | Opponent 1267-1706 | Mine 1778-652 | -439 | +1126 | -1565 | 0.00 | 0.00 |
| L1535 | 5 | 1 | Opponent 835-1337 | Mine 2516-175 | -502 | +2341 | -2843 | 0.00 | 0.00 |
| L1621 | 1 | 1 | draw 1361-1338 | Mine 3524-517 | +23 | +3007 | -2984 | 0.00 | 0.00 |
| L1625 | 5 | 1 | Mine 1403-921 | draw 855-1082 | +482 | -227 | +709 | 0.00 | 0.00 |
| L1629 | 3 | 1 | draw 1516-1364 | Opponent 732-1875 | +152 | -1143 | +1295 | 0.00 | 0.00 |
| L1633 | 1 | 1 | draw 1332-1259 | draw 1277-1555 | +73 | -278 | +351 | 0.00 | 0.00 |
| L1719 | 3 | 1 | Mine 1402-444 | Mine 3642-320 | +958 | +3322 | -2364 | 0.00 | 0.00 |
| L1723 | 1 | 1 | Mine 2759-889 | Mine 1903-1539 | +1870 | +364 | +1506 | 0.00 | 0.00 |
| L1727 | 5 | 1 | Mine 1214-795 | draw 1228-1049 | +419 | +179 | +240 | 0.00 | 0.00 |
| L1731 | 3 | 1 | Mine 2296-1106 | Mine 2493-403 | +1190 | +2090 | -900 | 0.00 | 0.00 |
| L1819 | 1 | 1 | Mine 1908-689 | Opponent 568-1281 | +1219 | -713 | +1932 | 0.00 | 0.00 |
| L1823 | 5 | 1 | Opponent 1096-1680 | Opponent 701-1832 | -584 | -1131 | +547 | 0.00 | 0.00 |
| L1827 | 3 | 1 | Opponent 881-2050 | Opponent 988-2134 | -1169 | -1146 | -23 | 0.00 | 0.00 |
| L1831 | 1 | 1 | Mine 2289-1406 | Mine 2012-985 | +883 | +1027 | -144 | 0.00 | 0.00 |
| L1835 | 5 | 1 | Opponent 776-1131 | draw 1155-1078 | -355 | +77 | -432 | 0.00 | 0.00 |
| L1923 | 3 | 1 | Opponent 759-3143 | Opponent 1692-2425 | -2384 | -733 | -1651 | 0.00 | 0.00 |
| L1927 | 1 | 1 | Opponent 782-1904 | draw 1920-1878 | -1122 | +42 | -1164 | 0.00 | 0.00 |
| L1932 | 6 | 1 | Opponent 832-2155 | Opponent 615-1661 | -1323 | -1046 | -277 | 0.00 | 0.00 |
| L2021 | 5 | 1 | draw 1358-1258 | Mine 1524-548 | +100 | +976 | -876 | 0.00 | 0.00 |
| L2025 | 3 | 1 | draw 1932-1735 | Opponent 1180-2289 | +197 | -1109 | +1306 | 0.00 | 0.00 |
| L2029 | 1 | 1 | Opponent 555-3106 | Opponent 690-1865 | -2551 | -1175 | -1376 | 0.00 | 0.00 |
| L2033 | 5 | 1 | Opponent 778-1168 | Opponent 492-1058 | -390 | -566 | +176 | 0.00 | 0.00 |
| L2123 | 5 | 1 | Opponent 295-2987 | Opponent 579-2601 | -2692 | -2022 | -670 | 0.00 | 0.00 |
| L2127 | 3 | 1 | draw 2103-2087 | Opponent 776-3364 | +16 | -2588 | +2604 | 0.00 | 0.00 |
| L2131 | 1 | 1 | Mine 2017-847 | Mine 2259-750 | +1170 | +1509 | -339 | 0.00 | 0.00 |
| L2223 | 3 | 1 | Opponent 288-3264 | draw 1483-1533 | -2976 | -50 | -2926 | 0.00 | 0.00 |
| L2227 | 1 | 1 | Mine 2733-502 | Mine 2139-1614 | +2231 | +525 | +1706 | 0.00 | 0.00 |
| L2231 | 5 | 1 | Mine 2429-948 | Mine 2121-633 | +1481 | +1488 | -7 | 0.00 | 0.00 |
| L2235 | 3 | 1 | Mine 3146-552 | Mine 2598-955 | +2594 | +1643 | +951 | 0.00 | 0.00 |
| L2327 | 5 | 1 | Mine 1939-1035 | draw 1623-1872 | +904 | -249 | +1153 | 0.00 | 0.00 |
| L2331 | 3 | 1 | Mine 902-490 | Mine 1995-1128 | +412 | +867 | -455 | 0.00 | 0.00 |
| L2335 | 1 | 1 | draw 1136-1227 | Mine 3263-592 | -91 | +2671 | -2762 | 0.00 | 0.00 |
| L2429 | 5 | 1 | draw 946-955 | Opponent 1511-2115 | -9 | -604 | +595 | 0.00 | 0.00 |
| L2433 | 3 | 1 | draw 913-750 | Mine 1941-520 | +163 | +1421 | -1258 | 0.00 | 0.00 |
| L2527 | 1 | 1 | Opponent 395-852 | Mine 1296-505 | -457 | +791 | -1248 | 0.00 | 0.00 |
| L2531 | 5 | 1 | draw 832-549 | Opponent 520-1209 | +283 | -689 | +972 | 0.00 | 0.00 |
| L2535 | 3 | 1 | Mine 1534-1112 | Opponent 539-1542 | +422 | -1003 | +1425 | 0.00 | 0.00 |
| L2630 | 2 | 1 | draw 1313-1481 | Mine 1738-1374 | -168 | +364 | -532 | 0.00 | 0.00 |
| L2634 | 6 | 1 | Opponent 739-1479 | Mine 1782-1401 | -740 | +381 | -1121 | 0.00 | 0.00 |
| L2730 | 6 | 1 | Opponent 880-1362 | draw 1455-1188 | -482 | +267 | -749 | 0.00 | 0.00 |
| L2735 | 5 | 1 | Opponent 427-1844 | Opponent 1047-1696 | -1417 | -649 | -768 | 0.00 | 0.00 |
| L2832 | 6 | 1 | Opponent 934-2679 | Opponent 1119-2333 | -1745 | -1214 | -531 | 0.00 | 0.00 |
| L2930 | 2 | 1 | Opponent 1285-1734 | Mine 2041-535 | -449 | +1506 | -1955 | 0.00 | 0.00 |
| L2934 | 6 | 1 | draw 1099-1072 | Mine 1860-60 | +27 | +1800 | -1773 | 0.00 | 0.00 |
| L3033 | 3 | 1 | draw 1517-1620 | Mine 1518-806 | -103 | +712 | -815 | 0.00 | 0.00 |
| L3133 | 1 | 1 | Mine 1343-1008 | draw 1457-1357 | +335 | +100 | +235 | 0.00 | 0.00 |
| L3234 | 6 | 1 | draw 1128-1238 | Mine 2016-492 | -110 | +1524 | -1634 | 0.00 | 0.00 |

## Totals

| | A: on | B: off |
| --- | --- | --- |
| Mine won / drew / lost | 53 / 34 / 57 | 60 / 27 / 57 |
| Mean margin (Mine - Opponent) | -36 | +76 |
| Cost per game | $0.000 | $0.000 |
| Mine side per game | $0.000 | $0.000 |
| Opponent side per game | $0.000 | $0.000 |
| Cost of the batch | $0.00 | $0.00 |
| Failed calls per game | 0.0 | 0.0 |
| VP from objectives, Mine | 561 | 586 |
| VP from objectives, Opponent | 570 | 533 |
| VP from kills, Mine | 720 | 846 |
| VP from kills, Opponent | 727 | 798 |
| VP from leaders, Mine | 49 | 55 |
| VP from leaders, Opponent | 66 | 77 |
| VP from other, Mine | 1 | 1 |
| VP from other, Opponent | 4 | 2 |
| Units lost, Mine | 4.6 | 5.2 |
| Units lost, Opponent | 4.5 | 5.3 |
| Scorecard: Far marker / quarter contested by round 3 (both sides) | 30% | 29% |
| Scorecard: Lone holders (player turns) (both sides) | 2.4 | 2.6 |
| Scorecard: Round of the first Hammer charge (both sides) | 2.8 | 2.5 |
| Scorecard: Lone charges into a block / monster / character (both sides) | 2.5 | 2.8 |
| Scorecard: Idle units (both sides) | 1.4 | 1.5 |
| Scorecard: Wounded Lords / monsters lost (both sides) | 0.3 | 0.3 |
| Scorecard: Doctrine flags raised (both sides) | 0.0 | 0.0 |
| Scorecard: Answers changed after a flag (both sides) | 0.0 | 0.0 |
| Scorecard: Points that never moved of their own (both sides) | 219.3 | 238.6 |

## Is the difference more than noise?

144 pairs of games: A's margin is -113 VP a game against B's, give or take 228 VP (two standard errors). Verdict: within noise (could be chance).

## KPIs (Morten 2026-11-10)

A = on (144 games), B = off (144 games).

| KPI | Target | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 59% | 23% | 41% | 0% | 0% | 0% |
| Winner chose to follow up after the loser gave ground |  | 95%; on the table 96% | 98%; on the table 99% | 97%; on the table 97% | 97%; on the table 97% | 95%; on the table 95% | 96%; on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 76%; on the table 78% | 86%; on the table 91% | 82%; on the table 86% | 94%; on the table 94% | 90%; on the table 93% | 92%; on the table 94% |
| Winner chose to pursue after the loser fled |  | 70%; on the table 78% | 77%; on the table 82% | 74%; on the table 80% | 79%; on the table 85% | 76%; on the table 83% | 78%; on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 88%; on the table 90% | 88%; on the table 91% | 88%; on the table 91% | 92%; on the table 94% | 89%; on the table 91% | 91%; on the table 93% |
| Magic missiles tried each own turn | 50%+ | 33% | 34% | 33% | 28% | 34% | 30% |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% | 43% | 46% | 41% | 46% | 43% |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 54% | 61% | 58% | - | - | - |
| Points that never fought | lower | 36% | 38% | 37% | 35% | 34% | 34% |
|   infantry points that never fought | lower | 40% | 56% | 47% | 43% | 53% | 48% |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% | 60% | 59% | 55% | 60% | 57% |
| Bound items with a magic missile used (at least once a game) |  | 96% | 83% | 90% | 91% | 79% | 86% |
| Bound items with another spell used |  | 41% | 44% | 42% | 61% | 44% | 55% |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% | 50% | 53% | 63% | 48% | 57% |
|   their share of the points of units over 100 pts | lower | 53% | 54% | 53% | 50% | 52% | 51% |

Flank and rear charges a unit could have turned to face (the side is the charged unit's):

| Measure | on Mine | on Opponent | off Mine | off Opponent |
| --- | --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (161) | 48% (128) | 49% (164) | 47% (145) |
| ...free all their last turn and able to turn (per game) | 0.70 | 0.56 | 0.69 | 0.58 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.24 | 0.15 | 0.15 | 0.20 |
| ...with the charger already in that arc before they moved (per game) | 0.49 | 0.40 | 0.50 | 0.38 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.05 | 1.60 | 1.35 | 0.74 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.15 | 0.75 | 0.88 | 0.70 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.39 | 7.28 | 6.35 | 6.31 |

### Charges a game and per unit by the wizard it carries

| Charges | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Charges declared a game | 3.9 | 5.7 | 4.8 | 4.7 | 5.8 | 5.2 |
| Charges that made contact a game | 2.9 | 4.0 | 3.5 | 3.4 | 4.1 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.85 declared, 0.70 contact (84 units) | 0.58 declared, 0.44 contact (59 units) | 0.73 declared, 0.59 contact (143 units) | 1.06 declared, 0.87 contact (87 units) | 1.05 declared, 0.68 contact (62 units) | 1.05 declared, 0.79 contact (149 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.88 declared, 0.77 contact (26 units) | 1.21 declared, 0.79 contact (42 units) | 1.09 declared, 0.78 contact (68 units) | 0.92 declared, 0.62 contact (26 units) | 1.16 declared, 0.98 contact (44 units) | 1.07 declared, 0.84 contact (70 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.36 contact (959 units) | 0.65 declared, 0.45 contact (1135 units) | 0.57 declared, 0.41 contact (2094 units) | 0.57 declared, 0.41 contact (972 units) | 0.63 declared, 0.44 contact (1137 units) | 0.60 declared, 0.43 contact (2109 units) |

## Movement (Morten 2026-11-11)

A = on (144 games), B = off (144 games); per side and game.

| Measure | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Games where this side made the first charge contact | 43% (62 of 144) | 57% (82 of 144) | 50% (144 of 288) | 45% (64 of 143) | 55% (79 of 143) | 50% (143 of 286) |
| Round of a side's first charge contact (sides that made one) | 2.9 | 2.6 | 2.8 | 2.7 | 2.6 | 2.6 |
| Sides that never declared a charge | 10% (14 of 144) | 2% (3 of 144) | 6% (17 of 288) | 8% (12 of 144) | 1% (2 of 144) | 5% (14 of 288) |
| Sides that never made charge contact | 14% (20 of 144) | 6% (9 of 144) | 10% (29 of 288) | 11% (16 of 144) | 6% (8 of 144) | 8% (24 of 288) |
| Charges declared a game | 4.0 | 5.6 | 4.8 | 4.7 | 5.7 | 5.2 |
| Charge contacts made a game | 3.0 | 3.9 | 3.5 | 3.4 | 4.0 | 3.7 |
| Charge contacts received a game | 3.9 | 3.0 | 3.5 | 4.0 | 3.4 | 3.7 |
| Joint charges a game (2+ units on one target in one turn) | 0.4 | 0.5 | 0.4 | 0.3 | 0.5 | 0.4 |
|   share of charged targets hit by 2+ units | 14% (53 of 370) | 15% (71 of 480) | 15% (124 of 850) | 9% (40 of 456) | 15% (74 of 496) | 12% (114 of 952) |
| Lone charges that a friend follows on the same target next turn | 6% (19 of 317) | 4% (18 of 409) | 5% (37 of 726) | 5% (22 of 416) | 8% (32 of 422) | 6% (54 of 838) |
| Set-ups (close in to charge next turn) that charged that target next turn | 13% (87 of 675) | 16% (161 of 985) | 15% (248 of 1660) | 14% (88 of 619) | 15% (120 of 790) | 15% (208 of 1409) |
|   ... and made contact | 11% (71 of 675) | 12% (116 of 985) | 11% (187 of 1660) | 11% (69 of 619) | 10% (82 of 790) | 11% (151 of 1409) |
|   ... with a friend on it too | 3% (22 of 675) | 3% (27 of 985) | 3% (49 of 1660) | 1% (5 of 619) | 3% (25 of 790) | 2% (30 of 1409) |
| Set-ups missed (no charge on that target next turn) | 87% (588 of 675) | 84% (824 of 985) | 85% (1412 of 1660) | 86% (531 of 619) | 85% (670 of 790) | 85% (1201 of 1409) |
| Charge contacts in the flank or rear (arc known) | 53% (229 of 430) | 50% (284 of 567) | 51% (513 of 997) | 47% (235 of 496) | 49% (285 of 579) | 48% (520 of 1075) |
|   in the rear | 11% (49 of 430) | 10% (59 of 567) | 11% (108 of 997) | 9% (44 of 496) | 11% (64 of 579) | 10% (108 of 1075) |
| Declared charges in the flank or rear (arc known) | 51% (294 of 574) | 48% (385 of 809) | 49% (679 of 1383) | 49% (335 of 682) | 49% (402 of 825) | 49% (737 of 1507) |
| Marches that gave up a magic missile a game (made: a failed march test or a MARCH CHECK turn left out) | 0.8 | 0.5 | 0.6 | 0.5 | 0.2 | 0.4 |

## Claimed against happened, per job (Morten 2026-11-13)

### Claimed against happened, per job: on

144 games. Claimed = the VP the pick's line said (the charge figure counts two turns: read it against the two-turn net). Happened = what came after the pick (job figures report option 12, Morten 2026-11-13).

| Job | Side | Picks a game | Claimed (mean VP) | Happened |
| --- | --- | --- | --- | --- |
| Charge | Mine | 3.4 | 112.1 | net 50 VP in 2 turns; declared 71% |
| Charge | Opponent | 5.0 | 121.5 | net 53 VP in 2 turns; declared 73% |
| Shoot | Mine | 9.1 | 25.9 | 2.9 VP of wounds that turn |
| Shoot | Opponent | 4.0 | 27.6 | 6.2 VP of wounds that turn |
| Hold a marker, the hill, a feature | Mine | 4.6 | 75.2 | 22.6 VP scored this turn and the enemy's next |
| Hold a marker, the hill, a feature | Opponent | 4.4 | 80.9 | 25.8 VP scored this turn and the enemy's next |
| Close in to charge next turn | Mine | 4.7 | 124.0 | charged that target next turn 10% |
| Close in to charge next turn | Opponent | 6.8 | 131.3 | charged that target next turn 14% |
| Advance on an enemy | Mine | 21.9 | 51.1 | charged that target next turn 3% |
| Advance on an enemy | Opponent | 24.2 | 43.8 | charged that target next turn 2% |
| Screen | Mine | 0.1 | 4.2 | guarded unit lost 0.00 wounds (line said 1.81 a turn) |
| Screen | Opponent | 0.2 | 1.3 | guarded unit lost 0.32 wounds (line said 2.25 a turn) |
| Redirect | Mine | 0.1 | -7.9 | enemy charged the guarded friend 0%, the chaff 40% |
| Redirect | Opponent | 0.4 | 35.6 | enemy charged the guarded friend 7%, the chaff 16% |
| Lure | Mine | 0.1 | -31.7 | enemy charged the guarded friend 11%, the chaff 0% |
| Lure | Opponent | 0.0 | -1.8 | enemy charged the guarded friend 0%, the chaff 0% |
| Join a unit | Mine | 0.7 | 41.6 | - |
| Join a unit | Opponent | 0.8 | 38.5 | - |

#### By unit type: on

Both sides together; picks a game, claimed mean VP and what happened.

| Unit type | Job | Picks a game | Claimed | Happened |
| --- | --- | --- | --- | --- |
| Regular Infantry | Charge | 1.22 | 62.6 | net 44 VP in 2 turns; declared 62% |
| Regular Infantry | Shoot | 2.95 | 27.0 | 9.5 VP of wounds that turn |
| Regular Infantry | Hold a marker, the hill, a feature | 5.38 | 69.7 | 23.9 VP scored this turn and the enemy's next |
| Regular Infantry | Close in to charge next turn | 0.26 | 44.6 | charged that target next turn 11% |
| Regular Infantry | Advance on an enemy | 14.26 | 39.0 | charged that target next turn 2% |
| Regular Infantry | Screen | 0.08 | 3.5 | guarded unit lost 0.00 wounds (line said 2.24 a turn) |
| Regular Infantry | Redirect | 0.15 | 19.7 | enemy charged the guarded friend 6%, the chaff 28% |
| Character | Charge | 1.94 | 215.5 | net 63 VP in 2 turns; declared 82% |
| Character | Shoot | 0.19 | 14.7 | 8.7 VP of wounds that turn |
| Character | Close in to charge next turn | 2.91 | 196.5 | charged that target next turn 18% |
| Character | Advance on an enemy | 5.33 | 75.0 | charged that target next turn 4% |
| Light Cavalry | Charge | 0.85 | 56.7 | net 23 VP in 2 turns; declared 43% |
| Light Cavalry | Shoot | 0.76 | 2.4 | 10.0 VP of wounds that turn |
| Light Cavalry | Hold a marker, the hill, a feature | 1.58 | 70.6 | 20.7 VP scored this turn and the enemy's next |
| Light Cavalry | Close in to charge next turn | 1.82 | 77.0 | charged that target next turn 8% |
| Light Cavalry | Advance on an enemy | 2.81 | 13.4 | charged that target next turn 2% |
| Light Cavalry | Redirect | 0.06 | -19.4 | enemy charged the guarded friend 0%, the chaff 20% |
| War Machines | Shoot | 7.31 | 28.3 | 0.4 VP of wounds that turn |
| Character (wizard) | Charge | 1.12 | 177.0 | net 94 VP in 2 turns; declared 70% |
| Character (wizard) | Shoot | 0.44 | -8.9 | 0.2 VP of wounds that turn |
| Character (wizard) | Hold a marker, the hill, a feature | 0.04 | 216.8 | 0.0 VP scored this turn and the enemy's next |
| Character (wizard) | Close in to charge next turn | 2.19 | 136.2 | charged that target next turn 11% |
| Character (wizard) | Advance on an enemy | 2.72 | 47.4 | charged that target next turn 5% |
| Heavy Cavalry | Charge | 0.40 | 111.2 | net 92 VP in 2 turns; declared 74% |
| Heavy Cavalry | Shoot | 0.10 | 8.8 | 0.0 VP of wounds that turn |
| Heavy Cavalry | Hold a marker, the hill, a feature | 0.65 | 89.2 | 17.9 VP scored this turn and the enemy's next |
| Heavy Cavalry | Close in to charge next turn | 1.42 | 149.2 | charged that target next turn 8% |
| Heavy Cavalry | Advance on an enemy | 2.90 | 81.1 | charged that target next turn 4% |
| Heavy Infantry | Charge | 0.30 | 90.1 | net 32 VP in 2 turns; declared 86% |
| Heavy Infantry | Shoot | 0.62 | 72.8 | 12.7 VP of wounds that turn |
| Heavy Infantry | Hold a marker, the hill, a feature | 0.88 | 119.0 | 45.5 VP scored this turn and the enemy's next |
| Heavy Infantry | Close in to charge next turn | 0.10 | 23.5 | charged that target next turn 13% |
| Heavy Infantry | Advance on an enemy | 3.42 | 48.0 | charged that target next turn 4% |
| Heavy Infantry | Redirect | 0.01 | 0.0 | enemy charged the guarded friend 0%, the chaff 50% |
| Heavy Chariots | Charge | 0.26 | 112.6 | net 12 VP in 2 turns; declared 92% |
| Heavy Chariots | Shoot | 0.49 | -1.4 | 5.0 VP of wounds that turn |
| Heavy Chariots | Hold a marker, the hill, a feature | 0.01 | -2.6 | 0.0 VP scored this turn and the enemy's next |
| Heavy Chariots | Close in to charge next turn | 0.23 | 122.3 | charged that target next turn 18% |
| Heavy Chariots | Advance on an enemy | 3.60 | 38.9 | charged that target next turn 3% |
| Monstrous Infantry | Charge | 0.83 | 64.0 | net 26 VP in 2 turns; declared 77% |
| Monstrous Infantry | Shoot | 0.07 | 1.2 | 0.0 VP of wounds that turn |
| Monstrous Infantry | Hold a marker, the hill, a feature | 0.05 | 191.0 | 0.0 VP scored this turn and the enemy's next |
| Monstrous Infantry | Close in to charge next turn | 0.40 | 60.5 | charged that target next turn 16% |
| Monstrous Infantry | Advance on an enemy | 2.59 | 45.5 | charged that target next turn 6% |
| Monstrous Infantry | Screen | 0.08 | -2.9 | guarded unit lost 0.45 wounds (line said 1.26 a turn) |
| Monstrous Infantry | Redirect | 0.12 | 46.8 | enemy charged the guarded friend 18%, the chaff 18% |
| War Beasts | Charge | 0.53 | 44.1 | net 42 VP in 2 turns; declared 70% |
| War Beasts | Shoot | 0.03 | 25.1 | 0.0 VP of wounds that turn |
| War Beasts | Hold a marker, the hill, a feature | 0.39 | 63.1 | 12.5 VP scored this turn and the enemy's next |
| War Beasts | Close in to charge next turn | 0.54 | 72.3 | charged that target next turn 18% |
| War Beasts | Advance on an enemy | 2.10 | 20.7 | charged that target next turn 2% |
| War Beasts | Screen | 0.17 | 3.9 | guarded unit lost 0.23 wounds (line said 2.51 a turn) |
| War Beasts | Redirect | 0.17 | 42.4 | enemy charged the guarded friend 0%, the chaff 17% |
| Behemoths | Charge | 0.26 | 95.2 | net 23 VP in 2 turns; declared 68% |
| Behemoths | Shoot | 0.03 | -54.1 | 0.0 VP of wounds that turn |
| Behemoths | Hold a marker, the hill, a feature | 0.03 | 336.7 | 0.0 VP scored this turn and the enemy's next |
| Behemoths | Close in to charge next turn | 0.49 | 103.0 | charged that target next turn 10% |
| Behemoths | Advance on an enemy | 3.03 | 89.3 | charged that target next turn 1% |
| Monstrous Creatures | Charge | 0.33 | 48.4 | net 30 VP in 2 turns; declared 77% |
| Monstrous Creatures | Shoot | 0.08 | 49.8 | 0.0 VP of wounds that turn |
| Monstrous Creatures | Close in to charge next turn | 0.45 | 54.3 | charged that target next turn 5% |
| Monstrous Creatures | Advance on an enemy | 1.65 | 26.3 | charged that target next turn 2% |
| Monstrous Cavalry | Charge | 0.28 | 87.5 | net 70 VP in 2 turns; declared 100% |
| Monstrous Cavalry | Shoot | 0.10 | 113.4 | 16.3 VP of wounds that turn |
| Monstrous Cavalry | Hold a marker, the hill, a feature | 0.02 | 166.0 | 0.0 VP scored this turn and the enemy's next |
| Monstrous Cavalry | Close in to charge next turn | 0.60 | 100.8 | charged that target next turn 14% |
| Monstrous Cavalry | Advance on an enemy | 1.15 | 61.3 | charged that target next turn 1% |
| Light Chariots | Charge | 0.03 | 48.2 | net 76 VP in 2 turns; declared 60% |
| Light Chariots | Shoot | 0.01 | 15.1 | 0.0 VP of wounds that turn |
| Light Chariots | Close in to charge next turn | 0.09 | 29.6 | charged that target next turn 8% |
| Light Chariots | Advance on an enemy | 0.38 | 14.8 | charged that target next turn 5% |
| Swarms | Charge | 0.07 | 64.8 | net 12 VP in 2 turns; declared 80% |
| Swarms | Close in to charge next turn | 0.02 | 71.6 | charged that target next turn 0% |
| Swarms | Advance on an enemy | 0.19 | 56.5 | charged that target next turn 7% |
| ? | Charge | 0.01 | 27.1 | net - VP in 2 turns; declared - |

### Claimed against happened, per job: off

144 games. Claimed = the VP the pick's line said (the charge figure counts two turns: read it against the two-turn net). Happened = what came after the pick (job figures report option 12, Morten 2026-11-13).

| Job | Side | Picks a game | Claimed (mean VP) | Happened |
| --- | --- | --- | --- | --- |
| Charge | Mine | 4.1 | 111.3 | net 53 VP in 2 turns; declared 75% |
| Charge | Opponent | 4.8 | 121.5 | net 45 VP in 2 turns; declared 75% |
| Shoot | Mine | 9.5 | 23.0 | 3.9 VP of wounds that turn |
| Shoot | Opponent | 4.3 | 14.6 | 7.3 VP of wounds that turn |
| Hold a marker, the hill, a feature | Mine | 4.9 | 76.9 | 28.9 VP scored this turn and the enemy's next |
| Hold a marker, the hill, a feature | Opponent | 4.6 | 82.9 | 27.2 VP scored this turn and the enemy's next |
| Close in to charge next turn | Mine | 4.3 | 60.3 | charged that target next turn 13% |
| Close in to charge next turn | Opponent | 5.5 | 68.6 | charged that target next turn 13% |
| Advance on an enemy | Mine | 14.3 | 30.0 | charged that target next turn 5% |
| Advance on an enemy | Opponent | 15.8 | 38.8 | charged that target next turn 5% |
| Screen | Mine | 2.2 | 64.9 | guarded unit lost 0.41 wounds (line said 4.33 a turn) |
| Screen | Opponent | 3.4 | 42.7 | guarded unit lost 0.44 wounds (line said 5.78 a turn) |
| Redirect | Mine | 1.9 | 11.7 | enemy charged the guarded friend 7%, the chaff 6% |
| Redirect | Opponent | 3.4 | 25.2 | enemy charged the guarded friend 4%, the chaff 4% |
| Lure | Mine | 0.8 | 113.9 | enemy charged the guarded friend 17%, the chaff 2% |
| Lure | Opponent | 0.6 | 98.2 | enemy charged the guarded friend 18%, the chaff 8% |
| Join a unit | Mine | 0.7 | 33.9 | - |
| Join a unit | Opponent | 0.8 | 52.3 | - |

#### By unit type: off

Both sides together; picks a game, claimed mean VP and what happened.

| Unit type | Job | Picks a game | Claimed | Happened |
| --- | --- | --- | --- | --- |
| Regular Infantry | Charge | 1.34 | 52.7 | net 45 VP in 2 turns; declared 52% |
| Regular Infantry | Shoot | 3.79 | 20.4 | 9.2 VP of wounds that turn |
| Regular Infantry | Hold a marker, the hill, a feature | 5.77 | 70.8 | 27.3 VP scored this turn and the enemy's next |
| Regular Infantry | Close in to charge next turn | 0.56 | 33.2 | charged that target next turn 12% |
| Regular Infantry | Advance on an enemy | 7.53 | 13.0 | charged that target next turn 2% |
| Regular Infantry | Screen | 2.26 | 75.6 | guarded unit lost 0.54 wounds (line said 5.60 a turn) |
| Regular Infantry | Redirect | 1.81 | 28.9 | enemy charged the guarded friend 6%, the chaff 3% |
| Character | Charge | 2.31 | 201.8 | net 55 VP in 2 turns; declared 86% |
| Character | Shoot | 0.11 | -16.2 | 1.7 VP of wounds that turn |
| Character | Close in to charge next turn | 2.12 | 89.6 | charged that target next turn 14% |
| Character | Advance on an enemy | 4.97 | 61.1 | charged that target next turn 11% |
| War Machines | Shoot | 7.24 | 21.6 | 0.7 VP of wounds that turn |
| Light Cavalry | Charge | 0.69 | 54.1 | net 43 VP in 2 turns; declared 64% |
| Light Cavalry | Shoot | 0.77 | 9.8 | 14.1 VP of wounds that turn |
| Light Cavalry | Hold a marker, the hill, a feature | 1.65 | 76.3 | 28.0 VP scored this turn and the enemy's next |
| Light Cavalry | Close in to charge next turn | 1.10 | 39.5 | charged that target next turn 8% |
| Light Cavalry | Advance on an enemy | 1.76 | 20.8 | charged that target next turn 4% |
| Light Cavalry | Screen | 0.65 | 27.7 | guarded unit lost 0.41 wounds (line said 4.78 a turn) |
| Light Cavalry | Redirect | 0.48 | -3.6 | enemy charged the guarded friend 2%, the chaff 9% |
| Character (wizard) | Charge | 1.40 | 155.2 | net 70 VP in 2 turns; declared 68% |
| Character (wizard) | Shoot | 0.51 | -11.8 | 1.5 VP of wounds that turn |
| Character (wizard) | Hold a marker, the hill, a feature | 0.03 | 246.1 | 0.0 VP scored this turn and the enemy's next |
| Character (wizard) | Close in to charge next turn | 2.19 | 82.5 | charged that target next turn 13% |
| Character (wizard) | Advance on an enemy | 1.95 | 22.4 | charged that target next turn 7% |
| Heavy Cavalry | Charge | 0.29 | 77.0 | net 34 VP in 2 turns; declared 86% |
| Heavy Cavalry | Shoot | 0.23 | 13.5 | 0.0 VP of wounds that turn |
| Heavy Cavalry | Hold a marker, the hill, a feature | 0.87 | 92.1 | 21.8 VP scored this turn and the enemy's next |
| Heavy Cavalry | Close in to charge next turn | 1.19 | 77.1 | charged that target next turn 13% |
| Heavy Cavalry | Advance on an enemy | 2.46 | 55.6 | charged that target next turn 5% |
| Heavy Cavalry | Screen | 0.08 | 32.5 | guarded unit lost 0.44 wounds (line said 4.38 a turn) |
| Heavy Cavalry | Redirect | 0.02 | -21.6 | enemy charged the guarded friend 0%, the chaff 0% |
| Heavy Infantry | Charge | 0.32 | 72.7 | net 29 VP in 2 turns; declared 80% |
| Heavy Infantry | Shoot | 0.63 | 51.9 | 21.8 VP of wounds that turn |
| Heavy Infantry | Hold a marker, the hill, a feature | 1.06 | 120.1 | 42.3 VP scored this turn and the enemy's next |
| Heavy Infantry | Close in to charge next turn | 0.11 | 11.7 | charged that target next turn 6% |
| Heavy Infantry | Advance on an enemy | 1.94 | 8.2 | charged that target next turn 3% |
| Heavy Infantry | Screen | 0.42 | 53.0 | guarded unit lost 0.39 wounds (line said 4.98 a turn) |
| Heavy Infantry | Redirect | 0.43 | 1.6 | enemy charged the guarded friend 3%, the chaff 0% |
| Heavy Chariots | Charge | 0.50 | 123.6 | net 31 VP in 2 turns; declared 83% |
| Heavy Chariots | Shoot | 0.16 | 29.7 | 5.6 VP of wounds that turn |
| Heavy Chariots | Close in to charge next turn | 0.47 | 31.8 | charged that target next turn 19% |
| Heavy Chariots | Advance on an enemy | 2.29 | 40.6 | charged that target next turn 8% |
| Heavy Chariots | Screen | 0.38 | 26.2 | guarded unit lost 0.13 wounds (line said 3.47 a turn) |
| Heavy Chariots | Redirect | 0.32 | 29.6 | enemy charged the guarded friend 12%, the chaff 0% |
| Monstrous Infantry | Charge | 0.65 | 59.9 | net 37 VP in 2 turns; declared 81% |
| Monstrous Infantry | Shoot | 0.15 | 3.5 | 5.1 VP of wounds that turn |
| Monstrous Infantry | Hold a marker, the hill, a feature | 0.10 | 108.7 | 0.0 VP scored this turn and the enemy's next |
| Monstrous Infantry | Close in to charge next turn | 0.46 | 40.3 | charged that target next turn 14% |
| Monstrous Infantry | Advance on an enemy | 1.53 | 19.6 | charged that target next turn 6% |
| Monstrous Infantry | Screen | 0.44 | 33.7 | guarded unit lost 0.11 wounds (line said 6.25 a turn) |
| Monstrous Infantry | Redirect | 0.80 | 32.2 | enemy charged the guarded friend 5%, the chaff 8% |
| War Beasts | Charge | 0.31 | 31.9 | net 57 VP in 2 turns; declared 73% |
| War Beasts | Shoot | 0.01 | 10.2 | 0.0 VP of wounds that turn |
| War Beasts | Hold a marker, the hill, a feature | 0.07 | 32.7 | 12.0 VP scored this turn and the enemy's next |
| War Beasts | Close in to charge next turn | 0.58 | 40.6 | charged that target next turn 10% |
| War Beasts | Advance on an enemy | 1.17 | 39.7 | charged that target next turn 3% |
| War Beasts | Screen | 0.60 | 50.0 | guarded unit lost 0.46 wounds (line said 5.13 a turn) |
| War Beasts | Redirect | 0.92 | 28.9 | enemy charged the guarded friend 4%, the chaff 6% |
| Behemoths | Charge | 0.35 | 105.5 | net 53 VP in 2 turns; declared 75% |
| Behemoths | Shoot | 0.08 | -8.9 | 23.6 VP of wounds that turn |
| Behemoths | Hold a marker, the hill, a feature | 0.01 | 49.2 | 0.0 VP scored this turn and the enemy's next |
| Behemoths | Close in to charge next turn | 0.35 | 68.4 | charged that target next turn 12% |
| Behemoths | Advance on an enemy | 2.56 | 72.3 | charged that target next turn 3% |
| Monstrous Creatures | Charge | 0.24 | 63.9 | net 60 VP in 2 turns; declared 83% |
| Monstrous Creatures | Shoot | 0.05 | 4.3 | 0.0 VP of wounds that turn |
| Monstrous Creatures | Close in to charge next turn | 0.24 | 4.5 | charged that target next turn 9% |
| Monstrous Creatures | Advance on an enemy | 0.80 | 12.6 | charged that target next turn 9% |
| Monstrous Creatures | Screen | 0.49 | 22.6 | guarded unit lost 0.06 wounds (line said 4.59 a turn) |
| Monstrous Creatures | Redirect | 0.26 | 4.3 | enemy charged the guarded friend 6%, the chaff 0% |
| Monstrous Cavalry | Charge | 0.35 | 85.2 | net 23 VP in 2 turns; declared 94% |
| Monstrous Cavalry | Shoot | 0.02 | 83.0 | 6.2 VP of wounds that turn |
| Monstrous Cavalry | Close in to charge next turn | 0.35 | 53.7 | charged that target next turn 24% |
| Monstrous Cavalry | Advance on an enemy | 0.87 | 66.3 | charged that target next turn 5% |
| Monstrous Cavalry | Screen | 0.12 | 22.1 | guarded unit lost 1.56 wounds (line said 7.94 a turn) |
| Monstrous Cavalry | Redirect | 0.17 | 2.5 | enemy charged the guarded friend 0%, the chaff 14% |
| Light Chariots | Charge | 0.03 | 20.0 | net -52 VP in 2 turns; declared 100% |
| Light Chariots | Shoot | 0.01 | -7.7 | 0.0 VP of wounds that turn |
| Light Chariots | Close in to charge next turn | 0.04 | 21.9 | charged that target next turn 17% |
| Light Chariots | Advance on an enemy | 0.08 | 20.1 | charged that target next turn 0% |
| Light Chariots | Screen | 0.16 | 53.2 | guarded unit lost 0.64 wounds (line said 3.71 a turn) |
| Light Chariots | Redirect | 0.05 | -16.4 | enemy charged the guarded friend 0%, the chaff 14% |
| Swarms | Charge | 0.10 | 86.1 | net -4 VP in 2 turns; declared 67% |
| Swarms | Close in to charge next turn | 0.03 | 32.3 | charged that target next turn 25% |
| Swarms | Advance on an enemy | 0.19 | 24.5 | charged that target next turn 0% |
| ? | Charge | 0.01 | 38.5 | net - VP in 2 turns; declared - |


## Doctrine scorecard (per game and side; far = share of games contested)

### Scorecard: on

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 9 | 6 | 1 | 1 | 0 | 0 | 0 | 322 |
| L0102 | 6 | 1 | Opponent | no | 5 | 1 | 4 | 4 | 0 | 0 | 0 | 222 |
| L0106 | 4 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 926 |
| L0110 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0114 | 6 | 1 | Mine | no | 14 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 5 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 4 | 0 | 0 | 0 | 268 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 20 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 77 |
| L0135 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 6 | 0 | 0 | 0 | 52 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0214 | 4 | 1 | Mine | no | 4 | 4 | 3 | 3 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 5 | 1 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Mine | no | 3 | 3 | 2 | 3 | 0 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Mine | no | 1 | 4 | 2 | 2 | 1 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 4 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 8 | 2 | 1 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 0 | 0 | 1 | 0 | 0 | 330 |
| L0315 | 3 | 1 | Mine | no | 1 | 5 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 9 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L0327 | 3 | 1 | Mine | yes | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 5 | 5 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 6 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 2 | 4 | 3 | 0 | 0 | 0 | 0 | 1104 |
| L0409 | 1 | 1 | Mine | no | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 6 | 3 | 0 | 1 | 0 | 0 | 0 | 564 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | - | 1 | 1 | 1 | 0 | 0 | 317 |
| L0417 | 3 | 1 | Mine | yes | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 135 |
| L0421 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 210 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 3 | 4 | 2 | 0 | 0 | 348 |
| L0429 | 3 | 1 | Mine | yes | 9 | - | 1 | 0 | 1 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0508 | 4 | 1 | Mine | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 515 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1687 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 1 | 0 | 0 | 330 |
| L0516 | 6 | 1 | Mine | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 9 | 3 | 2 | 2 | 1 | 0 | 0 | 200 |
| L0520 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 560 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 1 | 4 | 1 | 0 | 0 | 210 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 475 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0528 | 6 | 1 | Mine | yes | 3 | 6 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 4 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 475 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0608 | 2 | 1 | Mine | - | - | - | 2 | 2 | 0 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 605 |
| L0612 | 6 | 1 | Mine | no | 4 | - | 1 | 1 | 0 | 0 | 0 | 700 |
| L0612 | 6 | 1 | Opponent | no | 6 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0616 | 4 | 1 | Mine | no | 1 | - | 4 | 2 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 2 | 0 | 0 | 200 |
| L0620 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 801 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 1 | 0 | 0 | 210 |
| L0624 | 6 | 1 | Mine | no | 1 | 4 | 2 | 0 | 0 | 0 | 0 | 981 |
| L0624 | 6 | 1 | Opponent | no | 5 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 984 |
| L0628 | 4 | 1 | Opponent | no | 5 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0632 | 2 | 1 | Mine | - | - | 5 | 2 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 170 |
| L0709 | 1 | 1 | Mine | yes | 2 | 4 | 1 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 537 |
| L0713 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 140 |
| L0717 | 3 | 1 | Mine | yes | 3 | 3 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 1 | 6 | 1 | 0 | 2 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 1 | 2 | 0 | 1 | 0 | 0 | 0 | 558 |
| L0721 | 1 | 1 | Opponent | yes | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 355 |
| L0725 | 5 | 1 | Mine | yes | - | 5 | 2 | 3 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L0729 | 3 | 1 | Mine | no | 3 | 4 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Mine | no | 5 | - | 1 | 3 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 405 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 390 |
| L0810 | 6 | 1 | Opponent | no | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0815 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 1 | 0 | 0 | 115 |
| L0819 | 3 | 1 | Mine | no | 2 | 3 | 4 | 1 | 0 | 0 | 0 | 975 |
| L0819 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 1 | 0 | 0 | 330 |
| L0823 | 1 | 1 | Mine | no | 4 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 2 | 0 | 0 | 0 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 717 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 2 | 0 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 3 | 0 | 0 | 456 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 3 | 6 | 1 | 1 | 0 | 0 | 0 | 726 |
| L0913 | 1 | 1 | Opponent | no | 3 | 6 | 0 | 0 | 2 | 0 | 0 | 140 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 8 | 3 | 2 | 1 | 0 | 0 | 0 | 234 |
| L0922 | 4 | 1 | Mine | no | 4 | 6 | 2 | 0 | 0 | 0 | 0 | 619 |
| L0922 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 1 | 0 | 0 | 55 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 492 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 793 |
| L0930 | 6 | 1 | Opponent | no | 8 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 808 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 160 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 5 | 1 | 0 | 1 | 0 | 0 | 479 |
| L1017 | 3 | 1 | Mine | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 6 | 2 | 5 | 1 | 3 | 0 | 0 | 175 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 3 | - | 0 | 5 | 1 | 0 | 0 | 355 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 500 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 10 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 4 | 2 | 4 | 2 | 1 | 0 | 0 | 314 |
| L1126 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 2 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 170 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 4 | 3 | 0 | 1 | 0 | 0 | 274 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1220 | 2 | 1 | Mine | - | - | 5 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | 4 | 6 | 6 | 0 | 0 | 0 | 0 |
| L1224 | 6 | 1 | Mine | no | 7 | 3 | 0 | 0 | 1 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 1 | 0 | 0 | 305 |
| L1314 | 6 | 1 | Mine | no | 3 | 4 | 4 | 0 | 1 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 6 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 532 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 4 | 3 | 5 | 0 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 72 |
| L1327 | 1 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 2 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | no | - | 5 | 0 | 2 | 2 | 0 | 0 | 340 |
| L1335 | 3 | 1 | Mine | no | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 284 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 0 | 2 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 5 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | yes | 8 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | yes | 4 | 6 | 2 | 0 | 1 | 0 | 0 | 732 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 3 | 8 | 1 | 0 | 0 | 0 | 140 |
| L1519 | 1 | 1 | Mine | no | 7 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 0 | 0 | 0 | 0 | 226 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 196 |
| L1527 | 3 | 1 | Mine | yes | 8 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 732 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1621 | 1 | 1 | Mine | no | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 367 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 6 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 2 | 4 | 1 | 0 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L1633 | 1 | 1 | Mine | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | yes | 2 | 1 | 5 | 3 | 0 | 0 | 0 | 785 |
| L1719 | 3 | 1 | Mine | yes | 7 | 6 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 3 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 4 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 0 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 2 | 0 | 0 | 340 |
| L1819 | 1 | 1 | Mine | no | 2 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 5 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 3 | 3 | 0 | 2 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 4 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Mine | no | 2 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 126 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 4 | 1 | 3 | 1 | 0 | 0 | 0 | 491 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 403 |
| L2021 | 5 | 1 | Mine | yes | - | 6 | 0 | 2 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 6 | 2 | 5 | 0 | 0 | 0 | 355 |
| L2025 | 3 | 1 | Mine | no | 3 | - | 0 | 1 | 1 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 2 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | 4 | 4 | 5 | 1 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2123 | 5 | 1 | Mine | yes | - | - | 0 | 9 | 0 | 0 | 0 | 585 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 355 |
| L2127 | 3 | 1 | Opponent | no | 2 | 3 | 5 | 0 | 0 | 0 | 0 | 133 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 0 | 0 | 1 | 0 | 0 | 355 |
| L2131 | 1 | 1 | Opponent | no | 5 | 4 | 3 | 0 | 1 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 387 |
| L2223 | 3 | 1 | Opponent | yes | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 3 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 6 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | - | 0 | 1 | 2 | 0 | 0 | 1169 |
| L2235 | 3 | 1 | Mine | no | 5 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 1 | 2 | 7 | 1 | 0 | 0 | 0 | 126 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 4 | - | 1 | 1 | 0 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 245 |
| L2335 | 1 | 1 | Opponent | no | 3 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 2 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Mine | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 3 | 1 | 3 | 0 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 3 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 2 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 6 | 6 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 6 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 3 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 8 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 2 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 3 | 4 | 3 | 2 | 0 | 0 | 0 | 549 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 31% | 2.3 | 3.1 | 2.1 | 1.1 | 0.2 | 0.0 | 0.0 | 277.7 |
| **Average** | | | Opponent | 29% | 2.5 | 2.6 | 2.9 | 1.7 | 0.4 | 0.0 | 0.0 | 161.0 |

### Scorecard: off

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 10 | 3 | 1 | 0 | 0 | 0 | 0 | 322 |
| L0102 | 6 | 1 | Opponent | no | 2 | 3 | 1 | 6 | 0 | 0 | 0 | 170 |
| L0106 | 4 | 1 | Mine | no | 9 | 4 | 2 | 2 | 0 | 0 | 0 | 442 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 1109 |
| L0110 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 142 |
| L0110 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0114 | 6 | 1 | Mine | no | 11 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 123 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 7 | 1 | 1 | 5 | 0 | 0 | 0 | 302 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 55 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | yes | 9 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0210 | 6 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 11 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0214 | 4 | 1 | Mine | yes | 9 | - | 2 | 4 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | no | 0 | 1 | 0 | 2 | 0 | 0 | 0 | 177 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Mine | no | 0 | 1 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 7 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | 3 | 5 | 1 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 6 | 0 | 2 | 0 | 0 | 0 | 420 |
| L0311 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 3 | 0 | 1 | 0 | 0 | 330 |
| L0315 | 3 | 1 | Mine | yes | 7 | 3 | 1 | 1 | 0 | 0 | 0 | 760 |
| L0315 | 3 | 1 | Opponent | yes | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 10 | 2 | 6 | 0 | 0 | 0 | 0 | 760 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 1 | 0 | 0 | 140 |
| L0327 | 3 | 1 | Mine | yes | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 8 | 4 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 5 | 1 | 0 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 3 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 1019 |
| L0409 | 1 | 1 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 9 | 5 | 2 | 0 | 0 | 0 | 0 | 1179 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 317 |
| L0417 | 3 | 1 | Mine | yes | 5 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 3 | 2 | 3 | 0 | 1 | 0 | 0 | 49 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 2 | - | 0 | 3 | 1 | 0 | 0 | 145 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 4 | 2 | 0 | 0 | 348 |
| L0429 | 3 | 1 | Mine | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 593 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 330 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 2 | 0 | 0 | 280 |
| L0520 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 1120 |
| L0520 | 4 | 1 | Opponent | no | 6 | 2 | 1 | 6 | 1 | 0 | 0 | 420 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1497 |
| L0528 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0533 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 4 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 3 | 2 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 10 | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0616 | 4 | 1 | Mine | no | 0 | 5 | 2 | 0 | 1 | 0 | 0 | 743 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 200 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 926 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 5 | 1 | 0 | 0 | 95 |
| L0624 | 6 | 1 | Mine | no | 6 | 3 | 5 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 3 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 1292 |
| L0628 | 4 | 1 | Opponent | no | 2 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 801 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Mine | yes | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Mine | yes | - | 3 | 1 | 3 | 1 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 140 |
| L0717 | 3 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 175 |
| L0721 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 375 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 1 | 5 | 1 | 0 | 0 | 500 |
| L0725 | 5 | 1 | Mine | yes | - | 4 | 5 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 75 |
| L0729 | 3 | 1 | Mine | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0810 | 6 | 1 | Mine | no | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 724 |
| L0810 | 6 | 1 | Opponent | no | 11 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0815 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 679 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 1 | 3 | 3 | 0 | 1 | 0 | 0 | 715 |
| L0819 | 3 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 60 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 1 | 2 | 0 | 0 | 0 | 515 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 10 | 2 | 1 | 1 | 0 | 0 | 0 | 762 |
| L0831 | 3 | 1 | Opponent | no | 2 | 4 | 0 | 1 | 1 | 0 | 0 | 170 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 970 |
| L0913 | 1 | 1 | Opponent | no | 8 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L0918 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 3 | 3 | 3 | 3 | 0 | 0 | 0 | 234 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 492 |
| L0922 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 560 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 793 |
| L0930 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 1105 |
| L0934 | 4 | 1 | Opponent | no | 5 | 2 | 5 | 4 | 0 | 0 | 0 | 216 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 1 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1017 | 3 | 1 | Mine | no | 6 | 2 | 7 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 1 | 3 | 5 | 0 | 2 | 0 | 0 | 135 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 0 | 5 | 0 | 0 | 0 | 145 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 8 | 3 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1030 | 4 | 1 | Mine | no | 0 | 5 | 3 | 0 | 1 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 207 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 2 | 1 | 1 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 56 |
| L1114 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 522 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 177 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 2 | 0 | 0 | 485 |
| L1122 | 6 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 225 |
| L1126 | 4 | 1 | Mine | yes | 5 | 3 | 4 | 0 | 1 | 0 | 0 | 425 |
| L1126 | 4 | 1 | Opponent | no | 0 | 2 | 7 | 2 | 1 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 5 | 0 | 1 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 1 | 5 | 2 | 1 | 3 | 0 | 0 | 170 |
| L1135 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 3 | 0 | 4 | 0 | 0 | 0 | 158 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 200 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 4 | 1 | 1 | 0 | 0 | 420 |
| L1224 | 6 | 1 | Mine | no | 9 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 15 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1232 | 2 | 1 | Mine | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 1 | 0 | 0 | 340 |
| L1314 | 6 | 1 | Mine | no | 14 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 123 |
| L1319 | 5 | 1 | Mine | no | - | 2 | 1 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 4 | 3 | 2 | 1 | 1 | 0 | 0 | 302 |
| L1323 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 3 | 0 | 0 | 66 |
| L1327 | 1 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | yes | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 50 |
| L1331 | 5 | 1 | Mine | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 170 |
| L1335 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 4 | 0 | 0 | 0 | 140 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 305 |
| L1422 | 6 | 1 | Mine | no | 1 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 1 | 0 | 0 | 352 |
| L1427 | 5 | 1 | Mine | no | - | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | yes | 10 | 3 | 5 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 1 | 2 | 0 | 0 | 170 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 1 | 6 | 2 | 2 | 0 | 0 | 0 | 158 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 126 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 2 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 138 |
| L1527 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 4 | 2 | 5 | 1 | 1 | 0 | 0 | 176 |
| L1531 | 1 | 1 | Opponent | no | 1 | 5 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 4 | 1 | 4 | 0 | 0 | 0 | 657 |
| L1621 | 1 | 1 | Mine | yes | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 834 |
| L1625 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 7 | 3 | 0 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L1633 | 1 | 1 | Mine | yes | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Mine | yes | 11 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 3 | 0 | 2 | 0 | 0 | 585 |
| L1723 | 1 | 1 | Mine | yes | 6 | 3 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 1 | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | no | - | 3 | 2 | 0 | 0 | 0 | 0 | 49 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 0 | 5 | 3 | 0 | 0 | 0 | 0 | 49 |
| L1731 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 484 |
| L1819 | 1 | 1 | Mine | no | 1 | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | yes | 3 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 531 |
| L1827 | 3 | 1 | Opponent | no | 11 | 2 | 3 | 2 | 0 | 0 | 0 | 190 |
| L1831 | 1 | 1 | Mine | no | 10 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 0 | 0 | 0 | 140 |
| L1923 | 3 | 1 | Mine | yes | 2 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 3 | 1 | 3 | 0 | 0 | 0 | 0 | 245 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 60 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 642 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 5 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 4 | 6 | 0 | 0 | 0 | 145 |
| L2025 | 3 | 1 | Mine | yes | 1 | 4 | 1 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 1 | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 1 | - | 1 | 3 | 0 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 7 | 2 | 6 | 0 | 0 | 0 | 0 | 122 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 5 | 2 | 0 | 0 | 458 |
| L2033 | 5 | 1 | Opponent | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2123 | 5 | 1 | Mine | no | - | - | 2 | 6 | 0 | 0 | 0 | 65 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 1162 |
| L2127 | 3 | 1 | Opponent | no | 7 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 3 | 2 | 4 | 2 | 0 | 0 | 0 | 500 |
| L2131 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Mine | no | 4 | 2 | 5 | 0 | 1 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 185 |
| L2227 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 7 | 2 | 1 | 0 | 0 | 60 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 1 | 6 | 1 | 2 | 0 | 0 | 933 |
| L2235 | 3 | 1 | Mine | no | 0 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 2 | 0 | 0 | 257 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 8 | 0 | 2 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | yes | 5 | 3 | 3 | 1 | 1 | 0 | 0 | 138 |
| L2331 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 1 | 0 | 0 | 515 |
| L2335 | 1 | 1 | Mine | no | 3 | 1 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 158 |
| L2429 | 5 | 1 | Mine | no | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 1 | 0 | 0 | 170 |
| L2433 | 3 | 1 | Mine | no | 6 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 2 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 2 | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 6 | 1 | 2 | 1 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 4 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 285 |
| L2634 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 107 |
| L2730 | 6 | 1 | Mine | no | 0 | 6 | 6 | 3 | 0 | 0 | 0 | 380 |
| L2730 | 6 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 75 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 1 | 2 | 1 | 1 | 2 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 5 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 7 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 144 |
| L3133 | 1 | 1 | Mine | no | 4 | 3 | 2 | 2 | 2 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 380 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 31% | 2.9 | 2.6 | 2.8 | 1.2 | 0.2 | 0.0 | 0.0 | 306.4 |
| **Average** | | | Opponent | 27% | 2.2 | 2.4 | 2.9 | 1.8 | 0.4 | 0.0 | 0.0 | 170.8 |


## Charged fights (points per fight a side charged into; a combined charge is one fight)

### Charged fights: on

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 17 | 119 | 112 | 1.5 | 1.1 | 73 | 16 | +58 | 6 of 26 | 23 of 26 | +143 | +46 |
| Mine | Chaos Dwarfs | 15 | 160 | 269 | 2.1 | 1.3 | 130 | 20 | +111 | 16 of 31 | 19 of 31 | +268 | +65 |
| Mine | Dwarfen Mountain Holds | 14 | 534 | 36 | 1.3 | 1.1 | 28 | 44 | -16 | 4 of 18 | 12 of 18 | +114 | -33 |
| Mine | Empire of Man | 20 | 374 | 162 | 1.6 | 1.2 | 101 | 56 | +46 | 14 of 32 | 19 of 32 | +130 | +30 |
| Mine | Grand Cathay | 17 | 395 | 520 | 3.2 | 1.2 | 164 | 30 | +134 | 15 of 54 | 43 of 54 | +205 | +122 |
| Mine | High Elf Realms | 16 | 165 | 440 | 3.2 | 1.2 | 138 | 16 | +122 | 17 of 51 | 36 of 51 | +168 | +114 |
| Mine | Kingdom of Bretonnia | 4 | 48 | 499 | 4.8 | 1.1 | 105 | 80 | +25 | 8 of 19 | 14 of 19 | +289 | -6 |
| Mine | Lizardmen | 4 | 184 | 416 | 3.2 | 1.3 | 128 | 48 | +79 | 5 of 13 | 8 of 13 | +115 | +69 |
| Mine | Ogre Kingdoms | 5 | 39 | 225 | 4.2 | 1.0 | 53 | 19 | +34 | 5 of 21 | 16 of 20 | - | +34 |
| Mine | Orc & Goblin Tribes | 3 | 0 | 428 | 5.3 | 1.2 | 80 | 59 | +22 | 3 of 16 | 13 of 16 | +52 | +15 |
| Mine | Skaven | 7 | 115 | 36 | 1.6 | 1.2 | 23 | 0 | +23 | 1 of 11 | 6 of 11 | +0 | +28 |
| Mine | Tomb Kings of Khemri | 7 | 61 | 566 | 3.1 | 1.1 | 180 | 38 | +142 | 6 of 22 | 14 of 22 | +448 | +112 |
| Mine | Vampire Counts | 9 | 15 | 319 | 4.2 | 1.2 | 76 | 39 | +36 | 8 of 38 | 28 of 38 | +51 | +34 |
| Mine | Warriors of Chaos | 6 | 0 | 212 | 2.8 | 1.1 | 75 | 45 | +30 | 4 of 17 | 13 of 17 | +72 | +24 |
| **Mine** | all armies | 144 | 217 | 278 | 2.6 | 1.2 | 108 | 34 | +74 | 112 of 369 | 264 of 368 | +162 | +60 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 5.0 | 1.2 | 0 | 23 | -23 | 1 of 5 | 0 of 5 | -30 | -21 |
| Opponent | Dwarfen Mountain Holds | 3 | 174 | 77 | 3.7 | 1.3 | 21 | 0 | +21 | 1 of 11 | 4 of 11 | +50 | +10 |
| Opponent | Empire of Man | 5 | 174 | 12 | 1.2 | 1.0 | 10 | 0 | +10 | 2 of 6 | 3 of 6 | - | +10 |
| Opponent | Grand Cathay | 6 | 425 | 503 | 2.5 | 1.5 | 201 | 14 | +188 | 11 of 15 | 11 of 15 | +300 | +146 |
| Opponent | High Elf Realms | 10 | 75 | 343 | 3.2 | 1.3 | 107 | 13 | +94 | 21 of 32 | 16 of 32 | +149 | +76 |
| Opponent | Kingdom of Bretonnia | 3 | 32 | 189 | 2.7 | 1.0 | 71 | 0 | +71 | 3 of 8 | 5 of 8 | - | +71 |
| Opponent | Lizardmen | 3 | 160 | 460 | 2.0 | 1.0 | 230 | 91 | +139 | 5 of 6 | 2 of 6 | - | +139 |
| Opponent | Ogre Kingdoms | 5 | 66 | 283 | 4.4 | 1.2 | 64 | 37 | +27 | 7 of 22 | 13 of 22 | -84 | +45 |
| Opponent | Orc & Goblin Tribes | 6 | 42 | 530 | 5.5 | 1.1 | 96 | 8 | +88 | 9 of 33 | 20 of 32 | +117 | +86 |
| Opponent | Skaven | 8 | 96 | 116 | 1.6 | 1.3 | 72 | 3 | +69 | 4 of 13 | 11 of 13 | +200 | +45 |
| Opponent | Tomb Kings of Khemri | 14 | 92 | 545 | 3.4 | 1.2 | 162 | 75 | +87 | 28 of 47 | 30 of 47 | -62 | +118 |
| Opponent | Vampire Counts | 24 | 7 | 486 | 3.8 | 1.2 | 128 | 42 | +86 | 46 of 91 | 43 of 91 | +133 | +78 |
| Opponent | Warriors of Chaos | 31 | 7 | 431 | 2.6 | 1.1 | 165 | 31 | +134 | 42 of 81 | 44 of 81 | +389 | +110 |
| Opponent | Wood Elf Realms | 25 | 101 | 514 | 4.4 | 1.2 | 117 | 31 | +86 | 30 of 110 | 64 of 110 | +106 | +81 |
| **Opponent** | all armies | 144 | 75 | 415 | 3.3 | 1.2 | 124 | 33 | +92 | 210 of 480 | 266 of 479 | +126 | +86 |

### Charged fights: off

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 17 | 115 | 148 | 1.5 | 1.1 | 101 | 0 | +101 | 5 of 25 | 23 of 25 | +61 | +104 |
| Mine | Chaos Dwarfs | 15 | 188 | 553 | 3.3 | 1.1 | 166 | 22 | +144 | 27 of 50 | 36 of 49 | +143 | +144 |
| Mine | Dwarfen Mountain Holds | 14 | 547 | 85 | 2.0 | 1.1 | 43 | 51 | -8 | 10 of 28 | 13 of 28 | -92 | -2 |
| Mine | Empire of Man | 20 | 455 | 237 | 2.4 | 1.1 | 99 | 50 | +49 | 15 of 48 | 31 of 48 | -63 | +57 |
| Mine | Grand Cathay | 17 | 463 | 318 | 3.8 | 1.1 | 83 | 23 | +61 | 21 of 65 | 49 of 65 | +82 | +57 |
| Mine | High Elf Realms | 16 | 149 | 503 | 3.6 | 1.1 | 141 | 40 | +102 | 18 of 57 | 47 of 57 | +40 | +105 |
| Mine | Kingdom of Bretonnia | 4 | 82 | 434 | 4.2 | 1.1 | 102 | 5 | +97 | 6 of 17 | 11 of 17 | +112 | +96 |
| Mine | Lizardmen | 4 | 74 | 702 | 3.5 | 1.1 | 201 | 14 | +187 | 3 of 14 | 10 of 14 | -141 | +212 |
| Mine | Ogre Kingdoms | 5 | 102 | 133 | 3.6 | 1.1 | 37 | 47 | -10 | 5 of 18 | 8 of 18 | -34 | -8 |
| Mine | Orc & Goblin Tribes | 3 | 0 | 582 | 5.7 | 1.1 | 103 | 26 | +77 | 6 of 17 | 11 of 17 | +145 | +73 |
| Mine | Skaven | 7 | 172 | 90 | 2.0 | 1.1 | 45 | 40 | +6 | 2 of 14 | 10 of 14 | +60 | -4 |
| Mine | Tomb Kings of Khemri | 7 | 53 | 707 | 5.1 | 1.1 | 137 | 41 | +97 | 9 of 36 | 24 of 36 | +364 | +63 |
| Mine | Vampire Counts | 9 | 90 | 555 | 4.8 | 1.1 | 116 | 43 | +73 | 12 of 43 | 27 of 43 | +81 | +72 |
| Mine | Warriors of Chaos | 6 | 3 | 598 | 4.0 | 1.1 | 149 | 24 | +125 | 7 of 24 | 21 of 24 | +96 | +129 |
| **Mine** | all armies | 144 | 245 | 356 | 3.2 | 1.1 | 113 | 32 | +80 | 146 of 456 | 321 of 455 | +85 | +80 |
| Opponent | Beastmen Brayherds | 1 | 65 | 0 | 2.0 | 1.5 | 0 | 42 | -42 | 0 of 2 | 0 of 2 | +0 | -85 |
| Opponent | Dwarfen Mountain Holds | 3 | 166 | 64 | 2.3 | 1.1 | 27 | 35 | -8 | 0 of 7 | 4 of 7 | +0 | -9 |
| Opponent | Empire of Man | 5 | 524 | 181 | 1.4 | 1.1 | 129 | 0 | +129 | 3 of 7 | 5 of 7 | +140 | +128 |
| Opponent | Grand Cathay | 6 | 346 | 572 | 3.5 | 1.4 | 163 | 0 | +163 | 8 of 21 | 18 of 21 | +377 | +97 |
| Opponent | High Elf Realms | 10 | 170 | 514 | 3.8 | 1.2 | 135 | 62 | +73 | 17 of 38 | 21 of 38 | -99 | +105 |
| Opponent | Kingdom of Bretonnia | 3 | 87 | 169 | 1.3 | 1.0 | 127 | 69 | +58 | 2 of 4 | 2 of 4 | - | +58 |
| Opponent | Lizardmen | 3 | 91 | 63 | 1.3 | 1.0 | 47 | 0 | +47 | 1 of 4 | 2 of 4 | - | +47 |
| Opponent | Ogre Kingdoms | 5 | 82 | 338 | 3.4 | 1.2 | 99 | 8 | +91 | 6 of 17 | 6 of 16 | +474 | +9 |
| Opponent | Orc & Goblin Tribes | 6 | 10 | 186 | 3.0 | 1.1 | 62 | 29 | +33 | 8 of 18 | 9 of 18 | +0 | +35 |
| Opponent | Skaven | 8 | 80 | 43 | 1.0 | 1.0 | 43 | 81 | -38 | 4 of 8 | 5 of 8 | - | -38 |
| Opponent | Tomb Kings of Khemri | 14 | 105 | 808 | 4.7 | 1.2 | 171 | 48 | +124 | 30 of 66 | 41 of 66 | +90 | +132 |
| Opponent | Vampire Counts | 24 | 30 | 569 | 4.7 | 1.2 | 122 | 47 | +75 | 53 of 112 | 65 of 112 | +72 | +75 |
| Opponent | Warriors of Chaos | 31 | 9 | 512 | 3.4 | 1.1 | 153 | 31 | +122 | 62 of 104 | 64 of 104 | +256 | +104 |
| Opponent | Wood Elf Realms | 25 | 86 | 373 | 3.5 | 1.1 | 107 | 26 | +81 | 34 of 87 | 48 of 87 | +95 | +79 |
| **Opponent** | all armies | 144 | 92 | 442 | 3.4 | 1.2 | 129 | 37 | +92 | 228 of 495 | 290 of 494 | +129 | +85 |


## Effective charges (55-75% to win the first round: just enough force)

### Effective charges: on

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 26 | 3 (net -49) | 1 (net +0) | 1 (net +266) | 5 (net +83) | 2 (net +50) | 12 (net +61) | 2 | 4% (1 of 24) |
| Mine | Chaos Dwarfs | 31 | 6 (net +126) | 0 | 3 (net +70) | 3 (net +241) | 5 (net +130) | 12 (net +37) | 2 | 10% (3 of 29) |
| Mine | Dwarfen Mountain Holds | 18 | 1 (net -180) | 1 (net +0) | 3 (net +27) | 3 (net -5) | 0 | 8 (net -22) | 2 | 19% (3 of 16) |
| Mine | Empire of Man | 32 | 6 (net -41) | 0 | 2 (net -66) | 4 (net -1) | 5 (net +74) | 15 (net +98) | 0 | 6% (2 of 32) |
| Mine | Grand Cathay | 54 | 5 (net +176) | 1 (net +817) | 8 (net +138) | 7 (net +21) | 8 (net +43) | 23 (net +163) | 2 | 15% (8 of 52) |
| Mine | High Elf Realms | 51 | 1 (net +0) | 0 | 6 (net +138) | 12 (net +137) | 14 (net +176) | 11 (net +98) | 7 | 14% (6 of 44) |
| Mine | Kingdom of Bretonnia | 19 | 3 (net +193) | 3 (net -87) | 1 (net -137) | 0 | 3 (net +40) | 8 (net +23) | 1 | 6% (1 of 18) |
| Mine | Lizardmen | 13 | 2 (net +224) | 0 | 3 (net +30) | 1 (net +144) | 1 (net +235) | 2 (net +55) | 4 | 33% (3 of 9) |
| Mine | Ogre Kingdoms | 21 | 1 (net +0) | 1 (net -34) | 2 (net +0) | 3 (net +22) | 2 (net +0) | 5 (net +76) | 7 | 14% (2 of 14) |
| Mine | Orc & Goblin Tribes | 16 | 1 (net +233) | 0 | 3 (net +107) | 0 | 3 (net +88) | 2 (net +136) | 7 | 33% (3 of 9) |
| Mine | Skaven | 11 | 3 (net +0) | 0 | 2 (net +0) | 0 | 2 (net +32) | 4 (net +46) | 0 | 18% (2 of 11) |
| Mine | Tomb Kings of Khemri | 22 | 1 (net -70) | 0 | 4 (net +102) | 4 (net +30) | 3 (net +179) | 8 (net +236) | 2 | 20% (4 of 20) |
| Mine | Vampire Counts | 38 | 10 (net -76) | 0 | 5 (net +4) | 5 (net +27) | 4 (net +121) | 13 (net +106) | 1 | 14% (5 of 37) |
| Mine | Warriors of Chaos | 17 | 1 (net +0) | 0 | 5 (net +105) | 4 (net -154) | 0 | 5 (net +98) | 2 | 33% (5 of 15) |
| Opponent | Beastmen Brayherds | 5 | 0 | 1 (net -85) | 2 (net +0) | 2 (net -15) | 0 | 0 | 0 | 40% (2 of 5) |
| Opponent | Dwarfen Mountain Holds | 11 | 2 (net +0) | 1 (net +0) | 2 (net +42) | 2 (net +32) | 0 | 4 (net +20) | 0 | 18% (2 of 11) |
| Opponent | Empire of Man | 6 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 (net +0) | 2 | 25% (1 of 4) |
| Opponent | Grand Cathay | 15 | 4 (net +159) | 0 | 2 (net +395) | 2 (net +111) | 1 (net +84) | 4 (net +270) | 2 | 15% (2 of 13) |
| Opponent | High Elf Realms | 32 | 4 (net +167) | 0 | 4 (net +125) | 3 (net +28) | 2 (net +38) | 16 (net +127) | 3 | 14% (4 of 29) |
| Opponent | Kingdom of Bretonnia | 8 | 3 (net +72) | 0 | 1 (net +65) | 1 (net +0) | 0 | 2 (net +82) | 1 | 14% (1 of 7) |
| Opponent | Lizardmen | 6 | 0 | 0 | 3 (net +17) | 2 (net +102) | 0 | 1 (net +580) | 0 | 50% (3 of 6) |
| Opponent | Ogre Kingdoms | 22 | 2 (net -126) | 0 | 4 (net -53) | 3 (net +15) | 1 (net +65) | 4 (net +58) | 8 | 29% (4 of 14) |
| Opponent | Orc & Goblin Tribes | 33 | 1 (net +583) | 0 | 4 (net +8) | 2 (net +76) | 2 (net +89) | 6 (net +116) | 18 | 27% (4 of 15) |
| Opponent | Skaven | 13 | 3 (net +84) | 1 (net +205) | 3 (net +63) | 0 | 0 | 5 (net +50) | 1 | 25% (3 of 12) |
| Opponent | Tomb Kings of Khemri | 47 | 3 (net -52) | 1 (net -540) | 8 (net +45) | 10 (net +142) | 3 (net +71) | 15 (net +145) | 7 | 20% (8 of 40) |
| Opponent | Vampire Counts | 91 | 22 (net +28) | 1 (net +299) | 9 (net +37) | 14 (net +42) | 4 (net +5) | 35 (net +149) | 6 | 11% (9 of 85) |
| Opponent | Warriors of Chaos | 81 | 11 (net +116) | 0 | 14 (net +148) | 14 (net +112) | 4 (net +124) | 29 (net +194) | 9 | 19% (14 of 72) |
| Opponent | Wood Elf Realms | 110 | 14 (net +72) | 2 (net -51) | 7 (net +146) | 23 (net +77) | 14 (net +86) | 31 (net +95) | 19 | 8% (7 of 91) |

### Effective charges: off

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 25 | 1 (net +0) | 0 | 2 (net +128) | 4 (net +133) | 3 (net +72) | 10 (net +117) | 5 | 10% (2 of 20) |
| Mine | Chaos Dwarfs | 50 | 4 (net +452) | 0 | 9 (net +177) | 11 (net +75) | 6 (net +118) | 16 (net +112) | 4 | 20% (9 of 46) |
| Mine | Dwarfen Mountain Holds | 28 | 1 (net -185) | 1 (net -233) | 6 (net -41) | 3 (net +35) | 1 (net +60) | 14 (net +17) | 2 | 23% (6 of 26) |
| Mine | Empire of Man | 48 | 4 (net +46) | 0 | 9 (net -98) | 11 (net +130) | 5 (net +32) | 18 (net +81) | 1 | 19% (9 of 47) |
| Mine | Grand Cathay | 65 | 4 (net -36) | 3 (net +23) | 15 (net +68) | 10 (net +50) | 7 (net +48) | 23 (net +101) | 3 | 24% (15 of 62) |
| Mine | High Elf Realms | 57 | 1 (net -115) | 2 (net +60) | 4 (net -44) | 9 (net +195) | 9 (net +47) | 27 (net +121) | 5 | 8% (4 of 52) |
| Mine | Kingdom of Bretonnia | 17 | 5 (net +38) | 0 | 2 (net +54) | 2 (net -40) | 3 (net +67) | 2 (net +118) | 3 | 14% (2 of 14) |
| Mine | Lizardmen | 14 | 2 (net +158) | 0 | 4 (net +336) | 3 (net +105) | 1 (net -141) | 0 | 4 | 40% (4 of 10) |
| Mine | Ogre Kingdoms | 18 | 0 | 0 | 2 (net -17) | 2 (net -17) | 1 (net +45) | 6 (net +41) | 7 | 18% (2 of 11) |
| Mine | Orc & Goblin Tribes | 17 | 3 (net +304) | 0 | 0 | 1 (net -55) | 3 (net +15) | 2 (net +72) | 8 | 0% (0 of 9) |
| Mine | Skaven | 14 | 3 (net +22) | 0 | 1 (net -41) | 4 (net -6) | 2 (net +0) | 3 (net -21) | 1 | 8% (1 of 13) |
| Mine | Tomb Kings of Khemri | 36 | 3 (net +200) | 1 (net +56) | 7 (net -86) | 3 (net -19) | 9 (net +138) | 13 (net +172) | 0 | 19% (7 of 36) |
| Mine | Vampire Counts | 43 | 6 (net -87) | 2 (net +0) | 8 (net +111) | 5 (net +192) | 4 (net +105) | 16 (net +62) | 2 | 20% (8 of 41) |
| Mine | Warriors of Chaos | 24 | 3 (net +261) | 0 | 4 (net +67) | 4 (net +53) | 4 (net +258) | 8 (net +56) | 1 | 17% (4 of 23) |
| Opponent | Beastmen Brayherds | 2 | 0 | 0 | 1 (net -85) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Opponent | Dwarfen Mountain Holds | 7 | 1 (net +0) | 0 | 1 (net -60) | 3 (net -16) | 0 | 2 (net +28) | 0 | 14% (1 of 7) |
| Opponent | Empire of Man | 7 | 0 | 0 | 2 (net +164) | 2 (net +0) | 0 | 3 (net +192) | 0 | 29% (2 of 7) |
| Opponent | Grand Cathay | 21 | 2 (net +306) | 0 | 4 (net +104) | 7 (net +139) | 2 (net +116) | 5 (net +240) | 1 | 20% (4 of 20) |
| Opponent | High Elf Realms | 38 | 6 (net +3) | 2 (net -28) | 5 (net -24) | 6 (net +111) | 2 (net +0) | 12 (net +156) | 5 | 15% (5 of 33) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +434) | 3 | 0% (0 of 1) |
| Opponent | Lizardmen | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +94) | 1 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 17 | 1 (net +0) | 0 | 4 (net +310) | 1 (net -34) | 0 | 4 (net +103) | 7 | 40% (4 of 10) |
| Opponent | Orc & Goblin Tribes | 18 | 2 (net +110) | 0 | 2 (net -175) | 2 (net +0) | 0 | 2 (net +88) | 10 | 25% (2 of 8) |
| Opponent | Skaven | 8 | 1 (net -210) | 0 | 2 (net +38) | 1 (net +105) | 0 | 4 (net -69) | 0 | 25% (2 of 8) |
| Opponent | Tomb Kings of Khemri | 66 | 5 (net +106) | 2 (net -105) | 11 (net +180) | 8 (net +87) | 4 (net -84) | 23 (net +172) | 13 | 21% (11 of 53) |
| Opponent | Vampire Counts | 112 | 17 (net +17) | 5 (net -168) | 19 (net +131) | 24 (net +52) | 12 (net +81) | 27 (net +112) | 8 | 18% (19 of 104) |
| Opponent | Warriors of Chaos | 104 | 11 (net +166) | 6 (net +134) | 16 (net +103) | 10 (net +160) | 3 (net +113) | 39 (net +135) | 19 | 19% (16 of 85) |
| Opponent | Wood Elf Realms | 87 | 6 (net +112) | 1 (net +70) | 16 (net +43) | 12 (net +4) | 5 (net +68) | 33 (net +123) | 14 | 22% (16 of 73) |


## Charged fights by odds band, damage counted (Morten 2026-11-10)

### Charged fights, damage counted: on

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 44 | 242 | 269 | +34 | 114 | 75 | +39 | +16.2 |
| Mine | 50-54% | 7 | 220 | 184 | +75 | 163 | 82 | +81 | +36.8 |
| Mine | Effective (55-75%) | 48 | 276 | 209 | +74 | 141 | 63 | +78 | +28.3 |
| Mine | 76-89% | 51 | 238 | 165 | +54 | 112 | 53 | +59 | +24.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 128 | 258 | 189 | +95 | 149 | 41 | +108 | +41.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 52 | 424 | 99 | +108 | 132 | 22 | +110 | +25.9 |
| Mine | No odds | 39 | 294 | 160 | +32 | 87 | 61 | +26 | +9.0 |
| Mine | All fights | 369 | 282 | 182 | +74 | 130 | 50 | +80 | +28.5 |
| Opponent | Long shot (under 50%) | 69 | 244 | 257 | +70 | 141 | 76 | +65 | +26.8 |
| Opponent | 50-54% | 7 | 248 | 176 | -32 | 83 | 127 | -44 | -17.6 |
| Opponent | Effective (55-75%) | 64 | 240 | 221 | +83 | 156 | 71 | +85 | +35.6 |
| Opponent | 76-89% | 78 | 283 | 207 | +78 | 135 | 50 | +86 | +30.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 155 | 319 | 208 | +136 | 175 | 45 | +130 | +40.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 31 | 481 | 84 | +75 | 90 | 7 | +83 | +17.3 |
| Opponent | No odds | 76 | 222 | 188 | +60 | 124 | 70 | +54 | +24.5 |
| Opponent | All fights | 480 | 286 | 205 | +92 | 146 | 57 | +90 | +31.5 |

### Charged fights, damage counted: off

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 40 | 246 | 245 | +97 | 165 | 77 | +88 | +35.8 |
| Mine | 50-54% | 9 | 176 | 209 | +1 | 49 | 48 | +1 | +0.8 |
| Mine | Effective (55-75%) | 73 | 274 | 230 | +48 | 125 | 67 | +58 | +21.2 |
| Mine | 76-89% | 72 | 269 | 189 | +89 | 142 | 48 | +94 | +35.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 158 | 236 | 168 | +92 | 139 | 40 | +98 | +41.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 58 | 425 | 90 | +82 | 103 | 22 | +81 | +19.1 |
| Mine | No odds | 46 | 328 | 176 | +80 | 127 | 43 | +85 | +25.8 |
| Mine | All fights | 456 | 280 | 180 | +80 | 132 | 47 | +85 | +30.3 |
| Opponent | Long shot (under 50%) | 52 | 294 | 290 | +76 | 163 | 92 | +72 | +24.3 |
| Opponent | 50-54% | 16 | 274 | 299 | -14 | 186 | 192 | -6 | -2.2 |
| Opponent | Effective (55-75%) | 84 | 289 | 213 | +98 | 150 | 56 | +94 | +32.5 |
| Opponent | 76-89% | 76 | 294 | 197 | +69 | 117 | 51 | +66 | +22.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 158 | 301 | 210 | +133 | 186 | 50 | +136 | +45.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 28 | 484 | 105 | +55 | 94 | 42 | +51 | +10.6 |
| Opponent | No odds | 81 | 239 | 189 | +71 | 106 | 35 | +72 | +30.0 |
| Opponent | All fights | 495 | 297 | 210 | +92 | 149 | 57 | +91 | +30.8 |


## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| on | move | 2255 | 416 (18%) | 301 (13%) | 226 (10%) | 1613 (72%) |
| on | objective | 1660 | 249 (15%) | 187 (11%) | 195 (12%) | 1216 (73%) |
| off | move | 1837 | 438 (24%) | 309 (17%) | 204 (11%) | 1195 (65%) |
| off | objective | 1409 | 209 (15%) | 151 (11%) | 195 (14%) | 1005 (71%) |

## Combined arms (paper 2026-11-09, item 8)

### Combined arms: on (144 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 53 of 369 (14%) | 36 of 547 (7%) | 886 of 1608 (55%) | 0.32 per game | 0.30 / 0.15 per game |
| Opponent | 71 of 480 (15%) | 45 of 429 (10%) | 673 of 1314 (51%) | 0.41 per game | 0.10 / 0.02 per game |

### Combined arms: off (144 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 40 of 456 (9%) | 40 of 560 (7%) | 790 of 1434 (55%) | 0.26 per game | 0.15 / 0.07 per game |
| Opponent | 74 of 495 (15%) | 37 of 496 (7%) | 553 of 1228 (45%) | 0.46 per game | 0.08 / 0.06 per game |


## Quality by phase (per game and side)

| Phase | Number | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 3.5 | 3.0 | 3.5 |
| Strategy | Charge objectives carried out (made contact) | 55% (271 of 496) | 45% (319 of 716) | 53% (311 of 584) | 45% (313 of 698) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (650 of 1314) | 58% (337 of 582) | 47% (639 of 1364) | 48% (295 of 618) |
| Strategy | Close-in objectives charged next turn | 13% (89 of 675) | 16% (161 of 985) | 14% (88 of 619) | 15% (122 of 790) |
| Strategy | Support requests answered (helper made contact too) | 35% (21 of 60) | 51% (61 of 119) | 52% (24 of 46) | 39% (42 of 109) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 91% (10 of 11) | 80% (4 of 5) | 88% (7 of 8) | 80% (8 of 10) |
| Strategy | Hexes on a unit its side charged or shot that turn | 44% (24 of 55) | 39% (19 of 49) | 44% (21 of 48) | 77% (27 of 35) |
| Strategy | Joined characters whose unit fought | 54% (92 of 171) | 42% (58 of 139) | 54% (89 of 164) | 44% (60 of 135) |
| Strategy | Lone characters that fought | 76% (286 of 378) | 74% (272 of 370) | 78% (299 of 385) | 79% (296 of 374) |
| Movement | Charges halted short of contact | 0.1 | 0.3 | 0.2 | 0.2 |
| Movement | Idle units | 1.1 | 1.7 | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 277.7 | 161.0 | 306.4 | 170.8 |
| Movement | Fights charged into per game | 2.6 | 3.3 | 3.2 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 44 of 330, net +34 | 69 of 404, net +70 | 40 of 410, net +97 | 52 of 414, net +76 |
| Movement | Charges with odds: sweet spot (55-75%) | 48 of 330, net +74 | 64 of 404, net +83 | 73 of 410, net +48 | 84 of 414, net +98 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 52 of 330, net +108 | 31 of 404, net +75 | 58 of 410, net +82 | 28 of 414, net +55 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 128 of 330, net +95 | 155 of 404, net +136 | 158 of 410, net +92 | 158 of 414, net +133 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.9 | 9.8 | 9.0 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (533 of 971) | 37% (89 of 239) | 53% (504 of 956) | 41% (89 of 219) |
| Shooting | Points destroyed by shooting units | 74.8 | 36.4 | 72.7 | 42.6 |
| Shooting | War machine shots | 6.7 | 1.7 | 6.6 | 1.5 |
| Shooting | Points destroyed by war machines | 73.7 | 15.3 | 96.1 | 16.6 |
| Magic | Magic missiles cast | 1.9 | 1.1 | 1.7 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (106 of 275) | 33% (52 of 159) | 32% (80 of 250) | 36% (59 of 162) |
| Magic | Wounds caused by magic missiles | 3.9 | 1.6 | 3.6 | 1.6 |
| Magic | Wounds caused by other spells | 1.4 | 0.8 | 2.1 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 68.5 | 23.4 | 76.5 | 32.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.8 / 0.1 | 1.7 / 0.5 / 0.3 / 0.2 | 1.1 / 0.4 / 0.9 / 0.1 | 1.9 / 0.4 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 323.1 | 405.9 | 391.3 | 391.9 |
| Combat | Points run down | 80.7 | 93.2 | 73.3 | 140.2 |
| Combat | Net points per charged fight, damage counted | +80 | +90 | +85 | +91 |
| Combat | Net per 100 charger points, damage counted | +28.5 | +31.5 | +30.3 | +30.8 |
| Combat | First round won (charged fights) | 72% | 56% | 71% | 59% |
| Combat | Net points per charged fight | +74 | +92 | +80 | +92 |
| Combat | Net points per supported fight / lone fight | +162 / +60 | +126 / +86 | +85 / +80 | +129 / +85 |
| Combat | Charged fights on a top-3 enemy unit | 112 of 369 | 210 of 480 | 146 of 456 | 228 of 495 |
| Game | Points lost | 686.5 | 671.2 | 761.8 | 796.1 |
| Game | VP from objectives | 560.6 | 569.9 | 585.8 | 533.3 |
| Game | Lone holders (player turns) | 2.3 | 2.5 | 2.9 | 2.2 |

A = on:
- Mine won / drew / lost: 53 / 34 / 57 of 144 ended games (of 144); mean margin (Mine - Opponent) -36 VP
- The side that went first won 54 of 110 games with a winner
- Points traded per game (both sides' losses): 1358
- Games not ended: 0; findings 0, warnings 0

B = off:
- Mine won / drew / lost: 60 / 27 / 57 of 144 ended games (of 144); mean margin (Mine - Opponent) +76 VP
- The side that went first won 60 of 117 games with a winner
- Points traded per game (both sides' losses): 1558
- Games not ended: 0; findings 0, warnings 0

## Opponent rules (fired a game, figure / won / lost VP a game)

| Rule | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 (+0 / 0 / 0) | 0.6 (+0 / 0 / 1) | 0.6 (+0 / 0 / 0) | 0.5 (+0 / 0 / 1) |
| ALREADY CARRIED | 0.1 (+0 / 0 / 1) | - | 0.1 (+0 / 2 / 1) | - |
| ARRIVAL HUNT | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 0 / 1) | 0.0 (+0 / 0 / 1) | 0.0 (+1 / 0 / 0) |
| ARTILLERY RE-ROLL WEIGHED | 1.5 (+0 / 0 / 15) | 0.3 (+0 / 0 / 4) | 1.6 (+0 / 0 / 16) | 0.2 (+0 / 0 / 4) |
| BACKUP TARGETS | 1.1 (+8 / 0 / 27) | 1.2 (+12 / 0 / 29) | 0.9 (+7 / 0 / 19) | 0.9 (+11 / 0 / 11) |
| BEST FACING | 1.0 (+43 / 0 / 31) | 0.8 (+42 / 0 / 28) | - | - |
| BEST FIRST | 3.6 (+166 / 102 / 73) | 2.9 (+137 / 68 / 41) | - | - |
| BEST OVERALL | 0.8 (+56 / 0 / 29) | 0.8 (+55 / 0 / 30) | 0.5 (+26 / 0 / 23) | 0.3 (+16 / 0 / 13) |
| BEST PREY | 0.7 (+28 / 20 / 10) | 0.9 (+43 / 12 / 10) | 4.5 (+312 / 195 / 134) | 4.9 (+341 / 188 / 120) |
| BEST PRIZE | 0.1 (-4 / 2 / 7) | 0.1 (+1 / 2 / 3) | 0.0 (-1 / 1 / 0) | 0.0 (+4 / 9 / 1) |
| BIG CHARACTER SAFETY | 0.2 (+0 / 0 / 4) | 0.3 (-2 / 0 / 7) | 0.1 (-0 / 0 / 9) | 0.1 (-1 / 0 / 9) |
| BLOCKED CHARGE HANDED OVER | - | 0.0 (+0 / 1 / 0) | - | - |
| BLOCKED CHARGE SKIPPED | 0.1 (+0 / 1 / 0) | 0.1 (+0 / 3 / 0) | 0.1 (+0 / 6 / 2) | 0.1 (+0 / 10 / 0) |
| BLOCKED WHEEL | 0.5 (+6 / 0 / 4) | 0.5 (+13 / 0 / 9) | 0.4 (+10 / 0 / 5) | 0.4 (+2 / 0 / 3) |
| BOMBING RUN | 0.0 (+1 / 1 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 1 / 0) | 0.0 (+0 / 0 / 0) |
| BOUND ASSAILMENT | 0.0 (+0 / 0 / 1) | 0.0 (+0 / 0 / 1) | 0.0 (+0 / 0 / 5) | - |
| CANNON PLAN MISSED | 0.7 (+0 / 111 / 8) | 0.1 (+0 / 3 / 0) | 0.9 (+0 / 111 / 13) | 0.2 (+0 / 21 / 4) |
| CANNON PLANNED TARGET | 5.4 (+234 / 416 / 66) | 1.2 (+61 / 42 / 14) | 5.3 (+189 / 409 / 91) | 1.0 (+46 / 90 / 18) |
| CANNON SIGHT KEPT | 1.2 (+0 / 0 / 1) | 0.3 (+0 / 0 / 2) | 1.2 (+0 / 0 / 1) | 0.3 (+0 / 0 / 0) |
| CARRIES OUT COUNTER | 0.0 (-1 / 2 / 1) | 0.0 (-2 / 5 / 1) | 0.1 (-2 / 7 / 6) | 0.0 (+0 / 6 / 4) |
| CARRIES OUT SET-UP | 0.1 (-4 / 10 / 9) | 0.1 (-4 / 11 / 5) | 0.1 (-3 / 10 / 1) | 0.1 (-3 / 26 / 6) |
| CAST JOB | 0.4 (+13 / 36 / 4) | 0.2 (+6 / 10 / 0) | 0.7 (+19 / 43 / 22) | 0.5 (+13 / 36 / 18) |
| CASTER AWAY FROM SCREEN | 0.3 (+0 / 0 / 0) | 0.2 (+0 / 0 / 2) | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| CASTING BLOCK | 0.2 (+18 / 6 / 5) | 0.1 (+5 / 5 / 0) | 0.5 (+46 / 32 / 9) | 0.1 (+2 / 4 / 3) |
| CASTS AFTER FRIENDS | 0.8 (+0 / 0 / 28) | 0.4 (+0 / 0 / 10) | 0.6 (+0 / 0 / 23) | 0.3 (+0 / 0 / 8) |
| CASTS FROM BEHIND | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| CATCH FLIERS | 0.0 (+1 / 0 / 0) | - | 0.0 (+1 / 0 / 0) | 0.0 (+0 / 0 / 0) |
| CATCH ODDS | 0.0 (+1 / 0 / 0) | - | 0.0 (+1 / 0 / 0) | 0.0 (+1 / 0 / 0) |
| CHAFF PASSED | 0.3 (-1 / 11 / 4) | 0.2 (-1 / 4 / 2) | 0.2 (-0 / 4 / 7) | 0.2 (-0 / 10 / 3) |
| CHAMPION TAKES THE CHALLENGE | - | 0.0 (+0 / 0 / 4) | 0.0 (+0 / 2 / 1) | 0.0 (+0 / 3 / 0) |
| CHARGE NOW WEIGHED | 0.5 (-51 / 25 / 9) | 0.5 (-70 / 25 / 24) | 0.5 (-42 / 12 / 7) | 0.7 (-62 / 25 / 19) |
| CHARIOT NO STATIC JOB | 0.1 (+0 / 1 / 2) | - | 0.3 (+0 / 9 / 12) | 0.1 (+0 / 0 / 1) |
| CHARIOT WIZARD CAREFUL | 0.1 (-4 / 1 / 3) | 0.1 (-2 / 3 / 4) | 0.1 (-1 / 2 / 0) | 0.1 (-1 / 1 / 0) |
| CHEAP HELPER | 0.1 (+0 / 4 / 2) | 0.2 (+0 / 6 / 4) | 0.1 (+0 / 2 / 1) | 0.1 (+0 / 11 / 3) |
| COMBAT PIVOT | 0.4 (+0 / 12 / 30) | 0.4 (+0 / 20 / 15) | 0.5 (+0 / 32 / 23) | 0.5 (+0 / 27 / 38) |
| CONTINUE AHEAD WEIGHED | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 1) | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) |
| CONVEYANCE SEARCH | 0.9 (+121 / 16 / 32) | 0.4 (+42 / 9 / 10) | 0.6 (+72 / 32 / 28) | 0.3 (+35 / 3 / 21) |
| COUNTER-CHARGE COVER | 11.9 (+988 / 0 / 203) | 9.1 (+884 / 0 / 189) | 8.7 (+662 / 0 / 194) | 6.7 (+551 / 0 / 155) |
| DEFENSIVE ARMY | 0.6 (-0 / 15 / 6) | 0.3 (-0 / 22 / 3) | - | - |
| EDGE GIVE GROUND | 0.1 (+6 / 15 / 3) | 0.2 (+6 / 21 / 6) | 0.1 (+10 / 19 / 3) | 0.2 (+4 / 21 / 7) |
| ELIXIR WORTH | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 0 / 2) | 0.0 (+1 / 0 / 2) |
| ENGINEER BY LORE | 0.1 (+0 / 0 / 0) | - | 0.1 (+0 / 0 / 1) | - |
| FACES THE THREAT | 2.0 (+164 / 0 / 66) | 1.6 (+142 / 0 / 71) | 1.4 (+102 / 0 / 45) | 0.7 (+58 / 0 / 22) |
| FALLBACK BY WORTH | 4.6 (+61 / 0 / 55) | 5.3 (+87 / 0 / 64) | 6.5 (+93 / 0 / 98) | 7.2 (+99 / 0 / 81) |
| FIGHT LIFT | 0.1 (+1 / 4 / 3) | 0.0 (+1 / 1 / 0) | 0.1 (+1 / 7 / 6) | 0.0 (+1 / 7 / 0) |
| FIRE AND FLEE | 0.0 (+0 / 3 / 1) | 0.0 (+0 / 6 / 4) | 0.0 (+3 / 0 / 0) | 0.0 (+0 / 1 / 1) |
| FLANK NOT WEIGHED | 7.3 (+0 / 0 / 156) | 6.8 (+0 / 0 / 160) | 6.4 (+0 / 0 / 176) | 5.5 (+0 / 0 / 159) |
| FOCUS FIRE | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 2 / 1) | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 1 / 0) |
| FOLLOW UP WEIGHED | 1.2 (+150 / 0 / 35) | 1.0 (+169 / 0 / 40) | 1.1 (+153 / 0 / 42) | 1.2 (+180 / 0 / 53) |
| FRIENDS SHOTS CHECKED | 0.2 (+11 / 0 / 13) | 0.1 (+9 / 0 / 7) | 0.3 (+14 / 0 / 9) | 0.2 (+15 / 0 / 8) |
| GIVES UP | 0.6 (-25 / 76 / 12) | 1.2 (-56 / 144 / 45) | 1.2 (-30 / 116 / 35) | 1.4 (-51 / 190 / 72) |
| GIVES UP ITS SCREEN | 0.0 (-0 / 1 / 0) | 0.1 (-1 / 5 / 2) | 0.6 (-7 / 36 / 10) | 1.0 (-21 / 62 / 14) |
| GROUND FLIERS | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 0 / 0) | - |
| HELPER ALREADY ASKED | 0.0 (+0 / 1 / 0) | 0.1 (+0 / 13 / 3) | 0.0 (+0 / 0 / 0) | 0.1 (+0 / 9 / 1) |
| HELPER UNSEEN | 0.2 (+0 / 12 / 7) | 0.4 (+0 / 21 / 14) | 0.2 (+0 / 14 / 1) | 0.3 (+0 / 17 / 15) |
| HILL BY ITS CHANCE | 0.2 (-27 / 0 / 6) | 0.4 (-32 / 0 / 3) | - | - |
| HOLDS AMBUSHERS | 0.4 (+0 / 0 / 0) | 0.7 (+0 / 0 / 0) | 0.4 (+0 / 0 / 0) | 0.7 (+0 / 0 / 0) |
| HORN WORTH | - | 0.0 (+1 / 0 / 0) | - | 0.0 (+1 / 0 / 0) |
| HUNT ADVANCE | 0.1 (+3 / 1 / 1) | 0.2 (+5 / 3 / 3) | 0.1 (+4 / 11 / 1) | 0.1 (+5 / 8 / 6) |
| HUNT DROPPED | 0.0 (+0 / 1 / 1) | 0.1 (+0 / 3 / 2) | 0.0 (+0 / 0 / 0) | 0.1 (+0 / 0 / 2) |
| HUNT IN PAIRS | 0.5 (+23 / 0 / 6) | 0.7 (+32 / 0 / 15) | 0.3 (+17 / 0 / 5) | 0.5 (+19 / 0 / 1) |
| HUNT KEPT | 0.0 (+1 / 0 / 1) | 0.1 (+2 / 2 / 2) | 0.0 (+2 / 5 / 1) | 0.1 (+1 / 9 / 2) |
| HUNT RESULT | 0.1 (+6 / 1 / 2) | 0.2 (+14 / 6 / 4) | 0.1 (+15 / 0 / 2) | 0.2 (+10 / 8 / 4) |
| HUNT THE GUNS | 0.1 (+33 / 2 / 1) | 0.2 (+66 / 8 / 4) | 0.1 (+36 / 11 / 1) | 0.2 (+76 / 21 / 7) |
| INVITES THE FIGHT | 3.9 (+225 / 134 / 59) | 2.7 (+153 / 71 / 56) | - | - |
| JOINT CHARGE PLAN | 0.2 (+11 / 6 / 1) | 0.2 (+12 / 11 / 5) | 0.1 (+4 / 1 / 2) | 0.2 (+8 / 23 / 3) |
| KEEP FALLS | 0.1 (+2 / 0 / 2) | 0.0 (+0 / 0 / 0) | 0.1 (+2 / 0 / 3) | 0.0 (+0 / 0 / 0) |
| KEEPS ITS PREY | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 1 / 0) | 0.3 (+2 / 13 / 13) | 0.2 (+2 / 3 / 7) |
| KEEPS ITS TARGET | 2.0 (+59 / 150 / 46) | 2.7 (+82 / 201 / 81) | 1.7 (+51 / 163 / 24) | 2.1 (+63 / 231 / 71) |
| KEEPS SCOUTS OR AMBUSH | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) |
| KILLS COUNT | 1.7 (+67 / 114 / 41) | 2.0 (+97 / 168 / 38) | 1.9 (+80 / 111 / 42) | 1.9 (+93 / 142 / 61) |
| KILLS COUNT NEXT TURN | 5.4 (+185 / 206 / 80) | 7.4 (+307 / 237 / 144) | 8.5 (+311 / 395 / 201) | 10.7 (+478 / 412 / 252) |
| LINE HITS NO ONE | - | 0.0 (-0 / 0 / 0) | - | - |
| LONE CHARACTER SAFE SPOT | 0.4 (+17 / 19 / 13) | 0.4 (+12 / 13 / 20) | 0.4 (+16 / 8 / 12) | 0.4 (+19 / 7 / 22) |
| LONE WIZARD HOLDS BACK | 0.2 (+0 / 0 / 5) | 0.5 (+0 / 4 / 8) | 0.0 (+0 / 2 / 2) | 0.3 (+0 / 7 / 4) |
| LONE WIZARD KEPT IN | 0.6 (+38 / 0 / 0) | 0.3 (+23 / 0 / 0) | 0.6 (+38 / 0 / 0) | 0.3 (+23 / 0 / 0) |
| LONG SHOT | 0.4 (-5 / 22 / 4) | 0.5 (-2 / 30 / 6) | - | - |
| LOST CHARGE | 3.1 (-55 / 130 / 90) | 2.3 (-42 / 59 / 85) | - | - |
| LURE BY WHAT IT DRAWS | 0.1 (-4 / 0 / 1) | 0.0 (-4 / 0 / 0) | - | - |
| MAKE SURE TOGETHER | 0.7 (+62 / 19 / 13) | 1.0 (+78 / 35 / 22) | 0.8 (+50 / 24 / 10) | 0.8 (+42 / 40 / 24) |
| MANOEUVRE | 0.4 (+16 / 0 / 6) | 0.3 (+11 / 0 / 4) | 0.2 (+10 / 0 / 9) | 0.1 (+3 / 0 / 4) |
| MARCH AT ESCAPER | 0.1 (+0 / 0 / 0) | 0.1 (+1 / 0 / 0) | 0.1 (+1 / 0 / 5) | 0.0 (+0 / 0 / 0) |
| MARCH CHECK | 0.5 (+24 / 0 / 11) | 0.5 (+26 / 0 / 9) | 0.7 (+26 / 0 / 12) | 0.7 (+36 / 0 / 7) |
| MARCH ODDS | 0.2 (+22 / 11 / 3) | 0.2 (+18 / 8 / 0) | 0.8 (+54 / 34 / 24) | 0.6 (+49 / 26 / 15) |
| MARCH OVER CASTS | 0.9 (+66 / 0 / 19) | 0.5 (+33 / 0 / 7) | 0.5 (+42 / 0 / 19) | 0.2 (+20 / 0 / 6) |
| MAX FOR POSITIONING | 6.4 (+248 / 0 / 131) | 6.2 (+256 / 0 / 127) | 4.8 (+179 / 0 / 106) | 4.7 (+178 / 0 / 115) |
| MISSILES IN THE MOVE | 3.9 (+135 / 0 / 90) | 3.3 (+57 / 0 / 58) | 3.8 (+120 / 0 / 86) | 3.2 (+54 / 0 / 73) |
| MISSILES NEXT TURN | 5.1 (+95 / 0 / 112) | 4.1 (+43 / 0 / 81) | 4.7 (+90 / 0 / 112) | 3.7 (+38 / 0 / 84) |
| MODEL FACING | 0.2 (+71 / 0 / 2) | 0.1 (+19 / 0 / 0) | 0.1 (+32 / 0 / 2) | 0.1 (+13 / 0 / 0) |
| MONSTER WIZARD ROAMS | 0.3 (+0 / 25 / 3) | 0.3 (+0 / 14 / 4) | 0.2 (+0 / 9 / 3) | 0.2 (+0 / 12 / 2) |
| MOVE AND CAST | 0.2 (+9 / 0 / 1) | 0.1 (+5 / 0 / 0) | 0.2 (+15 / 0 / 7) | 0.2 (+9 / 0 / 7) |
| MOVE SPELL IN RANGE | 0.3 (+10 / 0 / 7) | 0.0 (+1 / 0 / 2) | 0.1 (+4 / 0 / 9) | 0.0 (+1 / 0 / 2) |
| MOVE SPELL OUT OF RANGE | 0.4 (-26 / 3 / 13) | 0.1 (-5 / 6 / 8) | 0.4 (-33 / 7 / 27) | 0.1 (-4 / 1 / 13) |
| MOVE SPELL SPOT | 0.4 (+0 / 0 / 15) | 0.1 (+0 / 0 / 7) | 0.3 (+0 / 0 / 7) | 0.1 (+0 / 0 / 0) |
| MOVE TO CHARGE | 5.0 (+435 / 206 / 77) | 7.6 (+660 / 273 / 193) | - | - |
| MOVES UNITS SPELL | 0.1 (+3 / 0 / 0) | 0.1 (+1 / 0 / 0) | 0.1 (+3 / 0 / 0) | 0.1 (+1 / 0 / 0) |
| NEEDED THERE | 0.0 (+5 / 4 / 0) | 0.1 (+8 / 13 / 0) | 0.1 (+5 / 7 / 0) | 0.1 (+5 / 7 / 0) |
| NO RALLY LEFT | 0.0 (+4 / 0 / 1) | 0.0 (+0 / 0 / 0) | 0.0 (+4 / 0 / 0) | 0.0 (+0 / 0 / 1) |
| NOT NEEDED | 0.2 (-12 / 22 / 2) | 0.3 (-16 / 31 / 4) | 0.2 (-9 / 18 / 3) | 0.3 (-17 / 32 / 3) |
| NOT TURNED | 7.4 (+169 / 0 / 127) | 7.3 (+139 / 0 / 147) | 6.3 (+107 / 0 / 151) | 6.3 (+86 / 0 / 141) |
| NOT WORTH A CAST | 0.7 (-0 / 0 / 13) | 0.5 (-0 / 0 / 0) | 0.7 (-0 / 0 / 15) | 0.4 (-0 / 0 / 5) |
| OFF BEST | 15.7 (-797 / 12 / 207) | 14.7 (-805 / 19 / 245) | 17.2 (-872 / 34 / 283) | 17.6 (-1018 / 44 / 342) |
| OPENS A LANE | 0.3 (+2 / 47 / 11) | 0.1 (+1 / 4 / 1) | 0.2 (+1 / 12 / 0) | 0.1 (+1 / 7 / 1) |
| OPENS UP | 0.2 (+15 / 11 / 5) | 0.2 (+15 / 8 / 2) | 0.2 (+21 / 14 / 3) | 0.3 (+22 / 15 / 7) |
| OVERRUN THREAT | - | 0.0 (+1 / 0 / 0) | - | 0.0 (+1 / 0 / 2) |
| OVERRUNS AWAY | 0.5 (+17 / 50 / 24) | 0.6 (+13 / 57 / 17) | 0.6 (+14 / 48 / 13) | 0.6 (+8 / 56 / 30) |
| PATHS CROSS | 2.6 (+204 / 0 / 37) | 3.2 (+283 / 0 / 38) | 2.2 (+146 / 0 / 42) | 2.8 (+216 / 0 / 57) |
| PERIAPT WORTH | 0.0 (+3 / 0 / 4) | 0.0 (+2 / 0 / 0) | 0.0 (+2 / 0 / 4) | 0.0 (+3 / 0 / 8) |
| PIVOT GUARDS FLANK | 0.2 (-3 / 0 / 11) | 0.2 (-3 / 0 / 6) | 0.1 (-2 / 0 / 7) | 0.1 (-4 / 0 / 4) |
| PLAN RESULT | 38.9 (+1243 / 1455 / 881) | 39.9 (+1010 / 1304 / 959) | 37.4 (+1499 / 1366 / 1022) | 38.0 (+1306 / 1270 / 1108) |
| PURSUES BIG PREY | 0.1 (-4 / 0 / 0) | 0.1 (-11 / 0 / 0) | 0.1 (-13 / 0 / 5) | 0.1 (-8 / 0 / 4) |
| PURSUES ON | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | - | 0.0 (+0 / 0 / 1) |
| RAIDS THE BAGGAGE | 0.0 (+1 / 0 / 1) | 0.0 (+4 / 0 / 0) | - | 0.0 (+1 / 0 / 0) |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 (+9 / 0 / 1) | 0.1 (+5 / 0 / 1) | 0.1 (+6 / 0 / 0) | 0.1 (+7 / 0 / 1) |
| RANDOM MOVE BY FIGURES | 0.9 (+16 / 0 / 24) | 1.8 (+22 / 0 / 41) | - | - |
| RANDOM MOVER NO PROMISE | 0.3 (-17 / 9 / 4) | 0.4 (-21 / 15 / 6) | - | - |
| REDIRECT BY WHAT IT STOPS | 0.1 (-3 / 0 / 1) | 0.4 (-0 / 0 / 3) | - | - |
| REDIRECT COUNTER | 2.3 (+185 / 0 / 41) | 4.4 (+434 / 0 / 67) | 2.9 (+147 / 0 / 48) | 4.3 (+289 / 0 / 77) |
| REDIRECT WEIGHED | 0.3 (+4 / 4 / 7) | 0.3 (+5 / 5 / 4) | 0.2 (+6 / 4 / 2) | 0.4 (+19 / 18 / 11) |
| RESERVE FALL BACK | 0.5 (+18 / 0 / 4) | 0.8 (+28 / 0 / 18) | - | - |
| RESTRAINS TO SHOOT | 0.1 (+4 / 0 / 6) | 0.1 (+2 / 0 / 6) | 0.1 (+6 / 0 / 10) | 0.1 (+4 / 0 / 0) |
| RISK BY ARC | 2.5 (+104 / 209 / 75) | 2.9 (+64 / 254 / 77) | 2.8 (+102 / 242 / 64) | 2.7 (+47 / 270 / 126) |
| SAFE SURE CHARGE | - | 0.0 (-0 / 0 / 0) | - | - |
| SAFER THAN THE JOB | 1.2 (+80 / 0 / 22) | 0.8 (+50 / 0 / 20) | 0.9 (+48 / 0 / 17) | 0.7 (+49 / 0 / 22) |
| SCOUT SPOT | 0.4 (+1 / 0 / 0) | 0.3 (+1 / 0 / 1) | 0.4 (+1 / 0 / 1) | 0.3 (+1 / 0 / 1) |
| SCOUT WAITS | 0.4 (+0 / 0 / 0) | 0.3 (+0 / 0 / 1) | 0.4 (+0 / 0 / 1) | 0.3 (+0 / 0 / 1) |
| SCREEN BY WHAT IT SAVES | 0.1 (-4 / 0 / 0) | 0.2 (-11 / 0 / 2) | - | - |
| SEARCH SPOT | 3.6 (+178 / 0 / 45) | 4.2 (+229 / 0 / 47) | 1.7 (+90 / 0 / 38) | 1.8 (+111 / 0 / 33) |
| SECOND HUNTER | 0.0 (-0 / 0 / 0) | 0.0 (-0 / 0 / 0) | 0.0 (-0 / 1 / 0) | 0.0 (-0 / 3 / 1) |
| SELF MOVE SPELL | 0.3 (+43 / 0 / 25) | 0.3 (+23 / 0 / 0) | 0.3 (+24 / 0 / 12) | 0.2 (+20 / 0 / 10) |
| SET UP TOGETHER | 1.1 (+124 / 40 / 22) | 1.9 (+172 / 53 / 33) | 1.1 (+68 / 30 / 18) | 1.5 (+87 / 66 / 41) |
| SET-UP ANY TARGET | 0.4 (+71 / 0 / 9) | 0.2 (+26 / 9 / 8) | 0.3 (+53 / 21 / 7) | 0.1 (+10 / 3 / 6) |
| SET-UP MISSED | 0.1 (+7 / 0 / 8) | 0.0 (+6 / 1 / 0) | 0.1 (+9 / 2 / 0) | 0.0 (+7 / 0 / 4) |
| SHOOTER COUNTED ONCE | - | 0.0 (-0 / 0 / 0) | - | - |
| SHOOTERS IN TWO RANKS | 0.4 (+1 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.4 (+1 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| SHOOTS FROM THE BEST SPOT | 0.6 (+29 / 35 / 11) | 0.4 (+22 / 21 / 3) | - | - |
| SHORT GUN FORWARD | 0.2 (+0 / 0 / 1) | 0.1 (+0 / 0 / 2) | 0.2 (+0 / 0 / 2) | 0.1 (+0 / 0 / 1) |
| SHOT REPLANNED | 0.7 (+0 / 152 / 8) | 0.2 (+0 / 19 / 4) | 0.6 (+0 / 126 / 8) | 0.3 (+0 / 26 / 3) |
| SHOTS IN THE MOVE | 15.4 (+700 / 0 / 206) | 9.4 (+274 / 0 / 127) | 13.5 (+585 / 0 / 228) | 8.6 (+263 / 0 / 150) |
| SPELL CATCH ODDS | 0.0 (-0 / 0 / 3) | 0.0 (-0 / 0 / 2) | 0.0 (-1 / 5 / 1) | 0.0 (-1 / 0 / 0) |
| SPELL SETS UP CHARGE | 0.6 (+111 / 4 / 12) | 0.2 (+43 / 9 / 8) | 0.4 (+62 / 27 / 13) | 0.1 (+25 / 3 / 6) |
| SPELL WORTH | 1.2 (+20 / 63 / 69) | 2.0 (+39 / 78 / 74) | 1.2 (+22 / 82 / 77) | 2.1 (+34 / 67 / 59) |
| STABLE ROLE | 11.6 (+0 / 397 / 146) | 10.7 (+0 / 274 / 151) | - | - |
| STANDS TO CAST | 0.0 (+1 / 1 / 1) | 0.0 (+2 / 0 / 0) | 0.0 (+1 / 0 / 5) | 0.0 (+2 / 0 / 0) |
| STAY WEIGHED | 0.0 (+0 / 0 / 0) | 0.0 (+2 / 0 / 0) | - | - |
| STOPS | 0.0 (+1 / 1 / 1) | 0.1 (+5 / 7 / 3) | 0.0 (+1 / 2 / 1) | 0.1 (+2 / 14 / 3) |
| STOPS SHORT OF THE FLANK | 0.6 (+23 / 0 / 27) | 0.4 (+19 / 0 / 8) | 0.4 (+25 / 0 / 20) | 0.4 (+17 / 0 / 11) |
| STUCK PIVOT | 0.1 (+0 / 0 / 2) | 0.2 (+0 / 0 / 6) | 0.2 (+0 / 0 / 2) | 0.2 (+0 / 0 / 10) |
| SUPPORT JOB KEPT | - | - | 0.0 (+0 / 3 / 0) | 0.0 (+0 / 2 / 0) |
| SUPPORTS | 7.5 (+361 / 270 / 115) | 9.0 (+364 / 256 / 114) | - | - |
| SURE CHARGE BEATS ADVANCE | 0.2 (-12 / 21 / 2) | 0.3 (-19 / 24 / 8) | 0.2 (-12 / 21 / 7) | 0.2 (-9 / 11 / 4) |
| SURE REACH TOGETHER | 0.4 (+1 / 1 / 3) | 0.5 (+5 / 5 / 27) | 0.5 (-3 / 13 / 10) | 0.6 (+1 / 3 / 13) |
| THROUGH LINE OF FIRE | 0.3 (+16 / 0 / 7) | 0.2 (+13 / 0 / 1) | 0.4 (+12 / 0 / 13) | 0.3 (+7 / 0 / 0) |
| TURN WORTH | 0.4 (-25 / 26 / 6) | 0.2 (-11 / 15 / 5) | 0.5 (-34 / 38 / 10) | 0.3 (-20 / 22 / 8) |
| TWO OR MORE ARRIVE | 0.3 (+2 / 6 / 8) | 0.4 (+3 / 7 / 8) | 0.3 (+3 / 5 / 2) | 0.4 (+2 / 10 / 15) |
| WALKS TO THE FIGHT | 1.8 (+84 / 47 / 23) | 1.0 (+40 / 32 / 18) | - | - |
| WAR ENGINE JOBS | 1.1 (+0 / 39 / 16) | 0.4 (+0 / 12 / 7) | - | - |
| WEARS DOWN | 1.0 (+43 / 114 / 40) | 1.6 (+57 / 136 / 61) | 1.0 (+53 / 118 / 35) | 1.4 (+47 / 171 / 70) |
| WHO HITS BACK | 0.3 (+26 / 0 / 16) | 0.3 (+23 / 0 / 8) | 0.3 (+23 / 0 / 15) | 0.2 (+18 / 0 / 8) |
| WHOLE FIGHT | 0.1 (+3 / 20 / 1) | 0.3 (+7 / 46 / 6) | 0.3 (+17 / 52 / 7) | 0.4 (+22 / 71 / 9) |
| WHOLE FIGHT GAIN | 0.3 (+42 / 27 / 8) | 0.6 (+49 / 64 / 19) | 0.2 (+14 / 20 / 3) | 0.5 (+38 / 43 / 12) |
| WOUNDED STAYS OUT | 0.0 (+0 / 7 / 0) | 0.0 (+0 / 1 / 0) | - | - |

A = on, B = off.

## Rule changes (changed a game, VP a change)

| Rule | A | B |
| --- | --- | --- |
| ADVANCE LANE KEPT | 1.27 (+0.0) | 1.13 (+0.0) |
| ALREADY CARRIED | - | - |
| ARRIVAL HUNT | 0.00 (-) | 0.00 (-) |
| ARTILLERY RE-ROLL WEIGHED | 1.80 (+0.0) | 1.76 (+0.0) |
| BACKUP TARGETS | 0.10 (+5.1) | 0.12 (+6.7) |
| BEST FACING | 1.76 (+48.5) | - |
| BEST FIRST | 6.57 (+46.1) | - |
| BEST OVERALL | 1.54 (+72.0) | 0.74 (+57.0) |
| BEST PREY | 0.44 (+39.1) | 4.16 (+45.8) |
| BEST PRIZE | 0.12 (-74.1) | 0.06 (-43.8) |
| BIG CHARACTER SAFETY | 0.49 (-3.0) | 0.24 (-3.2) |
| BLOCKED CHARGE HANDED OVER | 0.01 (+60.4) | - |
| BLOCKED CHARGE SKIPPED | 0.13 (+0.0) | 0.17 (+0.0) |
| BLOCKED WHEEL | 0.99 (+18.9) | 0.78 (+14.7) |
| BOMBING RUN | 0.04 (+30.2) | 0.03 (+36.9) |
| BOUND ASSAILMENT | 0.01 (+0.2) | 0.04 (+0.1) |
| CANNON PLAN MISSED | 0.00 (-) | 0.00 (-) |
| CANNON PLANNED TARGET | 1.13 (-8.0) | 1.06 (-11.5) |
| CANNON SIGHT KEPT | 1.53 (+0.0) | 1.50 (+0.0) |
| CARRIES OUT COUNTER | 0.04 (-79.3) | 0.01 (-109.5) |
| CARRIES OUT SET-UP | 0.10 (-81.1) | 0.08 (-83.0) |
| CAST JOB | 0.32 (+23.0) | 0.71 (+16.6) |
| CASTER AWAY FROM SCREEN | 0.46 (+0.0) | 0.39 (+0.0) |
| CASTING BLOCK | 0.22 (+41.2) | 0.44 (+51.1) |
| CASTS AFTER FRIENDS | - | - |
| CASTS FROM BEHIND | 0.33 (+0.0) | 0.33 (+0.0) |
| CATCH FLIERS | - | - |
| CATCH ODDS | 0.01 (-20.1) | 0.04 (-20.0) |
| CHAFF PASSED | 0.50 (-3.6) | 0.41 (-2.4) |
| CHAMPION TAKES THE CHALLENGE | 0.00 (-) | 0.01 (+0.0) |
| CHARGE NOW WEIGHED | 1.08 (+124.4) | 1.13 (+67.5) |
| CHARIOT NO STATIC JOB | 0.03 (-36.6) | 0.31 (-144.1) |
| CHARIOT WIZARD CAREFUL | 0.00 (-) | 0.00 (-) |
| CHEAP HELPER | - | - |
| COMBAT PIVOT | 0.81 (+0.0) | 1.01 (+0.0) |
| CONTINUE AHEAD WEIGHED | 0.01 (+0.0) | 0.02 (+0.0) |
| CONVEYANCE SEARCH | - | - |
| COUNTER-CHARGE COVER | 5.76 (+62.4) | 3.23 (+57.4) |
| DEFENSIVE ARMY | 0.10 (-27.9) | - |
| EDGE GIVE GROUND | 0.08 (+36.9) | 0.07 (+55.1) |
| ELIXIR WORTH | 0.04 (+20.9) | 0.05 (+54.5) |
| ENGINEER BY LORE | 0.00 (-) | 0.00 (-) |
| FACES THE THREAT | 3.65 (+84.1) | 2.10 (+76.3) |
| FALLBACK BY WORTH | 2.38 (+62.2) | 3.10 (+62.0) |
| FIGHT LIFT | - | - |
| FIRE AND FLEE | 0.08 (+11.7) | 0.04 (+77.5) |
| FLANK NOT WEIGHED | - | - |
| FOCUS FIRE | 0.04 (+39.1) | 0.04 (+21.9) |
| FOLLOW UP WEIGHED | 2.22 (+144.0) | 2.31 (+144.1) |
| FRIENDS SHOTS CHECKED | 0.38 (+55.8) | 0.48 (+59.7) |
| GIVES UP | 0.03 (+28.0) | 0.05 (+19.4) |
| GIVES UP ITS SCREEN | 0.00 (-) | 0.01 (+7.3) |
| GROUND FLIERS | - | - |
| HELPER ALREADY ASKED | - | - |
| HELPER UNSEEN | 0.00 (-) | 0.00 (-) |
| HILL BY ITS CHANCE | 0.00 (-) | - |
| HOLDS AMBUSHERS | 1.10 (+0.0) | 1.10 (+0.0) |
| HORN WORTH | 0.03 (+19.4) | 0.03 (+20.9) |
| HUNT ADVANCE | 0.07 (+27.9) | 0.10 (+42.6) |
| HUNT DROPPED | - | - |
| HUNT IN PAIRS | 0.35 (+40.5) | 0.14 (+52.2) |
| HUNT KEPT | - | - |
| HUNT RESULT | - | - |
| HUNT THE GUNS | - | - |
| INVITES THE FIGHT | 2.69 (+42.2) | - |
| JOINT CHARGE PLAN | 0.10 (+55.7) | 0.03 (+44.1) |
| KEEP FALLS | 0.12 (+40.7) | 0.14 (+32.1) |
| KEEPS ITS PREY | 0.00 (-) | 0.06 (+9.8) |
| KEEPS ITS TARGET | 0.90 (+16.1) | 0.91 (+17.9) |
| KEEPS SCOUTS OR AMBUSH | 0.06 (+0.0) | 0.06 (+0.0) |
| KILLS COUNT | 1.23 (+36.3) | 1.11 (+43.0) |
| KILLS COUNT NEXT TURN | 3.21 (+32.0) | 5.51 (+36.3) |
| LINE HITS NO ONE | 0.02 (+4.3) | - |
| LONE CHARACTER SAFE SPOT | - | - |
| LONE WIZARD HOLDS BACK | 0.11 (-45.9) | 0.10 (-27.6) |
| LONE WIZARD KEPT IN | 0.89 (+69.3) | 0.88 (+68.9) |
| LONG SHOT | 0.11 (+8.7) | - |
| LOST CHARGE | 0.22 (+18.2) | - |
| LURE BY WHAT IT DRAWS | 0.00 (-) | - |
| MAKE SURE TOGETHER | 0.51 (+76.3) | 0.54 (+44.1) |
| MANOEUVRE | 0.64 (+42.2) | 0.35 (+37.4) |
| MARCH AT ESCAPER | - | - |
| MARCH CHECK | 0.89 (+58.2) | 1.23 (+52.0) |
| MARCH ODDS | 0.45 (+22.8) | 1.30 (+22.1) |
| MARCH OVER CASTS | 0.00 (-) | 0.00 (-) |
| MAX FOR POSITIONING | 1.56 (+14.6) | 1.28 (+10.1) |
| MISSILES IN THE MOVE | 0.78 (+24.5) | 0.85 (+23.7) |
| MISSILES NEXT TURN | 0.19 (+4.4) | 0.15 (+10.7) |
| MODEL FACING | 0.32 (+283.4) | 0.21 (+214.1) |
| MONSTER WIZARD ROAMS | 0.00 (-) | 0.00 (-) |
| MOVE AND CAST | 0.28 (+51.4) | 0.40 (+58.7) |
| MOVE SPELL IN RANGE | 0.02 (+2.5) | 0.01 (+10.5) |
| MOVE SPELL OUT OF RANGE | - | - |
| MOVE SPELL SPOT | - | - |
| MOVE TO CHARGE | 6.71 (+65.8) | - |
| MOVES UNITS SPELL | 0.17 (+23.4) | 0.17 (+23.4) |
| NEEDED THERE | 0.09 (+0.0) | 0.09 (+0.0) |
| NO RALLY LEFT | 0.06 (+48.0) | 0.05 (+49.6) |
| NOT NEEDED | 0.00 (-) | 0.00 (-) |
| NOT TURNED | 0.00 (-) | 0.00 (-) |
| NOT WORTH A CAST | - | - |
| OFF BEST | 30.37 (-52.8) | 34.82 (-54.3) |
| OPENS A LANE | 0.03 (+21.2) | 0.01 (+5.6) |
| OPENS UP | 0.22 (+38.9) | 0.26 (+48.2) |
| OVERRUN THREAT | - | - |
| OVERRUNS AWAY | 0.22 (+34.2) | 0.15 (+27.4) |
| PATHS CROSS | 5.76 (+84.5) | 4.96 (+73.0) |
| PERIAPT WORTH | 0.06 (+86.8) | 0.07 (+78.5) |
| PIVOT GUARDS FLANK | 0.34 (-19.1) | 0.23 (-24.6) |
| PLAN RESULT | - | - |
| PURSUES BIG PREY | 0.18 (-83.0) | 0.22 (-98.1) |
| PURSUES ON | 0.02 (+5.8) | 0.02 (+4.8) |
| RAIDS THE BAGGAGE | 0.02 (+161.1) | 0.01 (+142.6) |
| RAIDS THE BAGGAGE NEXT TURN | 0.15 (+54.1) | 0.10 (+38.5) |
| RANDOM MOVE BY FIGURES | 1.60 (+23.4) | - |
| RANDOM MOVER NO PROMISE | 0.00 (-) | - |
| REDIRECT BY WHAT IT STOPS | 0.03 (+30.6) | - |
| REDIRECT COUNTER | 1.83 (+100.3) | 0.94 (+65.9) |
| REDIRECT WEIGHED | 0.59 (+52.0) | 0.57 (+53.4) |
| RESERVE FALL BACK | 1.35 (+33.7) | - |
| RESTRAINS TO SHOOT | 0.15 (+40.5) | 0.24 (+38.3) |
| RISK BY ARC | 1.47 (+34.0) | 1.27 (+35.2) |
| SAFE SURE CHARGE | 0.01 (-42.9) | - |
| SAFER THAN THE JOB | 1.90 (+68.3) | 1.58 (+61.2) |
| SCOUT SPOT | 0.00 (-) | 0.00 (-) |
| SCOUT WAITS | 0.72 (+0.0) | 0.72 (+0.0) |
| SCREEN BY WHAT IT SAVES | 0.01 (+35.8) | - |
| SEARCH SPOT | 7.78 (+52.6) | 3.46 (+58.2) |
| SECOND HUNTER | 0.00 (-) | 0.00 (-) |
| SELF MOVE SPELL | - | - |
| SET UP TOGETHER | 1.26 (+85.7) | 1.09 (+52.0) |
| SET-UP ANY TARGET | - | - |
| SET-UP MISSED | - | - |
| SHOOTER COUNTED ONCE | 0.00 (-) | - |
| SHOOTERS IN TWO RANKS | 0.59 (+2.2) | 0.56 (+2.0) |
| SHOOTS FROM THE BEST SPOT | 0.52 (+40.5) | - |
| SHORT GUN FORWARD | 0.25 (+0.0) | 0.25 (+0.0) |
| SHOT REPLANNED | 0.93 (+0.0) | 0.87 (+0.0) |
| SHOTS IN THE MOVE | 2.08 (+28.4) | 1.33 (+34.1) |
| SPELL CATCH ODDS | - | - |
| SPELL SETS UP CHARGE | - | - |
| SPELL WORTH | - | - |
| STABLE ROLE | 0.00 (-) | - |
| STANDS TO CAST | 0.06 (+5.7) | 0.06 (-12.3) |
| STAY WEIGHED | 0.03 (+68.4) | - |
| STOPS | 0.03 (+62.5) | 0.02 (+39.2) |
| STOPS SHORT OF THE FLANK | 1.09 (+38.7) | 0.80 (+52.3) |
| STUCK PIVOT | 0.37 (+0.0) | 0.39 (+0.0) |
| SUPPORT JOB KEPT | - | 0.03 (+41.1) |
| SUPPORTS | 9.99 (+27.1) | - |
| SURE CHARGE BEATS ADVANCE | 0.50 (-60.5) | 0.40 (-53.6) |
| SURE REACH TOGETHER | 0.08 (+14.4) | 0.12 (+14.7) |
| THROUGH LINE OF FIRE | 0.53 (+55.2) | 0.71 (+26.7) |
| TURN WORTH | 0.01 (+0.2) | 0.01 (+5.0) |
| TWO OR MORE ARRIVE | 0.03 (+6.0) | 0.01 (+0.6) |
| WALKS TO THE FIGHT | 2.03 (+22.3) | - |
| WAR ENGINE JOBS | 0.49 (-58.9) | - |
| WEARS DOWN | 0.49 (+40.6) | 0.42 (+29.6) |
| WHO HITS BACK | 0.58 (+55.4) | 0.44 (+67.7) |
| WHOLE FIGHT | 0.11 (+34.4) | 0.25 (+91.2) |
| WHOLE FIGHT GAIN | 0.60 (+52.6) | 0.31 (+45.0) |
| WOUNDED STAYS OUT | 0.03 (-73.1) | - |

A = on, B = off.

## Off best figure (times a game, both sides; VP a time)

| Reason | A | B |
| --- | --- | --- |
| AFTERMATH BAND | 0.17 (2.5) | 0.27 (2.6) |
| AFTERMATH NEEDS NEXT CHARGE | 0.12 (28.3) | 0.14 (70.9) |
| BEST PRIZE | 0.12 (74.1) | 0.06 (43.8) |
| BIG CHARACTER SAFETY | 0.22 (14.9) | 0.14 (10.2) |
| BLOCKED WHEEL | 0.22 (38.3) | 0.12 (40.3) |
| CANNON PLANNED TARGET | 0.25 (50.1) | 0.19 (80.9) |
| CARRIES OUT COUNTER | 0.04 (79.3) | 0.01 (109.5) |
| CARRIES OUT SET-UP | 0.10 (81.1) | 0.08 (83.0) |
| CATCH ODDS | 0.01 (20.1) | 0.04 (20.0) |
| CHAFF PASSED | 0.26 (6.7) | 0.23 (4.2) |
| CHARGE NOW WEIGHED | 0.12 (46.2) | 0.24 (35.7) |
| CHARIOT NO STATIC JOB | 0.03 (36.6) | 0.31 (144.1) |
| DEFENSIVE ARMY | 0.10 (27.9) | - |
| FACES THE THREAT | 0.04 (14.6) | 0.02 (11.5) |
| FALLBACK | 1.28 (43.9) | 2.25 (54.5) |
| FALLBACK BY WORTH | 0.01 (22.9) | - |
| FIGHT ORDER BAND | 0.12 (1.9) | 0.10 (1.9) |
| FOLLOW UP WEIGHED | 0.01 (4.6) | 0.01 (3.5) |
| FRIENDS SHOTS CHECKED | 0.01 (4.3) | 0.03 (3.5) |
| JOB FIRST | 26.40 (54.4) | 29.16 (56.5) |
| LONE CHARACTER SAFE SPOT | 0.43 (57.7) | 0.31 (74.5) |
| LONE WIZARD HOLDS BACK | 0.09 (56.4) | 0.06 (48.3) |
| LONG SHOT | 0.01 (14.7) | - |
| MARCH ODDS | 0.05 (12.7) | 0.10 (37.8) |
| MOVE AND CAST | 0.01 (16.7) | - |
| NO REASON | 0.10 (20.0) | - |
| PATHS CROSS | 0.29 (37.6) | 0.32 (31.8) |
| PIVOT GUARDS FLANK | 0.34 (19.1) | 0.23 (24.6) |
| PURSUES BIG PREY | 0.18 (83.0) | 0.22 (98.1) |
| PURSUES ON | 0.01 (4.1) | 0.01 (1.3) |
| REDIRECT WEIGHED | 0.03 (35.2) | 0.02 (27.8) |
| RULE SWITCHED OFF | - | 1.56 (17.5) |
| SAFE SURE CHARGE | 0.01 (42.9) | - |
| SAFER THAN THE JOB | 0.04 (21.8) | 0.03 (8.3) |
| STANDS TO CAST | 0.02 (10.5) | 0.02 (42.3) |
| STOPS SHORT OF THE FLANK | 0.13 (12.9) | 0.08 (10.6) |
| SUPPORT REQUEST | 0.32 (68.2) | 0.24 (92.3) |
| SURE CHARGE BEATS ADVANCE | 0.50 (60.5) | 0.40 (53.6) |
| THROUGH LINE OF FIRE | 0.05 (17.4) | 0.08 (20.1) |
| TURN GATE | 1.42 (40.5) | 0.81 (46.9) |
| WAR ENGINE JOBS | 0.48 (60.6) | - |
| WHO HITS BACK | 0.01 (2.4) | 0.01 (5.0) |
| WOUNDED STAYS OUT | 0.03 (73.1) | - |

A = on, B = off.

## Plans (happened, won of planned)

| Side | Plan | A | B |
| --- | --- | --- | --- |
| Mine | advance | 15% (40%) | 21% (89%) |
| Mine | charge | 56% (76%) | 63% (80%) |
| Mine | close in | 24% (22%) | 27% (47%) |
| Mine | hold | 37% (0%) | 41% (0%) |
| Mine | join | 96% (0%) | 93% (0%) |
| Mine | shoot | 62% (212%) | 63% (231%) |
| Mine | support | 93% (0%) | 88% (0%) |
| Opponent | advance | 14% (45%) | 18% (71%) |
| Opponent | charge | 53% (76%) | 60% (84%) |
| Opponent | close in | 24% (20%) | 27% (44%) |
| Opponent | hold | 32% (0%) | 38% (0%) |
| Opponent | join | 92% (0%) | 93% (0%) |
| Opponent | shoot | 56% (184%) | 64% (254%) |
| Opponent | support | 93% (0%) | 89% (0%) |

A = on, B = off.

## Packages: hunt the guns (per side)

| Batch | Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | Mine | 0.1 | 15 | 1 | 7% | 21% | 0% | 2.0 | 304 | 63 | 21% | 19 |
| A | Opponent | 0.2 | 29 | 2 | 19% | 30% | 0% | 2.2 | 339 | 76 | 30% | 85 |
| B | Mine | 0.1 | 14 | 0 | 14% | 50% | 0% | 2.7 | 375 | 156 | 36% | 20 |
| B | Opponent | 0.2 | 27 | 5 | 18% | 27% | 0% | 2.2 | 413 | 68 | 27% | 104 |

A = on, B = off.

### Battle groups: on

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.9 | 22% | 52% | 10% | 32% | 38% | 5% | 12% | 45% | 0% |
| Mine | REDIRECT COUNTER | 2.3 | 33% | 66% | 12% | 15% | 18% | 3% | 14% | 62% | 3% |
| Opponent | COUNTER-CHARGE COVER | 9.1 | 15% | 66% | 19% | 24% | 31% | 14% | 14% | 41% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 20% | 74% | 15% | 25% | 10% | 1% | 12% | 76% | 1% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Battle groups: off

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.7 | 26% | 48% | 11% | 47% | 38% | 13% | 12% | 37% | 0% |
| Mine | REDIRECT COUNTER | 2.9 | 30% | 69% | 15% | 32% | 16% | 4% | 5% | 73% | 3% |
| Opponent | COUNTER-CHARGE COVER | 6.7 | 20% | 63% | 14% | 46% | 35% | 9% | 12% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 27% | 72% | 16% | 15% | 18% | 1% | 15% | 62% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: on

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 13 | 26 (13) | 26 | 0 | 38 | 23% | 4.4 | 60 (3) | 17 (7) | - | 64 (3) | 16 (7) |
| Mine | Chaff | 139 | 41 (139) | 15 | 25 | 54 | 35% | 2.8 | 46 (69) | 34 (26) | 36 (44) | 52 (90) | 21 (49) |
| Mine | Character | 471 | 45 (471) | 45 | 0 | 36 | 16% | 2.5 | 51 (134) | 51 (215) | 25 (47) | 54 (212) | 44 (184) |
| Mine | Clean-up | 89 | 61 (89) | 30 | 31 | 35 | 38% | 2.9 | 35 (22) | 71 (54) | 88 (13) | 98 (49) | 27 (40) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 10 | 0 (10) | 0 | 0 | 92 | 20% | 1.9 | 0 (3) | 0 (6) | 0 (1) | 0 (9) | 0 (1) |
| Mine | Fast Hammer | 168 | 42 (168) | 25 | 16 | 46 | 25% | 2.8 | 41 (84) | 49 (54) | 31 (30) | 46 (112) | 34 (56) |
| Mine | Fragile | 17 | 47 (17) | 47 | 0 | 76 | 29% | 2.5 | 0 (4) | 79 (9) | 19 (4) | 89 (8) | 8 (9) |
| Mine | Hammer | 227 | 40 (227) | 28 | 12 | 36 | 15% | 2.6 | 25 (53) | 43 (143) | 56 (31) | 40 (145) | 42 (82) |
| Mine | Holder | 111 | 62 (111) | 6 | 56 | 25 | 32% | 3.4 | 58 (34) | 70 (55) | 51 (20) | 69 (66) | 54 (43) |
| Mine | Shooter | 161 | 86 (161) | 33 | 52 | 37 | 1% | 1.7 | 56 (26) | 96 (113) | 69 (22) | 103 (98) | 58 (63) |
| Mine | Support | 12 | 16 (12) | 16 | 0 | 35 | 0% | 3.2 | 0 (4) | 48 (4) | 0 (1) | 0 (4) | 46 (5) |
| Mine | War machine | 223 | 45 (223) | 45 | 0 | 35 | 2% | 1.2 | 50 (53) | 46 (139) | 33 (31) | 51 (43) | 43 (180) |
| Mine | Wizard | 78 | 13 (78) | 13 | 0 | 46 | 9% | 2.2 | 19 (20) | 18 (28) | 16 (11) | 29 (21) | 12 (38) |
| Opponent | Blocker | 5 | 108 (5) | 108 | 0 | 42 | 40% | 4.7 | - | 0 (4) | 412 (1) | 187 (3) | 0 (2) |
| Opponent | Chaff | 289 | 53 (289) | 17 | 36 | 44 | 42% | 2.7 | 51 (123) | 45 (64) | 62 (102) | 58 (210) | 41 (79) |
| Opponent | Character | 405 | 53 (405) | 52 | 1 | 30 | 23% | 2.4 | 63 (160) | 51 (188) | 42 (24) | 56 (231) | 56 (141) |
| Opponent | Clean-up | 61 | 37 (61) | 18 | 19 | 40 | 25% | 3.3 | 6 (22) | 55 (32) | 48 (7) | 39 (39) | 35 (22) |
| Opponent | Early | 3 | 0 (3) | 0 | 0 | 33 | 67% | 5.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | Fast | 2 | 90 (2) | 90 | 0 | 100 | 50% | 2.0 | - | 90 (2) | - | 90 (2) | - |
| Opponent | Fast Hammer | 214 | 39 (214) | 22 | 17 | 45 | 29% | 2.9 | 33 (93) | 39 (78) | 54 (43) | 40 (124) | 37 (90) |
| Opponent | Fragile | 35 | 22 (35) | 22 | 0 | 45 | 26% | 2.6 | 80 (8) | 13 (15) | 0 (11) | 23 (29) | 20 (5) |
| Opponent | Hammer | 243 | 34 (243) | 28 | 6 | 43 | 26% | 3.0 | 38 (69) | 31 (146) | 50 (28) | 35 (151) | 33 (92) |
| Opponent | Holder | 147 | 64 (147) | 9 | 56 | 27 | 44% | 3.4 | 52 (38) | 82 (73) | 34 (34) | 81 (90) | 40 (55) |
| Opponent | Shooter | 129 | 65 (129) | 19 | 46 | 36 | 1% | 1.4 | 40 (34) | 78 (78) | 53 (17) | 73 (76) | 55 (53) |
| Opponent | Support | 15 | 8 (15) | 8 | 0 | 27 | 60% | 3.7 | 0 (4) | 36 (4) | 0 (4) | 0 (3) | 15 (9) |
| Opponent | War machine | 60 | 39 (60) | 39 | 0 | 29 | 12% | 1.3 | 32 (17) | 34 (32) | 60 (11) | 63 (12) | 33 (48) |
| Opponent | Wizard | 106 | 14 (106) | 14 | 0 | 39 | 12% | 2.0 | 4 (47) | 45 (26) | 2 (15) | 24 (49) | 1 (39) |

### Deployment: positions vs output by unit type: off

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 13 | 51 (13) | 51 | 0 | 38 | 31% | 2.8 | 6 (4) | 16 (5) | 182 (4) | 22 (6) | 73 (7) |
| Mine | Chaff | 178 | 47 (178) | 17 | 29 | 65 | 39% | 2.7 | 52 (81) | 34 (32) | 45 (65) | 55 (124) | 28 (54) |
| Mine | Character | 473 | 54 (473) | 54 | 0 | 38 | 16% | 2.4 | 60 (145) | 61 (214) | 35 (33) | 63 (215) | 55 (177) |
| Mine | Clean-up | 61 | 64 (61) | 22 | 42 | 42 | 26% | 3.5 | 45 (26) | 77 (25) | 86 (10) | 80 (33) | 45 (28) |
| Mine | Early | 1 | 140 (1) | 140 | 0 | 0 | 0% | 5.0 | - | 140 (1) | - | - | 140 (1) |
| Mine | Fast | 1 | 67 (1) | 67 | 0 | 0 | 0% | 3.0 | - | 67 (1) | - | - | 67 (1) |
| Mine | Fast Hammer | 167 | 43 (167) | 34 | 9 | 48 | 22% | 2.8 | 43 (93) | 53 (38) | 33 (36) | 43 (120) | 44 (47) |
| Mine | Fragile | 17 | 3 (17) | 3 | 0 | 42 | 18% | 2.9 | 0 (6) | 5 (9) | 0 (2) | 6 (8) | 0 (9) |
| Mine | Hammer | 228 | 38 (228) | 26 | 12 | 46 | 17% | 2.5 | 23 (48) | 43 (145) | 33 (35) | 40 (148) | 35 (80) |
| Mine | Holder | 109 | 79 (109) | 5 | 74 | 26 | 40% | 3.4 | 42 (30) | 101 (61) | 66 (17) | 94 (64) | 59 (44) |
| Mine | Shooter | 161 | 90 (161) | 36 | 54 | 47 | 2% | 1.7 | 66 (35) | 97 (101) | 97 (25) | 111 (100) | 57 (61) |
| Mine | Support | 12 | 13 (12) | 13 | 0 | 28 | 33% | 3.0 | 0 (1) | 0 (5) | 79 (3) | 24 (5) | 8 (4) |
| Mine | War machine | 223 | 55 (223) | 55 | 0 | 40 | 3% | 1.3 | 69 (60) | 51 (139) | 48 (24) | 48 (41) | 57 (182) |
| Mine | Wizard | 76 | 17 (76) | 17 | 0 | 46 | 18% | 2.2 | 24 (20) | 16 (26) | 48 (8) | 54 (19) | 7 (35) |
| Opponent | Blocker | 5 | 475 (5) | 401 | 73 | 16 | 60% | 6.0 | 1127 (2) | 0 (3) | - | 694 (3) | 0 (2) |
| Opponent | Chaff | 325 | 37 (325) | 12 | 25 | 57 | 40% | 2.7 | 33 (125) | 46 (75) | 34 (125) | 44 (233) | 18 (92) |
| Opponent | Character | 405 | 59 (405) | 59 | 0 | 37 | 20% | 2.3 | 73 (163) | 53 (177) | 50 (26) | 67 (227) | 56 (139) |
| Opponent | Clean-up | 43 | 66 (43) | 27 | 40 | 35 | 28% | 2.9 | 24 (17) | 99 (20) | 66 (6) | 65 (28) | 69 (15) |
| Opponent | Early | 3 | 0 (3) | 0 | 0 | 0 | 67% | 5.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 212 | 44 (212) | 28 | 16 | 49 | 25% | 3.0 | 31 (109) | 52 (57) | 69 (46) | 49 (132) | 35 (80) |
| Opponent | Fragile | 33 | 42 (33) | 42 | 0 | 71 | 24% | 2.1 | 0 (3) | 64 (16) | 32 (10) | 35 (22) | 90 (7) |
| Opponent | Hammer | 243 | 26 (243) | 20 | 6 | 53 | 26% | 2.9 | 27 (74) | 25 (141) | 32 (28) | 27 (144) | 25 (99) |
| Opponent | Holder | 135 | 56 (135) | 4 | 51 | 27 | 44% | 3.3 | 26 (38) | 78 (73) | 37 (21) | 73 (71) | 37 (61) |
| Opponent | Shooter | 128 | 68 (128) | 22 | 46 | 44 | 3% | 1.4 | 39 (34) | 85 (79) | 33 (15) | 81 (77) | 49 (51) |
| Opponent | Support | 15 | 0 (15) | 0 | 0 | 38 | 33% | 4.0 | 0 (6) | 0 (5) | 0 (3) | 0 (6) | 0 (8) |
| Opponent | War machine | 60 | 42 (60) | 42 | 0 | 31 | 10% | 1.6 | 52 (15) | 44 (35) | 20 (10) | 71 (10) | 36 (50) |
| Opponent | Wizard | 106 | 23 (106) | 23 | 0 | 38 | 8% | 2.0 | 1 (43) | 71 (28) | 0 (18) | 39 (49) | 9 (40) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0106, L0110, L0114, L0118, L0122, L0126, L0130, L0135, L2429, L2433, L2527, L2531, L2535, L2630, L2634, L2730, L2735 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0425, L0434, L0524, L0624, L0725, L0827, L0926, L0934, L1026, L1034, L1126, L1224, L1327, L1427, L1527, L1625, L1727, L1827, L1927, L2025, L2127, L2227, L2327, L2527, L2634, L2934, L3234 |
| Clockwork Compass | Mine | L1216, L1220, L1224, L1228, L1232 |
| Clockwork Compass | Opponent | L0512, L0612 |
| Elixir of Power | Mine | L1114, L1118, L1122, L1126, L1131, L1135, L1923, L1927, L1932 |
| Elixir of Power | Opponent | L0311, L0319, L0819, L1319, L1519, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1823, L1827, L1831, L1835 |
| Fistful of Laurels | Opponent | L0118, L0218, L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L0533, L0733, L1633, L2033, L2433, L3033, L3133 |
| Invocation of Nehek | Mine | L2429, L2433, L2527, L2531, L2535, L2730, L2735 |
| Invocation of Nehek | Opponent | L0327, L0425, L0524, L0624, L0725, L0827, L1224, L1327, L1427, L1527, L1625, L1727, L1827, L1927, L2025, L2127, L2227, L2327, L2527 |
| Opal Amulet | Mine | L1418, L1422, L1427, L1431, L1435 |
| Opal Amulet | Opponent | L0114, L0214, L1114, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2025, L2029, L2033, L2123, L2127, L2131 |
| Periapt of Soul Exchange | Opponent | L0421, L0520, L0620, L0721, L1021, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0206, L0210, L0214, L0218, L0222, L0226, L0230, L0235, L1114, L1118, L1122, L1126, L1131, L1135, L1216, L1220, L1224, L1228, L1232, L1519, L1523, L1527, L1531, L1535, L3133 |
| Ring of Doom | Opponent | L0102, L0311, L0315, L0512, L0533, L0612, L0733, L0815, L0831, L1131, L1331, L1431, L1531, L1633, L1731, L1831, L2033, L2131, L2231, L2331, L2433, L2531, L3033, L3133 |
| Ring of Jet | Mine | L1013, L1017, L1021, L1026, L1030, L1034, L1114, L1118, L1122, L1126, L1131, L1135, L1216, L1220, L1224, L1228, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311, L0512, L0612, L0810 |
| Standard of the Fell Warrior | Mine | L1314, L1319, L1323, L1327, L1331, L1335 |
| Standard of the Fell Warrior | Opponent | L0413, L0713, L0913, L1013 |
| Storm Daemon (Renegade 2.0) | Mine | L2123, L2127, L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L0721, L1021, L1621, L2021 |
| Twice-Blessed Armour | Mine | L0709, L0713, L0717, L0721, L0725, L0729, L0733, L1013, L1017, L1021, L1026, L1030, L1034 |
| Twice-Blessed Armour | Opponent | L0110, L0210, L0307, L0810 |
| Witch Hunter's Ward | Mine | L0709, L0713, L0717, L0721, L0725, L0729, L0733, L0810, L0815, L0819, L0823, L0827, L0831, L0835 |
| Witch Hunter's Ward | Opponent | L0307, L0508, L0608 |

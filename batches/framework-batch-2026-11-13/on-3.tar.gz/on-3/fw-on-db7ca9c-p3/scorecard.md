# Doctrine scorecard: fw-on-db7ca9c-p3

### Scorecard: fw-on-db7ca9c-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 20 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 1 | 4 | 2 | 2 | 1 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 4 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 0 | 0 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | - | 1 | 1 | 1 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 9 | - | 1 | 0 | 1 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 9 | 3 | 2 | 2 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 475 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 801 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 2 | 4 | 1 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 537 |
| L0725 | 5 | 1 | Mine | yes | - | 5 | 2 | 3 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 2 | 0 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 3 | 0 | 0 | 456 |
| L0922 | 4 | 1 | Mine | no | 4 | 6 | 2 | 0 | 0 | 0 | 0 | 619 |
| L0922 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 5 | 1 | 0 | 1 | 0 | 0 | 479 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 10 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 4 | 2 | 4 | 2 | 1 | 0 | 0 | 314 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 1 | 0 | 0 | 305 |
| L1327 | 1 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 2 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 5 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 7 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 0 | 0 | 0 | 0 | 226 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | yes | 2 | 1 | 5 | 3 | 0 | 0 | 0 | 785 |
| L1731 | 3 | 1 | Mine | no | 0 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 2 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 2 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 403 |
| L2033 | 5 | 1 | Mine | yes | - | 4 | 4 | 5 | 1 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 387 |
| L2223 | 3 | 1 | Opponent | yes | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 2 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 2 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 3 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 3 | 4 | 3 | 2 | 0 | 0 | 0 | 549 |
| **Average** | | | Mine | 28% | 2.3 | 3.2 | 2.2 | 0.9 | 0.3 | 0.0 | 0.0 | 257.2 |
| **Average** | | | Opponent | 31% | 2.9 | 2.5 | 2.7 | 1.8 | 0.6 | 0.0 | 0.0 | 184.8 |

### KPIs: fw-on-db7ca9c-p3

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 57% (104 of 184) | 28% (51 of 182) | 42% (155 of 366) |
| Winner chose to follow up after the loser gave ground |  | 96% (75 of 78); on the table 96% | 100% (47 of 47); on the table 100% | 98% (122 of 125); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (3 of 4); on the table 75% | 73% (8 of 11); on the table 73% | 73% (11 of 15); on the table 73% |
| Winner chose to pursue after the loser fled |  | 69% (20 of 29); on the table 76% | 88% (28 of 32); on the table 91% | 79% (48 of 61); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 88% (98 of 111); on the table 90% | 92% (83 of 90); on the table 93% | 90% (181 of 201); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 31% (105 of 342) | 38% (72 of 192) | 33% (177 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (105 of 227) | 50% (72 of 143) | 48% (177 of 370) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 44% (11 of 25) | 56% (39 of 70) | 53% (50 of 95) |
| Points that never fought | lower | 36% (24690 of 68801) | 36% (25819 of 71990) | 36% (50509 of 140791) |
|   infantry points that never fought | lower | 35% (4924 of 14174) | 50% (7047 of 14220) | 42% (11971 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (163 of 272) | 61% (175 of 285) | 61% (338 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 100% (25 of 25); 1.9 uses a game | 92% (22 of 24); 2.4 uses a game | 96% (47 of 49); 2.2 uses a game |
| Bound items with another spell used |  | 14% (2 of 14); 0.2 uses a game | 50% (3 of 6); 0.1 uses a game | 25% (5 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 47% (16 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33132 of 59391) | 56% (35860 of 64043) | 56% (68992 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (16%) | 0.9 (27%) | 1.9 (19%) |
| MARCHED: its unit marched | 1.8 (27%) | 0.9 (28%) | 2.7 (27%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (2%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.3 (20%) | 0.8 (23%) | 2.1 (21%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (2%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.4 (22%) | 0.6 (17%) | 2.0 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.0 (1%) | 0.4 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.1 | 2.3 | 4.9 | 0.8 | 1.9 |
| not cast | 4.1 | 1.5 | 3.9 | 9.9 | 2.5 | 18.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (2%) | 0.6 (41%) | 0.4 (11%) | 1.9 (19%) | 0.2 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (27%) | 0.5 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.1 (7%) | 0.8 (19%) | 2.1 (21%) | 0.4 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) | 0.1 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 1.1 (27%) | 0.3 (22%) | 0.9 (23%) | 2.0 (20%) | 0.5 (19%) | 2.2 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.1 (9%) | 0.0 (1%) | 0.4 (4%) | 0.1 (4%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (7%) | 0.0 (0%) | 0.1 (1%) | 0.7 (28%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (56%) | 0.2 (13%) | 1.5 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.5 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.7 a game | 1.2 a game |
| stood (cast and not dispelled) | 67% (30 of 45) | 50% (10 of 20) | 62% (40 of 65) |
| the unit moved after it | 83% (25 of 30) | 70% (7 of 10) | 80% (32 of 40) |
| it charged on its next turn | 3% (1 of 30) | 20% (2 of 10) | 8% (3 of 40) |
| the enemy charged it first | 17% (5 of 30) | 0% (0 of 10) | 12% (5 of 40) |
| it fought by the end of its next turn | 7% (2 of 30) | 0% (0 of 10) | 5% (2 of 40) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (4 of 30) | 20% (2 of 10) | 15% (6 of 40) |
| none of these (no charge, no fight, no charge escaped) | 67% (20 of 30) | 60% (6 of 10) | 65% (26 of 40) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (559 of 801) | 63% (392 of 623) | 67% (951 of 1424) |
|   cavalry | 65% (39 of 60) | 64% (74 of 116) | 64% (113 of 176) |
|   character | 66% (69 of 105) | 36% (43 of 119) | 50% (112 of 224) |
|   chariot | 63% (65 of 103) | 74% (23 of 31) | 66% (88 of 134) |
|   infantry | 56% (119 of 211) | 68% (182 of 266) | 63% (301 of 477) |
|   monster | 54% (21 of 39) | 67% (2 of 3) | 55% (23 of 42) |
|   war machine | 87% (246 of 283) | 77% (68 of 88) | 85% (314 of 371) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (38%) | 1.8 (28%) | 4.3 (33%) |
| CHARGED: it charged | 0.6 (9%) | 1.4 (22%) | 2.0 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (8%) | 0.7 (11%) | 1.2 (10%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.1 (16%) | 0.8 (12%) | 1.9 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (2%) | 0.2 (3%) | 0.4 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (17%) | 1.1 (16%) | 2.2 (17%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.2 (3%) | 0.3 (2%) |
| OTHER BAR | 0.4 (5%) | 0.2 (3%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 1.0 | 82% | 5.8 pts | 28 pts |
| character | 3.7 | 1.1 | 83% | 6.1 pts | 23 pts |
| chariot | 2.4 | 0.9 | 76% | 12.9 pts | 32 pts |
| infantry | 12.9 | 4.4 | 75% | 9.0 pts | 116 pts |
| monster | 0.8 | 0.2 | 82% | 4.6 pts | 4 pts |
| war machine | 9.1 | 9.1 | 58% | 30.3 pts | 276 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 5.2 | 4.6 |
| Charges that made contact a game | 3.0 | 3.6 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.79 contact (24 units) | 0.59 declared, 0.53 contact (17 units) | 0.83 declared, 0.68 contact (41 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.75 contact (4 units) | 1.30 declared, 0.70 contact (10 units) | 1.21 declared, 0.71 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.39 contact (221 units) | 0.61 declared, 0.43 contact (267 units) | 0.57 declared, 0.41 contact (488 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (44 of 77) | 53% (8 of 15) | 30% (3 of 10) | 54% (55 of 102) |
| Character in a unit | 83% (24 of 29) | 83% (10 of 12) | 17% (1 of 6) | 74% (35 of 47) |
| Character on its own | 81% (39 of 48) | 59% (26 of 44) | 39% (27 of 69) | 57% (92 of 161) |
| Chariot | 73% (8 of 11) | 92% (11 of 12) | - | 83% (19 of 23) |
| Infantry | 59% (41 of 70) | 67% (28 of 42) | 0% (0 of 5) | 59% (69 of 117) |
| Monster | 50% (17 of 34) | 57% (4 of 7) | - | 51% (21 of 41) |
| Monstrous | 100% (10 of 10) | 55% (6 of 11) | - | 76% (16 of 21) |
| War Machines | 70% (30 of 43) | 50% (1 of 2) | - | 69% (31 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (11 of 11); on the table 100% | 32% (31 of 96) | 34% | 64% (14 of 22) | 100% (6 of 6); 3.2 uses a game | 0% (0 of 2); 0.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (4 of 4); on the table 100% | 44% (16 of 36) | 50% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 61% | 79% (19 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 85% (11 of 13); on the table 85% | 47% (14 of 30) | 41% | 64% (38 of 59) | 0.0 uses a game | 50% (1 of 2); 1.3 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 92% (22 of 24); on the table 92% | 27% (52 of 192) | 47% | 54% (40 of 74) | 94% (17 of 18); 5.8 uses a game | 25% (1 of 4); 0.1 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 82% (9 of 11); on the table 82% | 38% (16 of 42) | 34% | 57% (31 of 54) | 100% (9 of 9); 5.0 uses a game | 25% (3 of 12); 0.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 91% (10 of 11); on the table 100% | - | 42% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 83% (5 of 6); on the table 83% | 67% (4 of 6) | 12% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 100% | 0% (0 of 6) | 15% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 85% (11 of 13); on the table 92% | 17% (2 of 12) | 8% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 83% (5 of 6); on the table 83% | 25% (3 of 12) | 64% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 100% (15 of 15); on the table 100% | 0% (0 of 6) | 37% | 50% (13 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (35 of 40); on the table 88% | 35% (19 of 54) | 26% | 54% (25 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 90% (27 of 30); on the table 90% | 57% (17 of 30) | 26% | 58% (56 of 96) | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (14 of 14); on the table 100% | 25% (3 of 12) | 32% | 71% (44 of 62) | 91% (10 of 11); 7.7 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-on-db7ca9c-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (36) | 42% (34) | 43% (70) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.64 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.19 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.44 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.06 | 1.58 | 3.64 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.08 | 0.67 | 1.75 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.39 | 7.33 | 14.72 |

### Quality by phase: fw-on-db7ca9c-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 58% (72 of 124) | 45% (74 of 163) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (168 of 342) | 59% (111 of 189) |
| Strategy | Close-in objectives charged next turn | 14% (27 of 193) | 16% (38 of 244) |
| Strategy | Support requests answered (helper made contact too) | 53% (8 of 15) | 45% (13 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (4 of 7) | 58% (7 of 12) |
| Strategy | Joined characters whose unit fought | 41% (16 of 39) | 59% (19 of 32) |
| Strategy | Lone characters that fought | 76% (73 of 96) | 75% (76 of 102) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.9 | 1.8 |
| Movement | Points that never moved of their own | 257.2 | 184.8 |
| Movement | Fights charged into per game | 2.6 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 87, net -3 | 18 of 88, net +61 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 87, net +54 | 15 of 88, net +238 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 87, net +94 | 3 of 88, net +50 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 of 87, net +139 | 36 of 88, net +114 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.6 | 10.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (151 of 344) | 48% (188 of 391) |
| Shooting | Points destroyed by shooting units | 58.0 | 33.8 |
| Shooting | War machine shots | 6.8 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (141 of 246) | 40% (33 of 82) |
| Shooting | Points destroyed by war machines | 85.6 | 18.9 |
| Magic | Magic missiles cast | 1.9 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (31 of 69) | 35% (17 of 49) |
| Magic | Wounds caused by magic missiles | 2.8 | 1.9 |
| Magic | Wounds caused by other spells | 2.0 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 64.7 | 20.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.2 / 0.9 / 0.1 | 2.0 / 0.4 / 0.4 / 0.4 |
| Combat | Points destroyed in combat | 337.2 | 341.0 |
| Combat | Points run down | 94.7 | 120.1 |
| Combat | Net points per charged fight, damage counted | +104 | +92 |
| Combat | Net per 100 charger points, damage counted | +36.3 | +34.8 |
| Combat | First round won (charged fights) | 67% | 53% |
| Combat | Net points per charged fight | +95 | +86 |
| Combat | Net points per supported fight / lone fight | +210 / +75 | +14 / +95 |
| Combat | Charged fights on a top-3 enemy unit | 26 of 95 | 46 of 114 |
| Game | Points lost | 667.8 | 678.7 |
| Game | VP from objectives | 511.1 | 546.1 |
| Game | Lone holders (player turns) | 2.3 | 2.9 |

- Mine won / drew / lost: 14 / 8 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -69 VP
- The side that went first won 15 of 28 games with a winner
- Points traded per game (both sides' losses): 1346
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-on-db7ca9c-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 2.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.1 | +0.0 | 0.0 | 11.8 | 0.3 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 1.1 | +9.8 | 0.0 | 15.0 | 0.8 | +6.0 | 0.0 | 27.4 |
| BEST FACING | 1.0 | +46.4 | 0.0 | 18.9 | 0.9 | +30.7 | 0.0 | 26.0 |
| BEST FIRST | 3.5 | +168.8 | 94.5 | 86.6 | 2.6 | +123.2 | 56.4 | 58.4 |
| BEST OVERALL | 0.8 | +60.1 | 0.0 | 24.0 | 0.7 | +50.0 | 0.0 | 19.4 |
| BEST PREY | 0.8 | +38.5 | 27.9 | 12.9 | 0.8 | +37.0 | 13.7 | 11.6 |
| BEST PRIZE | 0.0 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.2 | +0.8 | 0.0 | 0.0 | 0.2 | -1.0 | 0.0 | 0.0 |
| BLOCKED CHARGE HANDED OVER | - | - | - | - | 0.0 | +1.7 | 2.4 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 2.4 | 0.0 |
| BLOCKED WHEEL | 0.6 | +14.1 | 0.0 | 0.0 | 0.6 | +15.9 | 0.0 | 1.9 |
| BOMBING RUN | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 131.1 | 4.6 | 0.2 | +0.0 | 3.9 | 0.0 |
| CANNON PLANNED TARGET | 6.1 | +242.4 | 478.3 | 55.7 | 1.5 | +82.7 | 41.8 | 16.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -15.5 | 27.9 | 23.3 | 0.1 | -2.5 | 0.0 | 3.2 |
| CAST JOB | 0.4 | +14.1 | 23.6 | 2.4 | 0.6 | +14.0 | 21.6 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +7.6 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 31.9 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -0.9 | 5.7 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.5 | 0.0 | 16.6 |
| CHARGE NOW WEIGHED | 0.6 | -62.9 | 43.5 | 6.5 | 0.4 | -36.7 | 19.0 | 11.7 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 15.0 |
| CHEAP HELPER | 0.0 | +0.0 | 2.7 | 0.0 | 0.1 | +0.0 | 2.0 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 26.0 | 25.8 | 0.4 | +0.0 | 3.4 | 7.8 |
| CONVEYANCE SEARCH | 1.1 | +160.1 | 0.0 | 14.6 | 0.5 | +45.2 | 6.6 | 0.0 |
| COUNTER-CHARGE COVER | 11.2 | +916.6 | 0.0 | 181.8 | 9.0 | +881.7 | 0.0 | 179.6 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 4.2 | 2.3 | 0.2 | -0.0 | 5.0 | 13.1 |
| EDGE GIVE GROUND | 0.1 | +7.0 | 15.7 | 10.1 | 0.2 | +5.2 | 11.0 | 4.5 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +151.8 | 0.0 | 54.2 | 1.6 | +169.7 | 0.0 | 83.4 |
| FALLBACK BY WORTH | 4.6 | +62.4 | 0.0 | 35.8 | 4.9 | +100.4 | 0.0 | 36.8 |
| FIGHT LIFT | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +2.4 | 5.9 | 1.7 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 7.4 | +0.0 | 0.0 | 97.5 | 6.6 | +0.0 | 0.0 | 131.8 |
| FOCUS FIRE | - | - | - | - | 0.1 | +3.8 | 3.4 | 0.0 |
| FOLLOW UP WEIGHED | 1.4 | +222.2 | 0.0 | 41.6 | 1.0 | +177.4 | 0.0 | 26.3 |
| FRIENDS SHOTS CHECKED | 0.2 | +8.9 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| GIVES UP | 0.8 | -27.1 | 89.8 | 23.4 | 1.0 | -39.0 | 98.4 | 25.8 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.1 | 12.2 | 4.1 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 1.2 | 0.1 | +0.0 | 14.9 | 3.2 |
| HELPER UNSEEN | 0.3 | +0.0 | 40.5 | 0.0 | 0.5 | +0.0 | 40.4 | 7.5 |
| HILL BY ITS CHANCE | 0.1 | -23.8 | 0.0 | 0.0 | 0.5 | -33.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +9.0 | 0.0 | 2.4 | 0.2 | +5.8 | 3.5 | 4.4 |
| HUNT DROPPED | 0.1 | +0.0 | 4.6 | 1.4 | 0.1 | +0.0 | 0.0 | 1.5 |
| HUNT IN PAIRS | 0.4 | +13.2 | 0.0 | 0.0 | 1.1 | +50.8 | 0.0 | 16.6 |
| HUNT KEPT | 0.1 | +2.2 | 0.0 | 1.5 | 0.1 | +2.1 | 3.5 | 2.9 |
| HUNT RESULT | 0.2 | +6.9 | 4.6 | 4.4 | 0.2 | +25.0 | 3.5 | 4.4 |
| HUNT THE GUNS | 0.2 | +62.7 | 4.6 | 3.8 | 0.2 | +69.5 | 13.7 | 1.5 |
| INVITES THE FIGHT | 3.7 | +225.8 | 142.9 | 48.3 | 2.4 | +158.2 | 55.5 | 49.0 |
| JOINT CHARGE PLAN | 0.4 | +38.4 | 12.4 | 5.0 | 0.2 | +12.0 | 0.0 | 6.4 |
| KEEP FALLS | 0.1 | +1.9 | 0.0 | 7.5 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 4.2 | 0.0 |
| KEEPS ITS TARGET | 2.0 | +60.0 | 159.0 | 63.3 | 2.7 | +80.0 | 202.3 | 76.3 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.7 | +86.4 | 123.0 | 34.8 | 1.8 | +94.9 | 127.8 | 10.1 |
| KILLS COUNT NEXT TURN | 5.8 | +239.3 | 273.5 | 55.5 | 7.6 | +269.2 | 251.1 | 106.5 |
| LONE CHARACTER SAFE SPOT | 0.7 | +37.7 | 32.3 | 0.0 | 0.4 | +13.8 | 8.8 | 17.4 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 11.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 1.7 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +0.4 | 18.3 | 0.0 | 0.3 | -2.6 | 12.7 | 2.8 |
| LOST CHARGE | 3.5 | -67.7 | 123.1 | 89.1 | 2.1 | -34.9 | 29.9 | 81.5 |
| LURE BY WHAT IT DRAWS | 0.0 | -4.7 | 0.0 | 3.1 | 0.0 | -1.4 | 0.0 | 1.5 |
| MAKE SURE TOGETHER | 1.0 | +116.9 | 48.5 | 20.5 | 1.4 | +76.8 | 37.1 | 26.3 |
| MANOEUVRE | 0.4 | +23.1 | 0.0 | 0.8 | 0.3 | +15.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +39.1 | 0.0 | 10.2 | 0.6 | +39.4 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +29.3 | 15.5 | 0.0 | 0.2 | +10.6 | 8.8 | 0.0 |
| MARCH OVER CASTS | 1.1 | +59.6 | 0.0 | 11.1 | 0.6 | +42.2 | 0.0 | 6.5 |
| MAX FOR POSITIONING | 6.2 | +250.3 | 0.0 | 134.6 | 6.2 | +284.7 | 0.0 | 130.4 |
| MISSILES IN THE MOVE | 4.1 | +141.3 | 0.0 | 60.5 | 4.7 | +81.6 | 0.0 | 58.9 |
| MISSILES NEXT TURN | 5.4 | +102.8 | 0.0 | 70.9 | 5.4 | +59.4 | 0.0 | 68.4 |
| MODEL FACING | 0.1 | +61.2 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 63.9 | 10.2 | 0.2 | +0.0 | 0.0 | 6.5 |
| MOVE AND CAST | 0.3 | +19.3 | 0.0 | 0.0 | 0.2 | +10.2 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +12.9 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.4 | -4.1 | 0.0 | 26.1 | 0.1 | -4.6 | 2.9 | 6.5 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 5.6 | +550.5 | 215.8 | 83.3 | 7.8 | +687.1 | 233.4 | 150.0 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.1 | -2.5 | 13.9 | 1.4 | 0.2 | -10.8 | 29.6 | 1.7 |
| NOT TURNED | 7.4 | +143.7 | 0.0 | 115.4 | 7.3 | +174.3 | 0.0 | 115.6 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 19.6 | 0.8 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 15.7 | -848.2 | 0.0 | 161.1 | 14.2 | -747.2 | 18.4 | 229.8 |
| OPENS A LANE | 0.4 | +3.7 | 74.1 | 16.9 | 0.4 | +3.7 | 11.7 | 4.6 |
| OPENS UP | 0.1 | +12.7 | 3.3 | 0.0 | 0.2 | +17.2 | 0.0 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +2.9 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.5 | +25.0 | 60.4 | 15.2 | 0.4 | +17.0 | 23.3 | 14.3 |
| PATHS CROSS | 2.4 | +174.2 | 0.0 | 26.6 | 2.9 | +305.9 | 0.0 | 37.7 |
| PERIAPT WORTH | 0.0 | +2.9 | 0.0 | 0.0 | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -6.2 | 0.0 | 34.9 | 0.2 | -3.6 | 0.0 | 10.5 |
| PLAN RESULT | 38.1 | +1095.8 | 1765.4 | 808.3 | 39.2 | +1125.3 | 1206.7 | 937.9 |
| PURSUES BIG PREY | 0.0 | -4.1 | 0.0 | 0.0 | 0.1 | -14.5 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | 0.0 | +0.1 | 0.0 | 3.4 | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +4.3 | 0.0 | 2.2 |
| RANDOM MOVE BY FIGURES | 0.7 | +7.8 | 0.0 | 5.8 | 1.9 | +21.0 | 0.0 | 70.6 |
| RANDOM MOVER NO PROMISE | 0.2 | -22.7 | 18.4 | 0.0 | 0.5 | -23.0 | 35.7 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.1 | 0.0 | 0.0 | 0.3 | -1.8 | 0.0 | 2.3 |
| REDIRECT COUNTER | 2.1 | +177.0 | 0.0 | 33.0 | 4.5 | +486.0 | 0.0 | 66.9 |
| REDIRECT WEIGHED | 0.3 | +11.2 | 10.9 | 3.1 | 0.4 | +7.4 | 7.2 | 0.0 |
| RESERVE FALL BACK | 0.4 | +12.5 | 0.0 | 0.0 | 1.0 | +27.6 | 0.0 | 12.0 |
| RESTRAINS TO SHOOT | 0.1 | +1.3 | 0.0 | 0.0 | 0.1 | +2.0 | 0.0 | 11.1 |
| RISK BY ARC | 2.5 | +101.6 | 211.9 | 72.7 | 2.4 | +55.9 | 211.8 | 32.5 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.4 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.1 | +83.3 | 0.0 | 10.1 | 0.7 | +60.2 | 0.0 | 11.9 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | -8.6 | 0.0 | 1.8 |
| SEARCH SPOT | 3.8 | +165.2 | 0.0 | 38.0 | 3.6 | +212.4 | 0.0 | 48.7 |
| SELF MOVE SPELL | 0.4 | +82.2 | 0.0 | 40.1 | 0.2 | +65.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.9 | +217.9 | 95.9 | 30.4 | 2.2 | +189.9 | 37.1 | 38.9 |
| SET-UP ANY TARGET | 0.6 | +101.1 | 0.0 | 14.6 | 0.1 | +15.9 | 6.6 | 0.0 |
| SET-UP MISSED | 0.1 | +14.5 | 0.0 | 0.0 | 0.0 | +10.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +30.3 | 38.7 | 5.5 | 0.5 | +26.9 | 18.0 | 0.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 97.3 | 17.2 | 0.2 | +0.0 | 22.6 | 0.0 |
| SHOTS IN THE MOVE | 14.6 | +675.7 | 0.0 | 191.4 | 10.8 | +346.9 | 0.0 | 106.2 |
| SPELL CATCH ODDS | 0.1 | -0.5 | 0.0 | 11.9 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.8 | +167.9 | 0.0 | 14.6 | 0.1 | +15.9 | 6.6 | 0.0 |
| SPELL WORTH | 1.4 | +27.8 | 24.6 | 34.4 | 2.5 | +47.3 | 100.7 | 84.7 |
| STABLE ROLE | 10.4 | +0.0 | 357.9 | 151.1 | 9.7 | +0.0 | 275.6 | 122.8 |
| STAY WEIGHED | - | - | - | - | 0.0 | +4.4 | 0.0 | 0.0 |
| STOPS | 0.1 | +5.2 | 4.6 | 3.0 | 0.1 | +0.6 | 13.7 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +28.7 | 0.0 | 22.9 | 0.4 | +20.6 | 0.0 | 1.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 10.6 |
| SUPPORTS | 6.4 | +324.4 | 248.2 | 72.1 | 8.3 | +354.2 | 288.3 | 129.8 |
| SURE CHARGE BEATS ADVANCE | 0.3 | -21.0 | 31.7 | 1.8 | 0.3 | -16.0 | 33.3 | 2.7 |
| SURE REACH TOGETHER | 0.3 | +0.1 | 5.5 | 0.0 | 0.4 | -0.6 | 0.0 | 10.2 |
| THROUGH LINE OF FIRE | 0.3 | +18.2 | 0.0 | 0.0 | 0.3 | +19.4 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -21.6 | 19.4 | 3.4 | 0.2 | -12.4 | 4.9 | 0.0 |
| TWO OR MORE ARRIVE | 0.4 | +4.7 | 25.2 | 20.5 | 0.4 | +3.5 | 0.0 | 16.5 |
| WALKS TO THE FIGHT | 2.1 | +102.3 | 53.1 | 26.5 | 0.7 | +18.5 | 23.9 | 14.2 |
| WAR ENGINE JOBS | 1.1 | +0.0 | 66.2 | 1.8 | 0.2 | +0.0 | 6.4 | 0.0 |
| WEARS DOWN | 1.1 | +67.4 | 139.5 | 40.1 | 1.2 | +43.8 | 105.3 | 49.6 |
| WHO HITS BACK | 0.2 | +20.3 | 0.0 | 0.0 | 0.2 | +28.9 | 0.0 | 9.4 |
| WHOLE FIGHT | 0.1 | +2.7 | 31.6 | 0.0 | 0.3 | -0.4 | 48.0 | 16.6 |
| WHOLE FIGHT GAIN | 0.3 | +50.1 | 25.4 | 3.8 | 0.7 | +54.1 | 73.3 | 9.0 |

### Rule changes: fw-on-db7ca9c-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1076 | 1076 | 1076 | 29.89 | -57434 | -53.4 |
| SUPPORTS | 530 | 530 | 324 | 9.00 | +8777 | +27.1 |
| SEARCH SPOT | 269 | 269 | 267 | 7.42 | +13762 | +51.5 |
| MOVE TO CHARGE | 481 | 481 | 265 | 7.36 | +18827 | +71.0 |
| BEST FIRST | 221 | 221 | 221 | 6.14 | +10511 | +47.6 |
| COUNTER-CHARGE COVER | 728 | 440 | 193 | 5.36 | +12145 | +62.9 |
| PATHS CROSS | 188 | 188 | 188 | 5.22 | +17285 | +91.9 |
| FACES THE THREAT | 131 | 131 | 131 | 3.64 | +11574 | +88.4 |
| KILLS COUNT NEXT TURN | 481 | 481 | 114 | 3.17 | +2762 | +24.2 |
| INVITES THE FIGHT | 220 | 220 | 100 | 2.78 | +5083 | +50.8 |
| FOLLOW UP WEIGHED | 88 | 88 | 88 | 2.44 | +14386 | +163.5 |
| ARTILLERY RE-ROLL WEIGHED | 86 | 86 | 86 | 2.39 | +0 | +0.0 |
| FALLBACK BY WORTH | 340 | 340 | 80 | 2.22 | +5860 | +73.3 |
| SHOTS IN THE MOVE | 914 | 635 | 73 | 2.03 | +2276 | +31.2 |
| BEST FACING | 68 | 68 | 68 | 1.89 | +2776 | +40.8 |
| WALKS TO THE FIGHT | 99 | 99 | 68 | 1.89 | +1546 | +22.7 |
| MAX FOR POSITIONING | 447 | 278 | 66 | 1.83 | +1079 | +16.3 |
| SET UP TOGETHER | 148 | 127 | 64 | 1.78 | +5011 | +78.3 |
| SAFER THAN THE JOB | 63 | 63 | 63 | 1.75 | +5164 | +82.0 |
| REDIRECT COUNTER | 238 | 138 | 60 | 1.67 | +7417 | +123.6 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| BEST OVERALL | 55 | 55 | 55 | 1.53 | +3962 | +72.0 |
| RISK BY ARC | 175 | 165 | 55 | 1.53 | +1771 | +32.2 |
| RANDOM MOVE BY FIGURES | 95 | 95 | 50 | 1.39 | +1037 | +20.7 |
| RESERVE FALL BACK | 50 | 50 | 50 | 1.39 | +1442 | +28.8 |
| KILLS COUNT | 127 | 122 | 47 | 1.31 | +2195 | +46.7 |
| CANNON PLANNED TARGET | 273 | 273 | 43 | 1.19 | -262 | -6.1 |
| BLOCKED WHEEL | 42 | 42 | 42 | 1.17 | +1080 | +25.7 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| ADVANCE LANE KEPT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| KEEPS ITS TARGET | 168 | 162 | 37 | 1.03 | +544 | +14.7 |
| MARCH CHECK | 48 | 44 | 36 | 1.00 | +2480 | +68.9 |
| MISSILES IN THE MOVE | 317 | 192 | 36 | 1.00 | +759 | +21.1 |
| STOPS SHORT OF THE FLANK | 36 | 36 | 36 | 1.00 | +1775 | +49.3 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +4954 | +141.5 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| SHOT REPLANNED | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 34 | 32 | 28 | 0.78 | +1774 | +63.4 |
| MAKE SURE TOGETHER | 88 | 60 | 25 | 0.69 | +1212 | +48.5 |
| MANOEUVRE | 26 | 26 | 25 | 0.69 | +1390 | +55.6 |
| REDIRECT WEIGHED | 25 | 25 | 25 | 0.69 | +1843 | +73.7 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 45 | 45 | 25 | 0.69 | +909 | +36.4 |
| THROUGH LINE OF FIRE | 23 | 23 | 23 | 0.64 | +1352 | +58.8 |
| SURE CHARGE BEATS ADVANCE | 22 | 22 | 22 | 0.61 | -1332 | -60.5 |
| CAST JOB | 36 | 36 | 21 | 0.58 | +359 | +17.1 |
| MOVE AND CAST | 20 | 20 | 20 | 0.56 | +1062 | +53.1 |
| WEARS DOWN | 84 | 77 | 20 | 0.56 | +912 | +45.6 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +350 | +18.4 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +1026 | +64.1 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | -8 | -0.5 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -42 | -3.0 |
| HUNT IN PAIRS | 53 | 36 | 14 | 0.39 | +636 | +45.5 |
| WAR ENGINE JOBS | 49 | 49 | 14 | 0.39 | -912 | -65.2 |
| BEST PREY | 58 | 58 | 13 | 0.36 | +829 | +63.8 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +357 | +27.4 |
| PIVOT GUARDS FLANK | 13 | 13 | 13 | 0.36 | -350 | -26.9 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| OPENS UP | 12 | 11 | 9 | 0.25 | +346 | +38.4 |
| OVERRUNS AWAY | 32 | 31 | 9 | 0.25 | +303 | +33.7 |
| LOST CHARGE | 202 | 201 | 8 | 0.22 | +95 | +11.8 |
| MISSILES NEXT TURN | 388 | 235 | 7 | 0.19 | +41 | +5.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| CARRIES OUT SET-UP | 11 | 11 | 6 | 0.17 | -650 | -108.3 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +260 | +43.3 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -669 | -111.5 |
| BACKUP TARGETS | 71 | 30 | 5 | 0.14 | +25 | +5.0 |
| GIVES UP | 64 | 60 | 5 | 0.14 | +140 | +28.0 |
| JOINT CHARGE PLAN | 21 | 21 | 5 | 0.14 | +182 | +36.4 |
| LONE WIZARD HOLDS BACK | 20 | 20 | 5 | 0.14 | -395 | -79.1 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +120 | +24.0 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| CASTING BLOCK | 5 | 5 | 4 | 0.11 | +31 | +7.7 |
| DEFENSIVE ARMY | 20 | 20 | 4 | 0.11 | -105 | -26.2 |
| EDGE GIVE GROUND | 10 | 10 | 4 | 0.11 | +121 | +30.2 |
| LONG SHOT | 23 | 23 | 4 | 0.11 | +39 | +9.8 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +2204 | +551.0 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +77 | +19.3 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +73 | +24.3 |
| HUNT ADVANCE | 11 | 11 | 3 | 0.08 | +134 | +44.5 |
| OPENS A LANE | 27 | 12 | 3 | 0.08 | +68 | +22.6 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +26 | +13.2 |
| CHARIOT NO STATIC JOB | 3 | 3 | 2 | 0.06 | -73 | -36.7 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +136 | +67.8 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +17 | +8.7 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +206 | +102.8 |
| STOPS | 7 | 7 | 2 | 0.06 | +12 | +5.9 |
| WHOLE FIGHT | 14 | 14 | 2 | 0.06 | +28 | +14.1 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -86 | -86.2 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +60 | +60.4 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 15 | 8 | 1 | 0.03 | +7 | +7.1 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +6 | +6.1 |
| RAIDS THE BAGGAGE | 2 | 2 | 1 | 0.03 | +144 | +143.7 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -43 | -42.9 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 1 | 0.03 | +33 | +33.4 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +157 | +157.0 |
| TURN WORTH | 17 | 16 | 1 | 0.03 | +0 | +0.2 |
| TWO OR MORE ARRIVE | 30 | 24 | 1 | 0.03 | +5 | +4.6 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 33 | 33 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 56 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 507 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 5 | 5 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 31 | 30 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 23 | 23 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 13 | trace | - | - | - | - |
| HUNT THE GUNS | 14 | trace | - | - | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 39 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 63 | 63 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 21 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 26 | not checked | - | - | - | - |
| NEEDED THERE | 1 | 1 | 0 | 0.00 | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 530 | 530 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 51 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2781 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 27 | 27 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 26 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 34 | not checked | - | - | - | - |
| SPELL WORTH | 140 | not checked | - | - | - | - |
| STABLE ROLE | 725 | 724 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 28 | 22 | 0 | 0.00 | - | - |

### Off best figure: fw-on-db7ca9c-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.86 | 12.19 | 54.7 |
| TURN GATE | gate | 0.56 | 0.86 | 44.2 |
| FALLBACK | gate | 0.64 | 0.53 | 42.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.33 | 0.28 | 60.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.36 | 0.17 | 80.4 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.19 | 26.9 |
| WAR ENGINE JOBS | rule | 0.25 | 0.11 | 70.1 |
| PATHS CROSS | rule | 0.19 | 0.08 | 25.9 |
| SUPPORT REQUEST | gate | 0.11 | 0.17 | 39.5 |
| BLOCKED WHEEL | rule | 0.14 | 0.11 | 19.1 |
| CANNON PLANNED TARGET | rule | 0.06 | 0.11 | 61.0 |
| CARRIES OUT SET-UP | rule | 0.14 | 0.03 | 108.3 |
| CHAFF PASSED | rule | 0.14 | 0.03 | 6.8 |
| PURSUES BIG PREY | rule | 0.03 | 0.14 | 111.5 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 1.8 |
| AFTERMATH BAND | gate | 0.03 | 0.08 | 1.4 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.08 | 20.1 |
| DEFENSIVE ARMY | rule | 0.06 | 0.06 | 26.2 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.08 | 98.9 |
| NO REASON | gate | 0.06 | 0.06 | 26.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 15.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 18.2 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 24.8 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 36.7 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 31.7 |
| BEST PRIZE | rule | 0.03 | - | 86.2 |
| FACES THE THREAT | rule | - | 0.03 | 6.1 |
| SAFE SURE CHARGE | rule | - | 0.03 | 42.9 |
| WHO HITS BACK | rule | - | 0.03 | 0.8 |

### Plans: fw-on-db7ca9c-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.6 | 12% | 746 | 219 | 29% |
| Mine | charge | 2.7 | 58% | 299 | 232 | 78% |
| Mine | close in | 5.3 | 23% | 773 | 125 | 16% |
| Mine | hold | 3.7 | 33% | 255 | 0 | 0% |
| Mine | join | 0.4 | 100% | 7 | 0 | 0% |
| Mine | shoot | 7.8 | 59% | 239 | 519 | 217% |
| Mine | support | 6.6 | 94% | 256 | 0 | 0% |
| Opponent | advance | 12.1 | 15% | 562 | 344 | 61% |
| Opponent | charge | 3.6 | 57% | 400 | 335 | 84% |
| Opponent | close in | 6.8 | 25% | 892 | 238 | 27% |
| Opponent | hold | 3.4 | 26% | 237 | 0 | 0% |
| Opponent | join | 0.6 | 95% | 20 | 0 | 0% |
| Opponent | shoot | 4.1 | 55% | 130 | 210 | 161% |
| Opponent | support | 8.6 | 91% | 273 | 0 | 0% |

### Packages: hunt the guns, fw-on-db7ca9c-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 0 | 17% | 17% | 0% | 2.0 | 376 | 42 | 17% | 27 |
| Opponent | 0.2 | 8 | 1 | 29% | 43% | 0% | 2.3 | 329 | 129 | 43% | 101 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 0 | 20% | 20% | 0% | 2.0 | 360 | 50 | 20% | 47 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 99 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 458 | 0 | 0% | 47 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 42 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 436 | 0 | 0% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 480 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 50% | 0% | 3.0 | 298 | 128 | 50% | 44 |
| Vampire Counts | 0.2 | 2 | 1 | 100% | 100% | 0% | 2.0 | 271 | 235 | 100% | 9 |
| Warriors of Chaos | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 350 | 205 | 50% | 65 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 67 |

### Battle groups: fw-on-db7ca9c-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.2 | 21% | 49% | 7% | 33% | 38% | 4% | 6% | 52% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 32% | 79% | 33% | 0% | 12% | 6% | 31% | 44% | 6% |
| Opponent | COUNTER-CHARGE COVER | 9.0 | 16% | 69% | 24% | 25% | 23% | 13% | 18% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 4.5 | 20% | 81% | 12% | 25% | 7% | 0% | 11% | 82% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-on-db7ca9c-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 34 | 49 (34) | 13 | 35 | 51 | 35% | 3.1 | 60 (21) | 0 (4) | 36 (9) | 59 (24) | 26 (10) |
| Mine | Character | 119 | 47 (119) | 47 | 0 | 31 | 17% | 2.5 | 62 (38) | 49 (54) | 0 (7) | 53 (60) | 50 (39) |
| Mine | Clean-up | 20 | 36 (20) | 18 | 18 | 48 | 30% | 2.8 | 31 (5) | 27 (13) | 168 (2) | 37 (13) | 34 (7) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 45 (44) | 30 | 15 | 42 | 32% | 3.1 | 45 (20) | 32 (18) | 83 (6) | 42 (31) | 51 (13) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 67% | 4.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 50 | 34 (50) | 27 | 7 | 30 | 18% | 2.5 | 27 (11) | 33 (35) | 60 (4) | 43 (34) | 16 (16) |
| Mine | Holder | 25 | 69 (25) | 8 | 60 | 30 | 24% | 3.8 | 66 (8) | 66 (13) | 92 (4) | 83 (14) | 53 (11) |
| Mine | Shooter | 37 | 49 (37) | 14 | 35 | 45 | 3% | 1.8 | 34 (6) | 54 (28) | 30 (3) | 53 (22) | 43 (15) |
| Mine | Support | 4 | 56 (4) | 56 | 0 | 0 | 0% | 3.0 | 0 (1) | 96 (3) | - | 0 (1) | 96 (3) |
| Mine | War machine | 52 | 56 (52) | 56 | 0 | 26 | 0% | 1.2 | 28 (13) | 72 (35) | 0 (4) | 52 (13) | 57 (39) |
| Mine | Wizard | 16 | 4 (16) | 4 | 0 | 67 | 6% | 1.8 | 20 (3) | 0 (4) | 0 (2) | 0 (5) | 17 (4) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 57 (68) | 29 | 28 | 48 | 50% | 2.5 | 55 (29) | 51 (11) | 63 (28) | 41 (48) | 95 (20) |
| Opponent | Character | 101 | 49 (101) | 49 | 0 | 29 | 14% | 2.3 | 48 (36) | 55 (51) | 55 (5) | 50 (50) | 56 (42) |
| Opponent | Clean-up | 10 | 26 (10) | 3 | 24 | 24 | 20% | 3.8 | 0 (4) | 38 (5) | 56 (1) | 14 (6) | 38 (4) |
| Opponent | Fast | 1 | 180 (1) | 180 | 0 | 100 | 0% | 2.0 | - | 180 (1) | - | 180 (1) | - |
| Opponent | Fast Hammer | 59 | 50 (59) | 27 | 23 | 43 | 24% | 2.9 | 56 (28) | 39 (21) | 58 (10) | 69 (26) | 34 (33) |
| Opponent | Fragile | 3 | 62 (3) | 62 | 0 | 33 | 33% | 2.5 | - | 92 (2) | 0 (1) | 46 (2) | 92 (1) |
| Opponent | Hammer | 47 | 25 (47) | 23 | 3 | 42 | 28% | 3.4 | 33 (16) | 24 (28) | 0 (3) | 30 (29) | 17 (18) |
| Opponent | Holder | 42 | 75 (42) | 7 | 68 | 49 | 33% | 2.9 | 74 (11) | 104 (19) | 13 (12) | 83 (29) | 59 (13) |
| Opponent | Shooter | 30 | 40 (30) | 15 | 25 | 33 | 0% | 1.1 | 52 (8) | 31 (20) | 115 (2) | 49 (18) | 29 (12) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | 0 (2) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 47 (17) | 47 | 0 | 29 | 6% | 1.4 | 0 (3) | 64 (10) | 36 (4) | 130 (3) | 32 (14) |
| Opponent | Wizard | 33 | 4 (33) | 4 | 0 | 44 | 9% | 2.2 | 0 (14) | 13 (9) | 0 (2) | 8 (14) | 0 (11) |

### Charged fights: fw-on-db7ca9c-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 53 | 135 | 1.5 | 1.3 | 90 | 0 | +90 | 1 of 6 | 5 of 6 | +187 | +41 |
| Mine | Chaos Dwarfs | 4 | 306 | 225 | 2.0 | 1.0 | 112 | 22 | +90 | 3 of 8 | 6 of 8 | - | +90 |
| Mine | Dwarfen Mountain Holds | 3 | 733 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Empire of Man | 5 | 358 | 128 | 2.2 | 1.3 | 58 | 9 | +49 | 3 of 11 | 9 of 11 | +72 | +40 |
| Mine | Grand Cathay | 5 | 252 | 902 | 3.8 | 1.1 | 237 | 28 | +209 | 6 of 19 | 16 of 19 | +644 | +158 |
| Mine | High Elf Realms | 4 | 99 | 435 | 2.8 | 1.0 | 158 | 0 | +158 | 6 of 11 | 4 of 11 | - | +158 |
| Mine | Kingdom of Bretonnia | 1 | 128 | 570 | 2.0 | 1.0 | 285 | 236 | +50 | 1 of 2 | 1 of 2 | - | +50 |
| Mine | Lizardmen | 1 | 286 | 314 | 3.0 | 1.0 | 105 | 163 | -58 | 1 of 3 | 1 of 3 | - | -58 |
| Mine | Ogre Kingdoms | 1 | 0 | 116 | 3.0 | 1.0 | 39 | 30 | +9 | 1 of 3 | 2 of 3 | - | +9 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 365 | 5.0 | 1.4 | 73 | 11 | +62 | 0 of 5 | 5 of 5 | +55 | +67 |
| Mine | Skaven | 1 | 0 | 19 | 3.0 | 1.0 | 6 | 0 | +6 | 0 of 3 | 1 of 3 | - | +6 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 554 | 4.0 | 1.1 | 138 | 17 | +122 | 2 of 8 | 3 of 8 | +663 | +44 |
| Mine | Vampire Counts | 2 | 0 | 330 | 4.0 | 1.6 | 82 | 56 | +26 | 1 of 8 | 6 of 8 | +50 | +11 |
| Mine | Warriors of Chaos | 2 | 0 | 72 | 3.5 | 1.1 | 21 | 17 | +4 | 1 of 7 | 5 of 7 | +144 | -19 |
| **Mine** | all armies | 36 | 208 | 323 | 2.6 | 1.2 | 122 | 28 | +95 | 26 of 95 | 64 of 95 | +210 | +75 |
| Opponent | Empire of Man | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Grand Cathay | 3 | 399 | 237 | 2.7 | 1.1 | 89 | 26 | +63 | 4 of 8 | 5 of 8 | +84 | +60 |
| Opponent | High Elf Realms | 3 | 0 | 229 | 2.0 | 1.3 | 114 | 10 | +104 | 4 of 6 | 5 of 6 | +105 | +104 |
| Opponent | Kingdom of Bretonnia | 2 | 48 | 224 | 3.0 | 1.0 | 74 | 0 | +74 | 3 of 6 | 3 of 6 | - | +74 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 500 | 7.0 | 1.0 | 71 | 8 | +64 | 1 of 7 | 5 of 6 | - | +64 |
| Opponent | Skaven | 1 | 120 | 0 | 1.0 | 1.0 | 0 | 35 | -35 | 0 of 1 | 1 of 1 | - | -35 |
| Opponent | Tomb Kings of Khemri | 4 | 94 | 415 | 2.8 | 1.2 | 151 | 0 | +151 | 8 of 11 | 8 of 11 | +0 | +184 |
| Opponent | Vampire Counts | 6 | 0 | 528 | 4.2 | 1.2 | 127 | 42 | +85 | 9 of 25 | 12 of 25 | -101 | +120 |
| Opponent | Warriors of Chaos | 9 | 4 | 620 | 3.3 | 1.1 | 186 | 69 | +117 | 13 of 30 | 10 of 30 | +97 | +119 |
| Opponent | Wood Elf Realms | 6 | 135 | 200 | 3.2 | 1.1 | 63 | 39 | +25 | 4 of 19 | 11 of 19 | +48 | +22 |
| **Opponent** | all armies | 36 | 73 | 388 | 3.2 | 1.1 | 122 | 37 | +86 | 46 of 114 | 60 of 113 | +14 | +95 |

### Effective charges: fw-on-db7ca9c-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net +0) | 0 | 0 | 1 (net +165) | 1 (net +45) | 3 (net +110) | 0 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 8 | 1 (net -176) | 0 | 1 (net +0) | 2 (net +361) | 0 | 3 (net +0) | 1 | 14% (1 of 7) |
| Mine | Empire of Man | 11 | 1 (net +68) | 0 | 0 | 2 (net +36) | 3 (net +96) | 5 (net +22) | 0 | 0% (0 of 11) |
| Mine | Grand Cathay | 19 | 4 (net +220) | 1 (net +817) | 3 (net +117) | 4 (net +55) | 2 (net +76) | 4 (net +336) | 1 | 17% (3 of 18) |
| Mine | High Elf Realms | 11 | 0 | 0 | 1 (net +122) | 4 (net +156) | 2 (net +106) | 3 (net +260) | 1 | 10% (1 of 10) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 1 (net -137) | 0 | 0 | 1 (net +236) | 0 | 50% (1 of 2) |
| Mine | Lizardmen | 3 | 1 (net -405) | 0 | 0 | 1 (net +144) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +0) | 0 | 1 (net +63) | 2 (net +136) | 1 | 25% (1 of 4) |
| Mine | Skaven | 3 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +19) | 0 | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 1 (net -66) | 4 (net +30) | 1 (net +250) | 2 (net +334) | 0 | 12% (1 of 8) |
| Mine | Vampire Counts | 8 | 2 (net -204) | 0 | 2 (net +144) | 2 (net +26) | 0 | 2 (net +137) | 0 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 7 | 1 (net +0) | 0 | 2 (net +72) | 1 (net +0) | 0 | 3 (net -39) | 0 | 29% (2 of 7) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 8 | 2 (net +178) | 0 | 0 | 1 (net -205) | 1 (net +84) | 2 (net +136) | 2 | 0% (0 of 6) |
| Opponent | High Elf Realms | 6 | 1 (net +0) | 0 | 1 (net +165) | 0 | 0 | 4 (net +116) | 0 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 6 | 3 (net +72) | 0 | 1 (net +65) | 0 | 0 | 2 (net +82) | 0 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +157) | 4 | 33% (1 of 3) |
| Opponent | Skaven | 1 | 1 (net -35) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 11 | 0 | 0 | 2 (net +233) | 3 (net +170) | 0 | 4 (net +126) | 2 | 22% (2 of 9) |
| Opponent | Vampire Counts | 25 | 7 (net +43) | 0 | 2 (net +238) | 5 (net +45) | 1 (net +66) | 7 (net +124) | 3 | 9% (2 of 22) |
| Opponent | Warriors of Chaos | 30 | 4 (net +66) | 0 | 5 (net +363) | 7 (net +52) | 0 | 9 (net +136) | 5 | 20% (5 of 25) |
| Opponent | Wood Elf Realms | 19 | 0 | 0 | 3 (net +192) | 0 | 1 (net +0) | 5 (net +57) | 10 | 33% (3 of 9) |

### Charged fights, damage counted: fw-on-db7ca9c-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 298 | 281 | -3 | 119 | 94 | +25 | +8.3 |
| Mine | 50-54% | 1 | 334 | 198 | +817 | 817 | 0 | +817 | +244.6 |
| Mine | Effective (55-75%) | 13 | 245 | 174 | +54 | 127 | 55 | +72 | +29.3 |
| Mine | 76-89% | 21 | 290 | 178 | +101 | 138 | 35 | +104 | +35.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 282 | 190 | +139 | 168 | 23 | +145 | +51.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 324 | 83 | +94 | 107 | 2 | +105 | +32.5 |
| Mine | No odds | 8 | 275 | 165 | +60 | 113 | 68 | +45 | +16.5 |
| Mine | All fights | 95 | 286 | 183 | +95 | 144 | 41 | +104 | +36.3 |
| Opponent | Long shot (under 50%) | 18 | 193 | 227 | +61 | 131 | 58 | +73 | +37.7 |
| Opponent | Effective (55-75%) | 15 | 262 | 216 | +238 | 263 | 4 | +259 | +98.5 |
| Opponent | 76-89% | 16 | 305 | 204 | +56 | 106 | 44 | +62 | +20.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 | 325 | 218 | +114 | 179 | 67 | +112 | +34.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 388 | 67 | +50 | 50 | 0 | +50 | +12.9 |
| Opponent | No odds | 26 | 186 | 179 | -2 | 114 | 112 | +3 | +1.5 |
| Opponent | All fights | 114 | 263 | 204 | +86 | 154 | 63 | +92 | +34.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-on-db7ca9c-p3 | move | 559 | 101 (18%) | 79 (14%) | 48 (9%) | 410 (73%) |
| fw-on-db7ca9c-p3 | objective | 437 | 64 (15%) | 52 (12%) | 47 (11%) | 326 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: fw-off-db7ca9c-p4

### Scorecard: fw-off-db7ca9c-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 11 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 123 |
| L0130 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 9 | - | 2 | 4 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | no | 0 | 1 | 0 | 2 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 7 | 3 | 1 | 1 | 0 | 0 | 0 | 760 |
| L0315 | 3 | 1 | Opponent | yes | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 5 | 1 | 0 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 5 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 3 | 2 | 3 | 0 | 1 | 0 | 0 | 49 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 1120 |
| L0520 | 4 | 1 | Opponent | no | 6 | 2 | 1 | 6 | 1 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 6 | 3 | 5 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 3 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 3 | 1 | 3 | 1 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 1 | 3 | 3 | 0 | 1 | 0 | 0 | 715 |
| L0819 | 3 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 560 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 6 | 2 | 7 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 1 | 3 | 5 | 0 | 2 | 0 | 0 | 135 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 2 | 1 | 1 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 56 |
| L1126 | 4 | 1 | Mine | yes | 5 | 3 | 4 | 0 | 1 | 0 | 0 | 425 |
| L1126 | 4 | 1 | Opponent | no | 0 | 2 | 7 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 4 | 1 | 1 | 0 | 0 | 420 |
| L1314 | 6 | 1 | Mine | no | 14 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | no | - | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 2 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 138 |
| L1621 | 1 | 1 | Mine | yes | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 834 |
| L1719 | 3 | 1 | Mine | yes | 11 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 3 | 0 | 2 | 0 | 0 | 585 |
| L1819 | 1 | 1 | Mine | no | 1 | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | yes | 3 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 0 | 0 | 0 | 140 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 5 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 4 | 6 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | no | - | - | 2 | 6 | 0 | 0 | 0 | 65 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 7 | 2 | 1 | 0 | 0 | 60 |
| L2331 | 3 | 1 | Mine | yes | 5 | 3 | 3 | 1 | 1 | 0 | 0 | 138 |
| L2331 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 1 | 0 | 0 | 515 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 2 | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 107 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 46% | 4.2 | 2.6 | 2.8 | 1.4 | 0.3 | 0.0 | 0.0 | 250.5 |
| **Average** | | | Opponent | 39% | 1.4 | 2.2 | 3.2 | 1.9 | 0.4 | 0.0 | 0.0 | 142.0 |

### KPIs: fw-off-db7ca9c-p4

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 167) | 0% (0 of 176) | 0% (0 of 343) |
| Winner chose to follow up after the loser gave ground |  | 98% (52 of 53); on the table 98% | 98% (53 of 54); on the table 98% | 98% (105 of 107); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 94% (16 of 17); on the table 94% | 100% (14 of 14); on the table 100% | 97% (30 of 31); on the table 97% |
| Winner chose to pursue after the loser fled |  | 84% (26 of 31); on the table 90% | 65% (22 of 34); on the table 71% | 74% (48 of 65); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 93% (94 of 101); on the table 95% | 87% (89 of 102); on the table 89% | 90% (183 of 203); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 29% (78 of 268) | 37% (65 of 176) | 32% (143 of 444) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (78 of 179) | 52% (65 of 125) | 47% (143 of 304) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 32% (22048 of 67942) | 30% (21463 of 71984) | 31% (43511 of 139926) |
|   infantry points that never fought | lower | 39% (6031 of 15347) | 57% (7871 of 13804) | 48% (13902 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (144 of 270) | 58% (162 of 280) | 56% (306 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.7 uses a game | 89% (8 of 9); 0.6 uses a game | 94% (29 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.8 uses a game | 55% (11 of 20); 0.6 uses a game | 64% (23 of 36); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 68% (13 of 19); 0.4 uses a game | 60% (9 of 15); 0.3 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (27141 of 57750) | 50% (31487 of 63347) | 48% (58628 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (29%) | 0.8 (24%) | 2.3 (27%) |
| MARCHED: its unit marched | 1.2 (23%) | 0.4 (13%) | 1.6 (19%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.2 (8%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.6 (31%) | 0.6 (21%) | 2.2 (27%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (9%) | 0.3 (3%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (0%) | 0.2 (3%) |
| GONE: slain | 0.2 (5%) | 0.7 (23%) | 0.9 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (7%) | 0.1 (3%) | 0.4 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.5 | 1.7 | 4.0 | 0.4 | 2.4 |
| not cast | 3.0 | 2.4 | 3.1 | 8.4 | 1.6 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.1 (45%) | 0.1 (4%) | 2.3 (27%) | 0.3 (19%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (19%) | 0.5 (29%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.2 (9%) | 0.9 (29%) | 2.2 (27%) | 0.4 (27%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (7%) | 0.3 (10%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (5%) | 0.1 (3%) | 0.0 (1%) | 0.2 (3%) | 0.1 (5%) | 0.8 (4%) |
| GONE: slain | 1.0 (33%) | 0.4 (17%) | 0.4 (12%) | 0.9 (11%) | 0.0 (0%) | 3.2 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.1 (3%) | 0.3 (10%) | 0.4 (5%) | 0.1 (3%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (10%) | 0.0 (0%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (44%) | 0.1 (5%) | 1.1 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.5 a game | 0.9 a game |
| stood (cast and not dispelled) | 67% (29 of 43) | 45% (5 of 11) | 63% (34 of 54) |
| the unit moved after it | 55% (16 of 29) | 60% (3 of 5) | 56% (19 of 34) |
| it charged on its next turn | 10% (3 of 29) | 0% (0 of 5) | 9% (3 of 34) |
| the enemy charged it first | 31% (9 of 29) | 0% (0 of 5) | 26% (9 of 34) |
| it fought by the end of its next turn | 38% (11 of 29) | 0% (0 of 5) | 32% (11 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 10% (3 of 29) | 0% (0 of 5) | 9% (3 of 34) |
| none of these (no charge, no fight, no charge escaped) | 34% (10 of 29) | 100% (5 of 5) | 44% (15 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (540 of 868) | 55% (283 of 518) | 59% (823 of 1386) |
|   cavalry | 57% (42 of 74) | 70% (73 of 104) | 65% (115 of 178) |
|   character | 52% (51 of 99) | 12% (15 of 123) | 30% (66 of 222) |
|   chariot | 45% (45 of 100) | 63% (12 of 19) | 48% (57 of 119) |
|   infantry | 54% (148 of 272) | 70% (155 of 221) | 61% (303 of 493) |
|   monster | 55% (24 of 44) | 21% (4 of 19) | 44% (28 of 63) |
|   war machine | 82% (230 of 279) | 75% (24 of 32) | 82% (254 of 311) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (28%) | 1.6 (24%) | 4.2 (27%) |
| CHARGED: it charged | 1.4 (16%) | 1.7 (26%) | 3.2 (20%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.4 (6%) | 1.0 (7%) |
| NO TARGET IN RANGE | 2.0 (22%) | 1.1 (17%) | 3.1 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.4 (6%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (14%) | 1.2 (18%) | 2.4 (15%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.1 | 1.7 | 74% | 8.0 pts | 41 pts |
| character | 2.2 | 0.3 | 90% | 2.6 pts | 6 pts |
| chariot | 1.6 | 0.9 | 67% | 13.9 pts | 22 pts |
| infantry | 12.8 | 4.8 | 73% | 10.4 pts | 133 pts |
| monster | 0.9 | 0.1 | 97% | 3.0 pts | 3 pts |
| war machine | 7.1 | 5.6 | 65% | 28.1 pts | 199 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.8 | 5.9 | 5.3 |
| Charges that made contact a game | 3.6 | 4.1 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.06 declared, 1.06 contact (16 units) | 1.06 declared, 0.65 contact (17 units) | 1.06 declared, 0.85 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.43 declared, 0.86 contact (7 units) | 1.17 declared, 1.08 contact (12 units) | 1.26 declared, 1.00 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.58 declared, 0.42 contact (253 units) | 0.59 declared, 0.41 contact (304 units) | 0.58 declared, 0.41 contact (557 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (40 of 81) | 44% (7 of 16) | 33% (2 of 6) | 48% (49 of 103) |
| Character in a unit | 87% (20 of 23) | 62% (8 of 13) | 100% (1 of 1) | 78% (29 of 37) |
| Character on its own | 86% (36 of 42) | 34% (10 of 29) | 26% (20 of 77) | 45% (66 of 148) |
| Chariot | 60% (9 of 15) | 58% (7 of 12) | - | 59% (16 of 27) |
| Infantry | 54% (45 of 83) | 40% (10 of 25) | 17% (1 of 6) | 49% (56 of 114) |
| Monster | 71% (24 of 34) | 79% (11 of 14) | - | 73% (35 of 48) |
| Monstrous | 71% (10 of 14) | 79% (11 of 14) | - | 75% (21 of 28) |
| War Machines | 74% (32 of 43) | 100% (2 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 78% (7 of 9); on the table 89% | 33% (34 of 102) | 14% | 50% (11 of 22) | 100% (6 of 6); 4.2 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (13 of 13); on the table 100% | 12% (3 of 24) | 35% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (7 of 7); on the table 100% | - | 68% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 93% (14 of 15); on the table 93% | 50% (9 of 18) | 46% | 58% (36 of 62) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 100% (10 of 10); on the table 100% | 26% (22 of 84) | 35% | 35% (13 of 37) | 100% (9 of 9); 6.2 uses a game | 100% (2 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 88% (14 of 16); on the table 88% | 25% (9 of 36) | 27% | 46% (32 of 70) | 100% (7 of 7); 2.3 uses a game | 57% (17 of 30); 4.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 53% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 78% (7 of 9); on the table 78% | 50% (3 of 6) | 31% | 71% (15 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 75% (3 of 4); on the table 100% | 67% (4 of 6) | 49% | 86% (12 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (6 of 6); on the table 100% | 40% (17 of 42) | 3% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 80% (8 of 10); on the table 80% | 45% (19 of 42) | 49% | 80% (36 of 45) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 100% (16 of 16); on the table 100% | 17% (1 of 6) | 19% | 30% (6 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (37 of 42); on the table 90% | 20% (12 of 60) | 22% | 48% (20 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 89% (24 of 27); on the table 89% | 50% (6 of 12) | 27% | 56% (40 of 72) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 88% (15 of 17); on the table 94% | 67% (4 of 6) | 24% | 55% (31 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (fw-off-db7ca9c-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (43) | 48% (38) | 49% (81) |
| ...free all their last turn and able to turn (per game) | 0.72 | 0.64 | 1.36 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.25 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.47 | 1.08 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.19 | 0.92 | 2.11 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.06 | 0.58 | 1.64 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.00 | 6.69 | 12.69 |

### Quality by phase: fw-off-db7ca9c-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 50% (79 of 158) | 45% (80 of 178) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (157 of 327) | 40% (57 of 143) |
| Strategy | Close-in objectives charged next turn | 10% (16 of 155) | 14% (26 of 180) |
| Strategy | Support requests answered (helper made contact too) | 55% (6 of 11) | 32% (9 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (4 of 12) | 88% (7 of 8) |
| Strategy | Joined characters whose unit fought | 68% (19 of 28) | 32% (8 of 25) |
| Strategy | Lone characters that fought | 77% (73 of 95) | 82% (75 of 91) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.4 | 1.9 |
| Movement | Points that never moved of their own | 250.5 | 142.0 |
| Movement | Fights charged into per game | 3.4 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 114, net +137 | 17 of 103, net +68 |
| Movement | Charges with odds: sweet spot (55-75%) | 21 of 114, net +50 | 23 of 103, net +10 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 19 of 114, net +104 | 7 of 103, net +32 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 of 114, net +97 | 37 of 103, net +81 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (155 of 351) | 44% (138 of 316) |
| Shooting | Points destroyed by shooting units | 65.7 | 57.7 |
| Shooting | War machine shots | 6.4 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (121 of 230) | 38% (9 of 24) |
| Shooting | Points destroyed by war machines | 115.6 | 8.4 |
| Magic | Magic missiles cast | 1.5 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (20 of 54) | 32% (14 of 44) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.6 |
| Magic | Wounds caused by other spells | 3.3 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 120.4 | 17.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.4 / 1.0 / 0.2 | 2.0 / 0.5 / 0.4 / 0.0 |
| Combat | Points destroyed in combat | 413.6 | 362.2 |
| Combat | Points run down | 68.9 | 146.3 |
| Combat | Net points per charged fight, damage counted | +95 | +74 |
| Combat | Net per 100 charger points, damage counted | +34.6 | +24.0 |
| Combat | First round won (charged fights) | 81% | 57% |
| Combat | Net points per charged fight | +90 | +69 |
| Combat | Net points per supported fight / lone fight | +5 / +100 | -3 / +79 |
| Combat | Charged fights on a top-3 enemy unit | 34 of 121 | 60 of 125 |
| Game | Points lost | 729.3 | 873.2 |
| Game | VP from objectives | 630.0 | 488.3 |
| Game | Lone holders (player turns) | 4.2 | 1.4 |

- Mine won / drew / lost: 20 / 3 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) +255 VP
- The side that went first won 16 of 33 games with a winner
- Points traded per game (both sides' losses): 1602
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-off-db7ca9c-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 8.9 | 2.6 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 6.9 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.9 | +5.4 | 0.0 | 9.9 | 1.3 | +15.1 | 0.0 | 17.2 |
| BEST OVERALL | 0.5 | +29.6 | 0.0 | 33.5 | 0.2 | +8.8 | 0.0 | 13.3 |
| BEST PREY | 5.3 | +311.4 | 262.7 | 187.6 | 5.2 | +356.4 | 127.6 | 139.5 |
| BEST PRIZE | - | - | - | - | 0.0 | +4.2 | 15.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.1 | 0.0 | 23.0 | 0.2 | -1.0 | 0.0 | 11.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.4 | 7.4 | 0.0 | +0.0 | 11.3 | 0.0 |
| BLOCKED WHEEL | 0.4 | +9.1 | 0.0 | 0.0 | 0.4 | -2.3 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.4 | 1.2 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 8.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 66.8 | 12.6 | 0.2 | +0.0 | 21.0 | 1.9 |
| CANNON PLANNED TARGET | 5.1 | +110.3 | 543.6 | 76.5 | 0.4 | +13.3 | 36.6 | 8.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -4.1 | 7.1 | 8.6 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -4.3 | 6.7 | 0.0 | 0.1 | +0.0 | 22.7 | 0.0 |
| CAST JOB | 0.6 | +19.9 | 38.1 | 23.4 | 0.4 | +15.9 | 20.4 | 37.8 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +30.5 | 23.6 | 8.9 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 62.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.7 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 11.0 | 0.2 | -0.3 | 33.6 | 8.1 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 1.7 | 0.0 | 0.0 | +0.9 | 11.3 | 0.0 |
| CHARGE NOW WEIGHED | 0.4 | -25.6 | 10.7 | 4.8 | 0.4 | -36.0 | 0.0 | 15.3 |
| CHARIOT NO STATIC JOB | 0.3 | +0.0 | 5.8 | 9.4 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.2 | 0.0 | 0.0 | 0.2 | -2.3 | 0.0 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 15.7 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 66.1 | 14.0 | 0.5 | +0.0 | 18.8 | 22.6 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.9 | +146.7 | 31.6 | 46.2 | 0.2 | +24.4 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 8.4 | +572.9 | 0.0 | 203.4 | 6.8 | +546.2 | 0.0 | 183.1 |
| EDGE GIVE GROUND | 0.1 | +2.8 | 33.9 | 0.0 | 0.1 | +2.2 | 3.1 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +2.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.2 | +97.4 | 0.0 | 36.1 | 0.9 | +68.7 | 0.0 | 38.6 |
| FALLBACK BY WORTH | 7.3 | +70.8 | 0.0 | 83.3 | 7.6 | +71.9 | 0.0 | 79.5 |
| FIGHT LIFT | 0.1 | +0.9 | 5.7 | 9.9 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 6.2 | +0.0 | 0.0 | 216.5 | 5.8 | +0.0 | 0.0 | 197.2 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +155.6 | 0.0 | 33.3 | 1.4 | +237.6 | 0.0 | 97.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +13.8 | 0.0 | 12.0 | 0.1 | +10.2 | 0.0 | 16.6 |
| GIVES UP | 1.2 | -23.9 | 141.2 | 28.1 | 1.4 | -62.2 | 172.1 | 103.7 |
| GIVES UP ITS SCREEN | 0.7 | -8.0 | 36.4 | 8.1 | 1.0 | -19.6 | 71.9 | 18.0 |
| GROUND FLIERS | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 3.4 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 23.0 | 0.0 | 0.3 | +0.0 | 4.0 | 25.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.2 | 16.4 | 0.0 | 0.2 | +4.1 | 8.1 | 9.4 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +12.1 | 0.0 | 0.0 | 0.5 | +8.3 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.6 | 0.0 | 3.2 |
| HUNT RESULT | 0.1 | +17.8 | 0.0 | 0.0 | 0.1 | +15.0 | 7.6 | 3.1 |
| HUNT THE GUNS | 0.1 | +24.6 | 16.4 | 0.0 | 0.2 | +58.7 | 19.0 | 7.9 |
| JOINT CHARGE PLAN | 0.1 | +1.7 | 3.4 | 0.0 | 0.1 | +7.5 | 11.3 | 0.0 |
| KEEP FALLS | 0.1 | +1.1 | 0.0 | 6.1 | 0.1 | +1.4 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.3 | +1.3 | 12.7 | 16.0 | 0.2 | +1.3 | 0.0 | 10.0 |
| KEEPS ITS TARGET | 1.6 | +49.2 | 181.4 | 10.5 | 2.1 | +64.2 | 229.1 | 93.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 2.4 | +96.7 | 138.5 | 63.5 | 1.9 | +110.1 | 121.4 | 78.6 |
| KILLS COUNT NEXT TURN | 9.7 | +327.2 | 477.2 | 215.7 | 10.7 | +555.6 | 284.4 | 259.6 |
| LONE CHARACTER SAFE SPOT | 0.6 | +27.9 | 22.8 | 18.8 | 0.4 | +30.7 | 9.4 | 25.4 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 7.9 | 0.4 | +0.0 | 8.6 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +30.1 | 6.8 | 9.6 | 0.4 | +20.4 | 11.3 | 23.8 |
| MANOEUVRE | 0.2 | +7.1 | 0.0 | 5.2 | 0.1 | +1.4 | 0.0 | 13.6 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 8.9 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +34.1 | 0.0 | 2.2 | 0.4 | +34.1 | 0.0 | 5.1 |
| MARCH ODDS | 0.9 | +41.4 | 37.0 | 29.9 | 0.5 | +71.8 | 28.5 | 25.6 |
| MARCH OVER CASTS | 0.6 | +37.8 | 0.0 | 8.9 | 0.2 | +14.2 | 0.0 | 5.5 |
| MAX FOR POSITIONING | 4.9 | +156.2 | 0.0 | 115.3 | 4.4 | +142.7 | 0.0 | 155.4 |
| MISSILES IN THE MOVE | 3.8 | +111.5 | 0.0 | 93.9 | 2.0 | +42.2 | 0.0 | 59.6 |
| MISSILES NEXT TURN | 4.7 | +82.9 | 0.0 | 113.4 | 2.6 | +28.3 | 0.0 | 98.4 |
| MODEL FACING | 0.2 | +26.1 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 12.3 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.1 | +1.9 | 0.0 | 4.5 | 0.1 | +10.1 | 0.0 | 15.0 |
| MOVE SPELL IN RANGE | 0.2 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -29.8 | 24.9 | 40.6 | 0.0 | -1.5 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 12.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +6.6 | 20.2 | 0.0 | 0.1 | +15.0 | 15.5 | 0.0 |
| NO RALLY LEFT | 0.0 | +3.9 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 2.7 |
| NOT NEEDED | 0.2 | -10.4 | 19.8 | 1.1 | 0.1 | -3.9 | 6.6 | 2.7 |
| NOT TURNED | 6.0 | +84.4 | 0.0 | 152.3 | 6.7 | +106.3 | 0.0 | 154.0 |
| NOT WORTH A CAST | 0.7 | -0.4 | 0.0 | 11.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 17.1 | -784.8 | 47.3 | 313.2 | 16.2 | -945.3 | 42.2 | 394.6 |
| OPENS A LANE | 0.1 | +0.4 | 16.9 | 0.0 | 0.2 | +2.0 | 15.6 | 4.5 |
| OPENS UP | 0.1 | +14.4 | 12.3 | 0.0 | 0.3 | +30.2 | 27.4 | 5.4 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +4.9 | 0.0 | 7.9 |
| OVERRUNS AWAY | 0.5 | +10.6 | 67.8 | 5.4 | 0.6 | +5.1 | 37.7 | 66.8 |
| PATHS CROSS | 2.2 | +122.1 | 0.0 | 33.5 | 3.1 | +272.8 | 0.0 | 71.2 |
| PERIAPT WORTH | 0.1 | +3.9 | 0.0 | 0.0 | 0.1 | +7.2 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.9 | 0.0 | 2.4 | 0.1 | -9.9 | 0.0 | 2.1 |
| PLAN RESULT | 39.5 | +1610.7 | 1677.0 | 1015.0 | 37.8 | +1257.6 | 1079.2 | 1343.4 |
| PURSUES BIG PREY | 0.1 | -17.6 | 0.0 | 17.4 | 0.1 | -19.5 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.1 | 0.0 | 3.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.6 | 0.0 | 0.0 | 0.1 | +10.6 | 0.0 | 5.5 |
| REDIRECT COUNTER | 3.0 | +108.3 | 0.0 | 55.6 | 4.9 | +300.4 | 0.0 | 100.2 |
| REDIRECT WEIGHED | 0.1 | +5.8 | 5.8 | 0.0 | 0.4 | +18.0 | 17.4 | 12.1 |
| RESTRAINS TO SHOOT | 0.2 | +6.6 | 0.0 | 11.1 | 0.0 | +1.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.9 | +118.7 | 301.2 | 38.8 | 2.5 | +42.7 | 230.5 | 186.1 |
| SAFER THAN THE JOB | 1.1 | +43.6 | 0.0 | 17.8 | 0.6 | +26.7 | 0.0 | 24.3 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 2.1 | +107.5 | 0.0 | 46.9 | 1.8 | +109.5 | 0.0 | 32.0 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.1 | +38.9 | 0.0 | 11.0 | 0.3 | +15.8 | 0.0 | 31.0 |
| SET UP TOGETHER | 0.8 | +33.2 | 9.9 | 22.6 | 1.0 | +52.7 | 11.3 | 53.2 |
| SET-UP ANY TARGET | 0.6 | +73.8 | 20.2 | 5.0 | 0.1 | +14.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.2 | +23.2 | 0.0 | 0.0 | 0.1 | +5.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.2 | +0.0 | 47.2 | 4.6 | 0.3 | +0.0 | 31.8 | 1.8 |
| SHOTS IN THE MOVE | 13.8 | +420.0 | 0.0 | 238.9 | 6.8 | +219.4 | 0.0 | 126.0 |
| SPELL SETS UP CHARGE | 0.6 | +73.8 | 20.2 | 5.0 | 0.1 | +14.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.5 | +19.7 | 67.7 | 87.9 | 2.2 | +37.1 | 98.7 | 96.0 |
| STANDS TO CAST | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.0 | +0.1 | 11.0 | 1.7 |
| STOPS SHORT OF THE FLANK | 0.3 | +18.6 | 0.0 | 23.3 | 0.5 | +20.7 | 0.0 | 15.3 |
| STUCK PIVOT | 0.4 | +0.0 | 0.0 | 9.9 | 0.2 | +0.0 | 0.0 | 9.9 |
| SUPPORT JOB KEPT | 0.1 | +0.0 | 5.5 | 1.7 | 0.0 | +0.0 | 7.2 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -7.8 | 26.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +0.1 | 3.4 | 9.6 | 0.6 | +0.7 | 0.0 | 27.3 |
| THROUGH LINE OF FIRE | 0.4 | +8.9 | 0.0 | 7.0 | 0.4 | +15.0 | 0.0 | 1.9 |
| TURN WORTH | 0.7 | -48.6 | 45.8 | 12.8 | 0.2 | -15.5 | 18.5 | 5.9 |
| TWO OR MORE ARRIVE | 0.3 | +1.2 | 6.8 | 0.0 | 0.4 | +2.0 | 0.0 | 24.8 |
| WEARS DOWN | 0.9 | +34.7 | 145.6 | 14.0 | 1.3 | +40.3 | 161.8 | 103.0 |
| WHO HITS BACK | 0.4 | +25.6 | 0.0 | 8.6 | 0.1 | +7.6 | 0.0 | 8.4 |
| WHOLE FIGHT | 0.4 | +5.9 | 51.5 | 11.0 | 0.5 | +44.7 | 74.6 | 17.4 |
| WHOLE FIGHT GAIN | 0.1 | +2.9 | 10.6 | 7.7 | 0.7 | +49.5 | 50.4 | 18.2 |

### Rule changes: fw-off-db7ca9c-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1199 | 1199 | 1199 | 33.31 | -62285 | -51.9 |
| KILLS COUNT NEXT TURN | 733 | 725 | 206 | 5.72 | +7328 | +35.6 |
| PATHS CROSS | 189 | 189 | 189 | 5.25 | +14217 | +75.2 |
| BEST PREY | 376 | 367 | 153 | 4.25 | +6201 | +40.5 |
| SEARCH SPOT | 138 | 138 | 136 | 3.78 | +7817 | +57.5 |
| COUNTER-CHARGE COVER | 548 | 276 | 106 | 2.94 | +6187 | +58.4 |
| FALLBACK BY WORTH | 534 | 534 | 96 | 2.67 | +5135 | +53.5 |
| FOLLOW UP WEIGHED | 92 | 92 | 92 | 2.56 | +14154 | +153.9 |
| FACES THE THREAT | 76 | 76 | 76 | 2.11 | +5980 | +78.7 |
| SAFER THAN THE JOB | 59 | 59 | 59 | 1.64 | +2533 | +42.9 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| KILLS COUNT | 154 | 148 | 54 | 1.50 | +2202 | +40.8 |
| CANNON SIGHT KEPT | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| RISK BY ARC | 197 | 180 | 48 | 1.33 | +1562 | +32.5 |
| MARCH ODDS | 49 | 49 | 45 | 1.25 | +927 | +20.6 |
| ADVANCE LANE KEPT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| MARCH CHECK | 41 | 40 | 39 | 1.08 | +2718 | +69.7 |
| MAX FOR POSITIONING | 336 | 170 | 38 | 1.06 | +331 | +8.7 |
| SHOTS IN THE MOVE | 739 | 458 | 38 | 1.06 | +993 | +26.1 |
| COMBAT PIVOT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| REDIRECT COUNTER | 285 | 125 | 35 | 0.97 | +1998 | +57.1 |
| BLOCKED WHEEL | 30 | 30 | 30 | 0.83 | +246 | +8.2 |
| KEEPS ITS TARGET | 136 | 133 | 30 | 0.83 | +557 | +18.6 |
| STOPS SHORT OF THE FLANK | 30 | 30 | 30 | 0.83 | +1416 | +47.2 |
| CHARGE NOW WEIGHED | 29 | 29 | 29 | 0.81 | +1570 | +54.1 |
| THROUGH LINE OF FIRE | 29 | 29 | 29 | 0.81 | +863 | +29.7 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MISSILES IN THE MOVE | 207 | 110 | 26 | 0.72 | +409 | +15.7 |
| BEST OVERALL | 25 | 25 | 25 | 0.69 | +1382 | +55.3 |
| SET UP TOGETHER | 64 | 52 | 24 | 0.67 | +984 | +41.0 |
| CANNON PLANNED TARGET | 200 | 200 | 23 | 0.64 | +106 | +4.6 |
| STUCK PIVOT | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| CAST JOB | 33 | 33 | 22 | 0.61 | +610 | +27.7 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +1287 | +71.5 |
| SHOT REPLANNED | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.47 | +36 | +2.1 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +944 | +55.5 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | -41 | -2.7 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -25 | -1.8 |
| MAKE SURE TOGETHER | 35 | 25 | 12 | 0.33 | +483 | +40.2 |
| WEARS DOWN | 78 | 71 | 12 | 0.33 | +253 | +21.1 |
| CHARIOT NO STATIC JOB | 13 | 13 | 11 | 0.31 | -1518 | -138.0 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +866 | +78.7 |
| MANOEUVRE | 11 | 11 | 11 | 0.31 | +307 | +27.9 |
| WHOLE FIGHT GAIN | 29 | 22 | 10 | 0.28 | +544 | +54.4 |
| CASTING BLOCK | 13 | 13 | 9 | 0.25 | +547 | +60.8 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WHOLE FIGHT | 31 | 29 | 9 | 0.25 | +1026 | +114.0 |
| MOVE AND CAST | 8 | 8 | 8 | 0.22 | +431 | +53.9 |
| OPENS UP | 17 | 15 | 8 | 0.22 | +387 | +48.4 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -386 | -48.2 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +277 | +34.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| NEEDED THERE | 8 | 8 | 7 | 0.19 | +0 | +0.0 |
| BACKUP TARGETS | 80 | 39 | 6 | 0.17 | +62 | +10.4 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +317 | +52.8 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +938 | +156.4 |
| OVERRUNS AWAY | 38 | 35 | 5 | 0.14 | +129 | +25.8 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +401 | +80.1 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -1336 | -267.1 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -292 | -58.3 |
| MISSILES NEXT TURN | 264 | 140 | 4 | 0.11 | +29 | +7.2 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 4 | 0.11 | +115 | +28.6 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.1 |
| HUNT ADVANCE | 9 | 9 | 3 | 0.08 | +55 | +18.4 |
| HUNT IN PAIRS | 27 | 17 | 3 | 0.08 | +121 | +40.4 |
| SUPPORT JOB KEPT | 3 | 3 | 3 | 0.08 | +107 | +35.7 |
| CARRIES OUT SET-UP | 4 | 4 | 2 | 0.06 | -156 | -78.1 |
| EDGE GIVE GROUND | 7 | 7 | 2 | 0.06 | +66 | +32.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 16 | 16 | 2 | 0.06 | -76 | -37.8 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +3 | +1.4 |
| SURE REACH TOGETHER | 35 | 24 | 2 | 0.06 | +0 | +0.0 |
| TWO OR MORE ARRIVE | 27 | 24 | 2 | 0.06 | +1 | +0.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -36 | -35.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +14 | +13.8 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -147 | -146.9 |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +80 | +80.2 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +6 | +6.2 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +22 | +21.9 |
| GIVES UP | 93 | 86 | 1 | 0.03 | +18 | +17.5 |
| GIVES UP ITS SCREEN | 60 | 57 | 1 | 0.03 | +2 | +1.7 |
| JOINT CHARGE PLAN | 6 | 6 | 1 | 0.03 | +21 | +21.2 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +2 | +2.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +6 | +5.8 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 38 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 9 | 9 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 40 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 431 | not checked | - | - | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 18 | 15 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| KEEPS ITS PREY | 19 | 17 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 34 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 457 | 457 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| OPENS A LANE | 11 | 6 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2785 | trace | - | - | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 8 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 24 | not checked | - | - | - | - |
| SPELL WORTH | 134 | not checked | - | - | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TURN WORTH | 35 | 31 | 0 | 0.00 | - | - |

### Off best figure: fw-off-db7ca9c-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.25 | 13.19 | 53.2 |
| FALLBACK | gate | 1.25 | 1.31 | 58.9 |
| RULE SWITCHED OFF | gate | 0.64 | 0.64 | 18.3 |
| TURN GATE | gate | 0.28 | 0.56 | 59.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.28 | 0.08 | 48.8 |
| PATHS CROSS | rule | 0.22 | 0.14 | 29.0 |
| AFTERMATH BAND | gate | 0.11 | 0.19 | 3.3 |
| CHARIOT NO STATIC JOB | rule | 0.28 | 0.03 | 138.0 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.17 | 9.2 |
| SUPPORT REQUEST | gate | 0.06 | 0.22 | 75.2 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.14 | 48.2 |
| CHAFF PASSED | rule | 0.14 | 0.06 | 3.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.03 | 52.5 |
| PURSUES BIG PREY | rule | 0.06 | 0.08 | 267.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.03 | 58.3 |
| BLOCKED WHEEL | rule | 0.06 | 0.06 | 35.6 |
| FIGHT ORDER BAND | gate | 0.08 | 0.03 | 1.7 |
| MARCH ODDS | rule | 0.06 | 0.06 | 100.7 |
| SAFER THAN THE JOB | rule | 0.08 | 0.03 | 9.0 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 23.4 |
| FACES THE THREAT | rule | 0.03 | 0.06 | 11.5 |
| STOPS SHORT OF THE FLANK | rule | - | 0.08 | 7.1 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 5.7 |
| CARRIES OUT SET-UP | rule | 0.06 | - | 78.1 |
| BEST PRIZE | rule | - | 0.03 | 35.5 |
| CANNON PLANNED TARGET | rule | 0.03 | - | 3.2 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 146.9 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 3.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 75.5 |
| WHO HITS BACK | rule | 0.03 | - | 5.0 |

### Plans: fw-off-db7ca9c-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.6 | 25% | 479 | 517 | 108% |
| Mine | charge | 3.5 | 68% | 317 | 336 | 106% |
| Mine | close in | 4.3 | 28% | 247 | 143 | 58% |
| Mine | hold | 4.8 | 37% | 438 | 0 | 0% |
| Mine | join | 0.8 | 93% | 22 | 0 | 0% |
| Mine | shoot | 7.9 | 62% | 226 | 614 | 272% |
| Mine | support | 4.6 | 88% | 227 | 0 | 0% |
| Opponent | advance | 14.5 | 15% | 691 | 437 | 63% |
| Opponent | charge | 4.1 | 56% | 526 | 394 | 75% |
| Opponent | close in | 4.8 | 22% | 467 | 168 | 36% |
| Opponent | hold | 3.5 | 29% | 302 | 0 | 0% |
| Opponent | join | 0.6 | 95% | 50 | 0 | 0% |
| Opponent | shoot | 3.5 | 63% | 96 | 260 | 272% |
| Opponent | support | 6.8 | 86% | 227 | 0 | 0% |

### Packages: hunt the guns, fw-off-db7ca9c-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 0 | 0% | 67% | 0% | 2.0 | 295 | 213 | 67% | 5 |
| Opponent | 0.2 | 6 | 1 | 0% | 40% | 0% | 2.0 | 341 | 108 | 40% | 122 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 467 | 445 | 100% | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 213 | 0 | 0% | 57 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 260 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 171 |
| Tomb Kings of Khemri | 1.2 | 5 | 1 | 0% | 25% | 0% | 2.0 | 322 | 49 | 25% | 0 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 100% | 0% | 2.0 | 312 | 270 | 100% | 14 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 119 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |

### Battle groups: fw-off-db7ca9c-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.4 | 29% | 48% | 16% | 50% | 49% | 11% | 12% | 27% | 0% |
| Mine | REDIRECT COUNTER | 3.0 | 35% | 74% | 5% | 50% | 14% | 6% | 3% | 72% | 6% |
| Opponent | COUNTER-CHARGE COVER | 6.8 | 17% | 55% | 14% | 17% | 31% | 6% | 17% | 47% | 0% |
| Opponent | REDIRECT COUNTER | 4.9 | 31% | 67% | 15% | 0% | 17% | 0% | 19% | 60% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-off-db7ca9c-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 148 (4) | 148 | 0 | 0 | 25% | 2.0 | - | 0 (1) | 238 (3) | - | 148 (4) |
| Mine | Chaff | 49 | 44 (49) | 21 | 23 | 68 | 29% | 2.9 | 35 (21) | 68 (11) | 40 (17) | 53 (32) | 25 (17) |
| Mine | Character | 106 | 61 (106) | 61 | 0 | 39 | 15% | 2.2 | 59 (34) | 79 (42) | 39 (8) | 48 (44) | 91 (40) |
| Mine | Clean-up | 14 | 79 (14) | 26 | 53 | 51 | 14% | 3.8 | 56 (6) | 95 (5) | 89 (3) | 85 (7) | 74 (7) |
| Mine | Early | 1 | 140 (1) | 140 | 0 | 0 | 0% | 5.0 | - | 140 (1) | - | - | 140 (1) |
| Mine | Fast Hammer | 39 | 48 (39) | 39 | 9 | 46 | 13% | 2.3 | 50 (24) | 51 (9) | 35 (6) | 45 (28) | 58 (11) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 54 | 50% | 2.5 | 0 (3) | 0 (1) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 38 (64) | 27 | 11 | 43 | 17% | 2.4 | 45 (10) | 36 (44) | 40 (10) | 31 (39) | 47 (25) |
| Mine | Holder | 30 | 124 (30) | 2 | 122 | 29 | 50% | 2.7 | 4 (7) | 176 (19) | 119 (3) | 132 (19) | 118 (10) |
| Mine | Shooter | 35 | 78 (35) | 29 | 49 | 40 | 3% | 1.5 | 30 (11) | 100 (19) | 100 (5) | 105 (23) | 31 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 64 (56) | 64 | 0 | 40 | 5% | 1.3 | 72 (20) | 68 (31) | 10 (5) | 62 (7) | 65 (49) |
| Mine | Wizard | 17 | 14 (17) | 14 | 0 | 38 | 12% | 1.8 | 24 (3) | 20 (7) | 0 (1) | 0 (2) | 23 (9) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 82 | 33 (82) | 8 | 25 | 64 | 33% | 3.0 | 31 (30) | 30 (21) | 37 (31) | 41 (62) | 6 (20) |
| Opponent | Character | 97 | 54 (97) | 54 | 0 | 38 | 24% | 2.3 | 63 (43) | 47 (41) | 64 (7) | 67 (52) | 44 (39) |
| Opponent | Clean-up | 12 | 131 (12) | 38 | 92 | 26 | 33% | 3.5 | 34 (3) | 191 (6) | 36 (3) | 130 (7) | 131 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 43 (54) | 31 | 12 | 62 | 19% | 3.0 | 43 (27) | 37 (17) | 60 (10) | 55 (34) | 26 (20) |
| Opponent | Fragile | 16 | 29 (16) | 29 | 0 | 75 | 19% | 2.1 | 0 (1) | 51 (9) | 0 (3) | 48 (9) | 0 (4) |
| Opponent | Hammer | 64 | 25 (64) | 18 | 6 | 53 | 31% | 3.0 | 43 (20) | 21 (38) | 0 (6) | 24 (42) | 26 (22) |
| Opponent | Holder | 27 | 28 (27) | 3 | 25 | 40 | 56% | 3.6 | 9 (12) | 46 (13) | 0 (1) | 48 (13) | 9 (13) |
| Opponent | Shooter | 34 | 94 (34) | 34 | 60 | 42 | 0% | 1.4 | 58 (9) | 115 (23) | 10 (2) | 95 (20) | 92 (14) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 67 | 33% | 2.5 | 0 (3) | 0 (1) | 0 (1) | 0 (3) | 0 (2) |
| Opponent | War machine | 6 | 27 (6) | 27 | 0 | 30 | 0% | 1.7 | 30 (3) | 22 (3) | - | 30 (3) | 22 (3) |
| Opponent | Wizard | 20 | 6 (20) | 6 | 0 | 50 | 5% | 2.4 | 0 (11) | 24 (5) | 0 (2) | 9 (13) | 0 (5) |

### Charged fights: fw-off-db7ca9c-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 170 | 116 | 1.8 | 1.0 | 66 | 0 | +66 | 0 of 7 | 6 of 7 | - | +66 |
| Mine | Chaos Dwarfs | 4 | 190 | 324 | 3.0 | 1.1 | 108 | 48 | +60 | 4 of 12 | 10 of 12 | -405 | +102 |
| Mine | Dwarfen Mountain Holds | 3 | 449 | 261 | 2.3 | 1.0 | 112 | 0 | +112 | 2 of 7 | 4 of 7 | - | +112 |
| Mine | Empire of Man | 5 | 820 | 256 | 2.4 | 1.2 | 107 | 91 | +16 | 4 of 12 | 7 of 12 | -94 | +38 |
| Mine | Grand Cathay | 4 | 439 | 342 | 5.0 | 1.1 | 68 | 6 | +62 | 7 of 20 | 18 of 20 | +97 | +56 |
| Mine | High Elf Realms | 4 | 142 | 480 | 2.8 | 1.0 | 174 | 0 | +174 | 3 of 11 | 10 of 11 | - | +174 |
| Mine | Kingdom of Bretonnia | 1 | 145 | 1052 | 5.0 | 1.2 | 210 | 16 | +194 | 2 of 5 | 5 of 5 | +112 | +215 |
| Mine | Lizardmen | 1 | 0 | 1243 | 4.0 | 1.0 | 311 | 0 | +311 | 2 of 4 | 3 of 4 | - | +311 |
| Mine | Ogre Kingdoms | 2 | 0 | 182 | 4.0 | 1.1 | 46 | 8 | +37 | 1 of 8 | 5 of 8 | -34 | +47 |
| Mine | Skaven | 2 | 345 | 33 | 1.0 | 1.0 | 33 | 0 | +33 | 0 of 2 | 2 of 2 | - | +33 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 506 | 4.0 | 1.0 | 126 | 78 | +48 | 3 of 8 | 5 of 8 | - | +48 |
| Mine | Vampire Counts | 2 | 404 | 350 | 6.5 | 1.2 | 54 | 0 | +54 | 2 of 13 | 12 of 13 | +36 | +59 |
| Mine | Warriors of Chaos | 2 | 0 | 1082 | 6.0 | 1.2 | 180 | 20 | +161 | 4 of 12 | 11 of 12 | +90 | +175 |
| **Mine** | all armies | 36 | 302 | 381 | 3.4 | 1.1 | 113 | 23 | +90 | 34 of 121 | 98 of 121 | +5 | +100 |
| Opponent | Empire of Man | 1 | 468 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 69 | 522 | 4.2 | 1.2 | 124 | 86 | +39 | 10 of 21 | 12 of 21 | -310 | +97 |
| Opponent | Lizardmen | 2 | 137 | 0 | 1.5 | 1.0 | 0 | 0 | +0 | 0 of 3 | 2 of 3 | - | +0 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 97 | 3.0 | 1.1 | 32 | 45 | -13 | 4 of 9 | 5 of 9 | +0 | -14 |
| Opponent | Skaven | 4 | 118 | 40 | 1.5 | 1.0 | 27 | 108 | -81 | 4 of 6 | 4 of 6 | - | -81 |
| Opponent | Tomb Kings of Khemri | 2 | 360 | 384 | 3.0 | 1.2 | 128 | 32 | +96 | 2 of 6 | 5 of 6 | -195 | +154 |
| Opponent | Vampire Counts | 6 | 25 | 659 | 4.8 | 1.2 | 136 | 49 | +87 | 15 of 29 | 13 of 29 | +176 | +73 |
| Opponent | Warriors of Chaos | 7 | 0 | 508 | 3.3 | 1.1 | 155 | 18 | +137 | 13 of 23 | 12 of 23 | +499 | +120 |
| Opponent | Wood Elf Realms | 6 | 98 | 464 | 4.7 | 1.1 | 99 | 20 | +79 | 12 of 28 | 18 of 28 | -31 | +98 |
| **Opponent** | all armies | 36 | 84 | 392 | 3.5 | 1.1 | 113 | 44 | +69 | 60 of 125 | 71 of 125 | -3 | +79 |

### Effective charges: fw-off-db7ca9c-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 0 | 1 (net +143) | 0 | 0 | 4 (net +49) | 1 | 17% (1 of 6) |
| Mine | Chaos Dwarfs | 12 | 0 | 0 | 1 (net +0) | 3 (net -73) | 3 (net +66) | 5 (net +148) | 0 | 8% (1 of 12) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 0 | 2 (net +0) | 0 | 1 (net +60) | 4 (net +180) | 0 | 29% (2 of 7) |
| Mine | Empire of Man | 12 | 1 (net +0) | 0 | 3 (net -116) | 3 (net +83) | 3 (net +13) | 2 (net +124) | 0 | 25% (3 of 12) |
| Mine | Grand Cathay | 20 | 0 | 1 (net +0) | 5 (net +88) | 4 (net +26) | 1 (net +35) | 9 (net +73) | 0 | 25% (5 of 20) |
| Mine | High Elf Realms | 11 | 0 | 1 (net +0) | 0 | 1 (net +600) | 3 (net +148) | 6 (net +146) | 0 | 0% (0 of 11) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 1 (net -80) | 2 (net +78) | 0 | 2 | 0% (0 of 3) |
| Mine | Lizardmen | 4 | 0 | 0 | 2 (net +539) | 1 (net +0) | 0 | 0 | 1 | 67% (2 of 3) |
| Mine | Ogre Kingdoms | 8 | 0 | 0 | 1 (net -34) | 1 (net +0) | 0 | 3 (net +80) | 3 | 20% (1 of 5) |
| Mine | Skaven | 2 | 2 (net +33) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +0) | 1 (net +56) | 2 (net -158) | 1 (net +250) | 1 (net +60) | 2 (net +168) | 0 | 25% (2 of 8) |
| Mine | Vampire Counts | 13 | 0 | 0 | 3 (net +20) | 1 (net +109) | 3 (net +54) | 6 (net +62) | 0 | 23% (3 of 13) |
| Mine | Warriors of Chaos | 12 | 2 (net +448) | 0 | 1 (net +27) | 3 (net +71) | 2 (net +408) | 4 (net -5) | 0 | 8% (1 of 12) |
| Opponent | High Elf Realms | 21 | 3 (net -85) | 0 | 4 (net +56) | 3 (net +59) | 1 (net +0) | 6 (net +63) | 4 | 24% (4 of 17) |
| Opponent | Lizardmen | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 1 | 50% (1 of 2) |
| Opponent | Orc & Goblin Tribes | 9 | 1 (net +0) | 0 | 1 (net -350) | 1 (net +0) | 0 | 1 (net +0) | 5 | 25% (1 of 4) |
| Opponent | Skaven | 6 | 1 (net -210) | 0 | 1 (net +0) | 0 | 0 | 4 (net -69) | 0 | 17% (1 of 6) |
| Opponent | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net -195) | 1 (net +210) | 1 (net +112) | 1 (net +176) | 2 | 25% (1 of 4) |
| Opponent | Vampire Counts | 29 | 5 (net +82) | 2 (net +382) | 5 (net +102) | 6 (net +31) | 3 (net +17) | 7 (net +66) | 1 | 18% (5 of 28) |
| Opponent | Warriors of Chaos | 23 | 4 (net +269) | 2 (net +194) | 3 (net -33) | 1 (net +499) | 0 | 5 (net +106) | 8 | 20% (3 of 15) |
| Opponent | Wood Elf Realms | 28 | 3 (net +45) | 0 | 7 (net +20) | 3 (net -42) | 2 (net +32) | 12 (net +143) | 1 | 26% (7 of 27) |

### Charged fights, damage counted: fw-off-db7ca9c-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 201 | 259 | +137 | 154 | 46 | +107 | +53.5 |
| Mine | 50-54% | 3 | 185 | 157 | +19 | 84 | 65 | +19 | +10.1 |
| Mine | Effective (55-75%) | 21 | 284 | 239 | +50 | 159 | 87 | +72 | +25.4 |
| Mine | 76-89% | 19 | 333 | 172 | +65 | 153 | 70 | +83 | +25.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 | 208 | 152 | +97 | 120 | 26 | +95 | +45.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 19 | 412 | 87 | +104 | 107 | 3 | +104 | +25.3 |
| Mine | No odds | 7 | 279 | 171 | +182 | 203 | 5 | +198 | +71.1 |
| Mine | All fights | 121 | 276 | 167 | +90 | 136 | 41 | +95 | +34.6 |
| Opponent | Long shot (under 50%) | 17 | 287 | 273 | +68 | 136 | 66 | +70 | +24.5 |
| Opponent | 50-54% | 4 | 284 | 303 | +288 | 324 | 24 | +300 | +105.4 |
| Opponent | Effective (55-75%) | 23 | 269 | 219 | +10 | 100 | 79 | +21 | +7.9 |
| Opponent | 76-89% | 15 | 365 | 251 | +63 | 144 | 72 | +72 | +19.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 323 | 232 | +81 | 174 | 94 | +80 | +24.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 432 | 71 | +32 | 53 | 9 | +43 | +10.0 |
| Opponent | No odds | 22 | 280 | 140 | +91 | 108 | 13 | +95 | +33.8 |
| Opponent | All fights | 125 | 310 | 214 | +69 | 138 | 64 | +74 | +24.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-off-db7ca9c-p4 | move | 452 | 119 (26%) | 84 (19%) | 56 (12%) | 277 (61%) |
| fw-off-db7ca9c-p4 | objective | 335 | 42 (13%) | 33 (10%) | 58 (17%) | 235 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

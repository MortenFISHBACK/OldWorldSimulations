# Doctrine scorecard: fw-off-db7ca9c-p3

### Scorecard: fw-off-db7ca9c-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 142 |
| L0110 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 11 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 1 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 3 | 0 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 8 | 4 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 2 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 4 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 926 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 5 | 1 | 0 | 0 | 95 |
| L0709 | 1 | 1 | Mine | yes | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 4 | 5 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 75 |
| L0815 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 679 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 10 | 2 | 1 | 1 | 0 | 0 | 0 | 762 |
| L0831 | 3 | 1 | Opponent | no | 2 | 4 | 0 | 1 | 1 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 492 |
| L0922 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 1 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 0 | 5 | 3 | 0 | 1 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 207 |
| L1122 | 6 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 225 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 1 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | yes | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 50 |
| L1422 | 6 | 1 | Mine | no | 1 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 1 | 0 | 0 | 352 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 126 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 4 | 1 | 4 | 0 | 0 | 0 | 657 |
| L1633 | 1 | 1 | Mine | yes | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 0 | 5 | 3 | 0 | 0 | 0 | 0 | 49 |
| L1731 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 484 |
| L1831 | 1 | 1 | Mine | no | 10 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 642 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 5 | 2 | 0 | 0 | 458 |
| L2033 | 5 | 1 | Opponent | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 4 | 2 | 5 | 0 | 1 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 2 | 0 | 0 | 257 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 8 | 0 | 2 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 6 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 2 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 285 |
| L2832 | 6 | 1 | Mine | no | 1 | 2 | 1 | 1 | 2 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 4 | 3 | 2 | 2 | 2 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 380 |
| **Average** | | | Mine | 31% | 2.7 | 2.7 | 2.4 | 1.1 | 0.4 | 0.0 | 0.0 | 299.2 |
| **Average** | | | Opponent | 31% | 2.1 | 2.4 | 3.0 | 1.6 | 0.4 | 0.0 | 0.0 | 176.7 |

### KPIs: fw-off-db7ca9c-p3

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 176) | 0% (0 of 180) | 0% (0 of 356) |
| Winner chose to follow up after the loser gave ground |  | 96% (69 of 72); on the table 96% | 96% (48 of 50); on the table 96% | 96% (117 of 122); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 91% (10 of 11); on the table 91% | 90% (9 of 10); on the table 90% | 90% (19 of 21); on the table 90% |
| Winner chose to pursue after the loser fled |  | 70% (16 of 23); on the table 70% | 88% (28 of 32); on the table 88% | 80% (44 of 55); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 90% (95 of 106); on the table 90% | 92% (85 of 92); on the table 92% | 91% (180 of 198); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 27% (94 of 342) | 39% (75 of 192) | 32% (169 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (94 of 217) | 49% (75 of 152) | 46% (169 of 369) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 38% (26168 of 68801) | 35% (25030 of 71990) | 36% (51198 of 140791) |
|   infantry points that never fought | lower | 48% (6742 of 14174) | 47% (6706 of 14220) | 47% (13448 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (145 of 272) | 60% (172 of 285) | 57% (317 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 92% (23 of 25); 1.7 uses a game | 88% (21 of 24); 2.6 uses a game | 90% (44 of 49); 2.1 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.5 uses a game | 17% (1 of 6); 0.1 uses a game | 40% (8 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 50% (17 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (28989 of 59391) | 52% (33464 of 64043) | 51% (62453 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (19%) | 1.0 (32%) | 2.4 (23%) |
| MARCHED: its unit marched | 1.5 (22%) | 0.8 (23%) | 2.2 (22%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.3 (9%) | 0.6 (5%) |
| IN COMBAT: engaged in combat | 1.6 (23%) | 0.7 (21%) | 2.2 (22%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 1.2 (18%) | 0.4 (12%) | 1.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (10%) | 0.0 (0%) | 0.7 (7%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.1 | 1.7 | 4.7 | 0.9 | 1.7 |
| not cast | 4.2 | 1.6 | 4.5 | 10.1 | 2.3 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (44%) | 0.3 (7%) | 2.4 (23%) | 0.2 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (22%) | 0.6 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (5%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.2 (16%) | 0.7 (16%) | 2.2 (22%) | 0.6 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (5%) | 0.1 (1%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.1 (2%) | 0.7 (4%) |
| GONE: slain | 1.4 (33%) | 0.1 (5%) | 0.7 (15%) | 1.6 (16%) | 0.1 (6%) | 2.4 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.3 (21%) | 0.4 (8%) | 0.7 (7%) | 0.0 (0%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (4%) | 0.0 (1%) | 0.1 (1%) | 0.6 (26%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (46%) | 0.2 (11%) | 2.0 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.6 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 56% (18 of 32) | 57% (8 of 14) | 57% (26 of 46) |
| the unit moved after it | 89% (16 of 18) | 100% (8 of 8) | 92% (24 of 26) |
| it charged on its next turn | 6% (1 of 18) | 25% (2 of 8) | 12% (3 of 26) |
| the enemy charged it first | 17% (3 of 18) | 12% (1 of 8) | 15% (4 of 26) |
| it fought by the end of its next turn | 17% (3 of 18) | 0% (0 of 8) | 12% (3 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 17% (3 of 18) | 25% (2 of 8) | 19% (5 of 26) |
| none of these (no charge, no fight, no charge escaped) | 61% (11 of 18) | 38% (3 of 8) | 54% (14 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (483 of 789) | 54% (325 of 604) | 58% (808 of 1393) |
|   cavalry | 67% (42 of 63) | 53% (55 of 104) | 58% (97 of 167) |
|   character | 49% (57 of 116) | 23% (29 of 126) | 36% (86 of 242) |
|   chariot | 34% (33 of 96) | 46% (16 of 35) | 37% (49 of 131) |
|   infantry | 56% (113 of 201) | 65% (161 of 248) | 61% (274 of 449) |
|   monster | 47% (17 of 36) | 80% (4 of 5) | 51% (21 of 41) |
|   war machine | 80% (221 of 277) | 70% (60 of 86) | 77% (281 of 363) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (29%) | 1.7 (22%) | 4.2 (26%) |
| CHARGED: it charged | 1.4 (16%) | 1.9 (25%) | 3.3 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.3 (4%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.6 (7%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.2 (14%) | 0.9 (12%) | 2.1 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.4 (5%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (19%) | 1.4 (18%) | 3.0 (18%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.3 (4%) | 0.6 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.2 (3%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.2 | 79% | 7.4 pts | 30 pts |
| character | 2.8 | 0.8 | 79% | 9.1 pts | 25 pts |
| chariot | 1.4 | 0.6 | 73% | 11.7 pts | 16 pts |
| infantry | 11.9 | 4.6 | 73% | 9.8 pts | 116 pts |
| monster | 0.7 | 0.3 | 69% | 16.2 pts | 12 pts |
| war machine | 8.0 | 6.1 | 64% | 20.6 pts | 166 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 6.1 | 5.2 |
| Charges that made contact a game | 3.0 | 4.3 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.88 declared, 0.67 contact (24 units) | 1.39 declared, 0.89 contact (18 units) | 1.10 declared, 0.76 contact (42 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.20 declared, 0.20 contact (5 units) | 1.09 declared, 0.82 contact (11 units) | 0.81 declared, 0.62 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.42 contact (218 units) | 0.71 declared, 0.50 contact (258 units) | 0.66 declared, 0.47 contact (476 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (41 of 77) | 60% (9 of 15) | 50% (5 of 10) | 54% (55 of 102) |
| Character in a unit | 83% (29 of 35) | 77% (10 of 13) | 50% (3 of 6) | 78% (42 of 54) |
| Character on its own | 79% (33 of 42) | 51% (22 of 43) | 22% (15 of 69) | 45% (70 of 154) |
| Chariot | 73% (8 of 11) | 75% (9 of 12) | - | 74% (17 of 23) |
| Infantry | 63% (44 of 70) | 48% (20 of 42) | 20% (1 of 5) | 56% (65 of 117) |
| Monster | 56% (19 of 34) | 86% (6 of 7) | - | 61% (25 of 41) |
| Monstrous | 60% (6 of 10) | 55% (6 of 11) | - | 57% (12 of 21) |
| War Machines | 67% (29 of 43) | 100% (2 of 2) | - | 69% (31 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 75% (3 of 4); on the table 75% | 24% (23 of 96) | 25% | 59% (13 of 22) | 83% (5 of 6); 3.0 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 67% (4 of 6); on the table 67% | 50% (18 of 36) | 51% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 65% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (16 of 18); on the table 89% | 33% (10 of 30) | 43% | 59% (35 of 59) | 0.0 uses a game | 50% (1 of 2); 1.3 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 94% (32 of 34); on the table 94% | 33% (63 of 192) | 35% | 50% (37 of 74) | 89% (16 of 18); 6.6 uses a game | 25% (1 of 4); 0.2 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 84% (21 of 25); on the table 84% | 24% (10 of 42) | 44% | 65% (35 of 54) | 89% (8 of 9); 3.3 uses a game | 33% (4 of 12); 1.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (7 of 7); on the table 100% | - | 53% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 100% (6 of 6); on the table 100% | 67% (4 of 6) | 39% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 37% | 43% (3 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (3 of 3); on the table 100% | 33% (4 of 12) | 0% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 75% (3 of 4); on the table 75% | 25% (3 of 12) | 60% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 93% (14 of 15); on the table 93% | 0% (0 of 6) | 13% | 35% (9 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 93% (27 of 29); on the table 93% | 33% (18 of 54) | 27% | 48% (22 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 91% (32 of 35); on the table 91% | 33% (10 of 30) | 27% | 51% (49 of 96) | 100% (4 of 4); 1.4 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (9 of 9); on the table 100% | 50% (6 of 12) | 52% | 77% (48 of 62) | 91% (10 of 11); 7.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-off-db7ca9c-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (44) | 49% (37) | 48% (81) |
| ...free all their last turn and able to turn (per game) | 0.81 | 0.58 | 1.39 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.17 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.33 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.72 | 1.03 | 2.75 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.67 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.81 | 5.44 | 12.25 |

### Quality by phase: fw-off-db7ca9c-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 56% (72 of 129) | 43% (77 of 178) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (157 of 365) | 47% (72 of 153) |
| Strategy | Close-in objectives charged next turn | 16% (28 of 172) | 18% (36 of 203) |
| Strategy | Support requests answered (helper made contact too) | 44% (4 of 9) | 41% (13 of 32) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (3 of 6) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 51% (21 of 41) | 50% (19 of 38) |
| Strategy | Lone characters that fought | 79% (74 of 94) | 76% (73 of 96) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 299.2 | 176.7 |
| Movement | Fights charged into per game | 2.9 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 92, net +28 | 6 of 104, net +132 |
| Movement | Charges with odds: sweet spot (55-75%) | 20 of 92, net +48 | 21 of 104, net +129 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 92, net +56 | 10 of 104, net -12 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 of 92, net +65 | 43 of 104, net +157 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (127 of 284) | 45% (142 of 316) |
| Shooting | Points destroyed by shooting units | 84.4 | 49.2 |
| Shooting | War machine shots | 6.1 | 1.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (108 of 221) | 34% (23 of 68) |
| Shooting | Points destroyed by war machines | 67.7 | 5.7 |
| Magic | Magic missiles cast | 1.9 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (22 of 67) | 33% (18 of 54) |
| Magic | Wounds caused by magic missiles | 3.4 | 2.8 |
| Magic | Wounds caused by other spells | 2.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 77.2 | 27.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.2 / 0.7 / 0.1 | 2.1 / 0.2 / 0.3 / 0.5 |
| Combat | Points destroyed in combat | 379.0 | 409.5 |
| Combat | Points run down | 53.4 | 137.3 |
| Combat | Net points per charged fight, damage counted | +70 | +73 |
| Combat | Net per 100 charger points, damage counted | +25.3 | +24.6 |
| Combat | First round won (charged fights) | 76% | 63% |
| Combat | Net points per charged fight | +64 | +73 |
| Combat | Net points per supported fight / lone fight | +45 / +65 | +108 / +67 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 103 | 65 of 131 |
| Game | Points lost | 726.3 | 734.8 |
| Game | VP from objectives | 530.0 | 487.5 |
| Game | Lone holders (player turns) | 2.7 | 2.1 |

- Mine won / drew / lost: 12 / 12 / 12 of 36 ended games (of 36); mean margin (Mine - Opponent) +22 VP
- The side that went first won 13 of 24 games with a winner
- Points traded per game (both sides' losses): 1461
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-off-db7ca9c-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 27.1 | 0.2 | +0.0 | 0.0 | 9.2 |
| BACKUP TARGETS | 1.1 | +9.8 | 0.0 | 29.3 | 0.6 | +8.0 | 0.0 | 0.0 |
| BEST OVERALL | 0.6 | +30.9 | 0.0 | 40.6 | 0.3 | +21.8 | 0.0 | 13.6 |
| BEST PREY | 4.6 | +377.4 | 199.1 | 143.9 | 4.4 | +321.7 | 163.1 | 82.7 |
| BEST PRIZE | - | - | - | - | 0.0 | +2.0 | 4.0 | 5.4 |
| BIG CHARACTER SAFETY | 0.1 | -0.8 | 0.0 | 12.3 | 0.1 | -0.3 | 0.0 | 12.3 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 5.6 | 0.0 | 0.1 | +0.0 | 13.3 | 0.0 |
| BLOCKED WHEEL | 0.4 | +19.3 | 0.0 | 0.0 | 0.3 | +4.3 | 0.0 | 7.9 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +1.6 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 100.4 | 15.3 | 0.2 | +0.0 | 33.8 | 9.2 |
| CANNON PLANNED TARGET | 5.4 | +211.3 | 295.9 | 82.6 | 0.8 | +38.0 | 43.6 | 23.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -5.1 | 18.5 | 0.0 | 0.1 | -5.9 | 12.3 | 6.6 |
| CAST JOB | 1.0 | +25.2 | 63.8 | 17.6 | 0.8 | +18.9 | 52.5 | 9.7 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +31.6 | 9.3 | 19.3 | 0.0 | +0.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 31.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.1 | +3.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.7 | 3.0 | 4.9 | 0.2 | -0.7 | 0.0 | 2.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 0.0 | 3.8 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.6 | -73.9 | 9.5 | 21.3 | 0.7 | -44.3 | 42.3 | 9.8 |
| CHARIOT NO STATIC JOB | 0.3 | +0.0 | 8.1 | 14.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.9 | 0.0 | 0.0 | 0.1 | -1.5 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 3.2 | 0.0 | 0.1 | +0.0 | 2.4 | 6.1 |
| COMBAT PIVOT | 0.4 | +0.0 | 13.2 | 8.6 | 0.6 | +0.0 | 45.3 | 47.8 |
| CONVEYANCE SEARCH | 0.7 | +64.2 | 84.4 | 65.1 | 0.3 | +16.9 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 9.0 | +778.7 | 0.0 | 205.1 | 6.1 | +520.3 | 0.0 | 115.8 |
| EDGE GIVE GROUND | 0.2 | +22.5 | 23.3 | 3.2 | 0.2 | +2.9 | 19.3 | 4.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +128.7 | 0.0 | 62.4 | 1.0 | +79.0 | 0.0 | 6.4 |
| FALLBACK BY WORTH | 6.4 | +105.4 | 0.0 | 124.2 | 6.1 | +71.5 | 0.0 | 63.0 |
| FIGHT LIFT | - | - | - | - | 0.1 | +1.8 | 13.1 | 0.0 |
| FIRE AND FLEE | 0.0 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 7.1 | +0.0 | 0.0 | 200.4 | 5.0 | +0.0 | 0.0 | 102.9 |
| FOCUS FIRE | 0.0 | +0.2 | 2.0 | 0.0 | 0.0 | +2.0 | 2.9 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +129.3 | 0.0 | 40.0 | 1.1 | +95.6 | 0.0 | 21.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +9.3 | 0.0 | 12.7 | 0.2 | +23.8 | 0.0 | 6.1 |
| GIVES UP | 1.1 | -25.3 | 102.8 | 16.0 | 1.4 | -48.5 | 239.1 | 26.5 |
| GIVES UP ITS SCREEN | 0.6 | -8.2 | 27.9 | 15.7 | 0.9 | -17.8 | 51.9 | 17.8 |
| GROUND FLIERS | 0.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 10.3 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 21.9 | 3.1 | 0.3 | +0.0 | 5.8 | 19.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +14.4 | 13.8 | 4.5 | 0.1 | +7.5 | 3.5 | 5.9 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 1.4 | 0.1 | +0.0 | 0.0 | 2.7 |
| HUNT IN PAIRS | 0.2 | +15.2 | 0.0 | 13.7 | 0.6 | +31.2 | 0.0 | 5.4 |
| HUNT KEPT | 0.2 | +7.8 | 18.3 | 5.4 | 0.1 | +0.5 | 6.9 | 0.0 |
| HUNT RESULT | 0.2 | +27.8 | 0.0 | 6.9 | 0.2 | +8.8 | 0.0 | 5.6 |
| HUNT THE GUNS | 0.2 | +69.4 | 13.8 | 1.4 | 0.2 | +65.0 | 1.9 | 8.6 |
| JOINT CHARGE PLAN | 0.2 | +8.6 | 0.0 | 0.0 | 0.3 | +5.7 | 6.1 | 10.6 |
| KEEP FALLS | 0.1 | +2.5 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.3 | +1.0 | 28.9 | 0.0 | 0.2 | +2.1 | 4.6 | 7.1 |
| KEEPS ITS TARGET | 1.9 | +58.3 | 134.5 | 25.9 | 1.7 | +51.7 | 226.2 | 19.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +82.8 | 90.8 | 34.2 | 2.1 | +91.8 | 182.5 | 50.4 |
| KILLS COUNT NEXT TURN | 9.5 | +354.2 | 361.0 | 218.6 | 10.4 | +385.0 | 350.1 | 200.2 |
| LONE CHARACTER SAFE SPOT | 0.5 | +17.8 | 9.1 | 23.9 | 0.3 | +17.9 | 0.0 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 6.6 | 0.0 | 0.4 | +0.0 | 6.5 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.3 | +22.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.3 | +94.5 | 49.8 | 14.3 | 1.3 | +55.7 | 53.8 | 21.4 |
| MANOEUVRE | 0.2 | +16.3 | 0.0 | 28.4 | 0.2 | +5.0 | 0.0 | 3.4 |
| MARCH AT ESCAPER | 0.1 | +1.4 | 0.0 | 5.8 | 0.1 | +0.7 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +35.7 | 0.0 | 40.9 | 1.0 | +69.8 | 0.0 | 3.2 |
| MARCH ODDS | 0.7 | +36.1 | 21.1 | 32.0 | 0.9 | +45.5 | 33.4 | 18.9 |
| MARCH OVER CASTS | 0.6 | +23.0 | 0.0 | 34.8 | 0.4 | +28.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.1 | +212.0 | 0.0 | 127.4 | 4.2 | +194.8 | 0.0 | 94.3 |
| MISSILES IN THE MOVE | 4.1 | +133.4 | 0.0 | 101.4 | 4.6 | +75.2 | 0.0 | 72.2 |
| MISSILES NEXT TURN | 5.2 | +95.4 | 0.0 | 148.2 | 5.3 | +57.2 | 0.0 | 68.9 |
| MODEL FACING | 0.0 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 13.4 | 12.1 | 0.1 | +0.0 | 0.0 | 6.5 |
| MOVE AND CAST | 0.4 | +28.6 | 0.0 | 17.6 | 0.3 | +10.4 | 0.0 | 6.5 |
| MOVE SPELL IN RANGE | 0.2 | +6.4 | 0.0 | 21.1 | 0.1 | +2.1 | 0.0 | 6.5 |
| MOVE SPELL OUT OF RANGE | 0.3 | -9.1 | 0.0 | 43.5 | 0.2 | -6.4 | 2.9 | 13.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 12.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +6.5 | 6.6 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -4.3 | 12.0 | 3.4 | 0.5 | -30.1 | 54.4 | 0.0 |
| NOT TURNED | 6.8 | +161.5 | 0.0 | 156.5 | 5.4 | +71.6 | 0.0 | 103.7 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 40.7 | 0.7 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 17.1 | -943.8 | 32.8 | 301.6 | 16.9 | -1032.6 | 49.2 | 273.2 |
| OPENS A LANE | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +0.1 | 0.9 | 0.0 |
| OPENS UP | 0.2 | +17.1 | 16.1 | 0.0 | 0.2 | +11.7 | 12.8 | 0.0 |
| OVERRUNS AWAY | 0.6 | +10.3 | 36.0 | 8.2 | 0.6 | +8.2 | 68.9 | 11.6 |
| PATHS CROSS | 2.7 | +160.4 | 0.0 | 36.8 | 2.5 | +191.0 | 0.0 | 29.1 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.0 | 0.0 | 5.6 | 0.1 | -3.6 | 0.0 | 8.9 |
| PLAN RESULT | 36.6 | +1528.4 | 1164.8 | 973.2 | 35.7 | +1417.7 | 1294.6 | 925.5 |
| PURSUES BIG PREY | 0.2 | -26.2 | 0.0 | 4.0 | 0.1 | -2.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +10.6 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.9 | +167.1 | 0.0 | 56.4 | 3.2 | +201.8 | 0.0 | 52.0 |
| REDIRECT WEIGHED | 0.1 | +10.1 | 7.8 | 6.5 | 0.3 | +8.1 | 7.3 | 19.6 |
| RESTRAINS TO SHOOT | 0.1 | +5.2 | 0.0 | 0.0 | 0.1 | +3.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +103.2 | 207.3 | 38.2 | 2.8 | +54.0 | 264.4 | 89.4 |
| SAFER THAN THE JOB | 0.9 | +60.2 | 0.0 | 22.4 | 0.7 | +54.5 | 0.0 | 21.8 |
| SCOUT SPOT | 0.4 | +0.3 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 2.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 2.0 |
| SEARCH SPOT | 1.8 | +105.3 | 0.0 | 30.3 | 1.5 | +97.8 | 0.0 | 24.2 |
| SECOND HUNTER | 0.1 | -1.1 | 4.6 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.4 | +43.9 | 0.0 | 9.1 | 0.2 | +60.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.8 | +157.9 | 57.4 | 29.6 | 1.7 | +91.4 | 60.2 | 28.8 |
| SET-UP ANY TARGET | 0.4 | +82.3 | 54.4 | 24.3 | 0.1 | +9.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +9.4 | 0.0 | 0.0 | 0.1 | +14.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.6 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.8 | +0.0 | 132.4 | 10.1 | 0.1 | +0.0 | 27.9 | 3.0 |
| SHOTS IN THE MOVE | 12.7 | +640.7 | 0.0 | 195.9 | 8.5 | +273.1 | 0.0 | 128.0 |
| SPELL CATCH ODDS | 0.1 | -4.5 | 20.7 | 2.6 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +94.4 | 75.5 | 45.4 | 0.1 | +9.5 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +20.1 | 91.9 | 83.6 | 2.6 | +42.3 | 62.0 | 48.9 |
| STANDS TO CAST | - | - | - | - | 0.1 | +2.2 | 0.0 | 0.0 |
| STOPS | 0.1 | +5.5 | 9.2 | 0.0 | 0.1 | +0.6 | 1.9 | 2.7 |
| STOPS SHORT OF THE FLANK | 0.5 | +38.5 | 0.0 | 36.8 | 0.4 | +13.1 | 0.0 | 23.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 9.4 |
| SURE CHARGE BEATS ADVANCE | 0.3 | -11.9 | 6.4 | 9.5 | 0.2 | -13.8 | 17.2 | 0.0 |
| SURE REACH TOGETHER | 0.5 | -3.4 | 24.8 | 12.1 | 0.6 | +3.3 | 10.7 | 11.4 |
| THROUGH LINE OF FIRE | 0.5 | +11.4 | 0.0 | 0.0 | 0.2 | +4.5 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -29.8 | 36.9 | 3.4 | 0.4 | -25.0 | 23.0 | 5.2 |
| TWO OR MORE ARRIVE | 0.6 | +5.6 | 0.0 | 3.2 | 0.5 | +6.0 | 6.1 | 16.3 |
| WEARS DOWN | 1.0 | +42.4 | 66.4 | 17.3 | 1.2 | +40.0 | 148.4 | 57.2 |
| WHO HITS BACK | 0.3 | +24.8 | 0.0 | 3.4 | 0.2 | +11.4 | 0.0 | 5.4 |
| WHOLE FIGHT | 0.3 | +17.8 | 29.4 | 6.9 | 0.4 | +29.3 | 73.3 | 10.1 |
| WHOLE FIGHT GAIN | 0.2 | +11.2 | 20.1 | 1.5 | 0.6 | +38.3 | 29.2 | 9.6 |

### Rule changes: fw-off-db7ca9c-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1224 | 1224 | 1224 | 34.00 | -71148 | -58.1 |
| PATHS CROSS | 187 | 187 | 187 | 5.19 | +12651 | +67.6 |
| KILLS COUNT NEXT TURN | 716 | 705 | 179 | 4.97 | +6004 | +33.5 |
| BEST PREY | 326 | 317 | 160 | 4.44 | +7550 | +47.2 |
| SEARCH SPOT | 119 | 119 | 118 | 3.28 | +7317 | +62.0 |
| COUNTER-CHARGE COVER | 542 | 256 | 100 | 2.78 | +5977 | +59.8 |
| FACES THE THREAT | 99 | 99 | 99 | 2.75 | +7478 | +75.5 |
| FALLBACK BY WORTH | 450 | 450 | 93 | 2.58 | +6372 | +68.5 |
| FOLLOW UP WEIGHED | 73 | 73 | 73 | 2.03 | +8099 | +110.9 |
| ARTILLERY RE-ROLL WEIGHED | 67 | 67 | 67 | 1.86 | +0 | +0.0 |
| MARCH CHECK | 72 | 66 | 59 | 1.64 | +3174 | +53.8 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +4130 | +71.2 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| MARCH ODDS | 57 | 56 | 54 | 1.50 | +741 | +13.7 |
| RISK BY ARC | 197 | 187 | 53 | 1.47 | +1654 | +31.2 |
| SHOTS IN THE MOVE | 763 | 480 | 53 | 1.47 | +2376 | +44.8 |
| SET UP TOGETHER | 126 | 106 | 52 | 1.44 | +3536 | +68.0 |
| MAX FOR POSITIONING | 333 | 163 | 49 | 1.36 | +719 | +14.7 |
| CHARGE NOW WEIGHED | 47 | 47 | 47 | 1.31 | +4170 | +88.7 |
| MISSILES IN THE MOVE | 315 | 168 | 44 | 1.22 | +1266 | +28.8 |
| KILLS COUNT | 131 | 122 | 43 | 1.19 | +1968 | +45.8 |
| CANNON PLANNED TARGET | 224 | 224 | 42 | 1.17 | -564 | -13.4 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| COMBAT PIVOT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| BEST OVERALL | 35 | 35 | 35 | 0.97 | +1895 | +54.2 |
| CAST JOB | 62 | 59 | 34 | 0.94 | +503 | +14.8 |
| SHOT REPLANNED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +1858 | +56.3 |
| LONE WIZARD KEPT IN | 32 | 32 | 32 | 0.89 | +2140 | +66.9 |
| ADVANCE LANE KEPT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| KEEPS ITS TARGET | 132 | 128 | 31 | 0.86 | +592 | +19.1 |
| REDIRECT COUNTER | 221 | 87 | 31 | 0.86 | +1757 | +56.7 |
| MAKE SURE TOGETHER | 92 | 63 | 29 | 0.81 | +1376 | +47.4 |
| MOVE AND CAST | 28 | 28 | 28 | 0.78 | +1402 | +50.1 |
| BLOCKED WHEEL | 26 | 26 | 26 | 0.72 | +850 | +32.7 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 25 | 25 | 25 | 0.69 | +574 | +22.9 |
| SURE CHARGE BEATS ADVANCE | 18 | 18 | 18 | 0.50 | -925 | -51.4 |
| WHOLE FIGHT GAIN | 29 | 29 | 18 | 0.50 | +662 | +36.8 |
| MANOEUVRE | 17 | 17 | 17 | 0.47 | +767 | +45.1 |
| REDIRECT WEIGHED | 17 | 17 | 17 | 0.47 | +672 | +39.5 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +988 | +58.1 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.44 | +27 | +1.7 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +1193 | +79.5 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTING BLOCK | 19 | 18 | 14 | 0.39 | +288 | +20.6 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -51 | -3.7 |
| PURSUES BIG PREY | 12 | 12 | 12 | 0.33 | -1032 | -86.0 |
| WEARS DOWN | 80 | 77 | 12 | 0.33 | +339 | +28.2 |
| CHARIOT NO STATIC JOB | 14 | 14 | 10 | 0.28 | -1268 | -126.8 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -200 | -20.0 |
| BIG CHARACTER SAFETY | 9 | 9 | 9 | 0.25 | -39 | -4.3 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WHOLE FIGHT | 25 | 23 | 9 | 0.25 | +830 | +92.2 |
| BACKUP TARGETS | 61 | 29 | 7 | 0.19 | +41 | +5.8 |
| HUNT ADVANCE | 13 | 13 | 7 | 0.19 | +374 | +53.5 |
| LONE WIZARD HOLDS BACK | 16 | 16 | 7 | 0.19 | -223 | -31.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| OPENS UP | 16 | 15 | 7 | 0.19 | +131 | +18.7 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +316 | +45.2 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +163 | +27.2 |
| MISSILES NEXT TURN | 377 | 192 | 6 | 0.17 | +44 | +7.3 |
| SURE REACH TOGETHER | 42 | 35 | 6 | 0.17 | +44 | +7.2 |
| CARRIES OUT SET-UP | 9 | 9 | 5 | 0.14 | -398 | -79.5 |
| EDGE GIVE GROUND | 17 | 17 | 5 | 0.14 | +430 | +85.9 |
| HUNT IN PAIRS | 29 | 15 | 5 | 0.14 | +176 | +35.2 |
| KEEPS ITS PREY | 18 | 16 | 5 | 0.14 | +17 | +3.4 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 4 | 0.11 | +136 | +34.0 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -12 | -4.0 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +74 | +24.6 |
| JOINT CHARGE PLAN | 18 | 18 | 3 | 0.08 | +155 | +51.8 |
| OVERRUNS AWAY | 44 | 42 | 3 | 0.08 | +66 | +22.1 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +84 | +42.0 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +78 | +38.8 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +9 | +4.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -39 | -39.4 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +6 | +6.1 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +415 | +415.4 |
| GIVES UP | 87 | 80 | 1 | 0.03 | +26 | +25.6 |
| GIVES UP ITS SCREEN | 56 | 56 | 1 | 0.03 | +13 | +13.0 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MODEL FACING | 1 | 1 | 1 | 0.03 | +105 | +105.0 |
| MOVE SPELL IN RANGE | 9 | 5 | 1 | 0.03 | +21 | +20.6 |
| NEEDED THERE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +323 | +323.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +122 | +121.9 |
| STOPS | 5 | 4 | 1 | 0.03 | +81 | +81.1 |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 43 | 43 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 436 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 18 | 18 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 8 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 31 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 34 | 34 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 19 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT NEEDED | 24 | 24 | 0 | 0.00 | - | - |
| NOT TURNED | 441 | 441 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 2600 | trace | - | - | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL CATCH ODDS | 5 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 138 | not checked | - | - | - | - |
| TURN WORTH | 30 | 28 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 39 | 37 | 0 | 0.00 | - | - |

### Off best figure: fw-off-db7ca9c-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.28 | 14.33 | 60.9 |
| FALLBACK | gate | 1.06 | 0.97 | 51.1 |
| RULE SWITCHED OFF | gate | 0.92 | 0.75 | 15.1 |
| TURN GATE | gate | 0.50 | 0.31 | 37.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.31 | 0.19 | 51.4 |
| PURSUES BIG PREY | rule | 0.22 | 0.11 | 86.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.14 | 98.2 |
| CHARIOT NO STATIC JOB | rule | 0.25 | 0.03 | 126.8 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.14 | 20.0 |
| CHAFF PASSED | rule | 0.11 | 0.14 | 5.7 |
| PATHS CROSS | rule | 0.19 | 0.06 | 35.7 |
| AFTERMATH BAND | gate | 0.06 | 0.17 | 2.6 |
| CANNON PLANNED TARGET | rule | 0.19 | 0.03 | 99.9 |
| SUPPORT REQUEST | gate | 0.06 | 0.14 | 102.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.08 | 142.0 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.03 | 57.5 |
| CARRIES OUT SET-UP | rule | 0.06 | 0.08 | 79.5 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.03 | 13.8 |
| BLOCKED WHEEL | rule | 0.08 | 0.03 | 16.5 |
| MARCH ODDS | rule | 0.08 | 0.03 | 13.1 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.03 | 13.8 |
| CATCH ODDS | rule | 0.06 | 0.03 | 4.0 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.03 | 7.1 |
| FRIENDS SHOTS CHECKED | rule | - | 0.06 | 3.3 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.03 | 111.6 |
| BEST PRIZE | rule | - | 0.03 | 39.4 |
| REDIRECT WEIGHED | rule | - | 0.03 | 39.4 |

### Plans: fw-off-db7ca9c-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.8 | 20% | 495 | 458 | 93% |
| Mine | charge | 2.8 | 61% | 299 | 214 | 72% |
| Mine | close in | 4.8 | 27% | 392 | 148 | 38% |
| Mine | hold | 3.4 | 43% | 208 | 0 | 0% |
| Mine | join | 0.5 | 88% | 15 | 0 | 0% |
| Mine | shoot | 8.7 | 64% | 277 | 708 | 255% |
| Mine | support | 3.8 | 84% | 223 | 0 | 0% |
| Opponent | advance | 12.3 | 23% | 479 | 477 | 100% |
| Opponent | charge | 4.4 | 61% | 457 | 468 | 102% |
| Opponent | close in | 5.5 | 28% | 390 | 204 | 52% |
| Opponent | hold | 3.7 | 32% | 314 | 0 | 0% |
| Opponent | join | 0.7 | 92% | 28 | 0 | 0% |
| Opponent | shoot | 3.7 | 58% | 93 | 269 | 290% |
| Opponent | support | 5.4 | 87% | 212 | 0 | 0% |

### Packages: hunt the guns, fw-off-db7ca9c-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 0 | 33% | 67% | 0% | 3.2 | 417 | 167 | 33% | 22 |
| Opponent | 0.2 | 7 | 1 | 17% | 33% | 0% | 2.0 | 347 | 53 | 33% | 64 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 0 | 40% | 80% | 0% | 3.2 | 392 | 200 | 40% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 172 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 542 | 0 | 0% | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 19 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 60 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Tomb Kings of Khemri | 0.3 | 2 | 1 | 0% | 0% | 0% | - | 426 | 0 | 0% | 12 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 75 | 73 | 100% | 46 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 375 | 0 | 0% | 91 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 253 | 243 | 100% | 18 |

### Battle groups: fw-off-db7ca9c-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.0 | 27% | 40% | 10% | 33% | 43% | 10% | 14% | 33% | 0% |
| Mine | REDIRECT COUNTER | 2.9 | 29% | 71% | 6% | 50% | 21% | 3% | 3% | 69% | 3% |
| Opponent | COUNTER-CHARGE COVER | 6.1 | 21% | 63% | 17% | 62% | 29% | 8% | 21% | 42% | 0% |
| Opponent | REDIRECT COUNTER | 3.2 | 27% | 74% | 19% | 0% | 20% | 0% | 16% | 56% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-off-db7ca9c-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 40 | 71 (40) | 35 | 36 | 64 | 50% | 2.7 | 88 (20) | 0 (8) | 86 (12) | 91 (32) | 0 (8) |
| Mine | Character | 120 | 53 (120) | 53 | 0 | 34 | 19% | 2.4 | 68 (43) | 53 (55) | 30 (6) | 69 (55) | 46 (49) |
| Mine | Clean-up | 15 | 47 (15) | 12 | 35 | 34 | 27% | 3.3 | 49 (7) | 44 (6) | 52 (2) | 65 (8) | 23 (7) |
| Mine | Fast Hammer | 43 | 24 (43) | 15 | 9 | 44 | 26% | 3.2 | 19 (24) | 31 (13) | 31 (6) | 31 (31) | 2 (12) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 33% | 6.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 50 | 35 (50) | 22 | 13 | 45 | 16% | 2.7 | 4 (13) | 41 (32) | 80 (5) | 37 (34) | 31 (16) |
| Mine | Holder | 25 | 52 (25) | 1 | 51 | 36 | 32% | 3.7 | 41 (6) | 67 (13) | 16 (6) | 67 (14) | 32 (11) |
| Mine | Shooter | 38 | 86 (38) | 49 | 37 | 36 | 3% | 1.7 | 105 (10) | 91 (25) | 6 (3) | 100 (24) | 65 (14) |
| Mine | Support | 4 | 46 (4) | 46 | 0 | 39 | 25% | 2.0 | 0 (1) | - | 79 (3) | 42 (3) | 59 (1) |
| Mine | War machine | 52 | 36 (52) | 36 | 0 | 35 | 0% | 1.2 | 44 (14) | 36 (34) | 0 (4) | 37 (14) | 35 (38) |
| Mine | Wizard | 15 | 15 (15) | 15 | 0 | 61 | 0% | 2.5 | 0 (4) | 6 (5) | 131 (1) | 48 (5) | 4 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 73 | 47 (73) | 13 | 35 | 63 | 41% | 2.9 | 26 (31) | 130 (13) | 23 (29) | 63 (52) | 12 (21) |
| Opponent | Character | 101 | 60 (101) | 60 | 0 | 29 | 21% | 2.1 | 59 (37) | 61 (49) | 89 (7) | 68 (52) | 54 (41) |
| Opponent | Clean-up | 9 | 35 (9) | 11 | 25 | 23 | 22% | 3.0 | 0 (3) | 23 (4) | 148 (2) | 48 (5) | 24 (4) |
| Opponent | Fast Hammer | 60 | 43 (60) | 25 | 18 | 45 | 22% | 2.7 | 25 (31) | 48 (17) | 92 (12) | 46 (32) | 39 (28) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 25 (47) | 20 | 6 | 53 | 26% | 3.0 | 27 (15) | 27 (28) | 0 (4) | 28 (25) | 21 (22) |
| Opponent | Holder | 40 | 54 (40) | 0 | 54 | 29 | 42% | 2.5 | 32 (10) | 71 (19) | 47 (10) | 61 (27) | 41 (12) |
| Opponent | Shooter | 28 | 35 (28) | 26 | 9 | 54 | 4% | 1.3 | 14 (7) | 34 (20) | 195 (1) | 44 (17) | 23 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 25% | 4.7 | 0 (1) | 0 (1) | 0 (2) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 38 (17) | 38 | 0 | 49 | 6% | 1.5 | 190 (3) | 9 (10) | 17 (4) | 226 (3) | 5 (14) |
| Opponent | Wizard | 33 | 19 (33) | 19 | 0 | 36 | 9% | 2.0 | 3 (13) | 84 (7) | 0 (4) | 18 (12) | 30 (12) |

### Charged fights: fw-off-db7ca9c-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 39 | 94 | 1.0 | 1.2 | 94 | 0 | +94 | 0 of 4 | 4 of 4 | +45 | +110 |
| Mine | Chaos Dwarfs | 4 | 202 | 290 | 2.5 | 1.0 | 116 | 11 | +105 | 3 of 10 | 6 of 9 | - | +105 |
| Mine | Dwarfen Mountain Holds | 3 | 518 | 22 | 3.0 | 1.1 | 7 | 57 | -50 | 3 of 9 | 4 of 9 | -185 | -33 |
| Mine | Empire of Man | 5 | 321 | 107 | 2.4 | 1.0 | 45 | 41 | +4 | 5 of 12 | 10 of 12 | - | +4 |
| Mine | Grand Cathay | 5 | 461 | 243 | 3.4 | 1.1 | 71 | 0 | +71 | 2 of 17 | 16 of 17 | +55 | +72 |
| Mine | High Elf Realms | 4 | 239 | 351 | 4.0 | 1.1 | 88 | 22 | +66 | 6 of 16 | 13 of 16 | +0 | +71 |
| Mine | Kingdom of Bretonnia | 1 | 108 | 639 | 5.0 | 1.0 | 128 | 0 | +128 | 1 of 5 | 3 of 5 | - | +128 |
| Mine | Lizardmen | 1 | 232 | 430 | 2.0 | 1.0 | 215 | 24 | +190 | 0 of 2 | 2 of 2 | - | +190 |
| Mine | Ogre Kingdoms | 1 | 512 | 0 | 2.0 | 1.0 | 0 | 84 | -84 | 1 of 2 | 1 of 2 | - | -84 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 337 | 5.0 | 1.2 | 67 | 11 | +56 | 1 of 5 | 3 of 5 | +145 | +34 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 362 | 4.0 | 1.0 | 90 | 40 | +50 | 1 of 8 | 5 of 8 | - | +50 |
| Mine | Vampire Counts | 2 | 0 | 963 | 4.5 | 1.2 | 214 | 56 | +158 | 3 of 9 | 7 of 9 | +129 | +167 |
| Mine | Warriors of Chaos | 2 | 10 | 288 | 2.0 | 1.0 | 144 | 64 | +80 | 2 of 4 | 4 of 4 | - | +80 |
| **Mine** | all armies | 36 | 229 | 261 | 2.9 | 1.1 | 91 | 27 | +64 | 28 of 103 | 78 of 102 | +45 | +65 |
| Opponent | Empire of Man | 1 | 380 | 477 | 4.0 | 1.0 | 119 | 0 | +119 | 2 of 4 | 3 of 4 | - | +119 |
| Opponent | Grand Cathay | 3 | 105 | 435 | 2.7 | 1.4 | 163 | 0 | +163 | 1 of 8 | 7 of 8 | +952 | +51 |
| Opponent | High Elf Realms | 3 | 305 | 130 | 2.3 | 1.3 | 56 | 81 | -25 | 3 of 7 | 3 of 7 | -110 | +9 |
| Opponent | Kingdom of Bretonnia | 2 | 48 | 254 | 1.5 | 1.0 | 169 | 92 | +77 | 2 of 3 | 1 of 3 | - | +77 |
| Opponent | Orc & Goblin Tribes | 1 | 60 | 126 | 4.0 | 1.0 | 32 | 14 | +18 | 2 of 4 | 1 of 4 | - | +18 |
| Opponent | Skaven | 1 | 60 | 105 | 1.0 | 1.0 | 105 | 0 | +105 | 0 of 1 | 0 of 1 | - | +105 |
| Opponent | Tomb Kings of Khemri | 4 | 57 | 660 | 5.0 | 1.2 | 132 | 37 | +95 | 8 of 20 | 13 of 20 | -52 | +132 |
| Opponent | Vampire Counts | 6 | 14 | 750 | 6.2 | 1.2 | 122 | 68 | +54 | 21 of 37 | 27 of 37 | +55 | +54 |
| Opponent | Warriors of Chaos | 9 | 24 | 590 | 3.9 | 1.1 | 152 | 47 | +104 | 21 of 35 | 23 of 35 | +262 | +84 |
| Opponent | Wood Elf Realms | 6 | 103 | 61 | 2.0 | 1.1 | 30 | 26 | +4 | 5 of 12 | 4 of 12 | +210 | -14 |
| **Opponent** | all armies | 36 | 82 | 437 | 3.6 | 1.2 | 120 | 47 | +73 | 65 of 131 | 82 of 131 | +108 | +67 |

### Effective charges: fw-off-db7ca9c-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 2 (net +165) | 2 (net +22) | 0 | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 10 | 0 | 0 | 3 (net +110) | 4 (net +73) | 0 | 2 (net +125) | 1 | 33% (3 of 9) |
| Mine | Dwarfen Mountain Holds | 9 | 1 (net -185) | 0 | 2 (net -30) | 2 (net +32) | 0 | 3 (net -89) | 1 | 25% (2 of 8) |
| Mine | Empire of Man | 12 | 0 | 0 | 4 (net +0) | 1 (net +0) | 1 (net +72) | 6 (net -4) | 0 | 33% (4 of 12) |
| Mine | Grand Cathay | 17 | 2 (net +110) | 2 (net +35) | 2 (net +107) | 3 (net +59) | 2 (net +64) | 5 (net +81) | 1 | 12% (2 of 16) |
| Mine | High Elf Realms | 16 | 0 | 0 | 1 (net +0) | 3 (net +162) | 2 (net +0) | 7 (net +2) | 3 | 8% (1 of 13) |
| Mine | Kingdom of Bretonnia | 5 | 2 (net +95) | 0 | 1 (net +109) | 0 | 0 | 1 (net +236) | 1 | 25% (1 of 4) |
| Mine | Lizardmen | 2 | 1 (net +67) | 0 | 0 | 1 (net +314) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 0 | 2 (net +72) | 3 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +0) | 0 | 2 (net -161) | 0 | 2 (net +30) | 3 (net +221) | 0 | 25% (2 of 8) |
| Mine | Vampire Counts | 9 | 2 (net +51) | 0 | 3 (net +153) | 0 | 1 (net +258) | 3 (net +203) | 0 | 33% (3 of 9) |
| Mine | Warriors of Chaos | 4 | 1 (net -111) | 0 | 1 (net +236) | 0 | 0 | 2 (net +98) | 0 | 25% (1 of 4) |
| Opponent | Empire of Man | 4 | 0 | 0 | 1 (net +189) | 1 (net +0) | 0 | 2 (net +144) | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 8 | 0 | 0 | 2 (net +112) | 2 (net +0) | 1 (net +0) | 3 (net +360) | 0 | 25% (2 of 8) |
| Opponent | High Elf Realms | 7 | 1 (net +270) | 1 (net -221) | 1 (net -347) | 0 | 1 (net +0) | 2 (net +0) | 1 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +434) | 2 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +105) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 20 | 0 | 0 | 2 (net +352) | 2 (net +120) | 3 (net -150) | 8 (net +82) | 5 | 13% (2 of 15) |
| Opponent | Vampire Counts | 37 | 3 (net -47) | 3 (net -534) | 5 (net +138) | 5 (net +22) | 4 (net +71) | 12 (net +215) | 5 | 16% (5 of 32) |
| Opponent | Warriors of Chaos | 35 | 2 (net +330) | 3 (net -82) | 7 (net +148) | 4 (net +80) | 1 (net +45) | 13 (net +131) | 5 | 23% (7 of 30) |
| Opponent | Wood Elf Realms | 12 | 0 | 0 | 3 (net +70) | 1 (net +0) | 0 | 2 (net +0) | 6 | 50% (3 of 6) |

### Charged fights, damage counted: fw-off-db7ca9c-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 264 | 227 | +28 | 114 | 91 | +23 | +8.7 |
| Mine | 50-54% | 2 | 211 | 174 | +35 | 35 | 0 | +35 | +16.6 |
| Mine | Effective (55-75%) | 20 | 286 | 249 | +48 | 91 | 42 | +49 | +17.1 |
| Mine | 76-89% | 16 | 262 | 163 | +104 | 114 | 12 | +102 | +39.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 262 | 170 | +65 | 129 | 52 | +77 | +29.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 383 | 83 | +56 | 76 | 0 | +76 | +19.8 |
| Mine | No odds | 11 | 265 | 184 | +74 | 101 | 15 | +86 | +32.4 |
| Mine | All fights | 103 | 278 | 183 | +64 | 108 | 38 | +70 | +25.3 |
| Opponent | Long shot (under 50%) | 6 | 298 | 336 | +132 | 280 | 161 | +118 | +39.6 |
| Opponent | 50-54% | 7 | 272 | 347 | -296 | 55 | 344 | -289 | -106.1 |
| Opponent | Effective (55-75%) | 21 | 319 | 242 | +129 | 182 | 72 | +110 | +34.4 |
| Opponent | 76-89% | 17 | 286 | 216 | +46 | 62 | 22 | +40 | +14.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 43 | 303 | 223 | +157 | 191 | 25 | +166 | +54.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 484 | 94 | -12 | 68 | 81 | -13 | -2.7 |
| Opponent | No odds | 27 | 215 | 228 | +29 | 89 | 56 | +33 | +15.4 |
| Opponent | All fights | 131 | 297 | 228 | +73 | 139 | 66 | +73 | +24.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-off-db7ca9c-p3 | move | 443 | 102 (23%) | 68 (15%) | 50 (11%) | 291 (66%) |
| fw-off-db7ca9c-p3 | objective | 375 | 63 (17%) | 46 (12%) | 43 (11%) | 269 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: fw-on-db7ca9c-p1

### Scorecard: fw-on-db7ca9c-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 9 | 6 | 1 | 1 | 0 | 0 | 0 | 322 |
| L0102 | 6 | 1 | Opponent | no | 5 | 1 | 4 | 4 | 0 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 5 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 4 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 77 |
| L0135 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 5 | 1 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 6 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 2 | 4 | 3 | 0 | 0 | 0 | 0 | 1104 |
| L0421 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 515 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 475 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 4 | - | 1 | 1 | 0 | 0 | 0 | 700 |
| L0612 | 6 | 1 | Opponent | no | 6 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 984 |
| L0628 | 4 | 1 | Opponent | no | 5 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 3 | 3 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 1 | 6 | 1 | 0 | 2 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 5 | - | 1 | 3 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 405 |
| L0823 | 1 | 1 | Mine | no | 4 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 2 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 3 | 6 | 1 | 1 | 0 | 0 | 0 | 726 |
| L0913 | 1 | 1 | Opponent | no | 3 | 6 | 0 | 0 | 2 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 793 |
| L0930 | 6 | 1 | Opponent | no | 8 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 3 | - | 0 | 5 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 7 | 3 | 0 | 0 | 1 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 532 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 284 |
| L1431 | 3 | 1 | Mine | yes | 8 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | yes | 4 | 6 | 2 | 0 | 1 | 0 | 0 | 732 |
| L1527 | 3 | 1 | Mine | yes | 8 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 6 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 4 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 5 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 3 | 3 | 0 | 2 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | no | 3 | - | 0 | 1 | 1 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 355 |
| L2127 | 3 | 1 | Opponent | no | 2 | 3 | 5 | 0 | 0 | 0 | 0 | 133 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | - | 0 | 1 | 2 | 0 | 0 | 1169 |
| L2335 | 1 | 1 | Mine | no | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 245 |
| L2335 | 1 | 1 | Opponent | no | 3 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 3 | 1 | 3 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 6 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 32% | 2.7 | 2.9 | 1.9 | 1.1 | 0.2 | 0.0 | 0.0 | 272.8 |
| **Average** | | | Opponent | 21% | 2.6 | 2.9 | 2.6 | 1.7 | 0.5 | 0.0 | 0.0 | 186.3 |

### KPIs: fw-on-db7ca9c-p1

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 62% (109 of 176) | 19% (36 of 193) | 39% (145 of 369) |
| Winner chose to follow up after the loser gave ground |  | 96% (69 of 72); on the table 99% | 96% (27 of 28); on the table 96% | 96% (96 of 100); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 82% (9 of 11); on the table 82% | 89% (16 of 18); on the table 94% | 86% (25 of 29); on the table 90% |
| Winner chose to pursue after the loser fled |  | 73% (22 of 30); on the table 87% | 83% (29 of 35); on the table 91% | 78% (51 of 65); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 88% (100 of 113); on the table 94% | 89% (72 of 81); on the table 94% | 89% (172 of 194); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 37% (123 of 330) | 29% (60 of 210) | 34% (183 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (123 of 232) | 39% (60 of 155) | 47% (183 of 387) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 63% (19 of 30) | 55% (33 of 60) | 58% (52 of 90) |
| Points that never fought | lower | 37% (26796 of 71484) | 41% (29298 of 71889) | 39% (56094 of 143373) |
|   infantry points that never fought | lower | 44% (7481 of 16863) | 59% (7917 of 13348) | 51% (15398 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (152 of 279) | 61% (179 of 295) | 58% (331 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.7 uses a game | 75% (15 of 20); 1.6 uses a game | 81% (34 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.5 uses a game | 0% (0 of 8); 0.0 uses a game | 42% (10 of 24); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 42% (5 of 12); 0.1 uses a game | 52% (16 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (28741 of 59666) | 57% (35471 of 62699) | 52% (64212 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (23%) | 1.4 (33%) | 2.7 (27%) |
| MARCHED: its unit marched | 1.4 (25%) | 0.9 (22%) | 2.4 (24%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (3%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.6 (28%) | 0.5 (12%) | 2.1 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 0.5 (9%) | 0.7 (17%) | 1.2 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (11%) | 0.2 (4%) | 0.8 (8%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.5 | 1.4 | 5.1 | 0.6 | 1.5 |
| not cast | 4.0 | 2.8 | 3.2 | 9.9 | 1.7 | 22.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (40%) | 0.3 (9%) | 2.7 (27%) | 0.4 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.4 (24%) | 0.5 (27%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.2 (8%) | 0.5 (15%) | 2.1 (21%) | 0.4 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (11%) | 0.3 (9%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.5 (2%) |
| GONE: slain | 0.9 (22%) | 0.4 (13%) | 0.5 (15%) | 1.2 (12%) | 0.1 (8%) | 2.4 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (10%) | 0.2 (8%) | 0.2 (5%) | 0.8 (8%) | 0.0 (0%) | 1.5 (7%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.1 (3%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.3 (16%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (56%) | 0.3 (10%) | 1.5 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.5 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 69% (25 of 36) | 67% (10 of 15) | 69% (35 of 51) |
| the unit moved after it | 64% (16 of 25) | 80% (8 of 10) | 69% (24 of 35) |
| it charged on its next turn | 0% (0 of 25) | 0% (0 of 10) | 0% (0 of 35) |
| the enemy charged it first | 20% (5 of 25) | 10% (1 of 10) | 17% (6 of 35) |
| it fought by the end of its next turn | 16% (4 of 25) | 10% (1 of 10) | 14% (5 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 16% (4 of 25) | 20% (2 of 10) | 17% (6 of 35) |
| none of these (no charge, no fight, no charge escaped) | 56% (14 of 25) | 70% (7 of 10) | 60% (21 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (629 of 954) | 58% (347 of 596) | 63% (976 of 1550) |
|   cavalry | 63% (52 of 82) | 63% (74 of 117) | 63% (126 of 199) |
|   character | 61% (75 of 122) | 31% (34 of 111) | 47% (109 of 233) |
|   chariot | 52% (51 of 98) | 54% (22 of 41) | 53% (73 of 139) |
|   infantry | 61% (195 of 322) | 63% (157 of 250) | 62% (352 of 572) |
|   monster | 57% (24 of 42) | 38% (9 of 24) | 50% (33 of 66) |
|   war machine | 81% (232 of 288) | 96% (51 of 53) | 83% (283 of 341) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.1 (35%) | 1.9 (28%) | 5.1 (32%) |
| CHARGED: it charged | 0.9 (10%) | 1.4 (20%) | 2.3 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.4 (6%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.3 (15%) | 1.3 (18%) | 2.6 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.5 (8%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (18%) | 1.0 (15%) | 2.7 (17%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (3%) | 0.5 (3%) |
| OTHER BAR | 0.4 (5%) | 0.2 (2%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.1 | 81% | 5.0 pts | 25 pts |
| character | 3.6 | 0.8 | 80% | 7.4 pts | 27 pts |
| chariot | 2.0 | 1.3 | 60% | 14.0 pts | 28 pts |
| infantry | 14.5 | 5.0 | 75% | 8.6 pts | 125 pts |
| monster | 1.1 | 0.4 | 78% | 5.8 pts | 6 pts |
| war machine | 7.9 | 4.9 | 66% | 21.3 pts | 167 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 5.2 | 4.6 |
| Charges that made contact a game | 3.1 | 3.6 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.70 declared, 0.60 contact (20 units) | 0.29 declared, 0.21 contact (14 units) | 0.53 declared, 0.44 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.33 declared, 1.00 contact (6 units) | 1.56 declared, 1.00 contact (9 units) | 1.47 declared, 1.00 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.38 contact (245 units) | 0.61 declared, 0.43 contact (277 units) | 0.56 declared, 0.40 contact (522 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 51% (36 of 70) | 62% (13 of 21) | 62% (5 of 8) | 55% (54 of 99) |
| Character in a unit | 79% (33 of 42) | 77% (17 of 22) | 100% (2 of 2) | 79% (52 of 66) |
| Character on its own | 87% (39 of 45) | 53% (20 of 38) | 28% (18 of 64) | 52% (77 of 147) |
| Chariot | 69% (11 of 16) | 60% (6 of 10) | - | 65% (17 of 26) |
| Infantry | 49% (44 of 89) | 31% (11 of 36) | 50% (1 of 2) | 44% (56 of 127) |
| Monster | 56% (18 of 32) | 60% (6 of 10) | - | 57% (24 of 42) |
| Monstrous | 82% (9 of 11) | 57% (8 of 14) | - | 68% (17 of 25) |
| War Machines | 80% (33 of 41) | 100% (1 of 1) | - | 81% (34 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 100% (16 of 16); on the table 100% | 36% (49 of 138) | 44% | 55% (18 of 33) | 78% (7 of 9); 3.2 uses a game | 100% (3 of 3); 1.5 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 88% (15 of 17); on the table 88% | 29% (7 of 24) | 22% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 60% (6 of 10); on the table 80% | - | 52% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 83% (10 of 12); on the table 92% | 64% (23 of 36) | 60% | 66% (42 of 64) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (10 of 10); on the table 100% | 39% (42 of 108) | 43% | 41% (18 of 44) | 100% (12 of 12); 9.2 uses a game | 100% (1 of 1); 0.2 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 81% (17 of 21); on the table 90% | 33% (10 of 30) | 35% | 51% (25 of 49) | 100% (5 of 5); 2.5 uses a game | 28% (5 of 18); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 34% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 42% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 80% (4 of 5); on the table 80% | 8% (1 of 12) | 33% | 71% (15 of 21) | 33% (1 of 3); 1.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (10 of 10); on the table 100% | 6% (2 of 36) | 8% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 100% (9 of 9); on the table 100% | 43% (13 of 30) | 29% | 50% (17 of 34) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Tomb Kings of Khemri | 6 | 88% (15 of 17); on the table 94% | 0% (0 of 12) | 38% | 43% (13 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 84% (26 of 31); on the table 94% | 35% (19 of 54) | 30% | 64% (32 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 94% (15 of 16); on the table 100% | 33% (10 of 30) | 42% | 66% (49 of 74) | 100% (4 of 4); 2.2 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 93% (14 of 15); on the table 93% | 23% (7 of 30) | 46% | 58% (38 of 66) | 33% (2 of 6); 1.8 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-on-db7ca9c-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (40) | 46% (28) | 52% (68) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.53 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.14 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.39 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.94 | 1.47 | 3.42 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.33 | 0.83 | 2.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.28 | 6.08 | 13.36 |

### Quality by phase: fw-on-db7ca9c-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 50% (56 of 113) | 43% (67 of 155) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (164 of 347) | 72% (93 of 129) |
| Strategy | Close-in objectives charged next turn | 13% (19 of 143) | 15% (38 of 256) |
| Strategy | Support requests answered (helper made contact too) | 21% (3 of 14) | 55% (12 of 22) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (8 of 16) | 23% (3 of 13) |
| Strategy | Joined characters whose unit fought | 51% (27 of 53) | 41% (17 of 41) |
| Strategy | Lone characters that fought | 80% (74 of 93) | 75% (71 of 95) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.1 | 1.7 |
| Movement | Points that never moved of their own | 272.8 | 186.3 |
| Movement | Fights charged into per game | 2.6 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 77, net +22 | 16 of 91, net +132 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 77, net +121 | 16 of 91, net -10 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 16 of 77, net +128 | 8 of 91, net +32 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 of 77, net +110 | 33 of 91, net +135 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.3 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (202 of 444) | 48% (161 of 337) |
| Shooting | Points destroyed by shooting units | 76.6 | 40.0 |
| Shooting | War machine shots | 6.4 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (116 of 232) | 29% (15 of 51) |
| Shooting | Points destroyed by war machines | 82.0 | 10.1 |
| Magic | Magic missiles cast | 2.2 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (30 of 81) | 42% (15 of 36) |
| Magic | Wounds caused by magic missiles | 5.1 | 1.5 |
| Magic | Wounds caused by other spells | 0.8 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 93.5 | 17.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.5 / 0.7 / 0.2 | 1.3 / 0.6 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 345.3 | 365.2 |
| Combat | Points run down | 86.7 | 110.4 |
| Combat | Net points per charged fight, damage counted | +93 | +90 |
| Combat | Net per 100 charger points, damage counted | +31.0 | +33.8 |
| Combat | First round won (charged fights) | 71% | 50% |
| Combat | Net points per charged fight | +89 | +97 |
| Combat | Net points per supported fight / lone fight | +220 / +66 | +145 / +91 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 93 | 44 of 112 |
| Game | Points lost | 641.9 | 754.3 |
| Game | VP from objectives | 640.6 | 633.9 |
| Game | Lone holders (player turns) | 2.7 | 2.6 |

- Mine won / drew / lost: 15 / 9 / 12 of 36 ended games (of 36); mean margin (Mine - Opponent) +117 VP
- The side that went first won 11 of 27 games with a winner
- Points traded per game (both sides' losses): 1396
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-on-db7ca9c-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 1.8 | 0.8 | +0.0 | 0.0 | 4.4 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 20.6 | 0.2 | +0.0 | 0.0 | 3.6 |
| BACKUP TARGETS | 0.7 | +5.5 | 0.0 | 14.8 | 1.4 | +12.0 | 0.0 | 42.1 |
| BEST FACING | 0.9 | +24.9 | 0.0 | 23.4 | 0.8 | +60.0 | 0.0 | 28.7 |
| BEST FIRST | 3.6 | +178.9 | 137.9 | 34.1 | 3.4 | +176.8 | 67.6 | 27.4 |
| BEST OVERALL | 0.8 | +46.8 | 0.0 | 43.8 | 0.6 | +65.3 | 0.0 | 37.5 |
| BEST PREY | 0.4 | +16.5 | 6.1 | 0.0 | 1.1 | +57.2 | 7.4 | 17.2 |
| BEST PRIZE | 0.1 | -12.9 | 3.5 | 28.5 | 0.0 | -0.3 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | +0.9 | 0.0 | 15.0 | 0.2 | -0.8 | 0.0 | 13.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 1.9 | 0.0 | 0.1 | +0.0 | 8.5 | 0.0 |
| BLOCKED WHEEL | 0.4 | -5.4 | 0.0 | 3.1 | 0.3 | +9.7 | 0.0 | 1.8 |
| BOMBING RUN | 0.1 | +2.3 | 4.2 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 92.7 | 11.0 | 0.1 | +0.0 | 1.8 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +176.6 | 418.8 | 66.2 | 1.2 | +18.5 | 47.6 | 17.9 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 4.0 | 0.1 | -8.5 | 15.6 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 10.9 | 8.2 | 0.1 | -3.5 | 10.1 | 10.6 |
| CAST JOB | 0.4 | +19.8 | 42.9 | 4.7 | 0.2 | +1.3 | 4.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 7.6 |
| CASTING BLOCK | 0.3 | +26.5 | 6.8 | 9.6 | 0.1 | +1.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 11.2 | 0.3 | +0.0 | 0.0 | 26.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.4 | -1.3 | 4.0 | 13.2 | 0.2 | -1.0 | 15.3 | 7.6 |
| CHARGE NOW WEIGHED | 0.7 | -88.1 | 23.1 | 11.3 | 0.6 | -100.2 | 7.6 | 29.0 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.2 | -14.0 | 1.4 | 0.0 | 0.1 | -3.6 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 5.1 | 2.9 | 0.1 | +0.0 | 1.7 | 3.2 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 8.2 | 0.4 | +0.0 | 24.5 | 6.7 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 5.4 |
| CONVEYANCE SEARCH | 0.5 | +52.6 | 0.0 | 22.5 | 0.3 | +36.6 | 16.6 | 13.1 |
| COUNTER-CHARGE COVER | 12.6 | +1081.0 | 0.0 | 167.5 | 9.1 | +932.5 | 0.0 | 241.2 |
| DEFENSIVE ARMY | 0.6 | +0.0 | 12.3 | 6.8 | 0.4 | +0.0 | 2.6 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +9.8 | 29.4 | 0.0 | 0.1 | +0.9 | 7.6 | 0.0 |
| ELIXIR WORTH | 0.0 | +1.0 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +152.3 | 0.0 | 43.1 | 1.5 | +172.0 | 0.0 | 87.9 |
| FALLBACK BY WORTH | 4.2 | +80.8 | 0.0 | 72.4 | 5.9 | +115.3 | 0.0 | 74.8 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +1.3 | 24.6 | 10.2 |
| FLANK NOT WEIGHED | 7.2 | +0.0 | 0.0 | 147.6 | 6.2 | +0.0 | 0.0 | 199.2 |
| FOLLOW UP WEIGHED | 1.2 | +85.9 | 0.0 | 33.3 | 0.6 | +64.4 | 0.0 | 21.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +13.2 | 0.0 | 29.1 | 0.1 | +3.0 | 0.0 | 19.1 |
| GIVES UP | 0.6 | -30.2 | 98.2 | 4.0 | 1.0 | -47.0 | 84.6 | 22.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 4.0 | 0.0 | 0.1 | -2.3 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 5.6 | 0.0 | 0.0 | +0.0 | 3.1 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 16.1 | 0.3 | +0.0 | 4.2 | 26.4 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -17.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.7 | 3.5 | 0.0 | 0.2 | +9.4 | 6.9 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +27.0 | 0.0 | 0.0 | 0.3 | +23.1 | 0.0 | 5.4 |
| HUNT KEPT | - | - | - | - | 0.1 | +6.8 | 5.8 | 3.1 |
| HUNT RESULT | 0.1 | +5.6 | 0.0 | 0.0 | 0.2 | +7.2 | 2.4 | 0.0 |
| HUNT THE GUNS | 0.1 | +25.9 | 3.5 | 0.0 | 0.2 | +55.8 | 3.5 | 0.0 |
| INVITES THE FIGHT | 3.9 | +265.1 | 157.4 | 54.4 | 3.1 | +165.8 | 61.9 | 72.7 |
| JOINT CHARGE PLAN | 0.1 | +3.6 | 10.9 | 0.0 | 0.4 | +24.6 | 13.4 | 11.7 |
| KEEP FALLS | 0.1 | +0.2 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.3 | 0.0 | 1.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +53.3 | 187.6 | 55.2 | 2.8 | +85.0 | 152.0 | 84.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +43.2 | 110.3 | 45.6 | 1.8 | +66.3 | 144.2 | 38.5 |
| KILLS COUNT NEXT TURN | 4.4 | +159.5 | 202.6 | 89.0 | 7.6 | +328.9 | 218.6 | 206.1 |
| LONE CHARACTER SAFE SPOT | 0.3 | +4.2 | 12.7 | 15.0 | 0.6 | +16.5 | 14.3 | 43.1 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 2.0 | 13.6 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -5.2 | 18.6 | 10.6 | 0.6 | -4.7 | 27.1 | 8.6 |
| LOST CHARGE | 2.9 | -51.9 | 189.2 | 93.5 | 3.0 | -50.7 | 57.2 | 103.1 |
| LURE BY WHAT IT DRAWS | 0.1 | -6.2 | 0.0 | 0.0 | 0.1 | -14.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +79.6 | 17.8 | 16.1 | 1.1 | +101.5 | 13.4 | 34.5 |
| MANOEUVRE | 0.3 | +8.7 | 0.0 | 9.6 | 0.5 | +8.0 | 0.0 | 11.7 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +9.4 | 0.0 | 4.5 | 0.7 | +34.0 | 0.0 | 29.8 |
| MARCH ODDS | 0.2 | +19.1 | 18.4 | 0.0 | 0.3 | +23.7 | 6.6 | 0.0 |
| MARCH OVER CASTS | 0.7 | +60.0 | 0.0 | 19.9 | 0.4 | +41.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.7 | +264.2 | 0.0 | 107.8 | 6.5 | +240.5 | 0.0 | 166.4 |
| MISSILES IN THE MOVE | 4.0 | +163.0 | 0.0 | 103.4 | 3.4 | +41.6 | 0.0 | 75.4 |
| MISSILES NEXT TURN | 5.0 | +115.8 | 0.0 | 146.7 | 4.1 | +35.9 | 0.0 | 115.2 |
| MODEL FACING | 0.2 | +119.6 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 12.3 | 0.0 | 0.3 | +0.0 | 13.4 | 0.0 |
| MOVE AND CAST | 0.2 | +10.7 | 0.0 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +9.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -67.2 | 0.0 | 0.0 | 0.1 | -4.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 26.1 |
| MOVE TO CHARGE | 4.3 | +542.9 | 270.2 | 78.2 | 8.3 | +708.5 | 244.0 | 258.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +4.5 | 2.7 | 0.0 | 0.1 | +9.3 | 24.6 | 0.0 |
| NOT NEEDED | 0.1 | -16.3 | 29.1 | 1.2 | 0.2 | -13.1 | 16.9 | 0.0 |
| NOT TURNED | 7.3 | +148.1 | 0.0 | 101.8 | 6.1 | +128.2 | 0.0 | 125.5 |
| NOT WORTH A CAST | 0.9 | -0.8 | 0.0 | 11.2 | 0.4 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 15.7 | -825.8 | 13.6 | 184.7 | 15.5 | -827.7 | 9.9 | 274.8 |
| OPENS A LANE | 0.1 | +0.5 | 17.2 | 4.6 | - | - | - | - |
| OPENS UP | 0.2 | +20.4 | 19.0 | 12.3 | 0.3 | +16.1 | 10.2 | 9.9 |
| OVERRUNS AWAY | 0.6 | +19.2 | 62.7 | 20.4 | 0.4 | +7.7 | 33.1 | 3.2 |
| PATHS CROSS | 2.8 | +187.5 | 0.0 | 24.2 | 3.3 | +297.2 | 0.0 | 43.4 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 15.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.1 | -1.5 | 0.0 | 0.0 | 0.2 | -2.9 | 0.0 | 12.4 |
| PLAN RESULT | 38.8 | +1406.2 | 1266.0 | 827.9 | 38.8 | +871.7 | 1195.8 | 972.2 |
| PURSUES BIG PREY | 0.1 | -6.4 | 0.0 | 0.0 | 0.1 | -8.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.6 | 0.0 | 0.0 | 0.1 | +6.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +15.6 | 0.0 | 18.2 | 1.7 | +26.4 | 0.0 | 36.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.1 | 3.5 | 4.7 | 0.2 | -9.6 | 0.0 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.4 | 0.0 | 0.0 | 0.3 | +8.1 | 0.0 | 1.2 |
| REDIRECT COUNTER | 2.1 | +151.4 | 0.0 | 28.0 | 4.4 | +489.4 | 0.0 | 69.1 |
| REDIRECT WEIGHED | 0.3 | +0.4 | 6.5 | 19.3 | 0.3 | +1.8 | 1.4 | 0.0 |
| RESERVE FALL BACK | 0.4 | +16.1 | 0.0 | 6.9 | 0.8 | +34.8 | 0.0 | 9.8 |
| RESTRAINS TO SHOOT | 0.1 | +1.9 | 0.0 | 9.2 | 0.0 | +1.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +91.1 | 210.5 | 80.9 | 2.5 | +57.3 | 147.6 | 69.4 |
| SAFER THAN THE JOB | 1.3 | +71.7 | 0.0 | 36.8 | 0.8 | +43.7 | 0.0 | 23.8 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.4 | 0.0 | 0.9 | 0.2 | +0.8 | 0.0 | 1.2 |
| SEARCH SPOT | 3.5 | +171.7 | 0.0 | 45.9 | 4.2 | +242.5 | 0.0 | 48.3 |
| SELF MOVE SPELL | 0.2 | +22.7 | 0.0 | 18.1 | 0.3 | +5.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.2 | +202.2 | 41.1 | 26.2 | 2.4 | +206.7 | 15.5 | 55.2 |
| SET-UP ANY TARGET | 0.2 | +11.5 | 0.0 | 11.2 | 0.1 | +25.8 | 16.6 | 13.1 |
| SET-UP MISSED | 0.1 | +3.8 | 0.0 | 22.5 | 0.0 | +4.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +29.3 | 48.0 | 12.7 | 0.4 | +12.8 | 32.4 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.7 | +0.0 | 141.7 | 0.0 | 0.2 | +0.0 | 12.9 | 7.6 |
| SHOTS IN THE MOVE | 16.1 | +682.8 | 0.0 | 185.9 | 8.5 | +188.8 | 0.0 | 93.4 |
| SPELL SETS UP CHARGE | 0.2 | +39.6 | 0.0 | 11.2 | 0.2 | +69.8 | 16.6 | 13.1 |
| SPELL WORTH | 1.3 | +16.5 | 90.4 | 90.4 | 1.6 | +32.8 | 63.3 | 63.3 |
| STABLE ROLE | 11.8 | +0.0 | 389.1 | 176.1 | 11.1 | +0.0 | 312.9 | 189.8 |
| STANDS TO CAST | 0.0 | +3.0 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +9.4 | 0.0 | 1.5 |
| STOPS SHORT OF THE FLANK | 0.7 | +16.5 | 0.0 | 37.6 | 0.6 | +30.4 | 0.0 | 28.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.3 | +0.0 | 0.0 | 4.0 |
| SUPPORTS | 8.1 | +382.5 | 194.8 | 151.8 | 8.1 | +348.8 | 265.8 | 105.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.5 | 6.6 | 0.0 | 0.3 | -16.9 | 13.2 | 10.9 |
| SURE REACH TOGETHER | 0.5 | +0.5 | 0.0 | 0.0 | 0.7 | +15.1 | 3.8 | 41.0 |
| THROUGH LINE OF FIRE | 0.4 | +21.6 | 0.0 | 11.7 | 0.2 | +7.9 | 0.0 | 3.5 |
| TURN WORTH | 0.4 | -25.5 | 37.2 | 8.7 | 0.2 | -12.0 | 21.9 | 6.4 |
| TWO OR MORE ARRIVE | 0.2 | +1.9 | 0.0 | 0.0 | 0.5 | +3.9 | 0.0 | 10.4 |
| WALKS TO THE FIGHT | 1.8 | +78.8 | 53.8 | 20.5 | 1.1 | +50.2 | 52.2 | 26.9 |
| WAR ENGINE JOBS | 0.9 | +0.0 | 33.4 | 14.4 | 0.6 | +0.0 | 7.8 | 15.4 |
| WEARS DOWN | 0.9 | +48.5 | 130.8 | 42.6 | 1.4 | +57.0 | 66.9 | 28.2 |
| WHO HITS BACK | 0.4 | +20.3 | 0.0 | 24.4 | 0.2 | +18.1 | 0.0 | 5.0 |
| WHOLE FIGHT | 0.1 | +0.2 | 9.1 | 0.0 | 0.2 | +4.0 | 35.9 | 2.3 |
| WHOLE FIGHT GAIN | 0.3 | +50.0 | 33.4 | 4.5 | 0.6 | +54.2 | 52.0 | 20.1 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 8.0 | 0.0 | 0.1 | +0.0 | 4.7 | 0.0 |

### Rule changes: fw-on-db7ca9c-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1122 | 1122 | 1122 | 31.17 | -59526 | -53.1 |
| SUPPORTS | 584 | 584 | 358 | 9.94 | +10281 | +28.7 |
| SEARCH SPOT | 278 | 278 | 275 | 7.64 | +14957 | +54.4 |
| BEST FIRST | 255 | 255 | 255 | 7.08 | +12808 | +50.2 |
| MOVE TO CHARGE | 455 | 455 | 250 | 6.94 | +19324 | +77.3 |
| PATHS CROSS | 220 | 220 | 220 | 6.11 | +17448 | +79.3 |
| COUNTER-CHARGE COVER | 782 | 446 | 219 | 6.08 | +13504 | +61.7 |
| FACES THE THREAT | 123 | 123 | 123 | 3.42 | +11673 | +94.9 |
| KILLS COUNT NEXT TURN | 430 | 430 | 108 | 3.00 | +4750 | +44.0 |
| INVITES THE FIGHT | 249 | 249 | 99 | 2.75 | +4791 | +48.4 |
| FALLBACK BY WORTH | 364 | 364 | 98 | 2.72 | +7059 | +72.0 |
| SAFER THAN THE JOB | 78 | 78 | 78 | 2.17 | +4154 | +53.3 |
| SHOTS IN THE MOVE | 887 | 592 | 75 | 2.08 | +2345 | +31.3 |
| WALKS TO THE FIGHT | 105 | 105 | 73 | 2.03 | +1752 | +24.0 |
| REDIRECT COUNTER | 232 | 142 | 67 | 1.86 | +8002 | +119.4 |
| FOLLOW UP WEIGHED | 64 | 64 | 64 | 1.78 | +5411 | +84.6 |
| ARTILLERY RE-ROLL WEIGHED | 62 | 62 | 62 | 1.72 | +0 | +0.0 |
| SET UP TOGETHER | 128 | 109 | 61 | 1.69 | +5549 | +91.0 |
| BEST FACING | 60 | 60 | 60 | 1.67 | +3058 | +51.0 |
| MAX FOR POSITIONING | 476 | 278 | 54 | 1.50 | +601 | +11.1 |
| BEST OVERALL | 53 | 53 | 53 | 1.47 | +4035 | +76.1 |
| CANNON PLANNED TARGET | 235 | 235 | 52 | 1.44 | -594 | -11.4 |
| CANNON SIGHT KEPT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 90 | 90 | 52 | 1.44 | +1512 | +29.1 |
| ADVANCE LANE KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 46 | 46 | 46 | 1.28 | +6531 | +142.0 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1832 | +40.7 |
| RISK BY ARC | 169 | 157 | 45 | 1.25 | +1678 | +37.3 |
| STOPS SHORT OF THE FLANK | 45 | 45 | 45 | 1.25 | +1688 | +37.5 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SHOT REPLANNED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| KEEPS ITS TARGET | 166 | 164 | 32 | 0.89 | +525 | +16.4 |
| KILLS COUNT | 110 | 103 | 31 | 0.86 | +1217 | +39.3 |
| MARCH CHECK | 34 | 33 | 31 | 0.86 | +1913 | +61.7 |
| MISSILES IN THE MOVE | 266 | 151 | 27 | 0.75 | +809 | +30.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| MANOEUVRE | 28 | 28 | 25 | 0.69 | +600 | +24.0 |
| THROUGH LINE OF FIRE | 25 | 25 | 25 | 0.69 | +1061 | +42.5 |
| BLOCKED WHEEL | 24 | 24 | 24 | 0.67 | +155 | +6.5 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| MAKE SURE TOGETHER | 64 | 47 | 23 | 0.64 | +1792 | +77.9 |
| COMBAT PIVOT | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +911 | +41.4 |
| CHAFF PASSED | 21 | 21 | 21 | 0.58 | -81 | -3.9 |
| WAR ENGINE JOBS | 53 | 53 | 21 | 0.58 | -1357 | -64.6 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.56 | +854 | +42.7 |
| BEST PREY | 53 | 53 | 19 | 0.53 | +851 | +44.8 |
| BIG CHARACTER SAFETY | 19 | 19 | 19 | 0.53 | +1 | +0.1 |
| MARCH ODDS | 18 | 18 | 18 | 0.50 | +266 | +14.8 |
| SHOOTS FROM THE BEST SPOT | 42 | 42 | 18 | 0.50 | +453 | +25.2 |
| WHOLE FIGHT GAIN | 30 | 24 | 17 | 0.47 | +888 | +52.2 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +585 | +39.0 |
| SURE CHARGE BEATS ADVANCE | 15 | 15 | 15 | 0.42 | -663 | -44.2 |
| WEARS DOWN | 83 | 79 | 15 | 0.42 | +759 | +50.6 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 13 | 13 | 13 | 0.36 | -160 | -12.3 |
| OPENS UP | 19 | 19 | 12 | 0.33 | +434 | +36.2 |
| CASTING BLOCK | 12 | 12 | 10 | 0.28 | +394 | +39.4 |
| HUNT IN PAIRS | 26 | 20 | 10 | 0.28 | +506 | +50.6 |
| CAST JOB | 19 | 19 | 9 | 0.25 | +522 | +58.0 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +4305 | +538.1 |
| MOVE AND CAST | 8 | 8 | 8 | 0.22 | +422 | +52.7 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| DEFENSIVE ARMY | 35 | 35 | 7 | 0.19 | -235 | -33.6 |
| MISSILES NEXT TURN | 330 | 190 | 7 | 0.19 | +22 | +3.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -634 | -105.7 |
| HUNT ADVANCE | 9 | 9 | 6 | 0.17 | +145 | +24.1 |
| LOST CHARGE | 211 | 210 | 6 | 0.17 | +52 | +8.6 |
| OVERRUNS AWAY | 37 | 36 | 6 | 0.17 | +250 | +41.7 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -548 | -91.3 |
| LONG SHOT | 37 | 35 | 5 | 0.14 | +4 | +0.7 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +260 | +52.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +103 | +25.7 |
| SURE REACH TOGETHER | 43 | 26 | 4 | 0.11 | +111 | +27.7 |
| BACKUP TARGETS | 74 | 35 | 3 | 0.08 | +5 | +1.8 |
| CARRIES OUT COUNTER | 4 | 4 | 3 | 0.08 | -308 | -102.5 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +56 | +18.8 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +47 | +15.7 |
| JOINT CHARGE PLAN | 21 | 21 | 3 | 0.08 | +327 | +109.1 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +58 | +19.4 |
| LONE WIZARD HOLDS BACK | 20 | 20 | 3 | 0.08 | -182 | -60.8 |
| REDIRECT BY WHAT IT STOPS | 16 | 16 | 3 | 0.08 | +72 | +24.2 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +58 | +19.3 |
| TWO OR MORE ARRIVE | 26 | 24 | 3 | 0.08 | +15 | +5.0 |
| WHOLE FIGHT | 13 | 13 | 3 | 0.08 | +80 | +26.7 |
| WOUNDED STAYS OUT | 4 | 4 | 3 | 0.08 | -255 | -85.1 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +82 | +41.0 |
| CARRIES OUT SET-UP | 7 | 7 | 2 | 0.06 | -125 | -62.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 4 | 4 | 2 | 0.06 | +0 | +0.0 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +70 | +35.2 |
| STOPS | 4 | 4 | 2 | 0.06 | +223 | +111.5 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -10 | -10.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| EDGE GIVE GROUND | 8 | 8 | 1 | 0.03 | +158 | +158.1 |
| MOVE SPELL IN RANGE | 7 | 4 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.0 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +148 | +147.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 23 | 23 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 11 | 11 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 483 | not checked | - | - | - | - |
| GIVES UP | 58 | 54 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 16 | 14 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 5 | 5 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 32 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 37 | 37 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 16 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NOT NEEDED | 11 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 481 | 481 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 47 | not checked | - | - | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2791 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 104 | not checked | - | - | - | - |
| STABLE ROLE | 825 | 820 | 0 | 0.00 | - | - |
| TURN WORTH | 23 | 22 | 0 | 0.00 | - | - |

### Off best figure: fw-on-db7ca9c-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.86 | 13.47 | 55.4 |
| FALLBACK | gate | 0.58 | 0.69 | 40.5 |
| TURN GATE | gate | 0.69 | 0.53 | 37.9 |
| WAR ENGINE JOBS | rule | 0.33 | 0.22 | 67.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.39 | 32.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.33 | 44.2 |
| PATHS CROSS | rule | 0.28 | 0.11 | 38.6 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.25 | 12.3 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.06 | 55.7 |
| CHAFF PASSED | rule | 0.22 | 0.08 | 7.3 |
| SUPPORT REQUEST | gate | 0.14 | 0.11 | 68.7 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.11 | 12.8 |
| BLOCKED WHEEL | rule | 0.11 | 0.11 | 37.0 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 2.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.11 | 20.5 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.08 | 56.6 |
| DEFENSIVE ARMY | rule | 0.17 | 0.03 | 33.6 |
| BEST PRIZE | rule | 0.14 | 0.03 | 105.7 |
| PURSUES BIG PREY | rule | 0.08 | 0.08 | 91.3 |
| CARRIES OUT COUNTER | rule | - | 0.08 | 102.5 |
| FACES THE THREAT | rule | 0.03 | 0.06 | 15.2 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 2.1 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 60.8 |
| MARCH ODDS | rule | 0.03 | 0.06 | 15.2 |
| NO REASON | gate | 0.03 | 0.06 | 11.9 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 11.6 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.03 | 10.2 |
| WOUNDED STAYS OUT | rule | - | 0.08 | 85.1 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 62.6 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 60.7 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 11.0 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 10.0 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 4.6 |
| LONG SHOT | rule | - | 0.03 | 14.7 |
| MOVE AND CAST | rule | 0.03 | - | 16.7 |

### Plans: fw-on-db7ca9c-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.0 | 17% | 805 | 364 | 45% |
| Mine | charge | 2.3 | 64% | 308 | 237 | 77% |
| Mine | close in | 4.0 | 27% | 660 | 142 | 22% |
| Mine | hold | 3.9 | 46% | 254 | 0 | 0% |
| Mine | join | 0.5 | 100% | 19 | 0 | 0% |
| Mine | shoot | 7.8 | 62% | 339 | 664 | 196% |
| Mine | support | 8.3 | 92% | 297 | 0 | 0% |
| Opponent | advance | 12.8 | 16% | 779 | 313 | 40% |
| Opponent | charge | 3.3 | 54% | 365 | 277 | 76% |
| Opponent | close in | 7.1 | 20% | 980 | 132 | 14% |
| Opponent | hold | 3.5 | 38% | 249 | 0 | 0% |
| Opponent | join | 0.8 | 89% | 33 | 0 | 0% |
| Opponent | shoot | 2.8 | 64% | 64 | 150 | 234% |
| Opponent | support | 8.4 | 94% | 283 | 0 | 0% |

### Packages: hunt the guns, fw-on-db7ca9c-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 1 | 0% | 50% | 0% | 2.0 | 247 | 100 | 50% | 14 |
| Opponent | 0.2 | 6 | 0 | 0% | 17% | 0% | 3.0 | 334 | 43 | 17% | 75 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Dwarfen Mountain Holds | 0.4 | 2 | 1 | 0% | 100% | 0% | 2.0 | 276 | 200 | 100% | 60 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 151 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 93 | 0 | 0% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 280 | 0 | 0% | 32 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 451 | 0 | 0% | 24 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 50% | 0% | 3.0 | 335 | 130 | 50% | 42 |

### Battle groups: fw-on-db7ca9c-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 12.6 | 19% | 56% | 9% | 38% | 39% | 8% | 14% | 39% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 30% | 50% | 9% | 0% | 25% | 5% | 5% | 65% | 0% |
| Opponent | COUNTER-CHARGE COVER | 9.1 | 12% | 51% | 15% | 33% | 26% | 11% | 17% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 20% | 68% | 19% | 50% | 12% | 4% | 20% | 64% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-on-db7ca9c-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 32 (3) | 32 | 0 | 37 | 33% | 5.0 | 0 (1) | 58 (2) | - | - | 32 (3) |
| Mine | Chaff | 36 | 30 (36) | 18 | 12 | 46 | 47% | 2.4 | 52 (15) | 15 (10) | 19 (11) | 32 (22) | 27 (14) |
| Mine | Character | 123 | 47 (123) | 47 | 0 | 35 | 16% | 2.3 | 55 (32) | 57 (58) | 5 (11) | 49 (59) | 56 (42) |
| Mine | Clean-up | 26 | 79 (26) | 44 | 36 | 21 | 31% | 3.6 | 48 (10) | 119 (12) | 59 (4) | 134 (13) | 33 (13) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 100 | 0% | 1.8 | 0 (1) | 0 (2) | 0 (1) | 0 (4) | - |
| Mine | Fast Hammer | 40 | 22 (40) | 10 | 12 | 48 | 38% | 2.7 | 19 (18) | 46 (11) | 9 (11) | 25 (29) | 16 (11) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 100 | 0% | 2.2 | - | 0 (4) | 69 (1) | 0 (1) | 17 (4) |
| Mine | Hammer | 56 | 54 (56) | 40 | 14 | 38 | 9% | 2.6 | 29 (11) | 68 (37) | 23 (8) | 38 (34) | 73 (22) |
| Mine | Holder | 26 | 87 (26) | 6 | 80 | 9 | 42% | 3.5 | 103 (6) | 71 (15) | 118 (5) | 96 (12) | 78 (14) |
| Mine | Shooter | 45 | 113 (45) | 36 | 78 | 30 | 0% | 1.9 | 80 (5) | 135 (33) | 50 (7) | 164 (24) | 60 (21) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 58 | 0% | 2.8 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 56 | 41 (56) | 41 | 0 | 32 | 5% | 1.3 | 56 (14) | 35 (37) | 46 (5) | 38 (11) | 42 (45) |
| Mine | Wizard | 23 | 29 (23) | 29 | 0 | 46 | 9% | 2.4 | 44 (6) | 44 (10) | 0 (3) | 76 (3) | 26 (16) |
| Opponent | Blocker | 1 | 412 (1) | 412 | 0 | 100 | 0% | 3.0 | - | - | 412 (1) | 412 (1) | - |
| Opponent | Chaff | 68 | 68 (68) | 7 | 61 | 46 | 38% | 2.8 | 58 (30) | 54 (16) | 91 (22) | 83 (50) | 22 (18) |
| Opponent | Character | 113 | 49 (113) | 48 | 1 | 34 | 26% | 2.4 | 71 (37) | 43 (58) | 22 (9) | 51 (72) | 54 (32) |
| Opponent | Clean-up | 18 | 46 (18) | 31 | 15 | 60 | 28% | 4.1 | 10 (5) | 72 (10) | 33 (3) | 57 (11) | 29 (7) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 53 | 37 (53) | 21 | 16 | 51 | 38% | 2.7 | 26 (20) | 36 (18) | 56 (15) | 34 (37) | 44 (16) |
| Opponent | Fragile | 10 | 51 (10) | 51 | 0 | 43 | 20% | 4.0 | 191 (3) | 0 (2) | 0 (5) | 51 (10) | - |
| Opponent | Hammer | 63 | 28 (63) | 22 | 6 | 47 | 25% | 2.5 | 29 (16) | 30 (40) | 8 (7) | 26 (39) | 34 (24) |
| Opponent | Holder | 40 | 71 (40) | 9 | 63 | 22 | 50% | 3.5 | 36 (9) | 90 (20) | 64 (10) | 99 (21) | 44 (18) |
| Opponent | Shooter | 32 | 72 (32) | 25 | 46 | 46 | 3% | 1.2 | 57 (8) | 75 (18) | 78 (6) | 72 (17) | 71 (15) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 34 (13) | 34 | 0 | 53 | 15% | 1.1 | 24 (5) | 0 (5) | 118 (3) | 38 (3) | 32 (10) |
| Opponent | Wizard | 24 | 5 (24) | 5 | 0 | 29 | 17% | 1.9 | 2 (11) | 19 (6) | 0 (5) | 8 (13) | 0 (9) |

### Charged fights: fw-on-db7ca9c-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 197 | 55 | 1.0 | 1.0 | 55 | 19 | +36 | 2 of 5 | 5 of 5 | - | +36 |
| Mine | Chaos Dwarfs | 3 | 70 | 699 | 2.7 | 1.5 | 262 | 39 | +223 | 7 of 8 | 3 of 8 | +453 | +85 |
| Mine | Dwarfen Mountain Holds | 4 | 360 | 67 | 1.2 | 1.4 | 54 | 0 | +54 | 1 of 5 | 4 of 5 | +114 | +14 |
| Mine | Empire of Man | 5 | 322 | 144 | 1.2 | 1.2 | 120 | 65 | +55 | 2 of 6 | 3 of 6 | +83 | +49 |
| Mine | Grand Cathay | 4 | 826 | 516 | 2.5 | 1.4 | 206 | 0 | +206 | 5 of 10 | 9 of 10 | +196 | +209 |
| Mine | High Elf Realms | 4 | 166 | 230 | 2.8 | 1.2 | 84 | 27 | +57 | 3 of 11 | 7 of 11 | +492 | +14 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 639 | 8.0 | 1.0 | 80 | 71 | +8 | 3 of 8 | 6 of 8 | - | +8 |
| Mine | Lizardmen | 1 | 265 | 385 | 4.0 | 1.2 | 96 | 35 | +61 | 1 of 4 | 2 of 4 | +235 | +3 |
| Mine | Ogre Kingdoms | 1 | 195 | 331 | 6.0 | 1.0 | 55 | 15 | +40 | 2 of 6 | 5 of 6 | - | +40 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 477 | 5.0 | 1.0 | 95 | 22 | +73 | 2 of 5 | 3 of 5 | - | +73 |
| Mine | Skaven | 2 | 139 | 116 | 2.5 | 1.2 | 46 | 0 | +46 | 1 of 5 | 3 of 5 | +0 | +58 |
| Mine | Tomb Kings of Khemri | 2 | 63 | 767 | 2.5 | 1.2 | 307 | 125 | +182 | 1 of 5 | 5 of 5 | +233 | +169 |
| Mine | Vampire Counts | 2 | 0 | 491 | 6.5 | 1.2 | 76 | 7 | +69 | 3 of 13 | 9 of 13 | +26 | +76 |
| Mine | Warriors of Chaos | 1 | 0 | 109 | 2.0 | 1.0 | 54 | 0 | +54 | 0 of 2 | 2 of 2 | - | +54 |
| **Mine** | all armies | 36 | 252 | 306 | 2.6 | 1.2 | 119 | 29 | +89 | 33 of 93 | 66 of 93 | +220 | +66 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 5.0 | 1.2 | 0 | 23 | -23 | 1 of 5 | 0 of 5 | -30 | -21 |
| Opponent | Dwarfen Mountain Holds | 1 | 65 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 0 of 3 | 1 of 3 | - | +0 |
| Opponent | Empire of Man | 1 | 160 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Grand Cathay | 1 | 460 | 280 | 2.0 | 1.5 | 140 | 0 | +140 | 2 of 2 | 1 of 2 | +185 | +95 |
| Opponent | High Elf Realms | 2 | 238 | 148 | 1.5 | 1.7 | 99 | 0 | +99 | 2 of 3 | 1 of 3 | +0 | +148 |
| Opponent | Lizardmen | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 2 | 42 | 284 | 5.5 | 1.2 | 52 | 71 | -20 | 4 of 11 | 7 of 11 | -347 | +13 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 1124 | 7.0 | 1.1 | 161 | 16 | +145 | 5 of 14 | 9 of 14 | +151 | +144 |
| Opponent | Skaven | 2 | 0 | 56 | 1.0 | 2.5 | 56 | 0 | +56 | 0 of 2 | 2 of 2 | +112 | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 108 | 738 | 3.5 | 1.1 | 211 | 44 | +167 | 8 of 14 | 5 of 14 | +290 | +158 |
| Opponent | Vampire Counts | 6 | 11 | 468 | 3.5 | 1.1 | 134 | 49 | +85 | 6 of 21 | 10 of 21 | +328 | +59 |
| Opponent | Warriors of Chaos | 7 | 10 | 257 | 1.4 | 1.1 | 180 | 0 | +180 | 5 of 10 | 8 of 10 | +663 | +126 |
| Opponent | Wood Elf Realms | 6 | 105 | 571 | 4.3 | 1.1 | 132 | 33 | +99 | 10 of 26 | 12 of 26 | +30 | +104 |
| **Opponent** | all armies | 36 | 68 | 403 | 3.1 | 1.2 | 129 | 32 | +97 | 44 of 112 | 56 of 112 | +145 | +91 |

### Effective charges: fw-on-db7ca9c-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 0 | 1 (net +0) | 0 | 3 (net +60) | 1 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 8 | 2 (net +263) | 0 | 1 (net +210) | 0 | 1 (net +362) | 3 (net +71) | 1 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 2 (net +134) | 1 | 25% (1 of 4) |
| Mine | Empire of Man | 6 | 1 (net -281) | 0 | 0 | 0 | 1 (net +83) | 4 (net +132) | 0 | 0% (0 of 6) |
| Mine | Grand Cathay | 10 | 0 | 0 | 3 (net +213) | 0 | 1 (net +45) | 6 (net +230) | 0 | 30% (3 of 10) |
| Mine | High Elf Realms | 11 | 0 | 0 | 2 (net +60) | 2 (net +0) | 3 (net +226) | 1 (net -151) | 3 | 25% (2 of 8) |
| Mine | Kingdom of Bretonnia | 8 | 1 (net +0) | 0 | 0 | 0 | 2 (net +60) | 5 (net -10) | 0 | 0% (0 of 8) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +90) | 0 | 1 (net +235) | 0 | 2 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 0 | 2 (net +33) | 1 (net +0) | 0 | 3 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +275) | 0 | 2 (net +101) | 0 | 2 | 33% (1 of 3) |
| Mine | Skaven | 5 | 2 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +45) | 1 (net +186) | 0 | 20% (1 of 5) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net +120) | 0 | 1 (net +233) | 2 (net +215) | 1 | 25% (1 of 4) |
| Mine | Vampire Counts | 13 | 3 (net -15) | 0 | 2 (net +58) | 0 | 2 (net +26) | 5 (net +130) | 1 | 17% (2 of 12) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Opponent | Beastmen Brayherds | 5 | 0 | 1 (net -85) | 2 (net +0) | 2 (net -15) | 0 | 0 | 0 | 40% (2 of 5) |
| Opponent | Dwarfen Mountain Holds | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Grand Cathay | 2 | 2 (net +140) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 3 | 1 (net +296) | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Ogre Kingdoms | 11 | 1 (net -347) | 0 | 1 (net -439) | 1 (net +0) | 1 (net +65) | 3 (net +27) | 4 | 14% (1 of 7) |
| Opponent | Orc & Goblin Tribes | 14 | 1 (net +583) | 0 | 1 (net +0) | 1 (net +151) | 1 (net +95) | 3 (net +127) | 7 | 14% (1 of 7) |
| Opponent | Skaven | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +112) | 0 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 14 | 2 (net +178) | 1 (net -540) | 2 (net +142) | 4 (net +361) | 2 (net +18) | 3 (net +255) | 0 | 14% (2 of 14) |
| Opponent | Vampire Counts | 21 | 3 (net +4) | 0 | 4 (net -124) | 3 (net +94) | 1 (net +0) | 7 (net +206) | 3 | 22% (4 of 18) |
| Opponent | Warriors of Chaos | 10 | 1 (net +559) | 0 | 2 (net +27) | 1 (net +147) | 1 (net +0) | 5 (net +208) | 0 | 20% (2 of 10) |
| Opponent | Wood Elf Realms | 26 | 5 (net +74) | 1 (net -102) | 2 (net +221) | 3 (net -42) | 1 (net +60) | 8 (net +80) | 6 | 10% (2 of 20) |

### Charged fights, damage counted: fw-on-db7ca9c-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 199 | 227 | +22 | 64 | 39 | +25 | +12.7 |
| Mine | 50-54% | 1 | 165 | 205 | +0 | 0 | 66 | -66 | -40.2 |
| Mine | Effective (55-75%) | 13 | 339 | 192 | +121 | 135 | 23 | +112 | +32.9 |
| Mine | 76-89% | 5 | 159 | 159 | +13 | 63 | 0 | +63 | +39.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 275 | 225 | +110 | 171 | 46 | +124 | +45.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 474 | 108 | +128 | 178 | 50 | +128 | +27.0 |
| Mine | No odds | 16 | 264 | 167 | +49 | 96 | 57 | +38 | +14.6 |
| Mine | All fights | 93 | 302 | 187 | +89 | 136 | 43 | +93 | +31.0 |
| Opponent | Long shot (under 50%) | 16 | 310 | 236 | +132 | 171 | 45 | +126 | +40.8 |
| Opponent | 50-54% | 3 | 209 | 222 | -242 | 11 | 242 | -232 | -110.8 |
| Opponent | Effective (55-75%) | 16 | 150 | 188 | -10 | 70 | 95 | -25 | -16.8 |
| Opponent | 76-89% | 15 | 246 | 168 | +124 | 169 | 40 | +130 | +52.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 283 | 185 | +135 | 155 | 40 | +116 | +40.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 468 | 77 | +32 | 47 | 0 | +47 | +10.0 |
| Opponent | No odds | 21 | 240 | 207 | +146 | 190 | 47 | +144 | +59.7 |
| Opponent | All fights | 112 | 266 | 188 | +97 | 142 | 52 | +90 | +33.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-on-db7ca9c-p1 | move | 566 | 90 (16%) | 60 (11%) | 66 (12%) | 410 (72%) |
| fw-on-db7ca9c-p1 | objective | 399 | 57 (14%) | 39 (10%) | 52 (13%) | 290 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

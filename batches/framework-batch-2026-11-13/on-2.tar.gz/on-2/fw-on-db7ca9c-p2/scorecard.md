# Doctrine scorecard: fw-on-db7ca9c-p2

### Scorecard: fw-on-db7ca9c-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 926 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 6 | 0 | 0 | 0 | 52 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 3 | 3 | 2 | 3 | 0 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 6 | 3 | 0 | 1 | 0 | 0 | 0 | 564 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 3 | 4 | 2 | 0 | 0 | 348 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1687 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | yes | 3 | 6 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 4 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 1 | - | 4 | 2 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 2 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 5 | 2 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 170 |
| **Average** | | | Mine | 25% | 2.3 | 3.7 | 1.9 | 2.0 | 0.0 | 0.0 | 0.0 | 453.7 |
| **Average** | | | Opponent | 38% | 2.2 | 2.3 | 2.1 | 1.4 | 0.7 | 0.0 | 0.0 | 297.8 |

### KPIs: fw-on-db7ca9c-p2

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 49% (28 of 57) | 40% (23 of 58) | 44% (51 of 115) |
| Winner chose to follow up after the loser gave ground |  | 89% (25 of 28); on the table 89% | 100% (16 of 16); on the table 100% | 93% (41 of 44); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (4 of 4); on the table 100% | 100% (6 of 6); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 75% (9 of 12); on the table 75% | 79% (11 of 14); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 91% (31 of 34); on the table 91% | 91% (31 of 34); on the table 91% | 91% (62 of 68); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 40% (55 of 138) | 27% (13 of 48) | 37% (68 of 186) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (55 of 117) | 52% (13 of 25) | 48% (68 of 142) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 42% (5 of 12) | 64% (7 of 11) | 52% (12 of 23) |
| Points that never fought | lower | 46% (10820 of 23594) | 53% (12830 of 23996) | 50% (23650 of 47590) |
|   infantry points that never fought | lower | 45% (3266 of 7332) | 69% (3408 of 4956) | 54% (6674 of 12288) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 66% (58 of 88) | 62% (58 of 93) | 64% (116 of 181) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.4 uses a game | 67% (2 of 3); 0.3 uses a game | 89% (8 of 9); 0.9 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.5 uses a game | 100% (1 of 1); 0.4 uses a game | 100% (3 of 3); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (6 of 8); 0.5 uses a game | 33% (1 of 3); 0.1 uses a game | 64% (7 of 11); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (11037 of 17752) | 63% (12466 of 19887) | 62% (23503 of 37639) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.8 (55%) | 0.3 (11%) | 4.2 (42%) |
| MARCHED: its unit marched | 0.7 (10%) | 0.7 (23%) | 1.3 (14%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.2 (18%) | 1.2 (40%) | 2.4 (25%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.2 (4%) | 0.6 (20%) | 0.8 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (2%) | 0.2 (6%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.4 (6%) | 0.0 (0%) | 0.4 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 0.7 | 1.0 | 5.7 | 0.1 | 1.2 |
| not cast | 2.2 | 2.3 | 4.0 | 9.8 | 1.4 | 13.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (50%) | 0.7 (17%) | 4.2 (42%) | 0.2 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (14%) | 0.2 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (7%) | 0.4 (18%) | 0.8 (21%) | 2.4 (25%) | 0.4 (29%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.0 (0%) | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.3 (15%) | 0.0 (0%) | 0.4 (10%) | 0.8 (8%) | 0.4 (29%) | 2.2 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.2 (7%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.2 (11%) | 0.1 (2%) | 0.4 (4%) | 0.1 (6%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (63%) | 0.3 (14%) | 1.8 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.5 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.1 a game | 0.8 a game |
| stood (cast and not dispelled) | 76% (13 of 17) | 100% (1 of 1) | 78% (14 of 18) |
| the unit moved after it | 62% (8 of 13) | 0% (0 of 1) | 57% (8 of 14) |
| it charged on its next turn | 0% (0 of 13) | 0% (0 of 1) | 0% (0 of 14) |
| the enemy charged it first | 15% (2 of 13) | 0% (0 of 1) | 14% (2 of 14) |
| it fought by the end of its next turn | 0% (0 of 13) | 0% (0 of 1) | 0% (0 of 14) |
| it moved out of a charge the enemy had planned (not charged first) | 15% (2 of 13) | 0% (0 of 1) | 14% (2 of 14) |
| none of these (no charge, no fight, no charge escaped) | 69% (9 of 13) | 100% (1 of 1) | 71% (10 of 14) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (268 of 371) | 55% (219 of 401) | 63% (487 of 772) |
|   cavalry | 50% (12 of 24) | 60% (36 of 60) | 57% (48 of 84) |
|   character | 70% (38 of 54) | 25% (8 of 32) | 53% (46 of 86) |
|   chariot | 36% (16 of 45) | 58% (7 of 12) | 40% (23 of 57) |
|   infantry | 64% (50 of 78) | 56% (87 of 155) | 59% (137 of 233) |
|   monster | 90% (9 of 10) | 47% (8 of 17) | 63% (17 of 27) |
|   war machine | 89% (143 of 160) | 58% (73 of 125) | 76% (216 of 285) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.9 (46%) | 2.8 (18%) | 6.7 (28%) |
| CHARGED: it charged | 0.9 (11%) | 2.1 (14%) | 3.0 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 1.0 (12%) | 0.5 (3%) | 1.5 (6%) |
| MOVED: a war machine that moved | 0.2 (3%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET IN RANGE | 0.2 (2%) | 3.4 (23%) | 3.6 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (1%) | 0.6 (4%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (17%) | 3.1 (20%) | 4.6 (19%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 1.3 (9%) | 1.7 (7%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (4%) | 1.3 (9%) | 1.7 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.2 | 79% | 2.4 pts | 14 pts |
| character | 3.9 | 1.8 | 66% | 14.1 pts | 55 pts |
| chariot | 1.9 | 1.5 | 57% | 20.3 pts | 39 pts |
| infantry | 16.4 | 6.6 | 75% | 8.1 pts | 133 pts |
| monster | 1.7 | 0.5 | 75% | 6.8 pts | 11 pts |
| war machine | 18.0 | 10.4 | 72% | 19.5 pts | 352 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 4.8 | 3.7 |
| Charges that made contact a game | 1.9 | 3.6 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (5 units) | 0.67 declared, 0.67 contact (3 units) | 0.25 declared, 0.25 contact (8 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.28 contact (81 units) | 0.62 declared, 0.47 contact (88 units) | 0.51 declared, 0.38 contact (169 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (7 of 11) | 67% (2 of 3) | 50% (1 of 2) | 62% (10 of 16) |
| Character in a unit | 86% (12 of 14) | 70% (7 of 10) | - | 79% (19 of 24) |
| Character on its own | 92% (11 of 12) | 40% (4 of 10) | 67% (10 of 15) | 68% (25 of 37) |
| Chariot | - | 89% (8 of 9) | - | 89% (8 of 9) |
| Infantry | 50% (14 of 28) | 47% (9 of 19) | - | 49% (23 of 47) |
| Monster | 50% (7 of 14) | - | - | 50% (7 of 14) |
| Monstrous | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| War Machines | 70% (21 of 30) | 100% (2 of 2) | - | 72% (23 of 32) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (12 of 12); on the table 100% | 34% (35 of 102) | 24% | 59% (13 of 22) | 100% (6 of 6); 4.2 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (14 of 14); on the table 100% | 56% (20 of 36) | 58% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 69% (9 of 13); on the table 69% | - | 61% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | 100% (5 of 5); on the table 100% | 33% (6 of 18) | 64% | 77% (17 of 22) | 0.0 uses a game | 100% (1 of 1); 2.5 uses a game | 0% (0 of 1); 0.0 uses a game |
| Grand Cathay | 1 | 100% (8 of 8); on the table 100% | 11% (2 of 18) | 43% | 33% (3 of 9) | 67% (2 of 3); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 50% (1 of 2); on the table 50% | - | 49% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 100% (5 of 5); on the table 100% | - | 33% | 67% (10 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 41% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 83% (5 of 6); on the table 83% | 17% (1 of 6) | 69% | 53% (8 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-on-db7ca9c-p2, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (10) | 67% (8) | 50% (18) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.25 | 0.58 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.08 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.17 | 0.08 | 0.25 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.17 | 1.58 | 3.75 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.00 | 0.92 | 1.92 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.67 | 4.92 | 11.58 |

### Quality by phase: fw-on-db7ca9c-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 65% (17 of 26) | 40% (24 of 60) |
| Strategy | Shoot objectives carried out (shot that target) | 61% (92 of 150) | 51% (49 of 96) |
| Strategy | Close-in objectives charged next turn | 9% (3 of 32) | 19% (18 of 96) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | 31% (5 of 16) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 65% (20 of 31) | 12% (2 of 16) |
| Strategy | Lone characters that fought | 61% (14 of 23) | 69% (20 of 29) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 2.0 | 1.4 |
| Movement | Points that never moved of their own | 453.7 | 297.8 |
| Movement | Fights charged into per game | 1.8 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 20, net +203 | 6 of 29, net -220 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 20, net +80 | 6 of 29, net -38 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 20, net +55 | 0 of 29 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 of 20, net -5 | 9 of 29, net +58 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.1 | 13.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (72 of 133) | 30% (47 of 157) |
| Shooting | Points destroyed by shooting units | 116.8 | 63.8 |
| Shooting | War machine shots | 11.9 | 6.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (80 of 143) | 48% (35 of 73) |
| Shooting | Points destroyed by war machines | 130.1 | 25.8 |
| Magic | Magic missiles cast | 2.5 | 0.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (13 of 30) | 60% (3 of 5) |
| Magic | Wounds caused by magic missiles | 5.5 | 0.2 |
| Magic | Wounds caused by other spells | 0.5 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 47.8 | 15.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.6 / 0.1 / 0.6 / 0.0 | 2.6 / 0.2 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 363.8 | 279.6 |
| Combat | Points run down | 0.0 | 34.8 |
| Combat | Net points per charged fight, damage counted | +35 | -11 |
| Combat | Net per 100 charger points, damage counted | +15.7 | -3.7 |
| Combat | First round won (charged fights) | 76% | 58% |
| Combat | Net points per charged fight | +28 | -11 |
| Combat | Net points per supported fight / lone fight | +141 / +16 | -48 / +1 |
| Combat | Charged fights on a top-3 enemy unit | 8 of 21 | 16 of 33 |
| Game | Points lost | 467.8 | 691.2 |
| Game | VP from objectives | 514.2 | 738.3 |
| Game | Lone holders (player turns) | 2.3 | 2.2 |

- Mine won / drew / lost: 6 / 2 / 4 of 12 ended games (of 12); mean margin (Mine - Opponent) +81 VP
- The side that went first won 5 of 10 games with a winner
- Points traded per game (both sides' losses): 1159
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-on-db7ca9c-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 7.9 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 10.4 |
| BACKUP TARGETS | 1.2 | +5.2 | 0.0 | 25.0 | 0.9 | +3.1 | 0.0 | 16.2 |
| BEST FACING | 1.3 | +55.5 | 0.0 | 31.2 | 0.6 | +38.7 | 0.0 | 0.0 |
| BEST FIRST | 4.2 | +198.6 | 94.0 | 81.2 | 4.2 | +189.3 | 137.9 | 40.8 |
| BEST OVERALL | 1.0 | +109.3 | 0.0 | 31.2 | 0.6 | +21.2 | 0.0 | 47.9 |
| BEST PREY | 1.2 | +38.1 | 26.8 | 14.2 | 0.7 | +19.8 | 9.3 | 11.7 |
| BEST PRIZE | 0.1 | +8.3 | 0.0 | 0.0 | 0.2 | -8.3 | 10.0 | 23.1 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.4 | -3.4 | 0.0 | 49.9 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.8 | +33.2 | 0.0 | 0.0 | 0.8 | +25.9 | 0.0 | 73.8 |
| BOMBING RUN | - | - | - | - | 0.1 | +2.9 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 209.7 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 9.1 | +644.1 | 845.2 | 9.2 | 4.2 | +301.9 | 32.6 | 48.3 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -10.4 | 23.1 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.4 | -3.7 | 59.0 | 18.1 |
| CAST JOB | 0.3 | +8.2 | 5.8 | 14.2 | 0.1 | +0.2 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +32.5 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.1 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | -1.5 | 0.0 | 6.7 |
| CHARGE NOW WEIGHED | 0.4 | -21.3 | 15.9 | 0.0 | 0.6 | -125.1 | 7.1 | 29.8 |
| CHARIOT NO STATIC JOB | 0.2 | +0.0 | 0.0 | 14.2 | - | - | - | - |
| CHEAP HELPER | 0.2 | +0.0 | 4.6 | 0.0 | 0.3 | +0.0 | 10.8 | 5.8 |
| COMBAT PIVOT | 0.3 | +0.0 | 6.0 | 25.8 | 0.7 | +0.0 | 0.0 | 104.6 |
| CONVEYANCE SEARCH | 1.1 | +164.3 | 0.0 | 7.9 | - | - | - | - |
| COUNTER-CHARGE COVER | 11.8 | +1310.3 | 0.0 | 92.4 | 7.5 | +392.0 | 0.0 | 178.9 |
| DEFENSIVE ARMY | 1.0 | -0.1 | 13.3 | 0.0 | 0.2 | +0.0 | 30.3 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +205.8 | 0.0 | 31.2 | 1.6 | +51.2 | 0.0 | 49.9 |
| FALLBACK BY WORTH | 3.7 | +42.3 | 0.0 | 7.9 | 5.2 | +80.3 | 0.0 | 41.6 |
| FIGHT LIFT | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.9 | 23.1 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 7.6 | +0.0 | 0.0 | 135.2 | 4.9 | +0.0 | 0.0 | 228.8 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.1 | 4.6 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +133.7 | 0.0 | 0.0 | 0.7 | +113.3 | 0.0 | 15.8 |
| FRIENDS SHOTS CHECKED | 0.1 | +1.7 | 0.0 | 8.8 | 0.3 | +38.9 | 0.0 | 0.0 |
| GIVES UP | 0.4 | -24.0 | 6.0 | 13.1 | 1.3 | -48.0 | 126.4 | 153.6 |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 29.5 | 18.1 |
| HELPER UNSEEN | - | - | - | - | 0.6 | +0.0 | 39.5 | 5.8 |
| HILL BY ITS CHANCE | 0.3 | -46.5 | 0.0 | 0.0 | 1.5 | -129.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +1.8 | 0.0 | 0.0 | 0.2 | +0.9 | 0.0 | 11.7 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 5.8 |
| HUNT IN PAIRS | 0.2 | +13.8 | 0.0 | 0.0 | 0.7 | +42.6 | 0.0 | 94.8 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.3 | 0.0 | 5.8 |
| HUNT RESULT | 0.2 | +36.4 | 0.0 | 4.3 | 0.2 | +10.2 | 0.0 | 5.8 |
| HUNT THE GUNS | 0.2 | +66.4 | 0.0 | 0.0 | 0.2 | +37.8 | 10.0 | 5.8 |
| INVITES THE FIGHT | 4.1 | +213.1 | 128.8 | 37.1 | 1.5 | +37.3 | 36.8 | 0.0 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +6.1 | 24.1 | 0.0 |
| KEEP FALLS | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.2 | +35.0 | 37.6 | 4.3 | 2.9 | +87.5 | 201.9 | 126.7 |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.1 | +76.5 | 46.2 | 6.8 | 1.7 | +61.5 | 62.5 | 22.9 |
| KILLS COUNT NEXT TURN | 4.2 | +102.5 | 102.0 | 66.6 | 7.9 | +371.8 | 168.4 | 263.4 |
| LONE CHARACTER SAFE SPOT | 0.4 | +2.1 | 6.0 | 0.0 | 0.3 | +2.8 | 0.0 | 3.8 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.8 | +66.3 | 0.0 | 0.0 | 0.7 | +48.5 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | -23.1 | 57.4 | 6.8 | 0.2 | -1.7 | 41.2 | 0.0 |
| LOST CHARGE | 2.8 | -40.5 | 76.8 | 22.5 | 1.8 | -20.3 | 36.2 | 39.2 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +3.6 | 0.0 | 4.3 | 1.3 | +86.3 | 0.0 | 3.8 |
| MANOEUVRE | 0.2 | +9.1 | 0.0 | 6.8 | 0.2 | +17.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.4 | +29.4 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.2 | +20.1 | 0.0 | 0.0 | 0.4 | -13.5 | 0.0 | 59.5 |
| MAX FOR POSITIONING | 5.2 | +132.1 | 0.0 | 47.9 | 4.4 | +159.6 | 0.0 | 190.7 |
| MISSILES IN THE MOVE | 4.0 | +142.8 | 0.0 | 28.0 | 1.7 | +26.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.4 | +96.6 | 0.0 | 27.7 | 2.6 | +35.7 | 0.0 | 127.3 |
| MODEL FACING | 1.3 | +264.9 | 0.0 | 5.0 | 1.0 | +231.8 | 0.0 | 0.0 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.4 | +0.0 | 72.2 | 31.7 |
| MOVE AND CAST | 0.2 | +8.0 | 0.0 | 7.1 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.7 | +29.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.0 | -29.2 | 13.5 | 7.9 | - | - | - | - |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 5.4 | - | - | - | - |
| MOVE TO CHARGE | 3.2 | +165.5 | 90.5 | 42.0 | 8.3 | +514.9 | 252.1 | 327.5 |
| MOVES UNITS SPELL | 0.2 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +9.0 | 0.0 | 0.0 | 0.1 | +4.7 | 7.9 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| NOT NEEDED | - | - | - | - | 0.1 | -1.1 | 0.0 | 0.0 |
| NOT TURNED | 6.7 | +141.1 | 0.0 | 104.0 | 4.9 | +96.0 | 0.0 | 255.7 |
| NOT WORTH A CAST | 0.2 | -0.2 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 16.8 | -874.7 | 4.6 | 237.4 | 15.5 | -850.9 | 15.0 | 284.2 |
| OPENS A LANE | 0.6 | +3.8 | 123.5 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +27.4 | 15.0 | 0.0 |
| OVERRUNS AWAY | 0.2 | +2.2 | 29.1 | 8.8 | 0.9 | +11.4 | 129.0 | 34.3 |
| PATHS CROSS | 1.9 | +136.0 | 0.0 | 7.1 | 2.5 | +236.9 | 0.0 | 41.8 |
| PIVOT GUARDS FLANK | 0.1 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 39.4 | +2086.1 | 1284.2 | 429.6 | 39.6 | +812.6 | 941.9 | 991.9 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.3 | 0.0 | 9.3 | 0.1 | +7.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +3.0 | 0.0 | 0.0 | 0.9 | +18.8 | 0.0 | 0.0 |
| RANDOM MOVER NO PROMISE | 0.3 | -11.8 | 12.0 | 0.0 | 0.4 | -28.6 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.1 | 0.0 | 0.0 | 0.2 | -11.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +121.8 | 0.0 | 65.3 | 3.4 | +192.3 | 0.0 | 50.5 |
| REDIRECT WEIGHED | 0.1 | +8.3 | 0.0 | 0.0 | 0.4 | +17.3 | 21.7 | 23.1 |
| RESERVE FALL BACK | 0.2 | +7.8 | 0.0 | 9.3 | 1.2 | +31.2 | 0.0 | 22.8 |
| RESTRAINS TO SHOOT | 0.1 | +7.5 | 0.0 | 0.0 | 0.2 | +9.9 | 0.0 | 0.0 |
| RISK BY ARC | 1.4 | +66.0 | 84.9 | 26.2 | 3.3 | +64.5 | 285.9 | 79.3 |
| SAFER THAN THE JOB | 1.0 | +94.0 | 0.0 | 32.8 | 0.9 | +32.6 | 0.0 | 45.1 |
| SCOUT SPOT | 0.2 | +0.2 | 0.0 | 0.0 | 0.8 | +1.3 | 0.0 | 5.5 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 5.5 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.4 | -39.6 | 0.0 | 0.0 |
| SEARCH SPOT | 3.2 | +142.4 | 0.0 | 0.0 | 3.1 | +145.5 | 0.0 | 70.6 |
| SET UP TOGETHER | 0.8 | +6.4 | 0.0 | 18.5 | 2.8 | +253.9 | 96.3 | 17.1 |
| SET-UP ANY TARGET | 0.4 | +35.4 | 0.0 | 7.9 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.4 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +49.7 | 79.7 | 0.0 | 0.3 | +39.8 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 345.8 | 0.0 | 0.7 | +0.0 | 52.0 | 0.0 |
| SHOTS IN THE MOVE | 19.2 | +1190.7 | 0.0 | 133.8 | 18.2 | +760.6 | 0.0 | 157.1 |
| SPELL CATCH ODDS | 0.1 | -0.1 | 5.4 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.8 | +163.3 | 0.0 | 7.9 | - | - | - | - |
| SPELL WORTH | 0.2 | +5.6 | 6.0 | 0.0 | 0.8 | +16.0 | 72.3 | 72.3 |
| STABLE ROLE | 16.5 | +0.0 | 464.0 | 47.7 | 11.2 | +0.0 | 201.8 | 54.2 |
| STANDS TO CAST | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.1 | +6.8 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.1 | +0.1 | 10.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.2 | +9.4 | 0.0 | 0.0 | 0.2 | +5.2 | 0.0 | 8.7 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORTS | 6.5 | +377.3 | 69.4 | 41.8 | 5.7 | +193.7 | 101.3 | 76.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.2 | 33.2 | 0.0 | 0.3 | -58.3 | 19.2 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +0.4 | 0.0 | 4.3 | 0.5 | +2.5 | 0.0 | 86.4 |
| THROUGH LINE OF FIRE | 0.1 | +2.5 | 0.0 | 7.1 | 0.4 | +17.8 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -13.1 | 12.0 | 13.1 | 0.5 | -19.8 | 41.0 | 16.2 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 0.0 | 7.1 | 0.8 | +2.3 | 24.1 | 0.0 |
| WALKS TO THE FIGHT | 2.2 | +88.4 | 67.8 | 4.3 | 0.8 | +46.0 | 6.8 | 6.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 5.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 0.8 | +9.8 | 47.1 | 15.2 | 2.0 | +53.5 | 152.3 | 223.8 |
| WHO HITS BACK | 0.2 | +4.2 | 0.0 | 0.0 | 0.2 | +41.3 | 0.0 | 15.5 |
| WHOLE FIGHT | 0.2 | +10.5 | 0.0 | 5.4 | 0.6 | +23.7 | 76.2 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +3.8 | 18.9 | 0.0 | 0.5 | +24.2 | 20.4 | 6.7 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: fw-on-db7ca9c-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 388 | 388 | 388 | 32.33 | -20707 | -53.4 |
| SUPPORTS | 146 | 146 | 106 | 8.83 | +3159 | +29.8 |
| BEST FIRST | 101 | 101 | 101 | 8.42 | +4655 | +46.1 |
| SEARCH SPOT | 75 | 75 | 74 | 6.17 | +3466 | +46.8 |
| MOVE TO CHARGE | 139 | 139 | 66 | 5.50 | +2280 | +34.5 |
| PATHS CROSS | 53 | 53 | 53 | 4.42 | +4475 | +84.4 |
| COUNTER-CHARGE COVER | 231 | 133 | 52 | 4.33 | +3849 | +74.0 |
| FACES THE THREAT | 45 | 45 | 45 | 3.75 | +3084 | +68.5 |
| KILLS COUNT NEXT TURN | 146 | 146 | 38 | 3.17 | +1014 | +26.7 |
| CANNON SIGHT KEPT | 34 | 34 | 34 | 2.83 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 33 | 33 | 33 | 2.75 | +0 | +0.0 |
| FALLBACK BY WORTH | 107 | 107 | 30 | 2.50 | +1471 | +49.0 |
| MODEL FACING | 28 | 28 | 28 | 2.33 | +5961 | +212.9 |
| INVITES THE FIGHT | 67 | 67 | 27 | 2.25 | +702 | +26.0 |
| SHOTS IN THE MOVE | 449 | 325 | 26 | 2.17 | +1076 | +41.4 |
| WALKS TO THE FIGHT | 36 | 36 | 25 | 2.08 | +574 | +23.0 |
| CANNON PLANNED TARGET | 160 | 160 | 24 | 2.00 | -786 | -32.7 |
| BEST FACING | 23 | 23 | 23 | 1.92 | +1130 | +49.1 |
| SAFER THAN THE JOB | 23 | 23 | 23 | 1.92 | +1519 | +66.1 |
| FOLLOW UP WEIGHED | 20 | 20 | 20 | 1.67 | +2964 | +148.2 |
| BEST OVERALL | 19 | 19 | 19 | 1.58 | +1567 | +82.5 |
| BLOCKED WHEEL | 18 | 18 | 18 | 1.50 | +709 | +39.4 |
| LONE WIZARD KEPT IN | 18 | 18 | 18 | 1.50 | +1377 | +76.5 |
| RESERVE FALL BACK | 18 | 18 | 18 | 1.50 | +468 | +26.0 |
| SET UP TOGETHER | 42 | 36 | 17 | 1.42 | +1546 | +90.9 |
| SHOT REPLANNED | 17 | 17 | 17 | 1.42 | +0 | +0.0 |
| RISK BY ARC | 57 | 51 | 14 | 1.17 | +307 | +21.9 |
| KILLS COUNT | 33 | 31 | 13 | 1.08 | +382 | +29.4 |
| SHOOTERS IN TWO RANKS | 13 | 13 | 13 | 1.08 | +26 | +2.0 |
| CHAFF PASSED | 12 | 12 | 12 | 1.00 | -18 | -1.5 |
| CHARGE NOW WEIGHED | 12 | 12 | 12 | 1.00 | +1134 | +94.5 |
| COMBAT PIVOT | 12 | 12 | 12 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 116 | 67 | 12 | 1.00 | +241 | +20.1 |
| RANDOM MOVE BY FIGURES | 23 | 23 | 12 | 1.00 | +263 | +21.9 |
| SCOUT WAITS | 12 | 12 | 12 | 1.00 | +0 | +0.0 |
| SHORT GUN FORWARD | 12 | 12 | 12 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 11 | 11 | 11 | 0.92 | +0 | +0.0 |
| REDIRECT COUNTER | 61 | 30 | 11 | 0.92 | +789 | +71.8 |
| ADVANCE LANE KEPT | 10 | 10 | 10 | 0.83 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.75 | +0 | +0.0 |
| BEST PREY | 22 | 22 | 8 | 0.67 | +143 | +17.9 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 8 | 0.67 | +662 | +82.7 |
| KEEPS ITS TARGET | 49 | 47 | 7 | 0.58 | +146 | +20.9 |
| MAKE SURE TOGETHER | 20 | 15 | 6 | 0.50 | +374 | +62.3 |
| MARCH CHECK | 6 | 6 | 6 | 0.50 | +277 | +46.2 |
| MISSILES IN THE MOVE | 68 | 37 | 6 | 0.50 | +118 | +19.7 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 0.50 | +527 | +87.8 |
| THROUGH LINE OF FIRE | 6 | 6 | 6 | 0.50 | +243 | +40.5 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.42 | -41 | -8.2 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.42 | +487 | +97.4 |
| MANOEUVRE | 6 | 6 | 5 | 0.42 | +324 | +64.8 |
| STOPS SHORT OF THE FLANK | 5 | 5 | 5 | 0.42 | +176 | +35.1 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.42 | -727 | -145.4 |
| WAR ENGINE JOBS | 18 | 18 | 5 | 0.42 | -244 | -48.9 |
| WEARS DOWN | 33 | 31 | 5 | 0.42 | +63 | +12.6 |
| WHO HITS BACK | 5 | 5 | 5 | 0.42 | +414 | +82.7 |
| BEST PRIZE | 4 | 4 | 4 | 0.33 | -335 | -83.7 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.33 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.33 | +209 | +52.2 |
| STUCK PIVOT | 4 | 4 | 4 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 9 | 9 | 4 | 0.33 | +220 | +55.0 |
| WHOLE FIGHT GAIN | 7 | 6 | 4 | 0.33 | +78 | +19.5 |
| CASTING BLOCK | 4 | 4 | 3 | 0.25 | +204 | +67.8 |
| HUNT IN PAIRS | 10 | 8 | 3 | 0.25 | +146 | +48.7 |
| MOVE AND CAST | 3 | 3 | 3 | 0.25 | +96 | +32.0 |
| OPENS UP | 4 | 4 | 3 | 0.25 | +158 | +52.8 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.17 | +110 | +55.1 |
| NEEDED THERE | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.17 | +126 | +62.8 |
| BOMBING RUN | 1 | 1 | 1 | 0.08 | +35 | +35.4 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.08 | -125 | -125.2 |
| CARRIES OUT SET-UP | 5 | 5 | 1 | 0.08 | -44 | -43.9 |
| CAST JOB | 5 | 5 | 1 | 0.08 | +1 | +0.7 |
| CATCH ODDS | 1 | 1 | 1 | 0.08 | -16 | -16.1 |
| CHARIOT NO STATIC JOB | 2 | 2 | 1 | 0.08 | -63 | -63.3 |
| DEFENSIVE ARMY | 14 | 14 | 1 | 0.08 | -15 | -14.8 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.08 | +5 | +4.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.08 | +11 | +10.7 |
| FOCUS FIRE | 1 | 1 | 1 | 0.08 | +14 | +13.7 |
| KEEP FALLS | 1 | 1 | 1 | 0.08 | +53 | +53.2 |
| LOST CHARGE | 55 | 55 | 1 | 0.08 | +8 | +8.0 |
| MISSILES NEXT TURN | 84 | 45 | 1 | 0.08 | +41 | +40.9 |
| MOVE SPELL IN RANGE | 8 | 7 | 1 | 0.08 | +0 | +0.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.08 | +1 | +1.2 |
| OVERRUNS AWAY | 14 | 13 | 1 | 0.08 | +3 | +3.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.08 | -10 | -10.3 |
| STANDS TO CAST | 1 | 1 | 1 | 0.08 | -12 | -11.5 |
| STAY WEIGHED | 1 | 1 | 1 | 0.08 | +82 | +81.6 |
| SURE REACH TOGETHER | 11 | 9 | 1 | 0.08 | +0 | +0.0 |
| TWO OR MORE ARRIVE | 11 | 6 | 1 | 0.08 | +10 | +10.2 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 25 | 9 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 11 | 11 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 14 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 13 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 150 | not checked | - | - | - | - |
| GIVES UP | 21 | 20 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 7 | 6 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 22 | 22 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 5 | 5 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 9 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 10 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 12 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NOT NEEDED | 1 | 1 | 0 | 0.00 | - | - |
| NOT TURNED | 139 | 139 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 948 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 9 | 9 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 12 | 12 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| STABLE ROLE | 332 | 331 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TURN WORTH | 10 | 9 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: fw-on-db7ca9c-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.25 | 14.42 | 53.4 |
| TURN GATE | gate | 1.08 | 0.25 | 41.7 |
| FALLBACK | gate | 0.83 | 0.25 | 52.8 |
| CANNON PLANNED TARGET | rule | 0.92 | 0.08 | 65.5 |
| SUPPORT REQUEST | gate | 0.08 | 0.42 | 75.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.33 | 145.4 |
| WAR ENGINE JOBS | rule | 0.42 | - | 48.9 |
| BEST PRIZE | rule | 0.08 | 0.25 | 83.7 |
| CHAFF PASSED | rule | - | 0.33 | 4.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.25 | 0.08 | 84.0 |
| PATHS CROSS | rule | 0.17 | 0.17 | 83.8 |
| BIG CHARACTER SAFETY | rule | - | 0.25 | 14.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.17 | - | 90.7 |
| BLOCKED WHEEL | rule | 0.08 | 0.08 | 15.7 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 74.0 |
| FACES THE THREAT | rule | - | 0.17 | 18.1 |
| FIGHT ORDER BAND | gate | 0.08 | 0.08 | 2.3 |
| AFTERMATH BAND | gate | 0.08 | - | 4.6 |
| CARRIES OUT COUNTER | rule | 0.08 | - | 125.2 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 43.9 |
| CATCH ODDS | rule | 0.08 | - | 16.1 |
| CHARIOT NO STATIC JOB | rule | 0.08 | - | 63.3 |
| DEFENSIVE ARMY | rule | 0.08 | - | 14.8 |
| FOLLOW UP WEIGHED | rule | 0.08 | - | 4.6 |
| PIVOT GUARDS FLANK | rule | 0.08 | - | 10.3 |
| REDIRECT WEIGHED | rule | 0.08 | - | 4.9 |
| STANDS TO CAST | rule | 0.08 | - | 11.5 |
| STOPS SHORT OF THE FLANK | rule | - | 0.08 | 5.8 |

### Plans: fw-on-db7ca9c-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.9 | 19% | 661 | 469 | 71% |
| Mine | charge | 1.7 | 60% | 190 | 108 | 57% |
| Mine | close in | 2.7 | 28% | 139 | 96 | 69% |
| Mine | hold | 4.1 | 45% | 284 | 0 | 0% |
| Mine | join | 1.2 | 93% | 53 | 0 | 0% |
| Mine | shoot | 10.2 | 75% | 530 | 1413 | 267% |
| Mine | support | 6.6 | 97% | 262 | 0 | 0% |
| Opponent | advance | 8.4 | 14% | 342 | 136 | 40% |
| Opponent | charge | 4.6 | 56% | 435 | 287 | 66% |
| Opponent | close in | 7.8 | 17% | 1028 | 84 | 8% |
| Opponent | hold | 6.2 | 38% | 524 | 0 | 0% |
| Opponent | join | 0.3 | 75% | 9 | 0 | 0% |
| Opponent | shoot | 6.2 | 49% | 371 | 306 | 82% |
| Opponent | support | 6.1 | 96% | 172 | 0 | 0% |

### Packages: hunt the guns, fw-on-db7ca9c-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 2 | 0 | 0% | 50% | 0% | 2.0 | 399 | 218 | 50% | 23 |
| Opponent | 0.2 | 3 | 0 | 33% | 33% | 0% | 2.0 | 151 | 41 | 33% | 160 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 332 | 0 | 0% | 40 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 466 | 437 | 100% | 20 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 318 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 165 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 277 |
| Tomb Kings of Khemri | 0.7 | 2 | 0 | 0% | 0% | 0% | - | 165 | 0 | 0% | 23 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.5 | 1 | 0 | 100% | 100% | 0% | 2.0 | 123 | 122 | 100% | 388 |

### Battle groups: fw-on-db7ca9c-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.8 | 23% | 59% | 25% | 50% | 50% | 4% | 12% | 33% | 0% |
| Mine | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 50% | 0% | 0% | 50% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.5 | 13% | 67% | 25% | 0% | 44% | 22% | 0% | 33% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 20% | 75% | 12% | 0% | 43% | 0% | 0% | 57% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-on-db7ca9c-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 7 | 0 (7) | 0 | 0 | 75 | 43% | 2.8 | 0 (2) | 0 (3) | 0 (2) | 0 (5) | 0 (2) |
| Mine | Character | 46 | 51 (46) | 51 | 0 | 23 | 7% | 2.5 | 0 (3) | 55 (25) | 59 (15) | 64 (18) | 43 (25) |
| Mine | Clean-up | 12 | 68 (12) | 8 | 60 | 31 | 83% | 1.0 | 0 (2) | 50 (8) | 211 (2) | 111 (8) | 0 (4) |
| Mine | Fast Hammer | 9 | 28 (9) | 20 | 8 | 70 | 44% | 2.8 | 0 (2) | 38 (3) | 40 (4) | 41 (6) | 0 (3) |
| Mine | Hammer | 28 | 31 (28) | 25 | 7 | 20 | 25% | 2.9 | 5 (5) | 30 (16) | 56 (7) | 28 (20) | 37 (8) |
| Mine | Holder | 10 | 39 (10) | 3 | 36 | 25 | 40% | 3.8 | 26 (5) | 185 (2) | 0 (3) | 39 (7) | 40 (3) |
| Mine | Shooter | 14 | 95 (14) | 32 | 63 | 32 | 0% | 1.1 | - | 84 (12) | 144 (2) | 127 (8) | 53 (6) |
| Mine | War machine | 30 | 57 (30) | 57 | 0 | 28 | 0% | 1.1 | 261 (4) | 28 (17) | 40 (9) | 13 (5) | 66 (25) |
| Mine | Wizard | 8 | 32 (8) | 32 | 0 | 20 | 12% | 2.6 | - | 15 (5) | 48 (3) | 152 (2) | 0 (6) |
| Opponent | Chaff | 20 | 53 (20) | 20 | 33 | 34 | 35% | 2.2 | 17 (6) | 80 (8) | 52 (6) | 59 (16) | 30 (4) |
| Opponent | Character | 31 | 24 (31) | 24 | 0 | 62 | 35% | 2.4 | 38 (11) | 19 (15) | 0 (2) | 30 (18) | 20 (10) |
| Opponent | Clean-up | 12 | 40 (12) | 20 | 20 | 40 | 17% | 2.9 | 0 (3) | 69 (9) | - | 58 (8) | 15 (4) |
| Opponent | Fast Hammer | 13 | 22 (13) | 18 | 4 | 43 | 38% | 2.2 | 54 (4) | 7 (5) | 17 (4) | 30 (7) | 8 (6) |
| Opponent | Hammer | 11 | 25 (11) | 19 | 5 | 22 | 36% | 3.7 | 0 (1) | 28 (8) | 31 (2) | 20 (9) | 41 (2) |
| Opponent | Holder | 15 | 113 (15) | 16 | 97 | 12 | 27% | 2.4 | 156 (2) | 148 (9) | 20 (4) | 132 (10) | 41 (5) |
| Opponent | Shooter | 15 | 139 (15) | 15 | 123 | 8 | 0% | 2.3 | 9 (3) | 188 (10) | 55 (2) | 189 (12) | 0 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 22 | 11 (22) | 11 | 0 | 17 | 14% | 1.5 | 17 (6) | 0 (13) | 43 (3) | 0 (3) | 13 (19) |
| Opponent | Wizard | 14 | 71 (14) | 71 | 0 | 33 | 7% | 1.3 | 0 (4) | 127 (7) | 0 (2) | 113 (5) | 0 (8) |

### Charged fights: fw-on-db7ca9c-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 127 | 82 | 1.8 | 1.1 | 47 | 0 | +47 | 2 of 7 | 7 of 7 | +55 | +45 |
| Mine | Chaos Dwarfs | 4 | 172 | 158 | 1.8 | 1.1 | 90 | 0 | +90 | 5 of 7 | 3 of 7 | +227 | +68 |
| Mine | Dwarfen Mountain Holds | 4 | 586 | 48 | 1.8 | 1.0 | 27 | 80 | -52 | 1 of 7 | 6 of 7 | - | -52 |
| **Mine** | all armies | 12 | 295 | 96 | 1.8 | 1.1 | 55 | 27 | +28 | 8 of 21 | 16 of 21 | +141 | +16 |
| Opponent | Dwarfen Mountain Holds | 2 | 229 | 116 | 4.0 | 1.4 | 29 | 0 | +29 | 1 of 8 | 3 of 8 | +50 | +16 |
| Opponent | Empire of Man | 2 | 98 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Opponent | Grand Cathay | 1 | 302 | 947 | 2.0 | 2.5 | 474 | 0 | +474 | 2 of 2 | 2 of 2 | +427 | +520 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 120 | 2.0 | 1.0 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | - | +60 |
| Opponent | Tomb Kings of Khemri | 3 | 101 | 476 | 4.0 | 1.3 | 119 | 222 | -103 | 8 of 12 | 8 of 12 | -240 | -35 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 309 | -309 | 3 of 3 | 0 of 3 | - | -309 |
| Opponent | Warriors of Chaos | 2 | 0 | 249 | 2.0 | 1.0 | 124 | 0 | +124 | 2 of 4 | 2 of 4 | - | +124 |
| **Opponent** | all armies | 12 | 105 | 269 | 2.8 | 1.3 | 98 | 109 | -11 | 16 of 33 | 19 of 33 | -48 | +1 |

### Effective charges: fw-on-db7ca9c-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 1 (net +0) | 0 | 0 | 1 (net +55) | 4 (net +36) | 1 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 7 | 2 (net +203) | 0 | 0 | 1 (net +0) | 0 | 4 (net +57) | 0 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 0 | 1 (net +80) | 0 | 0 | 6 (net -74) | 0 | 14% (1 of 7) |
| Opponent | Dwarfen Mountain Holds | 8 | 2 (net +0) | 1 (net +0) | 1 (net +85) | 2 (net +32) | 0 | 2 (net +40) | 0 | 12% (1 of 8) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 1 (net +520) | 1 (net +427) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 12 | 1 (net -511) | 0 | 3 (net -278) | 2 (net -238) | 0 | 4 (net +111) | 2 | 30% (3 of 10) |
| Opponent | Vampire Counts | 3 | 2 (net -464) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 4 | 1 (net +120) | 0 | 0 | 1 (net +378) | 0 | 1 (net +0) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: fw-on-db7ca9c-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 339 | 268 | +203 | 203 | 0 | +203 | +59.9 |
| Mine | 50-54% | 1 | 84 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 60 | 80 | +80 | 95 | 30 | +65 | +107.7 |
| Mine | 76-89% | 1 | 112 | 104 | +0 | 16 | 56 | -40 | -35.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 199 | 188 | -5 | 69 | 66 | +3 | +1.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 169 | 55 | +55 | 55 | 0 | +55 | +32.5 |
| Mine | No odds | 1 | 836 | 250 | +128 | 216 | 0 | +216 | +25.8 |
| Mine | All fights | 21 | 225 | 177 | +28 | 84 | 48 | +35 | +15.7 |
| Opponent | Long shot (under 50%) | 6 | 160 | 328 | -220 | 45 | 240 | -195 | -121.9 |
| Opponent | 50-54% | 1 | 60 | 84 | +0 | 0 | 60 | -60 | -100.0 |
| Opponent | Effective (55-75%) | 6 | 326 | 221 | -38 | 257 | 260 | -3 | -0.9 |
| Opponent | 76-89% | 7 | 458 | 263 | +56 | 159 | 128 | +31 | +6.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 | 170 | 164 | +58 | 79 | 18 | +61 | +35.8 |
| Opponent | No odds | 4 | 460 | 188 | +65 | 68 | 35 | +34 | +7.3 |
| Opponent | All fights | 33 | 289 | 226 | -11 | 118 | 129 | -11 | -3.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-on-db7ca9c-p2 | move | 154 | 33 (21%) | 23 (15%) | 14 (9%) | 107 (69%) |
| fw-on-db7ca9c-p2 | objective | 128 | 21 (16%) | 16 (12%) | 13 (10%) | 94 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Mine | L0206, L0222 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: fw-off-db7ca9c-p2

### Scorecard: fw-off-db7ca9c-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 9 | 4 | 2 | 2 | 0 | 0 | 0 | 442 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 1109 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 55 |
| L0206 | 2 | 1 | Mine | - | - | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | 3 | 5 | 1 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 6 | 0 | 2 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 1 | 0 | 0 | 140 |
| L0409 | 1 | 1 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 9 | 5 | 2 | 0 | 0 | 0 | 0 | 1179 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 4 | 2 | 0 | 0 | 348 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 593 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1497 |
| L0528 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 5 | 2 | 0 | 1 | 0 | 0 | 743 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 801 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 375 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 1 | 5 | 1 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 724 |
| L0810 | 6 | 1 | Opponent | no | 11 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 1 | 2 | 0 | 0 | 0 | 515 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 3 | 3 | 3 | 3 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 1105 |
| L0934 | 4 | 1 | Opponent | no | 5 | 2 | 5 | 4 | 0 | 0 | 0 | 216 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 8 | 3 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 2 | 0 | 0 | 485 |
| L1135 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 3 | 0 | 4 | 0 | 0 | 0 | 158 |
| L1228 | 4 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 4 | 3 | 2 | 1 | 1 | 0 | 0 | 302 |
| L1323 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 3 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 1 | 6 | 2 | 2 | 0 | 0 | 0 | 158 |
| L1531 | 1 | 1 | Mine | no | 4 | 2 | 5 | 1 | 1 | 0 | 0 | 176 |
| L1531 | 1 | 1 | Opponent | no | 1 | 5 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | no | - | 3 | 2 | 0 | 0 | 0 | 0 | 49 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 531 |
| L1827 | 3 | 1 | Opponent | no | 11 | 2 | 3 | 2 | 0 | 0 | 0 | 190 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 1 | - | 1 | 3 | 0 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 7 | 2 | 6 | 0 | 0 | 0 | 0 | 122 |
| L2131 | 1 | 1 | Mine | yes | 3 | 2 | 4 | 2 | 0 | 0 | 0 | 500 |
| L2131 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | no | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 1 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 4 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 75 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 7 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 20% | 1.7 | 2.6 | 3.1 | 1.2 | 0.2 | 0.0 | 0.0 | 341.4 |
| **Average** | | | Opponent | 27% | 2.6 | 2.6 | 2.7 | 2.0 | 0.4 | 0.0 | 0.0 | 218.7 |

### KPIs: fw-off-db7ca9c-p2

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 180) | 0% (0 of 184) | 0% (0 of 364) |
| Winner chose to follow up after the loser gave ground |  | 100% (59 of 59); on the table 100% | 91% (51 of 56); on the table 91% | 96% (110 of 115); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (7 of 7); on the table 100% | 91% (20 of 22); on the table 95% | 93% (27 of 29); on the table 97% |
| Winner chose to pursue after the loser fled |  | 78% (28 of 36); on the table 86% | 68% (13 of 19); on the table 89% | 75% (41 of 55); on the table 87% |
| Winner chose to follow up or pursue (all three) |  | 92% (94 of 102); on the table 95% | 87% (84 of 97); on the table 92% | 89% (178 of 199); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 31% (105 of 342) | 33% (51 of 156) | 31% (156 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (93 of 221) | 50% (51 of 103) | 44% (144 of 324) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 33% (23652 of 71583) | 37% (26742 of 71989) | 35% (50394 of 143572) |
|   infantry points that never fought | lower | 39% (6410 of 16324) | 56% (7895 of 14029) | 47% (14305 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (164 of 284) | 59% (174 of 297) | 58% (338 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 85% (17 of 20); 1.5 uses a game | 72% (13 of 18); 0.8 uses a game | 79% (30 of 38); 1.1 uses a game |
| Bound items with another spell used |  | 44% (8 of 18); 0.5 uses a game | 50% (1 of 2); 0.1 uses a game | 45% (9 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (15 of 20); 0.4 uses a game | 29% (2 of 7); 0.1 uses a game | 63% (17 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (31813 of 60231) | 51% (32085 of 63281) | 52% (63898 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (26%) | 0.6 (22%) | 2.3 (25%) |
| MARCHED: its unit marched | 1.1 (17%) | 0.4 (13%) | 1.5 (16%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.2 (7%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.7 (26%) | 0.6 (21%) | 2.3 (24%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (11%) | 0.5 (16%) | 1.2 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (9%) | 0.4 (13%) | 1.0 (11%) |
| STUPIDITY: Stupidity | 0.4 (6%) | 0.0 (0%) | 0.4 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.6 | 0.9 | 4.3 | 0.4 | 2.1 |
| not cast | 3.7 | 3.3 | 4.1 | 9.5 | 1.9 | 19.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (39%) | 0.3 (7%) | 2.3 (25%) | 0.4 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (16%) | 0.3 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (8%) | 0.8 (19%) | 2.3 (24%) | 0.2 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (10%) | 0.4 (12%) | 0.3 (8%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.2 (1%) |
| GONE: slain | 0.8 (22%) | 0.6 (17%) | 0.5 (13%) | 1.2 (12%) | 0.2 (10%) | 2.8 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (14%) | 0.4 (11%) | 0.6 (14%) | 1.0 (11%) | 0.2 (10%) | 1.5 (8%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (2%) | 0.2 (5%) | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.4 (19%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (49%) | 0.1 (3%) | 1.3 (32%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.4 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.5 a game | 0.5 a game | 0.5 a game |
| stood (cast and not dispelled) | 58% (11 of 19) | 29% (5 of 17) | 44% (16 of 36) |
| the unit moved after it | 73% (8 of 11) | 60% (3 of 5) | 69% (11 of 16) |
| it charged on its next turn | 9% (1 of 11) | 20% (1 of 5) | 12% (2 of 16) |
| the enemy charged it first | 9% (1 of 11) | 0% (0 of 5) | 6% (1 of 16) |
| it fought by the end of its next turn | 9% (1 of 11) | 0% (0 of 5) | 6% (1 of 16) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 11) | 20% (1 of 5) | 6% (1 of 16) |
| none of these (no charge, no fight, no charge escaped) | 82% (9 of 11) | 60% (3 of 5) | 75% (12 of 16) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (547 of 847) | 53% (431 of 809) | 59% (978 of 1656) |
|   cavalry | 56% (36 of 64) | 58% (92 of 160) | 57% (128 of 224) |
|   character | 51% (47 of 93) | 29% (35 of 119) | 39% (82 of 212) |
|   chariot | 38% (34 of 90) | 67% (34 of 51) | 48% (68 of 141) |
|   infantry | 57% (145 of 253) | 55% (169 of 306) | 56% (314 of 559) |
|   monster | 36% (17 of 47) | 57% (21 of 37) | 45% (38 of 84) |
|   war machine | 89% (268 of 300) | 59% (80 of 136) | 80% (348 of 436) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (31%) | 2.6 (24%) | 5.1 (27%) |
| CHARGED: it charged | 1.5 (18%) | 1.9 (19%) | 3.5 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.7 (7%) | 1.6 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.2 (15%) | 1.8 (17%) | 3.0 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.6 (5%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (18%) | 2.0 (19%) | 3.5 (19%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.4 (3%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (3%) | 0.4 (4%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.5 | 0.9 | 86% | 2.8 pts | 16 pts |
| character | 2.4 | 1.0 | 74% | 7.8 pts | 19 pts |
| chariot | 1.9 | 1.3 | 68% | 14.9 pts | 28 pts |
| infantry | 12.2 | 4.5 | 74% | 8.8 pts | 108 pts |
| monster | 1.4 | 0.4 | 76% | 7.6 pts | 10 pts |
| war machine | 9.7 | 8.6 | 61% | 27.4 pts | 265 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.9 | 5.4 | 5.2 |
| Charges that made contact a game | 3.6 | 3.9 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.08 declared, 0.76 contact (25 units) | 0.85 declared, 0.54 contact (13 units) | 1.00 declared, 0.68 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.50 contact (8 units) | 1.08 declared, 0.85 contact (13 units) | 0.95 declared, 0.71 contact (21 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.43 contact (245 units) | 0.57 declared, 0.42 contact (294 units) | 0.58 declared, 0.42 contact (539 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 70% (51 of 73) | 50% (9 of 18) | 67% (8 of 12) | 66% (68 of 103) |
| Character in a unit | 79% (19 of 24) | 29% (4 of 14) | 33% (1 of 3) | 59% (24 of 41) |
| Character on its own | 90% (43 of 48) | 45% (18 of 40) | 29% (18 of 63) | 52% (79 of 151) |
| Chariot | 71% (12 of 17) | 62% (8 of 13) | - | 67% (20 of 30) |
| Infantry | 54% (51 of 94) | 50% (17 of 34) | 33% (1 of 3) | 53% (69 of 131) |
| Monster | 62% (18 of 29) | 67% (6 of 9) | - | 63% (24 of 38) |
| Monstrous | 50% (7 of 14) | 43% (6 of 14) | - | 46% (13 of 28) |
| War Machines | 68% (39 of 57) | 100% (2 of 2) | - | 69% (41 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (7 of 7); on the table 100% | 13% (13 of 102) | 39% | 41% (9 of 22) | 50% (3 of 6); 1.8 uses a game | 50% (1 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (11 of 11); on the table 100% | 50% (18 of 36) | 45% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 73% (8 of 11); on the table 73% | - | 49% | 72% (39 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 100% (11 of 11); on the table 100% | 44% (21 of 48) | 42% | 67% (51 of 76) | 0.0 uses a game | 100% (2 of 2); 0.6 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 88% (22 of 25); on the table 92% | 38% (53 of 138) | 32% | 43% (23 of 54) | 86% (12 of 14); 6.3 uses a game | 0% (0 of 2); 0.0 uses a game | 33% (2 of 6); 0.3 uses a game |
| High Elf Realms | 4 | 92% (11 of 12); on the table 92% | 28% (5 of 18) | 42% | 52% (17 of 33) | 100% (3 of 3); 2.2 uses a game | 43% (6 of 14); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (4 of 4); on the table 100% | - | 43% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 21% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 71% (5 of 7); on the table 100% | 11% (2 of 18) | 29% | 68% (19 of 28) | 100% (4 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 8% (1 of 12) | 6% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 67% (10 of 15); on the table 80% | 33% (6 of 18) | 19% | 52% (13 of 25) | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 5 | 94% (16 of 17); on the table 94% | - | 39% | 44% (11 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 92% (24 of 26); on the table 100% | 39% (26 of 66) | 34% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 95% (19 of 20); on the table 100% | 33% (6 of 18) | 20% | 47% (34 of 73) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 90% (26 of 29); on the table 90% | 21% (5 of 24) | 40% | 62% (48 of 78) | 57% (4 of 7); 1.1 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-off-db7ca9c-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (46) | 49% (43) | 51% (89) |
| ...free all their last turn and able to turn (per game) | 0.92 | 0.75 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.19 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.42 | 1.06 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.03 | 0.50 | 1.53 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 0.94 | 1.75 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.61 | 6.58 | 13.19 |

### Quality by phase: fw-off-db7ca9c-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 58% (84 of 146) | 47% (84 of 177) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (162 of 336) | 43% (82 of 191) |
| Strategy | Close-in objectives charged next turn | 17% (26 of 152) | 16% (34 of 209) |
| Strategy | Support requests answered (helper made contact too) | 57% (8 of 14) | 20% (4 of 20) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 67% (2 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 38% (6 of 16) | 82% (9 of 11) |
| Strategy | Joined characters whose unit fought | 56% (25 of 45) | 46% (13 of 28) |
| Strategy | Lone characters that fought | 78% (78 of 100) | 79% (75 of 95) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 1.2 | 2.0 |
| Movement | Points that never moved of their own | 341.4 | 218.7 |
| Movement | Fights charged into per game | 3.3 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 111, net +110 | 14 of 109, net +75 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 111, net +80 | 23 of 109, net +105 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 111, net -5 | 6 of 109, net +138 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 of 111, net +108 | 43 of 109, net +119 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.4 | 10.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (142 of 301) | 42% (163 of 390) |
| Shooting | Points destroyed by shooting units | 73.0 | 41.8 |
| Shooting | War machine shots | 7.4 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (149 of 268) | 51% (41 of 80) |
| Shooting | Points destroyed by war machines | 113.0 | 34.0 |
| Magic | Magic missiles cast | 2.0 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (23 of 72) | 50% (15 of 30) |
| Magic | Wounds caused by magic missiles | 3.9 | 0.8 |
| Magic | Wounds caused by other spells | 1.3 | 1.5 |
| Magic | Points destroyed by magic (all spells) | 47.0 | 58.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.6 / 0.9 / 0.1 | 1.9 / 0.3 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 360.2 | 405.1 |
| Combat | Points run down | 78.8 | 117.4 |
| Combat | Net points per charged fight, damage counted | +90 | +95 |
| Combat | Net per 100 charger points, damage counted | +33.4 | +33.0 |
| Combat | First round won (charged fights) | 57% | 61% |
| Combat | Net points per charged fight | +80 | +100 |
| Combat | Net points per supported fight / lone fight | +93 / +79 | +175 / +89 |
| Combat | Charged fights on a top-3 enemy unit | 43 of 120 | 50 of 124 |
| Game | Points lost | 822.2 | 766.9 |
| Game | VP from objectives | 508.9 | 606.9 |
| Game | Lone holders (player turns) | 1.7 | 2.6 |

- Mine won / drew / lost: 11 / 7 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -138 VP
- The side that went first won 16 of 29 games with a winner
- Points traded per game (both sides' losses): 1589
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-off-db7ca9c-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 2.5 | 0.1 | +3.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 18.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +6.8 | 0.0 | 34.8 | 0.9 | +13.2 | 0.0 | 3.2 |
| BEST OVERALL | 0.4 | +29.4 | 0.0 | 13.3 | 0.3 | +23.6 | 0.0 | 17.2 |
| BEST PREY | 4.1 | +264.7 | 186.5 | 84.9 | 4.7 | +335.0 | 212.6 | 126.0 |
| BEST PRIZE | - | - | - | - | 0.1 | +6.6 | 10.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.8 | 0.0 | 0.1 | +0.0 | 10.7 | 0.0 |
| BLOCKED WHEEL | 0.3 | +1.4 | 0.0 | 7.4 | 0.6 | +7.9 | 0.0 | 3.9 |
| BOMBING RUN | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.4 | - | - | - | - |
| CANNON PLAN MISSED | 1.2 | +0.0 | 119.3 | 6.2 | 0.2 | +0.0 | 11.9 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +268.6 | 381.4 | 113.8 | 1.8 | +103.4 | 182.8 | 19.4 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -2.0 | 12.9 | 7.4 | 0.1 | +0.0 | 23.5 | 16.6 |
| CARRIES OUT SET-UP | 0.1 | -1.9 | 10.4 | 0.9 | 0.2 | -4.6 | 45.4 | 0.0 |
| CAST JOB | 0.8 | +12.6 | 18.5 | 16.6 | 0.6 | +12.1 | 72.8 | 17.7 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +24.1 | 36.2 | 8.2 | 0.2 | +7.0 | 14.1 | 12.6 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 15.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +3.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.4 | 5.4 | 2.2 | 0.2 | -0.4 | 6.4 | 0.0 |
| CHARGE NOW WEIGHED | 0.4 | -43.5 | 12.9 | 3.2 | 0.8 | -128.6 | 26.5 | 21.8 |
| CHARIOT NO STATIC JOB | 0.3 | +0.0 | 9.9 | 11.8 | 0.0 | +0.0 | 0.0 | 3.4 |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 2.9 | 0.1 | +0.0 | 6.6 | 3.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 6.4 | 37.1 | 0.5 | +0.0 | 24.4 | 43.3 |
| CONVEYANCE SEARCH | 0.4 | +31.1 | 0.0 | 0.0 | 0.4 | +47.7 | 10.6 | 53.9 |
| COUNTER-CHARGE COVER | 9.9 | +752.5 | 0.0 | 185.0 | 7.2 | +609.8 | 0.0 | 152.4 |
| EDGE GIVE GROUND | 0.2 | +11.6 | 6.9 | 8.2 | 0.3 | +5.5 | 33.4 | 6.6 |
| ELIXIR WORTH | 0.1 | +5.3 | 0.0 | 8.2 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| FACES THE THREAT | 1.0 | +76.5 | 0.0 | 29.1 | 0.5 | +45.7 | 0.0 | 37.5 |
| FALLBACK BY WORTH | 6.6 | +98.9 | 0.0 | 118.0 | 7.6 | +114.7 | 0.0 | 87.2 |
| FIGHT LIFT | 0.1 | +0.1 | 16.1 | 16.1 | 0.1 | +2.0 | 13.1 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.6 | 2.9 | 0.0 |
| FLANK NOT WEIGHED | 6.5 | +0.0 | 0.0 | 148.6 | 5.6 | +0.0 | 0.0 | 165.1 |
| FOLLOW UP WEIGHED | 1.0 | +160.7 | 0.0 | 44.1 | 1.1 | +161.9 | 0.0 | 13.3 |
| FRIENDS SHOTS CHECKED | 0.4 | +13.8 | 0.0 | 7.4 | 0.3 | +15.5 | 0.0 | 3.5 |
| GIVES UP | 1.1 | -26.7 | 109.0 | 30.7 | 1.5 | -53.1 | 196.4 | 79.9 |
| GIVES UP ITS SCREEN | 0.4 | -5.7 | 12.5 | 11.6 | 1.0 | -22.3 | 63.4 | 9.9 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 8.0 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 2.1 | 0.2 | +0.0 | 8.0 | 11.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.4 | 15.0 | 1.4 | 0.1 | +2.9 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.2 |
| HUNT IN PAIRS | 0.2 | +11.8 | 0.0 | 0.0 | 0.4 | +13.7 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +3.5 | 22.2 | 4.8 |
| HUNT RESULT | 0.1 | +15.2 | 0.0 | 0.0 | 0.2 | +11.8 | 11.1 | 5.1 |
| HUNT THE GUNS | 0.1 | +40.5 | 15.0 | 2.4 | 0.2 | +96.1 | 11.1 | 0.0 |
| JOINT CHARGE PLAN | 0.1 | +6.3 | 0.0 | 8.1 | 0.1 | +2.3 | 11.9 | 0.0 |
| KEEP FALLS | 0.1 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.4 | +3.8 | 5.8 | 25.7 | 0.2 | +2.5 | 6.4 | 4.4 |
| KEEPS ITS TARGET | 1.7 | +51.7 | 195.7 | 37.3 | 2.4 | +72.5 | 278.5 | 61.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.7 | +77.2 | 110.3 | 38.9 | 1.9 | +99.9 | 161.4 | 81.3 |
| KILLS COUNT NEXT TURN | 7.6 | +276.5 | 370.1 | 211.7 | 10.8 | +508.5 | 518.9 | 272.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +7.7 | 0.0 | 4.5 | 0.3 | +10.2 | 9.5 | 33.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 9.0 | 10.6 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.8 | +45.9 | 18.6 | 13.2 | 0.8 | +27.4 | 35.9 | 7.1 |
| MANOEUVRE | 0.2 | +8.8 | 0.0 | 1.8 | 0.1 | +3.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +19.2 | 0.0 | 0.0 | 0.5 | +13.2 | 0.0 | 18.2 |
| MARCH ODDS | 0.8 | +69.4 | 36.4 | 16.1 | 0.5 | +36.2 | 34.0 | 8.3 |
| MARCH OVER CASTS | 0.5 | +50.3 | 0.0 | 25.5 | 0.1 | +17.8 | 0.0 | 13.6 |
| MAX FOR POSITIONING | 4.4 | +151.4 | 0.0 | 102.0 | 4.8 | +185.9 | 0.0 | 93.2 |
| MISSILES IN THE MOVE | 3.6 | +83.6 | 0.0 | 89.6 | 2.7 | +52.2 | 0.0 | 119.1 |
| MISSILES NEXT TURN | 4.5 | +65.6 | 0.0 | 110.6 | 3.3 | +37.6 | 0.0 | 120.0 |
| MODEL FACING | 0.3 | +75.4 | 0.0 | 3.3 | 0.2 | +52.4 | 0.0 | 0.0 |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 9.6 | 0.0 | 0.2 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.2 | +8.8 | 0.0 | 1.7 | 0.1 | +9.5 | 0.0 | 1.9 |
| MOVE SPELL IN RANGE | 0.1 | +3.2 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -27.5 | 4.7 | 25.0 | 0.2 | -6.6 | 0.0 | 37.7 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.0 | +1.7 | 4.2 | 0.0 |
| NO RALLY LEFT | 0.1 | +2.2 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 3.0 |
| NOT NEEDED | 0.2 | -10.0 | 16.6 | 3.1 | 0.3 | -23.5 | 37.4 | 1.2 |
| NOT TURNED | 6.6 | +70.6 | 0.0 | 143.9 | 6.6 | +77.1 | 0.0 | 143.4 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 0.0 | 0.6 | -0.4 | 0.0 | 19.5 |
| OFF BEST | 17.7 | -913.2 | 30.3 | 215.5 | 19.1 | -1089.0 | 52.4 | 353.0 |
| OPENS A LANE | 0.2 | +2.0 | 24.9 | 0.0 | 0.1 | +0.6 | 12.8 | 0.0 |
| OPENS UP | 0.2 | +12.0 | 12.6 | 0.0 | 0.3 | +29.1 | 16.7 | 12.9 |
| OVERRUNS AWAY | 0.5 | +21.5 | 34.5 | 14.4 | 0.6 | +8.0 | 76.8 | 28.7 |
| PATHS CROSS | 1.8 | +140.3 | 0.0 | 57.8 | 2.9 | +212.6 | 0.0 | 68.5 |
| PERIAPT WORTH | 0.1 | +5.1 | 0.0 | 15.0 | 0.0 | +0.3 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.2 | 0.0 | 8.6 | 0.0 | -0.0 | 0.0 | 0.0 |
| PLAN RESULT | 36.8 | +1473.1 | 1379.2 | 1092.3 | 40.5 | +1386.8 | 1533.0 | 1065.1 |
| PURSUES BIG PREY | 0.1 | -5.0 | 0.0 | 0.0 | 0.2 | -7.7 | 0.0 | 16.6 |
| PURSUES ON | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.4 | 0.0 | 0.0 | 0.1 | +9.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.8 | +175.7 | 0.0 | 54.7 | 3.9 | +305.1 | 0.0 | 63.6 |
| REDIRECT WEIGHED | 0.2 | +0.8 | 0.8 | 2.9 | 0.6 | +45.6 | 45.1 | 10.9 |
| RESTRAINS TO SHOOT | 0.1 | +3.2 | 0.0 | 4.0 | 0.1 | +3.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.6 | +102.6 | 191.7 | 92.3 | 2.8 | +58.8 | 311.7 | 128.1 |
| SAFER THAN THE JOB | 0.8 | +40.7 | 0.0 | 14.7 | 0.9 | +88.1 | 0.0 | 17.2 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 1.5 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 1.5 | 0.6 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.5 | +79.3 | 0.0 | 47.4 | 1.9 | +117.2 | 0.0 | 34.9 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.5 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.2 | -0.2 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 1.2 | +50.8 | 28.2 | 18.0 | 1.6 | +70.4 | 68.0 | 32.8 |
| SET-UP ANY TARGET | 0.2 | +31.0 | 0.0 | 0.0 | 0.1 | +5.3 | 10.6 | 18.2 |
| SET-UP MISSED | - | - | - | - | 0.0 | +5.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 114.6 | 3.3 | 0.5 | +0.0 | 31.2 | 1.7 |
| SHOTS IN THE MOVE | 13.7 | +677.5 | 0.0 | 263.2 | 11.1 | +375.1 | 0.0 | 174.5 |
| SPELL SETS UP CHARGE | 0.2 | +46.5 | 0.0 | 0.0 | 0.2 | +35.9 | 10.6 | 18.2 |
| SPELL WORTH | 0.9 | +26.0 | 84.3 | 76.7 | 1.6 | +29.2 | 79.0 | 52.8 |
| STANDS TO CAST | - | - | - | - | 0.1 | +4.7 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.0 | 0.0 | 0.9 | 0.2 | +7.9 | 11.1 | 2.9 |
| STOPS SHORT OF THE FLANK | 0.4 | +19.3 | 0.0 | 6.6 | 0.2 | +16.6 | 0.0 | 1.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 9.4 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 7.6 | 0.0 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.2 | -15.6 | 38.8 | 10.5 | 0.2 | -6.8 | 6.2 | 3.5 |
| SURE REACH TOGETHER | 0.4 | -6.2 | 9.6 | 9.4 | 0.7 | -6.3 | 0.0 | 12.3 |
| THROUGH LINE OF FIRE | 0.3 | +12.2 | 0.0 | 16.6 | 0.3 | +9.1 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -23.5 | 33.8 | 7.7 | 0.3 | -18.0 | 16.7 | 21.6 |
| TWO OR MORE ARRIVE | 0.2 | +2.6 | 0.0 | 5.2 | 0.3 | +1.0 | 34.4 | 4.8 |
| WEARS DOWN | 1.2 | +52.3 | 155.1 | 75.3 | 1.5 | +52.7 | 187.4 | 60.4 |
| WHO HITS BACK | 0.2 | +24.5 | 0.0 | 25.0 | 0.2 | +24.8 | 0.0 | 9.0 |
| WHOLE FIGHT | 0.2 | +1.2 | 56.0 | 1.8 | 0.3 | -3.9 | 71.7 | 1.4 |
| WHOLE FIGHT GAIN | 0.2 | +12.8 | 8.0 | 2.9 | 0.2 | +22.8 | 27.0 | 12.8 |

### Rule changes: fw-off-db7ca9c-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1326 | 1326 | 1326 | 36.83 | -72073 | -54.4 |
| KILLS COUNT NEXT TURN | 663 | 650 | 209 | 5.81 | +7231 | +34.6 |
| PATHS CROSS | 171 | 171 | 171 | 4.75 | +12701 | +74.3 |
| BEST PREY | 317 | 309 | 143 | 3.97 | +6701 | +46.9 |
| COUNTER-CHARGE COVER | 617 | 311 | 136 | 3.78 | +7686 | +56.5 |
| FALLBACK BY WORTH | 511 | 511 | 130 | 3.61 | +7688 | +59.1 |
| SEARCH SPOT | 122 | 122 | 121 | 3.36 | +7074 | +58.5 |
| ARTILLERY RE-ROLL WEIGHED | 75 | 75 | 75 | 2.08 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 75 | 75 | 75 | 2.08 | +11614 | +154.9 |
| CANNON SIGHT KEPT | 65 | 65 | 65 | 1.81 | +0 | +0.0 |
| SAFER THAN THE JOB | 63 | 63 | 63 | 1.75 | +4636 | +73.6 |
| SHOTS IN THE MOVE | 892 | 541 | 58 | 1.61 | +1294 | +22.3 |
| FACES THE THREAT | 55 | 55 | 55 | 1.53 | +4399 | +80.0 |
| CHARGE NOW WEIGHED | 45 | 45 | 45 | 1.25 | +3919 | +87.1 |
| ADVANCE LANE KEPT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| MARCH ODDS | 45 | 45 | 43 | 1.19 | +1216 | +28.3 |
| MAX FOR POSITIONING | 332 | 174 | 41 | 1.14 | +287 | +7.0 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RISK BY ARC | 191 | 175 | 40 | 1.11 | +1816 | +45.4 |
| SHOT REPLANNED | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| KEEPS ITS TARGET | 149 | 145 | 39 | 1.08 | +677 | +17.4 |
| MARCH CHECK | 41 | 40 | 39 | 1.08 | +1360 | +34.9 |
| SET UP TOGETHER | 99 | 80 | 35 | 0.97 | +1373 | +39.2 |
| BLOCKED WHEEL | 33 | 33 | 33 | 0.92 | +334 | +10.1 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| KILLS COUNT | 130 | 119 | 32 | 0.89 | +1533 | +47.9 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CANNON PLANNED TARGET | 257 | 257 | 31 | 0.86 | -462 | -14.9 |
| REDIRECT COUNTER | 242 | 87 | 31 | 0.86 | +2458 | +79.3 |
| BEST OVERALL | 27 | 27 | 27 | 0.75 | +1908 | +70.7 |
| MISSILES IN THE MOVE | 228 | 128 | 26 | 0.72 | +652 | +25.1 |
| REDIRECT WEIGHED | 26 | 26 | 26 | 0.72 | +1480 | +56.9 |
| FRIENDS SHOTS CHECKED | 25 | 25 | 25 | 0.69 | +1052 | +42.1 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +49 | +2.0 |
| CAST JOB | 47 | 44 | 24 | 0.67 | +250 | +10.4 |
| STOPS SHORT OF THE FLANK | 22 | 22 | 22 | 0.61 | +1291 | +58.7 |
| MODEL FACING | 20 | 20 | 20 | 0.56 | +4600 | +230.0 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 0.56 | +768 | +38.4 |
| WEARS DOWN | 99 | 94 | 20 | 0.56 | +454 | +22.7 |
| CHAFF PASSED | 18 | 18 | 18 | 0.50 | -26 | -1.5 |
| SURE CHARGE BEATS ADVANCE | 17 | 17 | 17 | 0.47 | -806 | -47.4 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MAKE SURE TOGETHER | 59 | 33 | 15 | 0.42 | +716 | +47.7 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +1265 | +84.4 |
| CASTING BLOCK | 20 | 20 | 14 | 0.39 | +699 | +49.9 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 13 | 13 | 12 | 0.33 | +436 | +36.3 |
| MOVE AND CAST | 12 | 12 | 12 | 0.33 | +661 | +55.1 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +245 | +27.2 |
| CHARIOT NO STATIC JOB | 13 | 13 | 8 | 0.22 | -1059 | -132.4 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -456 | -57.0 |
| OVERRUNS AWAY | 39 | 32 | 7 | 0.19 | +136 | +19.5 |
| WHOLE FIGHT GAIN | 18 | 11 | 7 | 0.19 | +314 | +44.8 |
| HUNT IN PAIRS | 21 | 14 | 6 | 0.17 | +319 | +53.1 |
| OPENS UP | 16 | 13 | 6 | 0.17 | +483 | +80.5 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -80 | -13.3 |
| WHOLE FIGHT | 20 | 18 | 6 | 0.17 | +182 | +30.3 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.14 | -13 | -2.7 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +141 | +28.3 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 5 | 0.14 | -88 | -17.5 |
| KEEPS ITS PREY | 19 | 19 | 4 | 0.11 | +71 | +17.7 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MISSILES NEXT TURN | 281 | 155 | 4 | 0.11 | +27 | +6.8 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +21 | +5.2 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +154 | +38.5 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -93 | -31.0 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +198 | +65.8 |
| CARRIES OUT SET-UP | 10 | 10 | 2 | 0.06 | -235 | -117.7 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -102 | -50.9 |
| EDGE GIVE GROUND | 18 | 18 | 2 | 0.06 | +42 | +20.9 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +192 | +96.1 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +21 | +10.4 |
| HUNT ADVANCE | 7 | 7 | 2 | 0.06 | +59 | +29.5 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -99 | -49.4 |
| SURE REACH TOGETHER | 39 | 28 | 2 | 0.06 | +23 | +11.3 |
| BACKUP TARGETS | 68 | 31 | 1 | 0.03 | +5 | +5.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +26 | +25.9 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CARRIES OUT COUNTER | 7 | 7 | 1 | 0.03 | -72 | -72.0 |
| GIVES UP | 93 | 85 | 1 | 0.03 | +37 | +37.4 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +10 | +9.7 |
| MOVE SPELL IN RANGE | 3 | 2 | 1 | 0.03 | +0 | +0.3 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 9 | 7 | 1 | 0.03 | +3 | +3.0 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +13 | +13.2 |
| STOPS | 7 | 7 | 1 | 0.03 | +13 | +13.1 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +67 | +67.0 |
| TURN WORTH | 22 | 20 | 1 | 0.03 | +7 | +6.7 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 52 | 52 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 434 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 51 | 48 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 11 | 10 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 21 | 21 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 18 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 475 | 475 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 39 | not checked | - | - | - | - |
| PLAN RESULT | 2784 | trace | - | - | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 15 | not checked | - | - | - | - |
| SPELL WORTH | 91 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 17 | 14 | 0 | 0.00 | - | - |

### Off best figure: fw-off-db7ca9c-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.19 | 16.22 | 55.6 |
| FALLBACK | gate | 0.94 | 1.11 | 59.7 |
| RULE SWITCHED OFF | gate | 0.72 | 1.00 | 24.9 |
| TURN GATE | gate | 0.42 | 0.33 | 60.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.25 | 0.22 | 47.4 |
| PATHS CROSS | rule | 0.22 | 0.14 | 25.0 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.19 | 17.4 |
| CHAFF PASSED | rule | 0.11 | 0.14 | 2.9 |
| SUPPORT REQUEST | gate | 0.11 | 0.14 | 103.4 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 2.4 |
| CHARIOT NO STATIC JOB | rule | 0.19 | 0.03 | 132.4 |
| PURSUES BIG PREY | rule | 0.06 | 0.17 | 57.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.11 | 33.0 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.06 | 79.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.08 | 63.0 |
| BLOCKED WHEEL | rule | 0.11 | 0.06 | 54.4 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.03 | 13.3 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.11 | 17.5 |
| BEST PRIZE | rule | - | 0.08 | 31.0 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.06 | 11.3 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 117.7 |
| CATCH ODDS | rule | - | 0.06 | 50.9 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 3.8 |
| MARCH ODDS | rule | 0.06 | - | 9.5 |
| REDIRECT WEIGHED | rule | - | 0.06 | 22.0 |
| STANDS TO CAST | rule | - | 0.06 | 49.4 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 14.3 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 17.2 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 72.0 |
| FIGHT ORDER BAND | gate | - | 0.03 | 1.8 |
| SAFER THAN THE JOB | rule | 0.03 | - | 5.4 |

### Plans: fw-off-db7ca9c-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.3 | 18% | 425 | 382 | 90% |
| Mine | charge | 3.2 | 59% | 362 | 288 | 79% |
| Mine | close in | 4.2 | 26% | 299 | 122 | 41% |
| Mine | hold | 4.2 | 34% | 307 | 0 | 0% |
| Mine | join | 0.5 | 94% | 14 | 0 | 0% |
| Mine | shoot | 8.2 | 64% | 305 | 682 | 223% |
| Mine | support | 4.4 | 89% | 231 | 0 | 0% |
| Opponent | advance | 14.5 | 17% | 615 | 384 | 62% |
| Opponent | charge | 4.1 | 58% | 505 | 372 | 74% |
| Opponent | close in | 5.8 | 29% | 455 | 218 | 48% |
| Opponent | hold | 4.6 | 43% | 394 | 0 | 0% |
| Opponent | join | 0.6 | 100% | 31 | 0 | 0% |
| Opponent | shoot | 4.4 | 68% | 182 | 415 | 227% |
| Opponent | support | 6.6 | 91% | 321 | 0 | 0% |

### Packages: hunt the guns, fw-off-db7ca9c-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 0% | 25% | 0% | 2.0 | 364 | 137 | 25% | 38 |
| Opponent | 0.2 | 7 | 0 | 29% | 14% | 0% | 3.0 | 494 | 61 | 14% | 140 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 358 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 234 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 548 | 546 | 100% | 99 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 326 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 0% | 0% | 0% | - | 461 | 0 | 0% | 234 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 177 |
| Tomb Kings of Khemri | 0.4 | 2 | 0 | 100% | 50% | 0% | 3.0 | 441 | 213 | 50% | 28 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 481 | 0 | 0% | 180 |
| Wood Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 446 | 0 | 0% | 88 |

### Battle groups: fw-off-db7ca9c-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.9 | 20% | 50% | 8% | 50% | 29% | 15% | 12% | 44% | 0% |
| Mine | REDIRECT COUNTER | 2.8 | 28% | 69% | 24% | 29% | 18% | 5% | 5% | 73% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.2 | 22% | 75% | 16% | 44% | 42% | 6% | 6% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 24% | 73% | 9% | 33% | 23% | 0% | 20% | 57% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-off-db7ca9c-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 5 (5) | 5 | 0 | 67 | 20% | 2.2 | 10 (3) | 0 (1) | 0 (1) | 8 (4) | 0 (1) |
| Mine | Chaff | 44 | 29 (44) | 8 | 21 | 73 | 34% | 3.0 | 44 (24) | 0 (5) | 14 (15) | 27 (30) | 34 (14) |
| Mine | Character | 123 | 50 (123) | 50 | 0 | 43 | 15% | 2.5 | 45 (32) | 62 (59) | 59 (8) | 66 (55) | 42 (44) |
| Mine | Clean-up | 12 | 65 (12) | 8 | 57 | 57 | 25% | 3.6 | 52 (3) | 45 (6) | 137 (3) | 93 (7) | 29 (5) |
| Mine | Fast Hammer | 45 | 57 (45) | 47 | 11 | 50 | 31% | 2.8 | 61 (24) | 63 (10) | 40 (11) | 55 (31) | 64 (14) |
| Mine | Fragile | 5 | 9 (5) | 9 | 0 | 40 | 0% | 2.2 | - | 15 (3) | 0 (2) | 9 (5) | - |
| Mine | Hammer | 58 | 36 (58) | 28 | 8 | 45 | 19% | 2.7 | 6 (15) | 53 (33) | 19 (10) | 46 (38) | 21 (20) |
| Mine | Holder | 28 | 44 (28) | 7 | 37 | 17 | 32% | 3.6 | 25 (9) | 60 (15) | 34 (4) | 43 (18) | 46 (10) |
| Mine | Shooter | 43 | 75 (43) | 15 | 60 | 52 | 2% | 1.8 | 43 (7) | 87 (26) | 58 (10) | 107 (27) | 19 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | War machine | 59 | 70 (59) | 70 | 0 | 44 | 3% | 1.2 | 77 (13) | 68 (36) | 71 (10) | 53 (10) | 74 (49) |
| Mine | Wizard | 22 | 17 (22) | 17 | 0 | 44 | 18% | 2.2 | 0 (6) | 28 (9) | 57 (3) | 44 (9) | 0 (9) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 89 | 38 (89) | 16 | 22 | 49 | 38% | 2.6 | 33 (35) | 4 (20) | 66 (34) | 39 (63) | 34 (26) |
| Opponent | Character | 94 | 64 (94) | 64 | 0 | 41 | 17% | 2.6 | 96 (41) | 43 (35) | 15 (6) | 65 (55) | 78 (27) |
| Opponent | Clean-up | 10 | 36 (10) | 0 | 36 | 57 | 50% | 2.8 | 0 (6) | 124 (3) | 0 (1) | 12 (7) | 106 (3) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 45 | 35 (45) | 24 | 11 | 45 | 31% | 3.1 | 21 (28) | 61 (8) | 55 (9) | 32 (28) | 41 (17) |
| Opponent | Fragile | 5 | 124 (5) | 124 | 0 | 61 | 40% | 2.7 | 0 (1) | 202 (3) | 0 (1) | 0 (4) | 656 (1) |
| Opponent | Hammer | 69 | 30 (69) | 25 | 6 | 50 | 25% | 2.7 | 27 (19) | 29 (37) | 42 (13) | 32 (40) | 29 (29) |
| Opponent | Holder | 33 | 87 (33) | 14 | 72 | 16 | 36% | 3.2 | 43 (8) | 106 (22) | 50 (3) | 98 (18) | 71 (15) |
| Opponent | Shooter | 35 | 91 (35) | 16 | 75 | 36 | 3% | 1.6 | 46 (11) | 138 (17) | 30 (7) | 129 (23) | 33 (12) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 67% | 6.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 48 (24) | 48 | 0 | 12 | 17% | 1.7 | 22 (6) | 69 (15) | 0 (3) | 0 (2) | 52 (22) |
| Opponent | Wizard | 29 | 48 (29) | 48 | 0 | 41 | 3% | 1.9 | 0 (13) | 112 (8) | 0 (5) | 99 (13) | 0 (13) |

### Charged fights: fw-off-db7ca9c-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 90 | 135 | 1.2 | 1.0 | 108 | 0 | +108 | 4 of 5 | 5 of 5 | - | +108 |
| Mine | Chaos Dwarfs | 4 | 259 | 700 | 3.0 | 1.1 | 234 | 8 | +226 | 8 of 12 | 9 of 12 | +479 | +203 |
| Mine | Dwarfen Mountain Holds | 4 | 750 | 76 | 1.8 | 1.1 | 44 | 67 | -23 | 3 of 7 | 3 of 7 | +0 | -27 |
| Mine | Empire of Man | 5 | 301 | 391 | 3.0 | 1.0 | 130 | 40 | +90 | 6 of 15 | 7 of 15 | - | +90 |
| Mine | Grand Cathay | 4 | 356 | 470 | 3.5 | 1.1 | 134 | 43 | +92 | 4 of 14 | 8 of 14 | +60 | +94 |
| Mine | High Elf Realms | 4 | 99 | 605 | 3.5 | 1.0 | 173 | 51 | +122 | 3 of 14 | 12 of 14 | - | +122 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 5.0 | 1.0 | 0 | 0 | +0 | 3 of 5 | 2 of 5 | - | +0 |
| Mine | Lizardmen | 1 | 0 | 304 | 4.0 | 1.2 | 76 | 35 | +41 | 0 of 4 | 1 of 4 | -141 | +101 |
| Mine | Ogre Kingdoms | 1 | 0 | 235 | 6.0 | 1.0 | 39 | 101 | -62 | 3 of 6 | 1 of 6 | - | -62 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 1144 | 6.0 | 1.0 | 191 | 9 | +182 | 2 of 6 | 4 of 6 | - | +182 |
| Mine | Skaven | 2 | 258 | 246 | 4.0 | 1.2 | 61 | 36 | +25 | 1 of 8 | 4 of 8 | +60 | +14 |
| Mine | Tomb Kings of Khemri | 1 | 158 | 664 | 7.0 | 1.0 | 95 | 62 | +33 | 2 of 7 | 5 of 7 | - | +33 |
| Mine | Vampire Counts | 3 | 0 | 419 | 4.3 | 1.1 | 97 | 59 | +38 | 4 of 13 | 5 of 13 | +120 | +31 |
| Mine | Warriors of Chaos | 1 | 0 | 487 | 4.0 | 1.2 | 122 | 24 | +97 | 0 of 4 | 2 of 4 | +109 | +93 |
| **Mine** | all armies | 36 | 233 | 402 | 3.3 | 1.1 | 121 | 41 | +80 | 43 of 120 | 68 of 120 | +93 | +79 |
| Opponent | Dwarfen Mountain Holds | 2 | 94 | 96 | 3.5 | 1.1 | 27 | 35 | -8 | 0 of 7 | 4 of 7 | +0 | -9 |
| Opponent | Empire of Man | 2 | 758 | 70 | 1.0 | 1.5 | 70 | 0 | +70 | 0 of 2 | 1 of 2 | +140 | +0 |
| Opponent | Grand Cathay | 2 | 651 | 529 | 4.0 | 1.2 | 132 | 0 | +132 | 4 of 8 | 7 of 8 | +85 | +139 |
| Opponent | Kingdom of Bretonnia | 1 | 165 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Ogre Kingdoms | 3 | 119 | 109 | 4.0 | 1.1 | 27 | 9 | +18 | 4 of 12 | 3 of 11 | +177 | +4 |
| Opponent | Skaven | 1 | 110 | 77 | 1.0 | 1.0 | 77 | 0 | +77 | 0 of 1 | 1 of 1 | - | +77 |
| Opponent | Tomb Kings of Khemri | 4 | 123 | 946 | 4.2 | 1.2 | 223 | 52 | +171 | 11 of 17 | 9 of 17 | +190 | +165 |
| Opponent | Vampire Counts | 6 | 0 | 273 | 3.0 | 1.1 | 91 | 40 | +51 | 6 of 18 | 11 of 18 | +0 | +57 |
| Opponent | Warriors of Chaos | 8 | 0 | 488 | 3.8 | 1.2 | 130 | 16 | +114 | 18 of 30 | 20 of 30 | +197 | +97 |
| Opponent | Wood Elf Realms | 7 | 100 | 628 | 4.0 | 1.1 | 157 | 21 | +136 | 7 of 28 | 18 of 28 | +414 | +114 |
| **Opponent** | all armies | 36 | 134 | 431 | 3.4 | 1.1 | 125 | 25 | +100 | 50 of 124 | 75 of 123 | +175 | +89 |

### Effective charges: fw-off-db7ca9c-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 0 | 0 | 0 | 4 (net +135) | 1 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 12 | 2 (net +353) | 0 | 3 (net +420) | 3 (net +193) | 1 (net +153) | 3 (net +4) | 0 | 25% (3 of 12) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 1 (net -233) | 1 (net -128) | 0 | 0 | 4 (net +42) | 1 | 17% (1 of 6) |
| Mine | Empire of Man | 15 | 3 (net +62) | 0 | 2 (net -265) | 5 (net +185) | 0 | 4 (net +192) | 1 | 14% (2 of 14) |
| Mine | Grand Cathay | 14 | 2 (net -182) | 0 | 5 (net +121) | 0 | 2 (net +30) | 5 (net +196) | 0 | 36% (5 of 14) |
| Mine | High Elf Realms | 14 | 0 | 1 (net +120) | 1 (net -151) | 1 (net +546) | 2 (net -164) | 9 (net +169) | 0 | 7% (1 of 14) |
| Mine | Kingdom of Bretonnia | 5 | 2 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Mine | Lizardmen | 4 | 1 (net +250) | 0 | 1 (net +0) | 0 | 1 (net -141) | 0 | 1 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 0 | 1 (net -34) | 1 (net +45) | 2 (net +2) | 2 | 0% (0 of 4) |
| Mine | Orc & Goblin Tribes | 6 | 3 (net +304) | 0 | 0 | 1 (net -55) | 1 (net +45) | 0 | 1 | 0% (0 of 5) |
| Mine | Skaven | 8 | 0 | 0 | 0 | 4 (net -6) | 1 (net +0) | 2 (net +42) | 1 | 0% (0 of 7) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 0 | 1 (net -431) | 2 (net +0) | 4 (net +166) | 0 | 0% (0 of 7) |
| Mine | Vampire Counts | 13 | 2 (net -22) | 0 | 2 (net +186) | 2 (net +100) | 0 | 6 (net -27) | 1 | 17% (2 of 12) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 2 (net +3) | 0 | 1 (net +109) | 1 (net +274) | 0 | 50% (2 of 4) |
| Opponent | Dwarfen Mountain Holds | 7 | 1 (net +0) | 0 | 1 (net -60) | 3 (net -16) | 0 | 2 (net +28) | 0 | 14% (1 of 7) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +140) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 8 | 1 (net +0) | 0 | 1 (net +85) | 3 (net +285) | 0 | 2 (net +58) | 1 | 14% (1 of 7) |
| Opponent | Ogre Kingdoms | 12 | 1 (net +0) | 0 | 2 (net -20) | 0 | 0 | 3 (net +109) | 6 | 33% (2 of 6) |
| Opponent | Skaven | 1 | 0 | 0 | 1 (net +77) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 17 | 3 (net +166) | 1 (net -511) | 5 (net +187) | 2 (net +42) | 0 | 4 (net +396) | 2 | 33% (5 of 15) |
| Opponent | Vampire Counts | 18 | 5 (net +0) | 0 | 3 (net +120) | 6 (net +104) | 2 (net +164) | 2 (net -199) | 0 | 17% (3 of 18) |
| Opponent | Warriors of Chaos | 30 | 2 (net -58) | 0 | 5 (net +118) | 2 (net +282) | 2 (net +146) | 15 (net +120) | 4 | 19% (5 of 26) |
| Opponent | Wood Elf Realms | 28 | 1 (net +663) | 0 | 4 (net +86) | 5 (net +155) | 2 (net +105) | 15 (net +109) | 1 | 15% (4 of 27) |

### Charged fights, damage counted: fw-off-db7ca9c-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 257 | 232 | +110 | 161 | 43 | +118 | +46.0 |
| Mine | 50-54% | 2 | 82 | 304 | -56 | 60 | 116 | -56 | -68.5 |
| Mine | Effective (55-75%) | 18 | 277 | 236 | +80 | 170 | 84 | +86 | +31.0 |
| Mine | 76-89% | 19 | 255 | 244 | +90 | 163 | 68 | +95 | +37.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 | 237 | 184 | +108 | 154 | 29 | +125 | +52.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 429 | 80 | -5 | 65 | 72 | -7 | -1.7 |
| Mine | No odds | 9 | 284 | 160 | +17 | 99 | 78 | +21 | +7.6 |
| Mine | All fights | 120 | 268 | 197 | +80 | 144 | 55 | +90 | +33.4 |
| Opponent | Long shot (under 50%) | 14 | 262 | 296 | +75 | 131 | 66 | +66 | +25.0 |
| Opponent | 50-54% | 1 | 411 | 272 | -511 | 90 | 511 | -421 | -102.4 |
| Opponent | Effective (55-75%) | 23 | 303 | 202 | +105 | 136 | 40 | +96 | +31.8 |
| Opponent | 76-89% | 22 | 279 | 158 | +130 | 158 | 49 | +109 | +39.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 43 | 289 | 190 | +119 | 168 | 38 | +130 | +44.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 507 | 130 | +138 | 138 | 36 | +102 | +20.1 |
| Opponent | No odds | 15 | 207 | 177 | +47 | 69 | 35 | +34 | +16.3 |
| Opponent | All fights | 124 | 288 | 195 | +100 | 142 | 47 | +95 | +33.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-off-db7ca9c-p2 | move | 477 | 114 (24%) | 80 (17%) | 43 (9%) | 320 (67%) |
| fw-off-db7ca9c-p2 | objective | 361 | 60 (17%) | 46 (13%) | 42 (12%) | 259 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

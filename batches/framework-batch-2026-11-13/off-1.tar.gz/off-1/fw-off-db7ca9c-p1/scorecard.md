# Doctrine scorecard: fw-off-db7ca9c-p1

### Scorecard: fw-off-db7ca9c-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 10 | 3 | 1 | 0 | 0 | 0 | 0 | 322 |
| L0102 | 6 | 1 | Opponent | no | 2 | 3 | 1 | 6 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 7 | 1 | 1 | 5 | 0 | 0 | 0 | 302 |
| L0135 | 3 | 1 | Mine | yes | 9 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 7 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 10 | 2 | 6 | 0 | 0 | 0 | 0 | 760 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 3 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 1019 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 2 | - | 0 | 3 | 1 | 0 | 0 | 145 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 3 | 2 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 10 | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 1292 |
| L0628 | 4 | 1 | Opponent | no | 2 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 60 |
| L0913 | 1 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 970 |
| L0913 | 1 | 1 | Opponent | no | 8 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 793 |
| L0930 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 0 | 5 | 0 | 0 | 0 | 145 |
| L1114 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 522 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 177 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 5 | 0 | 1 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 1 | 5 | 2 | 1 | 3 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 9 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 15 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 2 | 1 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 4 | 0 | 0 | 0 | 140 |
| L1431 | 3 | 1 | Mine | yes | 10 | 3 | 5 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 1 | 2 | 0 | 0 | 170 |
| L1527 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 7 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 6 | 3 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 1 | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | yes | 2 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 3 | 1 | 3 | 0 | 0 | 0 | 0 | 245 |
| L2025 | 3 | 1 | Mine | yes | 1 | 4 | 1 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 1 | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 1162 |
| L2127 | 3 | 1 | Opponent | no | 7 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 1 | 6 | 1 | 2 | 0 | 0 | 933 |
| L2335 | 1 | 1 | Mine | no | 3 | 1 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 158 |
| L2531 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 6 | 1 | 2 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 6 | 6 | 3 | 0 | 0 | 0 | 380 |
| L2730 | 6 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 5 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 26% | 3.3 | 2.6 | 2.8 | 1.2 | 0.1 | 0.0 | 0.0 | 334.6 |
| **Average** | | | Opponent | 15% | 2.5 | 2.4 | 2.7 | 1.8 | 0.5 | 0.0 | 0.0 | 145.9 |

### KPIs: fw-off-db7ca9c-p1

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 176) | 0% (0 of 181) | 0% (0 of 357) |
| Winner chose to follow up after the loser gave ground |  | 95% (83 of 87); on the table 97% | 95% (58 of 61); on the table 97% | 95% (141 of 148); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 94% (16 of 17); on the table 94% | 77% (10 of 13); on the table 85% | 87% (26 of 30); on the table 90% |
| Winner chose to pursue after the loser fled |  | 86% (19 of 22); on the table 91% | 82% (28 of 34); on the table 88% | 84% (47 of 56); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 94% (118 of 126); on the table 95% | 89% (96 of 108); on the table 93% | 91% (214 of 234); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 25% (83 of 330) | 27% (57 of 210) | 26% (140 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 37% (83 of 227) | 36% (51 of 141) | 36% (134 of 368) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 35% (24816 of 71484) | 35% (25390 of 71889) | 35% (50206 of 143373) |
|   infantry points that never fought | lower | 45% (7638 of 16863) | 52% (6943 of 13348) | 48% (14581 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (157 of 279) | 61% (181 of 295) | 59% (338 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.8 uses a game | 70% (14 of 20); 1.2 uses a game | 81% (34 of 42); 1.5 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.6 uses a game | 38% (3 of 8); 0.2 uses a game | 62% (15 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 50% (6 of 12); 0.2 uses a game | 52% (16 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30521 of 59666) | 55% (34590 of 62699) | 53% (65111 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.5 (36%) | 1.3 (30%) | 3.8 (34%) |
| MARCHED: its unit marched | 1.0 (15%) | 0.6 (14%) | 1.6 (14%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.2 (6%) | 0.7 (6%) |
| IN COMBAT: engaged in combat | 1.7 (25%) | 0.8 (18%) | 2.4 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.6 (8%) | 1.0 (24%) | 1.6 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (9%) | 0.0 (0%) | 0.6 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.3 | 1.3 | 3.9 | 0.3 | 2.3 |
| not cast | 3.7 | 3.0 | 3.3 | 11.1 | 2.1 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.9 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (31%) | 0.2 (8%) | 3.8 (34%) | 0.6 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (14%) | 0.3 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.3 (9%) | 0.4 (12%) | 2.4 (22%) | 0.8 (38%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.3 (11%) | 0.4 (13%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.8 (20%) | 0.4 (14%) | 0.4 (12%) | 1.6 (14%) | 0.2 (8%) | 3.6 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.4 (12%) | 0.0 (0%) | 0.6 (5%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (10%) | 0.1 (3%) | 0.1 (1%) | 0.2 (8%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (63%) | 0.3 (9%) | 1.7 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.4 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 62% (20 of 32) | 71% (10 of 14) | 65% (30 of 46) |
| the unit moved after it | 55% (11 of 20) | 60% (6 of 10) | 57% (17 of 30) |
| it charged on its next turn | 0% (0 of 20) | 0% (0 of 10) | 0% (0 of 30) |
| the enemy charged it first | 10% (2 of 20) | 0% (0 of 10) | 7% (2 of 30) |
| it fought by the end of its next turn | 15% (3 of 20) | 0% (0 of 10) | 10% (3 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (5 of 20) | 20% (2 of 10) | 23% (7 of 30) |
| none of these (no charge, no fight, no charge escaped) | 60% (12 of 20) | 80% (8 of 10) | 67% (20 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (557 of 902) | 55% (325 of 586) | 59% (882 of 1488) |
|   cavalry | 45% (37 of 83) | 61% (75 of 123) | 54% (112 of 206) |
|   character | 49% (56 of 115) | 25% (25 of 100) | 38% (81 of 215) |
|   chariot | 41% (37 of 91) | 79% (26 of 33) | 51% (63 of 124) |
|   infantry | 60% (175 of 294) | 58% (142 of 244) | 59% (317 of 538) |
|   monster | 43% (15 of 35) | 50% (10 of 20) | 45% (25 of 55) |
|   war machine | 83% (237 of 284) | 71% (47 of 66) | 81% (284 of 350) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (27%) | 1.7 (23%) | 4.3 (25%) |
| CHARGED: it charged | 1.4 (14%) | 1.4 (19%) | 2.8 (17%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (8%) | 0.8 (11%) | 1.6 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.4 (14%) | 1.1 (16%) | 2.5 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.5 (7%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (20%) | 1.0 (14%) | 2.9 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.5 (7%) | 0.8 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 1.3 | 82% | 5.4 pts | 26 pts |
| character | 2.6 | 1.1 | 72% | 7.5 pts | 19 pts |
| chariot | 1.8 | 1.0 | 71% | 14.1 pts | 25 pts |
| infantry | 12.4 | 4.7 | 73% | 8.6 pts | 107 pts |
| monster | 0.8 | 0.2 | 86% | 7.6 pts | 6 pts |
| war machine | 7.9 | 6.4 | 62% | 24.2 pts | 191 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 5.8 | 5.3 |
| Charges that made contact a game | 3.4 | 3.9 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.23 declared, 1.09 contact (22 units) | 0.79 declared, 0.57 contact (14 units) | 1.06 declared, 0.89 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.17 declared, 0.83 contact (6 units) | 1.38 declared, 1.25 contact (8 units) | 1.29 declared, 1.07 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.37 contact (256 units) | 0.67 declared, 0.43 contact (281 units) | 0.60 declared, 0.40 contact (537 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (31 of 70) | 57% (12 of 21) | 38% (3 of 8) | 46% (46 of 99) |
| Character in a unit | 82% (33 of 40) | 77% (20 of 26) | 0% (0 of 3) | 77% (53 of 69) |
| Character on its own | 81% (38 of 47) | 56% (19 of 34) | 32% (20 of 63) | 53% (77 of 144) |
| Chariot | 88% (14 of 16) | 60% (6 of 10) | - | 77% (20 of 26) |
| Infantry | 60% (53 of 89) | 44% (16 of 36) | 0% (0 of 2) | 54% (69 of 127) |
| Monster | 56% (18 of 32) | 100% (10 of 10) | - | 67% (28 of 42) |
| Monstrous | 91% (10 of 11) | 57% (8 of 14) | - | 72% (18 of 25) |
| War Machines | 63% (26 of 41) | 100% (1 of 1) | - | 64% (27 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 93% (13 of 14); on the table 93% | 41% (56 of 138) | 44% | 58% (19 of 33) | 100% (9 of 9); 6.0 uses a game | 100% (3 of 3); 1.2 uses a game | 67% (6 of 9); 1.0 uses a game |
| Chaos Dwarfs | 3 | 91% (10 of 11); on the table 91% | 17% (4 of 24) | 47% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 75% (6 of 8); on the table 75% | - | 56% | 78% (32 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (8 of 10); on the table 90% | 39% (14 of 36) | 50% | 55% (35 of 64) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 96% (25 of 26); on the table 96% | 11% (12 of 108) | 33% | 45% (20 of 44) | 83% (10 of 12); 7.0 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 95% (20 of 21); on the table 95% | 17% (5 of 30) | 24% | 41% (20 of 49) | 80% (4 of 5); 1.7 uses a game | 56% (10 of 18); 3.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 32% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (7 of 7); on the table 100% | - | 26% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (7 of 7); on the table 100% | 25% (3 of 12) | 49% | 81% (17 of 21) | 67% (2 of 3); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 91% (10 of 11); on the table 91% | 14% (5 of 36) | 11% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 100% (14 of 14); on the table 100% | 23% (7 of 30) | 32% | 76% (26 of 34) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Tomb Kings of Khemri | 6 | 85% (22 of 26); on the table 92% | 17% (2 of 12) | 21% | 27% (8 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 89% (33 of 37); on the table 92% | 33% (18 of 54) | 40% | 56% (28 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 90% (26 of 29); on the table 97% | 33% (10 of 30) | 28% | 65% (48 of 74) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (10 of 10); on the table 100% | 13% (4 of 30) | 28% | 70% (46 of 66) | 33% (2 of 6); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-off-db7ca9c-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (31) | 40% (27) | 42% (58) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.36 | 0.69 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.19 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.22 | 0.28 | 0.50 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.47 | 0.53 | 2.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.72 | 0.61 | 1.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.97 | 6.53 | 12.50 |

### Quality by phase: fw-off-db7ca9c-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 50% (76 of 151) | 44% (72 of 165) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (163 of 336) | 64% (84 of 131) |
| Strategy | Close-in objectives charged next turn | 13% (18 of 140) | 13% (26 of 198) |
| Strategy | Support requests answered (helper made contact too) | 50% (6 of 12) | 55% (16 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 71% (5 of 7) |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (8 of 14) | 73% (8 of 11) |
| Strategy | Joined characters whose unit fought | 48% (24 of 50) | 45% (20 of 44) |
| Strategy | Lone characters that fought | 77% (74 of 96) | 79% (73 of 92) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 334.6 | 145.9 |
| Movement | Fights charged into per game | 3.1 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 93, net +126 | 15 of 98, net +65 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 93, net +4 | 17 of 98, net +170 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 17 of 93, net +133 | 5 of 98, net +123 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 of 93, net +89 | 35 of 98, net +174 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (172 of 354) | 47% (147 of 314) |
| Shooting | Points destroyed by shooting units | 67.6 | 21.8 |
| Shooting | War machine shots | 6.6 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (126 of 237) | 34% (16 of 47) |
| Shooting | Points destroyed by war machines | 88.1 | 18.2 |
| Magic | Magic missiles cast | 1.6 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (15 of 57) | 35% (12 of 34) |
| Magic | Wounds caused by magic missiles | 4.0 | 1.2 |
| Magic | Wounds caused by other spells | 1.9 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 61.6 | 26.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.4 / 1.0 / 0.1 | 1.5 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 412.6 | 390.8 |
| Combat | Points run down | 91.9 | 159.7 |
| Combat | Net points per charged fight, damage counted | +82 | +126 |
| Combat | Net per 100 charger points, damage counted | +27.5 | +43.6 |
| Combat | First round won (charged fights) | 69% | 54% |
| Combat | Net points per charged fight | +85 | +128 |
| Combat | Net points per supported fight / lone fight | +188 / +73 | +196 / +112 |
| Combat | Charged fights on a top-3 enemy unit | 41 of 112 | 53 of 115 |
| Game | Points lost | 769.4 | 809.7 |
| Game | VP from objectives | 674.4 | 550.3 |
| Game | Lone holders (player turns) | 3.3 | 2.5 |

- Mine won / drew / lost: 17 / 5 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) +167 VP
- The side that went first won 15 of 31 games with a winner
- Points traded per game (both sides' losses): 1579
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-off-db7ca9c-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 3.5 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 11.8 | 0.2 | +0.0 | 0.0 | 3.6 |
| BACKUP TARGETS | 0.8 | +7.1 | 0.0 | 1.8 | 1.0 | +9.4 | 0.0 | 23.9 |
| BEST OVERALL | 0.2 | +16.0 | 0.0 | 4.9 | 0.3 | +9.3 | 0.0 | 6.3 |
| BEST PREY | 3.8 | +296.1 | 130.9 | 118.2 | 5.2 | +352.2 | 248.9 | 132.4 |
| BEST PRIZE | 0.1 | -2.4 | 5.1 | 0.0 | 0.0 | +2.8 | 6.3 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | -0.4 | 0.0 | 13.3 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 14.4 | 0.0 | 0.1 | +0.0 | 3.1 | 0.0 |
| BLOCKED WHEEL | 0.4 | +10.0 | 0.0 | 14.2 | 0.2 | -3.5 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +1.7 | 4.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 8.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 156.9 | 16.7 | 0.1 | +0.0 | 18.4 | 5.3 |
| CANNON PLANNED TARGET | 5.2 | +164.1 | 416.8 | 90.1 | 1.0 | +27.8 | 95.7 | 19.4 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 9.7 | 6.5 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -1.0 | 5.1 | 2.4 | 0.2 | -2.4 | 23.8 | 16.6 |
| CAST JOB | 0.6 | +20.0 | 52.3 | 32.0 | 0.2 | +3.8 | 0.0 | 6.2 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.8 | +97.1 | 60.8 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 15.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.5 | 7.1 | 8.4 | 0.2 | -0.5 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 5.1 | 0.0 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.5 | -24.5 | 13.7 | 0.0 | 0.7 | -40.0 | 30.9 | 30.5 |
| CHARIOT NO STATIC JOB | 0.4 | +0.0 | 11.2 | 11.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARIOT WIZARD CAREFUL | 0.2 | -0.6 | 6.5 | 0.0 | 0.0 | -1.3 | 5.2 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 3.5 | 0.0 | 0.2 | +0.0 | 18.9 | 0.9 |
| COMBAT PIVOT | 0.6 | +0.0 | 40.6 | 31.8 | 0.5 | +0.0 | 18.8 | 36.4 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +46.0 | 10.7 | 0.0 | 0.2 | +51.0 | 0.0 | 30.4 |
| COUNTER-CHARGE COVER | 7.4 | +543.0 | 0.0 | 180.7 | 6.5 | +529.4 | 0.0 | 169.9 |
| EDGE GIVE GROUND | 0.1 | +4.4 | 11.0 | 0.0 | 0.1 | +7.0 | 29.6 | 16.6 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +2.6 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.5 | +104.0 | 0.0 | 53.2 | 0.5 | +40.5 | 0.0 | 7.0 |
| FALLBACK BY WORTH | 5.7 | +96.9 | 0.0 | 64.8 | 7.6 | +139.3 | 0.0 | 94.2 |
| FIGHT LIFT | 0.1 | +1.4 | 7.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.6 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 137.6 | 5.8 | +0.0 | 0.0 | 170.0 |
| FOCUS FIRE | - | - | - | - | 0.1 | +0.9 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +164.9 | 0.0 | 52.4 | 1.2 | +223.6 | 0.0 | 79.4 |
| FRIENDS SHOTS CHECKED | 0.3 | +19.0 | 0.0 | 5.8 | 0.2 | +9.1 | 0.0 | 7.3 |
| GIVES UP | 1.3 | -44.7 | 111.9 | 66.0 | 1.4 | -41.3 | 153.9 | 79.3 |
| GIVES UP ITS SCREEN | 0.7 | -7.0 | 67.4 | 6.5 | 1.0 | -25.2 | 61.8 | 9.3 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 12.5 | 3.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 10.9 | 0.0 | 0.4 | +0.0 | 49.1 | 2.6 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +4.9 | 20.4 | 9.3 |
| HUNT IN PAIRS | 0.4 | +28.4 | 0.0 | 5.7 | 0.6 | +24.3 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.0 | 6.5 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +6.0 | 13.9 | 3.2 |
| HUNT THE GUNS | 0.0 | +11.2 | 0.0 | 1.7 | 0.2 | +85.9 | 52.7 | 12.6 |
| JOINT CHARGE PLAN | 0.0 | +0.2 | 0.0 | 0.0 | 0.2 | +15.9 | 63.4 | 3.2 |
| KEEP FALLS | 0.1 | +0.1 | 0.0 | 6.1 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.2 | +2.2 | 2.7 | 10.0 | 0.3 | +1.8 | 0.0 | 5.8 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 139.4 | 21.4 | 2.2 | +65.0 | 188.8 | 107.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +62.7 | 105.7 | 29.4 | 1.8 | +71.6 | 101.5 | 34.9 |
| KILLS COUNT NEXT TURN | 7.2 | +288.1 | 369.8 | 156.2 | 10.8 | +464.5 | 495.3 | 275.8 |
| LONE CHARACTER SAFE SPOT | 0.2 | +10.7 | 0.0 | 2.4 | 0.6 | +17.9 | 10.1 | 26.5 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 2.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +28.7 | 18.9 | 1.2 | 0.8 | +65.5 | 60.9 | 44.4 |
| MANOEUVRE | 0.1 | +7.7 | 0.0 | 0.0 | 0.2 | +3.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.2 | 0.0 | 5.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +16.0 | 0.0 | 4.5 | 0.7 | +26.4 | 0.0 | 0.0 |
| MARCH ODDS | 0.8 | +69.9 | 41.0 | 17.8 | 0.6 | +43.5 | 8.3 | 6.2 |
| MARCH OVER CASTS | 0.6 | +57.5 | 0.0 | 5.5 | 0.2 | +20.9 | 0.0 | 3.2 |
| MAX FOR POSITIONING | 4.7 | +198.0 | 0.0 | 78.8 | 5.5 | +189.2 | 0.0 | 117.2 |
| MISSILES IN THE MOVE | 3.6 | +152.7 | 0.0 | 58.1 | 3.3 | +44.5 | 0.0 | 40.8 |
| MISSILES NEXT TURN | 4.5 | +114.8 | 0.0 | 75.1 | 3.7 | +29.8 | 0.0 | 50.1 |
| MODEL FACING | 0.1 | +21.7 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 25.0 | 0.0 |
| MOVE AND CAST | 0.2 | +20.6 | 0.0 | 4.5 | 0.1 | +4.7 | 0.0 | 6.2 |
| MOVE SPELL IN RANGE | 0.1 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -67.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 2.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +5.4 | 0.0 | 0.0 | 0.1 | +5.0 | 9.6 | 0.0 |
| NOT NEEDED | 0.2 | -10.6 | 24.1 | 5.2 | 0.2 | -10.6 | 28.0 | 8.2 |
| NOT TURNED | 6.0 | +111.6 | 0.0 | 149.8 | 6.5 | +88.1 | 0.0 | 161.9 |
| NOT WORTH A CAST | 1.2 | -0.9 | 0.0 | 7.6 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 17.1 | -845.9 | 24.2 | 302.8 | 18.0 | -1004.5 | 33.8 | 347.5 |
| OPENS A LANE | 0.2 | +1.1 | 7.4 | 1.8 | 0.0 | +0.1 | 0.0 | 0.0 |
| OPENS UP | 0.4 | +39.2 | 15.7 | 10.2 | 0.2 | +18.4 | 5.1 | 7.9 |
| OVERRUNS AWAY | 0.8 | +15.2 | 52.6 | 24.6 | 0.6 | +12.1 | 41.2 | 12.7 |
| PATHS CROSS | 1.9 | +162.7 | 0.0 | 38.7 | 2.7 | +186.0 | 0.0 | 59.1 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.3 | 0.0 | 10.6 | 0.1 | -2.7 | 0.0 | 4.0 |
| PLAN RESULT | 36.8 | +1382.6 | 1244.5 | 1008.7 | 37.9 | +1163.2 | 1173.9 | 1096.9 |
| PURSUES BIG PREY | 0.1 | -4.4 | 0.0 | 0.0 | 0.1 | -1.6 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.7 | 0.0 | 0.0 | 0.1 | +5.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.9 | +136.7 | 0.0 | 25.3 | 5.3 | +348.3 | 0.0 | 93.4 |
| REDIRECT WEIGHED | 0.3 | +5.5 | 2.5 | 0.0 | 0.2 | +4.8 | 2.4 | 0.0 |
| RESTRAINS TO SHOOT | 0.2 | +7.2 | 0.0 | 25.1 | 0.1 | +6.8 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +84.5 | 266.7 | 86.8 | 2.7 | +30.6 | 274.6 | 99.0 |
| SAFER THAN THE JOB | 0.7 | +46.6 | 0.0 | 13.4 | 0.6 | +26.9 | 0.0 | 24.8 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 1.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 1.9 |
| SEARCH SPOT | 1.5 | +67.6 | 0.0 | 26.2 | 2.0 | +119.3 | 0.0 | 41.2 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.0 | 13.9 | 3.2 |
| SELF MOVE SPELL | 0.3 | +14.7 | 0.0 | 18.1 | 0.1 | +1.6 | 0.0 | 9.1 |
| SET UP TOGETHER | 0.6 | +30.0 | 25.5 | 1.2 | 1.8 | +135.0 | 126.3 | 50.4 |
| SET-UP ANY TARGET | 0.3 | +24.7 | 8.4 | 0.0 | 0.1 | +9.8 | 0.0 | 7.6 |
| SET-UP MISSED | 0.0 | +1.5 | 8.4 | 0.0 | 0.1 | +4.5 | 0.0 | 15.2 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.8 | +0.0 | 208.4 | 13.4 | 0.2 | +0.0 | 14.8 | 5.3 |
| SHOTS IN THE MOVE | 13.9 | +601.4 | 0.0 | 213.4 | 8.1 | +182.8 | 0.0 | 170.9 |
| SPELL CATCH ODDS | 0.1 | -0.2 | 0.0 | 0.0 | 0.0 | -3.8 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +32.8 | 10.7 | 0.0 | 0.1 | +41.1 | 0.0 | 7.6 |
| SPELL WORTH | 1.1 | +20.5 | 83.1 | 58.1 | 1.7 | +28.9 | 30.2 | 36.7 |
| STANDS TO CAST | 0.1 | +3.2 | 1.2 | 20.2 | 0.0 | +1.3 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.3 | 0.0 | 1.7 | 0.1 | +0.9 | 32.4 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +22.8 | 0.0 | 15.2 | 0.4 | +17.3 | 0.0 | 3.2 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 9.9 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 1.7 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -13.4 | 13.2 | 9.6 | 0.3 | -15.4 | 22.4 | 13.7 |
| SURE REACH TOGETHER | 0.6 | -1.7 | 12.5 | 8.1 | 0.4 | +7.1 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.5 | +14.1 | 0.0 | 26.6 | 0.2 | +0.5 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -35.2 | 35.9 | 15.4 | 0.4 | -23.2 | 30.7 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +1.7 | 13.1 | 1.2 | 0.2 | +0.4 | 0.0 | 13.5 |
| WEARS DOWN | 1.1 | +83.1 | 105.5 | 33.1 | 1.4 | +55.7 | 187.1 | 58.5 |
| WHO HITS BACK | 0.2 | +18.2 | 0.0 | 21.0 | 0.2 | +26.3 | 0.0 | 8.6 |
| WHOLE FIGHT | 0.4 | +41.8 | 70.5 | 6.9 | 0.4 | +18.9 | 65.6 | 5.9 |
| WHOLE FIGHT GAIN | 0.3 | +29.1 | 40.1 | 0.0 | 0.6 | +41.6 | 63.4 | 8.7 |

### Rule changes: fw-off-db7ca9c-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1265 | 1265 | 1265 | 35.14 | -66614 | -52.7 |
| KILLS COUNT NEXT TURN | 650 | 641 | 200 | 5.56 | +8296 | +41.5 |
| PATHS CROSS | 167 | 167 | 167 | 4.64 | +12553 | +75.2 |
| BEST PREY | 324 | 314 | 143 | 3.97 | +6957 | +48.7 |
| FALLBACK BY WORTH | 478 | 478 | 128 | 3.56 | +8502 | +66.4 |
| COUNTER-CHARGE COVER | 500 | 249 | 123 | 3.42 | +6844 | +55.6 |
| SEARCH SPOT | 126 | 126 | 123 | 3.42 | +6766 | +55.0 |
| FOLLOW UP WEIGHED | 92 | 92 | 92 | 2.56 | +13983 | +152.0 |
| FACES THE THREAT | 72 | 72 | 72 | 2.00 | +5200 | +72.2 |
| ARTILLERY RE-ROLL WEIGHED | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| MAX FOR POSITIONING | 366 | 194 | 57 | 1.58 | +526 | +9.2 |
| CANNON PLANNED TARGET | 223 | 223 | 56 | 1.56 | -823 | -14.7 |
| SAFER THAN THE JOB | 48 | 48 | 48 | 1.33 | +2646 | +55.1 |
| ADVANCE LANE KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| SET UP TOGETHER | 83 | 74 | 46 | 1.28 | +2275 | +49.5 |
| MARCH ODDS | 49 | 48 | 45 | 1.25 | +1241 | +27.6 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| SHOTS IN THE MOVE | 793 | 494 | 43 | 1.19 | +1891 | +44.0 |
| CHARGE NOW WEIGHED | 42 | 42 | 42 | 1.17 | +1351 | +32.2 |
| RISK BY ARC | 203 | 191 | 42 | 1.17 | +1407 | +33.5 |
| MARCH CHECK | 41 | 40 | 40 | 1.11 | +1953 | +48.8 |
| COMBAT PIVOT | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| REDIRECT COUNTER | 297 | 110 | 39 | 1.08 | +2753 | +70.6 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SHOT REPLANNED | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| KEEPS ITS TARGET | 131 | 125 | 31 | 0.86 | +519 | +16.7 |
| KILLS COUNT | 128 | 123 | 31 | 0.86 | +1171 | +37.8 |
| STOPS SHORT OF THE FLANK | 30 | 30 | 30 | 0.83 | +1445 | +48.2 |
| THROUGH LINE OF FIRE | 28 | 28 | 28 | 0.78 | +523 | +18.7 |
| MISSILES IN THE MOVE | 247 | 146 | 27 | 0.75 | +583 | +21.6 |
| CASTING BLOCK | 31 | 30 | 26 | 0.72 | +1683 | +64.7 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| BLOCKED WHEEL | 24 | 24 | 24 | 0.67 | +236 | +9.8 |
| SHOOTERS IN TWO RANKS | 23 | 23 | 23 | 0.64 | +53 | +2.3 |
| CAST JOB | 31 | 29 | 22 | 0.61 | +328 | +14.9 |
| MAKE SURE TOGETHER | 47 | 30 | 22 | 0.61 | +868 | +39.4 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +940 | +44.8 |
| BEST OVERALL | 20 | 20 | 20 | 0.56 | +913 | +45.7 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1012 | +56.2 |
| SURE CHARGE BEATS ADVANCE | 17 | 17 | 17 | 0.47 | -1034 | -60.8 |
| WEARS DOWN | 90 | 83 | 17 | 0.47 | +760 | +44.7 |
| OPENS UP | 21 | 19 | 16 | 0.44 | +782 | +48.8 |
| CHARIOT NO STATIC JOB | 18 | 18 | 15 | 0.42 | -2493 | -166.2 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +1134 | +75.6 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -37 | -2.9 |
| WHOLE FIGHT | 32 | 30 | 12 | 0.33 | +1245 | +103.7 |
| MANOEUVRE | 11 | 11 | 11 | 0.31 | +398 | +36.2 |
| RESTRAINS TO SHOOT | 11 | 11 | 11 | 0.31 | +504 | +45.8 |
| MOVE AND CAST | 10 | 10 | 10 | 0.28 | +909 | +90.9 |
| WHOLE FIGHT GAIN | 31 | 27 | 10 | 0.28 | +507 | +50.7 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -146 | -16.2 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| STUCK PIVOT | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SURE REACH TOGETHER | 35 | 30 | 8 | 0.22 | +199 | +24.8 |
| MISSILES NEXT TURN | 294 | 160 | 7 | 0.19 | +126 | +18.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| OVERRUNS AWAY | 49 | 44 | 7 | 0.19 | +272 | +38.8 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.17 | -18 | -3.0 |
| HUNT IN PAIRS | 33 | 18 | 6 | 0.17 | +428 | +71.3 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -216 | -36.0 |
| BACKUP TARGETS | 63 | 20 | 4 | 0.11 | +12 | +3.0 |
| GIVES UP | 98 | 91 | 4 | 0.11 | +55 | +13.8 |
| NEEDED THERE | 6 | 5 | 4 | 0.11 | +0 | +0.0 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -182 | -60.7 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +103 | +34.4 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +32 | +10.6 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +22 | +7.2 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +780 | +259.8 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 3 | 0.08 | +173 | +57.7 |
| STANDS TO CAST | 4 | 3 | 3 | 0.08 | -15 | -5.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 8 | 8 | 2 | 0.06 | -124 | -61.9 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +23 | +11.3 |
| HUNT ADVANCE | 4 | 4 | 2 | 0.06 | +107 | +53.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +61 | +60.9 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -6 | -5.9 |
| EDGE GIVE GROUND | 8 | 8 | 1 | 0.03 | +14 | +13.9 |
| OPENS A LANE | 9 | 6 | 1 | 0.03 | +8 | +8.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +64 | +64.4 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | -1 | -1.3 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +143 | +142.6 |
| STOPS | 4 | 4 | 1 | 0.03 | +23 | +23.3 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +32 | +31.7 |
| TURN WORTH | 31 | 31 | 1 | 0.03 | +3 | +3.4 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 28 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 419 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 61 | 58 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 20 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 10 | 10 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 18 | 16 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 29 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 11 | 11 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 9 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 450 | 450 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 51 | not checked | - | - | - | - |
| PLAN RESULT | 2687 | trace | - | - | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 14 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 101 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 16 | 12 | 0 | 0.00 | - | - |

### Off best figure: fw-off-db7ca9c-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.47 | 14.69 | 56.2 |
| FALLBACK | gate | 0.97 | 1.39 | 48.0 |
| RULE SWITCHED OFF | gate | 0.81 | 0.75 | 11.2 |
| TURN GATE | gate | 0.39 | 0.44 | 31.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.31 | 60.8 |
| CHARIOT NO STATIC JOB | rule | 0.36 | 0.06 | 166.2 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.22 | 45.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.28 | 86.4 |
| AFTERMATH BAND | gate | 0.11 | 0.22 | 2.2 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.06 | 75.6 |
| PATHS CROSS | rule | 0.08 | 0.22 | 40.1 |
| FIGHT ORDER BAND | gate | 0.17 | 0.08 | 2.0 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.11 | 16.2 |
| CHAFF PASSED | rule | 0.08 | 0.14 | 4.6 |
| SUPPORT REQUEST | gate | 0.08 | 0.14 | 92.0 |
| PURSUES BIG PREY | rule | 0.06 | 0.11 | 36.0 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 47.7 |
| MARCH ODDS | rule | 0.03 | 0.08 | 13.5 |
| THROUGH LINE OF FIRE | rule | 0.08 | 0.03 | 42.2 |
| BEST PRIZE | rule | 0.06 | 0.03 | 60.7 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.03 | 7.5 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 7.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 36.6 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 61.9 |
| CATCH ODDS | rule | - | 0.03 | 5.9 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 3.3 |
| PURSUES ON | rule | - | 0.03 | 1.3 |
| STANDS TO CAST | rule | - | 0.03 | 27.9 |

### Plans: fw-off-db7ca9c-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.5 | 18% | 469 | 302 | 64% |
| Mine | charge | 3.4 | 62% | 417 | 283 | 68% |
| Mine | close in | 3.9 | 28% | 238 | 144 | 61% |
| Mine | hold | 4.9 | 51% | 297 | 0 | 0% |
| Mine | join | 0.6 | 95% | 15 | 0 | 0% |
| Mine | shoot | 8.1 | 62% | 343 | 653 | 191% |
| Mine | support | 4.4 | 90% | 247 | 0 | 0% |
| Opponent | advance | 13.4 | 19% | 653 | 433 | 66% |
| Opponent | charge | 4.1 | 67% | 412 | 357 | 87% |
| Opponent | close in | 5.3 | 28% | 450 | 189 | 42% |
| Opponent | hold | 3.7 | 47% | 239 | 0 | 0% |
| Opponent | join | 1.1 | 88% | 52 | 0 | 0% |
| Opponent | shoot | 3.3 | 65% | 74 | 185 | 249% |
| Opponent | support | 6.9 | 92% | 336 | 0 | 0% |

### Packages: hunt the guns, fw-off-db7ca9c-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 404 | 0 | 0% | 16 |
| Opponent | 0.2 | 7 | 3 | 25% | 25% | 0% | 2.0 | 456 | 54 | 25% | 90 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 404 | 0 | 0% | 118 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 157 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 158 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 102 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 269 | 217 | 100% | 9 |
| Warriors of Chaos | 0.6 | 5 | 3 | 0% | 0% | 0% | - | 614 | 0 | 0% | 74 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 18 |

### Battle groups: fw-off-db7ca9c-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.4 | 27% | 56% | 10% | 57% | 28% | 17% | 11% | 45% | 0% |
| Mine | REDIRECT COUNTER | 2.9 | 29% | 61% | 26% | 25% | 13% | 0% | 9% | 78% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.5 | 20% | 57% | 7% | 67% | 37% | 16% | 7% | 40% | 0% |
| Opponent | REDIRECT COUNTER | 5.3 | 27% | 75% | 20% | 30% | 15% | 2% | 5% | 73% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-off-db7ca9c-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 27 (3) | 27 | 0 | 19 | 67% | 6.0 | 0 (1) | 49 (2) | - | 73 (1) | 0 (2) |
| Mine | Chaff | 45 | 46 (45) | 9 | 37 | 55 | 47% | 2.2 | 44 (16) | 46 (8) | 47 (21) | 49 (30) | 40 (15) |
| Mine | Character | 124 | 50 (124) | 50 | 0 | 37 | 15% | 2.4 | 67 (36) | 55 (58) | 15 (11) | 65 (61) | 44 (44) |
| Mine | Clean-up | 20 | 66 (20) | 34 | 32 | 34 | 35% | 3.3 | 36 (10) | 116 (8) | 0 (2) | 81 (11) | 47 (9) |
| Mine | Fast | 1 | 67 (1) | 67 | 0 | 0 | 0% | 3.0 | - | 67 (1) | - | - | 67 (1) |
| Mine | Fast Hammer | 40 | 45 (40) | 38 | 7 | 53 | 15% | 2.7 | 41 (21) | 96 (6) | 29 (13) | 44 (30) | 49 (10) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 2.4 | - | 0 (5) | - | 0 (1) | 0 (4) |
| Mine | Hammer | 56 | 43 (56) | 27 | 16 | 49 | 16% | 2.3 | 59 (10) | 44 (36) | 19 (10) | 46 (37) | 36 (19) |
| Mine | Holder | 26 | 100 (26) | 9 | 91 | 22 | 46% | 3.6 | 101 (8) | 87 (14) | 155 (4) | 154 (13) | 51 (13) |
| Mine | Shooter | 45 | 120 (45) | 52 | 68 | 57 | 0% | 1.9 | 90 (7) | 108 (31) | 204 (7) | 132 (26) | 102 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 20% | 3.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 56 | 49 (56) | 49 | 0 | 40 | 4% | 1.3 | 86 (13) | 33 (38) | 79 (5) | 47 (10) | 50 (46) |
| Mine | Wizard | 22 | 22 (22) | 22 | 0 | 43 | 36% | 2.4 | 55 (7) | 0 (5) | 7 (3) | 94 (3) | 2 (12) |
| Opponent | Blocker | 1 | 1803 (1) | 1526 | 278 | 0 | 0% | 6.0 | 1803 (1) | - | - | 1803 (1) | - |
| Opponent | Chaff | 81 | 32 (81) | 13 | 19 | 55 | 47% | 2.3 | 42 (29) | 55 (21) | 7 (31) | 39 (56) | 16 (25) |
| Opponent | Character | 113 | 58 (113) | 58 | 0 | 42 | 20% | 2.3 | 76 (42) | 58 (52) | 18 (6) | 66 (68) | 60 (32) |
| Opponent | Clean-up | 12 | 61 (12) | 53 | 8 | 34 | 8% | 2.5 | 62 (5) | 59 (7) | - | 79 (9) | 0 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 53 | 54 (53) | 33 | 21 | 43 | 30% | 3.2 | 37 (23) | 69 (15) | 67 (15) | 61 (38) | 37 (15) |
| Opponent | Fragile | 9 | 38 (9) | 38 | 0 | 59 | 22% | 2.0 | 0 (1) | 0 (2) | 69 (5) | 47 (7) | 0 (1) |
| Opponent | Hammer | 63 | 24 (63) | 18 | 6 | 55 | 22% | 2.8 | 14 (20) | 25 (38) | 54 (5) | 25 (37) | 22 (26) |
| Opponent | Holder | 35 | 53 (35) | 2 | 51 | 23 | 43% | 4.2 | 25 (8) | 81 (19) | 25 (7) | 90 (13) | 31 (21) |
| Opponent | Shooter | 31 | 51 (31) | 11 | 40 | 45 | 6% | 1.3 | 38 (7) | 66 (19) | 5 (5) | 49 (17) | 53 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 0% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 40 (13) | 40 | 0 | 44 | 8% | 1.7 | 0 (3) | 49 (7) | 54 (3) | 0 (2) | 47 (11) |
| Opponent | Wizard | 24 | 12 (24) | 12 | 0 | 26 | 12% | 2.0 | 0 (6) | 34 (8) | 0 (7) | 23 (11) | 0 (10) |

### Charged fights: fw-off-db7ca9c-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 152 | 229 | 1.8 | 1.1 | 127 | 0 | +127 | 1 of 9 | 8 of 9 | +77 | +134 |
| Mine | Chaos Dwarfs | 3 | 69 | 1011 | 5.3 | 1.1 | 190 | 19 | +170 | 12 of 16 | 11 of 16 | +355 | +158 |
| Mine | Dwarfen Mountain Holds | 4 | 440 | 10 | 1.2 | 1.0 | 8 | 90 | -81 | 2 of 5 | 2 of 5 | - | -81 |
| Mine | Empire of Man | 5 | 379 | 193 | 1.8 | 1.1 | 107 | 21 | +86 | 0 of 9 | 7 of 9 | +0 | +97 |
| Mine | Grand Cathay | 4 | 595 | 236 | 3.5 | 1.2 | 67 | 53 | +14 | 8 of 14 | 7 of 14 | +84 | -5 |
| Mine | High Elf Realms | 4 | 116 | 576 | 4.0 | 1.1 | 144 | 75 | +69 | 6 of 16 | 12 of 16 | +60 | +70 |
| Mine | Kingdom of Bretonnia | 1 | 75 | 45 | 2.0 | 1.0 | 22 | 0 | +22 | 0 of 2 | 1 of 2 | - | +22 |
| Mine | Lizardmen | 1 | 66 | 832 | 4.0 | 1.0 | 208 | 0 | +208 | 1 of 4 | 4 of 4 | - | +208 |
| Mine | Ogre Kingdoms | 1 | 0 | 66 | 2.0 | 1.0 | 33 | 0 | +33 | 0 of 2 | 1 of 2 | - | +33 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 265 | 6.0 | 1.0 | 44 | 54 | -10 | 3 of 6 | 4 of 6 | - | -10 |
| Mine | Skaven | 2 | 0 | 38 | 2.0 | 1.0 | 19 | 66 | -48 | 1 of 4 | 4 of 4 | - | -48 |
| Mine | Tomb Kings of Khemri | 2 | 106 | 1274 | 6.5 | 1.3 | 196 | 7 | +189 | 3 of 13 | 9 of 13 | +364 | +111 |
| Mine | Vampire Counts | 2 | 0 | 554 | 4.0 | 1.0 | 138 | 72 | +66 | 3 of 8 | 3 of 8 | - | +66 |
| Mine | Warriors of Chaos | 1 | 0 | 358 | 4.0 | 1.0 | 90 | 0 | +90 | 1 of 4 | 4 of 4 | - | +90 |
| **Mine** | all armies | 36 | 217 | 381 | 3.1 | 1.1 | 123 | 37 | +85 | 41 of 112 | 77 of 112 | +188 | +73 |
| Opponent | Beastmen Brayherds | 1 | 65 | 0 | 2.0 | 1.5 | 0 | 42 | -42 | 0 of 2 | 0 of 2 | +0 | -85 |
| Opponent | Dwarfen Mountain Holds | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 255 | 289 | 1.0 | 1.0 | 289 | 0 | +289 | 1 of 1 | 1 of 1 | - | +289 |
| Opponent | Grand Cathay | 1 | 460 | 1066 | 5.0 | 1.6 | 213 | 0 | +213 | 3 of 5 | 4 of 5 | +282 | +110 |
| Opponent | High Elf Realms | 2 | 222 | 1071 | 5.0 | 1.1 | 214 | 0 | +214 | 4 of 10 | 6 of 10 | +559 | +176 |
| Opponent | Lizardmen | 1 | 0 | 189 | 1.0 | 1.0 | 189 | 0 | +189 | 1 of 1 | 0 of 1 | - | +189 |
| Opponent | Ogre Kingdoms | 2 | 26 | 682 | 2.5 | 1.4 | 273 | 7 | +266 | 2 of 5 | 3 of 5 | +622 | +28 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 349 | 2.5 | 1.0 | 140 | 11 | +129 | 2 of 5 | 3 of 5 | - | +129 |
| Opponent | Skaven | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 8 | 1031 | 5.8 | 1.1 | 179 | 57 | +122 | 9 of 23 | 14 of 23 | +241 | +104 |
| Opponent | Vampire Counts | 6 | 83 | 594 | 4.7 | 1.4 | 127 | 23 | +104 | 11 of 28 | 14 of 28 | +59 | +123 |
| Opponent | Warriors of Chaos | 7 | 6 | 442 | 2.3 | 1.2 | 193 | 40 | +153 | 10 of 16 | 9 of 16 | +268 | +137 |
| Opponent | Wood Elf Realms | 6 | 40 | 296 | 3.2 | 1.1 | 93 | 44 | +50 | 10 of 19 | 8 of 19 | -30 | +59 |
| **Opponent** | all armies | 36 | 67 | 508 | 3.2 | 1.2 | 159 | 31 | +128 | 53 of 115 | 62 of 115 | +196 | +112 |

### Effective charges: fw-off-db7ca9c-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 0 | 1 (net +114) | 2 (net +102) | 1 (net +170) | 2 (net +216) | 3 | 17% (1 of 6) |
| Mine | Chaos Dwarfs | 16 | 2 (net +550) | 0 | 2 (net +0) | 1 (net +168) | 2 (net +178) | 6 (net +132) | 3 | 15% (2 of 13) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net -60) | 1 (net +41) | 0 | 3 (net -129) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 9 | 0 | 0 | 0 | 2 (net +129) | 1 (net +49) | 6 (net +78) | 0 | 0% (0 of 9) |
| Mine | Grand Cathay | 14 | 0 | 0 | 3 (net -80) | 3 (net +74) | 2 (net +56) | 4 (net +68) | 2 | 25% (3 of 12) |
| Mine | High Elf Realms | 16 | 1 (net -115) | 0 | 2 (net -12) | 4 (net +30) | 2 (net +152) | 5 (net +171) | 2 | 14% (2 of 14) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net +0) | 0 | 0 | 0 | 1 (net +45) | 0 | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +265) | 1 (net +0) | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 4 | 0% (0 of 2) |
| Mine | Skaven | 4 | 1 (net +0) | 0 | 1 (net -41) | 0 | 1 (net +0) | 1 (net -149) | 0 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 13 | 1 (net +599) | 0 | 3 (net +12) | 1 (net +125) | 4 (net +280) | 4 (net +144) | 0 | 23% (3 of 13) |
| Mine | Vampire Counts | 8 | 2 (net -290) | 2 (net +0) | 0 | 2 (net +326) | 0 | 1 (net +170) | 1 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 1 (net +0) | 1 (net +107) | 1 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Beastmen Brayherds | 2 | 0 | 0 | 1 (net -85) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +289) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 5 | 1 (net +613) | 0 | 1 (net +105) | 2 (net +58) | 1 (net +233) | 0 | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 10 | 2 (net +0) | 1 (net +165) | 0 | 3 (net +162) | 0 | 4 (net +372) | 0 | 0% (0 of 10) |
| Opponent | Lizardmen | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +189) | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 5 | 0 | 0 | 2 (net +639) | 1 (net -34) | 0 | 1 (net +85) | 1 | 50% (2 of 4) |
| Opponent | Orc & Goblin Tribes | 5 | 1 (net +219) | 0 | 1 (net +0) | 0 | 0 | 1 (net +177) | 2 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 23 | 2 (net +16) | 1 (net +301) | 3 (net +180) | 3 (net +55) | 0 | 10 (net +154) | 4 | 16% (3 of 19) |
| Opponent | Vampire Counts | 28 | 4 (net +4) | 0 | 6 (net +154) | 7 (net +47) | 3 (net +106) | 6 (net +64) | 2 | 23% (6 of 26) |
| Opponent | Warriors of Chaos | 16 | 3 (net +70) | 1 (net +663) | 1 (net +122) | 3 (net +71) | 0 | 6 (net +204) | 2 | 7% (1 of 14) |
| Opponent | Wood Elf Realms | 19 | 2 (net -62) | 1 (net +70) | 2 (net +0) | 3 (net -200) | 1 (net +65) | 4 (net +182) | 6 | 15% (2 of 13) |

### Charged fights, damage counted: fw-off-db7ca9c-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 244 | 278 | +126 | 248 | 151 | +97 | +39.6 |
| Mine | 50-54% | 2 | 220 | 228 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 14 | 236 | 182 | +4 | 65 | 52 | +13 | +5.6 |
| Mine | 76-89% | 18 | 222 | 174 | +99 | 134 | 35 | +99 | +44.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 245 | 169 | +89 | 151 | 61 | +90 | +36.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 17 | 462 | 105 | +133 | 140 | 20 | +121 | +26.1 |
| Mine | No odds | 19 | 404 | 180 | +75 | 128 | 56 | +72 | +17.9 |
| Mine | All fights | 112 | 299 | 172 | +85 | 136 | 54 | +82 | +27.5 |
| Opponent | Long shot (under 50%) | 15 | 329 | 285 | +65 | 176 | 117 | +60 | +18.1 |
| Opponent | 50-54% | 4 | 232 | 216 | +300 | 300 | 13 | +287 | +123.8 |
| Opponent | Effective (55-75%) | 17 | 262 | 186 | +170 | 198 | 29 | +170 | +64.8 |
| Opponent | 76-89% | 22 | 266 | 184 | +31 | 99 | 61 | +39 | +14.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 292 | 196 | +174 | 214 | 50 | +164 | +56.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 529 | 142 | +123 | 149 | 19 | +130 | +24.6 |
| Opponent | No odds | 17 | 251 | 203 | +132 | 165 | 28 | +137 | +54.6 |
| Opponent | All fights | 115 | 290 | 203 | +128 | 178 | 52 | +126 | +43.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-off-db7ca9c-p1 | move | 465 | 103 (22%) | 77 (17%) | 55 (12%) | 307 (66%) |
| fw-off-db7ca9c-p1 | objective | 338 | 44 (13%) | 26 (8%) | 52 (15%) | 242 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

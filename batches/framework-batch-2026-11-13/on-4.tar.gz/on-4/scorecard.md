# Doctrine scorecard: fw-on-db7ca9c-p4

### Scorecard: fw-on-db7ca9c-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 14 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 4 | 4 | 3 | 3 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 8 | 2 | 1 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | 5 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 9 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 5 | 5 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 135 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 560 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 1 | 4 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 2 | 2 | 0 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 1 | 4 | 2 | 0 | 0 | 0 | 0 | 981 |
| L0624 | 6 | 1 | Opponent | no | 5 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 3 | 4 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 2 | 3 | 4 | 1 | 0 | 0 | 0 | 975 |
| L0819 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 1 | 0 | 0 | 330 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 492 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 6 | 2 | 5 | 1 | 3 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 2 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 5 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | 4 | 6 | 6 | 0 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 3 | 4 | 4 | 0 | 1 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 6 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | no | - | 5 | 0 | 2 | 2 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 196 |
| L1621 | 1 | 1 | Mine | no | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 367 |
| L1719 | 3 | 1 | Mine | yes | 7 | 6 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 3 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 126 |
| L2021 | 5 | 1 | Mine | yes | - | 6 | 0 | 2 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 6 | 2 | 5 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 0 | 9 | 0 | 0 | 0 | 585 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 3 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 6 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 4 | - | 1 | 1 | 0 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 6 | 6 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 39% | 2.3 | 3.4 | 2.4 | 1.2 | 0.2 | 0.0 | 0.0 | 258.6 |
| **Average** | | | Opponent | 39% | 2.3 | 2.6 | 3.4 | 2.1 | 0.3 | 0.0 | 0.0 | 92.2 |

### KPIs: fw-on-db7ca9c-p4

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 63% (113 of 179) | 18% (34 of 189) | 40% (147 of 368) |
| Winner chose to follow up after the loser gave ground |  | 94% (50 of 53); on the table 94% | 98% (54 of 55); on the table 100% | 96% (104 of 108); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 77% (10 of 13); on the table 85% | 77% (10 of 13); on the table 92% | 77% (20 of 26); on the table 88% |
| Winner chose to pursue after the loser fled |  | 71% (15 of 21); on the table 71% | 69% (36 of 52); on the table 69% | 70% (51 of 73); on the table 70% |
| Winner chose to follow up or pursue (all three) |  | 86% (75 of 87); on the table 87% | 83% (100 of 120); on the table 86% | 85% (175 of 207); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 28% (77 of 273) | 38% (62 of 165) | 32% (139 of 438) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (77 of 189) | 40% (50 of 125) | 40% (127 of 314) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (23 of 46) | 67% (54 of 81) | 61% (77 of 127) |
| Points that never fought | lower | 35% (23861 of 67942) | 35% (25457 of 71984) | 35% (49318 of 139926) |
|   infantry points that never fought | lower | 39% (6056 of 15347) | 57% (7914 of 13804) | 48% (13970 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (163 of 270) | 53% (149 of 280) | 57% (312 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.7 uses a game | 89% (8 of 9); 0.8 uses a game | 94% (29 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 44% (7 of 16); 0.4 uses a game | 60% (12 of 20); 0.4 uses a game | 53% (19 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 73% (11 of 15); 0.3 uses a game | 62% (21 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (32142 of 57750) | 44% (28047 of 63347) | 50% (60189 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (23%) | 0.8 (27%) | 2.1 (25%) |
| MARCHED: its unit marched | 1.6 (29%) | 0.8 (27%) | 2.3 (28%) |
| CHARGED: its unit charged | 0.1 (3%) | 0.2 (7%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.1 (20%) | 0.5 (18%) | 1.6 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (9%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.0 (18%) | 0.2 (9%) | 1.2 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.9 | 2.4 | 3.9 | 0.3 | 1.6 |
| not cast | 2.7 | 2.0 | 2.5 | 8.3 | 1.7 | 21.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (56%) | 0.2 (10%) | 2.1 (25%) | 0.4 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (28%) | 0.4 (26%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.0 (1%) | 0.6 (24%) | 1.6 (20%) | 0.3 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (8%) | 0.3 (13%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.9 (33%) | 0.2 (8%) | 0.3 (13%) | 1.2 (15%) | 0.2 (11%) | 2.7 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.2 (2%) | 0.0 (2%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.1 (3%) | 0.1 (2%) | 0.1 (1%) | 0.0 (2%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (15%) | 0.0 (0%) | 0.0 (0%) | 0.3 (18%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (56%) | 0.1 (7%) | 0.9 (36%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 0.6 a game | 1.2 a game |
| stood (cast and not dispelled) | 47% (28 of 59) | 55% (6 of 11) | 49% (34 of 70) |
| the unit moved after it | 82% (23 of 28) | 83% (5 of 6) | 82% (28 of 34) |
| it charged on its next turn | 0% (0 of 28) | 0% (0 of 6) | 0% (0 of 34) |
| the enemy charged it first | 14% (4 of 28) | 0% (0 of 6) | 12% (4 of 34) |
| it fought by the end of its next turn | 11% (3 of 28) | 33% (2 of 6) | 15% (5 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (3 of 28) | 0% (0 of 6) | 9% (3 of 34) |
| none of these (no charge, no fight, no charge escaped) | 75% (21 of 28) | 67% (4 of 6) | 74% (25 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (599 of 915) | 51% (277 of 539) | 60% (876 of 1454) |
|   cavalry | 68% (63 of 92) | 65% (72 of 110) | 67% (135 of 202) |
|   character | 38% (41 of 107) | 15% (19 of 130) | 25% (60 of 237) |
|   chariot | 50% (56 of 111) | 64% (14 of 22) | 53% (70 of 133) |
|   infantry | 64% (175 of 275) | 61% (138 of 228) | 62% (313 of 503) |
|   monster | 62% (32 of 52) | 36% (8 of 22) | 54% (40 of 74) |
|   war machine | 83% (232 of 278) | 96% (26 of 27) | 85% (258 of 305) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (31%) | 1.8 (24%) | 4.5 (28%) |
| CHARGED: it charged | 1.2 (14%) | 1.9 (26%) | 3.1 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.5 (7%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.5 (17%) | 1.1 (15%) | 2.5 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.5 (6%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.4 (19%) | 2.8 (17%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR | 0.4 (4%) | 0.1 (1%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.8 | 81% | 6.3 pts | 38 pts |
| character | 2.1 | 0.4 | 85% | 5.6 pts | 12 pts |
| chariot | 1.9 | 0.9 | 69% | 10.7 pts | 21 pts |
| infantry | 13.2 | 4.1 | 76% | 8.5 pts | 112 pts |
| monster | 1.2 | 0.2 | 88% | 5.3 pts | 6 pts |
| war machine | 7.2 | 6.4 | 67% | 31.6 pts | 226 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 6.4 | 5.2 |
| Charges that made contact a game | 2.9 | 4.7 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.82 declared, 0.76 contact (17 units) | 0.94 declared, 0.56 contact (16 units) | 0.88 declared, 0.67 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.67 contact (9 units) | 1.00 declared, 0.64 contact (11 units) | 0.85 declared, 0.65 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.34 contact (249 units) | 0.69 declared, 0.51 contact (298 units) | 0.60 declared, 0.43 contact (547 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (44 of 81) | 62% (10 of 16) | 33% (2 of 6) | 54% (56 of 103) |
| Character in a unit | 86% (25 of 29) | 57% (8 of 14) | 50% (1 of 2) | 76% (34 of 45) |
| Character on its own | 69% (25 of 36) | 61% (17 of 28) | 28% (21 of 76) | 45% (63 of 140) |
| Chariot | 80% (12 of 15) | 50% (6 of 12) | - | 67% (18 of 27) |
| Infantry | 60% (50 of 83) | 36% (9 of 25) | 50% (3 of 6) | 54% (62 of 114) |
| Monster | 59% (20 of 34) | 36% (5 of 14) | - | 52% (25 of 48) |
| Monstrous | 79% (11 of 14) | 64% (9 of 14) | - | 71% (20 of 28) |
| War Machines | 74% (32 of 43) | 100% (2 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 75% (9 of 12); on the table 75% | 34% (35 of 102) | 20% | 73% (16 of 22) | 100% (6 of 6); 3.5 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 90% (9 of 10); on the table 90% | 54% (13 of 24) | 33% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (4 of 4); on the table 100% | - | 51% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 83% (10 of 12); on the table 83% | 33% (6 of 18) | 55% | 65% (40 of 62) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 90% (9 of 10); on the table 90% | 21% (18 of 84) | 28% | 57% (21 of 37) | 100% (9 of 9); 7.5 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 93% (25 of 27); on the table 93% | 25% (9 of 36) | 25% | 44% (31 of 70) | 100% (7 of 7); 2.8 uses a game | 57% (17 of 30); 2.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 39% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 85% (11 of 13); on the table 85% | 50% (3 of 6) | 32% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 83% (5 of 6); on the table 100% | 33% (2 of 6) | 42% | 79% (11 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (6 of 6); on the table 100% | 36% (15 of 42) | 31% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 64% (9 of 14); on the table 79% | 35% (14 of 40) | 52% | 64% (29 of 45) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 50% (3 of 6); 0.5 uses a game |
| Tomb Kings of Khemri | 4 | 75% (9 of 12); on the table 75% | 0% (0 of 6) | 46% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 95% (21 of 22); on the table 95% | 25% (14 of 56) | 30% | 48% (20 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 72% (21 of 29); on the table 76% | 42% (5 of 12) | 26% | 56% (40 of 72) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 89% (25 of 28); on the table 89% | 83% (5 of 6) | 36% | 64% (36 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (fw-on-db7ca9c-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (43) | 51% (34) | 47% (77) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.50 | 1.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.17 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.39 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.86 | 1.61 | 3.47 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.08 | 0.67 | 1.75 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.22 | 8.50 | 15.72 |

### Quality by phase: fw-on-db7ca9c-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 56% (74 of 133) | 44% (86 of 194) |
| Strategy | Shoot objectives carried out (shot that target) | 53% (165 of 311) | 47% (50 of 106) |
| Strategy | Close-in objectives charged next turn | 13% (25 of 197) | 16% (39 of 239) |
| Strategy | Support requests answered (helper made contact too) | 38% (6 of 16) | 60% (18 of 30) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (10 of 15) | 17% (2 of 12) |
| Strategy | Joined characters whose unit fought | 48% (15 of 31) | 47% (16 of 34) |
| Strategy | Lone characters that fought | 74% (68 of 92) | 76% (62 of 82) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 1.2 | 2.1 |
| Movement | Points that never moved of their own | 258.6 | 92.2 |
| Movement | Fights charged into per game | 2.6 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 87, net -25 | 14 of 121, net +86 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 87, net +102 | 16 of 121, net +48 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 16 of 87, net +77 | 14 of 121, net +100 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 of 87, net +78 | 50 of 121, net +141 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.1 | 8.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (195 of 399) | 41% (125 of 308) |
| Shooting | Points destroyed by shooting units | 95.9 | 26.5 |
| Shooting | War machine shots | 6.4 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (127 of 232) | 8% (2 of 26) |
| Shooting | Points destroyed by war machines | 40.0 | 12.6 |
| Magic | Magic missiles cast | 1.4 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (17 of 49) | 25% (12 of 48) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.4 |
| Magic | Wounds caused by other spells | 1.1 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 38.0 | 26.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.5 / 0.7 / 0.2 | 1.8 / 0.6 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 278.6 | 481.5 |
| Combat | Points run down | 50.6 | 50.8 |
| Combat | Net points per charged fight, damage counted | +43 | +88 |
| Combat | Net per 100 charger points, damage counted | +16.0 | +27.3 |
| Combat | First round won (charged fights) | 67% | 55% |
| Combat | Net points per charged fight | +40 | +91 |
| Combat | Net points per supported fight / lone fight | +102 / +30 | +138 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 25 of 93 | 67 of 137 |
| Game | Points lost | 719.5 | 531.1 |
| Game | VP from objectives | 545.0 | 489.2 |
| Game | Lone holders (player turns) | 2.3 | 2.3 |

- Mine won / drew / lost: 9 / 9 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -149 VP
- The side that went first won 11 of 27 games with a winner
- Points traded per game (both sides' losses): 1251
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-on-db7ca9c-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 10.4 | 0.3 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.1 | +7.8 | 0.0 | 40.4 | 1.5 | +17.1 | 0.0 | 5.4 |
| BEST FACING | 1.0 | +57.6 | 0.0 | 62.9 | 0.6 | +29.7 | 0.0 | 9.9 |
| BEST FIRST | 3.2 | +138.6 | 51.8 | 81.9 | 2.5 | +88.6 | 86.4 | 26.9 |
| BEST OVERALL | 0.7 | +48.1 | 0.0 | 11.3 | 0.9 | +58.0 | 0.0 | 23.5 |
| BEST PREY | 0.8 | +32.3 | 27.3 | 14.8 | 1.1 | +51.1 | 21.4 | 5.5 |
| BEST PRIZE | 0.1 | -2.6 | 3.1 | 0.0 | 0.1 | +0.3 | 4.0 | 5.4 |
| BIG CHARACTER SAFETY | 0.2 | -1.5 | 0.0 | 0.0 | 0.4 | -3.7 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 1.8 | 1.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.5 | -4.6 | 0.0 | 0.0 | 0.4 | +6.0 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 124.9 | 14.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 5.0 | +185.4 | 348.5 | 80.3 | 0.7 | +25.0 | 35.7 | 3.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -0.2 | 0.0 | 0.0 | 0.0 | -1.0 | 5.7 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.8 | 2.5 | 5.7 | 0.1 | -6.0 | 5.1 | 0.0 |
| CAST JOB | 0.2 | +13.6 | 3.0 | 2.4 | 0.2 | +3.6 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +24.4 | 15.0 | 8.9 | 0.1 | +8.0 | 13.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 25.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -1.8 | 15.7 | 0.0 | 0.1 | -0.4 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.5 | -22.9 | 0.0 | 4.9 | 0.5 | -60.5 | 13.1 | 1.2 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 2.4 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.6 | 3.2 | 0.0 | 0.1 | -3.8 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.7 | 0.1 | +0.0 | 5.1 | 5.6 |
| COMBAT PIVOT | 0.7 | +0.0 | 16.1 | 63.9 | 0.3 | +0.0 | 22.2 | 4.7 |
| CONVEYANCE SEARCH | 1.4 | +210.1 | 46.3 | 74.5 | 0.2 | +27.0 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 11.8 | +841.0 | 0.0 | 230.9 | 9.8 | +855.3 | 0.0 | 141.6 |
| DEFENSIVE ARMY | 1.1 | -0.2 | 38.9 | 13.5 | 0.3 | -0.1 | 44.1 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.2 | 5.2 | 0.0 | 0.3 | +14.9 | 46.2 | 18.1 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +137.5 | 0.0 | 112.8 | 1.6 | +120.7 | 0.0 | 27.0 |
| FALLBACK BY WORTH | 5.4 | +64.9 | 0.0 | 70.6 | 5.6 | +57.0 | 0.0 | 70.1 |
| FIGHT LIFT | 0.1 | +0.4 | 14.8 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 3.0 |
| FLANK NOT WEIGHED | 6.8 | +0.0 | 0.0 | 174.4 | 7.6 | +0.0 | 0.0 | 107.2 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.2 | 1.8 | 4.4 |
| FOLLOW UP WEIGHED | 0.9 | +144.2 | 0.0 | 49.9 | 1.5 | +246.1 | 0.0 | 77.8 |
| FRIENDS SHOTS CHECKED | 0.3 | +18.6 | 0.0 | 18.4 | 0.2 | +21.1 | 0.0 | 8.2 |
| GIVES UP | 0.4 | -15.2 | 38.9 | 5.7 | 1.3 | -64.3 | 173.9 | 55.2 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.1 |
| HELPER UNSEEN | 0.3 | +0.0 | 0.8 | 4.4 | 0.4 | +0.0 | 8.4 | 15.4 |
| HILL BY ITS CHANCE | 0.5 | -54.4 | 0.0 | 19.9 | 0.5 | -32.3 | 0.0 | 10.4 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +1.9 | 3.5 | 1.9 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 4.6 | 3.0 |
| HUNT IN PAIRS | 0.6 | +19.0 | 0.0 | 23.4 | 0.9 | +36.9 | 0.0 | 4.9 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +21.4 | 8.1 | 4.9 |
| HUNT THE GUNS | 0.0 | +2.3 | 0.0 | 0.0 | 0.2 | +65.0 | 12.6 | 10.9 |
| INVITES THE FIGHT | 3.8 | +211.4 | 106.2 | 74.4 | 2.7 | +118.4 | 51.0 | 44.8 |
| JOINT CHARGE PLAN | 0.1 | +3.8 | 0.0 | 0.0 | 0.1 | +4.7 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +3.0 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 2.2 | +67.5 | 105.8 | 36.2 | 2.8 | +83.3 | 215.9 | 52.3 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +67.8 | 96.9 | 37.5 | 2.3 | +120.1 | 164.6 | 57.3 |
| KILLS COUNT NEXT TURN | 6.4 | +188.0 | 157.2 | 92.8 | 6.7 | +302.5 | 243.8 | 81.7 |
| LINE HITS NO ONE | - | - | - | - | 0.1 | -0.4 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | 0.4 | +11.3 | 14.4 | 12.8 | 0.3 | +9.7 | 1.2 | 18.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 4.9 | 12.9 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -2.8 | 12.5 | 1.8 | 0.5 | +0.5 | 13.6 | 3.2 |
| LOST CHARGE | 3.3 | -49.9 | 99.7 | 95.8 | 1.8 | -29.6 | 66.7 | 64.1 |
| LURE BY WHAT IT DRAWS | 0.1 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.8 | +45.2 | 0.0 | 13.7 | 0.6 | +83.1 | 32.8 | 18.2 |
| MANOEUVRE | 0.4 | +10.9 | 0.0 | 0.0 | 0.3 | +7.1 | 0.0 | 2.7 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +23.7 | 0.0 | 31.0 | 0.4 | +15.6 | 0.0 | 3.2 |
| MARCH ODDS | 0.2 | +21.2 | 11.2 | 0.0 | 0.2 | +25.8 | 12.7 | 0.0 |
| MARCH OVER CASTS | 0.9 | +59.4 | 0.0 | 33.5 | 0.6 | +36.5 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.6 | +242.3 | 0.0 | 136.5 | 6.4 | +264.2 | 0.0 | 70.1 |
| MISSILES IN THE MOVE | 3.4 | +125.7 | 0.0 | 88.6 | 2.5 | +45.3 | 0.0 | 56.1 |
| MISSILES NEXT TURN | 4.8 | +88.4 | 0.0 | 131.1 | 3.3 | +29.6 | 0.0 | 56.1 |
| MODEL FACING | 0.2 | +15.7 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 9.1 | 0.0 | 0.2 | +0.0 | 8.0 | 0.0 |
| MOVE AND CAST | 0.0 | +4.1 | 0.0 | 0.0 | 0.1 | +6.4 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.4 | +7.5 | 0.0 | 16.1 | 0.0 | +0.3 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.5 | -22.7 | 8.0 | 25.0 | 0.1 | -3.2 | 16.6 | 7.6 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 33.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 5.8 | +369.7 | 173.6 | 72.3 | 7.1 | +674.9 | 328.0 | 134.6 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +18.2 | 20.9 | 0.0 |
| NO RALLY LEFT | 0.1 | +13.3 | 0.0 | 3.8 | - | - | - | - |
| NOT NEEDED | 0.3 | -15.0 | 29.6 | 4.5 | 0.3 | -18.3 | 20.6 | 0.0 |
| NOT TURNED | 7.2 | +203.3 | 0.0 | 132.6 | 8.5 | +154.1 | 0.0 | 116.1 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 19.7 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.9 | -739.7 | 11.9 | 212.9 | 14.2 | -767.7 | 4.2 | 198.3 |
| OPENS A LANE | 0.3 | +3.8 | 23.9 | 8.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +15.7 | 14.0 | 2.9 | 0.1 | +7.5 | 4.6 | 0.0 |
| OVERRUNS AWAY | 0.5 | +13.4 | 27.4 | 36.0 | 0.9 | +14.7 | 87.2 | 40.0 |
| PATHS CROSS | 2.9 | +264.7 | 0.0 | 66.3 | 3.9 | +317.8 | 0.0 | 38.1 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +4.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -1.8 | 0.0 | 8.1 | 0.1 | -3.0 | 0.0 | 0.0 |
| PLAN RESULT | 40.3 | +1126.7 | 1239.4 | 950.3 | 40.9 | +1033.1 | 1457.4 | 864.5 |
| PURSUES BIG PREY | 0.1 | -2.8 | 0.0 | 0.0 | 0.1 | -14.3 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.7 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 3.4 |
| RANDOM MOVE BY FIGURES | 1.3 | +22.6 | 0.0 | 47.8 | 2.2 | +25.1 | 0.0 | 26.0 |
| RANDOM MOVER NO PROMISE | 0.4 | -21.2 | 4.9 | 4.7 | 0.5 | -27.9 | 14.9 | 9.9 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -5.4 | 0.0 | 2.1 | 0.6 | -7.5 | 0.0 | 4.0 |
| REDIRECT COUNTER | 2.7 | +212.7 | 0.0 | 30.3 | 4.8 | +425.6 | 0.0 | 68.4 |
| REDIRECT WEIGHED | 0.3 | +0.4 | 0.0 | 6.5 | 0.3 | +4.7 | 5.8 | 5.4 |
| RESERVE FALL BACK | 0.6 | +20.1 | 0.0 | 0.0 | 0.6 | +20.0 | 0.0 | 16.6 |
| RESTRAINS TO SHOOT | 0.1 | +3.1 | 0.0 | 0.0 | 0.1 | +2.1 | 0.0 | 6.5 |
| RISK BY ARC | 2.8 | +121.1 | 158.0 | 83.9 | 3.3 | +57.8 | 270.2 | 116.6 |
| SAFER THAN THE JOB | 1.1 | +64.1 | 0.0 | 19.2 | 0.7 | +37.3 | 0.0 | 14.1 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -10.7 | 0.0 | 0.0 | 0.3 | -10.2 | 0.0 | 0.8 |
| SEARCH SPOT | 3.9 | +201.4 | 0.0 | 59.8 | 4.7 | +246.8 | 0.0 | 30.6 |
| SELF MOVE SPELL | 0.2 | +39.5 | 0.0 | 0.0 | 0.5 | +22.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +65.9 | 4.8 | 13.7 | 1.3 | +136.6 | 39.2 | 20.7 |
| SET-UP ANY TARGET | 0.9 | +158.3 | 0.0 | 9.3 | 0.1 | +31.8 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +8.4 | 0.0 | 0.0 | 0.0 | +4.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +12.8 | 7.1 | 14.3 | 0.4 | +15.9 | 19.2 | 1.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.9 | +0.0 | 228.2 | 13.9 | 0.2 | +0.0 | 17.1 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +647.0 | 0.0 | 238.2 | 7.1 | +168.6 | 0.0 | 92.3 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 1.0 | +182.9 | 15.9 | 19.6 | 0.1 | +31.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +16.0 | 69.0 | 70.6 | 2.4 | +45.8 | 44.0 | 44.0 |
| STABLE ROLE | 11.7 | +0.0 | 371.9 | 170.1 | 10.1 | +0.0 | 180.1 | 130.2 |
| STANDS TO CAST | 0.1 | +1.9 | 3.6 | 2.2 | 0.0 | +1.6 | 0.0 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.1 | +5.7 | 9.2 | 9.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +17.7 | 0.0 | 12.1 | 0.4 | +10.9 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.7 | 0.3 | +0.0 | 0.0 | 4.0 |
| SUPPORTS | 7.7 | +339.7 | 395.8 | 126.2 | 10.4 | +399.2 | 278.6 | 87.4 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -18.1 | 21.4 | 0.0 | 0.2 | -8.5 | 28.0 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +2.5 | 0.0 | 0.0 | 0.5 | +3.1 | 6.5 | 28.1 |
| THROUGH LINE OF FIRE | 0.3 | +12.5 | 0.0 | 9.8 | 0.1 | +14.8 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -30.7 | 21.8 | 0.0 | 0.1 | -6.5 | 7.6 | 1.4 |
| TWO OR MORE ARRIVE | 0.4 | +1.4 | 0.0 | 8.0 | 0.4 | +4.1 | 8.9 | 4.8 |
| WALKS TO THE FIGHT | 1.8 | +82.1 | 35.7 | 28.1 | 1.0 | +41.2 | 12.3 | 0.0 |
| WAR ENGINE JOBS | 1.2 | +0.0 | 42.1 | 34.6 | 0.2 | +0.0 | 5.2 | 0.0 |
| WEARS DOWN | 1.2 | +32.8 | 74.5 | 50.0 | 1.5 | +56.2 | 120.8 | 60.3 |
| WHO HITS BACK | 0.4 | +34.4 | 0.0 | 12.6 | 0.4 | +27.6 | 0.0 | 10.9 |
| WHOLE FIGHT | 0.2 | +4.8 | 26.2 | 0.8 | 0.4 | +12.4 | 50.6 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +28.8 | 3.2 | 0.8 | 0.6 | +43.8 | 34.2 | 16.8 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 18.3 | 1.4 | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: fw-on-db7ca9c-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1083 | 1083 | 1083 | 30.08 | -54265 | -50.1 |
| SUPPORTS | 652 | 652 | 374 | 10.39 | +9335 | +25.0 |
| SEARCH SPOT | 312 | 312 | 312 | 8.67 | +16137 | +51.7 |
| PATHS CROSS | 242 | 242 | 242 | 6.72 | +20971 | +86.7 |
| MOVE TO CHARGE | 464 | 464 | 230 | 6.39 | +14507 | +63.1 |
| COUNTER-CHARGE COVER | 778 | 468 | 221 | 6.14 | +13011 | +58.9 |
| BEST FIRST | 208 | 208 | 208 | 5.78 | +8179 | +39.3 |
| FACES THE THREAT | 125 | 125 | 125 | 3.47 | +9296 | +74.4 |
| KILLS COUNT NEXT TURN | 470 | 470 | 107 | 2.97 | +3728 | +34.8 |
| INVITES THE FIGHT | 236 | 236 | 99 | 2.75 | +3540 | +35.8 |
| FOLLOW UP WEIGHED | 89 | 89 | 89 | 2.47 | +14054 | +157.9 |
| REDIRECT COUNTER | 270 | 188 | 89 | 2.47 | +7573 | +85.1 |
| FALLBACK BY WORTH | 396 | 396 | 86 | 2.39 | +4387 | +51.0 |
| RANDOM MOVE BY FIGURES | 127 | 127 | 77 | 2.14 | +1719 | +22.3 |
| WALKS TO THE FIGHT | 100 | 100 | 77 | 2.14 | +1817 | +23.6 |
| SHOTS IN THE MOVE | 818 | 548 | 76 | 2.11 | +1780 | +23.4 |
| SAFER THAN THE JOB | 63 | 63 | 63 | 1.75 | +3650 | +57.9 |
| RISK BY ARC | 219 | 212 | 58 | 1.61 | +1742 | +30.0 |
| BEST FACING | 57 | 57 | 57 | 1.58 | +3141 | +55.1 |
| BEST OVERALL | 56 | 56 | 56 | 1.56 | +3819 | +68.2 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| MAX FOR POSITIONING | 469 | 297 | 52 | 1.44 | +707 | +13.6 |
| ARTILLERY RE-ROLL WEIGHED | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.22 | +1445 | +32.8 |
| KILLS COUNT | 149 | 146 | 43 | 1.19 | +1583 | +36.8 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SHOT REPLANNED | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| COMBAT PIVOT | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +3672 | +104.9 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | +51 | +1.5 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +1030 | +30.3 |
| KEEPS ITS TARGET | 181 | 179 | 32 | 0.89 | +511 | +16.0 |
| CANNON PLANNED TARGET | 203 | 203 | 31 | 0.86 | +213 | +6.9 |
| WHO HITS BACK | 30 | 30 | 30 | 0.83 | +1621 | +54.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MARCH CHECK | 30 | 30 | 27 | 0.75 | +1395 | +51.7 |
| SET UP TOGETHER | 81 | 70 | 27 | 0.75 | +2736 | +101.3 |
| MANOEUVRE | 25 | 25 | 23 | 0.64 | +649 | +28.2 |
| MISSILES IN THE MOVE | 211 | 127 | 23 | 0.64 | +699 | +30.4 |
| BIG CHARACTER SAFETY | 22 | 22 | 22 | 0.61 | -186 | -8.4 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +869 | +41.4 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 30 | 28 | 21 | 0.58 | +1016 | +48.4 |
| WAR ENGINE JOBS | 51 | 51 | 20 | 0.56 | -1017 | -50.8 |
| STUCK PIVOT | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1432 | +79.5 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| WEARS DOWN | 97 | 94 | 17 | 0.47 | +656 | +38.6 |
| MAKE SURE TOGETHER | 49 | 36 | 16 | 0.44 | +2102 | +131.4 |
| SURE CHARGE BEATS ADVANCE | 16 | 16 | 16 | 0.44 | -958 | -59.9 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -80 | -5.3 |
| MARCH ODDS | 16 | 16 | 15 | 0.42 | +582 | +38.8 |
| THROUGH LINE OF FIRE | 15 | 15 | 15 | 0.42 | +982 | +65.4 |
| HUNT IN PAIRS | 54 | 33 | 14 | 0.39 | +486 | +34.7 |
| BEST PREY | 66 | 66 | 13 | 0.36 | +391 | +30.1 |
| PIVOT GUARDS FLANK | 12 | 12 | 12 | 0.33 | -173 | -14.4 |
| SHOOTS FROM THE BEST SPOT | 26 | 26 | 11 | 0.31 | +349 | +31.7 |
| OVERRUNS AWAY | 50 | 49 | 10 | 0.28 | +233 | +23.3 |
| CASTING BLOCK | 11 | 11 | 9 | 0.25 | +507 | +56.3 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| LOST CHARGE | 183 | 183 | 7 | 0.19 | +207 | +29.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| WHOLE FIGHT | 21 | 20 | 7 | 0.19 | +221 | +31.6 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -274 | -45.7 |
| CAST JOB | 15 | 15 | 6 | 0.17 | +115 | +19.2 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +286 | +47.6 |
| MISSILES NEXT TURN | 292 | 180 | 6 | 0.17 | +11 | +1.9 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +565 | +94.1 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -615 | -102.6 |
| LONE WIZARD HOLDS BACK | 21 | 21 | 5 | 0.14 | -108 | -21.5 |
| MOVE AND CAST | 5 | 5 | 5 | 0.14 | +378 | +75.6 |
| OPENS UP | 9 | 9 | 5 | 0.14 | +161 | +32.2 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +304 | +60.7 |
| CARRIES OUT SET-UP | 8 | 8 | 4 | 0.11 | -284 | -70.9 |
| JOINT CHARGE PLAN | 7 | 7 | 4 | 0.11 | +201 | +50.2 |
| NEEDED THERE | 5 | 5 | 4 | 0.11 | +0 | +0.0 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +350 | +87.6 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +186 | +46.4 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | +7 | +1.7 |
| BACKUP TARGETS | 93 | 47 | 3 | 0.08 | +27 | +9.0 |
| DEFENSIVE ARMY | 50 | 50 | 3 | 0.08 | -64 | -21.2 |
| EDGE GIVE GROUND | 13 | 12 | 3 | 0.08 | +76 | +25.5 |
| LINE HITS NO ONE | 3 | 3 | 3 | 0.08 | +13 | +4.3 |
| LONG SHOT | 30 | 30 | 3 | 0.08 | +25 | +8.3 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +282 | +94.0 |
| SURE REACH TOGETHER | 32 | 20 | 3 | 0.08 | +5 | +1.7 |
| CARRIES OUT COUNTER | 2 | 2 | 2 | 0.06 | -43 | -21.5 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +44 | +21.9 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +7 | +3.6 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +44 | +21.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PURSUES ON | 2 | 2 | 2 | 0.06 | +11 | +5.6 |
| WOUNDED STAYS OUT | 3 | 3 | 2 | 0.06 | -110 | -55.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +37 | +37.4 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -24 | -24.1 |
| HUNT ADVANCE | 4 | 4 | 1 | 0.03 | +1 | +1.1 |
| OPENS A LANE | 11 | 8 | 1 | 0.03 | +17 | +17.2 |
| REDIRECT BY WHAT IT STOPS | 26 | 26 | 1 | 0.03 | +16 | +15.8 |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 1 | 0.03 | +38 | +38.2 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +33 | +33.1 |
| STOPS | 4 | 4 | 1 | 0.03 | +78 | +78.1 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 42 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT NO STATIC JOB | 3 | 3 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 56 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 517 | not checked | - | - | - | - |
| GIVES UP | 61 | 57 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 25 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 34 | 34 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 26 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 53 | 53 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 18 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 14 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 24 | not checked | - | - | - | - |
| NOT NEEDED | 22 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 566 | 566 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| PLAN RESULT | 2924 | trace | - | - | - | - |
| RAIDS THE BAGGAGE | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 31 | 31 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 37 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 40 | not checked | - | - | - | - |
| SPELL WORTH | 136 | not checked | - | - | - | - |
| STABLE ROLE | 784 | 779 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 18 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 26 | 26 | 0 | 0.00 | - | - |

### Off best figure: fw-on-db7ca9c-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.86 | 11.97 | 52.9 |
| FALLBACK | gate | 0.97 | 0.61 | 33.2 |
| TURN GATE | gate | 0.50 | 1.06 | 32.2 |
| WAR ENGINE JOBS | rule | 0.50 | 0.06 | 50.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.19 | 0.25 | 59.9 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.25 | 15.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.22 | 0.11 | 42.8 |
| PIVOT GUARDS FLANK | rule | 0.22 | 0.11 | 14.4 |
| AFTERMATH BAND | gate | 0.11 | 0.17 | 2.4 |
| PATHS CROSS | rule | 0.11 | 0.17 | 28.4 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | 0.17 | 10.5 |
| CHAFF PASSED | rule | 0.17 | 0.08 | 8.8 |
| SUPPORT REQUEST | gate | 0.08 | 0.14 | 94.9 |
| BEST PRIZE | rule | 0.08 | 0.08 | 45.7 |
| BLOCKED WHEEL | rule | 0.11 | 0.06 | 92.4 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.03 | 3.9 |
| PURSUES BIG PREY | rule | 0.08 | 0.08 | 102.6 |
| LONE WIZARD HOLDS BACK | rule | - | 0.14 | 21.5 |
| NO REASON | gate | 0.06 | 0.08 | 7.3 |
| CARRIES OUT SET-UP | rule | 0.06 | 0.06 | 70.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.08 | 27.2 |
| DEFENSIVE ARMY | rule | 0.06 | 0.03 | 21.2 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 1.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 36.1 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.03 | 21.5 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.03 | 23.6 |
| FALLBACK BY WORTH | rule | 0.06 | - | 22.9 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 24.9 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.03 | 55.0 |
| CATCH ODDS | rule | 0.03 | - | 24.1 |
| MARCH ODDS | rule | 0.03 | - | 0.9 |
| PURSUES ON | rule | - | 0.03 | 4.1 |
| STANDS TO CAST | rule | - | 0.03 | 17.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 1.1 |
| WHO HITS BACK | rule | 0.03 | - | 3.9 |

### Plans: fw-on-db7ca9c-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.0 | 16% | 682 | 267 | 39% |
| Mine | charge | 2.7 | 43% | 215 | 137 | 64% |
| Mine | close in | 5.5 | 21% | 559 | 127 | 23% |
| Mine | hold | 4.1 | 34% | 263 | 0 | 0% |
| Mine | join | 0.6 | 90% | 8 | 0 | 0% |
| Mine | shoot | 7.5 | 59% | 290 | 596 | 206% |
| Mine | support | 7.9 | 93% | 264 | 0 | 0% |
| Opponent | advance | 12.6 | 15% | 572 | 280 | 49% |
| Opponent | charge | 4.4 | 49% | 562 | 369 | 66% |
| Opponent | close in | 6.4 | 29% | 964 | 237 | 25% |
| Opponent | hold | 3.6 | 29% | 224 | 0 | 0% |
| Opponent | join | 0.6 | 91% | 24 | 0 | 0% |
| Opponent | shoot | 2.3 | 51% | 59 | 148 | 251% |
| Opponent | support | 10.9 | 94% | 309 | 0 | 0% |

### Packages: hunt the guns, fw-on-db7ca9c-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 83 | 0 | 0% | 16 |
| Opponent | 0.2 | 7 | 1 | 33% | 50% | 0% | 2.0 | 353 | 128 | 50% | 66 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 152 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 83 | 0 | 0% | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 7 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 120 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 112 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 438 | 0 | 0% | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 33% | 67% | 0% | 2.0 | 336 | 180 | 67% | 50 |
| Warriors of Chaos | 0.1 | 1 | 1 | - | - | - | - | - | - | - | 13 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 336 | 115 | 50% | 121 |

### Battle groups: fw-on-db7ca9c-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.8 | 26% | 50% | 7% | 12% | 37% | 5% | 9% | 50% | 0% |
| Mine | REDIRECT COUNTER | 2.7 | 36% | 69% | 6% | 100% | 12% | 3% | 12% | 70% | 3% |
| Opponent | COUNTER-CHARGE COVER | 9.8 | 14% | 73% | 18% | 0% | 45% | 7% | 14% | 33% | 0% |
| Opponent | REDIRECT COUNTER | 4.8 | 21% | 75% | 19% | 0% | 7% | 0% | 7% | 86% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-on-db7ca9c-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 0 | 25% | 5.0 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Mine | Chaff | 34 | 36 (34) | 12 | 24 | 47 | 29% | 2.7 | 4 (14) | 23 (5) | 67 (15) | 56 (20) | 4 (14) |
| Mine | Character | 106 | 35 (106) | 35 | 0 | 42 | 20% | 2.5 | 44 (29) | 38 (48) | 12 (10) | 38 (39) | 37 (48) |
| Mine | Clean-up | 23 | 69 (23) | 45 | 25 | 41 | 35% | 2.5 | 0 (2) | 85 (17) | 51 (4) | 117 (11) | 39 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 73 | 25% | 2.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 40 | 37 (40) | 30 | 7 | 35 | 10% | 2.9 | 46 (25) | 32 (9) | 9 (6) | 46 (25) | 24 (15) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 100 | 75% | 3.0 | 0 (1) | 0 (2) | 0 (1) | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 35 (64) | 16 | 19 | 43 | 16% | 2.6 | 33 (13) | 36 (42) | 30 (9) | 33 (39) | 37 (25) |
| Mine | Holder | 31 | 74 (31) | 6 | 67 | 35 | 29% | 2.8 | 48 (7) | 97 (19) | 28 (5) | 90 (20) | 48 (11) |
| Mine | Shooter | 35 | 73 (35) | 45 | 29 | 40 | 3% | 1.5 | 26 (8) | 98 (22) | 57 (5) | 74 (26) | 72 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | War machine | 56 | 35 (56) | 35 | 0 | 42 | 2% | 1.4 | 43 (16) | 26 (30) | 47 (10) | 42 (9) | 34 (47) |
| Mine | Wizard | 17 | 0 (17) | 0 | 0 | 24 | 12% | 2.1 | 0 (5) | 0 (7) | 0 (1) | 0 (6) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 77 | 33 (77) | 5 | 28 | 44 | 47% | 2.6 | 32 (32) | 31 (18) | 36 (27) | 37 (58) | 18 (19) |
| Opponent | Character | 97 | 55 (97) | 54 | 2 | 19 | 23% | 2.4 | 51 (44) | 61 (42) | 70 (6) | 59 (53) | 54 (39) |
| Opponent | Clean-up | 12 | 37 (12) | 13 | 24 | 28 | 25% | 2.4 | 0 (4) | 39 (5) | 61 (3) | 16 (7) | 51 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 45 (54) | 28 | 16 | 38 | 30% | 3.3 | 18 (23) | 67 (23) | 90 (8) | 41 (33) | 50 (21) |
| Opponent | Fragile | 17 | 4 (17) | 4 | 0 | 39 | 18% | 1.9 | 16 (5) | 0 (8) | 0 (4) | 5 (14) | 0 (3) |
| Opponent | Hammer | 65 | 47 (65) | 35 | 12 | 33 | 29% | 3.0 | 43 (20) | 50 (38) | 33 (7) | 54 (41) | 36 (24) |
| Opponent | Holder | 30 | 22 (30) | 2 | 21 | 17 | 60% | 4.8 | 3 (9) | 34 (14) | 15 (6) | 24 (16) | 22 (13) |
| Opponent | Shooter | 34 | 67 (34) | 20 | 47 | 35 | 0% | 1.5 | 35 (10) | 88 (21) | 28 (3) | 43 (19) | 96 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 67 | 33% | 3.0 | 0 (1) | - | 0 (2) | - | 0 (3) |
| Opponent | War machine | 6 | 89 (6) | 89 | 0 | 40 | 17% | 1.0 | 91 (3) | 85 (3) | - | 91 (3) | 85 (3) |
| Opponent | Wizard | 20 | 10 (20) | 10 | 0 | 37 | 15% | 2.5 | 15 (12) | 2 (3) | 0 (2) | 13 (12) | 0 (5) |

### Charged fights: fw-on-db7ca9c-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 80 | 192 | 2.0 | 1.0 | 96 | 40 | +56 | 1 of 8 | 6 of 8 | - | +56 |
| Mine | Chaos Dwarfs | 4 | 70 | 102 | 2.0 | 1.4 | 51 | 15 | +36 | 1 of 8 | 7 of 8 | +96 | +0 |
| Mine | Dwarfen Mountain Holds | 3 | 499 | 15 | 1.7 | 1.0 | 9 | 48 | -39 | 2 of 5 | 2 of 5 | - | -39 |
| Mine | Empire of Man | 5 | 391 | 243 | 2.2 | 1.0 | 110 | 117 | -7 | 7 of 11 | 3 of 11 | - | -7 |
| Mine | Grand Cathay | 4 | 225 | 227 | 3.2 | 1.2 | 70 | 25 | +45 | 1 of 13 | 7 of 13 | +110 | +25 |
| Mine | High Elf Realms | 4 | 214 | 458 | 3.5 | 1.3 | 131 | 8 | +123 | 2 of 14 | 12 of 14 | +151 | +111 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 210 | 5.0 | 1.2 | 42 | 94 | -52 | 3 of 5 | 4 of 5 | +0 | -65 |
| Mine | Lizardmen | 1 | 0 | 110 | 2.0 | 2.0 | 55 | 0 | +55 | 1 of 2 | 2 of 2 | +110 | +0 |
| Mine | Ogre Kingdoms | 2 | 0 | 182 | 3.5 | 1.0 | 52 | 0 | +52 | 1 of 7 | 5 of 7 | - | +52 |
| Mine | Skaven | 2 | 32 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 96 | 484 | 3.0 | 1.0 | 161 | 12 | +150 | 3 of 6 | 3 of 6 | - | +150 |
| Mine | Vampire Counts | 2 | 67 | 67 | 3.0 | 1.0 | 22 | 8 | +15 | 0 of 6 | 5 of 6 | - | +15 |
| Mine | Warriors of Chaos | 2 | 0 | 206 | 3.5 | 1.1 | 59 | 92 | -34 | 3 of 7 | 5 of 7 | +0 | -39 |
| **Mine** | all armies | 36 | 174 | 205 | 2.6 | 1.2 | 79 | 39 | +40 | 25 of 93 | 62 of 93 | +102 | +30 |
| Opponent | Empire of Man | 1 | 515 | 60 | 2.0 | 1.0 | 30 | 0 | +30 | 1 of 2 | 1 of 2 | - | +30 |
| Opponent | High Elf Realms | 5 | 55 | 489 | 4.6 | 1.2 | 106 | 15 | +91 | 15 of 23 | 10 of 23 | +196 | +62 |
| Opponent | Lizardmen | 2 | 240 | 690 | 3.0 | 1.0 | 230 | 91 | +139 | 5 of 6 | 2 of 6 | - | +139 |
| Opponent | Orc & Goblin Tribes | 3 | 84 | 145 | 4.0 | 1.1 | 36 | 0 | +36 | 3 of 12 | 6 of 12 | +83 | +32 |
| Opponent | Skaven | 4 | 91 | 86 | 1.8 | 1.0 | 49 | 0 | +49 | 1 of 7 | 5 of 7 | - | +49 |
| Opponent | Tomb Kings of Khemri | 2 | 85 | 328 | 3.0 | 1.2 | 110 | 42 | +67 | 3 of 6 | 5 of 6 | +176 | +45 |
| Opponent | Vampire Counts | 6 | 8 | 507 | 4.5 | 1.3 | 113 | 28 | +85 | 19 of 27 | 13 of 27 | +85 | +84 |
| Opponent | Warriors of Chaos | 7 | 6 | 449 | 3.3 | 1.1 | 137 | 20 | +117 | 14 of 23 | 10 of 23 | +322 | +97 |
| Opponent | Wood Elf Realms | 6 | 36 | 709 | 5.2 | 1.4 | 137 | 28 | +109 | 6 of 31 | 24 of 31 | +91 | +117 |
| **Opponent** | all armies | 36 | 66 | 438 | 3.8 | 1.2 | 115 | 24 | +91 | 67 of 137 | 76 of 137 | +138 | +82 |

### Effective charges: fw-on-db7ca9c-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 2 (net -74) | 0 | 1 (net +266) | 3 (net +84) | 0 | 2 (net +40) | 0 | 12% (1 of 8) |
| Mine | Chaos Dwarfs | 8 | 1 (net +0) | 0 | 1 (net +0) | 0 | 4 (net +72) | 2 (net +0) | 0 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net -180) | 0 | 1 (net +0) | 3 (net -5) | 0 | 0 | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 11 | 4 (net -8) | 0 | 2 (net -66) | 2 (net -38) | 1 (net +0) | 2 (net +81) | 0 | 18% (2 of 11) |
| Mine | Grand Cathay | 13 | 1 (net +0) | 0 | 1 (net +0) | 3 (net -24) | 3 (net +15) | 5 (net +121) | 0 | 8% (1 of 13) |
| Mine | High Elf Realms | 14 | 1 (net +0) | 0 | 1 (net +663) | 2 (net +35) | 5 (net +168) | 3 (net +27) | 2 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +0) | 1 (net -261) | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 | 0% (0 of 4) |
| Mine | Lizardmen | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +110) | 0 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 7 | 0 | 0 | 2 (net +0) | 0 | 0 | 3 (net +85) | 2 | 40% (2 of 5) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 6 | 1 (net -70) | 0 | 1 (net +250) | 0 | 1 (net +54) | 3 (net +221) | 0 | 17% (1 of 6) |
| Mine | Vampire Counts | 6 | 1 (net +107) | 0 | 0 | 2 (net -9) | 1 (net +0) | 2 (net +0) | 0 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 7 | 0 | 0 | 3 (net +127) | 3 (net -206) | 0 | 0 | 1 | 50% (3 of 6) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Opponent | High Elf Realms | 23 | 2 (net +186) | 0 | 3 (net +112) | 3 (net +28) | 1 (net +77) | 11 (net +143) | 3 | 15% (3 of 20) |
| Opponent | Lizardmen | 6 | 0 | 0 | 3 (net +17) | 2 (net +102) | 0 | 1 (net +580) | 0 | 50% (3 of 6) |
| Opponent | Orc & Goblin Tribes | 12 | 0 | 0 | 2 (net +17) | 1 (net +0) | 1 (net +83) | 1 (net +0) | 7 | 40% (2 of 5) |
| Opponent | Skaven | 7 | 0 | 1 (net +205) | 1 (net +0) | 0 | 0 | 4 (net +34) | 1 | 17% (1 of 6) |
| Opponent | Tomb Kings of Khemri | 6 | 0 | 0 | 0 | 1 (net -60) | 1 (net +176) | 2 (net +63) | 2 | 0% (0 of 4) |
| Opponent | Vampire Counts | 27 | 7 (net +72) | 1 (net +299) | 2 (net +178) | 3 (net -17) | 2 (net -22) | 12 (net +102) | 0 | 7% (2 of 27) |
| Opponent | Warriors of Chaos | 23 | 4 (net +84) | 0 | 3 (net +0) | 4 (net +170) | 2 (net +199) | 8 (net +180) | 2 | 14% (3 of 21) |
| Opponent | Wood Elf Realms | 31 | 1 (net +0) | 0 | 2 (net +0) | 11 (net +63) | 7 (net +101) | 10 (net +199) | 0 | 6% (2 of 31) |

### Charged fights, damage counted: fw-on-db7ca9c-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 215 | 250 | -25 | 47 | 86 | -39 | -18.2 |
| Mine | 50-54% | 1 | 371 | 222 | -261 | 321 | 471 | -150 | -40.4 |
| Mine | Effective (55-75%) | 14 | 252 | 305 | +102 | 190 | 83 | +107 | +42.5 |
| Mine | 76-89% | 18 | 197 | 157 | -26 | 72 | 97 | -25 | -12.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 234 | 166 | +78 | 122 | 31 | +91 | +39.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 480 | 102 | +77 | 94 | 21 | +73 | +15.1 |
| Mine | No odds | 6 | 260 | 134 | +28 | 34 | 0 | +34 | +13.2 |
| Mine | All fights | 93 | 272 | 185 | +40 | 104 | 60 | +43 | +16.0 |
| Opponent | Long shot (under 50%) | 14 | 222 | 201 | +86 | 143 | 105 | +38 | +17.1 |
| Opponent | 50-54% | 2 | 470 | 207 | +252 | 274 | 22 | +252 | +53.6 |
| Opponent | Effective (55-75%) | 16 | 288 | 250 | +48 | 115 | 58 | +57 | +19.9 |
| Opponent | 76-89% | 25 | 294 | 226 | +62 | 124 | 51 | +73 | +24.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 50 | 352 | 220 | +141 | 173 | 31 | +142 | +40.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 498 | 92 | +100 | 117 | 15 | +103 | +20.7 |
| Opponent | No odds | 16 | 236 | 187 | +1 | 54 | 65 | -11 | -4.8 |
| Opponent | All fights | 137 | 324 | 206 | +91 | 136 | 48 | +88 | +27.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-on-db7ca9c-p4 | move | 601 | 113 (19%) | 81 (13%) | 65 (11%) | 423 (70%) |
| fw-on-db7ca9c-p4 | objective | 436 | 64 (15%) | 49 (11%) | 58 (13%) | 314 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

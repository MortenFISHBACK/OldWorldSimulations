# Doctrine scorecard: fw-on-db7ca9c-p2b

### Scorecard: fw-on-db7ca9c-p2b

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | yes | 1 | 2 | 0 | 1 | 0 | 0 | 0 | 558 |
| L0721 | 1 | 1 | Opponent | yes | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 390 |
| L0810 | 6 | 1 | Opponent | no | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 717 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 8 | 3 | 2 | 1 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 808 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 4 | 3 | 0 | 1 | 0 | 0 | 274 |
| L1228 | 4 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 4 | 3 | 5 | 0 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 72 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 0 | 2 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 3 | 8 | 1 | 0 | 0 | 0 | 140 |
| **Average** | | | Mine | 20% | 0.7 | 2.1 | 2.4 | 0.5 | 0.2 | 0.0 | 0.0 | 362.8 |
| **Average** | | | Opponent | 20% | 2.6 | 2.8 | 2.4 | 1.8 | 0.2 | 0.0 | 0.0 | 130.4 |

### KPIs: fw-on-db7ca9c-p2b

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 61% (35 of 57) | 3% (2 of 59) | 32% (37 of 116) |
| Winner chose to follow up after the loser gave ground |  | 95% (19 of 20); on the table 95% | 89% (8 of 9); on the table 100% | 93% (27 of 29); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 56% (5 of 9); on the table 67% | 67% (10 of 15); on the table 87% | 62% (15 of 24); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 80% (24 of 30); on the table 83% | 77% (20 of 26); on the table 92% | 79% (44 of 56); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 32% (46 of 144) | 23% (15 of 66) | 29% (61 of 210) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (46 of 95) | 27% (15 of 56) | 40% (61 of 151) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 71% (10 of 14) | 71% (10 of 14) |
| Points that never fought | lower | 39% (9343 of 23994) | 41% (9886 of 23996) | 40% (19229 of 47990) |
|   infantry points that never fought | lower | 41% (1714 of 4212) | 53% (2228 of 4201) | 47% (3942 of 8413) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (62 of 115) | 64% (61 of 95) | 59% (123 of 210) |
| Bound items with a magic missile used (at least once a game) |  | 100% (10 of 10); 3.3 uses a game | 88% (7 of 8); 1.7 uses a game | 94% (17 of 18); 2.5 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 29% (5 of 17); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 29% (2 of 7); 0.2 uses a game | 33% (1 of 3); 0.1 uses a game | 30% (3 of 10); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (11139 of 22519) | 58% (12176 of 21142) | 53% (23315 of 43661) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (15%) | 1.2 (27%) | 2.4 (19%) |
| MARCHED: its unit marched | 2.5 (31%) | 1.2 (27%) | 3.7 (30%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 2.9 (36%) | 0.6 (14%) | 3.5 (28%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |
| NO CASTS LEFT: every cast used on other spells | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.6 (7%) | 0.0 (0%) | 0.6 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (7%) | 0.2 (6%) | 0.8 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.8 (18%) | 0.8 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 2.9 | 1.2 | 5.1 | 0.8 | 1.9 |
| not cast | 3.1 | 5.6 | 3.8 | 12.4 | 2.2 | 23.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (3%) | 2.0 (36%) | 0.3 (9%) | 2.4 (19%) | 0.3 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (30%) | 0.7 (30%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (6%) | 0.8 (20%) | 3.5 (28%) | 0.6 (26%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (16%) | 1.0 (18%) | 0.5 (13%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| GONE: slain | 0.8 (27%) | 1.2 (22%) | 0.2 (4%) | 0.6 (5%) | 0.2 (7%) | 3.2 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.5 (9%) | 0.2 (7%) | 0.8 (7%) | 0.0 (0%) | 1.0 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.4 (19%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (6%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (46%) | 0.2 (3%) | 1.7 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.8 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.2 a game | 1.0 a game | 0.6 a game |
| stood (cast and not dispelled) | 100% (3 of 3) | 58% (7 of 12) | 67% (10 of 15) |
| the unit moved after it | 100% (3 of 3) | 43% (3 of 7) | 60% (6 of 10) |
| it charged on its next turn | 0% (0 of 3) | 14% (1 of 7) | 10% (1 of 10) |
| the enemy charged it first | 33% (1 of 3) | 0% (0 of 7) | 10% (1 of 10) |
| it fought by the end of its next turn | 33% (1 of 3) | 0% (0 of 7) | 10% (1 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | 14% (1 of 7) | 10% (1 of 10) |
| none of these (no charge, no fight, no charge escaped) | 67% (2 of 3) | 71% (5 of 7) | 70% (7 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (222 of 317) | 56% (134 of 240) | 64% (356 of 557) |
|   cavalry | 70% (19 of 27) | 78% (31 of 40) | 75% (50 of 67) |
|   character | 26% (9 of 34) | 43% (18 of 42) | 36% (27 of 76) |
|   chariot | 73% (24 of 33) | 68% (21 of 31) | 70% (45 of 64) |
|   infantry | 63% (57 of 91) | 47% (42 of 89) | 55% (99 of 180) |
|   monster | 67% (4 of 6) | 58% (15 of 26) | 59% (19 of 32) |
|   war machine | 87% (109 of 126) | 58% (7 of 12) | 84% (116 of 138) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (35%) | 3.2 (36%) | 5.9 (35%) |
| CHARGED: it charged | 1.3 (17%) | 1.9 (22%) | 3.2 (19%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.5 (6%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 0.8 (9%) | 1.3 (15%) | 2.1 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.2 (2%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (16%) | 1.2 (14%) | 2.5 (15%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.2 (3%) | 0.6 (3%) |
| OTHER BAR | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.8 | 2.0 | 76% | 6.7 pts | 52 pts |
| character | 2.5 | 0.3 | 90% | 1.3 pts | 3 pts |
| chariot | 3.8 | 2.8 | 76% | 14.0 pts | 53 pts |
| infantry | 10.8 | 4.3 | 71% | 10.6 pts | 114 pts |
| monster | 1.9 | 0.9 | 70% | 16.0 pts | 31 pts |
| war machine | 9.7 | 8.9 | 59% | 32.9 pts | 318 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 6.2 | 4.9 |
| Charges that made contact a game | 2.8 | 4.3 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 1.08 contact (12 units) | 0.60 declared, 0.60 contact (5 units) | 1.12 declared, 0.94 contact (17 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.67 declared, 1.67 contact (3 units) | 1.67 declared, 1.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.30 contact (70 units) | 0.61 declared, 0.41 contact (108 units) | 0.53 declared, 0.37 contact (178 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 61% (22 of 36) | 33% (1 of 3) | 40% (2 of 5) | 57% (25 of 44) |
| Character in a unit | 100% (5 of 5) | 100% (3 of 3) | 100% (1 of 1) | 100% (9 of 9) |
| Character on its own | 100% (14 of 14) | 39% (7 of 18) | 29% (6 of 21) | 51% (27 of 53) |
| Chariot | 58% (7 of 12) | 75% (3 of 4) | - | 62% (10 of 16) |
| Infantry | 41% (13 of 32) | 0% (0 of 4) | 67% (2 of 3) | 38% (15 of 39) |
| Monster | 100% (3 of 3) | 100% (4 of 4) | - | 100% (7 of 7) |
| Monstrous | 83% (5 of 6) | 78% (7 of 9) | - | 80% (12 of 15) |
| War Machines | 67% (18 of 27) | - | - | 67% (18 of 27) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 5 | 82% (9 of 11); on the table 82% | 27% (8 of 30) | 39% | 63% (34 of 54) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
| Grand Cathay | 5 | 72% (13 of 18); on the table 78% | 34% (41 of 120) | 46% | 47% (21 of 45) | 100% (11 of 11); 9.0 uses a game | 0% (0 of 2); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 3 | 100% (6 of 6); on the table 100% | 22% (4 of 18) | 30% | 35% (9 of 26) | 100% (1 of 1); 0.7 uses a game | 36% (5 of 14); 2.7 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (4 of 4); on the table 100% | 0% (0 of 12) | 39% | 76% (16 of 21) | 100% (3 of 3); 3.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 33% (2 of 6); on the table 100% | 17% (1 of 6) | 39% | 44% (4 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 20% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 100% (4 of 4); on the table 100% | 17% (2 of 12) | 56% | 73% (8 of 11) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 67% (4 of 6) | 94% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 3 | 80% (4 of 5); on the table 80% | 17% (1 of 6) | 22% | 69% (22 of 32) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-on-db7ca9c-p2b, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (13) | 67% (10) | 53% (23) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.50 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.08 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.42 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.50 | 1.75 | 4.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.50 | 1.00 | 2.50 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.50 | 8.33 | 12.83 |

### Quality by phase: fw-on-db7ca9c-p2b

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 54% (22 of 41) | 46% (31 of 68) |
| Strategy | Shoot objectives carried out (shot that target) | 34% (47 of 137) | 63% (22 of 35) |
| Strategy | Close-in objectives charged next turn | 15% (10 of 65) | 17% (12 of 71) |
| Strategy | Support requests answered (helper made contact too) | 33% (1 of 3) | 67% (10 of 15) |
| Strategy | Hexes on a unit its side charged or shot that turn | 15% (2 of 13) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 57% (4 of 7) | 14% (1 of 7) |
| Strategy | Lone characters that fought | 72% (29 of 40) | 74% (20 of 27) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 0.5 | 1.8 |
| Movement | Points that never moved of their own | 362.8 | 130.4 |
| Movement | Fights charged into per game | 2.5 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 28 | 7 of 34, net +239 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 28, net +88 | 7 of 34, net +161 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 28, net +138 | 2 of 34, net +52 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 of 28, net +91 | 12 of 34, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.5 | 11.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (41 of 126) | 59% (83 of 140) |
| Shooting | Points destroyed by shooting units | 41.0 | 46.2 |
| Shooting | War machine shots | 9.1 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (60 of 109) | 57% (4 of 7) |
| Shooting | Points destroyed by war machines | 131.1 | 32.5 |
| Magic | Magic missiles cast | 2.8 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (12 of 33) | 25% (2 of 8) |
| Magic | Wounds caused by magic missiles | 5.8 | 2.6 |
| Magic | Wounds caused by other spells | 4.1 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 169.8 | 26.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.5 / 1.1 / 1.0 / 0.2 | 2.1 / 0.2 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 300.0 | 424.6 |
| Combat | Points run down | 127.1 | 106.5 |
| Combat | Net points per charged fight, damage counted | +140 | +148 |
| Combat | Net per 100 charger points, damage counted | +44.7 | +45.8 |
| Combat | First round won (charged fights) | 93% | 65% |
| Combat | Net points per charged fight | +120 | +152 |
| Combat | Net points per supported fight / lone fight | +93 / +124 | +236 / +124 |
| Combat | Charged fights on a top-3 enemy unit | 10 of 30 | 19 of 40 |
| Game | Points lost | 826.8 | 790.3 |
| Game | VP from objectives | 560.0 | 554.2 |
| Game | Lone holders (player turns) | 0.7 | 2.6 |

- Mine won / drew / lost: 5 / 3 / 4 of 12 ended games (of 12); mean margin (Mine - Opponent) -42 VP
- The side that went first won 7 of 9 games with a winner
- Points traded per game (both sides' losses): 1617
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-on-db7ca9c-p2b

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.2 | +7.3 | 0.0 | 6.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 45.8 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.9 | +10.1 | 0.0 | 83.1 | 1.2 | +13.0 | 0.0 | 91.1 |
| BEST FACING | 0.8 | +59.4 | 0.0 | 0.0 | 1.2 | +65.9 | 0.0 | 100.8 |
| BEST FIRST | 2.8 | +130.0 | 139.2 | 54.7 | 2.6 | +114.3 | 12.6 | 99.0 |
| BEST OVERALL | 0.3 | +23.3 | 0.0 | 22.1 | 1.1 | +58.7 | 0.0 | 46.7 |
| BEST PREY | 0.5 | +25.7 | 10.4 | 0.0 | 0.9 | +39.3 | 10.8 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | +1.0 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.5 | +35.0 | 0.0 | 20.9 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 12.6 | - | - | - | - |
| CANNON PLAN MISSED | 1.3 | +0.0 | 73.8 | 10.8 | 0.2 | +0.0 | 21.2 | 0.0 |
| CANNON PLANNED TARGET | 6.3 | +330.3 | 404.4 | 162.5 | 0.4 | +54.1 | 91.3 | 0.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | +0.0 | 30.9 | 0.0 |
| CAST JOB | 1.1 | +6.8 | 215.1 | 0.0 | 0.1 | +9.2 | 22.1 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.1 | +7.5 | 10.5 | 0.0 | 0.1 | +7.6 | 18.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.5 | -2.9 | 49.9 | 13.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.6 | -55.1 | 74.8 | 34.0 | 0.4 | -48.4 | 66.8 | 30.8 |
| CHARIOT WIZARD CAREFUL | 0.2 | -0.4 | 0.0 | 0.0 | 0.1 | -2.0 | 31.7 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.4 | +0.0 | 13.5 | 9.1 |
| COMBAT PIVOT | 0.2 | +0.0 | 9.6 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 0.8 | +92.9 | 28.9 | 33.8 |
| COUNTER-CHARGE COVER | 10.2 | +871.1 | 0.0 | 241.4 | 8.2 | +1304.0 | 0.0 | 242.8 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | - | - | - | - | 0.6 | +10.3 | 52.6 | 2.8 |
| FACES THE THREAT | 2.5 | +262.6 | 0.0 | 69.8 | 1.8 | +148.1 | 0.0 | 114.0 |
| FALLBACK BY WORTH | 4.1 | +29.5 | 0.0 | 84.5 | 6.5 | +95.2 | 0.0 | 112.1 |
| FIRE AND FLEE | 0.1 | +1.8 | 0.0 | 0.0 | 0.2 | +1.8 | 0.0 | 9.5 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 150.8 | 7.5 | +0.0 | 0.0 | 200.3 |
| FOLLOW UP WEIGHED | 1.1 | +220.8 | 0.0 | 0.0 | 0.8 | +207.6 | 0.0 | 16.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +13.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -31.4 | 153.4 | 30.8 | 1.4 | -73.8 | 198.8 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.2 | -0.8 | 13.5 | 5.5 |
| GROUND FLIERS | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 34.0 | 10.4 |
| HELPER UNSEEN | 0.2 | +0.0 | 11.9 | 0.0 | 0.2 | +0.0 | 25.2 | 5.5 |
| HILL BY ITS CHANCE | 0.6 | -38.7 | 0.0 | 10.2 | - | - | - | - |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.3 | +7.2 | 0.0 | 9.2 |
| HUNT DROPPED | - | - | - | - | 0.3 | +0.0 | 27.5 | 0.0 |
| HUNT IN PAIRS | 1.2 | +82.4 | 0.0 | 0.0 | 0.8 | +10.3 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.4 | +0.0 | 27.5 | 9.2 |
| HUNT THE GUNS | - | - | - | - | 0.4 | +188.3 | 0.0 | 9.2 |
| INVITES THE FIGHT | 3.7 | +166.4 | 200.6 | 53.5 | 3.2 | +360.8 | 178.8 | 84.8 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +0.2 | 35.1 | 0.0 |
| KEEP FALLS | 0.1 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 2.2 | +65.0 | 276.6 | 30.8 | 2.5 | +75.0 | 177.7 | 52.8 |
| KILLS COUNT | 2.3 | +68.8 | 225.0 | 61.5 | 2.4 | +95.8 | 315.6 | 86.5 |
| KILLS COUNT NEXT TURN | 4.9 | +211.8 | 247.0 | 122.7 | 6.7 | +200.1 | 299.2 | 80.6 |
| LONE CHARACTER SAFE SPOT | 0.2 | +23.1 | 36.8 | 36.8 | 0.4 | +21.8 | 41.9 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +35.7 | 0.0 | 0.0 | 0.2 | +22.1 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -11.8 | 39.9 | 0.0 | 1.0 | +2.9 | 96.2 | 6.4 |
| LOST CHARGE | 3.2 | -68.6 | 192.8 | 101.5 | 2.8 | -102.1 | 146.8 | 151.4 |
| LURE BY WHAT IT DRAWS | 0.1 | -5.9 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.2 | +8.9 | 25.1 | 0.0 | 0.8 | +61.8 | 136.9 | 12.0 |
| MANOEUVRE | 0.2 | +40.5 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +20.5 | 0.0 | 0.0 | 0.8 | +16.4 | 0.0 | 13.2 |
| MARCH ODDS | 0.5 | +41.3 | 0.0 | 31.7 | 0.5 | +33.5 | 7.5 | 0.0 |
| MARCH OVER CASTS | 1.4 | +161.4 | 0.0 | 0.0 | 0.8 | +32.4 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.8 | +251.0 | 0.0 | 145.2 | 6.2 | +322.9 | 0.0 | 138.8 |
| MISSILES IN THE MOVE | 5.8 | +133.9 | 0.0 | 133.0 | 3.0 | +78.0 | 0.0 | 55.2 |
| MISSILES NEXT TURN | 7.2 | +87.1 | 0.0 | 119.1 | 4.0 | +62.2 | 0.0 | 55.2 |
| MONSTER WIZARD ROAMS | 0.8 | +0.0 | 41.2 | 0.0 | 0.4 | +0.0 | 35.1 | 0.0 |
| MOVE AND CAST | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +2.6 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.2 | -10.2 | 0.0 | 56.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 36.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 4.9 | +383.7 | 256.8 | 120.6 | 7.0 | +527.2 | 313.8 | 215.9 |
| NEEDED THERE | 0.2 | +9.5 | 16.2 | 0.0 | 0.1 | +12.3 | 13.5 | 0.0 |
| NOT NEEDED | 0.1 | -0.5 | 5.5 | 0.0 | 0.6 | -11.7 | 32.9 | 2.8 |
| NOT TURNED | 4.5 | +112.1 | 0.0 | 110.2 | 8.3 | +136.3 | 0.0 | 183.8 |
| NOT WORTH A CAST | 0.8 | -0.4 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.2 | -753.9 | 0.0 | 302.2 | 15.4 | -1031.8 | 68.4 | 308.1 |
| OPENS A LANE | 0.8 | +1.9 | 94.2 | 45.5 | - | - | - | - |
| OPENS UP | 0.2 | +8.7 | 19.0 | 0.0 | 0.1 | +5.1 | 8.7 | 0.0 |
| OVERRUNS AWAY | 0.5 | +23.1 | 50.0 | 30.8 | 0.2 | +20.4 | 20.5 | 0.0 |
| PATHS CROSS | 2.1 | +206.5 | 0.0 | 56.9 | 2.9 | +204.5 | 0.0 | 25.2 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -5.1 | 0.0 | 0.0 |
| PLAN RESULT | 35.4 | +1300.4 | 2039.2 | 1053.1 | 41.5 | +1286.8 | 1437.6 | 1181.8 |
| PURSUES BIG PREY | 0.2 | -12.7 | 0.0 | 0.0 | 0.2 | -11.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.3 | +39.6 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.2 | +7.0 | 0.0 | 24.2 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.1 | -4.9 | 24.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.4 | -2.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.4 | +131.5 | 0.0 | 79.2 | 4.8 | +546.6 | 0.0 | 95.9 |
| REDIRECT WEIGHED | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +6.9 | 0.0 | 0.0 | 1.1 | +18.3 | 0.0 | 60.3 |
| RESTRAINS TO SHOOT | 0.1 | +12.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.8 | +140.5 | 351.5 | 51.2 | 3.2 | +63.3 | 417.4 | 95.1 |
| SAFER THAN THE JOB | 1.5 | +146.6 | 0.0 | 14.8 | 1.0 | +111.9 | 0.0 | 15.9 |
| SCOUT SPOT | 0.3 | +2.1 | 0.0 | 0.0 | 0.7 | +5.0 | 0.0 | 2.8 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 2.8 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -32.3 | 0.0 | 4.6 |
| SEARCH SPOT | 2.2 | +154.8 | 0.0 | 66.8 | 4.9 | +314.4 | 0.0 | 46.2 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.9 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.5 | +15.6 | 25.1 | 0.0 | 1.4 | +120.5 | 167.8 | 12.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +49.1 | 28.9 | 33.8 |
| SET-UP MISSED | - | - | - | - | 0.1 | +9.6 | 15.4 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.2 | +0.3 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +55.9 | 28.2 | 14.8 | 0.5 | +48.4 | 22.1 | 31.5 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.8 | +0.0 | 62.6 | 0.0 | 0.2 | +0.0 | 22.8 | 30.0 |
| SHOTS IN THE MOVE | 17.7 | +996.7 | 0.0 | 378.3 | 9.5 | +308.3 | 0.0 | 339.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.4 | +102.6 | 28.9 | 33.8 |
| SPELL WORTH | 0.8 | +19.0 | 14.2 | 14.2 | 3.3 | +66.1 | 203.2 | 203.2 |
| STABLE ROLE | 10.0 | +0.0 | 537.6 | 155.4 | 11.8 | +0.0 | 472.2 | 188.6 |
| STANDS TO CAST | - | - | - | - | 0.1 | +7.4 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.2 | +11.6 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 1.4 | +62.4 | 0.0 | 46.6 | 0.3 | +15.9 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.1 | +0.0 | 0.0 | 12.1 |
| SUPPORTS | 5.4 | +225.7 | 322.8 | 78.1 | 10.1 | +467.6 | 250.5 | 122.8 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -0.7 | 22.8 | 12.5 | 0.3 | -7.9 | 8.7 | 49.9 |
| SURE REACH TOGETHER | 0.4 | +4.8 | 0.0 | 30.8 | 0.5 | +6.2 | 0.0 | 2.2 |
| THROUGH LINE OF FIRE | 0.4 | +34.9 | 0.0 | 13.7 | 0.2 | +15.8 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -27.6 | 42.8 | 20.5 | 0.2 | -9.8 | 22.8 | 15.4 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.4 | +1.7 | 35.1 | 0.0 |
| WALKS TO THE FIGHT | 1.3 | +63.1 | 53.7 | 41.0 | 1.4 | +72.1 | 72.9 | 26.3 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 0.0 | 25.0 | 1.0 | +0.0 | 71.7 | 30.8 |
| WEARS DOWN | 0.5 | +19.7 | 112.2 | 0.0 | 1.9 | +63.7 | 289.8 | 12.3 |
| WHO HITS BACK | 0.3 | +29.1 | 0.0 | 43.8 | 0.1 | +9.1 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | -2.7 | 43.7 | 0.0 | 0.3 | -0.9 | 33.1 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +26.8 | 25.9 | 10.2 | 1.2 | +110.2 | 258.2 | 79.7 |

### Rule changes: fw-on-db7ca9c-p2b

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 379 | 379 | 379 | 31.58 | -21430 | -56.5 |
| SUPPORTS | 186 | 186 | 117 | 9.75 | +3049 | +26.1 |
| SEARCH SPOT | 86 | 86 | 85 | 7.08 | +5630 | +66.2 |
| MOVE TO CHARGE | 143 | 143 | 76 | 6.33 | +3426 | +45.1 |
| BEST FIRST | 65 | 65 | 65 | 5.42 | +2931 | +45.1 |
| COUNTER-CHARGE COVER | 221 | 126 | 62 | 5.17 | +5213 | +84.1 |
| PATHS CROSS | 60 | 60 | 60 | 5.00 | +4933 | +82.2 |
| FACES THE THREAT | 51 | 51 | 51 | 4.25 | +4928 | +96.6 |
| KILLS COUNT NEXT TURN | 139 | 139 | 48 | 4.00 | +1455 | +30.3 |
| CANNON SIGHT KEPT | 34 | 34 | 34 | 2.83 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 33 | 33 | 33 | 2.75 | +0 | +0.0 |
| SHOTS IN THE MOVE | 326 | 221 | 32 | 2.67 | +745 | +23.3 |
| INVITES THE FIGHT | 82 | 82 | 30 | 2.50 | +1219 | +40.6 |
| SAFER THAN THE JOB | 30 | 30 | 30 | 2.50 | +3103 | +103.4 |
| FALLBACK BY WORTH | 127 | 127 | 29 | 2.42 | +1496 | +51.6 |
| BEST FACING | 24 | 24 | 24 | 2.00 | +1504 | +62.7 |
| WALKS TO THE FIGHT | 33 | 33 | 23 | 1.92 | +459 | +20.0 |
| FOLLOW UP WEIGHED | 22 | 22 | 22 | 1.83 | +5140 | +233.7 |
| MAX FOR POSITIONING | 144 | 91 | 22 | 1.83 | +406 | +18.5 |
| KILLS COUNT | 57 | 54 | 21 | 1.75 | +420 | +20.0 |
| STOPS SHORT OF THE FLANK | 21 | 21 | 21 | 1.75 | +940 | +44.7 |
| REDIRECT COUNTER | 74 | 42 | 18 | 1.50 | +1652 | +91.8 |
| BEST OVERALL | 17 | 17 | 17 | 1.42 | +984 | +57.9 |
| MARCH CHECK | 19 | 19 | 17 | 1.42 | +816 | +48.0 |
| RESERVE FALL BACK | 17 | 17 | 17 | 1.42 | +303 | +17.8 |
| ADVANCE LANE KEPT | 16 | 16 | 16 | 1.33 | +0 | +0.0 |
| RISK BY ARC | 72 | 71 | 15 | 1.25 | +830 | +55.4 |
| SCOUT WAITS | 15 | 15 | 15 | 1.25 | +0 | +0.0 |
| CANNON PLANNED TARGET | 81 | 81 | 12 | 1.00 | +121 | +10.1 |
| CHARGE NOW WEIGHED | 12 | 12 | 12 | 1.00 | +1405 | +117.1 |
| MARCH ODDS | 12 | 12 | 12 | 1.00 | +232 | +19.3 |
| MISSILES IN THE MOVE | 106 | 65 | 11 | 0.92 | +179 | +16.2 |
| SHOT REPLANNED | 11 | 11 | 11 | 0.92 | +0 | +0.0 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.83 | +0 | +0.0 |
| KEEPS ITS TARGET | 56 | 56 | 10 | 0.83 | +178 | +17.8 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 0.83 | +693 | +69.3 |
| RANDOM MOVE BY FIGURES | 14 | 14 | 10 | 0.83 | +84 | +8.4 |
| WHOLE FIGHT GAIN | 17 | 14 | 10 | 0.83 | +426 | +42.6 |
| HUNT IN PAIRS | 23 | 14 | 9 | 0.75 | +252 | +28.0 |
| BEST PREY | 17 | 17 | 8 | 0.67 | +195 | +24.4 |
| CAST JOB | 14 | 14 | 8 | 0.67 | +58 | +7.3 |
| REDIRECT WEIGHED | 8 | 8 | 8 | 0.67 | +244 | +30.5 |
| SET UP TOGETHER | 23 | 22 | 8 | 0.67 | +544 | +68.0 |
| WAR ENGINE JOBS | 21 | 21 | 8 | 0.67 | -524 | -65.5 |
| CHAFF PASSED | 7 | 7 | 7 | 0.58 | -35 | -5.0 |
| LOST CHARGE | 72 | 72 | 7 | 0.58 | +133 | +19.0 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 7 | 0.58 | +584 | +83.5 |
| THROUGH LINE OF FIRE | 7 | 7 | 7 | 0.58 | +608 | +86.9 |
| BLOCKED WHEEL | 6 | 6 | 6 | 0.50 | +420 | +70.0 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.50 | -290 | -48.2 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.50 | -103 | -17.1 |
| WEARS DOWN | 29 | 28 | 6 | 0.50 | +96 | +16.0 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.42 | +23 | +4.5 |
| MANOEUVRE | 5 | 5 | 5 | 0.42 | +490 | +98.1 |
| MISSILES NEXT TURN | 134 | 76 | 5 | 0.42 | +3 | +0.6 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 0.42 | +11 | +2.2 |
| WHO HITS BACK | 5 | 5 | 5 | 0.42 | +296 | +59.2 |
| COMBAT PIVOT | 4 | 4 | 4 | 0.33 | +0 | +0.0 |
| MAKE SURE TOGETHER | 12 | 11 | 4 | 0.33 | +170 | +42.6 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.33 | +256 | +64.0 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.25 | +43 | +14.4 |
| NEEDED THERE | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| OVERRUNS AWAY | 9 | 9 | 3 | 0.25 | +210 | +69.9 |
| CASTING BLOCK | 2 | 2 | 2 | 0.17 | +13 | +6.3 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.17 | +158 | +79.0 |
| MOVE AND CAST | 2 | 2 | 2 | 0.17 | +34 | +17.2 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| BACKUP TARGETS | 37 | 23 | 1 | 0.08 | +4 | +4.4 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.08 | +0 | +0.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.08 | +36 | +35.6 |
| LONG SHOT | 16 | 16 | 1 | 0.08 | +9 | +8.8 |
| OPENS UP | 3 | 3 | 1 | 0.08 | +46 | +46.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +52 | +51.9 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.08 | -62 | -61.8 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.08 | +144 | +143.7 |
| STANDS TO CAST | 1 | 1 | 1 | 0.08 | -2 | -2.1 |
| STUCK PIVOT | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| SURE REACH TOGETHER | 11 | 8 | 1 | 0.08 | +20 | +20.5 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 18 | 18 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 9 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 147 | not checked | - | - | - | - |
| GIVES UP | 25 | 25 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 4 | 4 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 7 | 7 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 8 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 6 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 26 | 26 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NOT NEEDED | 8 | 8 | 0 | 0.00 | - | - |
| NOT TURNED | 154 | 154 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 13 | not checked | - | - | - | - |
| OPENS A LANE | 9 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 923 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 12 | 12 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 49 | not checked | - | - | - | - |
| STABLE ROLE | 261 | 259 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| TURN WORTH | 8 | 8 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: fw-on-db7ca9c-p2b

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.50 | 12.58 | 56.4 |
| TURN GATE | gate | 0.50 | 1.33 | 64.8 |
| FALLBACK | gate | 0.58 | 0.83 | 66.2 |
| WAR ENGINE JOBS | rule | 0.58 | 0.08 | 65.5 |
| CHAFF PASSED | rule | 0.50 | - | 5.9 |
| PURSUES BIG PREY | rule | 0.25 | 0.25 | 48.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.33 | 17.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.25 | 60.3 |
| SUPPORT REQUEST | gate | 0.08 | 0.25 | 35.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.17 | 0.08 | 12.6 |
| MARCH ODDS | rule | 0.08 | 0.17 | 14.1 |
| PATHS CROSS | rule | 0.08 | 0.17 | 53.4 |
| CHARGE NOW WEIGHED | rule | - | 0.17 | 52.4 |
| NO REASON | gate | 0.17 | - | 59.9 |
| AFTERMATH BAND | gate | 0.08 | - | 3.8 |
| BIG CHARACTER SAFETY | rule | 0.08 | - | 5.5 |
| CANNON PLANNED TARGET | rule | 0.08 | - | 14.6 |
| FIGHT ORDER BAND | gate | - | 0.08 | 0.7 |
| PIVOT GUARDS FLANK | rule | - | 0.08 | 61.8 |
| STANDS TO CAST | rule | - | 0.08 | 2.1 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | - | 5.5 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 26.7 |

### Plans: fw-on-db7ca9c-p2b

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 8.8 | 22% | 599 | 316 | 53% |
| Mine | charge | 2.6 | 68% | 296 | 285 | 96% |
| Mine | close in | 5.3 | 22% | 619 | 180 | 29% |
| Mine | hold | 3.4 | 41% | 291 | 0 | 0% |
| Mine | join | 0.8 | 100% | 16 | 0 | 0% |
| Mine | shoot | 9.2 | 61% | 260 | 520 | 200% |
| Mine | support | 5.3 | 97% | 178 | 0 | 0% |
| Opponent | advance | 15.1 | 11% | 1212 | 365 | 30% |
| Opponent | charge | 4.8 | 52% | 367 | 439 | 120% |
| Opponent | close in | 5.7 | 21% | 581 | 186 | 32% |
| Opponent | hold | 3.0 | 33% | 196 | 0 | 0% |
| Opponent | join | 0.2 | 100% | 11 | 0 | 0% |
| Opponent | shoot | 2.2 | 81% | 69 | 297 | 431% |
| Opponent | support | 10.5 | 91% | 407 | 0 | 0% |

### Packages: hunt the guns, fw-on-db7ca9c-p2b

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Opponent | 0.4 | 5 | 0 | 0% | 0% | 0% | - | 452 | 0 | 0% | 131 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 27 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.7 | 2 | 0 | 0% | 0% | 0% | - | 633 | 0 | 0% | 151 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 750 |
| Tomb Kings of Khemri | 2.0 | 2 | 0 | 0% | 0% | 0% | - | 272 | 0 | 0% | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |

### Battle groups: fw-on-db7ca9c-p2b

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.2 | 20% | 48% | 4% | 100% | 21% | 8% | 17% | 54% | 0% |
| Mine | REDIRECT COUNTER | 1.4 | 41% | 57% | 0% | - | 0% | 0% | 29% | 71% | 0% |
| Opponent | COUNTER-CHARGE COVER | 8.2 | 21% | 76% | 14% | 67% | 22% | 22% | 17% | 39% | 0% |
| Opponent | REDIRECT COUNTER | 4.8 | 21% | 75% | 17% | 50% | 0% | 0% | 20% | 70% | 10% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-on-db7ca9c-p2b

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 89 | 50% | 2.0 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Mine | Character | 43 | 51 (43) | 51 | 0 | 43 | 16% | 2.8 | 32 (9) | 73 (21) | 39 (4) | 74 (21) | 34 (13) |
| Mine | Clean-up | 1 | 211 (1) | 0 | 211 | 0 | 100% | - | - | 211 (1) | - | 211 (1) | - |
| Mine | Fast Hammer | 22 | 75 (22) | 29 | 47 | 53 | 18% | 3.0 | 60 (10) | 115 (9) | 28 (3) | 87 (15) | 45 (7) |
| Mine | Hammer | 12 | 38 (12) | 34 | 4 | 56 | 8% | 2.5 | 0 (5) | 18 (5) | 225 (2) | 47 (7) | 26 (5) |
| Mine | Holder | 6 | 26 (6) | 6 | 20 | 0 | 17% | 3.0 | 49 (1) | 24 (3) | - | 24 (3) | 49 (1) |
| Mine | Shooter | 19 | 88 (19) | 26 | 62 | 43 | 0% | 1.6 | 78 (3) | 87 (12) | 97 (4) | 130 (12) | 23 (7) |
| Mine | War machine | 27 | 44 (27) | 44 | 0 | 47 | 4% | 1.1 | 0 (5) | 62 (19) | 0 (3) | 159 (4) | 25 (23) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 59 | 25% | 4.3 | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 38 | 76 (38) | 41 | 35 | 47 | 34% | 2.6 | 86 (18) | 13 (9) | 132 (11) | 85 (31) | 38 (7) |
| Opponent | Character | 28 | 63 (28) | 63 | 0 | 23 | 25% | 1.9 | 79 (10) | 60 (14) | 0 (2) | 68 (17) | 60 (9) |
| Opponent | Clean-up | 7 | 21 (7) | 21 | 0 | 50 | 43% | 4.0 | 0 (4) | 47 (3) | - | 23 (6) | 0 (1) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Fast Hammer | 12 | 22 (12) | 2 | 20 | 52 | 42% | 2.3 | 0 (4) | 21 (6) | 83 (2) | 14 (9) | 53 (3) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 81 | 60% | 2.0 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Hammer | 29 | 44 (29) | 38 | 6 | 59 | 14% | 2.8 | 110 (3) | 18 (19) | 130 (7) | 24 (17) | 78 (12) |
| Opponent | Holder | 8 | 72 (8) | 14 | 58 | 19 | 50% | 2.0 | 130 (2) | 43 (5) | 189 (1) | 114 (5) | 25 (3) |
| Opponent | Shooter | 7 | 56 (7) | 16 | 41 | 62 | 0% | 1.7 | 0 (2) | 189 (2) | 8 (3) | 75 (5) | 11 (2) |
| Opponent | War machine | 2 | 118 (2) | 118 | 0 | 0 | 0% | 1.0 | - | 161 (1) | 76 (1) | - | 118 (2) |
| Opponent | Wizard | 6 | 10 (6) | 10 | 0 | 61 | 0% | 1.2 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |

### Charged fights: fw-on-db7ca9c-p2b

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 5 | 424 | 134 | 0.8 | 1.2 | 167 | 0 | +167 | 2 of 4 | 4 of 4 | +350 | +106 |
| Mine | Grand Cathay | 4 | 314 | 342 | 3.0 | 1.1 | 114 | 62 | +52 | 3 of 12 | 11 of 12 | -369 | +91 |
| Mine | High Elf Realms | 3 | 242 | 765 | 4.7 | 1.1 | 164 | 0 | +164 | 5 of 14 | 13 of 14 | +196 | +159 |
| **Mine** | all armies | 12 | 342 | 361 | 2.5 | 1.1 | 144 | 25 | +120 | 10 of 30 | 28 of 30 | +93 | +124 |
| Opponent | Grand Cathay | 1 | 590 | 1080 | 3.0 | 1.7 | 360 | 0 | +360 | 3 of 3 | 3 of 3 | +506 | +287 |
| Opponent | Ogre Kingdoms | 3 | 82 | 282 | 3.7 | 1.2 | 77 | 3 | +74 | 3 of 11 | 6 of 11 | +48 | +80 |
| Opponent | Skaven | 1 | 281 | 477 | 3.0 | 1.3 | 159 | 0 | +159 | 3 of 3 | 3 of 3 | +288 | +94 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 932 | 4.0 | 1.0 | 233 | 0 | +233 | 1 of 4 | 4 of 4 | - | +233 |
| Opponent | Vampire Counts | 2 | 0 | 706 | 2.5 | 1.2 | 283 | 9 | +274 | 3 of 5 | 3 of 5 | +434 | +234 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 3 | 50 | 707 | 4.7 | 1.4 | 151 | 51 | +100 | 6 of 14 | 7 of 14 | +207 | +41 |
| **Opponent** | all armies | 12 | 106 | 572 | 3.3 | 1.3 | 172 | 20 | +152 | 19 of 40 | 26 of 40 | +236 | +124 |

### Effective charges: fw-on-db7ca9c-p2b

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 4 | 0 | 0 | 0 | 0 | 0 | 4 (net +167) | 0 | 0% (0 of 4) |
| Mine | Grand Cathay | 12 | 0 | 0 | 1 (net +110) | 0 | 2 (net +50) | 8 (net +52) | 1 | 9% (1 of 11) |
| Mine | High Elf Realms | 14 | 0 | 0 | 1 (net +66) | 4 (net +237) | 4 (net +181) | 4 (net +93) | 1 | 8% (1 of 13) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 1 (net +270) | 0 | 0 | 2 (net +405) | 0 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 11 | 1 (net +95) | 0 | 3 (net +76) | 2 (net +22) | 0 | 1 (net +150) | 4 | 43% (3 of 7) |
| Opponent | Skaven | 3 | 2 (net +144) | 0 | 1 (net +189) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 1 (net +442) | 0 | 0 | 2 (net +170) | 1 | 33% (1 of 3) |
| Opponent | Vampire Counts | 5 | 1 (net +641) | 0 | 1 (net +0) | 1 (net +126) | 0 | 2 (net +300) | 0 | 20% (1 of 5) |
| Opponent | Wood Elf Realms | 14 | 3 (net +215) | 0 | 0 | 3 (net +196) | 2 (net +52) | 5 (net -20) | 1 | 0% (0 of 13) |

### Charged fights, damage counted: fw-on-db7ca9c-p2b

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 178 | 88 | +88 | 88 | 0 | +88 | +49.4 |
| Mine | 76-89% | 4 | 256 | 201 | +237 | 266 | 39 | +227 | +88.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 305 | 199 | +91 | 189 | 58 | +131 | +43.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 397 | 95 | +138 | 138 | 0 | +138 | +34.7 |
| Mine | No odds | 2 | 366 | 172 | +92 | 92 | 0 | +92 | +25.2 |
| Mine | All fights | 30 | 312 | 169 | +120 | 176 | 36 | +140 | +44.7 |
| Opponent | Long shot (under 50%) | 7 | 327 | 274 | +239 | 275 | 32 | +244 | +74.4 |
| Opponent | Effective (55-75%) | 7 | 248 | 250 | +161 | 165 | 37 | +128 | +51.7 |
| Opponent | 76-89% | 6 | 294 | 168 | +127 | 175 | 37 | +138 | +47.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 405 | 220 | +150 | 230 | 83 | +147 | +36.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 600 | 100 | +52 | 84 | 0 | +84 | +14.1 |
| Opponent | No odds | 6 | 187 | 173 | +102 | 108 | 12 | +96 | +51.4 |
| Opponent | All fights | 40 | 324 | 214 | +152 | 193 | 44 | +148 | +45.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-on-db7ca9c-p2b | move | 182 | 40 (22%) | 32 (18%) | 14 (8%) | 128 (70%) |
| fw-on-db7ca9c-p2b | objective | 136 | 22 (16%) | 18 (13%) | 7 (5%) | 107 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827, L0934, L1026 |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Invocation of Nehek | Opponent | L0827 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

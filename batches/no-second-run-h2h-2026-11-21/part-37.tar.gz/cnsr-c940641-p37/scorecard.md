# Doctrine scorecard: cnsr-c940641-p37

### Scorecard: cnsr-c940641-p37

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 1315 |
| L0122 | 2 | 1 | Mine | - | - | 4 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 72 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 966 |
| **Average** | | | Mine | 0% | 0.0 | 4.0 | 1.0 | 3.0 | 0.3 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 0.0 | 2.5 | 1.3 | 2.0 | 0.0 | 0.0 | 0.0 | 784.3 |

### KPIs: cnsr-c940641-p37

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 7) | 65% (11 of 17) | 46% (11 of 24) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 100% (4 of 4); on the table 100% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 41% (37 of 90) | - | 41% (37 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (37 of 77) | - | 48% (37 of 77) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | - | 67% (4 of 6) |
| Points that never fought | lower | 65% (3732 of 5699) | 69% (4114 of 6000) | 67% (7846 of 11699) |
|   infantry points that never fought | lower | 69% (1545 of 2239) | 87% (1836 of 2111) | 78% (3381 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 38% (6 of 16) | 76% (19 of 25) | 61% (25 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 3.7 uses a game | 0.0 uses a game | 100% (4 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 31% (1221 of 3916) | 65% (2861 of 4382) | 49% (4082 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (34%) | - | 6.0 (34%) |
| MARCHED: its unit marched | 5.3 (30%) | - | 5.3 (30%) |
| IN COMBAT: engaged in combat | 2.0 (11%) | - | 2.0 (11%) |
| GONE: slain | 2.3 (13%) | - | 2.3 (13%) |
| STUPIDITY: Stupidity | 2.0 (11%) | - | 2.0 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 0.7 | 7.0 | 12.3 | 0.0 | 2.0 |
| not cast | 2.7 | 3.3 | 3.0 | 17.7 | 2.0 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (60%) | 0.0 (0%) | 6.0 (34%) | 1.0 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.3 (30%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (11%) | 1.0 (50%) | 0.0 (0%) |
| GONE: slain | 0.7 (25%) | 0.7 (20%) | 1.0 (33%) | 2.3 (13%) | 0.0 (0%) | 1.7 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.7 (22%) | 2.0 (11%) | 0.0 (0%) | 1.0 (4%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (75%) | 0.7 (20%) | 1.3 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.7 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.3 a game | 0.0 a game | 4.2 a game |
| stood (cast and not dispelled) | 56% (14 of 25) | - | 56% (14 of 25) |
| the unit moved after it | 64% (9 of 14) | - | 64% (9 of 14) |
| it charged on its next turn | 0% (0 of 14) | - | 0% (0 of 14) |
| the enemy charged it first | 29% (4 of 14) | - | 29% (4 of 14) |
| it fought by the end of its next turn | 29% (4 of 14) | - | 29% (4 of 14) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 14) | - | 0% (0 of 14) |
| none of these (no charge, no fight, no charge escaped) | 71% (10 of 14) | - | 71% (10 of 14) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (11 of 17) | 64% (124 of 194) | 64% (135 of 211) |
|   cavalry | - | 55% (16 of 29) | 55% (16 of 29) |
|   character | - | 56% (14 of 25) | 56% (14 of 25) |
|   chariot | - | 0% (0 of 1) | 0% (0 of 1) |
|   infantry | 65% (11 of 17) | 63% (40 of 63) | 64% (51 of 80) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | - | 69% (44 of 64) | 69% (44 of 64) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (67%) | 0.7 (3%) | 2.0 (8%) |
| CHARGED: it charged | 0.0 (0%) | 3.3 (14%) | 3.3 (13%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| NO TARGET IN RANGE | 0.7 (33%) | 9.7 (41%) | 10.3 (41%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (3%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 3.7 (16%) | 3.7 (14%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (3%) | 0.7 (3%) |
| OTHER BAR | 0.0 (0%) | 4.0 (17%) | 4.0 (16%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 1.7 | 77% | 3.4 pts | 25 pts |
| character | 4.7 | 3.3 | 64% | 6.5 pts | 30 pts |
| infantry | 25.7 | 13.0 | 66% | 4.7 pts | 120 pts |
| monster | 3.3 | 1.0 | 80% | 3.1 pts | 10 pts |
| war machine | 14.7 | 8.0 | 66% | 5.4 pts | 79 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 4.7 | 2.8 |
| Charges that made contact a game | 1.0 | 4.0 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.15 contact (20 units) | 0.52 declared, 0.44 contact (27 units) | 0.36 declared, 0.32 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 100% (3 of 3) | 33% (1 of 3) | - | 67% (4 of 6) |
| Character on its own | 67% (2 of 3) | 67% (2 of 3) | 0% (0 of 2) | 50% (4 of 8) |
| Infantry | 71% (5 of 7) | 29% (2 of 7) | - | 50% (7 of 14) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 50% (1 of 2); on the table 50% | 41% (37 of 90) | 65% | 38% (6 of 16) | 100% (4 of 4); 3.7 uses a game | 50% (1 of 2); 1.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 92% | 85% (17 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (4 of 4); on the table 100% | - | 22% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p37, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | - | 33% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p37

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | - | 20% (3 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (4 of 16) | 45% (37 of 83) |
| Strategy | Support requests answered (helper made contact too) | - | 75% (3 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 33% (3 of 9) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 33% (3 of 9) | 100% (4 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 56.7 | 784.3 |
| Movement | Fights charged into per game | 1.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 2 of 7, net -98 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 7, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 7 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 4 of 7, net +208 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.7 | 27.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (5 of 11) | 59% (48 of 82) |
| Shooting | Points destroyed by shooting units | 0.0 | 174.3 |
| Shooting | War machine shots | - | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 70% (31 of 44) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 6.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (5 of 18) | - |
| Magic | Wounds caused by magic missiles | 14.3 | - |
| Magic | Wounds caused by other spells | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 126.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.3 / 2.0 / 0.0 | 2.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 269.0 | 228.0 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | +153 | +119 |
| Combat | Net per 100 charger points, damage counted | +18.3 | +27.9 |
| Combat | First round won (charged fights) | 100% | 62% |
| Combat | Net points per charged fight | +164 | +86 |
| Combat | Net points per supported fight / lone fight | - / +164 | +208 / -36 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 5 of 8 |
| Game | Points lost | 519.7 | 448.7 |
| Game | VP from objectives | 653.3 | 670.0 |
| Game | Lone holders (player turns) | 0.0 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -53 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 968
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p37

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +117.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +40.4 | 0.0 | 0.0 |
| ARMY TABLE | 17.7 | +190.6 | 0.0 | 289.3 | 14.3 | +339.4 | 0.0 | 184.0 |
| BACKUP TARGETS | 0.7 | +2.0 | 0.0 | 17.3 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.3 | +0.0 | 27.0 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 14.7 | +147.4 | 291.0 | 180.0 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 6.3 | +499.2 | 120.0 | 181.3 | - | - | - | - |
| CASTS AFTER FRIENDS | 4.7 | +0.0 | 0.0 | 31.7 | - | - | - | - |
| CATCH FLIERS | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +43.5 | 0.0 | 0.0 | 1.3 | +74.1 | 0.0 | 48.0 |
| CHAFF PASSED | - | - | - | - | 1.3 | +0.0 | 0.0 | 24.0 |
| CHALLENGE BY POINTS | 1.3 | +23.6 | 0.0 | 107.3 | 1.0 | +18.5 | 0.0 | 48.0 |
| CHARACTER GUNS | - | - | - | - | 7.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.7 | -925.2 | 0.0 | 418.0 | 8.7 | -518.4 | 0.0 | 18.3 |
| CHARGE NOW FIRST | - | - | - | - | 3.3 | +0.0 | 319.7 | 0.0 |
| CHARIOT NO STATIC JOB | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 12.7 | +0.0 | 0.0 | 124.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 5.0 | +664.2 | 198.0 | 63.3 | - | - | - | - |
| COVER ONCE | 7.0 | -289.7 | 0.0 | 225.0 | 8.0 | -215.1 | 0.0 | 65.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -8.3 | 43.3 | 65.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 1.0 | -493.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +8.9 | 214.7 | 0.0 |
| EXACT ROUND | - | - | - | - | 2.7 | +28.6 | 271.0 | 65.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 4.7 | +29.2 | 507.3 | 65.0 |
| FALLS SHORT | 16.7 | +334.3 | 0.0 | 388.0 | 10.3 | +77.5 | 0.0 | 285.3 |
| FEATURE BUFFS | 16.3 | +458.8 | 0.0 | 187.0 | 0.7 | +3.5 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 2.0 | +127.0 | 17.3 | 65.0 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 67.3 | +6212.5 | 168.0 | 1348.0 | 136.0 | +4851.7 | 2050.0 | 1159.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 298.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 5.0 | +526.5 | 529.0 | 65.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -18.3 | 48.0 | 43.3 | 0.7 | -5.5 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -13.1 | 21.7 | 0.0 |
| GOAL WALK | 13.7 | +2298.1 | 0.0 | 182.7 | - | - | - | - |
| GUN FIGURES | - | - | - | - | 1.7 | +31.6 | 181.3 | 0.0 |
| GUN MASK | - | - | - | - | 2.3 | +134.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 85.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 10.7 | +0.0 | 0.0 | 418.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 12.3 | +0.0 | 0.0 | 311.0 | 5.3 | +0.0 | 0.0 | 18.3 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 21.7 | 4.0 | +0.0 | 0.0 | 24.0 |
| HIS MOVE AND SHOT | 5.3 | -95.6 | 0.0 | 193.0 | 3.3 | -79.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 4.0 | +0.0 | 0.0 | 120.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 21.7 | 5.7 | +0.0 | 0.0 | 24.0 |
| HIS RANDOM MOVE | - | - | - | - | 10.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.0 | +1513.7 | 0.0 | 825.3 | 48.3 | +1690.6 | 0.0 | 393.3 |
| HIS SHOTS BY HIS RUN | 42.0 | +851.0 | 0.0 | 808.7 | 38.0 | +1031.4 | 0.0 | 449.0 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +57.6 | 65.0 | 65.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 39.0 | +0.0 | 0.0 | 508.0 | 11.3 | +0.0 | 0.0 | 48.0 |
| HOLDER ASSIGNMENT | 13.0 | +1496.3 | 0.0 | 224.7 | 8.7 | +993.1 | 0.0 | 48.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 4.3 | -204.8 | 511.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +165.1 | 0.0 | 65.0 |
| IDLE COST | 10.7 | -82.1 | 0.0 | 288.3 | 2.7 | -50.5 | 0.0 | 18.3 |
| JOINT CHARGE NOW | - | - | - | - | 3.0 | -143.6 | 400.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 8.0 | +0.0 | 161.0 | 190.0 | 6.0 | +0.0 | 217.3 | 114.3 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 2.7 | +8.5 | 232.0 | 65.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +1.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +8.0 | 0.0 | 44.3 | 2.0 | -15.5 | 0.0 | 65.0 |
| MARCH BY THE SUM | 1.3 | +145.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +16.4 | 0.0 | 27.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +1.5 | 0.0 | 27.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -149.5 | 0.0 | 27.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +58.3 | 0.0 | 190.3 | 1.3 | +33.2 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.7 | +333.2 | 0.0 | 252.0 | - | - | - | - |
| MISSILES NEXT TURN | 9.0 | +281.0 | 0.0 | 252.0 | - | - | - | - |
| MISSILES ON ONE TARGET | 2.7 | -93.2 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | - | - | - | - | 4.0 | +777.8 | 0.0 | 20.0 |
| MOVE ORDER | 0.7 | +0.0 | 17.3 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 2.0 | -49.9 | 0.0 | 300.0 | - | - | - | - |
| MOVE SPELL SPOT | 2.7 | +0.0 | 0.0 | 198.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 0.3 | +62.5 | 0.0 | 0.0 | 4.3 | +275.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 3.3 | +121.1 | 0.0 | 43.3 | 8.7 | +346.8 | 0.0 | 24.0 |
| NEXT CHARGE BY LIST | 1.7 | +135.0 | 48.0 | 43.3 | 2.3 | +236.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 4.7 | -138.9 | 529.0 | 65.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.7 | -0.9 | 0.0 | 118.3 | - | - | - | - |
| OFF BEST | 3.3 | -29.6 | 0.0 | 71.7 | 7.0 | -212.7 | 0.0 | 195.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -109.3 | 0.0 | 324.0 | 5.7 | -52.4 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.3 | +141.3 | 17.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.7 | -4.9 | 0.0 | 134.0 | 3.0 | -146.7 | 0.0 | 24.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +3.6 | 24.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 2.3 | +32.4 | 271.0 | 0.0 |
| PATHS CROSS | 0.3 | +0.5 | 0.0 | 0.0 | 0.3 | +2.9 | 0.0 | 18.3 |
| PLAN RESULT | 30.3 | +44.7 | 96.0 | 669.3 | 61.0 | +825.2 | 1290.7 | 745.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 37.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 1.7 | +0.0 | 0.0 | 0.0 | 6.7 | -109.7 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 6.7 | +974.9 | 0.0 | 0.0 | 17.3 | +940.5 | 0.0 | 260.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +5.9 | 0.0 | 0.0 | 0.7 | +8.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.7 | +194.6 | 0.0 | 92.3 | 2.0 | +41.3 | 0.0 | 72.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +9.4 | 0.0 | 110.7 | 1.3 | +34.6 | 0.0 | 24.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +8.8 | 17.3 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.0 | -7.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +2.6 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.3 | +30.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 4.3 | +3.9 | 314.3 | 65.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 3.3 | -90.7 | 472.7 | 65.0 |
| RUN DOWN | - | - | - | - | 4.7 | -46.0 | 529.0 | 65.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.3 | 0.0 | 21.7 | 0.3 | +8.4 | 0.0 | 20.0 |
| SET CREDITED ONCE | 2.0 | -28.2 | 0.0 | 54.3 | 2.3 | -267.7 | 0.0 | 65.0 |
| SET UP BY THE SET | 2.0 | +11.9 | 0.0 | 54.3 | 3.7 | +365.3 | 0.0 | 154.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 134.0 | 26.7 | +0.0 | 0.0 | 253.3 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +82.5 | 0.0 | 214.7 | 0.7 | +1.6 | 36.7 | 146.7 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.1 | 0.0 | 0.0 |
| SHOT RISK POINTS | 32.3 | -296.9 | 0.0 | 395.7 | 36.0 | +474.6 | 0.0 | 508.3 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 3.7 | +74.2 | 0.0 | 86.7 | 48.0 | +861.4 | 0.0 | 362.0 |
| SPELL OFF EDGE | 0.7 | +39.4 | 35.0 | 118.3 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.7 | +314.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +4.7 | 65.0 | 118.3 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -22.1 | 0.0 | 65.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 188.7 | 2.7 | +0.0 | 0.0 | 85.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -3.8 | 65.0 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 81.0 | 4.3 | +0.0 | 0.0 | 24.0 |
| STANDS STILL | 20.0 | +0.0 | 168.0 | 510.0 | 94.7 | +0.0 | 1521.0 | 860.7 |
| STAY WORTH | 4.3 | +24.3 | 0.0 | 21.7 | 68.3 | +56.9 | 467.0 | 390.0 |
| SUPPORT ADDS | 8.3 | +317.0 | 0.0 | 147.7 | 1.3 | +34.2 | 0.0 | 18.3 |
| SUPPORT WORKED OUT | 8.3 | +317.0 | 0.0 | 147.7 | 1.3 | +34.2 | 0.0 | 18.3 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | 1.0 | +4.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 31.7 | 2.3 | +0.0 | 0.0 | 42.3 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -9.3 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 10.0 | 0.7 | +0.0 | 0.0 | 20.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 124.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 61.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.0 | +0.0 | 0.0 | 521.3 | 60.0 | +0.0 | 0.0 | 467.0 |
| TIED UP BY THE SUM | - | - | - | - | 1.0 | +83.0 | 65.0 | 0.0 |
| TIME ON OUR SIDE | 7.3 | +178.2 | 0.0 | 86.7 | 47.7 | +395.3 | 36.7 | 240.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | +22.0 | 0.0 | 65.0 |
| WHO HITS BACK | 0.7 | +31.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.0 | -438.4 | 0.0 | 253.7 | 1.3 | -324.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +75.3 | 17.3 | 0.0 |
| WOUNDS ON THE RANKS | 5.7 | +960.9 | 0.0 | 90.7 | 0.7 | +1.8 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p37

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 292 | 284 | 72 | 24.00 | +786 | +10.9 |
| HIS SHOTS BY HIS RUN | 240 | 231 | 69 | 23.00 | +700 | +10.1 |
| ARMY TABLE | 96 | 96 | 63 | 21.00 | +1434 | +22.8 |
| HOLDER ASSIGNMENT | 65 | 65 | 63 | 21.00 | +4290 | +68.1 |
| SHOT RISK POINTS | 205 | 197 | 43 | 14.33 | +591 | +13.7 |
| LEGAL CHARGES ONLY | 42 | 42 | 42 | 14.00 | +0 | +0.0 |
| FIVE ACTION | 610 | 600 | 35 | 11.67 | +2468 | +70.5 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -727 | -23.4 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| GOAL WALK | 41 | 40 | 24 | 8.00 | +4107 | +171.1 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 165 | 153 | 20 | 6.67 | +104 | +5.2 |
| CANNON PLANNED TARGET | 44 | 44 | 18 | 6.00 | +63 | +3.5 |
| REDIRECT FOR A FRIEND IN REACH | 17 | 17 | 17 | 5.67 | +113 | +6.6 |
| CASTING BLOCK | 19 | 19 | 15 | 5.00 | +178 | +11.9 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +2334 | +194.5 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| MOVE TO CHARGE COMPUTED | 14 | 12 | 10 | 3.33 | +564 | +56.4 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | -431 | -47.9 |
| WOUNDS ON THE RANKS | 19 | 18 | 9 | 3.00 | +775 | +86.1 |
| FOUR ROUNDS | 15 | 15 | 8 | 2.67 | +703 | +87.8 |
| PROMISE BY ITS OWN SUM | 25 | 25 | 8 | 2.67 | -329 | -41.1 |
| QUARTER ODDS | 72 | 72 | 8 | 2.67 | +978 | +122.2 |
| SUPPORT ADDS | 29 | 29 | 8 | 2.67 | +230 | +28.8 |
| SUPPORT WORKED OUT | 29 | 29 | 8 | 2.67 | +230 | +28.8 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +126 | +18.0 |
| NEXT CHARGE BY LIST | 12 | 12 | 7 | 2.33 | +556 | +79.5 |
| SET UP BY THE SET | 17 | 16 | 7 | 2.33 | +203 | +29.0 |
| REDIRECT COUNTER | 17 | 15 | 6 | 2.00 | +321 | +53.5 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 73 | 69 | 5 | 1.67 | +661 | +132.1 |
| COVER ONCE | 45 | 32 | 5 | 1.67 | +77 | +15.4 |
| MAX FOR POSITIONING | 19 | 18 | 5 | 1.67 | +11 | +2.2 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 5 | 1.67 | +27 | +5.4 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 81 | 56 | 4 | 1.33 | +83 | +20.8 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 40 | 28 | 4 | 1.33 | +32 | +7.9 |
| MANOEUVRE | 9 | 9 | 4 | 1.33 | +30 | +7.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +436 | +108.9 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 4 | 1.33 | +26 | +6.5 |
| RESERVE MOVE SPELL | 4 | 4 | 4 | 1.33 | +93 | +23.2 |
| RISK BY ARC | 13 | 13 | 4 | 1.33 | +78 | +19.5 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| STAY WORTH | 218 | 204 | 4 | 1.33 | +15 | +3.8 |
| THE RISK READS HIS RUN | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 3 | 1.00 | +113 | +37.6 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +304 | +101.3 |
| SHOTS IN THE MOVE | 155 | 128 | 3 | 1.00 | +56 | +18.6 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +161 | +53.6 |
| FEATURE BUFFS | 51 | 50 | 2 | 0.67 | +21 | +10.6 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FRIEND SHOOTS FIRST | 4 | 4 | 2 | 0.67 | +5 | +2.5 |
| GUN MASK | 7 | 7 | 2 | 0.67 | +113 | +56.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -4 | -2.2 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +10 | +5.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +8 | +3.9 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +26 | +13.1 |
| SURE REACH TOGETHER | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +27 | +13.4 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +70 | +35.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +351 | +350.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +121 | +121.3 |
| FALL BACK GOOD ORDER | 14 | 14 | 1 | 0.33 | +34 | +34.2 |
| FIGHT TO THE END | 6 | 6 | 1 | 0.33 | +67 | +67.4 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| HIS MOVE AND SHOT | 26 | 26 | 1 | 0.33 | +1 | +1.4 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +37 | +36.6 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +3 | +3.2 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 36 | 35 | 1 | 0.33 | +47 | +47.2 |
| ONE JOINT FIGURE | 4 | 4 | 1 | 0.33 | +67 | +67.4 |
| OVERRUNS AWAY | 7 | 7 | 1 | 0.33 | +48 | +47.7 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 1 | 0.33 | +15 | +14.7 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -8 | -7.5 |
| SHOTS AFTER THE MOVES | 17 | 17 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 8 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 14 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 21 | 21 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 10 | 10 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 56 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 15 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 25 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 47 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 53 | 52 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 12 | 12 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 22 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 30 | 30 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 151 | 149 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 13 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 20 | 16 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 17 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 8 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 32 | 20 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 29 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 274 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 10 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 13 | 12 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 92 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 28 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 344 | 338 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 8 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 273 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 13 | 12 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p37

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 6.00 | 17.2 |
| ARMY TABLE | rule | 1.67 | 1.33 | 16.9 |
| PROMISE BY ITS OWN SUM | rule | - | 2.67 | 41.1 |
| HOLDER ASSIGNMENT | rule | 1.67 | 0.33 | 10.9 |
| JOINT CHARGE NOW | rule | - | 1.67 | 125.0 |
| CANNON PLANNED TARGET | rule | - | 1.00 | 4.0 |
| AFTERMATH BAND | gate | 0.33 | 0.33 | 3.2 |
| MARCH OF THE TABLE | rule | 0.67 | - | 2.2 |
| RULE SWITCHED OFF | gate | - | 0.67 | 121.8 |
| NO REASON | gate | 0.33 | - | 29.1 |
| REFUSING RETIRES | rule | - | 0.33 | 7.5 |
| RESERVE FALL BACK | rule | - | 0.33 | 22.1 |
| WHO HITS BACK | rule | 0.33 | - | 2.2 |

### Plans: cnsr-c940641-p37

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 26.0 | 92% | 2769 | 0 | 0% |
| Mine | shoot | 4.0 | 25% | 401 | 45 | 11% |
| Mine | support | 0.3 | 100% | 9 | 0 | 0% |
| Opponent | charge | 4.3 | 46% | 447 | 156 | 35% |
| Opponent | move | 33.0 | 93% | 1155 | 0 | 0% |
| Opponent | shoot | 23.3 | 89% | 555 | 669 | 121% |
| Opponent | support | 0.3 | 100% | 17 | 0 | 0% |

### Battle groups: cnsr-c940641-p37

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 27% | 33% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p37

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 75 | 50% | 2.5 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 23 (15) | 23 | 0 | 23 | 27% | 2.9 | - | 32 (7) | 0 (2) | 18 (6) | 33 (3) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 67 | 33% | 3.5 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 86 (6) | 36 | 50 | 35 | 50% | 4.0 | 71 (1) | 104 (3) | 59 (2) | 63 (4) | 124 (2) |
| Mine | Holder | 5 | 0 (5) | 0 | 0 | 0 | 60% | 3.5 | 0 (4) | - | 0 (1) | 0 (2) | 0 (3) |
| Mine | Shooter | 2 | 77 (2) | 0 | 77 | 100 | 0% | 1.0 | - | 154 (1) | 0 (1) | 77 (2) | - |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 2.3 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 2 | 139 (2) | 0 | 139 | 100 | 0% | 1.5 | 278 (1) | 0 (1) | - | 139 (2) | - |
| Opponent | Character | 8 | 66 (8) | 66 | 0 | 0 | 38% | 2.2 | 0 (1) | 78 (6) | 0 (1) | 0 (4) | 95 (4) |
| Opponent | Clean-up | 6 | 0 (6) | 0 | 0 | 0 | 17% | 2.8 | 0 (1) | 0 (5) | - | 0 (5) | 0 (1) |
| Opponent | Fast Hammer | 4 | 11 (4) | 11 | 0 | 47 | 50% | 1.5 | 0 (1) | 33 (1) | 0 (2) | 14 (3) | 0 (1) |
| Opponent | Hammer | 3 | 30 (3) | 30 | 0 | 0 | 67% | 3.0 | 0 (1) | 208 (1) | 0 (1) | 104 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | Shooter | 10 | 86 (10) | 13 | 73 | 30 | 10% | 2.3 | 174 (2) | 77 (8) | - | 117 (8) | 0 (2) |
| Opponent | War machine | 12 | 29 (12) | 29 | 0 | 37 | 8% | 2.1 | 35 (10) | - | 0 (2) | 0 (2) | 36 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | - | - | - | - | - |

### Charged fights: cnsr-c940641-p37

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 126 | 164 | 1.0 | 1.0 | 164 | 0 | +164 | 0 of 3 | 3 of 3 | - | +164 |
| Opponent | Dwarfen Mountain Holds | 2 | 234 | 52 | 1.5 | 1.3 | 35 | 40 | -5 | 0 of 3 | 2 of 3 | -68 | +26 |
| Opponent | Tomb Kings of Khemri | 1 | 55 | 902 | 5.0 | 1.6 | 180 | 39 | +141 | 5 of 5 | 3 of 5 | +301 | -98 |
| **Opponent** | all armies | 3 | 174 | 335 | 2.7 | 1.5 | 126 | 39 | +86 | 5 of 8 | 5 of 8 | +208 | -36 |

### Effective charges: cnsr-c940641-p37

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Dwarfen Mountain Holds | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net -68) | 1 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 5 | 2 (net -98) | 0 | 0 | 0 | 0 | 3 (net +301) | 0 | 0% (0 of 5) |

### Charged fights, damage counted: cnsr-c940641-p37

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 3 | 836 | 105 | +164 | 164 | 11 | +153 | +18.3 |
| Mine | All fights | 3 | 836 | 105 | +164 | 164 | 11 | +153 | +18.3 |
| Opponent | Long shot (under 50%) | 2 | 313 | 322 | -98 | 0 | 98 | -98 | -31.2 |
| Opponent | Effective (55-75%) | 1 | 60 | 55 | +0 | 22 | 20 | +2 | +3.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 670 | 254 | +208 | 303 | 30 | +273 | +40.8 |
| Opponent | No odds | 1 | 50 | 52 | +52 | 52 | 0 | +52 | +104.0 |
| Opponent | All fights | 8 | 427 | 221 | +86 | 161 | 42 | +119 | +27.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p37 | move | 21 | 3 (14%) | 2 (10%) | 0 (0%) | 18 (86%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

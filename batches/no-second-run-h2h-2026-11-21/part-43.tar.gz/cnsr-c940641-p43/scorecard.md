# Doctrine scorecard: cnsr-c940641-p43

### Scorecard: cnsr-c940641-p43

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 1 | 0 | 0 | 895 |
| L1135 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1135 | 1 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 0 | 4 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Opponent | no | 5 | - | 0 | 1 | 1 | 0 | 0 | 351 |
| **Average** | | | Mine | 0% | 0.0 | 2.7 | 0.7 | 0.7 | 0.0 | 0.0 | 0.0 | 165.0 |
| **Average** | | | Opponent | 0% | 2.5 | - | 1.0 | 2.0 | 0.7 | 0.0 | 0.0 | 415.3 |

### KPIs: cnsr-c940641-p43

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (4 of 14) | 0% (0 of 14) | 14% (4 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 25% (1 of 4); on the table 50% | 62% (5 of 8); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (4 of 4); on the table 100% | 50% (1 of 2); on the table 50% | 83% (5 of 6); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 100% (11 of 11); on the table 100% | 33% (2 of 6); on the table 50% | 76% (13 of 17); on the table 82% |
| Magic missiles tried each own turn | 50%+ | 36% (26 of 72) | 33% (6 of 18) | 36% (32 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (26 of 54) | 50% (6 of 12) | 48% (32 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 51% (3075 of 5998) | 45% (2696 of 6000) | 48% (5771 of 11998) |
|   infantry points that never fought | lower | 87% (633 of 730) | 79% (617 of 782) | 83% (1250 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (15 of 25) | 88% (23 of 26) | 75% (38 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 5.0 uses a game | 50% (1 of 2); 2.0 uses a game | 78% (7 of 9); 3.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (3138 of 5614) | 88% (4991 of 5644) | 72% (8129 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.3 (22%) | 0.0 (0%) | 3.3 (17%) |
| MARCHED: its unit marched | 5.3 (35%) | 0.0 (0%) | 5.3 (28%) |
| CHARGED: its unit charged | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: engaged in combat | 5.3 (35%) | 0.3 (8%) | 5.7 (29%) |
| FLEEING: fleeing | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.7 (42%) | 1.7 (9%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 2.0 (50%) | 2.0 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.3 | 8.0 | 0.7 | 10.7 | 1.7 | 4.3 |
| not cast | 2.7 | 8.0 | 5.3 | 19.3 | 2.3 | 23.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (58%) | 0.0 (0%) | 3.3 (17%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.3 (28%) | 0.7 (29%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (6%) | 5.7 (29%) | 1.0 (43%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (25%) | 2.0 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.3 (1%) |
| OFF THE TABLE: off the table or not arrived | 1.7 (62%) | 0.7 (8%) | 1.7 (31%) | 1.7 (9%) | 0.0 (0%) | 3.3 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (10%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (38%) | 0.0 (0%) | 1.3 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 50% (1 of 2) | 50% (1 of 2) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (31 of 57) | 64% (42 of 66) | 59% (73 of 123) |
|   cavalry | - | 64% (7 of 11) | 64% (7 of 11) |
|   character | - | 90% (9 of 10) | 90% (9 of 10) |
|   chariot | 58% (7 of 12) | 89% (8 of 9) | 71% (15 of 21) |
|   infantry | 38% (5 of 13) | 39% (11 of 28) | 39% (16 of 41) |
|   monster | - | 88% (7 of 8) | 88% (7 of 8) |
|   war machine | 59% (19 of 32) | - | 59% (19 of 32) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (42%) | 3.0 (38%) | 6.7 (40%) |
| CHARGED: it charged | 0.3 (4%) | 0.3 (4%) | 0.7 (4%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.3 (15%) | 0.0 (0%) | 1.3 (8%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.7 (21%) | 1.7 (10%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (8%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (8%) | 2.0 (25%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 2.0 (23%) | 0.0 (0%) | 2.0 (12%) |
| OTHER BAR | 0.7 (8%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 0.3 | 89% | 6.1 pts | 18 pts |
| character | 3.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 5.0 | 1.7 | 73% | 12.8 pts | 64 pts |
| infantry | 7.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| monster | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 7.7 | 7.0 | 52% | 27.9 pts | 214 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 2.0 | 3.3 |
| Charges that made contact a game | 3.7 | 1.0 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.50 declared, 1.33 contact (6 units) | - | 1.50 declared, 1.33 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 2.00 contact (1 units) | - | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.11 contact (9 units) | 0.23 declared, 0.12 contact (26 units) | 0.26 declared, 0.11 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | - | 75% (3 of 4) | 70% (7 of 10) |
| Character in a unit | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Character on its own | - | 62% (5 of 8) | 40% (2 of 5) | 54% (7 of 13) |
| Chariot | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Infantry | 75% (6 of 8) | - | - | 75% (6 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| War Machines | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 100% (11 of 11); on the table 100% | 36% (26 of 72) | 51% | 60% (15 of 25) | 86% (6 of 7); 5.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 6) | 65% | 86% (6 of 7) | 100% (1 of 1); 6.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 25% (1 of 4); on the table 50% | 83% (5 of 6) | 8% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 62% | 100% (12 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p43, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 20% (1) | 43% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p43

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 77% (10 of 13) | 100% (2 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (18 of 42) | 76% (19 of 25) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (2 of 5) | 0% (0 of 3) |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 67% (2 of 3) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 0.7 | 2.0 |
| Movement | Points that never moved of their own | 165.0 | 415.3 |
| Movement | Fights charged into per game | 3.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 8, net +62 | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 8, net +204 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 8 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 8, net +195 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 14.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 12) | 47% (20 of 43) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 6.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 26% (5 of 19) | - |
| Shooting | Points destroyed by war machines | 0.0 | 55.0 |
| Magic | Magic missiles cast | 6.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 19) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 13.0 | - |
| Magic | Wounds caused by other spells | 6.0 | - |
| Magic | Points destroyed by magic (all spells) | 257.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.7 / 2.3 / 0.7 | 0.3 / 1.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 339.3 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +175 | +12 |
| Combat | Net per 100 charger points, damage counted | +50.8 | +20.3 |
| Combat | First round won (charged fights) | 78% | 33% |
| Combat | Net points per charged fight | +142 | +78 |
| Combat | Net points per supported fight / lone fight | +204 / +124 | - / +78 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 9 | 2 of 3 |
| Game | Points lost | 132.7 | 799.3 |
| Game | VP from objectives | 1043.3 | 146.7 |
| Game | Lone holders (player turns) | 0.0 | 2.5 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1729 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 932
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnsr-c940641-p43

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +133.4 | 0.0 | 135.7 |
| ARMY TABLE | 15.0 | -168.5 | 0.0 | 0.0 | 25.0 | +315.1 | 0.0 | 400.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +24.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| ASSAILMENT BY POINTS | - | - | - | - | 0.7 | +0.6 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.1 | 0.0 | 0.0 | 0.3 | +7.7 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -13.7 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.3 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.3 | +129.3 | 95.3 | 110.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.3 | +102.6 | 276.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 3.3 | +76.0 | 313.3 | 0.0 | 3.3 | +53.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 91.3 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +25.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +45.2 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.3 | -351.7 | 0.0 | 0.0 | 16.3 | -743.1 | 0.0 | 513.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 383.7 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 11.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.3 | +27.1 | 0.0 | 91.3 |
| COVER ONCE | 7.7 | -495.0 | 0.0 | 0.0 | 10.7 | -1582.3 | 0.0 | 482.3 |
| DENIED BY THE FIGHT | 1.0 | -3.5 | 95.7 | 77.7 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +31.2 | 52.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +11.8 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | -8.9 | 248.7 | 77.7 | 0.7 | -9.3 | 77.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +1.0 | 304.0 | 0.0 | 0.7 | +0.1 | 77.7 | 0.0 |
| FALLS SHORT | 3.0 | +65.7 | 0.0 | 0.0 | 28.3 | +374.4 | 0.0 | 485.3 |
| FEATURE BUFFS | 0.7 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 3.3 | +43.7 | 691.0 | 77.7 | 0.3 | +14.4 | 0.0 | 0.0 |
| FIVE ACTION | 84.0 | +6080.6 | 2083.7 | 297.7 | 73.0 | +3767.4 | 462.7 | 1088.7 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 314.0 |
| FOLLOW UP WEIGHED | 1.0 | +256.4 | 0.0 | 77.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +632.3 | 846.7 | 77.7 | 0.7 | +91.3 | 77.7 | 0.0 |
| FREED FROM HIS FIGHT | 4.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 22.7 |
| FRIEND SHOOTS FIRST | 1.7 | -10.9 | 152.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -10.7 | 135.7 | 77.7 | - | - | - | - |
| GOAL WALK | 3.7 | +232.9 | 0.0 | 0.0 | 11.0 | +1035.2 | 0.0 | 41.7 |
| GUN MASK | 3.7 | +117.6 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 22.7 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 513.7 |
| HIS CHARGE DENIED | 0.3 | +37.2 | 34.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 123.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 271.3 |
| HIS MOVE AND SHOT | 3.3 | -17.6 | 0.0 | 0.0 | 8.7 | -70.5 | 0.0 | 169.7 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 271.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 33.7 | +817.8 | 0.0 | 0.0 | 45.0 | +2444.6 | 0.0 | 523.0 |
| HIS SHOTS BY HIS RUN | 40.0 | +834.1 | 0.0 | 0.0 | 42.3 | +965.3 | 0.0 | 894.7 |
| HIS TURN DENIED | 2.0 | +97.8 | 604.3 | 77.7 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 271.3 |
| HOLDER ASSIGNMENT | 10.7 | +987.2 | 0.0 | 0.0 | 4.0 | +415.0 | 0.0 | 135.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -132.3 | 846.7 | 77.7 | 0.3 | -8.8 | 0.0 | 0.0 |
| HUNT IN PAIRS | 2.0 | +208.2 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 0.3 | -3.9 | 0.0 | 0.0 | 12.0 | -194.5 | 0.0 | 187.3 |
| JOINT CHARGE NOW | 2.0 | +359.4 | 542.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 61.7 | 155.3 | 8.0 | +0.0 | 77.7 | 341.0 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -1.0 | 77.7 | 0.0 |
| LOST AFTER ESCAPE | 4.3 | -20.7 | 846.7 | 77.7 | 0.3 | -0.1 | 77.7 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +25.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +58.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +32.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.7 | +177.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +31.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.3 | +111.7 | 0.0 | 0.0 | 3.0 | +134.8 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 8.7 | +190.8 | 0.0 | 0.0 | 4.0 | +42.2 | 0.0 | 188.3 |
| MISSILES NEXT TURN | 13.0 | +168.3 | 0.0 | 0.0 | 3.3 | +21.9 | 0.0 | 188.3 |
| MISSILES ON ONE TARGET | 1.0 | -7.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 42.0 |
| MOVE TO CHARGE COMPUTED | 5.0 | +412.2 | 0.0 | 0.0 | 2.0 | +153.3 | 0.0 | 68.0 |
| NEARER NOT NEEDED | 6.3 | +281.1 | 0.0 | 0.0 | 5.3 | +253.3 | 0.0 | 52.7 |
| NEXT CHARGE BY LIST | 4.0 | +381.9 | 152.0 | 0.0 | 1.7 | +125.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 1.3 | -31.1 | 0.0 | 0.0 | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -118.7 | 711.0 | 77.7 | 0.3 | -8.3 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.3 | -170.6 | 34.0 | 0.0 | 3.7 | -195.1 | 0.0 | 153.7 |
| OGRE LOADER SECOND SHOT | 4.7 | +140.6 | 0.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.0 | -113.3 | 0.0 | 0.0 | 4.3 | -82.8 | 0.0 | 110.0 |
| ONE JOINT FIGURE | 1.3 | +343.5 | 542.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 5.3 | +5.8 | 0.0 | 0.0 | 1.3 | -11.0 | 0.0 | 135.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -12.6 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +4.3 | 162.0 | 77.7 | 0.3 | +0.6 | 77.7 | 0.0 |
| PLAN RESULT | 37.0 | +1372.7 | 828.3 | 132.7 | 33.0 | +132.7 | 110.0 | 1060.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 5.7 | -101.0 | 0.0 | 0.0 | 4.0 | -103.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 152.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2.3 | -6.8 | 152.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.1 | 0.0 | 0.0 | 0.3 | -4.1 | 0.0 | 11.3 |
| PROMISE SHOT AWAY | 0.3 | -1.7 | 76.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.3 | +2108.0 | 433.0 | 0.0 | 9.3 | +860.4 | 0.0 | 27.3 |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 4.0 | +811.0 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 11.3 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 0.7 | -21.0 | 0.0 | 0.0 | 0.7 | -60.7 | 0.0 | 68.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +14.4 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | +247.6 | 791.3 | 77.7 | 0.7 | -28.4 | 77.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -10.5 | 13.7 | 0.0 | - | - | - | - |
| RUN DOWN | 2.3 | -15.3 | 270.0 | 77.7 | 0.7 | -10.5 | 77.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -20.8 | 76.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | -19.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +1.8 | 34.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -3.9 | 0.0 | 0.0 | 1.7 | -69.2 | 0.0 | 11.3 |
| SET UP BY THE SET | 1.3 | +74.0 | 0.0 | 0.0 | 4.3 | -1.6 | 0.0 | 53.3 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.0 | +0.0 | 0.0 | 110.0 | 8.7 | +0.0 | 0.0 | 118.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +95.0 | 0.0 | 0.0 | 1.0 | +2.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -47.6 | 211.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 16.0 | -132.5 | 0.0 | 0.0 | 28.0 | -3.4 | 0.0 | 250.3 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.7 | +662.4 | 0.0 | 110.0 | 14.3 | +499.9 | 0.0 | 229.0 |
| SPELL WORTH | 1.0 | +27.7 | 0.0 | 0.0 | 2.0 | +13.5 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 0.7 | +0.8 | 153.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 342.3 |
| STAND AND SHOOT | 1.0 | -11.0 | 214.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 10.3 | +0.0 | 0.0 | 100.3 |
| STANDS STILL | 44.3 | +0.0 | 1237.0 | 220.0 | 31.7 | +0.0 | 385.0 | 430.7 |
| STANDS TO CAST | - | - | - | - | 0.7 | +61.8 | 0.0 | 0.0 |
| STAY WORTH | 28.0 | +176.0 | 777.0 | 330.0 | 18.0 | +232.3 | 330.0 | 94.7 |
| STRIKE BY THE ODDS | 1.0 | +27.5 | 135.7 | 0.0 | 0.7 | +6.5 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +123.8 | 0.0 | 0.0 | 10.0 | +873.2 | 0.0 | 13.7 |
| SUPPORT WORKED OUT | 2.0 | +123.8 | 0.0 | 0.0 | 10.0 | +873.2 | 0.0 | 13.7 |
| SWIFTSTRIDE BY POINTS | 0.3 | -3.6 | 0.0 | 77.7 | 0.3 | +0.9 | 0.0 | 11.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -4.1 | 0.0 | 11.3 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 34.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 82.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 2.3 | +0.0 | 0.0 | 135.7 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.7 | +0.0 | 0.0 | 110.0 | 35.0 | +0.0 | 0.0 | 544.3 |
| TIED UP BY THE SUM | 0.7 | +50.6 | 41.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 28.7 | +453.5 | 90.7 | 0.0 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.7 | -35.5 | 0.0 | 0.0 | 0.3 | -14.8 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 22.7 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -8.4 | 155.3 | 0.0 |
| WHO HITS BACK | 0.3 | +105.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.3 | 77.7 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -50.3 | 0.0 | 0.0 | 3.0 | -424.5 | 0.0 | 371.7 |
| WHOLE FIGHT GAIN | 1.3 | +110.4 | 542.7 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.0 | +26.6 | 0.0 | 0.0 | 3.7 | +19.8 | 0.0 | 271.3 |

### Rule changes: cnsr-c940641-p43

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 120 | 120 | 77 | 25.67 | +1187 | +15.4 |
| HIS SHOT LIST | 236 | 221 | 69 | 23.00 | +1421 | +20.6 |
| HIS SHOTS BY HIS RUN | 247 | 229 | 54 | 18.00 | +978 | +18.1 |
| HOLDER ASSIGNMENT | 44 | 44 | 38 | 12.67 | +1785 | +47.0 |
| LEGAL CHARGES ONLY | 29 | 29 | 29 | 9.67 | +0 | +0.0 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -1097 | -45.7 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| FIVE ACTION | 471 | 452 | 22 | 7.33 | +1476 | +67.1 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| SHOT RISK POINTS | 132 | 124 | 18 | 6.00 | +411 | +22.8 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| GOAL WALK | 44 | 44 | 15 | 5.00 | +918 | +61.2 |
| SUPPORT ADDS | 36 | 35 | 15 | 5.00 | +535 | +35.7 |
| SUPPORT WORKED OUT | 36 | 35 | 15 | 5.00 | +535 | +35.7 |
| OGRE LOADER SECOND SHOT | 14 | 14 | 14 | 4.67 | +422 | +30.1 |
| CAST JOB | 13 | 13 | 10 | 3.33 | +107 | +10.7 |
| CASTING BLOCK | 20 | 20 | 10 | 3.33 | +71 | +7.1 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| COVER ONCE | 55 | 40 | 9 | 3.00 | +516 | +57.4 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 9 | 3.00 | -615 | -68.3 |
| QUARTER ODDS | 77 | 75 | 9 | 3.00 | +663 | +73.7 |
| FOUR ROUNDS | 16 | 15 | 8 | 2.67 | +810 | +101.3 |
| MOVE TO CHARGE COMPUTED | 21 | 16 | 8 | 2.67 | +585 | +73.1 |
| NEXT CHARGE BY LIST | 17 | 14 | 8 | 2.67 | +549 | +68.7 |
| SET UP BY THE SET | 17 | 15 | 8 | 2.67 | +157 | +19.6 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 86 | 70 | 8 | 2.67 | +12 | +1.5 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 7 | 2.33 | +25 | +3.6 |
| STAY WORTH | 138 | 126 | 7 | 2.33 | +69 | +9.8 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +1078 | +179.7 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -532 | -106.4 |
| STRIKE BY THE ODDS | 5 | 5 | 5 | 1.67 | +102 | +20.4 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +769 | +192.3 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 38 | 30 | 4 | 1.33 | +109 | +27.1 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| GUN MASK | 11 | 10 | 3 | 1.00 | +88 | +29.3 |
| MANOEUVRE | 10 | 10 | 3 | 1.00 | +88 | +29.2 |
| PROMISE KNOWS THE FIGHT | 10 | 10 | 3 | 1.00 | -20 | -6.7 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 3 | 1.00 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 3 | 3 | 3 | 1.00 | -151 | -50.3 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +400 | +200.1 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +2 | +0.9 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +136 | +67.8 |
| FALLS SHORT | 94 | 76 | 2 | 0.67 | +6 | +2.8 |
| HUNT IN PAIRS | 6 | 5 | 2 | 0.67 | +216 | +108.2 |
| IDLE COST | 37 | 24 | 2 | 0.67 | +8 | +4.2 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +176 | +87.9 |
| MAX FOR POSITIONING | 28 | 25 | 2 | 0.67 | +19 | +9.4 |
| ONE JOINT FIGURE | 4 | 4 | 2 | 0.67 | +422 | +211.2 |
| REDIRECT COUNTER | 12 | 12 | 2 | 0.67 | +185 | +92.4 |
| STANDS TO CAST | 2 | 2 | 2 | 0.67 | -59 | -29.6 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | -8 | -4.2 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +60 | +29.9 |
| WAR ENGINE JOBS | 6 | 6 | 2 | 0.67 | -23 | -11.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +35 | +34.8 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +14 | +13.5 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -0.6 |
| CHARGE LOSSES | 98 | 93 | 1 | 0.33 | +27 | +27.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +4 | +3.5 |
| HIS MOVE AND SHOT | 36 | 35 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +20 | +19.6 |
| MARCH CHECK | 4 | 4 | 1 | 0.33 | +31 | +30.6 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -12 | -11.9 |
| MISSILES NEXT TURN | 49 | 35 | 1 | 0.33 | +0 | +0.2 |
| MOVE ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 35 | 33 | 1 | 0.33 | +21 | +21.4 |
| NEXT OBJECTIVE NEARER | 5 | 4 | 1 | 0.33 | +36 | +35.8 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -38 | -37.9 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -5 | -5.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +21 | +21.4 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +43 | +43.3 |
| RISK BY ARC | 14 | 13 | 1 | 0.33 | +20 | +19.6 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +9 | +9.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +5 | +5.4 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS IN THE MOVE | 84 | 63 | 1 | 0.33 | +4 | +4.5 |
| THE ROW IN ITS ORDER | 7 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +302 | +302.5 |
| WOUNDS ON THE RANKS | 17 | 17 | 1 | 0.33 | +17 | +17.4 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 19 | 19 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARGE NOW FIRST | 8 | 8 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 29 | 27 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 8 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 11 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 27 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 19 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 61 | 57 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 31 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 36 | 32 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 43 | 37 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 62 | 62 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 14 | 13 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 12 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 21 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 20 | 16 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 210 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 65 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 18 | 18 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 31 | 30 | 0 | 0.00 | - | - |
| STANDS STILL | 228 | 221 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 7 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 23 | not checked | - | - | - | - |
| THE TABLE BINDS | 212 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 14 | 14 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p43

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 3.00 | 38.8 |
| ARMY TABLE | rule | 1.33 | 4.00 | 78.2 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 0.67 | 68.3 |
| MARCH OF THE TABLE | rule | 1.67 | - | 106.4 |
| NO REASON | gate | 1.67 | - | 75.1 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 15.5 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 6.7 |
| WALKS ON ITS ROUTE | rule | 0.67 | 0.33 | 50.3 |
| RULE SWITCHED OFF | gate | - | 0.67 | 31.5 |
| STANDS TO CAST | rule | - | 0.67 | 29.6 |
| WAR ENGINE JOBS | rule | 0.67 | - | 11.3 |
| BEST PRIZE | rule | 0.33 | - | 41.0 |
| CHAFF PASSED | rule | 0.33 | - | 0.6 |
| JOINT CHARGE NOW | rule | 0.33 | - | 79.6 |
| MARCH ODDS | rule | 0.33 | - | 11.9 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 37.9 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 5.1 |
| SET UP BY THE SET | rule | - | 0.33 | 53.5 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 10.9 |

### Plans: cnsr-c940641-p43

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 69% | 1085 | 720 | 66% |
| Mine | move | 21.0 | 100% | 1511 | 0 | 0% |
| Mine | shoot | 11.7 | 46% | 413 | 652 | 158% |
| Opponent | charge | 0.7 | 50% | 69 | 78 | 113% |
| Opponent | move | 24.7 | 89% | 1347 | 0 | 0% |
| Opponent | shoot | 7.3 | 5% | 556 | 55 | 10% |
| Opponent | support | 0.3 | 100% | 22 | 0 | 0% |

### Battle groups: cnsr-c940641-p43

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.0 | 17% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p43

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 74 (12) | 74 | 0 | 8 | 25% | 2.3 | - | 57 (7) | 95 (5) | 64 (7) | 81 (5) |
| Mine | Fast Hammer | 4 | 12 (4) | 12 | 0 | 0 | 25% | 2.3 | 42 (2) | 0 (2) | - | 19 (3) | 0 (1) |
| Mine | Holder | 5 | 69 (5) | 5 | 64 | 0 | 20% | 3.8 | - | 105 (3) | 12 (2) | 85 (4) | 0 (1) |
| Mine | Shooter | 2 | 474 (2) | 0 | 474 | 0 | 0% | 1.0 | 124 (1) | 825 (1) | - | 474 (2) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 17 | 0% | 2.2 | 0 (2) | 0 (2) | 0 (2) | 0 (1) | 0 (5) |
| Opponent | Chaff | 6 | 0 (6) | 0 | 0 | 41 | 33% | 3.0 | 0 (5) | 0 (1) | - | 0 (5) | 0 (1) |
| Opponent | Character | 7 | 0 (7) | 0 | 0 | 38 | 0% | 2.7 | 0 (1) | 0 (4) | - | 0 (4) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 32 | 0% | 2.3 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 16 (4) | 0 | 16 | 61 | 25% | 3.3 | - | 18 (3) | 0 (1) | 18 (3) | 0 (1) |
| Opponent | Hammer | 8 | 26 (8) | 26 | 0 | 40 | 38% | 1.4 | 108 (2) | 0 (2) | 0 (4) | 0 (5) | 71 (3) |
| Opponent | Holder | 1 | 54 (1) | 0 | 54 | 100 | 100% | - | - | 54 (1) | - | 54 (1) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 56 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |

### Charged fights: cnsr-c940641-p43

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 257 | 426 | 3.0 | 1.2 | 142 | 0 | +142 | 5 of 9 | 7 of 9 | +204 | +124 |
| Opponent | Ogre Kingdoms | 1 | 165 | 233 | 2.0 | 1.0 | 116 | 0 | +116 | 1 of 2 | 1 of 2 | - | +116 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 55 | 78 | 1.0 | 1.0 | 78 | 0 | +78 | 2 of 3 | 1 of 3 | - | +78 |

### Effective charges: cnsr-c940641-p43

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 9 | 3 (net +62) | 0 | 2 (net +204) | 0 | 0 | 3 (net +195) | 1 | 25% (2 of 8) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +233) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p43

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 267 | 288 | +62 | 62 | 0 | +62 | +23.1 |
| Mine | Effective (55-75%) | 2 | 584 | 357 | +204 | 543 | 201 | +342 | +58.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 251 | 178 | +195 | 200 | 0 | +200 | +79.8 |
| Mine | No odds | 1 | 369 | 102 | +102 | 102 | 0 | +102 | +27.6 |
| Mine | All fights | 9 | 343 | 246 | +142 | 219 | 45 | +175 | +50.8 |
| Opponent | Long shot (under 50%) | 1 | 102 | 358 | +0 | 0 | 51 | -51 | -50.0 |
| Opponent | 76-89% | 1 | 40 | 233 | +233 | 233 | 125 | +108 | +269.0 |
| Opponent | No odds | 1 | 34 | 97 | +0 | 5 | 26 | -21 | -61.4 |
| Opponent | All fights | 3 | 59 | 229 | +78 | 79 | 67 | +12 | +20.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p43 | move | 19 | 1 (5%) | 1 (5%) | 3 (16%) | 15 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

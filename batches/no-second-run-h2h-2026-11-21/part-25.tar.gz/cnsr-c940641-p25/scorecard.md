# Doctrine scorecard: cnsr-c940641-p25

### Scorecard: cnsr-c940641-p25

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 0 | 2 | 0 | 6 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 7 | - | 0 | 3 | 0 | 0 | 0 | 322 |
| L0135 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 7 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 3.0 | - | 0.0 | 1.3 | 0.0 | 0.0 | 0.0 | 125.7 |
| **Average** | | | Opponent | 0% | 0.7 | 2.7 | 1.7 | 6.0 | 0.0 | 0.0 | 0.0 | 131.3 |

### KPIs: cnsr-c940641-p25

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 4) | 0% (0 of 13) | 0% (0 of 17) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | - | 75% (3 of 4); on the table 75% | 75% (3 of 4); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 27% (24 of 90) | 8% (2 of 24) | 23% (26 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% (24 of 75) | 8% (2 of 24) | 26% (26 of 99) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 83% (5 of 6) | 83% (5 of 6) |
| Points that never fought | lower | 54% (3075 of 5700) | 82% (4860 of 5899) | 68% (7935 of 11599) |
|   infantry points that never fought | lower | 58% (1557 of 2703) | 100% (1219 of 1219) | 71% (2776 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (8 of 15) | 76% (19 of 25) | 68% (27 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 3.0 uses a game | 75% (3 of 4); 2.3 uses a game | 86% (6 of 7); 2.7 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 100% (3 of 3); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (2079 of 4077) | 69% (3393 of 4883) | 61% (5472 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 12.7 (58%) | 6.3 (86%) | 19.0 (65%) |
| MARCHED: its unit marched | 1.7 (8%) | 1.0 (14%) | 2.7 (9%) |
| REAR RANK: in a rear rank | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |
| OFF THE TABLE: off the table or not arrived | 5.0 (23%) | 0.0 (0%) | 5.0 (17%) |
| STUPIDITY: Stupidity | 1.3 (6%) | 0.0 (0%) | 1.3 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 9.3 | 2.0 | 8.3 | 8.7 | 0.3 |
| not cast | 8.7 | 8.0 | 7.7 | 29.3 | 43.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (62%) | 1.3 (17%) | 19.0 (65%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (9%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 1.7 (19%) | 1.7 (21%) | 1.7 (22%) | 5.0 (17%) | 7.0 (16%) |
| STUPIDITY: Stupidity | 0.7 (8%) | 0.0 (0%) | 1.3 (17%) | 1.3 (5%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 6.3 (73%) | 1.3 (17%) | 3.3 (43%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 35.3 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.0 a game | 1.3 a game | 4.7 a game |
| stood (cast and not dispelled) | 71% (17 of 24) | 100% (4 of 4) | 75% (21 of 28) |
| the unit moved after it | 59% (10 of 17) | 50% (2 of 4) | 57% (12 of 21) |
| it charged on its next turn | 0% (0 of 17) | 0% (0 of 4) | 0% (0 of 21) |
| the enemy charged it first | 12% (2 of 17) | 0% (0 of 4) | 10% (2 of 21) |
| it fought by the end of its next turn | 6% (1 of 17) | 0% (0 of 4) | 5% (1 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 17) | 0% (0 of 4) | 0% (0 of 21) |
| none of these (no charge, no fight, no charge escaped) | 88% (15 of 17) | 100% (4 of 4) | 90% (19 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 50% (14 of 28) | 44% (31 of 70) | 46% (45 of 98) |
|   cavalry | - | 73% (8 of 11) | 73% (8 of 11) |
|   character | - | 45% (5 of 11) | 45% (5 of 11) |
|   chariot | - | 33% (4 of 12) | 33% (4 of 12) |
|   infantry | 50% (14 of 28) | 25% (6 of 24) | 38% (20 of 52) |
|   monster | - | 67% (8 of 12) | 67% (8 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (36%) | 1.7 (13%) | 3.3 (19%) |
| CHARGED: it charged | 0.0 (0%) | 1.3 (10%) | 1.3 (8%) |
| FLEEING: it fled or was fleeing | 0.7 (14%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (7%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.3 (7%) | 6.7 (51%) | 7.0 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (21%) | 0.7 (5%) | 1.7 (9%) |
| SHELTERED: the target was sheltered | 0.7 (14%) | 1.7 (13%) | 2.3 (13%) |
| OTHER BAR | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 1.3 | 71% | 2.5 pts | 12 pts |
| character | 1.7 | 1.3 | 60% | 6.3 pts | 11 pts |
| chariot | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 6.7 | 4.0 | 70% | 7.1 pts | 47 pts |
| monster | 2.7 | 0.3 | 88% | 1.0 pts | 3 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 2.0 | 1.0 |
| Charges that made contact a game | 0.0 | 1.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (15 units) | 0.19 declared, 0.16 contact (32 units) | 0.13 declared, 0.11 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 100% (3 of 3) | 88% (7 of 8) | - | 91% (10 of 11) |
| Character on its own | 50% (1 of 2) | 67% (2 of 3) | 0% (0 of 1) | 50% (3 of 6) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 29% (2 of 7) | - | 50% (6 of 12) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (2 of 2); on the table 100% | 23% (25 of 108) | 62% | 57% (12 of 21) | 100% (5 of 5); 3.8 uses a game | 100% (3 of 3); 0.8 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 86% | 86% (6 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 75% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p25, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | - | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p25

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 24% (4 of 17) | 21% (4 of 19) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 25% (3 of 12) | 0% (0 of 7) |
| Strategy | Lone characters that fought | 100% (6 of 6) | 33% (1 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 6.0 |
| Movement | Points that never moved of their own | 125.7 | 131.3 |
| Movement | Fights charged into per game | 0.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 4, net +322 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 4, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 2 of 4, net +431 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.7 | 10.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 71% (10 of 14) | 62% (20 of 32) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 6.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 11% (2 of 18) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 17.0 | 3.3 |
| Magic | Points destroyed by magic (all spells) | 207.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.3 / 0.7 / 0.0 / 0.0 | 1.7 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 11.3 | 0.0 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | - | +234 |
| Combat | Net per 100 charger points, damage counted | - | +85.7 |
| Combat | First round won (charged fights) | - | 80% |
| Combat | Net points per charged fight | - | +243 |
| Combat | Net points per supported fight / lone fight | - / - | - / +243 |
| Combat | Charged fights on a top-3 enemy unit | - | 3 of 5 |
| Game | Points lost | 636.3 | 255.3 |
| Game | VP from objectives | 656.7 | 786.7 |
| Game | Lone holders (player turns) | 3.0 | 0.7 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -578 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 892
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p25

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 36.7 |
| ARMY TABLE | 7.3 | +77.4 | 0.0 | 61.7 | 21.3 | -150.9 | 0.0 | 168.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.7 | -135.4 | 214.7 | 0.0 |
| CAST JOB | - | - | - | - | 3.3 | +41.0 | 429.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 5.0 | +541.8 | 125.7 | 214.7 | 0.7 | +7.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 5.3 | +0.0 | 0.0 | 236.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.7 | +32.2 | 0.0 | 0.0 | 0.7 | +16.0 | 0.0 | 20.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 10.3 | -259.2 | 0.0 | 301.3 | 8.0 | -441.4 | 0.0 | 234.7 |
| CHARGE NOW FIRST | - | - | - | - | 1.0 | +0.0 | 233.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 2.7 | +0.0 | 0.0 | 107.3 | 11.3 | +0.0 | 0.0 | 83.3 |
| CONVEYANCE SEARCH | 6.7 | +886.9 | 322.0 | 355.0 | 1.3 | +44.9 | 0.0 | 0.0 |
| COVER ONCE | 3.0 | -167.4 | 0.0 | 236.3 | 4.7 | -181.1 | 0.0 | 75.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -63.5 | 107.3 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 74.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +6.9 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.0 | +78.9 | 233.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.3 | +2.8 | 322.0 | 0.0 |
| FALLS SHORT | 4.7 | +128.2 | 0.0 | 107.3 | 14.3 | +236.4 | 0.0 | 41.7 |
| FEATURE BUFFS | 13.3 | +601.9 | 0.0 | 319.7 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 1.0 | +28.9 | 322.0 | 0.0 |
| FIVE ACTION | 49.0 | +7015.9 | 125.7 | 804.0 | 102.7 | +4034.9 | 1413.7 | 352.7 |
| FLANK NOT WEIGHED | 1.0 | +0.0 | 0.0 | 214.7 | 4.7 | +0.0 | 0.0 | 44.0 |
| FOUR ROUNDS | - | - | - | - | 1.7 | +46.7 | 340.3 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -6.4 | 107.3 | 0.0 |
| GOAL WALK | 4.7 | +622.0 | 0.0 | 0.0 | 0.3 | +3.8 | 0.0 | 41.7 |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.3 | +0.0 | 107.3 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 107.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 301.3 | 5.7 | +0.0 | 0.0 | 193.0 |
| HIS CHARGE LIST | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -30.8 | 0.0 | 0.0 | 3.0 | -160.3 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.0 | +0.0 | 0.0 | 86.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 86.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 27.7 | +475.3 | 0.0 | 233.0 | 51.0 | +2240.3 | 0.0 | 102.0 |
| HIS SHOTS BY HIS RUN | 29.3 | +287.7 | 0.0 | 356.3 | 33.0 | +714.1 | 0.0 | 246.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +22.4 | 214.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 36.3 | +0.0 | 0.0 | 617.7 | 14.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 15.7 | +1633.1 | 0.0 | 258.0 | 10.3 | +1208.2 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.3 | -60.0 | 233.0 | 0.0 |
| IDLE COST | 1.3 | -6.3 | 0.0 | 0.0 | 22.7 | -207.5 | 0.0 | 128.7 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 12.7 | +0.0 | 87.0 | 135.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | -3.6 | 107.3 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.3 | -5.1 | 322.0 | 0.0 |
| MANOEUVRE | 1.7 | +9.6 | 0.0 | 107.3 | 0.7 | +12.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +84.0 | 0.0 | 0.0 | 0.3 | +10.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.3 | +17.4 | 0.0 | 18.3 | 1.0 | +1.2 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 74.7 |
| MISSILES IN THE MOVE | 8.7 | +580.1 | 0.0 | 322.0 | 6.0 | +104.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.0 | +397.4 | 0.0 | 322.0 | 6.3 | +58.8 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.7 | -60.5 | 0.0 | 107.3 | - | - | - | - |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 11.3 |
| MOVE SPELL OUT OF RANGE | 1.0 | -57.3 | 0.0 | 118.3 | - | - | - | - |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 2.0 | +99.9 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.3 | +302.2 | 0.0 | 258.0 | 2.7 | +141.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 1.0 | +38.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.7 | -44.8 | 340.3 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.7 | -2.8 | 0.0 | 118.3 | 2.0 | -3.1 | 0.0 | 0.0 |
| OFF BEST | 1.0 | -30.5 | 0.0 | 0.0 | 3.7 | -85.6 | 0.0 | 42.0 |
| ONE FIGHT FORMULA | 2.3 | -33.8 | 0.0 | 144.0 | 2.3 | -26.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.0 | +14.9 | 0.0 | 258.0 | 1.7 | +38.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -9.1 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.3 | +0.3 | 41.7 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +9.3 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +21.1 | 18.3 | 0.0 |
| PLAN RESULT | 21.7 | +130.7 | 0.0 | 534.3 | 45.0 | +584.7 | 558.3 | 298.3 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 1.7 | -9.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| QUARTER ODDS | 10.7 | +1571.4 | 84.0 | 0.0 | 22.0 | +2147.4 | 0.0 | 84.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +171.8 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.7 | +117.7 | 0.0 | 0.0 | 3.0 | +53.6 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 36.7 | 4.0 | +0.0 | 0.0 | 22.7 |
| REFORMS TO MEET IT | - | - | - | - | 0.3 | -25.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE MOVE SPELL | 1.0 | +26.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.7 | -66.8 | 340.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -4.2 | 214.7 | 0.0 |
| RUN DOWN | - | - | - | - | 1.7 | -13.4 | 340.3 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.0 | -115.0 | 0.0 | 0.0 | 0.7 | -0.7 | 0.0 | 20.0 |
| SEARCH SPOT | 0.3 | +5.8 | 0.0 | 0.0 | 0.7 | +8.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -88.3 | 0.0 | 41.7 |
| SET UP BY THE SET | - | - | - | - | 0.7 | +35.3 | 0.0 | 41.7 |
| SET-UP ANY TARGET | 0.3 | +28.9 | 107.3 | 118.3 | 0.3 | +45.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.3 | -0.5 | 0.0 | 0.0 | 0.7 | -1.3 | 0.0 | 20.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 107.3 | 6.0 | +0.0 | 0.0 | 10.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +240.1 | 0.0 | 214.7 | 1.3 | +39.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -3.8 | 214.7 | 0.0 |
| SHOT RISK POINTS | 15.0 | -176.3 | 0.0 | 83.3 | 44.0 | +313.2 | 0.0 | 268.7 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 5.7 | +114.8 | 0.0 | 43.3 | 12.7 | +111.4 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +28.9 | 107.3 | 118.3 | 0.3 | +45.9 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +4.7 | 68.0 | 236.7 | 2.0 | +8.7 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 125.7 | 3.3 | +0.0 | 0.0 | 83.7 |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 107.3 | 0.0 |
| STANDS STILL | 16.3 | +0.0 | 125.7 | 484.3 | 39.3 | +0.0 | 1073.3 | 53.0 |
| STAY WORTH | 8.7 | +96.2 | 0.0 | 0.0 | 17.3 | +71.3 | 1073.3 | 42.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | -135.4 | 214.7 | 0.0 |
| SUPPORT ADDS | 2.7 | +192.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +192.0 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -2.1 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 42.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 23.7 | +0.0 | 0.0 | 294.7 | 49.7 | +0.0 | 0.0 | 180.7 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +53.0 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 17.7 | +497.6 | 0.0 | 349.7 | 21.7 | +151.7 | 966.0 | 11.3 |
| WHO FIGHTS | - | - | - | - | 0.7 | -111.0 | 214.7 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -119.8 | 0.0 | 301.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 4.3 | +118.3 | 0.0 | 0.0 | 0.3 | +46.0 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p25

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 236 | 236 | 72 | 24.00 | +765 | +10.6 |
| HOLDER ASSIGNMENT | 78 | 78 | 70 | 23.33 | +3948 | +56.4 |
| ARMY TABLE | 86 | 86 | 50 | 16.67 | -223 | -4.5 |
| HIS SHOTS BY HIS RUN | 187 | 186 | 50 | 16.67 | +494 | +9.9 |
| LEGAL CHARGES ONLY | 38 | 38 | 38 | 12.67 | +0 | +0.0 |
| SHOT RISK POINTS | 177 | 176 | 38 | 12.67 | +543 | +14.3 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 118 | 109 | 21 | 7.00 | +166 | +7.9 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| CASTING BLOCK | 17 | 17 | 16 | 5.33 | +829 | +51.8 |
| FIVE ACTION | 455 | 454 | 15 | 5.00 | +1366 | +91.1 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| OFF BEST | 14 | 14 | 14 | 4.67 | -348 | -24.9 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| QUARTER ODDS | 98 | 98 | 13 | 4.33 | +919 | +70.7 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 13 | 4.33 | +247 | +19.0 |
| FEATURE BUFFS | 40 | 40 | 12 | 4.00 | +284 | +23.6 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 72 | 62 | 8 | 2.67 | +90 | +11.2 |
| FALLS SHORT | 57 | 46 | 6 | 2.00 | +170 | +28.4 |
| GOAL WALK | 15 | 15 | 6 | 2.00 | +1220 | +203.2 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 78 | 64 | 6 | 2.00 | +56 | +9.3 |
| SUPPORT ADDS | 8 | 8 | 6 | 2.00 | +152 | +25.4 |
| SUPPORT WORKED OUT | 8 | 8 | 6 | 2.00 | +152 | +25.4 |
| WOUNDS ON THE RANKS | 14 | 14 | 6 | 2.00 | +137 | +22.8 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 5 | 1.67 | +19 | +3.9 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 7 | 7 | 5 | 1.67 | +7 | +1.4 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 5 | 1.67 | +515 | +103.1 |
| CAST JOB | 10 | 10 | 4 | 1.33 | +35 | +8.7 |
| CHARGE LOSSES | 55 | 54 | 4 | 1.33 | +92 | +23.0 |
| MOVE TO CHARGE COMPUTED | 6 | 5 | 4 | 1.33 | +163 | +40.7 |
| COVER ONCE | 23 | 18 | 3 | 1.00 | +8 | +2.5 |
| MANOEUVRE | 7 | 7 | 3 | 1.00 | +66 | +22.0 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +181 | +60.3 |
| MISSILES NEXT TURN | 43 | 31 | 3 | 1.00 | +81 | +26.9 |
| REDIRECT COUNTER | 11 | 9 | 3 | 1.00 | +298 | +99.2 |
| RESERVE MOVE SPELL | 3 | 3 | 3 | 1.00 | +78 | +26.2 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +44 | +14.7 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 3 | 3 | 2 | 0.67 | +85 | +42.3 |
| MISSILES IN THE MOVE | 44 | 33 | 2 | 0.67 | +73 | +36.4 |
| NEXT CHARGE BY LIST | 3 | 3 | 2 | 0.67 | +74 | +37.1 |
| SHOTS IN THE MOVE | 55 | 35 | 2 | 0.67 | +20 | +10.2 |
| FIGHT TO THE END | 3 | 3 | 1 | 0.33 | +2 | +2.1 |
| FOUR ROUNDS | 5 | 5 | 1 | 0.33 | +2 | +2.1 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +2 | +2.1 |
| HONEST WORTH | 4 | 4 | 1 | 0.33 | +22 | +22.4 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +19 | +18.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -1 | -1.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 27 | 22 | 1 | 0.33 | +63 | +62.6 |
| ONE FIGHT FORMULA | 14 | 12 | 1 | 0.33 | +14 | +13.6 |
| ONE OBJECTIVE FORMULA | 29 | 18 | 1 | 0.33 | +58 | +57.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -27 | -27.3 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +32 | +32.3 |
| PROMISE BY ITS OWN SUM | 5 | 5 | 1 | 0.33 | -27 | -27.2 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -19 | -18.6 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| THE RISK READS HIS RUN | 18 | 18 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 1 | 0.33 | +41 | +41.4 |
| WHOLE FIGHT DANGER | 7 | 7 | 1 | 0.33 | +22 | +22.1 |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 20 | trace | - | - | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 42 | 42 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 24 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 30 | 29 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 9 | 9 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 20 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 19 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 18 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 151 | 151 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 5 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 11 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 200 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 33 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 11 | 11 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 27 | 27 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 167 | 167 | 0 | 0.00 | - | - |
| STRIKE BY THE ODDS | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 220 | not checked | - | - | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p25

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.67 | 3.67 | 26.6 |
| ARMY TABLE | rule | 1.33 | 2.33 | 113.1 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 14.4 |
| AFTERMATH BAND | gate | 0.33 | - | 1.9 |
| MARCH OF THE TABLE | rule | - | 0.33 | 1.3 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 27.3 |
| PROMISE BY ITS OWN SUM | rule | - | 0.33 | 27.2 |
| REFUSING RETIRES | rule | 0.33 | - | 18.6 |

### Plans: cnsr-c940641-p25

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 16.7 | 94% | 2111 | 0 | 0% |
| Mine | shoot | 4.3 | 46% | 690 | 131 | 19% |
| Mine | support | 0.7 | 50% | 0 | 0 | 0% |
| Opponent | charge | 1.7 | 80% | 148 | 244 | 165% |
| Opponent | move | 38.0 | 96% | 1026 | 0 | 0% |
| Opponent | shoot | 5.0 | 47% | 245 | 341 | 139% |
| Opponent | support | 0.3 | 0% | 3 | 0 | 0% |

### Battle groups: cnsr-c940641-p25

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p25

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 21 (18) | 21 | 0 | 39 | 17% | 1.6 | - | 10 (9) | 0 (3) | 0 (6) | 15 (6) |
| Mine | Hammer | 6 | 30 (6) | 2 | 28 | 34 | 50% | 3.3 | 65 (1) | 26 (4) | 11 (1) | 38 (4) | 14 (2) |
| Mine | Holder | 3 | 117 (3) | 0 | 117 | 0 | 100% | - | - | 175 (2) | - | 351 (1) | 0 (1) |
| Mine | Shooter | 6 | 54 (6) | 0 | 54 | 50 | 0% | 1.7 | - | 65 (5) | 0 (1) | 46 (4) | 69 (2) |
| Opponent | Chaff | 6 | 141 (6) | 0 | 141 | 25 | 67% | 4.0 | 0 (3) | 514 (2) | 0 (1) | 141 (6) | - |
| Opponent | Character | 8 | 44 (8) | 44 | 0 | 0 | 25% | 1.8 | 83 (4) | 0 (4) | - | 79 (4) | 0 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 7 | 19 (7) | 9 | 10 | 21 | 57% | 2.0 | 38 (1) | 0 (3) | 25 (3) | 29 (3) | 14 (4) |
| Opponent | Hammer | 13 | 54 (13) | 43 | 11 | 16 | 54% | 2.2 | - | 77 (8) | 0 (5) | 11 (3) | 69 (10) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Shooter | 3 | 82 (3) | 0 | 82 | 62 | 67% | 1.0 | 214 (1) | 0 (2) | - | 214 (1) | 0 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |

### Charged fights: cnsr-c940641-p25

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 207 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 0 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 0 of 1 | 1 of 1 | - | +55 |
| Opponent | Ogre Kingdoms | 1 | 0 | 807 | 2.0 | 1.0 | 404 | 17 | +386 | 2 of 2 | 1 of 2 | - | +386 |
| Opponent | Wood Elf Realms | 1 | 0 | 387 | 2.0 | 1.0 | 194 | 0 | +194 | 1 of 2 | 2 of 2 | - | +194 |
| **Opponent** | all armies | 3 | 0 | 416 | 1.7 | 1.0 | 250 | 7 | +243 | 3 of 5 | 4 of 5 | - | +243 |

### Effective charges: cnsr-c940641-p25

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +55) | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +807) | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 1 (net +322) | 0 | 1 (net +65) | 0 | 0 | 50% (1 of 2) |

### Charged fights, damage counted: cnsr-c940641-p25

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Effective (55-75%) | 1 | 499 | 322 | +322 | 377 | 0 | +377 | +75.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 168 | 188 | +431 | 447 | 65 | +382 | +227.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 65 | +65 | 65 | 0 | +65 | +13.0 |
| Opponent | No odds | 1 | 34 | 836 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 5 | 274 | 320 | +243 | 267 | 33 | +234 | +85.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p25 | move | 6 | 1 (17%) | 1 (17%) | 0 (0%) | 5 (83%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

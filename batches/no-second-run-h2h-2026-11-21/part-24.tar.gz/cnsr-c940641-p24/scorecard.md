# Doctrine scorecard: cnsr-c940641-p24

### Scorecard: cnsr-c940641-p24

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 5 | 1 | 5 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 3 | 0 | 0 | 0 | 549 |
| **Average** | | | Mine | 67% | 1.5 | 3.5 | 1.7 | 2.3 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 33% | 2.5 | 2.3 | 4.3 | 3.0 | 0.0 | 0.0 | 0.0 | 183.0 |

### KPIs: cnsr-c940641-p24

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 29% (5 of 17) | 16% (5 of 32) |
| Winner chose to follow up after the loser gave ground |  | - | 71% (5 of 7); on the table 71% | 71% (5 of 7); on the table 71% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | 78% (7 of 9); on the table 78% | 78% (7 of 9); on the table 78% |
| Magic missiles tried each own turn | 50%+ | 58% (14 of 24) | 33% (6 of 18) | 48% (20 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 58% (14 of 24) | 33% (6 of 18) | 48% (20 of 42) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 35% (2127 of 5999) | 54% (3270 of 6000) | 45% (5397 of 11999) |
|   infantry points that never fought | lower | 63% (493 of 780) | 45% (860 of 1918) | 50% (1353 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (14 of 18) | 76% (26 of 34) | 77% (40 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 1.7 uses a game | 50% (2 of 4); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 69% (3337 of 4808) | 71% (4240 of 5962) | 70% (7577 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (40%) | 1.7 (42%) | 3.0 (41%) |
| MARCHED: its unit marched | 1.0 (30%) | 2.0 (50%) | 3.0 (41%) |
| STUPIDITY: Stupidity | 1.0 (30%) | 0.0 (0%) | 1.0 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (8%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 2.3 | 3.7 | 6.7 | 1.3 | 1.7 |
| not cast | 3.3 | 0.3 | 2.3 | 7.3 | 4.7 | 22.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 3.0 (41%) | 2.7 (57%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (41%) | 1.7 (36%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (14%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.3 (7%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.3 (100%) | 0.0 (0%) | 2.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.0 (99%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 3.0 a game | 1.8 a game |
| stood (cast and not dispelled) | 50% (1 of 2) | 56% (5 of 9) | 55% (6 of 11) |
| the unit moved after it | 100% (1 of 1) | 60% (3 of 5) | 67% (4 of 6) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 5) | 0% (0 of 6) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 5) | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 5) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 20% (1 of 5) | 17% (1 of 6) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 80% (4 of 5) | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 3) | 66% (61 of 93) | 64% (61 of 96) |
|   cavalry | - | 61% (28 of 46) | 61% (28 of 46) |
|   character | 0% (0 of 3) | 71% (10 of 14) | 59% (10 of 17) |
|   infantry | - | 70% (23 of 33) | 70% (23 of 33) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 7.3 (69%) | 7.3 (63%) |
| CHARGED: it charged | 0.7 (67%) | 3.0 (28%) | 3.7 (31%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (33%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.3 | 1.7 | 86% | 6.5 pts | 80 pts |
| character | 3.3 | 0.3 | 90% | 1.4 pts | 5 pts |
| infantry | 11.7 | 1.3 | 91% | 2.4 pts | 28 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 5.7 | 4.2 |
| Charges that made contact a game | 2.3 | 4.7 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | - | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | - | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.25 contact (20 units) | 0.55 declared, 0.45 contact (31 units) | 0.45 declared, 0.37 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 82% (9 of 11) | 50% (1 of 2) | 100% (1 of 1) | 79% (11 of 14) |
| Character in a unit | 100% (2 of 2) | 100% (6 of 6) | - | 100% (8 of 8) |
| Character on its own | 100% (3 of 3) | - | 33% (2 of 6) | 56% (5 of 9) |
| Infantry | 83% (10 of 12) | 67% (2 of 3) | - | 80% (12 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | - | 58% (14 of 24) | 47% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 12% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 78% (7 of 9); on the table 78% | 33% (6 of 18) | 54% | 76% (26 of 34) | 50% (2 of 4); 1.7 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p24, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 62% (8) | 33% (1) | 56% (9) |
| ...free all their last turn and able to turn (per game) | 2.00 | 0.00 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 2.00 | 0.00 | 2.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnsr-c940641-p24

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 88% (7 of 8) | 73% (8 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | - | 43% (3 of 7) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 57% (4 of 7) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.3 | 3.0 |
| Movement | Points that never moved of their own | 0.0 | 183.0 |
| Movement | Fights charged into per game | 2.0 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 6, net +0 | 2 of 8, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +190 | 1 of 8, net +105 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 6, net +140 | 1 of 8, net +329 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 6, net +236 | 3 of 8, net +33 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.0 | 21.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 77% (50 of 65) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 3.7 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 9% (1 of 11) | 60% (3 of 5) |
| Magic | Wounds caused by magic missiles | 0.3 | 2.0 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 1.0 / 0.3 | 1.7 / 1.3 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 192.7 | 319.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +112 | +36 |
| Combat | Net per 100 charger points, damage counted | +35.9 | +20.4 |
| Combat | First round won (charged fights) | 50% | 77% |
| Combat | Net points per charged fight | +94 | +55 |
| Combat | Net points per supported fight / lone fight | +0 / +113 | +0 / +59 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 4 of 13 |
| Game | Points lost | 319.0 | 271.3 |
| Game | VP from objectives | 576.7 | 666.7 |
| Game | Lone holders (player turns) | 1.5 | 2.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -138 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 590
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p24

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +27.3 | 0.0 | 0.0 |
| ARMY TABLE | 30.7 | +532.1 | 0.0 | 99.3 | 48.0 | +658.3 | 0.0 | 285.3 |
| ASSAILMENT BY POINTS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +1.2 | 0.0 | 0.0 | 0.7 | +1.7 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 6.3 | +177.4 | 0.0 | 50.0 | 0.3 | +27.8 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 1.3 | -0.2 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +20.2 | 0.0 | 84.7 | 0.7 | +29.1 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -6.6 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 20.7 | -906.1 | 0.0 | 196.0 | 16.7 | -650.5 | 0.0 | 157.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 32.7 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 125.3 | 84.7 | 1.7 | +0.0 | 178.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 15.0 | +0.0 | 0.0 | 189.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +25.2 | 0.0 | 0.0 | 3.0 | +303.8 | 0.0 | 0.0 |
| COVER ONCE | 8.0 | -426.2 | 0.0 | 82.0 | 12.0 | -401.0 | 0.0 | 46.7 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | +10.3 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 1.3 | -8.2 | 0.0 | 118.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 0.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -49.0 | 78.7 | 0.0 | 0.3 | -36.4 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +3.4 | 46.7 | 118.0 | 2.3 | +6.9 | 94.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +5.7 | 125.3 | 118.0 | 3.0 | +0.0 | 137.3 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 22.3 | +325.2 | 0.0 | 199.7 | - | - | - | - |
| FEATURE BUFFS | 0.7 | +7.0 | 0.0 | 0.0 | 0.3 | +3.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +8.0 | 0.0 | 84.7 | 0.7 | +0.5 | 49.0 | 0.0 |
| FIVE ACTION | 86.3 | +4756.4 | 125.3 | 666.7 | 107.3 | +8053.2 | 211.3 | 477.3 |
| FLANK NOT WEIGHED | 12.7 | +0.0 | 0.0 | 137.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +9.4 | 0.0 | 0.0 | 1.3 | +166.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +123.1 | 125.3 | 118.0 | 4.0 | +447.6 | 211.3 | 0.0 |
| FREED FROM HIS FIGHT | 7.0 | +0.0 | 0.0 | 80.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -9.3 | 32.7 | 0.0 |
| GOAL WALK | 5.0 | +340.4 | 0.0 | 0.0 | 20.3 | +1500.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 30.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.7 | +0.0 | 0.0 | 33.3 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 15.0 | +0.0 | 0.0 | 196.0 | 11.0 | +0.0 | 0.0 | 157.3 |
| HIS CHARGE DENIED | 0.7 | +93.8 | 0.0 | 33.3 | 0.3 | +4.6 | 84.7 | 0.0 |
| HIS CHARGE LIST | 8.3 | +0.0 | 0.0 | 83.3 | 14.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 7.0 | -66.7 | 0.0 | 49.0 | 3.0 | -49.4 | 0.0 | 0.0 |
| HIS ONE QUARTER | 11.7 | +0.0 | 0.0 | 33.3 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 10.0 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 66.7 | +1726.5 | 0.0 | 432.7 | 29.7 | +300.3 | 0.0 | 34.7 |
| HIS SHOTS BY HIS RUN | 67.3 | +1233.7 | 0.0 | 432.0 | 28.0 | +242.0 | 0.0 | 192.0 |
| HIS TURN DENIED | 0.7 | +23.4 | 0.0 | 84.7 | 0.3 | +0.5 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 105.3 | 15.7 | +0.0 | 0.0 | 157.3 |
| HOLDER ASSIGNMENT | 9.0 | +625.1 | 0.0 | 52.7 | 10.3 | +800.2 | 0.0 | 78.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 2.7 | -98.4 | 125.3 | 118.0 | 3.3 | -119.1 | 211.3 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| IDLE COST | 17.7 | -228.7 | 0.0 | 74.0 | - | - | - | - |
| JOINT CHARGE NOW | 0.7 | +6.0 | 0.0 | 33.3 | 0.7 | +6.9 | 25.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 157.3 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 0.0 | 291.7 | 12.3 | +0.0 | 353.3 | 0.0 |
| LONG SHOT | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +28.8 | 20.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +2.9 | 125.3 | 0.0 | 0.7 | -1.1 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -29.8 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.2 | 0.0 | 0.0 | 0.3 | +4.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +92.0 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 2.3 | +86.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +34.9 | 0.0 | 0.0 | 0.3 | +7.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +39.8 | 0.0 | 0.0 | 2.7 | +594.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +12.7 | 0.0 | 25.0 | 2.0 | +30.9 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.3 | +15.1 | 0.0 | 0.0 | 5.3 | +189.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.7 | +13.7 | 0.0 | 0.0 | 6.7 | +128.9 | 0.0 | 0.0 |
| MOVE ORDER | 2.7 | +0.0 | 32.7 | 0.0 | 4.7 | +0.0 | 0.0 | 46.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.7 | -53.7 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 11.3 | +1396.5 | 0.0 | 0.0 | 5.7 | +421.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 10.0 | +379.6 | 0.0 | 112.0 | 7.0 | +364.8 | 0.0 | 78.7 |
| NEXT CHARGE BY LIST | 8.0 | +909.1 | 0.0 | 0.0 | 3.3 | +268.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.7 | -78.5 | 125.3 | 84.7 | 2.7 | -121.1 | 186.3 | 0.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | - | - | - | - | 1.7 | -3.0 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -125.1 | 0.0 | 0.0 | 8.7 | -654.5 | 0.0 | 46.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -118.6 | 0.0 | 50.0 | 6.7 | -89.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | +12.1 | 0.0 | 52.7 | 3.0 | +36.2 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.3 | -118.8 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +12.3 | 125.3 | 0.0 | - | - | - | - |
| OWN CAST FIRST | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.7 | +37.1 | 0.0 | 0.0 | 0.3 | +40.7 | 0.0 | 0.0 |
| PLAN RESULT | 45.0 | +146.7 | 20.0 | 638.0 | 48.7 | +204.6 | 153.7 | 241.3 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 84.7 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.3 | -258.4 | 0.0 | 0.0 | 13.0 | -472.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | -1.1 | 0.0 | 0.0 | 1.3 | -34.6 | 0.0 | 0.0 |
| QUARTER ODDS | 24.7 | +2635.0 | 46.7 | 100.0 | 32.0 | +3819.8 | 0.0 | 0.0 |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -16.0 | 0.0 | 0.0 | 1.7 | +0.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 6.7 | +438.6 | 0.0 | 101.7 | 0.7 | +11.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +17.9 | 0.0 | 101.7 | 2.7 | +114.6 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -36.6 | 0.0 | 0.0 | 1.0 | -4.3 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +18.0 | 0.0 | 0.0 | 1.3 | +127.9 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | -13.5 | 125.3 | 118.0 | 2.0 | +60.5 | 142.3 | 0.0 |
| RISK ON THE WAY | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -21.4 | 125.3 | 84.7 | 0.3 | -3.2 | 32.7 | 0.0 |
| RUN DOWN | 2.0 | -27.0 | 125.3 | 84.7 | 0.3 | -1.0 | 32.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | 3.0 | -15.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +1.7 | 0.0 | 0.0 | 0.7 | +21.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | 3.0 | -78.5 | 0.0 | 30.0 | 0.7 | -0.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 4.7 | +260.6 | 0.0 | 70.0 | 1.7 | +3.6 | 32.7 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +53.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 1.3 | +15.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| SHOT RISK POINTS | 49.3 | -391.7 | 0.0 | 332.3 | 13.0 | -86.7 | 0.0 | 69.3 |
| SHOTS AFTER THE MOVES | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +37.7 | 0.0 | 0.0 | 19.7 | +220.5 | 0.0 | 204.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +53.6 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +3.6 | 0.0 | 0.0 | 2.3 | +39.4 | 126.7 | 126.7 |
| SPOT AS THE GAME MOVES | 14.0 | +0.0 | 0.0 | 211.3 | 8.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -5.7 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 12.7 | +0.0 | 0.0 | 96.0 | 45.0 | +0.0 | 0.0 | 226.7 |
| STAY WORTH | - | - | - | - | 18.0 | +76.5 | 0.0 | 78.7 |
| STUPIDITY NEXT TURN | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 2.3 | +22.5 | 0.0 | 15.0 | 5.3 | +258.1 | 0.0 | 69.3 |
| SUPPORT WORKED OUT | 2.3 | +22.5 | 0.0 | 15.0 | 5.3 | +258.1 | 0.0 | 69.3 |
| SURE REACH TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -32.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 25.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.3 | +0.0 | 0.0 | 20.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 32.7 | - | - | - | - |
| THE STEP BACK IS MADE | 4.3 | +0.0 | 0.0 | 20.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.3 | +0.0 | 0.0 | 274.3 | 51.3 | +0.0 | 0.0 | 204.0 |
| TIED UP BY THE SUM | 1.0 | +153.6 | 125.3 | 84.7 | 1.0 | +135.3 | 57.7 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 56.0 | +551.9 | 0.0 | 238.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -4.4 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -1.6 | 0.0 | 0.0 | 0.3 | -0.8 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +32.6 | 0.0 | 0.0 | 0.7 | +22.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -317.9 | 0.0 | 98.0 | 3.3 | -435.2 | 0.0 | 157.3 |
| WOUNDS ON THE RANKS | 3.3 | +83.1 | 0.0 | 0.0 | 4.3 | +43.8 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p24

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 236 | 236 | 150 | 50.00 | +2630 | +17.5 |
| HIS SHOT LIST | 289 | 282 | 55 | 18.33 | +915 | +16.6 |
| HIS SHOTS BY HIS RUN | 286 | 278 | 52 | 17.33 | +794 | +15.3 |
| HOLDER ASSIGNMENT | 58 | 58 | 51 | 17.00 | +3017 | +59.2 |
| LEGAL CHARGES ONLY | 47 | 47 | 47 | 15.67 | +0 | +0.0 |
| OFF BEST | 41 | 41 | 41 | 13.67 | -2339 | -57.0 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| THE TABLE AGAIN | 36 | 36 | 33 | 11.00 | +0 | +0.0 |
| FIVE ACTION | 581 | 557 | 32 | 10.67 | +1690 | +52.8 |
| MOVE TO CHARGE COMPUTED | 51 | 45 | 28 | 9.33 | +1688 | +60.3 |
| TIME ON OUR SIDE | 168 | 133 | 24 | 8.00 | +120 | +5.0 |
| PROMISE BY ITS OWN SUM | 70 | 70 | 23 | 7.67 | -2192 | -95.3 |
| QUARTER ODDS | 170 | 163 | 23 | 7.67 | +2275 | +98.9 |
| MOVE ORDER | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| SHOT RISK POINTS | 187 | 180 | 22 | 7.33 | +227 | +10.3 |
| GOAL WALK | 76 | 72 | 20 | 6.67 | +888 | +44.4 |
| NEXT CHARGE BY LIST | 34 | 32 | 20 | 6.67 | +1623 | +81.1 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 17 | 5.67 | +4 | +0.2 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| FOUR ROUNDS | 20 | 20 | 12 | 4.00 | +486 | +40.5 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 20 | 20 | 10 | 3.33 | +84 | +8.4 |
| CHARGE LOSSES | 112 | 106 | 9 | 3.00 | +732 | +81.3 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 53 | 36 | 7 | 2.33 | +39 | +5.5 |
| NEARER NOT NEEDED | 51 | 47 | 6 | 2.00 | +152 | +25.4 |
| PATHS CROSS | 6 | 6 | 6 | 2.00 | +233 | +38.9 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +438 | +72.9 |
| SET UP BY THE SET | 19 | 19 | 6 | 2.00 | +162 | +27.0 |
| SUPPORT ADDS | 23 | 23 | 6 | 2.00 | +192 | +32.1 |
| SUPPORT WORKED OUT | 23 | 23 | 6 | 2.00 | +192 | +32.1 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +528 | +105.6 |
| PROMISE KNOWS THE FIGHT | 7 | 6 | 5 | 1.67 | -107 | -21.4 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +201 | +40.1 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -1 | -0.2 |
| COVER ONCE | 60 | 32 | 4 | 1.33 | +63 | +15.8 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +39 | +9.7 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -356 | -89.1 |
| RISK BY ARC | 13 | 13 | 4 | 1.33 | +64 | +16.1 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 4 | 1.33 | +3 | +0.8 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +148 | +49.3 |
| CHARGE NOW FIRST | 8 | 8 | 3 | 1.00 | -43 | -14.4 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| ONE OBJECTIVE FORMULA | 19 | 16 | 3 | 1.00 | +171 | +56.9 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 3 | 1.00 | +8 | +2.7 |
| SEARCH SPOT | 6 | 6 | 3 | 1.00 | +70 | +23.2 |
| THE ROW IN ITS ORDER | 26 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +89 | +29.6 |
| WHOLE FIGHT DANGER | 18 | 18 | 3 | 1.00 | +70 | +23.3 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +82 | +40.9 |
| FALLS SHORT | 67 | 56 | 2 | 0.67 | +6 | +2.8 |
| HIS CHARGE DENIED | 3 | 3 | 2 | 0.67 | +50 | +24.9 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 7 | 7 | 2 | 0.67 | +31 | +15.5 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -127 | -63.3 |
| ONE FIGHT FORMULA | 37 | 15 | 2 | 0.67 | +28 | +14.1 |
| REDIRECT COUNTER | 22 | 19 | 2 | 0.67 | +77 | +38.6 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOTS AFTER THE MOVES | 7 | 7 | 2 | 0.67 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -47 | -47.2 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DUEL STOPS AT THE KILL | 3 | 3 | 1 | 0.33 | +55 | +54.8 |
| EXACT ROUND | 11 | 11 | 1 | 0.33 | +0 | +0.1 |
| HIS MOVE AND SHOT | 30 | 29 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 18 | 18 | 1 | 0.33 | +55 | +54.8 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +7 | +7.1 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +276 | +275.9 |
| MAX FOR POSITIONING | 10 | 8 | 1 | 0.33 | +0 | +0.0 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -2 | -2.1 |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 1 | 0.33 | +4 | +4.0 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -6 | -6.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +9 | +9.0 |
| SET CREDITED ONCE | 11 | 11 | 1 | 0.33 | +2 | +2.1 |
| SHOTS IN THE MOVE | 61 | 38 | 1 | 0.33 | +23 | +23.4 |
| STAY WORTH | 54 | 35 | 1 | 0.33 | +1 | +0.9 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -13 | -13.1 |
| WOUNDS ON THE RANKS | 23 | 23 | 1 | 0.33 | +3 | +2.6 |
| BACKUP TARGETS | 4 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 8 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 11 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 15 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 23 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 9 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 78 | 75 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 68 | 65 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 32 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 57 | 53 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 65 | 61 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 92 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 19 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 7 | 7 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 11 | 11 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 12 | 12 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 29 | 16 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 37 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 12 | 12 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 281 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 12 | 12 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 9 | 9 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 18 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 68 | 62 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 173 | 161 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 13 | 11 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 296 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p24

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 6.00 | 49.4 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 5.33 | 95.3 |
| ARMY TABLE | rule | 1.33 | 4.67 | 40.9 |
| NO REASON | gate | - | 2.00 | 112.1 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | 1.00 | 21.4 |
| ONE PROMISE A TARGET | rule | 1.33 | - | 89.1 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 14.4 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 1.4 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 63.3 |
| AFTERMATH BAND | gate | - | 0.33 | 2.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 45.1 |
| CHAFF PASSED | rule | - | 0.33 | 0.7 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 47.2 |
| FALLBACK | gate | 0.33 | - | 38.0 |
| FOLLOW UP WEIGHED | rule | - | 0.33 | 2.7 |
| JOINT CHARGE NOW | rule | 0.33 | - | 18.1 |
| OWN CAST FIRST | rule | 0.33 | - | 2.1 |
| REFUSING RETIRES | rule | - | 0.33 | 6.3 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 13.1 |

### Plans: cnsr-c940641-p24

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 60% | 260 | 147 | 56% |
| Mine | join | 4.7 | 100% | 190 | 0 | 0% |
| Mine | move | 37.0 | 96% | 1679 | 0 | 0% |
| Mine | support | 1.7 | 100% | 36 | 0 | 0% |
| Opponent | charge | 3.3 | 50% | 496 | 205 | 41% |
| Opponent | move | 42.7 | 98% | 2786 | 0 | 0% |
| Opponent | shoot | 1.3 | 0% | 142 | 0 | 0% |
| Opponent | support | 1.3 | 100% | 62 | 0 | 0% |

### Battle groups: cnsr-c940641-p24

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 6.7 | 20% | 25% | 0% | - | 25% | 0% | 0% | 75% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p24

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 53 (9) | 0 | 53 | 32 | 67% | 3.3 | 68 (7) | 0 (1) | 0 (1) | 60 (8) | 0 (1) |
| Mine | Character | 10 | 34 (10) | 34 | 0 | 4 | 10% | 4.7 | 13 (6) | 51 (4) | - | 16 (4) | 44 (6) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 8 | 12 (8) | 0 | 12 | 11 | 25% | 4.3 | 21 (2) | 0 (4) | 16 (2) | 0 (1) | 15 (7) |
| Mine | Hammer | 2 | 84 (2) | 0 | 84 | 46 | 50% | 4.0 | 156 (1) | 0 (1) | - | 156 (1) | 0 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.5 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 25 (7) | 25 | 0 | 6 | 0% | 1.1 | 15 (5) | 66 (1) | 0 (1) | 0 (3) | 38 (4) |
| Opponent | Clean-up | 2 | 111 (2) | 0 | 111 | 0 | 50% | 1.0 | 222 (1) | 0 (1) | - | 222 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 22 (5) | 0 | 22 | 15 | 0% | 1.4 | 47 (2) | 0 (2) | 0 (1) | 47 (2) | 0 (3) |
| Opponent | Hammer | 11 | 25 (11) | 25 | 0 | 0 | 55% | 4.0 | 0 (3) | 53 (6) | 0 (2) | 72 (2) | 17 (9) |
| Opponent | Shooter | 8 | 18 (8) | 0 | 18 | 32 | 0% | 1.4 | 43 (2) | 14 (5) | 0 (1) | 33 (3) | 11 (5) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |

### Charged fights: cnsr-c940641-p24

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 70 | 1.5 | 1.3 | 47 | 0 | +47 | 0 of 3 | 1 of 3 | +0 | +70 |
| Mine | Warriors of Chaos | 1 | 0 | 426 | 3.0 | 1.0 | 142 | 0 | +142 | 1 of 3 | 2 of 3 | - | +142 |
| **Mine** | all armies | 3 | 0 | 189 | 2.0 | 1.2 | 94 | 0 | +94 | 1 of 6 | 3 of 6 | +0 | +113 |
| Opponent | Wood Elf Realms | 3 | 0 | 319 | 4.3 | 1.1 | 74 | 19 | +55 | 4 of 13 | 10 of 13 | +0 | +59 |

### Effective charges: cnsr-c940641-p24

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 3 | 2 (net +0) | 0 | 0 | 0 | 1 (net +140) | 0 | 0 | 0% (0 of 3) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 1 (net +190) | 1 (net +0) | 0 | 1 (net +236) | 0 | 33% (1 of 3) |
| Opponent | Wood Elf Realms | 13 | 2 (net +0) | 0 | 1 (net +105) | 1 (net +147) | 1 (net +329) | 3 (net +33) | 5 | 12% (1 of 8) |

### Charged fights, damage counted: cnsr-c940641-p24

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 75 | 114 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 479 | 224 | +190 | 190 | 0 | +190 | +39.7 |
| Mine | 76-89% | 1 | 285 | 208 | +0 | 104 | 0 | +104 | +36.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 479 | 236 | +236 | 236 | 0 | +236 | +49.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 471 | 140 | +140 | 140 | 0 | +140 | +29.7 |
| Mine | All fights | 6 | 311 | 172 | +94 | 112 | 0 | +112 | +35.9 |
| Opponent | Long shot (under 50%) | 2 | 375 | 348 | +0 | 95 | 213 | -118 | -31.5 |
| Opponent | Effective (55-75%) | 1 | 102 | 60 | +105 | 167 | 0 | +167 | +163.7 |
| Opponent | 76-89% | 1 | 102 | 147 | +147 | 147 | 17 | +130 | +127.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 242 | 163 | +33 | 49 | 0 | +49 | +20.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 75 | +329 | 329 | 0 | +329 | +65.9 |
| Opponent | No odds | 5 | 21 | 294 | +6 | 68 | 82 | -14 | -68.8 |
| Opponent | All fights | 13 | 176 | 226 | +55 | 101 | 66 | +36 | +20.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p24 | move | 23 | 5 (22%) | 5 (22%) | 3 (13%) | 15 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

# Doctrine scorecard: cnsr-c940641-p30

### Scorecard: cnsr-c940641-p30

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 5 | 5 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0913 | 1 | 1 | Opponent | no | 12 | 5 | 2 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 125 |
| L0930 | 6 | 1 | Opponent | no | 13 | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 6 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 0 | 6 | 0 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 3.7 | 4.0 | 1.0 | 1.3 | 0.0 | 0.0 | 0.0 | 276.7 |
| **Average** | | | Opponent | 0% | 8.7 | 5.0 | 0.7 | 3.0 | 0.3 | 0.0 | 0.0 | 143.3 |

### KPIs: cnsr-c940641-p30

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 50% (7 of 14) | 0% (0 of 13) | 26% (7 of 27) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 42% (20 of 48) | 17% (2 of 12) | 37% (22 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (20 of 42) | 17% (2 of 12) | 41% (22 of 54) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 36% (4 of 11) | 36% (4 of 11) |
| Points that never fought | lower | 72% (4330 of 5997) | 75% (4503 of 5999) | 74% (8833 of 11996) |
|   infantry points that never fought | lower | 93% (1487 of 1591) | 93% (1548 of 1660) | 93% (3035 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (25 of 34) | 65% (15 of 23) | 70% (40 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 75% (4254 of 5667) | 69% (3545 of 5150) | 72% (7799 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (54%) | 2.3 (70%) | 7.3 (58%) |
| MARCHED: its unit marched | 2.3 (25%) | 0.7 (20%) | 3.0 (24%) |
| IN COMBAT: engaged in combat | 1.7 (18%) | 0.0 (0%) | 1.7 (13%) |
| GONE: slain | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (10%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 3.7 | 1.7 | 7.3 | 0.3 | 1.0 |
| not cast | 0.0 | 4.3 | 0.3 | 12.7 | 1.7 | 19.0 |
| NO TARGET: no enemy in range, sight and arc it may target | - | 3.3 (77%) | 0.0 (0%) | 7.3 (58%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 0.0 (0%) | 3.0 (24%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.0 (0%) | 0.0 (0%) | 1.7 (13%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 1.0 (23%) | 0.0 (0%) | 0.3 (3%) | 1.7 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 80% (4 of 5) | 80% (4 of 5) |
| the unit moved after it | - | 25% (1 of 4) | 25% (1 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (86 of 124) | 77% (37 of 48) | 72% (123 of 172) |
|   character | 100% (3 of 3) | 62% (8 of 13) | 69% (11 of 16) |
|   chariot | 83% (15 of 18) | 100% (6 of 6) | 88% (21 of 24) |
|   infantry | 55% (31 of 56) | 65% (11 of 17) | 58% (42 of 73) |
|   monster | 50% (5 of 10) | - | 50% (5 of 10) |
|   war machine | 86% (32 of 37) | 100% (12 of 12) | 90% (44 of 49) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (24%) | 2.7 (73%) | 5.7 (35%) |
| CHARGED: it charged | 0.3 (3%) | 0.3 (9%) | 0.7 (4%) |
| MOVED: a war machine that moved | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 5.0 (39%) | 0.7 (18%) | 5.7 (35%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (21%) | 0.0 (0%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 4.3 | 1.0 | 77% | 2.7 pts | 12 pts |
| chariot | 7.0 | 1.7 | 86% | 3.5 pts | 24 pts |
| infantry | 17.0 | 10.0 | 59% | 12.0 pts | 204 pts |
| monster | 3.3 | 1.3 | 70% | 9.3 pts | 31 pts |
| war machine | 15.0 | 12.0 | 58% | 26.8 pts | 402 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 0.7 | 1.0 |
| Charges that made contact a game | 1.0 | 0.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.40 declared, 0.40 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.05 contact (20 units) | 0.09 declared, 0.09 contact (23 units) | 0.09 declared, 0.07 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (2 of 5) | - | - | 40% (2 of 5) |
| Character in a unit | 100% (7 of 7) | 100% (2 of 2) | - | 100% (9 of 9) |
| Character on its own | - | 50% (2 of 4) | 75% (3 of 4) | 62% (5 of 8) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 50% (7 of 14) | 75% (3 of 4) | - | 56% (10 of 18) |
| Monster | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 42% (10 of 24) | 92% | 79% (19 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 42% (10 of 24) | 33% | 60% (6 of 10) | 100% (2 of 2); 6.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 17% (1 of 6) | 71% | 25% (2 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 67% (2 of 3); on the table 67% | 17% (1 of 6) | 55% | 78% (7 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | - | 100% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p30, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 67% (2) | 75% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.00 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p30

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 3) | 100% (2 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 13% (7 of 55) | 63% (12 of 19) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (2 of 4) | - |
| Strategy | Joined characters whose unit fought | 11% (1 of 9) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.0 |
| Movement | Points that never moved of their own | 276.7 | 143.3 |
| Movement | Fights charged into per game | 1.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 2, net +104 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 2, net +0 | 1 of 2, net +227 |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.0 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (32 of 54) | 57% (16 of 28) |
| Shooting | Points destroyed by shooting units | 0.0 | 83.3 |
| Shooting | War machine shots | 10.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (16 of 32) | 33% (4 of 12) |
| Shooting | Points destroyed by war machines | 299.7 | 0.0 |
| Magic | Magic missiles cast | 3.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 27% (3 of 11) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 10.7 | 0.3 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 85.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.3 / 0.3 / 0.3 | 3.7 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 103.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +8 | +209 |
| Combat | Net per 100 charger points, damage counted | +2.7 | +70.9 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +0 | +166 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +166 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 1 of 2 |
| Game | Points lost | 303.7 | 477.7 |
| Game | VP from objectives | 813.3 | 760.0 |
| Game | Lone holders (player turns) | 3.7 | 8.7 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +225 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 781
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnsr-c940641-p30

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +2.1 | 0.0 | 0.0 | 0.3 | +11.7 | 0.0 | 0.0 |
| ARMY TABLE | 22.0 | +540.8 | 0.0 | 151.3 | 20.7 | +195.9 | 0.0 | 242.3 |
| ARTILLERY RE-ROLL WEIGHED | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 319.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.7 | +576.2 | 1085.7 | 125.0 | 4.0 | +65.8 | 118.0 | 0.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 41.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.7 | +139.2 | 319.3 | 0.0 | 1.3 | +22.3 | 69.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.3 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -2.2 | 41.7 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +10.6 | 0.0 | 75.7 | - | - | - | - |
| CHARACTER GUNS | 5.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.0 | -589.5 | 0.0 | 151.3 | 31.0 | -2065.7 | 0.0 | 875.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 48.3 | 0.0 | 0.7 | +0.0 | 75.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 3.0 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 0.0 | 37.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 68.3 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +227.6 | 0.0 | 0.0 |
| COVER ONCE | 12.7 | -1436.1 | 0.0 | 110.3 | 4.3 | -145.3 | 0.0 | 319.3 |
| DEFENSIVE ARMY | 1.3 | +0.0 | 638.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 41.7 | 7.0 | +37.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +24.5 | 48.3 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +12.6 | 48.3 | 0.0 | 0.3 | +0.0 | 75.7 | 0.0 |
| FALLS SHORT | 2.3 | +43.9 | 0.0 | 75.7 | 27.7 | +346.5 | 0.0 | 415.7 |
| FEATURE BUFFS | 2.0 | +37.4 | 0.0 | 0.0 | 4.0 | +60.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.1 | 0.0 | 0.0 | 0.3 | +3.3 | 75.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 105.3 | +9561.8 | 3472.3 | 470.7 | 99.0 | +5127.3 | 568.3 | 1389.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 75.7 | 5.7 | +0.0 | 0.0 | 356.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +104.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +104.5 | 48.3 | 0.0 | 0.7 | +55.6 | 110.3 | 0.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.7 | -213.5 | 0.0 | 0.0 | 0.7 | -2.2 | 0.0 | 0.0 |
| GOAL WALK | 10.0 | +1511.7 | 0.0 | 0.0 | 15.0 | +1680.3 | 0.0 | 0.0 |
| GUN FIGURES | 3.3 | +6.7 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 21.7 |
| GUN MASK | 5.3 | +62.8 | 0.0 | 0.0 | 1.7 | +72.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 151.3 | 9.3 | +0.0 | 0.0 | 735.3 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 191.7 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 319.3 |
| HIS MOVE AND SHOT | 2.0 | -9.4 | 0.0 | 0.0 | 5.3 | -96.0 | 0.0 | 108.3 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 136.7 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 319.3 |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.3 | +879.2 | 0.0 | 151.3 | 75.3 | +5707.3 | 0.0 | 1346.0 |
| HIS SHOTS BY HIS RUN | 31.0 | +689.2 | 0.0 | 151.3 | 80.7 | +2806.2 | 0.0 | 1389.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 21.7 | +0.0 | 0.0 | 0.0 | 34.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.7 | +1291.6 | 0.0 | 0.0 | 17.0 | +1608.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -36.9 | 48.3 | 0.0 | 0.7 | -23.8 | 110.3 | 0.0 |
| IDLE COST | 0.3 | -1.3 | 0.0 | 0.0 | 14.3 | -280.7 | 0.0 | 61.7 |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 68.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +1.0 | 48.3 | 0.0 | 0.3 | +0.1 | 75.7 | 0.0 |
| MANOEUVRE | 3.0 | -37.1 | 0.0 | 0.0 | 4.0 | +24.3 | 0.0 | 74.7 |
| MARCH AT ESCAPER | 0.3 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.7 | +113.8 | 0.0 | 0.0 | 0.3 | +19.7 | 0.0 | 0.0 |
| MARCH CHECK | 2.0 | +105.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.7 | -255.5 | 0.0 | 0.0 | 1.7 | -119.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +56.3 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.3 | +279.4 | 0.0 | 0.0 | 2.0 | +50.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 14.0 | +217.0 | 0.0 | 0.0 | 5.7 | +44.1 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.7 | +651.0 | 0.0 | 0.0 | 2.7 | +212.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 14.0 | +690.9 | 0.0 | 0.0 | 9.0 | +420.4 | 0.0 | 74.7 |
| NEXT CHARGE BY LIST | 3.7 | +197.1 | 0.0 | 0.0 | 2.0 | +207.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -65.8 | 48.3 | 0.0 | 0.7 | -44.1 | 110.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.0 | -226.0 | 0.0 | 125.0 | 1.0 | -17.6 | 0.0 | 21.7 |
| OGRE LOADER SECOND SHOT | 3.7 | +66.8 | 70.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.3 | -128.4 | 0.0 | 0.0 | 4.0 | -105.5 | 0.0 | 319.3 |
| ONE OBJECTIVE FORMULA | 5.7 | -41.7 | 0.0 | 0.0 | 8.0 | +302.2 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +4.2 | 0.0 | 0.0 | 0.3 | +2.0 | 34.7 | 0.0 |
| OWN CAST FIRST | 0.7 | -8.0 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.4 | 0.0 | 0.0 |
| PLAN RESULT | 45.7 | +1683.4 | 613.0 | 455.7 | 45.7 | +304.9 | 194.3 | 804.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 159.7 |
| PROMISE BY ITS OWN SUM | 5.7 | -206.4 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.0 | -145.9 | 0.0 | 0.0 | 0.7 | -2.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -13.1 | 48.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.7 | +2055.7 | 330.0 | 69.3 | 19.7 | +1817.2 | 318.3 | 166.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.7 | +62.6 | 0.0 | 263.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +18.7 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 2.0 | -11.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -34.4 | 48.3 | 0.0 | 0.7 | -29.9 | 110.3 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -7.6 | 0.0 | 0.0 | 0.3 | -9.6 | 34.7 | 0.0 |
| RUN DOWN | 1.0 | -10.4 | 48.3 | 0.0 | 0.7 | -2.2 | 110.3 | 0.0 |
| SAME CHARGE LATER | 0.3 | -8.2 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -152.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.3 | +59.2 | 0.0 | 0.0 | 0.7 | +22.5 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -35.8 | 0.0 | 0.0 | 0.7 | -4.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +35.8 | 0.0 | 0.0 | 0.7 | +3.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 19.0 | +0.0 | 0.0 | 159.7 | 7.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 5.0 | +107.4 | 120.0 | 0.0 | 1.3 | +47.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -79.1 | 0.0 | 0.0 | 0.3 | -1.6 | 34.7 | 0.0 |
| SHOT RISK POINTS | 11.3 | -76.6 | 0.0 | 151.3 | 46.3 | -1027.6 | 0.0 | 846.0 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 31.3 | +1712.5 | 0.0 | 159.7 | 12.3 | +310.2 | 0.0 | 341.0 |
| SPELL WORTH | - | - | - | - | 4.0 | +125.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +4.0 | 48.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 315.3 |
| STANDS FOR A REASON | - | - | - | - | 5.7 | +0.0 | 0.0 | 319.3 |
| STANDS STILL | 45.3 | +0.0 | 3424.0 | 319.3 | 37.7 | +0.0 | 458.0 | 597.3 |
| STAY WORTH | 42.0 | +614.9 | 2455.3 | 375.0 | 19.7 | +325.9 | 388.7 | 203.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.7 | +46.4 | 0.0 | 0.0 | 1.7 | +85.5 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +46.4 | 0.0 | 0.0 | 1.7 | +85.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 21.7 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 59.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 75.7 | 4.3 | +0.0 | 0.0 | 74.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 2.0 | +0.0 | 0.0 | 159.7 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 74.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.7 | +0.0 | 0.0 | 235.3 | 48.7 | +0.0 | 0.0 | 563.0 |
| TIED UP BY THE SUM | 0.7 | +69.2 | 48.3 | 0.0 | 0.3 | +37.7 | 75.7 | 0.0 |
| TIME ON OUR SIDE | 37.0 | +572.1 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 30.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +12.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 6.0 | -466.2 | 0.0 | 0.0 | 3.7 | -511.3 | 0.0 | 319.3 |
| WOUNDED STAYS OUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.0 | +21.4 | 0.0 | 0.0 | 2.7 | +185.7 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p30

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOTS BY HIS RUN | 335 | 331 | 102 | 34.00 | +1806 | +17.7 |
| HIS SHOT LIST | 329 | 328 | 93 | 31.00 | +2638 | +28.4 |
| ARMY TABLE | 128 | 128 | 88 | 29.33 | +2320 | +26.4 |
| HOLDER ASSIGNMENT | 89 | 89 | 84 | 28.00 | +6258 | +74.5 |
| SHOT RISK POINTS | 173 | 171 | 39 | 13.00 | +1671 | +42.8 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| GOAL WALK | 75 | 75 | 27 | 9.00 | +3219 | +119.2 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| CHARGE LOSSES | 141 | 139 | 25 | 8.33 | +2329 | +93.2 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -730 | -30.4 |
| FIVE ACTION | 613 | 608 | 23 | 7.67 | +1749 | +76.1 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 17 | 5.67 | +154 | +9.1 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 13 | 4.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 25 | 23 | 12 | 4.00 | +769 | +64.1 |
| CAST JOB | 15 | 15 | 11 | 3.67 | +63 | +5.7 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +201 | +18.2 |
| QUARTER ODDS | 109 | 107 | 10 | 3.33 | +505 | +50.5 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 17 | 17 | 9 | 3.00 | +219 | +24.4 |
| STAY WORTH | 185 | 169 | 9 | 3.00 | +248 | +27.6 |
| TIME ON OUR SIDE | 111 | 92 | 9 | 3.00 | +30 | +3.3 |
| COVER ONCE | 51 | 37 | 8 | 2.67 | +208 | +26.0 |
| CANNON PLANNED TARGET | 41 | 41 | 7 | 2.33 | -19 | -2.7 |
| GUN MASK | 21 | 21 | 7 | 2.33 | +137 | +19.6 |
| NEARER NOT NEEDED | 69 | 65 | 7 | 2.33 | +211 | +30.2 |
| PROMISE BY ITS OWN SUM | 24 | 24 | 7 | 2.33 | -619 | -88.5 |
| FALLS SHORT | 90 | 73 | 6 | 2.00 | +61 | +10.2 |
| MARCH BY THE SUM | 6 | 6 | 6 | 2.00 | +400 | +66.7 |
| SHOTS AFTER THE MOVES | 22 | 22 | 6 | 2.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +245 | +49.0 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| MANOEUVRE | 21 | 21 | 4 | 1.33 | +132 | +33.0 |
| ONE OBJECTIVE FORMULA | 41 | 28 | 4 | 1.33 | +85 | +21.2 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 4 | 1.33 | +188 | +47.0 |
| FOUR ROUNDS | 6 | 5 | 3 | 1.00 | +87 | +29.1 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 6 | 5 | 3 | 1.00 | +53 | +17.6 |
| THE ROW IN ITS ORDER | 31 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 29 | 29 | 3 | 1.00 | +178 | +59.3 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +41 | +20.6 |
| CHARGE NOW FIRST | 4 | 4 | 2 | 0.67 | -103 | -51.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 18 | 18 | 2 | 0.67 | +21 | +10.5 |
| IDLE COST | 44 | 39 | 2 | 0.67 | +11 | +5.4 |
| MAX FOR POSITIONING | 16 | 16 | 2 | 0.67 | +0 | +0.0 |
| MISSILES IN THE MOVE | 40 | 30 | 2 | 0.67 | +10 | +4.9 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -24 | -12.0 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 2 | 0.67 | -8 | -4.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS IN THE MOVE | 131 | 98 | 2 | 0.67 | +25 | +12.3 |
| TIED UP BY THE SUM | 3 | 2 | 2 | 0.67 | +79 | +39.7 |
| WAR ENGINE JOBS | 4 | 4 | 2 | 0.67 | -4 | -2.1 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.33 | -8 | -7.6 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -7 | -6.6 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +32 | +31.7 |
| EXACT ROUND | 4 | 3 | 1 | 0.33 | +5 | +4.9 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +313 | +312.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -24 | -24.1 |
| MISSILES NEXT TURN | 59 | 42 | 1 | 0.33 | +7 | +7.1 |
| OVERRUNS AWAY | 3 | 2 | 1 | 0.33 | +8 | +7.9 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -7 | -7.1 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -39 | -39.4 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +12 | +11.5 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT ADDS | 10 | 9 | 1 | 0.33 | +3 | +3.3 |
| SUPPORT WORKED OUT | 10 | 9 | 1 | 0.33 | +3 | +3.3 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +36 | +36.5 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 24 | 24 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 56 | 54 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 24 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 31 | 31 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 35 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 15 | 15 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 167 | 166 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 13 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 6 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 24 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 274 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 4 | 0 | 0.00 | - | - |
| RISK BY ARC | 5 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 4 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 80 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 45 | 41 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 17 | 17 | 0 | 0.00 | - | - |
| STANDS STILL | 249 | 249 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 295 | not checked | - | - | - | - |
| WAITS AGAIN | 18 | 18 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 17 | 16 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p30

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.33 | 1.00 | 32.9 |
| ARMY TABLE | rule | 2.00 | 2.00 | 43.5 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | - | 88.5 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 13.5 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 51.7 |
| OWN CAST FIRST | rule | 0.67 | - | 12.0 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 4.2 |
| WAR ENGINE JOBS | rule | 0.67 | - | 2.1 |
| AFTERMATH BAND | gate | 0.33 | - | 2.5 |
| CANNON PLANNED TARGET | rule | - | 0.33 | 65.8 |
| CATCH ODDS | rule | 0.33 | - | 7.6 |
| CHAFF PASSED | rule | - | 0.33 | 6.6 |
| MARCH OF THE TABLE | rule | 0.33 | - | 24.1 |
| NO REASON | gate | 0.33 | - | 4.9 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 7.1 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 39.4 |

### Plans: cnsr-c940641-p30

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 67 | 58 | 86% |
| Mine | move | 30.0 | 99% | 2415 | 0 | 0% |
| Mine | shoot | 14.7 | 48% | 1391 | 1625 | 117% |
| Opponent | charge | 0.3 | 100% | 42 | 76 | 180% |
| Opponent | move | 39.0 | 92% | 2498 | 0 | 0% |
| Opponent | shoot | 5.3 | 56% | 297 | 229 | 77% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p30

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p30

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 16 (10) | 16 | 0 | 13 | 40% | 2.8 | 23 (6) | 0 (4) | - | 21 (7) | 0 (3) |
| Mine | Clean-up | 3 | 44 (3) | 0 | 44 | 0 | 100% | - | 0 (1) | 67 (2) | - | 44 (3) | - |
| Mine | Fast Hammer | 3 | 6 (3) | 0 | 6 | 0 | 0% | 4.0 | 9 (2) | - | 0 (1) | 6 (3) | - |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 16 | 33% | 2.0 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Shooter | 6 | 139 (6) | 0 | 139 | 17 | 0% | 1.5 | 0 (1) | 212 (3) | 101 (2) | 139 (6) | - |
| Mine | War machine | 8 | 83 (8) | 83 | 0 | 35 | 0% | 1.5 | 0 (3) | 128 (3) | 127 (2) | 0 (1) | 94 (7) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Opponent | Chaff | 2 | 288 (2) | 0 | 288 | 44 | 100% | - | 514 (1) | 0 (1) | - | 514 (1) | 0 (1) |
| Opponent | Character | 9 | 12 (9) | 12 | 0 | 18 | 44% | 2.6 | 0 (1) | 12 (7) | 30 (1) | 19 (7) | 0 (2) |
| Opponent | Clean-up | 3 | 79 (3) | 0 | 79 | 0 | 100% | - | 0 (1) | 144 (2) | - | 144 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 76 (6) | 0 | 76 | 0 | 83% | 1.0 | - | 115 (4) | 16 (2) | 76 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 30 (4) | 30 | 0 | 74 | 25% | 2.0 | - | 58 (2) | 0 (2) | 30 (4) | - |
| Opponent | Holder | 4 | 8 (4) | 0 | 8 | 57 | 75% | 4.0 | - | 8 (4) | - | 0 (2) | 16 (2) |
| Opponent | Shooter | 4 | 27 (4) | 27 | 0 | 28 | 25% | 2.0 | 0 (1) | 0 (1) | 37 (2) | 31 (3) | 0 (1) |
| Opponent | War machine | 2 | 89 (2) | 89 | 0 | 0 | 0% | 1.0 | - | - | 89 (2) | 179 (1) | 0 (1) |

### Charged fights: cnsr-c940641-p30

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 240 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 675 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 1 of 3 | 2 of 3 | - | +0 |
| **Mine** | all armies | 3 | 385 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 3 | 2 of 3 | - | +0 |
| Opponent | High Elf Realms | 1 | 250 | 331 | 2.0 | 1.0 | 166 | 0 | +166 | 1 of 2 | 2 of 2 | - | +166 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 83 | 110 | 0.7 | 1.0 | 166 | 0 | +166 | 1 of 2 | 2 of 2 | - | +166 |

### Effective charges: cnsr-c940641-p30

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 1 | 0% (0 of 2) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +104) | 1 (net +227) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cnsr-c940641-p30

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 352 | 292 | +0 | 55 | 72 | -17 | -4.7 |
| Mine | No odds | 1 | 135 | 112 | +0 | 56 | 0 | +56 | +41.5 |
| Mine | All fights | 3 | 279 | 232 | +0 | 55 | 48 | +8 | +2.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 227 | +227 | 314 | 0 | +314 | +126.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 342 | 104 | +104 | 104 | 0 | +104 | +30.4 |
| Opponent | All fights | 2 | 294 | 166 | +166 | 209 | 0 | +209 | +70.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p30 | move | 19 | 5 (26%) | 4 (21%) | 0 (0%) | 14 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

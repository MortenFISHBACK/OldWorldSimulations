# Doctrine scorecard: cnsr-c940641-p38

### Scorecard: cnsr-c940641-p38

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 3 | 5 | 1 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 3 | 1 | 3 | 0 | 0 | 0 | 0 | 144 |
| L0307 | 1 | 1 | Mine | yes | 0 | - | 0 | 2 | 0 | 0 | 0 | 565 |
| L0307 | 1 | 1 | Opponent | no | 18 | 4 | 1 | 3 | 1 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 1 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 185 |
| **Average** | | | Mine | 33% | 0.0 | 2.0 | 1.3 | 3.0 | 0.3 | 0.0 | 0.0 | 385.0 |
| **Average** | | | Opponent | 33% | 10.5 | 2.7 | 1.7 | 2.0 | 0.3 | 0.0 | 0.0 | 234.7 |

### KPIs: cnsr-c940641-p38

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 58% (7 of 12) | 0% (0 of 16) | 25% (7 of 28) |
| Winner chose to follow up after the loser gave ground |  | 67% (4 of 6); on the table 83% | 100% (1 of 1); on the table 100% | 71% (5 of 7); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 83% | 50% (1 of 2); on the table 50% | 62% (5 of 8); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 28% (10 of 36) | 67% (4 of 6) | 33% (14 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 34% (10 of 29) | 67% (4 of 6) | 40% (14 of 35) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (1 of 2) | - | 50% (1 of 2) |
| Points that never fought | lower | 53% (3127 of 5897) | 57% (3411 of 5999) | 55% (6538 of 11896) |
|   infantry points that never fought | lower | 47% (679 of 1437) | 70% (658 of 938) | 56% (1337 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (14 of 22) | 50% (10 of 20) | 57% (24 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 25% (1 of 4); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (2807 of 4484) | 41% (1897 of 4648) | 52% (4704 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (58%) | 0.0 (0%) | 5.0 (54%) |
| MARCHED: its unit marched | 0.7 (8%) | 0.7 (100%) | 1.3 (14%) |
| IN COMBAT: engaged in combat | 0.7 (8%) | 0.0 (0%) | 0.7 (7%) |
| GONE: slain | 1.7 (19%) | 0.0 (0%) | 1.7 (18%) |
| STUPIDITY: Stupidity | 0.7 (8%) | 0.0 (0%) | 0.7 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 1.0 | 4.7 | 0.7 | 0.3 |
| not cast | 0.7 | 3.0 | 9.3 | 1.3 | 7.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 5.0 (54%) | 0.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (14%) | 0.7 (50%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (22%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (100%) | 0.0 (0%) | 1.7 (18%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.7 (22%) | 0.7 (7%) | 0.0 (0%) | 0.7 (9%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 1.7 (56%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.7 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 33% (1 of 3) | - | 33% (1 of 3) |
| the unit moved after it | 0% (0 of 1) | - | 0% (0 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 74% (39 of 53) | 71% (77 of 109) | 72% (116 of 162) |
|   cavalry | - | 87% (13 of 15) | 87% (13 of 15) |
|   character | - | 0% (0 of 16) | 0% (0 of 16) |
|   chariot | 61% (14 of 23) | 86% (6 of 7) | 67% (20 of 30) |
|   infantry | - | 78% (46 of 59) | 78% (46 of 59) |
|   war machine | 83% (25 of 30) | 100% (12 of 12) | 88% (37 of 42) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (14%) | 0.7 (6%) | 1.3 (9%) |
| CHARGED: it charged | 0.3 (7%) | 2.3 (22%) | 2.7 (17%) |
| IN COMBAT: it fought this turn or the last | 0.3 (7%) | 1.3 (12%) | 1.7 (11%) |
| MOVED: a war machine that moved | 0.7 (14%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.3 (7%) | 3.7 (34%) | 4.0 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (43%) | 2.0 (19%) | 4.0 (26%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.3 (7%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 0.7 | 89% | 0.5 pts | 3 pts |
| chariot | 6.7 | 5.3 | 55% | 28.7 pts | 192 pts |
| infantry | 18.0 | 8.3 | 69% | 9.5 pts | 171 pts |
| war machine | 12.7 | 13.0 | 68% | 40.4 pts | 511 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 3.7 | 3.0 |
| Charges that made contact a game | 1.3 | 2.3 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.35 declared, 0.20 contact (20 units) | 0.37 declared, 0.23 contact (30 units) | 0.36 declared, 0.22 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character in a unit | 80% (4 of 5) | 50% (1 of 2) | - | 71% (5 of 7) |
| Character on its own | 100% (1 of 1) | - | 20% (1 of 5) | 33% (2 of 6) |
| Chariot | - | 75% (3 of 4) | - | 75% (3 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| War Machines | 44% (4 of 9) | 100% (2 of 2) | - | 55% (6 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 60% (3 of 5); on the table 80% | 33% (4 of 12) | 16% | 50% (3 of 6) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (1 of 1); on the table 100% | 25% (6 of 24) | 71% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Empire of Man | 1 | - | 67% (4 of 6) | 91% | 70% (7 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 50% (1 of 2); on the table 50% | - | 40% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p38, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (3) | - | 43% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p38

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 57% (4 of 7) | 30% (3 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 62% (25 of 40) | 65% (22 of 34) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 86% (6 of 7) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 20% (1 of 5) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 385.0 | 234.7 |
| Movement | Fights charged into per game | 1.3 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 1 of 6, net -261 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +55 | 2 of 6, net +115 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 1 of 6, net +110 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net -132 | 1 of 6, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.7 | 24.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (5 of 14) | 36% (26 of 72) |
| Shooting | Points destroyed by shooting units | 93.7 | 109.3 |
| Shooting | War machine shots | 8.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 19% (5 of 26) | 58% (7 of 12) |
| Shooting | Points destroyed by war machines | 65.0 | 85.0 |
| Magic | Magic missiles cast | 0.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 33% (1 of 3) |
| Magic | Wounds caused by magic missiles | 2.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 5.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 345.3 | 196.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -17 | -11 |
| Combat | Net per 100 charger points, damage counted | -21.5 | -4.0 |
| Combat | First round won (charged fights) | 100% | 57% |
| Combat | Net points per charged fight | +2 | -4 |
| Combat | Net points per supported fight / lone fight | - / +2 | - / -4 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 4 | 3 of 7 |
| Game | Points lost | 695.3 | 494.0 |
| Game | VP from objectives | 466.7 | 773.3 |
| Game | Lone holders (player turns) | 0.0 | 10.5 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -369 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1189
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p38

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +18.3 | 0.0 | 56.7 | - | - | - | - |
| ARMY TABLE | 10.0 | +157.1 | 0.0 | 113.3 | 28.7 | +545.1 | 0.0 | 232.7 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 76.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -6.8 | 10.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | +4.4 | 0.0 | 65.0 |
| CANNON PLANNED TARGET | 8.0 | +316.8 | 210.7 | 340.0 | 4.0 | +81.4 | 56.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CAST JOB | 2.0 | +23.9 | 187.3 | 110.7 | 0.7 | +8.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +4.2 | 0.0 | 20.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +18.7 | 0.0 | 56.7 | 0.3 | +3.7 | 0.0 | 24.0 |
| CHARGE LOSSES | 21.3 | -540.2 | 0.0 | 268.0 | 19.0 | -369.9 | 0.0 | 294.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 24.0 | 17.3 | 1.0 | +0.0 | 102.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 56.7 | 11.3 | +0.0 | 0.0 | 158.7 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 143.7 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +22.1 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 10.7 | -839.0 | 0.0 | 73.3 | 2.7 | -76.1 | 0.0 | 18.3 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 65.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +16.7 | 105.0 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.0 | -2.8 | 64.3 | 17.3 | 3.3 | +63.1 | 319.0 | 65.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 70.0 | 17.3 | 3.3 | +5.3 | 301.7 | 208.7 |
| FALLS SHORT | 4.7 | +130.2 | 0.0 | 72.7 | 14.0 | +151.3 | 0.0 | 115.7 |
| FEATURE BUFFS | 5.0 | +91.9 | 0.0 | 0.0 | 2.7 | +55.3 | 0.0 | 130.0 |
| FIGHT TO THE END | - | - | - | - | 1.7 | +58.6 | 208.3 | 143.7 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 17.3 | 0.0 |
| FIVE ACTION | 79.7 | +4557.4 | 1137.7 | 1406.0 | 104.3 | +7801.3 | 1053.7 | 879.3 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 102.3 | 2.3 | +0.0 | 0.0 | 93.7 |
| FOLLOW UP WEIGHED | 0.3 | +35.3 | 0.0 | 0.0 | 0.3 | +40.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +37.8 | 88.3 | 17.3 | 3.7 | +361.4 | 319.0 | 208.7 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 34.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -5.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -1.8 | 0.0 | 28.3 | 1.7 | -13.6 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.3 | -14.8 | 0.0 | 208.7 |
| GOAL WALK | 13.3 | +743.5 | 0.0 | 56.7 | 17.7 | +2339.7 | 0.0 | 93.3 |
| GUN FIGURES | 3.3 | +90.6 | 187.3 | 103.3 | - | - | - | - |
| GUN MASK | - | - | - | - | 1.7 | -15.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 24.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 34.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 13.7 | +0.0 | 0.0 | 268.0 | 4.7 | +0.0 | 0.0 | 93.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +7.9 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 56.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -19.2 | 0.0 | 17.3 | 3.7 | -81.4 | 0.0 | 187.3 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 36.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 17.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 5.7 | +0.0 | 0.0 | 90.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 41.3 | +986.0 | 0.0 | 569.7 | 57.0 | +1903.8 | 0.0 | 610.0 |
| HIS SHOTS BY HIS RUN | 40.3 | +511.6 | 0.0 | 513.0 | 48.7 | +883.7 | 0.0 | 480.0 |
| HIS TURN DENIED | 1.0 | +5.7 | 70.0 | 17.3 | 1.0 | +10.8 | 76.7 | 65.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 18.7 | +0.0 | 0.0 | 0.0 | 22.7 | +0.0 | 0.0 | 214.7 |
| HOLDER ASSIGNMENT | 8.7 | +970.3 | 0.0 | 0.0 | 13.7 | +1023.4 | 0.0 | 107.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -21.4 | 88.3 | 17.3 | 2.7 | -97.5 | 290.7 | 143.7 |
| IDLE COST | 6.3 | -40.3 | 0.0 | 112.0 | 12.3 | -201.2 | 0.0 | 70.0 |
| JOINT CHARGE NOW | 0.7 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.3 | +9.9 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 36.7 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 18.3 | 160.0 | 11.3 | +0.0 | 403.3 | 332.7 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LONG SHOT | 1.3 | +20.5 | 64.3 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | -0.1 | 42.3 | 17.3 | 0.3 | -1.3 | 0.0 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.9 | 103.3 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +1.7 | 0.0 | 93.7 |
| MANOEUVRE | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | -22.0 | 0.0 | 23.3 |
| MARCH AT ESCAPER | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +14.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +20.1 | 0.0 | 28.3 | 0.7 | +98.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +23.4 | 0.0 | 112.0 | 2.3 | +23.5 | 0.0 | 93.7 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.3 | +138.8 | 0.0 | 83.7 | 1.3 | +16.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.3 | +94.6 | 0.0 | 140.3 | 1.7 | +41.0 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.7 | -7.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 10.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.7 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.7 | +130.0 | 0.0 | 74.0 | 7.0 | +546.6 | 0.0 | 93.7 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.7 | +226.0 | 0.0 | 0.0 | 12.3 | +542.6 | 0.0 | 70.0 |
| NEXT CHARGE BY LIST | 2.7 | +90.6 | 0.0 | 45.7 | 5.3 | +347.7 | 34.7 | 130.3 |
| NO DOUBLE ROUNDS | 2.0 | -17.0 | 88.3 | 17.3 | 3.7 | -143.5 | 319.0 | 208.7 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 36.7 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -81.8 | 0.0 | 181.7 | 7.7 | -359.6 | 0.0 | 65.0 |
| OGRE LOADER SECOND SHOT | 1.0 | +0.4 | 0.0 | 76.7 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | +0.7 | 24.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.3 | -11.8 | 0.0 | 45.7 | 8.0 | -184.5 | 0.0 | 93.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +254.1 | 0.0 | 65.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -41.3 | 0.0 | 0.0 | 4.7 | +29.0 | 0.0 | 89.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -4.2 | 34.7 | 36.7 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.0 | +46.5 | 36.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +0.6 | 18.3 | 0.0 | 1.0 | +14.6 | 149.0 | 0.0 |
| PLAN RESULT | 37.3 | +843.5 | 391.0 | 955.7 | 46.0 | +456.8 | 520.3 | 840.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 5.3 | -64.2 | 0.0 | 0.0 | 9.3 | -233.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -12.7 | 0.0 | 28.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.6 | 0.0 | 28.3 | 0.3 | -3.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 1.3 | -48.5 | 374.7 | 0.0 | 0.3 | -1.1 | 17.3 | 18.3 |
| QUARTER ODDS | 13.3 | +1121.7 | 0.0 | 73.3 | 19.3 | +2154.2 | 166.7 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +28.9 | 0.0 | 56.7 | 2.0 | +79.2 | 0.0 | 70.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 83.7 | 4.3 | +0.0 | 0.0 | 46.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +18.6 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -0.1 | 0.0 | 0.0 | 1.3 | -3.5 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +1.0 | 0.0 | 18.3 |
| RISK BY ARC | 2.3 | +49.3 | 88.3 | 17.3 | 3.3 | -43.0 | 262.3 | 208.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -19.7 | 113.3 | 208.7 |
| RUN DOWN | - | - | - | - | 1.3 | -3.0 | 105.0 | 143.7 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -149.3 | 0.0 | 20.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +36.7 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 18.3 |
| SECOND LOOK | - | - | - | - | 0.3 | +10.3 | 0.0 | 65.0 |
| SET CREDITED ONCE | 2.0 | -161.1 | 0.0 | 56.7 | 1.0 | -239.7 | 0.0 | 24.0 |
| SET UP BY THE SET | 3.0 | +263.0 | 0.0 | 85.0 | 3.0 | -43.4 | 0.0 | 24.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.7 | 0.0 | 93.7 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.0 | +0.0 | 0.0 | 405.3 | 12.0 | +0.0 | 0.0 | 18.3 |
| SHOOTS FROM THE BEST SPOT | 6.3 | +334.6 | 231.3 | 0.0 | 2.7 | +68.4 | 54.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -10.3 | 44.0 | 0.0 | 0.7 | -13.3 | 120.7 | 18.3 |
| SHOT RISK POINTS | 25.3 | -202.0 | 0.0 | 365.7 | 29.3 | +232.3 | 0.0 | 246.7 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +923.1 | 0.0 | 480.0 | 25.7 | +375.2 | 0.0 | 106.7 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -3.4 | 0.0 | 65.0 |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 148.0 | 5.0 | +0.0 | 0.0 | 141.0 |
| STAND AND SHOOT | 2.0 | -2.4 | 64.3 | 0.0 | 0.3 | -4.8 | 103.3 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 54.0 | 6.7 | +0.0 | 206.7 | 44.0 |
| STANDS STILL | 39.3 | +0.0 | 1049.3 | 920.7 | 39.3 | +0.0 | 734.7 | 104.7 |
| STANDS TO CAST | 0.3 | +0.7 | 0.0 | 27.0 | - | - | - | - |
| STAY WORTH | 25.3 | -399.6 | 608.7 | 1000.7 | 37.0 | +403.7 | 461.3 | 60.7 |
| STUBBORN BY POINTS | 0.3 | +7.9 | 0.0 | 76.7 | - | - | - | - |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| SUPPORT ADDS | 1.7 | +89.5 | 0.0 | 0.0 | 3.0 | +32.6 | 0.0 | 60.7 |
| SUPPORT WORKED OUT | 1.7 | +89.5 | 0.0 | 0.0 | 3.0 | +32.6 | 0.0 | 60.7 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +7.8 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 10.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -28.5 | 0.0 | 17.3 | 0.7 | -61.8 | 17.3 | 18.3 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 23.3 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 149.0 | 2.7 | +0.0 | 0.0 | 88.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.7 | +0.0 | 0.0 | 117.7 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 149.0 | 2.3 | +0.0 | 0.0 | 88.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.3 | +0.0 | 0.0 | 639.3 | 50.3 | +0.0 | 0.0 | 335.3 |
| TIED UP BY THE SUM | 0.7 | +31.6 | 24.0 | 17.3 | 1.0 | +120.3 | 74.0 | 0.0 |
| TIME ON OUR SIDE | 21.7 | +296.9 | 0.0 | 320.0 | 19.3 | +196.2 | 54.0 | 173.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 28.3 | 2.3 | +0.0 | 0.0 | 65.0 |
| WAR ENGINE JOBS | 2.0 | +0.0 | 187.3 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | -0.1 | 18.3 | 0.0 | 0.7 | -16.2 | 0.0 | 65.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +102.8 | 0.0 | 143.7 |
| WHOLE FIGHT DANGER | 2.3 | -237.7 | 0.0 | 90.7 | 1.0 | -74.2 | 0.0 | 187.3 |
| WOUNDS ON THE RANKS | 5.3 | +127.4 | 0.0 | 0.0 | 1.3 | +30.9 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p38

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 116 | 116 | 95 | 31.67 | +2007 | +21.1 |
| HIS SHOT LIST | 295 | 288 | 69 | 23.00 | +1785 | +25.9 |
| HOLDER ASSIGNMENT | 67 | 67 | 63 | 21.00 | +4618 | +73.3 |
| HIS SHOTS BY HIS RUN | 267 | 259 | 45 | 15.00 | +492 | +10.9 |
| LEGAL CHARGES ONLY | 42 | 42 | 42 | 14.00 | +0 | +0.0 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -1324 | -37.8 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| FIVE ACTION | 552 | 540 | 29 | 9.67 | +1297 | +44.7 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| GOAL WALK | 93 | 90 | 24 | 8.00 | +1855 | +77.3 |
| MOVE TO CHARGE COMPUTED | 32 | 28 | 19 | 6.33 | +550 | +29.0 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 123 | 105 | 19 | 6.33 | +59 | +3.1 |
| SHOT RISK POINTS | 164 | 158 | 17 | 5.67 | +1301 | +76.5 |
| NEXT CHARGE BY LIST | 24 | 23 | 15 | 5.00 | +487 | +32.5 |
| PROMISE BY ITS OWN SUM | 44 | 44 | 13 | 4.33 | -894 | -68.8 |
| SHOOTS FROM THE BEST SPOT | 27 | 27 | 13 | 4.33 | +565 | +43.5 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 18 | 17 | 8 | 2.67 | +425 | +53.1 |
| STAY WORTH | 187 | 167 | 8 | 2.67 | +18 | +2.2 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| QUARTER ODDS | 98 | 97 | 7 | 2.33 | +455 | +65.1 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 121 | 116 | 6 | 2.00 | +974 | +162.3 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SET UP BY THE SET | 18 | 18 | 6 | 2.00 | +709 | +118.2 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| MAX FOR POSITIONING | 14 | 13 | 5 | 1.67 | +15 | +3.1 |
| PROMISE SHOT AWAY | 5 | 5 | 5 | 1.67 | -149 | -29.8 |
| SHOTS IN THE MOVE | 122 | 93 | 5 | 1.67 | +221 | +44.3 |
| WOUNDS ON THE RANKS | 20 | 20 | 5 | 1.67 | +9 | +1.9 |
| CANNON PLANNED TARGET | 36 | 36 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +67 | +16.8 |
| FALLS SHORT | 56 | 50 | 4 | 1.33 | +107 | +26.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| SHOTS AFTER THE MOVES | 28 | 28 | 4 | 1.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.33 | +112 | +27.9 |
| CHARGE NOW FIRST | 5 | 5 | 3 | 1.00 | -21 | -7.1 |
| COVER ONCE | 40 | 28 | 3 | 1.00 | +32 | +10.7 |
| EXACT ROUND | 16 | 15 | 3 | 1.00 | +39 | +13.1 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 17 | 11 | 3 | 1.00 | +62 | +20.8 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +1 | +0.4 |
| RISK BY ARC | 17 | 16 | 3 | 1.00 | +77 | +25.7 |
| SUPPORT ADDS | 14 | 13 | 3 | 1.00 | +5 | +1.6 |
| SUPPORT WORKED OUT | 14 | 13 | 3 | 1.00 | +5 | +1.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| CAST JOB | 8 | 8 | 2 | 0.67 | +2 | +1.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +1 | +0.3 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +27 | +13.5 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +228 | +113.9 |
| HIS MOVE AND SHOT | 19 | 19 | 2 | 0.67 | +360 | +179.9 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +1 | +0.5 |
| NEARER NOT NEEDED | 51 | 49 | 2 | 0.67 | +83 | +41.7 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -13 | -6.3 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +3 | +1.4 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +111 | +55.6 |
| THE ROW IN ITS ORDER | 16 | 2 | 2 | 0.67 | +0 | +0.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -20 | -20.5 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GUN MASK | 5 | 5 | 1 | 0.33 | +36 | +35.8 |
| IDLE COST | 56 | 29 | 1 | 0.33 | +1 | +1.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +76 | +76.2 |
| LONG SHOT | 4 | 4 | 1 | 0.33 | +2 | +1.9 |
| MANOEUVRE | 15 | 15 | 1 | 0.33 | +6 | +5.9 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +11 | +11.4 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +24 | +24.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 31 | 21 | 1 | 0.33 | +1 | +1.2 |
| ONE OBJECTIVE FORMULA | 31 | 26 | 1 | 0.33 | +9 | +9.2 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +39 | +39.3 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +12 | +11.6 |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 1 | 0.33 | -38 | -38.0 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | -11 | -11.2 |
| RANDOM MOVE BY FIGURES | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 8 | 8 | 1 | 0.33 | +60 | +60.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +226 | +226.3 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -7 | -6.7 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +31 | +30.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -1 | -0.8 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +24 | +23.9 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +1 | +1.4 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +308 | +308.3 |
| BLOWS WHERE AIMED | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 63 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 14 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 23 | 23 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 16 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 55 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 16 | 16 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 14 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 17 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 124 | 124 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 19 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 17 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 250 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 75 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELLS IN THE FIGHT | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 31 | 23 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 22 | 21 | 0 | 0.00 | - | - |
| STANDS STILL | 236 | 231 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 260 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 11 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p38

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 7.00 | 23.5 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 3.00 | 68.8 |
| ARMY TABLE | rule | 0.33 | 2.00 | 24.1 |
| PROMISE SHOT AWAY | rule | 1.33 | 0.33 | 29.8 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 7.1 |
| RULE SWITCHED OFF | gate | - | 0.67 | 285.1 |
| AFTERMATH BAND | gate | 0.33 | - | 0.6 |
| BEST PRIZE | rule | - | 0.33 | 20.5 |
| JOINT CHARGE NOW | rule | 0.33 | - | 19.4 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 18.0 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 38.0 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 11.2 |
| REFUSING RETIRES | rule | - | 0.33 | 6.7 |
| RESERVE FALL BACK | rule | - | 0.33 | 25.3 |
| STANDS TO CAST | rule | 0.33 | - | 0.8 |

### Plans: cnsr-c940641-p38

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 97 | 112 | 116% |
| Mine | move | 22.7 | 93% | 1491 | 0 | 0% |
| Mine | shoot | 12.0 | 53% | 379 | 731 | 193% |
| Mine | support | 0.3 | 0% | 0 | 0 | 0% |
| Opponent | charge | 3.0 | 67% | 288 | 220 | 76% |
| Opponent | move | 34.3 | 95% | 2573 | 0 | 0% |
| Opponent | shoot | 8.7 | 46% | 533 | 237 | 44% |

### Battle groups: cnsr-c940641-p38

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 100% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 83% | 80% | 20% | 0% | 25% | 0% | 0% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p38

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 75 (7) | 75 | 0 | 8 | 14% | 2.7 | 0 (1) | 255 (1) | 67 (5) | 84 (6) | 0 (1) |
| Mine | Clean-up | 4 | 18 (4) | 18 | 0 | 24 | 75% | 3.0 | 0 (1) | 23 (3) | - | 0 (3) | 73 (1) |
| Mine | Fast Hammer | 5 | 22 (5) | 22 | 0 | 84 | 60% | 2.0 | - | 46 (3) | 0 (2) | 0 (4) | 138 (1) |
| Mine | Hammer | 9 | 22 (9) | 16 | 6 | 23 | 11% | 2.5 | 0 (1) | 26 (4) | 25 (4) | 30 (7) | 0 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 24 (8) | 24 | 0 | 67 | 0% | 1.1 | 25 (2) | 32 (5) | 0 (1) | 19 (3) | 27 (5) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 59 | 60% | 2.5 | 0 (1) | 0 (2) | 0 (2) | 0 (2) | 0 (3) |
| Opponent | Chaff | 5 | 24 (5) | 24 | 0 | 60 | 0% | 1.0 | 118 (1) | 0 (4) | - | 24 (5) | - |
| Opponent | Character | 8 | 27 (8) | 27 | 0 | 29 | 38% | 3.0 | 46 (3) | 10 (2) | 23 (3) | 28 (6) | 23 (2) |
| Opponent | Clean-up | 4 | 68 (4) | 0 | 68 | 29 | 100% | - | 0 (2) | 0 (1) | 139 (1) | 79 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 41 (6) | 20 | 22 | 17 | 50% | 3.7 | 0 (3) | 82 (3) | - | 0 (2) | 62 (4) |
| Opponent | Holder | 9 | 112 (9) | 9 | 103 | 19 | 0% | 1.9 | 16 (3) | 148 (4) | 176 (2) | 236 (4) | 9 (5) |
| Opponent | Shooter | 2 | 80 (2) | 55 | 25 | 0 | 0% | 1.5 | 59 (1) | 103 (1) | - | 59 (1) | 103 (1) |
| Opponent | War machine | 3 | 45 (3) | 45 | 0 | 33 | 33% | 1.0 | 45 (3) | - | - | 34 (2) | 68 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 38 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |

### Charged fights: cnsr-c940641-p38

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 344 | 3.0 | 1.0 | 115 | 0 | +115 | 0 of 3 | 3 of 3 | - | +115 |
| Mine | Chaos Dwarfs | 2 | 238 | 33 | 0.5 | 1.0 | 66 | 401 | -335 | 0 of 1 | 1 of 1 | - | -335 |
| **Mine** | all armies | 3 | 159 | 137 | 1.3 | 1.0 | 102 | 100 | +2 | 0 of 4 | 4 of 4 | - | +2 |
| Opponent | Empire of Man | 1 | 170 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 2 | 206 | 298 | 3.0 | 1.0 | 99 | 104 | -5 | 2 of 6 | 4 of 6 | - | -5 |
| **Opponent** | all armies | 3 | 194 | 198 | 2.3 | 1.0 | 85 | 89 | -4 | 3 of 7 | 4 of 7 | - | -4 |

### Effective charges: cnsr-c940641-p38

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 1 (net +55) | 1 (net +217) | 0 | 1 (net +72) | 0 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -335) | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 1 (net -261) | 0 | 1 (net +230) | 1 (net +85) | 1 (net +110) | 1 (net +0) | 1 | 20% (1 of 5) |

### Charged fights, damage counted: cnsr-c940641-p38

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 81 | 55 | +55 | 55 | 40 | +14 | +17.9 |
| Mine | 76-89% | 1 | 85 | 72 | +217 | 265 | 42 | +222 | +261.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 72 | 69 | -132 | 93 | 245 | -152 | -212.1 |
| Mine | All fights | 4 | 77 | 66 | +2 | 127 | 143 | -17 | -21.5 |
| Opponent | Long shot (under 50%) | 1 | 431 | 272 | -261 | 170 | 431 | -261 | -60.6 |
| Opponent | Effective (55-75%) | 2 | 192 | 272 | +115 | 189 | 64 | +126 | +65.5 |
| Opponent | 76-89% | 1 | 72 | 85 | +85 | 85 | 24 | +61 | +84.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 170 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 110 | +110 | 110 | 0 | +110 | +25.5 |
| Opponent | No odds | 1 | 195 | 272 | -195 | 157 | 397 | -240 | -123.0 |
| Opponent | All fights | 7 | 278 | 208 | -4 | 129 | 140 | -11 | -4.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p38 | move | 23 | 5 (22%) | 4 (17%) | 2 (9%) | 16 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

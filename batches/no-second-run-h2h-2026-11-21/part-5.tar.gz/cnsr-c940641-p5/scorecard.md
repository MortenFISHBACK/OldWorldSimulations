# Doctrine scorecard: cnsr-c940641-p5

### Scorecard: cnsr-c940641-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 0 | 4 | 3 | 2 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 6 | 6 | 1 | 0 | 1 | 0 | 0 | 141 |
| L0733 | 1 | 1 | Mine | no | 8 | 3 | 2 | 1 | 0 | 0 | 0 | 125 |
| L0733 | 1 | 1 | Opponent | no | 1 | 4 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 11 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 1 | 0 | 0 | 267 |
| **Average** | | | Mine | 0% | 6.3 | 3.5 | 1.7 | 1.3 | 0.0 | 0.0 | 0.0 | 338.3 |
| **Average** | | | Opponent | 33% | 2.3 | 4.0 | 2.0 | 2.3 | 0.7 | 0.0 | 0.0 | 136.0 |

### KPIs: cnsr-c940641-p5

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 75% (12 of 16) | 0% (0 of 12) | 43% (12 of 28) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 2); on the table 0% | 100% (3 of 3); on the table 100% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 33% | 80% (4 of 5); on the table 80% | 62% (5 of 8); on the table 62% |
| Magic missiles tried each own turn | 50%+ | 50% (6 of 12) | 17% (2 of 12) | 33% (8 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (6 of 9) | 17% (2 of 12) | 38% (8 of 21) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 71% (4229 of 5998) | 74% (4461 of 6000) | 72% (8690 of 11998) |
|   infantry points that never fought | lower | 48% (344 of 715) | 53% (756 of 1418) | 52% (1100 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (21 of 30) | 59% (13 of 22) | 65% (34 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3493 of 5389) | 54% (2690 of 5023) | 59% (6183 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (17%) | 3.0 (90%) | 3.3 (62%) |
| MARCHED: its unit marched | 0.7 (33%) | 0.3 (10%) | 1.0 (19%) |
| GONE: slain | 1.0 (50%) | 0.0 (0%) | 1.0 (19%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 0.3 | 2.7 | 1.0 | 0.0 |
| not cast | 3.7 | 1.7 | 5.3 | 1.0 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (9%) | 1.7 (100%) | 3.3 (62%) | 0.3 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (19%) | 0.3 (33%) | 0.0 (0%) |
| GONE: slain | 2.0 (55%) | 0.0 (0%) | 1.0 (19%) | 0.0 (0%) | 2.3 (19%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.7 (81%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 78% (69 of 89) | 72% (73 of 101) | 75% (142 of 190) |
|   cavalry | 75% (9 of 12) | 85% (17 of 20) | 81% (26 of 32) |
|   character | - | 53% (10 of 19) | 53% (10 of 19) |
|   chariot | 100% (2 of 2) | - | 100% (2 of 2) |
|   infantry | 67% (16 of 24) | 83% (45 of 54) | 78% (61 of 78) |
|   monster | - | 12% (1 of 8) | 12% (1 of 8) |
|   war machine | 82% (42 of 51) | - | 82% (42 of 51) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (40%) | 0.7 (7%) | 3.3 (21%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (21%) | 2.0 (12%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (7%) | 0.7 (4%) |
| MOVED: a war machine that moved | 0.7 (10%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.7 (10%) | 3.7 (39%) | 4.3 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (7%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (20%) | 1.3 (14%) | 2.7 (17%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 1.0 (15%) | 0.0 (0%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.3 | 3.3 | 79% | 7.8 pts | 88 pts |
| character | 3.3 | 0.3 | 90% | 2.1 pts | 7 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 28.7 | 8.3 | 79% | 8.3 pts | 238 pts |
| monster | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 14.0 | 13.3 | 52% | 36.9 pts | 517 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 3.7 | 2.7 |
| Charges that made contact a game | 1.3 | 1.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.22 declared, 0.17 contact (23 units) | 0.39 declared, 0.18 contact (28 units) | 0.31 declared, 0.18 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (6 of 9) | 33% (1 of 3) | - | 58% (7 of 12) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | 100% (1 of 1) | 100% (7 of 7) |
| Character on its own | 75% (3 of 4) | - | 33% (2 of 6) | 50% (5 of 10) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | 0% (0 of 1) | 17% (1 of 6) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 33% (1 of 3); on the table 33% | 50% (6 of 12) | 71% | 70% (21 of 30) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 33% (1 of 3); 0.3 uses a game |
| Lizardmen | 1 | - | - | 82% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 69% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (1 of 2); on the table 50% | 33% (2 of 6) | 73% | 70% (7 of 10) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p5, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 100% (2) | 57% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (4 of 4) | 44% (4 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (21 of 59) | 75% (12 of 16) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 20% (2 of 10) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.3 | 2.3 |
| Movement | Points that never moved of their own | 338.3 | 136.0 |
| Movement | Fights charged into per game | 1.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 1 of 4, net +210 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +0 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 1 of 4, net +130 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +0 | 1 of 4, net +265 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 25.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (14 of 28) | 46% (35 of 76) |
| Shooting | Points destroyed by shooting units | 136.3 | 194.0 |
| Shooting | War machine shots | 14.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (20 of 42) | - |
| Shooting | Points destroyed by war machines | 163.7 | 0.0 |
| Magic | Magic missiles cast | 2.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 6) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 5.3 | 2.7 |
| Magic | Wounds caused by other spells | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 34.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 0.0 / 0.0 | 2.3 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 0.0 | 160.0 |
| Combat | Points run down | 78.7 | 108.0 |
| Combat | Net points per charged fight, damage counted | +74 | +118 |
| Combat | Net per 100 charger points, damage counted | +39.4 | +43.5 |
| Combat | First round won (charged fights) | 100% | 80% |
| Combat | Net points per charged fight | +59 | +159 |
| Combat | Net points per supported fight / lone fight | - / +59 | - / +159 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 4 of 5 |
| Game | Points lost | 601.0 | 441.0 |
| Game | VP from objectives | 903.3 | 1046.7 |
| Game | Lone holders (player turns) | 6.3 | 2.3 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -311 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1042
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +145.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 18.0 | +145.4 | 0.0 | 186.0 | 27.3 | -192.1 | 0.0 | 140.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +2.8 | 0.0 | 67.3 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.7 | -49.6 | 45.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 222.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 13.3 | +272.9 | 822.7 | 301.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.7 | +163.0 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.7 | +12.7 | 63.0 | 0.0 |
| CATCH FLIERS | 0.3 | +13.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +3.0 | 0.0 | 0.0 | 0.7 | +12.7 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | -2.0 | 0.0 | 0.0 | 0.7 | -0.9 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 20.0 | -1290.6 | 0.0 | 978.3 | 17.0 | -1044.6 | 0.0 | 398.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 27.7 | 0.0 | 1.7 | +0.0 | 173.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 253.3 | 14.7 | +0.0 | 0.0 | 93.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 176.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 10.7 | -498.6 | 0.0 | 279.0 | 6.0 | -303.9 | 0.0 | 202.0 |
| DENIED BY THE FIGHT | 0.7 | -13.3 | 0.0 | 63.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 65.0 |
| EXACT ROUND | 1.0 | -24.4 | 0.0 | 63.0 | 2.7 | +89.1 | 188.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +46.3 | 78.7 | 63.0 | 2.3 | +0.0 | 125.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 20.0 | +232.6 | 0.0 | 113.3 |
| FEATURE BUFFS | 1.3 | +45.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +6.3 | 78.7 | 63.0 | 1.0 | +21.2 | 88.3 | 0.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 108.3 | +7546.0 | 2333.3 | 1805.0 | 93.7 | +6717.6 | 870.7 | 650.0 |
| FLANK NOT WEIGHED | 8.7 | +0.0 | 0.0 | 141.7 | 5.3 | +0.0 | 0.0 | 123.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +398.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +150.2 | 106.3 | 63.0 | 3.0 | +302.7 | 214.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 34.7 |
| FRIEND SHOOTS FIRST | 2.0 | -134.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| GOAL WALK | 6.0 | +442.1 | 0.0 | 0.0 | 14.0 | +851.5 | 0.0 | 69.3 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 88.3 | - | - | - | - |
| GUN MASK | 1.0 | +84.6 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.0 | +0.0 | 0.0 | 34.7 |
| HIS CHARGE BY HIS RUN | 14.0 | +0.0 | 0.0 | 843.7 | 9.3 | +0.0 | 0.0 | 246.7 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 134.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -39.6 | 0.0 | 388.0 | 2.0 | -42.4 | 0.0 | 0.0 |
| HIS ONE QUARTER | 9.0 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 12.7 |
| HIS OWN BEST MOVE | 11.0 | +0.0 | 0.0 | 134.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 45.3 | +1573.2 | 0.0 | 564.7 | 58.3 | +3343.5 | 0.0 | 311.0 |
| HIS SHOTS BY HIS RUN | 45.3 | +1125.0 | 0.0 | 1004.0 | 46.0 | +1777.4 | 0.0 | 492.7 |
| HIS TURN DENIED | 1.3 | +46.5 | 27.7 | 63.0 | 1.3 | +107.6 | 173.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 25.0 | +0.0 | 0.0 | 134.7 | 22.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 15.3 | +1471.5 | 0.0 | 67.3 | 16.0 | +1375.2 | 0.0 | 78.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -58.4 | 106.3 | 63.0 | 3.0 | -117.8 | 214.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +4.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.3 | -235.7 | 0.0 | 188.0 |
| KEPT FROM ITS LAST STOP | 7.3 | +0.0 | 0.0 | 134.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 83.0 | 114.0 | 15.3 | +0.0 | 581.7 | 44.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -0.8 | 106.3 | 63.0 | 1.0 | +0.9 | 25.7 | 0.0 |
| MANOEUVRE | 1.7 | +1.5 | 0.0 | 0.0 | 1.0 | +15.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +19.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.7 | +21.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -43.3 | 0.0 | 0.0 | 0.3 | +13.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +39.4 | 0.0 | 253.3 | 1.3 | +4.7 | 0.0 | 34.7 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +150.5 | 0.0 | 253.3 | 3.7 | +81.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +79.6 | 0.0 | 253.3 | 3.0 | +36.6 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 93.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +713.2 | 0.0 | 0.0 | 4.0 | +258.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +282.6 | 0.0 | 0.0 | 10.3 | +525.7 | 0.0 | 78.7 |
| NEXT CHARGE BY LIST | 5.0 | +508.1 | 0.0 | 0.0 | 2.0 | +153.2 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -68.3 | 106.3 | 63.0 | 3.0 | -123.2 | 214.0 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.6 | 0.0 | 253.3 | - | - | - | - |
| OFF BEST | 5.3 | -199.4 | 0.0 | 114.0 | 4.7 | -54.6 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -74.5 | 0.0 | 253.3 | 4.7 | -107.4 | 0.0 | 65.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -79.0 | 0.0 | 0.0 | 5.3 | -50.0 | 0.0 | 78.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -66.5 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 3.3 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +36.1 | 15.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +7.6 | 78.7 | 0.0 | 1.0 | +11.0 | 15.0 | 0.0 |
| PATHS CROSS | 0.3 | -5.0 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 49.7 | +1626.4 | 451.3 | 1115.3 | 41.7 | +330.7 | 272.7 | 572.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 5.3 | -17.0 | 0.0 | 0.0 | 6.3 | -149.5 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.3 | -58.7 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.7 | +2500.5 | 12.7 | 320.7 | 23.7 | +2784.2 | 429.7 | 12.7 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +142.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +57.3 | 0.0 | 0.0 | 2.3 | +41.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +187.9 | 0.0 | 12.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | -29.3 | 45.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -18.5 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +39.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | -57.7 | 106.3 | 63.0 | 2.0 | -287.7 | 145.0 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -38.1 | 110.7 | 0.0 |
| RUN DOWN | 1.7 | -10.7 | 106.3 | 63.0 | 2.0 | -9.3 | 110.7 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | -1.5 | 0.0 | 0.0 | 0.7 | +26.5 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +9.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -9.8 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.0 | +10.0 | 0.0 | 0.0 | 1.0 | -32.9 | 0.0 | 34.7 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 21.0 | +0.0 | 0.0 | 342.3 | 6.7 | +0.0 | 0.0 | 78.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +48.5 | 0.0 | 0.0 | 3.0 | +293.6 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -8.3 | 0.0 | 0.0 |
| SHOT RISK POINTS | 28.3 | -110.2 | 0.0 | 522.7 | 38.3 | +1321.0 | 0.0 | 486.3 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.7 | +1151.2 | 0.0 | 431.7 | 22.3 | +506.6 | 0.0 | 78.7 |
| SPELL WORTH | 0.7 | +10.3 | 56.7 | 56.7 | 4.0 | +33.9 | 78.7 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 126.7 | 4.0 | +0.0 | 0.0 | 41.0 |
| STAND AND SHOOT | 1.3 | -21.0 | 27.7 | 63.0 | 0.3 | -1.2 | 25.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 57.7 | +0.0 | 2227.0 | 738.0 | 25.0 | +0.0 | 656.7 | 192.0 |
| STAY WORTH | 50.0 | +633.2 | 1795.0 | 575.7 | 14.7 | +114.8 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +0.4 | 34.7 | 63.0 | 1.0 | +273.0 | 28.3 | 0.0 |
| SUPPORT ADDS | 6.0 | +411.3 | 0.0 | 0.0 | 4.7 | +424.2 | 0.0 | 104.0 |
| SUPPORT WORKED OUT | 6.0 | +411.3 | 0.0 | 0.0 | 4.7 | +424.2 | 0.0 | 104.0 |
| SURE REACH TOGETHER | 0.7 | +21.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 65.0 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 126.7 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 52.7 | +0.0 | 0.0 | 844.3 | 44.3 | +0.0 | 0.0 | 307.7 |
| TIED UP BY THE SUM | 0.7 | +45.6 | 27.7 | 0.0 | 1.3 | +147.0 | 100.0 | 0.0 |
| TIME ON OUR SIDE | 37.7 | +454.3 | 0.0 | 356.7 | - | - | - | - |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 34.7 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +10.8 | 0.0 | 63.0 | 0.7 | +247.7 | 0.0 | 0.0 |
| WHO HITS BACK | 0.7 | +44.9 | 0.0 | 0.0 | 0.3 | +48.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -743.2 | 0.0 | 455.7 | 1.7 | -214.1 | 0.0 | 58.3 |
| WOUNDS ON THE RANKS | 6.3 | +118.2 | 0.0 | 269.3 | 2.7 | +84.8 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 136 | 136 | 90 | 30.00 | -188 | -2.1 |
| HOLDER ASSIGNMENT | 94 | 94 | 83 | 27.67 | +4833 | +58.2 |
| HIS SHOT LIST | 311 | 306 | 75 | 25.00 | +2085 | +27.8 |
| HIS SHOTS BY HIS RUN | 274 | 272 | 63 | 21.00 | +953 | +15.1 |
| LEGAL CHARGES ONLY | 55 | 55 | 55 | 18.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| SHOT RISK POINTS | 200 | 196 | 32 | 10.67 | +1162 | +36.3 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -763 | -25.4 |
| QUARTER ODDS | 157 | 153 | 29 | 9.67 | +1719 | +59.3 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 113 | 92 | 17 | 5.67 | +36 | +2.1 |
| FIVE ACTION | 606 | 598 | 16 | 5.33 | +1919 | +119.9 |
| MOVE TO CHARGE COMPUTED | 31 | 28 | 14 | 4.67 | +1058 | +75.6 |
| CHARGE LOSSES | 111 | 111 | 13 | 4.33 | +467 | +35.9 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +462 | +35.5 |
| STAY WORTH | 194 | 176 | 13 | 4.33 | +56 | +4.3 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 21 | 20 | 12 | 4.00 | +637 | +53.1 |
| GOAL WALK | 60 | 60 | 10 | 3.33 | +454 | +45.4 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| SUPPORT ADDS | 32 | 32 | 9 | 3.00 | +509 | +56.5 |
| SUPPORT WORKED OUT | 32 | 32 | 9 | 3.00 | +509 | +56.5 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 8 | 2.67 | +214 | +26.8 |
| PROMISE BY ITS OWN SUM | 35 | 35 | 7 | 2.33 | -499 | -71.4 |
| THE RISK READS HIS RUN | 18 | 18 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOUR ROUNDS | 14 | 13 | 6 | 2.00 | +571 | +95.2 |
| SHOTS IN THE MOVE | 141 | 101 | 6 | 2.00 | +325 | +54.1 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF PASSED | 5 | 5 | 5 | 1.67 | -9 | -1.7 |
| COVER ONCE | 50 | 29 | 5 | 1.67 | +182 | +36.5 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| WOUNDS ON THE RANKS | 27 | 27 | 5 | 1.67 | +43 | +8.6 |
| EXACT ROUND | 11 | 10 | 4 | 1.33 | +64 | +15.9 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 18 | 15 | 4 | 1.33 | +94 | +23.5 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +159 | +39.8 |
| WHOLE FIGHT DANGER | 16 | 16 | 4 | 1.33 | +437 | +109.3 |
| CAST JOB | 8 | 8 | 3 | 1.00 | +60 | +20.0 |
| CHARGE NOW FIRST | 6 | 6 | 3 | 1.00 | -84 | -28.1 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 60 | 55 | 3 | 1.00 | +22 | +7.4 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +1195 | +398.2 |
| REDIRECT COUNTER | 9 | 6 | 3 | 1.00 | +97 | +32.3 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +227 | +75.7 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -149 | -74.4 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +15 | +7.4 |
| HIS TURN DENIED | 8 | 7 | 2 | 0.67 | +19 | +9.3 |
| HONEST WORTH | 14 | 13 | 2 | 0.67 | +8 | +4.1 |
| IDLE COST | 46 | 29 | 2 | 0.67 | +18 | +9.1 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +51 | +25.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +57 | +28.5 |
| MAX FOR POSITIONING | 8 | 8 | 2 | 0.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 51 | 47 | 2 | 0.67 | +44 | +21.9 |
| NO DOUBLE ROUNDS | 14 | 13 | 2 | 0.67 | +8 | +4.1 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -200 | -99.8 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +56 | +27.8 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +117 | +58.5 |
| RUN DOWN | 11 | 10 | 2 | 0.67 | +8 | +4.1 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +80 | +39.8 |
| SET UP BY THE SET | 6 | 6 | 2 | 0.67 | +254 | +127.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +28 | +14.1 |
| THE ROW IN ITS ORDER | 18 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 6 | 5 | 2 | 0.67 | +8 | +4.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +435 | +434.9 |
| CANNON PLANNED TARGET | 40 | 40 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 1 | 0.33 | +4 | +3.5 |
| FALL BACK GOOD ORDER | 11 | 10 | 1 | 0.33 | +116 | +115.7 |
| GUN MASK | 3 | 3 | 1 | 0.33 | +108 | +108.0 |
| HIS MOVE AND SHOT | 16 | 16 | 1 | 0.33 | +14 | +14.5 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +24 | +23.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -11 | -11.4 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +54 | +54.2 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -15 | -15.1 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | -0 | -0.5 |
| RISK BY ARC | 11 | 10 | 1 | 0.33 | +5 | +5.3 |
| ROUNDS AFTER TERROR | 6 | 6 | 1 | 0.33 | +7 | +7.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +27 | +27.0 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 4 | 4 | 1 | 0.33 | +38 | +37.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 20 | 16 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 66 | 66 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 11 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 3 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 70 | 69 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 23 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 38 | 37 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 53 | 50 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 53 | 51 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 143 | 143 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 34 | 34 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 13 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 27 | 14 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 31 | 24 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| OPENS A LANE | 10 | 9 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 274 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 83 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 29 | 29 | 0 | 0.00 | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 26 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 17 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 248 | 244 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 291 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 9 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 4.00 | 25.6 |
| ARMY TABLE | rule | 2.67 | 4.67 | 80.8 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 2.00 | 71.4 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.33 | 22.9 |
| CHAFF PASSED | rule | 0.67 | 0.67 | 2.2 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 28.1 |
| BEST PRIZE | rule | - | 0.67 | 74.4 |
| NO REASON | gate | - | 0.67 | 21.6 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 99.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 11.4 |
| PATHS CROSS | rule | 0.33 | - | 15.1 |
| RULE SWITCHED OFF | gate | 0.33 | - | 28.5 |

### Plans: cnsr-c940641-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 73 | 92 | 127% |
| Mine | join | 2.3 | 86% | 27 | 0 | 0% |
| Mine | move | 28.0 | 98% | 1980 | 0 | 0% |
| Mine | shoot | 18.0 | 69% | 1226 | 1534 | 125% |
| Opponent | charge | 2.3 | 57% | 297 | 213 | 72% |
| Opponent | move | 35.3 | 95% | 2209 | 0 | 0% |
| Opponent | shoot | 3.7 | 64% | 213 | 118 | 55% |
| Opponent | support | 0.3 | 100% | 106 | 0 | 0% |

### Battle groups: cnsr-c940641-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 18 (12) | 18 | 0 | 25 | 67% | 2.2 | 12 (6) | 0 (2) | 48 (3) | 31 (6) | 0 (5) |
| Mine | Clean-up | 1 | 164 (1) | 0 | 164 | 0 | 100% | - | - | 164 (1) | - | 164 (1) | - |
| Mine | Fast Hammer | 8 | 44 (8) | 13 | 31 | 25 | 50% | 3.5 | 53 (4) | 0 (3) | 101 (1) | 83 (4) | 0 (4) |
| Mine | Hammer | 2 | 14 (2) | 0 | 14 | 42 | 0% | 1.5 | - | 0 (1) | 24 (1) | 14 (2) | - |
| Mine | Shooter | 5 | 185 (5) | 45 | 140 | 16 | 0% | 1.4 | 136 (2) | 338 (1) | 71 (2) | 241 (3) | 71 (2) |
| Mine | War machine | 10 | 39 (10) | 39 | 0 | 41 | 0% | 1.4 | 0 (8) | 196 (2) | - | 0 (1) | 43 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 11 | 50% | 1.0 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Opponent | Character | 9 | 27 (9) | 27 | 0 | 5 | 44% | 1.2 | 0 (1) | 44 (4) | 21 (4) | 40 (5) | 7 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 5 | 35 (5) | 35 | 0 | 63 | 20% | 3.5 | 44 (1) | 65 (2) | 0 (2) | 17 (3) | 65 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 0% | 6.0 | 0 (3) | - | - | - | 0 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 61 | 33% | 1.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Holder | 3 | 386 (3) | 105 | 281 | 0 | 0% | 2.7 | 450 (1) | 450 (1) | 281 (1) | 450 (2) | 281 (1) |
| Opponent | Shooter | 7 | 128 (7) | 38 | 90 | 32 | 0% | 1.1 | 326 (2) | 71 (3) | 75 (2) | 146 (3) | 107 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cnsr-c940641-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 335 | 79 | 1.3 | 1.0 | 59 | 0 | +59 | 1 of 4 | 4 of 4 | - | +59 |
| Opponent | Lizardmen | 1 | 380 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 202 | 605 | 4.0 | 1.0 | 151 | 0 | +151 | 3 of 4 | 3 of 4 | - | +151 |
| Opponent | Wood Elf Realms | 1 | 0 | 189 | 1.0 | 1.0 | 189 | 0 | +189 | 1 of 1 | 1 of 1 | - | +189 |
| **Opponent** | all armies | 3 | 194 | 265 | 1.7 | 1.0 | 159 | 0 | +159 | 4 of 5 | 4 of 5 | - | +159 |

### Effective charges: cnsr-c940641-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 4 | 0 | 0 | 1 (net +0) | 1 (net +236) | 0 | 2 (net +0) | 0 | 25% (1 of 4) |
| Opponent | Tomb Kings of Khemri | 4 | 1 (net +210) | 0 | 0 | 1 (net +0) | 1 (net +130) | 1 (net +265) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: cnsr-c940641-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 189 | 208 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 181 | 236 | +236 | 277 | 87 | +190 | +104.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 189 | 109 | +0 | 52 | 0 | +52 | +27.7 |
| Mine | All fights | 4 | 187 | 166 | +59 | 95 | 22 | +74 | +39.4 |
| Opponent | Long shot (under 50%) | 1 | 195 | 371 | +210 | 243 | 179 | +64 | +32.7 |
| Opponent | 76-89% | 1 | 195 | 371 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 265 | +265 | 265 | 0 | +265 | +61.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 130 | +130 | 130 | 0 | +130 | +30.2 |
| Opponent | No odds | 1 | 104 | 189 | +189 | 294 | 164 | +130 | +125.5 |
| Opponent | All fights | 5 | 271 | 265 | +159 | 186 | 68 | +118 | +43.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p5 | move | 19 | 5 (26%) | 4 (21%) | 3 (16%) | 11 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

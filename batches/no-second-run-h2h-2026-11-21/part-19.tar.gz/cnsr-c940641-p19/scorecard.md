# Doctrine scorecard: cnsr-c940641-p19

### Scorecard: cnsr-c940641-p19

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 6 | 2 | 1 | 0 | 0 | 0 | 228 |
| L1135 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Opponent | no | 2 | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 2.0 | 2.0 | 1.0 | 0.0 | 0.0 | 0.0 | 220.0 |
| **Average** | | | Opponent | 0% | 2.0 | 5.0 | 1.7 | 1.0 | 0.0 | 0.0 | 0.0 | 76.0 |

### KPIs: cnsr-c940641-p19

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (4 of 13) | 0% (0 of 16) | 14% (4 of 29) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | 50% (3 of 6); on the table 50% | 100% (1 of 1); on the table 100% | 57% (4 of 7); on the table 57% |
| Winner chose to pursue after the loser fled |  | 100% (4 of 4); on the table 100% | - | 100% (4 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 70% (7 of 10); on the table 70% | 100% (1 of 1); on the table 100% | 73% (8 of 11); on the table 73% |
| Magic missiles tried each own turn | 50%+ | 32% (23 of 72) | 33% (6 of 18) | 32% (29 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (23 of 56) | 46% (6 of 13) | 42% (29 of 69) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 57% (3391 of 5998) | 27% (1646 of 6000) | 42% (5037 of 11998) |
|   infantry points that never fought | lower | 100% (730 of 730) | 84% (657 of 782) | 92% (1387 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 80% (20 of 25) | 69% (18 of 26) | 75% (38 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 71% (5 of 7); 6.0 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (6 of 9); 3.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 73% (4105 of 5614) | 67% (3781 of 5644) | 70% (7886 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.3 (27%) | 0.7 (17%) | 5.0 (25%) |
| MARCHED: its unit marched | 6.0 (37%) | 0.0 (0%) | 6.0 (30%) |
| CHARGED: its unit charged | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: engaged in combat | 5.3 (33%) | 0.0 (0%) | 5.3 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (17%) | 0.7 (3%) |
| GONE: slain | 0.0 (0%) | 1.0 (25%) | 1.0 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (17%) | 0.7 (3%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.0 (25%) | 1.0 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 5.7 | 1.3 | 9.7 | 1.0 | 4.3 |
| not cast | 1.3 | 10.3 | 4.7 | 20.3 | 3.0 | 23.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (13%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 7.3 (71%) | 0.0 (0%) | 5.0 (25%) | 0.3 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.0 (30%) | 1.7 (56%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.3 (26%) | 1.0 (33%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (19%) | 1.7 (36%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (50%) | 0.0 (0%) | 0.7 (14%) | 1.0 (5%) | 0.0 (0%) | 2.0 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (25%) | 0.7 (6%) | 0.7 (14%) | 0.7 (3%) | 0.0 (0%) | 1.3 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (25%) | 0.0 (0%) | 1.7 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.3 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 50% (2 of 4) | 50% (2 of 4) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (32 of 54) | 61% (47 of 77) | 60% (79 of 131) |
|   cavalry | - | 74% (14 of 19) | 74% (14 of 19) |
|   character | - | 64% (7 of 11) | 64% (7 of 11) |
|   chariot | 33% (4 of 12) | 89% (8 of 9) | 57% (12 of 21) |
|   infantry | 75% (9 of 12) | 34% (10 of 29) | 46% (19 of 41) |
|   monster | - | 89% (8 of 9) | 89% (8 of 9) |
|   war machine | 63% (19 of 30) | - | 63% (19 of 30) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (32%) | 4.3 (43%) | 6.7 (38%) |
| CHARGED: it charged | 1.3 (18%) | 1.3 (13%) | 2.7 (15%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.0 (14%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.7 (17%) | 1.7 (10%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (18%) | 1.7 (17%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 1.0 (14%) | 0.0 (0%) | 1.0 (6%) |
| OTHER BAR | 0.3 (5%) | 0.3 (3%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.0 | 83% | 7.3 pts | 44 pts |
| character | 2.3 | 0.7 | 86% | 15.1 pts | 35 pts |
| chariot | 4.0 | 2.7 | 67% | 34.8 pts | 139 pts |
| infantry | 9.3 | 1.3 | 86% | 4.8 pts | 45 pts |
| monster | 2.7 | 1.3 | 75% | 14.3 pts | 38 pts |
| war machine | 7.0 | 8.3 | 48% | 27.0 pts | 189 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 2.7 | 4.3 |
| Charges that made contact a game | 4.3 | 1.3 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 2.00 declared, 1.83 contact (6 units) | - | 2.00 declared, 1.83 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 1.00 contact (1 units) | - | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.11 contact (9 units) | 0.31 declared, 0.15 contact (26 units) | 0.34 declared, 0.14 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | - | 75% (3 of 4) | 70% (7 of 10) |
| Character in a unit | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Character on its own | 100% (1 of 1) | 67% (6 of 9) | 40% (2 of 5) | 60% (9 of 15) |
| Chariot | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Infantry | 75% (6 of 8) | - | - | 75% (6 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| War Machines | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 70% (7 of 10); on the table 70% | 32% (23 of 72) | 57% | 80% (20 of 25) | 71% (5 of 7); 6.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 40% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 50% (3 of 6) | 6% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 50% (3 of 6) | 37% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p19, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 17% (1) | 10% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p19

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 76% (13 of 17) | 50% (4 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (13 of 39) | 69% (11 of 16) |
| Strategy | Support requests answered (helper made contact too) | 100% (3 of 3) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (6 of 8) | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 100% (1 of 1) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 100% (7 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.0 | 1.0 |
| Movement | Points that never moved of their own | 220.0 | 76.0 |
| Movement | Fights charged into per game | 3.3 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 10, net +470 | 3 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 10, net +931 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 10, net +38 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 10, net +133 | 1 of 4, net +233 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.3 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 13) | 47% (23 of 49) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 6.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 32% (6 of 19) | - |
| Shooting | Points destroyed by war machines | 0.0 | 233.0 |
| Magic | Magic missiles cast | 6.0 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 17% (3 of 18) | 100% (5 of 5) |
| Magic | Wounds caused by magic missiles | 6.3 | - |
| Magic | Wounds caused by other spells | 3.7 | - |
| Magic | Points destroyed by magic (all spells) | 240.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 2.7 / 1.0 / 0.7 | 1.0 / 0.7 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 426.7 | 155.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +235 | +47 |
| Combat | Net per 100 charger points, damage counted | +59.8 | +23.5 |
| Combat | First round won (charged fights) | 90% | 50% |
| Combat | Net points per charged fight | +211 | +58 |
| Combat | Net points per supported fight / lone fight | +624 / +34 | - / +58 |
| Combat | Charged fights on a top-3 enemy unit | 7 of 10 | 3 of 4 |
| Game | Points lost | 388.3 | 1062.7 |
| Game | VP from objectives | 823.3 | 376.7 |
| Game | Lone holders (player turns) | 0.0 | 2.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +1171 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1451
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: cnsr-c940641-p19

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +33.7 | 0.0 | 77.7 | - | - | - | - |
| ARMY TABLE | 7.7 | +114.5 | 0.0 | 0.0 | 31.3 | +647.4 | 0.0 | 351.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.7 | +5.4 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 117.0 |
| BACKUP TARGETS | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -13.7 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | +6.6 | 0.0 | 52.7 |
| BOMBING RUN | 0.7 | +21.7 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.0 | +152.3 | 445.0 | 165.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.3 | +17.8 | 37.0 | 155.3 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 2.0 | +92.6 | 228.7 | 0.0 | 0.7 | +6.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 91.3 |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +11.1 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.3 | -456.6 | 0.0 | 456.3 | 17.7 | -652.4 | 0.0 | 603.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 488.0 | 155.3 | 1.0 | +0.0 | 110.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 22.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +183.1 | 52.7 | 182.7 |
| COVER ONCE | 5.3 | -208.9 | 0.0 | 55.0 | 4.7 | -575.2 | 0.0 | 125.3 |
| DENIED BY THE FIGHT | 0.3 | -2.9 | 52.7 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +14.6 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +21.6 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | +8.7 | 78.0 | 123.0 | 2.3 | -13.9 | 155.3 | 52.7 |
| FALL BACK GOOD ORDER | 3.7 | +3.9 | 589.0 | 77.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 4.3 | +87.5 | 0.0 | 200.7 | 22.3 | +326.8 | 0.0 | 397.3 |
| FEATURE BUFFS | 0.7 | +19.0 | 0.0 | 0.0 | 0.7 | +51.7 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.7 | +13.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.7 | +23.9 | 600.7 | 0.0 | 0.7 | +5.3 | 0.0 | 52.7 |
| FIVE ACTION | 83.3 | +6321.5 | 2645.3 | 1352.7 | 81.0 | +5424.4 | 1443.3 | 1162.0 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 123.0 | 4.3 | +0.0 | 0.0 | 95.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 6.0 | +1101.9 | 1214.7 | 200.7 | 2.7 | +147.5 | 155.3 | 52.7 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.3 | -6.5 | 302.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.7 | +278.5 | 0.0 | 0.0 | 14.0 | +1421.9 | 0.0 | 167.3 |
| GUN FIGURES | - | - | - | - | 0.7 | +105.9 | 55.0 | 61.7 |
| GUN MASK | 2.7 | +224.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.0 | +0.0 | 0.0 | 323.7 | 9.3 | +0.0 | 0.0 | 442.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +57.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 38.0 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 77.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -103.3 | 0.0 | 123.0 | 9.3 | -109.0 | 0.0 | 134.7 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 77.7 | 2.0 | +0.0 | 0.0 | 105.3 |
| HIS OWN BEST MOVE | 8.0 | +0.0 | 0.0 | 77.7 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 34.7 | +938.8 | 0.0 | 433.7 | 55.3 | +2966.2 | 0.0 | 834.0 |
| HIS SHOTS BY HIS RUN | 33.0 | +994.6 | 0.0 | 511.3 | 54.0 | +1847.6 | 0.0 | 834.7 |
| HIS TURN DENIED | 0.7 | +15.4 | 52.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.7 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 238.0 |
| HOLDER ASSIGNMENT | 9.7 | +977.1 | 0.0 | 0.0 | 8.0 | +842.2 | 0.0 | 195.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -128.6 | 691.3 | 200.7 | 2.0 | -75.9 | 77.7 | 0.0 |
| HUNT IN PAIRS | 0.3 | +44.0 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 0.7 | -30.8 | 0.0 | 0.0 | 10.7 | -141.2 | 0.0 | 120.7 |
| JOINT CHARGE NOW | 2.0 | +69.2 | 963.3 | 0.0 | 0.7 | +179.2 | 0.0 | 52.7 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | - | - | - | - | 4.7 | +0.0 | 77.7 | 461.3 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 4.0 | -18.0 | 1125.7 | 77.7 | 1.7 | +16.3 | 155.3 | 52.7 |
| LOST CHARGE | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 3.0 | -3.1 | 0.0 | 0.0 | 1.3 | +2.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +46.8 | 0.0 | 0.0 | 0.3 | +13.6 | 0.0 | 0.0 |
| MARCH CHECK | 2.0 | +92.5 | 0.0 | 0.0 | 0.7 | +29.6 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.0 | +128.2 | 0.0 | 0.0 | 0.3 | +102.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 2.3 | -26.1 | 0.0 | 200.7 | 0.3 | -16.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +54.3 | 0.0 | 77.7 | 1.7 | +73.4 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.7 | +212.4 | 0.0 | 155.3 | 3.7 | +30.3 | 0.0 | 119.0 |
| MISSILES NEXT TURN | 13.3 | +188.6 | 0.0 | 278.3 | 4.0 | +29.7 | 0.0 | 119.0 |
| MISSILES ON ONE TARGET | 1.0 | -10.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -17.6 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.7 | +332.7 | 0.0 | 0.0 | 3.7 | +213.6 | 0.0 | 41.7 |
| NEARER NOT NEEDED | 7.0 | +293.8 | 0.0 | 0.0 | 5.3 | +266.0 | 0.0 | 76.0 |
| NEXT CHARGE BY LIST | 2.7 | +303.9 | 0.0 | 0.0 | 3.3 | +195.4 | 0.0 | 41.7 |
| NEXT OBJECTIVE NEARER | 0.3 | -33.3 | 0.0 | 0.0 | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.0 | -205.0 | 359.0 | 77.7 | 2.3 | -86.9 | 77.7 | 52.7 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -101.1 | 0.0 | 132.7 | 4.0 | -131.4 | 0.0 | 41.7 |
| OGRE LOADER SECOND SHOT | 4.0 | +32.1 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -44.6 | 0.0 | 123.0 | 4.3 | -95.3 | 0.0 | 41.7 |
| ONE JOINT FIGURE | 0.7 | +263.1 | 362.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 5.3 | +128.9 | 0.0 | 0.0 | 1.7 | -70.2 | 0.0 | 119.0 |
| ONE ROUTE | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +8.2 | 11.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.3 | +60.3 | 53.0 | 123.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| OWN CAST FIRST | 0.3 | -0.4 | 0.0 | 0.0 | 0.7 | -2.1 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +7.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 37.3 | +1603.9 | 818.7 | 776.7 | 37.0 | +281.1 | 485.3 | 1203.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -113.8 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.0 | +2447.3 | 569.3 | 233.0 | 11.0 | +1113.7 | 77.7 | 198.7 |
| REAL GROUND | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +379.9 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -82.0 | 0.0 | 0.0 | 3.0 | -47.8 | 0.0 | 41.7 |
| RESERVE FALL BACK | 0.3 | +58.1 | 0.0 | 0.0 | 0.3 | +38.0 | 0.0 | 38.0 |
| RISK BY ARC | 5.3 | +64.6 | 1214.7 | 123.0 | 1.0 | -44.6 | 0.0 | 52.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -13.8 | 77.7 | 0.0 |
| RUN DOWN | 5.0 | -47.1 | 852.0 | 200.7 | 2.0 | -19.2 | 155.3 | 52.7 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +55.6 | 0.0 | 0.0 | 1.3 | +54.4 | 0.0 | 38.0 |
| SECOND LOOK | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 4.7 | -183.3 | 0.0 | 22.7 |
| SET UP BY THE SET | 0.3 | +4.2 | 0.0 | 0.0 | 6.7 | +280.4 | 0.0 | 22.7 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.3 | +0.0 | 0.0 | 242.7 | 5.3 | +0.0 | 0.0 | 84.7 |
| SHOOTS FROM THE BEST SPOT | 5.3 | +140.8 | 343.3 | 155.3 | 1.7 | +20.9 | 492.0 | 0.0 |
| SHOT OR CHARGE | 1.7 | -26.4 | 230.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 20.0 | -134.9 | 0.0 | 511.3 | 39.3 | +328.5 | 0.0 | 829.0 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.3 | +574.5 | 0.0 | 220.0 | 14.7 | +623.0 | 0.0 | 320.7 |
| SPELL WORTH | 1.3 | +23.3 | 0.0 | 0.0 | 2.7 | +44.8 | 182.7 | 299.7 |
| SPELLS IN THE FIGHT | 0.3 | +10.9 | 83.7 | 0.0 | 0.3 | +0.9 | 0.0 | 52.7 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 276.3 |
| STAND AND SHOOT | 0.3 | -3.4 | 83.7 | 0.0 | 0.3 | -1.6 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 0.0 | 38.0 |
| STANDS STILL | 45.7 | +0.0 | 1430.7 | 750.7 | 25.7 | +0.0 | 1288.0 | 244.3 |
| STANDS TO CAST | - | - | - | - | 0.3 | +42.9 | 0.0 | 0.0 |
| STAY WORTH | 30.7 | +209.1 | 1087.3 | 705.3 | 22.0 | +242.2 | 440.0 | 406.3 |
| STRIKE BY THE ODDS | 1.0 | +25.5 | 544.0 | 0.0 | 0.7 | +9.6 | 0.0 | 0.0 |
| SUPPORT ADDS | 0.3 | +13.9 | 0.0 | 0.0 | 6.3 | +510.5 | 0.0 | 79.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 155.3 | - | - | - | - |
| SUPPORT WORKED OUT | 0.3 | +13.9 | 0.0 | 0.0 | 6.3 | +510.5 | 0.0 | 79.7 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 83.7 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 136.3 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 172.0 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 160.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 34.0 | +0.0 | 0.0 | 443.3 | 37.7 | +0.0 | 0.0 | 554.7 |
| TIED UP BY THE SUM | 2.0 | +138.2 | 103.7 | 0.0 | 0.3 | +68.8 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 24.7 | +385.5 | 52.7 | 0.0 | 12.3 | +107.5 | 492.0 | 22.7 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 77.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -4.6 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.0 | +0.0 | 61.7 | 0.0 | 0.7 | +0.0 | 110.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -20.6 | 155.3 | 0.0 |
| WHO FIGHTS | 0.3 | -1.0 | 41.7 | 0.0 | - | - | - | - |
| WHO GETS IN | 0.7 | +100.8 | 362.7 | 0.0 | - | - | - | - |
| WHO HITS BACK | 1.0 | +311.5 | 0.0 | 123.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +3.6 | 77.7 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -33.7 | 0.0 | 0.0 | 0.7 | -62.3 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.7 | +86.1 | 362.7 | 0.0 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 6.3 | +95.9 | 0.0 | 0.0 | 5.3 | +173.4 | 0.0 | 238.0 |

### Rule changes: cnsr-c940641-p19

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 117 | 117 | 88 | 29.33 | +2059 | +23.4 |
| HIS SHOT LIST | 270 | 263 | 67 | 22.33 | +1805 | +26.9 |
| HIS SHOTS BY HIS RUN | 261 | 251 | 56 | 18.67 | +1333 | +23.8 |
| HOLDER ASSIGNMENT | 53 | 53 | 47 | 15.67 | +3292 | +70.0 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -698 | -24.1 |
| SHOT RISK POINTS | 178 | 169 | 28 | 9.33 | +941 | +33.6 |
| THE TABLE AGAIN | 35 | 35 | 28 | 9.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| GOAL WALK | 53 | 51 | 18 | 6.00 | +1387 | +77.0 |
| FIVE ACTION | 493 | 481 | 16 | 5.33 | +1377 | +86.1 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 15 | 5.00 | +199 | +13.3 |
| LEGAL CHARGES ONLY | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 22 | 21 | 14 | 4.67 | +758 | +54.1 |
| FOUR ROUNDS | 26 | 25 | 13 | 4.33 | +800 | +61.6 |
| STAY WORTH | 158 | 141 | 13 | 4.33 | +185 | +14.2 |
| NEXT CHARGE BY LIST | 18 | 18 | 12 | 4.00 | +704 | +58.7 |
| OGRE LOADER SECOND SHOT | 12 | 12 | 12 | 4.00 | +96 | +8.0 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| THE RISK READS HIS RUN | 18 | 18 | 10 | 3.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 111 | 99 | 10 | 3.33 | +59 | +5.9 |
| CHARGE LOSSES | 108 | 100 | 9 | 3.00 | +584 | +64.9 |
| SET UP BY THE SET | 21 | 21 | 9 | 3.00 | +268 | +29.8 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +745 | +93.1 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| QUARTER ODDS | 81 | 78 | 7 | 2.33 | +621 | +88.8 |
| SUPPORT ADDS | 20 | 17 | 7 | 2.33 | +473 | +67.5 |
| SUPPORT WORKED OUT | 20 | 17 | 7 | 2.33 | +473 | +67.5 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CAST JOB | 7 | 7 | 6 | 2.00 | +17 | +2.8 |
| COVER ONCE | 30 | 19 | 6 | 2.00 | +161 | +26.8 |
| PROMISE BY ITS OWN SUM | 27 | 27 | 6 | 2.00 | -342 | -56.9 |
| TIED UP BY THE SUM | 7 | 6 | 6 | 2.00 | +276 | +46.1 |
| WOUNDS ON THE RANKS | 35 | 35 | 6 | 2.00 | +96 | +16.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| MARCH CHECK | 8 | 8 | 5 | 1.67 | +170 | +34.0 |
| SEARCH SPOT | 7 | 7 | 5 | 1.67 | +330 | +66.0 |
| STRIKE BY THE ODDS | 5 | 5 | 5 | 1.67 | +105 | +21.1 |
| CASTING BLOCK | 8 | 8 | 4 | 1.33 | +73 | +18.2 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -691 | -172.6 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RISK BY ARC | 19 | 18 | 4 | 1.33 | +272 | +68.0 |
| SHOTS AFTER THE MOVES | 21 | 21 | 4 | 1.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +21 | +7.0 |
| IDLE COST | 34 | 22 | 3 | 1.00 | +45 | +14.9 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +181 | +60.4 |
| OVERRUNS AWAY | 5 | 5 | 3 | 1.00 | +79 | +26.2 |
| OWN CAST FIRST | 3 | 3 | 3 | 1.00 | -8 | -2.5 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +767 | +255.8 |
| BOMBING RUN | 2 | 2 | 2 | 0.67 | +65 | +32.6 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MISSILES NEXT TURN | 52 | 36 | 2 | 0.67 | +3 | +1.7 |
| ONE OBJECTIVE FORMULA | 21 | 19 | 2 | 0.67 | +176 | +87.8 |
| REDIRECT COUNTER | 9 | 9 | 2 | 0.67 | +139 | +69.6 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +288 | +144.1 |
| SHOTS IN THE MOVE | 81 | 63 | 2 | 0.67 | +185 | +92.7 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -128 | -63.9 |
| THE ROW IN ITS ORDER | 16 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +302 | +151.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +101 | +101.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +34 | +33.5 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -24 | -23.8 |
| CHARGE NOW FIRST | 12 | 12 | 1 | 0.33 | -58 | -57.5 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +13 | +13.3 |
| EVASIVE BY THE ODDS | 1 | 1 | 1 | 0.33 | +65 | +64.8 |
| FALLS SHORT | 80 | 62 | 1 | 0.33 | +8 | +8.4 |
| FEATURE BUFFS | 4 | 4 | 1 | 0.33 | +62 | +61.6 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +136 | +135.5 |
| HIS MOVE AND SHOT | 42 | 40 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 17 | 17 | 1 | 0.33 | +19 | +18.9 |
| MANOEUVRE | 13 | 13 | 1 | 0.33 | +8 | +8.5 |
| MAX FOR POSITIONING | 13 | 12 | 1 | 0.33 | +12 | +12.4 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +221 | +221.1 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +22 | +21.9 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +2 | +2.4 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -57 | -57.5 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -14 | -13.7 |
| WAR ENGINE JOBS | 5 | 5 | 1 | 0.33 | -3 | -3.4 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 18 | 18 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 36 | 35 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 14 | 13 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 13 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FIGHT TO THE END | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| GUN MASK | 8 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 61 | 59 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 36 | 35 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 37 | 37 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 43 | 43 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 79 | 78 | 0 | 0.00 | - | - |
| HONEST WORTH | 18 | 18 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 34 | 24 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEARER NOT NEEDED | 37 | 34 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 19 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 17 | 17 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 21 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 223 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | not checked | - | - | - | - |
| REAL GROUND | 5 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 13 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 21 | 20 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 14 | 14 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 50 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 34 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 214 | 210 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 215 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p19

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.00 | 26.1 |
| ARMY TABLE | rule | 1.33 | 2.33 | 98.6 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | - | 56.9 |
| HOLDER ASSIGNMENT | rule | - | 1.33 | 27.5 |
| MARCH OF THE TABLE | rule | 1.00 | 0.33 | 172.6 |
| NO REASON | gate | - | 1.00 | 22.2 |
| OWN CAST FIRST | rule | 0.33 | 0.67 | 2.5 |
| RULE SWITCHED OFF | gate | 0.67 | - | 2.6 |
| SET UP BY THE SET | rule | - | 0.67 | 13.3 |
| SUPPORT NARROWED | rule | 0.67 | - | 63.9 |
| BEST PRIZE | rule | 0.33 | - | 41.0 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 23.8 |
| CHARGE NOW FIRST | rule | 0.33 | - | 57.5 |
| JOINT CHARGE NOW | rule | 0.33 | - | 557.3 |
| STANDS TO CAST | rule | - | 0.33 | 57.5 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 13.7 |
| WAR ENGINE JOBS | rule | 0.33 | - | 3.4 |

### Plans: cnsr-c940641-p19

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.0 | 60% | 998 | 985 | 99% |
| Mine | move | 19.7 | 100% | 1471 | 0 | 0% |
| Mine | shoot | 12.7 | 53% | 604 | 619 | 102% |
| Opponent | charge | 1.0 | 0% | 79 | 52 | 66% |
| Opponent | move | 31.3 | 88% | 2122 | 0 | 0% |
| Opponent | shoot | 4.7 | 36% | 385 | 229 | 60% |

### Battle groups: cnsr-c940641-p19

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p19

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 97 (12) | 97 | 0 | 29 | 17% | 2.8 | - | 105 (8) | 83 (4) | 42 (6) | 128 (6) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 0 | 25% | 3.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Holder | 5 | 54 (5) | 13 | 41 | 0 | 40% | 2.3 | - | 67 (4) | 0 (1) | 88 (3) | 0 (2) |
| Mine | Shooter | 2 | 134 (2) | 0 | 134 | 0 | 0% | 1.0 | 62 (1) | 206 (1) | - | 134 (2) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 33 | 0% | 1.5 | 0 (2) | 0 (2) | 0 (2) | 0 (1) | 0 (5) |
| Opponent | Chaff | 6 | 263 (6) | 0 | 263 | 41 | 17% | 4.6 | 0 (5) | 1750 (1) | - | 370 (5) | 0 (1) |
| Opponent | Character | 7 | 24 (7) | 24 | 0 | 46 | 0% | 2.1 | 66 (2) | 29 (2) | - | 35 (3) | 47 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 36 | 0% | 3.3 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 4 | 13 (4) | 0 | 13 | 93 | 0% | 2.2 | - | 15 (3) | 0 (1) | 15 (3) | 0 (1) |
| Opponent | Hammer | 8 | 46 (8) | 46 | 0 | 37 | 25% | 2.5 | 189 (2) | 0 (2) | 0 (4) | 17 (5) | 95 (3) |
| Opponent | Holder | 1 | 108 (1) | 0 | 108 | 100 | 0% | 2.0 | - | 108 (1) | - | 108 (1) | - |
| Opponent | Shooter | 2 | 24 (2) | 0 | 24 | 56 | 0% | 2.0 | 43 (1) | 0 (1) | - | 24 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |

### Charged fights: cnsr-c940641-p19

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 240 | 782 | 3.3 | 1.3 | 234 | 23 | +211 | 7 of 10 | 9 of 10 | +624 | +34 |
| Opponent | Ogre Kingdoms | 1 | 699 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 233 | 3.0 | 1.0 | 78 | 0 | +78 | 3 of 3 | 1 of 3 | - | +78 |
| **Opponent** | all armies | 3 | 233 | 78 | 1.3 | 1.0 | 58 | 0 | +58 | 3 of 4 | 2 of 4 | - | +58 |

### Effective charges: cnsr-c940641-p19

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 10 | 2 (net +470) | 1 (net -233) | 1 (net +931) | 1 (net +0) | 2 (net +38) | 3 (net +133) | 0 | 10% (1 of 10) |
| Opponent | Ogre Kingdoms | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 3 | 2 (net +0) | 0 | 0 | 0 | 0 | 1 (net +233) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: cnsr-c940641-p19

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 648 | 426 | +470 | 470 | 0 | +470 | +72.5 |
| Mine | 50-54% | 1 | 233 | 297 | -233 | 57 | 233 | -176 | -75.5 |
| Mine | Effective (55-75%) | 1 | 713 | 494 | +931 | 986 | 0 | +986 | +138.4 |
| Mine | 76-89% | 1 | 369 | 251 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 205 | 147 | +133 | 200 | 25 | +175 | +85.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 352 | 38 | +38 | 38 | 0 | +38 | +10.7 |
| Mine | All fights | 10 | 393 | 241 | +211 | 266 | 31 | +235 | +59.8 |
| Opponent | Long shot (under 50%) | 3 | 98 | 289 | +0 | 7 | 23 | -16 | -15.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 233 | +233 | 233 | 0 | +233 | +46.7 |
| Opponent | All fights | 4 | 198 | 275 | +58 | 64 | 17 | +47 | +23.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p19 | move | 13 | 2 (15%) | 1 (8%) | 3 (23%) | 8 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

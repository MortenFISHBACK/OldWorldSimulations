# Doctrine scorecard: cnsr-c940641-p46

### Scorecard: cnsr-c940641-p46

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1827 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1927 | 1 | 1 | Mine | no | 0 | 1 | 6 | 0 | 1 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 0.0 | 1.0 | 3.0 | 1.0 | 1.0 | 0.0 | 0.0 | 337.5 |
| **Average** | | | Opponent | 0% | 2.0 | 2.0 | 2.5 | 3.0 | 1.0 | 0.0 | 0.0 | 85.0 |

### KPIs: cnsr-c940641-p46

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 0% (0 of 12) | 0% (0 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 100% (7 of 7); on the table 100% | 90% (9 of 10); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 24% (5 of 21) | 33% (3 of 9) | 27% (8 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (5 of 12) | 33% (3 of 9) | 38% (8 of 21) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (5 of 5) | 33% (2 of 6) | 64% (7 of 11) |
| Points that never fought | lower | 15% (610 of 3999) | 38% (1514 of 3999) | 27% (2124 of 7998) |
|   infantry points that never fought | lower | 39% (322 of 836) | 100% (619 of 619) | 65% (941 of 1455) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (9 of 15) | 46% (6 of 13) | 54% (15 of 28) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (2234 of 3466) | 35% (1201 of 3430) | 50% (3435 of 6896) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (12%) | 2.0 (100%) | 2.7 (36%) |
| MARCHED: its unit marched | 0.7 (12%) | 0.0 (0%) | 0.7 (9%) |
| IN COMBAT: engaged in combat | 2.0 (38%) | 0.0 (0%) | 2.0 (27%) |
| REAR RANK: in a rear rank | 0.7 (12%) | 0.0 (0%) | 0.7 (9%) |
| GONE: slain | 1.0 (19%) | 0.0 (0%) | 1.0 (14%) |
| NOT OFFERED: not in the cast list | 0.3 (6%) | 0.0 (0%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 2.0 | 2.7 | 0.7 | 1.7 |
| not cast | 7.7 | 6.0 | 7.3 | 2.3 | 24.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 2.7 (36%) | 1.0 (43%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 2.0 (27%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.0 (13%) | 1.0 (17%) | 0.7 (9%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (13%) | 0.0 (0%) | 1.0 (14%) | 0.0 (0%) | 1.7 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.0 (17%) | 0.0 (0%) | 1.0 (43%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.7 (74%) | 4.0 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 1.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 0% (0 of 3) | 33% (1 of 3) | 17% (1 of 6) |
| the unit moved after it | - | 100% (1 of 1) | 100% (1 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 88% (15 of 17) | 0% (0 of 8) | 60% (15 of 25) |
|   cavalry | - | 0% (0 of 3) | 0% (0 of 3) |
|   character | - | 0% (0 of 5) | 0% (0 of 5) |
|   infantry | 88% (15 of 17) | - | 88% (15 of 17) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (50%) | 0.0 (0%) | 0.3 (10%) |
| CHARGED: it charged | 0.0 (0%) | 1.3 (50%) | 1.3 (40%) |
| NO TARGET IN RANGE | 0.3 (50%) | 0.7 (25%) | 1.0 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (12%) | 0.3 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (12%) | 0.3 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| infantry | 5.3 | 3.0 | 56% | 27.6 pts | 147 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 4.7 | 4.7 |
| Charges that made contact a game | 4.0 | 2.7 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.43 contact (28 units) | 0.50 declared, 0.27 contact (26 units) | 0.50 declared, 0.35 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (1 of 2) | 33% (1 of 3) | 0% (0 of 1) | 33% (2 of 6) |
| Character in a unit | 50% (2 of 4) | 100% (1 of 1) | - | 60% (3 of 5) |
| Character on its own | 100% (2 of 2) | - | 60% (3 of 5) | 71% (5 of 7) |
| Infantry | 50% (2 of 4) | 0% (0 of 1) | - | 40% (2 of 5) |
| Monster | 0% (0 of 1) | 100% (2 of 2) | - | 67% (2 of 3) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Orc & Goblin Tribes | 1 | - | 42% (5 of 12) | 3% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 67% (2 of 3); on the table 67% | 0% (0 of 6) | 28% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (7 of 7); on the table 100% | 17% (1 of 6) | 25% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 51% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p46, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (3) | 38% (3) | 38% (6) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p46

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 57% (4 of 7) | 29% (4 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (5 of 10) | - |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 25% (1 of 4) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 100% (4 of 4) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 75% (3 of 4) | 83% (5 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 3.0 |
| Movement | Points that never moved of their own | 337.5 | 85.0 |
| Movement | Fights charged into per game | 3.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net -210 | 4 of 6, net +309 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (9 of 15) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 164.7 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 5) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 0.7 | - |
| Magic | Wounds caused by other spells | 0.3 | 3.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.7 / 0.0 | 0.7 / 0.0 / 1.0 / 0.3 |
| Combat | Points destroyed in combat | 252.7 | 658.3 |
| Combat | Points run down | 0.0 | 36.7 |
| Combat | Net points per charged fight, damage counted | +24 | +198 |
| Combat | Net per 100 charger points, damage counted | +8.8 | +62.0 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +24 | +245 |
| Combat | Net points per supported fight / lone fight | -210 / +71 | - / +245 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 3 of 6 |
| Game | Points lost | 1208.5 | 627.0 |
| Game | VP from objectives | 455.0 | 900.0 |
| Game | Lone holders (player turns) | 0.0 | 2.0 |

- Mine won / drew / lost: 0 / 0 / 2 of 2 ended games (of 3); mean margin (Mine - Opponent) -1026 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1836
- Games not ended: 1 (L1827-1); findings 1, warnings 0

### Opponent rules: cnsr-c940641-p46

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +12.5 | 0.0 | 0.0 |
| ARMY TABLE | 21.0 | +221.9 | 0.0 | 180.0 | 15.3 | +150.0 | 0.0 | 128.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +9.7 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.3 | +22.5 | 160.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +16.6 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | -8.5 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +16.6 | 0.0 | 16.7 |
| CHARGE LOSSES | 6.7 | -920.7 | 0.0 | 549.7 | 11.7 | -731.5 | 0.0 | 1155.3 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 233.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 85.0 | 20.7 | +0.0 | 0.0 | 89.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 116.7 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +58.7 | 64.0 | 31.7 | 1.0 | +10.7 | 0.0 | 0.0 |
| COVER ONCE | 5.3 | -295.2 | 0.0 | 78.3 | 3.0 | -116.2 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 0.0 | 7.0 | +58.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +33.4 | 70.0 | 0.0 |
| EXACT ROUND | 1.3 | +10.9 | 0.0 | 0.0 | 4.3 | +11.4 | 398.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +4.9 | 361.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 16.7 | +190.4 | 0.0 | 72.3 |
| FEATURE BUFFS | 1.0 | +13.6 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | -0.1 | 0.0 | 0.0 | 2.0 | +25.6 | 85.0 | 0.0 |
| FIVE ACTION | 62.3 | +4685.9 | 489.3 | 1048.0 | 75.3 | +5324.3 | 468.3 | 1480.7 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 180.0 | 2.7 | +0.0 | 0.0 | 181.3 |
| FOLLOW UP WEIGHED | 1.0 | +115.4 | 0.0 | 0.0 | 1.3 | +204.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +73.5 | 0.0 | 18.3 | 4.7 | +310.8 | 468.3 | 0.0 |
| FREED FROM HIS FIGHT | 4.7 | +0.0 | 0.0 | 156.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -4.9 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -1.5 | 180.0 | 0.0 |
| GOAL WALK | 15.0 | +1718.4 | 0.0 | 85.0 | 8.3 | +1107.9 | 0.0 | 0.0 |
| GUN FIGURES | 5.3 | +130.9 | 329.3 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 4.0 | +0.0 | 0.0 | 156.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.7 | +0.0 | 0.0 | 421.7 | 4.7 | +0.0 | 0.0 | 666.0 |
| HIS CHARGE DENIED | 0.3 | +20.5 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 156.7 | - | - | - | - |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 116.7 | 4.0 | +0.0 | 0.0 | 15.0 |
| HIS MOVE AND SHOT | - | - | - | - | 3.3 | -218.5 | 0.0 | 494.0 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 329.3 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 116.7 | 6.3 | +0.0 | 0.0 | 15.0 |
| HIS RANDOM MOVE | 12.3 | +0.0 | 0.0 | 351.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 3.0 | +0.0 | 0.0 | 128.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 8.0 | +103.3 | 0.0 | 293.3 | 27.7 | +706.3 | 0.0 | 494.0 |
| HIS SHOTS BY HIS RUN | 9.0 | +71.4 | 0.0 | 0.0 | 30.3 | +328.2 | 0.0 | 1358.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +4.1 | 0.0 | 0.0 |
| HIS TURN RUN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 9.7 | +0.0 | 0.0 | 128.0 | 11.7 | +0.0 | 0.0 | 573.3 |
| HOLDER ASSIGNMENT | 6.3 | +691.4 | 0.0 | 64.0 | 7.7 | +938.4 | 0.0 | 286.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -9.8 | 0.0 | 0.0 | 4.0 | -94.0 | 288.3 | 0.0 |
| IDLE COST | - | - | - | - | 17.3 | -204.4 | 0.0 | 31.7 |
| JOINT CHARGE NOW | 1.3 | +29.6 | 0.0 | 0.0 | 1.7 | +12.5 | 133.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 15.0 | 231.7 | 5.0 | +0.0 | 431.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 2.3 | -12.7 | 658.7 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.1 | 0.0 | 18.3 | 3.0 | +10.0 | 270.0 | 0.0 |
| MANOEUVRE | 2.0 | +14.4 | 0.0 | 64.0 | 1.0 | +1.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +66.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +13.0 | 0.0 | 180.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +125.8 | 0.0 | 0.0 | 3.0 | +83.4 | 0.0 | 0.0 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 0.0 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +35.0 | 0.0 | 0.0 | 1.7 | +3.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.3 | +19.0 | 0.0 | 180.0 | 2.3 | +2.6 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 180.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -2.2 | 0.0 | 31.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +150.2 | 0.0 | 116.7 | 7.3 | +700.1 | 0.0 | 30.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.0 | +278.5 | 0.0 | 64.0 | 4.0 | +166.1 | 0.0 | 40.7 |
| NEXT CHARGE BY LIST | 2.3 | +141.0 | 0.0 | 0.0 | 3.0 | +335.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -74.3 | 0.0 | 0.0 | 4.3 | -176.7 | 468.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 2.0 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 1.7 | -72.3 | 0.0 | 0.0 | 3.7 | -93.1 | 0.0 | 15.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.0 | -12.4 | 0.0 | 0.0 | 6.3 | -127.2 | 0.0 | 30.0 |
| ONE JOINT FIGURE | 0.7 | +35.4 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 1.7 | +31.5 | 0.0 | 64.0 | 2.3 | -17.7 | 0.0 | 286.7 |
| ONE PROMISE A TARGET | 0.7 | -32.5 | 0.0 | 0.0 | 1.0 | -29.9 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +11.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.7 | +18.2 | 121.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +28.6 | 0.0 | 0.0 |
| PLAN RESULT | 29.3 | +232.2 | 181.3 | 1268.0 | 35.3 | +476.0 | 156.7 | 760.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.0 | -109.8 | 0.0 | 116.7 | 9.0 | -359.9 | 0.0 | 30.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | +0.0 | 0.0 | 30.0 |
| QUARTER ODDS | 9.7 | +979.1 | 472.7 | 61.7 | 15.0 | +2384.9 | 55.0 | 692.0 |
| RANDOM MOVE BY FIGURES | 1.7 | +213.1 | 0.0 | 140.0 | 2.0 | +54.6 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.0 | +187.5 | 0.0 | 0.0 | 1.3 | +48.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +0.0 | 0.0 | 18.3 | 2.0 | +0.0 | 0.0 | 30.0 |
| REFORMS TO MEET IT | 2.3 | -52.8 | 0.0 | 0.0 | 1.0 | -8.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +78.8 | 0.0 | 18.3 | 4.3 | +55.5 | 450.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.7 | -75.0 | 200.0 | 0.0 |
| RUN DOWN | 0.3 | -3.4 | 0.0 | 0.0 | 3.7 | -28.1 | 218.3 | 0.0 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -68.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +25.0 | 0.0 | 180.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -310.8 | 0.0 | 16.7 |
| SET UP BY THE SET | 1.0 | +32.6 | 0.0 | 0.0 | 1.7 | +282.7 | 0.0 | 16.7 |
| SHOOTERS ON THE TABLE | 2.7 | +0.0 | 0.0 | 180.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +39.6 | 0.0 | 180.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -8.1 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 2.7 | -3.3 | 0.0 | 0.0 | 19.7 | -3.5 | 0.0 | 898.7 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 9.7 | +588.5 | 0.0 | 21.7 | 0.3 | +7.2 | 0.0 | 164.7 |
| SPELL WORTH | 0.7 | +15.7 | 180.0 | 180.0 | 1.0 | +8.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +2.7 | 0.0 | 0.0 | 0.3 | +2.7 | 85.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.7 | +0.0 | 0.0 | 231.7 | 9.7 | +0.0 | 0.0 | 16.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.3 | 0.0 | 0.0 |
| STANDS STILL | 17.7 | +0.0 | 489.3 | 250.0 | 14.0 | +0.0 | 0.0 | 16.7 |
| STAY WORTH | 7.0 | +198.5 | 329.3 | 21.7 | - | - | - | - |
| STRIKE BY THE ODDS | 1.0 | +5.2 | 430.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 12.0 | +844.1 | 0.0 | 128.0 | 6.7 | +241.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 12.0 | +844.1 | 0.0 | 128.0 | 6.7 | +241.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +0.8 | 0.0 | 15.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 21.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 21.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 78.3 | 3.3 | +0.0 | 0.0 | 40.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.3 | +0.0 | 0.0 | 16.7 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 78.3 | 2.7 | +0.0 | 0.0 | 40.7 |
| THE TABLE AGAIN | 4.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 27.7 | +0.0 | 0.0 | 344.0 | 36.7 | +0.0 | 0.0 | 720.0 |
| TIED UP BY THE SUM | 0.7 | +9.9 | 0.0 | 0.0 | 1.3 | +139.2 | 148.3 | 0.0 |
| TIME ON OUR SIDE | 30.3 | +361.9 | 16.7 | 322.3 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 116.7 | 2.3 | +0.0 | 0.0 | 15.0 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.0 | -11.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | -0.6 | 0.0 | 0.0 | 2.0 | +19.2 | 78.3 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.7 | +11.0 | 78.3 | 0.0 |
| WHO HITS BACK | 0.7 | +129.0 | 0.0 | 70.0 | 0.7 | +50.1 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +27.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 6.3 | -889.2 | 0.0 | 549.7 | 1.0 | -206.0 | 0.0 | 286.7 |
| WHOLE FIGHT GAIN | 0.7 | +15.6 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 1.3 | +30.4 | 0.0 | 143.3 |

### Rule changes: cnsr-c940641-p46

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 109 | 109 | 76 | 25.33 | +1246 | +16.4 |
| HOLDER ASSIGNMENT | 42 | 42 | 36 | 12.00 | +2814 | +78.2 |
| LEGAL CHARGES ONLY | 28 | 28 | 28 | 9.33 | +0 | +0.0 |
| FIVE ACTION | 413 | 409 | 27 | 9.00 | +1431 | +53.0 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| THE TABLE AGAIN | 28 | 28 | 25 | 8.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 118 | 117 | 23 | 7.67 | +110 | +4.8 |
| SUPPORT ADDS | 56 | 55 | 20 | 6.67 | +821 | +41.1 |
| SUPPORT WORKED OUT | 56 | 55 | 20 | 6.67 | +821 | +41.1 |
| MOVE TO CHARGE COMPUTED | 30 | 28 | 17 | 5.67 | +463 | +27.2 |
| REDIRECT FOR A FRIEND IN REACH | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| OFF BEST | 16 | 16 | 16 | 5.33 | -496 | -31.0 |
| PROMISE BY ITS OWN SUM | 39 | 39 | 16 | 5.33 | -1410 | -88.1 |
| GOAL WALK | 70 | 70 | 15 | 5.00 | +1356 | +90.4 |
| HIS SHOT LIST | 107 | 107 | 14 | 4.67 | +114 | +8.2 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| FOUR ROUNDS | 21 | 21 | 9 | 3.00 | +481 | +53.4 |
| IDLE COST | 52 | 36 | 9 | 3.00 | +33 | +3.7 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +127 | +14.1 |
| MAX FOR POSITIONING | 16 | 16 | 8 | 2.67 | +93 | +11.6 |
| CHARGE NOW FIRST | 13 | 13 | 7 | 2.33 | -260 | -37.2 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +960 | +137.1 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| NEXT CHARGE BY LIST | 16 | 16 | 7 | 2.33 | +440 | +62.9 |
| QUARTER ODDS | 74 | 74 | 7 | 2.33 | +608 | +86.9 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 7 | 2.33 | +803 | +114.7 |
| TIME ON OUR SIDE | 91 | 74 | 7 | 2.33 | +84 | +12.0 |
| SHOTS IN THE MOVE | 30 | 22 | 6 | 2.00 | +302 | +50.3 |
| THE RISK READS HIS RUN | 15 | 15 | 6 | 2.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 22 | 20 | 6 | 2.00 | +695 | +115.8 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -187 | -37.5 |
| RISK BY ARC | 19 | 19 | 5 | 1.67 | +242 | +48.5 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 5 | 1.67 | +37 | +7.5 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +6 | +1.4 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 25 | 15 | 4 | 1.33 | +49 | +12.3 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOT RISK POINTS | 67 | 66 | 4 | 1.33 | +47 | +11.6 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +410 | +102.4 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +30 | +10.1 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -25 | -8.5 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +86 | +28.6 |
| REDIRECT COUNTER | 13 | 9 | 3 | 1.00 | +180 | +60.1 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +16 | +5.3 |
| THE ROW IN ITS ORDER | 24 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +74 | +36.8 |
| CHARGE LOSSES | 55 | 52 | 2 | 0.67 | +87 | +43.5 |
| HARD STAY DROPPED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +48 | +24.1 |
| TIED UP BY THE SUM | 6 | 6 | 2 | 0.67 | +130 | +65.2 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +33 | +16.5 |
| WOUNDS ON THE RANKS | 4 | 4 | 2 | 0.67 | +42 | +20.8 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +38 | +37.5 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +24 | +24.0 |
| EXACT ROUND | 17 | 17 | 1 | 0.33 | +4 | +4.0 |
| FALLS SHORT | 50 | 41 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +60 | +60.0 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +200 | +199.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 33 | 30 | 1 | 0.33 | +8 | +7.6 |
| NO DOUBLE ROUNDS | 17 | 17 | 1 | 0.33 | +4 | +4.0 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +60 | +60.0 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +8 | +8.3 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -16 | -16.2 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +75 | +75.0 |
| SET UP BY THE SET | 8 | 8 | 1 | 0.33 | -41 | -41.2 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.33 | +52 | +52.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +2 | +2.2 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 79 | 79 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 14 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 21 | 19 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 16 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 16 | 16 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 28 | 25 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 6 | 6 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 19 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 10 | 9 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 51 | 51 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 30 | 30 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 15 | 15 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 30 | 30 | 0 | 0.00 | - | - |
| HOLD ODDS | 64 | 64 | 0 | 0.00 | - | - |
| HONEST WORTH | 16 | 16 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONG SHOT | 8 | 8 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 9 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 14 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 30 | 30 | 0 | 0.00 | - | - |
| NO SECOND RUN | 13 | 13 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 14 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 12 | 10 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 194 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 10 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 10 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 52 | 45 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 95 | 93 | 0 | 0.00 | - | - |
| STAY WORTH | 21 | 19 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 193 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p46

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 4.33 | 2.33 | 89.3 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 4.00 | 88.1 |
| JOB FIRST | gate | 1.33 | 3.00 | 37.7 |
| CHARGE NOW FIRST | rule | 0.67 | 1.67 | 37.2 |
| ONE PROMISE A TARGET | rule | 0.67 | 1.00 | 37.5 |
| JOINT CHARGE NOW | rule | 0.33 | 1.00 | 19.8 |
| FIGHT ORDER BAND | gate | 0.33 | 0.67 | 2.1 |
| CHAFF PASSED | rule | 0.67 | - | 12.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 1.9 |
| REFUSING RETIRES | rule | - | 0.33 | 16.2 |
| SET UP BY THE SET | rule | - | 0.33 | 41.2 |
| WHO GETS IN | rule | - | 0.33 | 18.8 |

### Plans: cnsr-c940641-p46

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 50% | 197 | 115 | 59% |
| Mine | move | 25.3 | 88% | 1777 | 0 | 0% |
| Mine | shoot | 2.0 | 33% | 259 | 117 | 45% |
| Opponent | charge | 2.7 | 62% | 413 | 476 | 115% |
| Opponent | join | 2.0 | 100% | 75 | 0 | 0% |
| Opponent | move | 30.3 | 96% | 1729 | 0 | 0% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p46

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 11% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p46

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 50% | 2.0 | 0 (2) | - | - | 0 (2) | - |
| Mine | Character | 5 | 17 (5) | 17 | 0 | 87 | 20% | 2.8 | 0 (1) | 81 (2) | 0 (1) | 35 (3) | 0 (1) |
| Mine | Clean-up | 2 | 13 (2) | 0 | 13 | 0 | 50% | 4.0 | 13 (2) | - | - | 0 (1) | 15 (1) |
| Mine | Fast Hammer | 1 | 158 (1) | 158 | 0 | 0 | 0% | 4.0 | - | 158 (1) | - | 158 (1) | - |
| Mine | Hammer | 5 | 3 (5) | 0 | 3 | 105 | 0% | 2.4 | 0 (2) | 10 (2) | 0 (1) | 4 (4) | 0 (1) |
| Mine | Holder | 3 | 36 (3) | 0 | 36 | 46 | 33% | 3.5 | 0 (1) | 66 (2) | - | 36 (3) | - |
| Mine | Shooter | 3 | 253 (3) | 253 | 0 | 33 | 0% | 1.3 | 0 (1) | 380 (2) | - | 380 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 20 | 0% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 28 | 60% | 3.0 | 0 (3) | 0 (1) | 0 (1) | 0 (2) | 0 (3) |
| Opponent | Character | 6 | 94 (6) | 94 | 0 | 50 | 17% | 3.4 | 116 (2) | 27 (2) | 152 (1) | 138 (4) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 68 (5) | 48 | 21 | 37 | 20% | 3.2 | - | 31 (3) | 142 (2) | 68 (5) | - |
| Opponent | Hammer | 2 | 144 (2) | 71 | 73 | 0 | 50% | 3.0 | - | 144 (2) | - | 207 (1) | 111 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | - | 0 (2) |

### Charged fights: cnsr-c940641-p46

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Orc & Goblin Tribes | 1 | 0 | 758 | 5.0 | 1.0 | 152 | 81 | +71 | 2 of 5 | 3 of 5 | - | +71 |
| Mine | Skaven | 1 | 494 | 0 | 1.0 | 2.0 | 0 | 210 | -210 | 0 of 1 | 1 of 1 | -210 | - |
| **Mine** | all armies | 2 | 247 | 379 | 3.0 | 1.2 | 126 | 102 | +24 | 2 of 6 | 4 of 6 | -210 | +71 |
| Opponent | Vampire Counts | 1 | 0 | 655 | 3.0 | 1.0 | 218 | 0 | +218 | 1 of 3 | 3 of 3 | - | +218 |
| Opponent | Warriors of Chaos | 1 | 0 | 815 | 3.0 | 1.0 | 272 | 0 | +272 | 2 of 3 | 3 of 3 | - | +272 |
| **Opponent** | all armies | 2 | 0 | 735 | 3.0 | 1.0 | 245 | 0 | +245 | 3 of 6 | 6 of 6 | - | +245 |

### Effective charges: cnsr-c940641-p46

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -210) | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 0 | 1 (net +235) | 0 | 2 (net +210) | 0 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +408) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: cnsr-c940641-p46

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 197 | 205 | -210 | 0 | 210 | -210 | -106.6 |
| Mine | No odds | 5 | 287 | 199 | +71 | 152 | 81 | +71 | +24.6 |
| Mine | All fights | 6 | 272 | 200 | +24 | 126 | 102 | +24 | +8.8 |
| Opponent | Effective (55-75%) | 1 | 85 | 197 | +0 | 46 | 102 | -56 | -66.2 |
| Opponent | 76-89% | 1 | 186 | 235 | +235 | 235 | 0 | +235 | +126.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 411 | 285 | +309 | 317 | 64 | +252 | +61.4 |
| Opponent | All fights | 6 | 319 | 262 | +245 | 258 | 60 | +198 | +62.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p46 | move | 20 | 6 (30%) | 3 (15%) | 1 (5%) | 13 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

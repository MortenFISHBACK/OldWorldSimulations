# Doctrine scorecard: cnsr-c940641-p15

### Scorecard: cnsr-c940641-p15

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 13 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 375 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 310 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 633 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 13.0 | 2.0 | 0.3 | 2.7 | 0.0 | 0.0 | 0.0 | 314.3 |
| **Average** | | | Opponent | 0% | 0.0 | 3.0 | 1.0 | 2.0 | 0.3 | 0.0 | 0.0 | 125.0 |

### KPIs: cnsr-c940641-p15

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 15) | 0% (0 of 30) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Magic missiles tried each own turn | 50%+ | 75% (9 of 12) | 56% (20 of 36) | 60% (29 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 82% (9 of 11) | 57% (20 of 35) | 63% (29 of 46) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 65% (3886 of 5998) | 83% (4985 of 5998) | 74% (8871 of 11996) |
|   infantry points that never fought | lower | 66% (946 of 1424) | 100% (1187 of 1187) | 82% (2133 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (14 of 23) | 85% (23 of 27) | 74% (37 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.3 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2777 of 5120) | 89% (4831 of 5442) | 72% (7608 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (56%) | 3.0 (47%) |
| MARCHED: its unit marched | 0.7 (67%) | 2.0 (38%) | 2.7 (42%) |
| IN COMBAT: engaged in combat | 0.3 (33%) | 0.0 (0%) | 0.3 (5%) |
| GONE: slain | 0.0 (0%) | 0.3 (6%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 2.0 | 2.0 | 9.7 | 0.7 | 0.3 |
| not cast | 4.0 | 4.0 | 4.0 | 6.3 | 1.3 | 19.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (92%) | 3.7 (92%) | 3.0 (47%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (42%) | 0.3 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (75%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 1.7 (8%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.7 (92%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (90%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.0 a game | 1.0 a game |
| stood (cast and not dispelled) | - | 67% (4 of 6) | 67% (4 of 6) |
| the unit moved after it | - | 50% (2 of 4) | 50% (2 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (56 of 86) | 68% (47 of 69) | 66% (103 of 155) |
|   cavalry | 58% (7 of 12) | - | 58% (7 of 12) |
|   character | 92% (12 of 13) | 100% (3 of 3) | 94% (15 of 16) |
|   chariot | 29% (7 of 24) | 75% (3 of 4) | 36% (10 of 28) |
|   infantry | 50% (6 of 12) | 54% (14 of 26) | 53% (20 of 38) |
|   monster | - | 83% (5 of 6) | 83% (5 of 6) |
|   war machine | 96% (24 of 25) | 73% (22 of 30) | 84% (46 of 55) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (17%) | 1.0 (14%) | 2.7 (15%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.7 (9%) | 0.7 (4%) |
| NO TARGET IN RANGE | 6.0 (60%) | 1.0 (14%) | 7.0 (40%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (20%) | 3.3 (45%) | 5.3 (31%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (14%) | 1.0 (6%) |
| STUPIDITY | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 5.0 | 1.0 | 80% | 7.3 pts | 37 pts |
| chariot | 3.3 | 4.0 | 50% | 28.0 pts | 93 pts |
| infantry | 8.7 | 1.7 | 81% | 11.1 pts | 96 pts |
| monster | 3.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 15.7 | 12.0 | 60% | 19.4 pts | 303 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 1.0 | 1.0 |
| Charges that made contact a game | 0.7 | 0.7 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.00 declared, 0.00 contact (3 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.05 contact (21 units) | 0.11 declared, 0.06 contact (18 units) | 0.10 declared, 0.05 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | 100% (2 of 2) | - | 83% (5 of 6) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| Character on its own | 100% (2 of 2) | 67% (4 of 6) | 50% (2 of 4) | 67% (8 of 12) |
| Chariot | - | 80% (4 of 5) | - | 80% (4 of 5) |
| Infantry | 67% (8 of 12) | 67% (2 of 3) | - | 67% (10 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | - | 75% (9 of 12) | 80% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | 0% (0 of 1); on the table 0% | - | 35% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 50% (6 of 12) | 100% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 50% (9 of 18) | 79% | 78% (7 of 9) | 100% (3 of 3); 10.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 70% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p15, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 50% (1) | 75% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p15

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 33% (1 of 3) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (11 of 38) | 34% (19 of 56) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 100% (5 of 5) | 17% (1 of 6) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 25% (2 of 8) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 2.7 | 2.0 |
| Movement | Points that never moved of their own | 314.3 | 125.0 |
| Movement | Fights charged into per game | 0.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 1, net +75 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (19 of 32) | 93% (25 of 27) |
| Shooting | Points destroyed by shooting units | 85.3 | 0.0 |
| Shooting | War machine shots | 8.0 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (16 of 24) | 23% (5 of 22) |
| Shooting | Points destroyed by war machines | 144.7 | 131.3 |
| Magic | Magic missiles cast | 2.0 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (2 of 6) | 70% (7 of 10) |
| Magic | Wounds caused by magic missiles | 7.0 | 0.7 |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 119.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 0.0 / 0.0 | 1.3 / 1.7 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 25.0 | 46.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +38 | +23 |
| Combat | Net per 100 charger points, damage counted | +9.2 | +10.8 |
| Combat | First round won (charged fights) | 50% | 0% |
| Combat | Net points per charged fight | +38 | +69 |
| Combat | Net points per supported fight / lone fight | - / +38 | - / +69 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 2 of 2 |
| Game | Points lost | 177.3 | 341.0 |
| Game | VP from objectives | 866.7 | 376.7 |
| Game | Lone holders (player turns) | 13.0 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +670 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 518
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p15

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 22.3 | -164.7 | 0.0 | 0.0 | 23.0 | +219.9 | 0.0 | 84.7 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 63.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +7.6 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -52.7 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 7.7 | +8.3 | 434.0 | 63.3 | 6.7 | +137.8 | 331.3 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.3 | +104.1 | 138.7 | 0.0 | 9.3 | +94.7 | 86.7 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 70.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +10.8 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.0 | -566.6 | 0.0 | 185.3 | 14.3 | -622.7 | 0.0 | 613.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 25.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +74.5 | 70.3 | 140.7 |
| COVER ONCE | 15.7 | -1505.3 | 0.0 | 109.7 | 8.7 | -1056.9 | 0.0 | 179.3 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | - | - | - | - | 0.7 | -37.1 | 0.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 25.0 | 0.0 | 1.0 | +0.2 | 0.0 | 0.0 |
| FALLS SHORT | 8.0 | +115.8 | 0.0 | 0.0 | 21.0 | +194.3 | 0.0 | 439.0 |
| FEATURE BUFFS | 0.7 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +16.7 | 0.0 | 0.0 | 1.0 | +2.4 | 0.0 | 0.0 |
| FIVE ACTION | 107.7 | +5719.7 | 1644.3 | 355.3 | 101.7 | +3519.6 | 822.0 | 1272.3 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 114.3 | 7.0 | +0.0 | 0.0 | 204.3 |
| FOUR ROUNDS | 1.0 | +115.8 | 25.0 | 0.0 | 1.0 | +82.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -0.1 | 0.0 | 144.7 |
| GIVES UP | 0.3 | -2.6 | 0.0 | 0.0 | 0.7 | -10.6 | 0.0 | 0.0 |
| GOAL WALK | 12.0 | +913.8 | 0.0 | 0.0 | 4.3 | +237.1 | 0.0 | 169.3 |
| GUN FIGURES | 1.3 | +34.3 | 100.3 | 0.0 | 0.7 | +20.0 | 0.0 | 0.0 |
| GUN MASK | 1.3 | +64.9 | 0.0 | 0.0 | 1.0 | -10.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 185.3 | 9.3 | +0.0 | 0.0 | 324.0 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -40.0 | 0.0 | 0.0 | 1.0 | -6.3 | 0.0 | 0.0 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 170.7 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 54.0 | +4295.7 | 0.0 | 228.7 | 52.0 | +3580.2 | 0.0 | 1272.3 |
| HIS SHOTS BY HIS RUN | 34.3 | +757.9 | 0.0 | 228.7 | 35.0 | +658.9 | 0.0 | 743.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +25.9 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.0 | +950.5 | 0.0 | 0.0 | 6.3 | +506.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -61.5 | 25.0 | 0.0 | 1.0 | -46.5 | 0.0 | 0.0 |
| HUNT IN PAIRS | 1.0 | +42.7 | 0.0 | 0.0 | 3.0 | +348.5 | 0.0 | 144.7 |
| IDLE COST | 5.3 | -94.5 | 0.0 | 0.0 | 11.3 | -170.5 | 0.0 | 339.0 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.0 | -11.6 | 0.0 | 0.0 |
| LOST CHARGE | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | +2.2 | 0.0 | 21.7 | 3.7 | -27.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +14.7 | 0.0 | 0.0 | 0.3 | +2.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +32.0 | 0.0 | 0.0 | 3.3 | +219.0 | 0.0 | 144.7 |
| MARCH OF THE TABLE | 0.3 | +7.4 | 0.0 | 0.0 | 1.0 | +29.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +1.9 | 0.0 | 0.0 | 1.3 | +115.3 | 0.0 | 144.7 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +137.5 | 0.0 | 0.0 | 4.0 | +133.1 | 0.0 | 289.3 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +123.3 | 0.0 | 0.0 | 11.3 | +93.6 | 0.0 | 144.7 |
| MISSILES NEXT TURN | 3.0 | +75.5 | 0.0 | 0.0 | 12.3 | +99.6 | 0.0 | 289.3 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 34.7 |
| MOVE SPELL IN RANGE | 3.7 | +135.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.3 | +30.4 | 0.0 | 0.0 | 1.3 | +35.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.3 | +416.9 | 0.0 | 0.0 | 9.7 | +440.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +16.4 | 0.0 | 0.0 | 0.7 | +10.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -20.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -1.0 | 25.0 | 0.0 | 0.7 | -16.1 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 6.0 | -390.3 | 0.0 | 0.0 | 5.3 | -201.0 | 0.0 | 144.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.7 | +21.7 | 21.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -97.3 | 0.0 | 46.3 | 1.7 | -28.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.0 | -53.3 | 0.0 | 0.0 | 2.7 | -113.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 3.0 | +55.4 | 86.7 | 0.0 |
| OPENS UP | 0.7 | +32.5 | 25.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.7 | +28.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -11.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 46.7 | +835.9 | 682.7 | 262.7 | 46.0 | +382.2 | 225.7 | 664.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.7 | -90.6 | 0.0 | 0.0 | 3.3 | -22.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -0.1 | 0.0 | 144.7 |
| QUARTER ODDS | 22.7 | +2266.0 | 69.3 | 185.3 | 20.3 | +1265.6 | 648.7 | 240.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +352.9 | 0.0 | 21.7 | 1.7 | +284.2 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 30.0 |
| REFORMS TO MEET IT | 0.7 | -27.3 | 0.0 | 0.0 | 0.7 | -41.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | +49.6 | 25.0 | 0.0 | 1.0 | -13.4 | 0.0 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -29.4 | 0.0 | 15.0 |
| SEARCH SPOT | 0.7 | +27.1 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 4.7 | -300.8 | 0.0 | 289.3 |
| SET UP BY THE SET | - | - | - | - | 5.3 | +366.9 | 0.0 | 289.3 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.3 | +0.0 | 0.0 | 63.3 | 18.3 | +0.0 | 0.0 | 70.3 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +173.7 | 543.3 | 0.0 | 3.3 | +15.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -6.8 | 0.0 | 0.0 |
| SHOT RISK POINTS | 25.3 | +124.5 | 0.0 | 228.7 | 23.7 | +114.5 | 0.0 | 1053.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.3 | +332.3 | 0.0 | 63.3 | 19.7 | +530.7 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +1.7 | 0.0 | 0.0 | 1.7 | +44.4 | 289.3 | 289.3 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 374.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 43.3 | 289.3 |
| STANDS STILL | 62.0 | +0.0 | 1619.3 | 355.3 | 54.0 | +0.0 | 822.0 | 0.0 |
| STAY WORTH | 25.3 | -107.3 | 717.3 | 0.0 | 35.0 | -161.7 | 364.7 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +52.7 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 5.3 | +388.1 | 0.0 | 0.0 | 8.0 | +538.3 | 0.0 | 65.0 |
| SUPPORT WORKED OUT | 5.3 | +388.1 | 0.0 | 0.0 | 8.0 | +538.3 | 0.0 | 65.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +28.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 134.7 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 25.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 51.7 | +0.0 | 0.0 | 177.7 | 49.7 | +0.0 | 0.0 | 714.0 |
| TIED UP BY THE SUM | 0.7 | +58.3 | 25.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 38.3 | +371.5 | 0.0 | 65.0 | 16.3 | +180.7 | 0.0 | 0.0 |
| WAITS AGAIN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 2.3 | +0.0 | 69.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -85.8 | 0.0 | 0.0 | 2.0 | -184.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.7 | +131.9 | 0.0 | 0.0 | 1.3 | +4.5 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p15

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 136 | 136 | 89 | 29.67 | +1447 | +16.3 |
| HIS SHOT LIST | 318 | 310 | 63 | 21.00 | +1957 | +31.1 |
| HIS SHOTS BY HIS RUN | 208 | 204 | 50 | 16.67 | +507 | +10.1 |
| HOLDER ASSIGNMENT | 49 | 49 | 47 | 15.67 | +3453 | +73.5 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -1774 | -52.2 |
| CAST JOB | 38 | 38 | 33 | 11.00 | +144 | +4.4 |
| SHOT RISK POINTS | 147 | 144 | 30 | 10.00 | +1047 | +34.9 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| TIME ON OUR SIDE | 164 | 151 | 21 | 7.00 | +90 | +4.3 |
| HARD STAY DROPPED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 15 | 5.00 | +74 | +5.0 |
| STAY WORTH | 181 | 166 | 14 | 4.67 | +109 | +7.8 |
| COVER ONCE | 73 | 55 | 13 | 4.33 | +426 | +32.8 |
| SUPPORT ADDS | 40 | 39 | 11 | 3.67 | +453 | +41.2 |
| SUPPORT WORKED OUT | 40 | 39 | 11 | 3.67 | +453 | +41.2 |
| FIVE ACTION | 628 | 617 | 10 | 3.33 | +257 | +25.7 |
| GOAL WALK | 49 | 48 | 10 | 3.33 | +481 | +48.1 |
| MARCH CHECK | 12 | 12 | 10 | 3.33 | +167 | +16.7 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| QUARTER ODDS | 129 | 125 | 9 | 3.00 | +347 | +38.6 |
| SET UP BY THE SET | 16 | 16 | 9 | 3.00 | +516 | +57.4 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +65 | +8.1 |
| CHARGE LOSSES | 88 | 84 | 7 | 2.33 | +392 | +56.0 |
| PROMISE BY ITS OWN SUM | 24 | 24 | 7 | 2.33 | -338 | -48.3 |
| IDLE COST | 50 | 42 | 6 | 2.00 | +25 | +4.1 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 87 | 76 | 5 | 1.67 | +35 | +6.9 |
| NEARER NOT NEEDED | 57 | 55 | 5 | 1.67 | +199 | +39.9 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 5 | 1.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOUR ROUNDS | 6 | 6 | 4 | 1.33 | +147 | +36.8 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| MANOEUVRE | 15 | 15 | 4 | 1.33 | +48 | +11.9 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -109 | -27.3 |
| MAX FOR POSITIONING | 24 | 20 | 4 | 1.33 | +1 | +0.2 |
| MISSILES IN THE MOVE | 43 | 32 | 4 | 1.33 | +69 | +17.3 |
| SHOTS AFTER THE MOVES | 22 | 22 | 4 | 1.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 43 | 43 | 3 | 1.00 | -2 | -0.7 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 3 | 1.00 | -157 | -52.5 |
| HUNT IN PAIRS | 12 | 10 | 3 | 1.00 | +267 | +88.9 |
| MOVE TO CHARGE COMPUTED | 8 | 7 | 3 | 1.00 | +37 | +12.4 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +85 | +28.4 |
| REDIRECT COUNTER | 10 | 9 | 3 | 1.00 | +708 | +236.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS IN THE MOVE | 102 | 69 | 3 | 1.00 | +75 | +25.1 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +32 | +16.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +52 | +26.2 |
| NEXT CHARGE BY LIST | 5 | 5 | 2 | 0.67 | +32 | +15.8 |
| OPENS A LANE | 9 | 8 | 2 | 0.67 | +26 | +13.1 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +86 | +43.2 |
| SURE REACH TOGETHER | 5 | 4 | 2 | 0.67 | +25 | +12.5 |
| THE ROW IN ITS ORDER | 18 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +121 | +60.3 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +38 | +38.3 |
| MISSILES NEXT TURN | 46 | 36 | 1 | 0.33 | +8 | +8.5 |
| MOVE SPELL IN RANGE | 11 | 7 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 18 | 10 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +33 | +33.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -33 | -33.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +3 | +3.0 |
| RISK BY ARC | 6 | 6 | 1 | 0.33 | +33 | +33.2 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +158 | +158.0 |
| WHOLE FIGHT DANGER | 12 | 11 | 1 | 0.33 | +47 | +47.1 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 9 | 9 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 44 | 44 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 6 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 45 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| GUN MASK | 7 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 56 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 16 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 22 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 17 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 68 | 68 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 6 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 17 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 10 | 0 | 0.00 | - | - |
| PLAN RESULT | 278 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 14 | 14 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 95 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 39 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 348 | 341 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 304 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 15 | 14 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p15

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 5.33 | 46.1 |
| ARMY TABLE | rule | 2.33 | 3.33 | 45.9 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 0.33 | 48.3 |
| MARCH OF THE TABLE | rule | 0.33 | 1.00 | 27.3 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 52.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 30.6 |
| CANNON PLANNED TARGET | rule | - | 0.33 | 2.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 33.3 |
| RULE SWITCHED OFF | gate | 0.33 | - | 252.6 |

### Plans: cnsr-c940641-p15

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 118 | 25 | 21% |
| Mine | join | 0.3 | 100% | 10 | 0 | 0% |
| Mine | move | 34.3 | 99% | 1971 | 0 | 0% |
| Mine | shoot | 11.0 | 55% | 377 | 811 | 215% |
| Opponent | charge | 1.0 | 0% | 43 | 0 | 0% |
| Opponent | join | 2.0 | 100% | 114 | 0 | 0% |
| Opponent | move | 27.3 | 94% | 882 | 0 | 0% |
| Opponent | shoot | 15.0 | 56% | 851 | 382 | 45% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p15

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.7 | 40% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p15

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 17 (11) | 17 | 0 | 5 | 18% | 2.7 | 19 (7) | 11 (4) | - | 18 (7) | 14 (4) |
| Mine | Clean-up | 6 | 111 (6) | 0 | 111 | 0 | 83% | 5.0 | 16 (3) | 222 (2) | 250 (1) | 136 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 19 (6) | 19 | 0 | 0 | 50% | 3.0 | 68 (2) | 0 (4) | - | 24 (5) | 0 (1) |
| Mine | Holder | 2 | 11 (2) | 0 | 11 | 50 | 100% | - | 22 (1) | 0 (1) | - | 11 (2) | - |
| Mine | Shooter | 2 | 105 (2) | 0 | 105 | 0 | 0% | 1.5 | 209 (1) | 0 (1) | - | 105 (2) | - |
| Mine | War machine | 5 | 91 (5) | 91 | 0 | 40 | 0% | 1.2 | 0 (2) | 457 (1) | 0 (2) | - | 91 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 47 | 75% | 4.0 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 8 (9) | 8 | 0 | 25 | 44% | 3.0 | 0 (3) | 15 (5) | 0 (1) | 9 (6) | 0 (3) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 57 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 0 | 33% | 5.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Shooter | 3 | 58 (3) | 0 | 58 | 33 | 0% | 1.0 | - | 173 (1) | 0 (2) | 87 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 56 (5) | 56 | 0 | 0 | 0% | 1.6 | - | - | 56 (5) | - | 56 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 27 | 0% | 2.8 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |

### Charged fights: cnsr-c940641-p15

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 307 | 38 | 1.0 | 1.0 | 38 | 0 | +38 | 1 of 2 | 1 of 2 | - | +38 |
| Mine | Dwarfen Mountain Holds | 1 | 434 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 349 | 25 | 0.7 | 1.0 | 38 | 0 | +38 | 1 of 2 | 1 of 2 | - | +38 |
| Opponent | Empire of Man | 1 | 139 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 255 | 138 | 2.0 | 1.0 | 69 | 0 | +69 | 2 of 2 | 0 of 2 | - | +69 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 131 | 46 | 0.7 | 1.0 | 69 | 0 | +69 | 2 of 2 | 0 of 2 | - | +69 |

### Effective charges: cnsr-c940641-p15

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 1 (net +75) | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p15

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 75 | +75 | 75 | 0 | +75 | +22.1 |
| Mine | No odds | 1 | 480 | 348 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 2 | 410 | 212 | +38 | 38 | 0 | +38 | +9.2 |
| Opponent | No odds | 2 | 211 | 239 | +69 | 171 | 148 | +23 | +10.8 |
| Opponent | All fights | 2 | 211 | 239 | +69 | 171 | 148 | +23 | +10.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p15 | move | 7 | 1 (14%) | 1 (14%) | 0 (0%) | 6 (86%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

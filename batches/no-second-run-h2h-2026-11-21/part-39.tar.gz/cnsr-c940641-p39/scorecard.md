# Doctrine scorecard: cnsr-c940641-p39

### Scorecard: cnsr-c940641-p39

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 11 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 295 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | 4 | 3 | 5 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 453 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| **Average** | | | Mine | 50% | 11.0 | 2.0 | 0.7 | 2.7 | 0.0 | 0.0 | 0.0 | 172.7 |
| **Average** | | | Opponent | 0% | 0.0 | 3.5 | 1.3 | 2.7 | 0.3 | 0.0 | 0.0 | 208.3 |

### KPIs: cnsr-c940641-p39

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 15% (2 of 13) | 7% (1 of 15) | 11% (3 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 67% (8 of 12) | 39% (14 of 36) | 46% (22 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 73% (8 of 11) | 47% (14 of 30) | 54% (22 of 41) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 74% (4421 of 5998) | 80% (4797 of 5998) | 77% (9218 of 11996) |
|   infantry points that never fought | lower | 83% (1185 of 1424) | 100% (1187 of 1187) | 91% (2372 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (15 of 23) | 85% (23 of 27) | 76% (38 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 2.7 uses a game | 100% (3 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3093 of 5120) | 90% (4872 of 5442) | 75% (7965 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (25%) | 4.0 (55%) | 4.3 (50%) |
| MARCHED: its unit marched | 0.7 (50%) | 1.0 (14%) | 1.7 (19%) |
| IN COMBAT: engaged in combat | 0.3 (25%) | 0.0 (0%) | 0.3 (4%) |
| GONE: slain | 0.0 (0%) | 2.0 (27%) | 2.0 (23%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (5%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.7 | 0.3 | 1.7 | 7.3 | 0.7 | 0.3 |
| not cast | 3.3 | 5.7 | 4.3 | 8.7 | 1.3 | 19.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (53%) | 3.3 (77%) | 4.3 (50%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.3 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (12%) | 0.3 (8%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.0 (0%) | 2.0 (35%) | 0.0 (0%) | 2.0 (23%) | 1.0 (75%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.3 (100%) | 0.0 (0%) | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.3 (98%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 80% (4 of 5) | 80% (4 of 5) |
| the unit moved after it | - | 100% (4 of 4) | 100% (4 of 4) |
| it charged on its next turn | - | 25% (1 of 4) | 25% (1 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 75% (3 of 4) | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (56 of 92) | 58% (42 of 72) | 60% (98 of 164) |
|   cavalry | 50% (6 of 12) | - | 50% (6 of 12) |
|   character | 94% (15 of 16) | 100% (1 of 1) | 94% (16 of 17) |
|   chariot | 21% (5 of 24) | 100% (6 of 6) | 37% (11 of 30) |
|   infantry | 50% (6 of 12) | 45% (13 of 29) | 46% (19 of 41) |
|   monster | - | 83% (5 of 6) | 83% (5 of 6) |
|   war machine | 86% (24 of 28) | 57% (17 of 30) | 71% (41 of 58) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (31%) | 1.0 (10%) | 4.7 (21%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO TARGET IN RANGE | 5.7 (47%) | 2.0 (20%) | 7.7 (35%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (17%) | 3.3 (33%) | 5.3 (24%) |
| SHELTERED: the target was sheltered | 0.7 (6%) | 2.7 (27%) | 3.3 (15%) |
| OTHER BAR | 0.0 (0%) | 0.7 (7%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.3 | 83% | 10.0 pts | 20 pts |
| character | 5.3 | 2.0 | 62% | 15.0 pts | 80 pts |
| chariot | 3.7 | 6.0 | 45% | 18.2 pts | 67 pts |
| infantry | 8.3 | 1.7 | 80% | 11.5 pts | 96 pts |
| monster | 3.3 | 0.3 | 90% | 6.9 pts | 23 pts |
| war machine | 14.0 | 7.0 | 69% | 8.6 pts | 120 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 1.3 | 1.2 |
| Charges that made contact a game | 0.3 | 0.7 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.00 declared, 0.00 contact (3 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.00 contact (21 units) | 0.12 declared, 0.00 contact (17 units) | 0.11 declared, 0.00 contact (38 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 100% (7 of 7) | 50% (1 of 2) | - | 89% (8 of 9) |
| Character on its own | - | 80% (4 of 5) | 75% (3 of 4) | 78% (7 of 9) |
| Chariot | - | 80% (4 of 5) | - | 80% (4 of 5) |
| Infantry | 58% (7 of 12) | 67% (2 of 3) | - | 60% (9 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 100% (5 of 5) | - | - | 100% (5 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (1 of 1); on the table 100% | 67% (8 of 12) | 80% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 62% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 33% (4 of 12) | 100% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 28% (5 of 18) | 90% | 78% (7 of 9) | 100% (3 of 3); 8.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 50% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p39, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 0% (0) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p39

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 33% (1 of 3) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 24% (10 of 41) | 30% (16 of 53) |
| Strategy | Joined characters whose unit fought | 50% (3 of 6) | 14% (1 of 7) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 29% (2 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.7 |
| Movement | Idle units | 2.7 | 2.7 |
| Movement | Points that never moved of their own | 172.7 | 208.3 |
| Movement | Fights charged into per game | 0.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 1, net -580 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (19 of 32) | 96% (24 of 25) |
| Shooting | Points destroyed by shooting units | 141.3 | 0.0 |
| Shooting | War machine shots | 8.0 | 5.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (9 of 24) | 24% (4 of 17) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 80% (4 of 5) | 71% (5 of 7) |
| Magic | Wounds caused by magic missiles | 5.3 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 84.7 | 31.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.0 / 0.0 | 1.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 193.3 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -69 | -333 |
| Combat | Net per 100 charger points, damage counted | -14.3 | -97.1 |
| Combat | First round won (charged fights) | 0% | 0% |
| Combat | Net points per charged fight | +0 | -290 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / -290 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 1 | 2 of 2 |
| Game | Points lost | 31.7 | 386.0 |
| Game | VP from objectives | 840.0 | 530.0 |
| Game | Lone holders (player turns) | 11.0 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +704 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 418
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p39

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 18.0 | +104.2 | 0.0 | 0.0 | 20.3 | +20.2 | 0.0 | 156.3 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 31.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +9.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 7.3 | +112.1 | 0.0 | 31.7 | 5.7 | +61.7 | 31.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 2.3 | +76.9 | 0.0 | 0.0 | 7.3 | +104.6 | 63.3 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +12.6 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.0 | -458.5 | 0.0 | 0.0 | 13.0 | -492.4 | 0.0 | 126.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 193.3 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +50.2 | 0.0 | 0.0 |
| COVER ONCE | 13.0 | -871.5 | 0.0 | 31.7 | 6.7 | -521.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -10.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | - | - | - | - | 1.0 | +27.9 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +1.4 | 0.0 | 0.0 |
| FALLS SHORT | 8.3 | +106.4 | 0.0 | 0.0 | 18.3 | +114.8 | 0.0 | 478.7 |
| FEATURE BUFFS | 0.7 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +16.7 | 0.0 | 0.0 | 1.3 | +31.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 109.0 | +5629.7 | 314.0 | 63.3 | 100.0 | +3606.9 | 126.7 | 874.0 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +94.3 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.0 | +106.4 | 0.0 | 0.0 | 1.3 | +110.8 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 126.3 |
| FRIEND SHOOTS FIRST | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 13.0 | +940.7 | 0.0 | 0.0 | 4.3 | +235.9 | 0.0 | 169.3 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 1.7 | +71.7 | 0.0 | 0.0 | 1.3 | -10.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 126.3 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +48.4 | 0.0 | 0.0 |
| HIS CHARGE LIST | 10.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 126.3 |
| HIS MOVE AND SHOT | 4.7 | -28.7 | 0.0 | 0.0 | 1.0 | -17.4 | 0.0 | 15.0 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 126.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 52.7 | +4019.9 | 0.0 | 0.0 | 50.7 | +3455.1 | 0.0 | 844.0 |
| HIS SHOTS BY HIS RUN | 34.7 | +925.2 | 0.0 | 0.0 | 31.3 | +747.4 | 0.0 | 409.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +28.1 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.0 | +1060.0 | 0.0 | 0.0 | 7.0 | +557.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -48.8 | 0.0 | 0.0 | 1.3 | -49.1 | 0.0 | 0.0 |
| HUNT IN PAIRS | 1.0 | +42.7 | 0.0 | 0.0 | 1.7 | +95.3 | 0.0 | 126.3 |
| IDLE COST | 5.3 | -94.5 | 0.0 | 0.0 | 13.7 | -216.5 | 0.0 | 422.0 |
| KEPT FROM ITS LAST STOP | 5.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 386.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +0.1 | 0.0 | 0.0 | 1.3 | +10.4 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | -22.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +14.7 | 0.0 | 0.0 | 1.0 | +232.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +23.1 | 0.0 | 0.0 | 3.7 | +257.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +7.4 | 0.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +1.9 | 0.0 | 0.0 | 1.0 | +16.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +87.2 | 0.0 | 0.0 | 2.0 | +12.5 | 0.0 | 126.3 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +147.9 | 0.0 | 0.0 | 10.3 | +87.3 | 0.0 | 126.3 |
| MISSILES NEXT TURN | 3.0 | +83.4 | 0.0 | 0.0 | 11.7 | +80.6 | 0.0 | 252.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.7 | +143.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.7 | +117.6 | 0.0 | 0.0 | 1.7 | +44.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.3 | +389.1 | 0.0 | 0.0 | 9.0 | +400.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +29.9 | 0.0 | 0.0 | 1.3 | +36.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -20.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -0.3 | 0.0 | 0.0 | 1.0 | -120.9 | 0.0 | 0.0 |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.7 | -110.5 | 0.0 | 0.0 | 3.7 | -108.1 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.7 | +23.6 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -92.5 | 0.0 | 0.0 | 1.0 | -19.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.3 | +120.0 | 0.0 | 0.0 | 3.3 | -210.5 | 0.0 | 0.0 |
| ONE ROUTE | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +16.7 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +28.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -11.1 | 0.0 | 0.0 | 0.3 | -1.3 | 0.0 | 0.0 |
| PLAN RESULT | 46.7 | +432.3 | 30.0 | 63.3 | 45.0 | +473.5 | 31.7 | 560.7 |
| PROMISE BY ITS OWN SUM | 6.7 | -263.2 | 0.0 | 0.0 | 2.7 | -25.6 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 19.0 | +1757.6 | 0.0 | 0.0 | 19.7 | +1197.4 | 0.0 | 0.0 |
| REAL GROUND | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +259.9 | 0.0 | 0.0 | 0.3 | +52.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +13.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | +22.1 | 0.0 | 0.0 | 1.3 | -46.3 | 0.0 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.0 | -9.9 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -39.2 | 0.0 | 30.0 |
| SEARCH SPOT | 0.7 | +27.1 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -32.5 | 0.0 | 0.0 | 2.0 | -114.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +12.0 | 0.0 | 0.0 | 2.0 | +216.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +19.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 31.7 | 17.0 | +0.0 | 0.0 | 15.0 |
| SHOOTS FROM THE BEST SPOT | 6.0 | +232.6 | 314.0 | 0.0 | 3.7 | +20.7 | 0.0 | 0.0 |
| SHOT RISK POINTS | 25.3 | +430.5 | 0.0 | 0.0 | 27.3 | +244.4 | 0.0 | 704.7 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +402.2 | 0.0 | 31.7 | 18.3 | +569.4 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +19.1 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +1.7 | 0.0 | 0.0 | 2.0 | +42.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 84.7 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 126.3 |
| STANDS STILL | 62.0 | +0.0 | 314.0 | 63.3 | 53.0 | +0.0 | 126.7 | 126.3 |
| STAY WORTH | 23.7 | -149.4 | 0.0 | 0.0 | 31.3 | -156.0 | 126.7 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +52.3 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.3 | +189.5 | 0.0 | 0.0 | 6.7 | +330.7 | 0.0 | 30.0 |
| SUPPORT WORKED OUT | 3.3 | +189.5 | 0.0 | 0.0 | 6.7 | +330.7 | 0.0 | 30.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +21.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 84.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 52.3 | +0.0 | 0.0 | 31.7 | 47.3 | +0.0 | 0.0 | 452.0 |
| TIED UP BY THE SUM | 0.3 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 41.3 | +442.6 | 30.0 | 0.0 | 17.0 | +180.7 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -125.8 | 0.0 | 0.0 | 3.0 | -198.7 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.0 | +75.6 | 0.0 | 0.0 | 1.3 | +6.0 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p39

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 115 | 115 | 84 | 28.00 | +587 | +7.0 |
| HIS SHOT LIST | 310 | 305 | 71 | 23.67 | +2094 | +29.5 |
| HIS SHOTS BY HIS RUN | 198 | 193 | 53 | 17.67 | +597 | +11.3 |
| HOLDER ASSIGNMENT | 51 | 51 | 49 | 16.33 | +3352 | +68.4 |
| SHOT RISK POINTS | 158 | 156 | 39 | 13.00 | +1257 | +32.2 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -656 | -29.8 |
| TIME ON OUR SIDE | 175 | 161 | 21 | 7.00 | +64 | +3.1 |
| CAST JOB | 29 | 29 | 20 | 6.67 | +106 | +5.3 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 29 | 29 | 20 | 6.67 | +162 | +8.1 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| SUPPORT ADDS | 30 | 30 | 14 | 4.67 | +447 | +31.9 |
| SUPPORT WORKED OUT | 30 | 30 | 14 | 4.67 | +447 | +31.9 |
| QUARTER ODDS | 116 | 116 | 13 | 4.33 | +586 | +45.1 |
| FIVE ACTION | 627 | 619 | 11 | 3.67 | +476 | +43.3 |
| GOAL WALK | 52 | 52 | 10 | 3.33 | +496 | +49.6 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| PROMISE BY ITS OWN SUM | 28 | 28 | 10 | 3.33 | -866 | -86.7 |
| CHARGE LOSSES | 84 | 82 | 9 | 3.00 | +296 | +32.9 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MARCH CHECK | 12 | 11 | 8 | 2.67 | +124 | +15.4 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +71 | +8.9 |
| STAY WORTH | 165 | 152 | 8 | 2.67 | +86 | +10.8 |
| GUN MASK | 9 | 9 | 7 | 2.33 | +110 | +15.6 |
| COVER ONCE | 59 | 47 | 6 | 2.00 | +70 | +11.6 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 57 | 49 | 5 | 1.67 | +19 | +3.8 |
| MOVE TO CHARGE COMPUTED | 10 | 8 | 5 | 1.67 | +201 | +40.1 |
| THE ROW IN ITS ORDER | 20 | 5 | 5 | 1.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +741 | +185.2 |
| NEARER NOT NEEDED | 55 | 52 | 4 | 1.33 | +191 | +47.8 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 10 | 10 | 4 | 1.33 | +238 | +59.6 |
| CANNON PLANNED TARGET | 39 | 39 | 3 | 1.00 | -2 | -0.7 |
| FOUR ROUNDS | 7 | 7 | 3 | 1.00 | +233 | +77.8 |
| MAX FOR POSITIONING | 17 | 15 | 3 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 39 | 31 | 3 | 1.00 | +75 | +25.1 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +85 | +28.4 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS AFTER THE MOVES | 21 | 21 | 3 | 1.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 3 | 1.00 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +38 | +18.8 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -259 | -129.3 |
| FALLS SHORT | 80 | 72 | 2 | 0.67 | +26 | +12.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HUNT IN PAIRS | 8 | 8 | 2 | 0.67 | +54 | +27.2 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MANOEUVRE | 14 | 14 | 2 | 0.67 | +18 | +8.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -28 | -14.1 |
| NEXT CHARGE BY LIST | 6 | 5 | 2 | 0.67 | +85 | +42.5 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -37 | -18.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +86 | +43.2 |
| WOUNDS ON THE RANKS | 16 | 16 | 2 | 0.67 | +1 | +0.3 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 5 | 5 | 1 | 0.33 | +68 | +67.9 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +283 | +282.8 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +70 | +70.3 |
| HIS MOVE AND SHOT | 17 | 16 | 1 | 0.33 | +7 | +6.6 |
| MOVE SPELL IN RANGE | 11 | 8 | 1 | 0.33 | +11 | +10.6 |
| ONE FIGHT FORMULA | 14 | 12 | 1 | 0.33 | +4 | +3.6 |
| ONE OBJECTIVE FORMULA | 17 | 14 | 1 | 0.33 | +57 | +57.3 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +33 | +33.2 |
| REDIRECT COUNTER | 6 | 6 | 1 | 0.33 | +43 | +43.5 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +40 | +39.6 |
| RISK BY ARC | 6 | 6 | 1 | 0.33 | +33 | +33.2 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +157 | +156.7 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +33 | +33.2 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARACTER GUNS | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 41 | 41 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 14 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 16 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 41 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 49 | 49 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 23 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 20 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 73 | 73 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 6 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 14 | 14 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 44 | 38 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 14 | 14 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 275 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 14 | 14 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 96 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 101 | 81 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 41 | 33 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 345 | 341 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 299 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 16 | 16 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p39

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 3.67 | 29.8 |
| ARMY TABLE | rule | 3.33 | 2.33 | 45.1 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 0.67 | 86.6 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 129.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 29.4 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 14.1 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 18.6 |
| CANNON PLANNED TARGET | rule | - | 0.33 | 2.0 |

### Plans: cnsr-c940641-p39

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 0% | 90 | 2 | 3% |
| Mine | join | 0.3 | 100% | 12 | 0 | 0% |
| Mine | move | 35.0 | 100% | 2008 | 0 | 0% |
| Mine | shoot | 10.7 | 56% | 207 | 430 | 208% |
| Opponent | charge | 1.3 | 25% | 132 | 48 | 37% |
| Opponent | join | 1.7 | 100% | 93 | 0 | 0% |
| Opponent | move | 27.3 | 98% | 821 | 0 | 0% |
| Opponent | shoot | 14.0 | 52% | 866 | 425 | 49% |
| Opponent | support | 0.7 | 50% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p39

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p39

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 47 (11) | 47 | 0 | 0 | 27% | 2.5 | 32 (8) | 103 (3) | - | 64 (8) | 0 (3) |
| Mine | Clean-up | 6 | 83 (6) | 0 | 83 | 0 | 83% | 5.0 | 0 (3) | 148 (2) | 250 (1) | 102 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 3 (6) | 3 | 0 | 0 | 50% | 3.0 | 0 (2) | 5 (4) | - | 0 (5) | 15 (1) |
| Mine | Holder | 2 | 11 (2) | 0 | 11 | 0 | 100% | - | 22 (1) | 0 (1) | - | 11 (2) | - |
| Mine | Shooter | 2 | 21 (2) | 0 | 21 | 0 | 0% | 2.0 | 42 (1) | 0 (1) | - | 21 (2) | - |
| Mine | War machine | 5 | 0 (5) | 0 | 0 | 20 | 0% | 1.2 | 0 (2) | 0 (1) | 0 (2) | - | 0 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 18 | 100% | - | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 0 (9) | 0 | 0 | 33 | 44% | 2.8 | 0 (3) | 0 (5) | 0 (1) | 0 (6) | 0 (3) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 57 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 111 (3) | 18 | 93 | 0 | 33% | 4.5 | - | 136 (2) | 57 (1) | 164 (2) | 0 (1) |
| Opponent | Shooter | 3 | 77 (3) | 0 | 77 | 0 | 0% | 1.0 | - | 173 (1) | 29 (2) | 87 (2) | 58 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 0 (5) | 0 | 0 | 0 | 20% | 1.0 | - | - | 0 (5) | - | 0 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 48 | 20% | 2.8 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |

### Charged fights: cnsr-c940641-p39

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 150 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Mine | Dwarfen Mountain Holds | 1 | 379 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 226 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 95 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 580 | -580 | 1 of 1 | 0 of 1 | - | -580 |
| **Opponent** | all armies | 3 | 32 | 0 | 0.7 | 1.0 | 0 | 290 | -290 | 2 of 2 | 0 of 2 | - | -290 |

### Effective charges: cnsr-c940641-p39

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1 (net -580) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: cnsr-c940641-p39

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 1 | 480 | 348 | +0 | 0 | 69 | -69 | -14.3 |
| Mine | All fights | 1 | 480 | 348 | +0 | 0 | 69 | -69 | -14.3 |
| Opponent | Effective (55-75%) | 1 | 480 | 339 | -580 | 145 | 580 | -435 | -90.6 |
| Opponent | No odds | 1 | 205 | 239 | +0 | 15 | 246 | -231 | -112.5 |
| Opponent | All fights | 2 | 342 | 289 | -290 | 80 | 413 | -333 | -97.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p39 | move | 6 | 0 (0%) | 0 (0%) | 0 (0%) | 6 (100%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

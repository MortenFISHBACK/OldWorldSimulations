# Doctrine scorecard: cnsr-c940641-p45

### Scorecard: cnsr-c940641-p45

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 0 | 1 | 6 | 0 | 0 | 0 | 0 | 100 |
| L1629 | 3 | 1 | Opponent | no | 2 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 5 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 1.5 | 3.0 | 3.0 | 0.0 | 0.3 | 0.0 | 0.0 | 33.3 |
| **Average** | | | Opponent | 33% | 3.0 | 2.7 | 2.3 | 2.3 | 0.3 | 0.0 | 0.0 | 113.3 |

### KPIs: cnsr-c940641-p45

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 16) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (6 of 6); on the table 100% | 100% (1 of 1); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 75% (3 of 4); on the table 75% | 0% (0 of 1); on the table 0% | 60% (3 of 5); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 91% (10 of 11); on the table 91% | 33% (1 of 3); on the table 33% | 79% (11 of 14); on the table 79% |
| Magic missiles tried each own turn | 50%+ | - | 8% (1 of 12) | 8% (1 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 12% (1 of 8) | 12% (1 of 8) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 80% (8 of 10) | 80% (8 of 10) |
| Points that never fought | lower | 41% (2488 of 6000) | 35% (2091 of 5999) | 38% (4579 of 11999) |
|   infantry points that never fought | lower | 61% (813 of 1332) | 79% (673 of 855) | 68% (1486 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (11 of 20) | 76% (19 of 25) | 67% (30 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (3 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2755 of 5135) | 69% (3736 of 5430) | 61% (6491 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (55%) | 2.0 (55%) |
| MARCHED: its unit marched | - | 0.3 (9%) | 0.3 (9%) |
| GONE: slain | - | 1.3 (36%) | 1.3 (36%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 0.7 | 0.7 | 0.3 | 1.0 |
| not cast | 5.7 | 1.3 | 1.3 | 3.7 | 19.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (55%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (9%) | 0.0 (0%) |
| GONE: slain | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 1.3 (36%) | 3.0 (16%) |
| STUPIDITY: Stupidity | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (82%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (56 of 89) | 33% (1 of 3) | 62% (57 of 92) |
|   cavalry | 83% (10 of 12) | 50% (1 of 2) | 79% (11 of 14) |
|   character | 44% (4 of 9) | 0% (0 of 1) | 40% (4 of 10) |
|   chariot | 50% (3 of 6) | - | 50% (3 of 6) |
|   infantry | 62% (24 of 39) | - | 62% (24 of 39) |
|   monster | 45% (5 of 11) | - | 45% (5 of 11) |
|   war machine | 83% (10 of 12) | - | 83% (10 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (15%) | 0.0 (0%) | 1.7 (14%) |
| CHARGED: it charged | 1.3 (12%) | 0.3 (50%) | 1.7 (14%) |
| MOVED: a war machine that moved | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 5.0 (45%) | 0.3 (50%) | 5.3 (46%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (24%) | 0.0 (0%) | 2.7 (23%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.7 | 75% | 3.3 pts | 13 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.0 | 1.0 | 67% | 65.0 pts | 65 pts |
| infantry | 12.7 | 1.0 | 92% | 3.1 pts | 39 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 3.3 | 1.3 | 80% | 19.3 pts | 64 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 2.7 | 3.8 |
| Charges that made contact a game | 5.0 | 1.7 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.50 declared, 0.00 contact (2 units) | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (4 units) | 1.00 declared, 1.00 contact (3 units) | 0.71 declared, 0.71 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.65 declared, 0.65 contact (20 units) | 0.20 declared, 0.10 contact (20 units) | 0.42 declared, 0.38 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (5 of 5) | 100% (3 of 3) | 100% (2 of 2) | 100% (10 of 10) |
| Character in a unit | 100% (2 of 2) | - | 100% (1 of 1) | 100% (3 of 3) |
| Character on its own | 60% (3 of 5) | 100% (2 of 2) | 38% (3 of 8) | 53% (8 of 15) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 71% (5 of 7) | 0% (0 of 3) | - | 50% (5 of 10) |
| Monster | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 44% | 57% (4 of 7) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 38% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 42% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 36% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 34% | 74% (14 of 19) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p45, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 45% (5) | 50% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.33 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnsr-c940641-p45

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 83% (10 of 12) | 25% (2 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (8 of 23) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 67% (2 of 3) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 60% (6 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 0.0 | 2.3 |
| Movement | Points that never moved of their own | 33.3 | 113.3 |
| Movement | Fights charged into per game | 4.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 11, net +0 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 11, net +0 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 11, net +106 | 2 of 4, net +106 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 11, net +280 | 2 of 4, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.7 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (18 of 53) | 17% (1 of 6) |
| Shooting | Points destroyed by shooting units | 103.7 | 0.0 |
| Shooting | War machine shots | 3.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (6 of 10) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Wounds caused by magic missiles | 8.0 | - |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 62.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.3 / 0.3 / 0.0 | 1.0 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 348.3 | 185.0 |
| Combat | Points run down | 28.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +92 | +128 |
| Combat | Net per 100 charger points, damage counted | +28.7 | +32.6 |
| Combat | First round won (charged fights) | 71% | 100% |
| Combat | Net points per charged fight | +86 | +128 |
| Combat | Net points per supported fight / lone fight | +195 / +77 | +141 / +124 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 14 | 0 of 4 |
| Game | Points lost | 227.0 | 625.3 |
| Game | VP from objectives | 933.3 | 543.3 |
| Game | Lone holders (player turns) | 1.5 | 3.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +881 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 852
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p45

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +25.6 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 27.3 | +439.7 | 0.0 | 136.0 | 27.3 | -357.7 | 0.0 | 113.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 28.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +3.8 | 0.0 | 155.0 |
| BACKUP TARGETS | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +4.1 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.3 | +0.0 | 113.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +10.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +29.0 | 0.0 | 203.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -3.4 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 4.7 | -110.7 | 0.0 | 0.0 | 18.7 | -878.4 | 0.0 | 462.3 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 133.0 | 0.0 | 1.7 | +0.0 | 105.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 101.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 9.7 | -647.3 | 0.0 | 86.0 | 9.3 | -1103.5 | 0.0 | 278.7 |
| DEFENSIVE FLOOR | 0.3 | +17.2 | 68.3 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -3.6 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 0.0 | 6.3 | +63.8 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +1.8 | 48.0 | 0.0 | 0.3 | +8.2 | 42.0 | 0.0 |
| EXACT ROUND | 2.3 | -20.1 | 311.7 | 0.0 | 2.0 | +41.6 | 152.3 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +0.5 | 136.7 | 0.0 | 2.3 | +0.0 | 171.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 21.0 | +228.9 | 0.0 | 371.0 |
| FEATURE BUFFS | 1.3 | +9.3 | 0.0 | 0.0 | 1.3 | +98.6 | 0.0 | 0.0 |
| FIGHT LIFT | 0.3 | +18.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | -0.1 | 0.0 | 0.0 | 0.7 | +29.0 | 47.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 93.7 | +8149.3 | 616.7 | 519.7 | 77.0 | +4876.9 | 218.3 | 1290.3 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 120.3 | 12.0 | +0.0 | 0.0 | 420.3 |
| FOLLOW UP WEIGHED | 1.0 | +390.8 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 4.3 | +356.7 | 464.7 | 0.0 | 2.7 | +151.6 | 218.3 | 0.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 308.0 |
| FRIEND SHOOTS FIRST | 4.7 | -68.8 | 0.0 | 35.7 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +40.3 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -11.6 | 175.0 | 0.0 | - | - | - | - |
| GOAL WALK | 10.0 | +807.2 | 0.0 | 0.0 | 9.0 | +642.7 | 0.0 | 0.0 |
| GUN MASK | 1.0 | -15.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 95.3 |
| HELPER UNSEEN | 0.3 | +0.0 | 68.3 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 0.0 | 13.7 | +0.0 | 0.0 | 462.3 |
| HIS CHARGE DENIED | 0.7 | +7.5 | 155.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 8.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 279.0 |
| HIS MOVE AND SHOT | 2.3 | -27.7 | 0.0 | 0.0 | 7.0 | -134.4 | 0.0 | 97.3 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 12.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 309.0 |
| HIS RANDOM MOVE | 13.7 | +0.0 | 0.0 | 164.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 7.3 | +167.8 | 0.0 | 0.0 | 39.3 | +928.3 | 0.0 | 845.7 |
| HIS SHOTS BY HIS RUN | 13.0 | +160.5 | 0.0 | 75.7 | 42.7 | +1078.2 | 0.0 | 984.0 |
| HIS TURN DENIED | 0.3 | +7.2 | 0.0 | 0.0 | 0.7 | +24.0 | 42.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 84.0 | 12.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.7 | +708.6 | 0.0 | 66.0 | 6.3 | +617.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -165.2 | 309.7 | 0.0 | 2.3 | -86.2 | 218.3 | 0.0 |
| HUNT IN PAIRS | 1.3 | +54.2 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 13.0 | -170.9 | 0.0 | 208.7 |
| JOINT CHARGE NOW | 0.7 | -5.5 | 40.0 | 0.0 | 0.7 | +36.5 | 94.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 12.3 | +0.0 | 641.3 | 188.0 | 5.0 | +0.0 | 71.0 | 550.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.7 | +8.1 | 311.7 | 0.0 | 1.3 | +6.4 | 113.0 | 0.0 |
| LOST CHARGE | 0.3 | -0.3 | 20.0 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +0.9 | 0.0 | 0.0 | 1.0 | +2.4 | 0.0 | 53.3 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -48.2 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.3 | +47.1 | 0.0 | 0.0 | 3.0 | +92.5 | 0.0 | 43.3 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +30.6 | 0.0 | 0.0 | 1.3 | +9.2 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 3.3 | +33.1 | 0.0 | 0.0 | 3.3 | +22.1 | 0.0 | 65.0 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 12.0 | +803.5 | 0.0 | 0.0 | 4.3 | +314.7 | 0.0 | 433.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 10.7 | +478.8 | 0.0 | 35.7 | 5.3 | +268.6 | 0.0 | 28.3 |
| NEXT CHARGE BY LIST | 6.3 | +486.1 | 0.0 | 0.0 | 2.3 | +202.0 | 0.0 | 356.0 |
| NO DOUBLE ROUNDS | 3.7 | -219.4 | 396.3 | 0.0 | 2.0 | -84.0 | 218.3 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | -2.8 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -114.5 | 0.0 | 0.0 | 3.7 | -157.6 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 42.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.3 | -233.0 | 0.0 | 0.0 | 6.0 | -111.3 | 0.0 | 294.0 |
| ONE OBJECTIVE FORMULA | 4.0 | -75.3 | 0.0 | 66.0 | 2.3 | +87.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -18.9 | 0.0 | 62.0 |
| OPENS UP | 0.3 | +34.1 | 28.3 | 0.0 | 0.3 | +13.8 | 24.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +19.7 | 28.3 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | -71.6 | 0.0 | 25.0 |
| PLAN RESULT | 42.3 | +598.5 | 331.7 | 371.3 | 38.7 | +164.7 | 0.0 | 779.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 15.0 | -328.0 | 0.0 | 0.0 | 5.3 | -82.8 | 0.0 | 77.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.3 | -29.1 | 0.0 | 35.7 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 26.3 | +3529.9 | 176.7 | 132.0 | 21.7 | +2595.8 | 66.0 | 236.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +92.2 | 0.0 | 226.7 |
| REDIRECT COUNTER | 1.7 | +68.8 | 0.0 | 0.0 | 3.0 | +480.9 | 0.0 | 68.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 53.3 |
| REFORMS TO MEET IT | 5.0 | -127.4 | 0.0 | 0.0 | 0.3 | -1.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.7 | +8.7 | 173.0 | 0.0 | 2.0 | +132.4 | 129.3 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -34.1 | 76.3 | 0.0 | 1.0 | -29.0 | 118.0 | 0.0 |
| RUN DOWN | 2.7 | -67.9 | 213.0 | 0.0 | 1.3 | -11.5 | 113.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -98.8 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +16.5 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | +89.4 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.3 | -205.3 | 0.0 | 35.7 | 1.0 | -19.1 | 0.0 | 25.0 |
| SET UP BY THE SET | 4.3 | +232.4 | 0.0 | 35.7 | 1.7 | +4.9 | 0.0 | 25.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 24.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +50.7 | 38.7 | 84.0 | 1.7 | +4.3 | 0.0 | 28.3 |
| SHOT OR CHARGE | 1.3 | -20.8 | 113.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 5.3 | -14.6 | 0.0 | 40.0 | 24.7 | -76.5 | 0.0 | 427.3 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 17.7 | +416.6 | 0.0 | 108.0 | 1.0 | +21.1 | 0.0 | 28.3 |
| SPELL WORTH | 2.0 | +51.2 | 0.0 | 0.0 | 2.3 | +5.9 | 40.0 | 40.0 |
| SPELLS IN THE FIGHT | 0.3 | -5.4 | 155.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 35.7 | 8.0 | +0.0 | 0.0 | 170.3 |
| STAND AND SHOOT | 0.3 | -3.6 | 28.3 | 0.0 | 1.0 | -27.5 | 66.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 32.0 | +0.0 | 152.0 | 337.3 | 18.7 | +0.0 | 0.0 | 397.0 |
| STAY WORTH | 20.0 | +56.6 | 113.3 | 42.0 | - | - | - | - |
| STRIKE BY THE ODDS | 0.7 | +44.0 | 0.0 | 0.0 | 0.3 | +3.8 | 0.0 | 68.3 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 11.7 | +728.6 | 0.0 | 98.3 | 10.0 | +931.9 | 0.0 | 73.3 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 11.7 | +728.6 | 0.0 | 98.3 | 10.0 | +931.9 | 0.0 | 73.3 |
| SURE REACH TOGETHER | 1.0 | +6.0 | 0.0 | 20.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +1.3 | 0.0 | 48.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 25.0 |
| THE PROMISE ADDS | 0.3 | -5.1 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 53.3 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 68.3 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 96.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.0 | +0.0 | 0.0 | 158.0 | 36.7 | +0.0 | 0.0 | 544.3 |
| TIED UP BY THE SUM | 2.0 | +246.0 | 173.0 | 0.0 | 1.3 | +181.6 | 105.3 | 0.0 |
| TIME ON OUR SIDE | 43.3 | +539.9 | 0.0 | 303.7 | - | - | - | - |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 30.0 |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 28.3 |
| WHAT THE JOINER ADDS | 0.7 | -59.0 | 136.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | +22.4 | 88.3 | 0.0 | 0.7 | -1.3 | 42.0 | 0.0 |
| WHO HITS BACK | 0.7 | +36.9 | 0.0 | 47.0 | 0.7 | +151.7 | 0.0 | 68.3 |
| WHOLE FIGHT | 0.3 | +37.8 | 68.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -100.4 | 0.0 | 0.0 | 4.0 | -231.2 | 0.0 | 88.3 |
| WOUNDS ON THE RANKS | 0.3 | +1.9 | 0.0 | 0.0 | 4.3 | +340.6 | 0.0 | 20.0 |

### Rule changes: cnsr-c940641-p45

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 164 | 164 | 90 | 30.00 | +198 | +2.2 |
| LEGAL CHARGES ONLY | 52 | 52 | 52 | 17.33 | +0 | +0.0 |
| FIVE ACTION | 512 | 494 | 47 | 15.67 | +1948 | +41.4 |
| HOLDER ASSIGNMENT | 48 | 48 | 45 | 15.00 | +2300 | +51.1 |
| QUARTER ODDS | 144 | 139 | 35 | 11.67 | +1858 | +53.1 |
| THE TABLE AGAIN | 36 | 36 | 34 | 11.33 | +0 | +0.0 |
| HIS SHOT LIST | 140 | 136 | 33 | 11.00 | +313 | +9.5 |
| HIS SHOTS BY HIS RUN | 167 | 159 | 32 | 10.67 | +417 | +13.0 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| PROMISE BY ITS OWN SUM | 61 | 61 | 25 | 8.33 | -1233 | -49.3 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -816 | -34.0 |
| MOVE TO CHARGE COMPUTED | 49 | 40 | 20 | 6.67 | +533 | +26.7 |
| SUPPORT ADDS | 65 | 62 | 18 | 6.00 | +1103 | +61.3 |
| SUPPORT WORKED OUT | 65 | 62 | 18 | 6.00 | +1103 | +61.3 |
| SHOT RISK POINTS | 90 | 85 | 16 | 5.33 | +248 | +15.5 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 21 | 21 | 9 | 3.00 | +478 | +53.1 |
| GOAL WALK | 57 | 57 | 8 | 2.67 | +333 | +41.6 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| NEXT CHARGE BY LIST | 26 | 22 | 8 | 2.67 | +330 | +41.2 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 8 | 2.67 | +277 | +34.6 |
| SET UP BY THE SET | 18 | 18 | 8 | 2.67 | +443 | +55.4 |
| TIED UP BY THE SUM | 10 | 10 | 8 | 2.67 | +262 | +32.7 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| COVER ONCE | 57 | 38 | 6 | 2.00 | +149 | +24.8 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| IDLE COST | 39 | 33 | 6 | 2.00 | +34 | +5.7 |
| CHARGE LOSSES | 70 | 66 | 5 | 1.67 | +350 | +70.0 |
| TIME ON OUR SIDE | 130 | 105 | 5 | 1.67 | +31 | +6.1 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +91 | +22.8 |
| CHARGE NOW FIRST | 11 | 11 | 4 | 1.33 | -224 | -56.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +93 | +23.3 |
| MAX FOR POSITIONING | 19 | 18 | 4 | 1.33 | +4 | +1.1 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 4 | 1.33 | +28 | +7.0 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +181 | +45.3 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +1172 | +390.8 |
| NO DOUBLE ROUNDS | 17 | 17 | 3 | 1.00 | +21 | +7.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | -215 | -71.6 |
| RISK BY ARC | 14 | 14 | 3 | 1.00 | +200 | +66.7 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS AFTER THE MOVES | 11 | 11 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +143 | +47.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 63 | 53 | 2 | 0.67 | +4 | +2.2 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +23 | +11.7 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +18 | +9.1 |
| REDIRECT COUNTER | 14 | 13 | 2 | 0.67 | +227 | +113.7 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 20 | 18 | 2 | 0.67 | +137 | +68.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +77 | +76.7 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +1 | +1.1 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +11 | +11.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +5 | +4.8 |
| EXACT ROUND | 13 | 13 | 1 | 0.33 | +6 | +5.5 |
| FEATURE BUFFS | 8 | 8 | 1 | 0.33 | +133 | +132.6 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +121 | +121.0 |
| GUN MASK | 3 | 3 | 1 | 0.33 | +8 | +7.6 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +6 | +5.5 |
| HONEST WORTH | 18 | 18 | 1 | 0.33 | +3 | +2.8 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +6 | +5.5 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +20 | +20.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NEARER NOT NEEDED | 48 | 45 | 1 | 0.33 | +29 | +29.1 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -57 | -56.7 |
| PROMISE READS THE TABLE | 7 | 7 | 1 | 0.33 | +8 | +8.3 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -12 | -11.6 |
| REFORMS TO MEET IT | 16 | 11 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -14 | -14.1 |
| RUN DOWN | 12 | 12 | 1 | 0.33 | +5 | +5.2 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +49 | +49.4 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| THE ROW IN ITS ORDER | 22 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 6 | 1 | 0.33 | +4 | +3.6 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +23 | +23.4 |
| WOUNDS ON THE RANKS | 14 | 13 | 1 | 0.33 | +39 | +38.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 66 | 63 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 16 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 60 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 29 | 28 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 14 | 12 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 14 | 14 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 54 | 52 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 41 | 35 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 28 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 40 | 38 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 58 | 48 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 41 | 40 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 79 | 77 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 9 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 20 | 13 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 6 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 40 | 19 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 19 | 12 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 243 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 22 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 56 | 34 | 0 | 0.00 | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 45 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 152 | 148 | 0 | 0.00 | - | - |
| STAY WORTH | 60 | 47 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | 2 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 239 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 10 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p45

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 3.33 | 5.67 | 89.1 |
| PROMISE BY ITS OWN SUM | rule | 6.67 | 1.67 | 49.3 |
| JOB FIRST | gate | 3.67 | 3.00 | 30.9 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 56.0 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 18.2 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 23.9 |
| NO REASON | gate | 0.67 | - | 11.9 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 56.7 |
| PATHS CROSS | rule | - | 0.33 | 238.0 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 11.6 |
| REFUSING RETIRES | rule | 0.33 | - | 14.1 |
| RULE SWITCHED OFF | gate | - | 0.33 | 166.6 |
| TURN GATE | gate | - | 0.33 | 8.3 |

### Plans: cnsr-c940641-p45

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 80% | 454 | 413 | 91% |
| Mine | move | 32.7 | 97% | 2234 | 0 | 0% |
| Mine | shoot | 6.3 | 26% | 463 | 185 | 40% |
| Opponent | charge | 2.0 | 50% | 312 | 152 | 49% |
| Opponent | join | 4.0 | 92% | 163 | 0 | 0% |
| Opponent | move | 31.7 | 95% | 1427 | 0 | 0% |
| Opponent | shoot | 0.7 | 50% | 43 | 12 | 28% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p45

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.0 | 22% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p45

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Mine | Chaff | 2 | 338 (2) | 0 | 338 | 0 | 0% | 1.5 | 412 (1) | 262 (1) | - | 412 (1) | 262 (1) |
| Mine | Character | 8 | 44 (8) | 44 | 0 | 5 | 12% | 2.7 | 54 (4) | 39 (3) | 0 (1) | 56 (5) | 6 (3) |
| Mine | Clean-up | 1 | 96 (1) | 96 | 0 | 0 | 0% | 5.0 | 96 (1) | - | - | 96 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 21 (4) | 21 | 0 | 0 | 0% | 2.2 | 26 (3) | 0 (1) | - | 0 (3) | 170 (1) |
| Mine | Hammer | 3 | 41 (3) | 37 | 4 | 26 | 33% | 1.5 | 144 (1) | 6 (2) | - | 144 (1) | 6 (2) |
| Mine | Shooter | 6 | 44 (6) | 17 | 27 | 29 | 0% | 1.3 | 0 (3) | 105 (3) | - | 89 (3) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 67 | 40% | 4.0 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 27 (10) | 27 | 0 | 25 | 30% | 3.1 | 50 (4) | 20 (5) | 0 (1) | 39 (7) | 11 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 0 (6) | 0 | 0 | 29 | 50% | 3.7 | 0 (3) | 0 (3) | - | 0 (4) | 0 (2) |
| Opponent | Hammer | 5 | 44 (5) | 6 | 38 | 36 | 20% | 2.8 | 59 (3) | 18 (2) | - | 54 (4) | 0 (1) |
| Opponent | Holder | 4 | 55 (4) | 0 | 55 | 46 | 50% | 3.0 | 0 (1) | 77 (3) | - | 0 (1) | 77 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 57 | 67% | 5.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: cnsr-c940641-p45

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 311 | 144 | 2.0 | 1.0 | 72 | 0 | +72 | 1 of 2 | 2 of 2 | - | +72 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 925 | 9.0 | 1.0 | 103 | 12 | +91 | 3 of 9 | 6 of 9 | - | +91 |
| Mine | Lizardmen | 1 | 186 | 240 | 3.0 | 1.3 | 80 | 0 | +80 | 1 of 3 | 2 of 3 | +195 | +22 |
| **Mine** | all armies | 3 | 166 | 436 | 4.7 | 1.1 | 94 | 8 | +86 | 5 of 14 | 10 of 14 | +195 | +77 |
| Opponent | Vampire Counts | 1 | 0 | 388 | 3.0 | 1.3 | 129 | 0 | +129 | 0 of 3 | 3 of 3 | +141 | +124 |
| Opponent | Warriors of Chaos | 2 | 0 | 63 | 0.5 | 1.0 | 126 | 0 | +126 | 0 of 1 | 1 of 1 | - | +126 |
| **Opponent** | all armies | 3 | 0 | 171 | 1.3 | 1.2 | 128 | 0 | +128 | 0 of 4 | 4 of 4 | +141 | +124 |

### Effective charges: cnsr-c940641-p45

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +144) | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Kingdom of Bretonnia | 9 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 0 | 2 (net +42) | 2 (net +420) | 2 | 14% (1 of 7) |
| Mine | Lizardmen | 3 | 1 (net +0) | 0 | 0 | 0 | 1 (net +195) | 0 | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 0 | 0 | 2 (net +106) | 1 (net +175) | 0 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +126) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p45

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 230 | 437 | +0 | 63 | 18 | +45 | +19.5 |
| Mine | 50-54% | 1 | 214 | 205 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 371 | 365 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 360 | 192 | +280 | 325 | 69 | +256 | +71.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 455 | 103 | +106 | 122 | 0 | +122 | +26.9 |
| Mine | No odds | 3 | 175 | 248 | -21 | 15 | 36 | -21 | -11.8 |
| Mine | All fights | 14 | 319 | 227 | +86 | 117 | 25 | +92 | +28.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 294 | 150 | +150 | 150 | 0 | +150 | +51.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 496 | 106 | +106 | 106 | 0 | +106 | +21.5 |
| Opponent | All fights | 4 | 395 | 128 | +128 | 128 | 0 | +128 | +32.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p45 | move | 32 | 6 (19%) | 5 (16%) | 4 (12%) | 22 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

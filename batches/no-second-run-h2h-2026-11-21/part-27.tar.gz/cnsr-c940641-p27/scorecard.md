# Doctrine scorecard: cnsr-c940641-p27

### Scorecard: cnsr-c940641-p27

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 8 | 3 | 1 | 3 | 0 | 0 | 0 | 139 |
| L0405 | 3 | 1 | Opponent | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 1120 |
| L0421 | 1 | 1 | Mine | no | 9 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 2 | - | 0 | 6 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 8.0 | 4.0 | 0.7 | 2.0 | 0.0 | 0.0 | 0.0 | 173.0 |
| **Average** | | | Opponent | 0% | 1.0 | - | 0.3 | 3.3 | 0.0 | 0.0 | 0.0 | 630.0 |

### KPIs: cnsr-c940641-p27

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 9% (1 of 11) | 71% (5 of 7) | 33% (6 of 18) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 33% (1 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 50% (2 of 4); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | 0% (0 of 6) | 28% (5 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (5 of 12) | 0% (0 of 5) | 29% (5 of 17) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 44% (4 of 9) | 44% (4 of 9) |
| Points that never fought | lower | 84% (5019 of 5998) | 72% (4329 of 5999) | 78% (9348 of 11997) |
|   infantry points that never fought | lower | 87% (1235 of 1424) | 83% (1414 of 1703) | 85% (2649 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (12 of 23) | 73% (19 of 26) | 63% (31 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2688 of 5120) | 68% (3196 of 4677) | 60% (5884 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (57%) | 0.7 (33%) | 2.0 (46%) |
| MARCHED: its unit marched | 1.0 (43%) | 1.0 (50%) | 2.0 (46%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (17%) | 0.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.0 | 1.7 | 1.7 | 0.7 |
| not cast | 2.3 | 3.0 | 4.3 | 2.3 | 11.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (78%) | 2.0 (46%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (46%) | 0.3 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (86%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (100%) | 0.7 (22%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.0 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 67% (2 of 3) | - | 67% (2 of 3) |
| the unit moved after it | 50% (1 of 2) | - | 50% (1 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 0% (0 of 2) | - | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | - | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (54 of 81) | 70% (72 of 103) | 68% (126 of 184) |
|   cavalry | 83% (10 of 12) | 0% (0 of 7) | 53% (10 of 19) |
|   character | 50% (5 of 10) | 80% (20 of 25) | 71% (25 of 35) |
|   chariot | 71% (15 of 21) | 38% (5 of 13) | 59% (20 of 34) |
|   infantry | 17% (2 of 12) | 50% (11 of 22) | 38% (13 of 34) |
|   war machine | 85% (22 of 26) | 100% (36 of 36) | 94% (58 of 62) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (26%) | 2.0 (19%) | 4.3 (22%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.3 (48%) | 5.0 (48%) | 9.3 (48%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (26%) | 3.0 (29%) | 5.3 (28%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 1.0 | 73% | 4.0 pts | 15 pts |
| character | 8.3 | 4.3 | 76% | 14.6 pts | 121 pts |
| chariot | 6.7 | 13.0 | 40% | 27.7 pts | 185 pts |
| infantry | 7.3 | 3.0 | 68% | 15.6 pts | 114 pts |
| war machine | 19.3 | 16.3 | 64% | 17.6 pts | 340 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 0.3 | 0.7 |
| Charges that made contact a game | 1.0 | 0.3 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.14 declared, 0.14 contact (22 units) | 0.05 declared, 0.05 contact (22 units) | 0.09 declared, 0.09 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (1 of 1) | - | 25% (1 of 4) |
| Character in a unit | 100% (10 of 10) | 0% (0 of 1) | - | 91% (10 of 11) |
| Character on its own | 100% (2 of 2) | 33% (1 of 3) | 100% (3 of 3) | 75% (6 of 8) |
| Chariot | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| Infantry | 62% (5 of 8) | 40% (2 of 5) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 33% (1 of 3); on the table 100% | 42% (5 of 12) | 76% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 74% | 79% (11 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 67% | 67% (6 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p27, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 67% (2) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnsr-c940641-p27

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 100% (1 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (22 of 33) | 64% (27 of 42) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 33% (3 of 9) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.3 |
| Movement | Points that never moved of their own | 173.0 | 630.0 |
| Movement | Fights charged into per game | 1.0 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net +388 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +95 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +540 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 12.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (15 of 32) | 81% (29 of 36) |
| Shooting | Points destroyed by shooting units | 156.3 | 103.3 |
| Shooting | War machine shots | 7.3 | 12.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 50% (18 of 36) |
| Shooting | Points destroyed by war machines | 176.0 | 68.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | - |
| Magic | Wounds caused by magic missiles | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 1.7 | 1.7 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 341.0 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +388 | +56 |
| Combat | Net per 100 charger points, damage counted | +114.5 | +112.0 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +341 | +0 |
| Combat | Net points per supported fight / lone fight | - / +341 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 3 | 0 of 1 |
| Game | Points lost | 256.3 | 822.3 |
| Game | VP from objectives | 976.7 | 626.7 |
| Game | Lone holders (player turns) | 8.0 | 1.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +943 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1079
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p27

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 17.3 | +742.9 | 0.0 | 299.3 | 9.7 | -32.0 | 0.0 | 209.3 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 43.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.7 | +3.8 | 0.0 | 360.0 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 0.7 | +0.0 | 68.0 | 0.0 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 12.0 | +293.8 | 375.3 | 190.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +33.4 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +10.2 | 0.0 | 30.3 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 19.0 | -893.1 | 0.0 | 103.3 | 9.0 | -844.9 | 0.0 | 617.3 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 241.3 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 11.3 | +0.0 | 0.0 | 43.3 | 5.7 | +0.0 | 0.0 | 124.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 70.0 |
| CONVEYANCE SEARCH | 1.0 | +113.8 | 46.3 | 0.0 | - | - | - | - |
| COVER ONCE | 3.7 | -126.8 | 0.0 | 31.7 | 3.3 | -183.2 | 0.0 | 210.7 |
| DENIED BY THE FIGHT | 0.3 | -6.5 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| DUEL STOPS AT THE KILL | 0.3 | -7.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +6.8 | 211.7 | 0.0 | 0.3 | -1.5 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +6.4 | 180.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 8.3 | +114.1 | 0.0 | 196.0 | 8.0 | +127.9 | 0.0 | 136.0 |
| FEATURE BUFFS | - | - | - | - | 1.3 | +11.9 | 0.0 | 122.7 |
| FIRE IN ORDER | 1.7 | +0.0 | 72.3 | 31.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 94.3 | +7340.7 | 1756.0 | 682.7 | 81.7 | +3405.9 | 1142.7 | 1517.3 |
| FLANK NOT WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 217.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +87.9 | 0.0 | 70.0 |
| FOUR ROUNDS | 1.0 | +255.4 | 211.7 | 0.0 | 0.3 | +7.9 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -2.2 | 30.7 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +8.3 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -10.5 | 31.7 | 0.0 | - | - | - | - |
| GOAL WALK | 14.3 | +2065.0 | 0.0 | 43.3 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 3.7 | +21.0 | 104.7 | 103.3 | 1.7 | +2.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 103.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 482.7 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 206.7 | 3.0 | +0.0 | 0.0 | 102.3 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -37.7 | 0.0 | 0.0 | 3.3 | -112.3 | 0.0 | 421.3 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 5.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.3 | +2592.2 | 0.0 | 406.0 | 33.7 | +1324.2 | 0.0 | 369.3 |
| HIS SHOTS BY HIS RUN | 36.7 | +936.0 | 0.0 | 386.0 | 25.0 | +553.9 | 0.0 | 853.7 |
| HIS TURN DENIED | 0.7 | +105.3 | 31.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 245.3 |
| HOLDER ASSIGNMENT | 9.0 | +989.9 | 0.0 | 0.0 | 9.0 | +844.4 | 0.0 | 128.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -54.8 | 211.7 | 0.0 | 0.3 | -1.5 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +127.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 7.0 | -112.8 | 0.0 | 68.0 | 9.0 | -119.0 | 0.0 | 88.7 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 140.0 | 21.7 | 0.3 | +0.0 | 0.0 | 180.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +0.5 | 0.0 | 0.0 | 0.3 | +2.7 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -17.3 | 0.0 | 18.3 |
| MANOEUVRE | 3.0 | +2.6 | 0.0 | 103.3 | 2.0 | +3.1 | 0.0 | 61.3 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +65.6 | 0.0 | 180.0 |
| MARCH CHECK | 1.3 | +112.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +168.6 | 0.0 | 0.0 | 0.7 | +73.4 | 0.0 | 180.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +111.6 | 0.0 | 0.0 | 0.3 | +4.3 | 0.0 | 21.7 |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 2.0 | +43.0 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +44.2 | 0.0 | 0.0 | 3.0 | +8.8 | 0.0 | 180.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.3 | +101.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.7 | -242.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +641.5 | 0.0 | 0.0 | 0.7 | +41.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +345.0 | 0.0 | 0.0 | 6.0 | +242.8 | 0.0 | 98.7 |
| NEXT CHARGE BY LIST | 3.0 | +648.3 | 30.7 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.0 | -49.4 | 211.7 | 0.0 | 0.3 | -6.9 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -207.2 | 0.0 | 31.7 | 3.0 | -210.2 | 0.0 | 73.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -95.5 | 0.0 | 0.0 | 0.7 | -0.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.0 | +4.9 | 0.0 | 0.0 | 4.3 | -10.6 | 0.0 | 61.3 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +10.7 | 211.7 | 0.0 | 0.3 | +2.5 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | -2.1 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 21.7 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +40.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -47.7 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 41.3 | +828.7 | 455.0 | 423.0 | 39.0 | +799.9 | 239.3 | 1084.0 |
| PROMISE BY ITS OWN SUM | 8.0 | -339.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 27.7 | +2802.5 | 394.7 | 63.3 | 19.0 | +1941.5 | 0.0 | 443.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +8.6 | 0.0 | 118.3 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 0.3 | -0.8 | 0.0 | 18.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 21.7 |
| RESERVE FALL BACK | 0.7 | +14.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -9.0 | 211.7 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -11.8 | 31.7 | 0.0 | - | - | - | - |
| RUN DOWN | 0.3 | -0.5 | 0.0 | 0.0 | 0.3 | -4.6 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.3 | -14.2 | 30.7 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.0 | -386.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.7 | +360.5 | 61.3 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +44.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.0 | +0.0 | 0.0 | 95.0 | 15.0 | +0.0 | 0.0 | 208.3 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +55.5 | 0.0 | 0.0 | 1.0 | +220.0 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT RISK POINTS | 31.7 | +735.7 | 0.0 | 356.7 | 16.7 | -32.7 | 0.0 | 473.0 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.3 | +499.5 | 0.0 | 230.0 | 20.0 | +838.2 | 0.0 | 190.0 |
| SPELL SETS UP CHARGE | 0.3 | +44.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 3.7 | +89.2 | 360.0 | 360.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 180.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.8 | 0.0 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 47.7 | +0.0 | 1544.3 | 596.0 | 47.0 | +0.0 | 1142.7 | 799.0 |
| STAY WORTH | 30.0 | +284.6 | 1108.3 | 325.0 | 37.7 | +27.2 | 1050.0 | 637.3 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | 0.3 | +26.1 | 0.0 | 0.0 | 1.7 | +127.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 0.3 | +26.1 | 0.0 | 0.0 | 1.7 | +127.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 21.7 | 3.7 | +0.0 | 0.0 | 59.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 21.7 | 3.0 | +0.0 | 0.0 | 59.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.0 | +0.0 | 0.0 | 309.7 | 40.0 | +0.0 | 0.0 | 641.3 |
| TIED UP BY THE SUM | 0.3 | +29.8 | 31.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 25.3 | +336.6 | 330.7 | 86.7 | 15.0 | +209.0 | 0.0 | 154.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.7 | -145.6 | 0.0 | 0.0 | 1.7 | -579.2 | 0.0 | 360.0 |
| WOUNDS ON THE RANKS | 2.7 | +199.1 | 0.0 | 0.0 | 1.7 | +45.3 | 0.0 | 134.7 |

### Rule changes: cnsr-c940641-p27

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 81 | 81 | 59 | 19.67 | +1894 | +32.1 |
| HOLDER ASSIGNMENT | 54 | 54 | 50 | 16.67 | +2958 | +59.2 |
| HIS SHOT LIST | 249 | 235 | 46 | 15.33 | +1139 | +24.8 |
| HIS SHOTS BY HIS RUN | 185 | 175 | 46 | 15.33 | +612 | +13.3 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -1252 | -52.2 |
| GOAL WALK | 52 | 43 | 22 | 7.33 | +2691 | +122.3 |
| SHOT RISK POINTS | 145 | 136 | 22 | 7.33 | +850 | +38.6 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 121 | 102 | 15 | 5.00 | +10 | +0.7 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| IDLE COST | 48 | 40 | 12 | 4.00 | +54 | +4.5 |
| STAY WORTH | 203 | 177 | 12 | 4.00 | +192 | +16.0 |
| CANNON PLANNED TARGET | 56 | 56 | 10 | 3.33 | -402 | -40.2 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 10 | 3.33 | -1017 | -101.7 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FIRE IN ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FIVE ACTION | 528 | 512 | 7 | 2.33 | +579 | +82.8 |
| QUARTER ODDS | 140 | 138 | 7 | 2.33 | +972 | +138.8 |
| SET UP BY THE SET | 8 | 8 | 7 | 2.33 | +790 | +112.9 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 7 | 2.33 | +190 | +27.1 |
| LEGAL CHARGES ONLY | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 84 | 77 | 5 | 1.67 | +776 | +155.2 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| SHOTS IN THE MOVE | 115 | 77 | 5 | 1.67 | +71 | +14.3 |
| THE RISK READS HIS RUN | 18 | 18 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| NEXT CHARGE BY LIST | 9 | 9 | 4 | 1.33 | +871 | +217.8 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 4 | 1.33 | +26 | +6.5 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| FOUR ROUNDS | 4 | 4 | 3 | 1.00 | +482 | +160.7 |
| MANOEUVRE | 15 | 15 | 3 | 1.00 | +29 | +9.8 |
| MOVE TO CHARGE COMPUTED | 10 | 10 | 3 | 1.00 | +870 | +289.9 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +12 | +5.8 |
| FALLS SHORT | 49 | 43 | 2 | 0.67 | +22 | +10.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MARCH CHECK | 4 | 3 | 2 | 0.67 | +22 | +11.2 |
| MAX FOR POSITIONING | 7 | 5 | 2 | 0.67 | +59 | +29.4 |
| NEARER NOT NEEDED | 38 | 36 | 2 | 0.67 | +79 | +39.5 |
| ONE OBJECTIVE FORMULA | 19 | 12 | 2 | 0.67 | +48 | +23.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -1 | -0.5 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +44 | +22.2 |
| SUPPORT ADDS | 6 | 6 | 2 | 0.67 | +45 | +22.6 |
| SUPPORT WORKED OUT | 6 | 6 | 2 | 0.67 | +45 | +22.6 |
| WOUNDS ON THE RANKS | 13 | 13 | 2 | 0.67 | +74 | +36.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +21 | +20.7 |
| CAST JOB | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +264 | +263.6 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +25 | +24.8 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +116 | +115.7 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +166 | +166.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +197 | +196.9 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -11 | -10.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -143 | -143.1 |
| REDIRECT COUNTER | 2 | 1 | 1 | 0.33 | +56 | +56.4 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| WHOLE FIGHT DANGER | 10 | 10 | 1 | 0.33 | +45 | +45.0 |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 29 | 29 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| COVER ONCE | 21 | 13 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 3 | 3 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 13 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 16 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 25 | 24 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 13 | 13 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 14 | 10 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 20 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 16 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 87 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 5 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 7 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 19 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 8 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 14 | 7 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 241 | trace | - | - | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 78 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 25 | 15 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 284 | 280 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 20 | not checked | - | - | - | - |
| THE TABLE BINDS | 255 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p27

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 3.00 | 52.6 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | - | 101.7 |
| ARMY TABLE | rule | 1.67 | 0.33 | 109.1 |
| CANNON PLANNED TARGET | rule | - | 2.00 | 67.1 |
| NO REASON | gate | 1.00 | - | 48.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 10.7 |
| PATHS CROSS | rule | 0.33 | - | 6.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 143.1 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |

### Plans: cnsr-c940641-p27

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 100% | 442 | 237 | 53% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 31.0 | 96% | 2616 | 0 | 0% |
| Mine | shoot | 9.0 | 67% | 287 | 592 | 206% |
| Opponent | charge | 0.3 | 0% | 34 | 16 | 47% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 24.7 | 89% | 952 | 0 | 0% |
| Opponent | shoot | 12.3 | 68% | 690 | 784 | 114% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p27

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p27

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 48 (11) | 48 | 0 | 0 | 18% | 2.2 | 19 (5) | 114 (4) | 0 (2) | 15 (7) | 83 (4) |
| Mine | Clean-up | 3 | 157 (3) | 58 | 99 | 0 | 67% | 3.0 | 157 (3) | - | - | 150 (2) | 169 (1) |
| Mine | Hammer | 8 | 23 (8) | 9 | 15 | 20 | 12% | 1.7 | 0 (2) | 28 (6) | - | 40 (5) | 7 (3) |
| Mine | Holder | 4 | 82 (4) | 0 | 82 | 27 | 75% | 2.0 | 0 (1) | 108 (3) | - | 237 (1) | 24 (3) |
| Mine | Shooter | 1 | 27 (1) | 0 | 27 | 0 | 0% | 2.0 | 27 (1) | - | - | - | 27 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 0 (14) | 0 | 0 | 52 | 43% | 3.2 | 0 (10) | 0 (1) | - | 0 (9) | 0 (2) |
| Opponent | Clean-up | 4 | 96 (4) | 0 | 96 | 0 | 75% | 5.0 | - | 96 (4) | - | 96 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 6 | 68 (6) | 51 | 17 | 29 | 17% | 2.6 | 109 (2) | 0 (1) | 64 (3) | 68 (6) | - |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 54 | 75% | 4.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 21 (9) | 21 | 0 | 62 | 11% | 1.0 | 21 (9) | - | - | 0 (1) | 24 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: cnsr-c940641-p27

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 134 | 512 | 1.5 | 1.0 | 341 | 0 | +341 | 2 of 3 | 2 of 3 | - | +341 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 332 | 341 | 1.0 | 1.0 | 341 | 0 | +341 | 2 of 3 | 2 of 3 | - | +341 |
| Opponent | Dwarfen Mountain Holds | 1 | 449 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 171 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |

### Effective charges: cnsr-c940641-p27

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 3 | 1 (net +388) | 0 | 0 | 0 | 1 (net +95) | 1 (net +540) | 0 | 0% (0 of 3) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p27

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 339 | 239 | +388 | 537 | 97 | +441 | +129.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 339 | 440 | +540 | 540 | 0 | +540 | +159.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 95 | +95 | 321 | 137 | +184 | +54.2 |
| Mine | All fights | 3 | 339 | 258 | +341 | 466 | 78 | +388 | +114.5 |
| Opponent | 76-89% | 1 | 50 | 112 | +0 | 56 | 0 | +56 | +112.0 |
| Opponent | All fights | 1 | 50 | 112 | +0 | 56 | 0 | +56 | +112.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p27 | move | 10 | 2 (20%) | 2 (20%) | 1 (10%) | 7 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

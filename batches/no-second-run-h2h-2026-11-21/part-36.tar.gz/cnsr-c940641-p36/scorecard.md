# Doctrine scorecard: cnsr-c940641-p36

### Scorecard: cnsr-c940641-p36

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | no | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 2 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2934 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 0.0 | 2.5 | 5.0 | 2.5 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 50% | 3.0 | 2.0 | 3.0 | 1.0 | 1.0 | 0.0 | 0.0 | 85.0 |

### KPIs: cnsr-c940641-p36

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 15) | 0% (0 of 29) |
| Winner chose to follow up after the loser gave ground |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 50% (1 of 2); on the table 50% | 75% (3 of 4); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 17% (1 of 6) | 33% (4 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (3 of 6) | 25% (1 of 4) | 40% (4 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (2 of 2) | 86% (6 of 7) | 89% (8 of 9) |
| Points that never fought | lower | 54% (2157 of 3999) | 14% (562 of 4000) | 34% (2719 of 7999) |
|   infantry points that never fought | lower | 100% (457 of 457) | 27% (150 of 559) | 60% (607 of 1016) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (8 of 12) | 67% (12 of 18) | 67% (20 of 30) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (1569 of 3154) | 70% (2546 of 3654) | 60% (4115 of 6808) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (100%) | 0.7 (40%) | 1.7 (62%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (20%) | 0.3 (12%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (40%) | 0.7 (25%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 2.0 | 1.7 | 1.3 | 0.7 | 1.3 |
| not cast | 4.3 | 0.0 | 2.3 | 2.7 | 1.3 | 21.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.7 (62%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.0 (0%) | 0.7 (25%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (100%) | - | 2.0 (86%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.3 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 40% (2 of 5) | - | 40% (2 of 5) |
| the unit moved after it | 100% (2 of 2) | - | 100% (2 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 0% (0 of 2) | - | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | - | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | - | 0% (0 of 6) | 0% (0 of 6) |
|   character | - | 0% (0 of 6) | 0% (0 of 6) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| CHARGED: it charged | - | 0.7 (33%) | 0.7 (33%) |
| NO TARGET IN RANGE | - | 0.3 (17%) | 0.3 (17%) |
| NO LINE OF SIGHT: in range, out of arc or sight | - | 1.0 (50%) | 1.0 (50%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 5.0 | 4.8 |
| Charges that made contact a game | 3.7 | 4.7 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.50 declared, 1.25 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 1.20 declared, 1.00 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.27 contact (22 units) | 0.58 declared, 0.54 contact (26 units) | 0.48 declared, 0.42 contact (48 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (5 of 5) | 67% (2 of 3) | 0% (0 of 1) | 78% (7 of 9) |
| Character in a unit | 75% (3 of 4) | 100% (1 of 1) | 0% (0 of 1) | 67% (4 of 6) |
| Character on its own | 0% (0 of 3) | 100% (2 of 2) | 33% (1 of 3) | 38% (3 of 8) |
| Infantry | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monster | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 54% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 14% | 67% (12 of 18) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p36, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 62% (8) | 78% (7) | 68% (15) |
| ...free all their last turn and able to turn (per game) | 2.33 | 1.33 | 3.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.67 | 0.67 | 2.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnsr-c940641-p36

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 62% (8 of 13) | 64% (7 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 100% (2 of 2) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 100% (6 of 6) |
| Movement | Charges halted short of contact | 0.7 | 0.3 |
| Movement | Idle units | 2.5 | 1.0 |
| Movement | Points that never moved of their own | 0.0 | 85.0 |
| Movement | Fights charged into per game | 4.5 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 8, net +0 | 1 of 5, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 8, net +142 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 8, net +260 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 8, net +99 | 3 of 5, net +53 |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.0 / 0.3 | 0.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 358.0 | 334.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +153 | +82 |
| Combat | Net per 100 charger points, damage counted | +44.4 | +36.3 |
| Combat | First round won (charged fights) | 67% | 88% |
| Combat | Net points per charged fight | +116 | +90 |
| Combat | Net points per supported fight / lone fight | +198 / +106 | - / +90 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 9 | 3 of 8 |
| Game | Points lost | 452.0 | 667.0 |
| Game | VP from objectives | 525.0 | 715.0 |
| Game | Lone holders (player turns) | 0.0 | 3.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) +138 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1119
- Games not ended: 1 (L2934-1); findings 1, warnings 0

### Opponent rules: cnsr-c940641-p36

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +5.9 | 0.0 | 0.0 | 0.3 | +96.4 | 0.0 | 0.0 |
| ARMY TABLE | 18.0 | +263.6 | 0.0 | 56.7 | 16.7 | +328.9 | 0.0 | 165.0 |
| ASSAILMENT BY POINTS | 0.3 | +2.3 | 0.0 | 193.3 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +39.1 | 113.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.7 | +40.7 | 0.0 | 15.0 | 0.3 | +4.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +23.0 | 0.0 | 86.7 |
| CHARGE LIST READ AGAIN | 0.3 | -6.3 | 66.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 9.3 | -259.8 | 0.0 | 0.0 | 6.3 | -275.2 | 0.0 | 342.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 173.7 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 22.0 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 95.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.3 | +56.6 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 8.0 | -550.5 | 0.0 | 0.0 | 6.7 | -357.0 | 0.0 | 166.3 |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 0.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -33.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +58.5 | 0.0 | 0.0 |
| EXACT ROUND | 2.7 | +18.1 | 196.7 | 0.0 | 3.3 | +14.9 | 56.7 | 38.7 |
| FACES THE THREAT | - | - | - | - | 0.7 | +46.1 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 4.7 | +7.6 | 367.3 | 193.3 | 3.7 | +0.0 | 156.3 | 38.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 20.7 | +269.6 | 0.0 | 15.0 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 0.3 | +3.5 | 0.0 | 32.7 |
| FIGHT TO THE END | 1.7 | +73.8 | 101.7 | 0.0 | 1.0 | +71.9 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 77.3 | +3956.9 | 480.7 | 583.3 | 73.3 | +4570.7 | 156.3 | 1193.7 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 50.0 | 8.7 | +0.0 | 0.0 | 367.3 |
| FOCUS FIRE | - | - | - | - | 0.3 | +5.7 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +36.8 | 0.0 | 0.0 | 0.7 | +30.2 | 0.0 | 38.7 |
| FOUR ROUNDS | 4.7 | +531.7 | 367.3 | 193.3 | 4.3 | +390.9 | 156.3 | 38.7 |
| FREED FROM HIS FIGHT | 6.7 | +0.0 | 0.0 | 193.3 | 10.0 | +0.0 | 0.0 | 348.0 |
| FRIEND CHARGES FIRST | 0.3 | -69.0 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +26.5 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -8.5 | 31.7 | 38.7 |
| GOAL WALK | 6.7 | +584.6 | 0.0 | 0.0 | 12.0 | +968.7 | 0.0 | 255.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 5.3 | +0.0 | 0.0 | 193.3 | 5.7 | +0.0 | 0.0 | 238.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 95.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 342.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +3.2 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.0 | +0.0 | 0.0 | 193.3 | 7.7 | +0.0 | 0.0 | 134.3 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 193.3 | 4.3 | +0.0 | 0.0 | 227.0 |
| HIS MOVE AND SHOT | 1.7 | -4.2 | 0.0 | 0.0 | 1.3 | -6.1 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 193.3 | 8.0 | +0.0 | 0.0 | 227.0 |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 163.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 50.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 29.7 | +345.9 | 0.0 | 341.7 | 7.7 | +55.8 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 22.7 | +173.3 | 0.0 | 15.0 | 14.0 | +304.2 | 0.0 | 173.3 |
| HIS TURN RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 0.0 | 14.3 | +0.0 | 0.0 | 130.7 |
| HOLDER ASSIGNMENT | 10.0 | +870.2 | 0.0 | 0.0 | 9.3 | +1161.2 | 0.0 | 65.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -181.3 | 301.3 | 193.3 | 4.0 | -181.7 | 156.3 | 38.7 |
| IDLE COST | 20.7 | -258.5 | 0.0 | 33.3 | - | - | - | - |
| JOINT CHARGE NOW | 1.0 | +22.7 | 132.0 | 0.0 | 0.3 | +9.7 | 0.0 | 0.0 |
| JOINT ON THE TABLE | 0.3 | +8.9 | 66.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.7 | +0.0 | 452.3 | 507.3 | 4.3 | +0.0 | 0.0 | 48.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -1.7 | 15.0 | 0.0 |
| LOST AFTER ESCAPE | 3.0 | +14.4 | 262.7 | 193.3 | 1.3 | -0.2 | 0.0 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 84.7 | 0.0 |
| MANOEUVRE | 1.3 | -18.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +37.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | +371.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +15.8 | 0.0 | 0.0 | 2.3 | +32.8 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +25.3 | 0.0 | 0.0 | 0.3 | +12.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +12.5 | 0.0 | 0.0 | 2.0 | +22.2 | 0.0 | 38.7 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 16.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.7 | +670.4 | 0.0 | 193.3 | 7.0 | +559.9 | 0.0 | 132.0 |
| NEARER NOT NEEDED | 8.7 | +326.7 | 0.0 | 0.0 | 7.0 | +290.9 | 0.0 | 113.3 |
| NEXT CHARGE BY LIST | 6.3 | +531.8 | 0.0 | 193.3 | 5.3 | +427.4 | 0.0 | 132.0 |
| NO DOUBLE ROUNDS | 3.3 | -238.3 | 268.7 | 193.3 | 3.3 | -150.2 | 156.3 | 38.7 |
| NO LATE CUT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 2.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.3 | -112.2 | 0.0 | 30.0 | 5.3 | -359.9 | 15.0 | 202.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -114.7 | 0.0 | 0.0 | 4.0 | -63.2 | 0.0 | 66.0 |
| ONE JOINT FIGURE | 0.7 | +49.1 | 66.0 | 0.0 | 0.3 | +17.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -98.9 | 0.0 | 0.0 | 3.0 | +43.2 | 0.0 | 32.7 |
| ONE PROMISE A TARGET | 0.7 | -39.1 | 0.0 | 0.0 | 0.3 | -32.5 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.6 | 0.0 | 193.3 | 0.7 | +23.6 | 0.0 | 0.0 |
| PATHS CROSS | 1.0 | +20.7 | 0.0 | 0.0 | 0.3 | +18.9 | 0.0 | 0.0 |
| PLAN RESULT | 40.0 | +469.7 | 56.7 | 483.3 | 36.0 | +232.5 | 114.7 | 659.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 66.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -178.1 | 0.0 | 0.0 | 12.0 | -504.4 | 0.0 | 172.3 |
| PROMISE KNOWS THE FIGHT | 1.7 | -0.6 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 7.0 | +369.4 | 0.0 | 293.3 | 5.7 | +764.6 | 25.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +46.2 | 0.0 | 0.0 | 2.3 | +10.9 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.0 | +21.3 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.7 | +177.3 | 0.0 | 40.0 | 2.0 | +87.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.7 | +40.4 | 0.0 | 65.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -2.5 | 0.0 | 193.3 | 3.0 | -212.8 | 0.0 | 132.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 84.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +38.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.3 | +136.6 | 140.3 | 193.3 | 4.0 | +76.8 | 131.3 | 38.7 |
| ROUNDS AFTER TERROR | 1.7 | -30.7 | 107.7 | 193.3 | 0.7 | -18.5 | 0.0 | 0.0 |
| RUN DOWN | 4.0 | -58.8 | 301.3 | 193.3 | 1.3 | -3.9 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 3.0 | -147.5 | 0.0 | 0.0 | 1.3 | -30.7 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +31.0 | 0.0 | 0.0 | 0.3 | +3.3 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +41.5 | 15.0 | 38.7 |
| SET CREDITED ONCE | 2.7 | -79.7 | 0.0 | 30.0 | 0.7 | -4.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 5.7 | +256.4 | 69.0 | 30.0 | 1.0 | -33.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 69.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -4.6 | 0.0 | 0.0 |
| SHOT RISK POINTS | 10.3 | -76.4 | 0.0 | 80.0 | 9.0 | +8.7 | 0.0 | 86.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +23.0 | 0.0 | 0.0 | 4.0 | +37.1 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +19.3 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -4.0 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 208.3 | 7.3 | +0.0 | 0.0 | 161.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| STANDS STILL | 15.0 | +0.0 | 113.3 | 100.0 | 29.7 | +0.0 | 0.0 | 480.0 |
| STAY WORTH | - | - | - | - | 6.0 | +28.3 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 1.7 | +0.0 | 0.0 | 193.3 | - | - | - | - |
| SUPPORT ADDS | 6.0 | +812.0 | 0.0 | 0.0 | 4.7 | +473.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 69.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 6.0 | +812.0 | 0.0 | 0.0 | 4.7 | +473.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.4 | 0.0 | 15.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 66.0 | 32.7 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.3 | +0.0 | 0.0 | 133.7 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.0 | +0.0 | 0.0 | 98.3 | 33.0 | +0.0 | 0.0 | 612.0 |
| TIED UP BY THE SUM | 1.3 | +170.5 | 140.3 | 0.0 | 1.3 | +209.2 | 15.0 | 38.7 |
| TIME ON OUR SIDE | - | - | - | - | 51.0 | +483.1 | 0.0 | 1014.7 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 132.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 2.0 | -27.7 | 65.3 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 1.0 | +33.0 | 32.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -189.3 | 0.0 | 0.0 | 2.3 | -199.7 | 0.0 | 255.3 |
| WHOLE FIGHT GAIN | 0.7 | +10.6 | 66.0 | 0.0 | 0.3 | +2.7 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.3 | +0.5 | 0.0 | 0.0 | 0.3 | +2.6 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p36

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 104 | 104 | 68 | 22.67 | +2151 | +31.6 |
| HOLDER ASSIGNMENT | 58 | 58 | 53 | 17.67 | +3447 | +65.0 |
| LEGAL CHARGES ONLY | 36 | 36 | 36 | 12.00 | +0 | +0.0 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -1416 | -48.8 |
| THE TABLE AGAIN | 31 | 31 | 26 | 8.67 | +0 | +0.0 |
| FIVE ACTION | 452 | 430 | 25 | 8.33 | +1409 | +56.4 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| PROMISE BY ITS OWN SUM | 63 | 63 | 24 | 8.00 | -2047 | -85.3 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 23 | 7.67 | +15 | +0.7 |
| GOAL WALK | 56 | 56 | 20 | 6.67 | +1376 | +68.8 |
| HIS SHOTS BY HIS RUN | 110 | 99 | 20 | 6.67 | +235 | +11.8 |
| FOUR ROUNDS | 27 | 25 | 15 | 5.00 | +970 | +64.6 |
| IDLE COST | 62 | 44 | 15 | 5.00 | +92 | +6.2 |
| MOVE TO CHARGE COMPUTED | 44 | 34 | 14 | 4.67 | +518 | +37.0 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| HIS SHOT LIST | 112 | 105 | 12 | 4.00 | +62 | +5.2 |
| TIME ON OUR SIDE | 153 | 124 | 12 | 4.00 | +3 | +0.2 |
| NEXT CHARGE BY LIST | 35 | 30 | 11 | 3.67 | +470 | +42.8 |
| SET UP BY THE SET | 20 | 19 | 10 | 3.33 | +572 | +57.2 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 8 | 2.67 | +171 | +21.4 |
| QUARTER ODDS | 38 | 37 | 7 | 2.33 | +517 | +73.8 |
| RISK BY ARC | 22 | 20 | 7 | 2.33 | +271 | +38.8 |
| SUPPORT ADDS | 32 | 29 | 7 | 2.33 | +364 | +52.0 |
| SUPPORT WORKED OUT | 32 | 29 | 7 | 2.33 | +364 | +52.0 |
| THE RISK READS HIS RUN | 15 | 15 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 8 | 6 | 6 | 2.00 | +126 | +21.0 |
| CHAFF IN THE MOVE | 6 | 6 | 5 | 1.67 | +15 | +3.0 |
| FIGHT TO THE END | 8 | 8 | 5 | 1.67 | +159 | +31.8 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +201 | +40.2 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| SHOT RISK POINTS | 58 | 49 | 5 | 1.67 | +169 | +33.8 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 13 | 13 | 4 | 1.33 | -394 | -98.5 |
| FALLS SHORT | 62 | 50 | 4 | 1.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +97 | +24.3 |
| MAX FOR POSITIONING | 9 | 9 | 4 | 1.33 | +4 | +0.9 |
| NEARER NOT NEEDED | 47 | 45 | 4 | 1.33 | +75 | +18.7 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +119 | +29.7 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +69 | +23.0 |
| EXACT ROUND | 18 | 16 | 3 | 1.00 | +14 | +4.8 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -215 | -71.5 |
| WHOLE FIGHT DANGER | 15 | 15 | 3 | 1.00 | +76 | +25.2 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +307 | +153.4 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +0 | +0.2 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 44 | 29 | 2 | 0.67 | +65 | +32.6 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +138 | +69.2 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +36 | +17.8 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT COUNTER | 17 | 15 | 2 | 0.67 | +158 | +78.9 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -1 | -0.6 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +115 | +57.7 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +103 | +51.5 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +124 | +62.2 |
| STAY WORTH | 18 | 14 | 2 | 0.67 | +4 | +1.9 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -155 | -77.6 |
| WHOLE FIGHT | 3 | 3 | 2 | 0.67 | +36 | +18.1 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | -19 | -18.8 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +61 | +60.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +17 | +17.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +80 | +79.6 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +27 | +26.6 |
| LOST AFTER ESCAPE | 13 | 13 | 1 | 0.33 | +0 | +0.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -113 | -112.7 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +8 | +7.6 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +12 | +12.2 |
| PROMISE KNOWS THE FIGHT | 8 | 7 | 1 | 0.33 | -2 | -1.7 |
| ROUNDS AFTER TERROR | 7 | 7 | 1 | 0.33 | +8 | +7.6 |
| SHOTS IN THE MOVE | 14 | 9 | 1 | 0.33 | +14 | +14.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 17 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +1 | +0.7 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARGE LOSSES | 47 | 39 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 102 | 99 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 25 | 23 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 53 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 50 | 45 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 33 | 30 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 34 | 29 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 9 | 7 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 1 | 1 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 43 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 54 | 50 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 31 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 15 | 15 | 0 | 0.00 | - | - |
| HIS TURN RUN | 32 | 32 | 0 | 0.00 | - | - |
| HOLD ODDS | 90 | 90 | 0 | 0.00 | - | - |
| HONEST WORTH | 24 | 22 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 7 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 11 | 6 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 20 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 32 | 32 | 0 | 0.00 | - | - |
| NO SECOND RUN | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 22 | 11 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 24 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 228 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 16 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 10 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 10 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 134 | 127 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 219 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 8 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p36

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 5.67 | 85.3 |
| JOB FIRST | gate | 2.67 | 4.67 | 46.6 |
| ARMY TABLE | rule | 2.00 | 1.00 | 91.8 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 98.5 |
| NO REASON | gate | 1.00 | - | 45.9 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.33 | 71.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 31.6 |
| RULE SWITCHED OFF | gate | - | 0.67 | 108.6 |
| SUPPORT NARROWED | rule | 0.67 | - | 77.6 |
| CHARGE LIST READ AGAIN | rule | 0.33 | - | 18.8 |
| FALLBACK | gate | 0.33 | - | 32.6 |
| JOINT CHARGE NOW | rule | 0.33 | - | 3.8 |
| MARCH OF THE TABLE | rule | - | 0.33 | 112.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.7 |
| REFUSING RETIRES | rule | 0.33 | - | 5.2 |
| TURN GATE | gate | 0.33 | - | 4.2 |

### Plans: cnsr-c940641-p36

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 70% | 383 | 413 | 108% |
| Mine | join | 3.7 | 100% | 145 | 0 | 0% |
| Mine | move | 31.0 | 98% | 1703 | 0 | 0% |
| Mine | shoot | 0.7 | 50% | 63 | 57 | 90% |
| Mine | support | 1.3 | 100% | 0 | 0 | - |
| Opponent | charge | 3.3 | 60% | 311 | 232 | 75% |
| Opponent | join | 1.0 | 100% | 93 | 0 | 0% |
| Opponent | move | 30.3 | 96% | 1676 | 0 | 0% |
| Opponent | shoot | 0.7 | 0% | 14 | 0 | 0% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p36

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 55% | 83% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p36

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 8 | 120 (8) | 23 | 97 | 24 | 62% | 4.3 | 0 (4) | 339 (2) | 178 (2) | 156 (5) | 62 (3) |
| Mine | Character | 7 | 75 (7) | 75 | 0 | 45 | 43% | 3.2 | 110 (2) | 0 (4) | 0 (1) | 80 (5) | 0 (2) |
| Mine | Fast | 1 | 67 (1) | 67 | 0 | 100 | 0% | 2.0 | - | 67 (1) | - | - | 67 (1) |
| Mine | Fast Hammer | 4 | 11 (4) | 0 | 11 | 0 | 50% | 2.5 | - | 13 (3) | 0 (1) | 13 (3) | 0 (1) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.0 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 1 | 257 (1) | 0 | 257 | 0 | 100% | - | - | 257 (1) | - | 257 (1) | - |
| Opponent | Character | 8 | 52 (8) | 52 | 0 | 17 | 0% | 3.4 | 142 (2) | 21 (4) | 0 (2) | 10 (5) | 125 (3) |
| Opponent | Fast Hammer | 5 | 31 (5) | 0 | 31 | 66 | 20% | 3.2 | 40 (2) | 0 (1) | 39 (2) | 51 (2) | 21 (3) |
| Opponent | Hammer | 4 | 29 (4) | 0 | 29 | 45 | 25% | 3.7 | - | 29 (4) | - | 0 (2) | 62 (2) |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 30 | 50% | 5.0 | 0 (1) | 0 (2) | - | - | 0 (3) |

### Charged fights: cnsr-c940641-p36

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 524 | 4.5 | 1.1 | 116 | 0 | +116 | 3 of 9 | 6 of 9 | +198 | +106 |
| Opponent | Warriors of Chaos | 2 | 0 | 502 | 4.0 | 1.0 | 126 | 36 | +90 | 3 of 8 | 7 of 8 | - | +90 |

### Effective charges: cnsr-c940641-p36

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 9 | 2 (net +0) | 0 | 2 (net +142) | 0 | 1 (net +260) | 3 (net +99) | 1 | 25% (2 of 8) |
| Opponent | Warriors of Chaos | 8 | 1 (net +0) | 0 | 0 | 1 (net +50) | 0 | 3 (net +53) | 3 | 0% (0 of 5) |

### Charged fights, damage counted: cnsr-c940641-p36

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 367 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 2 | 258 | 229 | +142 | 142 | 0 | +142 | +55.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 298 | 283 | +99 | 207 | 0 | +207 | +69.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 480 | 116 | +260 | 260 | 0 | +260 | +54.2 |
| Mine | No odds | 1 | 471 | 207 | +207 | 207 | 0 | +207 | +43.9 |
| Mine | All fights | 9 | 344 | 222 | +116 | 153 | 0 | +153 | +44.4 |
| Opponent | Long shot (under 50%) | 1 | 479 | 471 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 116 | 50 | +50 | 50 | 0 | +50 | +43.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 265 | 172 | +53 | 110 | 78 | +31 | +11.8 |
| Opponent | No odds | 3 | 136 | 237 | +170 | 208 | 39 | +170 | +124.4 |
| Opponent | All fights | 8 | 225 | 218 | +90 | 126 | 44 | +82 | +36.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p36 | move | 18 | 4 (22%) | 4 (22%) | 4 (22%) | 10 (56%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

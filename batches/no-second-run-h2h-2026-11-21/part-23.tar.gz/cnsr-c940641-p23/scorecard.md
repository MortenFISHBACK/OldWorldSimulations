# Doctrine scorecard: cnsr-c940641-p23

### Scorecard: cnsr-c940641-p23

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 6 | - | 0 | 4 | 0 | 0 | 0 | 500 |
| L2131 | 1 | 1 | Opponent | no | 1 | 5 | 0 | 0 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 1 | 2 | 0 | 2 | 0 | 0 | 0 | 297 |
| L2235 | 3 | 1 | Opponent | no | 8 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | no | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 3.5 | 2.0 | 0.3 | 3.0 | 0.0 | 0.0 | 0.0 | 265.7 |
| **Average** | | | Opponent | 0% | 4.5 | 3.3 | 0.3 | 2.3 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: cnsr-c940641-p23

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 16) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 100% | - | 67% (2 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 100% | - | 80% (4 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 25% (3 of 12) | - | 25% (3 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (3 of 12) | - | 25% (3 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 83% (10 of 12) | 43% (6 of 14) | 62% (16 of 26) |
| Points that never fought | lower | 54% (3230 of 5997) | 60% (3603 of 5999) | 57% (6833 of 11996) |
|   infantry points that never fought | lower | 65% (1088 of 1675) | 90% (1181 of 1306) | 76% (2269 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (13 of 21) | 74% (23 of 31) | 69% (36 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 1.3 uses a game | 100% (3 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2635 of 4866) | 73% (4297 of 5884) | 64% (6932 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (44%) | - | 1.3 (44%) |
| MARCHED: its unit marched | 1.7 (56%) | - | 1.7 (56%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 2.7 | 1.0 | 1.0 | 2.0 |
| not cast | 4.7 | 5.3 | 1.0 | 3.0 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.3 (100%) | 0.0 (0%) | 1.3 (44%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (56%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (100%) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 67% (2 of 3) | 67% (2 of 3) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 75% (48 of 64) | 62% (25 of 40) | 70% (73 of 104) |
|   cavalry | 100% (12 of 12) | 47% (9 of 19) | 68% (21 of 31) |
|   character | 0% (0 of 9) | 67% (6 of 9) | 33% (6 of 18) |
|   chariot | 89% (8 of 9) | - | 89% (8 of 9) |
|   infantry | 82% (28 of 34) | 83% (10 of 12) | 83% (38 of 46) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 2.7 (53%) | 2.7 (26%) |
| CHARGED: it charged | 1.0 (19%) | 0.0 (0%) | 1.0 (10%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 2.3 (44%) | 2.3 (47%) | 4.7 (45%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (31%) | 0.0 (0%) | 1.7 (16%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.0 | 2.3 | 81% | 5.2 pts | 62 pts |
| character | 2.0 | 0.3 | 83% | 0.8 pts | 2 pts |
| chariot | 2.7 | 0.3 | 88% | 8.1 pts | 22 pts |
| infantry | 13.3 | 5.3 | 75% | 9.0 pts | 120 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 1.3 | 1.3 |
| Charges that made contact a game | 1.0 | 1.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.11 contact (27 units) | 0.12 declared, 0.08 contact (25 units) | 0.13 declared, 0.10 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 83% (5 of 6) | 100% (4 of 4) | - | 90% (9 of 10) |
| Character in a unit | 100% (3 of 3) | 100% (2 of 2) | 0% (0 of 2) | 71% (5 of 7) |
| Character on its own | 100% (4 of 4) | - | 50% (3 of 6) | 70% (7 of 10) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 64% (7 of 11) | 50% (2 of 4) | - | 60% (9 of 15) |
| Monster | 60% (3 of 5) | 0% (0 of 1) | - | 50% (3 of 6) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 67% (2 of 3); on the table 100% | 33% (2 of 6) | 30% | 56% (5 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 54% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 77% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | - | - | 48% | 74% (14 of 19) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 84% | 75% (9 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p23, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 100% (3) | 80% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: cnsr-c940641-p23

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 53% (9 of 17) | 33% (2 of 6) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 83% (5 of 6) |
| Strategy | Joined characters whose unit fought | 50% (3 of 6) | 67% (2 of 3) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.0 | 2.3 |
| Movement | Points that never moved of their own | 265.7 | 56.7 |
| Movement | Fights charged into per game | 1.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 1 of 3, net +122 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 3, net +114 | 1 of 3, net -405 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +0 | 1 of 3, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.0 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 16% (8 of 51) | 39% (11 of 28) |
| Shooting | Points destroyed by shooting units | 80.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | - |
| Magic | Wounds caused by magic missiles | 0.3 | - |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 38.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.7 / 0.0 / 0.0 / 0.0 | 0.0 / 2.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 230.7 | 222.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +99 | -30 |
| Combat | Net per 100 charger points, damage counted | +29.7 | -15.2 |
| Combat | First round won (charged fights) | 100% | 67% |
| Combat | Net points per charged fight | +76 | -94 |
| Combat | Net points per supported fight / lone fight | - / +76 | - / -94 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 1 of 3 |
| Game | Points lost | 254.0 | 412.0 |
| Game | VP from objectives | 1013.3 | 493.3 |
| Game | Lone holders (player turns) | 3.5 | 4.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +690 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 666
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnsr-c940641-p23

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 33.3 | +211.5 | 0.0 | 376.3 | 34.7 | +201.2 | 0.0 | 326.7 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +4.2 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +104.9 | 0.0 | 0.0 | 1.0 | +5.7 | 21.7 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +2.6 | 0.0 | 0.0 | 0.7 | +20.4 | 0.0 | 196.7 |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.0 | -831.7 | 0.0 | 65.0 | 31.0 | -1184.0 | 0.0 | 535.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 34.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 11.3 | +0.0 | 0.0 | 40.0 | 9.0 | +0.0 | 0.0 | 41.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +63.1 | 0.0 | 0.0 |
| COVER ONCE | 10.7 | -700.9 | 0.0 | 21.7 | 11.0 | -625.8 | 0.0 | 151.7 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 41.7 | 0.0 | 0.7 | -1.0 | 0.0 | 38.7 |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 4.7 | +258.6 | 40.7 | 84.0 |
| EXACT ROUND | 1.0 | +5.8 | 34.0 | 0.0 | 1.0 | +23.9 | 40.7 | 38.7 |
| FACES THE THREAT | - | - | - | - | 0.7 | +28.3 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.2 | 75.7 | 0.0 | 1.3 | +2.1 | 60.7 | 193.7 |
| FALLS SHORT | 7.3 | +107.7 | 0.0 | 40.0 | 18.0 | +200.6 | 0.0 | 252.3 |
| FEATURE BUFFS | 0.7 | +2.9 | 0.0 | 0.0 | 0.7 | +21.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +18.7 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 105.3 | +6562.4 | 585.7 | 463.0 | 95.3 | +5183.6 | 82.3 | 934.3 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 171.7 |
| FOCUS FIRE | 0.3 | +18.6 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +28.5 | 0.0 | 0.0 | 0.3 | +132.6 | 0.0 | 38.7 |
| FOUR ROUNDS | 1.3 | +104.5 | 75.7 | 0.0 | 1.3 | +91.4 | 60.7 | 193.7 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 160.0 |
| FRIEND SHOOTS FIRST | 0.7 | -22.4 | 0.0 | 0.0 | 0.3 | -0.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -12.7 | 0.0 | 38.7 |
| GOAL WALK | 3.3 | +153.0 | 0.0 | 0.0 | 16.0 | +1514.6 | 0.0 | 83.3 |
| GUN FIGURES | 1.7 | +25.9 | 0.0 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 34.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 9.0 | +0.0 | 0.0 | 84.0 |
| HIS CHARGE BY HIS RUN | 12.7 | +0.0 | 0.0 | 21.7 | 15.7 | +0.0 | 0.0 | 304.3 |
| HIS CHARGE DENIED | 0.3 | +14.3 | 41.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 10.3 | +0.0 | 0.0 | 90.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 122.0 |
| HIS MOVE AND SHOT | 6.3 | -68.6 | 0.0 | 82.3 | 6.3 | -59.5 | 0.0 | 38.7 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 0.0 | 13.0 | +0.0 | 0.0 | 284.0 |
| HIS OWN BEST MOVE | 9.3 | +0.0 | 0.0 | 100.7 | 10.7 | +0.0 | 0.0 | 122.0 |
| HIS RANDOM MOVE | 29.0 | +0.0 | 0.0 | 241.7 | 15.0 | +0.0 | 0.0 | 269.3 |
| HIS RANDOM MOVER COMES | 3.7 | +0.0 | 0.0 | 43.3 | 4.3 | +0.0 | 0.0 | 192.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 33.3 | +571.5 | 0.0 | 171.3 | 57.3 | +1210.6 | 0.0 | 588.7 |
| HIS SHOTS BY HIS RUN | 35.3 | +449.7 | 0.0 | 166.3 | 48.7 | +563.9 | 0.0 | 474.7 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 26.0 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 15.3 | +995.2 | 0.0 | 0.0 | 7.7 | +507.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -55.5 | 75.7 | 0.0 | 0.7 | -30.2 | 60.7 | 155.0 |
| IDLE COST | 5.0 | -86.1 | 0.0 | 0.0 | 13.3 | -164.7 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +17.0 | 0.0 | 38.7 |
| KEPT FROM ITS LAST STOP | 4.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 14.0 | +0.0 | 462.7 | 40.7 | 5.7 | +0.0 | 21.7 | 571.7 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -3.6 | 0.0 | 21.7 | 1.7 | +159.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +7.4 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +28.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +14.5 | 0.0 | 0.0 | 0.7 | +31.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | -24.9 | 0.0 | 0.0 | 1.0 | +225.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +15.5 | 0.0 | 0.0 | 1.3 | +18.5 | 0.0 | 0.0 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +74.4 | 0.0 | 0.0 | 2.3 | +28.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +41.1 | 0.0 | 0.0 | 3.0 | +21.8 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -3.9 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.7 | +918.1 | 0.0 | 100.7 | 9.0 | +627.6 | 0.0 | 38.7 |
| NEARER NOT NEEDED | 11.0 | +373.1 | 0.0 | 20.0 | 7.3 | +340.2 | 0.0 | 48.0 |
| NEXT CHARGE BY LIST | 4.3 | +580.5 | 0.0 | 80.7 | 6.3 | +486.7 | 0.0 | 38.7 |
| NEXT OBJECTIVE NEARER | 0.3 | -0.1 | 0.0 | 0.0 | 0.7 | -1.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -75.4 | 75.7 | 0.0 | 1.0 | -37.4 | 20.0 | 193.7 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +7.7 | 0.0 | 0.0 |
| NOT WORTH A CAST | 4.7 | -4.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.7 | -183.2 | 0.0 | 62.3 | 7.7 | -196.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -91.5 | 0.0 | 0.0 | 8.3 | -230.2 | 0.0 | 156.3 |
| ONE OBJECTIVE FORMULA | 8.3 | -110.4 | 0.0 | 0.0 | 3.0 | -21.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -20.3 | 0.0 | 40.7 | 1.3 | +5.7 | 0.0 | 38.7 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +5.0 | 20.0 | 155.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +0.3 | 40.7 | 0.0 |
| PATHS CROSS | 0.3 | +4.4 | 0.0 | 0.0 | 0.3 | +8.4 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 49.3 | +248.4 | 109.7 | 473.0 | 44.3 | +111.5 | 43.3 | 842.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.3 | -370.5 | 0.0 | 20.0 | 14.7 | -537.7 | 0.0 | 38.7 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -22.4 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 30.0 | +2794.5 | 354.0 | 118.3 | 27.7 | +2485.9 | 0.0 | 332.0 |
| RANDOM MOVE BY FIGURES | 4.0 | +152.6 | 0.0 | 285.0 | 4.7 | +26.4 | 0.0 | 0.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.0 | +309.3 | 0.0 | 60.7 | 0.7 | +17.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 60.7 | - | - | - | - |
| REFORMS TO MEET IT | 1.7 | -82.5 | 0.0 | 0.0 | 0.3 | -5.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +21.1 | 0.0 | 0.0 | 0.7 | +13.8 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | -2.7 | 34.0 | 0.0 | 1.3 | +9.0 | 60.7 | 193.7 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | 0.7 | -3.3 | 41.7 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.7 | -8.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 0.7 | +0.3 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.0 | -79.4 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 3.3 | +43.4 | 0.0 | 0.0 | 0.7 | +8.7 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +18.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 21.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +45.7 | 84.0 | 0.0 | 2.3 | +30.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.6 | 34.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 16.7 | -250.8 | 0.0 | 41.7 | 25.7 | -377.9 | 0.0 | 237.3 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +294.0 | 0.0 | 84.0 | 9.0 | +169.5 | 0.0 | 76.0 |
| SPELL WORTH | 1.3 | +15.4 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -19.1 | 0.0 | 38.7 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 68.3 | 10.3 | +0.0 | 0.0 | 205.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 41.3 | +0.0 | 510.0 | 188.3 | 34.3 | +0.0 | 21.7 | 260.0 |
| STAY WORTH | 11.0 | +91.2 | 0.0 | 0.0 | 9.3 | +30.5 | 21.7 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +57.7 | 0.0 | 70.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +3.8 | 40.7 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 10.0 | +1033.1 | 0.0 | 21.7 | 5.7 | +251.5 | 0.0 | 86.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 10.0 | +1033.1 | 0.0 | 21.7 | 5.7 | +251.5 | 0.0 | 86.7 |
| SURE REACH TOGETHER | - | - | - | - | 2.7 | +13.0 | 0.0 | 38.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 40.7 | 5.7 | +0.0 | 0.0 | 41.7 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 21.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 38.7 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 43.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 51.3 | +0.0 | 0.0 | 124.0 | 45.3 | +0.0 | 0.0 | 370.3 |
| TIED UP BY THE SUM | 1.3 | +183.8 | 75.7 | 0.0 | 0.3 | +32.2 | 20.0 | 155.0 |
| TIME ON OUR SIDE | 34.3 | +348.4 | 0.0 | 84.0 | 18.0 | +168.2 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 40.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.7 | +62.8 | 0.0 | 155.0 |
| WHOLE FIGHT DANGER | 4.3 | -449.8 | 0.0 | 43.3 | 5.3 | -654.5 | 0.0 | 301.7 |
| WOUNDS ON THE RANKS | 2.0 | +5.1 | 0.0 | 0.0 | 3.3 | +154.8 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p23

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 204 | 204 | 129 | 43.00 | +1020 | +7.9 |
| HOLDER ASSIGNMENT | 69 | 69 | 65 | 21.67 | +3903 | +60.0 |
| LEGAL CHARGES ONLY | 59 | 59 | 59 | 19.67 | +0 | +0.0 |
| HIS SHOT LIST | 272 | 244 | 47 | 15.67 | +769 | +16.4 |
| FIVE ACTION | 602 | 564 | 43 | 14.33 | +2588 | +60.2 |
| OFF BEST | 43 | 43 | 43 | 14.33 | -1139 | -26.5 |
| PROMISE BY ITS OWN SUM | 75 | 75 | 39 | 13.00 | -2725 | -69.9 |
| HIS SHOTS BY HIS RUN | 252 | 227 | 31 | 10.33 | +481 | +15.5 |
| MOVE TO CHARGE COMPUTED | 53 | 40 | 30 | 10.00 | +1726 | +57.5 |
| QUARTER ODDS | 173 | 167 | 29 | 9.67 | +1658 | +57.2 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 32 | 26 | 21 | 7.00 | +1759 | +83.8 |
| CHARGE LOSSES | 144 | 127 | 17 | 5.67 | +681 | +40.0 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 26 | 26 | 16 | 5.33 | +537 | +33.6 |
| GOAL WALK | 58 | 54 | 14 | 4.67 | +430 | +30.7 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| SHOT RISK POINTS | 127 | 109 | 11 | 3.67 | +147 | +13.3 |
| SUPPORT ADDS | 47 | 44 | 11 | 3.67 | +465 | +42.3 |
| SUPPORT WORKED OUT | 47 | 44 | 11 | 3.67 | +465 | +42.3 |
| TIME ON OUR SIDE | 157 | 136 | 11 | 3.67 | +50 | +4.6 |
| COVER ONCE | 65 | 45 | 10 | 3.33 | +132 | +13.2 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 9 | 3.00 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 14 | 14 | 8 | 2.67 | +658 | +82.2 |
| IDLE COST | 55 | 35 | 8 | 2.67 | +63 | +7.9 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 8 | 2.67 | +51 | +6.4 |
| FOUR ROUNDS | 8 | 8 | 7 | 2.33 | +190 | +27.2 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -44 | -8.8 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +178 | +35.5 |
| MANOEUVRE | 9 | 9 | 4 | 1.33 | +480 | +120.0 |
| SET UP BY THE SET | 12 | 12 | 4 | 1.33 | +35 | +8.6 |
| THE ROW IN ITS ORDER | 32 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +69 | +23.1 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +483 | +161.1 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| MISSILES IN THE MOVE | 16 | 11 | 3 | 1.00 | +62 | +20.7 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +105 | +35.0 |
| CAST JOB | 7 | 7 | 2 | 0.67 | +6 | +2.8 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -4 | -2.0 |
| EXACT ROUND | 6 | 6 | 2 | 0.67 | +33 | +16.5 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +85 | +42.4 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +51 | +25.6 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +86 | +42.9 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -2 | -0.9 |
| ONE OBJECTIVE FORMULA | 34 | 21 | 2 | 0.67 | +37 | +18.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +38 | +19.2 |
| REDIRECT COUNTER | 14 | 14 | 2 | 0.67 | +43 | +21.4 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +160 | +79.9 |
| WHOLE FIGHT DANGER | 29 | 29 | 2 | 0.67 | +109 | +54.4 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 2 | 2 | 1 | 0.33 | -11 | -11.2 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 76 | 59 | 1 | 0.33 | +8 | +7.9 |
| FIGHT TO THE END | 1 | 1 | 1 | 0.33 | +37 | +37.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +56 | +55.7 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +29 | +28.8 |
| NEARER NOT NEEDED | 55 | 54 | 1 | 0.33 | +7 | +6.7 |
| NEXT OBJECTIVE NEARER | 3 | 3 | 1 | 0.33 | +39 | +38.6 |
| ONE FIGHT FORMULA | 40 | 20 | 1 | 0.33 | +103 | +103.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -9 | -9.3 |
| RISK BY ARC | 7 | 7 | 1 | 0.33 | +1 | +0.6 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +1 | +1.0 |
| SHOTS IN THE MOVE | 76 | 54 | 1 | 0.33 | +61 | +61.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +173 | +173.2 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +11 | +11.3 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -2 | -1.7 |
| SURE REACH TOGETHER | 8 | 7 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -7 | -7.0 |
| WOUNDS ON THE RANKS | 16 | 16 | 1 | 0.33 | +87 | +86.8 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 58 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 38 | 36 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 27 | 25 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 85 | 78 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 55 | 52 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 27 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 38 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 57 | 53 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 60 | 51 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 132 | 123 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 24 | 24 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 115 | 114 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 6 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 19 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 7 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 7 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 23 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NO DOUBLE ROUNDS | 7 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 14 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 8 | 7 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 281 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 12 | 12 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 56 | 53 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 227 | 211 | 0 | 0.00 | - | - |
| STAY WORTH | 61 | 51 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 290 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 4 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p23

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 8.00 | 69.9 |
| JOB FIRST | gate | 5.33 | 6.00 | 28.0 |
| ARMY TABLE | rule | 2.00 | 4.67 | 77.8 |
| NO REASON | gate | - | 1.67 | 32.2 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.67 | 16.0 |
| ONE PROMISE A TARGET | rule | 0.33 | 0.67 | 37.6 |
| RULE SWITCHED OFF | gate | 1.00 | - | 8.0 |
| CHAFF PASSED | rule | - | 0.67 | 2.0 |
| AFTERMATH BAND | gate | 0.33 | - | 1.8 |
| CHARGE NOW FIRST | rule | 0.33 | - | 11.2 |
| FOLLOW UP WEIGHED | rule | 0.33 | - | 1.8 |
| MARCH OF THE TABLE | rule | - | 0.33 | 1.7 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 9.3 |
| SUPPORT NARROWED | rule | 0.33 | - | 1.7 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 7.0 |

### Plans: cnsr-c940641-p23

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 75% | 148 | 120 | 81% |
| Mine | join | 1.7 | 100% | 96 | 0 | 0% |
| Mine | move | 42.3 | 96% | 2332 | 0 | 0% |
| Mine | shoot | 3.7 | 55% | 235 | 128 | 54% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 1.3 | 50% | 121 | 112 | 92% |
| Opponent | join | 1.0 | 100% | 20 | 0 | 0% |
| Opponent | move | 40.7 | 98% | 2047 | 0 | 0% |
| Opponent | shoot | 1.3 | 0% | 48 | 0 | 0% |

### Battle groups: cnsr-c940641-p23

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.0 | 17% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p23

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 113 (5) | 0 | 113 | 19 | 40% | 1.3 | 139 (4) | 0 (1) | - | 139 (4) | 0 (1) |
| Mine | Character | 9 | 14 (9) | 14 | 0 | 0 | 33% | 3.2 | 13 (5) | 16 (4) | - | 22 (4) | 7 (5) |
| Mine | Clean-up | 2 | 23 (2) | 0 | 23 | 0 | 0% | 4.5 | - | 0 (1) | 41 (1) | 41 (1) | 0 (1) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 15 | 75% | 1.0 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 4 | 40 (4) | 40 | 0 | 75 | 0% | 1.5 | 74 (1) | 41 (2) | 0 (1) | 29 (3) | 74 (1) |
| Mine | Holder | 7 | 91 (7) | 54 | 38 | 0 | 71% | 3.5 | 85 (3) | 106 (3) | 0 (1) | 100 (6) | 0 (1) |
| Mine | Shooter | 5 | 110 (5) | 39 | 71 | 44 | 0% | 1.2 | 480 (1) | 50 (2) | 0 (2) | 143 (3) | 55 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 9 | 11 (9) | 11 | 0 | 23 | 22% | 3.6 | 3 (6) | 0 (2) | 54 (1) | 15 (6) | 5 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 27 (5) | 0 | 27 | 14 | 40% | 2.7 | 42 (3) | - | 0 (2) | 0 (2) | 49 (3) |
| Opponent | Hammer | 10 | 26 (10) | 26 | 0 | 15 | 30% | 2.9 | 35 (4) | 20 (5) | 0 (1) | 65 (4) | 0 (6) |
| Opponent | Holder | 4 | 6 (4) | 0 | 6 | 58 | 50% | 4.0 | 25 (1) | 0 (2) | - | - | 7 (3) |
| Opponent | Shooter | 3 | 16 (3) | 0 | 16 | 31 | 0% | 1.0 | 0 (1) | 27 (2) | - | - | 16 (3) |

### Charged fights: cnsr-c940641-p23

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 116 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 240 | 227 | 2.0 | 1.0 | 114 | 0 | +114 | 0 of 2 | 2 of 2 | - | +114 |
| Mine | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 3 | 119 | 76 | 1.0 | 1.0 | 76 | 0 | +76 | 0 of 3 | 3 of 3 | - | +76 |
| Opponent | Warriors of Chaos | 2 | 0 | 30 | 1.0 | 1.0 | 30 | 232 | -202 | 1 of 2 | 2 of 2 | - | -202 |
| Opponent | Wood Elf Realms | 1 | 0 | 122 | 1.0 | 1.0 | 122 | 0 | +122 | 0 of 1 | 0 of 1 | - | +122 |
| **Opponent** | all armies | 3 | 0 | 61 | 1.0 | 1.0 | 61 | 155 | -94 | 1 of 3 | 2 of 3 | - | -94 |

### Effective charges: cnsr-c940641-p23

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 2 | 0 | 0 | 0 | 0 | 2 (net +114) | 0 | 0 | 0% (0 of 2) |
| Mine | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 1 (net -405) | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 1 | 1 (net +122) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p23

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 161 | 170 | +0 | 142 | 0 | +142 | +88.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 421 | 114 | +114 | 124 | 46 | +78 | +18.6 |
| Mine | All fights | 3 | 334 | 132 | +76 | 130 | 30 | +99 | +29.7 |
| Opponent | Long shot (under 50%) | 1 | 102 | 72 | +122 | 122 | 0 | +122 | +119.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 116 | 440 | +0 | 165 | 0 | +165 | +142.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 365 | 60 | -405 | 89 | 465 | -376 | -102.9 |
| Opponent | All fights | 3 | 194 | 191 | -94 | 125 | 155 | -30 | -15.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p23 | move | 24 | 1 (4%) | 1 (4%) | 0 (0%) | 23 (96%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

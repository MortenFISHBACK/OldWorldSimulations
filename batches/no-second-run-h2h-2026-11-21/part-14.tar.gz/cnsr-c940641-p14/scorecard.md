# Doctrine scorecard: cnsr-c940641-p14

### Scorecard: cnsr-c940641-p14

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 3 | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 6 | - | 0 | 2 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | no | 20 | 6 | 2 | 3 | 0 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 450 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 3 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 4.5 | 2.0 | 1.0 | 2.7 | 0.0 | 0.0 | 0.0 | 346.7 |
| **Average** | | | Opponent | 33% | 10.0 | 4.0 | 3.0 | 2.3 | 0.0 | 0.0 | 0.0 | 125.0 |

### KPIs: cnsr-c940641-p14

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 38% (5 of 13) | 0% (0 of 15) | 18% (5 of 28) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 100% | 100% (2 of 2); on the table 100% | 83% (5 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 100% | 100% (3 of 3); on the table 100% | 86% (6 of 7); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 19% (7 of 36) | 50% (3 of 6) | 24% (10 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 22% (7 of 32) | 60% (3 of 5) | 27% (10 of 37) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (1 of 3) | - | 33% (1 of 3) |
| Points that never fought | lower | 59% (3483 of 5897) | 67% (4006 of 5999) | 63% (7489 of 11896) |
|   infantry points that never fought | lower | 69% (993 of 1437) | 94% (883 of 938) | 79% (1876 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 45% (9 of 20) | 57% (24 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 0.0 uses a game | 100% (2 of 2); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (2 of 4); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (2747 of 4484) | 38% (1753 of 4648) | 49% (4500 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.3 (66%) | 0.0 (0%) | 6.3 (59%) |
| MARCHED: its unit marched | 1.7 (17%) | 0.7 (67%) | 2.3 (22%) |
| IN COMBAT: engaged in combat | 0.7 (7%) | 0.3 (33%) | 1.0 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 2.0 | 3.3 | 0.0 | 0.0 |
| not cast | 0.0 | 2.0 | 10.7 | 2.0 | 8.0 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 6.3 (59%) | 1.0 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 2.3 (22%) | 0.7 (33%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.7 (33%) | 1.0 (9%) | 0.3 (17%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | - | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 0.3 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.3 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.7 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 17% (1 of 6) | - | 17% (1 of 6) |
| the unit moved after it | 0% (0 of 1) | - | 0% (0 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 100% (1 of 1) | - | 100% (1 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 0% (0 of 1) | - | 0% (0 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 82% (47 of 57) | 72% (74 of 103) | 76% (121 of 160) |
|   cavalry | - | 100% (11 of 11) | 100% (11 of 11) |
|   character | - | 0% (0 of 16) | 0% (0 of 16) |
|   chariot | 68% (15 of 22) | 100% (2 of 2) | 71% (17 of 24) |
|   infantry | - | 81% (50 of 62) | 81% (50 of 62) |
|   war machine | 91% (32 of 35) | 92% (11 of 12) | 91% (43 of 47) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (20%) | 0.7 (7%) | 1.3 (10%) |
| CHARGED: it charged | 0.3 (10%) | 1.3 (14%) | 1.7 (13%) |
| IN COMBAT: it fought this turn or the last | 0.7 (20%) | 0.3 (3%) | 1.0 (8%) |
| MOVED: a war machine that moved | 0.3 (10%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 0.3 (10%) | 4.3 (45%) | 4.7 (36%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (20%) | 2.0 (21%) | 2.7 (21%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (7%) | 0.7 (5%) |
| OTHER BAR | 0.3 (10%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 0.7 | 88% | 0.6 pts | 3 pts |
| chariot | 5.7 | 6.0 | 41% | 29.6 pts | 168 pts |
| infantry | 19.0 | 7.7 | 70% | 6.9 pts | 131 pts |
| war machine | 14.3 | 19.3 | 70% | 50.1 pts | 718 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.0 | 2.5 |
| Charges that made contact a game | 2.0 | 1.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 1.00 declared, 1.00 contact (1 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.30 contact (20 units) | 0.27 declared, 0.13 contact (30 units) | 0.28 declared, 0.20 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character in a unit | 80% (4 of 5) | 50% (1 of 2) | - | 71% (5 of 7) |
| Character on its own | 100% (1 of 1) | - | 20% (1 of 5) | 33% (2 of 6) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 67% (6 of 9) | 100% (2 of 2) | - | 73% (8 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 50% (1 of 2); on the table 100% | 33% (4 of 12) | 18% | 50% (3 of 6) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (2 of 2); on the table 100% | 12% (3 of 24) | 79% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Empire of Man | 1 | - | 50% (3 of 6) | 81% | 60% (6 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (3 of 3); on the table 100% | - | 60% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p14, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | - | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnsr-c940641-p14

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (6 of 6) | 12% (1 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (23 of 46) | 49% (18 of 37) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 71% (5 of 7) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 5) | 57% (4 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 2.3 |
| Movement | Points that never moved of their own | 346.7 | 125.0 |
| Movement | Fights charged into per game | 1.7 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 2 of 2, net -60 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +122 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +66 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net +22 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 23.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (8 of 15) | 29% (20 of 69) |
| Shooting | Points destroyed by shooting units | 60.0 | 92.3 |
| Shooting | War machine shots | 10.7 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (7 of 32) | 36% (4 of 11) |
| Shooting | Points destroyed by war machines | 41.7 | 65.0 |
| Magic | Magic missiles cast | 1.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 67% (2 of 3) |
| Magic | Wounds caused by magic missiles | 2.3 | - |
| Magic | Points destroyed by magic (all spells) | 24.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 252.3 | 224.0 |
| Combat | Points run down | 0.0 | 28.3 |
| Combat | Net points per charged fight, damage counted | +27 | +19 |
| Combat | Net per 100 charger points, damage counted | +19.8 | +4.5 |
| Combat | First round won (charged fights) | 100% | 60% |
| Combat | Net points per charged fight | +51 | +61 |
| Combat | Net points per supported fight / lone fight | +0 / +64 | - / +61 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 2 of 5 |
| Game | Points lost | 628.3 | 361.3 |
| Game | VP from objectives | 496.7 | 916.7 |
| Game | Lone holders (player turns) | 4.5 | 10.0 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -611 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 990
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p14

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +138.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 14.3 | +34.1 | 0.0 | 90.3 | 31.7 | +722.6 | 0.0 | 244.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 76.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 1.0 | -72.7 | 102.3 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +10.2 | 0.0 | 430.0 | 3.7 | +125.1 | 73.3 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CAST JOB | 3.3 | +52.3 | 0.0 | 113.3 | 0.7 | +8.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.3 | +101.8 | 96.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +24.2 | 0.0 | 20.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.4 | 56.7 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 20.0 | -449.7 | 0.0 | 280.7 | 19.7 | -366.7 | 0.0 | 70.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 92.0 | 17.3 | 1.3 | +0.0 | 59.7 | 143.7 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 84.0 | 12.3 | +0.0 | 0.0 | 87.3 |
| COMBAT PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 143.7 |
| CONVEYANCE SEARCH | 1.3 | +95.9 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 13.0 | -1090.5 | 0.0 | 142.3 | 3.0 | -70.6 | 0.0 | 23.3 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 41.7 |
| EDGE GIVE GROUND | 0.3 | +6.1 | 0.0 | 0.0 | 0.7 | +0.4 | 56.0 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.7 | +1.5 | 110.7 | 17.3 | 3.0 | +9.9 | 296.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 132.7 | 17.3 | 2.3 | +9.9 | 212.3 | 143.7 |
| FALLS SHORT | 6.3 | +150.1 | 0.0 | 111.7 | 15.7 | +128.3 | 0.0 | 89.3 |
| FEATURE BUFFS | 6.3 | +139.9 | 0.0 | 175.3 | 3.0 | +65.1 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 1.0 | +61.9 | 135.0 | 143.7 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 28.3 | 24.0 |
| FIVE ACTION | 89.3 | +3312.8 | 412.0 | 1626.3 | 109.0 | +8626.7 | 1420.0 | 663.7 |
| FLANK NOT WEIGHED | 11.0 | +0.0 | 0.0 | 160.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +136.9 | 0.0 | 103.3 | 1.0 | +171.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +35.9 | 132.7 | 17.3 | 3.3 | +246.0 | 296.7 | 143.7 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 55.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.7 | -102.6 | 0.0 | 74.0 | 1.7 | -36.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -5.2 | 77.0 | 0.0 |
| GOAL WALK | 12.3 | +733.3 | 0.0 | 34.7 | 20.0 | +2250.7 | 0.0 | 70.0 |
| GUN FIGURES | 2.7 | +36.3 | 60.0 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 2.7 | +42.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 22.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 55.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 17.0 | +0.0 | 0.0 | 280.7 | 2.3 | +0.0 | 0.0 | 23.3 |
| HIS CHARGE LIST | 8.0 | +0.0 | 0.0 | 140.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 129.3 |
| HIS MOVE AND SHOT | 2.3 | -12.4 | 0.0 | 17.3 | 3.7 | -131.2 | 0.0 | 45.3 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 73.3 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 108.7 | 10.3 | +0.0 | 0.0 | 129.3 |
| HIS RANDOM MOVE | - | - | - | - | 8.0 | +0.0 | 0.0 | 48.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 45.7 | +1243.8 | 0.0 | 410.0 | 59.0 | +1928.9 | 0.0 | 472.0 |
| HIS SHOTS BY HIS RUN | 42.3 | +653.2 | 0.0 | 459.3 | 48.0 | +1157.7 | 0.0 | 430.7 |
| HIS TURN DENIED | 0.3 | +1.4 | 24.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 126.7 | 27.3 | +0.0 | 0.0 | 136.0 |
| HOLDER ASSIGNMENT | 8.3 | +781.0 | 0.0 | 87.7 | 16.7 | +1388.5 | 0.0 | 46.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -21.5 | 132.7 | 17.3 | 3.3 | -87.6 | 296.7 | 143.7 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +4.9 | 0.0 | 0.0 |
| IDLE COST | 7.7 | -71.9 | 0.0 | 80.3 | 14.0 | -209.8 | 0.0 | 68.7 |
| JOINT CHARGE NOW | 0.3 | -20.1 | 24.0 | 0.0 | 0.7 | -11.4 | 59.7 | 0.0 |
| KEEP FALLS | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 167.7 | 103.3 | 13.3 | +0.0 | 569.0 | 324.0 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.6 | 22.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | -0.1 | 40.7 | 0.0 | 2.0 | +2.7 | 147.7 | 143.7 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +2.4 | 0.0 | 0.0 |
| MANOEUVRE | 3.3 | +0.8 | 0.0 | 34.7 | 2.3 | -18.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.8 | 0.0 | 0.0 | 0.3 | +22.6 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +47.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +85.2 | 0.0 | 28.3 | 0.7 | -17.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +35.9 | 0.0 | 95.0 | 2.7 | +33.7 | 0.0 | 64.7 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +91.1 | 0.0 | 56.7 | 1.0 | +12.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.0 | +82.4 | 0.0 | 85.0 | 1.7 | +41.0 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.3 | -11.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 10.0 | 0.0 | 1.7 | +0.0 | 24.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -11.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.0 | +313.5 | 0.0 | 108.7 | 6.7 | +258.7 | 0.0 | 81.3 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.7 | +341.7 | 0.0 | 87.7 | 12.0 | +479.1 | 0.0 | 22.0 |
| NEXT CHARGE BY LIST | 4.3 | +162.4 | 0.0 | 34.7 | 5.3 | +198.9 | 0.0 | 40.7 |
| NO DOUBLE ROUNDS | 1.3 | -9.9 | 110.7 | 17.3 | 3.0 | -58.9 | 265.0 | 143.7 |
| NO LATE CUT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 10.0 | - | - | - | - |
| OFF BEST | 3.0 | -89.2 | 0.0 | 244.0 | 10.7 | -466.9 | 0.0 | 64.0 |
| OGRE LOADER SECOND SHOT | 1.7 | +0.5 | 0.0 | 76.7 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.0 | -16.3 | 0.0 | 97.7 | 7.3 | -146.2 | 0.0 | 64.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +5.3 | 135.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +20.7 | 0.0 | 31.7 | 7.0 | +196.3 | 0.0 | 46.0 |
| ONE PROMISE A TARGET | 0.7 | +2.5 | 0.0 | 0.0 | 0.7 | +1.5 | 0.0 | 40.7 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.7 | +61.7 | 109.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +26.1 | 22.0 | 0.0 | 1.0 | +30.0 | 87.7 | 0.0 |
| PLAN RESULT | 41.0 | +420.7 | 179.3 | 929.7 | 48.0 | +502.1 | 479.0 | 586.0 |
| PROMISE BY ITS OWN SUM | 6.0 | -61.4 | 0.0 | 0.0 | 11.3 | -247.9 | 0.0 | 40.7 |
| PROMISE IN STEPS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.3 | -6.4 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.0 | -54.7 | 0.0 | 74.0 | 0.3 | -9.8 | 0.0 | 0.0 |
| QUARTER ODDS | 14.3 | +784.9 | 0.0 | 328.3 | 20.3 | +2408.6 | 181.7 | 117.3 |
| RANDOM MOVE BY FIGURES | 1.0 | +0.0 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.7 | +67.9 | 0.0 | 76.7 | 2.0 | +68.6 | 0.0 | 110.7 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 84.3 | 3.7 | +0.0 | 0.0 | 176.7 |
| REDIRECT WEIGHED | - | - | - | - | 1.3 | -43.6 | 92.3 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -2.7 | 0.0 | 0.0 | 1.3 | -3.4 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +21.2 | 0.0 | 47.3 |
| RESERVE MOVE SPELL | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +6.7 | 132.7 | 17.3 | 1.7 | +3.9 | 119.3 | 143.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -15.6 | 119.3 | 143.7 |
| RUN DOWN | - | - | - | - | 2.0 | -11.2 | 136.7 | 143.7 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.7 | -239.0 | 0.0 | 30.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +32.1 | 0.0 | 17.3 | 0.7 | +0.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +15.7 | 17.3 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -7.0 | 0.0 | 24.0 |
| SET UP BY THE SET | 1.3 | -4.0 | 0.0 | 0.0 | 1.3 | +15.1 | 0.0 | 24.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +4.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.3 | -0.1 | 0.0 | 10.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.7 | +0.0 | 0.0 | 543.3 | 12.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +162.7 | 0.0 | 85.0 | 3.0 | +77.7 | 128.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -8.5 | 206.7 | 0.0 |
| SHOT RISK POINTS | 26.3 | -226.2 | 0.0 | 266.7 | 33.0 | -83.4 | 0.0 | 472.0 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +636.2 | 0.0 | 430.0 | 26.0 | +412.2 | 0.0 | 176.7 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 192.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 1.3 | -2.4 | 86.7 | 0.0 | 0.3 | -3.4 | 103.3 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 88.0 |
| STANDS STILL | 48.0 | +0.0 | 279.3 | 1291.0 | 46.0 | +0.0 | 1123.3 | 159.3 |
| STAY WORTH | 23.3 | -460.4 | 48.0 | 680.0 | 40.7 | +350.4 | 904.7 | 106.7 |
| STRIKE BY THE ODDS | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| SUPPORT ADDS | 4.0 | +538.2 | 0.0 | 66.7 | 5.3 | +95.9 | 0.0 | 23.3 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.0 | +538.2 | 0.0 | 66.7 | 5.3 | +95.9 | 0.0 | 23.3 |
| SURE REACH TOGETHER | - | - | - | - | 2.7 | +9.4 | 0.0 | 40.7 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 22.0 |
| THE PROMISE ADDS | 0.7 | -41.3 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 17.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 17.3 | - | - | - | - |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 34.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.3 | +0.0 | 0.0 | 767.0 | 52.7 | +0.0 | 0.0 | 260.0 |
| TIED UP BY THE SUM | 1.0 | +37.2 | 70.0 | 17.3 | 1.7 | +126.5 | 105.0 | 0.0 |
| TIME ON OUR SIDE | 22.0 | +295.9 | 0.0 | 60.0 | 19.7 | +215.4 | 0.0 | 88.7 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 81.3 |
| WAR ENGINE JOBS | 2.7 | +0.0 | 36.7 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +0.8 | 64.7 | 0.0 | 0.7 | -2.1 | 63.3 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.3 | -10.7 | 28.0 | 0.0 |
| WHO HITS BACK | 0.7 | +12.8 | 0.0 | 0.0 | 0.3 | +5.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -216.8 | 0.0 | 154.7 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +4.1 | 31.7 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +103.6 | 0.0 | 0.0 | 0.7 | +21.2 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p14

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 138 | 138 | 108 | 36.00 | +2440 | +22.6 |
| HIS SHOT LIST | 314 | 307 | 73 | 24.33 | +1303 | +17.9 |
| HOLDER ASSIGNMENT | 75 | 75 | 71 | 23.67 | +3994 | +56.3 |
| HIS SHOTS BY HIS RUN | 271 | 265 | 61 | 20.33 | +520 | +8.5 |
| LEGAL CHARGES ONLY | 45 | 45 | 45 | 15.00 | +0 | +0.0 |
| FIVE ACTION | 595 | 582 | 43 | 14.33 | +1414 | +32.9 |
| OFF BEST | 41 | 41 | 41 | 13.67 | -1669 | -40.7 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| MOVE TO CHARGE COMPUTED | 44 | 41 | 31 | 10.33 | +461 | +14.9 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 29 | 29 | 23 | 7.67 | +348 | +15.1 |
| GOAL WALK | 97 | 95 | 22 | 7.33 | +1464 | +66.5 |
| SHOT RISK POINTS | 178 | 172 | 21 | 7.00 | +427 | +20.3 |
| TIME ON OUR SIDE | 125 | 104 | 21 | 7.00 | +85 | +4.0 |
| PROMISE BY ITS OWN SUM | 52 | 52 | 18 | 6.00 | -928 | -51.6 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 22 | 22 | 10 | 3.33 | +154 | +15.4 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| STAY WORTH | 192 | 171 | 8 | 2.67 | +16 | +1.9 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 26 | 26 | 7 | 2.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +924 | +154.0 |
| FOUR ROUNDS | 16 | 15 | 6 | 2.00 | +392 | +65.3 |
| MAX FOR POSITIONING | 18 | 14 | 6 | 2.00 | +13 | +2.2 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| QUARTER ODDS | 104 | 104 | 6 | 2.00 | +483 | +80.5 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 8 | 7 | 6 | 2.00 | +177 | +29.6 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +1 | +0.3 |
| SUPPORT ADDS | 28 | 28 | 5 | 1.67 | +431 | +86.2 |
| SUPPORT WORKED OUT | 28 | 28 | 5 | 1.67 | +431 | +86.2 |
| CAST JOB | 12 | 12 | 4 | 1.33 | +1 | +0.2 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +70 | +17.5 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +1 | +0.1 |
| CHARGE LOSSES | 119 | 114 | 4 | 1.33 | +191 | +47.6 |
| COVER ONCE | 48 | 34 | 4 | 1.33 | +190 | +47.6 |
| IDLE COST | 65 | 36 | 4 | 1.33 | +52 | +12.9 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | +12 | +2.9 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 4 | 1.33 | -19 | -4.8 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +246 | +61.5 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +64 | +15.9 |
| SHOTS IN THE MOVE | 128 | 93 | 4 | 1.33 | +220 | +54.9 |
| BEST PRIZE | 3 | 3 | 3 | 1.00 | -218 | -72.7 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 66 | 51 | 3 | 1.00 | +71 | +23.8 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -95 | -31.6 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +72 | +23.9 |
| OPENS UP | 5 | 4 | 3 | 1.00 | +49 | +16.3 |
| OVERRUNS AWAY | 5 | 5 | 3 | 1.00 | +70 | +23.2 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +98 | +32.5 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +53 | +17.8 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 8 | 8 | 2 | 0.67 | +91 | +45.3 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +80 | +39.8 |
| MANOEUVRE | 17 | 17 | 2 | 0.67 | +9 | +4.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +79 | +39.6 |
| MISSILES IN THE MOVE | 14 | 8 | 2 | 0.67 | +4 | +2.1 |
| NEARER NOT NEEDED | 56 | 53 | 2 | 0.67 | +67 | +33.4 |
| ONE FIGHT FORMULA | 34 | 23 | 2 | 0.67 | +2 | +1.1 |
| RISK BY ARC | 11 | 11 | 2 | 0.67 | +14 | +7.2 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +47 | +23.6 |
| THE ROW IN ITS ORDER | 18 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 6 | 6 | 2 | 0.67 | +20 | +9.9 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +416 | +415.7 |
| CANNON PLANNED TARGET | 35 | 35 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +35 | +35.4 |
| CHARGE NOW FIRST | 8 | 8 | 1 | 0.33 | -55 | -55.2 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +9 | +8.8 |
| HONEST WORTH | 16 | 15 | 1 | 0.33 | +8 | +8.2 |
| MISSILES NEXT TURN | 26 | 18 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE OBJECTIVE FORMULA | 34 | 25 | 1 | 0.33 | +23 | +23.3 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | -23 | -22.8 |
| RANDOM MOVE BY FIGURES | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 14 | 11 | 1 | 0.33 | +16 | +16.1 |
| RESERVE MOVE SPELL | 1 | 1 | 1 | 0.33 | +22 | +22.0 |
| ROUNDS AFTER TERROR | 5 | 5 | 1 | 0.33 | +38 | +37.6 |
| SET CREDITED ONCE | 2 | 2 | 1 | 0.33 | +3 | +3.4 |
| SET UP BY THE SET | 8 | 8 | 1 | 0.33 | +145 | +145.2 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 8 | 5 | 1 | 0.33 | +3 | +3.0 |
| WAR ENGINE JOBS | 8 | 8 | 1 | 0.33 | -10 | -10.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -32 | -32.0 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +3 | +3.2 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 68 | 66 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| EXACT ROUND | 14 | 13 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 28 | 28 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 38 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 13 | 13 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 58 | 56 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 30 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 24 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 60 | 55 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 24 | 22 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 131 | 130 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 14 | 13 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 13 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 267 | trace | - | - | - | - |
| PROMISE IN STEPS | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 9 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 82 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 38 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 22 | 22 | 0 | 0.00 | - | - |
| STANDS STILL | 282 | 276 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 8 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 279 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p14

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 10.33 | 41.0 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 4.33 | 51.6 |
| ARMY TABLE | rule | 1.00 | 2.67 | 46.2 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 4.8 |
| BEST PRIZE | rule | - | 1.00 | 72.7 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 31.6 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 11.3 |
| REDIRECT WEIGHED | rule | - | 0.67 | 52.7 |
| AFTERMATH BAND | gate | 0.33 | - | 2.8 |
| CHAFF PASSED | rule | - | 0.33 | 1.1 |
| CHARGE NOW FIRST | rule | - | 0.33 | 55.2 |
| NO REASON | gate | - | 0.33 | 68.5 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 22.8 |
| WAR ENGINE JOBS | rule | 0.33 | - | 10.0 |
| WHO GETS IN | rule | - | 0.33 | 32.0 |

### Plans: cnsr-c940641-p14

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 100% | 44 | 116 | 261% |
| Mine | move | 25.7 | 92% | 1148 | 0 | 0% |
| Mine | shoot | 12.7 | 42% | 250 | 305 | 122% |
| Mine | support | 1.0 | 67% | 0 | 0 | 0% |
| Opponent | charge | 2.7 | 62% | 302 | 164 | 54% |
| Opponent | move | 35.3 | 93% | 2710 | 0 | 0% |
| Opponent | shoot | 10.0 | 47% | 563 | 338 | 60% |

### Battle groups: cnsr-c940641-p14

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.0 | 50% | 100% | 33% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p14

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 47 (7) | 47 | 0 | 0 | 43% | 3.0 | 0 (1) | 0 (1) | 57 (5) | 52 (6) | 0 (1) |
| Mine | Clean-up | 4 | 18 (4) | 18 | 0 | 26 | 75% | 5.0 | 0 (1) | 23 (3) | - | 0 (3) | 73 (1) |
| Mine | Fast Hammer | 5 | 22 (5) | 22 | 0 | 74 | 40% | 3.3 | - | 46 (3) | 0 (2) | 26 (4) | 0 (1) |
| Mine | Hammer | 9 | 38 (9) | 15 | 23 | 20 | 22% | 2.3 | 0 (1) | 12 (4) | 79 (4) | 51 (7) | 0 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 11 (8) | 11 | 0 | 59 | 0% | 1.0 | 0 (2) | 20 (5) | 0 (1) | 0 (3) | 17 (5) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 59 | 40% | 4.3 | 0 (1) | 0 (2) | 0 (2) | 0 (2) | 0 (3) |
| Opponent | Chaff | 5 | 9 (5) | 0 | 9 | 114 | 0% | 1.0 | 0 (1) | 11 (4) | - | 9 (5) | - |
| Opponent | Character | 8 | 31 (8) | 31 | 0 | 18 | 38% | 2.6 | 34 (3) | 53 (2) | 4 (3) | 38 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 68 (4) | 0 | 68 | 37 | 100% | - | 0 (2) | 0 (1) | 139 (1) | 79 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 15 (6) | 15 | 0 | 0 | 100% | - | 15 (3) | 14 (3) | - | 0 (2) | 22 (4) |
| Opponent | Holder | 9 | 129 (9) | 5 | 123 | 0 | 0% | 2.1 | 0 (2) | 182 (4) | 132 (3) | 284 (4) | 0 (5) |
| Opponent | Shooter | 2 | 103 (2) | 70 | 34 | 0 | 0% | 1.5 | 59 (1) | 151 (1) | - | 59 (1) | 151 (1) |
| Opponent | War machine | 3 | 52 (3) | 52 | 0 | 33 | 33% | 1.0 | 52 (3) | - | - | 34 (2) | 88 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: cnsr-c940641-p14

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 72 | 122 | 3.0 | 1.3 | 41 | 0 | +41 | 0 of 3 | 3 of 3 | +0 | +61 |
| Mine | Chaos Dwarfs | 2 | 152 | 66 | 1.0 | 1.0 | 66 | 0 | +66 | 0 of 2 | 2 of 2 | - | +66 |
| **Mine** | all armies | 3 | 126 | 85 | 1.7 | 1.2 | 51 | 0 | +51 | 0 of 5 | 5 of 5 | +0 | +64 |
| Opponent | Empire of Man | 1 | 195 | 225 | 1.0 | 1.0 | 225 | 0 | +225 | 0 of 1 | 1 of 1 | - | +225 |
| Opponent | Tomb Kings of Khemri | 2 | 138 | 292 | 2.0 | 1.0 | 146 | 126 | +20 | 2 of 4 | 2 of 4 | - | +20 |
| **Opponent** | all armies | 3 | 157 | 270 | 1.7 | 1.0 | 162 | 101 | +61 | 2 of 5 | 3 of 5 | - | +61 |

### Effective charges: cnsr-c940641-p14

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 1 (net +122) | 0 | 0 | 2 (net +0) | 0 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 1 (net +66) | 1 (net +66) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 4 | 2 (net -60) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 2) |

### Charged fights, damage counted: cnsr-c940641-p14

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 81 | 72 | +122 | 122 | 12 | +110 | +136.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 93 | 64 | +22 | 33 | 47 | -14 | -15.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 66 | +66 | 66 | 0 | +66 | +21.3 |
| Mine | All fights | 5 | 134 | 66 | +51 | 57 | 31 | +27 | +19.8 |
| Opponent | Long shot (under 50%) | 2 | 436 | 291 | -60 | 244 | 411 | -167 | -38.3 |
| Opponent | No odds | 3 | 407 | 121 | +142 | 166 | 24 | +142 | +34.9 |
| Opponent | All fights | 5 | 419 | 189 | +61 | 198 | 179 | +19 | +4.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p14 | move | 22 | 3 (14%) | 3 (14%) | 0 (0%) | 19 (86%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: cnsr-c940641-p1

### Scorecard: cnsr-c940641-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 7 | 2 | 0 | 5 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 5 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 4 | 5 | 1 | 7 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 3.3 | - | 0.0 | 1.7 | 0.0 | 0.0 | 0.0 | 18.3 |
| **Average** | | | Opponent | 0% | 3.7 | 3.5 | 1.0 | 5.7 | 0.0 | 0.0 | 0.0 | 131.3 |

### KPIs: cnsr-c940641-p1

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 3) | 0% (0 of 13) | 0% (0 of 16) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 39% (35 of 90) | 42% (10 of 24) | 39% (45 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (35 of 84) | 42% (10 of 24) | 42% (45 of 108) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (4 of 6) | 67% (4 of 6) |
| Points that never fought | lower | 69% (3942 of 5700) | 94% (5520 of 5899) | 82% (9462 of 11599) |
|   infantry points that never fought | lower | 72% (1944 of 2703) | 100% (1219 of 1219) | 81% (3163 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 27% (4 of 15) | 84% (21 of 25) | 62% (25 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.3 uses a game | 75% (3 of 4); 2.3 uses a game | 86% (6 of 7); 3.3 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 0.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 27% (1117 of 4077) | 76% (3698 of 4883) | 54% (4815 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 13.7 (75%) | 3.7 (79%) | 17.3 (75%) |
| MARCHED: its unit marched | 1.7 (9%) | 1.0 (21%) | 2.7 (12%) |
| IN COMBAT: engaged in combat | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 1.3 (7%) | 0.0 (0%) | 1.3 (6%) |
| STUPIDITY: Stupidity | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 10.0 | 2.3 | 10.7 | 15.0 | 1.0 |
| not cast | 8.0 | 7.7 | 5.3 | 23.0 | 43.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.3 (57%) | 1.0 (19%) | 17.3 (75%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (6%) | 0.7 (3%) | 0.0 (0%) |
| GONE: slain | 0.7 (8%) | 0.3 (4%) | 0.3 (6%) | 1.3 (6%) | 2.0 (5%) |
| STUPIDITY: Stupidity | 0.3 (4%) | 0.0 (0%) | 0.7 (12%) | 0.7 (3%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 7.0 (88%) | 2.7 (35%) | 3.0 (56%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 39.3 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.7 a game | 2.7 a game | 5.7 a game |
| stood (cast and not dispelled) | 62% (16 of 26) | 62% (5 of 8) | 62% (21 of 34) |
| the unit moved after it | 75% (12 of 16) | 20% (1 of 5) | 62% (13 of 21) |
| it charged on its next turn | 0% (0 of 16) | 0% (0 of 5) | 0% (0 of 21) |
| the enemy charged it first | 6% (1 of 16) | 0% (0 of 5) | 5% (1 of 21) |
| it fought by the end of its next turn | 0% (0 of 16) | 0% (0 of 5) | 0% (0 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 16) | 0% (0 of 5) | 0% (0 of 21) |
| none of these (no charge, no fight, no charge escaped) | 94% (15 of 16) | 100% (5 of 5) | 95% (20 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (20 of 33) | 50% (30 of 60) | 54% (50 of 93) |
|   cavalry | - | 73% (8 of 11) | 73% (8 of 11) |
|   character | - | 73% (8 of 11) | 73% (8 of 11) |
|   chariot | - | 50% (1 of 2) | 50% (1 of 2) |
|   infantry | 61% (20 of 33) | 25% (6 of 24) | 46% (26 of 57) |
|   monster | - | 58% (7 of 12) | 58% (7 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (77%) | 2.0 (20%) | 5.3 (37%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| FLEEING: it fled or was fleeing | 0.3 (8%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.7 (15%) | 6.7 (67%) | 7.3 (51%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.0 (10%) | 1.0 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 1.0 | 93% | 1.7 pts | 8 pts |
| character | 2.7 | 1.3 | 50% | 4.3 pts | 12 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 8.7 | 3.0 | 81% | 2.9 pts | 25 pts |
| monster | 2.3 | 2.0 | 57% | 6.9 pts | 16 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 1.3 | 0.7 |
| Charges that made contact a game | 0.0 | 1.0 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (15 units) | 0.12 declared, 0.09 contact (32 units) | 0.09 declared, 0.06 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | - | - | 100% (3 of 3) |
| Character in a unit | 67% (2 of 3) | 56% (5 of 9) | - | 58% (7 of 12) |
| Character on its own | 50% (1 of 2) | 50% (1 of 2) | 0% (0 of 1) | 40% (2 of 5) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 14% (1 of 7) | - | 42% (5 of 12) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (3 of 3); on the table 100% | 40% (43 of 108) | 74% | 43% (9 of 21) | 100% (5 of 5); 4.8 uses a game | 67% (2 of 3); 0.5 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 94% | 100% (7 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 33% (2 of 6) | 100% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p1, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | - | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 18% (3 of 17) | 31% (4 of 13) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 36% (5 of 14) | 0% (0 of 7) |
| Strategy | Lone characters that fought | 25% (1 of 4) | 0% (0 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 5.7 |
| Movement | Points that never moved of their own | 18.3 | 131.3 |
| Movement | Fights charged into per game | 0.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 1, net +55 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.7 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (5 of 20) | 65% (20 of 31) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 9.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (12 of 29) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 25.7 | 4.3 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 333.0 | 18.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.3 / 1.0 / 1.0 / 0.0 | 2.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 11.3 | 43.3 |
| Combat | Points run down | 0.0 | 317.3 |
| Combat | Net points per charged fight, damage counted | - | +26 |
| Combat | Net per 100 charger points, damage counted | - | +37.8 |
| Combat | First round won (charged fights) | - | 33% |
| Combat | Net points per charged fight | - | +50 |
| Combat | Net points per supported fight / lone fight | - / - | - / +50 |
| Combat | Charged fights on a top-3 enemy unit | - | 2 of 3 |
| Game | Points lost | 369.0 | 442.7 |
| Game | VP from objectives | 830.0 | 766.7 |
| Game | Lone holders (player turns) | 3.3 | 3.7 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +155 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 812
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnsr-c940641-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 98.3 |
| ARMY TABLE | 11.7 | +74.7 | 0.0 | 36.7 | 28.0 | +247.7 | 0.0 | 112.3 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -79.5 | 124.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.0 | +9.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 4.3 | +464.9 | 167.3 | 0.0 | 1.3 | +12.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 5.0 | +0.0 | 0.0 | 236.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +18.3 | 0.0 | 18.3 | 0.7 | +16.0 | 0.0 | 20.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.3 | -323.0 | 0.0 | 415.3 | 12.3 | -438.7 | 0.0 | 238.7 |
| CHARGE NOW FIRST | - | - | - | - | 0.7 | +0.0 | 142.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 3.7 | +0.0 | 0.0 | 0.0 | 17.3 | +0.0 | 0.0 | 289.3 |
| CONVEYANCE SEARCH | 8.7 | +1186.2 | 248.0 | 236.7 | 2.7 | +83.0 | 0.0 | 0.0 |
| COVER ONCE | 2.7 | -216.4 | 0.0 | 248.0 | 5.0 | -184.4 | 0.0 | 30.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.7 | 124.0 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 198.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.7 | +17.2 | 0.0 | 42.0 |
| EXACT ROUND | - | - | - | - | 1.0 | +70.5 | 266.3 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 0.3 | +0.0 | 124.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 22.0 | +281.0 | 0.0 | 28.3 |
| FEATURE BUFFS | 14.7 | +637.3 | 0.0 | 306.3 | - | - | - | - |
| FIVE ACTION | 56.7 | +8289.3 | 405.0 | 667.7 | 97.3 | +2986.6 | 321.3 | 780.0 |
| FLANK NOT WEIGHED | 1.0 | +0.0 | 0.0 | 124.0 | 4.3 | +0.0 | 0.0 | 49.7 |
| FOUR ROUNDS | - | - | - | - | 1.0 | +48.0 | 266.3 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 4.7 | +622.0 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 0.3 | +0.0 | 0.0 | 61.7 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.0 | +0.0 | 0.0 | 415.3 | 5.3 | +0.0 | 0.0 | 83.3 |
| HIS CHARGE LIST | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -19.9 | 0.0 | 124.0 | 2.7 | -55.8 | 0.0 | 56.7 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 90.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 7.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 34.7 | +468.0 | 0.0 | 551.0 | 56.0 | +2694.2 | 0.0 | 392.0 |
| HIS SHOTS BY HIS RUN | 37.7 | +223.8 | 0.0 | 649.3 | 39.0 | +929.2 | 0.0 | 417.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +29.4 | 248.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 40.3 | +0.0 | 0.0 | 634.3 | 13.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 16.0 | +1937.8 | 0.0 | 145.7 | 9.3 | +901.2 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.0 | -37.2 | 266.3 | 0.0 |
| IDLE COST | - | - | - | - | 30.3 | -333.1 | 0.0 | 269.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +23.2 | 248.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.3 | +0.0 | 81.0 | 186.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 0.7 | +9.0 | 248.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +2.1 | 0.0 | 30.0 |
| MANOEUVRE | 1.7 | -28.4 | 0.0 | 124.0 | 1.0 | +58.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +14.8 | 0.0 | 0.0 | 0.3 | +12.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +17.8 | 0.0 | 18.3 | 1.0 | +3.8 | 0.0 | 28.3 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 198.0 |
| MISSILES IN THE MOVE | 9.0 | +662.7 | 0.0 | 248.0 | 6.0 | +84.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 9.0 | +518.3 | 0.0 | 248.0 | 6.3 | +57.3 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 3.7 | -198.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 18.3 | 0.0 | 2.0 | +0.0 | 0.0 | 11.3 |
| MOVE SPELL OUT OF RANGE | 2.0 | -180.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 4.0 | +180.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.3 | +278.9 | 0.0 | 0.0 | 3.0 | +166.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 3.0 | +157.2 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | - | - | - | - | 1.0 | -12.6 | 266.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.0 | -4.5 | 0.0 | 118.3 | 2.0 | -3.3 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -18.4 | 0.0 | 0.0 | 2.0 | -41.5 | 0.0 | 42.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -43.9 | 0.0 | 160.7 | 3.7 | -54.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.0 | +261.3 | 0.0 | 145.7 | 3.3 | -56.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -9.1 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +1.1 | 83.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +21.1 | 18.3 | 0.0 |
| PLAN RESULT | 24.3 | +156.0 | 42.0 | 346.3 | 43.3 | +246.5 | 18.3 | 398.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 3.3 | -9.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| QUARTER ODDS | 12.7 | +1448.9 | 210.0 | 0.0 | 18.0 | +1796.9 | 248.0 | 174.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +108.5 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +54.1 | 0.0 | 18.3 | 2.7 | +39.7 | 0.0 | 68.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 73.3 | 3.0 | +0.0 | 0.0 | 102.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.3 | -138.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +13.3 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 0.7 | +15.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.0 | -66.7 | 266.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -1.9 | 124.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.0 | -10.0 | 266.3 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -4.3 | 0.0 | 18.3 | 0.7 | -0.7 | 0.0 | 20.0 |
| SEARCH SPOT | 1.3 | +22.3 | 0.0 | 0.0 | 0.7 | +18.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +2.1 | 0.0 | 30.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +45.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.3 | 0.0 | 20.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 18.3 | 5.0 | +0.0 | 0.0 | 10.0 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +162.7 | 167.3 | 0.0 | 0.3 | +0.6 | 18.3 | 0.0 |
| SHOT RISK POINTS | 21.0 | -185.4 | 0.0 | 470.3 | 52.3 | +664.8 | 0.0 | 533.3 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 6.7 | +205.1 | 0.0 | 0.0 | 10.7 | +84.0 | 0.0 | 61.7 |
| SPELL SETS UP CHARGE | 1.0 | +267.2 | 0.0 | 0.0 | 0.3 | +45.9 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +17.8 | 28.3 | 118.3 | 2.0 | +4.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 306.3 | 3.3 | +0.0 | 0.0 | 69.7 |
| STANDS FOR A REASON | - | - | - | - | 13.0 | +0.0 | 55.0 | 0.0 |
| STANDS STILL | 19.7 | +0.0 | 405.0 | 73.3 | 31.7 | +0.0 | 55.0 | 42.0 |
| STAY WORTH | 7.7 | +58.2 | 28.3 | 0.0 | 15.0 | +62.2 | 36.7 | 103.7 |
| SUPPORT ADDS | 3.0 | +97.9 | 0.0 | 0.0 | 1.0 | +15.9 | 0.0 | 28.3 |
| SUPPORT WORKED OUT | 3.0 | +97.9 | 0.0 | 0.0 | 1.0 | +15.9 | 0.0 | 28.3 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +1.6 | 0.0 | 30.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 11.3 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | - | - | - | - | 3.3 | +0.0 | 28.3 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 64.3 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 124.0 | - | - | - | - |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 22.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 28.0 | +0.0 | 0.0 | 343.0 | 47.3 | +0.0 | 0.0 | 379.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +7.8 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 27.7 | +686.3 | 0.0 | 274.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | -60.5 | 248.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -122.4 | 0.0 | 167.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 10.7 | +225.4 | 0.0 | 372.0 | 1.0 | +66.7 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 272 | 270 | 90 | 30.00 | +1311 | +14.6 |
| HOLDER ASSIGNMENT | 76 | 76 | 68 | 22.67 | +3374 | +49.6 |
| ARMY TABLE | 119 | 119 | 67 | 22.33 | +346 | +5.2 |
| HIS SHOTS BY HIS RUN | 230 | 227 | 50 | 16.67 | +519 | +10.4 |
| SHOT RISK POINTS | 220 | 217 | 43 | 14.33 | +550 | +12.8 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| LEGAL CHARGES ONLY | 30 | 30 | 30 | 10.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| IDLE COST | 91 | 75 | 18 | 6.00 | +162 | +9.0 |
| CASTING BLOCK | 17 | 17 | 15 | 5.00 | +540 | +36.0 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| TIME ON OUR SIDE | 83 | 73 | 12 | 4.00 | +136 | +11.3 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| QUARTER ODDS | 92 | 91 | 10 | 3.33 | +648 | +64.8 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 35 | 35 | 9 | 3.00 | +100 | +11.1 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| OFF BEST | 8 | 8 | 8 | 2.67 | -180 | -22.5 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 8 | 2.67 | +32 | +3.9 |
| FALLS SHORT | 66 | 52 | 7 | 2.33 | +98 | +14.0 |
| FEATURE BUFFS | 44 | 44 | 7 | 2.33 | +152 | +21.8 |
| FIVE ACTION | 462 | 456 | 7 | 2.33 | +673 | +96.1 |
| MOVE TO CHARGE COMPUTED | 12 | 11 | 7 | 2.33 | +248 | +35.4 |
| STAY WORTH | 68 | 51 | 7 | 2.33 | +72 | +10.3 |
| THE RISK READS HIS RUN | 18 | 18 | 7 | 2.33 | +0 | +0.0 |
| CAST JOB | 6 | 6 | 6 | 2.00 | +8 | +1.3 |
| GOAL WALK | 14 | 14 | 6 | 2.00 | +1220 | +203.2 |
| NEXT CHARGE BY LIST | 9 | 9 | 6 | 2.00 | +243 | +40.5 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SEARCH SPOT | 6 | 6 | 6 | 2.00 | +122 | +20.4 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 92 | 90 | 4 | 1.33 | +91 | +22.7 |
| MAX FOR POSITIONING | 8 | 8 | 4 | 1.33 | +4 | +0.9 |
| MISSILES IN THE MOVE | 45 | 31 | 4 | 1.33 | +249 | +62.4 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 4 | 1.33 | +325 | +81.4 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +19 | +6.3 |
| COVER ONCE | 23 | 17 | 3 | 1.00 | +78 | +26.1 |
| MISSILES NEXT TURN | 46 | 33 | 3 | 1.00 | +190 | +63.4 |
| SHOTS IN THE MOVE | 52 | 33 | 3 | 1.00 | +59 | +19.7 |
| SUPPORT ADDS | 12 | 12 | 3 | 1.00 | +28 | +9.3 |
| SUPPORT WORKED OUT | 12 | 12 | 3 | 1.00 | +28 | +9.3 |
| HIS MOVE AND SHOT | 21 | 21 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +70 | +34.8 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +23 | +11.7 |
| REDIRECT COUNTER | 10 | 7 | 2 | 0.67 | +38 | +19.2 |
| RESERVE MOVE SPELL | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +182 | +182.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +17 | +17.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 28 | 26 | 1 | 0.33 | +42 | +42.1 |
| ONE OBJECTIVE FORMULA | 34 | 25 | 1 | 0.33 | +58 | +57.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -27 | -27.3 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +32 | +32.3 |
| PROMISE BY ITS OWN SUM | 10 | 10 | 1 | 0.33 | -27 | -27.2 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +40 | +39.8 |
| SET UP BY THE SET | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| THE ROW IN ITS ORDER | 10 | 1 | 1 | 0.33 | +0 | +0.0 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 19 | trace | - | - | - | - |
| CHARGE NOW FIRST | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 63 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 5 | 5 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 16 | not checked | - | - | - | - |
| FOUR ROUNDS | 3 | 3 | 0 | 0.00 | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 37 | 36 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 4 | 4 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 28 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 162 | 161 | 0 | 0.00 | - | - |
| HONEST WORTH | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 11 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 15 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 22 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 203 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| RISK BY ARC | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 30 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 13 | 13 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 25 | 25 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 39 | 38 | 0 | 0.00 | - | - |
| STANDS STILL | 154 | 153 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 32 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 24 | not checked | - | - | - | - |
| THE TABLE BINDS | 226 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 1.00 | 2.33 | 30.8 |
| JOB FIRST | gate | 0.67 | 1.67 | 16.2 |
| HOLDER ASSIGNMENT | rule | 1.33 | - | 8.1 |
| JOINT CHARGE NOW | rule | - | 0.33 | 30.6 |
| NO REASON | gate | - | 0.33 | 66.3 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 27.3 |
| PROMISE BY ITS OWN SUM | rule | - | 0.33 | 27.2 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.6 |

### Plans: cnsr-c940641-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 20.3 | 92% | 2667 | 0 | 0% |
| Mine | shoot | 4.0 | 33% | 677 | 156 | 23% |
| Opponent | charge | 1.0 | 100% | 235 | 233 | 99% |
| Opponent | move | 39.0 | 92% | 959 | 0 | 0% |
| Opponent | shoot | 3.0 | 56% | 61 | 14 | 22% |
| Opponent | support | 0.3 | 0% | 3 | 0 | 0% |

### Battle groups: cnsr-c940641-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 33 (18) | 33 | 0 | 24 | 17% | 1.5 | - | 32 (11) | 7 (3) | 36 (8) | 15 (6) |
| Mine | Hammer | 6 | 39 (6) | 2 | 38 | 19 | 67% | 4.0 | 84 (1) | 35 (4) | 11 (1) | 52 (4) | 14 (2) |
| Mine | Holder | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Shooter | 6 | 108 (6) | 0 | 108 | 17 | 0% | 1.8 | - | 129 (5) | 0 (1) | 138 (4) | 46 (2) |
| Opponent | Chaff | 6 | 141 (6) | 0 | 141 | 38 | 67% | 3.0 | 0 (3) | 514 (2) | 0 (1) | 141 (6) | - |
| Opponent | Character | 8 | 50 (8) | 50 | 0 | 0 | 38% | 1.0 | 93 (4) | 0 (4) | - | 84 (4) | 6 (4) |
| Opponent | Early | 1 | 144 (1) | 144 | 0 | 100 | 0% | 6.0 | - | 144 (1) | - | - | 144 (1) |
| Opponent | Fast Hammer | 7 | 9 (7) | 9 | 0 | 49 | 57% | 1.7 | 0 (1) | 0 (3) | 25 (3) | 29 (3) | 0 (4) |
| Opponent | Hammer | 13 | 12 (13) | 0 | 12 | 28 | 62% | 1.8 | - | 17 (8) | 0 (5) | 0 (3) | 16 (10) |
| Opponent | Holder | 1 | 250 (1) | 0 | 250 | 0 | 100% | - | - | 250 (1) | - | - | 250 (1) |
| Opponent | Shooter | 3 | 99 (3) | 0 | 99 | 62 | 67% | 1.0 | 257 (1) | 0 (2) | - | 257 (1) | 0 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (2) | - |

### Charged fights: cnsr-c940641-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 333 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 0 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 0 of 1 | 1 of 1 | - | +55 |
| Opponent | Ogre Kingdoms | 1 | 0 | 130 | 2.0 | 1.0 | 65 | 17 | +48 | 2 of 2 | 0 of 2 | - | +48 |
| Opponent | Wood Elf Realms | 1 | 55 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 18 | 62 | 1.0 | 1.0 | 62 | 11 | +50 | 2 of 3 | 1 of 3 | - | +50 |

### Effective charges: cnsr-c940641-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +55) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 85 | 55 | +55 | 55 | 0 | +55 | +64.7 |
| Opponent | No odds | 2 | 62 | 579 | +48 | 65 | 53 | +12 | +19.4 |
| Opponent | All fights | 3 | 70 | 404 | +50 | 62 | 35 | +26 | +37.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p1 | move | 11 | 0 (0%) | 0 (0%) | 0 (0%) | 11 (100%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

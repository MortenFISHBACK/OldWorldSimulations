# Doctrine scorecard: cnsr-c940641-p2

### Scorecard: cnsr-c940641-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | 6 | 1 | 7 | 0 | 0 | 0 | 255 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 74 |
| L0235 | 1 | 1 | Mine | no | 6 | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | yes | 2 | 3 | 0 | 4 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 11 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0319 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 3 | 0 | 0 | 0 | 235 |
| **Average** | | | Mine | 0% | 8.5 | 5.0 | 1.0 | 3.7 | 0.0 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 50% | 2.0 | 3.0 | 1.0 | 3.7 | 0.0 | 0.0 | 0.0 | 144.7 |

### KPIs: cnsr-c940641-p2

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 9) | 0% (0 of 13) | 0% (0 of 22) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 2); on the table 0% | 100% (1 of 1); on the table 100% | 33% (1 of 3); on the table 33% |
| Magic missiles tried each own turn | 50%+ | 48% (20 of 42) | 17% (4 of 24) | 36% (24 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (20 of 42) | 17% (4 of 23) | 37% (24 of 65) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 83% (10 of 12) | - | 83% (10 of 12) |
| Points that never fought | lower | 66% (3830 of 5797) | 62% (3692 of 6000) | 64% (7522 of 11797) |
|   infantry points that never fought | lower | 57% (788 of 1374) | 69% (577 of 842) | 62% (1365 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (12 of 20) | 63% (17 of 27) | 62% (29 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 6.0 uses a game | 50% (1 of 2); 1.3 uses a game | 83% (5 of 6); 3.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (2060 of 4039) | 62% (3428 of 5515) | 57% (5488 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 7.3 (100%) | 0.0 (0%) | 7.3 (52%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.7 (70%) | 4.7 (33%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (20%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.0 | 4.0 | 8.0 | 1.3 |
| not cast | 3.0 | 6.0 | 14.0 | 26.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (11%) | 0.0 (0%) | 7.3 (52%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (11%) | 0.3 (6%) | 0.3 (2%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (67%) | 4.0 (67%) | 4.7 (33%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 1.7 (28%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.7 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 1.3 a game | 2.0 a game |
| stood (cast and not dispelled) | 88% (7 of 8) | 100% (4 of 4) | 92% (11 of 12) |
| the unit moved after it | 86% (6 of 7) | 0% (0 of 4) | 55% (6 of 11) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 4) | 0% (0 of 11) |
| the enemy charged it first | 0% (0 of 7) | 0% (0 of 4) | 0% (0 of 11) |
| it fought by the end of its next turn | 0% (0 of 7) | 0% (0 of 4) | 0% (0 of 11) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 7) | 0% (0 of 4) | 0% (0 of 11) |
| none of these (no charge, no fight, no charge escaped) | 100% (7 of 7) | 100% (4 of 4) | 100% (11 of 11) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (26 of 36) | 43% (33 of 77) | 52% (59 of 113) |
|   cavalry | - | 57% (8 of 14) | 57% (8 of 14) |
|   character | - | 33% (4 of 12) | 33% (4 of 12) |
|   chariot | 75% (9 of 12) | 58% (7 of 12) | 67% (16 of 24) |
|   infantry | - | 19% (5 of 27) | 19% (5 of 27) |
|   monster | - | 75% (9 of 12) | 75% (9 of 12) |
|   war machine | 71% (17 of 24) | - | 71% (17 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (30%) | 1.7 (11%) | 2.7 (15%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.0 (30%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 0.0 (0%) | 7.0 (48%) | 7.0 (39%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (40%) | 1.3 (9%) | 2.7 (15%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (7%) | 1.0 (6%) |
| OTHER BAR | 0.0 (0%) | 1.7 (11%) | 1.7 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 1.3 | 0.7 | 50% | 11.4 pts | 15 pts |
| chariot | 5.3 | 6.0 | 56% | 22.4 pts | 120 pts |
| infantry | 1.7 | 2.3 | 20% | 13.3 pts | 22 pts |
| monster | 3.0 | 2.3 | 56% | 12.1 pts | 36 pts |
| war machine | 6.0 | 3.3 | 72% | 5.9 pts | 35 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 2.0 | 1.5 |
| Charges that made contact a game | 1.0 | 1.3 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.12 declared, 0.12 contact (25 units) | 0.21 declared, 0.14 contact (29 units) | 0.17 declared, 0.13 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (1 of 1) | - | 50% (2 of 4) |
| Character in a unit | 88% (7 of 8) | 50% (3 of 6) | - | 71% (10 of 14) |
| Character on its own | - | 50% (1 of 2) | 100% (2 of 2) | 75% (3 of 4) |
| Chariot | 50% (1 of 2) | 50% (1 of 2) | - | 50% (2 of 4) |
| Infantry | 60% (3 of 5) | 0% (0 of 3) | - | 38% (3 of 8) |
| Monster | 50% (1 of 2) | 0% (0 of 1) | - | 33% (1 of 3) |
| Monstrous | 100% (2 of 2) | 50% (2 of 4) | - | 67% (4 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 0% (0 of 2); on the table 0% | 67% (20 of 30) | 60% | 50% (6 of 12) | 100% (4 of 4); 9.0 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | - | 0% (0 of 12) | 78% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 68% | 43% (3 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 12) | 82% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 34% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p2, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 50% (1) | 40% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 75% (3 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (14 of 28) | 40% (4 of 10) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 55% (6 of 11) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.7 | 3.7 |
| Movement | Points that never moved of their own | 225.0 | 144.7 |
| Movement | Fights charged into per game | 1.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net -52 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +126 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 1 of 1, net +85 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +158 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.0 | 11.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 89% (8 of 9) | 24% (8 of 33) |
| Shooting | Points destroyed by shooting units | 18.3 | 38.3 |
| Shooting | War machine shots | 6.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (7 of 18) | - |
| Shooting | Points destroyed by war machines | 0.0 | 28.3 |
| Magic | Magic missiles cast | 3.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 9) | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 16.7 | 4.3 |
| Magic | Wounds caused by other spells | 0.3 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 79.7 | 34.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 0.0 / 1.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 106.0 | 45.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +127 | -33 |
| Combat | Net per 100 charger points, damage counted | +244.6 | -9.7 |
| Combat | First round won (charged fights) | 0% | 33% |
| Combat | Net points per charged fight | +77 | +17 |
| Combat | Net points per supported fight / lone fight | - / +77 | +85 / -17 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 3 | 2 of 3 |
| Game | Points lost | 147.0 | 270.3 |
| Game | VP from objectives | 1000.0 | 613.3 |
| Game | Lone holders (player turns) | 8.5 | 2.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +642 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 417
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| ARMY TABLE | 17.0 | +190.7 | 0.0 | 191.7 | 29.7 | -61.5 | 0.0 | 94.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.7 | +7.4 | 105.3 | 17.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 55.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.3 | +38.6 | 110.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.0 | +61.0 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +37.8 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +10.0 | 0.0 | 10.0 | 1.0 | +4.5 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.3 | -227.6 | 0.0 | 34.7 | 10.0 | -341.2 | 0.0 | 38.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 105.3 | 17.3 | 1.0 | +0.0 | 56.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.7 | +0.0 | 0.0 | 48.3 | 8.3 | +0.0 | 0.0 | 55.0 |
| CONVEYANCE SEARCH | 2.3 | +492.7 | 0.0 | 0.0 | 1.3 | +29.5 | 0.0 | 0.0 |
| COVER ONCE | 3.7 | -115.1 | 0.0 | 52.0 | 3.3 | -97.7 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.3 | 28.3 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -2.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +11.6 | 105.3 | 17.3 | 1.0 | +3.0 | 74.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 17.3 | 1.0 | +0.1 | 56.7 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 10.0 | - | - | - | - |
| FALLS SHORT | 23.3 | +299.4 | 0.0 | 90.3 | 3.0 | +104.5 | 0.0 | 18.3 |
| FEATURE BUFFS | 10.0 | +461.7 | 0.0 | 0.0 | 1.0 | +30.2 | 0.0 | 38.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 100.7 | +7011.2 | 252.0 | 373.3 | 93.0 | +5636.5 | 345.3 | 340.7 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 91.3 | 3.3 | +0.0 | 0.0 | 18.3 |
| FOUR ROUNDS | 1.0 | +115.1 | 105.3 | 34.7 | 1.3 | +75.1 | 74.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 34.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -9.9 | 17.3 | 0.0 |
| GOAL WALK | 7.7 | +828.4 | 0.0 | 28.3 | 13.7 | +1019.2 | 0.0 | 0.0 |
| GROUND FLIERS | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 3.0 | +89.3 | 18.3 | 0.0 | 2.0 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 5.0 | +0.0 | 0.0 | 17.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 34.7 | - | - | - | - |
| HELPER UNSEEN | 0.3 | +0.0 | 52.7 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 34.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +60.4 | 56.7 | 0.0 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 34.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 7.7 | -134.6 | 0.0 | 170.0 | 1.3 | -9.3 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 84.0 |
| HIS OWN BEST MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 14.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 59.0 | +1920.7 | 0.0 | 338.7 | 64.7 | +3552.5 | 0.0 | 340.7 |
| HIS SHOTS BY HIS RUN | 57.3 | +1084.5 | 0.0 | 328.7 | 42.3 | +902.8 | 0.0 | 218.7 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 33.0 | +0.0 | 0.0 | 0.0 | 17.0 | +0.0 | 0.0 | 234.7 |
| HOLDER ASSIGNMENT | 16.0 | +1659.1 | 0.0 | 0.0 | 12.0 | +1210.2 | 0.0 | 136.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -1.1 | 52.7 | 17.3 | 1.3 | -85.7 | 74.0 | 0.0 |
| IDLE COST | 15.3 | -88.0 | 0.0 | 91.3 | 4.0 | -67.2 | 0.0 | 18.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +27.2 | 56.7 | 0.0 |
| KEEP FALLS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 84.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 90.7 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | -0.1 | 0.0 | 17.3 | 0.3 | -0.0 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +78.4 | 0.0 | 0.0 | 2.3 | -6.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +57.1 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +22.1 | 0.0 | 0.0 | 1.7 | +65.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -1.3 | 0.0 | 0.0 | 0.7 | +158.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +60.3 | 0.0 | 102.3 | 2.0 | +22.2 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.7 | +409.0 | 0.0 | 0.0 | 4.3 | +102.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.7 | +260.5 | 0.0 | 0.0 | 4.7 | +59.4 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.7 | -97.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.7 | +0.0 | 56.7 | 0.0 | 2.0 | +0.0 | 0.0 | 38.0 |
| MOVE SPELL IN RANGE | - | - | - | - | 0.7 | +12.5 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -63.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.3 | +460.8 | 0.0 | 119.7 | 1.3 | +24.5 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +185.1 | 0.0 | 0.0 | 10.7 | +487.6 | 0.0 | 74.7 |
| NEXT CHARGE BY LIST | 1.3 | +101.9 | 0.0 | 17.3 | 2.0 | +103.1 | 34.7 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -45.5 | 105.3 | 34.7 | 1.0 | -6.5 | 74.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -2059.5 | 0.0 | 0.0 | 2.3 | -16.0 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 2.3 | +6.4 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.0 | -16.1 | 0.0 | 102.3 | 3.3 | -61.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 9.7 | +93.1 | 0.0 | 0.0 | 3.7 | +21.7 | 0.0 | 56.3 |
| ONE PROMISE A TARGET | 1.3 | -68.1 | 0.0 | 45.7 | - | - | - | - |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +10.7 | 45.7 | 0.0 |
| PLAN RESULT | 45.0 | +281.8 | 71.0 | 237.3 | 42.0 | +199.2 | 45.7 | 375.0 |
| PROMISE BY ITS OWN SUM | 9.7 | -4362.7 | 0.0 | 28.3 | 3.0 | -88.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | -0.5 | 0.0 | 34.7 | - | - | - | - |
| PROMISE READS THE TABLE | 1.0 | -180.7 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 3.3 | -19.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.0 | +650.4 | 52.7 | 52.0 | 13.7 | +1614.2 | 17.3 | 84.0 |
| RANDOM MOVE BY FIGURES | 4.0 | +105.3 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.7 | +41.9 | 0.0 | 105.0 | 1.3 | -59.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +0.0 | 0.0 | 76.7 | 2.3 | +0.0 | 0.0 | 41.0 |
| REFORMS TO MEET IT | 2.0 | -133.8 | 0.0 | 74.0 | 1.0 | -21.2 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | -9.4 | 105.3 | 17.3 | 0.7 | +7.1 | 28.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -31.5 | 45.7 | 0.0 |
| RUN DOWN | 0.7 | -26.6 | 105.3 | 17.3 | 0.7 | -0.1 | 56.7 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.0 | -22.7 | 0.0 | 10.0 | 1.0 | -49.6 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +3.3 | 0.0 | 10.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | -54.6 | 0.0 | 17.3 | 0.3 | +11.9 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +6.6 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.7 | +25.7 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -5.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +239.9 | 0.0 | 0.0 | 1.3 | +20.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -7.2 | 28.3 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 47.3 | +589.0 | 0.0 | 338.7 | 46.0 | +1022.3 | 0.0 | 267.3 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 9.3 | +415.3 | 0.0 | 0.0 | 15.0 | +355.8 | 0.0 | 74.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.7 | +25.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -34.5 | 52.7 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 91.3 | 6.3 | +0.0 | 0.0 | 42.0 |
| STAND AND SHOOT | 0.3 | -2.9 | 52.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 51.0 | +0.0 | 146.7 | 79.3 | 39.7 | +0.0 | 271.3 | 34.0 |
| STAY WORTH | 21.0 | +110.7 | 146.7 | 0.0 | 18.7 | +89.3 | 214.7 | 116.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +1.0 | 0.0 | 11.3 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 2.3 | +12.9 | 0.0 | 62.0 | 3.3 | +162.5 | 0.0 | 76.0 |
| SUPPORT WORKED OUT | 2.3 | +12.9 | 0.0 | 62.0 | 3.3 | +162.5 | 0.0 | 76.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +5.7 | 0.0 | 53.3 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISE ADDS | 1.0 | -85.0 | 0.0 | 17.3 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 18.3 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 28.3 | 3.7 | +0.0 | 0.0 | 18.3 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 17.3 | 4.7 | +0.0 | 0.0 | 36.7 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 17.3 | - | - | - | - |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 36.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.0 | +0.0 | 0.0 | 174.3 | 45.0 | +0.0 | 0.0 | 164.7 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +83.7 | 45.7 | 0.0 |
| TIME ON OUR SIDE | 9.3 | +156.5 | 0.0 | 0.0 | 57.3 | +495.7 | 0.0 | 120.0 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 28.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 56.7 | 0.0 |
| WHO FIGHTS | 0.3 | +9.2 | 52.7 | 0.0 | 0.3 | +0.5 | 28.3 | 0.0 |
| WHO HITS BACK | 0.3 | +107.4 | 0.0 | 0.0 | 0.7 | +33.4 | 0.0 | 52.7 |
| WHOLE FIGHT DANGER | 0.7 | -31.4 | 0.0 | 34.7 | 1.0 | -25.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.7 | +431.7 | 0.0 | 0.0 | 3.0 | +502.0 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SHOT RISK POINTS | 280 | 275 | 107 | 35.67 | +3469 | +32.4 |
| HIS SHOT LIST | 371 | 365 | 97 | 32.33 | +959 | +9.9 |
| HIS SHOTS BY HIS RUN | 299 | 281 | 92 | 30.67 | +1492 | +16.2 |
| HOLDER ASSIGNMENT | 84 | 84 | 78 | 26.00 | +5036 | +64.6 |
| ARMY TABLE | 140 | 140 | 76 | 25.33 | +315 | +4.1 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 200 | 177 | 23 | 7.67 | +48 | +2.1 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -6226 | -311.3 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| FIVE ACTION | 581 | 560 | 19 | 6.33 | +849 | +44.7 |
| PROMISE BY ITS OWN SUM | 38 | 38 | 19 | 6.33 | -13353 | -702.8 |
| GOAL WALK | 64 | 59 | 15 | 5.00 | +633 | +42.2 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 14 | 4.67 | +181 | +13.0 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CAST JOB | 12 | 12 | 10 | 3.33 | +17 | +1.7 |
| PROMISE SHOT AWAY | 10 | 10 | 10 | 3.33 | -57 | -5.7 |
| QUARTER ODDS | 89 | 86 | 10 | 3.33 | +695 | +69.5 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 10 | 3.33 | +316 | +31.6 |
| STAY WORTH | 119 | 101 | 10 | 3.33 | +24 | +2.4 |
| SUPPORT ADDS | 17 | 16 | 9 | 3.00 | +257 | +28.5 |
| SUPPORT WORKED OUT | 17 | 16 | 9 | 3.00 | +257 | +28.5 |
| WOUNDS ON THE RANKS | 23 | 22 | 9 | 3.00 | +842 | +93.6 |
| MOVE TO CHARGE COMPUTED | 17 | 15 | 8 | 2.67 | +399 | +49.9 |
| MISSILES IN THE MOVE | 33 | 23 | 7 | 2.33 | +565 | +80.8 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +19 | +2.7 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 14 | 14 | 6 | 2.00 | +26 | +4.4 |
| FALLS SHORT | 79 | 60 | 5 | 1.67 | +52 | +10.4 |
| THE RISK READS HIS RUN | 18 | 18 | 5 | 1.67 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +25 | +6.4 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +1 | +0.1 |
| LEGAL CHARGES ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| NEXT CHARGE BY LIST | 10 | 10 | 4 | 1.33 | +62 | +15.6 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -204 | -51.1 |
| SHOTS IN THE MOVE | 73 | 55 | 4 | 1.33 | +388 | +97.0 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 21 | 15 | 3 | 1.00 | +76 | +25.4 |
| FOUR ROUNDS | 7 | 7 | 3 | 1.00 | +31 | +10.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 13 | 13 | 3 | 1.00 | +244 | +81.2 |
| MARCH CHECK | 7 | 7 | 3 | 1.00 | +91 | +30.3 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +383 | +127.6 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -4 | -2.0 |
| CHARGE LOSSES | 64 | 62 | 2 | 0.67 | +78 | +39.2 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -77 | -38.7 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +82 | +40.8 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +218 | +109.0 |
| PROMISE KNOWS THE FIGHT | 5 | 4 | 2 | 0.67 | -1 | -0.7 |
| SHOTS AFTER THE MOVES | 11 | 11 | 2 | 0.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 16 | 16 | 1 | 0.33 | +0 | +0.2 |
| FEATURE BUFFS | 33 | 32 | 1 | 0.33 | +21 | +21.1 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +80 | +79.6 |
| HIS MOVE AND SHOT | 27 | 25 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +23 | +22.9 |
| ONE OBJECTIVE FORMULA | 40 | 29 | 1 | 0.33 | +60 | +60.5 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +10 | +9.5 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -363 | -362.8 |
| REDIRECT COUNTER | 12 | 8 | 1 | 0.33 | +4 | +4.0 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +10 | +10.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +3 | +3.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| THE ROW IN ITS ORDER | 24 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 1 | 0.33 | +10 | +9.5 |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 11 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 56 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 11 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 5 | 5 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 25 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 5 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 21 | 20 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 16 | 15 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 10 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 150 | 148 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| IDLE COST | 58 | 45 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 34 | 23 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 5 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 43 | 39 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 6 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 19 | 11 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 261 | trace | - | - | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 40 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 43 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 272 | 259 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 270 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 2.00 | 327.6 |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 1.00 | 702.8 |
| ARMY TABLE | rule | 0.33 | 4.00 | 61.7 |
| PROMISE SHOT AWAY | rule | 3.33 | - | 5.7 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 15.8 |
| ONE PROMISE A TARGET | rule | 1.00 | - | 73.9 |
| CHAFF PASSED | rule | - | 0.67 | 2.0 |
| CHARGE NOW FIRST | rule | - | 0.67 | 38.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 0.7 |
| AFTERMATH BAND | gate | - | 0.33 | 2.1 |
| JOINT CHARGE NOW | rule | - | 0.33 | 14.5 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 362.8 |

### Plans: cnsr-c940641-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 174 | 92 | 53% |
| Mine | move | 37.0 | 96% | 2210 | 0 | 0% |
| Mine | shoot | 7.3 | 64% | 291 | 190 | 65% |
| Opponent | charge | 1.3 | 75% | 189 | 83 | 44% |
| Opponent | move | 37.3 | 94% | 2094 | 0 | 0% |
| Opponent | shoot | 3.0 | 56% | 206 | 116 | 56% |
| Opponent | support | 0.3 | 100% | 0 | 0 | 0% |

### Battle groups: cnsr-c940641-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 25% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 14 (11) | 14 | 0 | 0 | 36% | 2.1 | - | 1 (6) | 29 (5) | 14 (11) | - |
| Mine | Clean-up | 2 | 339 (2) | 0 | 339 | 0 | 100% | - | 316 (1) | - | 363 (1) | 339 (2) | - |
| Mine | Fast Hammer | 10 | 24 (10) | 24 | 0 | 63 | 60% | 4.5 | 46 (6) | 0 (1) | 0 (3) | 0 (7) | 84 (3) |
| Mine | Hammer | 9 | 47 (9) | 10 | 36 | 0 | 22% | 3.4 | 0 (2) | 53 (4) | 83 (3) | 47 (9) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 23 (8) | 0 | 23 | 45 | 75% | 4.5 | 47 (3) | 0 (4) | 0 (1) | 25 (7) | 0 (1) |
| Opponent | Character | 7 | 6 (7) | 6 | 0 | 0 | 29% | 1.8 | 0 (1) | 2 (4) | 13 (2) | 8 (5) | 3 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 38 | 67% | 2.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 59 (10) | 14 | 44 | 6 | 40% | 2.5 | 9 (5) | 110 (4) | 68 (1) | 20 (5) | 87 (5) |
| Opponent | Shooter | 4 | 75 (4) | 6 | 69 | 73 | 0% | 2.0 | 0 (1) | 77 (2) | 129 (1) | 59 (3) | 132 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |

### Charged fights: cnsr-c940641-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 120 | 142 | 1.5 | 1.0 | 95 | 17 | +77 | 3 of 3 | 0 of 3 | - | +77 |
| Mine | Chaos Dwarfs | 1 | 55 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 98 | 95 | 1.0 | 1.0 | 95 | 17 | +77 | 3 of 3 | 0 of 3 | - | +77 |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 1 of 1 | 0 of 1 | - | -34 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 134 | 85 | 1.0 | 2.0 | 85 | 0 | +85 | 0 of 1 | 1 of 1 | +85 | - |
| **Opponent** | all armies | 3 | 101 | 28 | 1.0 | 1.3 | 28 | 11 | +17 | 2 of 3 | 1 of 3 | +85 | -17 |

### Effective charges: cnsr-c940641-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 1 (net -52) | 0 | 1 (net +126) | 0 | 0 | 1 (net +158) | 0 | 33% (1 of 3) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 1 (net +85) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 52 | 297 | -52 | 50 | 52 | -2 | -4.8 |
| Mine | Effective (55-75%) | 1 | 52 | 158 | +126 | 252 | 26 | +226 | +434.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 52 | 158 | +158 | 158 | 0 | +158 | +303.8 |
| Mine | All fights | 3 | 52 | 204 | +77 | 153 | 26 | +127 | +244.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 624 | 85 | +85 | 85 | 0 | +85 | +13.6 |
| Opponent | No odds | 2 | 192 | 293 | -17 | 13 | 104 | -91 | -47.6 |
| Opponent | All fights | 3 | 336 | 224 | +17 | 37 | 70 | -33 | -9.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p2 | move | 16 | 3 (19%) | 3 (19%) | 1 (6%) | 12 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

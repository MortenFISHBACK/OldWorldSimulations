# Doctrine scorecard: cnsr-c940641-p34

### Scorecard: cnsr-c940641-p34

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | no | - | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 5 | 1 | 2 | 0 | 0 | 142 |
| L1923 | 3 | 1 | Mine | no | 0 | 1 | 5 | 0 | 1 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 140 |
| L2025 | 3 | 1 | Mine | yes | 6 | - | 1 | 0 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.0 | 1.0 | 2.7 | 0.7 | 0.3 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 33% | 2.0 | 1.7 | 4.7 | 1.7 | 0.7 | 0.0 | 0.0 | 94.0 |

### KPIs: cnsr-c940641-p34

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 15) | 0% (0 of 29) |
| Winner chose to follow up after the loser gave ground |  | 90% (9 of 10); on the table 90% | 75% (3 of 4); on the table 75% | 86% (12 of 14); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | - | 33% (1 of 3); on the table 33% | 33% (1 of 3); on the table 33% |
| Winner chose to pursue after the loser fled |  | - | 78% (7 of 9); on the table 89% | 78% (7 of 9); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 90% (9 of 10); on the table 90% | 69% (11 of 16); on the table 75% | 77% (20 of 26); on the table 81% |
| Magic missiles tried each own turn | 50%+ | 7% (2 of 30) | 33% (6 of 18) | 17% (8 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 12% (2 of 16) | 33% (6 of 18) | 24% (8 of 34) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (2 of 5) | - | 40% (2 of 5) |
| Points that never fought | lower | 20% (1219 of 5999) | 32% (1928 of 5999) | 26% (3147 of 11998) |
|   infantry points that never fought | lower | 43% (427 of 993) | 61% (634 of 1037) | 52% (1061 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (11 of 22) | 44% (7 of 16) | 47% (18 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (2953 of 5151) | 32% (1439 of 4500) | 46% (4392 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (4%) | 3.7 (92%) | 4.0 (30%) |
| MARCHED: its unit marched | 1.3 (14%) | 0.3 (8%) | 1.7 (12%) |
| CHARGED: its unit charged | 1.3 (14%) | 0.0 (0%) | 1.3 (10%) |
| IN COMBAT: engaged in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| REAR RANK: in a rear rank | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 4.0 (43%) | 0.0 (0%) | 4.0 (30%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 1.3 (14%) | 0.0 (0%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.3 | 1.7 | 2.7 | 0.3 |
| not cast | 6.7 | 0.7 | 4.3 | 13.3 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 4.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.7 (25%) | 0.0 (0%) | 1.7 (38%) | 0.3 (2%) | 0.0 (0%) |
| GONE: slain | 3.0 (45%) | 0.0 (0%) | 1.0 (23%) | 4.0 (30%) | 4.0 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) | 1.0 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (25%) | 0.0 (0%) | 1.3 (31%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 40% (2 of 5) | 40% (2 of 5) |
| the unit moved after it | - | 100% (2 of 2) | 100% (2 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (40 of 65) | 43% (32 of 75) | 51% (72 of 140) |
|   cavalry | - | 68% (13 of 19) | 68% (13 of 19) |
|   character | 100% (6 of 6) | 0% (0 of 14) | 30% (6 of 20) |
|   chariot | 64% (7 of 11) | - | 64% (7 of 11) |
|   infantry | 44% (16 of 36) | 45% (19 of 42) | 45% (35 of 78) |
|   monster | 92% (11 of 12) | - | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (12%) | 0.0 (0%) | 1.0 (4%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (12%) | 1.7 (7%) |
| FLEEING: it fled or was fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 2.0 (14%) | 2.0 (9%) |
| NO TARGET IN RANGE | 4.0 (48%) | 4.0 (28%) | 8.0 (35%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 3.3 (23%) | 3.7 (16%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (16%) | 2.3 (16%) | 3.7 (16%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.7 (5%) | 1.0 (4%) |
| OTHER BAR | 1.0 (12%) | 0.3 (2%) | 1.3 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 0.7 | 94% | 2.0 pts | 10 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.7 | 2.7 | 50% | 25.7 pts | 68 pts |
| infantry | 12.3 | 7.3 | 59% | 8.7 pts | 107 pts |
| monster | 3.7 | 1.0 | 82% | 7.2 pts | 26 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 7.7 | 5.5 |
| Charges that made contact a game | 2.0 | 6.3 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 4.00 declared, 3.00 contact (1 units) | 4.00 declared, 3.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.21 contact (28 units) | 0.63 declared, 0.53 contact (30 units) | 0.50 declared, 0.38 contact (58 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 33% (1 of 3) | - | 33% (1 of 3) |
| Character on its own | 40% (2 of 5) | 100% (4 of 4) | 29% (2 of 7) | 50% (8 of 16) |
| Chariot | 0% (0 of 2) | - | - | 0% (0 of 2) |
| Infantry | 50% (3 of 6) | - | - | 50% (3 of 6) |
| Monster | 25% (1 of 4) | 33% (1 of 3) | - | 29% (2 of 7) |
| Monstrous | - | 100% (4 of 4) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 67% (2 of 3); on the table 67% | 0% (0 of 6) | 39% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 12) | 3% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (7 of 7); on the table 100% | 17% (2 of 12) | 19% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 69% (9 of 13); on the table 69% | 0% (0 of 6) | 40% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (2 of 3); on the table 100% | 50% (6 of 12) | 17% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p34, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (8) | 100% (1) | 60% (9) |
| ...free all their last turn and able to turn (per game) | 2.67 | 0.33 | 3.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnsr-c940641-p34

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 70% (14 of 20) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (9 of 20) | 59% (10 of 17) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (3 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 2) |
| Strategy | Lone characters that fought | 90% (9 of 10) | 67% (6 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 1.7 |
| Movement | Points that never moved of their own | 225.0 | 94.0 |
| Movement | Fights charged into per game | 1.7 | 5.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 2 of 14, net -116 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +66 | 1 of 14, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 3 of 14, net +62 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +254 | 5 of 14, net +203 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.3 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (18 of 40) | 41% (18 of 44) |
| Shooting | Points destroyed by shooting units | 38.3 | 107.7 |
| Shooting | Points destroyed by war machines | 88.3 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.3 / 0.0 | 1.7 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 325.3 | 516.0 |
| Combat | Points run down | 0.0 | 325.7 |
| Combat | Net points per charged fight, damage counted | -31 | +179 |
| Combat | Net per 100 charger points, damage counted | -21.8 | +53.8 |
| Combat | First round won (charged fights) | 60% | 81% |
| Combat | Net points per charged fight | -17 | +162 |
| Combat | Net points per supported fight / lone fight | +66 / -38 | +658 / +47 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 8 of 16 |
| Game | Points lost | 1302.3 | 418.7 |
| Game | VP from objectives | 430.0 | 973.3 |
| Game | Lone holders (player turns) | 3.0 | 2.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -1578 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1721
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnsr-c940641-p34

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +26.2 | 0.0 | 0.0 | 0.3 | +3.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +6.6 | 0.0 | 0.0 |
| ARMY TABLE | 23.7 | +165.7 | 0.0 | 707.0 | 17.3 | +147.8 | 0.0 | 169.3 |
| ASSAILMENT BY POINTS | 0.3 | +0.1 | 0.0 | 108.7 | - | - | - | - |
| BACKUP TARGETS | 1.0 | +3.9 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | +20.9 | 0.0 | 65.0 |
| CAST JOB | - | - | - | - | 1.0 | +1.3 | 64.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.7 | +18.0 | 44.0 | 198.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +24.1 | 0.0 | 18.3 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +1.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -43.4 | 11.7 | 0.0 |
| CHARGE LOSSES | 16.0 | -1698.6 | 0.0 | 851.3 | 8.7 | -361.9 | 0.0 | 130.0 |
| CHARGE NOW FIRST | - | - | - | - | 5.0 | +0.0 | 887.0 | 81.7 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 409.3 | 14.7 | +0.0 | 0.0 | 48.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 70.0 | 1.7 | +0.0 | 0.0 | 113.3 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +214.9 | 0.0 | 0.0 |
| COVER ONCE | 13.0 | -500.7 | 0.0 | 359.7 | 2.3 | -77.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 2.0 | -9.7 | 110.7 | 23.3 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 0.0 | 7.3 | +33.6 | 0.0 | 23.3 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -295.3 | 64.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +3.6 | 85.0 | 0.0 |
| EXACT ROUND | 1.0 | -1.4 | 106.7 | 0.0 | 5.3 | +10.8 | 849.0 | 88.3 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 106.7 | 0.0 | 7.0 | +36.3 | 994.3 | 170.0 |
| FALLS SHORT | 1.7 | +2.6 | 0.0 | 85.0 | 16.0 | +155.3 | 0.0 | 52.0 |
| FEATURE BUFFS | 1.3 | +7.6 | 0.0 | 0.0 | 1.7 | +14.0 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 3.7 | +64.4 | 410.7 | 146.7 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 61.7 | 0.0 |
| FIVE ACTION | 75.0 | +4731.4 | 624.0 | 1885.0 | 96.0 | +9421.5 | 1881.0 | 656.7 |
| FLANK NOT WEIGHED | 11.0 | +0.0 | 0.0 | 342.3 | 2.7 | +0.0 | 0.0 | 25.0 |
| FOLLOW UP WEIGHED | 2.3 | +180.7 | 0.0 | 0.0 | 0.7 | +78.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +38.8 | 106.7 | 0.0 | 7.7 | +815.1 | 1049.3 | 170.0 |
| FREED FROM HIS FIGHT | 6.3 | +0.0 | 0.0 | 160.0 | 5.3 | +0.0 | 0.0 | 25.0 |
| FRIEND SHOOTS FIRST | 1.7 | -11.3 | 0.0 | 0.0 | 2.3 | -290.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -8.3 | 0.0 | 23.3 |
| GOAL WALK | 10.0 | +636.7 | 0.0 | 23.3 | 7.3 | +528.9 | 0.0 | 50.0 |
| GUN FIGURES | 3.0 | +38.5 | 130.0 | 123.3 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 36.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 11.7 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.7 | +0.0 | 0.0 | 851.3 | 3.7 | +0.0 | 0.0 | 84.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +52.1 | 11.7 | 0.0 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 23.3 | 0.7 | +0.0 | 0.0 | 22.0 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 449.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -84.7 | 0.0 | 240.0 | 5.0 | -90.9 | 0.0 | 45.0 |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 226.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 449.7 | 8.3 | +0.0 | 0.0 | 160.0 |
| HIS RANDOM MOVE | - | - | - | - | 6.7 | +0.0 | 0.0 | 50.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.7 | +441.6 | 0.0 | 886.3 | 27.7 | +655.5 | 0.0 | 258.3 |
| HIS SHOTS BY HIS RUN | 34.7 | +214.2 | 0.0 | 1478.7 | 25.3 | +499.4 | 0.0 | 234.0 |
| HIS TURN DENIED | 0.3 | +0.6 | 22.0 | 0.0 | 2.0 | +20.2 | 343.0 | 23.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.3 | +0.0 | 0.0 | 51.3 | 19.0 | +0.0 | 0.0 | 88.0 |
| HOLDER ASSIGNMENT | 8.0 | +498.6 | 0.0 | 51.3 | 11.0 | +861.2 | 0.0 | 22.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -3.0 | 106.7 | 0.0 | 6.3 | -302.8 | 770.3 | 88.3 |
| HUNT IN PAIRS | - | - | - | - | 1.7 | +12.8 | 0.0 | 0.0 |
| IDLE COST | 1.0 | -14.0 | 0.0 | 36.7 | 11.0 | -155.1 | 0.0 | 41.7 |
| JOINT CHARGE NOW | - | - | - | - | 2.0 | +399.2 | 558.0 | 65.0 |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 116.7 | 1.7 | +89.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 106.7 | 36.7 | 9.7 | +0.0 | 224.0 | 199.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 1.7 | +9.3 | 114.7 | 0.0 | 0.7 | +4.8 | 180.0 | 16.7 |
| LOST AFTER ESCAPE | 0.7 | -0.2 | 106.7 | 0.0 | 5.0 | +8.5 | 336.0 | 105.0 |
| LURE BY WHAT IT DRAWS | 0.3 | -18.3 | 0.0 | 18.3 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -0.2 | 0.0 | 64.0 | 1.3 | +1.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +42.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +27.9 | 0.0 | 180.0 | 0.7 | +52.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +230.6 | 0.0 | 25.7 | 4.0 | +39.5 | 0.0 | 40.0 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 0.0 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +26.1 | 0.0 | 262.0 | 3.3 | +35.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.0 | +52.4 | 0.0 | 442.0 | 4.7 | +26.8 | 0.0 | 0.0 |
| MOVE ORDER | 2.3 | +0.0 | 73.3 | 205.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +380.7 | 0.0 | 135.0 | 13.3 | +1305.7 | 0.0 | 160.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.7 | +309.7 | 0.0 | 174.7 | 11.0 | +408.6 | 0.0 | 22.0 |
| NEXT CHARGE BY LIST | 1.7 | +133.9 | 0.0 | 116.7 | 8.3 | +771.1 | 61.7 | 160.0 |
| NO DOUBLE ROUNDS | 0.7 | -7.8 | 22.0 | 0.0 | 7.3 | -445.4 | 1049.3 | 153.3 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.3 | -66.7 | 0.0 | 0.0 | 6.7 | -189.1 | 82.3 | 22.0 |
| ONE CHALLENGE TEST | 0.3 | -0.5 | 84.7 | 0.0 | 0.3 | -12.5 | 64.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 25.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -54.4 | 0.0 | 253.3 | 8.0 | -149.8 | 0.0 | 189.7 |
| ONE JOINT FIGURE | - | - | - | - | 1.7 | +317.4 | 279.0 | 81.7 |
| ONE OBJECTIVE FORMULA | 4.0 | -23.0 | 0.0 | 25.7 | 4.3 | +17.5 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -4.7 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +43.1 | 62.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.9 | 22.0 | 0.0 | 3.3 | +43.5 | 640.3 | 65.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -0.9 | 0.0 | 0.0 |
| PLAN RESULT | 36.3 | +297.5 | 316.7 | 1272.3 | 46.0 | +1423.1 | 710.7 | 617.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 4.3 | -12.9 | 0.0 | 18.3 | 14.7 | -558.8 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 5.7 | -4.2 | 61.7 | 0.0 |
| PROMISE READS THE TABLE | 1.7 | -19.1 | 0.0 | 0.0 | 0.7 | -91.4 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -0.5 | 130.0 | 0.0 | 1.3 | -3.2 | 123.3 | 0.0 |
| QUARTER ODDS | 19.0 | +1868.0 | 108.0 | 547.3 | 26.0 | +3621.1 | 557.0 | 192.7 |
| RANDOM MOVE BY FIGURES | 1.7 | +40.9 | 0.0 | 70.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.7 | +210.6 | 0.0 | 25.7 | 2.7 | +63.0 | 0.0 | 47.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +0.0 | 0.0 | 44.0 | 5.0 | +0.0 | 0.0 | 52.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -59.0 | 0.0 | 0.0 | 1.0 | -1.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 25.7 | 1.0 | +0.0 | 0.0 | 84.7 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +25.8 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +21.7 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | +5.2 | 84.7 | 0.0 | 6.0 | -191.9 | 975.3 | 170.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 5.0 | -202.9 | 421.0 | 146.7 |
| RUN DOWN | - | - | - | - | 5.7 | -53.6 | 421.0 | 105.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -80.3 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +27.7 | 0.0 | 99.0 | 1.3 | +75.2 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +19.5 | 82.3 | 0.0 |
| SELF MOVE SPELL | 1.0 | -2.0 | 0.0 | 108.7 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -6.1 | 0.0 | 65.0 |
| SET UP BY THE SET | 0.7 | -6.6 | 0.0 | 0.0 | 2.0 | +40.6 | 0.0 | 130.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +9.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.0 | +0.0 | 0.0 | 99.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +24.5 | 30.0 | 0.0 | 2.0 | +65.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| SHOT RISK POINTS | 16.7 | +3.4 | 0.0 | 466.3 | 15.3 | +68.6 | 0.0 | 212.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.3 | +299.0 | 0.0 | 174.7 | 12.7 | +590.1 | 0.0 | 22.0 |
| SPELL WORTH | 1.0 | +10.8 | 244.0 | 211.7 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 1.0 | -51.7 | 279.0 | 65.0 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 36.7 | 6.3 | +0.0 | 0.0 | 147.3 |
| STAND AND SHOOT | 0.3 | -0.5 | 0.0 | 0.0 | 0.7 | -4.6 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 26.3 | +0.0 | 517.3 | 353.0 | 35.0 | +0.0 | 831.7 | 0.0 |
| STAY WORTH | 11.7 | +42.7 | 260.0 | 61.7 | 17.3 | +261.4 | 543.3 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +5.2 | 99.0 | 130.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.7 | +1323.2 | 0.0 | 113.0 | 2.0 | +54.1 | 0.0 | 106.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 99.0 | 16.7 |
| SUPPORT WORKED OUT | 8.7 | +1323.2 | 0.0 | 113.0 | 2.0 | +54.1 | 0.0 | 106.7 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +6.8 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +5.4 | 0.0 | 116.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -10.1 | 0.0 | 0.0 | 0.3 | -11.2 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 61.7 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 61.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 61.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 34.0 | +0.0 | 0.0 | 788.3 | 45.7 | +0.0 | 0.0 | 243.3 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +201.0 | 125.0 | 0.0 |
| TIME ON OUR SIDE | 31.7 | +357.8 | 44.0 | 577.0 | 20.3 | +133.8 | 0.0 | 195.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -2.4 | 22.0 | 0.0 | 2.0 | +41.1 | 315.7 | 153.3 |
| WHO HITS BACK | 0.3 | +7.7 | 0.0 | 0.0 | 1.0 | +126.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 6.3 | -1287.5 | 0.0 | 483.3 | 3.0 | -238.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +26.8 | 180.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.3 | +29.0 | 0.0 | 128.0 | - | - | - | - |

### Rule changes: cnsr-c940641-p34

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 123 | 123 | 64 | 21.33 | +76 | +1.2 |
| FIVE ACTION | 513 | 496 | 58 | 19.33 | +3618 | +62.4 |
| HOLDER ASSIGNMENT | 57 | 57 | 51 | 17.00 | +2741 | +53.7 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| HIS SHOT LIST | 187 | 176 | 38 | 12.67 | +268 | +7.0 |
| MOVE TO CHARGE COMPUTED | 54 | 45 | 35 | 11.67 | +2165 | +61.8 |
| QUARTER ODDS | 135 | 135 | 29 | 9.67 | +3221 | +111.1 |
| REDIRECT FOR A FRIEND IN REACH | 28 | 28 | 28 | 9.33 | +0 | +0.0 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -767 | -28.4 |
| THE TABLE AGAIN | 35 | 35 | 27 | 9.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 180 | 170 | 25 | 8.33 | +239 | +9.5 |
| PROMISE BY ITS OWN SUM | 57 | 57 | 23 | 7.67 | -1715 | -74.6 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| NEXT CHARGE BY LIST | 30 | 26 | 18 | 6.00 | +1390 | +77.2 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 156 | 138 | 16 | 5.33 | +57 | +3.6 |
| GOAL WALK | 52 | 50 | 15 | 5.00 | +636 | +42.4 |
| SUPPORT ADDS | 32 | 32 | 15 | 5.00 | +737 | +49.1 |
| SUPPORT WORKED OUT | 32 | 32 | 15 | 5.00 | +737 | +49.1 |
| FOUR ROUNDS | 26 | 24 | 14 | 4.67 | +432 | +30.8 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOT RISK POINTS | 96 | 89 | 12 | 4.00 | +161 | +13.4 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +777 | +86.4 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| COMBAT PIVOT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 24 | 23 | 7 | 2.33 | +75 | +10.8 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 15 | 15 | 6 | 2.00 | -152 | -25.4 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +1198 | +199.6 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| PROMISE SHOT AWAY | 6 | 6 | 6 | 2.00 | -11 | -1.8 |
| COVER ONCE | 46 | 36 | 5 | 1.67 | +100 | +20.1 |
| SET UP BY THE SET | 8 | 8 | 5 | 1.67 | +344 | +68.8 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 5 | 1.67 | +158 | +31.5 |
| THE RISK READS HIS RUN | 18 | 18 | 5 | 1.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 28 | 25 | 5 | 1.67 | +362 | +72.5 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +8 | +2.1 |
| CHARGE LOSSES | 74 | 68 | 4 | 1.33 | +216 | +53.9 |
| PROMISE KNOWS THE FIGHT | 17 | 13 | 4 | 1.33 | -12 | -3.1 |
| SEARCH SPOT | 7 | 7 | 4 | 1.33 | +309 | +77.2 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +251 | +62.7 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 19 | 18 | 3 | 1.00 | +11 | +3.8 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 36 | 20 | 3 | 1.00 | +7 | +2.3 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| ONE JOINT FIGURE | 5 | 5 | 3 | 1.00 | +12 | +4.0 |
| RISK BY ARC | 20 | 18 | 3 | 1.00 | +11 | +3.7 |
| SHOTS IN THE MOVE | 81 | 63 | 3 | 1.00 | +216 | +72.1 |
| THE ROW IN ITS ORDER | 14 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 3 | 3 | 1.00 | +72 | +23.9 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +87 | +43.7 |
| CAST JOB | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 9 | 9 | 2 | 0.67 | +6 | +3.0 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +115 | +57.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +128 | +64.1 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +17 | +8.6 |
| NEARER NOT NEEDED | 56 | 54 | 2 | 0.67 | +52 | +26.2 |
| ONE OBJECTIVE FORMULA | 25 | 17 | 2 | 0.67 | +86 | +42.8 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 2 | 0.67 | +122 | +61.2 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +77 | +38.7 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +58 | +29.2 |
| SHOTS AFTER THE MOVES | 17 | 17 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 2 | 0.67 | +5 | +2.7 |
| SUPPORT NARROWED | 4 | 4 | 2 | 0.67 | -160 | -79.8 |
| WHO FIGHTS | 8 | 8 | 2 | 0.67 | +6 | +3.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +20 | +19.8 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| CASTING BLOCK | 5 | 5 | 1 | 0.33 | +2 | +1.8 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +10 | +9.7 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 27 | 27 | 1 | 0.33 | +3 | +2.6 |
| HIS TURN DENIED | 7 | 6 | 1 | 0.33 | +2 | +1.9 |
| HONEST WORTH | 22 | 20 | 1 | 0.33 | +18 | +17.7 |
| LONG SHOT | 7 | 7 | 1 | 0.33 | +2 | +1.8 |
| LOST AFTER ESCAPE | 17 | 16 | 1 | 0.33 | +2 | +1.9 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +4 | +4.1 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 24 | 22 | 1 | 0.33 | +36 | +36.2 |
| ONE FIGHT FORMULA | 39 | 25 | 1 | 0.33 | +27 | +27.4 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -14 | -14.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -3 | -2.6 |
| REDIRECT COUNTER | 19 | 15 | 1 | 0.33 | +41 | +41.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +65 | +65.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +16 | +16.2 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| WOUNDS ON THE RANKS | 13 | 13 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 4 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 63 | 63 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 24 | 23 | 0 | 0.00 | - | - |
| FALLS SHORT | 53 | 45 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 11 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 35 | 35 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 12 | 12 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 13 | 13 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 49 | 46 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 11 | 10 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 44 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 17 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 94 | 94 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 5 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 19 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 11 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 247 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 7 | 7 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 15 | 14 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 40 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 40 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 184 | 179 | 0 | 0.00 | - | - |
| STAY WORTH | 87 | 74 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | not checked | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 239 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p34

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 7.33 | 74.6 |
| JOB FIRST | gate | 2.00 | 4.33 | 26.9 |
| ARMY TABLE | rule | 2.67 | 2.00 | 90.8 |
| CHARGE NOW FIRST | rule | - | 2.00 | 25.4 |
| PROMISE SHOT AWAY | rule | 0.67 | 1.33 | 1.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.33 | 3.1 |
| RULE SWITCHED OFF | gate | - | 1.33 | 11.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 1.00 | 69.3 |
| JOINT CHARGE NOW | rule | - | 0.67 | 120.7 |
| SUPPORT NARROWED | rule | 0.67 | - | 79.8 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| FIGHT ORDER BAND | gate | 0.33 | - | 3.6 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 68.3 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 14.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 2.6 |

### Plans: cnsr-c940641-p34

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 25 | 111 | 450% |
| Mine | move | 28.3 | 88% | 1969 | 0 | 0% |
| Mine | shoot | 6.3 | 47% | 628 | 187 | 30% |
| Mine | support | 0.7 | 50% | 0 | 0 | - |
| Opponent | charge | 7.0 | 62% | 1501 | 1016 | 68% |
| Opponent | join | 2.0 | 100% | 76 | 0 | 0% |
| Opponent | move | 32.3 | 98% | 1748 | 0 | 0% |
| Opponent | shoot | 4.7 | 79% | 705 | 407 | 58% |

### Battle groups: cnsr-c940641-p34

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 27% | 67% | 0% | - | 67% | 0% | 0% | 33% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 38% | 67% | 0% | - | 67% | 0% | 0% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p34

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 29 (7) | 20 | 9 | 66 | 29% | 2.2 | 33 (6) | 0 (1) | - | 29 (7) | - |
| Mine | Character | 8 | 7 (8) | 7 | 0 | 104 | 0% | 2.4 | 0 (2) | - | 0 (1) | - | 0 (3) |
| Mine | Clean-up | 4 | 138 (4) | 41 | 97 | 31 | 25% | 5.3 | 142 (2) | 47 (1) | 553 (1) | 125 (1) | 144 (3) |
| Mine | Fast Hammer | 1 | 31 (1) | 31 | 0 | 0 | 0% | 3.0 | 31 (1) | - | - | - | 31 (1) |
| Mine | Hammer | 11 | 37 (11) | 35 | 3 | 70 | 0% | 1.8 | 10 (3) | 54 (7) | 0 (1) | 32 (4) | 41 (7) |
| Mine | Shooter | 3 | 23 (3) | 23 | 0 | 0 | 0% | 2.0 | 0 (2) | 69 (1) | - | 0 (1) | 35 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 126 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 8 | 109 (8) | 11 | 98 | 49 | 12% | 1.9 | 63 (2) | 157 (4) | 53 (2) | 148 (5) | 34 (3) |
| Opponent | Character | 8 | 108 (8) | 108 | 0 | 13 | 12% | 2.6 | 103 (4) | 133 (3) | - | 152 (3) | 92 (4) |
| Opponent | Clean-up | 4 | 43 (4) | 43 | 0 | 47 | 50% | 5.5 | 0 (2) | 57 (2) | - | 0 (2) | 57 (2) |
| Opponent | Fast Hammer | 7 | 54 (7) | 54 | 0 | 42 | 14% | 3.5 | 20 (2) | 79 (5) | - | 21 (4) | 77 (3) |
| Opponent | Holder | 4 | 136 (4) | 0 | 136 | 0 | 0% | 2.5 | 300 (2) | 0 (1) | 0 (1) | 188 (3) | 0 (1) |
| Opponent | Shooter | 4 | 38 (4) | 38 | 0 | 0 | 25% | 1.7 | 0 (2) | 76 (2) | - | 154 (2) | 0 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |

### Charged fights: cnsr-c940641-p34

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 335 | 66 | 2.0 | 1.5 | 33 | 0 | +33 | 0 of 2 | 2 of 2 | +66 | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 202 | -202 | 1 of 2 | 0 of 2 | - | -202 |
| Mine | Skaven | 1 | 45 | 254 | 1.0 | 1.0 | 254 | 0 | +254 | 1 of 1 | 1 of 1 | - | +254 |
| **Mine** | all armies | 3 | 127 | 107 | 1.7 | 1.2 | 64 | 81 | -17 | 2 of 5 | 3 of 5 | +66 | -38 |
| Opponent | Tomb Kings of Khemri | 2 | 162 | 1036 | 5.5 | 1.2 | 188 | 18 | +171 | 6 of 11 | 9 of 11 | +718 | +49 |
| Opponent | Vampire Counts | 1 | 0 | 1172 | 5.0 | 1.2 | 234 | 92 | +142 | 2 of 5 | 4 of 5 | +540 | +43 |
| **Opponent** | all armies | 3 | 108 | 1081 | 5.3 | 1.2 | 203 | 41 | +162 | 8 of 16 | 13 of 16 | +658 | +47 |

### Effective charges: cnsr-c940641-p34

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +66) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 1 (net -55) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +254) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 11 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +444) | 2 (net +94) | 4 (net +201) | 1 | 10% (1 of 10) |
| Opponent | Vampire Counts | 5 | 1 (net -231) | 0 | 0 | 1 (net +540) | 1 (net +0) | 1 (net +210) | 1 | 0% (0 of 4) |

### Charged fights, damage counted: cnsr-c940641-p34

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 68 | 66 | +66 | 66 | 26 | +40 | +59.6 |
| Mine | 76-89% | 1 | 55 | 66 | -55 | 0 | 55 | -55 | -100.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 197 | 254 | +254 | 254 | 26 | +228 | +115.6 |
| Mine | No odds | 2 | 192 | 246 | -175 | 0 | 184 | -184 | -95.6 |
| Mine | All fights | 5 | 141 | 175 | -17 | 64 | 95 | -31 | -21.8 |
| Opponent | Long shot (under 50%) | 2 | 122 | 166 | -116 | 150 | 294 | -144 | -117.4 |
| Opponent | Effective (55-75%) | 1 | 195 | 185 | +0 | 0 | 65 | -65 | -33.3 |
| Opponent | 76-89% | 3 | 418 | 259 | +476 | 483 | 12 | +471 | +112.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 387 | 262 | +203 | 344 | 98 | +246 | +63.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 261 | 58 | +62 | 69 | 0 | +69 | +26.3 |
| Opponent | No odds | 2 | 456 | 214 | +96 | 182 | 0 | +182 | +40.0 |
| Opponent | All fights | 16 | 333 | 200 | +162 | 252 | 73 | +179 | +53.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p34 | move | 26 | 4 (15%) | 3 (12%) | 5 (19%) | 17 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

# Doctrine scorecard: cnsr-c940641-p35

### Scorecard: cnsr-c940641-p35

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 4 | - | 0 | 2 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 127 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 1 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 0 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 2 | 1 | 2 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 2.0 | 3.0 | 3.0 | 1.7 | 0.0 | 0.0 | 0.0 | 209.0 |
| **Average** | | | Opponent | 0% | 1.0 | 1.5 | 2.0 | 3.0 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: cnsr-c940641-p35

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (4 of 14) | 0% (0 of 17) | 13% (4 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (2 of 2); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 67% | 100% (2 of 2); on the table 100% | 75% (6 of 8); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 6) | 39% (7 of 18) | 29% (7 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 2) | 39% (7 of 18) | 35% (7 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (5 of 10) | 67% (6 of 9) | 58% (11 of 19) |
| Points that never fought | lower | 55% (3296 of 5999) | 57% (3435 of 6000) | 56% (6731 of 11999) |
|   infantry points that never fought | lower | 93% (1440 of 1552) | 75% (775 of 1035) | 86% (2215 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (13 of 19) | 70% (21 of 30) | 69% (34 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 50% (1 of 2); 1.3 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (2970 of 4484) | 60% (3318 of 5546) | 63% (6288 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (100%) | 3.7 (65%) |
| MARCHED: its unit marched | 0.7 (33%) | 0.0 (0%) | 0.7 (12%) |
| GONE: slain | 1.3 (67%) | 0.0 (0%) | 1.3 (24%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 10.0 | 1.7 | 1.0 | 2.3 | 0.7 | 0.0 |
| not cast | 4.0 | 0.3 | 1.0 | 5.7 | 1.3 | 16.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 3.7 (65%) | 1.0 (75%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (33%) | 0.0 (0%) | 0.0 (0%) | 1.3 (24%) | 0.0 (0%) | 3.0 (19%) |
| STUPIDITY: Stupidity | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (58%) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 33% (1 of 3) | 33% (1 of 3) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (75 of 107) | 72% (23 of 32) | 71% (98 of 139) |
|   cavalry | 100% (14 of 14) | 73% (11 of 15) | 86% (25 of 29) |
|   character | 0% (0 of 17) | 33% (2 of 6) | 9% (2 of 23) |
|   chariot | 92% (12 of 13) | - | 92% (12 of 13) |
|   infantry | 78% (49 of 63) | 91% (10 of 11) | 80% (59 of 74) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (3%) | 1.7 (56%) | 2.0 (15%) |
| CHARGED: it charged | 2.3 (22%) | 0.7 (22%) | 3.0 (22%) |
| NO TARGET IN RANGE | 4.3 (41%) | 0.0 (0%) | 4.3 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (12%) | 0.0 (0%) | 1.3 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (22%) | 0.7 (22%) | 3.0 (22%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.3 | 2.0 | 86% | 3.9 pts | 55 pts |
| character | 0.7 | 0.3 | 50% | 2.6 pts | 2 pts |
| chariot | 4.0 | 0.7 | 83% | 1.2 pts | 5 pts |
| infantry | 23.0 | 9.3 | 74% | 10.4 pts | 239 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 2.7 | 3.5 |
| Charges that made contact a game | 3.0 | 2.0 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.28 contact (32 units) | 0.29 declared, 0.21 contact (24 units) | 0.36 declared, 0.25 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 100% (1 of 1) | 0% (0 of 1) | 56% (5 of 9) |
| Character in a unit | 100% (4 of 4) | 100% (1 of 1) | - | 100% (5 of 5) |
| Character on its own | 100% (4 of 4) | - | 50% (4 of 8) | 67% (8 of 12) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 64% (7 of 11) | 100% (1 of 1) | - | 67% (8 of 12) |
| Monster | 83% (5 of 6) | 0% (0 of 1) | - | 71% (5 of 7) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 60% | 67% (6 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 33% (1 of 3); on the table 33% | - | 52% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 59% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 56% | 92% (11 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 83% (5 of 6) | 57% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p35, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 33% (1) | 57% (4) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: cnsr-c940641-p35

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 36% (4 of 11) | 33% (2 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 76% (16 of 21) | 18% (2 of 11) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 44% (4 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 3.0 |
| Movement | Points that never moved of their own | 209.0 | 56.7 |
| Movement | Fights charged into per game | 3.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net -70 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +0 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 7, net +114 | 1 of 4, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 7, net +197 | 3 of 4, net +245 |
| Shooting | Shots by shooting units (incl. breath weapons) | 26.7 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (18 of 80) | 79% (19 of 24) |
| Shooting | Points destroyed by shooting units | 41.7 | 48.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 67% (2 of 3) |
| Magic | Wounds caused by magic missiles | - | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.3 / 0.0 / 0.0 / 0.0 | 2.7 / 1.3 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 171.7 | 494.3 |
| Combat | Points run down | 287.7 | 30.7 |
| Combat | Net points per charged fight, damage counted | +59 | +102 |
| Combat | Net per 100 charger points, damage counted | +20.6 | +30.3 |
| Combat | First round won (charged fights) | 89% | 100% |
| Combat | Net points per charged fight | +48 | +102 |
| Combat | Net points per supported fight / lone fight | - / +48 | +540 / -7 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 9 | 4 of 5 |
| Game | Points lost | 506.7 | 497.7 |
| Game | VP from objectives | 1046.7 | 530.0 |
| Game | Lone holders (player turns) | 2.0 | 1.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +531 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1004
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p35

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 35.3 | +824.9 | 0.0 | 0.0 | 27.0 | +206.7 | 0.0 | 313.0 |
| BACKUP TARGETS | 0.3 | +0.6 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 4.0 | +11.0 | 96.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.3 | +5.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +10.9 | 0.0 | 0.0 | 0.7 | +4.3 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -0.6 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.7 | -342.5 | 0.0 | 180.0 | 17.0 | -476.5 | 0.0 | 547.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 141.3 | 180.0 | 1.3 | +0.0 | 245.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 618.7 | 12.3 | +0.0 | 0.0 | 124.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +51.7 | 0.0 | 0.0 |
| COVER ONCE | 9.7 | -437.9 | 0.0 | 210.7 | 9.7 | -436.7 | 0.0 | 78.0 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +5.2 | 0.0 | 23.3 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 3.7 | +81.1 | 0.0 | 125.0 |
| EXACT ROUND | 2.0 | +14.5 | 124.7 | 180.0 | 1.7 | +51.1 | 202.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +51.4 | 168.3 | 180.0 | 1.3 | +1.1 | 382.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 2.0 | +12.7 | 0.0 | 22.0 | 17.3 | +235.5 | 0.0 | 155.0 |
| FEATURE BUFFS | 2.0 | +9.7 | 0.0 | 48.0 | 2.0 | +5.4 | 0.0 | 83.7 |
| FIGHT TO THE END | 0.7 | +7.2 | 0.0 | 180.0 | 0.7 | +8.0 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 110.0 | +9158.0 | 446.3 | 1493.0 | 89.0 | +4038.7 | 543.0 | 834.3 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 180.0 | 10.0 | +0.0 | 0.0 | 83.7 |
| FOCUS FIRE | 0.3 | +18.0 | 38.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +111.9 | 0.0 | 180.0 | - | - | - | - |
| FOUR ROUNDS | 4.3 | +316.7 | 255.0 | 203.3 | 2.3 | +69.6 | 447.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 70.0 |
| FRIEND SHOOTS FIRST | 0.7 | -8.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -5.4 | 0.0 | 23.3 | - | - | - | - |
| GOAL WALK | 15.7 | +2007.1 | 0.0 | 850.0 | 3.3 | +136.5 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 5.7 | +0.0 | 0.0 | 70.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 180.0 | 13.3 | +0.0 | 0.0 | 423.7 |
| HIS CHARGE DENIED | 0.7 | +2.8 | 30.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 9.0 | +0.0 | 0.0 | 130.0 | 5.7 | +0.0 | 0.0 | 251.0 |
| HIS LEGAL MOVES | 8.0 | +0.0 | 0.0 | 241.3 | 4.0 | +0.0 | 0.0 | 154.0 |
| HIS MOVE AND SHOT | 3.0 | -14.9 | 0.0 | 0.0 | 4.0 | -61.5 | 0.0 | 77.0 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 10.3 | +0.0 | 0.0 | 241.3 | 6.3 | +0.0 | 0.0 | 154.0 |
| HIS RANDOM MOVE | 19.3 | +0.0 | 0.0 | 48.0 | 7.0 | +0.0 | 0.0 | 124.0 |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 48.0 | 2.0 | +0.0 | 0.0 | 124.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 43.3 | +749.3 | 0.0 | 521.3 | 56.3 | +1468.6 | 0.0 | 684.3 |
| HIS SHOTS BY HIS RUN | 30.3 | +323.2 | 0.0 | 222.0 | 52.0 | +805.2 | 0.0 | 741.0 |
| HIS TURN DENIED | 0.7 | +4.5 | 38.0 | 0.0 | 0.3 | +4.8 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 24.0 | +0.0 | 0.0 | 262.7 | 15.3 | +0.0 | 0.0 | 334.7 |
| HOLDER ASSIGNMENT | 15.3 | +1055.3 | 0.0 | 131.3 | 9.7 | +760.8 | 0.0 | 214.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -89.2 | 255.0 | 180.0 | 2.0 | -58.9 | 267.0 | 0.0 |
| HUNT IN PAIRS | 1.7 | +15.0 | 0.0 | 65.0 | - | - | - | - |
| IDLE COST | 2.0 | -38.9 | 0.0 | 65.0 | 15.0 | -137.5 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.7 | -63.3 | 98.7 | 0.0 | 0.7 | +120.8 | 360.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 8.0 | +0.0 | 286.0 | 384.0 | 4.7 | +0.0 | 0.0 | 114.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.7 | +3.9 | 15.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +1.4 | 130.3 | 180.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -39.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -1.9 | 0.0 | 0.0 | 0.3 | -2.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +9.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -79.9 | 0.0 | 180.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +20.6 | 0.0 | 0.0 | 2.0 | +15.3 | 0.0 | 15.0 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +19.2 | 0.0 | 0.0 | 6.0 | +55.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.3 | +28.3 | 0.0 | 360.0 | 6.7 | +43.6 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 180.0 | 180.0 | 3.3 | +0.0 | 0.0 | 38.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.7 | -68.1 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.0 | +1221.1 | 0.0 | 0.0 | 7.3 | +597.7 | 0.0 | 154.0 |
| NEARER NOT NEEDED | 14.7 | +594.1 | 0.0 | 22.0 | 6.7 | +216.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 5.0 | +941.6 | 0.0 | 0.0 | 6.3 | +521.9 | 0.0 | 154.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -4.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.0 | -134.4 | 255.0 | 180.0 | 1.3 | -155.1 | 425.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 180.0 | - | - | - | - |
| OFF BEST | 7.0 | -149.5 | 46.7 | 87.0 | 9.3 | -301.6 | 0.0 | 84.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.0 | -71.1 | 0.0 | 0.0 | 6.0 | -70.5 | 0.0 | 115.0 |
| ONE JOINT FIGURE | 0.3 | +11.0 | 83.7 | 0.0 | 0.3 | +20.5 | 180.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.3 | +26.3 | 0.0 | 76.7 | 4.7 | -74.8 | 0.0 | 83.7 |
| ONE PROMISE A TARGET | 0.3 | -78.0 | 0.0 | 0.0 | 0.3 | -3.2 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +22.3 | 38.0 | 0.0 | 0.3 | +13.5 | 22.0 | 0.0 |
| OVERRUNS AWAY | 1.3 | +14.6 | 83.7 | 0.0 | 0.3 | +4.1 | 65.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +40.7 | 0.0 | 0.0 |
| PLAN RESULT | 50.0 | +468.1 | 193.0 | 737.0 | 46.3 | +519.5 | 526.0 | 665.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.7 | -442.9 | 0.0 | 130.0 | 11.3 | -454.7 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | -11.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -48.5 | 0.0 | 0.0 |
| QUARTER ODDS | 26.7 | +2245.5 | 76.7 | 23.3 | 28.3 | +2378.7 | 0.0 | 83.3 |
| RANDOM MOVE BY FIGURES | 3.3 | +107.8 | 0.0 | 48.3 | 3.0 | +23.2 | 0.0 | 56.7 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.0 | +17.2 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.7 | +171.9 | 0.0 | 46.0 | 2.3 | +55.5 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | 6.3 | +28.2 | 0.0 | 22.0 | 2.0 | +0.0 | 0.0 | 15.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +7.6 | 30.7 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -10.5 | 0.0 | 0.0 | 0.7 | -2.3 | 0.0 | 30.0 |
| RESERVE FALL BACK | 0.7 | +21.1 | 0.0 | 0.0 | 1.0 | +39.3 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | -63.3 | 255.0 | 203.3 | 2.0 | -22.6 | 447.0 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -45.6 | 168.3 | 0.0 | - | - | - | - |
| RUN DOWN | 2.3 | -104.0 | 168.3 | 180.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 22.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 22.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -18.1 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +3.5 | 0.0 | 0.0 | 0.7 | +29.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +61.3 | 46.7 | 180.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -8.0 | 0.0 | 0.0 | 1.7 | -58.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +17.1 | 0.0 | 0.0 | 5.0 | -101.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 46.7 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +27.3 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -19.8 | 94.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 23.0 | -139.7 | 0.0 | 68.7 | 25.0 | -222.0 | 0.0 | 646.0 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 25.3 | +418.9 | 0.0 | 46.0 | 7.0 | +97.3 | 0.0 | 84.7 |
| SPELL WORTH | 0.3 | +0.8 | 180.0 | 180.0 | 3.7 | +5.0 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -51.2 | 180.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 109.7 |
| STAND AND SHOOT | 1.3 | -4.7 | 38.0 | 180.0 | 0.3 | -0.5 | 22.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 44.0 | +0.0 | 191.3 | 187.0 | 35.3 | +0.0 | 96.0 | 177.0 |
| STAY WORTH | 18.3 | +109.1 | 191.3 | 0.0 | 7.7 | +48.8 | 96.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +11.4 | 56.7 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +8.9 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.0 | +309.3 | 0.0 | 61.3 | 3.3 | +70.5 | 0.0 | 40.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 15.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 8.0 | +309.3 | 0.0 | 61.3 | 3.3 | +70.5 | 0.0 | 40.0 |
| SURE REACH TOGETHER | 0.3 | +0.6 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -51.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 15.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 167.3 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 65.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 15.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 65.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 51.0 | +0.0 | 0.0 | 620.7 | 45.7 | +0.0 | 0.0 | 327.0 |
| TIED UP BY THE SUM | 1.3 | +170.7 | 141.3 | 0.0 | 0.7 | +50.0 | 22.0 | 0.0 |
| TIME ON OUR SIDE | 50.0 | +406.7 | 96.7 | 519.0 | 12.3 | +94.1 | 0.0 | 46.7 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | -0.3 | 30.0 | 0.0 | 0.3 | +4.4 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 1.0 | +78.5 | 0.0 | 56.7 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -179.6 | 0.0 | 180.0 | 2.7 | -120.9 | 0.0 | 76.0 |
| WHOLE FIGHT GAIN | 0.3 | +96.2 | 83.7 | 0.0 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.3 | +0.5 | 0.0 | 0.0 | 4.7 | +91.0 | 0.0 | 251.0 |

### Rule changes: cnsr-c940641-p35

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 187 | 187 | 132 | 44.00 | +3099 | +23.5 |
| HIS SHOT LIST | 299 | 279 | 79 | 26.33 | +700 | +8.9 |
| HOLDER ASSIGNMENT | 75 | 75 | 69 | 23.00 | +3600 | +52.2 |
| OFF BEST | 49 | 49 | 49 | 16.33 | -1353 | -27.6 |
| HIS SHOTS BY HIS RUN | 247 | 230 | 40 | 13.33 | +273 | +6.8 |
| LEGAL CHARGES ONLY | 38 | 38 | 38 | 12.67 | +0 | +0.0 |
| FIVE ACTION | 597 | 569 | 32 | 10.67 | +1291 | +40.3 |
| QUARTER ODDS | 165 | 159 | 30 | 10.00 | +1367 | +45.6 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 63 | 63 | 28 | 9.33 | -2693 | -96.2 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| REDIRECT FOR A FRIEND IN REACH | 25 | 25 | 24 | 8.00 | +68 | +2.8 |
| MOVE TO CHARGE COMPUTED | 43 | 33 | 21 | 7.00 | +1233 | +58.7 |
| NEXT CHARGE BY LIST | 34 | 28 | 17 | 5.67 | +1077 | +63.3 |
| TIME ON OUR SIDE | 187 | 163 | 17 | 5.67 | +61 | +3.6 |
| GOAL WALK | 57 | 57 | 14 | 4.67 | +1114 | +79.5 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| SHOT RISK POINTS | 144 | 132 | 12 | 4.00 | +356 | +29.6 |
| SUPPORT ADDS | 34 | 33 | 12 | 4.00 | +561 | +46.8 |
| SUPPORT WORKED OUT | 34 | 33 | 12 | 4.00 | +561 | +46.8 |
| RANDOM MOVE BY FIGURES | 19 | 19 | 11 | 3.67 | +393 | +35.7 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FOUR ROUNDS | 20 | 18 | 9 | 3.00 | +253 | +28.1 |
| THE RISK READS HIS RUN | 18 | 18 | 9 | 3.00 | +0 | +0.0 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 51 | 30 | 8 | 2.67 | +29 | +3.6 |
| SET UP BY THE SET | 18 | 18 | 8 | 2.67 | +156 | +19.5 |
| CHARGE LOSSES | 89 | 77 | 7 | 2.33 | +1202 | +171.7 |
| EVASIVE BY THE ODDS | 11 | 11 | 7 | 2.33 | +220 | +31.4 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| STAY WORTH | 78 | 73 | 6 | 2.00 | +34 | +5.7 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +181 | +36.3 |
| TIED UP BY THE SUM | 6 | 5 | 5 | 1.67 | +109 | +21.8 |
| WHOLE FIGHT DANGER | 14 | 12 | 5 | 1.67 | +378 | +75.6 |
| CAST JOB | 12 | 12 | 4 | 1.33 | +1 | +0.3 |
| COVER ONCE | 58 | 33 | 4 | 1.33 | +52 | +13.1 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +172 | +43.1 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| PROMISE KNOWS THE FIGHT | 8 | 7 | 4 | 1.33 | -33 | -8.2 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +336 | +111.9 |
| NO DOUBLE ROUNDS | 16 | 14 | 3 | 1.00 | +91 | +30.4 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +122 | +40.7 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +99 | +32.9 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| SUPPORT NARROWED | 3 | 3 | 3 | 1.00 | -74 | -24.7 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +138 | +45.9 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -2 | -0.9 |
| CHARGE NOW FIRST | 11 | 11 | 2 | 0.67 | -7 | -3.7 |
| EXACT ROUND | 11 | 10 | 2 | 0.67 | +25 | +12.7 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -243 | -121.7 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +30 | +15.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +184 | +92.0 |
| SHOTS IN THE MOVE | 97 | 77 | 2 | 0.67 | +116 | +58.1 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 17 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +10 | +10.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 11 | 9 | 1 | 0.33 | +44 | +44.3 |
| FIGHT TO THE END | 4 | 3 | 1 | 0.33 | +15 | +14.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +54 | +54.1 |
| HONEST WORTH | 18 | 16 | 1 | 0.33 | +28 | +28.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -35 | -34.6 |
| MAX FOR POSITIONING | 11 | 9 | 1 | 0.33 | +2 | +2.5 |
| NEARER NOT NEEDED | 64 | 59 | 1 | 0.33 | +43 | +42.9 |
| ONE FIGHT FORMULA | 30 | 19 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +28 | +27.6 |
| ONE OBJECTIVE FORMULA | 39 | 29 | 1 | 0.33 | +40 | +39.7 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -81 | -80.8 |
| REDIRECT COUNTER | 18 | 14 | 1 | 0.33 | +74 | +74.5 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +65 | +64.7 |
| RISK BY ARC | 18 | 16 | 1 | 0.33 | +16 | +15.9 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 1 | 0.33 | +4 | +3.9 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +34 | +34.2 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +27 | +26.7 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.5 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +28 | +27.6 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 4 | 4 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 58 | 48 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 12 | 12 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 27 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 17 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 65 | 56 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 44 | 43 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 36 | 31 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 21 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 39 | 35 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 50 | 43 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 79 | 74 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 16 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 118 | 117 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 5 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 21 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 289 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 38 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 13 | 13 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 238 | 228 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 290 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 8 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 15 | 15 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p35

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.67 | 9.00 | 28.4 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 5.33 | 96.2 |
| ARMY TABLE | rule | 4.33 | 4.33 | 49.7 |
| SUPPORT NARROWED | rule | 0.33 | 0.67 | 24.7 |
| CHARGE NOW FIRST | rule | 0.67 | - | 3.7 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 4.0 |
| JOINT CHARGE NOW | rule | 0.67 | - | 95.0 |
| ONE PROMISE A TARGET | rule | 0.33 | 0.33 | 121.7 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 16.5 |
| CHAFF PASSED | rule | - | 0.33 | 1.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 34.6 |
| NO REASON | gate | 0.33 | - | 6.6 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 80.8 |
| RULE SWITCHED OFF | gate | - | 0.33 | 12.8 |

### Plans: cnsr-c940641-p35

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 75% | 594 | 351 | 59% |
| Mine | move | 41.0 | 96% | 2875 | 0 | 0% |
| Mine | shoot | 4.3 | 38% | 251 | 117 | 47% |
| Mine | support | 0.7 | 100% | 15 | 0 | 0% |
| Opponent | charge | 2.0 | 83% | 180 | 447 | 248% |
| Opponent | join | 5.7 | 94% | 271 | 0 | 0% |
| Opponent | move | 35.3 | 94% | 1199 | 0 | 0% |
| Opponent | shoot | 2.7 | 62% | 119 | 72 | 61% |
| Opponent | support | 0.7 | 100% | 4 | 0 | 0% |

### Battle groups: cnsr-c940641-p35

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 9% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 29% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p35

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 38 (6) | 31 | 7 | 34 | 17% | 1.0 | - | 45 (5) | 0 (1) | 45 (5) | 0 (1) |
| Mine | Character | 7 | 54 (7) | 54 | 0 | 45 | 29% | 2.4 | 123 (2) | 0 (1) | 23 (4) | 75 (4) | 0 (3) |
| Mine | Clean-up | 1 | 695 (1) | 110 | 585 | 0 | 0% | 5.0 | - | 695 (1) | - | - | 695 (1) |
| Mine | Fast Hammer | 6 | 0 (6) | 0 | 0 | 29 | 50% | 4.0 | 0 (4) | 0 (2) | - | - | 0 (6) |
| Mine | Hammer | 5 | 63 (5) | 36 | 26 | 16 | 20% | 1.5 | 66 (3) | 59 (2) | - | 50 (2) | 69 (3) |
| Mine | Holder | 8 | 91 (8) | 0 | 91 | 15 | 25% | 2.5 | 224 (2) | 66 (5) | 0 (1) | 224 (2) | 50 (6) |
| Mine | Shooter | 5 | 86 (5) | 0 | 86 | 0 | 0% | 1.6 | 0 (2) | 195 (3) | - | 101 (4) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 25 (4) | 0 | 25 | 19 | 50% | 3.0 | 33 (3) | - | 0 (1) | 33 (3) | 0 (1) |
| Opponent | Character | 11 | 58 (11) | 58 | 0 | 20 | 55% | 2.6 | 81 (2) | 81 (7) | 0 (1) | 66 (6) | 77 (4) |
| Opponent | Fast Hammer | 6 | 24 (6) | 7 | 17 | 35 | 33% | 2.2 | - | 25 (5) | 19 (1) | 6 (3) | 36 (3) |
| Opponent | Hammer | 8 | 7 (8) | 7 | 0 | 29 | 62% | 3.7 | 0 (3) | 11 (5) | - | 9 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 67% | 4.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | Shooter | 3 | 115 (3) | 0 | 115 | 70 | 0% | 1.3 | - | 106 (2) | 136 (1) | 156 (2) | 26 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: cnsr-c940641-p35

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 45 | 2.0 | 1.0 | 22 | 0 | +22 | 0 of 2 | 2 of 2 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 62 | 498 | 3.5 | 1.0 | 142 | 87 | +55 | 3 of 7 | 6 of 7 | - | +55 |
| **Mine** | all armies | 3 | 42 | 347 | 3.0 | 1.0 | 116 | 68 | +48 | 3 of 9 | 8 of 9 | - | +48 |
| Opponent | Vampire Counts | 1 | 145 | 540 | 2.0 | 1.5 | 270 | 0 | +270 | 2 of 2 | 2 of 2 | +540 | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 290 | -290 | 1 of 1 | 1 of 1 | - | -290 |
| Opponent | Wood Elf Realms | 1 | 0 | 261 | 2.0 | 1.0 | 130 | 0 | +130 | 1 of 2 | 2 of 2 | - | +130 |
| **Opponent** | all armies | 3 | 48 | 267 | 1.7 | 1.2 | 160 | 58 | +102 | 4 of 5 | 5 of 5 | +540 | -7 |

### Effective charges: cnsr-c940641-p35

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +22) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net -70) | 0 | 1 (net +0) | 0 | 1 (net +114) | 2 (net +372) | 2 | 20% (1 of 5) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +270) | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +66) | 1 (net +195) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cnsr-c940641-p35

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 70 | 499 | -70 | 0 | 70 | -70 | -100.0 |
| Mine | Effective (55-75%) | 1 | 195 | 102 | +0 | 108 | 65 | +42 | +21.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 254 | 123 | +197 | 225 | 15 | +210 | +82.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 114 | +114 | 114 | 0 | +114 | +26.5 |
| Mine | No odds | 2 | 436 | 320 | -200 | 81 | 278 | -196 | -45.1 |
| Mine | All fights | 9 | 287 | 205 | +48 | 143 | 84 | +59 | +20.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 355 | 282 | +245 | 245 | 0 | +245 | +69.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 66 | +66 | 66 | 0 | +66 | +13.2 |
| Opponent | No odds | 1 | 120 | 431 | -290 | 0 | 290 | -290 | -241.7 |
| Opponent | All fights | 5 | 337 | 268 | +102 | 160 | 58 | +102 | +30.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p35 | move | 19 | 2 (11%) | 1 (5%) | 2 (11%) | 15 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

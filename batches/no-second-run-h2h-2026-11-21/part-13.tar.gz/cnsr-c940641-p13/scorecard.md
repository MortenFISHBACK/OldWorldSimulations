# Doctrine scorecard: cnsr-c940641-p13

### Scorecard: cnsr-c940641-p13

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 1064 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 2 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 0 | 2 | 0 | 0 | 0 | 403 |
| **Average** | | | Mine | 0% | 2.0 | - | 0.3 | 1.3 | 0.3 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 0% | 0.0 | 4.0 | 0.3 | 1.7 | 0.3 | 0.0 | 0.0 | 489.0 |

### KPIs: cnsr-c940641-p13

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 8) | 65% (11 of 17) | 44% (11 of 25) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | - | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 62% (56 of 90) | - | 62% (56 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (56 of 83) | - | 67% (56 of 83) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 83% (5 of 6) | - | 83% (5 of 6) |
| Points that never fought | lower | 47% (2664 of 5699) | 78% (4657 of 6000) | 63% (7321 of 11699) |
|   infantry points that never fought | lower | 52% (1163 of 2239) | 95% (2011 of 2111) | 73% (3174 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (9 of 16) | 56% (14 of 25) | 56% (23 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.7 uses a game | 0.0 uses a game | 100% (4 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (1758 of 3916) | 49% (2154 of 4382) | 47% (3912 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.7 (41%) | - | 4.7 (41%) |
| MARCHED: its unit marched | 4.3 (38%) | - | 4.3 (38%) |
| IN COMBAT: engaged in combat | 2.0 (18%) | - | 2.0 (18%) |
| GONE: slain | 0.3 (3%) | - | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.0 | 7.0 | 18.7 | 0.3 | 2.0 |
| not cast | 1.7 | 3.0 | 3.0 | 11.3 | 1.7 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (56%) | 0.0 (0%) | 4.7 (41%) | 1.3 (80%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (38%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (22%) | 2.0 (18%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (100%) | 1.3 (44%) | 2.3 (78%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.0 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.7 a game | 0.0 a game | 4.3 a game |
| stood (cast and not dispelled) | 65% (17 of 26) | - | 65% (17 of 26) |
| the unit moved after it | 59% (10 of 17) | - | 59% (10 of 17) |
| it charged on its next turn | 0% (0 of 17) | - | 0% (0 of 17) |
| the enemy charged it first | 6% (1 of 17) | - | 6% (1 of 17) |
| it fought by the end of its next turn | 0% (0 of 17) | - | 0% (0 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 6% (1 of 17) | - | 6% (1 of 17) |
| none of these (no charge, no fight, no charge escaped) | 88% (15 of 17) | - | 88% (15 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 55% (12 of 22) | 57% (116 of 202) | 57% (128 of 224) |
|   cavalry | - | 54% (19 of 35) | 54% (19 of 35) |
|   character | - | 60% (12 of 20) | 60% (12 of 20) |
|   chariot | - | 67% (4 of 6) | 67% (4 of 6) |
|   infantry | 55% (12 of 22) | 59% (38 of 64) | 58% (50 of 86) |
|   monster | - | 60% (6 of 10) | 60% (6 of 10) |
|   war machine | - | 55% (37 of 67) | 55% (37 of 67) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (70%) | 1.7 (6%) | 4.0 (12%) |
| CHARGED: it charged | 0.0 (0%) | 3.0 (10%) | 3.0 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| NO TARGET IN RANGE | 0.7 (20%) | 9.7 (34%) | 10.3 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.3 (5%) | 1.3 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (10%) | 7.7 (27%) | 8.0 (25%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (2%) | 0.7 (2%) |
| OTHER BAR | 0.0 (0%) | 4.3 (15%) | 4.3 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.7 | 2.3 | 79% | 2.9 pts | 28 pts |
| character | 4.0 | 6.0 | 42% | 24.0 pts | 96 pts |
| chariot | 1.3 | 0.7 | 50% | 4.0 pts | 5 pts |
| infantry | 24.3 | 10.0 | 70% | 7.4 pts | 181 pts |
| monster | 2.0 | 0.3 | 83% | 1.3 pts | 3 pts |
| war machine | 12.3 | 11.0 | 51% | 13.5 pts | 166 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 4.7 | 2.7 |
| Charges that made contact a game | 0.7 | 4.0 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (20 units) | 0.52 declared, 0.44 contact (27 units) | 0.34 declared, 0.30 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 75% (3 of 4) | 25% (1 of 4) | - | 50% (4 of 8) |
| Character on its own | 100% (2 of 2) | 100% (2 of 2) | 0% (0 of 2) | 67% (4 of 6) |
| Infantry | 43% (3 of 7) | 43% (3 of 7) | - | 43% (6 of 14) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 67% (2 of 3); on the table 67% | 62% (56 of 90) | 47% | 56% (9 of 16) | 100% (4 of 4); 4.7 uses a game | 100% (2 of 2); 1.7 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | 50% (1 of 2); on the table 50% | - | 83% | 60% (12 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | - | 66% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p13, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 17% (1) | 50% (1) | 25% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnsr-c940641-p13

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 77% (10 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (4 of 13) | 35% (26 of 74) |
| Strategy | Support requests answered (helper made contact too) | - | 67% (2 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 75% (9 of 12) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 0% (0 of 6) | 50% (1 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 1.7 |
| Movement | Points that never moved of their own | 0.0 | 489.0 |
| Movement | Fights charged into per game | 0.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net +0 | 2 of 8, net -52 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 8 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 8, net -65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 3 of 8, net +131 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.3 | 28.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (4 of 13) | 62% (52 of 84) |
| Shooting | Points destroyed by shooting units | 0.0 | 296.0 |
| Shooting | War machine shots | - | 12.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 62% (23 of 37) |
| Shooting | Points destroyed by war machines | 0.0 | 77.3 |
| Magic | Magic missiles cast | 9.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 63% (17 of 27) | - |
| Magic | Wounds caused by magic missiles | 18.7 | - |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 226.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.7 / 1.3 / 0.3 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 140.0 | 116.7 |
| Combat | Points run down | 0.0 | 18.3 |
| Combat | Net points per charged fight, damage counted | +51 | +47 |
| Combat | Net per 100 charger points, damage counted | +125.2 | +21.7 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +60 | +28 |
| Combat | Net points per supported fight / lone fight | - / +60 | +28 / +27 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 2 of 8 |
| Game | Points lost | 530.7 | 400.0 |
| Game | VP from objectives | 763.3 | 460.0 |
| Game | Lone holders (player turns) | 2.0 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +140 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 931
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p13

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +172.7 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 22.0 | +174.4 | 0.0 | 430.0 | 23.7 | +316.1 | 0.0 | 149.0 |
| BACKUP TARGETS | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | - | - | - | - | 0.3 | +10.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 1.3 | +0.0 | 264.3 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 12.7 | +137.3 | 699.7 | 40.0 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +7.8 | 0.0 | 140.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 4.0 | +280.5 | 88.0 | 90.7 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.3 | +0.0 | 0.0 | 73.3 | - | - | - | - |
| CATCH FLIERS | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.3 | +25.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +62.2 | 0.0 | 75.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 4.3 | -2.1 | 0.0 | 24.0 |
| CHALLENGE BY POINTS | 0.3 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 21.0 | -1252.0 | 0.0 | 788.3 | 13.0 | -563.8 | 0.0 | 117.7 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 40.0 | 17.3 | 2.3 | +0.0 | 155.7 | 65.0 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 265.3 | 6.3 | +0.0 | 0.0 | 261.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 6.7 | +764.4 | 195.7 | 146.7 | - | - | - | - |
| COVER ONCE | 8.3 | -282.1 | 0.0 | 385.3 | 6.3 | -350.7 | 0.0 | 126.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -0.8 | 21.7 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -245.9 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | -1.1 | 40.0 | 17.3 | 2.0 | -1.6 | 96.7 | 100.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 10.0 | 3.0 | +2.2 | 120.7 | 100.0 |
| FALLS SHORT | 15.7 | +338.8 | 0.0 | 550.3 | 16.7 | +44.6 | 0.0 | 237.3 |
| FEATURE BUFFS | 16.3 | +488.7 | 0.0 | 138.3 | 1.0 | +5.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +2.4 | 0.0 | 10.0 | 0.7 | +47.5 | 17.3 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 72.7 | +7174.5 | 333.0 | 1680.7 | 141.3 | +3492.1 | 2836.7 | 902.0 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 405.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +88.4 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 0.7 | +32.4 | 40.0 | 27.3 | 4.7 | +170.4 | 217.3 | 100.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 56.7 | 3.3 | +0.0 | 0.0 | 20.0 |
| FRIEND CHARGES FIRST | 0.3 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.3 | -0.5 | 0.0 | 10.0 | - | - | - | - |
| GOAL WALK | 14.0 | +2455.4 | 0.0 | 148.0 | 0.3 | +11.9 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.3 | +0.4 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 2.0 | +425.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 15.3 | +0.0 | 0.0 | 771.0 | 5.7 | +0.0 | 0.0 | 61.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +19.7 | 56.7 | 0.0 |
| HIS CHARGE LIST | 17.3 | +0.0 | 0.0 | 324.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.7 | -47.4 | 0.0 | 345.7 | 2.3 | -91.9 | 0.0 | 20.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 11.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 56.3 | +2166.1 | 0.0 | 1379.3 | 63.3 | +2344.6 | 0.0 | 316.7 |
| HIS SHOTS BY HIS RUN | 48.3 | +1101.2 | 0.0 | 1266.0 | 48.0 | +1314.0 | 0.0 | 426.7 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +18.4 | 43.3 | 35.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 39.0 | +0.0 | 0.0 | 727.0 | 11.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 14.0 | +1416.6 | 0.0 | 359.7 | 7.0 | +927.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -2.0 | 40.0 | 27.3 | 3.3 | -87.0 | 160.7 | 65.0 |
| HUNT IN PAIRS | - | - | - | - | 2.0 | +277.3 | 0.0 | 65.0 |
| HUNT RESULT | 0.3 | +41.0 | 0.0 | 17.3 | - | - | - | - |
| HUNT THE GUNS | 0.3 | +41.9 | 40.0 | 17.3 | - | - | - | - |
| IDLE COST | 10.0 | -71.6 | 0.0 | 117.0 | 6.3 | -116.7 | 0.0 | 24.0 |
| JOINT CHARGE NOW | - | - | - | - | 3.0 | +37.7 | 150.0 | 100.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 11.7 | +0.0 | 378.0 | 354.0 | 9.0 | +0.0 | 470.3 | 210.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +0.1 | 40.0 | 27.3 | 3.7 | +4.2 | 189.0 | 100.0 |
| MANOEUVRE | 0.7 | -21.9 | 0.0 | 181.3 | 1.3 | -9.1 | 0.0 | 65.0 |
| MARCH BY THE SUM | 1.3 | +76.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -69.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +64.8 | 0.0 | 129.0 | 2.3 | +38.1 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 9.0 | +429.9 | 0.0 | 483.7 | - | - | - | - |
| MISSILES NEXT TURN | 9.7 | +309.5 | 0.0 | 378.7 | - | - | - | - |
| MISSILES ON ONE TARGET | 2.3 | -63.2 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | - | - | - | - | 5.3 | +1298.2 | 0.0 | 20.0 |
| MOVE ORDER | 1.0 | +0.0 | 95.0 | 31.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.7 | +12.4 | 0.0 | 146.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.3 | -63.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 2.7 | +0.0 | 0.0 | 122.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +117.0 | 0.0 | 0.0 | 5.3 | +157.5 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.0 | +253.2 | 0.0 | 134.0 | 10.3 | +444.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +71.2 | 0.0 | 0.0 | 2.3 | +48.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 1.0 | -89.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -7.6 | 40.0 | 17.3 | 4.3 | -86.1 | 207.3 | 100.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| NOT WORTH A CAST | 1.7 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 1.7 | -71.4 | 0.0 | 31.7 | 7.7 | -185.8 | 0.0 | 98.3 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.3 | -117.8 | 0.0 | 288.0 | 5.0 | -49.2 | 0.0 | 61.0 |
| ONE JOINT FIGURE | - | - | - | - | 2.0 | -10.6 | 85.0 | 35.0 |
| ONE OBJECTIVE FORMULA | 8.3 | +19.7 | 0.0 | 224.7 | 3.7 | -34.8 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 1.3 | +7.3 | 223.3 | 0.0 |
| OVERRUNS AWAY | 0.7 | +1.1 | 40.0 | 27.3 | 1.7 | +26.4 | 117.3 | 65.0 |
| PATHS CROSS | 0.3 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.7 | -31.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 32.3 | +97.7 | 68.0 | 751.3 | 62.7 | +1162.9 | 1094.3 | 733.3 |
| PROMISE BY ITS OWN SUM | 3.3 | -10.5 | 0.0 | 0.0 | 7.0 | -104.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -0.5 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -3.6 | 0.0 | 0.0 |
| QUARTER ODDS | 6.7 | +1101.1 | 162.0 | 0.0 | 16.0 | +730.5 | 0.0 | 472.3 |
| RANDOM MOVE BY FIGURES | 2.0 | +45.4 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +8.7 | 0.0 | 56.7 | - | - | - | - |
| REDIRECT COUNTER | 2.0 | +62.8 | 0.0 | 85.0 | 2.3 | +83.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +15.7 | 0.0 | 175.7 | 3.3 | +0.0 | 0.0 | 24.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -1.8 | 0.0 | 0.0 | 2.7 | -6.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +2.7 | 0.0 | 0.0 | 1.0 | -2.1 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 2.0 | +115.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -14.6 | 40.0 | 27.3 | 3.3 | +51.5 | 155.7 | 100.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | +59.7 | 86.7 | 65.0 |
| RUN DOWN | 0.3 | -1.4 | 0.0 | 10.0 | 4.0 | -18.5 | 217.3 | 65.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.6 | 0.0 | 0.0 | 0.7 | +25.2 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +0.5 | 28.3 | 0.0 |
| SET CREDITED ONCE | 0.7 | -2.1 | 0.0 | 10.0 | 3.3 | -400.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +2.9 | 0.0 | 10.0 | 5.3 | +571.3 | 0.0 | 130.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.3 | +0.0 | 0.0 | 112.3 | 24.0 | +0.0 | 0.0 | 177.7 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +64.6 | 35.0 | 0.0 | 1.3 | +42.8 | 220.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.7 | -8.8 | 56.7 | 35.0 |
| SHOT RISK POINTS | 38.3 | -271.1 | 0.0 | 906.0 | 48.7 | +516.2 | 0.0 | 385.7 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 4.3 | +99.6 | 0.0 | 86.7 | 46.7 | +982.2 | 0.0 | 178.3 |
| SPELL SETS UP CHARGE | 0.7 | +334.8 | 90.7 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.3 | +13.7 | 130.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 124.0 | 4.3 | +0.0 | 0.0 | 83.3 |
| STAND AND SHOOT | 0.3 | -0.5 | 40.0 | 17.3 | 1.3 | -5.2 | 86.7 | 65.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 54.0 | 8.0 | +0.0 | 0.0 | 48.0 |
| STANDS STILL | 20.7 | +0.0 | 293.0 | 555.7 | 94.3 | +0.0 | 2619.3 | 403.3 |
| STAY WORTH | 6.3 | +82.0 | 40.0 | 0.0 | 60.7 | -208.6 | 1377.7 | 77.3 |
| STOPS | 0.3 | +0.9 | 40.0 | 17.3 | - | - | - | - |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| SUPPORT ADDS | 9.3 | +755.7 | 0.0 | 136.7 | 2.3 | +23.2 | 0.0 | 81.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 40.0 | 17.3 | 0.7 | +0.0 | 56.7 | 0.0 |
| SUPPORT WORKED OUT | 9.3 | +755.7 | 0.0 | 136.7 | 2.3 | +23.2 | 0.0 | 81.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +2.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 21.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -3.6 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 48.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 17.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 109.0 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 34.3 | +0.0 | 0.0 | 736.7 | 61.3 | +0.0 | 0.0 | 401.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +62.4 | 43.3 | 65.0 |
| TIME ON OUR SIDE | 11.7 | +285.5 | 0.0 | 160.0 | 42.7 | +367.4 | 0.0 | 35.0 |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 108.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | +9.5 | 0.0 | 20.0 | 0.7 | -6.0 | 20.0 | 0.0 |
| WHO FIGHTS | 0.3 | +1.2 | 0.0 | 10.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +4.4 | 0.0 | 17.3 | 0.3 | +19.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.7 | 0.0 | 10.0 | 0.3 | +0.5 | 10.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -575.4 | 0.0 | 210.0 | 1.3 | -319.8 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +36.1 | 28.3 | 0.0 |
| WOUNDS ON THE RANKS | 7.3 | +1042.3 | 0.0 | 272.0 | 1.3 | +10.2 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p13

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 359 | 351 | 102 | 34.00 | +1391 | +13.6 |
| ARMY TABLE | 137 | 137 | 99 | 33.00 | +1426 | +14.4 |
| HIS SHOTS BY HIS RUN | 289 | 280 | 83 | 27.67 | +1004 | +12.1 |
| LEGAL CHARGES ONLY | 62 | 62 | 62 | 20.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 63 | 63 | 61 | 20.33 | +3032 | +49.7 |
| SHOT RISK POINTS | 261 | 253 | 61 | 20.33 | +1105 | +18.1 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -772 | -27.6 |
| TIME ON OUR SIDE | 163 | 150 | 26 | 8.67 | +237 | +9.1 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| FIVE ACTION | 642 | 631 | 23 | 7.67 | +1662 | +72.3 |
| GOAL WALK | 43 | 43 | 21 | 7.00 | +3624 | +172.6 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 20 | 6.67 | +7 | +0.3 |
| MODEL FACING | 16 | 16 | 16 | 5.33 | +3895 | +243.4 |
| SUPPORT ADDS | 35 | 33 | 14 | 4.67 | +430 | +30.7 |
| SUPPORT WORKED OUT | 35 | 33 | 14 | 4.67 | +430 | +30.7 |
| CHAFF PASSED | 13 | 13 | 13 | 4.33 | -6 | -0.5 |
| CASTING BLOCK | 12 | 12 | 12 | 4.00 | +264 | +22.0 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 11 | 3.67 | -346 | -31.5 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| WOUNDS ON THE RANKS | 26 | 26 | 10 | 3.33 | +331 | +33.1 |
| CANNON PLANNED TARGET | 38 | 38 | 9 | 3.00 | -16 | -1.8 |
| COVER ONCE | 44 | 36 | 9 | 3.00 | +281 | +31.2 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +113 | +12.6 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 9 | 3.00 | +61 | +6.8 |
| MOVE TO CHARGE COMPUTED | 24 | 19 | 8 | 2.67 | +159 | +19.8 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOUR ROUNDS | 16 | 16 | 7 | 2.33 | +296 | +42.3 |
| MAX FOR POSITIONING | 18 | 18 | 7 | 2.33 | +36 | +5.1 |
| QUARTER ODDS | 68 | 68 | 7 | 2.33 | +963 | +137.6 |
| FEATURE BUFFS | 52 | 51 | 6 | 2.00 | +39 | +6.5 |
| MISSILES IN THE MOVE | 27 | 21 | 6 | 2.00 | +299 | +49.8 |
| RESERVE MOVE SPELL | 6 | 6 | 6 | 2.00 | +347 | +57.8 |
| SET UP BY THE SET | 18 | 17 | 6 | 2.00 | +382 | +63.7 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 102 | 99 | 5 | 1.67 | +476 | +95.2 |
| IDLE COST | 49 | 32 | 5 | 1.67 | +38 | +7.7 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 5 | 1.67 | +136 | +27.2 |
| RISK BY ARC | 12 | 12 | 5 | 1.67 | +107 | +21.3 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| GUN MASK | 6 | 6 | 4 | 1.33 | +855 | +213.7 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +229 | +57.2 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 49 | 49 | 4 | 1.33 | +181 | +45.2 |
| NEXT CHARGE BY LIST | 10 | 10 | 4 | 1.33 | +144 | +36.1 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +2 | +0.5 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| STAY WORTH | 201 | 192 | 4 | 1.33 | +11 | +2.7 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 97 | 76 | 3 | 1.00 | +3 | +1.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +77 | +25.8 |
| SHOTS AFTER THE MOVES | 16 | 16 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 2 | 0.67 | +30 | +15.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| LOST AFTER ESCAPE | 13 | 13 | 2 | 0.67 | +3 | +1.6 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -94 | -46.8 |
| REDIRECT COUNTER | 13 | 11 | 2 | 0.67 | +20 | +10.2 |
| SHOTS IN THE MOVE | 153 | 134 | 2 | 0.67 | +39 | +19.6 |
| WHAT THE JOINER ADDS | 4 | 4 | 2 | 0.67 | +38 | +19.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +49 | +24.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +518 | +518.2 |
| BACKUP TARGETS | 2 | 2 | 1 | 0.33 | +1 | +0.6 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +30 | +30.5 |
| CAST JOB | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.33 | -23 | -23.4 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +17 | +17.4 |
| CHARGE NOW FIRST | 8 | 8 | 1 | 0.33 | -4 | -4.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +265 | +265.3 |
| HIS MOVE AND SHOT | 27 | 24 | 1 | 0.33 | +5 | +5.3 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +16 | +16.4 |
| HONEST WORTH | 12 | 12 | 1 | 0.33 | +5 | +4.5 |
| MISSILES NEXT TURN | 29 | 22 | 1 | 0.33 | +2 | +1.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 34 | 25 | 1 | 0.33 | +1 | +0.6 |
| ONE JOINT FIGURE | 6 | 6 | 1 | 0.33 | +144 | +143.5 |
| ONE OBJECTIVE FORMULA | 36 | 26 | 1 | 0.33 | +71 | +70.9 |
| OVERRUNS AWAY | 7 | 7 | 1 | 0.33 | +2 | +1.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +16 | +16.5 |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 1 | 0.33 | -2 | -1.5 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 1 | 0.33 | +7 | +7.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +149 | +149.3 |
| ROUNDS AFTER TERROR | 5 | 5 | 1 | 0.33 | +72 | +72.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -9 | -8.8 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.1 |
| THE ROW IN ITS ORDER | 7 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 1 | 0.33 | +72 | +72.4 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +2 | +1.5 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 49 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 20 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 7 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 16 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 12 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 63 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 68 | 67 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 28 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 34 | 30 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 152 | 150 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 6 | 6 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 7 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 3 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 285 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 11 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 85 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 30 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 26 | 25 | 0 | 0.00 | - | - |
| STANDS STILL | 345 | 341 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 9 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 5 | not checked | - | - | - | - |
| THE TABLE BINDS | 287 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 15 | 14 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p13

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.33 | 7.00 | 21.6 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 2.67 | 31.5 |
| ARMY TABLE | rule | 1.33 | 2.00 | 13.8 |
| HOLDER ASSIGNMENT | rule | 1.67 | 0.33 | 11.6 |
| JOINT CHARGE NOW | rule | - | 1.33 | 30.4 |
| CANNON PLANNED TARGET | rule | - | 1.00 | 5.3 |
| PIVOT GUARDS FLANK | rule | 0.67 | - | 46.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 6.3 |
| CATCH ODDS | rule | 0.33 | - | 23.4 |
| CHAFF PASSED | rule | - | 0.33 | 6.2 |
| CHARGE NOW FIRST | rule | - | 0.33 | 4.0 |
| NO REASON | gate | - | 0.33 | 197.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.5 |
| RESERVE FALL BACK | rule | - | 0.33 | 22.1 |
| RULE SWITCHED OFF | gate | 0.33 | - | 29.1 |
| SUPPORT NARROWED | rule | - | 0.33 | 8.8 |

### Plans: cnsr-c940641-p13

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 58 | 40 | 68% |
| Mine | move | 28.0 | 94% | 2899 | 0 | 0% |
| Mine | shoot | 3.3 | 40% | 394 | 58 | 15% |
| Mine | support | 0.3 | 0% | 8 | 0 | 0% |
| Opponent | charge | 3.3 | 70% | 279 | 141 | 51% |
| Opponent | move | 40.0 | 98% | 1296 | 0 | 0% |
| Opponent | shoot | 19.3 | 83% | 322 | 1022 | 318% |

### Packages: hunt the guns, cnsr-c940641-p13

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 126 | 123 | 100% | 104 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 126 | 123 | 100% | 104 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: cnsr-c940641-p13

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 67% | 75% | 0% | - | 50% | 0% | 0% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p13

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 75 | 25% | 4.0 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 31 (15) | 31 | 0 | 12 | 13% | 3.7 | - | 26 (12) | 66 (2) | 34 (8) | 32 (6) |
| Mine | Clean-up | 3 | 77 (3) | 77 | 0 | 67 | 0% | 4.7 | 231 (1) | 0 (2) | - | 77 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 50% | 5.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 70 (6) | 11 | 59 | 26 | 33% | 4.8 | 0 (1) | 105 (3) | 34 (2) | 38 (4) | 124 (2) |
| Mine | Holder | 5 | 49 (5) | 0 | 49 | 0 | 60% | 4.5 | 14 (3) | 195 (1) | - | 0 (1) | 82 (3) |
| Mine | Shooter | 2 | 154 (2) | 0 | 154 | 100 | 0% | 1.0 | - | 308 (1) | 0 (1) | 154 (2) | - |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 78 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (3) | - |
| Opponent | Chaff | 2 | 69 (2) | 0 | 69 | 50 | 0% | 1.5 | 139 (1) | 0 (1) | - | 69 (2) | - |
| Opponent | Character | 8 | 40 (8) | 40 | 0 | 0 | 38% | 2.6 | 369 (1) | 9 (6) | 0 (1) | 108 (4) | 11 (4) |
| Opponent | Clean-up | 6 | 25 (6) | 8 | 17 | 0 | 33% | 2.0 | 0 (1) | 38 (5) | - | 10 (5) | 66 (1) |
| Opponent | Fast Hammer | 4 | 12 (4) | 12 | 0 | 87 | 25% | 2.3 | 0 (1) | 7 (1) | 21 (2) | 15 (3) | 0 (1) |
| Opponent | Hammer | 3 | 80 (3) | 80 | 0 | 0 | 33% | 4.5 | 0 (1) | 560 (1) | 0 (1) | 280 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 10 | 57 (10) | 25 | 31 | 23 | 10% | 2.4 | 87 (2) | 54 (8) | - | 65 (8) | 33 (2) |
| Opponent | War machine | 12 | 25 (12) | 25 | 0 | 19 | 8% | 2.0 | 18 (10) | - | 61 (2) | 0 (2) | 32 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: cnsr-c940641-p13

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 227 | 40 | 0.7 | 1.0 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | - | +60 |
| Opponent | Dwarfen Mountain Holds | 2 | 560 | 168 | 2.5 | 1.6 | 67 | 21 | +46 | 1 of 5 | 2 of 5 | +75 | +27 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 185 | 3.0 | 1.3 | 62 | 65 | -3 | 1 of 3 | 2 of 3 | -65 | +28 |
| **Opponent** | all armies | 3 | 373 | 174 | 2.7 | 1.5 | 65 | 38 | +28 | 2 of 8 | 4 of 8 | +28 | +27 |

### Effective charges: cnsr-c940641-p13

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 1 (net +0) | 0 | 0 | 1 (net +120) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 5 | 1 (net -105) | 1 (net +0) | 0 | 1 (net +0) | 0 | 2 (net +168) | 0 | 0% (0 of 5) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net +0) | 0 | 0 | 0 | 1 (net -65) | 1 (net +55) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: cnsr-c940641-p13

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 30 | 105 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 52 | 120 | +120 | 120 | 17 | +103 | +197.4 |
| Mine | All fights | 2 | 41 | 112 | +60 | 60 | 9 | +51 | +125.2 |
| Opponent | Long shot (under 50%) | 2 | 283 | 579 | -52 | 44 | 52 | -9 | -3.0 |
| Opponent | 50-54% | 1 | 105 | 52 | +0 | 17 | 52 | -35 | -33.5 |
| Opponent | 76-89% | 1 | 105 | 52 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 112 | 57 | +131 | 161 | 8 | +153 | +136.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 606 | 65 | -65 | 162 | 195 | -33 | -5.5 |
| Opponent | All fights | 8 | 215 | 187 | +28 | 94 | 47 | +47 | +21.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p13 | move | 18 | 2 (11%) | 2 (11%) | 1 (6%) | 15 (83%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

# Doctrine scorecard: cnsr-c940641-p32

### Scorecard: cnsr-c940641-p32

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 13 | 4 | 0 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 67% | 6.5 | 3.0 | 1.7 | 1.7 | 0.0 | 0.0 | 0.0 | 93.3 |
| **Average** | | | Opponent | 0% | 2.0 | 2.3 | 2.3 | 2.3 | 0.0 | 0.0 | 0.0 | 56.7 |

### KPIs: cnsr-c940641-p32

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (3 of 13) | 0% (0 of 13) | 12% (3 of 26) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 100% (1 of 1); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 57% (4 of 7); on the table 57% | 100% (3 of 3); on the table 100% | 70% (7 of 10); on the table 70% |
| Magic missiles tried each own turn | 50%+ | 28% (5 of 18) | 50% (12 of 24) | 40% (17 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (5 of 15) | 50% (12 of 24) | 44% (17 of 39) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 33% (3 of 9) | 33% (3 of 9) |
| Points that never fought | lower | 50% (2978 of 6000) | 46% (2762 of 6000) | 48% (5740 of 12000) |
|   infantry points that never fought | lower | 100% (1315 of 1315) | 61% (560 of 921) | 84% (1875 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (13 of 25) | 75% (24 of 32) | 65% (37 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.3 uses a game | 50% (1 of 2); 1.0 uses a game | 75% (3 of 4); 2.2 uses a game |
| Bound items with another spell used |  | 50% (5 of 10); 2.3 uses a game | 0.0 uses a game | 50% (5 of 10); 1.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (2625 of 5720) | 69% (4000 of 5830) | 57% (6625 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (23%) | 2.3 (58%) | 3.3 (40%) |
| MARCHED: its unit marched | 1.7 (38%) | 1.0 (25%) | 2.7 (32%) |
| CHARGED: its unit charged | 0.7 (15%) | 0.7 (17%) | 1.3 (16%) |
| IN COMBAT: engaged in combat | 1.0 (23%) | 0.0 (0%) | 1.0 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 1.0 | 3.3 | 5.7 | 0.0 | 3.7 |
| not cast | 2.7 | 3.0 | 2.7 | 8.3 | 2.0 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (89%) | 0.3 (12%) | 3.3 (40%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (32%) | 1.0 (50%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (16%) | 0.3 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (11%) | 0.3 (12%) | 1.0 (12%) | 0.7 (33%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (100%) | 0.0 (0%) | 2.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.0 a game | 0.3 a game | 1.7 a game |
| stood (cast and not dispelled) | 78% (7 of 9) | - | 78% (7 of 9) |
| the unit moved after it | 43% (3 of 7) | - | 43% (3 of 7) |
| it charged on its next turn | 0% (0 of 7) | - | 0% (0 of 7) |
| the enemy charged it first | 29% (2 of 7) | - | 29% (2 of 7) |
| it fought by the end of its next turn | 14% (1 of 7) | - | 14% (1 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (1 of 7) | - | 14% (1 of 7) |
| none of these (no charge, no fight, no charge escaped) | 57% (4 of 7) | - | 57% (4 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (63 of 93) | 71% (22 of 31) | 69% (85 of 124) |
|   cavalry | 73% (8 of 11) | 61% (11 of 18) | 66% (19 of 29) |
|   character | 34% (11 of 32) | 75% (3 of 4) | 39% (14 of 36) |
|   infantry | 80% (24 of 30) | 89% (8 of 9) | 82% (32 of 39) |
|   war machine | 100% (20 of 20) | - | 100% (20 of 20) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (30%) | 1.3 (44%) | 4.3 (33%) |
| CHARGED: it charged | 2.0 (20%) | 1.0 (33%) | 3.0 (23%) |
| IN COMBAT: it fought this turn or the last | 1.3 (13%) | 0.0 (0%) | 1.3 (10%) |
| NO TARGET IN RANGE | 1.7 (17%) | 0.3 (11%) | 2.0 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (17%) | 0.3 (11%) | 2.0 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.0 | 1.3 | 87% | 3.8 pts | 38 pts |
| character | 8.0 | 2.7 | 79% | 10.7 pts | 85 pts |
| infantry | 18.7 | 4.7 | 79% | 5.8 pts | 107 pts |
| war machine | 6.7 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 4.3 | 3.8 |
| Charges that made contact a game | 2.3 | 2.3 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.75 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.27 contact (22 units) | 0.57 declared, 0.30 contact (23 units) | 0.44 declared, 0.29 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (8 of 15) | 0% (0 of 2) | - | 47% (8 of 17) |
| Character in a unit | 100% (3 of 3) | 100% (2 of 2) | 0% (0 of 1) | 83% (5 of 6) |
| Character on its own | 75% (3 of 4) | 50% (2 of 4) | 33% (2 of 6) | 50% (7 of 14) |
| Infantry | 83% (10 of 12) | 50% (1 of 2) | - | 79% (11 of 14) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 57% (4 of 7); on the table 57% | 28% (5 of 18) | 50% | 52% (13 of 25) | 100% (2 of 2); 3.3 uses a game | 50% (5 of 10); 2.3 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 67% (8 of 12) | 33% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 23% | 67% (8 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 82% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p32, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 25% (1) | 50% (4) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p32

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 44% (4 of 9) | 55% (6 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 62% (18 of 29) | 0% (0 of 9) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | - | 83% (5 of 6) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.7 | 2.3 |
| Movement | Points that never moved of their own | 93.3 | 56.7 |
| Movement | Fights charged into per game | 2.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +0 | 1 of 5, net +151 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net -500 | 1 of 5, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +125 | 0 of 5 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.0 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (19 of 48) | 71% (17 of 24) |
| Shooting | Points destroyed by shooting units | 48.0 | 0.0 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 70% (14 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | 67% (4 of 6) |
| Magic | Wounds caused by magic missiles | 4.7 | 2.3 |
| Magic | Wounds caused by other spells | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 127.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.7 / 0.3 / 1.7 / 0.0 | 1.0 / 0.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 129.0 | 397.0 |
| Combat | Points run down | 0.0 | 147.3 |
| Combat | Net points per charged fight, damage counted | -83 | +114 |
| Combat | Net per 100 charger points, damage counted | -20.9 | +52.0 |
| Combat | First round won (charged fights) | 33% | 33% |
| Combat | Net points per charged fight | -98 | +119 |
| Combat | Net points per supported fight / lone fight | -500 / -17 | -126 / +168 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 2 of 6 |
| Game | Points lost | 578.3 | 389.3 |
| Game | VP from objectives | 670.0 | 593.3 |
| Game | Lone holders (player turns) | 6.5 | 2.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -93 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 968
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p32

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +20.5 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 29.3 | +466.0 | 0.0 | 368.0 | 27.7 | +318.4 | 0.0 | 290.7 |
| ASSAILMENT BY POINTS | 0.7 | +2.0 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.7 | +13.5 | 34.0 | 46.7 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -3.5 | 18.3 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 2.7 | +145.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +25.4 | 0.0 | 41.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -2.0 | 0.0 | 0.0 | 0.7 | -1.6 | 41.0 | 0.0 |
| CHARGE LOSSES | 17.0 | -500.0 | 0.0 | 414.7 | 22.7 | -1419.7 | 0.0 | 317.3 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 82.0 | 0.0 | 2.7 | +0.0 | 215.3 | 34.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 147.3 | 3.7 | +0.0 | 0.0 | 36.7 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| CONVEYANCE SEARCH | 2.0 | +260.7 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 8.0 | -487.4 | 0.0 | 141.7 | 5.3 | -434.7 | 0.0 | 48.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.0 | 50.3 | 34.0 |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -49.4 | 41.7 | 147.3 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +16.0 | 81.7 | 0.0 | 0.3 | +11.7 | 50.3 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 3.7 | +17.5 | 0.0 | 42.0 |
| EXACT ROUND | 1.3 | +8.3 | 108.3 | 0.0 | 2.3 | +32.7 | 174.3 | 76.0 |
| FALL BACK GOOD ORDER | 2.0 | +2.3 | 102.0 | 147.3 | 2.7 | +0.0 | 165.0 | 34.0 |
| FALLS SHORT | - | - | - | - | 21.7 | +276.4 | 0.0 | 155.3 |
| FEATURE BUFFS | 0.7 | +7.3 | 0.0 | 0.0 | 1.7 | +11.6 | 0.0 | 55.0 |
| FIGHT TO THE END | 0.3 | +23.7 | 0.0 | 147.3 | 1.0 | -0.6 | 50.3 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 96.3 | +6810.3 | 354.0 | 1369.0 | 79.7 | +5565.6 | 432.3 | 695.3 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 100.7 | 6.3 | +0.0 | 0.0 | 192.7 |
| FOLLOW UP WEIGHED | 0.3 | +60.7 | 0.0 | 0.0 | 0.7 | +11.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +521.7 | 190.0 | 314.0 | 3.7 | +203.9 | 215.3 | 76.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 55.0 |
| FRIEND SHOOTS FIRST | 1.7 | -8.8 | 0.0 | 0.0 | 0.3 | -3.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -15.6 | 41.7 | 147.3 | - | - | - | - |
| GOAL WALK | 5.0 | +209.6 | 0.0 | 0.0 | 7.7 | +346.5 | 0.0 | 0.0 |
| GUN FIGURES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 0.7 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 4.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 267.3 | 13.3 | +0.0 | 0.0 | 275.3 |
| HIS CHARGE DENIED | - | - | - | - | 1.3 | +64.4 | 100.7 | 76.0 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 113.3 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 461.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -20.3 | 0.0 | 0.0 | 4.3 | -60.1 | 0.0 | 42.0 |
| HIS ONE QUARTER | 7.7 | +0.0 | 0.0 | 333.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 678.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.3 | +0.0 | 0.0 | 434.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.3 | +1373.1 | 0.0 | 267.3 | 48.0 | +1287.3 | 0.0 | 457.0 |
| HIS SHOTS BY HIS RUN | 36.3 | +724.4 | 0.0 | 713.0 | 55.0 | +1221.0 | 0.0 | 619.3 |
| HIS TURN DENIED | 0.3 | +1.9 | 0.0 | 147.3 | 0.7 | +3.7 | 23.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 50.3 | 10.3 | +0.0 | 0.0 | 110.0 |
| HOLDER ASSIGNMENT | 9.3 | +736.9 | 0.0 | 50.3 | 6.3 | +487.2 | 0.0 | 36.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -104.5 | 190.0 | 147.3 | 1.3 | -19.7 | 124.0 | 34.0 |
| IDLE COST | - | - | - | - | 11.0 | -165.3 | 0.0 | 41.7 |
| JOINT CHARGE NOW | 0.7 | -250.3 | 0.0 | 166.7 | 1.0 | +81.5 | 50.3 | 76.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 148.3 | 395.3 | 3.7 | +0.0 | 115.7 | 34.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.7 | +2.1 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 1.0 | -4.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | -0.8 | 42.0 | 314.0 | 2.0 | +1.3 | 50.3 | 76.0 |
| MAKE SURE TOGETHER | 1.0 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +30.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +73.9 | 0.0 | 0.0 | 0.3 | +13.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +42.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.0 | +62.7 | 0.0 | 166.7 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | -21.7 | 0.0 | 166.7 | 1.0 | +160.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.7 | +112.1 | 0.0 | 166.7 | 1.3 | +89.4 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.7 | +72.0 | 0.0 | 0.0 | 5.3 | +216.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.3 | +57.6 | 0.0 | 166.7 | 5.3 | +119.3 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 9.7 | +1164.8 | 0.0 | 484.3 | 7.0 | +592.1 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +285.5 | 0.0 | 50.3 | 6.7 | +259.5 | 0.0 | 58.3 |
| NEXT CHARGE BY LIST | 5.3 | +543.4 | 0.0 | 166.7 | 4.7 | +407.0 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -6.6 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.0 | -101.0 | 190.0 | 166.7 | 3.3 | -122.2 | 174.3 | 76.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -218.9 | 0.0 | 166.7 | 4.0 | -136.2 | 0.0 | 48.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.7 | -1.4 | 91.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 7.3 | -178.8 | 0.0 | 364.3 | 4.3 | -95.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +114.4 | 0.0 | 166.7 | 0.3 | +18.6 | 0.0 | 42.0 |
| ONE OBJECTIVE FORMULA | 4.7 | +8.0 | 0.0 | 0.0 | 1.3 | +53.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -78.8 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +14.6 | 23.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.4 | 41.7 | 0.0 | 1.3 | +9.2 | 124.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | -19.5 | 0.0 | 0.0 |
| PLAN RESULT | 43.0 | +259.1 | 179.0 | 1100.7 | 39.7 | +466.0 | 100.7 | 591.3 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -435.0 | 0.0 | 166.7 | 7.7 | -112.6 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | -1.2 | 0.0 | 0.0 | 0.3 | -22.9 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -3.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 26.3 | +2636.3 | 212.0 | 333.3 | 25.0 | +2978.6 | 217.0 | 268.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +61.4 | 0.0 | 113.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +367.2 | 0.0 | 36.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 36.7 |
| REFORMS TO MEET IT | 3.7 | -127.8 | 0.0 | 151.0 | 1.3 | -19.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 50.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +3.8 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +3.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +15.1 | 142.0 | 147.3 | 3.7 | +61.0 | 215.3 | 76.0 |
| ROUNDS AFTER TERROR | 1.0 | -36.4 | 0.0 | 314.0 | 0.3 | -1.4 | 23.3 | 0.0 |
| RUN DOWN | 2.3 | -93.5 | 142.0 | 166.7 | 3.7 | -23.7 | 215.3 | 76.0 |
| SAME CHARGE LATER | 0.3 | -3.6 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 0.7 | +42.2 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +12.3 | 40.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +2.3 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.0 | -31.0 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 4.0 | +341.6 | 0.0 | 147.3 | 2.0 | +39.9 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +18.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.7 | +0.0 | 0.0 | 87.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +39.1 | 0.0 | 0.0 | 1.0 | +90.8 | 166.7 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.9 | 0.0 | 0.0 | 0.3 | -35.0 | 0.0 | 42.0 |
| SHOT RISK POINTS | 19.0 | -381.5 | 0.0 | 465.0 | 32.7 | -300.2 | 0.0 | 314.3 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 20.0 | +433.0 | 0.0 | 87.7 | 6.3 | +131.9 | 0.0 | 36.7 |
| SPELL SETS UP CHARGE | 0.3 | +18.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 3.7 | +115.4 | 0.0 | 0.0 | 1.7 | +13.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +3.1 | 42.0 | 0.0 | 2.3 | -39.7 | 151.0 | 76.0 |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 100.7 | 10.3 | +0.0 | 0.0 | 165.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -4.0 | 41.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 49.0 | +0.0 | 164.0 | 175.3 | 21.7 | +0.0 | 217.0 | 93.3 |
| STAY WORTH | 30.3 | +56.3 | 68.0 | 318.7 | 10.0 | +175.3 | 50.3 | 42.0 |
| STRIKE BY THE ODDS | 0.7 | +13.6 | 0.0 | 314.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| SUPPORT ADDS | 6.0 | +370.6 | 0.0 | 0.0 | 8.0 | +1324.7 | 0.0 | 18.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 124.0 | 34.0 |
| SUPPORT WORKED OUT | 6.0 | +370.6 | 0.0 | 0.0 | 8.0 | +1324.7 | 0.0 | 18.3 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -25.1 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 48.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 50.3 | 3.7 | +0.0 | 0.0 | 41.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 48.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 41.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 46.3 | +0.0 | 0.0 | 502.3 | 36.0 | +0.0 | 0.0 | 253.0 |
| TIED UP BY THE SUM | 1.0 | +110.7 | 100.0 | 0.0 | 0.3 | +32.0 | 23.3 | 0.0 |
| TIME ON OUR SIDE | 45.7 | +526.2 | 0.0 | 389.7 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -2.7 | 42.0 | 0.0 | 0.7 | -0.5 | 50.3 | 0.0 |
| WHO HITS BACK | 0.3 | +63.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 0.3 | -39.3 | 0.0 | 0.0 | 3.3 | -872.3 | 0.0 | 179.3 |
| WHOLE FIGHT GAIN | 0.7 | +273.5 | 0.0 | 166.7 | 0.3 | +13.4 | 0.0 | 42.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 4.7 | +167.1 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p32

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 171 | 171 | 109 | 36.33 | +948 | +8.7 |
| HIS SHOT LIST | 256 | 243 | 60 | 20.00 | +1868 | +31.1 |
| HIS SHOTS BY HIS RUN | 274 | 264 | 45 | 15.00 | +652 | +14.5 |
| HOLDER ASSIGNMENT | 47 | 47 | 40 | 13.33 | +2697 | +67.4 |
| FIVE ACTION | 528 | 507 | 32 | 10.67 | +2109 | +65.9 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| QUARTER ODDS | 154 | 148 | 29 | 9.67 | +1762 | +60.8 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -1065 | -38.0 |
| MOVE TO CHARGE COMPUTED | 50 | 42 | 27 | 9.00 | +1122 | +41.5 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| LEGAL CHARGES ONLY | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| SHOT RISK POINTS | 155 | 147 | 22 | 7.33 | +749 | +34.0 |
| NEXT CHARGE BY LIST | 30 | 29 | 18 | 6.00 | +585 | +32.5 |
| PROMISE BY ITS OWN SUM | 50 | 50 | 17 | 5.67 | -1643 | -96.6 |
| TIME ON OUR SIDE | 137 | 122 | 14 | 4.67 | +75 | +5.4 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 119 | 113 | 10 | 3.33 | +1532 | +153.2 |
| SET UP BY THE SET | 18 | 16 | 10 | 3.33 | +1756 | +175.6 |
| FOUR ROUNDS | 21 | 19 | 9 | 3.00 | +619 | +68.8 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 9 | 3.00 | +0 | +0.0 |
| GOAL WALK | 38 | 37 | 8 | 2.67 | +361 | +45.1 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 7 | 2.33 | +159 | +22.8 |
| COVER ONCE | 40 | 28 | 6 | 2.00 | +192 | +32.0 |
| RISK BY ARC | 17 | 15 | 6 | 2.00 | +145 | +24.2 |
| SUPPORT ADDS | 42 | 38 | 6 | 2.00 | +206 | +34.4 |
| SUPPORT WORKED OUT | 42 | 38 | 6 | 2.00 | +206 | +34.4 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -507 | -101.3 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| CASTING BLOCK | 8 | 8 | 4 | 1.33 | +134 | +33.6 |
| NEARER NOT NEEDED | 40 | 39 | 4 | 1.33 | +167 | +41.7 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +8 | +2.7 |
| CANNON PLANNED TARGET | 20 | 20 | 3 | 1.00 | -7 | -2.3 |
| CHARGE NOW FIRST | 11 | 11 | 3 | 1.00 | -73 | -24.2 |
| EVASIVE BY THE ODDS | 11 | 11 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +217 | +72.2 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 33 | 23 | 3 | 1.00 | +1 | +0.2 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +262 | +87.5 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -188 | -62.7 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 3 | 1.00 | +184 | +61.4 |
| SUPPORT NARROWED | 5 | 5 | 3 | 1.00 | -538 | -179.2 |
| WHOLE FIGHT DANGER | 11 | 11 | 3 | 1.00 | +887 | +295.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +61 | +30.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EDGE GIVE GROUND | 3 | 2 | 2 | 0.67 | +18 | +8.9 |
| EXACT ROUND | 11 | 10 | 2 | 0.67 | +20 | +9.9 |
| FALLS SHORT | 65 | 55 | 2 | 0.67 | +43 | +21.4 |
| MAX FOR POSITIONING | 12 | 10 | 2 | 0.67 | +15 | +7.3 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +164 | +82.2 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 2 | 0.67 | -72 | -36.2 |
| REDIRECT COUNTER | 5 | 5 | 2 | 0.67 | +49 | +24.3 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.67 | -17 | -8.4 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +127 | +63.3 |
| SHOTS AFTER THE MOVES | 18 | 18 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 121 | 104 | 2 | 0.67 | +116 | +57.9 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +41 | +20.4 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 2 | 2 | 0.67 | +59 | +29.6 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +325 | +162.5 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -10 | -10.5 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +76 | +76.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -3 | -3.4 |
| HIS CHARGE DENIED | 4 | 4 | 1 | 0.33 | +6 | +6.5 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +2 | +1.7 |
| HONEST WORTH | 12 | 10 | 1 | 0.33 | +10 | +10.4 |
| MARCH CHECK | 4 | 4 | 1 | 0.33 | +32 | +31.9 |
| MISSILES IN THE MOVE | 30 | 19 | 1 | 0.33 | +27 | +26.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 19 | 17 | 1 | 0.33 | +52 | +51.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -236 | -236.4 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +29 | +29.2 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +0 | +0.4 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -58 | -58.4 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -3 | -3.4 |
| REFORMS TO MEET IT | 15 | 13 | 1 | 0.33 | +26 | +26.2 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +12 | +11.5 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +11 | +11.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +37 | +36.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS IN THE MOVE | 79 | 57 | 1 | 0.33 | +24 | +24.0 |
| THE ROW IN ITS ORDER | 15 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +0 | +0.4 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +47 | +46.6 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 40 | 38 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 19 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 14 | 14 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 67 | 63 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 17 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 31 | 27 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 41 | 37 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 37 | 34 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 78 | 77 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 38 | 27 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 35 | 16 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 18 | 10 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 248 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 16 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 41 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 16 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 212 | 207 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 247 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p32

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 3.33 | 42.5 |
| ARMY TABLE | rule | 2.33 | 4.00 | 90.6 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 2.33 | 96.6 |
| JOINT CHARGE NOW | rule | 0.67 | 0.67 | 202.3 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 24.2 |
| MARCH OF THE TABLE | rule | 1.00 | - | 62.7 |
| SUPPORT NARROWED | rule | - | 1.00 | 179.2 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 3.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.33 | 36.2 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 8.4 |
| AFTERMATH BAND | gate | 0.33 | - | 3.4 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 10.5 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| FALLBACK | gate | - | 0.33 | 17.5 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 3.4 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 4.8 |
| NO REASON | gate | 0.33 | - | 18.8 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 236.4 |
| PATHS CROSS | rule | - | 0.33 | 58.4 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 3.4 |
| SET UP BY THE SET | rule | 0.33 | - | 11.6 |

### Plans: cnsr-c940641-p32

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 33% | 236 | 89 | 38% |
| Mine | move | 33.0 | 98% | 1809 | 0 | 0% |
| Mine | shoot | 8.0 | 29% | 241 | 170 | 71% |
| Opponent | charge | 3.7 | 55% | 385 | 272 | 71% |
| Opponent | join | 2.3 | 100% | 98 | 0 | 0% |
| Opponent | move | 31.0 | 95% | 2365 | 0 | 0% |
| Opponent | shoot | 2.7 | 62% | 267 | 194 | 73% |

### Battle groups: cnsr-c940641-p32

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p32

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 30 (8) | 30 | 0 | 43 | 12% | 2.3 | 19 (6) | 66 (2) | - | 19 (2) | 34 (6) |
| Mine | Clean-up | 3 | 39 (3) | 0 | 39 | 32 | 33% | 1.0 | 61 (2) | 0 (1) | - | 61 (2) | 0 (1) |
| Mine | Fast Hammer | 7 | 20 (7) | 0 | 20 | 43 | 43% | 3.8 | 26 (3) | 20 (3) | 0 (1) | 40 (2) | 12 (5) |
| Mine | Holder | 2 | 65 (2) | 0 | 65 | 0 | 100% | - | 65 (2) | - | - | 65 (2) | - |
| Mine | Shooter | 5 | 30 (5) | 30 | 0 | 0 | 0% | 1.4 | 21 (4) | 68 (1) | - | 21 (4) | 68 (1) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 25 | 0% | 1.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 50 (9) | 50 | 0 | 12 | 11% | 3.2 | 37 (3) | 77 (5) | - | 100 (3) | 36 (5) |
| Opponent | Clean-up | 3 | 46 (3) | 46 | 0 | 69 | 33% | 3.0 | - | 46 (3) | - | 0 (1) | 66 (2) |
| Opponent | Fast Hammer | 3 | 110 (3) | 63 | 47 | 0 | 0% | 4.0 | 133 (1) | 103 (2) | - | 129 (1) | 92 (2) |
| Opponent | Hammer | 8 | 0 (8) | 0 | 0 | 22 | 50% | 3.0 | 0 (4) | 0 (2) | 0 (2) | 0 (5) | 0 (3) |
| Opponent | Holder | 3 | 30 (3) | 30 | 0 | 65 | 33% | 3.0 | - | 0 (1) | 85 (1) | - | 47 (2) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 30 | 0% | 1.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |

### Charged fights: cnsr-c940641-p32

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 175 | 169 | 2.0 | 1.2 | 84 | 182 | -98 | 2 of 6 | 2 of 6 | -500 | -17 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 417 | 2.0 | 1.0 | 208 | 0 | +208 | 1 of 2 | 1 of 2 | - | +208 |
| Opponent | Warriors of Chaos | 1 | 0 | 274 | 2.0 | 1.0 | 137 | 0 | +137 | 0 of 2 | 1 of 2 | - | +137 |
| Opponent | Wood Elf Realms | 1 | 0 | 151 | 2.0 | 1.5 | 76 | 63 | +12 | 1 of 2 | 0 of 2 | -126 | +151 |
| **Opponent** | all armies | 3 | 0 | 281 | 2.0 | 1.2 | 140 | 21 | +119 | 2 of 6 | 2 of 6 | -126 | +168 |

### Effective charges: cnsr-c940641-p32

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 6 | 0 | 0 | 1 (net +0) | 1 (net -151) | 1 (net -500) | 1 (net +125) | 2 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 0 | 1 (net +70) | 0 | 1 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 2 (net +137) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 1 (net +151) | 1 (net -126) | 0 | 0 | 0 | 50% (1 of 2) |

### Charged fights, damage counted: cnsr-c940641-p32

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 151 | 116 | +0 | 23 | 60 | -37 | -24.6 |
| Mine | 76-89% | 1 | 151 | 126 | -151 | 54 | 192 | -139 | -91.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 125 | +125 | 125 | 0 | +125 | +50.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 989 | 201 | -500 | 89 | 500 | -411 | -41.5 |
| Mine | No odds | 2 | 416 | 232 | -30 | 204 | 221 | -17 | -4.2 |
| Mine | All fights | 6 | 395 | 172 | -98 | 116 | 199 | -83 | -20.9 |
| Opponent | Effective (55-75%) | 1 | 126 | 151 | +151 | 151 | 34 | +117 | +92.9 |
| Opponent | 76-89% | 3 | 163 | 225 | +49 | 148 | 65 | +83 | +51.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 350 | 70 | +70 | 70 | 0 | +70 | +20.0 |
| Opponent | No odds | 1 | 350 | 247 | +347 | 347 | 100 | +247 | +70.6 |
| Opponent | All fights | 6 | 219 | 190 | +119 | 169 | 55 | +114 | +52.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p32 | move | 25 | 3 (12%) | 3 (12%) | 5 (20%) | 17 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

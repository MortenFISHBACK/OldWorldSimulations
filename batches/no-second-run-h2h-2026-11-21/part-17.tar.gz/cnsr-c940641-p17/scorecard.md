# Doctrine scorecard: cnsr-c940641-p17

### Scorecard: cnsr-c940641-p17

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 2 | 1 | 3 | 2 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 1 | - | 1 | 3 | 1 | 0 | 0 | 410 |
| L0810 | 6 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 551 |
| L0810 | 6 | 1 | Opponent | no | 10 | 2 | 0 | 0 | 1 | 0 | 0 | 456 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 426 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 6 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.0 | 3.0 | 1.3 | 2.0 | 0.0 | 0.0 | 0.0 | 465.7 |
| **Average** | | | Opponent | 67% | 5.5 | 2.0 | 1.3 | 3.0 | 0.7 | 0.0 | 0.0 | 288.7 |

### KPIs: cnsr-c940641-p17

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 14) | 52% (15 of 29) |
| Winner chose to follow up after the loser gave ground |  | 86% (6 of 7); on the table 86% | 100% (1 of 1); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 86% (6 of 7); on the table 86% | 100% (2 of 2); on the table 100% | 89% (8 of 9); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 22% (8 of 36) | 29% (12 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 80% (4 of 5) | 33% (8 of 24) | 41% (12 of 29) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 38% (3 of 8) | 38% (3 of 8) |
| Points that never fought | lower | 67% (4049 of 5999) | 65% (3893 of 5998) | 66% (7942 of 11997) |
|   infantry points that never fought | lower | 92% (891 of 968) | 82% (909 of 1113) | 86% (1800 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (21 of 30) | 52% (13 of 25) | 62% (34 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 2.7 uses a game | 100% (3 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 50% (1 of 2); 0.3 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (3302 of 5378) | 58% (2991 of 5181) | 60% (6293 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (29%) | 2.7 (27%) |
| MARCHED: its unit marched | 0.3 (50%) | 2.7 (29%) | 3.0 (30%) |
| IN COMBAT: engaged in combat | 0.3 (50%) | 0.7 (7%) | 1.0 (10%) |
| GONE: slain | 0.0 (0%) | 3.3 (36%) | 3.3 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.3 | 1.7 | 4.3 | 4.0 | 0.3 | 0.3 |
| not cast | 3.7 | 0.3 | 1.7 | 10.0 | 3.7 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.3 (20%) | 2.7 (27%) | 1.0 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (30%) | 0.7 (18%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (10%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (18%) | 0.0 (0%) | 1.0 (60%) | 3.3 (33%) | 1.0 (27%) | 4.3 (16%) |
| STUPIDITY: Stupidity | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (27%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (73%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.3 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 4.3 a game | 2.2 a game |
| stood (cast and not dispelled) | - | 62% (8 of 13) | 62% (8 of 13) |
| the unit moved after it | - | 75% (6 of 8) | 75% (6 of 8) |
| it charged on its next turn | - | 0% (0 of 8) | 0% (0 of 8) |
| the enemy charged it first | - | 0% (0 of 8) | 0% (0 of 8) |
| it fought by the end of its next turn | - | 0% (0 of 8) | 0% (0 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 8) | 0% (0 of 8) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (8 of 8) | 100% (8 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 81% (71 of 88) | 67% (18 of 27) | 77% (89 of 115) |
|   cavalry | 92% (12 of 13) | - | 92% (12 of 13) |
|   chariot | 89% (8 of 9) | 69% (9 of 13) | 77% (17 of 22) |
|   infantry | 75% (9 of 12) | 55% (6 of 11) | 65% (15 of 23) |
|   war machine | 78% (42 of 54) | 100% (3 of 3) | 79% (45 of 57) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (12%) | 0.3 (11%) | 1.0 (12%) |
| IN COMBAT: it fought this turn or the last | 0.7 (12%) | 0.7 (22%) | 1.3 (15%) |
| MOVED: a war machine that moved | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |
| NO TARGET IN RANGE | 1.0 (18%) | 2.0 (67%) | 3.0 (35%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (29%) | 0.0 (0%) | 1.7 (19%) |
| SHELTERED: the target was sheltered | 0.7 (12%) | 0.0 (0%) | 0.7 (8%) |
| OTHER BAR | 0.7 (12%) | 0.0 (0%) | 0.7 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.3 | 2.3 | 79% | 7.8 pts | 73 pts |
| chariot | 6.0 | 1.3 | 83% | 3.2 pts | 19 pts |
| infantry | 5.0 | 1.3 | 80% | 3.5 pts | 18 pts |
| war machine | 15.3 | 10.0 | 74% | 28.9 pts | 443 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 4.3 | 3.0 |
| Charges that made contact a game | 1.7 | 2.3 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.20 declared, 0.20 contact (5 units) | 0.33 declared, 0.33 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.18 contact (22 units) | 0.52 declared, 0.26 contact (23 units) | 0.36 declared, 0.22 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (4 of 9) | 33% (1 of 3) | 100% (1 of 1) | 46% (6 of 13) |
| Character in a unit | 100% (6 of 6) | - | - | 100% (6 of 6) |
| Character on its own | 80% (4 of 5) | 50% (1 of 2) | 50% (2 of 4) | 64% (7 of 11) |
| Chariot | 67% (2 of 3) | 50% (1 of 2) | - | 60% (3 of 5) |
| Infantry | 0% (0 of 3) | 100% (1 of 1) | 50% (1 of 2) | 33% (2 of 6) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 77% (10 of 13) | - | - | 77% (10 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 86% (6 of 7); on the table 86% | 67% (4 of 6) | 67% | 70% (21 of 30) | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Grand Cathay | 1 | - | 17% (4 of 24) | 75% | 40% (4 of 10) | 100% (2 of 2); 6.0 uses a game | 100% (1 of 1); 3.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 41% | 56% (5 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 79% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p17, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 33% (1) | 17% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p17

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 50% (6 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 22% (11 of 51) | 42% (5 of 12) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 33% (3 of 9) | 40% (4 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 2.0 | 3.0 |
| Movement | Points that never moved of their own | 465.7 | 288.7 |
| Movement | Fights charged into per game | 1.7 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 1 of 6, net +102 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net -281 | 1 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 3, net +46 | 1 of 6, net -540 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 5.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 27% (9 of 33) | 67% (10 of 15) |
| Shooting | Points destroyed by shooting units | 125.0 | 0.0 |
| Shooting | War machine shots | 14.0 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (18 of 42) | 0% (0 of 4) |
| Shooting | Points destroyed by war machines | 213.0 | 43.3 |
| Magic | Magic missiles cast | 1.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 0.3 | 5.3 |
| Magic | Wounds caused by other spells | 1.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 48.3 | 67.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.7 / 0.3 / 0.0 | 4.0 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 284.0 | 135.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -23 | +45 |
| Combat | Net per 100 charger points, damage counted | -9.7 | +37.9 |
| Combat | First round won (charged fights) | 100% | 57% |
| Combat | Net points per charged fight | +33 | +25 |
| Combat | Net points per supported fight / lone fight | - / +33 | - / +25 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 4 of 7 |
| Game | Points lost | 551.7 | 754.7 |
| Game | VP from objectives | 593.3 | 833.3 |
| Game | Lone holders (player turns) | 1.0 | 5.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -122 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1306
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p17

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +8.9 | 0.0 | 54.7 | - | - | - | - |
| ARMY TABLE | 8.3 | +1.9 | 0.0 | 298.7 | 20.0 | +747.7 | 0.0 | 434.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.3 | +0.0 | 0.0 | 41.7 | 0.3 | +0.0 | 0.0 | 55.0 |
| BEST PRIZE | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 21.7 | 0.0 | 0.3 | +0.0 | 43.3 | 55.0 |
| CANNON PLANNED TARGET | 13.0 | +322.0 | 549.3 | 170.0 | 1.0 | +107.3 | 86.7 | 165.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CAST JOB | 0.7 | +30.5 | 0.0 | 0.0 | 2.0 | +58.9 | 269.3 | 246.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 2.7 | +0.0 | 0.0 | 123.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +13.7 | 0.0 | 18.3 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +0.3 | 0.0 | 54.7 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.0 | -545.9 | 0.0 | 244.0 | 17.3 | -1287.5 | 0.0 | 577.3 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 62.0 | 93.7 | 3.0 | +0.0 | 327.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.3 |
| CONVEYANCE SEARCH | - | - | - | - | 4.3 | +214.4 | 136.7 | 123.0 |
| COVER ONCE | 5.3 | -437.4 | 0.0 | 67.3 | 6.0 | -393.3 | 0.0 | 277.7 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 360.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -1.5 | 0.0 | 0.0 | 1.3 | -14.0 | 151.0 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 55.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.5 | 67.3 | 0.0 |
| EXACT ROUND | 1.0 | +9.0 | 134.7 | 93.7 | 2.7 | +15.0 | 218.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +118.4 | 134.7 | 93.7 | 4.0 | +4.7 | 395.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 24.3 | +320.9 | 0.0 | 684.3 |
| FEATURE BUFFS | 0.7 | +20.5 | 0.0 | 109.3 | 2.7 | +42.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -0.3 | 48.3 | 93.7 | 2.3 | +104.0 | 176.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 123.0 | 54.7 | - | - | - | - |
| FIVE ACTION | 95.0 | +5735.3 | 2421.3 | 1287.7 | 94.3 | +5524.1 | 837.7 | 2040.0 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 168.3 |
| FOLLOW UP WEIGHED | 2.3 | +317.1 | 0.0 | 228.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +186.5 | 148.3 | 93.7 | 4.3 | +281.8 | 395.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 145.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +8.0 | 0.0 | 0.0 |
| GOAL WALK | 8.3 | +520.4 | 0.0 | 0.0 | 15.3 | +1237.0 | 0.0 | 0.0 |
| GROUND FLIERS | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.6 | 0.0 | 21.7 |
| GUN MASK | 1.7 | +23.1 | 0.0 | 134.7 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.0 | +0.0 | 0.0 | 44.3 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 189.3 | 6.7 | +0.0 | 0.0 | 195.7 |
| HIS CHARGE DENIED | 0.7 | +8.7 | 13.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 125.0 | 0.7 | +0.0 | 0.0 | 70.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.3 | -28.1 | 0.0 | 54.7 | 4.0 | -79.9 | 0.0 | 70.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 41.7 | 4.7 | +0.0 | 0.0 | 21.7 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 27.3 |
| HIS RANDOM MOVE | 5.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 33.0 | +864.1 | 0.0 | 417.3 | 62.3 | +4494.2 | 0.0 | 1331.0 |
| HIS SHOTS BY HIS RUN | 26.3 | +606.5 | 0.0 | 189.3 | 50.7 | +1528.9 | 0.0 | 1196.0 |
| HIS TURN DENIED | - | - | - | - | 3.7 | +141.3 | 327.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 218.7 | 26.7 | +0.0 | 0.0 | 200.0 |
| HOLDER ASSIGNMENT | 7.7 | +963.5 | 0.0 | 109.3 | 14.0 | +1149.5 | 0.0 | 100.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -32.7 | 92.7 | 93.7 | 4.0 | -81.8 | 395.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +26.1 | 0.0 | 123.0 |
| IDLE COST | - | - | - | - | 18.0 | -211.1 | 0.0 | 423.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | -22.2 | 164.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 125.7 | 509.3 | 3.7 | +0.0 | 134.7 | 235.7 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 21.7 |
| LOST AFTER ESCAPE | 1.3 | +0.8 | 148.3 | 93.7 | 2.0 | +5.8 | 151.0 | 0.0 |
| MANOEUVRE | 3.0 | -24.2 | 0.0 | 0.0 | 1.0 | -7.5 | 0.0 | 30.7 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +20.9 | 0.0 | 68.3 |
| MARCH CHECK | - | - | - | - | 0.7 | +34.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 1.3 | +34.6 | 0.0 | 191.3 |
| MARCH OVER CASTS | - | - | - | - | 2.0 | +230.8 | 0.0 | 124.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +31.7 | 0.0 | 0.0 | 2.7 | +122.1 | 0.0 | 371.3 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +106.6 | 0.0 | 0.0 | 5.7 | +116.4 | 0.0 | 303.0 |
| MISSILES NEXT TURN | 1.3 | +56.9 | 0.0 | 0.0 | 9.7 | +100.4 | 0.0 | 550.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 68.3 |
| MOVE TO CHARGE COMPUTED | 2.0 | +174.8 | 0.0 | 0.0 | 4.3 | +458.6 | 0.0 | 150.3 |
| NEARER NOT NEEDED | 7.7 | +274.0 | 0.0 | 231.3 | 7.7 | +312.6 | 0.0 | 30.7 |
| NEXT CHARGE BY LIST | 0.3 | +10.9 | 0.0 | 0.0 | 3.3 | +380.8 | 0.0 | 27.3 |
| NO DOUBLE ROUNDS | 1.7 | -87.4 | 148.3 | 93.7 | 2.7 | -130.9 | 218.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -153.3 | 0.0 | 0.0 | 2.7 | -170.8 | 67.3 | 55.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -53.3 | 0.0 | 0.0 | 3.7 | -86.0 | 0.0 | 303.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | -1.6 | 109.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | +124.8 | 0.0 | 109.3 | 9.3 | -58.6 | 0.0 | 100.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +13.7 | 13.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +11.8 | 100.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +3.9 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +24.8 | 0.0 | 0.0 |
| PLAN RESULT | 41.7 | +1905.8 | 1498.7 | 880.0 | 47.0 | +500.7 | 176.7 | 1344.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 3.7 | -74.4 | 0.0 | 0.0 | 4.3 | -43.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 2.3 | -1.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -2.9 | 0.0 | 0.0 | 0.7 | -42.3 | 0.0 | 123.0 |
| PROMISE SHOT AWAY | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 20.7 | +1433.0 | 86.7 | 250.0 | 21.3 | +1789.8 | 67.3 | 43.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +16.7 | 0.0 | 236.7 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +20.2 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +3.3 | 41.7 | 0.0 |
| RISK BY ARC | 1.7 | -16.3 | 148.3 | 93.7 | 4.0 | +49.7 | 395.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -5.8 | 69.3 | 0.0 | 2.3 | -68.9 | 353.3 | 0.0 |
| RUN DOWN | 1.7 | -9.0 | 148.3 | 93.7 | 3.3 | -52.7 | 395.0 | 0.0 |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -100.7 | 0.0 | 55.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | +5.1 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +59.3 | 67.3 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -8.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | -11.9 | 55.7 | 0.0 | 1.0 | -24.7 | 0.0 | 30.7 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +44.9 | 68.3 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.7 | +70.9 | 123.0 | 123.0 |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 224.7 | 4.3 | +0.0 | 0.0 | 309.7 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +167.0 | 246.0 | 0.0 | 1.7 | +114.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 55.0 |
| SHOT RISK POINTS | 15.0 | +116.3 | 0.0 | 279.3 | 39.0 | +11.5 | 0.0 | 929.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.7 | +1389.8 | 0.0 | 510.3 | 6.7 | +302.7 | 0.0 | 208.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +44.9 | 68.3 | 0.0 |
| SPELL WORTH | 0.7 | +1.8 | 0.0 | 0.0 | 5.0 | +93.8 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 0.7 | +6.0 | 104.0 | 93.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 54.7 | 9.3 | +0.0 | 0.0 | 168.3 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 69.0 | +0.0 | 2273.0 | 895.3 | 25.3 | +0.0 | 442.7 | 869.0 |
| STAY WORTH | 38.0 | +763.2 | 2027.0 | 304.7 | 10.0 | +128.3 | 308.0 | 806.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.3 | +173.0 | 0.0 | 109.3 | 1.3 | +47.9 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +173.0 | 0.0 | 109.3 | 1.3 | +47.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 55.7 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -29.6 | 0.0 | 123.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 13.7 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 54.7 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 13.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.0 | +0.0 | 0.0 | 468.7 | 46.0 | +0.0 | 0.0 | 901.7 |
| TIED UP BY THE SUM | 1.0 | +100.2 | 44.3 | 0.0 | 0.7 | +44.4 | 109.3 | 0.0 |
| TIME ON OUR SIDE | 48.3 | +492.5 | 96.7 | 298.7 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.3 | +0.0 | 0.0 | 27.3 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -38.3 | 134.7 | 0.0 |
| WHO FIGHTS | 0.3 | -1.5 | 55.7 | 0.0 | 2.0 | +40.2 | 176.7 | 0.0 |
| WHO HITS BACK | 0.3 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.7 | +4.9 | 67.3 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -337.9 | 0.0 | 189.3 | 1.0 | -58.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +13.2 | 109.3 | 0.0 |
| WOUNDS ON THE RANKS | 2.3 | +21.7 | 0.0 | 0.0 | 1.3 | +60.6 | 0.0 | 55.7 |

### Rule changes: cnsr-c940641-p17

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 286 | 285 | 74 | 24.67 | +1894 | +25.6 |
| HOLDER ASSIGNMENT | 65 | 65 | 60 | 20.00 | +5747 | +95.8 |
| ARMY TABLE | 85 | 85 | 58 | 19.33 | +2023 | +34.9 |
| HIS SHOTS BY HIS RUN | 231 | 231 | 47 | 15.67 | +513 | +10.9 |
| SHOT RISK POINTS | 162 | 162 | 39 | 13.00 | +964 | +24.7 |
| TIME ON OUR SIDE | 145 | 138 | 36 | 12.00 | +58 | +1.6 |
| FIVE ACTION | 568 | 566 | 34 | 11.33 | +1441 | +42.4 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| GOAL WALK | 71 | 71 | 20 | 6.67 | +842 | +42.1 |
| LEGAL CHARGES ONLY | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -972 | -48.6 |
| ARTILLERY RE-ROLL WEIGHED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| QUARTER ODDS | 126 | 125 | 14 | 4.67 | +758 | +54.2 |
| MOVE TO CHARGE COMPUTED | 19 | 19 | 13 | 4.33 | +714 | +54.9 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| FOUR ROUNDS | 18 | 17 | 10 | 3.33 | +312 | +31.2 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 9 | 3.00 | +503 | +55.9 |
| CAST JOB | 8 | 8 | 8 | 2.67 | +82 | +10.3 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +952 | +118.9 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 54 | 46 | 8 | 2.67 | +47 | +5.8 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHARGE LOSSES | 91 | 91 | 6 | 2.00 | +615 | +102.6 |
| NEXT CHARGE BY LIST | 11 | 11 | 6 | 2.00 | +484 | +80.7 |
| CHARGE NOW FIRST | 12 | 12 | 5 | 1.67 | -315 | -63.1 |
| MAX FOR POSITIONING | 11 | 11 | 5 | 1.67 | +83 | +16.7 |
| PROMISE BY ITS OWN SUM | 24 | 24 | 5 | 1.67 | -353 | -70.6 |
| SHOTS IN THE MOVE | 88 | 61 | 5 | 1.67 | +136 | +27.1 |
| FALLS SHORT | 73 | 57 | 4 | 1.33 | +11 | +2.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -104 | -25.9 |
| STAY WORTH | 144 | 129 | 4 | 1.33 | +97 | +24.1 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.33 | +150 | +37.5 |
| CANNON PLANNED TARGET | 42 | 42 | 3 | 1.00 | +53 | +17.6 |
| COVER ONCE | 34 | 27 | 3 | 1.00 | +65 | +21.7 |
| FALL BACK GOOD ORDER | 16 | 15 | 3 | 1.00 | +111 | +37.1 |
| FIGHT TO THE END | 9 | 9 | 3 | 1.00 | +38 | +12.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -67 | -22.2 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +18 | +6.0 |
| PROMISE KNOWS THE FIGHT | 7 | 7 | 3 | 1.00 | -3 | -1.0 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 3 | 1.00 | +50 | +16.7 |
| SUPPORT ADDS | 8 | 8 | 3 | 1.00 | +225 | +74.9 |
| SUPPORT WORKED OUT | 8 | 8 | 3 | 1.00 | +225 | +74.9 |
| THE RISK READS HIS RUN | 18 | 18 | 3 | 1.00 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 11 | 10 | 2 | 0.67 | +7 | +3.6 |
| HIS TURN DENIED | 11 | 11 | 2 | 0.67 | +29 | +14.3 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +63 | +31.3 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +47 | +23.4 |
| MISSILES IN THE MOVE | 21 | 14 | 2 | 0.67 | +27 | +13.4 |
| ONE OBJECTIVE FORMULA | 38 | 26 | 2 | 0.67 | +134 | +66.8 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +4 | +2.2 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +38 | +18.9 |
| RISK BY ARC | 17 | 16 | 2 | 0.67 | +14 | +7.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +15 | +7.7 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 21 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +27 | +26.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -34 | -34.3 |
| CHAFF IN THE MOVE | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +24 | +23.9 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +0 | +0.2 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +25 | +25.0 |
| LOST AFTER ESCAPE | 10 | 10 | 1 | 0.33 | +0 | +0.2 |
| MISSILES NEXT TURN | 33 | 22 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 46 | 45 | 1 | 0.33 | +48 | +47.6 |
| NO DOUBLE ROUNDS | 13 | 12 | 1 | 0.33 | +37 | +36.9 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE FIGHT FORMULA | 19 | 11 | 1 | 0.33 | +89 | +89.4 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +74 | +74.4 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | +141 | +141.0 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +178 | +178.0 |
| SET UP BY THE SET | 6 | 6 | 1 | 0.33 | +98 | +97.7 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +5 | +5.4 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +17 | +16.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +27 | +27.3 |
| WHOLE FIGHT | 2 | 1 | 1 | 0.33 | +12 | +12.3 |
| WHOLE FIGHT DANGER | 16 | 16 | 1 | 0.33 | +10 | +9.6 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +9 | +9.1 |
| WOUNDS ON THE RANKS | 11 | 11 | 1 | 0.33 | +74 | +74.5 |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 62 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 13 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 10 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 21 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 21 | 21 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 14 | not checked | - | - | - | - |
| GUN MASK | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 42 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 11 | 11 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 12 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 17 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 17 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 114 | 114 | 0 | 0.00 | - | - |
| HONEST WORTH | 16 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 12 | 12 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 266 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 63 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 23 | 23 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 41 | 36 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 283 | 282 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 264 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 7 | 6 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p17

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 2.33 | 50.5 |
| ARMY TABLE | rule | 1.67 | 1.33 | 83.1 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 0.67 | 70.6 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 78.8 |
| MARCH OF THE TABLE | rule | - | 1.33 | 25.9 |
| JOINT CHARGE NOW | rule | - | 0.67 | 72.5 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 1.4 |
| BEST PRIZE | rule | - | 0.33 | 34.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 28.4 |
| NO REASON | gate | - | 0.33 | 12.6 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 0.9 |

### Plans: cnsr-c940641-p17

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 80% | 169 | 150 | 88% |
| Mine | move | 26.0 | 99% | 1210 | 0 | 0% |
| Mine | shoot | 14.0 | 62% | 1362 | 1756 | 129% |
| Opponent | charge | 4.0 | 50% | 526 | 230 | 44% |
| Opponent | join | 2.3 | 100% | 81 | 0 | 0% |
| Opponent | move | 36.3 | 95% | 2149 | 0 | 0% |
| Opponent | shoot | 3.3 | 80% | 164 | 271 | 165% |
| Opponent | support | 1.0 | 67% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p17

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p17

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 20 (12) | 20 | 0 | 26 | 75% | 2.0 | 0 (4) | 0 (3) | 41 (3) | 30 (6) | 0 (4) |
| Mine | Fast Hammer | 5 | 71 (5) | 58 | 13 | 22 | 60% | 1.5 | 111 (3) | 0 (1) | 50 (1) | 22 (3) | 138 (2) |
| Mine | Hammer | 4 | 39 (4) | 13 | 26 | 0 | 50% | 1.0 | 0 (1) | 55 (3) | - | 19 (3) | 89 (1) |
| Mine | Shooter | 5 | 29 (5) | 24 | 4 | 77 | 0% | 1.2 | 0 (1) | 0 (2) | 70 (2) | 29 (5) | - |
| Mine | War machine | 11 | 45 (11) | 45 | 0 | 46 | 9% | 1.4 | 10 (5) | 75 (6) | - | 0 (2) | 56 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 19 | 100% | - | 0 (3) | 0 (2) | - | 0 (5) | - |
| Opponent | Character | 11 | 19 (11) | 19 | 0 | 46 | 27% | 2.4 | 0 (3) | 14 (5) | 36 (3) | 22 (7) | 16 (4) |
| Opponent | Clean-up | 1 | 220 (1) | 0 | 220 | 100 | 0% | 3.0 | - | 220 (1) | - | 220 (1) | - |
| Opponent | Fast Hammer | 6 | 85 (6) | 38 | 47 | 14 | 17% | 3.0 | 78 (3) | 96 (3) | - | 134 (4) | 29 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 68 (4) | 68 | 0 | 69 | 25% | 1.7 | 72 (2) | 134 (1) | 0 (1) | 98 (3) | 0 (1) |
| Opponent | Holder | 4 | 111 (4) | 0 | 111 | 19 | 50% | 3.0 | - | 40 (2) | 171 (2) | 111 (4) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 50 | 0% | 2.5 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 39 (2) | 39 | 0 | 100 | 0% | 1.0 | - | 39 (2) | - | 79 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: cnsr-c940641-p17

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 386 | 148 | 1.7 | 1.0 | 89 | 56 | +33 | 0 of 5 | 5 of 5 | - | +33 |
| Opponent | Grand Cathay | 1 | 332 | 125 | 1.0 | 1.0 | 125 | 0 | +125 | 0 of 1 | 1 of 1 | - | +125 |
| Opponent | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 270 | -270 | 1 of 2 | 2 of 2 | - | -270 |
| Opponent | Vampire Counts | 1 | 0 | 593 | 4.0 | 1.0 | 148 | 0 | +148 | 3 of 4 | 1 of 4 | - | +148 |
| **Opponent** | all armies | 3 | 111 | 239 | 2.3 | 1.0 | 103 | 77 | +25 | 4 of 7 | 4 of 7 | - | +25 |

### Effective charges: cnsr-c940641-p17

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 5 | 0 | 0 | 1 (net -281) | 0 | 0 | 2 (net +46) | 2 | 33% (1 of 3) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +125) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net -540) | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 4 | 1 (net +102) | 0 | 1 (net +0) | 1 (net +289) | 0 | 0 | 1 | 33% (1 of 3) |

### Charged fights, damage counted: cnsr-c940641-p17

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 181 | 145 | -281 | 87 | 340 | -254 | -140.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 189 | 92 | +46 | 46 | 0 | +46 | +24.3 |
| Mine | No odds | 2 | 322 | 156 | +176 | 198 | 176 | +22 | +6.9 |
| Mine | All fights | 5 | 241 | 128 | +33 | 115 | 139 | -23 | -9.7 |
| Opponent | Long shot (under 50%) | 1 | 50 | 202 | +102 | 167 | 0 | +167 | +334.0 |
| Opponent | Effective (55-75%) | 1 | 186 | 265 | +0 | 26 | 0 | +26 | +14.2 |
| Opponent | 76-89% | 3 | 99 | 122 | +138 | 138 | 16 | +122 | +123.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 112 | 189 | -540 | 94 | 540 | -446 | -397.8 |
| Opponent | No odds | 1 | 186 | 202 | +202 | 202 | 0 | +202 | +108.6 |
| Opponent | All fights | 7 | 119 | 175 | +25 | 129 | 84 | +45 | +37.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p17 | move | 15 | 4 (27%) | 3 (20%) | 2 (13%) | 9 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

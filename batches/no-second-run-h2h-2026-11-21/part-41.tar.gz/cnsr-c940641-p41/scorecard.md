# Doctrine scorecard: cnsr-c940641-p41

### Scorecard: cnsr-c940641-p41

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 4 | 1 | 3 | 1 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 1 | 4 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 425 |
| L0810 | 6 | 1 | Opponent | no | 8 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 538 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 6 | 0 | 0 | 0 | 60 |
| **Average** | | | Mine | 0% | 2.0 | 1.0 | 1.3 | 1.3 | 0.0 | 0.0 | 0.0 | 377.7 |
| **Average** | | | Opponent | 67% | 4.0 | 2.0 | 0.7 | 3.3 | 0.3 | 0.0 | 0.0 | 248.3 |

### KPIs: cnsr-c940641-p41

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (12 of 12) | 0% (0 of 14) | 46% (12 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 100% (8 of 8); on the table 100% | 100% (10 of 10); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 25% (9 of 36) | 31% (13 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 80% (4 of 5) | 30% (9 of 30) | 37% (13 of 35) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 60% (3623 of 5999) | 67% (3990 of 5998) | 63% (7613 of 11997) |
|   infantry points that never fought | lower | 54% (520 of 968) | 72% (799 of 1113) | 63% (1319 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (19 of 30) | 60% (15 of 25) | 62% (34 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 4.3 uses a game | 100% (3 of 3); 2.2 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 50% (1 of 2); 0.3 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (3068 of 5378) | 58% (3030 of 5181) | 58% (6098 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (52%) | 4.7 (48%) |
| MARCHED: its unit marched | 0.3 (50%) | 2.3 (26%) | 2.7 (28%) |
| IN COMBAT: engaged in combat | 0.3 (50%) | 0.3 (4%) | 0.7 (7%) |
| FLEEING: fleeing | 0.0 (0%) | 1.0 (11%) | 1.0 (10%) |
| GONE: slain | 0.0 (0%) | 0.7 (7%) | 0.7 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.0 | 2.0 | 4.0 | 4.3 | 1.3 | 0.7 |
| not cast | 3.0 | 0.0 | 2.0 | 9.7 | 2.7 | 27.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.3 (17%) | 4.7 (48%) | 1.7 (62%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 2.7 (28%) | 1.0 (38%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | - | 0.0 (0%) | 1.0 (10%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (33%) | - | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 2.0 (7%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (67%) | - | 1.7 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.0 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 4.0 a game | 2.0 a game |
| stood (cast and not dispelled) | - | 50% (6 of 12) | 50% (6 of 12) |
| the unit moved after it | - | 67% (4 of 6) | 67% (4 of 6) |
| it charged on its next turn | - | 0% (0 of 6) | 0% (0 of 6) |
| the enemy charged it first | - | 0% (0 of 6) | 0% (0 of 6) |
| it fought by the end of its next turn | - | 0% (0 of 6) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 6) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (6 of 6) | 100% (6 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (61 of 83) | 77% (24 of 31) | 75% (85 of 114) |
|   cavalry | 80% (12 of 15) | - | 80% (12 of 15) |
|   chariot | 100% (7 of 7) | 76% (13 of 17) | 83% (20 of 24) |
|   infantry | 38% (3 of 8) | 73% (8 of 11) | 58% (11 of 19) |
|   war machine | 74% (39 of 53) | 100% (3 of 3) | 75% (42 of 56) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (27%) | 0.0 (0%) | 2.0 (21%) |
| CHARGED: it charged | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (14%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (14%) | 0.3 (3%) |
| MOVED: a war machine that moved | 2.0 (27%) | 0.0 (0%) | 2.0 (21%) |
| NO TARGET IN RANGE | 0.7 (9%) | 1.3 (57%) | 2.0 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (5%) | 0.3 (14%) | 0.7 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (18%) | 0.0 (0%) | 1.3 (14%) |
| OTHER BAR | 0.7 (9%) | 0.0 (0%) | 0.7 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 5.0 | 65% | 11.7 pts | 90 pts |
| chariot | 7.0 | 0.3 | 95% | 2.1 pts | 15 pts |
| infantry | 3.7 | 1.3 | 64% | 8.4 pts | 31 pts |
| war machine | 14.3 | 14.0 | 60% | 31.2 pts | 448 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 3.3 | 2.5 |
| Charges that made contact a game | 1.7 | 2.3 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.20 declared, 0.20 contact (5 units) | 0.33 declared, 0.33 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.50 contact (2 units) | 1.00 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.19 declared, 0.19 contact (21 units) | 0.32 declared, 0.23 contact (22 units) | 0.26 declared, 0.21 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (3 of 9) | 0% (0 of 3) | 100% (1 of 1) | 31% (4 of 13) |
| Character in a unit | 100% (6 of 6) | - | - | 100% (6 of 6) |
| Character on its own | 100% (5 of 5) | 0% (0 of 2) | 50% (2 of 4) | 64% (7 of 11) |
| Chariot | 33% (1 of 3) | 100% (2 of 2) | - | 60% (3 of 5) |
| Infantry | 67% (2 of 3) | 100% (1 of 1) | 50% (1 of 2) | 67% (4 of 6) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 69% (9 of 13) | - | - | 69% (9 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (2 of 2); on the table 100% | 67% (4 of 6) | 60% | 63% (19 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 33% (1 of 3); 0.3 uses a game |
| Grand Cathay | 1 | - | 29% (7 of 24) | 90% | 40% (4 of 10) | 100% (2 of 2); 9.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 52% | 78% (7 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 58% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p41, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (3) | 50% (2) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.67 | 0.00 | 0.67 |

### Quality by phase: cnsr-c940641-p41

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | 67% (6 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 23% (11 of 48) | 44% (8 of 18) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 75% (3 of 4) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 45% (5 of 11) | 33% (3 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.3 | 3.3 |
| Movement | Points that never moved of their own | 377.7 | 248.3 |
| Movement | Fights charged into per game | 1.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +0 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 3 of 6, net +360 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +92 | 1 of 6, net +77 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.7 | 7.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (8 of 26) | 43% (9 of 21) |
| Shooting | Points destroyed by shooting units | 118.3 | 0.0 |
| Shooting | War machine shots | 13.0 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (18 of 39) | 0% (0 of 4) |
| Shooting | Points destroyed by war machines | 266.7 | 43.3 |
| Magic | Magic missiles cast | 1.0 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 67% (4 of 6) |
| Magic | Wounds caused by magic missiles | 1.3 | 8.7 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 143.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.3 / 0.0 / 0.0 | 3.7 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 116.7 | 176.7 |
| Combat | Points run down | 30.7 | 287.3 |
| Combat | Net points per charged fight, damage counted | +92 | +260 |
| Combat | Net per 100 charger points, damage counted | +41.8 | +114.2 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +101 | +236 |
| Combat | Net points per supported fight / lone fight | - / +101 | +866 / +110 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 5 | 3 of 6 |
| Game | Points lost | 959.7 | 622.3 |
| Game | VP from objectives | 526.7 | 900.0 |
| Game | Lone holders (player turns) | 2.0 | 4.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -742 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1582
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p41

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +57.2 | 0.0 | 0.0 |
| ARMY TABLE | 5.3 | +29.4 | 0.0 | 0.0 | 20.7 | +471.4 | 0.0 | 389.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.0 | +0.0 | 0.0 | 41.7 | 0.3 | +0.0 | 0.0 | 55.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -8.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 378.3 | 0.0 | 0.3 | +0.0 | 43.3 | 55.0 |
| CANNON PLANNED TARGET | 12.7 | +428.7 | 1286.7 | 170.0 | 1.0 | +107.3 | 86.7 | 165.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CAST JOB | 2.0 | +82.8 | 273.3 | 0.0 | 2.0 | +14.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +4.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +16.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.0 | -782.7 | 0.0 | 794.3 | 16.7 | -1450.6 | 0.0 | 710.7 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 355.7 | 156.7 | 1.7 | +0.0 | 182.0 | 68.3 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 286.0 | 14.0 | +0.0 | 0.0 | 147.3 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 3.7 | +321.5 | 0.0 | 0.0 |
| COVER ONCE | 8.3 | -487.6 | 0.0 | 506.0 | 7.7 | -576.5 | 0.0 | 99.0 |
| DENIED BY THE FIGHT | 0.3 | -0.5 | 0.0 | 63.0 | 0.7 | -6.1 | 41.7 | 68.3 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 55.0 |
| EDGE GIVE GROUND | 0.3 | +38.9 | 68.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.3 | +39.2 | 138.3 | 156.7 | 2.0 | +15.2 | 242.0 | 68.3 |
| FALL BACK GOOD ORDER | 1.3 | +17.4 | 100.7 | 156.7 | 3.0 | +0.9 | 408.0 | 68.3 |
| FALLS SHORT | - | - | - | - | 26.0 | +350.0 | 0.0 | 495.7 |
| FEATURE BUFFS | 0.3 | +10.2 | 0.0 | 0.0 | 2.3 | +27.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -0.8 | 68.3 | 93.7 | 0.7 | +28.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 88.3 | +5454.7 | 3220.7 | 2175.3 | 97.0 | +5158.0 | 972.7 | 1926.0 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 336.3 | 3.7 | +0.0 | 0.0 | 135.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.7 | +224.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +82.6 | 169.0 | 156.7 | 3.3 | +274.8 | 471.0 | 68.3 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 70.0 |
| FRIEND SHOOTS FIRST | 1.0 | -19.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 7.3 | +663.3 | 0.0 | 25.7 | 17.3 | +1170.9 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +0.0 | 0.0 | 176.7 | 1.7 | +8.4 | 0.0 | 21.7 |
| GUN MASK | 2.0 | +56.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 155.7 | - | - | - | - |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 794.3 | 6.3 | +0.0 | 0.0 | 170.7 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 90.0 | - | - | - | - |
| HIS LEGAL MOVES | 0.7 | +0.0 | 0.0 | 134.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.0 | -80.8 | 0.0 | 244.0 | 2.3 | -32.8 | 0.0 | 180.0 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 370.7 | 6.7 | +0.0 | 0.0 | 126.7 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 134.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 8.3 | +0.0 | 0.0 | 51.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 29.3 | +662.1 | 0.0 | 789.3 | 64.7 | +4548.1 | 0.0 | 1011.0 |
| HIS SHOTS BY HIS RUN | 24.3 | +566.1 | 0.0 | 539.3 | 53.3 | +1771.8 | 0.0 | 1147.7 |
| HIS TURN DENIED | 0.3 | +3.7 | 0.0 | 63.0 | 1.3 | +55.2 | 41.7 | 68.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 186.0 | 23.0 | +0.0 | 0.0 | 61.3 |
| HOLDER ASSIGNMENT | 8.7 | +949.6 | 0.0 | 147.7 | 14.3 | +1116.3 | 0.0 | 30.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -24.5 | 100.7 | 156.7 | 2.7 | -67.1 | 267.7 | 68.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +26.1 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.7 | -221.3 | 0.0 | 360.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | -66.9 | 140.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 15.0 | 197.7 | 4.3 | +0.0 | 358.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -7.2 | 169.0 | 156.7 | 2.7 | +5.7 | 456.0 | 68.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +7.5 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +29.6 | 0.0 | 0.0 | 0.3 | +5.6 | 0.0 | 68.3 |
| MARCH CHECK | - | - | - | - | 0.3 | +10.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 1.3 | +26.2 | 0.0 | 68.3 |
| MARCH OVER CASTS | 0.3 | -36.3 | 0.0 | 0.0 | 0.7 | +141.7 | 0.0 | 68.3 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +53.9 | 0.0 | 67.3 | 3.0 | +54.3 | 0.0 | 180.0 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +49.7 | 0.0 | 0.0 | 7.7 | +90.0 | 0.0 | 180.0 |
| MISSILES NEXT TURN | 1.3 | +41.8 | 0.0 | 0.0 | 10.3 | +101.8 | 0.0 | 428.3 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 21.7 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.7 | +302.2 | 0.0 | 0.0 | 3.7 | +546.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +385.2 | 0.0 | 329.7 | 9.0 | +428.8 | 0.0 | 30.7 |
| NEXT CHARGE BY LIST | 5.0 | +528.2 | 285.0 | 134.7 | 3.3 | +511.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -3.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -55.4 | 99.0 | 156.7 | 2.7 | -73.2 | 408.0 | 68.3 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.7 | +0.0 | 0.0 | 30.0 | - | - | - | - |
| NOT WORTH A CAST | 0.7 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.0 | -431.1 | 0.0 | 130.0 | 1.7 | -143.9 | 0.0 | 55.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -85.2 | 0.0 | 134.7 | 3.7 | -93.1 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +28.3 | 140.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | +67.4 | 0.0 | 147.7 | 8.0 | -86.6 | 0.0 | 30.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -71.9 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +5.9 | 18.3 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +17.6 | 15.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +16.0 | 100.7 | 0.0 | 0.3 | +4.5 | 140.3 | 0.0 |
| PATHS CROSS | 0.3 | +3.7 | 0.0 | 0.0 | 1.3 | +13.9 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +41.3 | 0.0 | 180.0 |
| PLAN RESULT | 40.3 | +1332.0 | 1300.3 | 1339.3 | 48.3 | +485.6 | 239.7 | 1053.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.3 | -501.2 | 0.0 | 176.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | -2.9 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.0 | -19.2 | 0.0 | 0.0 | 0.3 | -28.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.7 | +1573.6 | 220.7 | 767.7 | 20.3 | +1914.6 | 529.7 | 363.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +48.9 | 0.0 | 236.7 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.0 | +22.7 | 0.0 | 33.3 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 33.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +12.9 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | -4.1 | 169.0 | 156.7 | 2.3 | -44.2 | 270.7 | 68.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -50.3 | 325.7 | 0.0 |
| RUN DOWN | 1.3 | -12.3 | 99.0 | 156.7 | 2.3 | -31.2 | 393.0 | 68.3 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +17.8 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.7 | -35.5 | 118.3 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 3.0 | -234.7 | 0.0 | 15.0 |
| SEARCH SPOT | 0.3 | +3.1 | 0.0 | 54.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +28.2 | 140.3 | 0.0 |
| SET CREDITED ONCE | 1.3 | -14.7 | 0.0 | 0.0 | 0.7 | -99.0 | 0.0 | 15.0 |
| SET UP BY THE SET | 1.3 | +9.3 | 0.0 | 0.0 | 1.7 | +217.8 | 0.0 | 15.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +7.5 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 1.0 | +111.4 | 68.3 | 0.0 |
| SHOOTERS ON THE TABLE | 16.0 | +0.0 | 0.0 | 359.3 | 5.0 | +0.0 | 0.0 | 388.3 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 3.3 | +39.3 | 202.3 | 201.7 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 55.0 |
| SHOT RISK POINTS | 16.0 | -87.4 | 0.0 | 513.7 | 37.7 | -93.8 | 0.0 | 1068.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 21.7 | +1187.3 | 0.0 | 603.3 | 7.0 | +253.5 | 0.0 | 230.0 |
| SPELL WORTH | 1.0 | +2.8 | 56.7 | 56.7 | 5.3 | +87.8 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 1.0 | -4.0 | 70.0 | 156.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 54.7 | 10.3 | +0.0 | 0.0 | 95.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.2 | 25.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 25.7 | 180.0 |
| STANDS STILL | 63.0 | +0.0 | 3051.7 | 1546.7 | 25.3 | +0.0 | 501.7 | 845.0 |
| STAY WORTH | 38.3 | +540.4 | 2825.0 | 540.7 | 10.0 | +110.6 | 299.3 | 646.7 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 96.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +155.8 | 0.0 | 0.0 | 5.0 | +138.8 | 0.0 | 67.3 |
| SUPPORT WORKED OUT | 2.7 | +155.8 | 0.0 | 0.0 | 5.0 | +138.8 | 0.0 | 67.3 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +0.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -28.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.3 | +0.0 | 0.0 | 994.3 | 47.0 | +0.0 | 0.0 | 818.0 |
| TIED UP BY THE SUM | 0.3 | +22.3 | 30.7 | 0.0 | 0.3 | +22.2 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 45.3 | +480.7 | 0.0 | 1059.0 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +2.4 | 126.0 | 0.0 |
| WHO FIGHTS | 0.3 | +2.8 | 0.0 | 63.0 | 1.3 | +45.5 | 185.3 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +3.8 | 63.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -509.3 | 0.0 | 483.0 | 1.7 | -168.7 | 0.0 | 30.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +57.9 | 140.3 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +28.3 | 0.0 | 134.7 | 3.3 | +85.8 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p41

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOTS BY HIS RUN | 233 | 226 | 65 | 21.67 | +950 | +14.6 |
| HOLDER ASSIGNMENT | 69 | 69 | 64 | 21.33 | +4509 | +70.5 |
| HIS SHOT LIST | 282 | 271 | 60 | 20.00 | +1548 | +25.8 |
| ARMY TABLE | 78 | 78 | 58 | 19.33 | +1581 | +27.3 |
| SHOT RISK POINTS | 161 | 153 | 32 | 10.67 | +675 | +21.1 |
| TIME ON OUR SIDE | 136 | 115 | 27 | 9.00 | +61 | +2.2 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -1725 | -86.2 |
| FIVE ACTION | 556 | 544 | 18 | 6.00 | +1082 | +60.1 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 22 | 19 | 15 | 5.00 | +933 | +62.2 |
| GOAL WALK | 74 | 74 | 14 | 4.67 | +897 | +64.1 |
| NEXT CHARGE BY LIST | 25 | 23 | 14 | 4.67 | +911 | +65.1 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| QUARTER ODDS | 111 | 107 | 13 | 4.33 | +725 | +55.8 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| PROMISE BY ITS OWN SUM | 33 | 33 | 11 | 3.67 | -1504 | -136.7 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| IDLE COST | 47 | 44 | 9 | 3.00 | +32 | +3.5 |
| CHARGE NOW FIRST | 14 | 14 | 8 | 2.67 | -287 | -35.9 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +147 | +18.3 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 8 | 2.67 | +9 | +1.2 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CAST JOB | 12 | 12 | 7 | 2.33 | +30 | +4.3 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 145 | 130 | 6 | 2.00 | +17 | +2.9 |
| FALLS SHORT | 78 | 68 | 5 | 1.67 | +19 | +3.9 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +673 | +134.6 |
| PATHS CROSS | 5 | 5 | 5 | 1.67 | +53 | +10.6 |
| PROMISE KNOWS THE FIGHT | 8 | 6 | 5 | 1.67 | -9 | -1.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -78 | -19.6 |
| MAX FOR POSITIONING | 15 | 15 | 4 | 1.33 | +2 | +0.4 |
| CHARGE LOSSES | 89 | 83 | 3 | 1.00 | +287 | +95.6 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 48 | 33 | 3 | 1.00 | +22 | +7.2 |
| FOUR ROUNDS | 15 | 14 | 3 | 1.00 | +79 | +26.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MISSILES IN THE MOVE | 27 | 17 | 3 | 1.00 | +30 | +10.1 |
| SUPPORT ADDS | 23 | 21 | 3 | 1.00 | +3 | +0.9 |
| SUPPORT WORKED OUT | 23 | 21 | 3 | 1.00 | +3 | +0.9 |
| WHOLE FIGHT DANGER | 16 | 16 | 3 | 1.00 | +4 | +1.5 |
| CANNON PLANNED TARGET | 41 | 41 | 2 | 0.67 | +53 | +26.4 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -201 | -100.3 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +105 | +52.7 |
| MISSILES NEXT TURN | 35 | 24 | 2 | 0.67 | +1 | +0.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SET UP BY THE SET | 9 | 9 | 2 | 0.67 | +424 | +211.8 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +172 | +171.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -26 | -26.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +50 | +49.7 |
| EXACT ROUND | 10 | 10 | 1 | 0.33 | +25 | +25.0 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +21 | +20.7 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GUN MASK | 6 | 6 | 1 | 0.33 | +8 | +8.4 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +25 | +25.0 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +12 | +12.4 |
| NEARER NOT NEEDED | 52 | 48 | 1 | 0.33 | +87 | +86.6 |
| NO DOUBLE ROUNDS | 12 | 11 | 1 | 0.33 | +48 | +47.6 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE OBJECTIVE FORMULA | 34 | 27 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -216 | -215.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +124 | +123.8 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| REDIRECT COUNTER | 3 | 2 | 1 | 0.33 | +45 | +45.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +39 | +38.6 |
| RISK BY ARC | 12 | 11 | 1 | 0.33 | +5 | +5.4 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +53 | +53.3 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +9 | +9.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +85 | +84.6 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 86 | 60 | 1 | 0.33 | +21 | +21.2 |
| SPELLS IN THE FIGHT | 3 | 3 | 1 | 0.33 | +5 | +5.4 |
| THE ROW IN ITS ORDER | 17 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 5 | 5 | 1 | 0.33 | +82 | +82.1 |
| WOUNDS ON THE RANKS | 16 | 16 | 1 | 0.33 | +61 | +60.9 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 62 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 11 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 23 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 42 | 36 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 13 | 13 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 6 | 6 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 31 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 13 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 25 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 108 | 108 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 12 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 26 | 15 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 1 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 266 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | not checked | - | - | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 10 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 63 | not checked | - | - | - | - |
| SPELL WORTH | 19 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 43 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 265 | 257 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | 2 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 5 | not checked | - | - | - | - |
| THE TABLE BINDS | 259 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 2 | 2 | 0 | 0.00 | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p41

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 1.33 | 87.0 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | - | 136.7 |
| CHARGE NOW FIRST | rule | 2.33 | 0.33 | 35.9 |
| ARMY TABLE | rule | 1.00 | 1.33 | 43.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.67 | 1.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 8.3 |
| MARCH OF THE TABLE | rule | - | 1.00 | 26.2 |
| JOINT CHARGE NOW | rule | - | 0.67 | 100.3 |
| BEST PRIZE | rule | - | 0.33 | 26.0 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 215.6 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 1.1 |
| RULE SWITCHED OFF | gate | - | 0.33 | 72.2 |

### Plans: cnsr-c940641-p41

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 100% | 213 | 222 | 105% |
| Mine | join | 0.7 | 100% | 9 | 0 | 0% |
| Mine | move | 24.7 | 95% | 1159 | 0 | 0% |
| Mine | shoot | 13.3 | 48% | 1164 | 1110 | 95% |
| Opponent | charge | 2.3 | 71% | 431 | 332 | 77% |
| Opponent | join | 2.0 | 100% | 62 | 0 | 0% |
| Opponent | move | 38.3 | 95% | 1915 | 0 | 0% |
| Opponent | shoot | 4.3 | 69% | 323 | 153 | 48% |
| Opponent | support | 1.3 | 75% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p41

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p41

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 14 (12) | 14 | 0 | 58 | 67% | 3.0 | 0 (3) | 0 (3) | 30 (3) | 27 (5) | 0 (4) |
| Mine | Fast Hammer | 5 | 52 (5) | 30 | 23 | 42 | 40% | 3.7 | 48 (3) | 22 (1) | 88 (1) | 56 (3) | 47 (2) |
| Mine | Hammer | 4 | 28 (4) | 0 | 28 | 54 | 25% | 2.3 | 0 (1) | 40 (3) | - | 0 (3) | 97 (1) |
| Mine | Shooter | 5 | 63 (5) | 54 | 9 | 89 | 0% | 1.4 | 125 (1) | 12 (2) | 70 (2) | 63 (5) | - |
| Mine | War machine | 11 | 57 (11) | 57 | 0 | 37 | 9% | 1.6 | 113 (5) | 10 (6) | - | 0 (2) | 70 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 50 | 50% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 59 | 100% | - | 0 (3) | 0 (2) | - | 0 (5) | - |
| Opponent | Character | 11 | 42 (11) | 42 | 0 | 36 | 36% | 3.1 | 112 (3) | 0 (4) | 32 (3) | 95 (5) | 12 (5) |
| Opponent | Clean-up | 1 | 461 (1) | 461 | 0 | 0 | 0% | 6.0 | - | 461 (1) | - | 461 (1) | - |
| Opponent | Fast Hammer | 6 | 91 (6) | 44 | 47 | 0 | 17% | 2.2 | 82 (3) | 105 (3) | - | 170 (4) | 0 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 59 (4) | 59 | 0 | 49 | 0% | 3.0 | 147 (2) | 0 (1) | 0 (1) | 85 (3) | 0 (1) |
| Opponent | Holder | 4 | 145 (4) | 16 | 129 | 19 | 75% | 3.0 | - | 0 (2) | 269 (2) | 189 (3) | 0 (1) |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 100 | 0% | 2.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 39 (2) | 39 | 0 | 100 | 0% | 1.0 | - | 39 (2) | - | 79 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: cnsr-c940641-p41

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 385 | 169 | 1.7 | 1.0 | 101 | 0 | +101 | 3 of 5 | 5 of 5 | - | +101 |
| Opponent | Grand Cathay | 1 | 559 | 125 | 1.0 | 1.0 | 125 | 0 | +125 | 0 of 1 | 1 of 1 | - | +125 |
| Opponent | Skaven | 1 | 0 | 266 | 2.0 | 1.0 | 133 | 70 | +63 | 1 of 2 | 2 of 2 | - | +63 |
| Opponent | Vampire Counts | 1 | 0 | 1165 | 3.0 | 1.3 | 388 | 0 | +388 | 2 of 3 | 3 of 3 | +866 | +150 |
| **Opponent** | all armies | 3 | 186 | 519 | 2.0 | 1.2 | 259 | 23 | +236 | 3 of 6 | 6 of 6 | +866 | +110 |

### Effective charges: cnsr-c940641-p41

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 5 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +208) | 0 | 1 (net +92) | 0 | 20% (1 of 5) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +125) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 0 | 0 | 1 (net +49) | 0 | 0 | 1 (net +77) | 0 | 50% (1 of 2) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 2 (net +515) | 1 (net +135) | 0 | 0 | 0 | 67% (2 of 3) |

### Charged fights, damage counted: cnsr-c940641-p41

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 189 | 222 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 181 | 145 | +0 | 0 | 45 | -45 | -25.0 |
| Mine | 76-89% | 2 | 272 | 208 | +208 | 266 | 48 | +218 | +80.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 189 | 92 | +92 | 92 | 21 | +71 | +37.6 |
| Mine | All fights | 5 | 221 | 175 | +101 | 125 | 32 | +92 | +41.8 |
| Opponent | Effective (55-75%) | 3 | 295 | 275 | +360 | 477 | 69 | +408 | +138.4 |
| Opponent | 76-89% | 2 | 196 | 130 | +130 | 130 | 0 | +130 | +66.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 92 | 77 | +77 | 77 | 0 | +77 | +83.7 |
| Opponent | All fights | 6 | 228 | 194 | +236 | 295 | 35 | +260 | +114.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p41 | move | 15 | 4 (27%) | 3 (20%) | 2 (13%) | 9 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

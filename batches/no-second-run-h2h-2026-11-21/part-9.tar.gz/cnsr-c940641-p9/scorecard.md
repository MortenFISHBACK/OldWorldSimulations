# Doctrine scorecard: cnsr-c940641-p9

### Scorecard: cnsr-c940641-p9

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 6 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Opponent | no | - | - | 2 | 5 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 50% | 6.0 | 3.0 | 3.0 | 0.5 | 0.5 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 0% | 0.0 | 2.0 | 3.0 | 4.5 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: cnsr-c940641-p9

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 14) | 0% (0 of 29) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 50% (1 of 2); on the table 50% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 2); on the table 50% | 0% (0 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 25% (1 of 4); on the table 50% | 43% (3 of 7); on the table 57% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 4) | 56% (10 of 18) | 45% (10 of 22) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 56% (10 of 18) | 56% (10 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 44% (1761 of 4000) | 51% (2050 of 3999) | 48% (3811 of 7999) |
|   infantry points that never fought | lower | 52% (497 of 959) | 68% (310 of 457) | 57% (807 of 1416) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (8 of 13) | 83% (10 of 12) | 72% (18 of 25) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 0.0 uses a game | 100% (2 of 2); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (2085 of 3520) | 82% (2588 of 3154) | 70% (4673 of 6674) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.7 (100%) | 2.7 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 2.0 | 1.3 | 3.3 | 0.7 | 0.7 |
| not cast | 6.0 | 2.0 | 0.7 | 2.7 | 1.3 | 25.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 2.7 (100%) | 0.7 (50%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 1.0 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (6%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.7 (94%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.3 (99%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.0 a game | 0.7 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (31 of 53) | - | 58% (31 of 53) |
|   cavalry | 69% (9 of 13) | - | 69% (9 of 13) |
|   character | 38% (3 of 8) | - | 38% (3 of 8) |
|   chariot | 50% (3 of 6) | - | 50% (3 of 6) |
|   infantry | 43% (6 of 14) | - | 43% (6 of 14) |
|   war machine | 83% (10 of 12) | - | 83% (10 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (32%) | - | 2.3 (32%) |
| CHARGED: it charged | 0.7 (9%) | - | 0.7 (9%) |
| IN COMBAT: it fought this turn or the last | 1.3 (18%) | - | 1.3 (18%) |
| MOVED: a war machine that moved | 0.7 (9%) | - | 0.7 (9%) |
| NO TARGET IN RANGE | 2.0 (27%) | - | 2.0 (27%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (5%) | - | 0.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 1.3 | 67% | 0.9 pts | 3 pts |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 3.7 | 2.0 | 82% | 1.6 pts | 6 pts |
| war machine | 3.3 | 2.0 | 60% | 13.7 pts | 46 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 4.0 | 4.0 |
| Charges that made contact a game | 3.0 | 3.0 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) | 0.50 declared, 0.50 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.41 contact (22 units) | 0.40 declared, 0.28 contact (25 units) | 0.47 declared, 0.34 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (2 of 2) | 50% (1 of 2) | 57% (4 of 7) |
| Character in a unit | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Character on its own | - | 50% (1 of 2) | 80% (4 of 5) | 71% (5 of 7) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 75% (3 of 4) | 50% (1 of 2) | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 44% | 57% (4 of 7) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 44% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 2 | 25% (1 of 4); on the table 50% | 56% (10 of 18) | 51% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p9, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 33% (3) | 38% (5) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p9

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (4 of 8) | 50% (5 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 5% (1 of 19) | 0% (0 of 6) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 100% (1 of 1) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 100% (5 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.5 | 4.5 |
| Movement | Points that never moved of their own | 0.0 | 0.0 |
| Movement | Fights charged into per game | 3.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 1 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +0 | 1 of 4, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +50 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +166 | 2 of 4, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (15 of 25) | - |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 3.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (6 of 10) | - |
| Shooting | Points destroyed by war machines | 25.0 | 0.0 |
| Magic | Magic missiles cast | - | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 50% (3 of 6) |
| Magic | Wounds caused by magic missiles | 1.0 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 1.3 / 0.0 / 0.0 | 1.7 / 0.3 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 237.3 | 20.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +75 | +58 |
| Combat | Net per 100 charger points, damage counted | +21.5 | +23.3 |
| Combat | First round won (charged fights) | 67% | 83% |
| Combat | Net points per charged fight | +106 | +18 |
| Combat | Net points per supported fight / lone fight | - / +106 | - / +18 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 3 of 6 |
| Game | Points lost | 93.0 | 393.5 |
| Game | VP from objectives | 675.0 | 380.0 |
| Game | Lone holders (player turns) | 6.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 0 of 2 ended games (of 3); mean margin (Mine - Opponent) +502 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 486
- Games not ended: 1 (L1723-1); findings 2, warnings 0

### Opponent rules: cnsr-c940641-p9

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +108.7 | 0.0 | 0.0 | 0.3 | +18.8 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +28.0 | 0.0 | 0.0 |
| ARMY TABLE | 16.3 | +375.9 | 0.0 | 0.0 | 17.7 | +390.0 | 0.0 | 62.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.3 | +26.4 | 50.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +7.0 | 0.0 | 0.0 | 1.3 | +7.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +188.2 | 0.0 | 0.0 |
| CHAFF PASSED | 1.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +30.7 | 0.0 | 0.0 | 0.7 | +1.6 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -7.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +23.8 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -771.7 | 0.0 | 126.0 | 15.3 | -862.1 | 0.0 | 225.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 111.0 | 0.0 | 2.0 | +0.0 | 84.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.3 | +0.0 | 0.0 | 84.0 | 17.3 | +0.0 | 0.0 | 62.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 25.0 |
| COVER ONCE | 18.3 | -874.1 | 0.0 | 0.0 | 11.3 | -1022.0 | 0.0 | 244.7 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -5.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +103.1 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.0 | +2.3 | 176.7 | 0.0 | 3.0 | +50.5 | 84.0 | 84.7 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 160.0 | 0.0 | 3.0 | +2.2 | 84.0 | 0.0 |
| FALLS SHORT | 1.7 | +19.1 | 0.0 | 0.0 | 22.0 | +256.8 | 0.0 | 244.7 |
| FEATURE BUFFS | 1.7 | +28.5 | 0.0 | 0.0 | 0.3 | +2.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +3.2 | 0.0 | 0.0 | 1.7 | +25.3 | 42.0 | 84.7 |
| FIVE ACTION | 76.7 | +5205.6 | 361.3 | 168.0 | 82.3 | +4186.8 | 84.0 | 707.3 |
| FLANK NOT WEIGHED | 10.3 | +0.0 | 0.0 | 42.0 | 8.3 | +0.0 | 0.0 | 199.3 |
| FOUR ROUNDS | 3.3 | +388.5 | 261.3 | 0.0 | 4.0 | +361.5 | 84.0 | 84.7 |
| FREED FROM HIS FIGHT | 9.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 98.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -20.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.0 | -12.2 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -5.4 | 0.0 | 0.0 | 0.7 | -8.9 | 0.0 | 84.7 |
| GOAL WALK | 12.3 | +908.0 | 0.0 | 0.0 | 4.3 | +384.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 5.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 49.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 16.3 | +0.0 | 0.0 | 126.0 | 13.3 | +0.0 | 0.0 | 225.3 |
| HIS CHARGE DENIED | 0.3 | +37.8 | 62.0 | 0.0 | 0.7 | +97.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 8.7 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 258.0 |
| HIS LEGAL MOVES | 9.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 124.0 |
| HIS MOVE AND SHOT | 4.0 | -22.2 | 0.0 | 0.0 | 6.0 | -63.4 | 0.0 | 25.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 12.7 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 124.0 |
| HIS RUN AFTER OUR TURN | 5.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 24.7 | +184.4 | 0.0 | 0.0 | 43.3 | +883.7 | 0.0 | 100.0 |
| HIS SHOTS BY HIS RUN | 26.7 | +106.6 | 0.0 | 0.0 | 46.3 | +564.8 | 0.0 | 257.3 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +15.8 | 0.0 | 0.0 |
| HIS TURN RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 84.0 | 13.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.7 | +570.5 | 0.0 | 42.0 | 9.0 | +626.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -146.1 | 261.3 | 0.0 | 4.0 | -133.9 | 84.0 | 84.7 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +5.1 | 0.0 | 0.0 |
| IDLE COST | 2.0 | -35.7 | 0.0 | 0.0 | 17.0 | -212.7 | 0.0 | 183.7 |
| JOINT CHARGE NOW | 0.7 | +48.1 | 98.0 | 0.0 | 0.7 | +41.1 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 12.7 | +0.0 | 219.3 | 60.0 | 12.3 | +0.0 | 40.0 | 236.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -2.9 | 49.0 | 0.0 | 3.3 | +10.0 | 84.0 | 84.7 |
| LOST CHARGE | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -49.5 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +7.5 | 0.0 | 42.0 | 1.3 | -24.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +40.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +350.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +29.6 | 0.0 | 0.0 | 2.3 | +165.7 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +52.8 | 0.0 | 0.0 | 5.0 | +36.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +40.7 | 0.0 | 0.0 | 5.0 | +23.1 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 25.0 |
| MOVE TO CHARGE COMPUTED | 11.7 | +873.2 | 0.0 | 0.0 | 12.7 | +1067.6 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.7 | +302.4 | 0.0 | 84.0 | 7.7 | +267.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 9.0 | +663.0 | 0.0 | 0.0 | 9.0 | +758.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -20.0 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.0 | -137.9 | 127.7 | 0.0 | 3.3 | -193.4 | 84.0 | 84.7 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.3 | -152.7 | 84.7 | 0.0 | 3.3 | -222.3 | 42.0 | 62.0 |
| ONE FIGHT FORMULA | 5.7 | -122.4 | 0.0 | 0.0 | 8.0 | -163.0 | 0.0 | 146.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +16.6 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | +14.3 | 0.0 | 42.0 | 3.3 | -38.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -42.0 | 0.0 | 0.0 | 1.7 | -42.0 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +38.5 | 146.7 | 0.0 | 1.7 | +120.1 | 42.0 | 0.0 |
| PATHS CROSS | 0.3 | +4.6 | 0.0 | 0.0 | 0.7 | +32.7 | 0.0 | 0.0 |
| PLAN RESULT | 34.0 | +420.0 | 75.0 | 84.0 | 41.0 | +208.7 | 62.0 | 474.7 |
| PROMISE BELOW ZERO | - | - | - | - | 1.0 | +0.0 | 0.0 | 84.7 |
| PROMISE BY ITS OWN SUM | 15.0 | -679.2 | 0.0 | 0.0 | 11.3 | -269.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | -0.6 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -13.8 | 0.0 | 0.0 | 0.7 | -3.7 | 0.0 | 0.0 |
| QUARTER ODDS | 17.0 | +2108.5 | 114.7 | 0.0 | 12.3 | +1476.9 | 0.0 | 114.7 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +83.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +13.5 | 0.0 | 0.0 | 6.0 | +924.6 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +33.7 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.7 | -120.8 | 0.0 | 0.0 | 2.7 | -32.7 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 84.7 |
| RESERVE FALL BACK | 1.0 | +43.2 | 0.0 | 0.0 | 1.0 | +21.8 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +69.8 | 244.7 | 0.0 | 3.7 | -96.7 | 84.0 | 84.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.7 | -43.2 | 84.0 | 0.0 |
| RUN DOWN | - | - | - | - | 3.0 | -51.4 | 84.0 | 84.7 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -50.8 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +18.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +59.2 | 84.7 | 0.0 | 0.7 | +44.1 | 42.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | +108.4 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -2.5 | 0.0 | 0.0 | 1.7 | -10.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | -34.7 | 0.0 | 0.0 | 4.0 | -25.7 | 0.0 | 62.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +23.6 | 0.0 | 0.0 | 1.0 | +212.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -6.4 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 14.0 | -116.3 | 0.0 | 0.0 | 31.3 | -294.2 | 0.0 | 112.0 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +324.2 | 0.0 | 42.0 | 7.0 | +26.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +30.4 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 146.7 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -10.2 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 25.7 | +0.0 | 100.0 | 42.0 | 17.0 | +0.0 | 0.0 | 212.7 |
| STAY WORTH | 10.0 | +41.7 | 50.0 | 0.0 | 6.3 | +15.2 | 0.0 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +17.8 | 84.7 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.7 | +144.2 | 0.0 | 0.0 | 6.0 | +652.4 | 0.0 | 62.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.7 | +144.2 | 0.0 | 0.0 | 6.0 | +652.4 | 0.0 | 62.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 25.0 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 25.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.7 | +0.0 | 0.0 | 84.0 | 41.3 | +0.0 | 0.0 | 311.3 |
| TIED UP BY THE SUM | 0.3 | +66.4 | 62.0 | 0.0 | 1.0 | +117.3 | 42.0 | 0.0 |
| TIME ON OUR SIDE | 30.7 | +441.1 | 0.0 | 168.0 | 5.0 | +30.5 | 0.0 | 0.0 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 62.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | +78.7 | 169.3 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -1.5 | 62.0 | 0.0 | 0.7 | -4.3 | 0.0 | 0.0 |
| WHO GETS IN | 0.7 | +48.1 | 98.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +6.6 | 0.0 | 0.0 | 1.3 | +255.2 | 0.0 | 84.7 |
| WHOLE FIGHT | 0.3 | -59.9 | 84.7 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.0 | -660.4 | 0.0 | 126.0 | 3.7 | -571.7 | 0.0 | 163.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +7.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.7 | +1.2 | 0.0 | 0.0 | 4.3 | +30.6 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p9

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 75 | 75 | 75 | 25.00 | +0 | +0.0 |
| ARMY TABLE | 102 | 102 | 69 | 23.00 | +1825 | +26.5 |
| HOLDER ASSIGNMENT | 50 | 50 | 46 | 15.33 | +2489 | +54.1 |
| FIVE ACTION | 477 | 454 | 43 | 14.33 | +2538 | +59.0 |
| HIS SHOT LIST | 204 | 191 | 37 | 12.33 | +387 | +10.5 |
| HIS SHOTS BY HIS RUN | 219 | 205 | 35 | 11.67 | +262 | +7.5 |
| MOVE TO CHARGE COMPUTED | 73 | 58 | 33 | 11.00 | +1449 | +43.9 |
| PROMISE BY ITS OWN SUM | 79 | 79 | 33 | 11.00 | -2847 | -86.3 |
| THE TABLE AGAIN | 32 | 32 | 27 | 9.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| NEXT CHARGE BY LIST | 54 | 44 | 21 | 7.00 | +1342 | +63.9 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| QUARTER ODDS | 88 | 87 | 18 | 6.00 | +1676 | +93.1 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 18 | 6.00 | +0 | +0.0 |
| OFF BEST | 17 | 17 | 17 | 5.67 | -1125 | -66.2 |
| GOAL WALK | 50 | 50 | 13 | 4.33 | +711 | +54.7 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| COVER ONCE | 89 | 61 | 10 | 3.33 | +52 | +5.2 |
| SHOT RISK POINTS | 136 | 127 | 9 | 3.00 | +61 | +6.8 |
| FOUR ROUNDS | 22 | 19 | 8 | 2.67 | +500 | +62.5 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| SUPPORT ADDS | 29 | 27 | 8 | 2.67 | +161 | +20.1 |
| SUPPORT WORKED OUT | 29 | 27 | 8 | 2.67 | +161 | +20.1 |
| THE RISK READS HIS RUN | 16 | 16 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 57 | 44 | 7 | 2.33 | +59 | +8.5 |
| ONE PROMISE A TARGET | 7 | 7 | 7 | 2.33 | -252 | -36.0 |
| RISK BY ARC | 20 | 17 | 7 | 2.33 | +287 | +41.0 |
| CHAFF IN THE MOVE | 9 | 9 | 6 | 2.00 | +0 | +0.0 |
| COMBAT PIVOT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +195 | +32.5 |
| WHO HITS BACK | 6 | 6 | 6 | 2.00 | +646 | +107.6 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF PASSED | 5 | 5 | 5 | 1.67 | -0 | -0.0 |
| TIME ON OUR SIDE | 107 | 82 | 5 | 1.67 | +34 | +6.9 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +97 | +24.2 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +267 | +66.8 |
| MAX FOR POSITIONING | 12 | 12 | 4 | 1.33 | +0 | +0.0 |
| REDIRECT COUNTER | 20 | 20 | 4 | 1.33 | +260 | +65.0 |
| SET UP BY THE SET | 16 | 16 | 4 | 1.33 | +257 | +64.2 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +100 | +25.0 |
| CHARGE NOW FIRST | 12 | 12 | 3 | 1.00 | -198 | -66.1 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 24 | 20 | 3 | 1.00 | +36 | +12.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +112 | +37.3 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +56 | +18.8 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +310 | +103.3 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +382 | +191.2 |
| CANNON PLANNED TARGET | 10 | 10 | 2 | 0.67 | +53 | +26.4 |
| CAST JOB | 6 | 6 | 2 | 0.67 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +221 | +110.5 |
| FALLS SHORT | 71 | 58 | 2 | 0.67 | +1 | +0.6 |
| HIS CHARGE DENIED | 3 | 3 | 2 | 0.67 | +108 | +54.1 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +18 | +8.9 |
| NO DOUBLE ROUNDS | 16 | 15 | 2 | 0.67 | +7 | +3.4 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +144 | +72.1 |
| WOUNDS ON THE RANKS | 15 | 15 | 2 | 0.67 | +1 | +0.7 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +84 | +84.1 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +71 | +71.3 |
| CHARGE LOSSES | 99 | 91 | 1 | 0.33 | +303 | +303.3 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -34 | -33.7 |
| EXACT ROUND | 15 | 13 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 15 | 13 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 30 | 25 | 1 | 0.33 | +1 | +1.4 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +22 | +22.5 |
| MISSILES NEXT TURN | 25 | 21 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NEARER NOT NEEDED | 49 | 47 | 1 | 0.33 | +36 | +36.1 |
| OVERRUNS AWAY | 8 | 6 | 1 | 0.33 | +30 | +30.3 |
| PROMISE KNOWS THE FIGHT | 13 | 5 | 1 | 0.33 | -2 | -1.9 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | -7 | -7.1 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| STAY WORTH | 49 | 40 | 1 | 0.33 | +15 | +15.1 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +53 | +53.3 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +8.0 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 26 | 26 | 1 | 0.33 | +0 | +0.2 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 86 | 83 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 6 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 56 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 50 | 41 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 35 | 28 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 89 | 84 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 54 | 51 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 45 | 38 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 12 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 71 | 61 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 31 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 16 | 16 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS TURN RUN | 32 | 32 | 0 | 0.00 | - | - |
| HOLD ODDS | 74 | 74 | 0 | 0.00 | - | - |
| HONEST WORTH | 21 | 18 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 19 | 19 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 11 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 32 | 32 | 0 | 0.00 | - | - |
| NO SECOND RUN | 16 | 16 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 41 | 14 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 22 | 18 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 225 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 19 | 17 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 28 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 12 | 12 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 68 | 52 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 46 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 128 | 122 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 8 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 231 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | not checked | - | - | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | not checked | - | - | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p9

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 7.33 | 3.67 | 86.3 |
| JOB FIRST | gate | 2.00 | 2.67 | 63.7 |
| ARMY TABLE | rule | 1.33 | 2.00 | 38.2 |
| ONE PROMISE A TARGET | rule | 0.67 | 1.67 | 36.0 |
| CHARGE NOW FIRST | rule | 1.00 | - | 66.1 |
| NO REASON | gate | - | 0.67 | 16.1 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 33.7 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 1.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 13.9 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.9 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 7.1 |
| RULE SWITCHED OFF | gate | 0.33 | - | 201.5 |

### Plans: cnsr-c940641-p9

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 67% | 464 | 316 | 68% |
| Mine | move | 26.3 | 95% | 1638 | 0 | 0% |
| Mine | shoot | 4.7 | 43% | 277 | 104 | 38% |
| Opponent | charge | 3.7 | 45% | 639 | 194 | 30% |
| Opponent | join | 2.7 | 100% | 110 | 0 | 0% |
| Opponent | move | 31.3 | 97% | 1556 | 0 | 0% |
| Opponent | shoot | 1.7 | 20% | 29 | 15 | 50% |
| Opponent | support | 1.7 | 100% | 34 | 0 | 0% |

### Battle groups: cnsr-c940641-p9

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 6.0 | 11% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p9

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Character | 5 | 21 (5) | 21 | 0 | 0 | 20% | 2.5 | 0 (2) | 33 (3) | - | 0 (3) | 49 (2) |
| Mine | Clean-up | 1 | 125 (1) | 125 | 0 | 100 | 0% | 2.0 | 125 (1) | - | - | 125 (1) | - |
| Mine | Fast Hammer | 3 | 48 (3) | 0 | 48 | 0 | 0% | 2.7 | - | 48 (3) | - | 181 (1) | 0 (2) |
| Mine | Hammer | 2 | 46 (2) | 46 | 0 | 0 | 50% | 3.0 | 46 (2) | - | - | 46 (2) | - |
| Mine | Shooter | 2 | 30 (2) | 0 | 30 | 42 | 0% | 2.0 | 71 (1) | 0 (1) | - | 71 (1) | 0 (1) |
| Mine | War machine | 2 | 38 (2) | 38 | 0 | 0 | 0% | 1.0 | 75 (1) | 0 (1) | - | 38 (2) | - |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 8 | 0 (8) | 0 | 0 | 30 | 88% | 2.0 | 0 (5) | 0 (3) | - | 0 (5) | 0 (3) |
| Opponent | Character | 7 | 4 (7) | 4 | 0 | 4 | 29% | 4.0 | 0 (2) | 8 (4) | 0 (1) | 0 (3) | 8 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 4 | 17 (4) | 11 | 5 | 17 | 50% | 2.5 | 16 (1) | 0 (1) | 34 (2) | 0 (1) | 25 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.0 | 0 (3) | 0 (1) | - | 0 (2) | 0 (2) |

### Charged fights: cnsr-c940641-p9

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 236 | 3.0 | 1.0 | 79 | 0 | +79 | 0 of 3 | 2 of 3 | - | +79 |
| Mine | Kingdom of Bretonnia | 1 | 75 | 401 | 3.0 | 1.0 | 134 | 0 | +134 | 2 of 3 | 2 of 3 | - | +134 |
| **Mine** | all armies | 2 | 38 | 318 | 3.0 | 1.0 | 106 | 0 | +106 | 2 of 6 | 4 of 6 | - | +106 |
| Opponent | Vampire Counts | 2 | 0 | 93 | 3.0 | 1.0 | 31 | 12 | +18 | 3 of 6 | 5 of 6 | - | +18 |

### Effective charges: cnsr-c940641-p9

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 0 | 0 | 1 (net +0) | 0 | 1 (net +50) | 1 (net +186) | 0 | 33% (1 of 3) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +147) | 2 | 0% (0 of 1) |
| Opponent | Vampire Counts | 6 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 2 (net +0) | 2 | 25% (1 of 4) |

### Charged fights, damage counted: cnsr-c940641-p9

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 60 | 75 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 387 | 166 | +166 | 166 | 0 | +166 | +43.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 497 | 50 | +50 | 50 | 0 | +50 | +10.1 |
| Mine | No odds | 2 | 384 | 367 | +127 | 127 | 93 | +34 | +8.9 |
| Mine | All fights | 6 | 350 | 199 | +106 | 106 | 31 | +75 | +21.5 |
| Opponent | Long shot (under 50%) | 1 | 50 | 80 | +0 | 16 | 0 | +16 | +32.0 |
| Opponent | Effective (55-75%) | 1 | 471 | 432 | +0 | 240 | 0 | +240 | +51.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 362 | 402 | +0 | 0 | 10 | -10 | -2.9 |
| Opponent | No odds | 2 | 118 | 93 | +56 | 93 | 38 | +56 | +47.0 |
| Opponent | All fights | 6 | 247 | 250 | +18 | 74 | 16 | +58 | +23.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p9 | move | 30 | 6 (20%) | 5 (17%) | 3 (10%) | 21 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

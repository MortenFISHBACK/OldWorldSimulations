# Doctrine scorecard: cnsr-c940641-p18

### Scorecard: cnsr-c940641-p18

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 1 | 5 | 1 | 1 | 0 | 0 | 0 | 250 |
| L0918 | 6 | 1 | Opponent | no | 3 | - | 2 | 3 | 1 | 0 | 0 | 185 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 539 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 5 | 6 | 0 | 0 | 0 | 500 |
| L1026 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1026 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 0.5 | 5.0 | 0.5 | 1.0 | 0.0 | 0.0 | 0.0 | 394.5 |
| **Average** | | | Opponent | 0% | 1.5 | 3.0 | 3.5 | 4.5 | 0.5 | 0.0 | 0.0 | 342.5 |

### KPIs: cnsr-c940641-p18

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 67% (6 of 9) | 0% (0 of 11) | 30% (6 of 20) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 100% (3 of 3); on the table 100% | 100% (7 of 7); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 35% (14 of 40) | 11% (1 of 9) | 31% (15 of 49) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (14 of 37) | 11% (1 of 9) | 33% (15 of 46) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 63% (2523 of 3998) | 81% (3239 of 3998) | 72% (5762 of 7996) |
|   infantry points that never fought | lower | 57% (814 of 1420) | 83% (553 of 670) | 65% (1367 of 2090) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 71% (17 of 24) | 73% (11 of 15) | 72% (28 of 39) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.0 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (3 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 73% (2673 of 3668) | 74% (2516 of 3391) | 74% (5189 of 7059) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (58%) | 0.0 (0%) | 5.0 (44%) |
| MARCHED: its unit marched | 2.3 (27%) | 0.7 (25%) | 3.0 (26%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (25%) | 0.7 (6%) |
| GONE: slain | 0.7 (8%) | 0.0 (0%) | 0.7 (6%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (50%) | 1.3 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.0 | 0.7 | 5.0 | 0.3 | 0.3 |
| not cast | 2.0 | 4.0 | 11.3 | 2.3 | 10.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (50%) | 5.0 (44%) | 1.0 (43%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.0 (26%) | 1.0 (43%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (50%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.3 (97%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (67 of 110) | 73% (54 of 74) | 66% (121 of 184) |
|   cavalry | - | 58% (7 of 12) | 58% (7 of 12) |
|   character | 100% (9 of 9) | 72% (13 of 18) | 81% (22 of 27) |
|   chariot | 64% (7 of 11) | 100% (5 of 5) | 75% (12 of 16) |
|   infantry | 48% (21 of 44) | 63% (17 of 27) | 54% (38 of 71) |
|   monster | 77% (10 of 13) | 100% (12 of 12) | 88% (22 of 25) |
|   war machine | 61% (20 of 33) | - | 61% (20 of 33) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (23%) | 4.0 (60%) | 7.3 (35%) |
| CHARGED: it charged | 0.0 (0%) | 1.3 (20%) | 1.3 (6%) |
| FLEEING: it fled or was fleeing | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (7%) | 0.7 (10%) | 1.7 (8%) |
| MOVED: a war machine that moved | 0.7 (5%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET IN RANGE | 2.7 (19%) | 0.3 (5%) | 3.0 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (5%) | 0.0 (0%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (14%) | 0.3 (5%) | 2.3 (11%) |
| SHELTERED: the target was sheltered | 3.3 (23%) | 0.0 (0%) | 3.3 (16%) |
| OTHER BAR | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 0.3 | 91% | 0.7 pts | 3 pts |
| character | 7.3 | 1.3 | 82% | 1.2 pts | 9 pts |
| chariot | 4.0 | 4.0 | 58% | 16.0 pts | 64 pts |
| infantry | 13.0 | 9.0 | 59% | 8.3 pts | 108 pts |
| monster | 10.7 | 2.0 | 88% | 3.3 pts | 35 pts |
| war machine | 6.7 | 6.0 | 65% | 17.7 pts | 118 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 2.3 | 1.7 |
| Charges that made contact a game | 0.7 | 1.7 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.50 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (22 units) | 0.23 declared, 0.16 contact (31 units) | 0.15 declared, 0.11 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Character in a unit | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 50% (1 of 2) | 75% (3 of 4) |
| Chariot | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| Infantry | 40% (4 of 10) | 100% (2 of 2) | - | 50% (6 of 12) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 50% (1 of 2) | 100% (4 of 4) | - | 83% (5 of 6) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (4 of 4); on the table 100% | 42% (10 of 24) | 63% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 92% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 70% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p18, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 100% (1) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p18

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | 67% (4 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (19 of 53) | 74% (14 of 19) |
| Strategy | Joined characters whose unit fought | 33% (2 of 6) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 50% (2 of 4) | 33% (1 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 4.5 |
| Movement | Points that never moved of their own | 394.5 | 342.5 |
| Movement | Fights charged into per game | 0.5 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 4, net +300 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 4, net +104 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 4, net +125 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.0 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 19% (9 of 48) | 41% (22 of 54) |
| Shooting | Points destroyed by shooting units | 9.0 | 0.0 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (12 of 20) | - |
| Shooting | Points destroyed by war machines | 41.3 | 0.0 |
| Magic | Magic missiles cast | 2.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 6) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 4.7 | - |
| Magic | Wounds caused by other spells | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 27.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.3 / 0.3 / 0.3 | 1.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 11.3 | 134.7 |
| Combat | Points run down | 0.0 | 76.3 |
| Combat | Net points per charged fight, damage counted | -19 | +146 |
| Combat | Net per 100 charger points, damage counted | -7.1 | +92.2 |
| Combat | First round won (charged fights) | 100% | 60% |
| Combat | Net points per charged fight | +0 | +120 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +120 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 2 of 5 |
| Game | Points lost | 381.0 | 319.0 |
| Game | VP from objectives | 530.0 | 765.0 |
| Game | Lone holders (player turns) | 0.5 | 1.5 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -354 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 700
- Games not ended: 1 (L1026-1); findings 1, warnings 0

### Opponent rules: cnsr-c940641-p18

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.0 | +252.7 | 0.0 | 104.0 | 26.3 | +329.2 | 0.0 | 104.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +1.4 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.7 | -64.1 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 8.3 | +86.7 | 64.0 | 41.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.3 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +29.1 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +19.3 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.3 | -567.7 | 0.0 | 222.0 | 16.0 | -553.0 | 0.0 | 60.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 13.7 | +0.0 | 0.0 | 20.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.0 | -220.2 | 0.0 | 0.0 | 2.0 | -156.8 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.3 | 0.0 | 0.0 | 1.3 | -16.9 | 104.0 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +0.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +1.4 | 0.0 | 0.0 | 1.0 | +1.1 | 111.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.5 | 0.0 | 0.0 | 2.0 | +0.4 | 145.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 29.3 | +339.7 | 0.0 | 295.3 |
| FEATURE BUFFS | 0.3 | +6.8 | 0.0 | 0.0 | 0.7 | +10.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -0.4 | 0.0 | 0.0 | 0.3 | +0.2 | 34.7 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 93.0 | +4106.9 | 542.0 | 374.7 | 93.3 | +4599.5 | 298.3 | 738.7 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +72.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +37.1 | 0.0 | 0.0 | 2.0 | +82.2 | 145.7 | 0.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 83.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.2 | 0.0 | 0.0 | 0.7 | -3.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +12.5 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.3 | +511.9 | 0.0 | 0.0 | 23.0 | +2154.8 | 0.0 | 97.3 |
| GUN FIGURES | 1.7 | +0.7 | 61.7 | 0.0 | 0.3 | +7.7 | 0.0 | 0.0 |
| GUN MASK | 5.3 | +227.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 246.7 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 83.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 104.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 22.7 |
| HIS MOVE AND SHOT | 3.0 | -8.4 | 0.0 | 0.0 | 6.7 | -53.2 | 0.0 | 52.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 83.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 22.7 |
| HIS RUN AFTER OUR TURN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 41.7 | +1131.7 | 0.0 | 291.3 | 71.0 | +5104.7 | 0.0 | 199.0 |
| HIS SHOTS BY HIS RUN | 36.0 | +493.0 | 0.0 | 208.0 | 56.0 | +1454.7 | 0.0 | 152.7 |
| HIS TURN DENIED | 0.3 | +3.2 | 0.0 | 0.0 | 1.3 | +62.6 | 104.0 | 0.0 |
| HIS TURN RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 69.3 | 17.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 11.0 | +1086.3 | 0.0 | 34.7 | 12.3 | +1156.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -35.7 | 0.0 | 0.0 | 2.0 | -67.6 | 145.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +7.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 20.7 | -273.4 | 0.0 | 41.3 |
| KEPT FROM ITS LAST STOP | 5.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 0.0 | 34.7 | 5.0 | +0.0 | 138.7 | 34.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | -2.0 | 69.3 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +2.7 | 0.0 | 0.0 | 1.0 | +5.6 | 69.3 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 3.0 | -7.2 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +21.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.0 | +105.4 | 0.0 | 0.0 | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.0 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +115.6 | 0.0 | 0.0 | 0.3 | +39.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +5.5 | 0.0 | 0.0 | 1.3 | +17.4 | 0.0 | 22.7 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.7 | +123.1 | 0.0 | 0.0 | 1.7 | +29.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 11.0 | +105.7 | 0.0 | 0.0 | 2.7 | +25.0 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 41.3 | 11.3 |
| MOVE TO CHARGE COMPUTED | 3.0 | +224.1 | 0.0 | 0.0 | 2.3 | +160.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +276.8 | 0.0 | 0.0 | 4.0 | +185.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +134.8 | 0.0 | 0.0 | 2.3 | +160.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -20.6 | 0.0 | 0.0 | 1.7 | -51.0 | 111.0 | 0.0 |
| NO LATE CUT | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -145.6 | 0.0 | 0.0 | 4.0 | -48.8 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 3.3 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -62.5 | 0.0 | 0.0 | 3.7 | -61.8 | 0.0 | 11.3 |
| ONE JOINT FIGURE | 0.3 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.0 | +19.8 | 0.0 | 0.0 | 4.7 | -8.3 | 0.0 | 0.0 |
| ONE ROUTE | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +17.2 | 34.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +44.2 | 41.7 | 0.0 |
| OWN CAST FIRST | - | - | - | - | 0.7 | -0.5 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 39.3 | +841.0 | 87.7 | 340.0 | 41.0 | +172.9 | 111.0 | 354.0 |
| PROMISE BY ITS OWN SUM | 6.0 | -91.1 | 0.0 | 0.0 | 2.7 | -94.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | -4.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 6.7 | +673.5 | 36.0 | 83.3 | 13.7 | +946.9 | 83.3 | 54.0 |
| REAL GROUND | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +18.8 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 4.0 | +157.9 | 0.0 | 9.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.0 | +26.2 | 0.0 | 31.7 |
| REFORMS TO MEET IT | 0.7 | -32.0 | 0.0 | 0.0 | 0.7 | -7.6 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +17.8 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | +31.6 | 0.0 | 0.0 | 1.7 | -174.4 | 111.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | +1.2 | 0.0 | 0.0 | 0.7 | -19.7 | 34.7 | 0.0 |
| RUN DOWN | 0.3 | -6.7 | 0.0 | 0.0 | 1.3 | -11.5 | 104.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -266.7 | 0.0 | 18.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 34.7 | - | - | - | - |
| SECOND LOOK | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -5.8 | 0.0 | 0.0 | 0.7 | -26.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +12.2 | 0.0 | 0.0 | 2.0 | +74.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 41.7 | 8.3 | +0.0 | 0.0 | 274.3 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +155.1 | 55.3 | 0.0 | 1.3 | +5.1 | 152.7 | 0.0 |
| SHOT OR CHARGE | 0.7 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 22.3 | -272.5 | 0.0 | 152.7 | 40.0 | -221.3 | 0.0 | 170.7 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 27.0 | +780.8 | 0.0 | 152.7 | 17.3 | +247.7 | 0.0 | 265.3 |
| SPELL WORTH | - | - | - | - | 2.0 | +24.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 69.0 |
| STAND AND SHOOT | 0.3 | -2.9 | 0.0 | 0.0 | 0.7 | -3.8 | 34.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 10.3 | +0.0 | 69.3 | 37.3 |
| STANDS STILL | 51.0 | +0.0 | 542.0 | 166.7 | 28.3 | +0.0 | 152.7 | 566.7 |
| STAY WORTH | 45.3 | +130.9 | 468.7 | 201.3 | 25.0 | +226.9 | 0.0 | 814.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +7.2 | 20.0 | 11.3 |
| SUPPORT ADDS | 1.0 | +109.4 | 0.0 | 0.0 | 0.7 | +6.6 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.0 | +109.4 | 0.0 | 0.0 | 0.7 | +6.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 34.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 57.7 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.0 | +0.0 | 0.0 | 111.0 | 46.7 | +0.0 | 0.0 | 372.7 |
| TIED UP BY THE SUM | 0.3 | +47.5 | 0.0 | 0.0 | 0.7 | +109.5 | 34.7 | 0.0 |
| TIME ON OUR SIDE | 47.7 | +595.7 | 160.7 | 104.0 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 2.7 | +0.0 | 0.0 | 493.3 |
| WHO FIGHTS | 0.3 | -4.8 | 0.0 | 0.0 | 0.3 | -4.8 | 34.7 | 0.0 |
| WHO HITS BACK | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +15.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -230.9 | 0.0 | 152.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 4.7 | +33.7 | 0.0 | 0.0 | 0.7 | +10.5 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p18

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 338 | 333 | 122 | 40.67 | +2267 | +18.6 |
| ARMY TABLE | 112 | 112 | 90 | 30.00 | +1702 | +18.9 |
| HIS SHOTS BY HIS RUN | 276 | 271 | 77 | 25.67 | +1117 | +14.5 |
| HOLDER ASSIGNMENT | 70 | 70 | 64 | 21.33 | +3612 | +56.4 |
| GOAL WALK | 97 | 95 | 37 | 12.33 | +1486 | +40.2 |
| SHOT RISK POINTS | 187 | 182 | 37 | 12.33 | +952 | +25.7 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -583 | -20.8 |
| HARD STAY DROPPED | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| THE TABLE AGAIN | 31 | 31 | 19 | 6.33 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| TIME ON OUR SIDE | 143 | 112 | 18 | 6.00 | +93 | +5.2 |
| ARTILLERY RE-ROLL WEIGHED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| STAY WORTH | 211 | 187 | 17 | 5.67 | +138 | +8.1 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +58 | +3.9 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FIVE ACTION | 559 | 549 | 11 | 3.67 | +1096 | +99.6 |
| MOVE TO CHARGE COMPUTED | 16 | 13 | 10 | 3.33 | +291 | +29.1 |
| OGRE LOADER SECOND SHOT | 10 | 10 | 10 | 3.33 | +14 | +1.4 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 10 | 3.33 | +66 | +6.6 |
| IDLE COST | 62 | 40 | 9 | 3.00 | +61 | +6.8 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 9 | 3.00 | -557 | -61.8 |
| GUN MASK | 16 | 16 | 7 | 2.33 | +285 | +40.8 |
| CAST JOB | 10 | 10 | 6 | 2.00 | +34 | +5.7 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| NEXT CHARGE BY LIST | 9 | 9 | 6 | 2.00 | +231 | +38.5 |
| HIS MOVE AND SHOT | 29 | 26 | 5 | 1.67 | +19 | +3.8 |
| MARCH CHECK | 7 | 7 | 5 | 1.67 | +59 | +11.8 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +37 | +9.2 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| MAX FOR POSITIONING | 8 | 7 | 4 | 1.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 29 | 28 | 4 | 1.33 | +127 | +31.7 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 4 | 1.33 | -14 | -3.5 |
| QUARTER ODDS | 61 | 60 | 4 | 1.33 | +182 | +45.5 |
| THE RISK READS HIS RUN | 16 | 16 | 4 | 1.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 16 | 16 | 4 | 1.33 | +9 | +2.2 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +58 | +19.2 |
| CHARGE LOSSES | 100 | 96 | 3 | 1.00 | +268 | +89.3 |
| FOUR ROUNDS | 9 | 9 | 3 | 1.00 | +24 | +7.9 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -22 | -7.2 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +53 | +17.7 |
| SHOTS IN THE MOVE | 133 | 102 | 3 | 1.00 | +81 | +27.1 |
| SUPPORT ADDS | 5 | 5 | 3 | 1.00 | +226 | +75.4 |
| SUPPORT WORKED OUT | 5 | 5 | 3 | 1.00 | +226 | +75.4 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +115 | +38.3 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -192 | -96.2 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 27 | 22 | 2 | 0.67 | +69 | +34.5 |
| EVASIVE BY THE ODDS | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 6 | 6 | 2 | 0.67 | +8 | +4.1 |
| FALLS SHORT | 88 | 71 | 2 | 0.67 | +20 | +9.8 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +217 | +108.7 |
| HIS TURN DENIED | 5 | 5 | 2 | 0.67 | +64 | +31.9 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +64 | +32.2 |
| MISSILES IN THE MOVE | 28 | 20 | 2 | 0.67 | +40 | +20.2 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -1 | -0.7 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -32 | -15.8 |
| RISK BY ARC | 8 | 8 | 2 | 0.67 | +13 | +6.7 |
| SET UP BY THE SET | 11 | 11 | 2 | 0.67 | +43 | +21.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +22 | +10.8 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +54 | +26.8 |
| CHARGE NOW FIRST | 2 | 2 | 1 | 0.33 | -38 | -37.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 3 | 3 | 1 | 0.33 | +0 | +0.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +38 | +37.5 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 5 | 5 | 1 | 0.33 | +2 | +1.8 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +1 | +0.6 |
| MISSILES NEXT TURN | 41 | 26 | 1 | 0.33 | +1 | +1.1 |
| NO DOUBLE ROUNDS | 8 | 8 | 1 | 0.33 | +25 | +24.8 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +2 | +1.8 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +3 | +2.9 |
| ROUNDS AFTER TERROR | 3 | 3 | 1 | 0.33 | +2 | +1.8 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 25 | 25 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 13 | 13 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 67 | 67 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 24 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 38 | 36 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 16 | 13 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 26 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 30 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 31 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 16 | 16 | 0 | 0.00 | - | - |
| HIS TURN RUN | 31 | 31 | 0 | 0.00 | - | - |
| HOLD ODDS | 97 | 97 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 27 | 27 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 18 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 18 | 18 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 31 | 31 | 0 | 0.00 | - | - |
| NO SECOND RUN | 15 | 15 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 22 | 15 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 23 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 18 | 18 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 241 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 18 | 18 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 12 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 75 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 31 | 27 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 31 | 29 | 0 | 0.00 | - | - |
| STANDS STILL | 238 | 233 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 260 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 8 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p18

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.67 | 20.5 |
| ARMY TABLE | rule | 0.33 | 2.67 | 18.0 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 0.67 | 61.8 |
| HOLDER ASSIGNMENT | rule | 1.33 | 0.67 | 30.4 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 3.5 |
| BEST PRIZE | rule | - | 0.67 | 96.2 |
| MARCH OF THE TABLE | rule | 0.67 | - | 10.8 |
| OWN CAST FIRST | rule | - | 0.67 | 0.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 37.3 |
| CHARGE NOW FIRST | rule | 0.33 | - | 37.9 |
| NO REASON | gate | - | 0.33 | 12.9 |
| REFUSING RETIRES | rule | - | 0.33 | 31.1 |

### Plans: cnsr-c940641-p18

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 43 | 30 | 70% |
| Mine | move | 23.7 | 97% | 1048 | 0 | 0% |
| Mine | shoot | 14.7 | 70% | 679 | 811 | 119% |
| Opponent | charge | 1.3 | 75% | 71 | 101 | 142% |
| Opponent | move | 33.0 | 95% | 1617 | 0 | 0% |
| Opponent | shoot | 5.3 | 38% | 282 | 72 | 25% |
| Opponent | support | 1.3 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p18

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.0 | 17% | 50% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p18

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 11 (8) | 11 | 0 | 41 | 38% | 3.2 | 0 (2) | 0 (3) | 47 (2) | 19 (4) | 0 (3) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Hammer | 7 | 8 (7) | 8 | 0 | 0 | 14% | 2.0 | 0 (1) | 5 (3) | 13 (3) | 11 (5) | 0 (2) |
| Mine | Shooter | 6 | 110 (6) | 4 | 106 | 50 | 0% | 2.0 | 26 (1) | 231 (2) | 58 (3) | 132 (5) | 0 (1) |
| Mine | War machine | 6 | 5 (6) | 5 | 0 | 33 | 0% | 1.2 | 0 (1) | 7 (4) | 0 (1) | - | 5 (6) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 7 | 242 (7) | 37 | 204 | 44 | 43% | 2.8 | 334 (2) | 156 (1) | 244 (4) | 242 (7) | - |
| Opponent | Character | 4 | 15 (4) | 15 | 0 | 0 | 0% | 1.8 | - | 31 (2) | 0 (2) | 23 (2) | 0 (2) |
| Opponent | Clean-up | 3 | 36 (3) | 0 | 36 | 0 | 33% | 1.0 | - | 56 (2) | 0 (1) | 36 (3) | - |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 9 | 26 (9) | 26 | 0 | 24 | 44% | 1.4 | 0 (4) | 68 (3) | 0 (2) | 371 (1) | 0 (8) |
| Opponent | Shooter | 1 | 150 (1) | 0 | 150 | 0 | 0% | 1.0 | - | 150 (1) | - | 150 (1) | - |

### Charged fights: cnsr-c940641-p18

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 117 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Ogre Kingdoms | 1 | 0 | 104 | 2.0 | 1.0 | 52 | 17 | +35 | 0 of 2 | 1 of 2 | - | +35 |
| Opponent | Wood Elf Realms | 1 | 0 | 529 | 3.0 | 1.0 | 176 | 0 | +176 | 2 of 3 | 2 of 3 | - | +176 |
| **Opponent** | all armies | 2 | 0 | 316 | 2.5 | 1.0 | 127 | 7 | +120 | 2 of 5 | 3 of 5 | - | +120 |

### Effective charges: cnsr-c940641-p18

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +104) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Wood Elf Realms | 3 | 1 (net +300) | 0 | 0 | 1 (net +104) | 0 | 1 (net +125) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: cnsr-c940641-p18

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 1 | 265 | 77 | +0 | 34 | 53 | -19 | -7.1 |
| Mine | All fights | 1 | 265 | 77 | +0 | 34 | 53 | -19 | -7.1 |
| Opponent | Long shot (under 50%) | 1 | 109 | 209 | +300 | 314 | 54 | +259 | +238.0 |
| Opponent | Effective (55-75%) | 1 | 40 | 104 | +104 | 104 | 2 | +102 | +255.0 |
| Opponent | 76-89% | 1 | 109 | 104 | +104 | 168 | 55 | +113 | +103.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 227 | +125 | 289 | 0 | +289 | +57.9 |
| Opponent | No odds | 1 | 34 | 189 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 5 | 158 | 167 | +120 | 175 | 29 | +146 | +92.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p18 | move | 17 | 2 (12%) | 2 (12%) | 1 (6%) | 14 (82%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

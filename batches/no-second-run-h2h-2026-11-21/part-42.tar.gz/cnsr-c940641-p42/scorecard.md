# Doctrine scorecard: cnsr-c940641-p42

### Scorecard: cnsr-c940641-p42

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Opponent | no | 8 | - | 1 | 3 | 1 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 399 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 6 | 0 | 0 | 0 | 500 |
| L1026 | 6 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Opponent | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.7 | 4.0 | 1.3 | 1.0 | 0.0 | 0.0 | 0.0 | 133.0 |
| **Average** | | | Opponent | 0% | 2.7 | 4.0 | 2.3 | 3.3 | 0.3 | 0.0 | 0.0 | 166.7 |

### KPIs: cnsr-c940641-p42

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 46% (6 of 13) | 0% (0 of 11) | 25% (6 of 24) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | 100% (2 of 2); on the table 100% | 86% (6 of 7); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 83% | 100% (2 of 2); on the table 100% | 88% (7 of 8); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 40% (19 of 48) | 25% (3 of 12) | 37% (22 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (19 of 42) | 25% (3 of 12) | 41% (22 of 54) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 57% (3405 of 5997) | 70% (4212 of 5998) | 64% (7617 of 11995) |
|   infantry points that never fought | lower | 51% (814 of 1591) | 86% (987 of 1147) | 66% (1801 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (21 of 34) | 75% (15 of 20) | 67% (36 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 1.7 uses a game | 100% (1 of 1); 1.3 uses a game | 67% (2 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (3306 of 5667) | 69% (3563 of 5186) | 63% (6869 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.3 (55%) | 0.0 (0%) | 5.3 (42%) |
| MARCHED: its unit marched | 2.3 (24%) | 1.0 (33%) | 3.3 (26%) |
| IN COMBAT: engaged in combat | 2.0 (21%) | 0.0 (0%) | 2.0 (16%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (22%) | 0.7 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (44%) | 1.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 0.7 | 7.3 | 1.0 | 1.0 |
| not cast | 2.0 | 5.3 | 12.7 | 3.0 | 15.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (62%) | 5.3 (42%) | 1.0 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.3 (26%) | 1.3 (44%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 2.0 (16%) | 0.7 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (38%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (98%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (82 of 131) | 68% (54 of 79) | 65% (136 of 210) |
|   cavalry | - | 55% (6 of 11) | 55% (6 of 11) |
|   character | 100% (7 of 7) | 56% (10 of 18) | 68% (17 of 25) |
|   chariot | 83% (15 of 18) | 92% (11 of 12) | 87% (26 of 30) |
|   infantry | 47% (22 of 47) | 62% (16 of 26) | 52% (38 of 73) |
|   monster | 50% (6 of 12) | 92% (11 of 12) | 71% (17 of 24) |
|   war machine | 68% (32 of 47) | - | 68% (32 of 47) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (18%) | 4.3 (52%) | 7.3 (30%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (12%) | 1.0 (4%) |
| IN COMBAT: it fought this turn or the last | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| MOVED: a war machine that moved | 2.3 (14%) | 0.0 (0%) | 2.3 (9%) |
| NO TARGET IN RANGE | 3.3 (20%) | 1.0 (12%) | 4.3 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (6%) | 0.3 (4%) | 1.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.7 (22%) | 1.3 (16%) | 5.0 (20%) |
| SHELTERED: the target was sheltered | 1.7 (10%) | 0.0 (0%) | 1.7 (7%) |
| OTHER BAR | 0.7 (4%) | 0.3 (4%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 0.7 | 78% | 1.8 pts | 5 pts |
| character | 5.7 | 2.0 | 65% | 3.6 pts | 20 pts |
| chariot | 8.7 | 7.3 | 62% | 23.1 pts | 200 pts |
| infantry | 13.0 | 6.3 | 69% | 6.9 pts | 90 pts |
| monster | 7.7 | 1.3 | 87% | 2.7 pts | 21 pts |
| war machine | 11.0 | 10.0 | 61% | 20.5 pts | 225 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 3.0 | 2.3 |
| Charges that made contact a game | 1.7 | 2.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 1.33 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 1.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 1.00 contact (1 units) | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (20 units) | 0.23 declared, 0.16 contact (31 units) | 0.16 declared, 0.12 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| Character on its own | - | 33% (1 of 3) | 40% (2 of 5) | 38% (3 of 8) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 36% (4 of 11) | 100% (2 of 2) | 0% (0 of 1) | 43% (6 of 14) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 100% (5 of 5) | - | 100% (7 of 7) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (1 of 1); on the table 100% | 50% (12 of 24) | 62% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 80% (4 of 5); on the table 80% | 29% (7 of 24) | 46% | 50% (5 of 10) | 50% (1 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 96% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 50% (3 of 6) | 45% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 70% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p42, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 50% (2) | 56% (5) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.67 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.33 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p42

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | 62% (5 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (20 of 57) | 46% (13 of 28) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 44% (4 of 9) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 3.3 |
| Movement | Points that never moved of their own | 133.0 | 166.7 |
| Movement | Fights charged into per game | 1.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +0 | 1 of 5, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 1 of 5, net +386 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 4, net +22 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 4 | 0 of 5 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.7 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 14% (7 of 50) | 43% (23 of 54) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 10.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (17 of 32) | - |
| Shooting | Points destroyed by war machines | 77.0 | 0.0 |
| Magic | Magic missiles cast | 3.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 9% (1 of 11) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 7.3 | 2.0 |
| Magic | Wounds caused by other spells | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 61.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.7 / 0.0 | 2.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 82.7 | 0.0 |
| Combat | Points run down | 0.0 | 128.7 |
| Combat | Net points per charged fight, damage counted | +30 | +56 |
| Combat | Net per 100 charger points, damage counted | +10.8 | +29.9 |
| Combat | First round won (charged fights) | 80% | 50% |
| Combat | Net points per charged fight | +21 | +58 |
| Combat | Net points per supported fight / lone fight | - / +21 | - / +58 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 2 of 6 |
| Game | Points lost | 223.0 | 282.3 |
| Game | VP from objectives | 536.7 | 696.7 |
| Game | Lone holders (player turns) | 0.7 | 2.7 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) -33 VP
- Points traded per game (both sides' losses): 505
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p42

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 11.3 | +350.9 | 0.0 | 34.7 | 29.3 | +212.1 | 0.0 | 335.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.0 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -24.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 30.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.3 | +205.3 | 179.7 | 193.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.3 | +46.4 | 71.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +24.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -7.8 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.0 | -547.9 | 0.0 | 34.7 | 21.3 | -750.5 | 0.0 | 168.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 73.7 | 15.0 | +0.0 | 0.0 | 88.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.3 | -297.2 | 0.0 | 0.0 | 3.0 | -214.4 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -15.7 | 69.3 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +0.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | -4.0 | 55.0 | 0.0 | 2.0 | +1.6 | 89.7 | 36.3 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 20.0 | 0.0 | 1.7 | +6.8 | 143.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 33.3 | +364.9 | 0.0 | 227.7 |
| FEATURE BUFFS | 0.7 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | -0.3 | 0.0 | 0.0 | 0.3 | +0.2 | 34.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 106.7 | +4827.7 | 740.0 | 750.7 | 108.3 | +5662.6 | 198.0 | 822.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 73.7 | 4.7 | +0.0 | 0.0 | 56.3 |
| FOLLOW UP WEIGHED | 1.0 | +35.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +99.9 | 55.0 | 0.0 | 2.7 | +153.7 | 198.0 | 36.3 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -0.9 | 0.0 | 0.0 | 0.7 | -3.8 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.3 | 20.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.0 | +446.5 | 0.0 | 0.0 | 25.3 | +2286.0 | 0.0 | 97.3 |
| GUN FIGURES | 3.0 | +10.2 | 123.3 | 0.0 | 1.0 | +7.7 | 0.0 | 123.3 |
| GUN MASK | 5.0 | +243.9 | 0.0 | 147.3 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 61.7 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 72.7 |
| HIS CHARGE DENIED | 0.3 | +17.3 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 95.3 |
| HIS MOVE AND SHOT | 3.7 | -25.5 | 0.0 | 0.0 | 10.0 | -129.3 | 0.0 | 98.7 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 95.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 41.7 | +1312.3 | 0.0 | 69.3 | 78.7 | +5891.3 | 0.0 | 487.0 |
| HIS SHOTS BY HIS RUN | 35.7 | +935.2 | 0.0 | 69.3 | 64.3 | +1619.1 | 0.0 | 438.0 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +152.1 | 69.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.7 | +0.0 | 0.0 | 294.7 | 18.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 13.0 | +1346.4 | 0.0 | 147.3 | 14.0 | +1422.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -35.5 | 55.0 | 0.0 | 2.7 | -157.8 | 198.0 | 36.3 |
| IDLE COST | - | - | - | - | 24.3 | -391.4 | 0.0 | 131.3 |
| JOINT CHARGE NOW | 0.7 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | 0.3 | +13.6 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 20.0 | 34.7 | 3.7 | +0.0 | 104.0 | 89.7 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | -2.2 | 34.7 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +0.3 | 20.0 | 0.0 | 2.0 | +2.4 | 163.3 | 36.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +5.4 | 0.0 | 35.7 |
| MANOEUVRE | 2.3 | -14.9 | 0.0 | 0.0 | 1.0 | -3.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +10.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +21.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +74.7 | 0.0 | 0.0 | 1.0 | +52.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | +310.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +8.8 | 0.0 | 0.0 | 1.7 | +10.0 | 0.0 | 58.3 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.0 | +148.4 | 0.0 | 0.0 | 2.3 | +26.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 12.3 | +119.8 | 0.0 | 0.0 | 3.0 | +24.4 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 71.3 | 62.0 |
| MOVE TO CHARGE COMPUTED | 3.0 | +112.0 | 0.0 | 0.0 | 3.7 | +328.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +273.1 | 0.0 | 73.7 | 6.0 | +272.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +11.3 | 0.0 | 0.0 | 3.7 | +328.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -47.1 | 55.0 | 0.0 | 2.0 | -50.3 | 198.0 | 36.3 |
| NO LATE CUT | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.0 | -102.6 | 20.0 | 55.0 | 3.0 | -47.2 | 0.0 | 35.7 |
| OGRE LOADER SECOND SHOT | 3.3 | +18.7 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -43.5 | 0.0 | 0.0 | 4.7 | -88.2 | 0.0 | 83.3 |
| ONE OBJECTIVE FORMULA | 4.0 | +86.0 | 0.0 | 73.7 | 5.3 | +46.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -13.4 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +17.2 | 34.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +9.2 | 73.7 | 0.0 |
| OWN CAST FIRST | - | - | - | - | 0.7 | -0.4 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +21.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -1.0 | 0.0 | 0.0 | 0.3 | -11.6 | 0.0 | 0.0 |
| PLAN RESULT | 45.7 | +869.7 | 252.3 | 444.7 | 48.7 | +269.3 | 34.7 | 437.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -136.6 | 0.0 | 0.0 | 3.3 | -94.5 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 10.0 | +724.6 | 251.0 | 83.3 | 13.3 | +888.4 | 0.0 | 72.3 |
| REAL GROUND | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +235.2 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 4.3 | +0.0 | 0.0 | 54.0 |
| REFORMS TO MEET IT | 1.0 | -5.4 | 0.0 | 0.0 | 1.3 | -139.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +52.2 | 55.0 | 0.0 | 1.7 | -156.2 | 143.0 | 36.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -55.3 | 163.3 | 0.0 |
| RUN DOWN | 0.3 | -0.3 | 0.0 | 0.0 | 2.0 | -10.0 | 198.0 | 36.3 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -266.7 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +3.3 | 0.0 | 34.7 | - | - | - | - |
| SECOND LOOK | 0.3 | +7.8 | 20.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | - | - | - | - | 0.3 | +5.4 | 0.0 | 35.7 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 17.0 | +0.0 | 0.0 | 193.3 | 10.3 | +0.0 | 0.0 | 18.7 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +218.9 | 108.7 | 0.0 | 5.0 | +133.3 | 0.0 | 123.3 |
| SHOT OR CHARGE | 0.3 | -37.9 | 0.0 | 0.0 | 0.7 | -33.6 | 0.0 | 36.3 |
| SHOT RISK POINTS | 23.3 | -377.4 | 0.0 | 34.7 | 49.3 | +46.0 | 0.0 | 338.3 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 30.0 | +1148.1 | 0.0 | 228.0 | 18.0 | +333.6 | 0.0 | 142.0 |
| SPELL WORTH | - | - | - | - | 4.0 | +41.1 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 119.0 |
| STAND AND SHOOT | 0.3 | -0.8 | 0.0 | 0.0 | 0.7 | -5.1 | 34.7 | 36.3 |
| STANDS FOR A REASON | - | - | - | - | 11.3 | +0.0 | 0.0 | 73.0 |
| STANDS STILL | 56.3 | +0.0 | 685.0 | 534.0 | 35.7 | +0.0 | 0.0 | 296.0 |
| STAY WORTH | 46.0 | +475.5 | 469.3 | 284.7 | 29.3 | +305.6 | 0.0 | 207.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.2 | 0.0 | 11.3 |
| SUPPORT ADDS | 0.3 | +54.4 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 0.3 | +54.4 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 34.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 18.7 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 73.7 | 6.3 | +0.0 | 0.0 | 20.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 73.7 | 3.3 | +0.0 | 0.0 | 20.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.3 | +0.0 | 0.0 | 375.3 | 53.0 | +0.0 | 0.0 | 387.3 |
| TIED UP BY THE SUM | 0.3 | +28.3 | 15.0 | 0.0 | 0.3 | +53.6 | 34.7 | 0.0 |
| TIME ON OUR SIDE | 53.0 | +676.7 | 37.3 | 182.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 123.3 |
| WHO FIGHTS | - | - | - | - | 0.7 | -11.2 | 73.7 | 0.0 |
| WHO HITS BACK | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.3 | -72.7 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 5.0 | +65.7 | 0.0 | 0.0 | 0.7 | +9.0 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p42

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 361 | 358 | 135 | 45.00 | +2802 | +20.8 |
| ARMY TABLE | 122 | 122 | 100 | 33.33 | +1440 | +14.4 |
| HIS SHOTS BY HIS RUN | 300 | 297 | 94 | 31.33 | +1390 | +14.8 |
| HOLDER ASSIGNMENT | 81 | 81 | 75 | 25.00 | +4730 | +63.1 |
| SHOT RISK POINTS | 218 | 215 | 50 | 16.67 | +1521 | +30.4 |
| GOAL WALK | 103 | 101 | 35 | 11.67 | +1397 | +39.9 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -449 | -16.6 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 159 | 132 | 22 | 7.33 | +110 | +5.0 |
| ARTILLERY RE-ROLL WEIGHED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| MOVE ORDER | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| FIVE ACTION | 645 | 633 | 16 | 5.33 | +956 | +59.7 |
| SHOOTS FROM THE BEST SPOT | 28 | 28 | 14 | 4.67 | +242 | +17.3 |
| STAY WORTH | 226 | 202 | 14 | 4.67 | +128 | +9.2 |
| LEGAL CHARGES ONLY | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 13 | 4.33 | -693 | -53.3 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 20 | 16 | 11 | 3.67 | +520 | +47.3 |
| OGRE LOADER SECOND SHOT | 10 | 10 | 10 | 3.33 | +56 | +5.6 |
| IDLE COST | 73 | 48 | 9 | 3.00 | +61 | +6.8 |
| CAST JOB | 7 | 7 | 7 | 2.33 | +33 | +4.8 |
| NEXT CHARGE BY LIST | 13 | 11 | 7 | 2.33 | +443 | +63.3 |
| FOUR ROUNDS | 14 | 13 | 6 | 2.00 | +240 | +39.9 |
| GUN MASK | 15 | 15 | 6 | 2.00 | +231 | +38.4 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| QUARTER ODDS | 70 | 70 | 6 | 2.00 | +322 | +53.7 |
| THE RISK READS HIS RUN | 18 | 18 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 100 | 83 | 5 | 1.67 | +4 | +0.8 |
| MARCH CHECK | 7 | 7 | 5 | 1.67 | +101 | +20.1 |
| MAX FOR POSITIONING | 9 | 8 | 5 | 1.67 | +1 | +0.3 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +14 | +3.4 |
| CHARGE LOSSES | 115 | 112 | 4 | 1.33 | +325 | +81.1 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +105 | +26.2 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| NEARER NOT NEEDED | 36 | 33 | 4 | 1.33 | +85 | +21.2 |
| SHOTS IN THE MOVE | 144 | 117 | 4 | 1.33 | +172 | +43.0 |
| WOUNDS ON THE RANKS | 17 | 17 | 4 | 1.33 | +6 | +1.6 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 31 | 26 | 3 | 1.00 | +17 | +5.8 |
| HIS TURN DENIED | 5 | 5 | 3 | 1.00 | +301 | +100.5 |
| MISSILES IN THE MOVE | 37 | 27 | 3 | 1.00 | +21 | +7.1 |
| ONE OBJECTIVE FORMULA | 28 | 26 | 3 | 1.00 | +108 | +35.8 |
| RISK BY ARC | 9 | 8 | 3 | 1.00 | +95 | +31.8 |
| SHOTS AFTER THE MOVES | 25 | 25 | 3 | 1.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 28 | 28 | 2 | 0.67 | -16 | -7.8 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS MOVE AND SHOT | 41 | 40 | 2 | 0.67 | +6 | +3.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +29 | +14.4 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +64 | +32.2 |
| MISSILES NEXT TURN | 46 | 32 | 2 | 0.67 | +8 | +4.2 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -1 | -0.6 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -38 | -18.9 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +127 | +63.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +6 | +6.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -72 | -71.9 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -41 | -40.8 |
| EVASIVE BY THE ODDS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +41 | +40.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +1 | +0.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -20 | -20.0 |
| ONE FIGHT FORMULA | 24 | 18 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -40 | -40.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +65 | +65.0 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -37 | -37.2 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +11 | +10.7 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +10 | +10.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +23 | +23.4 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| SUPPORT ADDS | 1 | 1 | 1 | 0.33 | +113 | +113.2 |
| SUPPORT WORKED OUT | 1 | 1 | 1 | 0.33 | +113 | +113.2 |
| THE ROW IN ITS ORDER | 17 | 1 | 1 | 0.33 | +0 | +0.0 |
| WAR ENGINE JOBS | 20 | 20 | 1 | 0.33 | -0 | -0.3 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +7 | +7.5 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 19 | 19 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 70 | 69 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 11 | 10 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 40 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 17 | 15 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 18 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 7 | 7 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 28 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 115 | 115 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 11 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 27 | 27 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 18 | 18 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 16 | 16 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE ROUTE | 18 | 18 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 283 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 18 | 18 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 10 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 82 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 35 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 34 | 32 | 0 | 0.00 | - | - |
| STANDS STILL | 276 | 272 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 33 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 295 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p42

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.00 | 17.8 |
| ARMY TABLE | rule | - | 4.67 | 31.0 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 0.67 | 53.3 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 24.0 |
| NO REASON | gate | 0.67 | - | 10.1 |
| OWN CAST FIRST | rule | - | 0.67 | 0.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 18.9 |
| AFTERMATH BAND | gate | 0.33 | - | 1.0 |
| BEST PRIZE | rule | - | 0.33 | 71.9 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 15.6 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 40.8 |
| JOINT CHARGE NOW | rule | 0.33 | - | 11.9 |
| MARCH OF THE TABLE | rule | 0.33 | - | 20.0 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 40.1 |
| REFUSING RETIRES | rule | - | 0.33 | 37.2 |

### Plans: cnsr-c940641-p42

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 32 | 31 | 98% |
| Mine | move | 29.7 | 98% | 1388 | 0 | 0% |
| Mine | shoot | 15.0 | 62% | 689 | 839 | 122% |
| Opponent | charge | 1.0 | 100% | 38 | 109 | 285% |
| Opponent | move | 39.3 | 95% | 2039 | 0 | 0% |
| Opponent | shoot | 7.0 | 52% | 425 | 160 | 38% |
| Opponent | support | 1.3 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p42

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p42

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 16 (12) | 16 | 0 | 0 | 33% | 2.9 | 16 (5) | 9 (5) | 47 (2) | 17 (7) | 16 (5) |
| Mine | Clean-up | 2 | 58 (2) | 0 | 58 | 61 | 50% | 5.0 | - | - | 58 (2) | 58 (2) | - |
| Mine | Fast Hammer | 3 | 13 (3) | 0 | 13 | 0 | 33% | 1.5 | 0 (1) | 20 (2) | - | 18 (2) | 0 (1) |
| Mine | Hammer | 7 | 13 (7) | 9 | 4 | 0 | 14% | 1.8 | 0 (1) | 30 (3) | 0 (3) | 9 (5) | 22 (2) |
| Mine | Shooter | 6 | 94 (6) | 17 | 77 | 33 | 0% | 2.0 | 105 (1) | 159 (2) | 48 (3) | 113 (5) | 0 (1) |
| Mine | War machine | 8 | 11 (8) | 11 | 0 | 27 | 0% | 1.1 | 0 (1) | 25 (4) | 0 (3) | - | 11 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 11 | 124 (11) | 0 | 124 | 62 | 36% | 3.0 | 142 (3) | 117 (1) | 118 (7) | 124 (11) | - |
| Opponent | Character | 6 | 19 (6) | 19 | 0 | 0 | 0% | 1.7 | 39 (2) | 14 (2) | 0 (2) | 10 (2) | 25 (4) |
| Opponent | Clean-up | 4 | 27 (4) | 0 | 27 | 24 | 25% | 2.3 | - | 56 (2) | 0 (2) | 36 (3) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 10 | 0 (10) | 0 | 0 | 16 | 40% | 2.2 | 0 (4) | 0 (4) | 0 (2) | 0 (2) | 0 (8) |
| Opponent | Holder | 1 | 92 (1) | 0 | 92 | 0 | 100% | - | - | 92 (1) | - | - | 92 (1) |
| Opponent | Shooter | 1 | 150 (1) | 0 | 150 | 0 | 0% | 1.0 | - | 150 (1) | - | 150 (1) | - |

### Charged fights: cnsr-c940641-p42

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 157 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Mine | Grand Cathay | 1 | 100 | 105 | 4.0 | 1.0 | 26 | 0 | +26 | 0 of 4 | 4 of 4 | - | +26 |
| **Mine** | all armies | 3 | 138 | 35 | 1.7 | 1.0 | 21 | 0 | +21 | 1 of 5 | 4 of 5 | - | +21 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 1 of 2 | 1 of 2 | - | -17 |
| Opponent | Vampire Counts | 1 | 0 | 386 | 2.0 | 1.0 | 193 | 0 | +193 | 1 of 2 | 1 of 2 | - | +193 |
| Opponent | Wood Elf Realms | 1 | 0 | 104 | 2.0 | 1.0 | 52 | 54 | -2 | 0 of 2 | 1 of 2 | - | -2 |
| **Opponent** | all armies | 3 | 0 | 163 | 2.0 | 1.0 | 82 | 24 | +58 | 2 of 6 | 3 of 6 | - | +58 |

### Effective charges: cnsr-c940641-p42

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 4 | 0 | 0 | 0 | 1 (net +0) | 2 (net +22) | 0 | 1 | 0% (0 of 3) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 2 | 1 (net +0) | 0 | 1 (net +386) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 2 (net -2) | 0 | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cnsr-c940641-p42

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 265 | 499 | +0 | 166 | 159 | +7 | +2.8 |
| Mine | 76-89% | 1 | 205 | 110 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 352 | 52 | +22 | 40 | 0 | +40 | +11.5 |
| Mine | No odds | 1 | 205 | 60 | +60 | 60 | 0 | +60 | +29.3 |
| Mine | All fights | 5 | 276 | 155 | +21 | 61 | 32 | +30 | +10.8 |
| Opponent | Long shot (under 50%) | 1 | 329 | 205 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 1 | 500 | 171 | +386 | 386 | 62 | +324 | +64.7 |
| Opponent | 76-89% | 3 | 86 | 158 | -2 | 59 | 43 | +15 | +17.9 |
| Opponent | No odds | 1 | 34 | 189 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 6 | 187 | 173 | +58 | 94 | 38 | +56 | +29.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p42 | move | 12 | 1 (8%) | 1 (8%) | 3 (25%) | 8 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

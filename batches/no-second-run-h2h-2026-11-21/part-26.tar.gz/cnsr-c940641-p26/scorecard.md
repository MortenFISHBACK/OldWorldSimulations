# Doctrine scorecard: cnsr-c940641-p26

### Scorecard: cnsr-c940641-p26

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 9 | 0 | 0 | 0 | 285 |
| L0218 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 148 |
| L0235 | 1 | 1 | Mine | no | 6 | 4 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | yes | 5 | 3 | 1 | 4 | 1 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 4 | - | 0 | 0 | 0 | 0 | 0 | 335 |
| L0319 | 1 | 1 | Opponent | no | 2 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 5.0 | 4.0 | 0.3 | 4.3 | 0.0 | 0.0 | 0.0 | 206.7 |
| **Average** | | | Opponent | 50% | 3.5 | 3.0 | 0.7 | 3.7 | 0.3 | 0.0 | 0.0 | 91.0 |

### KPIs: cnsr-c940641-p26

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 11% (1 of 9) | 0% (0 of 13) | 5% (1 of 22) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 57% (24 of 42) | 8% (2 of 24) | 39% (26 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (24 of 42) | 10% (2 of 21) | 41% (26 of 63) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 73% (8 of 11) | - | 73% (8 of 11) |
| Points that never fought | lower | 78% (4525 of 5797) | 60% (3604 of 6000) | 69% (8129 of 11797) |
|   infantry points that never fought | lower | 77% (1060 of 1374) | 85% (717 of 842) | 80% (1777 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 80% (16 of 20) | 52% (14 of 27) | 64% (30 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 75% (3 of 4); 5.0 uses a game | 50% (1 of 2); 1.7 uses a game | 67% (4 of 6); 3.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 100% (1 of 1); 0.3 uses a game | 83% (5 of 6); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 76% (3063 of 4039) | 45% (2476 of 5515) | 58% (5539 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (100%) | 0.0 (0%) | 6.0 (45%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.3 (59%) | 4.3 (32%) |
| GONE: slain | 0.0 (0%) | 0.7 (9%) | 0.7 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.7 (23%) | 1.7 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 0.7 | 3.0 | 8.7 | 0.3 |
| not cast | 3.3 | 7.0 | 13.3 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (10%) | 0.0 (0%) | 6.0 (45%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (10%) | 0.3 (5%) | 0.3 (2%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (60%) | 4.0 (57%) | 4.3 (32%) | 0.0 (0%) |
| GONE: slain | 0.7 (20%) | 0.7 (10%) | 0.7 (5%) | 1.3 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.7 (12%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 2.0 (29%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.0 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.7 a game | 1.5 a game |
| stood (cast and not dispelled) | 86% (6 of 7) | 50% (1 of 2) | 78% (7 of 9) |
| the unit moved after it | 83% (5 of 6) | 0% (0 of 1) | 71% (5 of 7) |
| it charged on its next turn | 0% (0 of 6) | 0% (0 of 1) | 0% (0 of 7) |
| the enemy charged it first | 0% (0 of 6) | 0% (0 of 1) | 0% (0 of 7) |
| it fought by the end of its next turn | 0% (0 of 6) | 0% (0 of 1) | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | 0% (0 of 1) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 100% (6 of 6) | 100% (1 of 1) | 100% (7 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (22 of 33) | 53% (44 of 83) | 57% (66 of 116) |
|   cavalry | - | 59% (10 of 17) | 59% (10 of 17) |
|   character | - | 50% (6 of 12) | 50% (6 of 12) |
|   chariot | 50% (6 of 12) | 58% (7 of 12) | 54% (13 of 24) |
|   infantry | - | 37% (11 of 30) | 37% (11 of 30) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 76% (16 of 21) | - | 76% (16 of 21) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (36%) | 1.7 (13%) | 3.0 (18%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (8%) | 1.0 (6%) |
| IN COMBAT: it fought this turn or the last | 0.3 (9%) | 0.3 (3%) | 0.7 (4%) |
| MOVED: a war machine that moved | 0.7 (18%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.0 (0%) | 6.7 (51%) | 6.7 (40%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (36%) | 1.0 (8%) | 2.3 (14%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| OTHER BAR | 0.0 (0%) | 1.7 (13%) | 1.7 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.0 | 75% | 4.3 pts | 17 pts |
| character | 2.0 | 1.3 | 50% | 15.7 pts | 31 pts |
| chariot | 4.3 | 5.3 | 38% | 22.7 pts | 99 pts |
| infantry | 3.7 | 4.3 | 45% | 11.0 pts | 40 pts |
| monster | 3.3 | 3.7 | 50% | 14.8 pts | 49 pts |
| war machine | 5.3 | 2.7 | 75% | 6.3 pts | 34 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 3.0 | 2.0 |
| Charges that made contact a game | 1.0 | 2.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.12 declared, 0.12 contact (25 units) | 0.31 declared, 0.21 contact (29 units) | 0.22 declared, 0.17 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 0% (0 of 1) | - | 25% (1 of 4) |
| Character in a unit | 86% (6 of 7) | 83% (5 of 6) | - | 85% (11 of 13) |
| Character on its own | 100% (1 of 1) | 100% (2 of 2) | 0% (0 of 2) | 60% (3 of 5) |
| Chariot | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |
| Infantry | 60% (3 of 5) | 33% (1 of 3) | - | 50% (4 of 8) |
| Monster | 50% (1 of 2) | 0% (0 of 1) | - | 33% (1 of 3) |
| Monstrous | 100% (2 of 2) | 25% (1 of 4) | - | 50% (3 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 100% (1 of 1); on the table 100% | 80% (24 of 30) | 86% | 75% (9 of 12) | 75% (3 of 4); 7.5 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | - | 0% (0 of 12) | 63% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 100% | 57% (4 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 12) | 33% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | - | 33% (2 of 6) | 47% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p26, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 100% (1) | 80% (4) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p26

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (11 of 22) | 21% (3 of 14) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 10) | 80% (4 of 5) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 4.3 | 3.7 |
| Movement | Points that never moved of their own | 206.7 | 91.0 |
| Movement | Fights charged into per game | 0.7 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net +0 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 2, net +137 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +158 | 1 of 2, net -104 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.0 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 83% (5 of 6) | 50% (22 of 44) |
| Shooting | Points destroyed by shooting units | 0.0 | 38.3 |
| Shooting | War machine shots | 5.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (7 of 16) | - |
| Shooting | Points destroyed by war machines | 0.0 | 28.3 |
| Magic | Magic missiles cast | 4.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (3 of 12) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 11.3 | 1.7 |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 41.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.0 / 0.7 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 144.0 | 296.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +79 | +85 |
| Combat | Net per 100 charger points, damage counted | +71.2 | +18.4 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +79 | +133 |
| Combat | Net points per supported fight / lone fight | +158 / +0 | +137 / +132 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 2 | 2 of 5 |
| Game | Points lost | 413.7 | 204.0 |
| Game | VP from objectives | 653.3 | 1206.7 |
| Game | Lone holders (player turns) | 5.0 | 3.5 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -775 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 618
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p26

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| ARMY TABLE | 15.3 | +142.9 | 0.0 | 209.0 | 27.0 | +15.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -38.0 | 17.3 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | +5.2 | 52.7 | 17.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.3 | +0.0 | 55.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 4.3 | +36.3 | 91.7 | 73.3 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.7 | +10.9 | 52.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +48.9 | 0.0 | 0.0 | 2.3 | +39.6 | 103.3 | 0.0 |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +10.0 | 0.0 | 10.0 | 1.0 | +0.6 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 1.3 | -2.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +9.8 | 0.0 | 0.0 | 0.3 | +14.1 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.3 | -260.1 | 0.0 | 346.7 | 10.3 | -257.6 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 105.3 | 17.3 | 1.0 | +0.0 | 113.3 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -3.0 | 52.7 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 48.3 | 12.7 | +0.0 | 0.0 | 18.3 |
| CONVEYANCE SEARCH | 2.3 | +232.9 | 0.0 | 0.0 | 0.7 | +15.3 | 0.0 | 0.0 |
| COVER ONCE | 3.7 | -139.6 | 0.0 | 151.0 | 2.0 | -49.6 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | 0.3 | -3.4 | 52.7 | 0.0 | - | - | - | - |
| ELIXIR WORTH | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +11.5 | 105.3 | 17.3 | 1.3 | +5.9 | 74.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 105.3 | 0.0 | 1.0 | +0.0 | 56.7 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 10.0 | - | - | - | - |
| FALLS SHORT | 22.3 | +297.8 | 0.0 | 90.3 | 4.0 | +124.6 | 0.0 | 0.0 |
| FEATURE BUFFS | 11.3 | +539.9 | 0.0 | 117.3 | 1.0 | +29.6 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +8.0 | 105.3 | 0.0 | - | - | - | - |
| FIVE ACTION | 94.0 | +6877.3 | 320.7 | 883.3 | 103.3 | +6358.7 | 470.7 | 36.7 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 108.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +10.9 | 0.0 | 17.3 | - | - | - | - |
| FOUR ROUNDS | 1.0 | +153.9 | 158.0 | 17.3 | 1.7 | +96.9 | 130.7 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 17.3 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -2.1 | 17.3 | 0.0 |
| GOAL WALK | 7.7 | +828.4 | 0.0 | 28.3 | 13.7 | +1051.0 | 0.0 | 0.0 |
| GROUND FLIERS | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 2.0 | +4.1 | 0.0 | 0.0 | 2.0 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.3 | +0.0 | 52.7 | 17.3 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 186.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +41.9 | 56.7 | 0.0 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 60.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.7 | -101.8 | 0.0 | 193.7 | 4.0 | -42.4 | 0.0 | 0.0 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.0 | +0.0 | 0.0 | 60.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 18.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 58.0 | +1923.5 | 0.0 | 382.7 | 68.0 | +3364.6 | 0.0 | 36.7 |
| HIS SHOTS BY HIS RUN | 53.7 | +969.8 | 0.0 | 709.3 | 42.0 | +1083.1 | 0.0 | 36.7 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +16.8 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 33.0 | +0.0 | 0.0 | 121.3 | 21.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 15.0 | +1641.6 | 0.0 | 87.0 | 13.7 | +1505.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -1.2 | 105.3 | 0.0 | 1.7 | -71.6 | 130.7 | 0.0 |
| IDLE COST | 17.3 | -96.4 | 0.0 | 108.7 | 4.0 | -67.2 | 0.0 | 18.3 |
| JOINT CHARGE NOW | 0.7 | -39.5 | 105.3 | 0.0 | 0.3 | -8.6 | 28.3 | 0.0 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +9.1 | 28.3 | 0.0 |
| KEEP FALLS | 0.3 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 155.3 | 1.0 | +0.0 | 74.0 | 52.7 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +1.1 | 105.3 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +45.0 | 0.0 | 17.3 | 3.3 | -38.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +151.2 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +22.1 | 0.0 | 0.0 | 1.3 | +48.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -40.6 | 0.0 | 0.0 | 0.3 | +129.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +41.8 | 0.0 | 85.0 | 1.7 | +18.3 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +350.6 | 0.0 | 0.0 | 4.0 | +73.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.7 | +267.2 | 0.0 | 0.0 | 4.0 | +51.7 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.7 | -150.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.7 | +0.0 | 45.7 | 17.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.3 | -83.2 | 0.0 | 91.3 |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.0 | +441.4 | 0.0 | 189.0 | - | - | - | - |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +194.3 | 0.0 | 0.0 | 11.7 | +537.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +196.5 | 0.0 | 86.7 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.0 | -114.5 | 158.0 | 17.3 | 1.7 | -41.7 | 130.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.7 | -1933.8 | 0.0 | 103.3 | 3.0 | -54.5 | 17.3 | 0.0 |
| OGRE LOADER SECOND SHOT | 1.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | +12.1 | 52.7 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.0 | -35.2 | 0.0 | 240.3 | 2.0 | -66.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.7 | +206.8 | 0.0 | 0.0 | 4.7 | -41.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.3 | -55.7 | 0.0 | 80.3 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.3 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +15.2 | 45.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +7.6 | 105.3 | 0.0 | 0.7 | +11.6 | 74.0 | 0.0 |
| PLAN RESULT | 43.0 | +244.2 | 71.0 | 691.3 | 44.7 | +333.2 | 131.7 | 71.0 |
| PROMISE BY ITS OWN SUM | 9.3 | -3977.7 | 0.0 | 235.0 | 3.0 | -96.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | -0.5 | 0.0 | 34.7 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -44.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.3 | -3.0 | 0.0 | 146.7 | - | - | - | - |
| QUARTER ODDS | 14.3 | +1028.9 | 105.3 | 263.3 | 17.3 | +1888.1 | 56.7 | 0.0 |
| RANDOM MOVE BY FIGURES | 3.7 | +68.8 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +54.7 | 0.0 | 105.0 | 2.0 | -64.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 76.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -132.5 | 0.0 | 108.7 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | +1.9 | 105.3 | 17.3 | 1.0 | -20.4 | 102.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -13.8 | 28.3 | 0.0 |
| RUN DOWN | 1.0 | -17.3 | 158.0 | 17.3 | 1.0 | -0.5 | 56.7 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -11.3 | 0.0 | 10.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 10.0 | 1.3 | +3.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +18.3 | 17.3 | 0.0 |
| SET CREDITED ONCE | 1.0 | -5.2 | 0.0 | 27.3 | - | - | - | - |
| SET UP BY THE SET | 1.0 | +55.0 | 0.0 | 27.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +3.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +8.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 73.3 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +45.5 | 0.0 | 0.0 | 2.7 | +24.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.5 | 28.3 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 47.0 | +480.4 | 0.0 | 585.7 | 51.0 | +561.4 | 0.0 | 36.7 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 7.7 | +177.9 | 0.0 | 73.3 | 19.7 | +402.2 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +8.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -34.4 | 52.7 | 17.3 | - | - | - | - |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 308.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -2.9 | 52.7 | 17.3 | - | - | - | - |
| STANDS FOR A REASON | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 42.7 | +0.0 | 162.7 | 174.0 | 50.3 | +0.0 | 340.0 | 0.0 |
| STAY WORTH | 19.0 | +89.5 | 162.7 | 323.3 | 21.3 | +54.7 | 283.3 | 0.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.7 | +255.6 | 0.0 | 113.3 | 3.3 | +59.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 28.3 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +255.6 | 0.0 | 113.3 | 3.3 | +59.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +0.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -71.2 | 0.0 | 17.3 | - | - | - | - |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.7 | +0.0 | 56.7 | 183.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 17.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.0 | +0.0 | 0.0 | 381.3 | 49.7 | +0.0 | 0.0 | 18.3 |
| TIED UP BY THE SUM | - | - | - | - | 1.0 | +152.9 | 102.3 | 0.0 |
| TIME ON OUR SIDE | 9.0 | +154.0 | 0.0 | 30.3 | 67.0 | +494.8 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 58.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 56.7 | 0.0 |
| WHO FIGHTS | 0.3 | +9.2 | 52.7 | 17.3 | 0.3 | +0.2 | 28.3 | 0.0 |
| WHO HITS BACK | 0.7 | +16.2 | 0.0 | 0.0 | 0.3 | +42.7 | 0.0 | 52.7 |
| WHOLE FIGHT DANGER | 0.7 | -37.3 | 0.0 | 30.3 | 0.7 | -16.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 5.7 | +457.3 | 0.0 | 0.0 | 2.3 | +148.9 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p26

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SHOT RISK POINTS | 294 | 289 | 108 | 36.00 | +2540 | +23.5 |
| HIS SHOT LIST | 378 | 375 | 99 | 33.00 | +835 | +8.4 |
| HIS SHOTS BY HIS RUN | 287 | 272 | 89 | 29.67 | +1763 | +19.8 |
| ARMY TABLE | 127 | 127 | 81 | 27.00 | +408 | +5.0 |
| HOLDER ASSIGNMENT | 86 | 86 | 80 | 26.67 | +4798 | +60.0 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| TIME ON OUR SIDE | 228 | 208 | 34 | 11.33 | +123 | +3.6 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| FIVE ACTION | 592 | 570 | 23 | 7.67 | +658 | +28.6 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 19 | 6.33 | -12223 | -643.3 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 64 | 59 | 17 | 5.67 | +801 | +47.1 |
| OFF BEST | 17 | 17 | 17 | 5.67 | -5965 | -350.9 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| STAY WORTH | 121 | 103 | 10 | 3.33 | +60 | +6.0 |
| CAST JOB | 11 | 11 | 9 | 3.00 | +11 | +1.2 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 24 | 24 | 9 | 3.00 | +599 | +66.5 |
| CASTING BLOCK | 9 | 9 | 8 | 2.67 | +81 | +10.1 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 8 | 2.67 | +207 | +25.8 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 8 | 2.67 | +19 | +2.4 |
| FALLS SHORT | 79 | 59 | 7 | 2.33 | +95 | +13.6 |
| MOVE TO CHARGE COMPUTED | 12 | 10 | 7 | 2.33 | +411 | +58.7 |
| SUPPORT ADDS | 15 | 14 | 7 | 2.33 | +161 | +23.0 |
| SUPPORT WORKED OUT | 15 | 14 | 7 | 2.33 | +161 | +23.0 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 33 | 20 | 5 | 1.67 | +209 | +41.8 |
| QUARTER ODDS | 95 | 89 | 5 | 1.67 | +653 | +130.6 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -8 | -2.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| NEXT CHARGE BY LIST | 7 | 6 | 4 | 1.33 | +125 | +31.3 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -167 | -41.7 |
| PROMISE SHOT AWAY | 4 | 4 | 4 | 1.33 | -9 | -2.2 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +10 | +2.6 |
| THE RISK READS HIS RUN | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE LOSSES | 71 | 68 | 3 | 1.00 | +109 | +36.3 |
| FEATURE BUFFS | 37 | 36 | 3 | 1.00 | +67 | +22.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -144 | -48.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +500 | +166.8 |
| MAX FOR POSITIONING | 9 | 9 | 3 | 1.00 | +6 | +2.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +1 | +0.4 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 28 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +128 | +42.6 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +72 | +35.8 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -72 | -36.1 |
| FOUR ROUNDS | 8 | 6 | 2 | 0.67 | +94 | +46.8 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| MARCH CHECK | 6 | 6 | 2 | 0.67 | +77 | +38.6 |
| ONE OBJECTIVE FORMULA | 37 | 23 | 2 | 0.67 | +223 | +111.5 |
| PROMISE KNOWS THE FIGHT | 5 | 4 | 2 | 0.67 | -1 | -0.7 |
| SHOTS AFTER THE MOVES | 12 | 12 | 2 | 0.67 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +3 | +1.4 |
| TIED UP BY THE SUM | 3 | 2 | 2 | 0.67 | +119 | +59.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -114 | -114.1 |
| CANNON PLANNED TARGET | 13 | 13 | 1 | 0.33 | +0 | +0.2 |
| CHAFF IN THE MOVE | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| COVER ONCE | 17 | 9 | 1 | 0.33 | +37 | +36.6 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +16 | +16.1 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +33 | +32.6 |
| HIS CHARGE DENIED | 2 | 1 | 1 | 0.33 | +97 | +96.5 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +17 | +16.6 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +27 | +27.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +6 | +6.3 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +135 | +135.1 |
| REDIRECT COUNTER | 13 | 10 | 1 | 0.33 | +3 | +2.8 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +110 | +109.9 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +55 | +54.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 82 | 62 | 1 | 0.33 | +8 | +7.5 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -49 | -48.9 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 70 | 68 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 6 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 20 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 26 | 26 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 6 | 6 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 32 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 6 | 6 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 56 | 54 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 163 | 161 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 5 | 0 | 0.00 | - | - |
| IDLE COST | 64 | 48 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 32 | 21 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 5 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 46 | 42 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 8 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 18 | 8 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | not checked | - | - | - | - |
| OPENS UP | 2 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 263 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 5 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 37 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 279 | 266 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 275 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p26

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 1.33 | 643.3 |
| ARMY TABLE | rule | - | 5.00 | 51.0 |
| JOB FIRST | gate | 2.67 | 2.33 | 393.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 2.00 | 27.5 |
| PROMISE SHOT AWAY | rule | 1.33 | - | 2.2 |
| CHAFF PASSED | rule | - | 1.00 | 2.7 |
| ONE PROMISE A TARGET | rule | 1.00 | - | 61.4 |
| CHARGE NOW FIRST | rule | - | 0.67 | 36.1 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 107.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 0.7 |
| RULE SWITCHED OFF | gate | - | 0.67 | 33.3 |
| BEST PRIZE | rule | - | 0.33 | 114.1 |
| SUPPORT NARROWED | rule | - | 0.33 | 48.9 |

### Plans: cnsr-c940641-p26

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 174 | 105 | 61% |
| Mine | move | 36.3 | 94% | 2570 | 0 | 0% |
| Mine | shoot | 5.7 | 65% | 153 | 139 | 91% |
| Opponent | charge | 1.3 | 100% | 178 | 131 | 73% |
| Opponent | move | 40.0 | 98% | 2154 | 0 | 0% |
| Opponent | shoot | 3.3 | 50% | 113 | 202 | 179% |

### Battle groups: cnsr-c940641-p26

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 29% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p26

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 10 (11) | 10 | 0 | 12 | 36% | 2.7 | - | 0 (5) | 21 (5) | 10 (10) | - |
| Mine | Clean-up | 2 | 226 (2) | 0 | 226 | 49 | 100% | - | 316 (1) | - | 132 (1) | 226 (2) | - |
| Mine | Fast Hammer | 10 | 52 (10) | 52 | 0 | 63 | 60% | 4.0 | 0 (6) | 0 (1) | 132 (3) | 73 (7) | 0 (3) |
| Mine | Hammer | 9 | 30 (9) | 2 | 27 | 24 | 44% | 3.4 | 0 (2) | 21 (4) | 83 (3) | 30 (9) | - |
| Mine | Holder | 2 | 60 (2) | 0 | 60 | 0 | 100% | - | 119 (1) | - | 0 (1) | - | 60 (2) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 19 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 15 (8) | 0 | 15 | 14 | 75% | 5.5 | 31 (3) | 0 (4) | 0 (1) | 17 (7) | 0 (1) |
| Opponent | Character | 7 | 36 (7) | 36 | 0 | 14 | 0% | 3.0 | 63 (1) | 26 (4) | 55 (1) | 48 (4) | 33 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 2.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 30 (1) | 30 | 0 | 0 | 0% | 5.0 | - | 30 (1) | - | 30 (1) | - |
| Opponent | Hammer | 10 | 78 (10) | 15 | 63 | 6 | 50% | 1.8 | 21 (5) | 134 (4) | 110 (1) | 40 (5) | 106 (5) |
| Opponent | Shooter | 4 | 109 (4) | 6 | 103 | 30 | 0% | 2.0 | 0 (1) | 110 (2) | 193 (1) | 88 (3) | 184 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (2) | - | 0 (2) | - |

### Charged fights: cnsr-c940641-p26

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 62 | 79 | 1.0 | 1.5 | 79 | 0 | +79 | 2 of 2 | 2 of 2 | +158 | +0 |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 42 | 53 | 0.7 | 1.5 | 79 | 0 | +79 | 2 of 2 | 2 of 2 | +158 | +0 |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 529 | 2.0 | 1.0 | 264 | 0 | +264 | 2 of 2 | 2 of 2 | - | +264 |
| Opponent | Wood Elf Realms | 1 | 30 | 411 | 3.0 | 1.3 | 137 | 91 | +46 | 0 of 3 | 3 of 3 | +137 | +0 |
| **Opponent** | all armies | 3 | 67 | 313 | 1.7 | 1.2 | 188 | 55 | +133 | 2 of 5 | 5 of 5 | +137 | +132 |

### Effective charges: cnsr-c940641-p26

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +158) | 0 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 0 | 1 (net +137) | 1 (net -104) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: cnsr-c940641-p26

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 52 | 158 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 170 | 158 | +158 | 158 | 0 | +158 | +92.9 |
| Mine | All fights | 2 | 111 | 158 | +79 | 79 | 0 | +79 | +71.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 170 | -104 | 170 | 385 | -215 | -43.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 624 | 85 | +137 | 137 | 0 | +137 | +22.0 |
| Opponent | No odds | 3 | 397 | 225 | +211 | 220 | 52 | +168 | +42.3 |
| Opponent | All fights | 5 | 463 | 186 | +133 | 193 | 108 | +85 | +18.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p26 | move | 13 | 4 (31%) | 3 (23%) | 0 (0%) | 9 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

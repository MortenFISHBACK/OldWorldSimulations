# Doctrine scorecard: cnsr-c940641-p33

### Scorecard: cnsr-c940641-p33

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 3 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 50% | 3.0 | 3.0 | 2.0 | 1.0 | 0.5 | 0.0 | 0.0 | 50.0 |
| **Average** | | | Opponent | 50% | 1.0 | 2.5 | 4.5 | 2.0 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: cnsr-c940641-p33

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 15) | 0% (0 of 30) |
| Winner chose to follow up after the loser gave ground |  | 88% (7 of 8); on the table 100% | 50% (2 of 4); on the table 100% | 75% (9 of 12); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (2 of 4); on the table 50% | 50% (2 of 4); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | 43% (3 of 7); on the table 86% | 43% (3 of 7); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 88% (7 of 8); on the table 100% | 47% (7 of 15); on the table 80% | 61% (14 of 23); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 5) | 72% (13 of 18) | 57% (13 of 23) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 81% (13 of 16) | 81% (13 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 22% (897 of 4000) | 38% (1516 of 3999) | 30% (2413 of 7999) |
|   infantry points that never fought | lower | 69% (657 of 959) | 28% (128 of 457) | 55% (785 of 1416) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (7 of 13) | 42% (5 of 12) | 48% (12 of 25) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (1816 of 3520) | 28% (892 of 3154) | 41% (2708 of 6674) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (60%) | 1.0 (60%) |
| IN COMBAT: engaged in combat | - | 0.7 (40%) | 0.7 (40%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.7 | 0.3 | 4.3 | 0.7 | 4.3 |
| not cast | 6.3 | 2.3 | 1.7 | 1.7 | 1.3 | 22.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 1.0 (60%) | 0.7 (50%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (5%) | 1.3 (57%) | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.3 (84%) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.7 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (30 of 44) | - | 68% (30 of 44) |
|   cavalry | 100% (8 of 8) | - | 100% (8 of 8) |
|   character | 43% (3 of 7) | - | 43% (3 of 7) |
|   chariot | 33% (2 of 6) | - | 33% (2 of 6) |
|   infantry | 64% (7 of 11) | - | 64% (7 of 11) |
|   war machine | 83% (10 of 12) | - | 83% (10 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (43%) | - | 2.0 (43%) |
| CHARGED: it charged | 1.0 (21%) | - | 1.0 (21%) |
| IN COMBAT: it fought this turn or the last | 0.7 (14%) | - | 0.7 (14%) |
| MOVED: a war machine that moved | 0.3 (7%) | - | 0.3 (7%) |
| NO TARGET IN RANGE | 0.7 (14%) | - | 0.7 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 0.7 | 89% | 0.4 pts | 1 pts |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 0.7 | 0.3 | 50% | 15.8 pts | 11 pts |
| infantry | 4.7 | 1.3 | 86% | 6.3 pts | 29 pts |
| war machine | 3.3 | 2.7 | 50% | 24.5 pts | 82 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 5.0 | 5.0 |
| Charges that made contact a game | 4.3 | 4.3 | 4.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 1.00 declared, 0.00 contact (2 units) | 0.60 declared, 0.20 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.67 declared, 0.57 contact (21 units) | 0.52 declared, 0.52 contact (25 units) | 0.59 declared, 0.54 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 50% (1 of 2) | 0% (0 of 2) | 14% (1 of 7) |
| Character in a unit | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Character on its own | 100% (1 of 1) | 0% (0 of 2) | 40% (2 of 5) | 38% (3 of 8) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 75% (3 of 4) | 100% (2 of 2) | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 0% | 43% (3 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 83% (5 of 6); on the table 100% | - | 45% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 2 | 47% (7 of 15); on the table 80% | 72% (13 of 18) | 38% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p33, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 50% (5) | 38% (5) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.33 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p33

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 85% (11 of 13) | 64% (9 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 12% (2 of 17) | 0% (0 of 14) |
| Strategy | Support requests answered (helper made contact too) | 100% (3 of 3) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 40% (2 of 5) |
| Strategy | Lone characters that fought | 100% (5 of 5) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 50.0 | 0.0 |
| Movement | Fights charged into per game | 4.5 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 8, net +268 | 1 of 8, net +100 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 8, net +0 | 1 of 8, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 8, net +50 | 0 of 8 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 8, net -92 | 3 of 8, net +127 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (13 of 26) | - |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 3.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 70% (7 of 10) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 2.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 75% (6 of 8) |
| Magic | Wounds caused by magic missiles | 1.7 | - |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 41.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.3 / 0.3 / 0.0 | 2.0 / 0.3 / 1.3 / 0.7 |
| Combat | Points destroyed in combat | 272.7 | 291.3 |
| Combat | Points run down | 0.0 | 169.7 |
| Combat | Net points per charged fight, damage counted | +15 | +21 |
| Combat | Net per 100 charger points, damage counted | +4.0 | +17.3 |
| Combat | First round won (charged fights) | 89% | 75% |
| Combat | Net points per charged fight | -40 | +22 |
| Combat | Net points per supported fight / lone fight | -138 / -12 | - / +22 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 9 | 0 of 8 |
| Game | Points lost | 721.5 | 421.5 |
| Game | VP from objectives | 385.0 | 580.0 |
| Game | Lone holders (player turns) | 3.0 | 1.0 |

- Mine won / drew / lost: 0 / 1 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -408 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1143
- Games not ended: 1 (L1723-1); findings 1, warnings 0

### Opponent rules: cnsr-c940641-p33

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +81.9 | 0.0 | 0.0 | 0.7 | +48.9 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +4.1 | 0.0 | 0.0 |
| ARMY TABLE | 17.0 | +305.5 | 0.0 | 84.0 | 19.3 | +203.3 | 0.0 | 102.7 |
| ASSAILMENT BY POINTS | - | - | - | - | 2.0 | +6.1 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -28.6 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.7 | -71.5 | 0.0 | 92.3 | - | - | - | - |
| CANNON PLANNED TARGET | 3.3 | +26.4 | 0.0 | 33.3 | - | - | - | - |
| CAST JOB | 0.7 | +23.1 | 25.0 | 0.0 | 4.3 | +38.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +184.9 | 0.0 | 40.0 |
| CHAFF PASSED | 1.3 | -5.4 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +6.9 | 0.0 | 0.0 |
| CHARGE LOSSES | 14.7 | -712.9 | 0.0 | 168.0 | 10.7 | -563.5 | 0.0 | 84.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 49.0 | 0.0 | 4.0 | +0.0 | 178.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 84.0 | 18.3 | +0.0 | 0.0 | 84.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 199.0 | - | - | - | - |
| COVER ONCE | 15.7 | -829.3 | 0.0 | 92.0 | 12.0 | -1304.5 | 0.0 | 150.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -3.5 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +110.4 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.3 | -50.5 | 133.7 | 92.3 | 3.7 | +20.4 | 176.0 | 16.7 |
| FALL BACK GOOD ORDER | 2.3 | +0.0 | 49.0 | 92.3 | 2.7 | +0.2 | 127.3 | 16.7 |
| FALLS SHORT | - | - | - | - | 24.0 | +310.6 | 0.0 | 159.3 |
| FEATURE BUFFS | 1.3 | +36.0 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| FIGHT LIFT | 0.7 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +7.6 | 84.7 | 0.0 | 2.0 | +10.9 | 100.7 | 0.0 |
| FIVE ACTION | 72.0 | +4283.3 | 366.3 | 694.7 | 86.3 | +6074.9 | 265.0 | 441.7 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 58.7 | 7.0 | +0.0 | 0.0 | 168.3 |
| FOLLOW UP WEIGHED | 2.3 | +347.2 | 0.0 | 92.3 | 2.0 | +417.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +357.6 | 251.3 | 184.7 | 5.0 | +267.3 | 265.0 | 16.7 |
| FREED FROM HIS FIGHT | 10.0 | +0.0 | 0.0 | 117.3 | 3.0 | +0.0 | 0.0 | 33.3 |
| FRIEND SHOOTS FIRST | - | - | - | - | 3.0 | -9.2 | 0.0 | 30.0 |
| GIVES UP | 1.0 | -2.4 | 84.7 | 0.0 | - | - | - | - |
| GOAL WALK | 12.0 | +913.7 | 0.0 | 0.0 | 4.7 | +399.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 7.3 | +0.0 | 0.0 | 117.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.7 | +0.0 | 84.7 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 13.0 | +0.0 | 0.0 | 168.0 | 8.3 | +0.0 | 0.0 | 84.7 |
| HIS CHARGE DENIED | 0.7 | +51.7 | 102.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 7.3 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 94.3 |
| HIS LEGAL MOVES | 6.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 120.7 |
| HIS MOVE AND SHOT | 4.7 | -19.3 | 0.0 | 0.0 | 4.7 | -53.9 | 0.0 | 25.0 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 33.3 |
| HIS OWN BEST MOVE | 10.3 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 120.7 |
| HIS RUN AFTER OUR TURN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 25.0 | +135.4 | 0.0 | 144.0 | 41.7 | +887.9 | 0.0 | 106.3 |
| HIS SHOTS BY HIS RUN | 25.3 | +179.1 | 0.0 | 0.0 | 38.0 | +570.9 | 0.0 | 107.7 |
| HIS TURN DENIED | 1.0 | +2.1 | 0.0 | 184.7 | 2.0 | +65.1 | 176.0 | 0.0 |
| HIS TURN RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 9.0 | +0.0 | 0.0 | 228.0 | 15.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 6.0 | +483.0 | 0.0 | 127.3 | 11.0 | +768.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -192.0 | 251.3 | 184.7 | 4.7 | -147.7 | 231.7 | 16.7 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +5.1 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +48.6 | 33.3 | 0.0 |
| IDLE COST | - | - | - | - | 16.0 | -169.1 | 0.0 | 15.0 |
| JOINT CHARGE NOW | 2.0 | +374.5 | 169.3 | 184.7 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 117.3 | 6.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 15.0 | +0.0 | 99.0 | 1903.0 | 8.0 | +0.0 | 127.3 | 218.3 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 3.0 | -21.9 | 84.7 | 184.7 | 3.3 | +10.3 | 238.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.0 | -74.5 | 0.0 | 25.0 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 42.0 | 1.3 | +12.3 | 0.0 | 25.0 |
| MARCH BY THE SUM | 0.3 | +38.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +118.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 58.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +41.4 | 0.0 | 0.0 | 5.0 | +207.3 | 0.0 | 58.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +51.1 | 0.0 | 0.0 | 4.3 | +37.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +40.0 | 0.0 | 0.0 | 4.7 | +21.8 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 9.0 | +698.6 | 0.0 | 0.0 | 11.0 | +1048.7 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.3 | +327.2 | 0.0 | 163.0 | 6.7 | +261.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 7.3 | +538.7 | 0.0 | 0.0 | 7.7 | +727.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -203.7 | 166.7 | 184.7 | 4.7 | -153.6 | 265.0 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 58.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.0 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -95.1 | 0.0 | 85.3 | 5.7 | -242.3 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 58.7 | - | - | - | - |
| ONE FIGHT FORMULA | 6.0 | -106.8 | 0.0 | 0.0 | 7.0 | -147.0 | 0.0 | 99.7 |
| ONE JOINT FIGURE | 0.3 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.3 | -39.5 | 0.0 | 68.7 | 4.7 | +37.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -42.0 | 0.0 | 0.0 | 0.7 | -25.2 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 58.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +27.7 | 62.3 | 0.0 |
| OVERRUNS AWAY | 1.0 | +7.1 | 33.0 | 0.0 | 1.7 | +52.1 | 94.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +7.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -16.3 | 0.0 | 0.0 |
| PLAN RESULT | 33.0 | +682.3 | 243.3 | 577.3 | 43.7 | +324.2 | 127.3 | 432.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.7 | -203.9 | 0.0 | 0.0 | 10.0 | -306.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | -3.7 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.7 | -4.2 | 0.0 | 30.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| QUARTER ODDS | 13.0 | +1359.9 | 49.0 | 284.7 | 15.7 | +2395.1 | 95.7 | 131.3 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 58.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +16.2 | 0.0 | 0.0 | 5.3 | +675.8 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 26.7 | 4.7 | +0.0 | 0.0 | 18.0 |
| REFORMS TO MEET IT | 2.0 | -65.6 | 0.0 | 0.0 | 1.3 | -36.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 84.7 |
| RESERVE FALL BACK | 0.3 | +1.6 | 0.0 | 0.0 | 0.7 | +4.0 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | +218.8 | 251.3 | 92.3 | 4.0 | -159.3 | 196.3 | 16.7 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 58.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -32.4 | 178.3 | 0.0 |
| RUN DOWN | - | - | - | - | 4.0 | -37.0 | 265.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -7.3 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -45.8 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +1.2 | 0.0 | 0.0 | 1.7 | +26.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -23.5 | 0.0 | 0.0 | 2.0 | -74.6 | 0.0 | 15.0 |
| SET UP BY THE SET | 4.0 | -27.0 | 0.0 | 0.0 | 3.0 | +90.5 | 0.0 | 30.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 60.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +2.0 | 15.0 | 0.0 | 1.0 | +47.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.8 | 0.0 | 16.7 |
| SHOT RISK POINTS | 11.3 | -64.1 | 0.0 | 0.0 | 31.0 | -220.2 | 0.0 | 106.3 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +311.9 | 0.0 | 238.3 | 8.3 | +158.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +17.3 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 58.7 | 8.0 | +0.0 | 0.0 | 49.0 |
| STAND AND SHOOT | - | - | - | - | 2.3 | -13.9 | 26.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 23.7 | +0.0 | 115.0 | 210.7 | 16.7 | +0.0 | 0.0 | 75.0 |
| STAY WORTH | 7.7 | +0.9 | 0.0 | 0.0 | 10.0 | +64.5 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.3 | +1.1 | 33.3 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +16.5 | 84.7 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.7 | +258.8 | 0.0 | 0.0 | 8.0 | +579.7 | 0.0 | 141.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.7 | +258.8 | 0.0 | 0.0 | 8.0 | +579.7 | 0.0 | 141.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +16.6 | 0.0 | 15.0 |
| SWIFTSTRIDE BY POINTS | 0.7 | +1.9 | 0.0 | 26.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -24.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.3 | +0.0 | 0.0 | 202.7 | 43.3 | +0.0 | 0.0 | 176.0 |
| TIED UP BY THE SUM | 0.7 | +73.1 | 33.0 | 0.0 | 2.3 | +286.0 | 163.0 | 0.0 |
| TIME ON OUR SIDE | 33.0 | +461.9 | 0.0 | 247.0 | - | - | - | - |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 15.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.0 | +0.0 | 0.0 | 25.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -6.6 | 0.0 | 33.3 |
| WHO FIGHTS | 0.7 | +13.1 | 0.0 | 92.3 | 1.3 | +10.4 | 85.3 | 0.0 |
| WHO HITS BACK | 0.7 | +102.7 | 0.0 | 0.0 | 0.7 | +11.2 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 16.7 |
| WHOLE FIGHT DANGER | 4.7 | -630.2 | 0.0 | 168.0 | 2.3 | -361.0 | 0.0 | 84.7 |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 0.0 | 92.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +26.9 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p33

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 109 | 109 | 74 | 24.67 | +1489 | +20.1 |
| LEGAL CHARGES ONLY | 69 | 69 | 69 | 23.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 51 | 51 | 47 | 15.67 | +2690 | +57.2 |
| HIS SHOT LIST | 200 | 195 | 37 | 12.33 | +210 | +5.7 |
| HIS SHOTS BY HIS RUN | 190 | 179 | 34 | 11.33 | +265 | +7.8 |
| FIVE ACTION | 475 | 460 | 30 | 10.00 | +2568 | +85.6 |
| THE TABLE AGAIN | 33 | 33 | 30 | 10.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 60 | 53 | 27 | 9.00 | +1211 | +44.9 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -1012 | -37.5 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| PROMISE BY ITS OWN SUM | 62 | 62 | 20 | 6.67 | -1532 | -76.6 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| NEXT CHARGE BY LIST | 45 | 43 | 18 | 6.00 | +1061 | +58.9 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| MOVE ORDER | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| FOUR ROUNDS | 29 | 28 | 14 | 4.67 | +644 | +46.0 |
| FOLLOW UP WEIGHED | 13 | 13 | 13 | 4.33 | +2293 | +176.4 |
| THE RISK READS HIS RUN | 17 | 17 | 13 | 4.33 | +0 | +0.0 |
| COVER ONCE | 83 | 60 | 12 | 4.00 | +183 | +15.3 |
| SUPPORT ADDS | 35 | 35 | 12 | 4.00 | +327 | +27.3 |
| SUPPORT WORKED OUT | 35 | 35 | 12 | 4.00 | +327 | +27.3 |
| CAST JOB | 15 | 15 | 10 | 3.33 | +26 | +2.6 |
| GOAL WALK | 50 | 50 | 10 | 3.33 | +583 | +58.3 |
| QUARTER ODDS | 86 | 80 | 9 | 3.00 | +414 | +46.1 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| SET UP BY THE SET | 21 | 21 | 8 | 2.67 | +616 | +77.0 |
| TIED UP BY THE SUM | 9 | 9 | 8 | 2.67 | +211 | +26.4 |
| IDLE COST | 48 | 42 | 7 | 2.33 | +67 | +9.5 |
| SHOT RISK POINTS | 127 | 119 | 7 | 2.33 | +83 | +11.8 |
| ASSAILMENT BY POINTS | 6 | 6 | 6 | 2.00 | +18 | +3.1 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +1123 | +187.2 |
| MAX FOR POSITIONING | 20 | 18 | 6 | 2.00 | +16 | +2.6 |
| RISK BY ARC | 24 | 23 | 6 | 2.00 | +211 | +35.1 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -16 | -4.1 |
| CHARGE NOW FIRST | 16 | 16 | 4 | 1.33 | -169 | -42.2 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -202 | -50.4 |
| SEARCH SPOT | 6 | 6 | 4 | 1.33 | +83 | +20.8 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| TIME ON OUR SIDE | 99 | 73 | 4 | 1.33 | +2 | +0.5 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +202 | +50.5 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +392 | +130.8 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 11 | 8 | 3 | 1.00 | -11 | -3.7 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +17 | +5.6 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 3 | 1.00 | +48 | +15.9 |
| CHARGE LOSSES | 76 | 71 | 2 | 0.67 | +433 | +216.4 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +128 | +63.8 |
| EXACT ROUND | 18 | 17 | 2 | 0.67 | +34 | +17.1 |
| FALLS SHORT | 72 | 62 | 2 | 0.67 | +0 | +0.0 |
| HIS MOVE AND SHOT | 28 | 27 | 2 | 0.67 | +8 | +4.0 |
| HIS TURN DENIED | 9 | 9 | 2 | 0.67 | +9 | +4.5 |
| HONEST WORTH | 28 | 27 | 2 | 0.67 | +25 | +12.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| NEARER NOT NEEDED | 48 | 46 | 2 | 0.67 | +93 | +46.7 |
| NO DOUBLE ROUNDS | 25 | 24 | 2 | 0.67 | +39 | +19.4 |
| OVERRUNS AWAY | 8 | 8 | 2 | 0.67 | +51 | +25.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +22 | +10.9 |
| SHOTS AFTER THE MOVES | 12 | 12 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 53 | 45 | 2 | 0.67 | +12 | +6.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +6 | +2.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +12 | +12.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -86 | -85.9 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +21 | +20.6 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +43 | +42.9 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +114 | +114.5 |
| MISSILES IN THE MOVE | 20 | 13 | 1 | 0.33 | +2 | +1.8 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE FIGHT FORMULA | 39 | 18 | 1 | 0.33 | +3 | +3.4 |
| ONE OBJECTIVE FORMULA | 24 | 21 | 1 | 0.33 | +3 | +3.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -49 | -48.8 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -0.8 |
| REDIRECT COUNTER | 18 | 16 | 1 | 0.33 | +0 | +0.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +4 | +3.8 |
| SHOTS IN THE MOVE | 71 | 54 | 1 | 0.33 | +5 | +4.8 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +50 | +49.5 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -54 | -54.5 |
| SURE REACH TOGETHER | 5 | 4 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 11 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 88 | 87 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 15 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FIGHT TO THE END | 9 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 49 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 39 | 33 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 27 | 22 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 64 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 54 | 50 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 44 | 42 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 13 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 67 | 65 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 32 | 32 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 17 | 17 | 0 | 0.00 | - | - |
| HIS TURN RUN | 33 | 33 | 0 | 0.00 | - | - |
| HOLD ODDS | 73 | 72 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 24 | 23 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 19 | 18 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 15 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 33 | 33 | 0 | 0.00 | - | - |
| NO SECOND RUN | 16 | 16 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 230 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 9 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 11 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 37 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 38 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 121 | 117 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 227 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 6 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 21 | 19 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p33

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 5.00 | 39.7 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 3.33 | 76.6 |
| ARMY TABLE | rule | 0.67 | 2.67 | 48.0 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 42.2 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.67 | 50.4 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 3.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 3.7 |
| RULE SWITCHED OFF | gate | - | 0.67 | 19.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 60.0 |
| BEST PRIZE | rule | - | 0.33 | 85.9 |
| CHAFF PASSED | rule | 0.33 | - | 16.3 |
| FIGHT ORDER BAND | gate | 0.33 | - | 0.7 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 48.8 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 0.8 |
| SUPPORT NARROWED | rule | - | 0.33 | 54.5 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 4.7 |

### Plans: cnsr-c940641-p33

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 64% | 615 | 493 | 80% |
| Mine | move | 23.7 | 93% | 1426 | 0 | 0% |
| Mine | shoot | 5.7 | 35% | 324 | 190 | 59% |
| Opponent | charge | 3.7 | 73% | 407 | 324 | 80% |
| Opponent | join | 2.7 | 100% | 110 | 0 | 0% |
| Opponent | move | 32.7 | 96% | 1544 | 0 | 0% |
| Opponent | shoot | 3.0 | 0% | 248 | 0 | 0% |
| Opponent | support | 1.7 | 80% | 0 | 0 | - |

### Packages: hunt the guns, cnsr-c940641-p33

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.5 | 1 | 1 | - | - | - | - | - | - | - | 0 |

### Battle groups: cnsr-c940641-p33

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 50% | 0% | 0% | - | 0% | 0% | 100% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 5.3 | 12% | 50% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p33

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Character | 5 | 45 (5) | 45 | 0 | 48 | 0% | 2.6 | 70 (2) | 32 (3) | - | 53 (3) | 35 (2) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 3 | 40 (3) | 16 | 24 | 0 | 0% | 2.3 | - | 40 (3) | - | 128 (1) | 8 (2) |
| Mine | Hammer | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Mine | Shooter | 2 | 30 (2) | 0 | 30 | 100 | 0% | 2.0 | 71 (1) | 0 (1) | - | 71 (1) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 8 | 26 (8) | 20 | 6 | 24 | 50% | 4.5 | 9 (5) | 56 (3) | - | 9 (5) | 56 (3) |
| Opponent | Character | 7 | 50 (7) | 50 | 0 | 26 | 43% | 4.0 | 17 (2) | 105 (3) | 0 (1) | 115 (2) | 15 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 4 | 52 (4) | 36 | 16 | 0 | 25% | 3.3 | 47 (1) | 26 (1) | 81 (2) | 26 (1) | 64 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 4 | 34 (4) | 34 | 0 | 0 | 25% | 2.7 | 38 (3) | 0 (1) | - | 0 (2) | 68 (2) |

### Charged fights: cnsr-c940641-p33

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 125 | 99 | 5.0 | 1.0 | 20 | 119 | -100 | 1 of 5 | 4 of 5 | - | -100 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 415 | 4.0 | 1.5 | 104 | 69 | +34 | 3 of 4 | 4 of 4 | -138 | +208 |
| **Mine** | all armies | 2 | 62 | 257 | 4.5 | 1.2 | 57 | 97 | -40 | 4 of 9 | 8 of 9 | -138 | -12 |
| Opponent | Vampire Counts | 2 | 0 | 241 | 4.0 | 1.0 | 60 | 38 | +22 | 0 of 8 | 6 of 8 | - | +22 |

### Effective charges: cnsr-c940641-p33

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 5 | 0 | 0 | 1 (net +0) | 0 | 2 (net +50) | 1 (net +0) | 1 | 25% (1 of 4) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +268) | 0 | 0 | 1 (net +147) | 0 | 2 (net -138) | 0 | 0% (0 of 4) |
| Opponent | Vampire Counts | 8 | 1 (net +100) | 0 | 1 (net +0) | 3 (net -101) | 0 | 3 (net +127) | 0 | 12% (1 of 8) |

### Charged fights, damage counted: cnsr-c940641-p33

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 277 | 348 | +268 | 324 | 0 | +324 | +117.1 |
| Mine | Effective (55-75%) | 1 | 60 | 186 | +0 | 31 | 0 | +31 | +51.7 |
| Mine | 76-89% | 1 | 275 | 147 | +147 | 147 | 0 | +147 | +53.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 470 | 221 | -92 | 57 | 112 | -55 | -11.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 414 | 50 | +50 | 50 | 0 | +50 | +12.0 |
| Mine | No odds | 1 | 497 | 471 | -597 | 294 | 597 | -303 | -60.9 |
| Mine | All fights | 9 | 372 | 213 | -40 | 118 | 104 | +15 | +4.0 |
| Opponent | Long shot (under 50%) | 1 | 45 | 100 | +100 | 100 | 8 | +92 | +205.6 |
| Opponent | Effective (55-75%) | 1 | 186 | 199 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 3 | 101 | 160 | -101 | 0 | 101 | -101 | -100.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 147 | 127 | +127 | 127 | 1 | +127 | +86.4 |
| Opponent | All fights | 8 | 122 | 145 | +22 | 60 | 39 | +21 | +17.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p33 | move | 26 | 8 (31%) | 8 (31%) | 3 (12%) | 15 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

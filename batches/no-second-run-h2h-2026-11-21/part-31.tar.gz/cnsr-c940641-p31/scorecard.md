# Doctrine scorecard: cnsr-c940641-p31

### Scorecard: cnsr-c940641-p31

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 5 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 3 | - | 2 | 0 | 0 | 0 | 0 | 427 |
| L1131 | 3 | 1 | Opponent | yes | 3 | 5 | 1 | 2 | 0 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1224 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 4.0 | 2.0 | 1.0 | 0.0 | 0.0 | 0.0 | 0.0 | 378.5 |
| **Average** | | | Opponent | 50% | 1.5 | 4.0 | 1.0 | 1.0 | 0.0 | 0.0 | 0.0 | 85.0 |

### KPIs: cnsr-c940641-p31

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 45% (5 of 11) | 0% (0 of 14) | 20% (5 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 67% | 0% (0 of 1); on the table 0% | 25% (1 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 80% | 0% (0 of 2); on the table 0% | 43% (3 of 7); on the table 57% |
| Magic missiles tried each own turn | 50%+ | 26% (15 of 58) | 35% (6 of 17) | 28% (21 of 75) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (15 of 42) | 35% (6 of 17) | 36% (21 of 59) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 60% (6 of 10) | 60% (6 of 10) |
| Points that never fought | lower | 51% (2028 of 3998) | 53% (2103 of 4000) | 52% (4131 of 7998) |
|   infantry points that never fought | lower | 68% (365 of 536) | 57% (236 of 413) | 63% (601 of 949) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (10 of 16) | 62% (13 of 21) | 62% (23 of 37) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 7.7 uses a game | 100% (1 of 1); 1.0 uses a game | 88% (7 of 8); 4.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 50% (3 of 6); 2.0 uses a game | 50% (3 of 6); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (1954 of 3614) | 71% (2828 of 4000) | 63% (4782 of 7614) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.7 (19%) | 1.0 (27%) | 3.7 (20%) |
| MARCHED: its unit marched | 5.3 (37%) | 2.7 (73%) | 8.0 (44%) |
| CHARGED: its unit charged | 1.0 (7%) | 0.0 (0%) | 1.0 (6%) |
| IN COMBAT: engaged in combat | 4.0 (28%) | 0.0 (0%) | 4.0 (22%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (9%) | 0.0 (0%) | 1.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 5.0 | 2.3 | 7.0 | 0.7 | 0.3 |
| not cast | 1.3 | 6.0 | 1.3 | 18.0 | 6.7 | 30.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (78%) | 0.0 (0%) | 3.7 (20%) | 1.0 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.0 (44%) | 2.3 (35%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (6%) | 0.3 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (22%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) | 1.3 (20%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.3 (22%) | 0.0 (0%) | 0.0 (0%) | 1.7 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (100%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 29.7 (98%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.3 a game | 1.2 a game |
| stood (cast and not dispelled) | - | 29% (2 of 7) | 29% (2 of 7) |
| the unit moved after it | - | 50% (1 of 2) | 50% (1 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 50% (1 of 2) | 50% (1 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 50% (1 of 2) | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 89% (39 of 44) | 48% (10 of 21) | 75% (49 of 65) |
|   cavalry | - | 62% (5 of 8) | 62% (5 of 8) |
|   character | - | 0% (0 of 6) | 0% (0 of 6) |
|   chariot | 70% (7 of 10) | - | 70% (7 of 10) |
|   infantry | 100% (12 of 12) | 71% (5 of 7) | 89% (17 of 19) |
|   war machine | 91% (20 of 22) | - | 91% (20 of 22) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (60%) | 0.7 (18%) | 1.7 (31%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (9%) | 0.3 (6%) |
| MOVED: a war machine that moved | 0.3 (20%) | 0.0 (0%) | 0.3 (6%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.0 (27%) | 1.0 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.0 (27%) | 1.0 (19%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (18%) | 0.7 (12%) |
| SHELTERED: the target was sheltered | 0.3 (20%) | 0.0 (0%) | 0.3 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.3 | 0.7 | 71% | 12.4 pts | 29 pts |
| infantry | 11.3 | 2.3 | 88% | 10.5 pts | 118 pts |
| war machine | 7.3 | 3.7 | 73% | 22.0 pts | 162 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 2.0 | 2.2 |
| Charges that made contact a game | 1.7 | 1.7 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.71 declared, 0.43 contact (7 units) | 0.00 declared, 0.00 contact (3 units) | 0.50 declared, 0.30 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.17 declared, 0.17 contact (12 units) | 0.29 declared, 0.24 contact (21 units) | 0.24 declared, 0.21 contact (33 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (4 of 8) | 0% (0 of 1) | 0% (0 of 2) | 36% (4 of 11) |
| Character in a unit | 100% (1 of 1) | - | 100% (1 of 1) | 100% (2 of 2) |
| Character on its own | 60% (3 of 5) | 50% (1 of 2) | 75% (3 of 4) | 64% (7 of 11) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 100% (4 of 4) | - | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 2 | 60% (3 of 5); on the table 80% | 24% (10 of 42) | 51% | 62% (10 of 16) | 100% (4 of 4); 9.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 1 | 0% (0 of 1); on the table 0% | 17% (1 of 6) | 69% | 67% (6 of 9) | 0.0 uses a game | 50% (3 of 6); 6.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 1); on the table 0% | 50% (3 of 6) | 36% | 58% (7 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p31, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 75% (3) | 62% (5) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: cnsr-c940641-p31

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 67% (4 of 6) | 67% (4 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 53% (24 of 45) | 20% (1 of 5) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | - |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 100% (1 of 1) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.0 | 1.0 |
| Movement | Points that never moved of their own | 378.5 | 85.0 |
| Movement | Fights charged into per game | 2.0 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +0 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 1 of 4, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +210 | 1 of 4, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.3 | 5.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (11 of 19) | 75% (12 of 16) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (10 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 4.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 17% (2 of 12) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 1.7 | 1.3 |
| Magic | Wounds caused by other spells | 1.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 41.0 | 98.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 2.0 / 0.3 / 0.7 | 1.0 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 104.3 | 105.0 |
| Combat | Points run down | 83.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +175 | +61 |
| Combat | Net per 100 charger points, damage counted | +52.7 | +45.3 |
| Combat | First round won (charged fights) | 100% | 60% |
| Combat | Net points per charged fight | +141 | +63 |
| Combat | Net points per supported fight / lone fight | - / +141 | - / +63 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 4 | 2 of 5 |
| Game | Points lost | 454.5 | 318.5 |
| Game | VP from objectives | 645.0 | 675.0 |
| Game | Lone holders (player turns) | 4.0 | 1.5 |

- Mine won / drew / lost: 0 / 1 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -206 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 773
- Games not ended: 1 (L1224-1); findings 3, warnings 0

### Opponent rules: cnsr-c940641-p31

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 8.3 | +131.4 | 0.0 | 77.7 | 31.7 | -256.9 | 0.0 | 83.7 |
| ARTILLERY RE-ROLL WEIGHED | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 9.3 | +383.1 | 41.0 | 165.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.7 | +134.7 | 47.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +178.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +7.3 | 0.0 | 0.0 | 0.3 | +3.7 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 1.0 | -91.1 | 0.0 | 0.0 |
| CHARGE LOSSES | 10.3 | -562.1 | 0.0 | 77.7 | 30.0 | -1508.1 | 0.0 | 83.7 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 83.7 | 0.0 | 0.7 | +0.0 | 50.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.0 | +0.0 | 0.0 | 50.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 2.3 | +525.8 | 0.0 | 0.0 |
| COVER ONCE | 10.0 | -604.5 | 0.0 | 55.0 | 9.3 | -573.5 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -4.5 | 83.7 | 0.0 | 0.3 | -7.5 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -45.9 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +1.5 | 0.0 | 0.0 | 0.7 | +16.7 | 0.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +5.1 | 83.7 | 0.0 | 1.0 | +12.3 | 50.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 25.7 | +247.8 | 0.0 | 124.7 |
| FIGHT TO THE END | 1.7 | +26.4 | 83.7 | 0.0 | 0.3 | +19.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 73.7 | +6242.9 | 377.3 | 585.3 | 85.0 | +5232.2 | 205.3 | 362.7 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 127.7 | 10.7 | +0.0 | 0.0 | 83.7 |
| FOLLOW UP WEIGHED | 1.3 | +322.5 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.3 | +307.9 | 83.7 | 0.0 | 2.0 | +233.6 | 50.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 77.7 | 17.3 | +0.0 | 0.0 | 138.7 |
| FRIEND SHOOTS FIRST | 2.7 | -33.4 | 0.0 | 0.0 | 0.7 | -0.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +24.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -37.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 2.0 | +129.4 | 0.0 | 0.0 | 12.3 | +1834.8 | 0.0 | 0.0 |
| GUN MASK | 2.7 | +104.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 77.7 | 16.0 | +0.0 | 0.0 | 138.7 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 0.0 | 17.7 | +0.0 | 0.0 | 83.7 |
| HIS CHARGE DENIED | 0.3 | +9.1 | 83.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 165.7 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -30.9 | 0.0 | 0.0 | 12.0 | -161.8 | 0.0 | 83.7 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 205.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 14.3 | +74.9 | 0.0 | 0.0 | 71.3 | +4865.2 | 0.0 | 279.0 |
| HIS SHOTS BY HIS RUN | 22.7 | +169.2 | 0.0 | 255.3 | 62.0 | +2207.5 | 0.0 | 362.7 |
| HIS TURN DENIED | 0.3 | +4.9 | 0.0 | 0.0 | 0.7 | +24.5 | 50.0 | 0.0 |
| HIS TURN RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.0 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 165.7 |
| HOLDER ASSIGNMENT | 9.3 | +782.6 | 0.0 | 0.0 | 9.0 | +912.0 | 0.0 | 124.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -83.1 | 83.7 | 0.0 | 1.3 | -9.7 | 0.0 | 0.0 |
| HUNT IN PAIRS | 1.7 | +28.1 | 0.0 | 0.0 | 0.7 | +27.9 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +76.7 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 17.0 | -280.7 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | -1.8 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -3.3 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 95.3 | 0.0 | 6.0 | +0.0 | 0.0 | 124.7 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | +6.2 | 83.7 | 0.0 | 1.7 | -1.1 | 50.0 | 0.0 |
| LOST CHARGE | 0.3 | -3.1 | 0.0 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +1.1 | 0.0 | 0.0 | 1.7 | -41.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 2.0 | +88.8 | 0.0 | 0.0 | 0.7 | +64.7 | 0.0 | 0.0 |
| MARCH CHECK | 3.0 | +133.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 2.3 | +106.9 | 0.0 | 0.0 | 1.0 | +7.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 3.7 | -18.8 | 0.0 | 77.7 | 2.7 | +199.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +147.2 | 0.0 | 0.0 | 5.0 | +114.3 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 8.0 | +215.3 | 0.0 | 0.0 | 3.3 | +18.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 13.7 | +223.2 | 0.0 | 77.7 | 6.7 | +32.2 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.7 | -40.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 4.3 | +0.0 | 83.7 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.7 | +912.1 | 0.0 | 50.0 | 13.3 | +1012.6 | 0.0 | 83.7 |
| NEARER NOT NEEDED | 4.7 | +177.7 | 0.0 | 0.0 | 6.0 | +216.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.3 | +576.8 | 0.0 | 50.0 | 7.3 | +453.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -63.5 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.0 | -100.8 | 83.7 | 0.0 | 2.0 | -85.5 | 50.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.7 | +38.6 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.3 | -299.3 | 0.0 | 0.0 | 7.0 | -555.9 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 7.7 | +109.2 | 41.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 8.0 | -182.6 | 0.0 | 50.0 | 10.0 | -227.9 | 0.0 | 83.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -5.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -124.6 | 0.0 | 0.0 | 3.7 | -67.7 | 0.0 | 41.0 |
| ONE PROMISE A TARGET | 1.0 | -98.2 | 0.0 | 0.0 | 3.0 | -92.1 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +9.2 | 50.0 | 0.0 |
| OWN CAST FIRST | 0.7 | -5.3 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.7 | +19.8 | 0.0 | 0.0 |
| PLAN RESULT | 31.3 | +437.0 | 249.3 | 475.3 | 40.0 | +81.8 | 245.0 | 362.7 |
| PROMISE BY ITS OWN SUM | 13.7 | -454.6 | 0.0 | 0.0 | 11.3 | -419.3 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | -11.7 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.0 | -83.0 | 0.0 | 0.0 | 0.3 | -36.8 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 1.3 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.0 | +2281.2 | 47.7 | 220.0 | 16.7 | +2470.9 | 50.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +70.4 | 0.0 | 113.3 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +79.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +24.8 | 55.0 | 0.0 |
| REFORMS TO MEET IT | 4.3 | -242.3 | 0.0 | 50.0 | 1.3 | -18.4 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +6.5 | 83.7 | 0.0 | 1.7 | -86.2 | 50.0 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | 1.3 | -37.9 | 83.7 | 0.0 | 2.0 | -27.5 | 50.0 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +13.8 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | +86.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +8.2 | 0.0 | 0.0 | 0.7 | +47.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -11.8 | 0.0 | 0.0 | 3.3 | -146.2 | 0.0 | 41.0 |
| SET UP BY THE SET | 3.0 | +60.4 | 47.7 | 0.0 | 7.0 | +333.6 | 0.0 | 82.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +55.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -2.2 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.7 | +0.0 | 0.0 | 165.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +244.2 | 164.0 | 0.0 | 1.3 | +106.3 | 155.3 | 0.0 |
| SHOT RISK POINTS | 9.0 | -101.7 | 0.0 | 155.3 | 51.7 | +860.3 | 0.0 | 165.7 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +922.5 | 0.0 | 215.0 | 4.3 | +79.1 | 0.0 | 41.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.7 | +130.7 | 0.0 | 0.0 |
| SPELL WORTH | - | - | - | - | 1.7 | +43.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -4.5 | 0.0 | 0.0 | 0.3 | +17.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 124.7 |
| STAND AND SHOOT | 0.3 | -10.4 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 37.0 | +0.0 | 293.7 | 330.0 | 21.3 | +0.0 | 155.3 | 197.0 |
| STAY WORTH | 29.7 | -280.7 | 82.0 | 330.0 | 4.7 | -58.5 | 0.0 | 41.0 |
| STOPS | - | - | - | - | 0.3 | +17.7 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +256.5 | 0.0 | 77.7 | 2.3 | +143.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 50.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +256.5 | 0.0 | 77.7 | 2.3 | +143.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +7.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | -8.8 | 0.0 | 77.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -76.1 | 0.0 | 0.0 | 0.3 | -36.8 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.0 | +0.0 | 0.0 | 292.7 | 42.0 | +0.0 | 0.0 | 124.7 |
| TIED UP BY THE SUM | 0.7 | +80.3 | 83.7 | 0.0 | 0.3 | +16.3 | 50.0 | 0.0 |
| TIME ON OUR SIDE | 26.0 | +456.4 | 0.0 | 127.7 | - | - | - | - |
| WAITS AGAIN | 5.3 | +0.0 | 0.0 | 50.0 | 0.7 | +0.0 | 0.0 | 83.7 |
| WHO FIGHTS | 0.3 | -0.7 | 0.0 | 0.0 | 0.3 | -2.3 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +26.0 | 0.0 | 0.0 | 0.7 | +45.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -424.7 | 0.0 | 0.0 | 3.0 | -219.8 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +42.3 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.7 | +9.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p31

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 120 | 120 | 66 | 22.00 | +681 | +10.3 |
| HIS SHOT LIST | 257 | 244 | 56 | 18.67 | +2365 | +42.2 |
| HIS SHOTS BY HIS RUN | 254 | 241 | 50 | 16.67 | +856 | +17.1 |
| HOLDER ASSIGNMENT | 55 | 55 | 49 | 16.33 | +3848 | +78.5 |
| FIVE ACTION | 476 | 452 | 48 | 16.00 | +3939 | +82.1 |
| OFF BEST | 43 | 43 | 43 | 14.33 | -2565 | -59.7 |
| PROMISE BY ITS OWN SUM | 75 | 75 | 32 | 10.67 | -2622 | -81.9 |
| MOVE TO CHARGE COMPUTED | 63 | 58 | 30 | 10.00 | +1391 | +46.4 |
| SHOT RISK POINTS | 182 | 171 | 29 | 9.67 | +1188 | +41.0 |
| THE TABLE AGAIN | 33 | 33 | 28 | 9.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| QUARTER ODDS | 98 | 95 | 24 | 8.00 | +3392 | +141.3 |
| OGRE LOADER SECOND SHOT | 23 | 23 | 23 | 7.67 | +328 | +14.3 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| NEXT CHARGE BY LIST | 35 | 34 | 17 | 5.67 | +1011 | +59.5 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| GOAL WALK | 43 | 43 | 14 | 4.67 | +2400 | +171.5 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| ONE PROMISE A TARGET | 12 | 12 | 12 | 4.00 | -571 | -47.6 |
| SET UP BY THE SET | 30 | 30 | 11 | 3.67 | +582 | +52.9 |
| CHARGE LOSSES | 121 | 114 | 10 | 3.33 | +1251 | +125.1 |
| MARCH OF THE TABLE | 10 | 10 | 10 | 3.33 | -344 | -34.4 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 9 | 3.00 | +77 | +8.6 |
| MARCH BY THE SUM | 8 | 8 | 8 | 2.67 | +460 | +57.5 |
| THE RISK READS HIS RUN | 17 | 17 | 8 | 2.67 | +0 | +0.0 |
| COVER ONCE | 58 | 36 | 7 | 2.33 | +264 | +37.7 |
| FOUR ROUNDS | 13 | 12 | 7 | 2.33 | +528 | +75.4 |
| SHOTS AFTER THE MOVES | 20 | 20 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 6 | 2.00 | +211 | +35.2 |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 16 | 15 | 6 | 2.00 | +1091 | +181.8 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CAST JOB | 11 | 11 | 5 | 1.67 | +81 | +16.2 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| MARCH CHECK | 9 | 8 | 5 | 1.67 | +120 | +24.0 |
| SUPPORT ADDS | 13 | 13 | 5 | 1.67 | +226 | +45.2 |
| SUPPORT WORKED OUT | 13 | 13 | 5 | 1.67 | +226 | +45.2 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +967 | +241.8 |
| IDLE COST | 51 | 37 | 4 | 1.33 | +8 | +2.1 |
| PROMISE SHOT AWAY | 4 | 4 | 4 | 1.33 | -12 | -2.9 |
| CANNON PLANNED TARGET | 28 | 28 | 3 | 1.00 | -157 | -52.3 |
| CHAFF IN THE MOVE | 7 | 7 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +33 | +11.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -5 | -1.7 |
| MANOEUVRE | 7 | 7 | 3 | 1.00 | +19 | +6.5 |
| MAX FOR POSITIONING | 31 | 26 | 3 | 1.00 | +24 | +8.0 |
| TIME ON OUR SIDE | 78 | 54 | 3 | 1.00 | +48 | +15.9 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +217 | +72.4 |
| FALLS SHORT | 77 | 66 | 2 | 0.67 | +16 | +7.9 |
| GUN MASK | 8 | 8 | 2 | 0.67 | +83 | +41.3 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MISSILES IN THE MOVE | 34 | 25 | 2 | 0.67 | +22 | +11.1 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -16 | -7.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +59 | +29.7 |
| PROMISE KNOWS THE FIGHT | 24 | 23 | 2 | 0.67 | -35 | -17.6 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -13 | -6.7 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +168 | +84.1 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +99 | +49.6 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +21 | +21.3 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -20 | -19.7 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 6 | 5 | 1 | 0.33 | +24 | +24.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +73 | +73.1 |
| HIS MOVE AND SHOT | 44 | 42 | 1 | 0.33 | +52 | +52.3 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +8 | +7.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +3 | +3.3 |
| MISSILES NEXT TURN | 61 | 37 | 1 | 0.33 | +13 | +12.8 |
| NEARER NOT NEEDED | 32 | 31 | 1 | 0.33 | +23 | +23.3 |
| ONE OBJECTIVE FORMULA | 24 | 17 | 1 | 0.33 | +76 | +76.0 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +8 | +7.8 |
| REDIRECT COUNTER | 5 | 5 | 1 | 0.33 | +42 | +41.6 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +188 | +187.9 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +41 | +41.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +18 | +18.5 |
| STAY WORTH | 103 | 91 | 1 | 0.33 | +4 | +4.1 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -37 | -37.0 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +2 | +1.8 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -26 | -26.3 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +115 | +114.7 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 41 | 41 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 55 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 57 | 55 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 10 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 50 | 49 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 77 | 71 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 30 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 30 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 35 | 34 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 32 | 32 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 17 | 17 | 0 | 0.00 | - | - |
| HIS TURN RUN | 33 | 33 | 0 | 0.00 | - | - |
| HOLD ODDS | 76 | 76 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 7 | 2 | 0 | 0.00 | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 10 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 19 | 19 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 5 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 11 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 33 | 33 | 0 | 0.00 | - | - |
| NO SECOND RUN | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 54 | 31 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 214 | trace | - | - | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 7 | 7 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 17 | 17 | 0 | 0.00 | - | - |
| RISK BY ARC | 11 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 13 | 13 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 57 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 62 | 42 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 40 | 35 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 175 | 164 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 9 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 231 | not checked | - | - | - | - |
| WAITS AGAIN | 18 | 16 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p31

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.00 | 6.67 | 54.8 |
| PROMISE BY ITS OWN SUM | rule | 6.67 | 4.00 | 81.9 |
| ARMY TABLE | rule | 1.33 | 3.00 | 91.0 |
| ONE PROMISE A TARGET | rule | 1.00 | 3.00 | 47.6 |
| MARCH OF THE TABLE | rule | 2.00 | 1.00 | 38.2 |
| PROMISE SHOT AWAY | rule | 1.33 | - | 2.9 |
| JOINT CHARGE NOW | rule | - | 0.67 | 29.0 |
| OWN CAST FIRST | rule | 0.67 | - | 7.9 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 17.6 |
| REFUSING RETIRES | rule | - | 0.67 | 6.7 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 156.9 |
| CHARGE NOW FIRST | rule | - | 0.33 | 19.7 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 9.0 |
| NO REASON | gate | 0.33 | - | 243.6 |
| RULE SWITCHED OFF | gate | - | 0.33 | 75.7 |
| SUPPORT NARROWED | rule | - | 0.33 | 37.0 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 26.3 |

### Plans: cnsr-c940641-p31

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 67% | 168 | 161 | 96% |
| Mine | move | 16.7 | 96% | 1193 | 0 | 0% |
| Mine | shoot | 12.7 | 24% | 963 | 276 | 29% |
| Opponent | charge | 1.0 | 67% | 142 | 82 | 57% |
| Opponent | join | 1.3 | 100% | 82 | 0 | 0% |
| Opponent | move | 35.7 | 96% | 2283 | 0 | 0% |
| Opponent | shoot | 1.0 | 0% | 4 | 0 | 0% |
| Opponent | support | 1.0 | 100% | 100 | 0 | 0% |

### Packages: hunt the guns, cnsr-c940641-p31

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 1.0 | 1 | 1 | - | - | - | - | - | - | - | 0 |

### Battle groups: cnsr-c940641-p31

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p31

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 5 | 13 (5) | 13 | 0 | 27 | 20% | 2.8 | 44 (2) | 0 (2) | - | 0 (2) | 33 (2) |
| Mine | Clean-up | 1 | 72 (1) | 72 | 0 | 0 | 0% | 3.0 | 72 (1) | - | - | 72 (1) | - |
| Mine | Fast Hammer | 4 | 18 (4) | 0 | 18 | 15 | 25% | 2.7 | 0 (2) | 25 (2) | - | 14 (3) | 25 (1) |
| Mine | Holder | 1 | 140 (1) | 0 | 140 | 0 | 0% | 1.0 | 140 (1) | - | - | 140 (1) | - |
| Mine | Shooter | 2 | 139 (2) | 0 | 139 | 0 | 0% | 1.0 | 0 (1) | 278 (1) | - | 139 (2) | - |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 50 | 0% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (1) | 0 (3) |
| Mine | Wizard | 3 | 60 (3) | 60 | 0 | 33 | 0% | 3.3 | 0 (2) | 114 (1) | - | 60 (3) | - |
| Opponent | Character | 6 | 18 (6) | 18 | 0 | 0 | 17% | 4.2 | 16 (3) | 21 (3) | - | 17 (3) | 20 (3) |
| Opponent | Fast Hammer | 7 | 55 (7) | 29 | 26 | 50 | 14% | 2.7 | 108 (2) | 33 (5) | - | 77 (4) | 30 (3) |
| Opponent | Hammer | 3 | 51 (3) | 51 | 0 | 37 | 33% | 3.5 | 0 (2) | 137 (1) | - | 0 (2) | 137 (1) |
| Opponent | Holder | 3 | 44 (3) | 0 | 44 | 0 | 33% | 6.0 | 125 (1) | - | 0 (2) | 0 (1) | 68 (2) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cnsr-c940641-p31

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 62 | 282 | 2.0 | 1.0 | 141 | 0 | +141 | 2 of 4 | 4 of 4 | - | +141 |
| Opponent | High Elf Realms | 1 | 296 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 315 | 3.0 | 1.0 | 105 | 0 | +105 | 0 of 3 | 2 of 3 | - | +105 |
| **Opponent** | all armies | 2 | 148 | 158 | 2.5 | 1.0 | 63 | 0 | +63 | 2 of 5 | 3 of 5 | - | +63 |

### Effective charges: cnsr-c940641-p31

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 4 | 1 (net +0) | 0 | 0 | 1 (net +143) | 0 | 2 (net +210) | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Warriors of Chaos | 3 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net +150) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: cnsr-c940641-p31

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 369 | 144 | +0 | 235 | 105 | +130 | +35.2 |
| Mine | 76-89% | 1 | 233 | 143 | +143 | 143 | 0 | +143 | +61.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 364 | 189 | +210 | 255 | 41 | +214 | +58.7 |
| Mine | All fights | 4 | 332 | 166 | +141 | 222 | 47 | +175 | +52.7 |
| Opponent | 50-54% | 1 | 144 | 171 | +0 | 21 | 82 | -61 | -42.3 |
| Opponent | Effective (55-75%) | 1 | 143 | 358 | +0 | 179 | 0 | +179 | +125.2 |
| Opponent | 76-89% | 1 | 151 | 358 | +0 | 0 | 91 | -91 | -60.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 116 | 150 | +150 | 150 | 39 | +111 | +96.0 |
| Opponent | No odds | 1 | 116 | 165 | +165 | 165 | 0 | +165 | +142.2 |
| Opponent | All fights | 5 | 134 | 240 | +63 | 103 | 42 | +61 | +45.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p31 | move | 39 | 4 (10%) | 3 (8%) | 1 (3%) | 34 (87%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

# Doctrine scorecard: cnsr-c940641-p11

### Scorecard: cnsr-c940641-p11

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 555 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 4 | 6 | 2 | 0 | 0 | 0 | 72 |
| L2231 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 4 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 114 |
| **Average** | | | Mine | 33% | 1.0 | 3.0 | 2.7 | 2.3 | 0.0 | 0.0 | 0.0 | 209.0 |
| **Average** | | | Opponent | 33% | 0.0 | 2.0 | 3.0 | 2.0 | 1.3 | 0.0 | 0.0 | 94.7 |

### KPIs: cnsr-c940641-p11

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 15% (2 of 13) | 0% (0 of 14) | 7% (2 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (7 of 7); on the table 100% | 100% (11 of 11); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 25% | 0% (0 of 2); on the table 50% | 17% (1 of 6); on the table 33% |
| Winner chose to follow up or pursue (all three) |  | 62% (5 of 8); on the table 62% | 78% (7 of 9); on the table 89% | 71% (12 of 17); on the table 76% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 6) | 33% (6 of 18) | 25% (6 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 3) | 33% (6 of 18) | 29% (6 of 21) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 38% (3 of 8) | 70% (7 of 10) | 56% (10 of 18) |
| Points that never fought | lower | 55% (3278 of 5999) | 38% (2303 of 6000) | 47% (5581 of 11999) |
|   infantry points that never fought | lower | 96% (1497 of 1552) | 57% (590 of 1035) | 81% (2087 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (14 of 19) | 70% (21 of 30) | 71% (35 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 50% (1 of 2); 0.7 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (2852 of 4484) | 60% (3306 of 5546) | 61% (6158 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (50%) | 2.0 (33%) |
| MARCHED: its unit marched | 1.0 (50%) | 1.3 (33%) | 2.3 (39%) |
| GONE: slain | 1.0 (50%) | 0.0 (0%) | 1.0 (17%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.7 (17%) | 0.7 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 11.0 | 1.0 | 1.7 | 2.0 | 1.0 | 0.3 |
| not cast | 3.0 | 1.0 | 0.3 | 6.0 | 1.0 | 15.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (100%) | 0.3 (100%) | 2.0 (33%) | 0.3 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (39%) | 0.3 (33%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 1.0 (17%) | 0.0 (0%) | 2.3 (15%) |
| STUPIDITY: Stupidity | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (56%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.7 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 40% (2 of 5) | 40% (2 of 5) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (80 of 109) | 69% (20 of 29) | 72% (100 of 138) |
|   cavalry | 94% (17 of 18) | 79% (11 of 14) | 88% (28 of 32) |
|   character | 0% (0 of 15) | 25% (1 of 4) | 5% (1 of 19) |
|   chariot | 92% (11 of 12) | - | 92% (11 of 12) |
|   infantry | 81% (52 of 64) | 73% (8 of 11) | 80% (60 of 75) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 1.0 (33%) | 1.0 (8%) |
| CHARGED: it charged | 2.7 (28%) | 1.0 (33%) | 3.7 (29%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.3 (11%) | 0.7 (5%) |
| NO TARGET IN RANGE | 5.0 (52%) | 0.3 (11%) | 5.3 (42%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (14%) | 0.0 (0%) | 1.3 (11%) |
| OTHER BAR | 0.0 (0%) | 0.3 (11%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.7 | 1.0 | 95% | 1.6 pts | 22 pts |
| character | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.7 | 1.3 | 64% | 5.9 pts | 22 pts |
| infantry | 22.7 | 6.3 | 78% | 6.1 pts | 138 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.3 | 3.7 |
| Charges that made contact a game | 1.7 | 2.7 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.50 contact (2 units) | 1.00 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.28 declared, 0.16 contact (32 units) | 0.50 declared, 0.32 contact (22 units) | 0.37 declared, 0.22 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 100% (1 of 1) | 0% (0 of 1) | 56% (5 of 9) |
| Character in a unit | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Character on its own | 100% (5 of 5) | - | 38% (3 of 8) | 62% (8 of 13) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 73% (8 of 11) | 100% (1 of 1) | - | 75% (9 of 12) |
| Monster | 83% (5 of 6) | 100% (1 of 1) | - | 86% (6 of 7) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 55% | 89% (8 of 9) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 50% (3 of 6); on the table 50% | - | 54% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 75% (6 of 8); on the table 88% | 33% (2 of 6) | 39% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 0% (0 of 6) | 26% | 92% (11 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 50% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p11, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (4) | 33% (1) | 56% (5) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnsr-c940641-p11

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 38% (3 of 8) | 27% (3 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 54% (14 of 26) | 67% (6 of 9) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 70% (7 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.3 | 2.0 |
| Movement | Points that never moved of their own | 209.0 | 94.7 |
| Movement | Fights charged into per game | 1.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 1 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 5, net +126 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 5 | 5 of 6, net +215 |
| Shooting | Shots by shooting units (incl. breath weapons) | 30.0 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 26% (23 of 90) | 36% (8 of 22) |
| Shooting | Points destroyed by shooting units | 0.0 | 70.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 5) |
| Magic | Wounds caused by magic missiles | 0.7 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.3 / 0.0 / 0.0 / 0.0 | 2.3 / 0.7 / 0.3 / 0.7 |
| Combat | Points destroyed in combat | 287.3 | 352.3 |
| Combat | Points run down | 226.0 | 48.3 |
| Combat | Net points per charged fight, damage counted | +347 | +127 |
| Combat | Net per 100 charger points, damage counted | +97.2 | +47.7 |
| Combat | First round won (charged fights) | 80% | 75% |
| Combat | Net points per charged fight | +373 | +141 |
| Combat | Net points per supported fight / lone fight | - / +373 | - / +141 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 5 of 8 |
| Game | Points lost | 437.7 | 591.0 |
| Game | VP from objectives | 933.3 | 653.3 |
| Game | Lone holders (player turns) | 1.0 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +480 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1029
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p11

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 34.0 | +367.5 | 0.0 | 222.0 | 27.0 | -332.4 | 0.0 | 96.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| BEST OVERALL | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +13.1 | 0.0 | 0.0 | 2.3 | +5.8 | 24.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +10.1 | 0.0 | 22.0 | 0.3 | +3.7 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +23.3 | 0.0 | 41.7 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.3 | -125.6 | 0.0 | 733.3 | 24.0 | -827.3 | 0.0 | 264.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 168.3 | 0.0 | 2.7 | +0.0 | 424.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 12.3 | +0.0 | 0.0 | 408.3 | 16.3 | +0.0 | 0.0 | 56.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 48.3 | 0.3 | +0.0 | 0.0 | 56.7 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +201.0 | 0.0 | 0.0 |
| COVER ONCE | 8.3 | -461.8 | 0.0 | 310.0 | 12.0 | -602.9 | 0.0 | 210.0 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -2.4 | 46.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -0.8 | 41.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 4.0 | +442.6 | 0.0 | 41.7 |
| EXACT ROUND | 1.3 | +3.3 | 38.0 | 0.0 | 2.0 | +6.7 | 66.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +1.8 | 172.0 | 0.0 | 3.0 | +0.0 | 263.3 | 0.0 |
| FALLS SHORT | 1.7 | +14.6 | 0.0 | 0.0 | 22.0 | +238.4 | 0.0 | 66.7 |
| FEATURE BUFFS | 1.0 | +4.2 | 0.0 | 0.0 | 1.3 | +55.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +21.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 65.0 | 0.0 |
| FIVE ACTION | 116.3 | +9421.5 | 501.0 | 1557.7 | 89.7 | +4662.9 | 532.7 | 708.7 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 490.0 | 11.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +242.3 | 0.0 | 48.3 | 1.7 | +392.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +254.8 | 258.0 | 0.0 | 4.0 | +343.5 | 376.7 | 0.0 |
| FREED FROM HIS FIGHT | 6.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 167.3 |
| FRIEND SHOOTS FIRST | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -3.3 | 0.0 | 0.0 |
| GOAL WALK | 13.0 | +1583.2 | 0.0 | 490.0 | 8.3 | +351.3 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 620.0 | 17.0 | +0.0 | 0.0 | 224.0 |
| HIS CHARGE DENIED | 0.3 | +10.6 | 41.7 | 0.0 | 0.3 | +30.5 | 65.0 | 0.0 |
| HIS CHARGE LIST | 7.0 | +0.0 | 0.0 | 109.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 440.0 | 7.7 | +0.0 | 0.0 | 38.0 |
| HIS MOVE AND SHOT | 4.7 | -39.8 | 0.0 | 130.0 | 3.7 | -55.4 | 0.0 | 0.0 |
| HIS ONE QUARTER | 8.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 96.0 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 635.0 | 11.0 | +0.0 | 0.0 | 38.0 |
| HIS RANDOM MOVE | 17.0 | +0.0 | 0.0 | 48.0 | 6.0 | +0.0 | 0.0 | 40.0 |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 48.0 | 1.7 | +0.0 | 0.0 | 40.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 50.7 | +880.1 | 0.0 | 287.0 | 52.0 | +1307.5 | 0.0 | 422.7 |
| HIS SHOTS BY HIS RUN | 37.3 | +564.6 | 0.0 | 656.0 | 61.7 | +1110.4 | 0.0 | 615.3 |
| HIS TURN DENIED | 0.3 | +19.6 | 46.7 | 0.0 | 0.7 | +3.0 | 48.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 21.0 | +0.0 | 0.0 | 0.0 | 15.0 | +0.0 | 0.0 | 192.0 |
| HOLDER ASSIGNMENT | 13.3 | +1069.0 | 0.0 | 0.0 | 9.7 | +949.8 | 0.0 | 142.7 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -108.5 | 258.0 | 0.0 | 4.0 | -89.5 | 376.7 | 0.0 |
| HUNT IN PAIRS | 0.7 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 2.0 | -38.9 | 0.0 | 65.0 | 17.3 | -158.4 | 0.0 | 41.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +2.7 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 10.0 | +0.0 | 172.0 | 218.3 | 4.7 | +0.0 | 220.3 | 219.7 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +1.3 | 83.7 | 0.0 | 1.7 | +10.1 | 66.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +1.7 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -1.3 | 0.0 | 0.0 | 2.0 | -6.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +1.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +24.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -32.3 | 0.0 | 180.0 | 1.0 | +485.4 | 0.0 | 83.7 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +3.5 | 0.0 | 180.0 | 0.3 | +4.2 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +42.1 | 0.0 | 0.0 | 4.7 | +70.9 | 0.0 | 20.0 |
| MISSILES NEXT TURN | 2.7 | +31.6 | 0.0 | 360.0 | 6.7 | +52.8 | 0.0 | 103.7 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 83.7 | 41.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -16.7 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.0 | +1693.5 | 0.0 | 325.0 | 8.0 | +420.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 14.0 | +511.9 | 0.0 | 24.0 | 7.0 | +276.9 | 0.0 | 104.7 |
| NEXT CHARGE BY LIST | 5.7 | +1383.5 | 0.0 | 195.0 | 6.0 | +388.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -96.0 | 210.0 | 0.0 | 3.0 | -250.2 | 376.7 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.3 | -233.2 | 0.0 | 105.3 | 7.0 | -191.5 | 0.0 | 83.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -131.5 | 0.0 | 195.0 | 6.7 | -107.3 | 0.0 | 125.3 |
| ONE OBJECTIVE FORMULA | 6.3 | -19.5 | 0.0 | 0.0 | 4.0 | +26.8 | 0.0 | 94.7 |
| ONE PROMISE A TARGET | 0.3 | -100.8 | 0.0 | 65.0 | 2.7 | -57.9 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 1.3 | +9.3 | 88.0 | 93.3 |
| OPENS UP | 0.7 | +52.3 | 38.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 1.3 | +12.1 | 131.7 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| PLAN RESULT | 51.7 | +307.1 | 163.3 | 780.3 | 46.3 | +414.0 | 295.7 | 696.3 |
| PROMISE BY ITS OWN SUM | 10.3 | -479.0 | 0.0 | 130.0 | 5.7 | -62.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.0 | -4.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 30.3 | +2865.9 | 89.7 | 178.3 | 27.3 | +2527.1 | 113.3 | 192.0 |
| RANDOM MOVE BY FIGURES | 2.7 | +75.9 | 0.0 | 145.0 | 3.3 | +118.9 | 0.0 | 56.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.7 | +157.0 | 0.0 | 86.3 | 1.0 | +17.7 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 7.7 | +0.0 | 0.0 | 64.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.3 | -60.5 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +6.2 | 0.0 | 24.0 | 0.3 | +3.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | -21.8 | 168.3 | 0.0 | 2.7 | -42.6 | 376.7 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.7 | -34.0 | 216.3 | 0.0 | 1.0 | -8.3 | 0.0 | 0.0 |
| RUN DOWN | 2.3 | -85.4 | 258.0 | 0.0 | 2.0 | -15.2 | 66.7 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +13.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +25.1 | 0.0 | 0.0 | 0.3 | +9.2 | 18.3 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -31.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +48.3 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.3 | +0.0 | 0.0 | 180.0 | 5.0 | +0.0 | 0.0 | 46.7 |
| SHOOTS FROM THE BEST SPOT | 5.3 | +119.4 | 159.3 | 360.0 | - | - | - | - |
| SHOT RISK POINTS | 28.0 | -106.7 | 0.0 | 482.3 | 33.3 | -351.0 | 0.0 | 20.0 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 28.0 | +481.1 | 0.0 | 68.0 | 6.0 | +162.7 | 0.0 | 84.7 |
| SPELL WORTH | 0.7 | +22.3 | 360.0 | 360.0 | 3.7 | +5.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 9.3 | +0.0 | 0.0 | 423.3 | 11.0 | +0.0 | 0.0 | 258.7 |
| STAND AND SHOOT | 0.3 | -2.5 | 38.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 55.7 | +0.0 | 243.0 | 585.3 | 26.3 | +0.0 | 156.0 | 361.3 |
| STAY WORTH | 23.7 | +103.7 | 83.7 | 0.0 | 6.7 | +96.2 | 24.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +309.8 | 0.0 | 0.0 | 1.7 | +90.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +309.8 | 0.0 | 0.0 | 1.7 | +90.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -158.4 | 0.0 | 0.0 | 0.3 | -16.7 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 41.7 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 65.0 | 3.7 | +0.0 | 0.0 | 20.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 65.0 | - | - | - | - |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 65.0 | 4.0 | +0.0 | 0.0 | 20.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 55.3 | +0.0 | 0.0 | 706.3 | 45.0 | +0.0 | 0.0 | 326.0 |
| TIED UP BY THE SUM | 2.0 | +281.4 | 126.3 | 0.0 | 1.7 | +234.9 | 178.3 | 0.0 |
| TIME ON OUR SIDE | 58.3 | +463.5 | 0.0 | 1065.0 | 4.7 | +55.6 | 0.0 | 38.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -8.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +13.5 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 1.0 | +58.9 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +5.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.0 | -4.3 | 0.0 | 360.0 | 3.3 | -291.3 | 0.0 | 264.0 |
| WOUNDS ON THE RANKS | 0.3 | +1.4 | 0.0 | 0.0 | 6.3 | +105.8 | 0.0 | 187.3 |

### Rule changes: cnsr-c940641-p11

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 183 | 183 | 119 | 39.67 | +483 | +4.1 |
| HIS SHOT LIST | 308 | 301 | 92 | 30.67 | +1136 | +12.3 |
| HIS SHOTS BY HIS RUN | 297 | 291 | 63 | 21.00 | +646 | +10.3 |
| HOLDER ASSIGNMENT | 69 | 69 | 63 | 21.00 | +4571 | +72.6 |
| LEGAL CHARGES ONLY | 44 | 44 | 44 | 14.67 | +0 | +0.0 |
| OFF BEST | 37 | 37 | 37 | 12.33 | -1274 | -34.4 |
| FIVE ACTION | 618 | 608 | 32 | 10.67 | +2015 | +63.0 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| QUARTER ODDS | 173 | 171 | 25 | 8.33 | +1691 | +67.6 |
| REDIRECT FOR A FRIEND IN REACH | 25 | 25 | 25 | 8.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 48 | 46 | 21 | 7.00 | +1917 | +91.3 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 20 | 6.67 | -1625 | -81.3 |
| SHOT RISK POINTS | 184 | 181 | 17 | 5.67 | +184 | +10.8 |
| TIME ON OUR SIDE | 189 | 161 | 16 | 5.33 | +9 | +0.6 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| GOAL WALK | 64 | 64 | 13 | 4.33 | +869 | +66.8 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| NEXT CHARGE BY LIST | 35 | 33 | 13 | 4.33 | +1869 | +143.8 |
| FOUR ROUNDS | 21 | 20 | 11 | 3.67 | +568 | +51.6 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 11 | 3.67 | +172 | +15.6 |
| RANDOM MOVE BY FIGURES | 18 | 18 | 10 | 3.33 | +584 | +58.4 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| ONE PROMISE A TARGET | 9 | 9 | 9 | 3.00 | -476 | -52.9 |
| THE RISK READS HIS RUN | 18 | 18 | 9 | 3.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1905 | +238.1 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 58 | 35 | 8 | 2.67 | +27 | +3.3 |
| TIED UP BY THE SUM | 11 | 10 | 8 | 2.67 | +221 | +27.7 |
| CHARGE LOSSES | 103 | 100 | 6 | 2.00 | +749 | +124.8 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| EVASIVE BY THE ODDS | 12 | 12 | 5 | 1.67 | +705 | +141.1 |
| STAY WORTH | 91 | 84 | 5 | 1.67 | +84 | +16.8 |
| WHOLE FIGHT DANGER | 13 | 13 | 5 | 1.67 | +308 | +61.5 |
| CAST JOB | 9 | 9 | 4 | 1.33 | +21 | +5.3 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 17 | 17 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 102 | 81 | 4 | 1.33 | +110 | +27.4 |
| SUPPORT ADDS | 11 | 11 | 4 | 1.33 | +235 | +58.7 |
| SUPPORT WORKED OUT | 11 | 11 | 4 | 1.33 | +235 | +58.7 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 61 | 35 | 3 | 1.00 | +36 | +12.1 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +8 | +2.7 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -14 | -4.8 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +30 | +10.0 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +48 | +15.9 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +143 | +47.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -2 | -0.8 |
| FIGHT TO THE END | 2 | 2 | 2 | 0.67 | +4 | +2.2 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +18 | +9.1 |
| NO DOUBLE ROUNDS | 17 | 16 | 2 | 0.67 | +65 | +32.6 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +32 | +16.1 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +10 | +4.8 |
| RISK BY ARC | 14 | 13 | 2 | 0.67 | +10 | +4.9 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +103 | +51.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 2 | 0.67 | +4 | +2.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.2 |
| BEST OVERALL | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 1 | 0.33 | +5 | +5.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +70 | +69.8 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -73 | -73.1 |
| CHARGE NOW FIRST | 15 | 15 | 1 | 0.33 | -31 | -31.2 |
| EXACT ROUND | 10 | 10 | 1 | 0.33 | +6 | +5.6 |
| FALL BACK GOOD ORDER | 15 | 15 | 1 | 0.33 | +0 | +0.4 |
| FALLS SHORT | 71 | 58 | 1 | 0.33 | +24 | +24.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +8 | +8.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +14 | +14.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +57 | +56.9 |
| HONEST WORTH | 21 | 20 | 1 | 0.33 | +10 | +9.9 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +64 | +64.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 5 | 4 | 1 | 0.33 | +4 | +3.6 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 1 | 0.33 | -21 | -21.5 |
| REDIRECT COUNTER | 14 | 12 | 1 | 0.33 | +57 | +56.6 |
| RUN DOWN | 13 | 12 | 1 | 0.33 | +101 | +100.6 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| SET UP BY THE SET | 13 | 13 | 1 | 0.33 | +1 | +0.8 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -1 | -1.4 |
| THE ROW IN ITS ORDER | 20 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +6 | +5.6 |
| WOUNDS ON THE RANKS | 20 | 20 | 1 | 0.33 | +45 | +44.8 |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 86 | 84 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 62 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 34 | 34 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 24 | 24 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 69 | 68 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 38 | 36 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 49 | 49 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 52 | 50 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 69 | 69 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 108 | 108 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 19 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 28 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEARER NOT NEEDED | 63 | 61 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 36 | 17 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 31 | 23 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 4 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 294 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 43 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 61 | 54 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 246 | 242 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 301 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p11

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 6.67 | 33.6 |
| ARMY TABLE | rule | 5.33 | 4.67 | 70.3 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | 2.00 | 81.3 |
| ONE PROMISE A TARGET | rule | 0.33 | 2.67 | 52.9 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 8.4 |
| PROMISE SHOT AWAY | rule | 1.00 | - | 4.8 |
| JOINT CHARGE NOW | rule | - | 0.67 | 11.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 45.0 |
| CHAFF PASSED | rule | - | 0.33 | 1.7 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 73.1 |
| CHARGE NOW FIRST | rule | 0.33 | - | 31.2 |
| NO REASON | gate | - | 0.33 | 28.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 21.5 |
| RULE SWITCHED OFF | gate | 0.33 | - | 59.1 |
| SUPPORT NARROWED | rule | 0.33 | - | 1.4 |

### Plans: cnsr-c940641-p11

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 62% | 667 | 213 | 32% |
| Mine | move | 43.3 | 96% | 2699 | 0 | 0% |
| Mine | shoot | 5.7 | 35% | 285 | 94 | 33% |
| Opponent | charge | 2.7 | 75% | 390 | 377 | 97% |
| Opponent | join | 5.0 | 100% | 215 | 0 | 0% |
| Opponent | move | 36.7 | 97% | 1384 | 0 | 0% |
| Opponent | shoot | 2.0 | 50% | 113 | 37 | 32% |

### Battle groups: cnsr-c940641-p11

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 27% | 100% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p11

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 22 (6) | 0 | 22 | 48 | 0% | 1.2 | - | 26 (5) | 0 (1) | 26 (5) | 0 (1) |
| Mine | Character | 7 | 78 (7) | 78 | 0 | 22 | 14% | 2.5 | 176 (2) | 0 (3) | 44 (2) | 109 (4) | 0 (3) |
| Mine | Clean-up | 1 | 293 (1) | 0 | 293 | 0 | 0% | 2.0 | - | 293 (1) | - | - | 293 (1) |
| Mine | Fast Hammer | 6 | 0 (6) | 0 | 0 | 42 | 67% | 3.5 | 0 (4) | 0 (2) | - | - | 0 (6) |
| Mine | Hammer | 5 | 56 (5) | 23 | 33 | 32 | 20% | 1.5 | 41 (3) | 74 (2) | - | 71 (2) | 49 (3) |
| Mine | Holder | 8 | 14 (8) | 0 | 14 | 0 | 50% | 1.2 | 61 (2) | 0 (5) | - | 61 (2) | 0 (5) |
| Mine | Shooter | 5 | 71 (5) | 0 | 71 | 0 | 0% | 1.4 | 0 (2) | 162 (3) | - | 85 (4) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 173 (4) | 23 | 150 | 25 | 25% | 2.7 | 231 (3) | - | 0 (1) | 231 (3) | 0 (1) |
| Opponent | Character | 11 | 39 (11) | 39 | 0 | 38 | 36% | 3.6 | 81 (2) | 36 (7) | 0 (1) | 30 (6) | 77 (4) |
| Opponent | Fast Hammer | 6 | 46 (6) | 12 | 35 | 20 | 17% | 2.8 | - | 51 (5) | 19 (1) | 58 (3) | 39 (3) |
| Opponent | Hammer | 8 | 7 (8) | 7 | 0 | 29 | 50% | 4.5 | 0 (3) | 11 (5) | - | 9 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 35 | 67% | 4.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | Shooter | 3 | 92 (3) | 18 | 74 | 70 | 0% | 1.0 | - | 71 (2) | 142 (1) | 134 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: cnsr-c940641-p11

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 932 | 2.0 | 1.0 | 466 | 0 | +466 | 1 of 4 | 4 of 4 | - | +466 |
| **Mine** | all armies | 3 | 0 | 621 | 1.7 | 1.0 | 373 | 0 | +373 | 1 of 5 | 4 of 5 | - | +373 |
| Opponent | Vampire Counts | 1 | 145 | 740 | 4.0 | 1.0 | 185 | 0 | +185 | 2 of 4 | 3 of 4 | - | +185 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 66 | 390 | 3.0 | 1.0 | 130 | 0 | +130 | 2 of 3 | 3 of 3 | - | +130 |
| **Opponent** | all armies | 3 | 70 | 377 | 2.7 | 1.0 | 141 | 0 | +141 | 5 of 8 | 6 of 8 | - | +141 |

### Effective charges: cnsr-c940641-p11

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 1 (net +1484) | 3 (net +126) | 0 | 0 | 0% (0 of 4) |
| Opponent | Vampire Counts | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +342) | 1 | 33% (1 of 3) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +130) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: cnsr-c940641-p11

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 41 | 75 | +0 | 19 | 76 | -58 | -140.9 |
| Mine | 76-89% | 1 | 431 | 201 | +1484 | 1484 | 96 | +1388 | +322.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 437 | 126 | +126 | 150 | 16 | +134 | +30.7 |
| Mine | All fights | 5 | 357 | 131 | +373 | 391 | 44 | +347 | +97.2 |
| Opponent | Effective (55-75%) | 1 | 186 | 210 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 356 | 208 | +215 | 228 | 9 | +219 | +61.5 |
| Opponent | No odds | 2 | 82 | 243 | +28 | 28 | 67 | -40 | -48.4 |
| Opponent | All fights | 8 | 266 | 217 | +141 | 149 | 22 | +127 | +47.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p11 | move | 20 | 3 (15%) | 2 (10%) | 6 (30%) | 11 (55%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

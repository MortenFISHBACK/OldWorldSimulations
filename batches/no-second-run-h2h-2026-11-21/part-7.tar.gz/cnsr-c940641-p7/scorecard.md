# Doctrine scorecard: cnsr-c940641-p7

### Scorecard: cnsr-c940641-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 2 | 2 | 1 | 0 | 1 | 0 | 0 | 165 |
| L1114 | 4 | 1 | Opponent | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | yes | 2 | 4 | 1 | 2 | 0 | 0 | 0 | 340 |
| L1224 | 6 | 1 | Mine | no | 14 | 1 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 1 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 5.3 | 1.5 | 1.7 | 0.0 | 0.3 | 0.0 | 0.0 | 275.0 |
| **Average** | | | Opponent | 33% | 2.0 | 4.3 | 1.3 | 1.7 | 0.0 | 0.0 | 0.0 | 113.3 |

### KPIs: cnsr-c940641-p7

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 50% (7 of 14) | 0% (0 of 14) | 25% (7 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 33% (22 of 66) | 61% (11 of 18) | 39% (33 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (22 of 42) | 73% (11 of 15) | 58% (33 of 57) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 44% (4 of 9) | 44% (4 of 9) |
| Points that never fought | lower | 48% (2879 of 5998) | 51% (3051 of 5998) | 49% (5930 of 11996) |
|   infantry points that never fought | lower | 77% (559 of 730) | 100% (913 of 913) | 90% (1472 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (14 of 25) | 57% (16 of 28) | 57% (30 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 6.7 uses a game | 100% (1 of 1); 1.3 uses a game | 88% (7 of 8); 4.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 50% (3 of 6); 1.3 uses a game | 50% (3 of 6); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (2508 of 5614) | 47% (2751 of 5828) | 46% (5259 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.0 (20%) | 0.0 (0%) | 3.0 (18%) |
| MARCHED: its unit marched | 2.7 (18%) | 1.3 (57%) | 4.0 (24%) |
| CHARGED: its unit charged | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: engaged in combat | 4.7 (32%) | 0.7 (29%) | 5.3 (31%) |
| GONE: slain | 2.0 (14%) | 0.3 (14%) | 2.3 (14%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (9%) | 0.0 (0%) | 1.3 (8%) |
| STUPIDITY: Stupidity | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 5.7 | 1.3 | 11.0 | 2.0 | 5.0 |
| not cast | 1.7 | 6.3 | 2.7 | 17.0 | 6.0 | 31.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (47%) | 0.0 (0%) | 3.0 (18%) | 1.3 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (24%) | 1.0 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.3 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (11%) | 0.7 (25%) | 5.3 (31%) | 0.3 (6%) | 0.0 (0%) |
| GONE: slain | 0.3 (20%) | 2.3 (37%) | 0.3 (12%) | 2.3 (14%) | 1.0 (17%) | 1.0 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (8%) | 1.3 (22%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (80%) | 0.0 (0%) | 1.7 (62%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 28.0 (90%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 100% (4 of 4) | 100% (4 of 4) |
| the unit moved after it | - | 0% (0 of 4) | 0% (0 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 25% (1 of 4) | 25% (1 of 4) |
| it fought by the end of its next turn | - | 25% (1 of 4) | 25% (1 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 25% (1 of 4) | 25% (1 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 50% (2 of 4) | 50% (2 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (44 of 61) | 35% (7 of 20) | 63% (51 of 81) |
|   cavalry | 0% (0 of 12) | 38% (3 of 8) | 15% (3 of 20) |
|   character | - | 0% (0 of 8) | 0% (0 of 8) |
|   chariot | 75% (9 of 12) | - | 75% (9 of 12) |
|   infantry | 100% (11 of 11) | 100% (4 of 4) | 100% (15 of 15) |
|   war machine | 92% (24 of 26) | - | 92% (24 of 26) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (35%) | 0.3 (8%) | 2.3 (23%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (23%) | 1.0 (10%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) |
| MOVED: a war machine that moved | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| FREE: none of these - no target in range or sight, or held its fire | 3.0 (53%) | 0.0 (0%) | 3.0 (30%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.7 (38%) | 1.7 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (15%) | 0.7 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) |
| SHELTERED: the target was sheltered | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.0 | 0.3 | 89% | 3.4 pts | 10 pts |
| infantry | 10.0 | 2.0 | 80% | 9.7 pts | 97 pts |
| war machine | 8.3 | 5.0 | 72% | 15.3 pts | 128 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 3.3 | 3.0 |
| Charges that made contact a game | 2.3 | 2.3 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.86 contact (7 units) | 0.33 declared, 0.33 contact (3 units) | 0.80 declared, 0.70 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (10 units) | 0.43 declared, 0.29 contact (21 units) | 0.32 declared, 0.23 contact (31 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (6 of 11) | 50% (1 of 2) | 0% (0 of 2) | 47% (7 of 15) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 67% (4 of 6) | 67% (4 of 6) | 0% (0 of 7) | 42% (8 of 19) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 67% (2 of 3); on the table 67% | 33% (22 of 66) | 48% | 56% (14 of 25) | 86% (6 of 7); 6.7 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 55% | 56% (5 of 9) | 0.0 uses a game | 50% (3 of 6); 4.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 56% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 1); on the table 0% | 67% (4 of 6) | 42% | 50% (6 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p7, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | 80% (4) | 55% (6) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 75% (6 of 8) | 67% (4 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (13 of 43) | 50% (1 of 2) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 83% (5 of 6) | 0% (0 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | - |
| Strategy | Lone characters that fought | 90% (9 of 10) | 45% (5 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.0 | 1.7 |
| Movement | Points that never moved of their own | 275.0 | 113.3 |
| Movement | Fights charged into per game | 2.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 7, net +0 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 7, net +60 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +297 | 3 of 4, net +228 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.7 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (8 of 20) | 73% (8 of 11) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 8.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (9 of 24) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 6.0 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 44% (8 of 18) | 33% (2 of 6) |
| Magic | Wounds caused by magic missiles | 14.0 | 1.0 |
| Magic | Wounds caused by other spells | 3.7 | 3.3 |
| Magic | Points destroyed by magic (all spells) | 382.7 | 191.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 2.0 / 1.3 / 1.0 | 1.7 / 1.0 / 1.7 / 0.0 |
| Combat | Points destroyed in combat | 281.0 | 382.0 |
| Combat | Points run down | 83.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +181 | +192 |
| Combat | Net per 100 charger points, damage counted | +60.3 | +66.8 |
| Combat | First round won (charged fights) | 86% | 83% |
| Combat | Net points per charged fight | +156 | +191 |
| Combat | Net points per supported fight / lone fight | - / +156 | +316 / +166 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 7 | 4 of 6 |
| Game | Points lost | 798.7 | 784.3 |
| Game | VP from objectives | 553.3 | 630.0 |
| Game | Lone holders (player turns) | 5.3 | 2.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -24 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1583
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnsr-c940641-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| ARMY TABLE | 11.3 | +138.2 | 0.0 | 142.3 | 28.7 | -31.1 | 0.0 | 743.7 |
| ARTILLERY RE-ROLL WEIGHED | 5.0 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +3.7 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 1.0 | +10.1 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -14.6 | 73.7 | 0.0 |
| CANNON PLANNED TARGET | 8.0 | +211.5 | 79.7 | 220.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.0 | +170.7 | 739.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 313.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +203.7 | 0.0 | 100.0 |
| CHALLENGE BY POINTS | 1.0 | +32.2 | 0.0 | 73.7 | 1.3 | +41.6 | 0.0 | 245.3 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | +4.8 | 0.0 | 114.3 |
| CHARGE LOSSES | 9.7 | -671.3 | 0.0 | 289.7 | 28.3 | -1010.3 | 0.0 | 1116.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 301.3 | 0.0 | 2.0 | +0.0 | 343.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 173.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 119.3 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +45.8 | 313.3 | 313.3 |
| COVER ONCE | 9.3 | -574.9 | 0.0 | 110.0 | 6.0 | -352.1 | 0.0 | 16.7 |
| DENIED BY THE FIGHT | 0.3 | -4.5 | 83.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -3.9 | 0.0 | 0.0 |
| ELIXIR WORTH | 0.3 | +18.6 | 0.0 | 98.7 | - | - | - | - |
| EXACT ROUND | 1.3 | +15.4 | 447.7 | 0.0 | 2.3 | +61.2 | 490.3 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.7 | +9.8 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +5.1 | 579.0 | 72.3 | 2.0 | +1.2 | 306.7 | 114.3 |
| FALLS SHORT | - | - | - | - | 22.7 | +235.6 | 0.0 | 744.3 |
| FIGHT TO THE END | 1.0 | +14.9 | 131.3 | 72.3 | - | - | - | - |
| FIVE ACTION | 74.3 | +5161.9 | 1633.7 | 989.7 | 83.7 | +5160.7 | 645.7 | 2220.0 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 151.3 | 6.0 | +0.0 | 0.0 | 100.3 |
| FOLLOW UP WEIGHED | 0.3 | +29.6 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.7 | +332.8 | 620.0 | 72.3 | 3.0 | +229.3 | 490.3 | 114.3 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 77.7 | 6.3 | +0.0 | 0.0 | 177.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -65.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.0 | -30.1 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.7 | +65.5 | 0.0 | 119.3 | - | - | - | - |
| GIVES UP | 0.3 | -2.9 | 156.7 | 0.0 | - | - | - | - |
| GOAL WALK | 1.3 | +135.4 | 0.0 | 0.0 | 12.0 | +1784.5 | 0.0 | 95.3 |
| GUN MASK | 2.7 | +170.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 77.7 | 3.7 | +0.0 | 0.0 | 177.3 |
| HELPER UNSEEN | - | - | - | - | 0.7 | +0.0 | 147.3 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 212.0 | 11.3 | +0.0 | 0.0 | 267.7 |
| HIS CHARGE DENIED | 0.3 | +9.1 | 83.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 0.0 | 17.3 | +0.0 | 0.0 | 786.7 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.7 | -5.3 | 0.0 | 0.0 | 12.7 | -173.8 | 0.0 | 504.3 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 212.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 7.3 | +0.0 | 0.0 | 367.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 147.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 19.3 | +180.7 | 0.0 | 110.0 | 67.0 | +5318.4 | 0.0 | 2022.0 |
| HIS SHOTS BY HIS RUN | 21.0 | +157.0 | 0.0 | 367.3 | 60.3 | +1655.0 | 0.0 | 1731.3 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +91.7 | 257.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.3 | +0.0 | 0.0 | 212.0 | 16.0 | +0.0 | 0.0 | 438.3 |
| HOLDER ASSIGNMENT | 11.0 | +918.4 | 0.0 | 106.0 | 10.3 | +1023.9 | 0.0 | 261.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -97.0 | 620.0 | 72.3 | 2.7 | -68.6 | 416.7 | 114.3 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +41.5 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.7 | +196.7 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.7 | +254.4 | 110.0 | 0.0 |
| IDLE COST | - | - | - | - | 18.7 | -292.9 | 0.0 | 384.7 |
| JOINT CHARGE NOW | 0.7 | -7.5 | 313.3 | 0.0 | 1.0 | -48.9 | 147.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 107.3 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 47.7 | 422.0 | 4.0 | +0.0 | 119.3 | 88.7 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | +0.3 | 559.0 | 72.3 | 1.7 | -6.2 | 270.3 | 114.3 |
| LOST CHARGE | 0.3 | -2.3 | 156.7 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.7 | +1.1 | 0.0 | 0.0 | 1.3 | -1.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 2.3 | +71.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.3 | +101.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.3 | +94.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.0 | +69.0 | 0.0 | 77.7 | 1.0 | +145.9 | 0.0 | 156.7 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +98.4 | 0.0 | 32.3 | 2.7 | +46.0 | 0.0 | 156.7 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.0 | +281.5 | 0.0 | 73.7 | 4.0 | +21.1 | 0.0 | 156.7 |
| MISSILES NEXT TURN | 14.0 | +220.7 | 0.0 | 151.3 | 6.0 | +30.7 | 0.0 | 313.3 |
| MISSILES ON ONE TARGET | 0.7 | -9.6 | 0.0 | 73.7 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 167.3 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 313.3 |
| MOVE TO CHARGE COMPUTED | 5.3 | +457.6 | 0.0 | 0.0 | 3.7 | +394.9 | 0.0 | 83.7 |
| NEARER NOT NEEDED | 4.0 | +156.7 | 0.0 | 0.0 | 7.3 | +293.5 | 0.0 | 40.0 |
| NEXT CHARGE BY LIST | 1.7 | +299.0 | 0.0 | 0.0 | 2.0 | +95.5 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -0.3 | 0.0 | 0.0 | 0.3 | -6.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -120.6 | 620.0 | 72.3 | 3.0 | -155.3 | 490.3 | 114.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.0 | -433.0 | 0.0 | 110.0 | 4.7 | -253.3 | 0.0 | 20.0 |
| OGRE LOADER SECOND SHOT | 7.0 | +66.3 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -4.6 | 73.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -93.7 | 0.0 | 32.3 | 5.0 | -155.0 | 0.0 | 240.3 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +48.5 | 147.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -70.3 | 0.0 | 106.0 | 4.0 | -44.6 | 0.0 | 123.7 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +16.9 | 20.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +9.4 | 110.0 | 0.0 |
| OWN CAST FIRST | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -17.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 33.7 | +712.7 | 520.3 | 1049.7 | 41.3 | +398.7 | 335.7 | 1463.0 |
| PROMISE BY ITS OWN SUM | 13.3 | -682.8 | 0.0 | 0.0 | 6.7 | -153.4 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | -11.7 | 0.0 | 0.0 | 1.3 | -0.8 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 8.7 | +1360.3 | 0.0 | 212.0 | 15.3 | +2317.4 | 202.3 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +56.9 | 0.0 | 113.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.3 | +167.6 | 0.0 | 60.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -33.5 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +28.6 | 505.7 | 72.3 | 3.0 | -145.3 | 490.3 | 114.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -31.7 | 55.0 | 0.0 |
| RUN DOWN | 1.0 | -23.0 | 172.3 | 0.0 | 2.0 | -42.5 | 306.7 | 114.3 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | +148.5 | 0.0 | 80.0 |
| SEARCH SPOT | 0.3 | +1.2 | 0.0 | 0.0 | 0.7 | +51.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -8.1 | 0.0 | 0.0 | 0.7 | -72.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +15.5 | 0.0 | 0.0 | 3.7 | +158.2 | 110.0 | 20.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +14.1 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -2.2 | 0.0 | 40.0 |
| SHOOTERS ON THE TABLE | 13.7 | +0.0 | 0.0 | 220.0 | 2.7 | +0.0 | 0.0 | 20.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +296.5 | 41.0 | 0.0 | 0.7 | +86.5 | 155.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -4.5 | 114.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 8.7 | -56.2 | 0.0 | 330.0 | 48.3 | +1249.2 | 0.0 | 1636.3 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +618.0 | 0.0 | 307.3 | 3.3 | +84.0 | 0.0 | 59.0 |
| SPELL WORTH | 0.7 | +7.7 | 0.0 | 0.0 | 1.7 | +33.0 | 313.3 | 313.3 |
| SPELLS IN THE FIGHT | 1.0 | -3.0 | 271.0 | 72.3 | 0.3 | -6.7 | 73.7 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 73.7 | 7.7 | +0.0 | 0.0 | 204.3 |
| STAND AND SHOOT | 0.3 | -1.2 | 41.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 4.7 | +0.0 | 0.0 | 354.3 |
| STANDS STILL | 40.0 | +0.0 | 1013.7 | 550.0 | 15.7 | +0.0 | 155.3 | 278.0 |
| STAY WORTH | 26.0 | -311.0 | 348.0 | 330.0 | 3.7 | -41.9 | 0.0 | 59.0 |
| STOPS | - | - | - | - | 0.7 | +89.7 | 110.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +4.4 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.7 | +763.3 | 0.0 | 142.3 | 0.7 | +38.0 | 0.0 | 53.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 41.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 5.7 | +763.3 | 0.0 | 142.3 | 0.7 | +38.0 | 0.0 | 53.7 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +2.4 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | -8.8 | 0.0 | 77.7 | 0.3 | +1.1 | 0.0 | 41.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 47.7 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 20.0 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 73.7 | - | - | - | - |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.0 | +0.0 | 0.0 | 403.7 | 40.7 | +0.0 | 0.0 | 992.3 |
| TIED UP BY THE SUM | 1.0 | +109.7 | 144.7 | 0.0 | 0.7 | +81.5 | 110.0 | 0.0 |
| TIME ON OUR SIDE | 32.3 | +490.8 | 0.0 | 77.7 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 83.7 |
| WHO FIGHTS | - | - | - | - | 0.3 | -27.3 | 73.7 | 0.0 |
| WHO HITS BACK | 0.3 | +58.7 | 0.0 | 123.0 | 0.7 | +169.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -582.5 | 0.0 | 147.3 | 1.0 | -87.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +146.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +5.1 | 0.0 | 147.3 | - | - | - | - |

### Rule changes: cnsr-c940641-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 120 | 120 | 72 | 24.00 | +1529 | +21.2 |
| HIS SHOT LIST | 259 | 245 | 61 | 20.33 | +2098 | +34.4 |
| HOLDER ASSIGNMENT | 64 | 64 | 58 | 19.33 | +4036 | +69.6 |
| HIS SHOTS BY HIS RUN | 244 | 235 | 43 | 14.33 | +720 | +16.7 |
| FIVE ACTION | 474 | 457 | 35 | 11.67 | +2739 | +78.3 |
| OFF BEST | 32 | 32 | 32 | 10.67 | -2059 | -64.3 |
| SHOT RISK POINTS | 171 | 166 | 32 | 10.67 | +2086 | +65.2 |
| PROMISE BY ITS OWN SUM | 60 | 60 | 28 | 9.33 | -2509 | -89.6 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| QUARTER ODDS | 72 | 70 | 22 | 7.33 | +1729 | +78.6 |
| OGRE LOADER SECOND SHOT | 21 | 21 | 21 | 7.00 | +199 | +9.5 |
| LEGAL CHARGES ONLY | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| MOVE TO CHARGE COMPUTED | 27 | 23 | 17 | 5.67 | +1248 | +73.4 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| CHARGE LOSSES | 114 | 112 | 13 | 4.33 | +1641 | +126.2 |
| SUPPORT ADDS | 19 | 19 | 13 | 4.33 | +1410 | +108.4 |
| SUPPORT WORKED OUT | 19 | 19 | 13 | 4.33 | +1410 | +108.4 |
| GOAL WALK | 40 | 40 | 12 | 4.00 | +2185 | +182.1 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 11 | 3.67 | +240 | +21.8 |
| CAST JOB | 12 | 12 | 10 | 3.33 | +10 | +1.0 |
| FOUR ROUNDS | 17 | 17 | 10 | 3.33 | +682 | +68.2 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| COVER ONCE | 46 | 30 | 8 | 2.67 | +142 | +17.7 |
| NEXT CHARGE BY LIST | 11 | 10 | 8 | 2.67 | +850 | +106.3 |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 8 | 2.67 | +113 | +14.1 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +222 | +31.7 |
| IDLE COST | 56 | 38 | 7 | 2.33 | +49 | +7.0 |
| MARCH BY THE SUM | 7 | 7 | 7 | 2.33 | +213 | +30.4 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SET UP BY THE SET | 15 | 15 | 6 | 2.00 | +249 | +41.4 |
| TIME ON OUR SIDE | 97 | 73 | 6 | 2.00 | +52 | +8.6 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 9 | 9 | 5 | 1.67 | +113 | +22.6 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -169 | -33.8 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| MARCH CHECK | 7 | 7 | 5 | 1.67 | +116 | +23.2 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +146 | +29.3 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -283 | -70.7 |
| MISSILES IN THE MOVE | 45 | 28 | 4 | 1.33 | +97 | +24.1 |
| PROMISE KNOWS THE FIGHT | 7 | 7 | 4 | 1.33 | -37 | -9.4 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 4 | 1.33 | +171 | +42.7 |
| SHOTS AFTER THE MOVES | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| EXACT ROUND | 11 | 11 | 3 | 1.00 | +71 | +23.7 |
| GUN MASK | 8 | 8 | 3 | 1.00 | +266 | +88.8 |
| MAX FOR POSITIONING | 22 | 20 | 3 | 1.00 | +31 | +10.4 |
| MISSILES NEXT TURN | 60 | 38 | 3 | 1.00 | +17 | +5.8 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +567 | +188.9 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +159 | +53.1 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +682 | +227.2 |
| CANNON PLANNED TARGET | 24 | 24 | 2 | 0.67 | -101 | -50.5 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +29 | +14.7 |
| FALLS SHORT | 68 | 63 | 2 | 0.67 | +14 | +7.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +197 | +98.3 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +24 | +11.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +27 | +13.5 |
| NEARER NOT NEEDED | 34 | 34 | 2 | 0.67 | +56 | +28.0 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -9 | -4.5 |
| RISK BY ARC | 16 | 16 | 2 | 0.67 | +35 | +17.5 |
| SHOTS IN THE MOVE | 56 | 41 | 2 | 0.67 | +19 | +9.4 |
| STOPS | 2 | 2 | 2 | 0.67 | +138 | +69.1 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | -23 | -11.4 |
| THE ROW IN ITS ORDER | 18 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 11 | 11 | 2 | 0.67 | +575 | +287.3 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +14 | +14.1 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +11 | +11.2 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 10 | 10 | 1 | 0.33 | -82 | -81.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +56 | +55.7 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +89 | +88.7 |
| ONE FIGHT FORMULA | 29 | 19 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 25 | 17 | 1 | 0.33 | +84 | +84.2 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +12 | +12.1 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +17 | +16.9 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -10 | -10.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -51 | -51.3 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ROUNDS AFTER TERROR | 2 | 2 | 1 | 0.33 | +17 | +16.9 |
| STAY WORTH | 89 | 80 | 1 | 0.33 | +2 | +1.7 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +13 | +13.1 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +130 | +129.5 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 41 | 40 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 13 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 45 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 26 | 24 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 15 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 61 | 59 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 68 | 66 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 15 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 43 | 42 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 22 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 22 | 22 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 88 | 0 | 0.00 | - | - |
| HONEST WORTH | 16 | 16 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 3 | 3 | 0 | 0.00 | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 11 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 17 | 17 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 225 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 49 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 38 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 167 | 157 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 227 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 4.67 | 64.3 |
| PROMISE BY ITS OWN SUM | rule | 7.67 | 1.67 | 89.6 |
| ARMY TABLE | rule | 0.67 | 2.33 | 49.3 |
| MARCH OF THE TABLE | rule | 1.33 | - | 70.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | 0.67 | 9.4 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 15.1 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 251.6 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 4.5 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 156.9 |
| CHARGE NOW FIRST | rule | 0.33 | - | 81.9 |
| OWN CAST FIRST | rule | 0.33 | - | 10.5 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 51.3 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 26.3 |

### Plans: cnsr-c940641-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 86% | 284 | 437 | 154% |
| Mine | move | 20.0 | 95% | 1612 | 0 | 0% |
| Mine | shoot | 11.3 | 41% | 495 | 276 | 56% |
| Opponent | charge | 2.0 | 100% | 414 | 399 | 96% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 36.3 | 92% | 1978 | 0 | 0% |
| Opponent | shoot | 0.7 | 0% | 0 | 0 | - |
| Opponent | support | 1.3 | 75% | 150 | 0 | 0% |

### Packages: hunt the guns, cnsr-c940641-p7

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.7 | 2 | 0 | 100% | 100% | 0% | 2.0 | 382 | 295 | 100% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 2.0 | 2 | 0 | 100% | 100% | 0% | 2.0 | 382 | 295 | 100% | 0 |

### Battle groups: cnsr-c940641-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.3 | 50% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 74 (9) | 74 | 0 | 23 | 22% | 2.1 | 81 (2) | 81 (6) | - | 50 (4) | 105 (4) |
| Mine | Clean-up | 2 | 74 (2) | 0 | 74 | 0 | 0% | 3.5 | 0 (1) | 139 (1) | - | 74 (2) | - |
| Mine | Fast Hammer | 4 | 21 (4) | 0 | 21 | 35 | 25% | 2.7 | 0 (2) | 29 (2) | - | 27 (3) | 8 (1) |
| Mine | Holder | 1 | 123 (1) | 0 | 123 | 129 | 0% | 1.0 | 123 (1) | - | - | 123 (1) | - |
| Mine | Shooter | 4 | 112 (4) | 33 | 79 | 18 | 25% | 1.3 | 96 (3) | 186 (1) | - | 139 (3) | 54 (1) |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 67 | 0% | 1.0 | 0 (2) | 0 (2) | 0 (2) | 0 (1) | 0 (5) |
| Mine | Wizard | 3 | 60 (3) | 60 | 0 | 100 | 0% | 2.3 | 0 (1) | 114 (1) | - | 70 (2) | - |
| Opponent | Chaff | 2 | 175 (2) | 0 | 175 | 100 | 50% | 4.0 | - | 350 (1) | 0 (1) | 175 (2) | - |
| Opponent | Character | 10 | 64 (10) | 64 | 0 | 26 | 40% | 3.3 | 109 (3) | 50 (5) | 0 (2) | 43 (5) | 89 (5) |
| Opponent | Fast Hammer | 9 | 18 (9) | 0 | 18 | 84 | 33% | 2.8 | 30 (2) | 15 (7) | - | 10 (5) | 27 (4) |
| Opponent | Hammer | 3 | 88 (3) | 88 | 0 | 37 | 0% | 3.0 | 0 (2) | 237 (1) | - | 0 (2) | 237 (1) |
| Opponent | Holder | 5 | 25 (5) | 0 | 25 | 0 | 100% | - | 0 (2) | 0 (1) | 60 (2) | 34 (2) | 15 (3) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cnsr-c940641-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 383 | 365 | 2.3 | 1.0 | 156 | 0 | +156 | 4 of 7 | 6 of 7 | - | +156 |
| Opponent | High Elf Realms | 1 | 358 | 296 | 2.0 | 1.0 | 148 | 0 | +148 | 2 of 2 | 1 of 2 | - | +148 |
| Opponent | Vampire Counts | 1 | 217 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 850 | 3.0 | 1.3 | 283 | 0 | +283 | 1 of 3 | 3 of 3 | +316 | +267 |
| **Opponent** | all armies | 3 | 192 | 382 | 2.0 | 1.2 | 191 | 0 | +191 | 4 of 6 | 5 of 6 | +316 | +166 |

### Effective charges: cnsr-c940641-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 7 | 0 | 0 | 2 (net +0) | 1 (net +143) | 1 (net +60) | 3 (net +297) | 0 | 29% (2 of 7) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net +165) | 0 | 2 (net +342) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: cnsr-c940641-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 298 | 406 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 233 | 143 | +143 | 143 | 0 | +143 | +61.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 312 | 265 | +297 | 367 | 13 | +354 | +113.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 334 | 60 | +60 | 60 | 0 | +60 | +18.0 |
| Mine | All fights | 7 | 300 | 259 | +156 | 186 | 6 | +181 | +60.3 |
| Opponent | 76-89% | 1 | 116 | 165 | +165 | 165 | 0 | +165 | +142.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 322 | 291 | +228 | 228 | 0 | +228 | +70.8 |
| Opponent | No odds | 2 | 322 | 364 | +148 | 308 | 156 | +152 | +47.2 |
| Opponent | All fights | 6 | 288 | 294 | +191 | 244 | 52 | +192 | +66.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p7 | move | 20 | 3 (15%) | 1 (5%) | 2 (10%) | 15 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

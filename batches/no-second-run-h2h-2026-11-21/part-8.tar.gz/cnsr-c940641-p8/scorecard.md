# Doctrine scorecard: cnsr-c940641-p8

### Scorecard: cnsr-c940641-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 3 | 4 | 0 | 1 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 1 | 0 | 0 | 286 |
| **Average** | | | Mine | 33% | 1.5 | 3.0 | 3.0 | 1.0 | 0.0 | 0.0 | 0.0 | 93.3 |
| **Average** | | | Opponent | 0% | 0.5 | 2.7 | 3.0 | 1.7 | 0.3 | 0.0 | 0.0 | 95.3 |

### KPIs: cnsr-c940641-p8

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 13) | 0% (0 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 2); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fled |  | 60% (3 of 5); on the table 60% | 50% (1 of 2); on the table 50% | 57% (4 of 7); on the table 57% |
| Winner chose to follow up or pursue (all three) |  | 75% (6 of 8); on the table 75% | 50% (3 of 6); on the table 50% | 64% (9 of 14); on the table 64% |
| Magic missiles tried each own turn | 50%+ | 11% (2 of 18) | 29% (7 of 24) | 21% (9 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 13% (2 of 15) | 35% (7 of 20) | 26% (9 of 35) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 40% (4 of 10) | 40% (4 of 10) |
| Points that never fought | lower | 34% (2055 of 6000) | 32% (1940 of 6000) | 33% (3995 of 12000) |
|   infantry points that never fought | lower | 57% (746 of 1315) | 47% (435 of 921) | 53% (1181 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (12 of 25) | 75% (24 of 32) | 63% (36 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 2.0 uses a game |
| Bound items with another spell used |  | 50% (5 of 10); 2.3 uses a game | 0.0 uses a game | 50% (5 of 10); 1.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 38% (2172 of 5720) | 77% (4495 of 5830) | 58% (6667 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (38%) | 3.0 (53%) | 5.0 (45%) |
| MARCHED: its unit marched | 2.0 (38%) | 0.7 (12%) | 2.7 (24%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.7 (12%) | 1.0 (9%) |
| IN COMBAT: engaged in combat | 1.0 (19%) | 0.3 (6%) | 1.3 (12%) |
| GONE: slain | 0.0 (0%) | 0.3 (6%) | 0.3 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (12%) | 0.7 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 1.3 | 2.7 | 3.0 | 0.3 | 4.3 |
| not cast | 2.3 | 2.7 | 3.3 | 11.0 | 1.7 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (88%) | 0.3 (10%) | 5.0 (45%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (24%) | 0.7 (40%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (9%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) | 1.3 (12%) | 1.0 (60%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (14%) | 0.0 (0%) | 0.3 (10%) | 0.7 (6%) | 0.0 (0%) | 0.3 (2%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (86%) | 0.0 (0%) | 2.7 (80%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.3 a game | 1.3 a game |
| stood (cast and not dispelled) | 57% (4 of 7) | - | 57% (4 of 7) |
| the unit moved after it | 25% (1 of 4) | - | 25% (1 of 4) |
| it charged on its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| the enemy charged it first | 25% (1 of 4) | - | 25% (1 of 4) |
| it fought by the end of its next turn | 25% (1 of 4) | - | 25% (1 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 75% (3 of 4) | - | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (63 of 93) | 75% (24 of 32) | 70% (87 of 125) |
|   cavalry | 92% (11 of 12) | 83% (15 of 18) | 87% (26 of 30) |
|   character | 29% (10 of 35) | 60% (3 of 5) | 32% (13 of 40) |
|   infantry | 85% (22 of 26) | 67% (6 of 9) | 80% (28 of 35) |
|   war machine | 100% (20 of 20) | - | 100% (20 of 20) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (40%) | 1.3 (50%) | 5.3 (42%) |
| CHARGED: it charged | 2.0 (20%) | 0.3 (12%) | 2.3 (18%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 1.3 (13%) | 0.3 (12%) | 1.7 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (17%) | 0.7 (25%) | 2.3 (18%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.0 | 1.3 | 90% | 2.9 pts | 40 pts |
| character | 7.0 | 1.7 | 81% | 6.6 pts | 46 pts |
| infantry | 16.3 | 4.0 | 78% | 6.5 pts | 107 pts |
| war machine | 6.7 | 4.0 | 60% | 8.7 pts | 58 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 4.3 | 4.0 |
| Charges that made contact a game | 3.3 | 2.7 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.75 declared, 0.50 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.36 contact (22 units) | 0.57 declared, 0.35 contact (23 units) | 0.47 declared, 0.36 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (10 of 15) | 100% (2 of 2) | - | 71% (12 of 17) |
| Character in a unit | 100% (1 of 1) | 100% (1 of 1) | 100% (1 of 1) | 100% (3 of 3) |
| Character on its own | 83% (5 of 6) | 20% (1 of 5) | 33% (2 of 6) | 47% (8 of 17) |
| Infantry | 75% (9 of 12) | 50% (1 of 2) | - | 71% (10 of 14) |
| Monster | 0% (0 of 2) | - | - | 0% (0 of 2) |
| Monstrous | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 75% (6 of 8); on the table 75% | 11% (2 of 18) | 34% | 48% (12 of 25) | 100% (2 of 2); 2.3 uses a game | 50% (5 of 10); 2.3 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 33% (4 of 12) | 30% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | 50% (2 of 4); on the table 50% | 33% (2 of 6) | 14% | 67% (8 of 12) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | 17% (1 of 6) | 52% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p8, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 38% (3) | 50% (6) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnsr-c940641-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 67% (6 of 9) | 44% (4 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 69% (22 of 32) | 23% (3 of 13) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | - | 67% (2 of 3) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 100% (9 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 93.3 | 95.3 |
| Movement | Fights charged into per game | 3.3 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net -151 | 2 of 6, net -51 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 7, net -76 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 7 | 1 of 6, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 7, net +0 | 1 of 6, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.3 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (18 of 46) | 96% (24 of 25) |
| Shooting | Points destroyed by shooting units | 151.0 | 0.0 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (9 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 40% (2 of 5) |
| Magic | Wounds caused by magic missiles | 3.7 | 0.3 |
| Magic | Wounds caused by other spells | 3.0 | - |
| Magic | Points destroyed by magic (all spells) | 83.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.7 / 0.7 / 2.7 / 0.3 | 1.7 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 240.7 | 219.3 |
| Combat | Points run down | 34.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +145 | +54 |
| Combat | Net per 100 charger points, damage counted | +40.9 | +25.4 |
| Combat | First round won (charged fights) | 60% | 50% |
| Combat | Net points per charged fight | +116 | -16 |
| Combat | Net points per supported fight / lone fight | - / +116 | - / -16 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 10 | 4 of 8 |
| Game | Points lost | 323.7 | 910.3 |
| Game | VP from objectives | 620.0 | 513.3 |
| Game | Lone holders (player turns) | 1.5 | 0.5 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +677 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1234
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 30.3 | +266.7 | 0.0 | 465.0 | 28.0 | +187.0 | 0.0 | 116.7 |
| ASSAILMENT BY POINTS | 1.0 | +6.4 | 0.0 | 0.0 | 0.7 | +1.5 | 0.0 | 108.7 |
| BACKUP TARGETS | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -102.9 | 65.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.3 | +0.1 | 0.0 | 50.3 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 83.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.7 | +146.5 | 328.3 | 46.7 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 0.7 | +3.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +5.3 | 0.0 | 54.0 | 0.7 | +8.9 | 0.0 | 83.3 |
| CHAMPION KNOWS CHALLENGE | 0.7 | -7.1 | 0.0 | 100.7 | 0.3 | -2.4 | 54.0 | 0.0 |
| CHARGE LOSSES | 16.3 | -628.9 | 0.0 | 199.7 | 24.7 | -2293.5 | 0.0 | 703.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 101.7 | 50.3 | 2.0 | +0.0 | 73.7 | 34.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -1.8 | 54.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 54.0 | 6.0 | +0.0 | 0.0 | 125.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +326.7 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 9.0 | -587.3 | 0.0 | 152.0 | 8.3 | -705.3 | 0.0 | 258.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -1.6 | 54.0 | 34.0 |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -53.1 | 41.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +235.4 | 0.0 | 0.0 | 0.3 | +9.8 | 50.3 | 34.0 |
| ELIXIR WORTH | - | - | - | - | 0.3 | +10.7 | 0.0 | 116.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.7 | +49.4 | 0.0 | 41.7 |
| EXACT ROUND | 1.3 | +21.4 | 171.3 | 50.3 | 2.0 | +4.7 | 73.7 | 68.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 153.0 | 0.0 | 2.7 | +44.3 | 178.0 | 68.0 |
| FALLS SHORT | - | - | - | - | 21.3 | +245.1 | 0.0 | 142.3 |
| FEATURE BUFFS | 0.7 | +8.3 | 0.0 | 0.0 | 1.0 | +4.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +23.5 | 0.0 | 50.3 | 1.3 | +1.4 | 100.7 | 68.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 86.3 | 0.0 | - | - | - | - |
| FIVE ACTION | 97.0 | +6579.7 | 1406.0 | 706.7 | 76.0 | +5173.0 | 228.3 | 1063.7 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 148.3 | 6.7 | +0.0 | 0.0 | 338.3 |
| FOLLOW UP WEIGHED | 1.3 | +183.1 | 0.0 | 0.0 | 0.7 | +54.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +476.7 | 254.7 | 100.7 | 3.0 | +170.7 | 178.0 | 68.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 156.0 |
| FRIEND SHOOTS FIRST | 2.0 | -14.5 | 0.0 | 0.0 | 0.3 | -2.3 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -11.7 | 38.7 | 0.0 | - | - | - | - |
| GOAL WALK | 4.3 | +174.3 | 0.0 | 0.0 | 8.3 | +346.7 | 0.0 | 0.0 |
| GUN FIGURES | 0.7 | +17.0 | 68.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 142.3 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 40.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 50.3 | 0.0 |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 145.7 | 15.7 | +0.0 | 0.0 | 569.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +28.8 | 0.0 | 34.0 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 38.7 |
| HIS MOVE AND SHOT | 5.0 | -61.7 | 0.0 | 50.3 | 7.3 | -54.1 | 0.0 | 95.7 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 267.3 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 38.7 |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 95.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 36.0 | +2038.5 | 0.0 | 512.7 | 46.7 | +1154.9 | 0.0 | 549.3 |
| HIS SHOTS BY HIS RUN | 36.3 | +925.4 | 0.0 | 512.7 | 54.3 | +1165.1 | 0.0 | 841.0 |
| HIS TURN DENIED | 0.7 | +3.6 | 0.0 | 50.3 | 0.7 | +12.4 | 77.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 8.7 | +644.2 | 0.0 | 0.0 | 5.3 | +366.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -101.4 | 140.3 | 100.7 | 1.0 | -35.6 | 23.3 | 34.0 |
| IDLE COST | - | - | - | - | 12.0 | -158.7 | 0.0 | 158.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -19.6 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 249.7 | 148.3 | 4.3 | +0.0 | 50.3 | 261.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.7 | +76.5 | 0.0 | 65.0 |
| LONG SHOT | - | - | - | - | 0.7 | +13.4 | 104.3 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -2.3 | 80.3 | 100.7 | 1.3 | +2.7 | 104.3 | 34.0 |
| LOST CHARGE | 0.3 | -0.7 | 0.0 | 50.3 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +40.7 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | -1.4 | 0.0 | 0.0 | 1.3 | -4.3 | 0.0 | 36.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +30.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +31.2 | 0.0 | 0.0 | 0.3 | +13.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +13.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +183.2 | 0.0 | 0.0 | 0.7 | +66.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.0 | +118.8 | 0.0 | 0.0 | 2.7 | +167.9 | 0.0 | 58.3 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +64.8 | 0.0 | 108.0 | 5.0 | +283.2 | 0.0 | 256.7 |
| MISSILES NEXT TURN | 6.0 | +47.7 | 0.0 | 108.0 | 5.7 | +155.7 | 0.0 | 218.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 7.7 | +980.4 | 0.0 | 0.0 | 5.3 | +394.9 | 0.0 | 78.7 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +416.5 | 0.0 | 100.7 | 7.0 | +287.8 | 0.0 | 18.3 |
| NEXT CHARGE BY LIST | 6.0 | +747.0 | 0.0 | 0.0 | 3.3 | +294.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.0 | -103.5 | 254.7 | 100.7 | 3.0 | -105.3 | 178.0 | 68.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 18.3 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.0 | -177.9 | 0.0 | 50.3 | 5.0 | -152.9 | 0.0 | 160.7 |
| ONE CHALLENGE TEST | 0.3 | -51.1 | 114.3 | 0.0 | 0.3 | -2.4 | 54.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 50.3 | 1.0 | +0.0 | 0.0 | 18.3 |
| ONE FIGHT FORMULA | 8.7 | -273.1 | 0.0 | 0.0 | 5.3 | -116.9 | 0.0 | 154.3 |
| ONE OBJECTIVE FORMULA | 4.7 | +52.6 | 0.0 | 0.0 | 1.3 | +50.8 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +14.6 | 23.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +24.2 | 41.7 | 0.0 | 1.0 | +7.2 | 73.7 | 34.0 |
| PLAN RESULT | 43.0 | +487.1 | 475.7 | 522.3 | 39.7 | +425.4 | 201.3 | 1215.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.0 | -312.0 | 0.0 | 0.0 | 6.3 | -38.8 | 0.0 | 77.3 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -6.4 | 0.0 | 0.0 | 0.3 | -59.6 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 26.7 | +2243.8 | 1077.3 | 50.3 | 17.0 | +2129.5 | 0.0 | 499.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +75.4 | 0.0 | 113.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | -88.3 | 0.0 | 18.3 |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +280.9 | 0.0 | 18.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 18.3 |
| REFORMS TO MEET IT | 2.3 | -558.8 | 0.0 | 0.0 | 1.7 | -20.9 | 0.0 | 40.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 151.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +6.5 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +0.7 | 254.7 | 100.7 | 3.0 | +56.7 | 178.0 | 68.0 |
| ROUNDS AFTER TERROR | 1.7 | -40.3 | 153.0 | 0.0 | 0.7 | -5.8 | 23.3 | 0.0 |
| RUN DOWN | 3.0 | -199.7 | 254.7 | 100.7 | 2.7 | -11.2 | 178.0 | 34.0 |
| SEARCH SPOT | 0.7 | -9.2 | 0.0 | 0.0 | 0.3 | +41.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +6.1 | 41.7 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | - | - | - | - | 1.7 | +3.0 | 0.0 | 108.7 |
| SET CREDITED ONCE | 1.0 | -17.0 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 4.0 | +238.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +40.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.0 | +0.0 | 0.0 | 46.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +129.2 | 77.3 | 0.0 | 1.7 | +359.4 | 50.3 | 38.7 |
| SHOT OR CHARGE | 0.7 | -25.3 | 83.3 | 0.0 | 0.3 | -3.5 | 0.0 | 0.0 |
| SHOT RISK POINTS | 22.3 | +406.2 | 0.0 | 350.7 | 33.0 | -382.9 | 0.0 | 645.0 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 21.0 | +569.5 | 0.0 | 154.7 | 8.3 | +864.5 | 0.0 | 36.7 |
| SPELL SETS UP CHARGE | 0.3 | +34.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 3.7 | +103.5 | 0.0 | 0.0 | 2.0 | +8.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +4.7 | 38.7 | 50.3 | 1.3 | -14.1 | 50.3 | 34.0 |
| SPOT AS THE GAME MOVES | 7.7 | +0.0 | 0.0 | 98.0 | 9.0 | +0.0 | 0.0 | 328.7 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -9.3 | 54.0 | 34.0 |
| STANDS FOR A REASON | - | - | - | - | 4.7 | +0.0 | 0.0 | 73.3 |
| STANDS STILL | 45.3 | +0.0 | 1151.3 | 255.3 | 18.7 | +0.0 | 50.3 | 134.0 |
| STAY WORTH | 29.0 | +204.8 | 438.3 | 178.0 | 12.3 | +340.1 | 0.0 | 36.7 |
| STRIKE BY THE ODDS | 0.3 | +10.3 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.7 | +578.7 | 0.0 | 196.0 | 8.0 | +1101.6 | 0.0 | 116.7 |
| SUPPORT NARROWED | 1.3 | +0.0 | 83.3 | 50.3 | 1.3 | +0.0 | 73.7 | 34.0 |
| SUPPORT WORKED OUT | 8.7 | +578.7 | 0.0 | 196.0 | 8.0 | +1101.6 | 0.0 | 116.7 |
| SURE REACH TOGETHER | 1.0 | +36.2 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +8.3 | 0.0 | 18.3 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -5.2 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 77.3 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 40.0 |
| THE ROW READS HIS LAST RUN | 2.7 | +0.0 | 0.0 | 98.0 | - | - | - | - |
| THE STEP BACK IS MADE | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 46.7 | +0.0 | 0.0 | 303.0 | 34.0 | +0.0 | 0.0 | 390.3 |
| TIED UP BY THE SUM | 0.7 | +61.8 | 60.0 | 0.0 | 0.3 | +32.0 | 23.3 | 0.0 |
| TIME ON OUR SIDE | 44.0 | +541.9 | 0.0 | 357.0 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 3.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | -15.3 | 114.3 | 50.3 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -146.3 | 0.0 | 0.0 | 7.0 | -1687.1 | 0.0 | 428.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 5.7 | +201.3 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 175 | 175 | 127 | 42.33 | +1619 | +12.7 |
| HIS SHOT LIST | 248 | 238 | 62 | 20.67 | +3129 | +50.5 |
| HIS SHOTS BY HIS RUN | 272 | 261 | 49 | 16.33 | +459 | +9.4 |
| HOLDER ASSIGNMENT | 42 | 42 | 35 | 11.67 | +1929 | +55.1 |
| LEGAL CHARGES ONLY | 34 | 34 | 34 | 11.33 | +0 | +0.0 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -993 | -33.1 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| SHOT RISK POINTS | 166 | 160 | 27 | 9.00 | +1610 | +59.6 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| MOVE TO CHARGE COMPUTED | 39 | 36 | 25 | 8.33 | +1161 | +46.5 |
| FIVE ACTION | 519 | 506 | 22 | 7.33 | +1452 | +66.0 |
| QUARTER ODDS | 131 | 130 | 20 | 6.67 | +1473 | +73.6 |
| NEXT CHARGE BY LIST | 28 | 27 | 19 | 6.33 | +1058 | +55.7 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 49 | 49 | 13 | 4.33 | -1052 | -81.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 123 | 119 | 11 | 3.67 | +1660 | +150.9 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SUPPORT ADDS | 50 | 49 | 11 | 3.67 | +541 | +49.2 |
| SUPPORT WORKED OUT | 50 | 49 | 11 | 3.67 | +541 | +49.2 |
| FOUR ROUNDS | 19 | 18 | 10 | 3.33 | +437 | +43.7 |
| COVER ONCE | 52 | 33 | 9 | 3.00 | +321 | +35.7 |
| THE RISK READS HIS RUN | 18 | 18 | 9 | 3.00 | +0 | +0.0 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| CANNON PLANNED TARGET | 20 | 20 | 7 | 2.33 | +30 | +4.4 |
| SHOTS IN THE MOVE | 88 | 73 | 7 | 2.33 | +682 | +97.4 |
| TIME ON OUR SIDE | 132 | 114 | 7 | 2.33 | +42 | +6.0 |
| WHOLE FIGHT DANGER | 26 | 25 | 7 | 2.33 | +988 | +141.2 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +711 | +118.6 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 6 | 2.00 | +576 | +96.0 |
| SUPPORT NARROWED | 8 | 8 | 6 | 2.00 | -524 | -87.4 |
| ASSAILMENT BY POINTS | 5 | 5 | 5 | 1.67 | +24 | +4.7 |
| EVASIVE BY THE ODDS | 8 | 8 | 5 | 1.67 | +11 | +2.1 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| NEARER NOT NEEDED | 46 | 41 | 5 | 1.67 | +155 | +31.0 |
| STAY WORTH | 124 | 114 | 5 | 1.67 | +92 | +18.4 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +43 | +10.7 |
| GOAL WALK | 38 | 37 | 4 | 1.33 | +265 | +66.2 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 4 | 1.33 | +226 | +56.6 |
| REDIRECT COUNTER | 5 | 5 | 4 | 1.33 | +336 | +84.0 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RISK BY ARC | 18 | 17 | 4 | 1.33 | +64 | +16.0 |
| SET UP BY THE SET | 13 | 11 | 4 | 1.33 | +61 | +15.3 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +134 | +44.8 |
| MAX FOR POSITIONING | 14 | 10 | 3 | 1.00 | +7 | +2.3 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +83 | +27.8 |
| EDGE GIVE GROUND | 3 | 3 | 2 | 0.67 | +271 | +135.4 |
| EXACT ROUND | 10 | 10 | 2 | 0.67 | +21 | +10.6 |
| FALL BACK GOOD ORDER | 11 | 11 | 2 | 0.67 | +21 | +10.6 |
| FALLS SHORT | 64 | 54 | 2 | 0.67 | +43 | +21.4 |
| IDLE COST | 36 | 25 | 2 | 0.67 | +0 | +0.2 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -81 | -40.4 |
| NO DOUBLE ROUNDS | 18 | 17 | 2 | 0.67 | +102 | +50.8 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -7 | -3.4 |
| REFUSING RETIRES | 5 | 5 | 2 | 0.67 | -22 | -11.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +20 | +9.8 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +25 | +12.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -309 | -308.7 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -89 | -88.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +32 | +32.2 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +29 | +28.7 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -59 | -58.9 |
| LONG SHOT | 2 | 2 | 1 | 0.33 | +30 | +30.2 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +1 | +0.6 |
| MISSILES IN THE MOVE | 26 | 18 | 1 | 0.33 | +5 | +4.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +29 | +29.2 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +28 | +28.5 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | -143 | -142.9 |
| REFORMS TO MEET IT | 12 | 12 | 1 | 0.33 | +27 | +27.2 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +124 | +124.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +18 | +18.1 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS AFTER THE MOVES | 21 | 21 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +31 | +31.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 3 | 2 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 21 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +16 | +16.1 |
| WOUNDS ON THE RANKS | 17 | 17 | 1 | 0.33 | +24 | +24.3 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTING BLOCK | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 12 | 12 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 39 | 39 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 45 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 22 | 21 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 13 | 12 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 78 | 74 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 24 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 23 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 37 | 35 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 34 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 36 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 1 | 1 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 67 | 67 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 11 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 35 | 27 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 42 | 24 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 18 | 11 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 248 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 16 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 3 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 44 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 50 | 49 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 192 | 185 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 242 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 14 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 4.00 | 5.00 | 72.0 |
| JOB FIRST | gate | 4.67 | 3.33 | 35.0 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 1.00 | 81.0 |
| SUPPORT NARROWED | rule | 0.67 | 1.33 | 87.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 26.5 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 3.5 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.67 | 26.0 |
| MARCH OF THE TABLE | rule | 0.67 | - | 40.4 |
| NO REASON | gate | - | 0.67 | 23.8 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 3.4 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 11.1 |
| BEST PRIZE | rule | 0.33 | - | 308.7 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 88.7 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| FALLBACK | gate | - | 0.33 | 17.5 |
| JOINT CHARGE NOW | rule | - | 0.33 | 58.9 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 142.9 |
| RULE SWITCHED OFF | gate | 0.33 | - | 35.9 |
| SET UP BY THE SET | rule | 0.33 | - | 11.6 |

### Plans: cnsr-c940641-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 33% | 674 | 153 | 23% |
| Mine | move | 32.3 | 97% | 1732 | 0 | 0% |
| Mine | shoot | 7.7 | 78% | 409 | 335 | 82% |
| Opponent | charge | 3.0 | 44% | 320 | 269 | 84% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 31.3 | 93% | 2580 | 0 | 0% |
| Opponent | shoot | 4.0 | 42% | 346 | 156 | 45% |
| Opponent | support | 0.3 | 0% | 11 | 0 | 0% |

### Battle groups: cnsr-c940641-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 40% | 100% | 0% | - | 0% | 0% | 50% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 72 (8) | 72 | 0 | 0 | 0% | 2.6 | 42 (6) | 160 (2) | - | 24 (2) | 85 (6) |
| Mine | Clean-up | 3 | 54 (3) | 0 | 54 | 37 | 0% | 2.0 | 85 (2) | 0 (1) | - | 85 (2) | 0 (1) |
| Mine | Fast Hammer | 7 | 9 (7) | 0 | 9 | 57 | 43% | 4.0 | 0 (3) | 20 (3) | 0 (1) | 0 (2) | 12 (5) |
| Mine | Holder | 2 | 78 (2) | 0 | 78 | 0 | 50% | 4.0 | 78 (2) | - | - | 78 (2) | - |
| Mine | Shooter | 5 | 28 (5) | 28 | 0 | 19 | 0% | 1.4 | 35 (4) | 0 (1) | - | 35 (4) | 0 (1) |
| Mine | War machine | 4 | 76 (4) | 76 | 0 | 25 | 0% | 1.0 | 151 (2) | 0 (2) | - | 0 (2) | 151 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 67% | 5.0 | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 10 (9) | 10 | 0 | 39 | 0% | 2.7 | 6 (3) | 20 (4) | - | 47 (2) | 0 (5) |
| Opponent | Clean-up | 3 | 46 (3) | 46 | 0 | 62 | 0% | 3.0 | - | 46 (3) | - | 148 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 26 (3) | 0 | 26 | 49 | 0% | 2.7 | 114 (1) | 0 (2) | - | 0 (1) | 50 (2) |
| Opponent | Hammer | 8 | 34 (8) | 34 | 0 | 41 | 38% | 2.8 | 0 (4) | 84 (2) | 65 (2) | 24 (5) | 56 (3) |
| Opponent | Holder | 3 | 15 (3) | 0 | 15 | 29 | 67% | 3.0 | - | 0 (2) | 42 (1) | 0 (1) | 23 (2) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 30 | 0% | 1.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 117 | 0% | 1.3 | 0 (1) | - | - | - | 0 (1) |

### Charged fights: cnsr-c940641-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 234 | 487 | 3.3 | 1.0 | 146 | 30 | +116 | 5 of 10 | 6 of 10 | - | +116 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 70 | 3.0 | 1.0 | 23 | 135 | -112 | 1 of 3 | 1 of 3 | - | -112 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 0 | 313 | 4.0 | 1.0 | 78 | 26 | +53 | 2 of 4 | 3 of 4 | - | +53 |
| **Opponent** | all armies | 3 | 0 | 128 | 2.7 | 1.0 | 48 | 63 | -16 | 4 of 8 | 4 of 8 | - | -16 |

### Effective charges: cnsr-c940641-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 10 | 1 (net -151) | 0 | 2 (net -76) | 3 (net +302) | 0 | 1 (net +0) | 3 | 29% (2 of 7) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 1 (net +70) | 0 | 2 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 4 | 1 (net -102) | 1 (net +162) | 0 | 1 (net +151) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: cnsr-c940641-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 151 | 116 | -151 | 77 | 151 | -74 | -48.8 |
| Mine | Effective (55-75%) | 2 | 320 | 158 | -76 | 14 | 109 | -95 | -29.5 |
| Mine | 76-89% | 3 | 444 | 220 | +302 | 395 | 19 | +376 | +84.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 3 | 395 | 221 | +185 | 238 | 42 | +196 | +49.7 |
| Mine | All fights | 10 | 355 | 188 | +116 | 200 | 55 | +145 | +40.9 |
| Opponent | Long shot (under 50%) | 2 | 111 | 374 | -51 | 62 | 51 | +11 | +9.7 |
| Opponent | 50-54% | 1 | 125 | 162 | +162 | 162 | 0 | +162 | +129.6 |
| Opponent | 76-89% | 1 | 102 | 151 | +151 | 151 | 0 | +151 | +148.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 400 | +0 | 286 | 0 | +286 | +57.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 350 | 70 | +70 | 70 | 0 | +70 | +20.0 |
| Opponent | No odds | 2 | 202 | 238 | -202 | 73 | 202 | -129 | -63.8 |
| Opponent | All fights | 8 | 213 | 251 | -16 | 117 | 63 | +54 | +25.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p8 | move | 26 | 6 (23%) | 4 (15%) | 5 (19%) | 15 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

# Doctrine scorecard: cnsr-c940641-p29

### Scorecard: cnsr-c940641-p29

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 497 |
| L0717 | 3 | 1 | Opponent | yes | 3 | 3 | 1 | 0 | 1 | 0 | 0 | 141 |
| L0733 | 1 | 1 | Mine | no | 8 | 4 | 0 | 2 | 1 | 0 | 0 | 295 |
| L0733 | 1 | 1 | Opponent | no | 2 | 4 | 0 | 5 | 0 | 0 | 0 | 405 |
| L0823 | 1 | 1 | Mine | no | 21 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 195 |
| **Average** | | | Mine | 0% | 11.0 | 4.0 | 0.0 | 1.3 | 0.3 | 0.0 | 0.0 | 435.7 |
| **Average** | | | Opponent | 33% | 1.7 | 3.0 | 1.0 | 2.3 | 0.3 | 0.0 | 0.0 | 247.0 |

### KPIs: cnsr-c940641-p29

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 94% (15 of 16) | 0% (0 of 10) | 58% (15 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% | 100% (6 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 58% (7 of 12) | 25% (3 of 12) | 42% (10 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 70% (7 of 10) | 43% (3 of 7) | 59% (10 of 17) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 71% (4247 of 5998) | 68% (4093 of 6000) | 70% (8340 of 11998) |
|   infantry points that never fought | lower | 48% (344 of 715) | 83% (1173 of 1418) | 71% (1517 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (18 of 30) | 64% (14 of 22) | 62% (32 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2776 of 5389) | 52% (2591 of 5023) | 52% (5367 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (33%) | 1.0 (21%) |
| MARCHED: its unit marched | 1.0 (60%) | 0.3 (11%) | 1.3 (29%) |
| IN COMBAT: engaged in combat | 0.3 (20%) | 0.3 (11%) | 0.7 (14%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (11%) | 0.3 (7%) |
| GONE: slain | 0.3 (20%) | 1.0 (33%) | 1.3 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 1.0 | 3.3 | 0.3 | 0.7 |
| not cast | 5.3 | 1.0 | 4.7 | 1.7 | 11.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (33%) | 1.0 (21%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (29%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (33%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.7 (12%) | 0.0 (0%) | 0.3 (7%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 2.3 (44%) | 0.3 (33%) | 1.3 (29%) | 1.0 (60%) | 1.3 (12%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.7 (85%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 74% (73 of 98) | 64% (58 of 91) | 69% (131 of 189) |
|   cavalry | 75% (9 of 12) | 60% (9 of 15) | 67% (18 of 27) |
|   character | - | 44% (8 of 18) | 44% (8 of 18) |
|   chariot | 100% (2 of 2) | - | 100% (2 of 2) |
|   infantry | 67% (16 of 24) | 77% (40 of 52) | 74% (56 of 76) |
|   monster | - | 17% (1 of 6) | 17% (1 of 6) |
|   war machine | 77% (46 of 60) | - | 77% (46 of 60) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (36%) | 1.0 (9%) | 4.0 (21%) |
| CHARGED: it charged | 0.0 (0%) | 3.0 (27%) | 3.0 (16%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (6%) | 0.7 (3%) |
| MOVED: a war machine that moved | 1.3 (16%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET IN RANGE | 0.3 (4%) | 2.3 (21%) | 2.7 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.3 (12%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (16%) | 2.3 (21%) | 3.7 (19%) |
| SHELTERED: the target was sheltered | 1.7 (20%) | 0.0 (0%) | 1.7 (9%) |
| OTHER BAR | 0.7 (8%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.0 | 3.0 | 78% | 8.5 pts | 77 pts |
| character | 2.7 | 1.0 | 75% | 13.9 pts | 37 pts |
| chariot | 0.7 | 0.7 | 50% | 48.9 pts | 33 pts |
| infantry | 27.0 | 6.3 | 84% | 5.2 pts | 139 pts |
| monster | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 15.3 | 13.0 | 61% | 34.9 pts | 535 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 4.3 | 2.3 |
| Charges that made contact a game | 0.3 | 2.3 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.04 declared, 0.04 contact (23 units) | 0.45 declared, 0.24 contact (29 units) | 0.27 declared, 0.15 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (6 of 9) | 0% (0 of 3) | - | 50% (6 of 12) |
| Character in a unit | 83% (5 of 6) | - | - | 83% (5 of 6) |
| Character on its own | 100% (3 of 3) | 100% (1 of 1) | 14% (1 of 7) | 45% (5 of 11) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | 67% (2 of 3) | 0% (0 of 1) | 33% (2 of 6) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (1 of 1); on the table 100% | 58% (7 of 12) | 71% | 60% (18 of 30) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 33% (1 of 3); 0.3 uses a game |
| Lizardmen | 1 | - | - | 80% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 45% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 80% | 80% (8 of 10) | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p29, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | - | 33% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnsr-c940641-p29

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 70% (7 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 14% (9 of 64) | 70% (7 of 10) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 33% (3 of 9) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 1.3 | 2.3 |
| Movement | Points that never moved of their own | 435.7 | 247.0 |
| Movement | Fights charged into per game | 0.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 1, net -380 | 3 of 6, net -132 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 1 of 6, net +110 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 6, net +265 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 21.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 73% (22 of 30) | 51% (32 of 63) |
| Shooting | Points destroyed by shooting units | 77.7 | 15.0 |
| Shooting | War machine shots | 15.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 74% (34 of 46) | - |
| Shooting | Points destroyed by war machines | 163.7 | 0.0 |
| Magic | Magic missiles cast | 2.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (2 of 6) | 67% (2 of 3) |
| Magic | Wounds caused by magic missiles | 8.0 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 209.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.0 / 0.3 / 0.0 | 1.3 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 160.3 | 280.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -228 | +3 |
| Combat | Net per 100 charger points, damage counted | -125.7 | +1.2 |
| Combat | First round won (charged fights) | 0% | 33% |
| Combat | Net points per charged fight | -380 | -4 |
| Combat | Net points per supported fight / lone fight | - / -380 | -70 / +10 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 5 of 6 |
| Game | Points lost | 383.3 | 646.7 |
| Game | VP from objectives | 1026.7 | 806.7 |
| Game | Lone holders (player turns) | 11.0 | 1.7 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +525 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1030
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p29

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 21.0 | -17.7 | 0.0 | 183.3 | 23.3 | +386.7 | 0.0 | 491.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -104.3 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 163.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 14.7 | +1464.7 | 713.0 | 176.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +74.0 | 69.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +68.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -2.1 | 0.0 | 0.0 | 1.0 | -0.8 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 21.0 | -930.5 | 0.0 | 36.7 | 21.0 | -1599.7 | 0.0 | 258.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 69.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 4.7 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 0.0 | 186.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 88.3 | - | - | - | - |
| COVER ONCE | 12.3 | -543.6 | 0.0 | 36.7 | 8.0 | -462.4 | 0.0 | 92.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -4.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 65.0 |
| EXACT ROUND | - | - | - | - | 2.7 | +65.8 | 88.3 | 110.3 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +3.3 | 88.3 | 65.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 18.0 | +183.4 | 0.0 | 189.3 |
| FEATURE BUFFS | 0.7 | +13.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.7 | +28.4 | 0.0 | 65.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 119.3 | +11166.9 | 1859.0 | 500.0 | 83.0 | +5328.1 | 155.0 | 986.3 |
| FLANK NOT WEIGHED | 12.7 | +0.0 | 0.0 | 88.3 | 8.7 | +0.0 | 0.0 | 163.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +227.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.3 | +94.4 | 0.0 | 0.0 | 3.3 | +333.6 | 125.0 | 110.3 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 23.3 |
| FRIEND SHOOTS FIRST | 2.7 | -135.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -2.4 | 0.0 | 65.0 |
| GOAL WALK | 8.7 | +659.6 | 0.0 | 0.0 | 15.3 | +1123.9 | 0.0 | 129.3 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 4.3 | +177.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 13.0 | +0.0 | 0.0 | 36.7 | 15.0 | +0.0 | 0.0 | 200.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +8.9 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 58.3 |
| HIS LEGAL MOVES | 9.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -8.7 | 0.0 | 0.0 | 3.0 | -52.9 | 0.0 | 58.3 |
| HIS ONE QUARTER | 8.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 129.7 |
| HIS OWN BEST MOVE | 11.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.0 | +2055.4 | 0.0 | 110.0 | 59.3 | +3274.2 | 0.0 | 701.0 |
| HIS SHOTS BY HIS RUN | 42.0 | +1078.3 | 0.0 | 146.7 | 45.7 | +2101.3 | 0.0 | 601.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +8.9 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 25.7 | +0.0 | 0.0 | 0.0 | 21.0 | +0.0 | 0.0 | 44.0 |
| HOLDER ASSIGNMENT | 16.7 | +1407.2 | 0.0 | 0.0 | 15.0 | +1146.4 | 0.0 | 44.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 2.3 | -106.4 | 125.0 | 65.0 |
| HORN WORTH | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +4.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 14.3 | -220.2 | 0.0 | 194.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +37.7 | 0.0 | 23.3 |
| KEEP FALLS | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 44.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 26.3 | 556.7 | 19.3 | +0.0 | 236.7 | 83.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +14.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 2.0 | +3.9 | 36.7 | 110.3 |
| MAKE SURE TOGETHER | 1.0 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +74.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.7 | +20.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -31.6 | 0.0 | 0.0 | 0.3 | +13.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 44.0 |
| MAX FOR POSITIONING | 2.7 | +85.1 | 0.0 | 0.0 | 1.0 | +5.0 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +173.2 | 0.0 | 0.0 | 2.7 | +29.8 | 0.0 | 147.3 |
| MISSILES NEXT TURN | 3.0 | +100.1 | 0.0 | 0.0 | 3.0 | +26.1 | 0.0 | 147.3 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 6.3 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +493.6 | 0.0 | 0.0 | 3.0 | +325.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +314.3 | 0.0 | 0.0 | 8.7 | +407.3 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 1.0 | +50.5 | 0.0 | 0.0 | 2.3 | +229.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 0.3 | -9.4 | 0.0 | 0.0 | 3.3 | -161.4 | 125.0 | 110.3 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +3.3 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 28.3 | - | - | - | - |
| OFF BEST | 4.7 | -181.9 | 0.0 | 43.3 | 3.7 | -39.7 | 0.0 | 6.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.0 | -123.2 | 0.0 | 36.7 | 3.3 | -55.1 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +19.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -78.4 | 0.0 | 0.0 | 7.0 | -81.2 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -66.5 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 44.0 |
| OPENS A LANE | 0.3 | +0.3 | 78.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +15.3 | 36.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.3 | +68.7 | 43.3 | 65.0 |
| PATHS CROSS | 0.3 | +1.5 | 0.0 | 0.0 | 0.7 | +45.1 | 0.0 | 0.0 |
| PLAN RESULT | 53.0 | +1310.5 | 772.0 | 406.7 | 39.0 | +200.4 | 110.0 | 694.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -54.9 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -64.2 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| QUARTER ODDS | 38.3 | +3495.7 | 499.7 | 463.3 | 19.3 | +2644.5 | 125.0 | 240.7 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 44.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 2.7 | +100.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.0 | +112.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 4.0 | +77.1 | 0.0 | 41.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.7 | -29.2 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 0.3 | -23.6 | 0.0 | 0.0 | 2.0 | -283.0 | 43.3 | 87.0 |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -30.4 | 80.0 | 65.0 |
| RUN DOWN | - | - | - | - | 2.7 | -13.4 | 125.0 | 87.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -15.6 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +16.6 | 0.0 | 0.0 | 0.7 | +1.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +1.8 | 0.0 | 0.0 | 0.7 | +25.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 25.0 | +0.0 | 0.0 | 206.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +62.1 | 69.3 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -5.2 | 0.0 | 65.0 |
| SHOT RISK POINTS | 34.0 | -305.3 | 0.0 | 146.7 | 38.7 | +403.4 | 0.0 | 539.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 26.3 | +2311.6 | 0.0 | 176.7 | 16.7 | +361.6 | 0.0 | 111.3 |
| SPELL WORTH | 0.3 | +3.1 | 28.3 | 28.3 | 2.3 | +27.0 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 127.7 |
| STANDS FOR A REASON | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 70.3 | +0.0 | 1859.0 | 390.0 | 14.0 | +0.0 | 30.0 | 66.7 |
| STAY WORTH | 46.3 | +473.2 | 1473.7 | 130.0 | 12.3 | +83.1 | 30.0 | 111.3 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +23.5 | 28.3 | 150.0 |
| SUPPORT ADDS | 2.7 | +163.2 | 0.0 | 36.7 | 1.3 | +80.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +163.2 | 0.0 | 36.7 | 1.3 | +80.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 2.0 | +13.9 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +13.7 | 0.0 | 36.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 123.3 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 69.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 2.0 | +0.0 | 0.0 | 64.7 |
| THE STEP BACK IS MADE | - | - | - | - | 2.0 | +0.0 | 0.0 | 69.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 57.0 | +0.0 | 0.0 | 280.0 | 39.3 | +0.0 | 0.0 | 403.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +74.1 | 43.3 | 0.0 |
| TIME ON OUR SIDE | 43.3 | +487.0 | 0.0 | 15.0 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -47.5 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.3 | +35.9 | 0.0 | 110.3 |
| WHO HITS BACK | 0.7 | +115.1 | 0.0 | 0.0 | 0.3 | +32.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -377.3 | 0.0 | 0.0 | 3.7 | -230.7 | 0.0 | 61.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +3.5 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 7.3 | +127.6 | 0.0 | 0.0 | 2.0 | +68.9 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p29

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 95 | 95 | 84 | 28.00 | +4280 | +51.0 |
| HIS SHOT LIST | 325 | 323 | 81 | 27.00 | +2149 | +26.5 |
| LEGAL CHARGES ONLY | 74 | 74 | 74 | 24.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 263 | 262 | 58 | 19.33 | +1373 | +23.7 |
| ARMY TABLE | 133 | 133 | 54 | 18.00 | +910 | +16.8 |
| SHOT RISK POINTS | 218 | 217 | 34 | 11.33 | +977 | +28.7 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| QUARTER ODDS | 173 | 173 | 26 | 8.67 | +2338 | +89.9 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -665 | -26.6 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| FIVE ACTION | 607 | 605 | 22 | 7.33 | +2015 | +91.6 |
| TIME ON OUR SIDE | 130 | 109 | 19 | 6.33 | +58 | +3.0 |
| MOVE TO CHARGE COMPUTED | 25 | 25 | 18 | 6.00 | +1011 | +56.2 |
| ARTILLERY RE-ROLL WEIGHED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| CHARGE LOSSES | 126 | 125 | 13 | 4.33 | +536 | +41.2 |
| GOAL WALK | 72 | 72 | 12 | 4.00 | +430 | +35.8 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +190 | +15.9 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| COVER ONCE | 61 | 39 | 7 | 2.33 | +290 | +41.4 |
| NEXT CHARGE BY LIST | 10 | 10 | 7 | 2.33 | +318 | +45.4 |
| THE RISK READS HIS RUN | 18 | 18 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOUR ROUNDS | 11 | 11 | 6 | 2.00 | +318 | +52.9 |
| SUPPORT ADDS | 12 | 12 | 6 | 2.00 | +394 | +65.7 |
| SUPPORT WORKED OUT | 12 | 12 | 6 | 2.00 | +394 | +65.7 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| PROMISE BY ITS OWN SUM | 21 | 21 | 5 | 1.67 | -165 | -32.9 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 5 | 1.67 | +33 | +6.7 |
| SHOTS IN THE MOVE | 129 | 97 | 5 | 1.67 | +319 | +63.8 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -9 | -2.2 |
| IDLE COST | 43 | 27 | 4 | 1.33 | +70 | +17.6 |
| MISSILES IN THE MOVE | 15 | 13 | 4 | 1.33 | +222 | +55.5 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 23 | 23 | 4 | 1.33 | +0 | +0.0 |
| STAY WORTH | 176 | 162 | 4 | 1.33 | +5 | +1.2 |
| CHAFF IN THE MOVE | 5 | 4 | 3 | 1.00 | +72 | +24.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +682 | +227.4 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +222 | +74.0 |
| MAX FOR POSITIONING | 11 | 10 | 3 | 1.00 | +92 | +30.8 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +140 | +46.6 |
| RISK BY ARC | 7 | 7 | 3 | 1.00 | +51 | +17.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +53 | +17.6 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +70 | +23.4 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +419 | +139.6 |
| CHARGE NOW FIRST | 4 | 4 | 2 | 0.67 | -212 | -106.2 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +113 | +56.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -200 | -99.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -232 | -116.0 |
| SURE REACH TOGETHER | 6 | 6 | 2 | 0.67 | +0 | +0.2 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +41 | +20.6 |
| THE ROW IN ITS ORDER | 14 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 19 | 19 | 2 | 0.67 | +131 | +65.5 |
| WOUNDS ON THE RANKS | 28 | 28 | 2 | 0.67 | +47 | +23.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -313 | -312.8 |
| CAST JOB | 3 | 3 | 1 | 0.33 | +22 | +22.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.4 |
| EXACT ROUND | 8 | 8 | 1 | 0.33 | +4 | +4.0 |
| FALL BACK GOOD ORDER | 6 | 6 | 1 | 0.33 | +9 | +9.4 |
| GUN MASK | 13 | 13 | 1 | 0.33 | +11 | +10.6 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +9 | +9.4 |
| HIS MOVE AND SHOT | 15 | 15 | 1 | 0.33 | +8 | +8.5 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +27 | +26.7 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +8 | +8.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +50 | +50.0 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +28 | +27.5 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -11 | -11.4 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +28 | +28.0 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -1.0 |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 1 | 0.33 | +1 | +1.0 |
| REDIRECT COUNTER | 6 | 5 | 1 | 0.33 | +17 | +17.0 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +75 | +75.2 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -142 | -142.5 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 4 | 4 | 1 | 0.33 | +4 | +4.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 44 | 44 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 56 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 54 | 52 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 64 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 16 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 84 | 83 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 17 | 16 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 45 | 44 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 44 | 44 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 52 | 51 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 140 | 140 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 7 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 26 | 26 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MANOEUVRE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 13 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 48 | 47 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 28 | 18 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 36 | 29 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 276 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 85 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 27 | 23 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 17 | 17 | 0 | 0.00 | - | - |
| STANDS STILL | 253 | 252 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 14 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 289 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 2 | 2 | 0 | 0.00 | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p29

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 3.67 | 26.6 |
| ARMY TABLE | rule | 2.00 | 1.67 | 63.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.33 | 27.4 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | - | 32.9 |
| CHAFF PASSED | rule | 0.33 | 0.67 | 2.9 |
| CHARGE NOW FIRST | rule | 0.67 | - | 106.2 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 99.8 |
| SUPPORT NARROWED | rule | 0.67 | - | 116.0 |
| BEST PRIZE | rule | - | 0.33 | 312.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 11.4 |
| PATHS CROSS | rule | - | 0.33 | 15.2 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 1.0 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 142.5 |

### Plans: cnsr-c940641-p29

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 27 | 0 | 0% |
| Mine | join | 2.7 | 88% | 40 | 0 | 0% |
| Mine | move | 32.7 | 100% | 2149 | 0 | 0% |
| Mine | shoot | 17.3 | 60% | 1608 | 1311 | 81% |
| Opponent | charge | 2.0 | 17% | 201 | 76 | 38% |
| Opponent | move | 33.0 | 93% | 1989 | 0 | 0% |
| Opponent | shoot | 2.7 | 75% | 144 | 125 | 87% |
| Opponent | support | 1.3 | 100% | 70 | 0 | 0% |

### Battle groups: cnsr-c940641-p29

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p29

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 44 (12) | 44 | 0 | 23 | 67% | 2.2 | 47 (7) | 44 (2) | 37 (3) | 52 (7) | 28 (5) |
| Mine | Clean-up | 1 | 164 (1) | 0 | 164 | 0 | 100% | - | - | 164 (1) | - | 164 (1) | - |
| Mine | Fast Hammer | 8 | 51 (8) | 13 | 39 | 7 | 62% | 3.3 | 79 (4) | 18 (3) | 25 (1) | 68 (4) | 33 (4) |
| Mine | Hammer | 2 | 90 (2) | 47 | 42 | 42 | 0% | 1.5 | - | 0 (1) | 154 (1) | 90 (2) | - |
| Mine | Shooter | 5 | 110 (5) | 8 | 102 | 0 | 0% | 2.0 | 39 (2) | 220 (1) | 64 (2) | 132 (3) | 64 (2) |
| Mine | War machine | 10 | 39 (10) | 39 | 0 | 21 | 0% | 1.3 | 0 (8) | 196 (2) | - | 0 (1) | 43 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 61 | 50% | 1.0 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Opponent | Character | 9 | 38 (9) | 38 | 0 | 17 | 22% | 1.7 | 27 (1) | 27 (3) | 65 (3) | 64 (4) | 12 (3) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 28 | 67% | 6.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 5 | 11 (5) | 11 | 0 | 87 | 60% | 2.0 | 44 (1) | 0 (2) | 0 (2) | 17 (3) | 0 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (3) | - | - | - | 0 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 61 | 33% | 1.5 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Holder | 3 | 195 (3) | 23 | 172 | 31 | 0% | 2.7 | 0 (1) | 284 (2) | - | 312 (2) | 0 (1) |
| Opponent | Shooter | 7 | 99 (7) | 0 | 99 | 21 | 0% | 1.1 | 110 (2) | 119 (3) | 54 (2) | 74 (3) | 126 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cnsr-c940641-p29

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 450 | 0 | 0.3 | 1.0 | 0 | 380 | -380 | 0 of 1 | 0 of 1 | - | -380 |
| Opponent | Lizardmen | 1 | 0 | 110 | 2.0 | 1.0 | 55 | 0 | +55 | 1 of 2 | 2 of 2 | - | +55 |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 350 | 4.0 | 1.2 | 88 | 120 | -33 | 4 of 4 | 0 of 4 | -70 | -20 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 15 | 153 | 2.0 | 1.2 | 77 | 80 | -4 | 5 of 6 | 2 of 6 | -70 | +10 |

### Effective charges: cnsr-c940641-p29

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 1 (net -380) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 1 (net +0) | 1 (net +110) | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 4 | 3 (net -132) | 0 | 0 | 0 | 0 | 1 (net +265) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: cnsr-c940641-p29

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 181 | 0 | -380 | 243 | 470 | -228 | -125.7 |
| Mine | All fights | 1 | 181 | 0 | -380 | 243 | 470 | -228 | -125.7 |
| Opponent | Long shot (under 50%) | 3 | 172 | 371 | -132 | 36 | 171 | -135 | -78.7 |
| Opponent | 76-89% | 1 | 405 | 189 | +0 | 147 | 0 | +147 | +36.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 265 | +265 | 265 | 96 | +169 | +39.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 405 | 110 | +110 | 110 | 0 | +110 | +27.2 |
| Opponent | All fights | 6 | 293 | 280 | -4 | 105 | 101 | +3 | +1.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p29 | move | 17 | 1 (6%) | 1 (6%) | 1 (6%) | 15 (88%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

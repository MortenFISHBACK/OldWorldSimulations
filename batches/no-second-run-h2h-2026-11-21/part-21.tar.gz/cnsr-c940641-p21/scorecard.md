# Doctrine scorecard: cnsr-c940641-p21

### Scorecard: cnsr-c940641-p21

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 1 | 0 | 0 | 732 |
| L1629 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 307 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 3 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 5 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.0 | 2.7 | 3.7 | 0.0 | 0.0 | 0.0 | 0.0 | 102.3 |
| **Average** | | | Opponent | 33% | 1.5 | 3.0 | 4.3 | 2.0 | 0.7 | 0.0 | 0.0 | 244.0 |

### KPIs: cnsr-c940641-p21

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 15) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (8 of 8); on the table 100% | 100% (2 of 2); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | 100% (3 of 3); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 82% (9 of 11); on the table 82% | 100% (6 of 6); on the table 100% | 88% (15 of 17); on the table 88% |
| Magic missiles tried each own turn | 50%+ | - | 42% (5 of 12) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 42% (5 of 12) | 42% (5 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 62% (5 of 8) | 62% (5 of 8) |
| Points that never fought | lower | 43% (2573 of 6000) | 40% (2392 of 5999) | 41% (4965 of 11999) |
|   infantry points that never fought | lower | 68% (900 of 1332) | 93% (795 of 855) | 78% (1695 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (12 of 20) | 60% (15 of 25) | 60% (27 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3099 of 5135) | 52% (2831 of 5430) | 56% (5930 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (86%) | 2.0 (86%) |
| MARCHED: its unit marched | - | 0.3 (14%) | 0.3 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.3 | 0.7 | 1.7 | 1.0 |
| not cast | 6.7 | 0.7 | 1.3 | 2.3 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (86%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) |
| GONE: slain | 1.0 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (10%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (70%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (42 of 74) | 12% (1 of 8) | 52% (43 of 82) |
|   cavalry | 83% (5 of 6) | 20% (1 of 5) | 55% (6 of 11) |
|   character | 18% (2 of 11) | 0% (0 of 3) | 14% (2 of 14) |
|   chariot | 33% (1 of 3) | - | 33% (1 of 3) |
|   infantry | 62% (21 of 34) | - | 62% (21 of 34) |
|   monster | 50% (7 of 14) | - | 50% (7 of 14) |
|   war machine | 100% (6 of 6) | - | 100% (6 of 6) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (12%) | 1.0 (43%) | 2.3 (18%) |
| CHARGED: it charged | 1.7 (16%) | 1.0 (43%) | 2.7 (21%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 1.3 (12%) | 0.0 (0%) | 1.3 (10%) |
| NO TARGET IN RANGE | 4.7 (44%) | 0.3 (14%) | 5.0 (38%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 0.7 | 0.7 | 50% | 38.7 pts | 26 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 10.7 | 1.7 | 84% | 6.7 pts | 71 pts |
| monster | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 2.0 | 1.3 | 67% | 18.9 pts | 38 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 5.3 | 5.2 |
| Charges that made contact a game | 3.0 | 3.0 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.50 declared, 0.00 contact (2 units) | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (4 units) | 1.33 declared, 1.00 contact (3 units) | 0.86 declared, 0.71 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.65 declared, 0.35 contact (20 units) | 0.55 declared, 0.30 contact (20 units) | 0.60 declared, 0.33 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 80% (4 of 5) | 67% (2 of 3) | 100% (2 of 2) | 80% (8 of 10) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 40% (2 of 5) | 100% (2 of 2) | 44% (4 of 9) | 50% (8 of 16) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 57% (4 of 7) | 0% (0 of 3) | - | 40% (4 of 10) |
| Monster | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 51% | 57% (4 of 7) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 50% (1 of 2); on the table 50% | - | 30% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (6 of 6); on the table 100% | - | 48% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 6) | 34% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (2 of 2); on the table 100% | 83% (5 of 6) | 43% | 53% (10 of 19) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p21, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 20% (1) | 17% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnsr-c940641-p21

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 27% (3 of 11) | 27% (4 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (7 of 16) | 0% (0 of 2) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 2) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 50% (1 of 2) |
| Strategy | Lone characters that fought | 62% (5 of 8) | 73% (8 of 11) |
| Movement | Charges halted short of contact | 0.3 | 1.0 |
| Movement | Idle units | 0.0 | 2.0 |
| Movement | Points that never moved of their own | 102.3 | 244.0 |
| Movement | Fights charged into per game | 3.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +0 | 2 of 5, net +92 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 1 of 5, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 1 of 5, net +80 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net +40 | 1 of 5, net +60 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.0 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (21 of 42) | 67% (2 of 3) |
| Shooting | Points destroyed by shooting units | 77.3 | 0.0 |
| Shooting | War machine shots | 2.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (3 of 6) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 3.0 | 3.7 |
| Magic | Wounds caused by other spells | 0.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 62.0 | 104.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 0.3 / 0.0 | 1.7 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 308.7 | 86.7 |
| Combat | Points run down | 0.0 | 110.7 |
| Combat | Net points per charged fight, damage counted | +29 | +66 |
| Combat | Net per 100 charger points, damage counted | +9.7 | +19.4 |
| Combat | First round won (charged fights) | 78% | 75% |
| Combat | Net points per charged fight | +60 | +63 |
| Combat | Net points per supported fight / lone fight | - / +60 | +0 / +72 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 9 | 0 of 8 |
| Game | Points lost | 487.7 | 431.3 |
| Game | VP from objectives | 563.3 | 733.3 |
| Game | Lone holders (player turns) | 3.0 | 1.5 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -240 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 919
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnsr-c940641-p21

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 24.0 | +157.1 | 0.0 | 118.0 | 17.7 | -166.8 | 0.0 | 152.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -9.4 | 0.0 | 0.0 | 0.3 | -2.7 | 33.3 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -89.9 | 61.7 | 0.0 |
| CANNON PLANNED TARGET | 2.0 | +56.3 | 56.7 | 66.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -40.8 | 20.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.3 | +106.1 | 0.0 | 53.3 | 1.0 | +10.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +9.4 | 0.0 | 0.0 | 0.3 | +20.2 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -3.4 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 5.7 | -185.3 | 0.0 | 142.7 | 14.3 | -826.1 | 0.0 | 414.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 77.3 | 0.0 | 1.3 | +0.0 | 102.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 80.0 | 13.0 | +0.0 | 0.0 | 95.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 56.7 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 10.3 | -686.0 | 0.0 | 113.3 | 10.3 | -982.4 | 0.0 | 38.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -3.6 | 42.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 33.3 | 6.3 | +63.8 | 0.0 | 124.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -52.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.7 | 35.7 | 0.0 |
| EXACT ROUND | 2.7 | +12.7 | 136.0 | 0.0 | 4.3 | -19.0 | 237.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.7 | +0.1 | 181.0 | 0.0 | 5.0 | +12.3 | 210.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 20.0 | +256.9 | 0.0 | 139.3 |
| FEATURE BUFFS | 1.3 | +16.2 | 0.0 | 0.0 | 2.0 | +144.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +23.9 | 0.0 | 0.0 | 0.3 | +25.0 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 38.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 78.7 | +6138.5 | 696.7 | 929.3 | 76.3 | +5534.5 | 272.7 | 720.7 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 71.3 | 10.0 | +0.0 | 0.0 | 100.7 |
| FOLLOW UP WEIGHED | 0.7 | +42.6 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.3 | +264.6 | 219.7 | 0.0 | 5.7 | +224.4 | 272.7 | 0.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 38.7 |
| FRIEND SHOOTS FIRST | 2.0 | -58.0 | 0.0 | 20.0 | - | - | - | - |
| GIVES UP | 0.3 | -0.6 | 0.0 | 0.0 | 1.0 | -26.1 | 62.3 | 0.0 |
| GOAL WALK | 8.7 | +693.0 | 0.0 | 0.0 | 8.0 | +642.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 38.7 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 0.0 | 13.0 | +0.0 | 0.0 | 376.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 20.0 | 8.0 | +0.0 | 0.0 | 77.3 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 201.3 |
| HIS MOVE AND SHOT | 1.0 | -25.6 | 0.0 | 0.0 | 3.0 | -27.9 | 0.0 | 206.0 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.0 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 231.3 |
| HIS RANDOM MOVE | 11.0 | +0.0 | 0.0 | 184.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 142.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 9.3 | +231.5 | 0.0 | 40.0 | 35.3 | +843.9 | 0.0 | 396.7 |
| HIS SHOTS BY HIS RUN | 9.3 | +111.1 | 0.0 | 73.3 | 34.7 | +674.6 | 0.0 | 566.7 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +53.3 | 102.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 9.3 | +0.0 | 0.0 | 263.3 | 14.7 | +0.0 | 0.0 | 167.3 |
| HOLDER ASSIGNMENT | 7.0 | +548.7 | 0.0 | 201.7 | 8.3 | +748.4 | 0.0 | 83.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -95.2 | 142.3 | 0.0 | 4.7 | -238.9 | 230.7 | 0.0 |
| HUNT IN PAIRS | 1.3 | +40.1 | 0.0 | 0.0 | 0.3 | +2.8 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 11.7 | -153.4 | 0.0 | 53.7 |
| JOINT CHARGE NOW | 1.7 | +64.5 | 77.3 | 0.0 | 2.0 | +86.9 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.7 | +0.0 | 102.0 | 80.0 | 5.7 | +0.0 | 104.7 | 377.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +9.8 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +0.1 | 58.7 | 0.0 | 2.7 | +4.6 | 61.7 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.7 | 42.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.3 | +0.0 | 0.0 | 26.7 | - | - | - | - |
| MAKE SURE TOGETHER | 1.0 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.7 | -3.1 | 0.0 | 80.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +109.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +53.0 | 0.0 | 0.0 | 0.7 | -43.9 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +16.7 | 0.0 | 66.3 | 4.0 | +148.4 | 0.0 | 15.0 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +28.1 | 0.0 | 132.7 | 2.7 | +60.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +26.3 | 0.0 | 66.3 | 3.7 | +48.1 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 11.3 | +944.8 | 0.0 | 76.7 | 9.7 | +576.5 | 0.0 | 231.3 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.3 | +380.3 | 0.0 | 202.3 | 5.0 | +239.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 7.7 | +842.7 | 0.0 | 0.0 | 7.3 | +388.7 | 0.0 | 107.3 |
| NEXT OBJECTIVE NEARER | 0.7 | -6.1 | 0.0 | 71.3 | 0.3 | -1.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.0 | -197.8 | 199.7 | 0.0 | 4.0 | -53.8 | 211.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -165.2 | 0.0 | 0.0 | 4.0 | -156.3 | 26.7 | 38.7 |
| ONE CHALLENGE TEST | 0.3 | -2.1 | 38.7 | 0.0 | 0.3 | +24.1 | 61.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -174.1 | 0.0 | 38.3 | 7.7 | -132.9 | 0.0 | 115.7 |
| ONE JOINT FIGURE | 0.3 | +8.2 | 38.7 | 0.0 | 0.3 | +3.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | +13.3 | 0.0 | 201.7 | 3.7 | -9.9 | 0.0 | 83.7 |
| ONE PROMISE A TARGET | 0.7 | -1.8 | 0.0 | 0.0 | 2.0 | -33.3 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +49.7 | 38.7 | 0.0 | 1.7 | +122.1 | 149.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +24.5 | 38.7 | 0.0 | 1.7 | +11.6 | 150.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +6.1 | 0.0 | 0.0 |
| PLAN RESULT | 37.3 | +451.1 | 252.7 | 679.7 | 39.0 | +170.2 | 185.7 | 660.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| PROMISE BY ITS OWN SUM | 11.7 | -207.4 | 0.0 | 76.7 | 11.0 | -300.3 | 0.0 | 201.3 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | -2.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -6.2 | 0.0 | 20.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -27.0 | 113.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 19.0 | +2491.5 | 167.3 | 362.7 | 21.7 | +2192.6 | 115.0 | 83.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +90.7 | 0.0 | 283.3 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -12.7 | 0.0 | 0.0 | 1.0 | +9.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +79.0 | 0.0 | 53.3 | 3.0 | +307.7 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +24.2 | 0.0 | 53.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 1.3 | +75.1 | 140.3 | 0.0 | 0.3 | -2.7 | 33.3 | 0.0 |
| REFORMS TO MEET IT | 3.7 | -34.5 | 0.0 | 76.7 | 0.7 | -34.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +13.9 | 0.0 | 26.7 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.3 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.7 | -3.6 | 181.0 | 0.0 | 5.7 | +230.5 | 272.7 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -13.6 | 83.7 | 0.0 | 2.3 | -55.6 | 157.3 | 0.0 |
| RUN DOWN | 3.3 | -90.1 | 199.7 | 0.0 | 4.3 | -30.2 | 239.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -65.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +14.8 | 0.0 | 71.3 | - | - | - | - |
| SECOND LOOK | 0.7 | +13.2 | 0.0 | 0.0 | 0.7 | +13.4 | 26.7 | 0.0 |
| SELF MOVE SPELL | 2.0 | +33.9 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -9.6 | 0.0 | 20.0 | 5.0 | -144.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +52.7 | 0.0 | 20.0 | 5.7 | +241.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 173.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +42.3 | 107.3 | 209.3 | 1.3 | +21.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.9 | 0.0 | 0.0 |
| SHOT RISK POINTS | 8.3 | -33.8 | 0.0 | 86.7 | 20.3 | -194.4 | 0.0 | 453.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 11.0 | +280.6 | 0.0 | 236.0 | 0.7 | +17.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +17.0 | 0.0 | 0.0 | 2.0 | +8.9 | 40.0 | 40.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 71.3 | 9.3 | +0.0 | 0.0 | 316.3 |
| STAND AND SHOOT | - | - | - | - | 1.7 | -33.6 | 183.7 | 0.0 |
| STANDS STILL | 29.3 | +0.0 | 477.0 | 619.3 | 17.0 | +0.0 | 0.0 | 247.3 |
| STAY WORTH | 11.7 | -53.5 | 274.3 | 176.7 | 0.3 | +5.0 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +13.2 | 83.7 | 0.0 | 0.3 | -89.9 | 61.7 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +3.4 | 56.7 | 71.3 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.0 | +389.9 | 0.0 | 46.7 | 13.7 | +1145.8 | 0.0 | 77.3 |
| SUPPORT NARROWED | 1.0 | +0.0 | 77.3 | 38.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 6.0 | +389.9 | 0.0 | 46.7 | 13.7 | +1145.8 | 0.0 | 77.3 |
| SURE REACH TOGETHER | 1.0 | +6.0 | 0.0 | 38.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 62.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 20.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 20.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.7 | +0.0 | 0.0 | 411.7 | 36.3 | +0.0 | 0.0 | 238.0 |
| TIED UP BY THE SUM | 1.7 | +170.2 | 58.7 | 0.0 | 2.7 | +331.0 | 211.0 | 0.0 |
| TIME ON OUR SIDE | 43.0 | +509.0 | 0.0 | 312.3 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 26.7 | 2.3 | +0.0 | 0.0 | 68.7 |
| WHAT THE JOINER ADDS | 0.7 | -24.5 | 40.0 | 0.0 | 0.7 | -5.2 | 0.0 | 0.0 |
| WHO FIGHTS | 1.3 | +3.7 | 58.7 | 0.0 | 0.7 | -4.0 | 103.7 | 0.0 |
| WHO HITS BACK | 0.7 | +97.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +10.1 | 20.0 | 0.0 | 0.3 | -1.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -110.0 | 0.0 | 142.7 | 3.0 | -498.3 | 0.0 | 56.7 |
| WHOLE FIGHT GAIN | 0.3 | +22.1 | 38.7 | 0.0 | 0.3 | +5.3 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.3 | +7.8 | 0.0 | 0.0 | 4.0 | +93.6 | 0.0 | 167.3 |

### Rule changes: cnsr-c940641-p21

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 125 | 125 | 89 | 29.67 | +1154 | +13.0 |
| FIVE ACTION | 465 | 444 | 46 | 15.33 | +1839 | +40.0 |
| HOLDER ASSIGNMENT | 46 | 46 | 43 | 14.33 | +2444 | +56.8 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 63 | 57 | 30 | 10.00 | +1284 | +42.8 |
| HIS SHOTS BY HIS RUN | 132 | 128 | 29 | 9.67 | +109 | +3.7 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| HIS SHOT LIST | 134 | 125 | 25 | 8.33 | +284 | +11.3 |
| PROMISE BY ITS OWN SUM | 68 | 68 | 25 | 8.33 | -1523 | -60.9 |
| QUARTER ODDS | 122 | 114 | 23 | 7.67 | +1709 | +74.3 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -965 | -48.2 |
| NEXT CHARGE BY LIST | 45 | 42 | 17 | 5.67 | +1199 | +70.5 |
| SUPPORT ADDS | 59 | 55 | 17 | 5.67 | +859 | +50.5 |
| SUPPORT WORKED OUT | 59 | 55 | 17 | 5.67 | +859 | +50.5 |
| FOUR ROUNDS | 30 | 27 | 11 | 3.67 | +580 | +52.8 |
| JOINT CHARGE NOW | 11 | 11 | 11 | 3.67 | +454 | +41.3 |
| GOAL WALK | 50 | 50 | 10 | 3.33 | +641 | +64.1 |
| SHOT RISK POINTS | 86 | 84 | 10 | 3.33 | +92 | +9.2 |
| TIED UP BY THE SUM | 13 | 10 | 10 | 3.33 | +350 | +35.0 |
| TIME ON OUR SIDE | 129 | 110 | 10 | 3.33 | +32 | +3.2 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| RISK BY ARC | 28 | 25 | 9 | 3.00 | +285 | +31.6 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| ONE PROMISE A TARGET | 8 | 8 | 8 | 2.67 | -105 | -13.1 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| SET UP BY THE SET | 21 | 20 | 7 | 2.33 | +476 | +68.0 |
| THE RISK READS HIS RUN | 18 | 18 | 7 | 2.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| OPENS UP | 7 | 6 | 6 | 2.00 | +164 | +27.4 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +55 | +9.1 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 6 | 2.00 | +37 | +6.1 |
| CHARGE LOSSES | 60 | 59 | 5 | 1.67 | +579 | +115.8 |
| CHARGE NOW FIRST | 10 | 10 | 5 | 1.67 | -253 | -50.6 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 35 | 29 | 5 | 1.67 | +28 | +5.7 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 5 | 1.67 | +272 | +54.4 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 1.67 | +622 | +124.5 |
| CHAFF IN THE MOVE | 7 | 6 | 4 | 1.33 | +55 | +13.7 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 24 | 22 | 4 | 1.33 | +100 | +25.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +80 | +20.0 |
| SUPPORT NARROWED | 6 | 6 | 4 | 1.33 | -165 | -41.4 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +130 | +43.3 |
| MAX FOR POSITIONING | 18 | 15 | 3 | 1.00 | +18 | +6.1 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +18 | +6.1 |
| REDIRECT COUNTER | 13 | 11 | 3 | 1.00 | +181 | +60.4 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS IN THE MOVE | 35 | 29 | 3 | 1.00 | +40 | +13.4 |
| THE ROW IN ITS ORDER | 13 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 16 | 16 | 3 | 1.00 | +243 | +81.1 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -36 | -18.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +89 | +44.4 |
| FEATURE BUFFS | 10 | 10 | 2 | 0.67 | +208 | +104.2 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +329 | +164.4 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -81 | -40.5 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +44 | +22.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +265 | +132.7 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +48 | +24.2 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -122 | -122.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COVER ONCE | 62 | 40 | 1 | 0.33 | +9 | +8.7 |
| FALLS SHORT | 60 | 49 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +39 | +38.9 |
| HONEST WORTH | 25 | 22 | 1 | 0.33 | +0 | +0.3 |
| HUNT IN PAIRS | 5 | 3 | 1 | 0.33 | +22 | +21.5 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +16 | +16.3 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +20 | +20.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NEARER NOT NEEDED | 43 | 41 | 1 | 0.33 | +22 | +22.5 |
| NEXT OBJECTIVE NEARER | 3 | 3 | 1 | 0.33 | +10 | +10.0 |
| ONE CHALLENGE TEST | 2 | 2 | 1 | 0.33 | +20 | +19.8 |
| ONE FIGHT FORMULA | 43 | 20 | 1 | 0.33 | +2 | +1.5 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +6 | +5.8 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 1 | 0.33 | -6 | -6.1 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | +48 | +47.6 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -23 | -23.2 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +42 | +41.7 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +5 | +5.1 |
| RUN DOWN | 23 | 21 | 1 | 0.33 | +3 | +3.2 |
| STAY WORTH | 36 | 33 | 1 | 0.33 | +1 | +0.7 |
| STRIKE BY THE ODDS | 2 | 2 | 1 | 0.33 | +40 | +39.7 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +10 | +10.1 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 16 | 16 | 1 | 0.33 | +76 | +75.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 6 | 6 | 0 | 0.00 | - | - |
| CAST JOB | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 63 | 59 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 21 | 18 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 26 | 25 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 29 | 27 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 36 | 35 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 35 | 29 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 12 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 51 | 43 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 33 | 33 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 72 | 72 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 3 | 3 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 14 | 13 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 15 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 20 | 15 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 21 | 14 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 8 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 229 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 13 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 16 | 15 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 18 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 12 | 12 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 43 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 139 | 134 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 8 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 216 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 11 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p21

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 5.00 | 4.00 | 63.6 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | 3.67 | 60.9 |
| JOB FIRST | gate | 2.67 | 3.00 | 44.7 |
| ONE PROMISE A TARGET | rule | 0.67 | 1.33 | 17.4 |
| CHARGE NOW FIRST | rule | 1.00 | 0.67 | 50.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 63.2 |
| SUPPORT NARROWED | rule | 0.33 | 1.00 | 41.4 |
| NO REASON | gate | - | 1.00 | 68.5 |
| BEST PRIZE | rule | 0.33 | 0.33 | 18.2 |
| JOINT CHARGE NOW | rule | - | 0.67 | 13.5 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 40.5 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 122.4 |
| PATHS CROSS | rule | - | 0.33 | 18.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 6.1 |
| REFUSING RETIRES | rule | 0.33 | - | 23.2 |

### Plans: cnsr-c940641-p21

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 36% | 354 | 128 | 36% |
| Mine | move | 28.7 | 93% | 1850 | 0 | 0% |
| Mine | shoot | 4.7 | 43% | 359 | 323 | 90% |
| Mine | support | 0.3 | 100% | 12 | 0 | 0% |
| Opponent | charge | 3.7 | 55% | 546 | 170 | 31% |
| Opponent | join | 3.7 | 91% | 170 | 0 | 0% |
| Opponent | move | 31.0 | 96% | 2051 | 0 | 0% |
| Opponent | support | 0.7 | 100% | 7 | 0 | 0% |

### Battle groups: cnsr-c940641-p21

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 75% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 22% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p21

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 100 | 0% | 6.0 | - | - | - | - | - |
| Mine | Chaff | 2 | 75 (2) | 0 | 75 | 100 | 0% | 1.5 | 150 (1) | 0 (1) | - | 150 (1) | 0 (1) |
| Mine | Character | 8 | 30 (8) | 30 | 0 | 0 | 25% | 2.5 | 11 (4) | 72 (3) | 0 (1) | 37 (5) | 9 (3) |
| Mine | Clean-up | 1 | 70 (1) | 0 | 70 | 100 | 0% | 4.0 | 70 (1) | - | - | 70 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 34 | 0% | 2.2 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | Hammer | 3 | 46 (3) | 42 | 4 | 0 | 33% | 1.5 | 165 (1) | 6 (2) | - | 165 (1) | 6 (2) |
| Mine | Shooter | 6 | 48 (6) | 34 | 13 | 46 | 0% | 1.7 | 59 (3) | 32 (3) | - | 27 (3) | 68 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 39 | 40% | 3.3 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 33 (10) | 33 | 0 | 10 | 20% | 3.9 | 43 (4) | 30 (5) | 22 (1) | 30 (7) | 37 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 7 (6) | 0 | 7 | 32 | 50% | 3.3 | 0 (3) | 15 (3) | - | 12 (4) | 0 (2) |
| Opponent | Hammer | 5 | 60 (5) | 23 | 38 | 54 | 40% | 2.7 | 59 (3) | 63 (2) | - | 46 (4) | 126 (1) |
| Opponent | Holder | 4 | 30 (4) | 0 | 30 | 0 | 75% | 5.0 | 42 (1) | 44 (2) | - | - | 43 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Wizard | 3 | 71 (3) | 71 | 0 | 13 | 33% | 2.5 | 0 (1) | 0 (1) | 161 (1) | 161 (1) | 0 (2) |

### Charged fights: cnsr-c940641-p21

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 232 | 421 | 3.0 | 1.0 | 140 | 0 | +140 | 2 of 3 | 2 of 3 | - | +140 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 170 | 2.0 | 1.0 | 85 | 107 | -22 | 0 of 2 | 2 of 2 | - | -22 |
| Mine | Lizardmen | 1 | 186 | 165 | 4.0 | 1.0 | 41 | 0 | +41 | 1 of 4 | 3 of 4 | - | +41 |
| **Mine** | all armies | 3 | 139 | 252 | 3.0 | 1.0 | 84 | 24 | +60 | 3 of 9 | 7 of 9 | - | +60 |
| Opponent | Vampire Counts | 1 | 0 | 185 | 3.0 | 1.3 | 62 | 0 | +62 | 0 of 3 | 2 of 3 | +0 | +92 |
| Opponent | Warriors of Chaos | 2 | 157 | 160 | 2.5 | 1.0 | 64 | 0 | +64 | 0 of 5 | 4 of 5 | - | +64 |
| **Opponent** | all armies | 3 | 105 | 168 | 2.7 | 1.1 | 63 | 0 | +63 | 0 of 8 | 6 of 8 | +0 | +72 |

### Effective charges: cnsr-c940641-p21

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 0 | 0 | 0 | 1 (net +251) | 0 | 1 (net +0) | 1 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +60) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 3 | 2 (net +92) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 5 | 0 | 0 | 1 (net +0) | 0 | 1 (net +80) | 1 (net +60) | 2 | 33% (1 of 3) |

### Charged fights, damage counted: cnsr-c940641-p21

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 185 | 380 | +0 | 95 | 92 | +2 | +1.4 |
| Mine | 76-89% | 1 | 497 | 201 | +251 | 251 | 276 | -25 | -5.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 249 | 107 | +40 | 52 | 48 | +4 | +1.8 |
| Mine | No odds | 4 | 322 | 148 | +43 | 122 | 54 | +68 | +21.3 |
| Mine | All fights | 9 | 302 | 166 | +60 | 110 | 81 | +29 | +9.7 |
| Opponent | Long shot (under 50%) | 2 | 286 | 155 | +92 | 114 | 29 | +85 | +29.8 |
| Opponent | Effective (55-75%) | 1 | 205 | 275 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 116 | 60 | +60 | 60 | 39 | +21 | +18.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 494 | 80 | +80 | 80 | 0 | +80 | +16.2 |
| Opponent | No odds | 3 | 443 | 88 | +60 | 85 | 0 | +85 | +19.3 |
| Opponent | All fights | 8 | 340 | 124 | +63 | 78 | 12 | +66 | +19.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p21 | move | 34 | 5 (15%) | 3 (9%) | 10 (29%) | 19 (56%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

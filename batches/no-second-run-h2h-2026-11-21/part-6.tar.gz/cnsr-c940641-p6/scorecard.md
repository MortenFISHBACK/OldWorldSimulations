# Doctrine scorecard: cnsr-c940641-p6

### Scorecard: cnsr-c940641-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 14 | 5 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 185 |
| L0930 | 6 | 1 | Opponent | no | 11 | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 5 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 2.3 | 3.0 | 0.7 | 0.7 | 0.0 | 0.0 | 0.0 | 311.7 |
| **Average** | | | Opponent | 0% | 8.3 | 5.0 | 0.3 | 2.7 | 0.7 | 0.0 | 0.0 | 143.3 |

### KPIs: cnsr-c940641-p6

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 38% (5 of 13) | 0% (0 of 12) | 20% (5 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 100% | 75% (3 of 4); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 44% (21 of 48) | 8% (1 of 12) | 37% (22 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (21 of 45) | 17% (1 of 6) | 43% (22 of 51) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 57% (8 of 14) | 57% (8 of 14) |
| Points that never fought | lower | 76% (4561 of 5997) | 79% (4714 of 5999) | 77% (9275 of 11996) |
|   infantry points that never fought | lower | 76% (1211 of 1591) | 88% (1456 of 1660) | 82% (2667 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (22 of 34) | 65% (15 of 23) | 65% (37 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.0 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (3627 of 5667) | 60% (3113 of 5150) | 62% (6740 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (56%) | 0.7 (18%) | 5.7 (45%) |
| MARCHED: its unit marched | 3.0 (33%) | 0.7 (18%) | 3.7 (29%) |
| IN COMBAT: engaged in combat | 1.0 (11%) | 0.0 (0%) | 1.0 (8%) |
| GONE: slain | 0.0 (0%) | 2.0 (55%) | 2.0 (16%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.0 | 3.3 | 0.7 | 7.3 | 0.3 | 0.3 |
| not cast | 2.0 | 4.7 | 1.3 | 12.7 | 1.7 | 19.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (79%) | 0.0 (0%) | 5.7 (45%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (29%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 2.0 (100%) | 0.0 (0%) | 1.3 (100%) | 2.0 (16%) | 0.0 (0%) | 4.3 (22%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (21%) | 0.0 (0%) | 0.3 (3%) | 1.7 (100%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 100% (2 of 2) | 100% (2 of 2) |
| the unit moved after it | - | 100% (2 of 2) | 100% (2 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (76 of 119) | 73% (36 of 49) | 67% (112 of 168) |
|   character | 100% (3 of 3) | 20% (2 of 10) | 38% (5 of 13) |
|   chariot | 87% (13 of 15) | 78% (7 of 9) | 83% (20 of 24) |
|   infantry | 45% (23 of 51) | 83% (15 of 18) | 55% (38 of 69) |
|   monster | 62% (8 of 13) | - | 62% (8 of 13) |
|   war machine | 78% (29 of 37) | 100% (12 of 12) | 84% (41 of 49) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (28%) | 1.7 (38%) | 5.7 (30%) |
| CHARGED: it charged | 0.7 (5%) | 0.7 (15%) | 1.3 (7%) |
| IN COMBAT: it fought this turn or the last | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.3 (9%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET IN RANGE | 4.7 (33%) | 1.3 (31%) | 6.0 (32%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (19%) | 0.3 (8%) | 3.0 (16%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (2%) | 0.3 (8%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 6.7 | 4.3 | 70% | 20.5 pts | 137 pts |
| infantry | 16.7 | 10.7 | 56% | 9.0 pts | 151 pts |
| monster | 5.3 | 0.7 | 88% | 5.5 pts | 29 pts |
| war machine | 14.0 | 13.7 | 52% | 30.9 pts | 432 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 1.0 | 1.0 |
| Charges that made contact a game | 1.0 | 1.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (20 units) | 0.13 declared, 0.13 contact (23 units) | 0.12 declared, 0.12 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (2 of 5) | - | - | 40% (2 of 5) |
| Character in a unit | 100% (6 of 6) | 100% (2 of 2) | - | 100% (8 of 8) |
| Character on its own | 100% (1 of 1) | 50% (2 of 4) | 25% (1 of 4) | 44% (4 of 9) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 36% (5 of 14) | 75% (3 of 4) | - | 44% (8 of 18) |
| Monster | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (1 of 1); on the table 100% | 42% (10 of 24) | 81% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 46% (11 of 24) | 66% | 50% (5 of 10) | 100% (2 of 2); 9.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 0% (0 of 1); on the table 100% | 17% (1 of 6) | 88% | 25% (2 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 72% | 89% (8 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | - | 76% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p6, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 67% (2) | 60% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 33% (1 of 3) | 100% (3 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 11% (6 of 53) | 62% (13 of 21) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 12% (1 of 8) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 311.7 | 143.3 |
| Movement | Fights charged into per game | 1.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 3, net -32 | 2 of 3, net +176 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.7 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (23 of 47) | 67% (18 of 27) |
| Shooting | Points destroyed by shooting units | 0.0 | 98.3 |
| Shooting | War machine shots | 9.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (15 of 29) | 25% (3 of 12) |
| Shooting | Points destroyed by war machines | 181.3 | 0.0 |
| Magic | Magic missiles cast | 4.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (5 of 14) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 12.7 | 3.3 |
| Magic | Points destroyed by magic (all spells) | 188.3 | 34.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.0 / 0.3 | 1.3 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 48.3 | 197.3 |
| Combat | Points run down | 0.0 | 45.0 |
| Combat | Net points per charged fight, damage counted | -1 | +154 |
| Combat | Net per 100 charger points, damage counted | -0.3 | +76.3 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | -32 | +162 |
| Combat | Net points per supported fight / lone fight | - / -32 | - / +162 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 1 of 3 |
| Game | Points lost | 342.0 | 564.7 |
| Game | VP from objectives | 743.3 | 903.3 |
| Game | Lone holders (player turns) | 2.3 | 8.3 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +127 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 907
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnsr-c940641-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 25.7 | +442.4 | 0.0 | 255.3 | 19.7 | +188.4 | 0.0 | 258.3 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +3.5 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 9.3 | +444.4 | 1038.7 | 125.0 | 4.0 | +65.8 | 318.7 | 0.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.3 | +196.2 | 586.0 | 0.0 | 0.7 | +11.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 266.7 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +20.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.1 | 0.0 | 0.0 | 0.3 | -2.2 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +18.2 | 0.0 | 75.7 | 0.7 | +4.3 | 0.0 | 159.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | +46.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 14.3 | -674.1 | 0.0 | 220.7 | 28.3 | -2066.2 | 0.0 | 1042.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 367.7 | 45.0 | 0.7 | +0.0 | 86.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +103.6 | 266.7 | 266.7 |
| COVER ONCE | 6.7 | -736.4 | 0.0 | 117.3 | 5.3 | -235.9 | 0.0 | 133.3 |
| DENIED BY THE FIGHT | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 0.0 | 7.0 | +37.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.6 | 41.7 | 0.0 |
| EXACT ROUND | 0.7 | +2.9 | 48.3 | 45.0 | 0.7 | +2.7 | 86.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +3.9 | 0.0 | 45.0 | 0.3 | +0.0 | 45.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 27.7 | +285.6 | 0.0 | 446.7 |
| FEATURE BUFFS | 2.0 | +38.7 | 0.0 | 0.0 | 2.7 | +44.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +1.6 | 0.0 | 0.0 | 0.3 | -0.4 | 45.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 101.7 | +8035.1 | 4655.7 | 515.7 | 97.0 | +5536.1 | 1112.0 | 1572.7 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +186.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +77.5 | 48.3 | 45.0 | 1.0 | +62.5 | 162.3 | 0.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 40.0 |
| FRIEND SHOOTS FIRST | 0.7 | -18.1 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.3 | +1437.3 | 0.0 | 0.0 | 14.0 | +1771.6 | 0.0 | 0.0 |
| GUN FIGURES | 3.0 | +20.2 | 266.7 | 0.0 | 0.7 | +0.0 | 0.0 | 21.7 |
| GUN MASK | 6.0 | +141.7 | 0.0 | 0.0 | 1.3 | +0.7 | 0.0 | 133.3 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 151.3 | 11.7 | +0.0 | 0.0 | 315.0 |
| HIS CHARGE DENIED | 0.3 | +19.3 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 69.3 | 6.0 | +0.0 | 0.0 | 48.3 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 266.7 |
| HIS MOVE AND SHOT | 1.3 | -22.6 | 0.0 | 0.0 | 5.0 | -96.2 | 0.0 | 133.3 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 266.7 |
| HIS RANDOM MOVE | 14.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 37.7 | +1175.6 | 0.0 | 220.7 | 74.3 | +6050.2 | 0.0 | 1166.7 |
| HIS SHOTS BY HIS RUN | 27.7 | +449.2 | 0.0 | 220.7 | 72.0 | +2515.4 | 0.0 | 1244.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +73.6 | 41.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.7 | +0.0 | 0.0 | 0.0 | 32.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 11.7 | +1044.9 | 0.0 | 0.0 | 17.3 | +1641.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -22.5 | 48.3 | 45.0 | 0.7 | -19.9 | 117.3 | 0.0 |
| IDLE COST | - | - | - | - | 13.0 | -278.9 | 0.0 | 698.0 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 2.7 | +0.0 | 0.0 | 1117.7 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -15.6 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 43.3 |
| LOST AFTER ESCAPE | 0.7 | +2.3 | 0.0 | 45.0 | 0.7 | +1.0 | 120.7 | 0.0 |
| MANOEUVRE | 2.7 | +23.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +35.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +29.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -214.7 | 0.0 | 0.0 | 0.3 | +29.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +57.3 | 0.0 | 0.0 | 0.3 | +4.3 | 0.0 | 133.3 |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 12.0 | +333.5 | 0.0 | 0.0 | 2.3 | +61.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 14.3 | +239.3 | 0.0 | 0.0 | 4.0 | +36.5 | 0.0 | 446.7 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 266.7 |
| MOVE TO CHARGE COMPUTED | 4.7 | +223.5 | 0.0 | 0.0 | 3.0 | +316.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 12.3 | +576.5 | 0.0 | 0.0 | 7.7 | +348.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.0 | +191.9 | 0.0 | 0.0 | 2.3 | +272.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -104.9 | 48.3 | 45.0 | 0.7 | -45.2 | 117.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -215.9 | 0.0 | 0.0 | 1.7 | -60.9 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 3.7 | +43.2 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | +46.0 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -101.2 | 0.0 | 0.0 | 4.3 | -110.5 | 0.0 | 133.3 |
| ONE OBJECTIVE FORMULA | 4.0 | -26.0 | 0.0 | 0.0 | 8.0 | +64.4 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +12.3 | 0.0 | 45.0 | 0.7 | +4.5 | 120.7 | 0.0 |
| OWN CAST FIRST | 1.0 | -8.7 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PLAN RESULT | 44.0 | +1921.8 | 1945.7 | 519.0 | 45.3 | +414.3 | 269.3 | 844.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -200.5 | 0.0 | 0.0 | 3.3 | -43.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 14.0 | +1618.2 | 43.3 | 151.3 | 19.0 | +2029.3 | 495.7 | 80.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.7 | +105.9 | 0.0 | 96.7 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | -15.2 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -53.2 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -18.8 | 48.3 | 45.0 | 1.0 | -20.4 | 162.3 | 0.0 |
| RUN DOWN | 1.0 | -16.5 | 48.3 | 45.0 | 1.0 | -11.1 | 162.3 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -152.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 16.3 | +0.0 | 0.0 | 125.0 | 7.7 | +0.0 | 0.0 | 21.7 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +159.8 | 0.0 | 0.0 | 1.0 | +12.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -70.9 | 0.0 | 0.0 | 0.7 | -27.7 | 151.3 | 0.0 |
| SHOT RISK POINTS | 12.0 | -136.7 | 0.0 | 69.3 | 44.7 | -535.6 | 0.0 | 1129.3 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 27.3 | +1431.5 | 0.0 | 200.7 | 11.3 | +282.8 | 0.0 | 43.3 |
| SPELL WORTH | - | - | - | - | 2.0 | +60.0 | 446.7 | 446.7 |
| SPELLS IN THE FIGHT | 0.3 | +1.3 | 48.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 355.0 |
| STANDS FOR A REASON | - | - | - | - | 3.0 | +0.0 | 0.0 | 180.0 |
| STANDS STILL | 46.7 | +0.0 | 4607.3 | 250.0 | 38.3 | +0.0 | 949.7 | 128.3 |
| STAY WORTH | 44.7 | +662.6 | 4474.0 | 284.7 | 20.0 | +302.0 | 798.3 | 86.7 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.7 | +31.7 | 0.0 | 0.0 | 4.0 | +222.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 45.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.7 | +31.7 | 0.0 | 0.0 | 4.0 | +222.9 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 21.7 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 40.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 21.7 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 21.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.0 | +0.0 | 0.0 | 235.3 | 47.0 | +0.0 | 0.0 | 738.0 |
| TIED UP BY THE SUM | 0.7 | +58.5 | 48.3 | 45.0 | 0.3 | +23.9 | 41.7 | 0.0 |
| TIME ON OUR SIDE | 39.3 | +589.5 | 0.0 | 49.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +0.6 | 90.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.7 | 45.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.3 | -474.9 | 0.0 | 151.3 | 3.3 | -369.8 | 0.0 | 266.7 |
| WOUNDS ON THE RANKS | 0.7 | +10.0 | 0.0 | 0.0 | 1.0 | +48.0 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 336 | 333 | 89 | 29.67 | +2183 | +24.5 |
| ARMY TABLE | 136 | 136 | 85 | 28.33 | +1799 | +21.2 |
| HOLDER ASSIGNMENT | 87 | 87 | 82 | 27.33 | +4852 | +59.2 |
| HIS SHOTS BY HIS RUN | 299 | 297 | 80 | 26.67 | +1154 | +14.4 |
| SHOT RISK POINTS | 170 | 169 | 37 | 12.33 | +1310 | +35.4 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| GOAL WALK | 70 | 69 | 22 | 7.33 | +3038 | +138.1 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -830 | -37.7 |
| CHARGE LOSSES | 128 | 126 | 16 | 5.33 | +1140 | +71.3 |
| FIVE ACTION | 596 | 591 | 16 | 5.33 | +654 | +40.9 |
| QUARTER ODDS | 99 | 99 | 14 | 4.67 | +855 | +61.0 |
| MOVE TO CHARGE COMPUTED | 23 | 22 | 13 | 4.33 | +452 | +34.8 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CAST JOB | 12 | 12 | 12 | 4.00 | +208 | +17.3 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +129 | +11.8 |
| STAY WORTH | 194 | 179 | 11 | 3.67 | +127 | +11.5 |
| NEXT CHARGE BY LIST | 19 | 18 | 10 | 3.33 | +379 | +37.9 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 10 | 3.33 | -733 | -73.3 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 14 | 14 | 8 | 2.67 | +317 | +39.7 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 8 | 2.67 | +220 | +27.6 |
| TIME ON OUR SIDE | 118 | 98 | 8 | 2.67 | +9 | +1.1 |
| SHOTS AFTER THE MOVES | 24 | 24 | 7 | 2.33 | +0 | +0.0 |
| FOUR ROUNDS | 6 | 6 | 5 | 1.67 | +193 | +38.6 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| CANNON PLANNED TARGET | 40 | 40 | 4 | 1.33 | +58 | +14.6 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 83 | 71 | 4 | 1.33 | +39 | +9.7 |
| IDLE COST | 39 | 31 | 4 | 1.33 | +51 | +12.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| THE RISK READS HIS RUN | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +67 | +22.4 |
| CHARGE NOW FIRST | 7 | 7 | 3 | 1.00 | -49 | -16.4 |
| COVER ONCE | 36 | 25 | 3 | 1.00 | +14 | +4.7 |
| FEATURE BUFFS | 14 | 14 | 3 | 1.00 | +32 | +10.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +108 | +35.9 |
| OWN CAST FIRST | 3 | 3 | 3 | 1.00 | -26 | -8.7 |
| SUPPORT ADDS | 17 | 17 | 3 | 1.00 | +37 | +12.3 |
| SUPPORT WORKED OUT | 17 | 17 | 3 | 1.00 | +37 | +12.3 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -7 | -3.4 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +559 | +279.6 |
| MISSILES IN THE MOVE | 43 | 28 | 2 | 0.67 | +8 | +3.8 |
| ONE OBJECTIVE FORMULA | 36 | 29 | 2 | 0.67 | +31 | +15.3 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +8 | +3.9 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +27 | +13.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS IN THE MOVE | 116 | 87 | 2 | 0.67 | +48 | +23.8 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +13 | +6.3 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -4 | -2.1 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +1 | +0.4 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 1 | 0.33 | +89 | +89.4 |
| EXACT ROUND | 4 | 4 | 1 | 0.33 | +5 | +5.1 |
| FALL BACK GOOD ORDER | 3 | 3 | 1 | 0.33 | +8 | +7.5 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +186 | +186.1 |
| LOST AFTER ESCAPE | 4 | 4 | 1 | 0.33 | +0 | +0.4 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +109 | +109.3 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +43 | +43.3 |
| MAX FOR POSITIONING | 15 | 15 | 1 | 0.33 | +1 | +1.1 |
| NEARER NOT NEEDED | 60 | 55 | 1 | 0.33 | +22 | +21.5 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +89 | +89.4 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -13 | -12.9 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 1 | 0.33 | -3 | -2.6 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| THE ROW IN ITS ORDER | 28 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +0 | +0.4 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 17 | 17 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 48 | 48 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 23 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| GUN MASK | 22 | 22 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 55 | 55 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 19 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 35 | 35 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 25 | 24 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 42 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 157 | 157 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 55 | 43 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 30 | 20 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 268 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | not checked | - | - | - | - |
| REFORMS TO MEET IT | 5 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 72 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 38 | 34 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 255 | 252 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 282 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 26 | 25 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 1.67 | 35.0 |
| ARMY TABLE | rule | 4.00 | 2.00 | 83.8 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 0.67 | 73.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 31.9 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 16.4 |
| OWN CAST FIRST | rule | 1.00 | - | 8.7 |
| WAR ENGINE JOBS | rule | 0.67 | - | 2.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 95.8 |
| CHAFF PASSED | rule | - | 0.33 | 6.6 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 12.9 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 2.6 |

### Plans: cnsr-c940641-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 84 | 48 | 57% |
| Mine | move | 27.7 | 99% | 2092 | 0 | 0% |
| Mine | shoot | 15.3 | 57% | 1361 | 1873 | 138% |
| Opponent | charge | 0.7 | 100% | 132 | 87 | 66% |
| Opponent | move | 37.7 | 94% | 2451 | 0 | 0% |
| Opponent | shoot | 6.0 | 72% | 300 | 328 | 109% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 16 (10) | 16 | 0 | 17 | 50% | 2.4 | 24 (6) | 0 (4) | - | 17 (7) | 13 (3) |
| Mine | Clean-up | 3 | 49 (3) | 0 | 49 | 0 | 67% | 5.0 | 0 (1) | 75 (2) | - | 49 (3) | - |
| Mine | Fast Hammer | 3 | 10 (3) | 10 | 0 | 29 | 0% | 2.7 | 14 (2) | - | 0 (1) | 10 (3) | - |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 16 | 17% | 2.0 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Shooter | 6 | 130 (6) | 0 | 130 | 17 | 0% | 1.7 | 0 (1) | 183 (3) | 115 (2) | 130 (6) | - |
| Mine | War machine | 8 | 50 (8) | 50 | 0 | 35 | 0% | 1.4 | 0 (3) | 128 (3) | 20 (2) | 383 (1) | 7 (7) |
| Mine | Wizard | 4 | 167 (4) | 167 | 0 | 0 | 50% | 1.5 | 0 (1) | 222 (3) | - | 222 (3) | 0 (1) |
| Opponent | Chaff | 2 | 264 (2) | 0 | 264 | 44 | 100% | - | 471 (1) | 0 (1) | - | 471 (1) | 0 (1) |
| Opponent | Character | 9 | 52 (9) | 42 | 9 | 53 | 56% | 1.5 | 123 (1) | 44 (7) | 0 (1) | 40 (5) | 67 (4) |
| Opponent | Clean-up | 3 | 110 (3) | 0 | 110 | 0 | 100% | - | 0 (1) | 199 (2) | - | 199 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 70 (6) | 0 | 70 | 0 | 83% | 1.0 | - | 105 (4) | 16 (2) | 70 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 0 (4) | 0 | 0 | 22 | 25% | 2.3 | - | 0 (2) | 0 (2) | 0 (4) | - |
| Opponent | Holder | 4 | 34 (4) | 34 | 0 | 0 | 50% | 3.5 | - | 34 (4) | - | 147 (1) | 0 (3) |
| Opponent | Shooter | 4 | 32 (4) | 32 | 0 | 28 | 25% | 1.7 | 0 (1) | 0 (1) | 44 (2) | 37 (3) | 0 (1) |
| Opponent | War machine | 2 | 179 (2) | 179 | 0 | 0 | 0% | 1.0 | - | - | 179 (2) | 179 (1) | 179 (1) |

### Charged fights: cnsr-c940641-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 440 | 0 | 0.5 | 1.0 | 0 | 240 | -240 | 1 of 1 | 1 of 1 | - | -240 |
| Mine | Grand Cathay | 1 | 230 | 145 | 2.0 | 1.0 | 72 | 0 | +72 | 0 of 2 | 2 of 2 | - | +72 |
| **Mine** | all armies | 3 | 370 | 48 | 1.0 | 1.0 | 48 | 80 | -32 | 1 of 3 | 3 of 3 | - | -32 |
| Opponent | High Elf Realms | 1 | 399 | 352 | 2.0 | 1.0 | 176 | 0 | +176 | 1 of 2 | 2 of 2 | - | +176 |
| Opponent | Skaven | 1 | 0 | 135 | 1.0 | 1.0 | 135 | 0 | +135 | 0 of 1 | 1 of 1 | - | +135 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 133 | 162 | 1.0 | 1.0 | 162 | 0 | +162 | 1 of 3 | 3 of 3 | - | +162 |

### Effective charges: cnsr-c940641-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -240) | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +72) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +176) | 0 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +135) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 238 | 239 | -32 | 84 | 85 | -1 | -0.3 |
| Mine | All fights | 3 | 238 | 239 | -32 | 84 | 85 | -1 | -0.3 |
| Opponent | 76-89% | 1 | 112 | 135 | +135 | 218 | 124 | +94 | +84.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 247 | 176 | +176 | 184 | 0 | +184 | +74.5 |
| Opponent | All fights | 3 | 202 | 162 | +162 | 196 | 41 | +154 | +76.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p6 | move | 19 | 3 (16%) | 3 (16%) | 0 (0%) | 16 (84%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

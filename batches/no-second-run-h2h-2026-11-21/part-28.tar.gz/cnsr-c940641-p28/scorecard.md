# Doctrine scorecard: cnsr-c940641-p28

### Scorecard: cnsr-c940641-p28

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 6 | 0 | 1 | 0 | 0 | 0 | 95 |
| L0524 | 2 | 1 | Opponent | - | - | - | 2 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 325 |
| L0612 | 6 | 1 | Opponent | no | 3 | 4 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 461 |
| L0628 | 4 | 1 | Opponent | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 351 |
| **Average** | | | Mine | 0% | 0.0 | 6.0 | 0.0 | 2.7 | 0.0 | 0.0 | 0.0 | 293.7 |
| **Average** | | | Opponent | 0% | 2.5 | 4.0 | 1.0 | 1.7 | 0.3 | 0.0 | 0.0 | 227.0 |

### KPIs: cnsr-c940641-p28

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 15) | 50% (15 of 30) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 100% (3 of 3); on the table 100% | 86% (6 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | - | 43% (13 of 30) | 43% (13 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 45% (13 of 29) | 45% (13 of 29) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 78% (4689 of 6000) | 76% (4579 of 5998) | 77% (9268 of 11998) |
|   infantry points that never fought | lower | 79% (1760 of 2232) | 100% (694 of 694) | 84% (2454 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (17 of 27) | 65% (15 of 23) | 64% (32 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 3.3 uses a game | 67% (2 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (2450 of 4232) | 72% (4182 of 5787) | 66% (6632 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (18%) | 1.0 (18%) |
| MARCHED: its unit marched | - | 4.3 (76%) | 4.3 (76%) |
| IN COMBAT: engaged in combat | - | 0.3 (6%) | 0.3 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.3 | 4.3 | 0.3 | 1.0 |
| not cast | 2.0 | 2.7 | 5.7 | 3.7 | 23.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (88%) | 1.0 (18%) | 1.0 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 4.3 (76%) | 2.0 (55%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (17%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) | 0.7 (18%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (99%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (131 of 212) | 75% (12 of 16) | 63% (143 of 228) |
|   cavalry | 38% (8 of 21) | 25% (1 of 4) | 36% (9 of 25) |
|   character | 85% (28 of 33) | - | 85% (28 of 33) |
|   infantry | 50% (27 of 54) | - | 50% (27 of 54) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |
|   war machine | 64% (59 of 92) | 92% (11 of 12) | 67% (70 of 104) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.7 (17%) | 0.3 (25%) | 5.0 (18%) |
| CHARGED: it charged | 2.0 (7%) | 0.0 (0%) | 2.0 (7%) |
| FLEEING: it fled or was fleeing | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (25%) | 0.3 (1%) |
| MOVED: a war machine that moved | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 9.7 (36%) | 0.3 (25%) | 10.0 (35%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (5%) | 0.0 (0%) | 1.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 7.3 (27%) | 0.0 (0%) | 7.3 (26%) |
| SHELTERED: the target was sheltered | 1.0 (4%) | 0.3 (25%) | 1.3 (5%) |
| OTHER BAR | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 0.3 | 89% | 3.1 pts | 9 pts |
| character | 10.3 | 7.0 | 68% | 12.5 pts | 129 pts |
| infantry | 19.0 | 5.7 | 79% | 10.4 pts | 198 pts |
| monster | 3.0 | 0.3 | 89% | 3.1 pts | 9 pts |
| war machine | 23.3 | 17.0 | 67% | 20.5 pts | 479 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 1.0 | 1.7 |
| Charges that made contact a game | 2.3 | 0.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.32 contact (22 units) | 0.23 declared, 0.15 contact (13 units) | 0.29 declared, 0.26 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | 100% (1 of 1) | 50% (1 of 2) | 43% (3 of 7) |
| Character in a unit | 57% (4 of 7) | 67% (2 of 3) | - | 60% (6 of 10) |
| Character on its own | 100% (1 of 1) | 75% (3 of 4) | 100% (3 of 3) | 88% (7 of 8) |
| Infantry | 43% (3 of 7) | 50% (3 of 6) | - | 46% (6 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 90% (9 of 10) | - | - | 90% (9 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 75% (3 of 4); on the table 75% | - | 78% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 44% (8 of 18) | 89% | 56% (5 of 9) | 67% (2 of 3); 10.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | - | 33% (2 of 6) | 94% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (3 of 3); on the table 100% | 50% (3 of 6) | 45% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p28, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (1) | 100% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.00 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnsr-c940641-p28

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (7 of 7) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 60% (40 of 67) | 32% (7 of 22) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 36% (4 of 11) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 2) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.7 | 1.7 |
| Movement | Points that never moved of their own | 293.7 | 227.0 |
| Movement | Fights charged into per game | 1.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +347 | 1 of 1, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +60 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +20 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 26.0 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (43 of 78) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 109.3 | 0.0 |
| Shooting | War machine shots | 19.7 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 66% (39 of 59) | 36% (4 of 11) |
| Shooting | Points destroyed by war machines | 0.0 | 93.3 |
| Magic | Magic missiles cast | - | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 50% (3 of 6) |
| Magic | Wounds caused by magic missiles | - | 3.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.3 / 0.3 / 1.0 / 0.3 |
| Combat | Points destroyed in combat | 172.3 | 20.0 |
| Combat | Points run down | 13.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +113 | -138 |
| Combat | Net per 100 charger points, damage counted | +71.2 | -103.2 |
| Combat | First round won (charged fights) | 75% | 0% |
| Combat | Net points per charged fight | +112 | -25 |
| Combat | Net points per supported fight / lone fight | +136 / +41 | - / -25 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 2 of 2 |
| Game | Points lost | 133.3 | 334.7 |
| Game | VP from objectives | 640.0 | 553.3 |
| Game | Lone holders (player turns) | 0.0 | 2.5 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +255 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 468
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p28

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +50.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 11.0 | +137.5 | 0.0 | 60.0 | 9.0 | +214.2 | 0.0 | 20.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 74.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 15.0 | +187.5 | 535.0 | 106.7 | 3.7 | +132.4 | 80.0 | 0.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 4.3 | +16.7 | 40.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.3 | +6.7 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +78.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -5.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.3 | -263.9 | 0.0 | 160.0 | 15.7 | -544.5 | 0.0 | 280.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 50.7 | 0.0 | 0.7 | +0.0 | 0.0 | 16.7 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 33.3 |
| COVER ONCE | 13.3 | -799.5 | 0.0 | 20.0 | 5.0 | -238.0 | 0.0 | 0.0 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 0.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -17.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +37.3 | 342.0 | 20.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| FACES THE THREAT | 0.3 | +26.2 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 37.0 | 0.0 | 1.0 | +1.0 | 0.0 | 16.7 |
| FALLBACK BY WORTH | 0.3 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 23.3 | +300.7 | 0.0 | 72.3 |
| FEATURE BUFFS | 0.7 | +0.5 | 0.0 | 0.0 | 1.3 | +5.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +0.7 | 87.7 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 137.7 | +5246.6 | 2274.0 | 513.3 | 68.3 | +2520.0 | 120.0 | 513.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 72.3 |
| FOUR ROUNDS | 2.3 | +292.8 | 399.0 | 20.0 | 1.0 | +87.5 | 0.0 | 16.7 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.7 | -53.9 | 0.0 | 0.0 | 0.7 | -0.7 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -1.3 | 37.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.0 | +250.4 | 0.0 | 0.0 | 2.3 | +97.3 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +41.5 | 135.7 | 0.0 | - | - | - | - |
| GUN MASK | 2.7 | +151.1 | 0.0 | 0.0 | 1.0 | +50.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 6.0 | +0.0 | 0.0 | 20.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 60.0 | 7.7 | +0.0 | 0.0 | 144.7 |
| HIS CHARGE LIST | 15.7 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 416.0 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -21.0 | 0.0 | 0.0 | 5.7 | -59.6 | 0.0 | 228.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 6.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.0 | +1901.6 | 0.0 | 220.0 | 40.0 | +4062.7 | 0.0 | 463.3 |
| HIS SHOTS BY HIS RUN | 33.7 | +591.3 | 0.0 | 240.0 | 37.0 | +899.8 | 0.0 | 463.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.3 | +0.0 | 0.0 | 0.0 | 13.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +804.7 | 0.0 | 0.0 | 9.0 | +1091.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -27.1 | 70.7 | 0.0 | 0.7 | -40.2 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +38.7 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 16.7 | -437.1 | 0.0 | 30.3 |
| JOINT CHARGE NOW | 1.7 | -16.0 | 348.3 | 20.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 37.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | -6.6 | 20.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +4.8 | 87.7 | 0.0 | 0.3 | -2.0 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +6.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +32.8 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 2.0 | +113.6 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 1.0 | +36.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 3.0 | +183.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +24.6 | 0.0 | 20.0 | 4.0 | +54.1 | 0.0 | 20.0 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 0.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 8.0 | +50.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 10.3 | +55.5 | 0.0 | 135.7 |
| MODEL FACING | 3.0 | +802.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.3 | +193.8 | 0.0 | 0.0 | 3.0 | +231.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +226.8 | 0.0 | 0.0 | 5.0 | +233.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +152.7 | 0.0 | 0.0 | 3.0 | +231.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -49.8 | 399.0 | 20.0 | 0.3 | -9.9 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -169.8 | 0.0 | 53.3 | 3.3 | -102.0 | 0.0 | 20.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.3 | +5.3 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -28.5 | 0.0 | 20.0 | 3.7 | -72.9 | 0.0 | 20.0 |
| ONE JOINT FIGURE | 0.3 | -56.4 | 135.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.3 | -34.0 | 0.0 | 0.0 | 4.0 | -88.4 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +79.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -28.8 | 0.0 | 0.0 |
| PLAN RESULT | 61.3 | +1120.8 | 1258.3 | 246.7 | 32.0 | +116.7 | 0.0 | 609.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 72.3 |
| PROMISE BY ITS OWN SUM | 4.0 | -41.3 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -0.1 | 0.0 | 0.0 | 0.7 | -0.7 | 0.0 | 0.0 |
| QUARTER ODDS | 16.7 | +1062.0 | 814.0 | 60.0 | 2.0 | +700.0 | 0.0 | 271.3 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +161.3 | 0.0 | 20.0 |
| REDIRECT COUNTER | 1.3 | +140.7 | 0.0 | 0.0 | 1.7 | +20.7 | 0.0 | 33.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +137.9 | 0.0 | 33.7 |
| REFORMS TO MEET IT | 1.0 | -28.2 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.3 | +13.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +59.8 | 379.0 | 20.0 | 1.0 | +27.1 | 0.0 | 16.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -10.4 | 0.0 | 16.7 |
| RUN DOWN | 1.7 | -24.7 | 359.0 | 20.0 | 0.3 | -0.8 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -100.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | -6.5 | 0.0 | 20.0 |
| SET CREDITED ONCE | - | - | - | - | 1.7 | -104.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | -75.7 | 0.0 | 0.0 | 3.0 | +78.7 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +7.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 21.7 | +0.0 | 0.0 | 106.7 | 7.3 | +0.0 | 0.0 | 20.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +17.1 | 0.0 | 0.0 | 2.0 | +41.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -7.6 | 50.7 | 0.0 | 0.7 | -1.3 | 0.0 | 0.0 |
| SHOT RISK POINTS | 28.0 | +902.2 | 0.0 | 220.0 | 21.0 | +221.9 | 0.0 | 463.3 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 32.0 | +1245.2 | 0.0 | 166.7 | 4.0 | +315.2 | 0.0 | 0.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +138.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -5.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 103.3 | +0.0 | 1875.0 | 453.3 | 20.3 | +0.0 | 120.0 | 20.0 |
| STAY WORTH | 53.0 | +374.2 | 1526.0 | 360.0 | 14.0 | +208.7 | 120.0 | 0.0 |
| SUPPORT ADDS | 4.0 | +156.0 | 0.0 | 40.0 | 1.7 | +26.6 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.0 | +156.0 | 0.0 | 40.0 | 1.7 | +26.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.8 | 0.0 | 0.0 | 1.3 | +5.4 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +2.8 | 0.0 | 69.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 135.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 54.3 | +0.0 | 0.0 | 166.7 | 33.7 | +0.0 | 0.0 | 258.3 |
| TIED UP BY THE SUM | 0.7 | +19.0 | 50.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 60.0 | +607.3 | 72.3 | 60.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -76.9 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | +9.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -80.6 | 0.0 | 0.0 | 1.7 | -48.8 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +1.0 | 37.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.0 | +29.3 | 0.0 | 0.0 | 2.0 | +150.4 | 0.0 | 135.7 |

### Rule changes: cnsr-c940641-p28

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 267 | 266 | 103 | 34.33 | +3243 | +31.5 |
| HIS SHOTS BY HIS RUN | 212 | 207 | 59 | 19.67 | +739 | +12.5 |
| HOLDER ASSIGNMENT | 54 | 54 | 50 | 16.67 | +4038 | +80.8 |
| SHOT RISK POINTS | 147 | 146 | 41 | 13.67 | +2075 | +50.6 |
| ARMY TABLE | 60 | 60 | 39 | 13.00 | +525 | +13.5 |
| TIME ON OUR SIDE | 180 | 167 | 34 | 11.33 | +116 | +3.4 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| FIVE ACTION | 618 | 613 | 24 | 8.00 | +1214 | +50.6 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -816 | -34.0 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| CHARGE LOSSES | 84 | 83 | 13 | 4.33 | +743 | +57.2 |
| IDLE COST | 50 | 42 | 11 | 3.67 | +348 | +31.7 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| COVER ONCE | 55 | 51 | 10 | 3.33 | +8 | +0.8 |
| THE RISK READS HIS RUN | 18 | 18 | 10 | 3.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 56 | 56 | 9 | 3.00 | +0 | +0.0 |
| MODEL FACING | 9 | 9 | 9 | 3.00 | +2406 | +267.3 |
| FOUR ROUNDS | 10 | 10 | 8 | 2.67 | +351 | +43.9 |
| MOVE TO CHARGE COMPUTED | 16 | 14 | 8 | 2.67 | +380 | +47.5 |
| CAST JOB | 13 | 13 | 7 | 2.33 | +20 | +2.9 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +16 | +2.2 |
| SUPPORT ADDS | 17 | 17 | 7 | 2.33 | +167 | +23.9 |
| SUPPORT WORKED OUT | 17 | 17 | 7 | 2.33 | +167 | +23.9 |
| ARTILLERY RE-ROLL WEIGHED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| GOAL WALK | 16 | 16 | 6 | 2.00 | +417 | +69.6 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 25 | 25 | 6 | 2.00 | -124 | -20.6 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 6 | 2.00 | +57 | +9.6 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 23 | 23 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -48 | -9.6 |
| NEXT CHARGE BY LIST | 11 | 11 | 5 | 1.67 | +371 | +74.2 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +412 | +82.4 |
| RISK BY ARC | 9 | 9 | 5 | 1.67 | +57 | +11.5 |
| SET UP BY THE SET | 13 | 13 | 5 | 1.67 | +155 | +31.0 |
| SHOTS IN THE MOVE | 108 | 101 | 5 | 1.67 | +298 | +59.6 |
| FALLS SHORT | 70 | 61 | 4 | 1.33 | +64 | +16.1 |
| MARCH CHECK | 6 | 6 | 4 | 1.33 | +131 | +32.7 |
| QUARTER ODDS | 56 | 56 | 4 | 1.33 | +65 | +16.3 |
| WOUNDS ON THE RANKS | 12 | 12 | 4 | 1.33 | +109 | +27.3 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| GUN MASK | 11 | 11 | 3 | 1.00 | +35 | +11.8 |
| MANOEUVRE | 9 | 9 | 3 | 1.00 | +22 | +7.3 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -110 | -36.5 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +239 | +79.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| LEGAL CHARGES ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +98 | +49.2 |
| MAX FOR POSITIONING | 16 | 15 | 2 | 0.67 | +60 | +29.9 |
| REDIRECT COUNTER | 9 | 7 | 2 | 0.67 | +64 | +31.9 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +8 | +4.2 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +45 | +22.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +151 | +151.3 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.5 |
| EXACT ROUND | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +79 | +78.6 |
| FALLBACK BY WORTH | 1 | 1 | 1 | 0.33 | +8 | +8.3 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 26 | 26 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 4 | 4 | 1 | 0.33 | +2 | +2.5 |
| NEARER NOT NEEDED | 30 | 26 | 1 | 0.33 | +31 | +31.4 |
| ONE OBJECTIVE FORMULA | 25 | 22 | 1 | 0.33 | +93 | +93.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -86 | -86.5 |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +40 | +39.8 |
| SEARCH SPOT | 4 | 4 | 1 | 0.33 | +19 | +19.3 |
| STAY WORTH | 201 | 192 | 1 | 0.33 | +29 | +29.4 |
| SURE REACH TOGETHER | 5 | 5 | 1 | 0.33 | +2 | +1.7 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -231 | -230.8 |
| WHO FIGHTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +2 | +2.5 |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 18 | 18 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 54 | 54 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 23 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 50 | 50 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 74 | 73 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 40 | 39 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 43 | 42 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 81 | 81 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 24 | 19 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 31 | 26 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 21 | 17 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 280 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 87 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 32 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 371 | 368 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 5 | not checked | - | - | - | - |
| THE TABLE BINDS | 264 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p28

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 3.00 | 34.3 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | - | 20.6 |
| ARMY TABLE | rule | 1.00 | 0.67 | 20.5 |
| JOINT CHARGE NOW | rule | 1.00 | - | 44.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.67 | - | 57.1 |
| FALLBACK | gate | 0.33 | 0.33 | 21.2 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 3.2 |
| MARCH OF THE TABLE | rule | - | 0.67 | 54.8 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | - | 7.5 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 86.5 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 230.8 |

### Plans: cnsr-c940641-p28

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 22 | 32 | 147% |
| Mine | join | 2.3 | 100% | 77 | 0 | 0% |
| Mine | move | 37.3 | 98% | 1270 | 0 | 0% |
| Mine | shoot | 20.7 | 61% | 721 | 1089 | 151% |
| Opponent | charge | 1.0 | 0% | 50 | 4 | 9% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 23.3 | 93% | 989 | 0 | 0% |
| Opponent | shoot | 6.0 | 44% | 290 | 112 | 39% |
| Opponent | support | 0.7 | 100% | 29 | 0 | 0% |

### Battle groups: cnsr-c940641-p28

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.7 | 40% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p28

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 18 (13) | 18 | 0 | 0 | 23% | 3.1 | 33 (6) | 0 (6) | 0 (1) | 20 (11) | 0 (2) |
| Mine | Clean-up | 4 | 67 (4) | 67 | 0 | 0 | 75% | 1.0 | 0 (1) | 0 (1) | 131 (2) | 67 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 27 | 0% | 1.7 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 129 (4) | 8 | 121 | 0 | 25% | 3.3 | 12 (1) | 212 (3) | - | 129 (4) | - |
| Mine | Shooter | 8 | 60 (8) | 3 | 57 | 5 | 12% | 2.0 | 0 (1) | 118 (4) | 9 (3) | 44 (6) | 98 (2) |
| Mine | War machine | 17 | 7 (17) | 7 | 0 | 16 | 12% | 1.6 | 0 (4) | 12 (9) | 0 (4) | 0 (3) | 8 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 63 | 33% | 4.5 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 2 (10) | 2 | 0 | 11 | 40% | 3.3 | 0 (3) | 0 (4) | 0 (2) | 0 (8) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 3 | 5 (3) | 0 | 5 | 34 | 67% | 6.0 | 0 (1) | 17 (1) | 0 (1) | 7 (2) | 0 (1) |
| Opponent | Holder | 6 | 84 (6) | 6 | 78 | 26 | 50% | 2.0 | 18 (1) | 96 (5) | - | 129 (4) | 7 (2) |
| Opponent | War machine | 2 | 85 (2) | 85 | 0 | 0 | 0% | 1.0 | - | 170 (1) | 0 (1) | - | 85 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |

### Charged fights: cnsr-c940641-p28

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 109 | 169 | 1.3 | 1.8 | 127 | 15 | +112 | 1 of 4 | 3 of 4 | +136 | +41 |
| Opponent | Grand Cathay | 1 | 340 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 50 | -50 | 1 of 1 | 0 of 1 | - | -50 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 113 | 0 | 0.7 | 1.0 | 0 | 25 | -25 | 2 of 2 | 0 of 2 | - | -25 |

### Effective charges: cnsr-c940641-p28

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +347) | 0 | 0 | 0 | 1 (net +60) | 2 (net +20) | 0 | 0% (0 of 4) |
| Opponent | Grand Cathay | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p28

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 120 | 357 | +347 | 407 | 100 | +307 | +255.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 112 | 76 | +20 | 55 | 13 | +42 | +37.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 289 | 60 | +60 | 60 | 0 | +60 | +20.8 |
| Mine | All fights | 4 | 158 | 142 | +112 | 144 | 32 | +113 | +71.2 |
| Opponent | Long shot (under 50%) | 1 | 217 | 183 | +0 | 87 | 323 | -236 | -108.8 |
| Opponent | No odds | 1 | 50 | 239 | -50 | 32 | 71 | -39 | -78.7 |
| Opponent | All fights | 2 | 134 | 211 | -25 | 59 | 197 | -138 | -103.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p28 | move | 11 | 2 (18%) | 1 (9%) | 0 (0%) | 9 (82%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

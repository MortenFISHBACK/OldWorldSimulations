# Doctrine scorecard: cnsr-c940641-p48

### Scorecard: cnsr-c940641-p48

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 5 | 5 | 1 | 1 | 0 | 0 | 0 | 168 |
| L2535 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 2 | 6 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 6 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 67% | 5.5 | 3.7 | 1.7 | 3.3 | 0.0 | 0.0 | 0.0 | 56.0 |
| **Average** | | | Opponent | 33% | 4.5 | 2.3 | 3.0 | 1.3 | 0.0 | 0.0 | 0.0 | 48.0 |

### KPIs: cnsr-c940641-p48

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 35% (6 of 17) | 19% (6 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (7 of 7); on the table 100% | 83% (5 of 6); on the table 83% | 92% (12 of 13); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 83% (5 of 6); on the table 83% | 100% (2 of 2); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to follow up or pursue (all three) |  | 94% (15 of 16); on the table 94% | 88% (7 of 8); on the table 88% | 92% (22 of 24); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 46% (11 of 24) | 33% (6 of 18) | 40% (17 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (11 of 22) | 38% (6 of 16) | 45% (17 of 38) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 55% (3279 of 5999) | 38% (2255 of 6000) | 46% (5534 of 11999) |
|   infantry points that never fought | lower | 63% (495 of 780) | 36% (693 of 1918) | 44% (1188 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (12 of 18) | 65% (22 of 34) | 65% (34 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 1.3 uses a game | 50% (2 of 4); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (2671 of 4808) | 52% (3084 of 5962) | 53% (5755 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (46%) | 1.7 (42%) | 3.7 (44%) |
| MARCHED: its unit marched | 0.3 (8%) | 1.3 (33%) | 1.7 (20%) |
| CHARGED: its unit charged | 1.0 (23%) | 0.0 (0%) | 1.0 (12%) |
| IN COMBAT: engaged in combat | 0.7 (15%) | 0.0 (0%) | 0.7 (8%) |
| GONE: slain | 0.0 (0%) | 0.7 (17%) | 0.7 (8%) |
| STUPIDITY: Stupidity | 0.3 (8%) | 0.0 (0%) | 0.3 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (8%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.3 | 2.7 | 5.7 | 1.7 | 2.7 |
| not cast | 3.0 | 1.0 | 3.3 | 8.3 | 4.3 | 21.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (33%) | 0.3 (10%) | 3.7 (44%) | 3.3 (77%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (20%) | 0.7 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (12%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (20%) | 0.7 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (33%) | 0.7 (67%) | 0.0 (0%) | 0.7 (8%) | 0.0 (0%) | 1.3 (6%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.3 (8%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (67%) | 0.0 (0%) | 2.3 (70%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 2.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 50% (1 of 2) | 50% (3 of 6) | 50% (4 of 8) |
| the unit moved after it | 100% (1 of 1) | 0% (0 of 3) | 25% (1 of 4) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 3) | 0% (0 of 4) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 3) | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 3) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 3) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 100% (3 of 3) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 4) | 66% (59 of 90) | 63% (59 of 94) |
|   cavalry | - | 66% (27 of 41) | 66% (27 of 41) |
|   character | 0% (0 of 4) | 67% (10 of 15) | 53% (10 of 19) |
|   infantry | - | 65% (22 of 34) | 65% (22 of 34) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 5.7 (55%) | 5.7 (49%) |
| CHARGED: it charged | 0.7 (50%) | 3.0 (29%) | 3.7 (31%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (3%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (6%) | 0.7 (6%) |
| NO TARGET IN RANGE | 0.3 (25%) | 0.0 (0%) | 0.3 (3%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (25%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (6%) | 0.7 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.7 | 1.3 | 89% | 5.0 pts | 58 pts |
| character | 3.3 | 1.7 | 50% | 8.8 pts | 29 pts |
| infantry | 10.3 | 4.3 | 77% | 5.8 pts | 60 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 6.3 | 5.5 |
| Charges that made contact a game | 3.0 | 4.0 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.75 declared, 0.00 contact (4 units) | - | 0.75 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | - | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.47 declared, 0.37 contact (19 units) | 0.61 declared, 0.39 contact (31 units) | 0.56 declared, 0.38 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (7 of 11) | 50% (1 of 2) | 100% (1 of 1) | 64% (9 of 14) |
| Character in a unit | 100% (2 of 2) | 50% (2 of 4) | 0% (0 of 1) | 57% (4 of 7) |
| Character on its own | 100% (3 of 3) | 100% (2 of 2) | 0% (0 of 5) | 50% (5 of 10) |
| Infantry | 75% (9 of 12) | 67% (2 of 3) | - | 73% (11 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 80% (4 of 5) | - | - | 80% (4 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 92% (12 of 13); on the table 92% | 46% (11 of 24) | 48% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (3 of 3); on the table 100% | - | 68% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 88% (7 of 8); on the table 88% | 33% (6 of 18) | 38% | 65% (22 of 34) | 50% (2 of 4); 1.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p48, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 70% (7) | 25% (1) | 57% (8) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.33 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnsr-c940641-p48

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 69% (9 of 13) | 64% (7 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 0% (0 of 7) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 3.3 | 1.3 |
| Movement | Points that never moved of their own | 56.0 | 48.0 |
| Movement | Fights charged into per game | 3.0 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 9, net +0 | 2 of 7, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 9, net +558 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 9, net +127 | 1 of 7, net +329 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 9, net +122 | 2 of 7, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.7 | 21.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 64% (41 of 64) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 12% (1 of 8) | 75% (3 of 4) |
| Magic | Wounds caused by magic missiles | 0.3 | 1.3 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 111.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.3 / 1.7 / 0.3 | 2.0 / 0.7 / 0.0 / 1.0 |
| Combat | Points destroyed in combat | 225.7 | 306.3 |
| Combat | Points run down | 144.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +134 | +73 |
| Combat | Net per 100 charger points, damage counted | +49.6 | +33.3 |
| Combat | First round won (charged fights) | 78% | 73% |
| Combat | Net points per charged fight | +144 | +72 |
| Combat | Net points per supported fight / lone fight | - / +144 | +0 / +79 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 9 | 4 of 11 |
| Game | Points lost | 434.0 | 653.0 |
| Game | VP from objectives | 693.3 | 650.0 |
| Game | Lone holders (player turns) | 5.5 | 4.5 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +286 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1087
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p48

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +17.5 | 0.0 | 0.0 |
| ARMY TABLE | 23.3 | -94.6 | 0.0 | 190.0 | 48.7 | +395.6 | 0.0 | 398.0 |
| BACKUP TARGETS | 0.7 | +1.2 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +4.8 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 7.3 | +173.1 | 0.0 | 30.0 | 0.3 | +27.8 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +49.6 | 0.0 | 84.7 | 0.7 | +59.1 | 0.0 | 74.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.7 | -11.6 | 265.3 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 5.3 | +0.0 | 0.0 | 149.3 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +20.9 | 132.7 | 0.0 |
| CHARGE LOSSES | 17.7 | -595.8 | 0.0 | 320.7 | 18.7 | -722.6 | 0.0 | 538.3 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 285.7 | 84.7 | 2.0 | +0.0 | 424.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 16.3 | +0.0 | 0.0 | 58.3 | 4.7 | +0.0 | 0.0 | 41.7 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +25.2 | 0.0 | 0.0 | 2.0 | +98.5 | 0.0 | 0.0 |
| COVER ONCE | 6.0 | -334.0 | 0.0 | 127.7 | 14.0 | -505.4 | 0.0 | 41.7 |
| DEFENSIVE FLOOR | - | - | - | - | 0.7 | +2.7 | 265.3 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -1.7 | 0.0 | 84.7 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 0.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -63.2 | 153.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.3 | +4.8 | 126.3 | 84.7 | 3.3 | +14.5 | 221.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +5.9 | 211.0 | 84.7 | 2.0 | +0.0 | 109.7 | 0.0 |
| FALLBACK BY WORTH | 0.7 | +0.0 | 0.0 | 15.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 23.3 | +322.1 | 0.0 | 47.7 | - | - | - | - |
| FEATURE BUFFS | 0.7 | +7.0 | 0.0 | 0.0 | 0.7 | +8.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +5.9 | 41.7 | 84.7 | 1.7 | +5.5 | 49.0 | 0.0 |
| FIVE ACTION | 78.7 | +4859.4 | 468.3 | 634.7 | 99.3 | +7350.0 | 799.3 | 891.3 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 152.7 | 6.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +59.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +253.3 | 468.3 | 84.7 | 4.7 | +392.6 | 571.7 | 0.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 50.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -1.2 | 0.0 | 0.0 |
| GOAL WALK | 5.7 | +376.3 | 0.0 | 0.0 | 22.3 | +1607.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.3 | +0.0 | 0.0 | 320.7 | 13.0 | +0.0 | 0.0 | 538.3 |
| HIS CHARGE DENIED | 0.3 | +12.2 | 52.7 | 0.0 | 0.3 | +4.6 | 84.7 | 0.0 |
| HIS CHARGE LIST | 8.3 | +0.0 | 0.0 | 50.0 | 12.7 | +0.0 | 0.0 | 79.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 190.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 8.0 | -81.3 | 0.0 | 222.7 | 4.0 | -12.5 | 0.0 | 90.7 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 190.0 | 11.0 | +0.0 | 0.0 | 38.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 59.3 | +1280.2 | 0.0 | 516.7 | 26.3 | +211.2 | 0.0 | 161.0 |
| HIS SHOTS BY HIS RUN | 58.7 | +929.4 | 0.0 | 335.3 | 19.7 | +140.9 | 0.0 | 446.7 |
| HIS TURN DENIED | 0.3 | +16.1 | 0.0 | 84.7 | 1.3 | +2.0 | 398.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 65.3 | 17.3 | +0.0 | 0.0 | 356.0 |
| HOLDER ASSIGNMENT | 9.7 | +754.7 | 0.0 | 32.7 | 11.0 | +787.6 | 0.0 | 178.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 4.3 | -166.5 | 415.7 | 84.7 | 3.3 | -112.5 | 173.7 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +4.1 | 0.0 | 0.0 |
| IDLE COST | 17.0 | -221.0 | 0.0 | 227.3 | - | - | - | - |
| JOINT CHARGE NOW | 0.7 | +103.6 | 105.3 | 0.0 | 1.0 | +29.4 | 398.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 157.3 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 158.0 | 351.0 | 10.7 | +0.0 | 605.7 | 41.7 |
| LONG SHOT | 0.7 | +0.3 | 0.0 | 0.0 | 0.7 | +10.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 4.0 | +11.0 | 430.3 | 0.0 | 1.7 | -3.3 | 265.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -29.8 | 0.0 | 0.0 |
| MANOEUVRE | 3.0 | -0.3 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 2.3 | +90.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +34.9 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +3.9 | 0.0 | 0.0 | 2.0 | +499.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +62.4 | 0.0 | 0.0 | 4.7 | +58.8 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +14.5 | 0.0 | 0.0 | 5.0 | +165.8 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 5.0 | +12.1 | 0.0 | 0.0 | 6.3 | +109.0 | 0.0 | 52.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 120.3 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 2.3 | -71.4 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.0 | +1144.0 | 0.0 | 190.0 | 6.3 | +450.9 | 0.0 | 38.0 |
| NEARER NOT NEEDED | 11.7 | +465.6 | 0.0 | 32.7 | 9.0 | +420.9 | 0.0 | 78.7 |
| NEXT CHARGE BY LIST | 7.7 | +828.7 | 0.0 | 0.0 | 2.3 | +197.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 4.0 | -235.3 | 385.0 | 84.7 | 2.7 | -154.1 | 531.7 | 0.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -1.4 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -86.9 | 41.7 | 0.0 | 7.0 | -282.9 | 0.0 | 41.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -101.9 | 0.0 | 50.0 | 7.7 | -146.0 | 0.0 | 38.0 |
| ONE JOINT FIGURE | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.0 | +77.7 | 0.0 | 32.7 | 4.3 | +41.3 | 0.0 | 99.3 |
| ONE PROMISE A TARGET | 0.7 | -100.7 | 0.0 | 0.0 | 0.7 | -65.4 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +13.4 | 38.0 | 0.0 | 0.3 | +15.2 | 15.0 | 0.0 |
| OVERRUNS AWAY | 3.0 | +17.1 | 415.7 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| OWN CAST FIRST | 0.7 | -2.5 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.7 | +37.1 | 0.0 | 0.0 | 0.3 | +40.7 | 0.0 | 0.0 |
| PLAN RESULT | 42.7 | +261.6 | 158.0 | 752.0 | 47.0 | +697.1 | 929.7 | 738.7 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 84.7 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.3 | -74.8 | 0.0 | 0.0 | 9.7 | -166.8 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | -31.9 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -1.2 | 0.0 | 0.0 |
| QUARTER ODDS | 18.7 | +1991.5 | 235.3 | 0.0 | 24.7 | +3279.2 | 265.3 | 93.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | -30.7 | 0.0 | 0.0 | 1.3 | +14.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 6.3 | +385.7 | 0.0 | 55.0 | 1.3 | +33.8 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.3 | +26.2 | 0.0 | 30.0 | 2.7 | +106.1 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.3 | -67.5 | 0.0 | 0.0 | 2.0 | -201.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +14.9 | 0.0 | 0.0 | 1.0 | +5.1 | 0.0 | 38.0 |
| RISK BY ARC | 4.7 | -59.3 | 468.3 | 84.7 | 3.3 | +109.2 | 522.7 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 2.0 | -32.8 | 216.0 | 84.7 | - | - | - | - |
| RUN DOWN | 4.7 | -78.9 | 468.3 | 84.7 | 0.7 | -1.1 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 3.0 | -18.9 | 0.0 | 30.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +1.7 | 0.0 | 0.0 | 1.0 | +16.6 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +16.5 | 41.7 | 0.0 | 1.0 | +40.7 | 15.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -47.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.0 | +212.9 | 0.0 | 0.0 | 1.0 | +2.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.7 | +27.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +8.0 | 0.0 | 0.0 | 1.3 | +14.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.9 | 0.0 | 0.0 | 0.7 | -1.7 | 0.0 | 0.0 |
| SHOT RISK POINTS | 40.0 | -494.5 | 0.0 | 368.7 | 15.3 | -44.5 | 0.0 | 216.3 |
| SHOTS AFTER THE MOVES | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.3 | +18.9 | 0.0 | 0.0 | 19.3 | +193.5 | 0.0 | 322.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.7 | +27.9 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +2.2 | 0.0 | 0.0 | 2.3 | +34.5 | 218.0 | 218.0 |
| SPOT AS THE GAME MOVES | 12.7 | +0.0 | 0.0 | 386.3 | 10.3 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.7 | -6.3 | 99.3 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 11.3 | +0.0 | 0.0 | 62.7 | 32.7 | +0.0 | 227.7 | 264.7 |
| STAY WORTH | 0.3 | +8.7 | 0.0 | 0.0 | 16.3 | +83.0 | 132.7 | 125.3 |
| STRIKE BY THE ODDS | - | - | - | - | 2.0 | +17.1 | 530.7 | 41.7 |
| STUPIDITY NEXT TURN | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 2.0 | +232.2 | 0.0 | 0.0 | 5.3 | +285.8 | 0.0 | 69.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 38.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +232.2 | 0.0 | 0.0 | 5.3 | +285.8 | 0.0 | 69.3 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -32.4 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.7 | +0.0 | 0.0 | 25.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.3 | +0.0 | 0.0 | 38.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.0 | +0.0 | 0.0 | 275.0 | 47.0 | +0.0 | 0.0 | 411.0 |
| TIED UP BY THE SUM | 1.3 | +161.9 | 158.3 | 84.7 | 1.0 | +125.5 | 40.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 54.7 | +571.8 | 0.0 | 586.3 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -1.1 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.3 | -19.9 | 166.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +1.0 | 41.7 | 0.0 | 0.7 | -5.2 | 0.0 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.3 | -4.9 | 132.7 | 0.0 |
| WHO HITS BACK | 0.3 | +51.9 | 0.0 | 0.0 | 0.7 | +42.8 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.7 | +7.1 | 83.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.3 | -113.2 | 0.0 | 98.0 | 3.3 | -609.5 | 0.0 | 344.7 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.7 | +100.8 | 0.0 | 0.0 | 2.3 | +27.0 | 0.0 | 105.3 |

### Rule changes: cnsr-c940641-p48

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 216 | 216 | 131 | 43.67 | +1609 | +12.3 |
| HOLDER ASSIGNMENT | 62 | 62 | 55 | 18.33 | +3506 | +63.7 |
| LEGAL CHARGES ONLY | 43 | 43 | 43 | 14.33 | +0 | +0.0 |
| OFF BEST | 40 | 40 | 40 | 13.33 | -1110 | -27.7 |
| HIS SHOTS BY HIS RUN | 235 | 232 | 39 | 13.00 | +291 | +7.5 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| HIS SHOT LIST | 257 | 253 | 34 | 11.33 | +116 | +3.4 |
| FIVE ACTION | 534 | 517 | 33 | 11.00 | +1624 | +49.2 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 49 | 46 | 29 | 9.67 | +1511 | +52.1 |
| QUARTER ODDS | 130 | 124 | 26 | 8.67 | +2200 | +84.6 |
| GOAL WALK | 84 | 82 | 22 | 7.33 | +1016 | +46.2 |
| REDIRECT FOR A FRIEND IN REACH | 24 | 24 | 21 | 7.00 | +20 | +1.0 |
| NEXT CHARGE BY LIST | 30 | 30 | 19 | 6.33 | +1450 | +76.3 |
| MOVE ORDER | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| FOUR ROUNDS | 28 | 26 | 17 | 5.67 | +486 | +28.6 |
| TIME ON OUR SIDE | 164 | 130 | 16 | 5.33 | +92 | +5.8 |
| PROMISE BY ITS OWN SUM | 54 | 54 | 14 | 4.67 | -725 | -51.8 |
| SHOT RISK POINTS | 166 | 163 | 14 | 4.67 | +222 | +15.8 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 23 | 23 | 10 | 3.33 | +75 | +7.5 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| COVER ONCE | 60 | 34 | 7 | 2.33 | +67 | +9.6 |
| RISK BY ARC | 24 | 23 | 7 | 2.33 | +149 | +21.2 |
| IDLE COST | 51 | 35 | 6 | 2.00 | +25 | +4.2 |
| PATHS CROSS | 6 | 6 | 6 | 2.00 | +233 | +38.9 |
| STRIKE BY THE ODDS | 6 | 6 | 6 | 2.00 | +51 | +8.5 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +399 | +79.7 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 5 | 1.67 | +13 | +2.6 |
| SUPPORT ADDS | 22 | 21 | 5 | 1.67 | +304 | +60.9 |
| SUPPORT WORKED OUT | 22 | 21 | 5 | 1.67 | +304 | +60.9 |
| TIED UP BY THE SUM | 7 | 7 | 5 | 1.67 | +107 | +21.4 |
| WOUNDS ON THE RANKS | 18 | 18 | 5 | 1.67 | +20 | +4.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +326 | +81.5 |
| CHARGE LOSSES | 109 | 106 | 4 | 1.33 | +265 | +66.2 |
| CHARGE NOW FIRST | 13 | 13 | 4 | 1.33 | -166 | -41.5 |
| NEARER NOT NEEDED | 62 | 60 | 4 | 1.33 | +127 | +31.8 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -498 | -124.5 |
| REDIRECT COUNTER | 23 | 19 | 4 | 1.33 | +174 | +43.5 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +60 | +15.0 |
| SEARCH SPOT | 7 | 7 | 4 | 1.33 | +55 | +13.7 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +171 | +42.8 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| ONE OBJECTIVE FORMULA | 25 | 20 | 3 | 1.00 | +225 | +75.1 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 3 | 1.00 | +8 | +2.7 |
| SET UP BY THE SET | 9 | 9 | 3 | 1.00 | +233 | +77.6 |
| SHOTS AFTER THE MOVES | 7 | 7 | 3 | 1.00 | +0 | +0.0 |
| STAY WORTH | 50 | 37 | 3 | 1.00 | +51 | +16.9 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +185 | +61.7 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 70 | 57 | 2 | 0.67 | +14 | +7.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +179 | +89.3 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 7 | 7 | 2 | 0.67 | +59 | +29.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -123 | -61.3 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -8 | -3.8 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 2 | 0.67 | -96 | -47.9 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -234 | -116.9 |
| THE ROW IN ITS ORDER | 31 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 14 | 14 | 2 | 0.67 | +11 | +5.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +52 | +52.5 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +63 | +62.7 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DUEL STOPS AT THE KILL | 2 | 2 | 1 | 0.33 | +55 | +54.8 |
| EXACT ROUND | 17 | 16 | 1 | 0.33 | +28 | +27.7 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +14 | +13.6 |
| HONEST WORTH | 23 | 22 | 1 | 0.33 | +55 | +54.8 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +12 | +12.2 |
| MAX FOR POSITIONING | 20 | 17 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 38 | 19 | 1 | 0.33 | +0 | +0.3 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +33 | +33.5 |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 1 | 0.33 | +4 | +4.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -2 | -2.4 |
| SHOTS IN THE MOVE | 59 | 42 | 1 | 0.33 | +2 | +2.2 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +9.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -3 | -3.3 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -15 | -14.7 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.33 | -107 | -107.4 |
| BACKUP TARGETS | 3 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 16 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 63 | 62 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 14 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 3 | 3 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 8 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 24 | 23 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 11 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 76 | 75 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 63 | 63 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 40 | 37 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 36 | 36 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 31 | 31 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 62 | 58 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 100 | 100 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 17 | 15 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 13 | 13 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 27 | 19 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 34 | 25 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 20 | 20 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 13 | 13 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 10 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 13 | 13 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 12 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 15 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 19 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 69 | 62 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 132 | 123 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 12 | 11 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 270 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p48

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 5.33 | 27.0 |
| ARMY TABLE | rule | 1.00 | 6.33 | 80.7 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 3.67 | 51.8 |
| CHARGE NOW FIRST | rule | 0.67 | 0.67 | 41.5 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.67 | 124.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 8.2 |
| RULE SWITCHED OFF | gate | - | 1.00 | 37.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.67 | 37.5 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 61.3 |
| OWN CAST FIRST | rule | 0.67 | - | 3.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 47.9 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 116.9 |
| FALLBACK | gate | 0.33 | - | 28.5 |
| JOINT CHARGE NOW | rule | - | 0.33 | 14.7 |
| NO REASON | gate | 0.33 | - | 2.1 |
| REFUSING RETIRES | rule | - | 0.33 | 2.4 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 3.3 |
| WHO GETS IN | rule | - | 0.33 | 14.7 |
| WOUNDED STAYS OUT | rule | - | 0.33 | 107.4 |

### Plans: cnsr-c940641-p48

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 78% | 444 | 262 | 59% |
| Mine | join | 4.7 | 100% | 203 | 0 | 0% |
| Mine | move | 33.0 | 95% | 1867 | 0 | 0% |
| Mine | support | 2.0 | 100% | 38 | 0 | 0% |
| Opponent | charge | 4.0 | 75% | 431 | 560 | 130% |
| Opponent | move | 40.0 | 95% | 2651 | 0 | 0% |
| Opponent | shoot | 2.0 | 33% | 111 | 137 | 124% |
| Opponent | support | 1.0 | 100% | 53 | 0 | 0% |

### Battle groups: cnsr-c940641-p48

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 6.3 | 37% | 71% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p48

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 58 (9) | 0 | 58 | 21 | 56% | 4.2 | 75 (7) | 0 (1) | 0 (1) | 66 (8) | 0 (1) |
| Mine | Character | 10 | 60 (10) | 60 | 0 | 2 | 40% | 3.5 | 13 (5) | 89 (5) | - | 11 (5) | 97 (5) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 8 | 17 (8) | 7 | 10 | 44 | 50% | 3.5 | 16 (2) | 19 (4) | 16 (2) | 0 (1) | 22 (7) |
| Mine | Hammer | 2 | 84 (2) | 0 | 84 | 46 | 50% | 4.0 | 156 (1) | 0 (1) | - | 156 (1) | 0 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.5 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 35 (7) | 35 | 0 | 18 | 0% | 1.1 | 34 (4) | 66 (1) | 0 (1) | 66 (2) | 31 (4) |
| Opponent | Clean-up | 2 | 55 (2) | 0 | 55 | 0 | 0% | 3.0 | 111 (1) | 0 (1) | - | 111 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 28 (5) | 15 | 13 | 39 | 0% | 1.4 | 28 (2) | 0 (2) | 79 (1) | 28 (2) | 28 (3) |
| Opponent | Hammer | 11 | 32 (11) | 32 | 0 | 43 | 27% | 4.5 | 0 (3) | 68 (6) | 0 (2) | 72 (2) | 25 (9) |
| Opponent | Shooter | 8 | 46 (8) | 0 | 46 | 42 | 0% | 1.4 | 107 (2) | 37 (5) | 0 (1) | 82 (3) | 30 (5) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |

### Charged fights: cnsr-c940641-p48

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 252 | 3.5 | 1.0 | 72 | 0 | +72 | 0 of 7 | 5 of 7 | - | +72 |
| Mine | Warriors of Chaos | 1 | 0 | 794 | 2.0 | 1.0 | 397 | 0 | +397 | 1 of 2 | 2 of 2 | - | +397 |
| **Mine** | all armies | 3 | 0 | 433 | 3.0 | 1.0 | 144 | 0 | +144 | 1 of 9 | 7 of 9 | - | +144 |
| Opponent | Wood Elf Realms | 3 | 112 | 339 | 3.7 | 1.1 | 92 | 21 | +72 | 4 of 11 | 8 of 11 | +0 | +79 |

### Effective charges: cnsr-c940641-p48

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 7 | 2 (net +0) | 0 | 0 | 0 | 2 (net +127) | 3 (net +83) | 0 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 1 (net +558) | 0 | 0 | 1 (net +236) | 0 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 11 | 2 (net +0) | 0 | 0 | 2 (net +74) | 1 (net +329) | 2 (net +0) | 4 | 0% (0 of 7) |

### Charged fights, damage counted: cnsr-c940641-p48

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 50 | 126 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 479 | 224 | +558 | 558 | 160 | +398 | +83.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 230 | 153 | +122 | 139 | 0 | +139 | +60.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 471 | 127 | +127 | 127 | 0 | +127 | +27.0 |
| Mine | All fights | 9 | 271 | 149 | +144 | 152 | 18 | +134 | +49.6 |
| Opponent | Long shot (under 50%) | 2 | 176 | 348 | +0 | 0 | 9 | -9 | -5.1 |
| Opponent | 76-89% | 2 | 106 | 108 | +74 | 98 | 0 | +98 | +92.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 312 | 152 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 75 | +329 | 329 | 0 | +329 | +65.9 |
| Opponent | No odds | 4 | 182 | 172 | +78 | 141 | 67 | +74 | +40.7 |
| Opponent | All fights | 11 | 220 | 180 | +72 | 99 | 26 | +73 | +33.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p48 | move | 25 | 7 (28%) | 4 (16%) | 4 (16%) | 14 (56%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

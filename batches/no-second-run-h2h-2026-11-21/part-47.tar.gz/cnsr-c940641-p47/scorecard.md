# Doctrine scorecard: cnsr-c940641-p47

### Scorecard: cnsr-c940641-p47

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 11 | - | 0 | 5 | 1 | 0 | 0 | 420 |
| L2131 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 1 | 0 | 0 | 732 |
| L2235 | 3 | 1 | Mine | no | 6 | 1 | 1 | 1 | 0 | 0 | 0 | 127 |
| L2235 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 6 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 8.5 | 1.0 | 0.7 | 3.3 | 0.3 | 0.0 | 0.0 | 182.3 |
| **Average** | | | Opponent | 33% | 0.5 | 3.0 | 3.0 | 2.7 | 0.7 | 0.0 | 0.0 | 244.0 |

### KPIs: cnsr-c940641-p47

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 13% (2 of 15) | 0% (0 of 15) | 7% (2 of 30) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | - | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 40% (2 of 5); on the table 40% | - | 40% (2 of 5); on the table 40% |
| Winner chose to follow up or pursue (all three) |  | 60% (6 of 10); on the table 60% | - | 60% (6 of 10); on the table 60% |
| Magic missiles tried each own turn | 50%+ | 17% (2 of 12) | - | 17% (2 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 22% (2 of 9) | - | 22% (2 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (6 of 12) | 64% (9 of 14) | 58% (15 of 26) |
| Points that never fought | lower | 56% (3345 of 5997) | 42% (2516 of 5999) | 49% (5861 of 11996) |
|   infantry points that never fought | lower | 83% (1398 of 1675) | 72% (936 of 1306) | 78% (2334 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (11 of 21) | 84% (26 of 31) | 71% (37 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 100% (2 of 2); 1.7 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (2419 of 4866) | 76% (4485 of 5884) | 64% (6904 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (30%) | - | 1.0 (30%) |
| MARCHED: its unit marched | 1.3 (40%) | - | 1.3 (40%) |
| IN COMBAT: engaged in combat | 0.7 (20%) | - | 0.7 (20%) |
| GONE: slain | 0.3 (10%) | - | 0.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 4.0 | 1.3 | 0.7 | 2.3 |
| not cast | 4.7 | 4.0 | 0.7 | 3.3 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (100%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (40%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (20%) | 0.0 (0%) |
| GONE: slain | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 2.0 (9%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (93%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 75% (3 of 4) | 75% (3 of 4) |
| the unit moved after it | - | 33% (1 of 3) | 33% (1 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (49 of 68) | 43% (15 of 35) | 62% (64 of 103) |
|   cavalry | 100% (9 of 9) | 50% (7 of 14) | 70% (16 of 23) |
|   character | 0% (0 of 10) | 11% (1 of 9) | 5% (1 of 19) |
|   chariot | 85% (11 of 13) | - | 85% (11 of 13) |
|   infantry | 81% (29 of 36) | 58% (7 of 12) | 75% (36 of 48) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 2.3 (35%) | 2.3 (18%) |
| CHARGED: it charged | 2.7 (42%) | 1.7 (25%) | 4.3 (33%) |
| NO TARGET IN RANGE | 2.3 (37%) | 2.3 (35%) | 4.7 (36%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (11%) | 0.0 (0%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (11%) | 0.3 (5%) | 1.0 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.3 | 1.7 | 84% | 4.0 pts | 42 pts |
| character | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.7 | 0.3 | 91% | 3.5 pts | 13 pts |
| infantry | 13.0 | 6.3 | 69% | 11.0 pts | 144 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.7 | 3.8 |
| Charges that made contact a game | 1.7 | 3.3 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.18 contact (28 units) | 0.56 declared, 0.40 contact (25 units) | 0.43 declared, 0.28 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | 100% (4 of 4) | - | 80% (8 of 10) |
| Character in a unit | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| Character on its own | 100% (5 of 5) | - | 38% (3 of 8) | 62% (8 of 13) |
| Chariot | 0% (0 of 2) | - | - | 0% (0 of 2) |
| Infantry | 73% (8 of 11) | 75% (3 of 4) | - | 73% (11 of 15) |
| Monster | 80% (4 of 5) | 0% (0 of 1) | - | 67% (4 of 6) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 60% (3 of 5); on the table 60% | 17% (1 of 6) | 37% | 33% (3 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 60% (3 of 5); on the table 60% | - | 42% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 89% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | - | - | 40% | 89% (17 of 19) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 46% | 75% (9 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p47, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (3) | 60% (3) | 75% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.00 | 1.00 |

### Quality by phase: cnsr-c940641-p47

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 42% (5 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 22% (4 of 18) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 75% (6 of 8) |
| Strategy | Joined characters whose unit fought | 40% (2 of 5) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 88% (7 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 3.3 | 2.7 |
| Movement | Points that never moved of their own | 182.3 | 244.0 |
| Movement | Fights charged into per game | 1.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 7 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 7, net +72 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 2, net +62 | 2 of 7, net +58 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 3 of 7, net +26 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.3 | 6.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (22 of 52) | 58% (11 of 19) |
| Shooting | Points destroyed by shooting units | 42.0 | 18.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | - |
| Magic | Wounds caused by magic missiles | 1.3 | 1.0 |
| Magic | Wounds caused by other spells | 0.7 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.3 / 0.7 / 1.0 / 0.0 | 0.0 / 2.7 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 413.3 | 175.7 |
| Combat | Points run down | 34.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +137 | -57 |
| Combat | Net per 100 charger points, damage counted | +37.2 | -19.2 |
| Combat | First round won (charged fights) | 100% | 75% |
| Combat | Net points per charged fight | +100 | -34 |
| Combat | Net points per supported fight / lone fight | - / +100 | -116 / -23 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 4 of 8 |
| Game | Points lost | 362.3 | 552.3 |
| Game | VP from objectives | 1006.7 | 230.0 |
| Game | Lone holders (player turns) | 8.5 | 0.5 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1120 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 915
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: cnsr-c940641-p47

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +116.4 | 0.0 | 180.0 | - | - | - | - |
| ARMY TABLE | 27.3 | +353.5 | 0.0 | 140.0 | 30.7 | +171.2 | 0.0 | 480.7 |
| BACKUP TARGETS | 0.3 | +0.6 | 0.0 | 65.0 | 1.0 | +3.5 | 0.0 | 38.0 |
| CAST JOB | 1.3 | +50.0 | 226.7 | 0.0 | 0.7 | +5.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.3 | +20.0 | 0.0 | 20.0 | 1.3 | +5.9 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 1.0 | -2.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +37.5 | 0.0 | 41.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | +5.5 | 180.0 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 9.3 | -331.5 | 0.0 | 148.3 | 23.3 | -1152.6 | 0.0 | 701.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 109.7 | 0.0 | 1.3 | +0.0 | 289.0 | 42.0 |
| CLOSES ON WHAT IT BEATS | 12.7 | +0.0 | 0.0 | 66.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +176.1 | 0.0 | 0.0 |
| COVER ONCE | 6.3 | -427.2 | 0.0 | 65.0 | 11.7 | -598.3 | 0.0 | 220.3 |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 38.0 |
| DUEL STOPS AT THE KILL | 0.7 | -1.2 | 83.3 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +10.4 | 41.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 4.3 | +117.1 | 18.3 | 83.7 |
| EXACT ROUND | 2.3 | +12.9 | 68.0 | 0.0 | 2.0 | +74.9 | 564.0 | 119.3 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +22.1 | 68.0 | 0.0 | 3.3 | +25.6 | 653.0 | 161.3 |
| FALLS SHORT | 7.7 | +111.4 | 0.0 | 20.0 | 17.7 | +122.4 | 0.0 | 226.3 |
| FEATURE BUFFS | 1.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +28.8 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 99.0 | +8542.4 | 504.0 | 439.7 | 84.0 | +4446.0 | 871.3 | 1383.3 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 133.0 |
| FOLLOW UP WEIGHED | 0.7 | +144.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 3.0 | +259.5 | 151.3 | 0.0 | 4.3 | +157.5 | 871.3 | 161.3 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 68.0 |
| FRIEND SHOOTS FIRST | 4.0 | -91.1 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +6.6 | 0.0 | 24.0 | - | - | - | - |
| GIVES UP | 1.0 | -15.4 | 41.7 | 0.0 | 1.0 | -3.8 | 360.0 | 38.7 |
| GOAL WALK | 3.0 | +122.1 | 0.0 | 0.0 | 15.0 | +1614.8 | 0.0 | 106.7 |
| GUN FIGURES | 2.0 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 41.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 68.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 148.3 | 12.3 | +0.0 | 0.0 | 329.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +15.1 | 65.0 | 0.0 |
| HIS CHARGE LIST | 10.7 | +0.0 | 0.0 | 48.3 | 7.7 | +0.0 | 0.0 | 79.7 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 65.0 | 4.7 | +0.0 | 0.0 | 34.0 |
| HIS MOVE AND SHOT | 6.7 | -53.7 | 0.0 | 216.3 | 3.7 | -52.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 18.3 | 10.3 | +0.0 | 0.0 | 529.7 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 170.0 | 5.7 | +0.0 | 0.0 | 68.0 |
| HIS RANDOM MOVE | 25.0 | +0.0 | 0.0 | 108.3 | 12.7 | +0.0 | 0.0 | 680.0 |
| HIS RANDOM MOVER COMES | 3.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 334.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 21.3 | +300.5 | 0.0 | 125.7 | 45.3 | +1103.0 | 0.0 | 1180.3 |
| HIS SHOTS BY HIS RUN | 26.0 | +356.3 | 0.0 | 274.7 | 42.3 | +680.3 | 0.0 | 605.7 |
| HIS TURN DENIED | 0.3 | +0.7 | 0.0 | 0.0 | 1.3 | +33.5 | 246.3 | 84.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 25.3 | +0.0 | 0.0 | 48.0 | 5.7 | +0.0 | 0.0 | 80.0 |
| HOLDER ASSIGNMENT | 15.3 | +1140.7 | 0.0 | 24.0 | 4.7 | +255.6 | 0.0 | 120.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -102.6 | 151.3 | 0.0 | 2.7 | -110.8 | 331.3 | 84.0 |
| HUNT KEPT | - | - | - | - | 0.3 | +0.6 | 180.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +0.0 | 180.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.7 | +363.8 | 360.0 | 38.7 |
| IDLE COST | 5.0 | -88.9 | 0.0 | 0.0 | 12.0 | -150.7 | 0.0 | 312.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | +44.3 | 540.0 | 77.3 |
| KEPT FROM ITS LAST STOP | 4.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 80.0 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 11.3 | +0.0 | 409.3 | 336.7 | 2.7 | +0.0 | 0.0 | 110.0 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 180.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.3 | -19.7 | 0.0 | 20.0 | - | - | - | - |
| MANOEUVRE | 1.0 | -10.0 | 0.0 | 0.0 | 2.7 | +5.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +13.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +42.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | 1.0 | +45.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +6.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | -28.0 | 0.0 | 0.0 | 1.0 | +300.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 80.0 |
| MAX FOR POSITIONING | 1.3 | +35.5 | 0.0 | 18.3 | 0.3 | +7.0 | 0.0 | 0.0 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +71.4 | 0.0 | 0.0 | 2.3 | +29.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.0 | +39.6 | 0.0 | 0.0 | 3.0 | +33.1 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 38.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.7 | -68.9 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.3 | +1382.5 | 0.0 | 170.0 | 4.0 | +420.3 | 0.0 | 72.7 |
| NEARER NOT NEEDED | 11.3 | +383.0 | 0.0 | 20.0 | 7.0 | +351.8 | 0.0 | 40.0 |
| NEXT CHARGE BY LIST | 6.7 | +1159.7 | 0.0 | 130.0 | 1.7 | +117.8 | 0.0 | 38.7 |
| NO DOUBLE ROUNDS | 3.0 | -110.1 | 151.3 | 0.0 | 3.3 | -172.8 | 691.3 | 161.3 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 40.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 1.0 | +1.3 | 0.0 | 65.0 |
| NOT WORTH A CAST | 4.3 | -4.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -98.4 | 41.7 | 18.3 | 3.3 | -47.3 | 0.0 | 65.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +5.5 | 180.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -76.8 | 0.0 | 65.0 | 4.3 | -119.2 | 0.0 | 110.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +16.7 | 180.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.0 | +83.9 | 0.0 | 24.0 | 1.0 | -21.2 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -36.5 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 80.0 |
| OPENS UP | - | - | - | - | 0.7 | +9.0 | 38.3 | 0.0 |
| OVERRUNS AWAY | 0.7 | +1.0 | 41.7 | 0.0 | 1.7 | +23.5 | 629.0 | 80.7 |
| PATHS CROSS | 0.3 | +4.4 | 0.0 | 0.0 | 1.0 | +142.6 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 46.7 | +364.9 | 174.3 | 296.3 | 41.3 | +438.8 | 1007.7 | 871.3 |
| PROMISE BY ITS OWN SUM | 9.0 | -189.8 | 0.0 | 40.0 | 9.7 | -458.5 | 0.0 | 72.7 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | -1.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.7 | -90.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.0 | -52.8 | 42.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.3 | +3092.0 | 268.3 | 36.7 | 25.0 | +2371.2 | 558.3 | 568.3 |
| RANDOM MOVE BY FIGURES | 4.0 | +107.0 | 0.0 | 48.3 | 4.7 | +109.4 | 0.0 | 113.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 80.0 |
| REDIRECT COUNTER | 2.3 | +187.3 | 0.0 | 24.0 | 1.7 | +39.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 100.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 4.3 | -97.4 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.0 | +13.9 | 0.0 | 24.0 | 0.7 | +24.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +15.9 | 109.7 | 0.0 | 4.0 | +62.5 | 851.3 | 161.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 2.0 | -5.7 | 83.3 | 0.0 | 1.3 | -0.2 | 720.0 | 38.7 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -97.3 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.3 | +238.2 | 0.0 | 0.0 |
| SECOND HUNTER | - | - | - | - | 0.3 | -0.3 | 180.0 | 38.7 |
| SECOND LOOK | 1.0 | +38.5 | 75.7 | 0.0 | 0.3 | +9.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.0 | -59.5 | 0.0 | 24.0 | - | - | - | - |
| SET UP BY THE SET | 3.0 | +37.5 | 34.0 | 24.0 | - | - | - | - |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 65.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +17.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.7 | +0.0 | 0.0 | 21.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +142.2 | 0.0 | 43.3 | - | - | - | - |
| SHOT RISK POINTS | 12.7 | -201.0 | 0.0 | 216.3 | 20.3 | +88.3 | 0.0 | 488.3 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.0 | +544.4 | 0.0 | 42.3 | 6.0 | +86.7 | 0.0 | 38.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +17.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +62.6 | 180.0 | 180.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 1.7 | -53.1 | 540.0 | 77.3 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 92.3 | 10.0 | +0.0 | 0.0 | 231.0 |
| STAND AND SHOOT | 0.7 | -0.5 | 0.0 | 0.0 | 0.7 | -4.1 | 42.3 | 42.0 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 39.7 | +0.0 | 352.7 | 98.3 | 27.7 | +0.0 | 0.0 | 214.0 |
| STAY WORTH | 11.3 | +126.2 | 197.3 | 0.0 | 4.7 | -7.1 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 1.0 | +2.2 | 540.0 | 38.7 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.7 | +468.7 | 0.0 | 56.7 | 5.0 | +156.6 | 0.0 | 114.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 180.0 | 38.7 |
| SUPPORT WORKED OUT | 7.7 | +468.7 | 0.0 | 56.7 | 5.0 | +156.6 | 0.0 | 114.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +6.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 24.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 18.3 | 0.0 | 6.7 | +0.0 | 68.0 | 117.7 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 41.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 41.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.3 | +0.0 | 0.0 | 185.7 | 37.3 | +0.0 | 0.0 | 450.7 |
| TIED UP BY THE SUM | 2.7 | +359.6 | 151.3 | 0.0 | 0.7 | +104.7 | 85.0 | 0.0 |
| TIME ON OUR SIDE | 29.3 | +270.4 | 42.0 | 184.0 | 17.3 | +173.1 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | +35.1 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | -4.1 | 48.0 | 84.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +0.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -244.8 | 0.0 | 0.0 | 8.0 | -761.0 | 0.0 | 326.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +1.5 | 180.0 | 0.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 24.0 | 42.0 |
| WOUNDS ON THE RANKS | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +143.6 | 0.0 | 83.7 |

### Rule changes: cnsr-c940641-p47

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 174 | 174 | 106 | 35.33 | +992 | +9.4 |
| HOLDER ASSIGNMENT | 60 | 60 | 56 | 18.67 | +2634 | +47.0 |
| LEGAL CHARGES ONLY | 42 | 42 | 42 | 14.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 205 | 193 | 41 | 13.67 | +439 | +10.7 |
| HIS SHOT LIST | 200 | 185 | 36 | 12.00 | +482 | +13.4 |
| FIVE ACTION | 549 | 523 | 35 | 11.67 | +3299 | +94.3 |
| QUARTER ODDS | 160 | 158 | 25 | 8.33 | +2836 | +113.4 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| MOVE TO CHARGE COMPUTED | 43 | 34 | 23 | 7.67 | +1763 | +76.6 |
| PROMISE BY ITS OWN SUM | 56 | 56 | 23 | 7.67 | -1945 | -84.6 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -438 | -19.9 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 26 | 26 | 15 | 5.00 | +649 | +43.3 |
| CHARGE LOSSES | 98 | 89 | 14 | 4.67 | +3083 | +220.2 |
| NEXT CHARGE BY LIST | 25 | 25 | 14 | 4.67 | +1458 | +104.1 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| GOAL WALK | 54 | 50 | 10 | 3.33 | +269 | +26.9 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| FOUR ROUNDS | 22 | 19 | 9 | 3.00 | +175 | +19.5 |
| SUPPORT ADDS | 38 | 37 | 8 | 2.67 | +112 | +14.0 |
| SUPPORT WORKED OUT | 38 | 37 | 8 | 2.67 | +112 | +14.0 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 10 | 8 | 8 | 2.67 | +281 | +35.2 |
| TIME ON OUR SIDE | 140 | 119 | 8 | 2.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOT RISK POINTS | 99 | 90 | 7 | 2.33 | +147 | +21.0 |
| WHOLE FIGHT DANGER | 34 | 33 | 7 | 2.33 | +1181 | +168.7 |
| CAST JOB | 6 | 6 | 6 | 2.00 | +9 | +1.6 |
| CHARGE NOW FIRST | 9 | 9 | 6 | 2.00 | -254 | -42.4 |
| COVER ONCE | 54 | 38 | 6 | 2.00 | +56 | +9.3 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 6 | 2.00 | +179 | +29.9 |
| CHAFF IN THE MOVE | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 13 | 13 | 5 | 1.67 | +273 | +54.6 |
| IDLE COST | 51 | 31 | 5 | 1.67 | +17 | +3.4 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +133 | +26.5 |
| PROMISE READS THE TABLE | 8 | 8 | 5 | 1.67 | -142 | -28.3 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +114 | +22.8 |
| RISK BY ARC | 18 | 15 | 5 | 1.67 | +80 | +16.1 |
| THE ROW IN ITS ORDER | 31 | 5 | 5 | 1.67 | +0 | +0.0 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +441 | +110.2 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +715 | +178.7 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +145 | +36.2 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -6 | -2.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| NEARER NOT NEEDED | 55 | 54 | 3 | 1.00 | +140 | +46.6 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -158 | -52.8 |
| REDIRECT COUNTER | 12 | 9 | 3 | 1.00 | +74 | +24.5 |
| SHOTS IN THE MOVE | 69 | 46 | 3 | 1.00 | +80 | +26.5 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +349 | +174.6 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +112 | +56.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +432 | +216.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +17 | +8.4 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +129 | +64.3 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +70 | +35.1 |
| ONE OBJECTIVE FORMULA | 24 | 18 | 2 | 0.67 | +64 | +32.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SET UP BY THE SET | 9 | 8 | 2 | 0.67 | +88 | +43.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| STAY WORTH | 48 | 39 | 2 | 0.67 | +9 | +4.5 |
| WHAT THE JOINER ADDS | 4 | 2 | 2 | 0.67 | +1 | +0.4 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 1 | 0.33 | +31 | +31.1 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +3 | +3.3 |
| EXACT ROUND | 13 | 12 | 1 | 0.33 | +1 | +0.9 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +37 | +37.5 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| HIS MOVE AND SHOT | 31 | 28 | 1 | 0.33 | +14 | +13.8 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +1 | +0.9 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -20 | -20.3 |
| MAX FOR POSITIONING | 5 | 5 | 1 | 0.33 | +2 | +1.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -109 | -109.3 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -8 | -8.2 |
| PROMISE KNOWS THE FIGHT | 9 | 4 | 1 | 0.33 | -4 | -3.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +81 | +81.2 |
| SHOTS AFTER THE MOVES | 7 | 7 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -2 | -1.7 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +9 | +9.2 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 2 | 1 | 1 | 0.33 | +0 | +0.4 |
| BACKUP TARGETS | 4 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 13 | 0 | 0.00 | - | - |
| FALLS SHORT | 76 | 69 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 12 | 11 | 0 | 0.00 | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 61 | 57 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 55 | 52 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 34 | 33 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 35 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 113 | 110 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 23 | 22 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 92 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 14 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 21 | 20 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 16 | 11 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| NO DOUBLE ROUNDS | 19 | 17 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 13 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 27 | 13 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 7 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 7 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 11 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 24 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 49 | 46 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 202 | 194 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 254 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 13 | 13 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p47

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 4.67 | 84.6 |
| JOB FIRST | gate | 3.67 | 2.00 | 15.7 |
| ARMY TABLE | rule | 2.33 | 2.67 | 114.2 |
| CHARGE NOW FIRST | rule | 1.67 | 0.33 | 42.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 28.3 |
| PROMISE READS THE TABLE | rule | 1.00 | - | 59.6 |
| PROMISE SHOT AWAY | rule | 1.00 | - | 52.8 |
| RULE SWITCHED OFF | gate | - | 1.00 | 33.5 |
| CHAFF PASSED | rule | - | 0.67 | 2.8 |
| JOINT CHARGE NOW | rule | - | 0.67 | 153.4 |
| AFTERMATH BAND | gate | - | 0.33 | 1.6 |
| MARCH OF THE TABLE | rule | - | 0.33 | 20.3 |
| NO REASON | gate | 0.33 | - | 69.3 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 109.3 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 8.2 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 3.7 |
| SUPPORT NARROWED | rule | 0.33 | - | 1.7 |

### Plans: cnsr-c940641-p47

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 44% | 394 | 157 | 40% |
| Mine | join | 1.7 | 100% | 96 | 0 | 0% |
| Mine | move | 38.7 | 95% | 2263 | 0 | 0% |
| Mine | shoot | 3.3 | 80% | 266 | 208 | 78% |
| Opponent | charge | 3.7 | 27% | 443 | 428 | 97% |
| Opponent | join | 0.7 | 50% | 20 | 0 | 0% |
| Opponent | move | 36.0 | 95% | 1618 | 0 | 0% |
| Opponent | shoot | 0.3 | 100% | 0 | 11 | - |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Packages: hunt the guns, cnsr-c940641-p47

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.7 | 2 | 1 | 0% | 0% | 0% | - | 546 | 0 | 0% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 1.0 | 2 | 1 | 0% | 0% | 0% | - | 546 | 0 | 0% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: cnsr-c940641-p47

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 14% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p47

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 103 (5) | 0 | 103 | 59 | 40% | 1.7 | 127 (4) | 0 (1) | - | 127 (4) | 0 (1) |
| Mine | Character | 9 | 21 (9) | 21 | 0 | 22 | 33% | 2.8 | 17 (7) | 37 (2) | - | 37 (4) | 7 (5) |
| Mine | Clean-up | 2 | 84 (2) | 44 | 39 | 0 | 0% | 4.0 | - | 106 (1) | 68 (1) | 68 (1) | 106 (1) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 24 | 50% | 1.5 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 4 | 154 (4) | 154 | 0 | 22 | 0% | 2.0 | 74 (1) | 223 (2) | 80 (1) | 181 (3) | 74 (1) |
| Mine | Holder | 7 | 38 (7) | 0 | 38 | 0 | 86% | 6.0 | 66 (4) | 0 (2) | 0 (1) | 41 (6) | 0 (1) |
| Mine | Shooter | 5 | 20 (5) | 0 | 20 | 41 | 20% | 1.0 | 109 (1) | 0 (2) | 0 (2) | 32 (3) | 0 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 9 | 12 (9) | 12 | 0 | 17 | 11% | 3.0 | 17 (6) | 0 (2) | 0 (1) | 17 (6) | 5 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 8 (5) | 8 | 0 | 42 | 40% | 2.7 | 0 (3) | - | 22 (2) | 0 (2) | 15 (3) |
| Opponent | Hammer | 10 | 9 (10) | 9 | 0 | 44 | 20% | 3.8 | 19 (4) | 0 (5) | 0 (1) | 24 (4) | 0 (6) |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 24 | 50% | 5.0 | - | 0 (3) | 0 (1) | 0 (4) | - |
| Opponent | Shooter | 3 | 25 (3) | 0 | 25 | 31 | 0% | 1.7 | 0 (1) | 40 (2) | - | - | 25 (3) |

### Charged fights: cnsr-c940641-p47

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 126 | 329 | 4.0 | 1.0 | 82 | 0 | +82 | 0 of 4 | 4 of 4 | - | +82 |
| Mine | Vampire Counts | 1 | 0 | 170 | 1.0 | 1.0 | 170 | 0 | +170 | 0 of 1 | 1 of 1 | - | +170 |
| **Mine** | all armies | 3 | 42 | 166 | 1.7 | 1.0 | 100 | 0 | +100 | 0 of 5 | 5 of 5 | - | +100 |
| Opponent | Warriors of Chaos | 2 | 28 | 30 | 2.0 | 1.5 | 15 | 164 | -149 | 3 of 4 | 3 of 4 | -116 | -160 |
| Opponent | Wood Elf Realms | 1 | 0 | 322 | 4.0 | 1.0 | 80 | 0 | +80 | 1 of 4 | 3 of 4 | - | +80 |
| **Opponent** | all armies | 3 | 18 | 127 | 2.7 | 1.2 | 48 | 82 | -34 | 4 of 8 | 6 of 8 | -116 | -23 |

### Effective charges: cnsr-c940641-p47

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 0 | 2 (net +62) | 0 | 2 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 1 (net +60) | 2 (net -58) | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 1 (net +72) | 1 (net +0) | 1 (net +55) | 1 (net +195) | 0 | 25% (1 of 4) |

### Charged fights, damage counted: cnsr-c940641-p47

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 421 | 125 | +62 | 134 | 23 | +111 | +26.4 |
| Mine | No odds | 3 | 334 | 125 | +125 | 171 | 16 | +155 | +46.3 |
| Mine | All fights | 5 | 369 | 125 | +100 | 156 | 19 | +137 | +37.2 |
| Opponent | Effective (55-75%) | 1 | 126 | 72 | +72 | 72 | 0 | +72 | +57.1 |
| Opponent | 76-89% | 1 | 126 | 72 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 330 | 358 | +26 | 83 | 63 | +21 | +6.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 496 | 58 | +58 | 58 | 0 | +58 | +11.6 |
| Opponent | No odds | 1 | 120 | 210 | -541 | 35 | 737 | -702 | -585.0 |
| Opponent | All fights | 8 | 294 | 193 | -34 | 59 | 116 | -57 | -19.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p47 | move | 20 | 2 (10%) | 1 (5%) | 4 (20%) | 14 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

# Doctrine scorecard: cnsr-c940641-p10

### Scorecard: cnsr-c940641-p10

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | no | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 4 | 1 | 1 | 0 | 0 | 327 |
| L1923 | 3 | 1 | Mine | no | 1 | 1 | 7 | 0 | 0 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | yes | 10 | 2 | 4 | 2 | 0 | 0 | 0 | 257 |
| L2025 | 3 | 1 | Mine | yes | 11 | - | 1 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 6.0 | 2.5 | 3.3 | 1.0 | 0.0 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 67% | 8.0 | 1.7 | 4.3 | 1.3 | 0.3 | 0.0 | 0.0 | 194.7 |

### KPIs: cnsr-c940641-p10

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 6% (1 of 16) | 4% (1 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (6 of 6); on the table 100% | 83% (5 of 6); on the table 100% | 92% (11 of 12); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 50% (3 of 6); on the table 67% | 50% (3 of 6); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 100% (6 of 6); on the table 100% | 69% (9 of 13); on the table 85% | 79% (15 of 19); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 13% (4 of 30) | 39% (7 of 18) | 23% (11 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 22% (4 of 18) | 39% (7 of 18) | 31% (11 of 36) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | - | 43% (3 of 7) |
| Points that never fought | lower | 25% (1476 of 5999) | 25% (1499 of 5999) | 25% (2975 of 11998) |
|   infantry points that never fought | lower | 75% (741 of 993) | 68% (702 of 1037) | 71% (1443 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 41% (9 of 22) | 56% (9 of 16) | 47% (18 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2474 of 5151) | 47% (2133 of 4500) | 48% (4607 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (4%) | 3.3 (91%) | 3.7 (30%) |
| MARCHED: its unit marched | 1.0 (12%) | 0.3 (9%) | 1.3 (11%) |
| CHARGED: its unit charged | 1.3 (15%) | 0.0 (0%) | 1.3 (11%) |
| IN COMBAT: engaged in combat | 1.3 (15%) | 0.0 (0%) | 1.3 (11%) |
| REAR RANK: in a rear rank | 0.7 (8%) | 0.0 (0%) | 0.7 (5%) |
| GONE: slain | 1.3 (15%) | 0.0 (0%) | 1.3 (11%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (15%) | 0.0 (0%) | 1.3 (11%) |
| NOT OFFERED: not in the cast list | 1.3 (15%) | 0.0 (0%) | 1.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.3 | 2.0 | 3.7 | 0.7 |
| not cast | 6.7 | 0.7 | 4.0 | 12.3 | 19.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 3.7 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (30%) | 0.0 (0%) | 2.0 (50%) | 0.7 (5%) | 0.0 (0%) |
| GONE: slain | 1.0 (15%) | 0.0 (0%) | 0.3 (8%) | 1.3 (11%) | 1.7 (9%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (20%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (35%) | 0.0 (0%) | 1.7 (42%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.3 (90%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.0 a game | 1.0 a game |
| stood (cast and not dispelled) | - | 67% (4 of 6) | 67% (4 of 6) |
| the unit moved after it | - | 100% (4 of 4) | 100% (4 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 50% (27 of 54) | 63% (48 of 76) | 58% (75 of 130) |
|   cavalry | - | 93% (14 of 15) | 93% (14 of 15) |
|   character | 83% (5 of 6) | 0% (0 of 17) | 22% (5 of 23) |
|   chariot | 55% (6 of 11) | - | 55% (6 of 11) |
|   infantry | 32% (8 of 25) | 77% (34 of 44) | 61% (42 of 69) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (11%) | 0.0 (0%) | 1.0 (5%) |
| CHARGED: it charged | 1.0 (11%) | 1.7 (18%) | 2.7 (15%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 1.0 (11%) | 1.3 (7%) |
| NO TARGET IN RANGE | 4.3 (48%) | 3.7 (39%) | 8.0 (44%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (7%) | 2.0 (21%) | 2.7 (15%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (4%) | 1.0 (11%) | 1.3 (7%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 1.0 (11%) | 0.0 (0%) | 1.0 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 2.3 | 62% | 8.7 pts | 46 pts |
| character | 1.7 | 1.0 | 60% | 19.5 pts | 32 pts |
| chariot | 2.3 | 1.7 | 71% | 19.3 pts | 45 pts |
| infantry | 17.0 | 7.7 | 69% | 8.2 pts | 139 pts |
| monster | 3.3 | 0.3 | 90% | 3.2 pts | 11 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.3 | 6.0 | 5.7 |
| Charges that made contact a game | 4.3 | 5.0 | 4.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 4.00 declared, 2.00 contact (1 units) | 4.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.46 contact (28 units) | 0.47 declared, 0.43 contact (30 units) | 0.52 declared, 0.45 contact (58 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 67% (2 of 3) | - | 67% (2 of 3) |
| Character in a unit | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |
| Character on its own | 0% (0 of 3) | 33% (1 of 3) | 43% (3 of 7) | 31% (4 of 13) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Monster | 25% (1 of 4) | 33% (1 of 3) | - | 29% (2 of 7) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 38% | 43% (3 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 0% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (4 of 4); on the table 100% | 17% (2 of 12) | 36% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 64% (7 of 11); on the table 82% | 0% (0 of 6) | 27% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 58% (7 of 12) | 20% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p10, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 58% (7) | 43% (3) | 53% (10) |
| ...free all their last turn and able to turn (per game) | 1.67 | 0.67 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.67 | 0.67 | 2.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p10

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 62% (5 of 8) | 69% (11 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (5 of 13) | 69% (11 of 16) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 50% (1 of 2) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 75% (6 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 1.3 |
| Movement | Points that never moved of their own | 225.0 | 194.7 |
| Movement | Fights charged into per game | 3.7 | 5.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net -540 | 2 of 12, net -152 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 7, net +270 | 0 of 12 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 7, net +66 | 1 of 12, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 7, net +108 | 7 of 12, net +87 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (12 of 28) | 30% (16 of 54) |
| Shooting | Points destroyed by shooting units | 0.0 | 22.7 |
| Shooting | Points destroyed by war machines | 23.3 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 15.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.0 / 0.3 / 0.0 | 1.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 530.3 | 582.0 |
| Combat | Points run down | 0.0 | 326.3 |
| Combat | Net points per charged fight, damage counted | -12 | +151 |
| Combat | Net per 100 charger points, damage counted | -6.4 | +50.6 |
| Combat | First round won (charged fights) | 55% | 80% |
| Combat | Net points per charged fight | +4 | +127 |
| Combat | Net points per supported fight / lone fight | +270 / -56 | - / +127 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 11 | 8 of 15 |
| Game | Points lost | 1241.3 | 535.3 |
| Game | VP from objectives | 503.3 | 1003.3 |
| Game | Lone holders (player turns) | 6.0 | 8.0 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -1369 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1777
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnsr-c940641-p10

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +10.2 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +32.6 | 0.0 | 0.0 |
| ARMY TABLE | 16.3 | +514.5 | 0.0 | 218.3 | 20.7 | +163.4 | 0.0 | 66.7 |
| ASSAILMENT BY POINTS | 0.3 | +0.3 | 0.0 | 108.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +2.2 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -8.3 | 21.7 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -263.9 | 131.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.7 | +32.4 | 66.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -2.9 | 78.3 | 42.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -23.2 | 0.0 | 84.7 |
| CHARGE LOSSES | 16.3 | -1093.9 | 0.0 | 394.3 | 14.3 | -670.2 | 0.0 | 161.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 22.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 1.0 | +0.0 | 94.3 | 0.0 | 3.3 | +0.0 | 623.0 | 16.7 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 13.3 | 14.7 | +0.0 | 0.0 | 231.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 70.0 | 1.3 | +0.0 | 286.7 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +46.0 | 0.0 | 0.0 |
| COVER ONCE | 8.3 | -322.6 | 0.0 | 107.3 | 4.3 | -183.9 | 0.0 | 72.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -1.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 36.7 | 7.3 | +33.6 | 0.0 | 23.3 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -17.3 | 65.7 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +7.1 | 150.7 | 0.0 |
| EXACT ROUND | 1.3 | +24.8 | 225.3 | 29.7 | 4.7 | -28.3 | 775.7 | 245.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 116.3 | 29.7 | 4.0 | +21.4 | 446.3 | 261.7 |
| FALLS SHORT | 2.0 | +19.0 | 0.0 | 103.3 | 15.7 | +149.4 | 0.0 | 144.3 |
| FEATURE BUFFS | 1.3 | +8.0 | 0.0 | 26.7 | 1.0 | +7.6 | 0.0 | 44.0 |
| FIGHT TO THE END | 0.7 | -0.1 | 49.0 | 0.0 | 2.0 | +1.8 | 233.3 | 101.3 |
| FIVE ACTION | 71.3 | +3795.3 | 932.3 | 1610.3 | 92.0 | +6876.8 | 1671.7 | 1111.0 |
| FLANK NOT WEIGHED | 10.3 | +0.0 | 0.0 | 309.3 | 3.7 | +0.0 | 0.0 | 48.3 |
| FOLLOW UP WEIGHED | 1.0 | +107.0 | 0.0 | 0.0 | 1.3 | +162.3 | 0.0 | 65.0 |
| FOUR ROUNDS | 3.0 | +139.5 | 476.3 | 29.7 | 6.0 | +589.5 | 841.3 | 346.3 |
| FREED FROM HIS FIGHT | 11.0 | +0.0 | 0.0 | 233.0 | 1.3 | +0.0 | 0.0 | 25.0 |
| FRIEND SHOOTS FIRST | 1.3 | -8.7 | 0.0 | 0.0 | 0.7 | -3.0 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -10.6 | 0.0 | 0.0 | 1.3 | -22.8 | 21.7 | 264.7 |
| GOAL WALK | 9.7 | +663.0 | 0.0 | 0.0 | 6.3 | +393.2 | 0.0 | 130.0 |
| GUN FIGURES | 3.0 | +36.5 | 30.0 | 105.0 | - | - | - | - |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 7.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 180.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 271.0 | 7.3 | +0.0 | 0.0 | 161.3 |
| HIS CHARGE DENIED | 1.3 | +47.7 | 409.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 68.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 131.0 | 3.0 | +0.0 | 0.0 | 98.0 |
| HIS MOVE AND SHOT | 2.7 | -8.8 | 0.0 | 123.3 | 7.7 | -110.7 | 0.0 | 15.0 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 143.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 131.0 | 6.7 | +0.0 | 0.0 | 98.0 |
| HIS RANDOM MOVE | - | - | - | - | 9.0 | +0.0 | 0.0 | 329.7 |
| HIS RANDOM MOVER COMES | - | - | - | - | 4.7 | +0.0 | 0.0 | 169.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 36.3 | +316.3 | 0.0 | 945.3 | 26.7 | +672.0 | 0.0 | 120.7 |
| HIS SHOTS BY HIS RUN | 35.7 | +174.2 | 0.0 | 672.3 | 35.7 | +674.6 | 0.0 | 288.7 |
| HIS TURN DENIED | 0.7 | +1.7 | 44.0 | 11.3 | 0.7 | +34.2 | 61.7 | 0.0 |
| HIS TURN RUN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.3 | +0.0 | 0.0 | 298.3 | 19.7 | +0.0 | 0.0 | 301.3 |
| HOLDER ASSIGNMENT | 7.7 | +533.5 | 0.0 | 226.0 | 10.7 | +841.3 | 0.0 | 128.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -57.4 | 116.3 | 29.7 | 4.7 | -206.9 | 763.0 | 264.7 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +13.1 | 0.0 | 0.0 |
| IDLE COST | 1.3 | -33.8 | 0.0 | 0.0 | 11.0 | -160.6 | 0.0 | 154.0 |
| JOINT CHARGE NOW | 0.7 | +115.8 | 360.0 | 0.0 | 0.3 | +7.1 | 0.0 | 180.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -7.1 | 0.0 | 84.7 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 0.0 | 1.7 | +89.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 285.7 | 217.7 | 13.0 | +0.0 | 883.0 | 892.3 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | +8.4 | 49.0 | 0.0 | 0.3 | +1.8 | 0.0 | 16.7 |
| LOST AFTER ESCAPE | 0.3 | -0.2 | 22.0 | 11.3 | 3.0 | +4.0 | 162.3 | 346.3 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 85.0 | 0.0 |
| MANOEUVRE | 1.3 | +37.0 | 0.0 | 25.7 | 1.3 | -16.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +51.5 | 0.0 | 0.0 | 0.7 | +23.1 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +48.1 | 0.0 | 64.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -17.4 | 0.0 | 0.0 | 1.0 | -10.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +57.7 | 0.0 | 26.7 | 2.0 | +37.4 | 0.0 | 40.0 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 18.3 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +42.6 | 0.0 | 244.0 | 3.7 | +23.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.0 | +36.7 | 0.0 | 244.0 | 4.7 | +19.6 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 25.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.0 | +88.0 | 0.0 | 0.0 | 13.0 | +1029.8 | 0.0 | 231.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.7 | +305.2 | 0.0 | 90.7 | 12.3 | +407.9 | 0.0 | 66.7 |
| NEXT CHARGE BY LIST | 0.7 | +31.7 | 0.0 | 0.0 | 8.0 | +709.6 | 22.7 | 169.3 |
| NO DOUBLE ROUNDS | 1.7 | -61.4 | 405.3 | 29.7 | 5.3 | -238.3 | 724.7 | 329.7 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.5 | 0.0 | 31.7 | - | - | - | - |
| OFF BEST | 3.0 | -143.4 | 0.0 | 11.3 | 6.7 | -339.9 | 0.0 | 106.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -55.9 | 0.0 | 141.7 | 9.0 | -177.2 | 0.0 | 197.0 |
| ONE JOINT FIGURE | 0.3 | +32.1 | 180.0 | 0.0 | 0.3 | +5.8 | 0.0 | 16.7 |
| ONE OBJECTIVE FORMULA | 4.3 | +19.6 | 0.0 | 182.0 | 5.0 | -71.0 | 0.0 | 86.7 |
| ONE PROMISE A TARGET | - | - | - | - | 1.0 | -16.8 | 22.7 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +59.2 | 41.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.9 | 22.0 | 11.3 | 1.3 | +24.2 | 61.7 | 65.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 36.0 | +778.2 | 360.3 | 1546.0 | 44.7 | +976.8 | 192.0 | 990.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 2.7 | -8.0 | 0.0 | 0.0 | 15.3 | -515.3 | 0.0 | 61.7 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 8.0 | -7.1 | 22.7 | 231.0 |
| PROMISE READS THE TABLE | 1.3 | -16.5 | 0.0 | 0.0 | 0.3 | -1.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.5 | 0.0 | 0.0 |
| QUARTER ODDS | 15.3 | +1825.2 | 325.0 | 391.0 | 23.7 | +2824.0 | 678.3 | 65.0 |
| RANDOM MOVE BY FIGURES | 2.3 | +30.1 | 0.0 | 70.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.3 | +131.2 | 0.0 | 38.0 | 3.0 | +100.7 | 0.0 | 106.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 93.3 | 3.0 | +0.0 | 0.0 | 59.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.0 | -68.8 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 84.7 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +60.1 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +6.4 | 0.0 | 0.0 | 0.7 | +38.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +111.3 | 454.3 | 18.3 | 4.0 | -55.9 | 348.0 | 261.7 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 4.0 | -190.8 | 441.7 | 346.3 |
| RUN DOWN | - | - | - | - | 4.7 | -51.6 | 438.7 | 346.3 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +8.9 | 0.0 | 61.7 | 2.0 | +75.2 | 0.0 | 22.0 |
| SECOND LOOK | 0.3 | +20.9 | 0.0 | 0.0 | 0.3 | +1.6 | 70.0 | 0.0 |
| SELF MOVE SPELL | 1.7 | -3.2 | 0.0 | 108.7 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -28.4 | 0.0 | 15.0 |
| SET UP BY THE SET | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +16.3 | 78.3 | 195.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 100.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +112.8 | 130.0 | 421.7 | 1.0 | +9.1 | 78.3 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -74.4 | 204.0 | 0.0 |
| SHOT RISK POINTS | 16.3 | -139.7 | 0.0 | 393.7 | 18.0 | +83.0 | 0.0 | 105.7 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 9.7 | +257.0 | 0.0 | 219.0 | 16.0 | +264.8 | 0.0 | 106.0 |
| SPELL WORTH | 0.7 | +9.7 | 180.0 | 180.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 456.0 | 5.0 | +0.0 | 0.0 | 156.3 |
| STAND AND SHOOT | 0.3 | -0.5 | 0.0 | 18.3 | 1.7 | -8.6 | 21.7 | 245.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 22.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 25.7 | +0.0 | 456.0 | 720.3 | 33.0 | +0.0 | 830.3 | 0.0 |
| STAY WORTH | 8.7 | +50.7 | 152.0 | 87.3 | 21.3 | +147.0 | 490.0 | 42.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | -71.4 | 262.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.0 | +861.5 | 0.0 | 43.3 | 4.3 | +117.2 | 0.0 | 44.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 49.0 | 0.0 | 0.3 | +0.0 | 0.0 | 16.7 |
| SUPPORT WORKED OUT | 8.0 | +861.5 | 0.0 | 43.3 | 4.3 | +117.2 | 0.0 | 44.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 173.0 | 2.0 | +0.0 | 0.0 | 133.7 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 4.0 | +0.0 | 0.0 | 134.7 | 1.0 | +0.0 | 0.0 | 49.0 |
| THE TABLE AGAIN | 5.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.3 | +0.0 | 0.0 | 325.0 | 44.7 | +0.0 | 0.0 | 382.3 |
| TIED UP BY THE SUM | 0.7 | +99.1 | 45.3 | 0.0 | 2.0 | +214.2 | 263.0 | 0.0 |
| TIME ON OUR SIDE | 32.3 | +326.0 | 44.0 | 417.0 | 21.0 | +181.1 | 0.0 | 84.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 153.3 | 61.7 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -105.0 | 233.3 | 0.0 |
| WHO FIGHTS | 0.7 | -2.4 | 22.0 | 29.7 | 0.3 | -0.4 | 20.0 | 0.0 |
| WHO HITS BACK | 1.0 | +26.4 | 0.0 | 11.3 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +17.8 | 116.7 | 0.0 |
| WHOLE FIGHT DANGER | 6.0 | -856.3 | 0.0 | 140.0 | 4.3 | -371.5 | 0.0 | 138.0 |
| WOUNDS ON THE RANKS | 2.7 | +138.0 | 0.0 | 131.0 | 1.0 | +0.9 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p10

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 111 | 111 | 73 | 24.33 | +1092 | +15.0 |
| LEGAL CHARGES ONLY | 52 | 52 | 52 | 17.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 55 | 55 | 49 | 16.33 | +2564 | +52.3 |
| FIVE ACTION | 490 | 478 | 45 | 15.00 | +2823 | +62.7 |
| HIS SHOT LIST | 189 | 182 | 30 | 10.00 | +117 | +3.9 |
| THE TABLE AGAIN | 33 | 33 | 30 | 10.00 | +0 | +0.0 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -1450 | -50.0 |
| HIS SHOTS BY HIS RUN | 214 | 210 | 27 | 9.00 | +452 | +16.8 |
| MOVE TO CHARGE COMPUTED | 45 | 39 | 26 | 8.67 | +722 | +27.8 |
| PROMISE BY ITS OWN SUM | 54 | 54 | 25 | 8.33 | -1570 | -62.8 |
| QUARTER ODDS | 117 | 117 | 21 | 7.00 | +1362 | +64.8 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| HARD STAY DROPPED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| SUPPORT ADDS | 37 | 37 | 18 | 6.00 | +532 | +29.5 |
| SUPPORT WORKED OUT | 37 | 37 | 18 | 6.00 | +532 | +29.5 |
| TIME ON OUR SIDE | 160 | 142 | 18 | 6.00 | +48 | +2.7 |
| FOUR ROUNDS | 27 | 25 | 16 | 5.33 | +916 | +57.2 |
| GOAL WALK | 48 | 46 | 15 | 5.00 | +486 | +32.4 |
| CHARGE LOSSES | 92 | 90 | 13 | 4.33 | +1153 | +88.7 |
| SHOT RISK POINTS | 103 | 103 | 12 | 4.00 | +158 | +13.1 |
| NEXT CHARGE BY LIST | 26 | 24 | 11 | 3.67 | +544 | +49.4 |
| THE RISK READS HIS RUN | 15 | 15 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +808 | +115.4 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| STAY WORTH | 90 | 80 | 7 | 2.33 | +12 | +1.7 |
| COMBAT PIVOT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| PROMISE KNOWS THE FIGHT | 24 | 21 | 6 | 2.00 | -22 | -3.6 |
| RISK BY ARC | 19 | 17 | 6 | 2.00 | +135 | +22.5 |
| COVER ONCE | 38 | 26 | 5 | 1.67 | +63 | +12.5 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +224 | +44.8 |
| TIED UP BY THE SUM | 8 | 7 | 5 | 1.67 | +101 | +20.2 |
| WHOLE FIGHT DANGER | 31 | 29 | 5 | 1.67 | +114 | +22.8 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 13 | 13 | 4 | 1.33 | -240 | -59.9 |
| MAX FOR POSITIONING | 13 | 10 | 4 | 1.33 | +13 | +3.1 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +180 | +45.1 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 4 | 1.33 | +178 | +44.5 |
| CASTING BLOCK | 5 | 5 | 3 | 1.00 | +1 | +0.3 |
| EXACT ROUND | 18 | 17 | 3 | 1.00 | +10 | +3.3 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +369 | +122.9 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +18 | +6.0 |
| ONE FIGHT FORMULA | 39 | 26 | 3 | 1.00 | +40 | +13.4 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -50 | -16.7 |
| RANDOM MOVE BY FIGURES | 7 | 7 | 3 | 1.00 | +90 | +30.1 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 1.00 | +135 | +45.0 |
| SEARCH SPOT | 7 | 7 | 3 | 1.00 | +252 | +84.1 |
| SET UP BY THE SET | 7 | 7 | 3 | 1.00 | +250 | +83.3 |
| SHOTS IN THE MOVE | 77 | 60 | 3 | 1.00 | +96 | +32.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +38 | +12.7 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -9 | -4.3 |
| HIS MOVE AND SHOT | 31 | 31 | 2 | 0.67 | +9 | +4.6 |
| NEARER NOT NEEDED | 60 | 57 | 2 | 0.67 | +35 | +17.4 |
| ONE JOINT FIGURE | 2 | 2 | 2 | 0.67 | +75 | +37.6 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +2 | +1.1 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -2 | -0.8 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +67 | +33.7 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -40 | -20.1 |
| THE ROW IN ITS ORDER | 9 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 11 | 11 | 2 | 0.67 | +61 | +30.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +31 | +30.7 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +98 | +97.8 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -25 | -25.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -50 | -49.9 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +1 | +1.2 |
| FALL BACK GOOD ORDER | 18 | 16 | 1 | 0.33 | +36 | +36.2 |
| FALLS SHORT | 53 | 44 | 1 | 0.33 | +6 | +6.2 |
| FEATURE BUFFS | 7 | 7 | 1 | 0.33 | +2 | +2.0 |
| FIGHT TO THE END | 8 | 6 | 1 | 0.33 | +1 | +1.2 |
| HIS CHARGE DENIED | 4 | 4 | 1 | 0.33 | +69 | +69.3 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +56 | +56.2 |
| HONEST WORTH | 20 | 18 | 1 | 0.33 | +1 | +1.2 |
| IDLE COST | 37 | 20 | 1 | 0.33 | +4 | +4.2 |
| LOST AFTER ESCAPE | 10 | 10 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +113 | +113.1 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 21 | 20 | 1 | 0.33 | +1 | +1.2 |
| ONE OBJECTIVE FORMULA | 28 | 16 | 1 | 0.33 | +38 | +37.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| REDIRECT COUNTER | 19 | 16 | 1 | 0.33 | +32 | +32.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SHOTS AFTER THE MOVES | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 1 | 0.33 | +4 | +3.5 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +8 | +7.9 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 65 | 65 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 37 | 36 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 24 | 23 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 58 | 58 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 13 | 13 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 27 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 14 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 15 | 15 | 0 | 0.00 | - | - |
| HIS TURN RUN | 35 | 35 | 0 | 0.00 | - | - |
| HOLD ODDS | 96 | 96 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 2 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 19 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 35 | 35 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 242 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 12 | 12 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 25 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 30 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 176 | 174 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 225 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p10

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 5.67 | 40.7 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 8.00 | 62.8 |
| ARMY TABLE | rule | 2.00 | 0.67 | 44.7 |
| PROMISE KNOWS THE FIGHT | rule | - | 2.00 | 3.6 |
| CHARGE NOW FIRST | rule | - | 1.33 | 59.9 |
| ONE PROMISE A TARGET | rule | - | 1.00 | 16.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.67 | 200.8 |
| CHAFF PASSED | rule | - | 0.67 | 4.3 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 0.8 |
| SUPPORT NARROWED | rule | 0.67 | - | 20.1 |
| BEST PRIZE | rule | - | 0.33 | 25.0 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 49.9 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 57.1 |
| NO REASON | gate | - | 0.33 | 9.4 |
| RULE SWITCHED OFF | gate | 0.33 | - | 21.7 |

### Plans: cnsr-c940641-p10

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 78% | 260 | 666 | 256% |
| Mine | move | 28.7 | 88% | 1387 | 0 | 0% |
| Mine | shoot | 4.3 | 46% | 334 | 113 | 34% |
| Opponent | charge | 5.0 | 67% | 664 | 709 | 107% |
| Opponent | join | 2.0 | 100% | 76 | 0 | 0% |
| Opponent | move | 33.0 | 94% | 1728 | 0 | 0% |
| Opponent | shoot | 4.7 | 79% | 254 | 268 | 106% |

### Battle groups: cnsr-c940641-p10

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 20% | 50% | 0% | - | 0% | 0% | 50% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 44% | 50% | 25% | 0% | 33% | 0% | 0% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p10

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 29 (7) | 20 | 9 | 88 | 14% | 2.5 | 33 (6) | 0 (1) | - | 29 (7) | - |
| Mine | Character | 8 | 49 (8) | 49 | 0 | 72 | 0% | 2.0 | 49 (3) | - | 56 (2) | - | 51 (5) |
| Mine | Clean-up | 4 | 101 (4) | 24 | 78 | 63 | 75% | 4.0 | 31 (2) | 155 (1) | 553 (1) | 62 (1) | 119 (3) |
| Mine | Fast Hammer | 1 | 1 (1) | 1 | 0 | 115 | 0% | 2.0 | 1 (1) | - | - | - | 1 (1) |
| Mine | Hammer | 11 | 32 (11) | 25 | 7 | 44 | 9% | 2.0 | 46 (3) | 26 (7) | 0 (1) | 40 (4) | 27 (7) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 67 | 0% | 2.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Mine | Wizard | 2 | 7 (2) | 7 | 0 | 126 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 8 | 138 (8) | 11 | 127 | 62 | 25% | 1.5 | 105 (2) | 146 (4) | 159 (2) | 157 (5) | 101 (3) |
| Opponent | Character | 8 | 71 (8) | 71 | 0 | 23 | 12% | 3.0 | 21 (5) | 152 (3) | - | 15 (3) | 103 (5) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 74 | 50% | 3.5 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Fast Hammer | 7 | 128 (7) | 128 | 0 | 26 | 14% | 3.8 | 228 (2) | 52 (5) | - | 251 (4) | 39 (3) |
| Opponent | Holder | 4 | 127 (4) | 13 | 114 | 23 | 0% | 1.5 | 250 (2) | - | 24 (2) | 250 (2) | 24 (2) |
| Opponent | Shooter | 4 | 7 (4) | 7 | 0 | 0 | 0% | 1.5 | 0 (2) | 14 (2) | - | 28 (2) | 0 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 2.7 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |

### Charged fights: cnsr-c940641-p10

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 70 | 610 | 4.0 | 1.5 | 152 | 22 | +130 | 2 of 4 | 2 of 4 | +270 | -10 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 126 | 5.0 | 1.0 | 25 | 43 | -18 | 2 of 5 | 3 of 5 | - | -18 |
| Mine | Skaven | 1 | 45 | 147 | 2.0 | 1.0 | 74 | 270 | -196 | 1 of 2 | 1 of 2 | - | -196 |
| **Mine** | all armies | 3 | 38 | 294 | 3.7 | 1.2 | 80 | 77 | +4 | 5 of 11 | 6 of 11 | +270 | -56 |
| Opponent | Tomb Kings of Khemri | 2 | 34 | 1100 | 5.5 | 1.0 | 200 | 24 | +176 | 6 of 11 | 10 of 11 | - | +176 |
| Opponent | Vampire Counts | 1 | 0 | 275 | 4.0 | 1.0 | 69 | 76 | -7 | 2 of 4 | 2 of 4 | - | -7 |
| **Opponent** | all armies | 3 | 23 | 825 | 5.0 | 1.0 | 165 | 38 | +127 | 8 of 15 | 12 of 15 | - | +127 |

### Effective charges: cnsr-c940641-p10

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 2 (net +270) | 0 | 0 | 1 (net +70) | 1 | 67% (2 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 1 (net -55) | 1 (net +66) | 0 | 3 | 0% (0 of 2) |
| Mine | Skaven | 2 | 1 (net -540) | 0 | 0 | 0 | 0 | 1 (net +147) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 11 | 0 | 0 | 0 | 2 (net +78) | 1 (net +0) | 6 (net +102) | 2 | 0% (0 of 9) |
| Opponent | Vampire Counts | 4 | 2 (net -152) | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: cnsr-c940641-p10

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 0 | 480 | -540 | 0 | 540 | -540 | - |
| Mine | Effective (55-75%) | 2 | 265 | 253 | +270 | 270 | 86 | +184 | +69.6 |
| Mine | 76-89% | 1 | 55 | 66 | -55 | 0 | 55 | -55 | -100.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 188 | 108 | +108 | 108 | 3 | +106 | +56.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 343 | 66 | +66 | 66 | 0 | +66 | +19.2 |
| Mine | No odds | 4 | 210 | 222 | -47 | 15 | 62 | -47 | -22.6 |
| Mine | All fights | 11 | 195 | 202 | +4 | 80 | 93 | -12 | -6.4 |
| Opponent | Long shot (under 50%) | 2 | 152 | 35 | -152 | 34 | 152 | -118 | -77.6 |
| Opponent | 76-89% | 2 | 313 | 300 | +78 | 217 | 98 | +119 | +38.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 320 | 233 | +87 | 142 | 33 | +109 | +34.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 195 | 60 | +0 | 50 | 0 | +50 | +25.6 |
| Opponent | No odds | 3 | 372 | 268 | +484 | 484 | 0 | +484 | +130.1 |
| Opponent | All fights | 15 | 299 | 211 | +127 | 200 | 49 | +151 | +50.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p10 | move | 25 | 10 (40%) | 10 (40%) | 3 (12%) | 12 (48%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

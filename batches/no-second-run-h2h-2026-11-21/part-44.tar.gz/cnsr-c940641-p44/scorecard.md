# Doctrine scorecard: cnsr-c940641-p44

### Scorecard: cnsr-c940641-p44

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | yes | 3 | 2 | 5 | 1 | 2 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 4 | 0 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 123 |
| L1435 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 2.3 | 2.0 | 2.0 | 0.3 | 0.0 | 0.0 | 87.7 |
| **Average** | | | Opponent | 50% | 1.5 | 3.5 | 3.3 | 1.3 | 1.0 | 0.0 | 0.0 | 101.7 |

### KPIs: cnsr-c940641-p44

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 16) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 75% (3 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 100% | 100% (2 of 2); on the table 100% | 83% (5 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 22% (4 of 18) | - | 22% (4 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (4 of 10) | - | 40% (4 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 44% (2662 of 6000) | 48% (2875 of 6000) | 46% (5537 of 12000) |
|   infantry points that never fought | lower | 56% (516 of 923) | 64% (747 of 1159) | 61% (1263 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (16 of 26) | 71% (17 of 24) | 66% (33 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 2.0 uses a game | 100% (2 of 2); 1.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 2.7 uses a game | 0.0 uses a game | 36% (5 of 14); 1.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (3144 of 5860) | 69% (3525 of 5131) | 61% (6669 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (14%) | - | 0.7 (14%) |
| MARCHED: its unit marched | 1.3 (29%) | - | 1.3 (29%) |
| IN COMBAT: engaged in combat | 0.3 (7%) | - | 0.3 (7%) |
| GONE: slain | 2.3 (50%) | - | 2.3 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 4.0 | 2.7 | 1.3 | 0.7 |
| not cast | 3.7 | 6.0 | 5.3 | 4.7 | 27.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (50%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (29%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.3 (7%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (55%) | 2.0 (33%) | 2.0 (38%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (36%) | 1.0 (17%) | 2.3 (44%) | 2.3 (50%) | 7.0 (26%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (9%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 88% (7 of 8) | - | 88% (7 of 8) |
| the unit moved after it | 0% (0 of 7) | - | 0% (0 of 7) |
| it charged on its next turn | 0% (0 of 7) | - | 0% (0 of 7) |
| the enemy charged it first | 14% (1 of 7) | - | 14% (1 of 7) |
| it fought by the end of its next turn | 29% (2 of 7) | - | 29% (2 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 7) | - | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 71% (5 of 7) | - | 71% (5 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (48 of 82) | 58% (62 of 106) | 59% (110 of 188) |
|   cavalry | 48% (12 of 25) | 76% (19 of 25) | 62% (31 of 50) |
|   character | 19% (4 of 21) | 47% (7 of 15) | 31% (11 of 36) |
|   chariot | - | 67% (8 of 12) | 67% (8 of 12) |
|   infantry | 83% (20 of 24) | 50% (21 of 42) | 62% (41 of 66) |
|   monster | - | 58% (7 of 12) | 58% (7 of 12) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (18%) | 1.3 (9%) | 3.3 (13%) |
| CHARGED: it charged | 2.0 (18%) | 2.3 (16%) | 4.3 (17%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 1.0 (7%) | 1.3 (5%) |
| NO TARGET IN RANGE | 4.0 (35%) | 5.0 (34%) | 9.0 (35%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.0 (7%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.0 (26%) | 2.7 (18%) | 5.7 (22%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 1.0 (7%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 15.7 | 1.3 | 91% | 2.3 pts | 36 pts |
| character | 5.3 | 1.7 | 69% | 9.0 pts | 48 pts |
| chariot | 2.7 | 1.3 | 75% | 31.2 pts | 83 pts |
| infantry | 19.0 | 6.3 | 77% | 12.5 pts | 238 pts |
| monster | 2.3 | 1.3 | 57% | 35.7 pts | 83 pts |
| war machine | 4.0 | 1.3 | 83% | 10.8 pts | 43 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 4.7 | 4.3 |
| Charges that made contact a game | 2.7 | 2.7 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | - | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.30 contact (23 units) | 0.42 declared, 0.24 contact (33 units) | 0.45 declared, 0.27 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (10 of 17) | - | - | 59% (10 of 17) |
| Character in a unit | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Character on its own | - | 75% (3 of 4) | 38% (3 of 8) | 50% (6 of 12) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (8 of 10) | 100% (1 of 1) | - | 82% (9 of 11) |
| Monster | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Monstrous | 50% (1 of 2) | 50% (1 of 2) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 75% (3 of 4); on the table 100% | 22% (4 of 18) | 44% | 62% (16 of 26) | 100% (1 of 1); 2.0 uses a game | 36% (5 of 14); 2.7 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 58% | 86% (6 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | - | 33% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 52% | 67% (8 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p44, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 60% (3) | 62% (5) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnsr-c940641-p44

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 67% (8 of 12) | 22% (2 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 53% (17 of 32) | 43% (9 of 21) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | 33% (2 of 6) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 2) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 2.0 | 1.3 |
| Movement | Points that never moved of their own | 87.7 | 101.7 |
| Movement | Fights charged into per game | 2.3 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 1 of 3, net +143 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +0 | 1 of 3, net -265 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 7, net +110 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 7, net +347 | 1 of 3, net +400 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.3 | 22.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (17 of 46) | 73% (49 of 67) |
| Shooting | Points destroyed by shooting units | 11.3 | 217.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 92% (11 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | - |
| Magic | Wounds caused by magic missiles | 0.7 | 2.0 |
| Magic | Wounds caused by other spells | 3.7 | - |
| Magic | Points destroyed by magic (all spells) | 48.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.7 / 0.7 / 0.0 | 2.7 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 542.0 | 181.0 |
| Combat | Points run down | 191.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +120 | -78 |
| Combat | Net per 100 charger points, damage counted | +30.0 | -29.6 |
| Combat | First round won (charged fights) | 100% | 14% |
| Combat | Net points per charged fight | +128 | -62 |
| Combat | Net points per supported fight / lone fight | +66 / +139 | - / -62 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 4 of 8 |
| Game | Points lost | 448.3 | 928.7 |
| Game | VP from objectives | 326.7 | 986.7 |
| Game | Lone holders (player turns) | 0.0 | 1.5 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -108 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1377
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p44

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +23.6 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +32.0 | 0.0 | 0.0 |
| ARMY TABLE | 26.3 | +351.0 | 0.0 | 329.3 | 32.7 | +487.7 | 0.0 | 648.7 |
| ASSAILMENT BY POINTS | 0.3 | +2.0 | 0.0 | 133.3 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -30.3 | 76.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 1.0 | +0.2 | 0.0 | 145.7 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +59.6 | 873.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -30.9 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +12.8 | 0.0 | 0.0 | 0.7 | +15.7 | 0.0 | 231.3 |
| CASTS AFTER FRIENDS | 2.3 | +0.0 | 0.0 | 300.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +15.1 | 0.0 | 22.7 |
| CHAFF PASSED | 0.7 | -9.2 | 180.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +57.3 | 0.0 | 50.3 | 1.0 | +51.5 | 0.0 | 157.3 |
| CHARGE LOSSES | 23.7 | -1362.9 | 0.0 | 1163.3 | 9.7 | -609.2 | 0.0 | 444.7 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 303.0 | 0.0 | 2.0 | +0.0 | 133.3 | 143.7 |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 100.7 | 16.7 | +0.0 | 0.0 | 150.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.7 | +536.1 | 433.3 | 433.3 | - | - | - | - |
| COVER ONCE | 14.3 | -855.1 | 0.0 | 581.7 | 7.0 | -567.4 | 0.0 | 179.0 |
| DENIED BY THE FIGHT | 0.3 | -2.0 | 0.0 | 0.0 | 0.3 | -0.3 | 133.3 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -53.8 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +47.2 | 0.0 | 0.0 |
| EXACT ROUND | 2.7 | +10.3 | 224.0 | 0.0 | 2.0 | +41.8 | 181.0 | 347.0 |
| FALL BACK GOOD ORDER | 3.3 | +16.4 | 339.7 | 0.0 | 3.3 | +35.1 | 181.0 | 527.0 |
| FALLS SHORT | 11.7 | +112.9 | 0.0 | 166.7 | 14.7 | +167.0 | 0.0 | 80.0 |
| FEATURE BUFFS | 1.7 | +15.5 | 0.0 | 0.0 | 1.3 | +17.3 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.0 | 0.0 | 143.7 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 95.3 | +4479.0 | 2588.3 | 1364.7 | 102.3 | +7437.6 | 1781.7 | 2047.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 498.7 | 7.3 | +0.0 | 0.0 | 379.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +91.8 | 0.0 | 143.7 |
| FOUR ROUNDS | 4.0 | +137.1 | 383.7 | 0.0 | 3.3 | +208.7 | 181.0 | 527.0 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 100.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 6.0 | +446.5 | 0.0 | 266.7 | 8.7 | +557.4 | 0.0 | 23.3 |
| GUN FIGURES | - | - | - | - | 1.3 | +3.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 25.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 16.7 | +0.0 | 0.0 | 1163.3 | 6.3 | +0.0 | 0.0 | 356.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +9.5 | 0.0 | 0.0 |
| HIS CHARGE LIST | 7.0 | +0.0 | 0.0 | 100.7 | 18.7 | +0.0 | 0.0 | 374.7 |
| HIS LEGAL MOVES | 8.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 65.0 |
| HIS MOVE AND SHOT | 6.7 | -61.8 | 0.0 | 445.7 | 2.7 | -10.3 | 0.0 | 0.0 |
| HIS ONE QUARTER | 9.0 | +0.0 | 0.0 | 196.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 11.7 | +0.0 | 0.0 | 47.7 | 3.7 | +0.0 | 0.0 | 65.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 64.0 | +3060.9 | 0.0 | 964.7 | 65.7 | +2253.7 | 0.0 | 1052.0 |
| HIS SHOTS BY HIS RUN | 58.7 | +1917.5 | 0.0 | 1364.7 | 37.7 | +551.0 | 0.0 | 771.7 |
| HIS TURN DENIED | 1.3 | +169.5 | 66.0 | 0.0 | 0.7 | +59.0 | 133.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 50.3 | 18.0 | +0.0 | 0.0 | 120.0 |
| HOLDER ASSIGNMENT | 8.7 | +923.8 | 0.0 | 50.3 | 10.7 | +884.2 | 0.0 | 60.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -147.1 | 383.7 | 0.0 | 2.7 | -139.4 | 181.0 | 503.7 |
| IDLE COST | 8.0 | -101.5 | 0.0 | 166.7 | 15.0 | -189.9 | 0.0 | 153.3 |
| JOINT CHARGE NOW | 1.0 | +2.0 | 66.0 | 0.0 | 1.0 | +28.4 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 50.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 152.7 | 98.0 | 10.3 | +0.0 | 367.3 | 886.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +10.7 | 22.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +1.4 | 151.0 | 0.0 | 1.7 | +1.5 | 47.7 | 23.3 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -138.5 | 0.0 | 22.7 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +7.9 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +57.6 | 0.0 | 13.3 |
| MARCH BY THE SUM | 0.7 | +109.3 | 0.0 | 133.3 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +15.8 | 0.0 | 300.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +171.9 | 0.0 | 300.0 | 0.3 | -82.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +12.9 | 0.0 | 0.0 | 3.0 | +116.8 | 0.0 | 22.7 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +44.4 | 0.0 | 0.0 | 3.0 | +84.0 | 0.0 | 231.3 |
| MISSILES NEXT TURN | 5.0 | +30.8 | 0.0 | 433.3 | 3.3 | +86.5 | 0.0 | 115.7 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 166.7 | 1.7 | +0.0 | 23.3 | 20.0 |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 300.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.3 | +701.0 | 0.0 | 47.7 | 3.0 | +212.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.7 | +327.0 | 0.0 | 0.0 | 9.7 | +369.4 | 0.0 | 99.0 |
| NEXT CHARGE BY LIST | 3.7 | +448.3 | 0.0 | 47.7 | 2.3 | +178.4 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -141.7 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.7 | -56.3 | 342.0 | 0.0 | 2.3 | -171.2 | 181.0 | 323.7 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 11.3 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -233.7 | 0.0 | 47.7 | 3.3 | -131.6 | 0.0 | 65.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 11.3 |
| ONE FIGHT FORMULA | 7.3 | -169.2 | 0.0 | 214.3 | 2.3 | -58.1 | 0.0 | 65.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +42.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | +143.4 | 0.0 | 0.0 | 5.3 | -172.9 | 0.0 | 60.0 |
| ONE PROMISE A TARGET | 0.3 | -9.9 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.3 | +2.3 | 45.3 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +15.7 | 36.7 | 0.0 | 0.3 | +28.4 | 0.0 | 180.0 |
| OVERRUNS AWAY | 3.0 | +188.3 | 347.0 | 0.0 | 0.7 | +0.5 | 0.0 | 0.0 |
| PLAN RESULT | 42.7 | +567.0 | 830.7 | 763.3 | 47.7 | +860.5 | 881.0 | 1555.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.3 | -228.6 | 0.0 | 0.0 | 8.7 | -202.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | -13.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -16.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 18.0 | +1759.6 | 1066.7 | 196.0 | 16.0 | +2280.8 | 148.3 | 456.7 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 4.3 | +505.1 | 0.0 | 58.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.3 | +0.0 | 0.0 | 69.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -126.5 | 0.0 | 47.7 | 1.0 | -34.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 143.7 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +22.9 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | -154.4 | 383.7 | 0.0 | 2.3 | -17.4 | 181.0 | 203.3 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -21.4 | 152.3 | 0.0 | 1.0 | -20.6 | 133.3 | 143.7 |
| RUN DOWN | 1.3 | -11.8 | 165.7 | 0.0 | 2.7 | -12.9 | 47.7 | 347.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -41.4 | 0.0 | 11.3 |
| SEARCH SPOT | 0.3 | +1.5 | 0.0 | 0.0 | 0.3 | +7.6 | 0.0 | 38.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -5.5 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.0 | -11.8 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +7.9 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +90.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 203.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +33.7 | 41.7 | 0.0 | 2.7 | +67.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -44.4 | 130.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 40.0 | -562.0 | 0.0 | 1100.0 | 21.0 | +61.2 | 0.0 | 365.3 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.3 | +418.3 | 0.0 | 0.0 | 23.0 | +1107.6 | 0.0 | 282.0 |
| SPELL SETS UP CHARGE | 0.7 | +90.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +15.4 | 266.7 | 266.7 | 1.7 | +7.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +1.7 | 44.0 | 0.0 | 0.7 | -8.4 | 47.7 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 300.0 | 5.7 | +0.0 | 0.0 | 60.0 |
| STAND AND SHOOT | 0.7 | -5.6 | 22.0 | 0.0 | 0.7 | -35.2 | 0.0 | 180.0 |
| STANDS FOR A REASON | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 43.0 | +0.0 | 2204.7 | 201.3 | 36.7 | +0.0 | 1600.7 | 915.0 |
| STAY WORTH | 22.3 | +132.7 | 528.0 | 0.0 | 15.7 | +151.6 | 550.3 | 96.0 |
| SUPPORT ADDS | 3.7 | +141.5 | 0.0 | 100.7 | 4.3 | +315.0 | 0.0 | 22.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 22.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.7 | +141.5 | 0.0 | 100.7 | 4.3 | +315.0 | 0.0 | 22.7 |
| SURE REACH TOGETHER | - | - | - | - | 1.3 | +30.7 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 133.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -16.3 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 53.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 53.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.3 | +0.0 | 0.0 | 682.3 | 49.0 | +0.0 | 0.0 | 640.7 |
| TIED UP BY THE SUM | 2.7 | +248.9 | 144.3 | 0.0 | 1.3 | +230.8 | 0.0 | 323.7 |
| TIME ON OUR SIDE | 31.3 | +340.9 | 41.7 | 619.0 | 24.7 | +282.5 | 0.0 | 870.3 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | -5.8 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | - | - | - | - | 2.3 | +0.0 | 666.7 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -37.1 | 0.0 | 46.7 |
| WHO FIGHTS | 0.7 | -2.1 | 44.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 1.0 | +197.7 | 0.0 | 0.0 | 0.7 | +28.8 | 0.0 | 143.7 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +25.0 | 0.0 | 23.3 |
| WHOLE FIGHT DANGER | 3.7 | -409.6 | 0.0 | 398.0 | 2.7 | -436.7 | 0.0 | 333.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +59.7 | 0.0 | 0.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 180.0 |

### Rule changes: cnsr-c940641-p44

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 177 | 177 | 140 | 46.67 | +2116 | +15.1 |
| HIS SHOT LIST | 389 | 376 | 97 | 32.33 | +1731 | +17.8 |
| HIS SHOTS BY HIS RUN | 289 | 281 | 60 | 20.00 | +1129 | +18.8 |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +3988 | +73.9 |
| LEGAL CHARGES ONLY | 42 | 42 | 42 | 14.00 | +0 | +0.0 |
| SHOT RISK POINTS | 183 | 180 | 36 | 12.00 | +1087 | +30.2 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -1096 | -47.6 |
| PROMISE BY ITS OWN SUM | 54 | 54 | 23 | 7.67 | -1293 | -56.2 |
| MOVE TO CHARGE COMPUTED | 28 | 27 | 20 | 6.67 | +1072 | +53.6 |
| TIME ON OUR SIDE | 168 | 152 | 18 | 6.00 | +91 | +5.0 |
| FIVE ACTION | 593 | 575 | 17 | 5.67 | +882 | +51.9 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| QUARTER ODDS | 102 | 100 | 14 | 4.67 | +1487 | +106.2 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| COVER ONCE | 64 | 46 | 12 | 4.00 | +222 | +18.5 |
| GOAL WALK | 44 | 44 | 12 | 4.00 | +645 | +53.7 |
| NEXT CHARGE BY LIST | 18 | 18 | 12 | 4.00 | +952 | +79.4 |
| TIED UP BY THE SUM | 12 | 12 | 10 | 3.33 | +380 | +38.0 |
| CHARGE LOSSES | 100 | 99 | 9 | 3.00 | +1094 | +121.5 |
| FOUR ROUNDS | 22 | 21 | 9 | 3.00 | +216 | +24.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 8 | 2.67 | +73 | +9.1 |
| SUPPORT ADDS | 24 | 24 | 7 | 2.33 | +79 | +11.3 |
| SUPPORT WORKED OUT | 24 | 24 | 7 | 2.33 | +79 | +11.3 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +326 | +54.4 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +91 | +15.2 |
| THE RISK READS HIS RUN | 18 | 18 | 6 | 2.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 15 | 15 | 5 | 1.67 | -256 | -51.2 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 121 | 96 | 5 | 1.67 | +111 | +22.3 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +574 | +114.9 |
| NEARER NOT NEEDED | 52 | 51 | 4 | 1.33 | +145 | +36.2 |
| RISK BY ARC | 19 | 19 | 4 | 1.33 | +161 | +40.3 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 1.00 | +0 | +0.2 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 14 | 14 | 3 | 1.00 | +35 | +11.8 |
| FALLS SHORT | 79 | 69 | 3 | 1.00 | +7 | +2.4 |
| HIS TURN DENIED | 6 | 6 | 3 | 1.00 | +210 | +70.1 |
| IDLE COST | 69 | 54 | 3 | 1.00 | +18 | +5.8 |
| MANOEUVRE | 14 | 14 | 3 | 1.00 | +216 | +72.2 |
| MAX FOR POSITIONING | 16 | 15 | 3 | 1.00 | +13 | +4.2 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 3 | 1.00 | -41 | -13.6 |
| WHOLE FIGHT DANGER | 19 | 19 | 3 | 1.00 | +328 | +109.4 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +22 | +11.2 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -27 | -13.7 |
| FALL BACK GOOD ORDER | 20 | 19 | 2 | 0.67 | +11 | +5.5 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS MOVE AND SHOT | 28 | 28 | 2 | 0.67 | +70 | +35.1 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +328 | +164.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -47 | -23.7 |
| OVERRUNS AWAY | 11 | 11 | 2 | 0.67 | +43 | +21.6 |
| REDIRECT COUNTER | 13 | 12 | 2 | 0.67 | +134 | +66.8 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +69 | +34.3 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +27 | +13.6 |
| SET UP BY THE SET | 3 | 3 | 2 | 0.67 | +79 | +39.5 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +71 | +70.7 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +96 | +96.0 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -163 | -163.1 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -93 | -92.8 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 4 | 4 | 1 | 0.33 | +92 | +92.5 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +276 | +275.5 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MISSILES IN THE MOVE | 18 | 15 | 1 | 0.33 | +1 | +0.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -30 | -29.7 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +52 | +52.4 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +168 | +167.9 |
| SHOTS AFTER THE MOVES | 19 | 19 | 1 | 0.33 | +0 | +0.0 |
| STAY WORTH | 114 | 104 | 1 | 0.33 | +0 | +0.3 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -17 | -17.4 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +25 | +25.1 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.33 | -11 | -10.7 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CANNON PLANNED TARGET | 12 | 12 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 77 | 77 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| FEATURE BUFFS | 9 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 14 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 69 | 69 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 77 | 74 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 33 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 34 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 46 | 44 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 97 | 97 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 19 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 25 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 18 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 29 | 20 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 28 | 25 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 11 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 48 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 36 | 35 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 17 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 239 | 225 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 28 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 20 | not checked | - | - | - | - |
| THE TABLE BINDS | 283 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p44

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 4.00 | 56.2 |
| JOB FIRST | gate | 4.00 | 3.33 | 40.9 |
| ARMY TABLE | rule | 4.33 | 2.67 | 26.8 |
| CHARGE NOW FIRST | rule | 1.33 | 0.33 | 51.2 |
| JOINT CHARGE NOW | rule | 0.67 | 0.33 | 48.4 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 13.6 |
| CHAFF PASSED | rule | 0.67 | - | 13.7 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| MARCH OF THE TABLE | rule | 0.67 | - | 23.7 |
| BEST PRIZE | rule | 0.33 | - | 163.1 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 92.8 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 5.0 |
| NO REASON | gate | 0.33 | - | 195.2 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 29.7 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 17.4 |
| WOUNDED STAYS OUT | rule | - | 0.33 | 10.7 |

### Plans: cnsr-c940641-p44

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 73% | 428 | 235 | 55% |
| Mine | move | 30.3 | 96% | 1608 | 0 | 0% |
| Mine | shoot | 8.7 | 69% | 220 | 332 | 151% |
| Opponent | charge | 3.0 | 44% | 477 | 260 | 54% |
| Opponent | move | 38.7 | 94% | 2040 | 0 | 0% |
| Opponent | shoot | 5.0 | 60% | 825 | 601 | 73% |
| Opponent | support | 1.0 | 67% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p44

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.3 | 23% | 100% | 33% | 0% | 0% | 0% | 0% | 50% | 50% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p44

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 77 (7) | 77 | 0 | 30 | 0% | 1.4 | 62 (5) | 219 (1) | 0 (1) | 50 (5) | 134 (2) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 14 | 21 (14) | 6 | 14 | 23 | 50% | 2.9 | 11 (8) | 34 (6) | - | 24 (9) | 14 (5) |
| Mine | Shooter | 4 | 5 (4) | 5 | 0 | 0 | 0% | 1.0 | 0 (3) | 19 (1) | - | 7 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 7 | 182 (7) | 0 | 182 | 70 | 14% | 2.3 | - | 287 (4) | 82 (3) | 338 (4) | 72 (3) |
| Opponent | Character | 4 | 34 (4) | 34 | 0 | 75 | 0% | 1.2 | - | 34 (4) | - | 0 (2) | 63 (2) |
| Opponent | Clean-up | 4 | 42 (4) | 42 | 0 | 41 | 25% | 4.0 | 0 (1) | 70 (2) | 0 (1) | 52 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 4 (4) | 0 | 4 | 29 | 25% | 2.7 | 8 (2) | 0 (2) | - | 6 (3) | 0 (1) |
| Opponent | Hammer | 8 | 33 (8) | 33 | 0 | 31 | 25% | 2.5 | 115 (2) | 0 (3) | 0 (3) | 0 (4) | 55 (4) |
| Opponent | Holder | 3 | 141 (3) | 0 | 141 | 31 | 0% | 3.7 | 450 (1) | 0 (1) | 0 (1) | 450 (1) | 0 (2) |
| Opponent | Shooter | 4 | 66 (4) | 28 | 38 | 41 | 0% | 2.5 | 0 (1) | 83 (2) | 137 (1) | 161 (2) | 0 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 61 | 0% | 2.7 | 0 (2) | - | - | 0 (1) | 0 (1) |

### Charged fights: cnsr-c940641-p44

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 59 | 300 | 2.3 | 1.1 | 128 | 0 | +128 | 2 of 7 | 7 of 7 | +66 | +139 |
| Opponent | Ogre Kingdoms | 1 | 500 | 0 | 2.0 | 1.0 | 0 | 248 | -248 | 1 of 2 | 0 of 2 | - | -248 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 551 | 4.0 | 1.0 | 138 | 174 | -36 | 2 of 4 | 1 of 3 | - | -36 |
| Opponent | Wood Elf Realms | 1 | 151 | 143 | 2.0 | 1.0 | 72 | 0 | +72 | 1 of 2 | 0 of 2 | - | +72 |
| **Opponent** | all armies | 3 | 217 | 231 | 2.7 | 1.0 | 87 | 149 | -62 | 4 of 8 | 1 of 7 | - | -62 |

### Effective charges: cnsr-c940641-p44

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 7 | 0 | 0 | 1 (net +0) | 0 | 5 (net +110) | 1 (net +347) | 0 | 14% (1 of 7) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 1 (net -265) | 0 | 0 | 1 (net +400) | 2 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 2 | 1 (net +143) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p44

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 342 | 195 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 489 | 297 | +347 | 347 | 60 | +287 | +58.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 393 | 82 | +110 | 110 | 0 | +110 | +28.1 |
| Mine | All fights | 7 | 400 | 129 | +128 | 128 | 9 | +120 | +30.0 |
| Opponent | Long shot (under 50%) | 1 | 102 | 143 | +143 | 143 | 34 | +109 | +106.9 |
| Opponent | Effective (55-75%) | 1 | 70 | 342 | -265 | 0 | 265 | -265 | -378.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 440 | 400 | +400 | 400 | 0 | +400 | +90.9 |
| Opponent | No odds | 5 | 299 | 312 | -155 | 58 | 231 | -174 | -58.1 |
| Opponent | All fights | 8 | 263 | 306 | -62 | 104 | 182 | -78 | -29.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p44 | move | 18 | 3 (17%) | 3 (17%) | 5 (28%) | 10 (56%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

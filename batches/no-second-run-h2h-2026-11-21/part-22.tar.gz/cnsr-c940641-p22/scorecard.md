# Doctrine scorecard: cnsr-c940641-p22

### Scorecard: cnsr-c940641-p22

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 0 | - | 4 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 11 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 4 | 0 | 1 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 4 | - | 1 | 3 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 2.0 | 1.0 | 3.0 | 1.3 | 1.0 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 0% | 5.0 | 2.0 | 4.3 | 1.7 | 0.0 | 0.0 | 0.0 | 56.7 |

### KPIs: cnsr-c940641-p22

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 15) | 0% (0 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (5 of 5); on the table 100% | 100% (9 of 9); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 71% (5 of 7); on the table 100% | 67% (6 of 9); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 86% (6 of 7); on the table 86% | 80% (12 of 15); on the table 93% | 82% (18 of 22); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 17% (4 of 24) | 33% (4 of 12) | 22% (8 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 29% (4 of 14) | 33% (4 of 12) | 31% (8 of 26) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 78% (7 of 9) | 50% (3 of 6) | 67% (10 of 15) |
| Points that never fought | lower | 22% (1300 of 5999) | 30% (1807 of 5999) | 26% (3107 of 11998) |
|   infantry points that never fought | lower | 36% (362 of 993) | 78% (619 of 793) | 55% (981 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 42% (8 of 19) | 56% (23 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (3657 of 5151) | 31% (1524 of 4976) | 51% (5181 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (10%) | 2.7 (100%) | 3.3 (36%) |
| MARCHED: its unit marched | 1.7 (25%) | 0.0 (0%) | 1.7 (18%) |
| IN COMBAT: engaged in combat | 2.3 (35%) | 0.0 (0%) | 2.3 (25%) |
| FLEEING: fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |
| GONE: slain | 0.7 (10%) | 0.0 (0%) | 0.7 (7%) |
| NOT OFFERED: not in the cast list | 1.0 (15%) | 0.0 (0%) | 1.0 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 3.0 | 2.7 | 1.3 | 4.3 |
| not cast | 7.3 | 7.0 | 9.3 | 2.7 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 3.3 (36%) | 2.3 (88%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.7 (18%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 2.3 (25%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.0 (14%) | 1.0 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.7 (2%) |
| GONE: slain | 0.7 (9%) | 0.7 (10%) | 0.7 (7%) | 0.0 (0%) | 3.3 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.3 (12%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.0 (11%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.3 (73%) | 4.7 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 2.0 a game | 1.5 a game |
| stood (cast and not dispelled) | 33% (1 of 3) | 33% (2 of 6) | 33% (3 of 9) |
| the unit moved after it | 100% (1 of 1) | 100% (2 of 2) | 100% (3 of 3) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 100% (2 of 2) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (37 of 56) | 0% (0 of 8) | 58% (37 of 64) |
|   cavalry | - | 0% (0 of 3) | 0% (0 of 3) |
|   character | 57% (4 of 7) | 0% (0 of 5) | 33% (4 of 12) |
|   chariot | 92% (11 of 12) | - | 92% (11 of 12) |
|   infantry | 50% (14 of 28) | - | 50% (14 of 28) |
|   monster | 89% (8 of 9) | - | 89% (8 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (53%) | 0.7 (25%) | 4.0 (44%) |
| CHARGED: it charged | 0.3 (5%) | 1.3 (50%) | 1.7 (19%) |
| IN COMBAT: it fought this turn or the last | 1.7 (26%) | 0.0 (0%) | 1.7 (19%) |
| NO TARGET IN RANGE | 0.3 (5%) | 0.3 (12%) | 0.7 (7%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (12%) | 0.3 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |
| OTHER BAR | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 1.3 | 0.3 | 75% | 1.9 pts | 2 pts |
| chariot | 3.7 | 1.3 | 73% | 14.0 pts | 51 pts |
| infantry | 5.3 | 2.0 | 69% | 10.8 pts | 57 pts |
| monster | 2.7 | 0.7 | 88% | 4.7 pts | 12 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 6.3 | 5.2 |
| Charges that made contact a game | 3.3 | 4.3 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (4 units) | 1.00 declared, 1.00 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.36 contact (28 units) | 0.62 declared, 0.38 contact (24 units) | 0.52 declared, 0.37 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | 33% (1 of 3) | 0% (0 of 2) | 22% (2 of 9) |
| Character in a unit | 67% (4 of 6) | 100% (1 of 1) | - | 71% (5 of 7) |
| Character on its own | 100% (2 of 2) | 50% (1 of 2) | 50% (3 of 6) | 60% (6 of 10) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (2 of 4) | 0% (0 of 1) | - | 40% (2 of 5) |
| Monster | 0% (0 of 1) | 100% (3 of 3) | - | 75% (3 of 4) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 35% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 25% (3 of 12) | 0% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 67% (2 of 3); on the table 67% | 17% (1 of 6) | 30% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 2 | 90% (9 of 10); on the table 100% | 33% (4 of 12) | 34% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 60% (3 of 5); on the table 80% | - | 22% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p22, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (3) | 56% (5) | 53% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p22

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 60% (3 of 5) | 39% (7 of 18) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (1 of 4) | 0% (0 of 2) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 100% (5 of 5) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 100% (5 of 5) | 64% (7 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 1.7 |
| Movement | Points that never moved of their own | 225.0 | 56.7 |
| Movement | Fights charged into per game | 3.3 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 4 of 11, net -248 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +205 | 2 of 11, net +117 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 11 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net +115 | 4 of 11, net +122 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.3 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (19 of 37) | 100% (1 of 1) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 2.0 | - |
| Magic | Wounds caused by other spells | 0.3 | 2.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 1.0 / 0.0 | 2.0 / 0.0 / 1.7 / 0.0 |
| Combat | Points destroyed in combat | 725.3 | 495.0 |
| Combat | Points run down | 28.3 | 115.3 |
| Combat | Net points per charged fight, damage counted | +4 | +23 |
| Combat | Net per 100 charger points, damage counted | +2.9 | +7.1 |
| Combat | First round won (charged fights) | 50% | 58% |
| Combat | Net points per charged fight | +7 | +8 |
| Combat | Net points per supported fight / lone fight | - / +7 | +0 / +9 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 10 | 5 of 12 |
| Game | Points lost | 913.0 | 680.3 |
| Game | VP from objectives | 600.0 | 873.3 |
| Game | Lone holders (player turns) | 2.0 | 5.0 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -579 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1593
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p22

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +3.5 | 0.0 | 0.0 |
| ARMY TABLE | 36.7 | -71.9 | 0.0 | 614.0 | 21.0 | +357.7 | 0.0 | 137.7 |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +9.7 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -11.9 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 1.7 | +5.5 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.3 | +1.2 | 18.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +24.4 | 0.0 | 0.0 |
| CHAFF PASSED | 2.0 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +46.8 | 0.0 | 99.0 | 0.7 | +17.9 | 0.0 | 16.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | +4.2 | 0.0 | 0.0 |
| CHARGE LOSSES | 9.7 | -1266.0 | 0.0 | 233.3 | 10.7 | -818.3 | 0.0 | 410.7 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 87.0 | 0.0 | 4.0 | +0.0 | 430.7 | 314.3 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 151.7 | 23.7 | +0.0 | 0.0 | 78.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 186.7 | 0.7 | +0.0 | 0.0 | 215.3 |
| CONVEYANCE SEARCH | 0.7 | +73.7 | 0.0 | 0.0 | 2.0 | +16.9 | 0.0 | 0.0 |
| COVER ONCE | 8.0 | -440.8 | 0.0 | 186.3 | 2.0 | -59.7 | 0.0 | 62.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -3.3 | 99.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 0.0 | 7.0 | +58.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 1.0 | -170.2 | 99.0 | 190.3 |
| EXACT ROUND | 1.0 | +11.8 | 155.3 | 0.0 | 4.3 | +0.7 | 445.0 | 314.3 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 124.0 | 0.0 | 4.7 | +6.4 | 522.3 | 442.7 |
| FALLS SHORT | 2.0 | +27.4 | 0.0 | 0.0 | 17.0 | +203.4 | 0.0 | 205.3 |
| FEATURE BUFFS | 1.7 | +29.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +2.2 | 87.0 | 0.0 | 3.3 | +217.7 | 496.7 | 504.7 |
| FIVE ACTION | 72.3 | +6071.3 | 263.7 | 1155.3 | 89.0 | +6352.7 | 555.3 | 1468.0 |
| FLANK NOT WEIGHED | 13.3 | +0.0 | 0.0 | 204.7 | 3.7 | +0.0 | 0.0 | 25.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.3 | +230.9 | 0.0 | 62.0 |
| FOUR ROUNDS | 1.7 | +131.5 | 245.7 | 0.0 | 6.3 | +737.0 | 555.3 | 504.7 |
| FREED FROM HIS FIGHT | 13.0 | +0.0 | 0.0 | 30.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -1.1 | 62.0 | 0.0 | - | - | - | - |
| GIVES UP ITS SCREEN | - | - | - | - | 0.3 | -3.7 | 0.0 | 0.0 |
| GOAL WALK | 17.0 | +1823.6 | 0.0 | 375.0 | 7.7 | +1131.7 | 0.0 | 0.0 |
| GUN FIGURES | 5.0 | +46.3 | 0.0 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.7 | +0.0 | 0.0 | 30.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 233.3 | 5.3 | +0.0 | 0.0 | 410.7 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +56.8 | 11.3 | 0.0 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 238.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 6.3 | +0.0 | 0.0 | 135.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 0.7 | -15.0 | 0.0 | 0.0 | 4.7 | -80.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 113.3 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 135.0 | 10.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 15.7 | +0.0 | 0.0 | 258.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 12.3 | +135.5 | 0.0 | 43.3 | 36.3 | +561.0 | 0.0 | 440.3 |
| HIS SHOTS BY HIS RUN | 12.7 | +145.2 | 0.0 | 214.7 | 28.0 | +619.1 | 0.0 | 434.7 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +9.6 | 177.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.7 | +0.0 | 0.0 | 234.3 | 13.7 | +0.0 | 0.0 | 686.7 |
| HOLDER ASSIGNMENT | 10.0 | +963.5 | 0.0 | 126.3 | 9.0 | +905.5 | 0.0 | 343.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -32.5 | 245.7 | 0.0 | 5.7 | -237.5 | 555.3 | 504.7 |
| IDLE COST | 0.3 | -11.0 | 0.0 | 0.0 | 19.3 | -225.0 | 0.0 | 58.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +27.6 | 78.3 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -1.6 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.7 | +0.0 | 455.0 | 409.7 | 8.7 | +0.0 | 488.0 | 960.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.7 | +0.3 | 130.3 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | -0.9 | 158.7 | 0.0 | 3.3 | +30.9 | 365.7 | 190.3 |
| MANOEUVRE | 2.0 | +66.8 | 0.0 | 0.0 | 1.0 | +1.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +180.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -14.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +177.8 | 0.0 | 36.7 | 3.0 | +33.4 | 0.0 | 25.0 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 0.0 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +82.3 | 0.0 | 0.0 | 2.7 | +6.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +48.4 | 0.0 | 0.0 | 2.7 | +2.9 | 0.0 | 0.0 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.7 | -3.6 | 0.0 | 31.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.3 | +167.0 | 0.0 | 116.7 | 10.7 | +1068.9 | 0.0 | 62.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.0 | +422.1 | 0.0 | 78.3 | 4.7 | +197.2 | 0.0 | 143.3 |
| NEXT CHARGE BY LIST | 2.0 | +140.6 | 18.0 | 0.0 | 4.3 | +488.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -21.4 | 121.7 | 0.0 | 5.7 | -245.1 | 555.3 | 314.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 2.0 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -238.7 | 0.0 | 0.0 | 3.3 | -60.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -12.3 | 0.0 | 0.0 | 9.0 | -217.8 | 0.0 | 143.3 |
| ONE OBJECTIVE FORMULA | 4.0 | +0.7 | 0.0 | 89.7 | 3.0 | -38.9 | 0.0 | 171.7 |
| ONE PROMISE A TARGET | 0.7 | -32.5 | 0.0 | 0.0 | 0.7 | -75.6 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +40.3 | 21.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 2.0 | +24.9 | 224.3 | 190.3 |
| PATHS CROSS | - | - | - | - | 0.3 | -13.5 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 36.3 | +178.3 | 105.0 | 1184.0 | 45.3 | +453.8 | 257.3 | 1003.0 |
| PROMISE BY ITS OWN SUM | 5.3 | -276.9 | 0.0 | 116.7 | 13.0 | -489.7 | 0.0 | 62.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | -0.1 | 0.0 | 62.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -13.1 | 0.0 | 0.0 |
| QUARTER ODDS | 15.3 | +2082.6 | 28.3 | 179.3 | 25.7 | +2893.9 | 25.7 | 436.0 |
| RANDOM MOVE BY FIGURES | 3.0 | +90.7 | 0.0 | 70.0 | 2.0 | +30.3 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +95.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.7 | +216.6 | 0.0 | 62.3 | 4.0 | +285.8 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 25.7 | 3.3 | +120.5 | 0.0 | 28.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +44.4 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -26.4 | 0.0 | 0.0 | 1.7 | -50.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 99.0 | 1.7 | +0.0 | 0.0 | 130.3 |
| RISK BY ARC | 1.3 | +38.7 | 217.3 | 0.0 | 5.7 | +22.4 | 544.0 | 504.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.7 | -95.0 | 340.7 | 504.7 |
| RUN DOWN | 0.7 | -10.9 | 96.7 | 0.0 | 5.3 | -44.7 | 533.7 | 504.7 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -68.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +13.6 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +30.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -2.5 | 0.0 | 0.0 | 2.0 | -38.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.7 | +46.8 | 0.0 | 0.0 | 3.0 | -35.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 78.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 6.7 | -2.6 | 0.0 | 94.7 | 21.7 | -145.5 | 0.0 | 130.0 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 9.0 | +287.9 | 0.0 | 121.3 | 0.3 | +7.2 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +71.6 | 135.0 | 135.0 | 2.0 | +16.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +2.7 | 85.0 | 190.3 |
| SPOT AS THE GAME MOVES | 13.7 | +0.0 | 0.0 | 459.0 | 9.7 | +0.0 | 0.0 | 121.7 |
| STAND AND SHOOT | 0.3 | -2.5 | 28.3 | 0.0 | 1.3 | -9.8 | 47.3 | 0.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 16.7 | +0.0 | 18.0 | 314.0 | 17.3 | +0.0 | 0.0 | 286.7 |
| STAY WORTH | 3.7 | +13.8 | 0.0 | 43.3 | - | - | - | - |
| STRIKE BY THE ODDS | 1.3 | +6.5 | 430.0 | 0.0 | 1.3 | +24.1 | 30.0 | 186.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 17.0 | +1221.7 | 0.0 | 231.3 | 3.7 | +138.7 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 68.3 | 0.0 | 1.0 | +0.0 | 89.3 | 62.0 |
| SUPPORT WORKED OUT | 17.0 | +1221.7 | 0.0 | 231.3 | 3.7 | +138.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +4.8 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.3 | 0.0 | 10.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -13.3 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 6.3 | +0.0 | 0.0 | 78.3 | 3.3 | +0.0 | 0.0 | 28.3 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 62.0 |
| THE ROW READS HIS LAST RUN | 1.7 | +0.0 | 0.0 | 21.7 | - | - | - | - |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 62.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.3 | +0.0 | 0.0 | 370.3 | 43.3 | +0.0 | 0.0 | 481.7 |
| TIED UP BY THE SUM | 0.3 | +5.3 | 25.0 | 0.0 | 1.0 | +104.1 | 100.0 | 62.0 |
| TIME ON OUR SIDE | 31.0 | +368.4 | 0.0 | 492.3 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 153.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 1.3 | +54.1 | 248.0 | 0.0 | 0.7 | -55.7 | 0.0 | 380.7 |
| WHO FIGHTS | 0.3 | -13.4 | 68.3 | 0.0 | 1.7 | +55.1 | 104.0 | 124.0 |
| WHO GETS IN | - | - | - | - | 0.3 | -6.3 | 78.3 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +53.9 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.7 | -60.2 | 124.0 | 0.0 | 0.3 | -0.5 | 0.0 | 190.3 |
| WHOLE FIGHT DANGER | 7.7 | -1190.1 | 0.0 | 233.3 | 1.7 | -459.2 | 0.0 | 348.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +4.9 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +78.9 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p22

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 173 | 173 | 110 | 36.67 | +1466 | +13.3 |
| HOLDER ASSIGNMENT | 57 | 57 | 51 | 17.00 | +3391 | +66.5 |
| LEGAL CHARGES ONLY | 46 | 46 | 46 | 15.33 | +0 | +0.0 |
| FIVE ACTION | 484 | 470 | 29 | 9.67 | +1263 | +43.5 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| THE TABLE AGAIN | 34 | 34 | 25 | 8.33 | +0 | +0.0 |
| HIS SHOT LIST | 146 | 141 | 23 | 7.67 | +179 | +7.8 |
| QUARTER ODDS | 123 | 121 | 23 | 7.67 | +1756 | +76.3 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -896 | -40.7 |
| PROMISE BY ITS OWN SUM | 55 | 55 | 22 | 7.33 | -2300 | -104.6 |
| REDIRECT FOR A FRIEND IN REACH | 22 | 22 | 22 | 7.33 | +352 | +16.0 |
| HIS SHOTS BY HIS RUN | 122 | 118 | 18 | 6.00 | +270 | +15.0 |
| MOVE ORDER | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| SUPPORT ADDS | 62 | 60 | 17 | 5.67 | +1333 | +78.4 |
| SUPPORT WORKED OUT | 62 | 60 | 17 | 5.67 | +1333 | +78.4 |
| GOAL WALK | 74 | 74 | 15 | 5.00 | +1547 | +103.1 |
| FOUR ROUNDS | 24 | 23 | 14 | 4.67 | +1450 | +103.6 |
| IDLE COST | 59 | 42 | 14 | 4.67 | +50 | +3.6 |
| MOVE TO CHARGE COMPUTED | 39 | 30 | 12 | 4.00 | +223 | +18.6 |
| SHOT RISK POINTS | 85 | 83 | 11 | 3.67 | +127 | +11.5 |
| RANDOM MOVE BY FIGURES | 15 | 15 | 10 | 3.33 | +363 | +36.3 |
| STRIKE BY THE ODDS | 8 | 8 | 8 | 2.67 | +92 | +11.5 |
| THE RISK READS HIS RUN | 16 | 16 | 8 | 2.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 28 | 25 | 8 | 2.67 | +771 | +96.3 |
| CHARGE NOW FIRST | 14 | 14 | 7 | 2.33 | -439 | -62.7 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| CHAFF PASSED | 6 | 6 | 6 | 2.00 | -13 | -2.1 |
| MAX FOR POSITIONING | 18 | 15 | 6 | 2.00 | +27 | +4.5 |
| TIME ON OUR SIDE | 93 | 72 | 6 | 2.00 | +18 | +3.1 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +194 | +38.8 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| SET UP BY THE SET | 17 | 17 | 5 | 1.67 | +336 | +67.2 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 61 | 57 | 4 | 1.33 | +483 | +120.7 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +693 | +173.1 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 4 | 1.33 | +206 | +51.4 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -324 | -81.1 |
| REDIRECT COUNTER | 26 | 18 | 4 | 1.33 | +73 | +18.3 |
| RISK BY ARC | 21 | 20 | 4 | 1.33 | +183 | +45.8 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +30 | +10.1 |
| CAST JOB | 5 | 5 | 3 | 1.00 | +0 | +0.1 |
| COVER ONCE | 30 | 15 | 3 | 1.00 | +20 | +6.5 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +83 | +27.6 |
| NEARER NOT NEEDED | 41 | 38 | 3 | 1.00 | +73 | +24.4 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 28 | 18 | 3 | 1.00 | +144 | +47.8 |
| THE ROW IN ITS ORDER | 29 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +147 | +49.1 |
| WOUNDS ON THE RANKS | 10 | 10 | 3 | 1.00 | +48 | +16.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 16 | 15 | 2 | 0.67 | +22 | +11.2 |
| HARD STAY DROPPED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 3 | 2 | 0.67 | +67 | +33.5 |
| HIS MOVE AND SHOT | 16 | 16 | 2 | 0.67 | +5 | +2.3 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +542 | +270.8 |
| MISSILES IN THE MOVE | 14 | 6 | 2 | 0.67 | +2 | +0.9 |
| NEXT CHARGE BY LIST | 19 | 18 | 2 | 0.67 | +106 | +53.2 |
| NO DOUBLE ROUNDS | 20 | 19 | 2 | 0.67 | +32 | +16.2 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +32 | +16.2 |
| PROMISE KNOWS THE FIGHT | 9 | 4 | 2 | 0.67 | -0 | -0.2 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +41 | +20.4 |
| SUPPORT NARROWED | 4 | 4 | 2 | 0.67 | -20 | -9.8 |
| SURE REACH TOGETHER | 6 | 6 | 2 | 0.67 | +0 | +0.0 |
| WHAT THE JOINER ADDS | 6 | 6 | 2 | 0.67 | +24 | +12.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +11 | +10.6 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -36 | -35.7 |
| CASTING BLOCK | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 12 | 12 | 1 | 0.33 | +406 | +405.9 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| ONE FIGHT FORMULA | 34 | 15 | 1 | 0.33 | +1 | +1.1 |
| ONE OBJECTIVE FORMULA | 21 | 14 | 1 | 0.33 | +37 | +36.6 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +28 | +28.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -40 | -40.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +24 | +24.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -5 | -4.7 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -36 | -35.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +388 | +388.3 |
| REFUSING RETIRES | 7 | 7 | 1 | 0.33 | -3 | -3.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +90 | +90.2 |
| STAY WORTH | 11 | 10 | 1 | 0.33 | +1 | +0.8 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| WHO FIGHTS | 6 | 5 | 1 | 0.33 | +116 | +116.3 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -19 | -18.8 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +84 | +83.7 |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 87 | 87 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 15 | 0 | 0.00 | - | - |
| FALLS SHORT | 57 | 49 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 51 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 49 | 44 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | not checked | - | - | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 15 | 13 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 36 | 34 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 10 | 10 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 41 | 39 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 51 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 63 | 63 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 16 | 16 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 94 | 94 | 0 | 0.00 | - | - |
| HONEST WORTH | 22 | 22 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 12 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 245 | trace | - | - | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 7 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 11 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 70 | 62 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 102 | 98 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 224 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 15 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p22

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 7.00 | 1.33 | 124.5 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 5.67 | 104.6 |
| JOB FIRST | gate | 2.67 | 2.67 | 52.8 |
| CHARGE NOW FIRST | rule | - | 2.33 | 62.7 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.67 | 81.1 |
| AFTERMATH BAND | gate | 0.67 | - | 1.6 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 1.3 |
| SUPPORT NARROWED | rule | - | 0.67 | 9.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 42.4 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 35.7 |
| CHAFF PASSED | rule | 0.33 | - | 12.7 |
| FALLBACK | gate | - | 0.33 | 3.6 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 30.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 18.8 |
| PATHS CROSS | rule | - | 0.33 | 40.5 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 4.7 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 35.9 |
| REFUSING RETIRES | rule | 0.33 | - | 3.3 |
| SET UP BY THE SET | rule | - | 0.33 | 36.5 |
| WHO GETS IN | rule | - | 0.33 | 18.8 |

### Plans: cnsr-c940641-p22

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 75% | 174 | 155 | 89% |
| Mine | move | 33.7 | 91% | 2689 | 0 | 0% |
| Mine | shoot | 1.3 | 50% | 171 | 23 | 13% |
| Opponent | charge | 4.7 | 50% | 761 | 454 | 60% |
| Opponent | join | 3.3 | 100% | 125 | 0 | 0% |
| Opponent | move | 36.7 | 97% | 2020 | 0 | 0% |
| Opponent | support | 0.7 | 100% | 60 | 0 | 0% |

### Battle groups: cnsr-c940641-p22

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 21% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 4.0 | 33% | 100% | 0% | - | 75% | 0% | 0% | 25% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p22

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 167 (7) | 50 | 116 | 66 | 14% | 3.2 | 147 (6) | 308 (1) | - | 147 (6) | 308 (1) |
| Mine | Character | 7 | 77 (7) | 77 | 0 | 42 | 0% | 2.3 | 32 (2) | 235 (3) | 0 (1) | 173 (3) | 35 (3) |
| Mine | Clean-up | 2 | 49 (2) | 36 | 13 | 0 | 50% | 5.0 | 49 (2) | - | - | 0 (1) | 58 (1) |
| Mine | Fast Hammer | 1 | 187 (1) | 187 | 0 | 0 | 0% | 3.0 | - | 187 (1) | - | 187 (1) | - |
| Mine | Hammer | 10 | 1 (10) | 0 | 1 | 63 | 10% | 1.9 | 0 (2) | 3 (5) | 0 (3) | 4 (4) | 0 (6) |
| Mine | Holder | 3 | 72 (3) | 0 | 72 | 46 | 67% | 6.0 | 0 (1) | 132 (2) | - | 72 (3) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 100 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 20 | 0% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 79 (9) | 26 | 53 | 21 | 33% | 4.2 | 24 (4) | 267 (2) | 55 (3) | 164 (4) | 32 (5) |
| Opponent | Character | 10 | 65 (10) | 65 | 0 | 38 | 30% | 3.7 | 86 (4) | 85 (4) | 15 (1) | 64 (4) | 74 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 8 | 68 (8) | 43 | 25 | 62 | 12% | 3.4 | 42 (2) | 78 (4) | 82 (2) | 68 (5) | 68 (3) |
| Opponent | Hammer | 2 | 112 (2) | 57 | 55 | 0 | 50% | 4.0 | - | 112 (2) | - | 165 (1) | 84 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.3 | 0 (1) | 0 (1) | 0 (2) | - | 0 (4) |

### Charged fights: cnsr-c940641-p22

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 261 | 4.0 | 1.0 | 65 | 198 | -133 | 1 of 4 | 2 of 4 | - | -133 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 717 | 4.0 | 1.0 | 179 | 101 | +78 | 2 of 4 | 1 of 4 | - | +78 |
| Mine | Skaven | 1 | 0 | 290 | 2.0 | 1.0 | 145 | 0 | +145 | 0 of 2 | 2 of 2 | - | +145 |
| **Mine** | all armies | 3 | 0 | 423 | 3.3 | 1.0 | 127 | 120 | +7 | 3 of 10 | 5 of 10 | - | +7 |
| Opponent | Vampire Counts | 2 | 0 | 400 | 4.5 | 1.0 | 89 | 110 | -21 | 4 of 9 | 4 of 9 | - | -21 |
| Opponent | Warriors of Chaos | 1 | 0 | 287 | 3.0 | 1.3 | 96 | 0 | +96 | 1 of 3 | 3 of 3 | +0 | +144 |
| **Opponent** | all armies | 3 | 0 | 363 | 4.0 | 1.1 | 91 | 83 | +8 | 5 of 12 | 7 of 12 | +0 | +9 |

### Effective charges: cnsr-c940641-p22

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +130) | 2 | 0% (0 of 2) |
| Mine | Skaven | 2 | 0 | 0 | 1 (net +205) | 0 | 0 | 1 (net +85) | 0 | 50% (1 of 2) |
| Opponent | Vampire Counts | 9 | 4 (net -248) | 0 | 2 (net +117) | 1 (net +77) | 0 | 2 (net +245) | 0 | 22% (2 of 9) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: cnsr-c940641-p22

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 197 | 205 | +205 | 205 | 0 | +205 | +104.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 90 | 115 | +115 | 115 | 0 | +115 | +127.7 |
| Mine | No odds | 6 | 154 | 246 | -80 | 122 | 207 | -85 | -55.1 |
| Mine | All fights | 10 | 140 | 203 | +7 | 128 | 124 | +4 | +2.9 |
| Opponent | Long shot (under 50%) | 4 | 328 | 303 | -248 | 0 | 248 | -248 | -75.6 |
| Opponent | Effective (55-75%) | 2 | 116 | 137 | +117 | 120 | 8 | +112 | +97.4 |
| Opponent | 76-89% | 1 | 60 | 77 | +77 | 77 | 6 | +71 | +118.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 430 | 282 | +122 | 178 | 0 | +178 | +41.3 |
| Opponent | No odds | 1 | 494 | 192 | +287 | 287 | 28 | +259 | +52.4 |
| Opponent | All fights | 12 | 318 | 240 | +8 | 110 | 87 | +23 | +7.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p22 | move | 21 | 3 (14%) | 2 (10%) | 3 (14%) | 15 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

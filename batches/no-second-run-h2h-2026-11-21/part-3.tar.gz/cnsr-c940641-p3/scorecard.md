# Doctrine scorecard: cnsr-c940641-p3

### Scorecard: cnsr-c940641-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 10 | 2 | 2 | 3 | 0 | 0 | 0 | 139 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1236 |
| L0421 | 1 | 1 | Mine | no | 6 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 7.7 | 2.5 | 2.0 | 2.0 | 0.0 | 0.0 | 0.0 | 173.0 |
| **Average** | | | Opponent | 0% | 0.0 | - | 0.0 | 3.3 | 0.0 | 0.0 | 0.0 | 668.7 |

### KPIs: cnsr-c940641-p3

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 56% (5 of 9) | 25% (5 of 20) |
| Winner chose to follow up after the loser gave ground |  | 60% (3 of 5); on the table 100% | 0% (0 of 2); on the table 50% | 43% (3 of 7); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 2); on the table 0% | 0% (0 of 1); on the table 100% | 0% (0 of 3); on the table 33% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 38% (3 of 8); on the table 62% | 0% (0 of 3); on the table 67% | 27% (3 of 11); on the table 64% |
| Magic missiles tried each own turn | 50%+ | 17% (2 of 12) | 67% (4 of 6) | 33% (6 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 20% (2 of 10) | 67% (4 of 6) | 38% (6 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (5 of 10) | 50% (5 of 10) |
| Points that never fought | lower | 67% (4031 of 5998) | 61% (3680 of 5999) | 64% (7711 of 11997) |
|   infantry points that never fought | lower | 87% (1235 of 1424) | 67% (1133 of 1703) | 76% (2368 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (13 of 23) | 65% (17 of 26) | 61% (30 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2671 of 5120) | 56% (2618 of 4677) | 54% (5289 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (40%) | 0.0 (0%) | 1.3 (33%) |
| MARCHED: its unit marched | 1.3 (40%) | 0.7 (100%) | 2.0 (50%) |
| IN COMBAT: engaged in combat | 0.3 (10%) | 0.0 (0%) | 0.3 (8%) |
| GONE: slain | 0.3 (10%) | 0.0 (0%) | 0.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 0.7 | 2.0 | 1.0 | 0.3 |
| not cast | 2.3 | 3.3 | 4.0 | 3.0 | 11.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (50%) | 1.3 (33%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (50%) | 0.7 (22%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (10%) | 0.3 (8%) | 0.3 (11%) | 0.0 (0%) |
| GONE: slain | 0.3 (14%) | 0.3 (10%) | 0.3 (8%) | 0.3 (11%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (56%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (86%) | 1.0 (30%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.3 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | 50% (1 of 2) | - | 50% (1 of 2) |
| the unit moved after it | 0% (0 of 1) | - | 0% (0 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 56% (44 of 79) | 70% (66 of 94) | 64% (110 of 173) |
|   cavalry | 64% (7 of 11) | 0% (0 of 7) | 39% (7 of 18) |
|   character | 50% (5 of 10) | 71% (12 of 17) | 63% (17 of 27) |
|   chariot | 40% (8 of 20) | 54% (7 of 13) | 45% (15 of 33) |
|   infantry | 17% (2 of 12) | 50% (9 of 18) | 37% (11 of 30) |
|   war machine | 85% (22 of 26) | 97% (38 of 39) | 92% (60 of 65) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (29%) | 1.3 (14%) | 4.7 (22%) |
| CHARGED: it charged | 1.0 (9%) | 0.0 (0%) | 1.0 (5%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (11%) | 1.0 (5%) |
| NO TARGET IN RANGE | 4.0 (34%) | 3.7 (39%) | 7.7 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 1.0 (11%) | 1.3 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (23%) | 2.0 (21%) | 4.7 (22%) |
| OTHER BAR | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 1.0 | 57% | 12.5 pts | 29 pts |
| character | 7.3 | 5.7 | 50% | 17.3 pts | 127 pts |
| chariot | 5.0 | 6.3 | 67% | 14.3 pts | 72 pts |
| infantry | 6.3 | 3.7 | 58% | 15.6 pts | 99 pts |
| war machine | 20.0 | 21.3 | 57% | 30.2 pts | 604 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 0.0 | 1.8 |
| Charges that made contact a game | 3.0 | 0.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.36 contact (22 units) | 0.00 declared, 0.00 contact (22 units) | 0.23 declared, 0.18 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (1 of 1) | - | 25% (1 of 4) |
| Character in a unit | 100% (8 of 8) | 0% (0 of 1) | - | 89% (8 of 9) |
| Character on its own | 75% (3 of 4) | 67% (2 of 3) | 33% (1 of 3) | 60% (6 of 10) |
| Chariot | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| Infantry | 75% (6 of 8) | 40% (2 of 5) | 0% (0 of 1) | 57% (8 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 38% (3 of 8); on the table 62% | 17% (2 of 12) | 51% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 0% (0 of 2); on the table 50% | - | 64% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 100% | 67% (4 of 6) | 56% | 56% (5 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p3, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 40% (2) | 40% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnsr-c940641-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 44% (4 of 9) | - |
| Strategy | Shoot objectives carried out (shot that target) | 67% (18 of 27) | 74% (32 of 43) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 56% (5 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.3 |
| Movement | Points that never moved of their own | 173.0 | 668.7 |
| Movement | Fights charged into per game | 2.7 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +323 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +212 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net +32 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.3 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (9 of 22) | 65% (22 of 34) |
| Shooting | Points destroyed by shooting units | 132.3 | 46.3 |
| Shooting | War machine shots | 7.3 | 12.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 45% (17 of 38) |
| Shooting | Points destroyed by war machines | 176.0 | 355.7 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | - | 1.3 |
| Magic | Wounds caused by other spells | - | 1.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 103.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 1.0 | 1.3 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 346.0 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +191 | - |
| Combat | Net per 100 charger points, damage counted | +48.8 | - |
| Combat | First round won (charged fights) | 62% | - |
| Combat | Net points per charged fight | +183 | - |
| Combat | Net points per supported fight / lone fight | +0 / +210 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 5 of 8 | - |
| Game | Points lost | 598.3 | 839.0 |
| Game | VP from objectives | 990.0 | 610.0 |
| Game | Lone holders (player turns) | 7.7 | 0.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +733 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1437
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +8.9 | 0.0 | 0.0 | 0.7 | +136.1 | 0.0 | 0.0 |
| ARMY TABLE | 13.3 | +269.3 | 0.0 | 253.0 | 8.3 | +36.7 | 0.0 | 134.7 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 75.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | -98.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 1.7 | +0.0 | 246.0 | 31.7 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 12.3 | +283.2 | 1037.0 | 253.3 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| CAST JOB | - | - | - | - | 0.7 | +11.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +10.2 | 0.0 | 30.3 |
| CHALLENGE BY POINTS | 0.3 | +6.6 | 0.0 | 0.0 | 0.7 | +36.4 | 0.0 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 20.0 | -677.7 | 0.0 | 536.3 | 6.3 | -601.0 | 0.0 | 134.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 70.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 43.3 | 7.0 | +0.0 | 0.0 | 86.7 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 70.0 |
| CONVEYANCE SEARCH | 0.7 | +21.5 | 46.3 | 0.0 | - | - | - | - |
| COVER ONCE | 2.7 | -70.8 | 0.0 | 31.7 | 5.7 | -450.3 | 0.0 | 85.0 |
| DENIED BY THE FIGHT | 0.7 | -15.5 | 0.0 | 103.3 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| DUEL STOPS AT THE KILL | 0.7 | -45.0 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.7 | +6.4 | 21.7 | 37.3 | - | - | - | - |
| EXACT ROUND | 2.3 | +8.0 | 101.7 | 206.7 | - | - | - | - |
| FALL BACK GOOD ORDER | 3.3 | +4.5 | 31.7 | 206.7 | - | - | - | - |
| FALLS SHORT | 6.7 | +79.9 | 0.0 | 0.0 | 10.3 | +125.1 | 0.0 | 65.0 |
| FEATURE BUFFS | 0.7 | +19.9 | 0.0 | 0.0 | 2.0 | +10.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +0.9 | 0.0 | 103.3 | - | - | - | - |
| FIRE IN ORDER | 1.3 | +0.0 | 41.7 | 31.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 89.0 | +7206.0 | 1545.0 | 1276.0 | 89.0 | +2699.0 | 2599.3 | 1062.0 |
| FLANK NOT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 21.7 |
| FOLLOW UP WEIGHED | 0.7 | +70.5 | 0.0 | 41.3 | - | - | - | - |
| FOUR ROUNDS | 3.7 | +405.1 | 101.7 | 206.7 | - | - | - | - |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 43.3 |
| FRIEND SHOOTS FIRST | 0.3 | -1.8 | 0.0 | 0.0 | 1.3 | -7.0 | 0.0 | 21.7 |
| GIVES UP | 0.3 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 13.0 | +1862.1 | 0.0 | 43.3 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +23.3 | 43.3 | 0.0 | 2.7 | +5.8 | 0.0 | 65.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 43.3 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 386.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS MOVE AND SHOT | 1.0 | -7.8 | 0.0 | 103.3 | 1.7 | -66.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 9.7 | +0.0 | 0.0 | 250.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 3.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 46.3 | +2486.2 | 0.0 | 792.7 | 34.0 | +1445.2 | 0.0 | 380.3 |
| HIS SHOTS BY HIS RUN | 36.3 | +698.6 | 0.0 | 772.7 | 29.7 | +817.0 | 0.0 | 377.0 |
| HIS TURN DENIED | 1.3 | +33.6 | 0.0 | 206.7 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 0.0 | 14.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.7 | +1033.2 | 0.0 | 0.0 | 8.0 | +683.3 | 0.0 | 67.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -196.1 | 101.7 | 206.7 | - | - | - | - |
| IDLE COST | 7.0 | -114.9 | 0.0 | 68.0 | 8.7 | -115.2 | 0.0 | 33.7 |
| JOINT CHARGE NOW | 1.0 | -1.8 | 0.0 | 206.7 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 70.0 | 63.0 | 1.0 | +0.0 | 0.0 | 79.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -18.1 | 31.7 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -22.6 | 0.0 | 18.3 |
| MAKE SURE TOGETHER | 0.3 | +23.5 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.3 | +1.5 | 0.0 | 0.0 | 1.0 | -11.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +33.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +4.4 | 0.0 | 0.0 | 0.3 | +23.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +112.4 | 0.0 | 103.3 | - | - | - | - |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 1.0 | +17.3 | 0.0 | 0.0 | 2.3 | +18.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +30.9 | 0.0 | 193.3 | 3.0 | +14.7 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 103.3 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.3 | +130.0 | 0.0 | 193.3 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.7 | -103.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 46.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.3 | +223.6 | 0.0 | 0.0 | 1.0 | +43.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +192.8 | 0.0 | 0.0 | 6.3 | +289.8 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +151.7 | 0.0 | 0.0 | 0.3 | +8.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -225.2 | 101.7 | 206.7 | - | - | - | - |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +23.4 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -107.5 | 0.0 | 31.7 | 2.7 | -30.9 | 0.0 | 73.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -85.2 | 0.0 | 103.3 | 0.3 | -0.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.3 | +53.3 | 0.0 | 0.0 | 4.0 | +22.9 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +28.5 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -62.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.3 | +642.1 | 275.0 | 1100.0 | 41.7 | +964.5 | 712.3 | 554.7 |
| PROMISE BY ITS OWN SUM | 6.3 | -295.9 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -6.9 | 0.0 | 21.7 |
| QUARTER ODDS | 23.0 | +2873.1 | 359.7 | 656.7 | 22.3 | +1529.7 | 722.7 | 450.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +37.7 | 0.0 | 118.3 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 1.7 | +50.2 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 18.3 |
| REDIRECT WEIGHED | 0.3 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 0.3 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | -33.1 | 0.0 | 103.3 | - | - | - | - |
| ROUNDS AFTER TERROR | 2.0 | -34.0 | 31.7 | 0.0 | - | - | - | - |
| RUN DOWN | 2.0 | -5.3 | 0.0 | 103.3 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +50.2 | 70.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -26.2 | 0.0 | 0.0 | 0.3 | -11.9 | 0.0 | 21.7 |
| SET UP BY THE SET | 1.7 | +79.0 | 0.0 | 0.0 | 0.3 | +11.9 | 0.0 | 21.7 |
| SET UP TOGETHER | 0.3 | +23.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.7 | +0.0 | 0.0 | 95.0 | 15.0 | +0.0 | 0.0 | 271.7 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +63.3 | 0.0 | 0.0 | 0.3 | +58.0 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT OR CHARGE | 0.3 | -4.4 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 31.0 | +453.4 | 0.0 | 732.7 | 18.0 | +28.8 | 0.0 | 420.3 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +378.4 | 0.0 | 126.7 | 20.7 | +516.2 | 0.0 | 318.3 |
| SPELL WORTH | - | - | - | - | 3.7 | +85.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +5.0 | 70.0 | 103.3 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 70.0 |
| STAND AND SHOOT | 0.3 | -1.1 | 0.0 | 103.3 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 40.7 | +0.0 | 1443.3 | 296.7 | 54.7 | +0.0 | 2599.3 | 733.0 |
| STAY WORTH | 26.7 | +256.4 | 1007.3 | 325.0 | 38.7 | -172.2 | 1445.3 | 702.3 |
| STRIKE BY THE ODDS | 0.3 | +26.3 | 61.7 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +23.5 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | - | - | - | - | 2.0 | +117.4 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | - | - | - | - | 2.0 | +117.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 103.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 68.0 | 4.0 | +0.0 | 0.0 | 43.3 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 21.7 | 3.3 | +0.0 | 0.0 | 43.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.0 | +0.0 | 0.0 | 503.0 | 42.7 | +0.0 | 0.0 | 413.7 |
| TIED UP BY THE SUM | 0.7 | +76.0 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 23.0 | +314.4 | 269.3 | 86.7 | 17.0 | +198.0 | 413.3 | 89.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +0.8 | 0.0 | 103.3 | - | - | - | - |
| WHO HITS BACK | 0.3 | +62.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -83.3 | 0.0 | 0.0 | 2.0 | -356.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +199.1 | 0.0 | 0.0 | 1.7 | +12.8 | 0.0 | 134.7 |

### Rule changes: cnsr-c940641-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 241 | 229 | 65 | 21.67 | +890 | +13.7 |
| HIS SHOTS BY HIS RUN | 198 | 187 | 52 | 17.33 | +539 | +10.4 |
| HOLDER ASSIGNMENT | 53 | 53 | 49 | 16.33 | +2982 | +60.9 |
| ARMY TABLE | 65 | 65 | 46 | 15.33 | +1020 | +22.2 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| SHOT RISK POINTS | 147 | 140 | 25 | 8.33 | +408 | +16.3 |
| OFF BEST | 17 | 17 | 17 | 5.67 | -415 | -24.4 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 120 | 101 | 15 | 5.00 | +50 | +3.3 |
| GOAL WALK | 48 | 41 | 13 | 4.33 | +1248 | +96.0 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| IDLE COST | 47 | 41 | 9 | 3.00 | +34 | +3.8 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FIVE ACTION | 534 | 519 | 8 | 2.67 | +557 | +69.6 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 22 | 22 | 7 | 2.33 | -888 | -126.8 |
| QUARTER ODDS | 136 | 135 | 7 | 2.33 | +837 | +119.6 |
| CANNON PLANNED TARGET | 57 | 57 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FIRE IN ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| MOVE TO CHARGE COMPUTED | 13 | 10 | 5 | 1.67 | +172 | +34.4 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 5 | 1.67 | +113 | +22.6 |
| STAY WORTH | 196 | 174 | 5 | 1.67 | +157 | +31.5 |
| FOUR ROUNDS | 11 | 10 | 4 | 1.33 | +316 | +79.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 4 | 1.33 | +95 | +23.7 |
| THE RISK READS HIS RUN | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +435 | +145.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +129 | +43.1 |
| CHARGE LOSSES | 79 | 71 | 3 | 1.00 | +82 | +27.3 |
| CHARGE NOW FIRST | 5 | 5 | 3 | 1.00 | -273 | -91.0 |
| FALLS SHORT | 51 | 47 | 3 | 1.00 | +22 | +7.2 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -5 | -1.8 |
| MAX FOR POSITIONING | 8 | 8 | 3 | 1.00 | +139 | +46.5 |
| NEXT CHARGE BY LIST | 7 | 7 | 3 | 1.00 | +88 | +29.3 |
| SET UP BY THE SET | 6 | 6 | 3 | 1.00 | +181 | +60.4 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 25 | 18 | 2 | 0.67 | +15 | +7.6 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +211 | +105.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MISSILES IN THE MOVE | 10 | 6 | 2 | 0.67 | +2 | +0.8 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +151 | +75.4 |
| SHOTS IN THE MOVE | 109 | 77 | 2 | 0.67 | +40 | +20.1 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -11 | -11.0 |
| EXACT ROUND | 7 | 7 | 1 | 0.33 | +11 | +11.0 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +4 | +4.5 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 19 | 14 | 1 | 0.33 | +28 | +28.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -187 | -186.9 |
| REDIRECT COUNTER | 6 | 3 | 1 | 0.33 | +56 | +56.4 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +38 | +38.5 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -16 | -16.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +5 | +4.8 |
| ROUNDS AFTER TERROR | 6 | 5 | 1 | 0.33 | +2 | +2.3 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +7 | +7.2 |
| SET UP TOGETHER | 1 | 1 | 1 | 0.33 | +45 | +45.3 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +79 | +78.9 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +70 | +70.5 |
| SUPPORT ADDS | 6 | 6 | 1 | 0.33 | +2 | +1.8 |
| SUPPORT WORKED OUT | 6 | 6 | 1 | 0.33 | +2 | +1.8 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +62 | +62.2 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +125 | +125.4 |
| WOUNDS ON THE RANKS | 13 | 13 | 1 | 0.33 | +9 | +8.7 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 10 | 10 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CAST JOB | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 26 | 26 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 14 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 7 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 22 | 21 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 9 | 9 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 10 | 10 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 8 | 8 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 15 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 29 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 9 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 92 | 91 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 10 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 33 | 31 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 10 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 14 | 5 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 246 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 6 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 71 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 28 | 21 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 286 | 283 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 14 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 251 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 14 | 13 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.67 | 2.67 | 15.6 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | - | 126.8 |
| ARMY TABLE | rule | 1.67 | 0.33 | 66.0 |
| RULE SWITCHED OFF | gate | 1.33 | - | 53.1 |
| CHARGE NOW FIRST | rule | 1.00 | - | 91.0 |
| JOINT CHARGE NOW | rule | 0.67 | - | 18.3 |
| BEST PRIZE | rule | 0.33 | - | 11.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 16.9 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 186.9 |
| REFUSING RETIRES | rule | - | 0.33 | 16.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |

### Plans: cnsr-c940641-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 43% | 395 | 136 | 34% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 29.3 | 94% | 2317 | 0 | 0% |
| Mine | shoot | 8.3 | 60% | 327 | 506 | 155% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 27.0 | 91% | 843 | 0 | 0% |
| Opponent | shoot | 13.0 | 77% | 349 | 964 | 277% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 52 (11) | 52 | 0 | 23 | 18% | 1.9 | 38 (5) | 102 (4) | 0 (2) | 31 (7) | 75 (4) |
| Mine | Clean-up | 3 | 99 (3) | 0 | 99 | 34 | 67% | 3.0 | 99 (3) | - | - | 150 (2) | 0 (1) |
| Mine | Hammer | 8 | 22 (8) | 7 | 15 | 37 | 25% | 2.3 | 0 (2) | 26 (6) | - | 30 (5) | 14 (3) |
| Mine | Holder | 4 | 76 (4) | 0 | 76 | 49 | 75% | 1.0 | 0 (1) | 100 (3) | - | 259 (1) | 8 (3) |
| Mine | Shooter | 1 | 58 (1) | 58 | 0 | 0 | 0% | 1.0 | 58 (1) | - | - | - | 58 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 23 (14) | 23 | 0 | 47 | 36% | 2.9 | 33 (9) | 0 (3) | - | 31 (8) | 0 (4) |
| Opponent | Clean-up | 4 | 96 (4) | 0 | 96 | 0 | 100% | - | - | 96 (4) | - | 96 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 6 | 34 (6) | 17 | 17 | 48 | 17% | 2.6 | 44 (2) | 0 (1) | 42 (3) | 34 (6) | - |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 0 | 67% | 3.0 | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 67 | 50% | 2.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 108 (9) | 108 | 0 | 71 | 11% | 1.0 | 108 (9) | - | - | 0 (1) | 125 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: cnsr-c940641-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 98 | 734 | 4.0 | 1.1 | 183 | 0 | +183 | 5 of 8 | 5 of 8 | +0 | +210 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 308 | 489 | 2.7 | 1.1 | 183 | 0 | +183 | 5 of 8 | 5 of 8 | +0 | +210 |
| Opponent | Dwarfen Mountain Holds | 1 | 1141 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 505 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: cnsr-c940641-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 8 | 1 (net +323) | 0 | 0 | 0 | 1 (net +212) | 3 (net +32) | 3 | 0% (0 of 5) |

### Charged fights, damage counted: cnsr-c940641-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 339 | 239 | +323 | 323 | 0 | +323 | +95.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 433 | 275 | +32 | 179 | 143 | +37 | +8.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 95 | +212 | 212 | 0 | +212 | +62.5 |
| Mine | No odds | 3 | 386 | 180 | +279 | 294 | 0 | +294 | +76.3 |
| Mine | All fights | 8 | 392 | 212 | +183 | 244 | 54 | +191 | +48.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p3 | move | 12 | 6 (50%) | 5 (42%) | 0 (0%) | 6 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

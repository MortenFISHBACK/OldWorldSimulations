# Doctrine scorecard: cnsr-c940641-p20

### Scorecard: cnsr-c940641-p20

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 138 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 2 | 1 | 1 | 0 | 0 | 77 |
| L1435 | 1 | 1 | Mine | no | 6 | 5 | 1 | 2 | 0 | 0 | 0 | 123 |
| L1435 | 1 | 1 | Opponent | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.5 | 3.0 | 4.0 | 0.7 | 0.0 | 0.0 | 0.0 | 146.7 |
| **Average** | | | Opponent | 50% | 0.5 | 2.0 | 3.0 | 0.7 | 0.7 | 0.0 | 0.0 | 71.7 |

### KPIs: cnsr-c940641-p20

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 18% (3 of 17) | 9% (3 of 33) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 100% (1 of 1); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 75% (6 of 8); on the table 75% | 100% (2 of 2); on the table 100% | 80% (8 of 10); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 39% (7 of 18) | - | 39% (7 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (7 of 13) | - | 54% (7 of 13) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 32% (1936 of 6000) | 40% (2389 of 6000) | 36% (4325 of 12000) |
|   infantry points that never fought | lower | 37% (339 of 923) | 69% (797 of 1159) | 55% (1136 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (15 of 26) | 58% (14 of 24) | 58% (29 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 100% (2 of 2); 2.7 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 2.3 uses a game | 0.0 uses a game | 43% (6 of 14); 1.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (2923 of 5860) | 52% (2645 of 5131) | 51% (5568 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (9%) | - | 0.3 (9%) |
| MARCHED: its unit marched | 1.3 (36%) | - | 1.3 (36%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | - | 0.3 (9%) |
| GONE: slain | 1.3 (36%) | - | 1.3 (36%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (9%) | - | 0.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 3.0 | 3.7 | 2.3 | 0.7 |
| not cast | 2.3 | 7.0 | 4.3 | 3.7 | 27.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (48%) | 0.0 (0%) | 0.3 (9%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (36%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.3 (9%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (86%) | 2.0 (29%) | 2.0 (46%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 1.3 (19%) | 1.3 (31%) | 1.3 (36%) | 6.0 (22%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.3 (9%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (14%) | 0.0 (0%) | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.7 a game | 0.0 a game | 1.8 a game |
| stood (cast and not dispelled) | 64% (7 of 11) | - | 64% (7 of 11) |
| the unit moved after it | 29% (2 of 7) | - | 29% (2 of 7) |
| it charged on its next turn | 14% (1 of 7) | - | 14% (1 of 7) |
| the enemy charged it first | 14% (1 of 7) | - | 14% (1 of 7) |
| it fought by the end of its next turn | 14% (1 of 7) | - | 14% (1 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (1 of 7) | - | 14% (1 of 7) |
| none of these (no charge, no fight, no charge escaped) | 57% (4 of 7) | - | 57% (4 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 51% (38 of 75) | 63% (62 of 99) | 57% (100 of 174) |
|   cavalry | 39% (9 of 23) | 89% (17 of 19) | 62% (26 of 42) |
|   character | 20% (5 of 25) | 40% (8 of 20) | 29% (13 of 45) |
|   chariot | - | 100% (9 of 9) | 100% (9 of 9) |
|   infantry | 83% (15 of 18) | 55% (23 of 42) | 63% (38 of 60) |
|   monster | - | 56% (5 of 9) | 56% (5 of 9) |
|   war machine | 100% (9 of 9) | - | 100% (9 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (22%) | 1.0 (8%) | 3.7 (15%) |
| CHARGED: it charged | 2.7 (22%) | 2.7 (22%) | 5.3 (22%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.7 (5%) | 1.0 (4%) |
| NO TARGET IN RANGE | 4.7 (38%) | 3.3 (27%) | 8.0 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.7 (5%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (14%) | 4.0 (32%) | 5.7 (23%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.7 | 1.0 | 95% | 1.8 pts | 23 pts |
| character | 6.0 | 1.3 | 78% | 4.2 pts | 25 pts |
| chariot | 3.0 | 1.7 | 78% | 34.7 pts | 104 pts |
| infantry | 19.0 | 5.7 | 81% | 12.6 pts | 239 pts |
| monster | 2.0 | 1.0 | 67% | 31.2 pts | 62 pts |
| war machine | 3.0 | 1.0 | 78% | 10.8 pts | 32 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 5.0 | 5.3 |
| Charges that made contact a game | 4.3 | 3.3 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | - | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.70 declared, 0.52 contact (23 units) | 0.45 declared, 0.30 contact (33 units) | 0.55 declared, 0.39 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (10 of 17) | - | - | 59% (10 of 17) |
| Character in a unit | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Character on its own | - | 50% (2 of 4) | 25% (2 of 8) | 33% (4 of 12) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 80% (8 of 10) | 100% (1 of 1) | - | 82% (9 of 11) |
| Monster | 0% (0 of 2) | 100% (1 of 1) | - | 33% (1 of 3) |
| Monstrous | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 75% (6 of 8); on the table 75% | 39% (7 of 18) | 32% | 58% (15 of 26) | 100% (1 of 1); 1.3 uses a game | 43% (6 of 14); 2.3 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 50% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | - | 17% | 0% (0 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 52% | 67% (8 of 12) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p20, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 71% (5) | 67% (2) | 70% (7) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.67 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnsr-c940641-p20

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 71% (12 of 17) | 45% (5 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 37% (10 of 27) | 45% (9 of 20) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | 43% (3 of 7) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 2) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 0.7 |
| Movement | Points that never moved of their own | 146.7 | 71.7 |
| Movement | Fights charged into per game | 4.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 12 | 1 of 6, net +230 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 12, net +532 | 1 of 6, net +17 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 12, net +59 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 12, net +126 | 3 of 6, net +316 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.3 | 22.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 24% (9 of 37) | 68% (46 of 68) |
| Shooting | Points destroyed by shooting units | 11.3 | 147.3 |
| Shooting | War machine shots | 3.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 89% (8 of 9) | - |
| Shooting | Points destroyed by war machines | 0.0 | 166.7 |
| Magic | Magic missiles cast | 2.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 6) | - |
| Magic | Wounds caused by magic missiles | 3.0 | 1.3 |
| Magic | Wounds caused by other spells | 3.0 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.7 / 0.7 / 0.0 | 3.3 / 2.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 248.3 | 231.3 |
| Combat | Points run down | 328.7 | 59.0 |
| Combat | Net points per charged fight, damage counted | +126 | +149 |
| Combat | Net per 100 charger points, damage counted | +38.4 | +41.7 |
| Combat | First round won (charged fights) | 92% | 78% |
| Combat | Net points per charged fight | +147 | +160 |
| Combat | Net points per supported fight / lone fight | - / +147 | +400 / +130 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 13 | 3 of 9 |
| Game | Points lost | 869.0 | 772.0 |
| Game | VP from objectives | 413.3 | 830.0 |
| Game | Lone holders (player turns) | 3.5 | 0.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -516 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1641
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnsr-c940641-p20

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +103.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 20.3 | +56.2 | 0.0 | 968.7 | 32.0 | +165.0 | 0.0 | 718.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| BEST PRIZE | 0.7 | -2.7 | 41.7 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 1.7 | +0.2 | 0.0 | 237.0 | - | - | - | - |
| CANNON PLANNED TARGET | 3.0 | +10.9 | 0.0 | 46.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -64.4 | 20.0 | 147.3 | 0.3 | -66.9 | 76.7 | 0.0 |
| CAST JOB | 1.3 | +21.9 | 107.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.3 | +0.0 | 0.0 | 433.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +9.4 | 0.0 | 11.3 |
| CHAFF PASSED | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 2.0 | +117.4 | 0.0 | 259.7 | 0.3 | +16.5 | 0.0 | 41.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -2.7 | 25.7 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +5.2 | 22.0 | 0.0 | 0.3 | +60.7 | 47.7 | 0.0 |
| CHARGE LOSSES | 20.7 | -845.0 | 0.0 | 726.7 | 13.7 | -466.6 | 0.0 | 298.3 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 373.0 | 47.7 | 3.0 | +0.0 | 408.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 153.3 | 14.3 | +0.0 | 0.0 | 11.3 |
| CONVEYANCE SEARCH | 3.0 | +342.0 | 433.3 | 433.3 | - | - | - | - |
| COVER ONCE | 8.3 | -468.1 | 0.0 | 183.3 | 6.7 | -597.5 | 0.0 | 212.0 |
| DENIED BY THE FIGHT | 0.3 | -0.3 | 0.0 | 0.0 | 0.7 | -1.7 | 124.3 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -82.5 | 115.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +7.5 | 20.0 | 0.0 | 0.7 | +14.6 | 266.7 | 0.0 |
| EVASIVE BY THE ODDS | 0.3 | +2.0 | 0.0 | 59.0 | 1.7 | +195.9 | 59.0 | 0.0 |
| EXACT ROUND | 3.3 | +41.8 | 329.3 | 195.0 | 2.0 | +23.0 | 391.0 | 0.0 |
| FALL BACK GOOD ORDER | 4.3 | +11.7 | 570.0 | 47.7 | 2.3 | +13.4 | 360.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 11.3 |
| FALLS SHORT | 10.0 | +112.3 | 0.0 | 166.7 | 13.7 | +144.1 | 0.0 | 104.0 |
| FEATURE BUFFS | 2.3 | +20.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.3 | +19.8 | 76.7 | 0.0 |
| FIVE ACTION | 86.7 | +4371.5 | 1174.0 | 2696.7 | 101.7 | +7717.6 | 3200.0 | 1860.7 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 225.0 | 13.0 | +0.0 | 0.0 | 243.0 |
| FOLLOW UP WEIGHED | 1.0 | +198.1 | 0.0 | 0.0 | 1.0 | +69.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.7 | +265.4 | 650.3 | 342.3 | 4.3 | +305.0 | 734.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 202.7 |
| FRIEND SHOOTS FIRST | 1.3 | -12.5 | 0.0 | 0.0 | 0.7 | -23.2 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -0.2 | 20.0 | 147.3 | 1.0 | -14.5 | 135.7 | 0.0 |
| GOAL WALK | 5.7 | +417.1 | 0.0 | 225.0 | 7.7 | +447.2 | 0.0 | 167.3 |
| GUN FIGURES | - | - | - | - | 2.0 | +62.8 | 166.7 | 0.0 |
| GUN MASK | 1.3 | -16.3 | 0.0 | 151.0 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 20.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 6.7 | +0.0 | 0.0 | 46.7 |
| HIS CHARGE BY HIS RUN | 11.7 | +0.0 | 0.0 | 260.0 | 9.0 | +0.0 | 0.0 | 298.3 |
| HIS CHARGE DENIED | - | - | - | - | 1.3 | +60.7 | 172.0 | 0.0 |
| HIS CHARGE LIST | 7.3 | +0.0 | 0.0 | 234.0 | 8.7 | +0.0 | 0.0 | 162.7 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 166.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 8.7 | -124.2 | 0.0 | 543.3 | 4.3 | -28.1 | 0.0 | 85.0 |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 266.7 | 3.7 | +0.0 | 0.0 | 147.7 |
| HIS OWN BEST MOVE | 11.3 | +0.0 | 0.0 | 214.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 55.7 | +3017.2 | 0.0 | 1933.0 | 58.7 | +1616.8 | 0.0 | 793.7 |
| HIS SHOTS BY HIS RUN | 51.7 | +1468.8 | 0.0 | 1754.7 | 43.3 | +705.7 | 0.0 | 793.7 |
| HIS TURN DENIED | 1.7 | +53.7 | 87.7 | 147.3 | 1.0 | +8.1 | 325.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 44.0 |
| HOLDER ASSIGNMENT | 9.0 | +836.3 | 0.0 | 0.0 | 8.7 | +780.5 | 0.0 | 22.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.3 | -249.3 | 572.3 | 342.3 | 3.7 | -167.2 | 600.7 | 0.0 |
| IDLE COST | 6.0 | -90.5 | 0.0 | 0.0 | 13.7 | -186.7 | 0.0 | 45.3 |
| JOINT CHARGE NOW | 0.3 | -41.4 | 78.0 | 0.0 | 0.7 | -25.4 | 266.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 157.7 | 282.0 | 4.0 | +0.0 | 206.3 | 325.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -0.4 | 316.3 | 0.0 | 1.7 | +3.4 | 284.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -114.4 | 0.0 | 11.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +3.0 | 0.0 | 0.0 | 2.0 | -5.4 | 0.0 | 91.3 |
| MARCH AT ESCAPER | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +100.0 | 0.0 | 166.7 | 0.3 | +7.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +2.8 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +11.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.7 | +280.9 | 0.0 | 433.3 | - | - | - | - |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +32.4 | 0.0 | 0.0 | 2.3 | +75.5 | 0.0 | 11.3 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +30.0 | 0.0 | 0.0 | 3.0 | +55.5 | 0.0 | 115.7 |
| MISSILES NEXT TURN | 5.7 | +29.0 | 0.0 | 300.0 | 3.3 | +66.4 | 0.0 | 115.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 22.0 | 83.7 |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 433.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.0 | +459.2 | 0.0 | 47.7 | 6.3 | +653.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.0 | +306.9 | 0.0 | 244.7 | 9.0 | +367.5 | 0.0 | 162.7 |
| NEXT CHARGE BY LIST | 4.7 | +236.2 | 41.7 | 47.7 | 4.0 | +258.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -3.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.3 | -87.3 | 507.0 | 342.3 | 3.7 | -221.6 | 734.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 11.3 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -174.6 | 0.0 | 100.0 | 3.0 | -82.4 | 50.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.7 | -170.8 | 0.0 | 0.0 | 5.7 | -130.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -26.8 | 0.0 | 0.0 | 3.7 | -230.1 | 0.0 | 22.0 |
| ONE PROMISE A TARGET | 0.7 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +56.3 | 72.7 | 147.3 | - | - | - | - |
| OVERRUNS AWAY | 2.7 | +34.9 | 265.7 | 195.0 | 1.3 | +2.8 | 262.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +7.3 | 0.0 | 0.0 |
| PLAN RESULT | 40.7 | +515.4 | 450.7 | 1698.0 | 48.0 | +1236.6 | 832.0 | 1330.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 11.0 | -317.8 | 0.0 | 0.0 | 9.7 | -482.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -3.2 | 23.3 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -5.8 | 0.0 | 0.0 |
| QUARTER ODDS | 11.0 | +1299.2 | 245.7 | 916.7 | 17.7 | +2318.9 | 1037.0 | 274.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +318.5 | 0.0 | 68.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 4.0 | +0.0 | 0.0 | 142.7 |
| REDIRECT WEIGHED | 1.3 | +7.0 | 11.3 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 3.0 | -59.5 | 0.0 | 0.0 | 4.0 | -111.2 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 4.7 | -23.4 | 494.3 | 342.3 | 3.3 | -18.6 | 467.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -42.2 | 237.3 | 0.0 | 2.0 | -60.8 | 444.0 | 0.0 |
| RUN DOWN | 2.7 | -19.7 | 396.3 | 47.7 | 4.0 | -30.0 | 734.0 | 0.0 |
| SAME CHARGE LATER | 0.3 | -3.1 | 41.7 | 0.0 | - | - | - | - |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -104.9 | 0.0 | 22.7 |
| SEARCH SPOT | 1.0 | +8.2 | 0.0 | 50.3 | 0.7 | +21.5 | 0.0 | 38.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +5.6 | 50.3 | 0.0 |
| SET CREDITED ONCE | 0.7 | -13.6 | 0.0 | 0.0 | 0.3 | -5.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +13.8 | 0.0 | 0.0 | 1.7 | -44.1 | 50.3 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +80.3 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.3 | +41.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.0 | +0.0 | 0.0 | 105.7 | 8.3 | +0.0 | 0.0 | 358.3 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +98.4 | 34.7 | 133.3 | 6.3 | +509.1 | 710.0 | 387.3 |
| SHOT OR CHARGE | 1.3 | -47.4 | 124.0 | 0.0 | 0.7 | -8.0 | 76.7 | 0.0 |
| SHOT RISK POINTS | 34.3 | -474.0 | 0.0 | 1218.0 | 19.7 | -99.4 | 0.0 | 404.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.0 | +305.5 | 0.0 | 282.7 | 21.3 | +751.8 | 0.0 | 675.3 |
| SPELL SETS UP CHARGE | 0.7 | +80.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.0 | +43.8 | 266.7 | 266.7 | 1.7 | +19.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.0 | +7.4 | 120.0 | 47.7 | 0.3 | -3.5 | 47.7 | 0.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 610.7 | 6.7 | +0.0 | 0.0 | 38.0 |
| STAND AND SHOOT | 1.0 | -6.7 | 183.7 | 0.0 | 1.0 | -5.6 | 118.0 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 36.0 | +0.0 | 523.7 | 860.7 | 34.7 | +0.0 | 2466.0 | 1172.3 |
| STAY WORTH | 24.3 | +79.1 | 399.7 | 435.0 | 16.0 | +120.9 | 333.3 | 384.7 |
| STRIKE BY THE ODDS | 0.7 | +18.0 | 20.0 | 133.3 | - | - | - | - |
| SUPPORT ADDS | 3.7 | +342.9 | 0.0 | 268.7 | 7.3 | +741.4 | 0.0 | 80.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 22.0 | 0.0 | 1.0 | +0.0 | 201.0 | 0.0 |
| SUPPORT WORKED OUT | 3.7 | +342.9 | 0.0 | 268.7 | 7.3 | +741.4 | 0.0 | 80.7 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +30.3 | 0.0 | 44.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.8 | 0.0 | 41.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 38.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 100.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 98.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 47.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.0 | +0.0 | 0.0 | 1080.0 | 48.3 | +0.0 | 0.0 | 820.3 |
| TIED UP BY THE SUM | 2.7 | +208.9 | 174.0 | 195.0 | 2.0 | +329.2 | 266.3 | 0.0 |
| TIME ON OUR SIDE | 30.0 | +374.8 | 44.0 | 933.3 | 24.3 | +262.5 | 0.0 | 794.3 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.0 | +0.0 | 166.7 | 61.7 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -54.4 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -4.5 | 76.7 | 0.0 |
| WHO HITS BACK | 0.7 | +133.9 | 0.0 | 0.0 | 0.3 | +37.1 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +27.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -54.7 | 0.0 | 212.3 | 3.0 | -224.0 | 0.0 | 197.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 0.3 | +10.4 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p20

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 157 | 157 | 118 | 39.33 | +887 | +7.5 |
| HIS SHOT LIST | 343 | 330 | 101 | 33.67 | +1751 | +17.3 |
| HIS SHOTS BY HIS RUN | 285 | 271 | 65 | 21.67 | +946 | +14.6 |
| HOLDER ASSIGNMENT | 53 | 53 | 49 | 16.33 | +3396 | +69.3 |
| FIVE ACTION | 565 | 544 | 34 | 11.33 | +1307 | +38.5 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| SHOT RISK POINTS | 162 | 157 | 27 | 9.00 | +653 | +24.2 |
| MOVE TO CHARGE COMPUTED | 43 | 36 | 25 | 8.33 | +838 | +33.5 |
| PROMISE BY ITS OWN SUM | 62 | 62 | 24 | 8.00 | -2400 | -100.0 |
| LEGAL CHARGES ONLY | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -771 | -36.7 |
| SHOOTS FROM THE BEST SPOT | 27 | 27 | 18 | 6.00 | +645 | +35.8 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 26 | 25 | 15 | 5.00 | +681 | +45.4 |
| TIME ON OUR SIDE | 163 | 146 | 15 | 5.00 | +85 | +5.6 |
| QUARTER ODDS | 86 | 83 | 14 | 4.67 | +1184 | +84.6 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 30 | 27 | 12 | 4.00 | +345 | +28.8 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| GOAL WALK | 40 | 39 | 11 | 3.67 | +468 | +42.5 |
| SUPPORT ADDS | 33 | 33 | 10 | 3.33 | +188 | +18.8 |
| SUPPORT WORKED OUT | 33 | 33 | 10 | 3.33 | +188 | +18.8 |
| THE RISK READS HIS RUN | 18 | 18 | 10 | 3.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 103 | 85 | 9 | 3.00 | +395 | +43.9 |
| TIED UP BY THE SUM | 14 | 12 | 9 | 3.00 | +273 | +30.4 |
| CHARGE LOSSES | 103 | 98 | 8 | 2.67 | +511 | +63.9 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +402 | +57.4 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| STAY WORTH | 121 | 111 | 7 | 2.33 | +42 | +6.1 |
| CHARGE NOW FIRST | 18 | 18 | 6 | 2.00 | -218 | -36.4 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +802 | +133.8 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 1.67 | +1 | +0.1 |
| COVER ONCE | 45 | 24 | 5 | 1.67 | +159 | +31.9 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +29 | +7.4 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +324 | +80.9 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +105 | +26.3 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 71 | 64 | 3 | 1.00 | +11 | +3.6 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -200 | -66.8 |
| MANOEUVRE | 11 | 11 | 3 | 1.00 | +20 | +6.8 |
| RISK BY ARC | 24 | 21 | 3 | 1.00 | +76 | +25.2 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +117 | +39.1 |
| SET UP BY THE SET | 7 | 7 | 3 | 1.00 | +29 | +9.7 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +414 | +137.8 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -48 | -23.9 |
| CARRIES OUT SET-UP | 2 | 2 | 2 | 0.67 | -394 | -196.9 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.67 | +198 | +98.9 |
| EXACT ROUND | 16 | 15 | 2 | 0.67 | +6 | +3.1 |
| HIS TURN DENIED | 8 | 7 | 2 | 0.67 | +34 | +16.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| IDLE COST | 59 | 42 | 2 | 0.67 | +17 | +8.3 |
| NEARER NOT NEEDED | 51 | 50 | 2 | 0.67 | +76 | +38.1 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | +10 | +4.8 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -10 | -4.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +54 | +27.1 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +7 | +3.4 |
| THE ROW IN ITS ORDER | 23 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 13 | 13 | 2 | 0.67 | +9 | +4.3 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +310 | +310.1 |
| CANNON PLANNED TARGET | 9 | 9 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -3 | -2.8 |
| EVASIVE BY THE ODDS | 6 | 6 | 1 | 0.33 | +521 | +521.2 |
| FIGHT TO THE END | 1 | 1 | 1 | 0.33 | +12 | +11.8 |
| HIS CHARGE DENIED | 4 | 3 | 1 | 0.33 | +42 | +41.6 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -36 | -35.8 |
| MAX FOR POSITIONING | 17 | 14 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 40 | 24 | 1 | 0.33 | +4 | +4.0 |
| ONE OBJECTIVE FORMULA | 26 | 22 | 1 | 0.33 | +38 | +37.7 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +22 | +21.9 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -2 | -1.8 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -17 | -17.3 |
| REDIRECT COUNTER | 10 | 9 | 1 | 0.33 | +60 | +59.5 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -1 | -1.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +17 | +16.7 |
| SPELLS IN THE FIGHT | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +6 | +6.3 |
| WOUNDS ON THE RANKS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 20 | 18 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 51 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 24 | 24 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| GUN MASK | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 20 | 20 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 60 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 48 | 47 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 29 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 39 | 36 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 48 | 42 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 88 | 0 | 0.00 | - | - |
| HONEST WORTH | 27 | 24 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 9 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 16 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 24 | 21 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OPENS UP | 3 | 3 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 12 | 11 | 0 | 0.00 | - | - |
| PLAN RESULT | 266 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 21 | 16 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 20 | 18 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 52 | not checked | - | - | - | - |
| SHOT OR CHARGE | 6 | 5 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 40 | 35 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 212 | 205 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 26 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 265 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | not checked | - | - | - | - |

### Off best figure: cnsr-c940641-p20

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.67 | 3.33 | 100.0 |
| ARMY TABLE | rule | 4.33 | 3.33 | 37.6 |
| JOB FIRST | gate | 4.00 | 2.33 | 38.1 |
| CHARGE NOW FIRST | rule | 1.33 | 0.67 | 36.3 |
| BEST PRIZE | rule | 0.67 | - | 23.9 |
| CARRIES OUT SET-UP | rule | 0.33 | 0.33 | 196.9 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 4.2 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 182.1 |
| NO REASON | gate | - | 0.67 | 23.3 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 4.8 |
| CHAFF PASSED | rule | 0.33 | - | 2.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 35.8 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 1.0 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.8 |
| PURSUES BIG PREY | rule | - | 0.33 | 17.3 |
| REFUSING RETIRES | rule | 0.33 | - | 1.3 |

### Plans: cnsr-c940641-p20

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 100% | 456 | 382 | 84% |
| Mine | move | 29.0 | 92% | 1236 | 0 | 0% |
| Mine | shoot | 8.0 | 42% | 368 | 133 | 36% |
| Opponent | charge | 3.7 | 64% | 459 | 415 | 90% |
| Opponent | move | 38.7 | 92% | 2032 | 0 | 0% |
| Opponent | shoot | 5.0 | 53% | 708 | 821 | 116% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: cnsr-c940641-p20

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 60% | 67% | 17% | 0% | 0% | 0% | 0% | 80% | 20% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p20

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 66 (7) | 66 | 0 | 45 | 0% | 1.6 | 37 (5) | 253 (1) | 0 (1) | 32 (5) | 137 (2) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 14 | 37 (14) | 12 | 25 | 36 | 29% | 3.8 | 20 (8) | 60 (6) | - | 50 (9) | 14 (5) |
| Mine | Shooter | 4 | 0 (4) | 0 | 0 | 51 | 0% | 1.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Chaff | 7 | 261 (7) | 0 | 261 | 89 | 14% | 2.3 | - | 517 (4) | 16 (3) | 608 (4) | 14 (3) |
| Opponent | Character | 4 | 70 (4) | 70 | 0 | 0 | 0% | 1.2 | - | 70 (4) | - | 61 (2) | 78 (2) |
| Opponent | Clean-up | 4 | 42 (4) | 42 | 0 | 70 | 0% | 5.5 | 0 (1) | 70 (2) | 0 (1) | 52 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 64 (4) | 64 | 0 | 19 | 0% | 3.0 | 57 (2) | 72 (2) | - | 42 (3) | 118 (1) |
| Opponent | Hammer | 8 | 33 (8) | 33 | 0 | 75 | 25% | 3.2 | 0 (2) | 70 (3) | 0 (3) | 81 (4) | 0 (4) |
| Opponent | Holder | 3 | 78 (3) | 0 | 78 | 62 | 0% | 3.0 | 114 (2) | - | 0 (1) | 250 (1) | 0 (2) |
| Opponent | Shooter | 4 | 146 (4) | 81 | 66 | 21 | 0% | 2.2 | 239 (1) | 142 (2) | 0 (1) | 67 (2) | 201 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 61 | 0% | 2.7 | 0 (2) | - | - | 0 (1) | 0 (1) |

### Charged fights: cnsr-c940641-p20

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 11 | 638 | 4.3 | 1.0 | 147 | 0 | +147 | 2 of 13 | 12 of 13 | - | +147 |
| Opponent | Ogre Kingdoms | 1 | 500 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 442 | 1179 | 6.0 | 1.2 | 196 | 10 | +186 | 2 of 6 | 5 of 6 | +400 | +144 |
| Opponent | Wood Elf Realms | 1 | 0 | 443 | 2.0 | 1.0 | 222 | 63 | +158 | 1 of 2 | 2 of 2 | - | +158 |
| **Opponent** | all armies | 3 | 314 | 541 | 3.0 | 1.1 | 180 | 21 | +160 | 3 of 9 | 7 of 9 | +400 | +130 |

### Effective charges: cnsr-c940641-p20

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 13 | 0 | 0 | 2 (net +532) | 0 | 8 (net +59) | 2 (net +126) | 1 | 17% (2 of 12) |
| Opponent | Tomb Kings of Khemri | 6 | 1 (net +230) | 0 | 0 | 1 (net -60) | 0 | 2 (net +324) | 2 | 0% (0 of 4) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 1 (net +17) | 0 | 0 | 1 (net +300) | 0 | 50% (1 of 2) |

### Charged fights, damage counted: cnsr-c940641-p20

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 320 | 187 | +532 | 532 | 0 | +532 | +166.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 316 | 188 | +126 | 126 | 0 | +126 | +39.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 312 | 67 | +59 | 62 | 13 | +48 | +15.5 |
| Mine | No odds | 1 | 500 | 125 | +125 | 125 | 188 | -62 | -12.5 |
| Mine | All fights | 13 | 328 | 108 | +147 | 149 | 22 | +126 | +38.4 |
| Opponent | Long shot (under 50%) | 1 | 195 | 230 | +230 | 230 | 98 | +132 | +67.9 |
| Opponent | Effective (55-75%) | 1 | 102 | 143 | +17 | 143 | 143 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 431 | 342 | -60 | 0 | 60 | -60 | -13.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 522 | 251 | +316 | 356 | 29 | +327 | +62.6 |
| Opponent | No odds | 3 | 305 | 151 | +101 | 101 | 6 | +95 | +31.2 |
| Opponent | All fights | 9 | 356 | 214 | +160 | 194 | 45 | +149 | +41.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p20 | move | 30 | 4 (13%) | 3 (10%) | 8 (27%) | 18 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

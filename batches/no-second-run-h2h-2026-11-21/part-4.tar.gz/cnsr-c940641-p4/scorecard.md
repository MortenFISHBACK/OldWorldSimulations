# Doctrine scorecard: cnsr-c940641-p4

### Scorecard: cnsr-c940641-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 95 |
| L0524 | 2 | 1 | Opponent | - | - | 6 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 295 |
| L0612 | 6 | 1 | Opponent | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 361 |
| L0628 | 4 | 1 | Opponent | no | 10 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | - | 0.0 | 3.0 | 0.0 | 0.0 | 0.0 | 250.3 |
| **Average** | | | Opponent | 0% | 6.0 | 6.0 | 0.3 | 2.3 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: cnsr-c940641-p4

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 16) | 48% (15 of 31) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Magic missiles tried each own turn | 50%+ | - | 27% (8 of 30) | 27% (8 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 27% (8 of 30) | 27% (8 of 30) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 97% (5835 of 6000) | 97% (5846 of 5998) | 97% (11681 of 11998) |
|   infantry points that never fought | lower | 100% (2232 of 2232) | 100% (694 of 694) | 100% (2926 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (19 of 27) | 74% (17 of 23) | 72% (36 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 2.7 uses a game | 67% (2 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (2788 of 4232) | 79% (4582 of 5787) | 74% (7370 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 3.3 (45%) | 3.3 (45%) |
| MARCHED: its unit marched | - | 3.7 (50%) | 3.7 (50%) |
| CHARGED: its unit charged | - | 0.3 (5%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 0.7 | 2.7 | 0.7 | 0.0 |
| not cast | 2.0 | 3.3 | 7.3 | 3.3 | 24.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (100%) | 3.3 (45%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.7 (50%) | 1.7 (50%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.3 (10%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (139 of 215) | 72% (13 of 18) | 65% (152 of 233) |
|   cavalry | 48% (11 of 23) | 17% (1 of 6) | 41% (12 of 29) |
|   character | 85% (22 of 26) | - | 85% (22 of 26) |
|   infantry | 40% (23 of 58) | - | 40% (23 of 58) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |
|   war machine | 77% (74 of 96) | 100% (12 of 12) | 80% (86 of 108) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.7 (18%) | 0.3 (20%) | 5.0 (19%) |
| CHARGED: it charged | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |
| MOVED: a war machine that moved | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 10.0 (39%) | 0.7 (40%) | 10.7 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 7.0 (28%) | 0.7 (40%) | 7.7 (28%) |
| SHELTERED: the target was sheltered | 1.3 (5%) | 0.0 (0%) | 1.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 1.3 | 77% | 7.0 pts | 30 pts |
| character | 7.3 | 5.0 | 68% | 8.8 pts | 65 pts |
| infantry | 15.3 | 2.0 | 87% | 4.0 pts | 61 pts |
| monster | 3.0 | 0.3 | 89% | 6.0 pts | 18 pts |
| war machine | 28.7 | 16.7 | 69% | 15.7 pts | 449 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 0.7 | 0.8 |
| Charges that made contact a game | 0.7 | 0.0 | 0.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.33 declared, 0.00 contact (3 units) | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.14 declared, 0.09 contact (22 units) | 0.08 declared, 0.00 contact (13 units) | 0.11 declared, 0.06 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (1 of 1) | 50% (1 of 2) | 57% (4 of 7) |
| Character in a unit | 100% (7 of 7) | 100% (4 of 4) | 100% (1 of 1) | 100% (12 of 12) |
| Character on its own | 100% (1 of 1) | 100% (3 of 3) | 100% (2 of 2) | 100% (6 of 6) |
| Infantry | 29% (2 of 7) | 50% (3 of 6) | - | 38% (5 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 97% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 17% (3 of 18) | 100% | 67% (6 of 9) | 67% (2 of 3); 8.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 33% (2 of 6) | 100% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 50% (3 of 6) | 92% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p4, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | - | - |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.67 | 0.00 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnsr-c940641-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 0% (0 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 63% (51 of 81) | 33% (6 of 18) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 11) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 2) | 0% (0 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.0 | 2.3 |
| Movement | Points that never moved of their own | 250.3 | 110.0 |
| Movement | Fights charged into per game | 0.7 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 2, net +20 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 22.0 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (34 of 66) | 0% (0 of 2) |
| Shooting | Points destroyed by shooting units | 56.0 | 0.0 |
| Shooting | War machine shots | 24.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (47 of 74) | 8% (1 of 12) |
| Shooting | Points destroyed by war machines | 0.0 | 60.0 |
| Magic | Magic missiles cast | - | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 20% (1 of 5) |
| Magic | Wounds caused by magic missiles | - | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.3 / 0.3 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 0.0 | 0.0 |
| Combat | Points run down | 13.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +18 | - |
| Combat | Net per 100 charger points, damage counted | +22.4 | - |
| Combat | First round won (charged fights) | 100% | - |
| Combat | Net points per charged fight | +20 | - |
| Combat | Net points per supported fight / lone fight | - / +20 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | - |
| Game | Points lost | 91.7 | 69.7 |
| Game | VP from objectives | 740.0 | 673.3 |
| Game | Lone holders (player turns) | 0.0 | 6.0 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) -4 VP
- Points traded per game (both sides' losses): 161
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +14.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 13.3 | -130.0 | 0.0 | 0.0 | 12.0 | +56.8 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 19.7 | +144.3 | 181.7 | 71.7 | 4.0 | +99.0 | 60.0 | 0.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 3.0 | +21.5 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +78.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -5.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.3 | -208.6 | 0.0 | 0.0 | 19.0 | -1004.7 | 0.0 | 56.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 13.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 12.0 | -755.2 | 0.0 | 0.0 | 5.7 | -234.4 | 0.0 | 56.0 |
| DEFENSIVE ARMY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 40.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| EXACT ROUND | 0.7 | +1.7 | 13.7 | 0.0 | 0.7 | +1.6 | 0.0 | 0.0 |
| FACES THE THREAT | 0.7 | +15.9 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 26.0 | +305.2 | 0.0 | 56.0 |
| FEATURE BUFFS | 0.7 | +1.4 | 0.0 | 0.0 | 1.3 | +5.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +0.7 | 13.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 143.3 | +4122.6 | 250.0 | 286.7 | 74.3 | +2407.0 | 0.0 | 139.3 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +19.3 | 13.7 | 0.0 | 0.7 | +27.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.7 | +284.3 | 0.0 | 0.0 | 1.7 | +69.6 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.7 | +48.1 | 0.0 | 0.0 | 1.7 | +50.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 6.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 56.0 |
| HIS CHARGE LIST | 10.7 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 112.0 |
| HIS MOVE AND SHOT | 1.7 | -6.2 | 0.0 | 0.0 | 4.0 | -37.8 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 112.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 48.3 | +1492.3 | 0.0 | 80.0 | 44.7 | +4891.7 | 0.0 | 27.3 |
| HIS SHOTS BY HIS RUN | 29.3 | +497.4 | 0.0 | 0.0 | 41.7 | +1188.3 | 0.0 | 139.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 0.0 | 18.3 | +0.0 | 0.0 | 112.0 |
| HOLDER ASSIGNMENT | 10.3 | +963.3 | 0.0 | 0.0 | 11.0 | +1221.9 | 0.0 | 56.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -4.9 | 13.7 | 0.0 | 0.7 | -17.1 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 17.3 | -402.2 | 0.0 | 13.7 |
| JOINT CHARGE NOW | 0.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +4.8 | 13.7 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.7 | -6.3 | 0.0 | 0.0 | 1.7 | -3.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +76.2 | 0.0 | 56.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +17.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.3 | +114.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.3 | +34.0 | 0.0 | 0.0 | 0.7 | +9.7 | 0.0 | 0.0 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 40.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 6.7 | +46.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 9.7 | +53.7 | 0.0 | 56.0 |
| MODEL FACING | 4.0 | +903.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 1.7 | +38.4 | 0.0 | 0.0 | 4.0 | +204.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +261.9 | 0.0 | 0.0 | 5.3 | +251.8 | 0.0 | 56.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 4.0 | +204.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -7.9 | 13.7 | 0.0 | 0.7 | -11.4 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.7 | -167.7 | 0.0 | 0.0 | 4.3 | -167.4 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 3.7 | +7.3 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -17.5 | 0.0 | 0.0 | 3.3 | -46.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | -36.0 | 0.0 | 0.0 | 5.0 | -86.2 | 0.0 | 56.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -28.5 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 62.7 | +702.0 | 27.3 | 103.3 | 33.0 | +47.9 | 0.0 | 83.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 4.7 | -67.4 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 18.0 | +1087.9 | 0.0 | 0.0 | 3.3 | +798.5 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +54.8 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +140.7 | 0.0 | 0.0 | 1.0 | -27.8 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 13.7 |
| REFORMS TO MEET IT | 0.3 | -1.3 | 0.0 | 0.0 | 1.3 | -5.7 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | +45.3 | 13.7 | 0.0 | 0.3 | +50.6 | 0.0 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -4.0 | 0.0 | 0.0 |
| RUN DOWN | 1.0 | -15.4 | 13.7 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -100.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +14.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -6.5 | 0.0 | 0.0 | 0.7 | -9.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +7.3 | 0.0 | 0.0 | 2.7 | +32.4 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 27.0 | +0.0 | 0.0 | 71.7 | 6.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +129.8 | 0.0 | 0.0 | 1.0 | +17.7 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -7.6 | 13.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 29.0 | +756.6 | 0.0 | 80.0 | 24.0 | -690.6 | 0.0 | 83.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 35.0 | +958.9 | 0.0 | 71.7 | 5.0 | +234.4 | 0.0 | 0.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +142.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 56.0 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 107.0 | +0.0 | 236.3 | 286.7 | 23.0 | +0.0 | 0.0 | 0.0 |
| STAY WORTH | 57.7 | +89.4 | 180.3 | 120.0 | 12.0 | +240.3 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.3 | +195.9 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.3 | +195.9 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +8.4 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +2.5 | 0.0 | 13.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 60.7 | +0.0 | 0.0 | 71.7 | 37.3 | +0.0 | 0.0 | 69.7 |
| TIED UP BY THE SUM | 0.7 | +19.0 | 13.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 62.0 | +633.1 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | +9.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -57.2 | 0.0 | 0.0 | 0.7 | -35.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.3 | +39.6 | 0.0 | 0.0 | 3.3 | +354.2 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 279 | 277 | 105 | 35.00 | +3632 | +34.6 |
| HOLDER ASSIGNMENT | 64 | 64 | 60 | 20.00 | +3404 | +56.7 |
| HIS SHOTS BY HIS RUN | 213 | 206 | 58 | 19.33 | +923 | +15.9 |
| SHOT RISK POINTS | 159 | 157 | 51 | 17.00 | +1738 | +34.1 |
| ARMY TABLE | 76 | 76 | 49 | 16.33 | +497 | +10.1 |
| TIME ON OUR SIDE | 186 | 168 | 34 | 11.33 | +119 | +3.5 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -1005 | -30.5 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| CHARGE LOSSES | 94 | 92 | 16 | 5.33 | +1199 | +74.9 |
| CANNON PLANNED TARGET | 71 | 71 | 14 | 4.67 | +62 | +4.5 |
| COVER ONCE | 53 | 44 | 14 | 4.67 | +87 | +6.2 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| FIVE ACTION | 653 | 646 | 13 | 4.33 | +302 | +23.2 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +2710 | +225.8 |
| IDLE COST | 52 | 45 | 11 | 3.67 | +354 | +32.2 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +22 | +2.0 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 17 | 15 | 10 | 3.33 | +105 | +10.5 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 10 | 3.33 | +204 | +20.4 |
| SHOTS AFTER THE MOVES | 24 | 24 | 10 | 3.33 | +0 | +0.0 |
| SUPPORT ADDS | 13 | 13 | 10 | 3.33 | +170 | +17.0 |
| SUPPORT WORKED OUT | 13 | 13 | 10 | 3.33 | +170 | +17.0 |
| NEXT CHARGE BY LIST | 12 | 12 | 8 | 2.67 | +98 | +12.3 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 8 | 2.67 | -202 | -25.3 |
| SET UP BY THE SET | 12 | 12 | 8 | 2.67 | -34 | -4.3 |
| GOAL WALK | 16 | 16 | 6 | 2.00 | +500 | +83.3 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| QUARTER ODDS | 64 | 64 | 6 | 2.00 | +948 | +158.0 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 17 | 17 | 6 | 2.00 | +306 | +51.0 |
| CAST JOB | 9 | 9 | 4 | 1.33 | +3 | +0.8 |
| FALLS SHORT | 78 | 67 | 4 | 1.33 | +64 | +16.1 |
| FOUR ROUNDS | 5 | 5 | 4 | 1.33 | +37 | +9.2 |
| MARCH CHECK | 4 | 4 | 4 | 1.33 | +48 | +11.9 |
| RISK BY ARC | 4 | 4 | 4 | 1.33 | +38 | +9.5 |
| THE RISK READS HIS RUN | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| GUN MASK | 13 | 13 | 3 | 1.00 | +60 | +20.1 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +48 | +23.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| NEARER NOT NEEDED | 34 | 29 | 2 | 0.67 | +70 | +34.9 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -86 | -42.8 |
| REDIRECT COUNTER | 7 | 5 | 2 | 0.67 | +23 | +11.4 |
| STAY WORTH | 209 | 197 | 2 | 0.67 | +14 | +6.9 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +33 | +16.6 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +44 | +43.8 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -17 | -16.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +1 | +1.2 |
| LOST AFTER ESCAPE | 3 | 3 | 1 | 0.33 | +5 | +4.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -52 | -51.9 |
| MAX FOR POSITIONING | 6 | 5 | 1 | 0.33 | +1 | +1.1 |
| MISSILES IN THE MOVE | 20 | 18 | 1 | 0.33 | +11 | +11.4 |
| ONE FIGHT FORMULA | 21 | 15 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 34 | 32 | 1 | 0.33 | +8 | +8.1 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +43 | +43.4 |
| SHOTS IN THE MOVE | 120 | 96 | 1 | 0.33 | +12 | +11.7 |
| SURE REACH TOGETHER | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.6 |
| WHO FIGHTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 16 | 16 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 62 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 3 | 3 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 25 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 52 | 52 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 66 | 66 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 30 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 37 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 101 | 101 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| MANOEUVRE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 29 | 26 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 287 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 100 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 29 | 21 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 390 | 385 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 294 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 8 | 8 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 4.00 | 29.7 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | - | 25.3 |
| ARMY TABLE | rule | 0.67 | 0.67 | 48.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 17.5 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 42.8 |
| SET UP BY THE SET | rule | - | 0.67 | 26.0 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| FALLBACK | gate | 0.33 | - | 1.5 |
| JOINT CHARGE NOW | rule | 0.33 | - | 16.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | - | 82.2 |
| MARCH OF THE TABLE | rule | - | 0.33 | 51.9 |
| NO REASON | gate | - | 0.33 | 29.4 |

### Plans: cnsr-c940641-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 23 | 23 | 101% |
| Mine | join | 2.3 | 100% | 85 | 0 | 0% |
| Mine | move | 38.0 | 99% | 1025 | 0 | 0% |
| Mine | shoot | 21.3 | 45% | 564 | 679 | 120% |
| Opponent | charge | 0.3 | 0% | 26 | 0 | 0% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 26.7 | 98% | 732 | 0 | 0% |
| Opponent | shoot | 4.3 | 46% | 170 | 48 | 28% |
| Opponent | support | 0.7 | 100% | 29 | 0 | 0% |

### Battle groups: cnsr-c940641-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 0 (13) | 0 | 0 | 0 | 38% | 3.0 | 0 (6) | 0 (6) | 0 (1) | 0 (11) | 0 (2) |
| Mine | Clean-up | 4 | 20 (4) | 0 | 20 | 0 | 75% | 1.0 | 0 (1) | 0 (1) | 39 (2) | 20 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 87 (4) | 0 | 87 | 0 | 50% | 2.0 | 0 (1) | 147 (3) | - | 87 (4) | - |
| Mine | Shooter | 8 | 74 (8) | 3 | 71 | 0 | 25% | 2.3 | 164 (1) | 98 (4) | 9 (3) | 78 (6) | 66 (2) |
| Mine | War machine | 17 | 10 (17) | 10 | 0 | 16 | 12% | 1.5 | 0 (4) | 18 (9) | 0 (4) | 0 (3) | 12 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 25 | 67% | 3.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 0 (10) | 0 | 0 | 0 | 70% | 2.0 | 0 (3) | 0 (5) | 0 (2) | 0 (9) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 3 | 25 (3) | 0 | 25 | 0 | 100% | - | 0 (1) | 84 (1) | 0 (1) | 35 (2) | 0 (1) |
| Opponent | Holder | 6 | 94 (6) | 0 | 94 | 15 | 50% | 2.3 | 0 (1) | 111 (5) | - | 119 (4) | 51 (2) |
| Opponent | War machine | 2 | 55 (2) | 55 | 0 | 0 | 0% | 1.0 | - | 109 (1) | 0 (1) | - | 55 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: cnsr-c940641-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 56 | 14 | 0.7 | 1.0 | 20 | 0 | +20 | 0 of 2 | 2 of 2 | - | +20 |
| Opponent | Grand Cathay | 1 | 180 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 60 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: cnsr-c940641-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +20) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cnsr-c940641-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 82 | 76 | +20 | 48 | 30 | +18 | +22.4 |
| Mine | All fights | 2 | 82 | 76 | +20 | 48 | 30 | +18 | +22.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p4 | move | 9 | 2 (22%) | 1 (11%) | 0 (0%) | 7 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

# Doctrine scorecard: cnsr-c940641-p16

### Scorecard: cnsr-c940641-p16

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 335 |
| L0528 | 6 | 1 | Opponent | no | 9 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 798 |
| L0616 | 4 | 1 | Opponent | no | 2 | 5 | 0 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 4 | 3 | 2 | 0 | 0 | 0 | 500 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.0 | 4.0 | 1.3 | 2.3 | 0.0 | 0.0 | 0.0 | 544.3 |
| **Average** | | | Opponent | 0% | 5.5 | 4.0 | 0.3 | 2.3 | 0.3 | 0.0 | 0.0 | 66.7 |

### KPIs: cnsr-c940641-p16

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (13 of 13) | 0% (0 of 10) | 57% (13 of 23) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 33% | 100% (4 of 4); on the table 100% | 71% (5 of 7); on the table 71% |
| Magic missiles tried each own turn | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 89% (5327 of 6000) | 75% (4481 of 5999) | 82% (9808 of 11999) |
|   infantry points that never fought | lower | 90% (1999 of 2232) | 100% (720 of 720) | 92% (2719 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (18 of 27) | 71% (15 of 21) | 69% (33 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (2586 of 4232) | 62% (3373 of 5415) | 62% (5959 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (83%) | 1.7 (83%) |
| MARCHED: its unit marched | - | 0.3 (17%) | 0.3 (17%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 0.3 | 0.0 | 0.0 | 0.0 |
| not cast | 3.7 | 2.0 | 2.0 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.7 (83%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.7 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (55%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (117 of 191) | 56% (20 of 36) | 60% (137 of 227) |
|   cavalry | 39% (7 of 18) | 62% (8 of 13) | 48% (15 of 31) |
|   character | 61% (14 of 23) | 0% (0 of 6) | 48% (14 of 29) |
|   infantry | 45% (22 of 49) | 0% (0 of 5) | 41% (22 of 54) |
|   monster | 83% (10 of 12) | - | 83% (10 of 12) |
|   war machine | 72% (64 of 89) | 100% (12 of 12) | 75% (76 of 101) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 6.0 (24%) | 0.7 (12%) | 6.7 (22%) |
| CHARGED: it charged | 1.7 (7%) | 0.3 (6%) | 2.0 (7%) |
| IN COMBAT: it fought this turn or the last | 0.3 (1%) | 0.3 (6%) | 0.7 (2%) |
| NO TARGET IN RANGE | 7.0 (28%) | 2.3 (44%) | 9.3 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (1%) | 0.3 (6%) | 0.7 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.7 (23%) | 1.3 (25%) | 7.0 (23%) |
| SHELTERED: the target was sheltered | 2.0 (8%) | 0.0 (0%) | 2.0 (7%) |
| OTHER BAR | 1.7 (7%) | 0.0 (0%) | 1.7 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.0 | 81% | 6.3 pts | 34 pts |
| character | 4.7 | 4.0 | 64% | 11.4 pts | 53 pts |
| infantry | 14.3 | 3.7 | 77% | 8.3 pts | 119 pts |
| monster | 3.3 | 1.3 | 80% | 6.4 pts | 21 pts |
| war machine | 25.3 | 14.3 | 61% | 18.7 pts | 473 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.0 | 2.0 |
| Charges that made contact a game | 2.0 | 1.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.29 contact (21 units) | 0.30 declared, 0.15 contact (20 units) | 0.29 declared, 0.22 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (4 of 4) | - | 50% (1 of 2) | 83% (5 of 6) |
| Character in a unit | 100% (7 of 7) | 67% (2 of 3) | 100% (1 of 1) | 91% (10 of 11) |
| Character on its own | - | 50% (1 of 2) | 33% (1 of 3) | 40% (2 of 5) |
| Infantry | 57% (4 of 7) | 33% (2 of 6) | - | 46% (6 of 13) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 33% (1 of 3); on the table 33% | - | 89% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 77% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 73% | 87% (13 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p16, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 80% (4) | 71% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnsr-c940641-p16

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (4 of 4) | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 55% (49 of 89) | 50% (7 of 14) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 11) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 50% (1 of 2) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.3 | 2.3 |
| Movement | Points that never moved of their own | 544.3 | 66.7 |
| Movement | Fights charged into per game | 2.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +0 | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 1 of 2, net +120 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +0 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 19.7 | 5.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (37 of 59) | 13% (2 of 15) |
| Shooting | Points destroyed by shooting units | 291.0 | 0.0 |
| Shooting | War machine shots | 21.3 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 73% (47 of 64) | 75% (9 of 12) |
| Shooting | Points destroyed by war machines | 196.3 | 38.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 71.7 |
| Combat | Points run down | 0.0 | 77.7 |
| Combat | Net points per charged fight, damage counted | +83 | +133 |
| Combat | Net per 100 charger points, damage counted | +126.1 | +44.7 |
| Combat | First round won (charged fights) | 83% | 67% |
| Combat | Net points per charged fight | +0 | +133 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +133 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 6 | 1 of 3 |
| Game | Points lost | 282.0 | 464.0 |
| Game | VP from objectives | 570.0 | 460.0 |
| Game | Lone holders (player turns) | 1.0 | 5.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +292 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 746
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p16

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.0 | +36.7 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 9.7 | +141.4 | 0.0 | 0.0 | 22.3 | +373.9 | 0.0 | 106.7 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 33.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -68.5 | 61.0 | 0.0 |
| BOMBING RUN | 0.7 | +9.4 | 157.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 2.0 | +0.0 | 361.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 22.0 | +855.0 | 2078.3 | 106.7 | 4.0 | +93.4 | 76.7 | 66.7 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +44.4 | 0.0 | 10.0 |
| CHAFF PASSED | 1.0 | -1.5 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +30.3 | 0.0 | 61.0 | - | - | - | - |
| CHARACTER GUNS | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 7.0 | -129.8 | 0.0 | 0.0 | 18.3 | -1171.0 | 0.0 | 788.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 471.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 61.0 | 0.0 |
| COVER ONCE | 4.3 | -369.1 | 0.0 | 0.0 | 5.0 | -201.4 | 0.0 | 0.0 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 77.7 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +14.0 | 0.0 | 0.0 | 2.0 | -7.7 | 256.3 | 157.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.6 | 0.0 | 0.0 | 0.7 | +0.0 | 40.0 | 157.0 |
| FALLS SHORT | - | - | - | - | 20.0 | +147.7 | 0.0 | 546.7 |
| FEATURE BUFFS | 1.3 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +0.8 | 0.0 | 0.0 | 0.3 | +14.1 | 61.0 | 0.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 26.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 133.0 | +7643.8 | 5784.3 | 368.7 | 77.3 | +2222.0 | 409.7 | 1353.0 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 320.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +107.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +39.5 | 0.0 | 0.0 | 2.0 | +69.5 | 256.3 | 157.0 |
| FRIEND SHOOTS FIRST | 1.3 | -121.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -1.3 | 61.0 | 0.0 |
| GOAL WALK | 3.7 | +105.8 | 0.0 | 0.0 | 13.3 | +943.0 | 0.0 | 0.0 |
| GUN FIGURES | 1.0 | +12.8 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 3.0 | +67.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 5.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.7 | +0.0 | 155.3 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 714.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +16.2 | 0.0 | 0.0 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 370.7 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 314.0 |
| HIS MOVE AND SHOT | 1.3 | -13.2 | 0.0 | 0.0 | 3.7 | -43.2 | 0.0 | 216.3 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 53.3 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 314.0 |
| HIS RANDOM MOVE | 18.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 26.0 | +692.0 | 0.0 | 0.0 | 61.3 | +4627.8 | 0.0 | 1062.7 |
| HIS SHOTS BY HIS RUN | 19.0 | +241.7 | 0.0 | 77.7 | 53.3 | +1890.2 | 0.0 | 1062.7 |
| HIS TURN DENIED | 0.3 | +2.9 | 0.0 | 0.0 | 0.7 | +19.5 | 155.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.3 | +0.0 | 0.0 | 77.7 | 12.3 | +0.0 | 0.0 | 74.0 |
| HOLDER ASSIGNMENT | 10.3 | +1131.1 | 0.0 | 77.7 | 7.7 | +725.7 | 0.0 | 37.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -11.7 | 0.0 | 0.0 | 1.7 | -91.3 | 178.7 | 157.0 |
| IDLE COST | - | - | - | - | 19.0 | -347.0 | 0.0 | 411.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +245.3 | 155.3 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 163.0 | 61.0 | 2.7 | +0.0 | 61.0 | 26.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +1.5 | 0.0 | 0.0 | 0.7 | -5.5 | 61.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | -25.9 | 0.0 | 0.0 | 2.0 | +3.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | - | - | - | - | 1.3 | +8.3 | 0.0 | 26.7 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +4.3 | 0.0 | 0.0 |
| MODEL FACING | 4.0 | +1388.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +175.9 | 0.0 | 0.0 | 2.7 | +136.2 | 0.0 | 53.3 |
| NEARER NOT NEEDED | 4.0 | +190.7 | 0.0 | 0.0 | 3.7 | +213.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.7 | +92.2 | 0.0 | 0.0 | 1.7 | +91.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -32.2 | 0.0 | 0.0 | 1.0 | -26.5 | 117.7 | 157.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -231.6 | 0.0 | 77.7 | 3.7 | -151.0 | 0.0 | 33.3 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +1.2 | 77.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -45.0 | 0.0 | 0.0 | 3.0 | -68.2 | 0.0 | 346.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +9.5 | 155.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | -54.3 | 0.0 | 77.7 | 2.7 | +4.7 | 0.0 | 37.0 |
| ONE PROMISE A TARGET | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +8.7 | 0.0 | 0.0 | 0.7 | +1.3 | 77.7 | 0.0 |
| PATHS CROSS | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 10.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 60.0 | +1919.1 | 2250.3 | 363.0 | 37.0 | +282.2 | 61.0 | 631.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.3 | -141.7 | 0.0 | 0.0 | 3.7 | -81.1 | 0.0 | 53.3 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 53.3 |
| PROMISE READS THE TABLE | 1.3 | -181.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 12.3 | +899.7 | 694.7 | 0.0 | 10.3 | +1027.2 | 40.0 | 343.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +74.6 | 0.0 | 113.3 |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 3.0 | -17.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +194.9 | 0.0 | 26.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.7 | +8.8 | 0.0 | 26.7 |
| REFORMS TO MEET IT | 2.0 | -24.0 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.7 | +34.5 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.7 | +49.1 | 0.0 | 0.0 | 1.7 | +28.3 | 178.7 | 157.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -8.9 | 178.7 | 157.0 |
| RUN DOWN | 2.0 | -15.8 | 0.0 | 0.0 | 1.0 | -6.6 | 77.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -82.0 | 0.0 | 20.0 |
| SEARCH SPOT | 0.3 | +5.2 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -181.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | +181.1 | 0.0 | 0.0 | 0.7 | -14.8 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +25.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 31.3 | +0.0 | 0.0 | 184.3 | 5.7 | +0.0 | 0.0 | 66.7 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +29.3 | 157.0 | 0.0 | 0.3 | +34.0 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 8.7 | +169.3 | 0.0 | 0.0 | 34.0 | -729.9 | 0.0 | 1062.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 38.0 | +2134.1 | 0.0 | 184.3 | 9.0 | +296.5 | 0.0 | 483.0 |
| SPELL WORTH | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 63.7 |
| STAND AND SHOOT | 0.3 | -1.2 | 0.0 | 0.0 | 0.3 | -4.5 | 61.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.0 | +0.0 | 0.0 | 163.0 |
| STANDS STILL | 96.0 | +0.0 | 5784.3 | 291.0 | 24.0 | +0.0 | 153.3 | 300.0 |
| STAY WORTH | 77.3 | +813.6 | 3060.7 | 200.0 | 12.0 | +336.9 | 153.3 | 289.7 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.3 | +59.1 | 0.0 | 0.0 | 3.0 | +63.5 | 0.0 | 26.7 |
| SUPPORT NARROWED | 1.0 | +0.0 | 157.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.3 | +59.1 | 0.0 | 0.0 | 3.0 | +63.5 | 0.0 | 26.7 |
| SURE REACH TOGETHER | 0.7 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +9.7 | 0.0 | 10.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 10.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 13.7 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 13.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 62.0 | +0.0 | 0.0 | 184.3 | 36.7 | +0.0 | 0.0 | 551.3 |
| TIED UP BY THE SUM | 0.7 | +15.8 | 0.0 | 0.0 | 0.7 | +47.7 | 40.0 | 157.0 |
| TIME ON OUR SIDE | 53.0 | +587.9 | 27.3 | 77.7 | - | - | - | - |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 1.0 | -3.7 | 0.0 | 0.0 | 1.0 | +7.3 | 77.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +13.1 | 0.0 | 157.0 |
| WHOLE FIGHT DANGER | 0.3 | -2.3 | 0.0 | 0.0 | 3.7 | -358.4 | 0.0 | 351.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +14.3 | 77.7 | 0.0 |
| WOUNDS ON THE RANKS | 1.7 | +75.3 | 0.0 | 0.0 | 3.7 | +259.0 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p16

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 96 | 96 | 70 | 23.33 | +1202 | +17.2 |
| HIS SHOT LIST | 262 | 252 | 51 | 17.00 | +1332 | +26.1 |
| HOLDER ASSIGNMENT | 54 | 54 | 51 | 17.00 | +3404 | +66.7 |
| HIS SHOTS BY HIS RUN | 217 | 212 | 45 | 15.00 | +703 | +15.6 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -1148 | -38.3 |
| SHOT RISK POINTS | 128 | 124 | 25 | 8.33 | +531 | +21.2 |
| TIME ON OUR SIDE | 159 | 141 | 23 | 7.67 | +62 | +2.7 |
| FIVE ACTION | 631 | 615 | 22 | 7.33 | +282 | +12.8 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 21 | 7.00 | -668 | -31.8 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 78 | 78 | 18 | 6.00 | -80 | -4.4 |
| MOVE TO CHARGE COMPUTED | 24 | 21 | 18 | 6.00 | +265 | +14.7 |
| LEGAL CHARGES ONLY | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +4167 | +347.2 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| GOAL WALK | 51 | 51 | 9 | 3.00 | +478 | +53.1 |
| IDLE COST | 57 | 45 | 9 | 3.00 | +43 | +4.8 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 9 | 3.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 141 | 118 | 9 | 3.00 | +413 | +45.9 |
| CHAFF IN THE MOVE | 8 | 8 | 8 | 2.67 | +46 | +5.7 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +224 | +28.0 |
| NEXT CHARGE BY LIST | 10 | 8 | 7 | 2.33 | +217 | +30.9 |
| CHARGE LOSSES | 76 | 74 | 6 | 2.00 | +173 | +28.8 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 268 | 251 | 6 | 2.00 | +203 | +33.9 |
| COVER ONCE | 28 | 23 | 5 | 1.67 | +118 | +23.5 |
| FOUR ROUNDS | 12 | 11 | 5 | 1.67 | +39 | +7.8 |
| QUARTER ODDS | 68 | 66 | 5 | 1.67 | +102 | +20.5 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +104 | +20.7 |
| RISK BY ARC | 10 | 9 | 5 | 1.67 | +159 | +31.7 |
| WOUNDS ON THE RANKS | 16 | 16 | 5 | 1.67 | +198 | +39.7 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -5 | -1.3 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| GUN MASK | 9 | 9 | 4 | 1.33 | +136 | +33.9 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| SUPPORT ADDS | 13 | 13 | 4 | 1.33 | +33 | +8.2 |
| SUPPORT WORKED OUT | 13 | 13 | 4 | 1.33 | +33 | +8.2 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +110 | +36.7 |
| EXACT ROUND | 11 | 10 | 3 | 1.00 | +7 | +2.4 |
| FALLS SHORT | 60 | 49 | 3 | 1.00 | +20 | +6.8 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 3 | 1.00 | +0 | +0.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.67 | +28 | +14.1 |
| FEATURE BUFFS | 4 | 4 | 2 | 0.67 | +4 | +2.2 |
| FIGHT TO THE END | 4 | 4 | 2 | 0.67 | +16 | +7.8 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +12 | +6.1 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +736 | +367.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +11 | +5.7 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +8 | +3.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +3 | +1.6 |
| PROMISE READS THE TABLE | 4 | 4 | 2 | 0.67 | -299 | -149.6 |
| REDIRECT BY WHAT IT STOPS | 9 | 9 | 2 | 0.67 | +25 | +12.3 |
| REDIRECT COUNTER | 10 | 8 | 2 | 0.67 | +102 | +51.2 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +21 | +10.5 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +13 | +6.5 |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 2 | 0.67 | +107 | +53.3 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +29 | +14.5 |
| TIED UP BY THE SUM | 4 | 4 | 2 | 0.67 | +10 | +5.2 |
| WHOLE FIGHT DANGER | 12 | 11 | 2 | 0.67 | +28 | +14.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +91 | +90.9 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -22 | -22.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +323 | +323.1 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +1 | +0.6 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| MAX FOR POSITIONING | 4 | 4 | 1 | 0.33 | +1 | +1.4 |
| ONE FIGHT FORMULA | 22 | 17 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -2 | -2.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -8 | -8.2 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -11 | -10.7 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +7 | +7.1 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 5 | 1 | 0.33 | +1 | +0.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +39 | +39.3 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 13 | 13 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 54 | 54 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 23 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 4 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 43 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 66 | 64 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 15 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 28 | 27 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 55 | 53 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 1 | 1 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 77 | 76 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 23 | 20 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 18 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 291 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 2 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 6 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 111 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 38 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 360 | 351 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 296 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p16

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.33 | 36.7 |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 1.67 | 31.8 |
| ARMY TABLE | rule | 1.33 | 3.33 | 39.1 |
| CANNON PLANNED TARGET | rule | 3.00 | - | 9.7 |
| CHAFF PASSED | rule | 0.67 | 0.33 | 1.8 |
| RULE SWITCHED OFF | gate | 1.00 | - | 74.3 |
| PROMISE READS THE TABLE | rule | 0.67 | - | 149.6 |
| AFTERMATH BAND | gate | - | 0.33 | 0.9 |
| CHARGE NOW FIRST | rule | 0.33 | - | 22.0 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 29.1 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 2.4 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 8.2 |
| REFUSING RETIRES | rule | 0.33 | - | 10.7 |

### Plans: cnsr-c940641-p16

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 0% | 43 | 35 | 81% |
| Mine | join | 2.7 | 100% | 88 | 0 | 0% |
| Mine | move | 31.0 | 99% | 1303 | 0 | 0% |
| Mine | shoot | 24.7 | 76% | 1862 | 1884 | 101% |
| Opponent | charge | 1.7 | 80% | 204 | 206 | 101% |
| Opponent | move | 29.3 | 98% | 990 | 0 | 0% |
| Opponent | shoot | 4.0 | 17% | 264 | 77 | 29% |
| Opponent | support | 2.0 | 83% | 29 | 0 | 0% |

### Battle groups: cnsr-c940641-p16

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 20% | 50% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p16

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 3 (13) | 3 | 0 | 6 | 46% | 2.6 | 0 (3) | 0 (5) | 7 (4) | 4 (7) | 0 (5) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Hammer | 6 | 78 (6) | 13 | 65 | 0 | 50% | 3.0 | - | 80 (4) | 73 (2) | 74 (5) | 88 (1) |
| Mine | Shooter | 10 | 76 (10) | 38 | 38 | 29 | 0% | 2.5 | - | 33 (4) | 122 (6) | 30 (5) | 133 (5) |
| Mine | War machine | 17 | 45 (17) | 45 | 0 | 20 | 12% | 1.4 | 71 (9) | 49 (2) | 0 (6) | 0 (3) | 54 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 58 | 40% | 3.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 25 (8) | 25 | 0 | 38 | 62% | 3.0 | 10 (3) | 0 (1) | 43 (4) | 38 (5) | 0 (3) |
| Opponent | Clean-up | 3 | 70 (3) | 0 | 70 | 0 | 67% | 4.0 | 71 (1) | 69 (2) | - | 70 (3) | - |
| Opponent | Fast Hammer | 4 | 27 (4) | 0 | 27 | 0 | 50% | 2.5 | - | 48 (3) | 0 (1) | 61 (2) | 0 (2) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 42 | 100% | - | 0 (1) | 0 (2) | - | 0 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 44 | 0% | 3.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 2 | 58 (2) | 58 | 0 | 50 | 0% | 1.0 | - | - | 58 (2) | - | 58 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: cnsr-c940641-p16

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 487 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 6 | 5 of 6 | - | +0 |
| Opponent | Kingdom of Bretonnia | 1 | 115 | 120 | 1.0 | 1.0 | 120 | 0 | +120 | 0 of 1 | 1 of 1 | - | +120 |
| Opponent | Warriors of Chaos | 2 | 0 | 139 | 1.0 | 1.0 | 139 | 0 | +139 | 1 of 2 | 1 of 2 | - | +139 |
| **Opponent** | all armies | 3 | 38 | 133 | 1.0 | 1.0 | 133 | 0 | +133 | 1 of 3 | 2 of 3 | - | +133 |

### Effective charges: cnsr-c940641-p16

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 1 (net +0) | 2 | 0% (0 of 4) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 0 | 1 (net +120) | 0 | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p16

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 60 | 137 | +0 | 20 | 0 | +20 | +32.6 |
| Mine | 76-89% | 2 | 82 | 108 | +0 | 58 | 26 | +32 | +38.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 60 | 137 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 2 | 55 | 82 | +0 | 239 | 32 | +207 | +376.8 |
| Mine | All fights | 6 | 66 | 109 | +0 | 102 | 19 | +83 | +126.1 |
| Opponent | Long shot (under 50%) | 1 | 30 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 371 | 120 | +120 | 120 | 0 | +120 | +32.3 |
| Opponent | No odds | 1 | 489 | 183 | +278 | 278 | 0 | +278 | +56.9 |
| Opponent | All fights | 3 | 297 | 121 | +133 | 133 | 0 | +133 | +44.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p16 | move | 17 | 4 (24%) | 4 (24%) | 0 (0%) | 13 (76%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

# Doctrine scorecard: cnsr-c940641-p40

### Scorecard: cnsr-c940641-p40

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 702 |
| L0528 | 6 | 1 | Opponent | no | 9 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 1061 |
| L0616 | 4 | 1 | Opponent | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 100 |
| L0632 | 2 | 1 | Mine | - | - | 5 | 3 | 1 | 0 | 0 | 0 | 801 |
| L0632 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 5.0 | 1.3 | 2.7 | 0.0 | 0.0 | 0.0 | 854.7 |
| **Average** | | | Opponent | 0% | 5.0 | - | 0.0 | 1.7 | 0.3 | 0.0 | 0.0 | 33.3 |

### KPIs: cnsr-c940641-p40

Rules off - Opponent only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (13 of 13) | 0% (0 of 10) | 57% (13 of 23) |
| Winner chose to follow up after the loser gave ground |  | 43% (3 of 7); on the table 57% | 100% (6 of 6); on the table 100% | 69% (9 of 13); on the table 77% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 50% (2 of 4); on the table 50% | 60% (3 of 5); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 56% (5 of 9); on the table 67% | 80% (8 of 10); on the table 80% | 68% (13 of 19); on the table 74% |
| Magic missiles tried each own turn | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 58% (7 of 12) | 58% (7 of 12) |
| Points that never fought | lower | 84% (5011 of 6000) | 77% (4649 of 5999) | 81% (9660 of 11999) |
|   infantry points that never fought | lower | 81% (1813 of 2232) | 85% (613 of 720) | 82% (2426 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (21 of 27) | 67% (14 of 21) | 73% (35 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 74% (3140 of 4232) | 70% (3787 of 5415) | 72% (6927 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (67%) | 1.3 (67%) |
| MARCHED: its unit marched | - | 0.7 (33%) | 0.7 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.0 | 0.0 | 0.0 | 0.0 |
| not cast | 3.0 | 2.0 | 2.0 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.3 (67%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (123 of 194) | 62% (18 of 29) | 63% (141 of 223) |
|   cavalry | 33% (7 of 21) | 67% (6 of 9) | 43% (13 of 30) |
|   character | 70% (16 of 23) | 0% (0 of 3) | 62% (16 of 26) |
|   infantry | 49% (25 of 51) | 20% (1 of 5) | 46% (26 of 56) |
|   monster | 45% (5 of 11) | - | 45% (5 of 11) |
|   war machine | 80% (70 of 88) | 92% (11 of 12) | 81% (81 of 100) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (14%) | 1.3 (36%) | 4.7 (17%) |
| CHARGED: it charged | 3.0 (13%) | 0.0 (0%) | 3.0 (11%) |
| IN COMBAT: it fought this turn or the last | 0.7 (3%) | 0.3 (9%) | 1.0 (4%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (9%) | 0.3 (1%) |
| NO TARGET IN RANGE | 6.7 (28%) | 1.7 (45%) | 8.3 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 8.0 (34%) | 0.0 (0%) | 8.0 (29%) |
| SHELTERED: the target was sheltered | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 2.0 | 64% | 13.0 pts | 61 pts |
| character | 5.3 | 4.7 | 62% | 13.8 pts | 74 pts |
| infantry | 17.7 | 6.3 | 72% | 8.6 pts | 152 pts |
| monster | 1.7 | 1.0 | 60% | 6.9 pts | 11 pts |
| war machine | 27.0 | 17.0 | 64% | 20.2 pts | 546 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 0.3 | 2.0 |
| Charges that made contact a game | 3.0 | 0.3 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.43 contact (21 units) | 0.05 declared, 0.05 contact (20 units) | 0.29 declared, 0.24 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | 50% (1 of 2) | 50% (3 of 6) |
| Character in a unit | 100% (6 of 6) | 100% (3 of 3) | 100% (1 of 1) | 100% (10 of 10) |
| Character on its own | 100% (1 of 1) | 50% (1 of 2) | 100% (3 of 3) | 83% (5 of 6) |
| Infantry | 43% (3 of 7) | 50% (3 of 6) | - | 46% (6 of 13) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 56% (5 of 9); on the table 67% | - | 84% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (5 of 5); on the table 100% | - | 77% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 60% (3 of 5); on the table 60% | 0% (0 of 6) | 78% | 73% (11 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p40, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 80% (4) | 67% (4) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p40

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 82% (9 of 11) | 100% (1 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (62 of 92) | 58% (7 of 12) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 17% (1 of 6) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.7 | 1.7 |
| Movement | Points that never moved of their own | 854.7 | 33.3 |
| Movement | Fights charged into per game | 2.3 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 1 of 1, net +60 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +80 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 7 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 7, net +0 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 19.0 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (24 of 57) | 14% (2 of 14) |
| Shooting | Points destroyed by shooting units | 220.7 | 0.0 |
| Shooting | War machine shots | 23.3 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (45 of 70) | 64% (7 of 11) |
| Shooting | Points destroyed by war machines | 222.0 | 110.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 1.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 102.3 | 60.0 |
| Combat | Points run down | 26.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +43 | +60 |
| Combat | Net per 100 charger points, damage counted | +48.9 | +21.8 |
| Combat | First round won (charged fights) | 57% | 100% |
| Combat | Net points per charged fight | +38 | +60 |
| Combat | Net points per supported fight / lone fight | +0 / +53 | - / +60 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 7 | 0 of 1 |
| Game | Points lost | 170.0 | 535.3 |
| Game | VP from objectives | 640.0 | 566.7 |
| Game | Lone holders (player turns) | 0.0 | 5.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +514 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 705
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnsr-c940641-p40

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.0 | +65.3 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 8.0 | +155.3 | 0.0 | 20.0 | 17.7 | +312.7 | 0.0 | 290.3 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 33.3 | - | - | - | - |
| CANNON PLAN MISSED | 2.0 | +0.0 | 311.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 22.7 | +401.2 | 2404.0 | 40.0 | 3.7 | +128.5 | 153.3 | 0.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +58.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.7 | -191.9 | 0.0 | 96.7 | 26.7 | -1502.1 | 0.0 | 1378.3 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 45.7 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 341.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 45.7 | 0.0 | - | - | - | - |
| COVER ONCE | 8.3 | -686.6 | 0.0 | 0.0 | 5.7 | -350.2 | 0.0 | 202.7 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EXACT ROUND | 3.3 | +51.9 | 91.3 | 0.0 | 0.3 | -1.6 | 20.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +9.5 | 91.3 | 0.0 | 0.3 | +0.0 | 20.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 17.3 | +353.2 | 0.0 | 724.0 |
| FEATURE BUFFS | 1.3 | +32.0 | 0.0 | 0.0 | 0.7 | +8.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | -2.7 | 26.7 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.0 | +0.0 | 26.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 133.7 | +4542.9 | 5954.7 | 263.3 | 72.7 | +2362.9 | 250.0 | 1946.3 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 45.7 |
| FOLLOW UP WEIGHED | 0.7 | +12.3 | 0.0 | 0.0 | 0.3 | +66.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.7 | +58.9 | 118.0 | 0.0 | 0.3 | +29.6 | 20.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 193.7 |
| FRIEND SHOOTS FIRST | 1.0 | -48.4 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.7 | +15.7 | 0.0 | 0.0 |
| GOAL WALK | 2.3 | +66.9 | 0.0 | 0.0 | 14.0 | +949.1 | 0.0 | 184.3 |
| GUN FIGURES | 0.7 | +0.0 | 163.0 | 38.3 | - | - | - | - |
| GUN MASK | 2.3 | +25.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 193.7 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 20.0 | 13.3 | +0.0 | 0.0 | 984.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +2.8 | 20.0 | 0.0 |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 40.0 | 16.0 | +0.0 | 0.0 | 330.3 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 516.7 |
| HIS MOVE AND SHOT | - | - | - | - | 3.3 | -32.3 | 0.0 | 53.3 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 96.7 | - | - | - | - |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 516.7 |
| HIS RANDOM MOVE | 19.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 35.0 | +1053.0 | 0.0 | 183.3 | 58.7 | +5250.6 | 0.0 | 1499.0 |
| HIS SHOTS BY HIS RUN | 19.0 | +279.3 | 0.0 | 96.7 | 49.7 | +1553.6 | 0.0 | 1702.7 |
| HIS TURN DENIED | 0.7 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 165.3 |
| HOLDER ASSIGNMENT | 10.0 | +1276.8 | 0.0 | 0.0 | 9.0 | +898.8 | 0.0 | 109.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -16.7 | 118.0 | 0.0 | 0.3 | -27.5 | 20.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +9.5 | 0.0 | 163.0 |
| IDLE COST | - | - | - | - | 16.0 | -292.7 | 0.0 | 568.0 |
| JOINT CHARGE NOW | 1.7 | +23.9 | 91.3 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 56.7 | 40.0 | 4.0 | +0.0 | 20.0 | 205.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 3.3 | +6.7 | 118.0 | 0.0 | 0.3 | +2.6 | 20.0 | 0.0 |
| MANOEUVRE | 0.3 | -1.0 | 0.0 | 0.0 | 2.0 | +10.7 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +40.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +22.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.7 | +1.8 | 0.0 | 20.0 | 2.0 | +33.9 | 0.0 | 189.7 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +4.5 | 0.0 | 0.0 |
| MODEL FACING | 3.0 | +887.9 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 157.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +209.9 | 0.0 | 0.0 | 1.3 | +37.2 | 0.0 | 157.0 |
| NEARER NOT NEEDED | 5.3 | +230.6 | 0.0 | 0.0 | 3.7 | +158.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.0 | +107.9 | 0.0 | 0.0 | 0.7 | +35.7 | 0.0 | 157.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -5.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -55.0 | 118.0 | 0.0 | 0.3 | -2.3 | 20.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -113.8 | 0.0 | 20.0 | 3.3 | -116.0 | 0.0 | 26.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -54.4 | 0.0 | 0.0 | 4.3 | -96.8 | 0.0 | 582.0 |
| ONE JOINT FIGURE | 0.7 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.0 | -8.3 | 0.0 | 0.0 | 4.0 | -205.2 | 0.0 | 82.7 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +3.9 | 26.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.7 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 61.3 | +2965.0 | 1824.0 | 263.3 | 34.3 | +81.0 | 38.3 | 845.0 |
| PROMISE BY ITS OWN SUM | 11.7 | -219.7 | 0.0 | 0.0 | 2.7 | -19.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 13.3 | +897.9 | 0.0 | 116.7 | 6.7 | +611.4 | 96.7 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +37.7 | 0.0 | 113.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | -26.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.7 | +192.7 | 0.0 | 80.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +6.1 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.3 | -100.2 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +26.7 | 0.0 | 53.3 |
| RISK BY ARC | 2.7 | +112.4 | 118.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -5.9 | 20.0 | 0.0 |
| RUN DOWN | 3.7 | -22.6 | 118.0 | 0.0 | 0.3 | -0.6 | 20.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -35.1 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 2.0 | +117.2 | 0.0 | 326.0 |
| SET UP BY THE SET | 0.7 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +0.5 | 0.0 | 20.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 31.7 | +0.0 | 0.0 | 40.0 | 5.0 | +0.0 | 0.0 | 189.7 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +9.2 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 163.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT RISK POINTS | 12.7 | +466.5 | 0.0 | 183.3 | 39.7 | -1110.8 | 0.0 | 1584.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 38.7 | +1375.0 | 0.0 | 98.3 | 8.0 | +340.9 | 0.0 | 469.7 |
| SPELL WORTH | - | - | - | - | 1.0 | +18.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 363.0 |
| STAND AND SHOOT | 0.3 | -0.6 | 26.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 216.3 |
| STANDS STILL | 100.7 | +0.0 | 5836.7 | 223.3 | 21.0 | +0.0 | 230.0 | 584.0 |
| STAY WORTH | 73.0 | -193.0 | 4950.7 | 118.3 | 10.7 | +289.2 | 153.3 | 189.7 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.3 | +165.0 | 0.0 | 40.0 | 3.7 | +95.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.3 | +165.0 | 0.0 | 40.0 | 3.7 | +95.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 1.0 | +3.6 | 0.0 | 40.3 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 13.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 2.0 | +0.0 | 0.0 | 163.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 61.7 | +0.0 | 0.0 | 60.0 | 33.7 | +0.0 | 0.0 | 893.7 |
| TIED UP BY THE SUM | 0.7 | +15.8 | 45.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 54.7 | +607.5 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 1.7 | -11.7 | 26.7 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +3.0 | 0.0 | 0.0 | 0.3 | +14.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -78.6 | 0.0 | 0.0 | 2.3 | -296.9 | 0.0 | 520.0 |
| WHOLE FIGHT GAIN | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.7 | +20.9 | 0.0 | 0.0 | 8.3 | +721.6 | 0.0 | 0.0 |

### Rule changes: cnsr-c940641-p40

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 281 | 269 | 80 | 26.67 | +1852 | +23.2 |
| HOLDER ASSIGNMENT | 57 | 57 | 54 | 18.00 | +4127 | +76.4 |
| ARMY TABLE | 77 | 77 | 46 | 15.33 | +1258 | +27.3 |
| HIS SHOTS BY HIS RUN | 206 | 200 | 44 | 14.67 | +896 | +20.4 |
| SHOT RISK POINTS | 157 | 152 | 43 | 14.33 | +2717 | +63.2 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -689 | -25.5 |
| TIME ON OUR SIDE | 164 | 144 | 26 | 8.67 | +163 | +6.3 |
| PROMISE BY ITS OWN SUM | 43 | 43 | 23 | 7.67 | -718 | -31.2 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| FIVE ACTION | 619 | 605 | 19 | 6.33 | +294 | +15.5 |
| HARD STAY DROPPED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 79 | 79 | 14 | 4.67 | -31 | -2.2 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 23 | 19 | 13 | 4.33 | +134 | +10.3 |
| THE RISK READS HIS RUN | 18 | 18 | 13 | 4.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 100 | 100 | 9 | 3.00 | +363 | +40.3 |
| MODEL FACING | 9 | 9 | 9 | 3.00 | +2664 | +296.0 |
| CHAFF IN THE MOVE | 9 | 9 | 8 | 2.67 | +33 | +4.1 |
| SUPPORT ADDS | 24 | 23 | 8 | 2.67 | +202 | +25.3 |
| SUPPORT WORKED OUT | 24 | 23 | 8 | 2.67 | +202 | +25.3 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 7 | 2.33 | +113 | +16.1 |
| WOUNDS ON THE RANKS | 27 | 27 | 7 | 2.33 | +123 | +17.5 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| NEXT CHARGE BY LIST | 11 | 9 | 6 | 2.00 | +103 | +17.2 |
| SEARCH SPOT | 6 | 6 | 6 | 2.00 | +352 | +58.6 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 42 | 32 | 5 | 1.67 | +58 | +11.6 |
| EXACT ROUND | 11 | 11 | 5 | 1.67 | +82 | +16.4 |
| GOAL WALK | 49 | 49 | 5 | 1.67 | +164 | +32.9 |
| IDLE COST | 48 | 40 | 5 | 1.67 | +100 | +19.9 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +72 | +14.4 |
| RISK BY ARC | 8 | 8 | 5 | 1.67 | +68 | +13.6 |
| SHOTS AFTER THE MOVES | 25 | 25 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 140 | 116 | 5 | 1.67 | +132 | +26.5 |
| ARTILLERY RE-ROLL WEIGHED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOUR ROUNDS | 12 | 12 | 4 | 1.33 | +58 | +14.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| STAY WORTH | 251 | 236 | 4 | 1.33 | +78 | +19.6 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +196 | +65.3 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +236 | +78.8 |
| QUARTER ODDS | 60 | 60 | 3 | 1.00 | +68 | +22.7 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +80 | +26.7 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 3 | 1.00 | +7 | +2.5 |
| SWIFTSTRIDE BY POINTS | 3 | 3 | 3 | 1.00 | +11 | +3.6 |
| WEAPON BY POINTS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +47 | +23.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 7 | 7 | 2 | 0.67 | +32 | +16.1 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +96 | +47.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +16 | +8.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +18 | +9.1 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -28 | -28.1 |
| FALLS SHORT | 52 | 41 | 1 | 0.33 | +37 | +36.6 |
| GUN MASK | 7 | 6 | 1 | 0.33 | +27 | +26.8 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| LOST AFTER ESCAPE | 11 | 11 | 1 | 0.33 | +1 | +0.9 |
| MAX FOR POSITIONING | 8 | 7 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 27 | 26 | 1 | 0.33 | +6 | +6.5 |
| NEXT OBJECTIVE NEARER | 1 | 1 | 1 | 0.33 | +87 | +86.7 |
| ONE FIGHT FORMULA | 28 | 23 | 1 | 0.33 | +13 | +13.0 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +3 | +2.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +50 | +50.0 |
| SET UP BY THE SET | 2 | 2 | 1 | 0.33 | +8 | +8.2 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -18 | -18.4 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 13 | 13 | 1 | 0.33 | +2 | +2.4 |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 46 | 46 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 27 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 23 | 20 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 52 | 52 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 64 | 59 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 15 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 10 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 26 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 57 | 54 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 90 | 90 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 10 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 24 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 287 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 110 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 24 | 13 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 365 | 359 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 286 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p40

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.00 | 28.1 |
| PROMISE BY ITS OWN SUM | rule | 6.67 | 1.00 | 31.2 |
| ARMY TABLE | rule | 1.00 | 2.00 | 13.7 |
| CANNON PLANNED TARGET | rule | 1.00 | - | 10.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 17.8 |
| JOINT CHARGE NOW | rule | 0.67 | - | 6.3 |
| CHARGE NOW FIRST | rule | 0.33 | - | 28.1 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| FIGHT ORDER BAND | gate | 0.33 | - | 4.7 |
| RULE SWITCHED OFF | gate | - | 0.33 | 2.7 |
| SUPPORT NARROWED | rule | 0.33 | - | 18.4 |

### Plans: cnsr-c940641-p40

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 62% | 149 | 131 | 88% |
| Mine | join | 2.7 | 100% | 75 | 0 | 0% |
| Mine | move | 31.0 | 98% | 1032 | 0 | 0% |
| Mine | shoot | 25.0 | 75% | 815 | 2834 | 348% |
| Opponent | move | 30.0 | 92% | 1019 | 0 | 0% |
| Opponent | shoot | 3.3 | 30% | 270 | 81 | 30% |
| Opponent | support | 1.0 | 100% | 3 | 0 | 0% |

### Battle groups: cnsr-c940641-p40

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.7 | 38% | 100% | 0% | - | 33% | 0% | 0% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p40

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 0 (13) | 0 | 0 | 0 | 54% | 2.8 | 0 (3) | 0 (7) | 0 (3) | 0 (9) | 0 (4) |
| Mine | Clean-up | 3 | 43 (3) | 43 | 0 | 0 | 33% | 1.0 | 0 (1) | 0 (1) | 267 (1) | 133 (2) | 0 (1) |
| Mine | Hammer | 6 | 69 (6) | 28 | 41 | 0 | 67% | 3.0 | - | 103 (4) | 0 (2) | 95 (5) | 0 (1) |
| Mine | Shooter | 10 | 72 (10) | 12 | 60 | 4 | 10% | 2.1 | - | 117 (4) | 24 (6) | 108 (5) | 27 (5) |
| Mine | War machine | 17 | 67 (17) | 67 | 0 | 26 | 12% | 1.5 | 72 (9) | 0 (2) | 83 (6) | 0 (3) | 81 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 77 | 60% | 2.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 2 (8) | 2 | 0 | 44 | 62% | 3.7 | 0 (3) | 0 (1) | 6 (3) | 4 (5) | 0 (2) |
| Opponent | Clean-up | 3 | 44 (3) | 0 | 44 | 0 | 67% | 6.0 | 54 (1) | 34 (2) | - | 44 (3) | - |
| Opponent | Fast Hammer | 4 | 44 (4) | 0 | 44 | 12 | 50% | 2.5 | - | 79 (3) | 0 (1) | 101 (2) | 0 (2) |
| Opponent | Hammer | 3 | 30 (3) | 30 | 0 | 42 | 33% | 4.0 | 0 (1) | 35 (2) | - | 30 (3) | - |
| Opponent | Holder | 2 | 160 (2) | 0 | 160 | 44 | 0% | 4.0 | - | 160 (2) | - | 160 (2) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 2 | 165 (2) | 165 | 0 | 0 | 0% | 1.0 | - | - | 165 (2) | - | 165 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: cnsr-c940641-p40

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 443 | 129 | 2.3 | 1.3 | 55 | 17 | +38 | 0 of 7 | 4 of 7 | +0 | +53 |
| Opponent | Kingdom of Bretonnia | 1 | 330 | 60 | 1.0 | 1.0 | 60 | 0 | +60 | 0 of 1 | 1 of 1 | - | +60 |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 110 | 20 | 0.3 | 1.0 | 60 | 0 | +60 | 0 of 1 | 1 of 1 | - | +60 |

### Effective charges: cnsr-c940641-p40

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 0 | 1 (net +80) | 2 (net +94) | 0 | 4 (net +0) | 0 | 14% (1 of 7) |
| Opponent | Kingdom of Bretonnia | 1 | 1 (net +60) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p40

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 60 | 80 | +80 | 80 | 0 | +80 | +133.3 |
| Mine | 76-89% | 2 | 55 | 136 | +94 | 220 | 90 | +130 | +236.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 110 | 130 | +0 | 30 | 40 | -10 | -9.5 |
| Mine | All fights | 7 | 87 | 125 | +38 | 91 | 49 | +43 | +48.9 |
| Opponent | Long shot (under 50%) | 1 | 275 | 60 | +60 | 60 | 0 | +60 | +21.8 |
| Opponent | All fights | 1 | 275 | 60 | +60 | 60 | 0 | +60 | +21.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p40 | move | 20 | 1 (5%) | 1 (5%) | 3 (15%) | 16 (80%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

# Doctrine scorecard: cnsr-c940641-p12

### Scorecard: cnsr-c940641-p12

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | no | - | 5 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 9 | 3 | 0 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 6 | 2 | 5 | 0 | 0 | 0 | 115 |
| **Average** | | | Mine | 0% | 4.5 | 3.3 | 4.0 | 2.0 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 33% | 2.5 | 3.3 | 3.7 | 2.7 | 0.3 | 0.0 | 0.0 | 95.0 |

### KPIs: cnsr-c940641-p12

Rules off - Mine only: NO SECOND RUN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 17) | 0% (0 of 34) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 86% (6 of 7); on the table 86% | 80% (8 of 10); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 0% | - | 0% (0 of 2); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 43% (3 of 7); on the table 43% | 86% (6 of 7); on the table 86% | 64% (9 of 14); on the table 64% |
| Magic missiles tried each own turn | 50%+ | 83% (5 of 6) | 33% (2 of 6) | 58% (7 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (5 of 5) | 33% (2 of 6) | 64% (7 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 83% (5 of 6) | 57% (4 of 7) | 69% (9 of 13) |
| Points that never fought | lower | 39% (2327 of 5998) | 36% (2147 of 5998) | 37% (4474 of 11996) |
|   infantry points that never fought | lower | 78% (701 of 902) | 58% (624 of 1072) | 67% (1325 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (12 of 19) | 62% (16 of 26) | 62% (28 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (1 of 1); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (2883 of 5038) | 58% (3083 of 5360) | 57% (5966 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (50%) | 0.7 (40%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.7 (50%) | 0.7 (40%) |
| GONE: slain | 0.3 (100%) | 0.0 (0%) | 0.3 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 2.0 | 2.0 | 2.3 | 0.7 | 1.0 |
| not cast | 4.3 | 0.0 | 2.0 | 1.7 | 1.3 | 23.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | - | 0.3 (17%) | 0.3 (20%) | 0.3 (25%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 1.0 (75%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (100%) | - | 1.3 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 67% (4 of 6) | - | 67% (4 of 6) |
| the unit moved after it | 100% (4 of 4) | - | 100% (4 of 4) |
| it charged on its next turn | 25% (1 of 4) | - | 25% (1 of 4) |
| the enemy charged it first | 25% (1 of 4) | - | 25% (1 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 50% (2 of 4) | - | 50% (2 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 29% (2 of 7) | 66% (25 of 38) | 60% (27 of 45) |
|   cavalry | 50% (2 of 4) | 80% (8 of 10) | 71% (10 of 14) |
|   character | 0% (0 of 3) | 50% (8 of 16) | 42% (8 of 19) |
|   infantry | - | 75% (9 of 12) | 75% (9 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (20%) | 1.7 (38%) | 2.0 (33%) |
| CHARGED: it charged | 0.3 (20%) | 2.0 (46%) | 2.3 (39%) |
| NO TARGET IN RANGE | 1.0 (60%) | 0.3 (8%) | 1.3 (22%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (8%) | 0.3 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.0 | 83% | 1.3 pts | 8 pts |
| character | 2.7 | 0.3 | 88% | 6.9 pts | 18 pts |
| infantry | 5.0 | 0.7 | 87% | 7.3 pts | 37 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.0 | 4.7 |
| Charges that made contact a game | 3.0 | 4.3 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.75 declared, 0.50 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.42 declared, 0.29 contact (24 units) | 0.58 declared, 0.50 contact (26 units) | 0.50 declared, 0.40 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 100% (5 of 5) | 0% (0 of 1) | 69% (9 of 13) |
| Character in a unit | 100% (3 of 3) | 0% (0 of 1) | 100% (1 of 1) | 80% (4 of 5) |
| Character on its own | 50% (2 of 4) | 50% (1 of 2) | 43% (3 of 7) | 46% (6 of 13) |
| Infantry | 57% (4 of 7) | 0% (0 of 1) | - | 50% (4 of 8) |
| Monster | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 25% (1 of 4); on the table 25% | 83% (5 of 6) | 31% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 80% (8 of 10); on the table 80% | 33% (2 of 6) | 44% | 60% (15 of 25) | 100% (1 of 1); 1.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 31% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cnsr-c940641-p12, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 36% (4) | 75% (6) | 53% (10) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnsr-c940641-p12

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (6 of 12) | 62% (8 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 100% (1 of 1) | 38% (5 of 13) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 4) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 89% (8 of 9) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.0 | 2.7 |
| Movement | Points that never moved of their own | 56.7 | 95.0 |
| Movement | Fights charged into per game | 3.0 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 8, net -256 | 0 of 10 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 8, net +0 | 3 of 10, net +62 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 8, net +0 | 1 of 10, net +30 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 8, net +26 | 2 of 10, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.7 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 5) | 67% (18 of 27) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 100% (1 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.3 / 0.7 | 0.0 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 95.0 | 520.3 |
| Combat | Points run down | 9.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -9 | +51 |
| Combat | Net per 100 charger points, damage counted | -4.1 | +14.2 |
| Combat | First round won (charged fights) | 56% | 75% |
| Combat | Net points per charged fight | -60 | +62 |
| Combat | Net points per supported fight / lone fight | - / -60 | +0 / +68 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 9 | 5 of 12 |
| Game | Points lost | 470.3 | 231.7 |
| Game | VP from objectives | 670.0 | 500.0 |
| Game | Lone holders (player turns) | 4.5 | 2.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -59 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 702
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: cnsr-c940641-p12

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +116.3 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +21.9 | 0.0 | 0.0 |
| ARMY TABLE | 19.3 | +153.5 | 0.0 | 119.0 | 18.7 | -24.6 | 0.0 | 68.3 |
| ASSAILMENT BY POINTS | 0.7 | +2.3 | 0.0 | 70.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.7 | -92.4 | 56.7 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 3.3 | +22.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 70.3 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 5.0 | +169.8 | 0.0 | 50.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 1.0 | -0.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +13.0 | 0.0 | 0.0 | 0.7 | +25.9 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.0 | -417.9 | 0.0 | 143.3 | 9.7 | -575.4 | 0.0 | 65.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 32.7 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 1.7 | +0.0 | 32.7 | 0.0 | 1.7 | +0.0 | 132.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 21.0 | +0.0 | 0.0 | 304.7 | 12.3 | +0.0 | 0.0 | 109.3 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 25.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.7 | +113.3 | 70.3 | 140.7 | - | - | - | - |
| COVER ONCE | 9.7 | -829.7 | 0.0 | 230.3 | 12.3 | -599.0 | 0.0 | 32.7 |
| DENIED BY THE FIGHT | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 0.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -115.4 | 143.3 | 0.0 |
| EXACT ROUND | 3.0 | -4.2 | 41.7 | 77.0 | 4.3 | +49.3 | 319.0 | 0.0 |
| FALL BACK GOOD ORDER | 4.0 | +18.0 | 41.7 | 111.7 | 3.7 | +0.0 | 383.7 | 0.0 |
| FALLS SHORT | 21.7 | +337.9 | 0.0 | 307.3 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 1.7 | +26.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 2.0 | +63.7 | 0.0 | 77.0 | 1.0 | +68.6 | 0.0 | 0.0 |
| FIVE ACTION | 83.7 | +4262.4 | 41.7 | 896.7 | 95.0 | +4540.0 | 462.3 | 296.7 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 146.0 | 12.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +17.8 | 0.0 | 0.0 | 2.0 | +407.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.3 | +487.4 | 41.7 | 111.7 | 5.0 | +455.2 | 462.3 | 0.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 70.3 | 10.0 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -17.1 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.0 | -3.9 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.3 | -22.0 | 33.3 | 0.0 |
| GIVES UP ITS SCREEN | 0.3 | -0.5 | 0.0 | 15.0 | - | - | - | - |
| GOAL WALK | 9.0 | +679.0 | 0.0 | 0.0 | 11.0 | +926.6 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 70.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 1.0 | +0.0 | 143.3 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 143.3 | 5.7 | +0.0 | 0.0 | 65.3 |
| HIS CHARGE DENIED | 0.3 | +2.0 | 0.0 | 0.0 | 1.0 | +60.6 | 78.7 | 0.0 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -17.7 | 0.0 | 0.0 | 0.7 | -2.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 10.0 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 10.7 | +0.0 | 0.0 | 131.3 | 28.7 | +0.0 | 0.0 | 157.0 |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 37.0 | +493.2 | 0.0 | 313.3 | 12.0 | +60.7 | 0.0 | 71.3 |
| HIS SHOTS BY HIS RUN | 38.3 | +442.8 | 0.0 | 425.0 | 10.7 | +44.3 | 0.0 | 0.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +2.0 | 70.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.0 | +0.0 | 0.0 | 286.7 | 17.7 | +0.0 | 0.0 | 202.0 |
| HOLDER ASSIGNMENT | 11.7 | +1034.3 | 0.0 | 143.3 | 10.0 | +993.0 | 0.0 | 101.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -170.7 | 41.7 | 111.7 | 3.7 | -165.6 | 319.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +26.9 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +70.3 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +72.8 | 70.3 | 0.0 |
| IDLE COST | 22.3 | -331.2 | 0.0 | 99.0 | - | - | - | - |
| JOINT CHARGE NOW | 0.3 | -1.3 | 0.0 | 0.0 | 0.7 | +74.7 | 286.7 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 286.7 | 0.7 | +0.0 | 0.0 | 65.3 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 13.3 | +0.0 | 149.0 | 336.7 | 9.0 | +0.0 | 254.0 | 107.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 3.0 | +8.4 | 32.7 | 93.7 | 2.0 | -4.2 | 348.7 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +7.4 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +24.6 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +18.4 | 0.0 | 70.3 | 1.0 | +41.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -29.8 | 0.0 | 70.3 | 0.7 | -15.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.3 |
| MAX FOR POSITIONING | 1.3 | +68.0 | 0.0 | 18.0 | 3.0 | +51.6 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +39.5 | 0.0 | 140.7 | 2.3 | +30.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +20.0 | 0.0 | 140.7 | 3.3 | +40.8 | 0.0 | 0.0 |
| MOVE ORDER | 4.0 | +0.0 | 59.0 | 160.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.7 | +606.3 | 0.0 | 0.0 | 9.3 | +754.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +389.0 | 0.0 | 0.0 | 6.7 | +293.7 | 0.0 | 35.7 |
| NEXT CHARGE BY LIST | 7.7 | +571.2 | 0.0 | 0.0 | 9.0 | +691.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.7 | -178.0 | 41.7 | 77.0 | 4.0 | -262.3 | 319.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.3 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.7 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.0 | -107.9 | 0.0 | 119.3 | 5.0 | -287.1 | 16.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.0 | -72.5 | 0.0 | 70.3 | 6.7 | -157.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +12.4 | 143.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.7 | +10.1 | 0.0 | 0.0 | 4.7 | +9.8 | 0.0 | 32.7 |
| ONE PROMISE A TARGET | 0.7 | -39.1 | 0.0 | 0.0 | 0.7 | -5.1 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.3 |
| OPENS UP | 0.3 | +16.9 | 9.0 | 0.0 | 0.3 | +38.0 | 10.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +1.2 | 0.0 | 77.0 | 0.3 | +1.6 | 0.0 | 0.0 |
| PATHS CROSS | 1.3 | +21.6 | 0.0 | 0.0 | 0.3 | +37.4 | 0.0 | 35.7 |
| PIVOT GUARDS FLANK | 0.3 | -2.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 45.3 | +121.9 | 0.0 | 843.7 | 44.0 | +345.8 | 87.0 | 198.7 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -160.3 | 0.0 | 0.0 | 11.7 | -458.6 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | -0.6 | 0.0 | 0.0 | 3.7 | -1.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 2.0 | -3.9 | 0.0 | 0.0 |
| QUARTER ODDS | 5.7 | +458.7 | 0.0 | 70.3 | 9.0 | +736.9 | 70.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +125.4 | 0.0 | 0.0 | 2.3 | +2.8 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.3 |
| REDIRECT BY WHAT IT STOPS | 1.7 | +84.3 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.7 | +236.9 | 0.0 | 25.0 | 2.3 | +132.4 | 0.0 | 9.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +28.7 | 0.0 | 25.0 | 1.7 | +0.0 | 0.0 | 9.0 |
| REDIRECT WEIGHED | 0.3 | -25.9 | 56.7 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.3 | -8.5 | 0.0 | 0.0 | 2.3 | -93.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +36.3 | 0.0 | 49.0 | - | - | - | - |
| RISK BY ARC | 3.7 | +124.6 | 41.7 | 77.0 | 4.0 | +201.4 | 452.3 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -39.5 | 32.7 | 0.0 | 0.7 | -22.1 | 10.0 | 0.0 |
| RUN DOWN | 3.0 | -65.3 | 32.7 | 93.7 | 1.0 | -4.6 | 10.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 3.3 | -183.0 | 0.0 | 50.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +50.1 | 0.0 | 0.0 | 1.0 | +31.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +91.4 | 16.7 | 0.0 |
| SET CREDITED ONCE | 1.7 | -29.3 | 0.0 | 0.0 | 3.3 | -32.0 | 0.0 | 18.0 |
| SET UP BY THE SET | 3.0 | -5.9 | 0.0 | 0.0 | 4.3 | +21.6 | 0.0 | 18.0 |
| SET UP TOGETHER | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.7 | +86.1 | 0.0 | 70.3 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.7 | -3.6 | 0.0 | 20.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 15.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -0.9 | 0.0 | 0.0 |
| SHOT RISK POINTS | 14.0 | -129.5 | 0.0 | 221.0 | 3.7 | -29.7 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.3 | +29.3 | 0.0 | 0.0 | 8.3 | +57.7 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.7 | +86.1 | 0.0 | 70.3 | - | - | - | - |
| SPELL WORTH | 1.3 | +14.8 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -1.6 | 70.3 | 0.0 |
| SPOT AS THE GAME MOVES | 11.3 | +0.0 | 0.0 | 308.0 | 10.0 | +0.0 | 0.0 | 80.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 13.7 | +0.0 | 0.0 | 189.7 | 45.0 | +0.0 | 0.0 | 0.0 |
| STAY WORTH | - | - | - | - | 12.7 | +85.6 | 0.0 | 35.7 |
| STOPS | - | - | - | - | 0.3 | +1.3 | 70.3 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +4.0 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 6.3 | +861.2 | 0.0 | 89.3 | 5.3 | +406.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 32.7 | 0.0 | 0.7 | +0.0 | 132.3 | 0.0 |
| SUPPORT WORKED OUT | 6.3 | +861.2 | 0.0 | 89.3 | 5.3 | +406.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +2.6 | 0.0 | 32.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 35.7 |
| THE PROMISE ADDS | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 70.3 | 3.3 | +0.0 | 0.0 | 71.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 49.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 442.7 | 44.3 | +0.0 | 0.0 | 148.3 |
| TIED UP BY THE SUM | 1.3 | +161.7 | 9.0 | 15.0 | 0.7 | +129.9 | 16.7 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 73.0 | +662.0 | 0.0 | 175.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.3 | -29.2 | 0.0 | 69.3 | - | - | - | - |
| WHO FIGHTS | 1.3 | +43.7 | 0.0 | 62.0 | 1.0 | -22.1 | 205.3 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.7 | +74.7 | 286.7 | 0.0 |
| WHO HITS BACK | 1.0 | +153.0 | 0.0 | 62.0 | - | - | - | - |
| WHOLE FIGHT | 0.7 | +26.5 | 0.0 | 34.7 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -258.2 | 0.0 | 143.3 | 6.7 | -539.7 | 0.0 | 65.3 |
| WHOLE FIGHT GAIN | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: cnsr-c940641-p12

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 114 | 114 | 81 | 27.00 | +937 | +11.6 |
| LEGAL CHARGES ONLY | 67 | 67 | 67 | 22.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 65 | 65 | 60 | 20.00 | +3671 | +61.2 |
| FIVE ACTION | 536 | 513 | 43 | 14.33 | +2516 | +58.5 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 219 | 176 | 25 | 8.33 | +22 | +0.9 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -1184 | -49.3 |
| MOVE TO CHARGE COMPUTED | 54 | 46 | 23 | 7.67 | +1154 | +50.2 |
| NEXT CHARGE BY LIST | 50 | 44 | 22 | 7.33 | +989 | +44.9 |
| GOAL WALK | 60 | 59 | 20 | 6.67 | +1158 | +57.9 |
| HIS SHOT LIST | 147 | 142 | 19 | 6.33 | +180 | +9.5 |
| PROMISE BY ITS OWN SUM | 61 | 61 | 19 | 6.33 | -1857 | -97.7 |
| HIS SHOTS BY HIS RUN | 147 | 142 | 18 | 6.00 | +54 | +3.0 |
| FOUR ROUNDS | 28 | 26 | 17 | 5.67 | +1053 | +61.9 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| IDLE COST | 67 | 49 | 13 | 4.33 | +81 | +6.2 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 13 | 4.33 | +0 | +0.0 |
| SUPPORT ADDS | 35 | 33 | 12 | 4.00 | +280 | +23.3 |
| SUPPORT WORKED OUT | 35 | 33 | 12 | 4.00 | +280 | +23.3 |
| WHOLE FIGHT DANGER | 28 | 26 | 12 | 4.00 | +196 | +16.3 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 15 | 15 | 10 | 3.33 | +0 | +0.0 |
| SHOT RISK POINTS | 53 | 49 | 10 | 3.33 | +81 | +8.1 |
| COVER ONCE | 66 | 43 | 9 | 3.00 | +104 | +11.6 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +1275 | +141.7 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 9 | 3.00 | +385 | +42.8 |
| RISK BY ARC | 23 | 21 | 9 | 3.00 | +273 | +30.4 |
| THE RISK READS HIS RUN | 18 | 18 | 9 | 3.00 | +0 | +0.0 |
| QUARTER ODDS | 44 | 44 | 8 | 2.67 | +309 | +38.6 |
| FALLS SHORT | 65 | 55 | 7 | 2.33 | +46 | +6.6 |
| SET UP BY THE SET | 22 | 21 | 7 | 2.33 | +328 | +46.9 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 38 | 28 | 6 | 2.00 | +168 | +28.0 |
| CAST JOB | 10 | 10 | 5 | 1.67 | +12 | +2.5 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +117 | +23.4 |
| CHARGE LOSSES | 65 | 61 | 5 | 1.67 | +127 | +25.4 |
| EXACT ROUND | 22 | 20 | 5 | 1.67 | +40 | +7.9 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| MAX FOR POSITIONING | 13 | 12 | 5 | 1.67 | +0 | +0.0 |
| PATHS CROSS | 5 | 5 | 5 | 1.67 | +177 | +35.4 |
| SEARCH SPOT | 7 | 7 | 5 | 1.67 | +244 | +48.7 |
| SHOTS IN THE MOVE | 29 | 18 | 5 | 1.67 | +55 | +11.1 |
| TIED UP BY THE SUM | 6 | 5 | 5 | 1.67 | +116 | +23.2 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -178 | -44.5 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -133 | -33.2 |
| SUPPORT NARROWED | 5 | 5 | 4 | 1.33 | -252 | -63.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -1 | -0.3 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +220 | +73.5 |
| PROMISE KNOWS THE FIGHT | 16 | 14 | 3 | 1.00 | -5 | -1.7 |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 3 | 1.00 | +72 | +24.1 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +444 | +148.1 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +372 | +186.2 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +7 | +3.5 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -308 | -154.0 |
| CHARGE NOW FIRST | 10 | 10 | 2 | 0.67 | -59 | -29.6 |
| FALL BACK GOOD ORDER | 23 | 22 | 2 | 0.67 | +0 | +0.0 |
| LOST AFTER ESCAPE | 15 | 15 | 2 | 0.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 45 | 44 | 2 | 0.67 | +74 | +37.1 |
| ONE OBJECTIVE FORMULA | 34 | 32 | 2 | 0.67 | +90 | +44.8 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +24 | +11.9 |
| REDIRECT COUNTER | 18 | 15 | 2 | 0.67 | +47 | +23.6 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +274 | +137.1 |
| THE ROW IN ITS ORDER | 20 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO FIGHTS | 7 | 7 | 2 | 0.67 | +92 | +45.9 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +224 | +112.1 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +66 | +65.7 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -79 | -79.1 |
| FEATURE BUFFS | 5 | 5 | 1 | 0.33 | +21 | +20.7 |
| FIGHT TO THE END | 9 | 9 | 1 | 0.33 | +27 | +26.7 |
| HIS CHARGE DENIED | 4 | 3 | 1 | 0.33 | +29 | +29.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +19 | +19.1 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +22 | +22.3 |
| NEXT OBJECTIVE NEARER | 1 | 1 | 1 | 0.33 | +36 | +36.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -6 | -6.5 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -109 | -108.6 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -6 | -5.6 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +109 | +108.8 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +12 | +12.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.7 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.33 | +29 | +29.2 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 100 | 98 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 61 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 35 | 35 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 32 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 39 | 37 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 10 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 4 | 4 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 56 | 53 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 118 | 109 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 12 | 11 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 110 | 110 | 0 | 0.00 | - | - |
| HONEST WORTH | 24 | 23 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 12 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 15 | 8 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 23 | 22 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 35 | 13 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 268 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 6 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 9 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 15 | 14 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 18 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 64 | 60 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 176 | 164 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 266 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 7 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnsr-c940641-p12

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 4.33 | 52.6 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 4.33 | 97.7 |
| ARMY TABLE | rule | 1.67 | 2.67 | 60.0 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.67 | 33.2 |
| SUPPORT NARROWED | rule | 1.00 | 0.33 | 63.0 |
| MARCH OF THE TABLE | rule | 0.33 | 0.67 | 59.4 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.67 | 1.7 |
| BEST PRIZE | rule | 0.67 | - | 154.0 |
| CHARGE NOW FIRST | rule | 0.67 | - | 29.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 21.9 |
| NO REASON | gate | - | 0.67 | 60.4 |
| RULE SWITCHED OFF | gate | 0.67 | - | 5.3 |
| CHAFF PASSED | rule | - | 0.33 | 0.7 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 79.1 |
| JOINT CHARGE NOW | rule | 0.33 | - | 3.8 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 6.5 |
| REDIRECT WEIGHED | rule | 0.33 | - | 108.6 |
| REFUSING RETIRES | rule | - | 0.33 | 5.6 |

### Plans: cnsr-c940641-p12

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 56% | 308 | 122 | 40% |
| Mine | join | 4.3 | 92% | 172 | 0 | 0% |
| Mine | move | 36.0 | 98% | 1575 | 0 | 0% |
| Mine | support | 2.0 | 100% | 58 | 0 | 0% |
| Opponent | charge | 3.3 | 50% | 485 | 291 | 60% |
| Opponent | join | 1.3 | 100% | 124 | 0 | 0% |
| Opponent | move | 36.0 | 96% | 1769 | 0 | 0% |
| Opponent | shoot | 3.3 | 30% | 105 | 55 | 52% |

### Packages: hunt the guns, cnsr-c940641-p12

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 218 | 211 | 100% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 218 | 211 | 100% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: cnsr-c940641-p12

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 36% | 50% | 50% | 50% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 14% | 0% | 0% | - | 0% | 0% | 0% | 0% | 100% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnsr-c940641-p12

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 80 (9) | 0 | 80 | 29 | 67% | 4.3 | 0 (4) | 111 (3) | 200 (2) | 124 (6) | 0 (3) |
| Mine | Character | 9 | 9 (9) | 9 | 0 | 17 | 22% | 4.0 | 18 (2) | 2 (5) | 0 (1) | 12 (5) | 0 (3) |
| Mine | Clean-up | 1 | 246 (1) | 0 | 246 | 0 | 100% | - | - | - | 246 (1) | 246 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 6 | 18 (6) | 6 | 12 | 41 | 33% | 4.0 | - | 16 (4) | 25 (2) | 20 (3) | 16 (3) |
| Mine | Hammer | 2 | 60 (2) | 23 | 37 | 0 | 50% | 3.0 | - | 60 (2) | - | 68 (1) | 56 (1) |
| Mine | Holder | 1 | 212 (1) | 0 | 212 | 0 | 0% | 5.0 | 212 (1) | - | - | 212 (1) | - |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 39 | 50% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 3 | 194 (3) | 0 | 194 | 22 | 100% | - | 0 (1) | 343 (1) | 0 (1) | 194 (3) | - |
| Opponent | Character | 10 | 52 (10) | 52 | 0 | 0 | 20% | 2.8 | 0 (3) | 62 (6) | 243 (1) | 88 (6) | 0 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 32 (5) | 5 | 27 | 22 | 40% | 3.0 | 30 (2) | 0 (1) | 51 (2) | 66 (2) | 15 (3) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 67 | 0% | 3.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 15 (6) | 0 | 15 | 21 | 33% | 3.8 | - | 19 (4) | 0 (2) | 0 (3) | 32 (3) |
| Opponent | Holder | 6 | 30 (6) | 0 | 30 | 27 | 50% | 2.3 | 18 (3) | 60 (2) | - | - | 36 (5) |
| Opponent | Shooter | 1 | 56 (1) | 0 | 56 | 0 | 0% | 3.0 | - | - | 56 (1) | 56 (1) | - |

### Charged fights: cnsr-c940641-p12

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 134 | 4.0 | 1.0 | 34 | 102 | -68 | 2 of 8 | 4 of 8 | - | -68 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 3 | 0 | 89 | 3.0 | 1.0 | 30 | 90 | -60 | 2 of 9 | 5 of 9 | - | -60 |
| Opponent | Warriors of Chaos | 2 | 0 | 360 | 5.0 | 1.1 | 72 | 0 | +72 | 4 of 10 | 8 of 10 | +0 | +80 |
| Opponent | Wood Elf Realms | 1 | 0 | 30 | 2.0 | 1.0 | 15 | 0 | +15 | 1 of 2 | 1 of 2 | - | +15 |
| **Opponent** | all armies | 3 | 0 | 250 | 4.0 | 1.1 | 62 | 0 | +62 | 5 of 12 | 9 of 12 | +0 | +68 |

### Effective charges: cnsr-c940641-p12

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 8 | 3 (net -256) | 0 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 1 (net +53) | 1 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 10 | 0 | 0 | 3 (net +62) | 4 (net +121) | 0 | 2 (net +0) | 1 | 33% (3 of 9) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +30) | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: cnsr-c940641-p12

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 119 | 285 | -256 | 0 | 256 | -256 | -214.2 |
| Mine | Effective (55-75%) | 1 | 186 | 285 | +0 | 190 | 0 | +190 | +102.2 |
| Mine | 76-89% | 1 | 186 | 173 | +0 | 115 | 31 | +84 | +45.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 125 | 104 | +26 | 58 | 22 | +36 | +28.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 480 | 144 | +0 | 172 | 0 | +172 | +35.9 |
| Mine | No odds | 1 | 480 | 170 | +170 | 170 | 0 | +170 | +35.4 |
| Mine | All fights | 9 | 216 | 204 | -60 | 85 | 94 | -9 | -4.1 |
| Opponent | Effective (55-75%) | 3 | 388 | 376 | +62 | 62 | 0 | +62 | +16.0 |
| Opponent | 76-89% | 4 | 258 | 179 | +121 | 121 | 0 | +121 | +46.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 298 | 220 | +0 | 16 | 28 | -12 | -4.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 500 | 30 | +30 | 140 | 222 | -82 | -16.4 |
| Opponent | No odds | 2 | 504 | 272 | +25 | 25 | 0 | +25 | +5.0 |
| Opponent | All fights | 12 | 359 | 238 | +62 | 74 | 23 | +51 | +14.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnsr-c940641-p12 | move | 22 | 4 (18%) | 2 (9%) | 4 (18%) | 14 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

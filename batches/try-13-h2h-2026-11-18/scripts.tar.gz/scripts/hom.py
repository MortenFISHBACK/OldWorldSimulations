"""HIS ONE MOVE: assumed action v what the enemy unit actually did in his turn, by kind."""
import sys,json,glob,re,collections
root=sys.argv[1]; M=collections.Counter(); ok=collections.Counter()
R=re.compile(r'#(\d+) .*?(not )?as assumed: it was assumed to (\w+)(?: #(\d+))?')
TG=collections.Counter()
for f in glob.glob(root+'/*/*/game-*.log.jsonl'):
    ev=[json.loads(l) for l in open(f) if l.strip()]; ev=[e for e in ev if e.get('kind')=='action']
    for k,e in enumerate(ev):
        s=e.get('summary') or ''
        if e.get('type')!='OpponentRule' or not s.startswith('HIS ONE MOVE') or 'as assumed' not in s: continue
        m=R.search(s); U=int(m.group(1)); S=e['side']; assumed=m.group(3)
        # player turns: a new one starts at a Strategy row of the other side
        seg=[];cur=None;start=0
        for i,x in enumerate(ev[:k+1]):
            if x['phase']=='Strategy' and x.get('side')!=cur:
                if cur is not None: seg.append((cur,start,i))
                cur=x.get('side'); start=i
        prev=[t for t in seg if t[0]!=S]
        win=ev[prev[-1][1]:prev[-1][2]] if prev else []
        acts=[x for x in win if x.get('actor_id')==U]
        ts={x['type'] for x in acts}; txt=' '.join(x.get('summary','') for x in acts)
        did=('charge' if any(x['type']=='Charge' and 'declares' in x.get('summary','') for x in acts) else
             'flee' if ('Flee' in ' '.join(ts) or 'BreakTestMove' in ts or ' flees' in txt) else
             'march' if 'March' in ts else
             'shoot' if ts & {'Shooting','WarMachineShot'} else
             'move' if ts & {'RemainingMove','RandomMovement','ModelsTurned','FreeReform','SkirmisherFormUp'} or any(x['phase']=='Movement' and x.get('from') and x.get('to') and x['from']!=x['to'] and None not in x['from'] for x in acts) else
             'in combat' if ts & {'CombatAttack','CombatResult'} else
             'stand / nothing seen')
        if assumed=='charge' and did=='charge':
            tg={x.get('target_id') for x in acts if x['type']=='Charge' and 'declares' in x.get('summary','')}
            TG['same target' if m.group(4) and int(m.group(4)) in tg else 'other target']+=1
        M[(assumed,did)]+=1; ok[(assumed, m.group(2) is None)]+=1
kinds=sorted({a for a,_ in M}); dids=sorted({d for _,d in M})
print('| assumed \\ did | '+' | '.join(dids)+' | as assumed (row) |'); print('|---'*(len(dids)+2)+'|')
for a in kinds:
    n=sum(M[(a,d)] for d in dids)
    print(f'| {a} ({n}) | '+' | '.join(str(M[(a,d)]) for d in dids)+f' | {ok[(a,True)]} |')
print('assumed charge and he charged:',dict(TG))

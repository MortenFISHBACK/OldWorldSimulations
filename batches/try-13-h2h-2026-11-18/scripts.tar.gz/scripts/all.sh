#!/bin/bash
S=~/s13; W=~/w13
bash $S/pull13.sh; bash $S/analyse13.sh ~/t13 $W >/dev/null
cd $S
timeout 600 python3 -I promise9.py ~/t13 > $W/promise9.out 2>&1
timeout 600 python3 -I rows.py ~/t13 > $W/rows.out 2>&1
timeout 600 python3 -I joint/build.py ~/t13 > /dev/null 2>&1; timeout 600 python3 -I joint/joint.py ~/t13 $S/joint/charges.pkl > $W/joint.out 2>&1
timeout 600 bash holds.sh > $W/holds.out 2>&1
timeout 300 python3 -I again.py ~/t13 > $W/again.out 2>&1
timeout 300 python3 -I m10.py ~/t13 > $W/m10.out 2>&1
find ~/t13 -name 'game-*.log.jsonl' | xargs grep -h '"OpponentRule"' | grep -c '"summary": "PROMISE BY ITS OWN SUM' > $W/takenoff.out
head -3 $W/report.out

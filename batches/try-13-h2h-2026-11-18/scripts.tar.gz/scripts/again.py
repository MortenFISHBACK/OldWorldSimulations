"""Try 12: THE TABLE AGAIN / SHOTS AFTER THE MOVES rows (new side): seconds a game, units/rows priced again v changed;
PROMISE KEPT v WITHDRAWN rows; rows carried out by THE TABLE BINDS.  python3 -I again.py <root>"""
import json,glob,re,sys,collections
R=sys.argv[1]; fs=glob.glob(R+'/**/game-*.log.jsonl',recursive=True)
c=collections.Counter(); sec=collections.Counter(); mins=[]
for f in fs:
    for l in open(f,encoding='utf-8'):
        if '"summary"' not in l: continue
        d=json.loads(l); s=d.get('summary') or ''
        if s.startswith('THE TABLE AGAIN:'):
            m=re.search(r'(\d+) units? priced again after the charges, (\d+) rows? changed, ([\d.]+) s',s)
            c['again rows']+=1
            if m: c['again units']+=int(m[1]); c['again changed']+=int(m[2]); sec['again']+=float(m[3])
            else: c['again unparsed']+=1
        elif s.startswith('SHOTS AFTER THE MOVES:'):
            m=re.search(r'(\d+) shoot rows? priced again after the moves, (\d+) changed, ([\d.]+) s',s)
            c['shots rows']+=1
            if m: c['shots priced']+=int(m[1]); c['shots changed']+=int(m[2]); sec['shots']+=float(m[3])
            else: c['shots unparsed']+=1
        elif s.startswith('PROMISE KEPT'):
            c['promise kept']+=1
            if 'THE TABLE BINDS' in s: c['kept: carried out as its table row']+=1
        elif s.startswith('PROMISE WITHDRAWN'): c['promise withdrawn']+=1
        elif s.startswith('THE TABLE BINDS'): c['table binds rows']+=1
G=len(fs); print('games',G)
for k,v in sorted(c.items()): print(f'{k}: {v} ({v/G:.2f} a game)')
for k,v in sec.items(): print(f'seconds {k}: {v:.0f} total, {v/G:.1f} s a game')

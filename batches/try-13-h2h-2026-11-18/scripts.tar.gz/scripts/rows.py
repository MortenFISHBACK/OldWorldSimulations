import sys,json,glob,re,collections
root=sys.argv[1]
tags=["HIS ONE MOVE","PROMISE BY ITS OWN SUM","SECOND LOOK","THE TABLE AGAIN","ARMY TABLE"]
side=collections.Counter(); pat=collections.defaultdict(collections.Counter); secs=collections.Counter(); ng=0
for f in glob.glob(root+'/*/*/game-*.log.jsonl'):
    arm=f.split('/')[-3].split('-')[0]; ng+=1
    for l in open(f):
        if '"OpponentRule"' not in l: continue
        r=json.loads(l); s=r.get('summary') or ''
        for t in tags:
            if s.startswith(t+':'):
                side[(arm,t,r['side'])]+=1
                m=re.search(r'([0-9.]+) s \|',s)
                if m: secs[t]+=float(m.group(1))
                pat[t][re.sub(r'[0-9]+(\.[0-9]+)?','#',s)[:200]]+=1
print('games',ng)
for k,v in sorted(side.items()): print(k,v)
for t in tags: print(t,'s/game %.1f'%(secs[t]/max(ng,1)))
for t in tags[:3]:
    print('==',t)
    for k,v in pat[t].most_common(12): print(v,k)
print('== HIS ONE MOVE check rows')
c=collections.Counter(); d=[]
for f in glob.glob(root+'/*/*/game-*.log.jsonl'):
    for l in open(f):
        if '"OpponentRule"' not in l or 'as assumed' not in l: continue
        s=json.loads(l)['summary']
        m=re.search(r'(not )?as assumed: it was assumed to (\w+)(?: to \(([-0-9.]+), ([-0-9.]+)\))?, it (\w+)(?: at \(([-0-9.]+), ([-0-9.]+)\))?',s)
        if not m: c['unparsed']+=1; continue
        ok='as' if not m.group(1) else 'not'
        c[(ok,m.group(2))]+=1
        if m.group(3) and m.group(6):
            d.append(((float(m.group(3))-float(m.group(6)))**2+(float(m.group(4))-float(m.group(7)))**2)**.5)
for k,v in sorted(c.items(),key=str): print(k,v)
import statistics
if d: print('assumed v real spot distance: median %.1f, under 3": %d of %d'%(statistics.median(d),sum(x<3 for x in d),len(d)))
print('== HIS ONE MOVE as/not by assumed action')
c=collections.Counter()
for f in glob.glob(root+'/*/*/game-*.log.jsonl'):
    for l in open(f):
        if '"OpponentRule"' not in l or 'as assumed' not in l: continue
        s=json.loads(l)['summary']; m=re.search(r'(not )?as assumed: it was assumed to (\w+)',s)
        if m: c[('not' if m.group(1) else 'as', m.group(2))]+=1
print('total',sum(c.values()),'as',sum(v for k,v in c.items() if k[0]=='as'))
for k,v in sorted(c.items()): print(k,v)

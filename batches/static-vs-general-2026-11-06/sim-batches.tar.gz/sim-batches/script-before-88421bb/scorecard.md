# Doctrine scorecard: script-before-88421bb

### Scorecard: script-before-88421bb

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | 1 | 1 | Mine | yes | 6 | 1 | 4 | 4 | 0 | 0 | 0 | 68 |
| C1 | 1 | 1 | Opponent | no | 0 | 6 | 5 | 0 | 1 | 0 | 0 | 0 |
| C1 | 1 | 2 | Mine | yes | 7 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| C1 | 1 | 2 | Opponent | no | 2 | - | 1 | 1 | 0 | 0 | 0 | 168 |
| C2 | 2 | 1 | Mine | - | - | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| C2 | 2 | 1 | Opponent | - | - | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| C2 | 2 | 2 | Mine | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| C2 | 2 | 2 | Opponent | - | - | 1 | 1 | 5 | 0 | 0 | 0 | 0 |
| C3 | 3 | 1 | Mine | no | 0 | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| C3 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 4 | 1 | 0 | 0 | 0 |
| C3 | 3 | 2 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| C3 | 3 | 2 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| E1 | 1 | 1 | Mine | no | 0 | - | 5 | 0 | 1 | 0 | 0 | 0 |
| E1 | 1 | 1 | Opponent | no | 9 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| E1 | 1 | 2 | Mine | no | 1 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| E1 | 1 | 2 | Opponent | no | 0 | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| E2 | 2 | 1 | Mine | - | - | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| E2 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| E2 | 2 | 2 | Mine | - | - | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| E2 | 2 | 2 | Opponent | - | - | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| E3 | 3 | 1 | Mine | no | 2 | - | 4 | 1 | 1 | 0 | 0 | 0 |
| E3 | 3 | 1 | Opponent | no | 3 | - | 9 | 2 | 0 | 0 | 0 | 0 |
| E3 | 3 | 2 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| E3 | 3 | 2 | Opponent | no | 2 | 1 | 6 | 4 | 0 | 0 | 0 | 0 |
| N1 | 1 | 1 | Mine | yes | 2 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| N1 | 1 | 1 | Opponent | no | 0 | 2 | 10 | 6 | 0 | 0 | 0 | 279 |
| N1 | 1 | 2 | Mine | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| N1 | 1 | 2 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| N2 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| N2 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| N2 | 2 | 2 | Mine | - | - | 1 | 11 | 0 | 0 | 0 | 0 | 0 |
| N2 | 2 | 2 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| N3 | 3 | 1 | Mine | no | 4 | 1 | 9 | 4 | 0 | 0 | 0 | 434 |
| N3 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| N3 | 3 | 2 | Mine | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 434 |
| N3 | 3 | 2 | Opponent | no | 3 | 1 | 6 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 25% | 1.8 | 1.6 | 5.2 | 1.4 | 0.3 | 0.0 | 0.0 | 52.0 |
| **Average** | | | Opponent | 0% | 1.7 | 2.1 | 4.2 | 2.3 | 0.3 | 0.0 | 0.0 | 24.8 |

### Charged fights: script-before-88421bb

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 4.5 | 1.2 | 0 | 10 | -10 | 6 of 9 | 4 of 9 | +0 | -12 |
| Mine | Dwarfen Mountain Holds | 2 | 147 | 0 | 4.0 | 1.2 | 0 | 154 | -154 | 4 of 8 | 3 of 8 | -214 | -134 |
| Mine | Grand Cathay | 6 | 312 | 276 | 4.3 | 1.2 | 64 | 5 | +58 | 7 of 26 | 18 of 26 | +131 | +45 |
| Mine | Kingdom of Bretonnia | 2 | 0 | 87 | 9.5 | 1.5 | 9 | 69 | -60 | 13 of 19 | 8 of 19 | -132 | -8 |
| Mine | Orc & Goblin Tribes | 2 | 125 | 536 | 9.5 | 1.1 | 56 | 33 | +23 | 4 of 19 | 15 of 19 | +188 | +4 |
| Mine | Tomb Kings of Khemri | 2 | 130 | 0 | 9.0 | 1.1 | 0 | 44 | -44 | 3 of 18 | 11 of 18 | +0 | -46 |
| Mine | Wood Elf Realms | 2 | 55 | 290 | 7.5 | 1.1 | 39 | 24 | +14 | 2 of 15 | 3 of 15 | +112 | -1 |
| **Mine** | all armies | 18 | 155 | 193 | 6.3 | 1.2 | 31 | 40 | -9 | 39 of 114 | 62 of 114 | -17 | -8 |
| Opponent | Beastmen Brayherds | 4 | 92 | 34 | 2.0 | 1.2 | 17 | 0 | +17 | 2 of 8 | 5 of 8 | +135 | +0 |
| Opponent | Dwarfen Mountain Holds | 6 | 45 | 276 | 5.3 | 1.1 | 52 | 5 | +46 | 4 of 32 | 22 of 32 | +42 | +47 |
| Opponent | Empire of Man | 2 | 95 | 184 | 7.5 | 1.1 | 24 | 37 | -13 | 1 of 15 | 10 of 15 | +60 | -18 |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 136 | 2.5 | 1.1 | 54 | 0 | +54 | 2 of 10 | 9 of 10 | +0 | +61 |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 622 | 7.5 | 1.3 | 83 | 10 | +73 | 2 of 15 | 13 of 15 | +19 | +86 |
| **Opponent** | all armies | 18 | 46 | 219 | 4.4 | 1.1 | 49 | 11 | +38 | 11 of 80 | 59 of 80 | +42 | +38 |


## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | E2, N3 |
| Charmed Shield | Opponent | C2, E1, N2, N3 |
| Flamestrike Wand | Mine | E3 |
| Paymaster's Coin | Opponent | N3 |

# this batch (plays none) vs script-before-88421bb

A = this batch (plays none): script-figures-all-216c523, 9 of 9 games ended
B = script-before-88421bb: script-before-88421bb, 9 of 9 games ended

## Game by game (Victory Points Mine-Opponent; margin = Mine minus Opponent)

| Match-up | Scenario | Seed | A | B | Margin A | Margin B | A minus B | Cost A | Cost B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | 1 | 1 | draw 1323-1120 | Mine 2500-301 | +203 | +2199 | -1996 | 0.00 | 0.00 |
| C2 | 2 | 1 | Mine 1802-478 | Mine 1746-335 | +1324 | +1411 | -87 | 0.00 | 0.00 |
| C3 | 3 | 1 | draw 1761-1897 | Mine 2096-1508 | -136 | +588 | -724 | 0.00 | 0.00 |
| E1 | 1 | 1 | Opponent 1015-2491 | Opponent 462-2645 | -1476 | -2183 | +707 | 0.00 | 0.00 |
| E2 | 2 | 1 | Opponent 230-2291 | draw 985-1175 | -2061 | -190 | -1871 | 0.00 | 0.00 |
| E3 | 3 | 1 | Opponent 984-2066 | Opponent 1134-2355 | -1082 | -1221 | +139 | 0.00 | 0.00 |
| N1 | 1 | 1 | draw 1437-1152 | Mine 1829-1297 | +285 | +532 | -247 | 0.00 | 0.00 |
| N2 | 2 | 1 | Opponent 572-1790 | Opponent 867-1229 | -1218 | -362 | -856 | 0.00 | 0.00 |
| N3 | 3 | 1 | Mine 2070-1450 | Mine 2142-1455 | +620 | +687 | -67 | 0.00 | 0.00 |

## Totals

| | A: this batch (plays none) | B: script-before-88421bb |
| --- | --- | --- |
| Mine won / drew / lost | 2 / 3 / 4 | 5 / 1 / 3 |
| Mean margin (Mine - Opponent) | -393 | +162 |
| Cost per game | $0.000 | $0.000 |
| Mine side per game | $0.000 | $0.000 |
| Opponent side per game | $0.000 | $0.000 |
| Cost of the batch | $0.00 | $0.00 |
| Failed calls per game | 0.0 | 0.0 |
| VP from objectives, Mine | 674 | 692 |
| VP from objectives, Opponent | 471 | 506 |
| VP from kills, Mine | 464 | 677 |
| VP from kills, Opponent | 1105 | 822 |
| VP from leaders, Mine | 67 | 78 |
| VP from leaders, Opponent | 61 | 39 |
| VP from other, Mine | 39 | 82 |
| VP from other, Opponent | 0 | 0 |
| Units lost, Mine | 8.7 | 7.6 |
| Units lost, Opponent | 5.9 | 6.7 |
| Scorecard: Far marker / quarter contested by round 3 (both sides) | 25% | 17% |
| Scorecard: Lone holders (player turns) (both sides) | 2.8 | 2.2 |
| Scorecard: Round of the first Hammer charge (both sides) | 1.9 | 2.1 |
| Scorecard: Lone charges into a block / monster / character (both sides) | 3.9 | 5.5 |
| Scorecard: Idle units (both sides) | 1.8 | 1.8 |
| Scorecard: Wounded Lords / monsters lost (both sides) | 0.4 | 0.4 |
| Scorecard: Doctrine flags raised (both sides) | 0.0 | 0.0 |
| Scorecard: Answers changed after a flag (both sides) | 0.0 | 0.0 |
| Scorecard: Points that never moved of their own (both sides) | 260.8 | 43.4 |

## Is the difference more than noise?

9 pairs of games: A's margin is -556 VP a game against B's, give or take 603 VP (two standard errors). Verdict: within noise (could be chance).

## Doctrine scorecard (per game and side; far = share of games contested)

### Scorecard: this batch (plays none)

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | 1 | 1 | Mine | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| C1 | 1 | 1 | Opponent | no | 0 | 4 | 6 | 1 | 0 | 0 | 0 | 778 |
| C2 | 2 | 1 | Mine | - | - | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| C2 | 2 | 1 | Opponent | - | - | 1 | 3 | 3 | 0 | 0 | 0 | 517 |
| C3 | 3 | 1 | Mine | yes | 6 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| C3 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 1010 |
| E1 | 1 | 1 | Mine | no | 0 | - | 5 | 0 | 0 | 0 | 0 | 0 |
| E1 | 1 | 1 | Opponent | no | 12 | 2 | 3 | 1 | 3 | 0 | 0 | 0 |
| E2 | 2 | 1 | Mine | - | - | 1 | 3 | 0 | 1 | 0 | 0 | 0 |
| E2 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 765 |
| E3 | 3 | 1 | Mine | yes | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| E3 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 50 |
| N1 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| N1 | 1 | 1 | Opponent | no | 5 | 2 | 5 | 2 | 0 | 0 | 0 | 448 |
| N2 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| N2 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 222 |
| N3 | 3 | 1 | Mine | yes | 1 | 1 | 3 | 4 | 1 | 0 | 0 | 529 |
| N3 | 3 | 1 | Opponent | no | 6 | 3 | 3 | 1 | 0 | 0 | 0 | 375 |
| **Average** | | | Mine | 50% | 1.5 | 1.6 | 4.4 | 1.2 | 0.6 | 0.0 | 0.0 | 58.8 |
| **Average** | | | Opponent | 0% | 4.0 | 2.2 | 3.3 | 2.3 | 0.3 | 0.0 | 0.0 | 462.8 |

### Scorecard: script-before-88421bb

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | 1 | 1 | Mine | yes | 6 | 1 | 4 | 4 | 0 | 0 | 0 | 68 |
| C1 | 1 | 1 | Opponent | no | 0 | 6 | 5 | 0 | 1 | 0 | 0 | 0 |
| C2 | 2 | 1 | Mine | - | - | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| C2 | 2 | 1 | Opponent | - | - | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| C3 | 3 | 1 | Mine | no | 0 | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| C3 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 4 | 1 | 0 | 0 | 0 |
| E1 | 1 | 1 | Mine | no | 0 | - | 5 | 0 | 1 | 0 | 0 | 0 |
| E1 | 1 | 1 | Opponent | no | 9 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| E2 | 2 | 1 | Mine | - | - | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| E2 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| E3 | 3 | 1 | Mine | no | 2 | - | 4 | 1 | 1 | 0 | 0 | 0 |
| E3 | 3 | 1 | Opponent | no | 3 | - | 9 | 2 | 0 | 0 | 0 | 0 |
| N1 | 1 | 1 | Mine | yes | 2 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| N1 | 1 | 1 | Opponent | no | 0 | 2 | 10 | 6 | 0 | 0 | 0 | 279 |
| N2 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| N2 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| N3 | 3 | 1 | Mine | no | 4 | 1 | 9 | 4 | 0 | 0 | 0 | 434 |
| N3 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.3 | 1.4 | 5.6 | 1.6 | 0.4 | 0.0 | 0.0 | 55.8 |
| **Average** | | | Opponent | 0% | 2.2 | 2.6 | 5.4 | 2.1 | 0.4 | 0.0 | 0.0 | 31.0 |


## Charged fights (points per fight a side charged into; a combined charge is one fight)

### Charged fights: this batch (plays none)

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 2.0 | 1.5 | 0 | 412 | -412 | 2 of 2 | 0 of 2 | -265 | -560 |
| Mine | Dwarfen Mountain Holds | 1 | 75 | 229 | 6.0 | 1.2 | 38 | 85 | -47 | 2 of 6 | 3 of 6 | +0 | -56 |
| Mine | Grand Cathay | 3 | 154 | 373 | 4.7 | 1.1 | 80 | 10 | +70 | 6 of 14 | 9 of 14 | +0 | +76 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 74 | 9.0 | 1.3 | 8 | 95 | -87 | 6 of 9 | 2 of 9 | -200 | -30 |
| Mine | Orc & Goblin Tribes | 1 | 160 | 744 | 7.0 | 1.1 | 106 | 45 | +62 | 4 of 7 | 3 of 7 | -152 | +97 |
| Mine | Tomb Kings of Khemri | 1 | 73 | 399 | 13.0 | 1.1 | 31 | 35 | -5 | 3 of 13 | 5 of 13 | +74 | -11 |
| Mine | Wood Elf Realms | 1 | 55 | 217 | 8.0 | 1.4 | 27 | 90 | -62 | 2 of 8 | 0 of 8 | -113 | -32 |
| **Mine** | all armies | 9 | 92 | 309 | 6.6 | 1.2 | 47 | 65 | -18 | 25 of 59 | 22 of 59 | -117 | +5 |
| Opponent | Beastmen Brayherds | 2 | 94 | 264 | 2.0 | 1.0 | 132 | 44 | +88 | 1 of 4 | 3 of 4 | - | +88 |
| Opponent | Dwarfen Mountain Holds | 3 | 55 | 225 | 5.0 | 1.2 | 45 | 0 | +45 | 5 of 15 | 8 of 15 | +71 | +41 |
| Opponent | Empire of Man | 1 | 430 | 180 | 3.0 | 1.0 | 60 | 0 | +60 | 0 of 3 | 3 of 3 | - | +60 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 666 | 2.0 | 1.0 | 333 | 0 | +333 | 1 of 4 | 4 of 4 | - | +333 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 892 | 5.0 | 1.0 | 178 | 15 | +163 | 2 of 5 | 5 of 5 | - | +163 |
| **Opponent** | all armies | 9 | 87 | 401 | 3.4 | 1.1 | 116 | 8 | +108 | 9 of 31 | 23 of 31 | +71 | +111 |

### Charged fights: script-before-88421bb

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 4.0 | 1.2 | 0 | 22 | -22 | 2 of 4 | 2 of 4 | +0 | -29 |
| Mine | Dwarfen Mountain Holds | 1 | 147 | 0 | 5.0 | 1.4 | 0 | 153 | -153 | 3 of 5 | 1 of 5 | -214 | -112 |
| Mine | Grand Cathay | 3 | 312 | 472 | 3.7 | 1.2 | 129 | 12 | +116 | 3 of 11 | 9 of 11 | +262 | +84 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 10.0 | 1.5 | 0 | 89 | -89 | 7 of 10 | 1 of 10 | -175 | -32 |
| Mine | Orc & Goblin Tribes | 1 | 125 | 787 | 10.0 | 1.1 | 79 | 53 | +26 | 2 of 10 | 7 of 10 | +376 | -13 |
| Mine | Tomb Kings of Khemri | 1 | 130 | 0 | 6.0 | 1.0 | 0 | 44 | -44 | 1 of 6 | 3 of 6 | - | -44 |
| Mine | Wood Elf Realms | 1 | 55 | 328 | 8.0 | 1.2 | 41 | 42 | -2 | 1 of 8 | 3 of 8 | +112 | -39 |
| **Mine** | all armies | 9 | 155 | 281 | 6.0 | 1.2 | 47 | 56 | -9 | 19 of 54 | 26 of 54 | -0 | -11 |
| Opponent | Beastmen Brayherds | 2 | 92 | 68 | 3.0 | 1.3 | 22 | 0 | +22 | 1 of 6 | 4 of 6 | +135 | +0 |
| Opponent | Dwarfen Mountain Holds | 3 | 45 | 396 | 8.3 | 1.1 | 47 | 7 | +41 | 4 of 25 | 19 of 25 | +42 | +40 |
| Opponent | Empire of Man | 1 | 95 | 184 | 6.0 | 1.0 | 31 | 69 | -38 | 1 of 6 | 3 of 6 | - | -38 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 205 | 3.5 | 1.1 | 59 | 0 | +59 | 2 of 7 | 6 of 7 | +0 | +68 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 892 | 4.0 | 1.5 | 223 | 19 | +204 | 1 of 4 | 4 of 4 | +132 | +228 |
| **Opponent** | all armies | 9 | 46 | 312 | 5.3 | 1.2 | 58 | 14 | +45 | 9 of 48 | 36 of 48 | +66 | +42 |


## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | E2, N3 |
| Charmed Shield | Opponent | C2, E1, N2, N3 |
| Flamestrike Wand | Mine | E3 |
| Paymaster's Coin | Opponent | N3 |

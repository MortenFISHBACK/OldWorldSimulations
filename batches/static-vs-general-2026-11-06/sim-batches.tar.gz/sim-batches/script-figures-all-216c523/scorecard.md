# Doctrine scorecard: script-figures-all-216c523

### Scorecard: script-figures-all-216c523

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | 1 | 1 | Mine | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| C1 | 1 | 1 | Opponent | no | 0 | 4 | 6 | 1 | 0 | 0 | 0 | 778 |
| C1 | 1 | 2 | Mine | yes | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| C1 | 1 | 2 | Opponent | no | 0 | - | 4 | 2 | 0 | 0 | 0 | 683 |
| C2 | 2 | 1 | Mine | - | - | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| C2 | 2 | 1 | Opponent | - | - | 1 | 3 | 3 | 0 | 0 | 0 | 517 |
| C2 | 2 | 2 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| C2 | 2 | 2 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 559 |
| C3 | 3 | 1 | Mine | yes | 6 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| C3 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 1010 |
| C3 | 3 | 2 | Mine | yes | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| C3 | 3 | 2 | Opponent | no | 0 | 5 | 3 | 5 | 0 | 0 | 0 | 1541 |
| E1 | 1 | 1 | Mine | no | 0 | - | 5 | 0 | 0 | 0 | 0 | 0 |
| E1 | 1 | 1 | Opponent | no | 12 | 2 | 3 | 1 | 3 | 0 | 0 | 0 |
| E1 | 1 | 2 | Mine | no | 2 | - | 5 | 0 | 0 | 0 | 0 | 0 |
| E1 | 1 | 2 | Opponent | no | 0 | 1 | 5 | 1 | 2 | 0 | 0 | 368 |
| E2 | 2 | 1 | Mine | - | - | 1 | 3 | 0 | 1 | 0 | 0 | 0 |
| E2 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 765 |
| E2 | 2 | 2 | Mine | - | - | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| E2 | 2 | 2 | Opponent | - | - | 4 | 2 | 4 | 0 | 0 | 0 | 190 |
| E3 | 3 | 1 | Mine | yes | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| E3 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 50 |
| E3 | 3 | 2 | Mine | no | 0 | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| E3 | 3 | 2 | Opponent | no | 5 | 1 | 2 | 5 | 0 | 0 | 0 | 0 |
| N1 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| N1 | 1 | 1 | Opponent | no | 5 | 2 | 5 | 2 | 0 | 0 | 0 | 448 |
| N1 | 1 | 2 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| N1 | 1 | 2 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 484 |
| N2 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| N2 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 222 |
| N2 | 2 | 2 | Mine | - | - | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| N2 | 2 | 2 | Opponent | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 57 |
| N3 | 3 | 1 | Mine | yes | 1 | 1 | 3 | 4 | 1 | 0 | 0 | 529 |
| N3 | 3 | 1 | Opponent | no | 6 | 3 | 3 | 1 | 0 | 0 | 0 | 375 |
| N3 | 3 | 2 | Mine | yes | 2 | 2 | 6 | 5 | 0 | 0 | 0 | 434 |
| N3 | 3 | 2 | Opponent | no | 7 | 6 | 3 | 0 | 0 | 0 | 0 | 526 |
| **Average** | | | Mine | 50% | 1.4 | 1.7 | 3.8 | 1.6 | 0.3 | 0.0 | 0.0 | 53.5 |
| **Average** | | | Opponent | 0% | 3.0 | 2.6 | 3.3 | 2.4 | 0.3 | 0.0 | 0.0 | 476.3 |

### Charged fights: script-figures-all-216c523

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 3.0 | 1.3 | 0 | 191 | -191 | 6 of 6 | 0 of 6 | -132 | -220 |
| Mine | Dwarfen Mountain Holds | 2 | 75 | 114 | 5.5 | 1.1 | 21 | 83 | -62 | 5 of 11 | 4 of 11 | +0 | -68 |
| Mine | Grand Cathay | 6 | 154 | 186 | 4.0 | 1.2 | 47 | 6 | +41 | 8 of 24 | 17 of 24 | +0 | +49 |
| Mine | Kingdom of Bretonnia | 2 | 0 | 74 | 7.5 | 1.4 | 10 | 91 | -81 | 9 of 15 | 5 of 15 | -192 | -25 |
| Mine | Orc & Goblin Tribes | 2 | 160 | 556 | 7.5 | 1.3 | 74 | 39 | +35 | 7 of 15 | 10 of 15 | -60 | +70 |
| Mine | Tomb Kings of Khemri | 2 | 73 | 264 | 12.5 | 1.1 | 21 | 34 | -13 | 3 of 25 | 13 of 25 | +68 | -24 |
| Mine | Wood Elf Realms | 2 | 55 | 108 | 6.0 | 1.6 | 18 | 62 | -44 | 2 of 12 | 2 of 12 | -61 | -27 |
| **Mine** | all armies | 18 | 92 | 186 | 6.0 | 1.2 | 31 | 53 | -22 | 40 of 108 | 51 of 108 | -65 | -9 |
| Opponent | Beastmen Brayherds | 4 | 94 | 166 | 2.8 | 1.1 | 60 | 21 | +39 | 1 of 11 | 8 of 11 | +83 | +35 |
| Opponent | Dwarfen Mountain Holds | 6 | 55 | 136 | 4.7 | 1.3 | 29 | 0 | +29 | 8 of 28 | 13 of 28 | +35 | +27 |
| Opponent | Empire of Man | 2 | 430 | 122 | 3.0 | 1.0 | 41 | 0 | +41 | 0 of 6 | 6 of 6 | - | +41 |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 402 | 2.0 | 1.1 | 201 | 0 | +201 | 3 of 8 | 5 of 7 | +50 | +223 |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 446 | 5.5 | 1.1 | 81 | 7 | +74 | 4 of 11 | 9 of 11 | +0 | +82 |
| **Opponent** | all armies | 18 | 87 | 235 | 3.6 | 1.2 | 66 | 5 | +61 | 16 of 64 | 41 of 63 | +38 | +66 |


## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | E2, N3 |
| Charmed Shield | Opponent | C2, E1, N2, N3 |
| Flamestrike Wand | Mine | E3 |
| Paymaster's Coin | Opponent | N3 |

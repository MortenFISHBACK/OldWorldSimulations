# Doctrine scorecard: script-gang-ca2149f

### Scorecard: script-gang-ca2149f

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | 1 | 1 | Mine | no | 2 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| C1 | 1 | 1 | Opponent | no | 0 | - | 3 | 0 | 0 | 0 | 0 | 395 |
| C1 | 1 | 2 | Mine | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| C1 | 1 | 2 | Opponent | no | 0 | - | 4 | 2 | 0 | 0 | 0 | 503 |
| C2 | 2 | 1 | Mine | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| C2 | 2 | 1 | Opponent | - | - | 1 | 3 | 6 | 0 | 0 | 0 | 487 |
| C2 | 2 | 2 | Mine | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| C2 | 2 | 2 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 524 |
| C3 | 3 | 1 | Mine | yes | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| C3 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 4 | 0 | 0 | 0 | 560 |
| C3 | 3 | 2 | Mine | yes | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| C3 | 3 | 2 | Opponent | no | 0 | 6 | 1 | 5 | 0 | 0 | 0 | 1175 |
| E1 | 1 | 1 | Mine | no | 0 | - | 9 | 0 | 0 | 0 | 0 | 0 |
| E1 | 1 | 1 | Opponent | no | 10 | 2 | 5 | 0 | 2 | 0 | 0 | 72 |
| E1 | 1 | 2 | Mine | no | 0 | - | 4 | 0 | 0 | 0 | 0 | 138 |
| E1 | 1 | 2 | Opponent | no | 0 | 1 | 6 | 2 | 1 | 0 | 0 | 0 |
| E2 | 2 | 1 | Mine | - | - | 1 | 4 | 3 | 1 | 0 | 0 | 425 |
| E2 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 190 |
| E2 | 2 | 2 | Mine | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 55 |
| E2 | 2 | 2 | Opponent | - | - | - | 2 | 4 | 0 | 0 | 0 | 190 |
| E3 | 3 | 1 | Mine | yes | 2 | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| E3 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| E3 | 3 | 2 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| E3 | 3 | 2 | Opponent | no | 1 | 1 | 2 | 3 | 0 | 0 | 0 | 74 |
| N1 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| N1 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 533 |
| N1 | 1 | 2 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| N1 | 1 | 2 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 265 |
| N2 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| N2 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 222 |
| N2 | 2 | 2 | Mine | - | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| N2 | 2 | 2 | Opponent | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| N3 | 3 | 1 | Mine | yes | 1 | 1 | 3 | 6 | 1 | 0 | 0 | 529 |
| N3 | 3 | 1 | Opponent | no | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 410 |
| N3 | 3 | 2 | Mine | yes | 0 | 2 | 4 | 5 | 1 | 0 | 0 | 434 |
| N3 | 3 | 2 | Opponent | no | 3 | 3 | 3 | 0 | 0 | 0 | 0 | 410 |
| **Average** | | | Mine | 50% | 0.6 | 1.7 | 4.2 | 1.6 | 0.4 | 0.0 | 0.0 | 87.8 |
| **Average** | | | Opponent | 0% | 1.8 | 2.3 | 2.8 | 2.1 | 0.2 | 0.0 | 0.0 | 333.9 |

### Charged fights: script-gang-ca2149f

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 336 | 3.5 | 1.1 | 96 | 28 | +68 | 7 of 7 | 2 of 7 | +0 | +80 |
| Mine | Dwarfen Mountain Holds | 2 | 495 | 114 | 3.5 | 1.0 | 33 | 100 | -67 | 3 of 7 | 2 of 7 | - | -67 |
| Mine | Grand Cathay | 6 | 112 | 91 | 4.0 | 1.2 | 23 | 16 | +6 | 9 of 24 | 18 of 24 | +26 | +2 |
| Mine | Kingdom of Bretonnia | 2 | 0 | 37 | 9.0 | 1.2 | 4 | 47 | -43 | 10 of 18 | 4 of 18 | -110 | -29 |
| Mine | Orc & Goblin Tribes | 2 | 0 | 596 | 9.0 | 1.2 | 66 | 23 | +43 | 7 of 18 | 10 of 18 | +14 | +46 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 236 | 9.5 | 1.1 | 25 | 38 | -13 | 5 of 19 | 12 of 19 | +74 | -18 |
| Mine | Wood Elf Realms | 2 | 55 | 108 | 8.0 | 1.4 | 14 | 88 | -74 | 3 of 16 | 0 of 16 | -98 | -56 |
| **Mine** | all armies | 18 | 98 | 189 | 6.1 | 1.2 | 31 | 43 | -12 | 44 of 109 | 48 of 109 | -45 | -5 |
| Opponent | Beastmen Brayherds | 4 | 94 | 98 | 1.5 | 1.0 | 65 | 30 | +36 | 2 of 6 | 4 of 6 | - | +36 |
| Opponent | Dwarfen Mountain Holds | 6 | 93 | 112 | 4.5 | 1.3 | 25 | 8 | +17 | 13 of 27 | 9 of 27 | +8 | +21 |
| Opponent | Empire of Man | 2 | 459 | 30 | 2.0 | 1.0 | 15 | 0 | +15 | 0 of 4 | 2 of 4 | - | +15 |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 220 | 2.0 | 1.0 | 110 | 19 | +90 | 3 of 8 | 4 of 7 | - | +90 |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 408 | 5.5 | 1.2 | 74 | 0 | +74 | 3 of 11 | 10 of 11 | +175 | +52 |
| **Opponent** | all armies | 18 | 103 | 156 | 3.1 | 1.2 | 50 | 10 | +41 | 21 of 56 | 29 of 55 | +42 | +40 |


## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | E2, N3 |
| Charmed Shield | Opponent | C2, E1, N2, N3 |
| Flamestrike Wand | Mine | E3 |
| Paymaster's Coin | Opponent | N3 |

# this batch (plays none) vs script-before-88421bb

A = this batch (plays none): script-figures-step1, 6 of 6 games ended
B = script-before-88421bb: script-before-88421bb, 6 of 6 games ended

## Game by game (Victory Points Mine-Opponent; margin = Mine minus Opponent)

| Match-up | Scenario | Seed | A | B | Margin A | Margin B | A minus B | Cost A | Cost B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | 1 | 1 | Mine 2080-911 | Mine 2500-301 | +1169 | +2199 | -1030 | 0.00 | 0.00 |
| E1 | 1 | 1 | Opponent 1015-2491 | Opponent 462-2645 | -1476 | -2183 | +707 | 0.00 | 0.00 |
| E2 | 2 | 1 | Opponent 800-1219 | draw 985-1175 | -419 | -190 | -229 | 0.00 | 0.00 |
| N1 | 1 | 1 | draw 1387-1152 | Mine 1829-1297 | +235 | +532 | -297 | 0.00 | 0.00 |
| N2 | 2 | 1 | Opponent 606-1861 | Opponent 867-1229 | -1255 | -362 | -893 | 0.00 | 0.00 |
| N3 | 3 | 1 | Mine 2070-1450 | Mine 2142-1455 | +620 | +687 | -67 | 0.00 | 0.00 |

## Totals

| | A: this batch (plays none) | B: script-before-88421bb |
| --- | --- | --- |
| Mine won / drew / lost | 2 / 1 / 3 | 3 / 1 / 2 |
| Mean margin (Mine - Opponent) | -188 | +114 |
| Cost per game | $0.000 | $0.000 |
| Mine side per game | $0.000 | $0.000 |
| Opponent side per game | $0.000 | $0.000 |
| Cost of the batch | $0.00 | $0.00 |
| Failed calls per game | 0.0 | 0.0 |
| VP from objectives, Mine | 667 | 673 |
| VP from objectives, Opponent | 543 | 420 |
| VP from kills, Mine | 551 | 627 |
| VP from kills, Opponent | 921 | 889 |
| VP from leaders, Mine | 83 | 58 |
| VP from leaders, Opponent | 50 | 42 |
| VP from other, Mine | 25 | 106 |
| VP from other, Opponent | 0 | 0 |
| Units lost, Mine | 8.5 | 8.8 |
| Units lost, Opponent | 6.5 | 6.5 |
| Scorecard: Far marker / quarter contested by round 3 (both sides) | 25% | 25% |
| Scorecard: Lone holders (player turns) (both sides) | 3.1 | 2.6 |
| Scorecard: Round of the first Hammer charge (both sides) | 2.2 | 2.2 |
| Scorecard: Lone charges into a block / monster / character (both sides) | 3.9 | 5.3 |
| Scorecard: Idle units (both sides) | 1.3 | 1.5 |
| Scorecard: Wounded Lords / monsters lost (both sides) | 0.4 | 0.4 |
| Scorecard: Doctrine flags raised (both sides) | 0.0 | 0.0 |
| Scorecard: Answers changed after a flag (both sides) | 0.0 | 0.0 |
| Scorecard: Points that never moved of their own (both sides) | 213.9 | 65.1 |

## Is the difference more than noise?

6 pairs of games: A's margin is -302 VP a game against B's, give or take 511 VP (two standard errors). Verdict: within noise (could be chance).

## Doctrine scorecard (per game and side; far = share of games contested)

### Scorecard: this batch (plays none)

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | 1 | 1 | Mine | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| C1 | 1 | 1 | Opponent | yes | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 395 |
| E1 | 1 | 1 | Mine | no | 0 | - | 5 | 0 | 0 | 0 | 0 | 0 |
| E1 | 1 | 1 | Opponent | no | 12 | 2 | 3 | 1 | 3 | 0 | 0 | 0 |
| E2 | 2 | 1 | Mine | - | - | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| E2 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 765 |
| N1 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| N1 | 1 | 1 | Opponent | no | 5 | 2 | 5 | 2 | 0 | 0 | 0 | 448 |
| N2 | 2 | 1 | Mine | - | - | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| N2 | 2 | 1 | Opponent | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 55 |
| N3 | 3 | 1 | Mine | yes | 1 | 1 | 3 | 4 | 1 | 0 | 0 | 529 |
| N3 | 3 | 1 | Opponent | no | 6 | 3 | 3 | 1 | 0 | 0 | 0 | 375 |
| **Average** | | | Mine | 25% | 0.5 | 1.4 | 4.8 | 1.2 | 0.3 | 0.0 | 0.0 | 88.2 |
| **Average** | | | Opponent | 25% | 5.8 | 2.8 | 3.0 | 1.5 | 0.5 | 0.0 | 0.0 | 339.7 |

### Scorecard: script-before-88421bb

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | 1 | 1 | Mine | yes | 6 | 1 | 4 | 4 | 0 | 0 | 0 | 68 |
| C1 | 1 | 1 | Opponent | no | 0 | 6 | 5 | 0 | 1 | 0 | 0 | 0 |
| E1 | 1 | 1 | Mine | no | 0 | - | 5 | 0 | 1 | 0 | 0 | 0 |
| E1 | 1 | 1 | Opponent | no | 9 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| E2 | 2 | 1 | Mine | - | - | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| E2 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| N1 | 1 | 1 | Mine | yes | 2 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| N1 | 1 | 1 | Opponent | no | 0 | 2 | 10 | 6 | 0 | 0 | 0 | 279 |
| N2 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| N2 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| N3 | 3 | 1 | Mine | no | 4 | 1 | 9 | 4 | 0 | 0 | 0 | 434 |
| N3 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 3.0 | 1.2 | 5.3 | 1.5 | 0.3 | 0.0 | 0.0 | 83.7 |
| **Average** | | | Opponent | 0% | 2.2 | 3.0 | 5.3 | 1.5 | 0.5 | 0.0 | 0.0 | 46.5 |


## Charged fights (points per fight a side charged into; a combined charge is one fight)

### Charged fights: this batch (plays none)

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 205 | 2.0 | 1.5 | 102 | 0 | +102 | 2 of 2 | 2 of 2 | +0 | +205 |
| Mine | Dwarfen Mountain Holds | 1 | 75 | 229 | 6.0 | 1.2 | 38 | 85 | -47 | 2 of 6 | 3 of 6 | +0 | -56 |
| Mine | Grand Cathay | 1 | 0 | 535 | 8.0 | 1.1 | 67 | 0 | +67 | 2 of 8 | 5 of 8 | +120 | +59 |
| Mine | Orc & Goblin Tribes | 1 | 160 | 744 | 7.0 | 1.1 | 106 | 45 | +62 | 4 of 7 | 3 of 7 | -152 | +97 |
| Mine | Tomb Kings of Khemri | 1 | 73 | 399 | 13.0 | 1.1 | 31 | 35 | -5 | 3 of 13 | 5 of 13 | +74 | -11 |
| Mine | Wood Elf Realms | 1 | 55 | 251 | 9.0 | 1.2 | 28 | 92 | -64 | 3 of 9 | 4 of 9 | -162 | -36 |
| **Mine** | all armies | 6 | 60 | 394 | 7.5 | 1.2 | 53 | 47 | +6 | 16 of 45 | 22 of 45 | -40 | +14 |
| Opponent | Beastmen Brayherds | 1 | 27 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Dwarfen Mountain Holds | 2 | 150 | 132 | 6.0 | 1.2 | 22 | 0 | +22 | 2 of 12 | 8 of 12 | +70 | +18 |
| Opponent | Empire of Man | 1 | 430 | 180 | 3.0 | 1.0 | 60 | 0 | +60 | 0 of 3 | 3 of 3 | - | +60 |
| Opponent | Orc & Goblin Tribes | 1 | 35 | 280 | 2.0 | 1.0 | 140 | 0 | +140 | 0 of 2 | 0 of 2 | - | +140 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 892 | 5.0 | 1.0 | 178 | 15 | +163 | 2 of 5 | 5 of 5 | - | +163 |
| **Opponent** | all armies | 6 | 132 | 269 | 3.7 | 1.1 | 73 | 3 | +70 | 4 of 22 | 16 of 22 | +70 | +70 |

### Charged fights: script-before-88421bb

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 4.0 | 1.2 | 0 | 22 | -22 | 2 of 4 | 2 of 4 | +0 | -29 |
| Mine | Dwarfen Mountain Holds | 1 | 147 | 0 | 5.0 | 1.4 | 0 | 153 | -153 | 3 of 5 | 1 of 5 | -214 | -112 |
| Mine | Grand Cathay | 1 | 0 | 842 | 5.0 | 1.2 | 168 | 0 | +168 | 0 of 5 | 5 of 5 | +471 | +93 |
| Mine | Orc & Goblin Tribes | 1 | 125 | 787 | 10.0 | 1.1 | 79 | 53 | +26 | 2 of 10 | 7 of 10 | +376 | -13 |
| Mine | Tomb Kings of Khemri | 1 | 130 | 0 | 6.0 | 1.0 | 0 | 44 | -44 | 1 of 6 | 3 of 6 | - | -44 |
| Mine | Wood Elf Realms | 1 | 55 | 328 | 8.0 | 1.2 | 41 | 42 | -2 | 1 of 8 | 3 of 8 | +112 | -39 |
| **Mine** | all armies | 6 | 76 | 326 | 6.3 | 1.2 | 52 | 52 | -1 | 9 of 38 | 21 of 38 | +92 | -21 |
| Opponent | Beastmen Brayherds | 1 | 185 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 0 of 3 | 2 of 3 | - | +0 |
| Opponent | Dwarfen Mountain Holds | 2 | 68 | 397 | 8.0 | 1.1 | 50 | 0 | +50 | 2 of 16 | 12 of 16 | +28 | +53 |
| Opponent | Empire of Man | 1 | 95 | 184 | 6.0 | 1.0 | 31 | 69 | -38 | 1 of 6 | 3 of 6 | - | -38 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 410 | 5.0 | 1.2 | 82 | 0 | +82 | 1 of 5 | 4 of 5 | +0 | +102 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 892 | 4.0 | 1.5 | 223 | 19 | +204 | 1 of 4 | 4 of 4 | +132 | +228 |
| **Opponent** | all armies | 6 | 69 | 380 | 5.7 | 1.1 | 67 | 14 | +53 | 5 of 34 | 25 of 34 | +47 | +53 |


## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | E2, N3 |
| Charmed Shield | Opponent | E1, N2, N3 |
| Paymaster's Coin | Opponent | N3 |

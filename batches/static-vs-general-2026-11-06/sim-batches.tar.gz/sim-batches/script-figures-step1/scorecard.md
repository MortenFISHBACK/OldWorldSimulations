# Doctrine scorecard: script-figures-step1

### Scorecard: script-figures-step1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| C1 | 1 | 1 | Mine | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| C1 | 1 | 1 | Opponent | yes | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 395 |
| C2 | 2 | 1 | Mine | - | - | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| C2 | 2 | 1 | Opponent | - | - | 1 | 5 | 4 | 0 | 0 | 0 | 100 |
| C3 | 3 | 1 | Mine | yes | 6 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| C3 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 1010 |
| E1 | 1 | 1 | Mine | no | 0 | - | 5 | 0 | 0 | 0 | 0 | 0 |
| E1 | 1 | 1 | Opponent | no | 12 | 2 | 3 | 1 | 3 | 0 | 0 | 0 |
| E2 | 2 | 1 | Mine | - | - | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| E2 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 765 |
| E3 | 3 | 1 | Mine | yes | 2 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| E3 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| N1 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| N1 | 1 | 1 | Opponent | no | 5 | 2 | 5 | 2 | 0 | 0 | 0 | 448 |
| N2 | 2 | 1 | Mine | - | - | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| N2 | 2 | 1 | Opponent | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 55 |
| N3 | 3 | 1 | Mine | yes | 1 | 1 | 3 | 4 | 1 | 0 | 0 | 529 |
| N3 | 3 | 1 | Opponent | no | 6 | 3 | 3 | 1 | 0 | 0 | 0 | 375 |
| **Average** | | | Mine | 50% | 1.7 | 1.6 | 4.7 | 1.2 | 0.6 | 0.0 | 0.0 | 58.8 |
| **Average** | | | Opponent | 17% | 3.8 | 2.4 | 3.0 | 2.2 | 0.3 | 0.0 | 0.0 | 349.8 |

### Charged fights: script-figures-step1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 205 | 2.0 | 1.5 | 102 | 0 | +102 | 2 of 2 | 2 of 2 | +0 | +205 |
| Mine | Dwarfen Mountain Holds | 1 | 75 | 229 | 6.0 | 1.2 | 38 | 85 | -47 | 2 of 6 | 3 of 6 | +0 | -56 |
| Mine | Grand Cathay | 3 | 154 | 269 | 4.7 | 1.1 | 58 | 32 | +26 | 5 of 14 | 9 of 14 | +120 | +18 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 74 | 7.0 | 1.7 | 11 | 110 | -100 | 4 of 7 | 3 of 7 | -232 | -1 |
| Mine | Orc & Goblin Tribes | 1 | 160 | 744 | 7.0 | 1.1 | 106 | 45 | +62 | 4 of 7 | 3 of 7 | -152 | +97 |
| Mine | Tomb Kings of Khemri | 1 | 73 | 399 | 13.0 | 1.1 | 31 | 35 | -5 | 3 of 13 | 5 of 13 | +74 | -11 |
| Mine | Wood Elf Realms | 1 | 55 | 251 | 9.0 | 1.2 | 28 | 92 | -64 | 3 of 9 | 4 of 9 | -162 | -36 |
| **Mine** | all armies | 9 | 92 | 301 | 6.4 | 1.2 | 47 | 57 | -11 | 23 of 58 | 29 of 58 | -98 | +7 |
| Opponent | Beastmen Brayherds | 2 | 14 | 89 | 1.5 | 1.0 | 59 | 134 | -75 | 1 of 3 | 1 of 3 | - | -75 |
| Opponent | Dwarfen Mountain Holds | 3 | 100 | 112 | 5.0 | 1.2 | 22 | 12 | +11 | 4 of 15 | 9 of 15 | +71 | +1 |
| Opponent | Empire of Man | 1 | 430 | 180 | 3.0 | 1.0 | 60 | 0 | +60 | 0 of 3 | 3 of 3 | - | +60 |
| Opponent | Orc & Goblin Tribes | 2 | 18 | 564 | 1.5 | 1.0 | 376 | 0 | +376 | 0 of 3 | 1 of 3 | - | +376 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 892 | 5.0 | 1.0 | 178 | 15 | +163 | 2 of 5 | 5 of 5 | - | +163 |
| **Opponent** | all armies | 9 | 88 | 302 | 3.2 | 1.1 | 94 | 22 | +71 | 7 of 29 | 19 of 29 | +71 | +71 |


## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | E2, N3 |
| Charmed Shield | Opponent | C2, E1, N2, N3 |
| Flamestrike Wand | Mine | E3 |
| Paymaster's Coin | Opponent | N3 |

# Doctrine scorecard: h7-opp-dcce224-p2

### Scorecard: h7-opp-dcce224-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 1 | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0108 | 6 | 1 | Opponent | no | 3 | 6 | 0 | 0 | 0 | 0 | 0 | 36 |
| L0123 | 3 | 1 | Mine | yes | 4 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0123 | 3 | 1 | Opponent | yes | 5 | 2 | 6 | 1 | 0 | 0 | 0 | 72 |
| L0207 | 3 | 1 | Mine | no | 6 | - | 2 | 3 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 7 | 4 | 1 | 0 | 0 | 0 | 0 | 170 |
| L0224 | 2 | 1 | Mine | - | - | 1 | 3 | 4 | 0 | 0 | 0 | 251 |
| L0224 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 110 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 425 |
| **Average** | | | Mine | 33% | 3.7 | 3.2 | 1.6 | 2.8 | 0.0 | 0.0 | 0.0 | 106.2 |
| **Average** | | | Opponent | 33% | 5.0 | 4.0 | 1.4 | 1.6 | 0.0 | 0.0 | 0.0 | 140.6 |

### KPIs: h7-opp-dcce224-p2

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 5 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 19) | 48% (13 of 27) | 28% (13 of 46) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 100% | 67% (4 of 6); on the table 67% | 75% (9 of 12); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 75% (3 of 4); on the table 75% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 100% | 75% (9 of 12); on the table 75% | 78% (14 of 18); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 25% (28 of 114) | 42% (5 of 12) | 26% (33 of 126) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 31% (28 of 89) | 42% (5 of 12) | 33% (33 of 101) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (6 of 12) | - | 50% (6 of 12) |
| Points that never fought | lower | 63% (6034 of 9597) | 52% (5246 of 9997) | 58% (11280 of 19594) |
|   infantry points that never fought | lower | 63% (1997 of 3176) | 65% (1193 of 1845) | 64% (3190 of 5021) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (19 of 30) | 48% (20 of 42) | 54% (39 of 72) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 2.6 uses a game | 0.0 uses a game | 83% (5 of 6); 1.3 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.6 uses a game | 100% (1 of 1); 0.2 uses a game | 100% (3 of 3); 0.9 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 71% (5 of 7); 1.0 uses a game | 0% (0 of 3); 0.0 uses a game | 50% (5 of 10); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (3702 of 6757) | 42% (3650 of 8652) | 48% (7352 of 15409) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 8.2 (48%) | 1.0 (71%) | 9.2 (49%) |
| MARCHED: its unit marched | 4.0 (23%) | 0.2 (14%) | 4.2 (23%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (14%) | 0.2 (1%) |
| IN COMBAT: engaged in combat | 3.0 (17%) | 0.0 (0%) | 3.0 (16%) |
| GONE: slain | 2.0 (12%) | 0.0 (0%) | 2.0 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.4 | 3.6 | 6.6 | 3.4 |
| not cast | 3.4 | 2.2 | 7.2 | 18.6 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.8 (82%) | 0.0 (0%) | 9.2 (49%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.2 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (12%) | 0.4 (18%) | 1.2 (17%) | 3.0 (16%) | 0.0 (0%) |
| GONE: slain | 0.2 (6%) | 0.0 (0%) | 1.2 (17%) | 2.0 (11%) | 2.2 (11%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.8 (82%) | 0.0 (0%) | 4.8 (67%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.2 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 5.0 a game | 0.2 a game | 2.6 a game |
| stood (cast and not dispelled) | 64% (16 of 25) | 100% (1 of 1) | 65% (17 of 26) |
| the unit moved after it | 62% (10 of 16) | 100% (1 of 1) | 65% (11 of 17) |
| it charged on its next turn | 6% (1 of 16) | 0% (0 of 1) | 6% (1 of 17) |
| the enemy charged it first | 19% (3 of 16) | 0% (0 of 1) | 18% (3 of 17) |
| it fought by the end of its next turn | 6% (1 of 16) | 0% (0 of 1) | 6% (1 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 16) | 0% (0 of 1) | 0% (0 of 17) |
| none of these (no charge, no fight, no charge escaped) | 75% (12 of 16) | 100% (1 of 1) | 76% (13 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (31 of 45) | 48% (68 of 143) | 53% (99 of 188) |
|   cavalry | - | 52% (16 of 31) | 52% (16 of 31) |
|   character | - | 0% (0 of 6) | 0% (0 of 6) |
|   chariot | 75% (6 of 8) | 75% (9 of 12) | 75% (15 of 20) |
|   infantry | 67% (14 of 21) | 65% (20 of 31) | 65% (34 of 52) |
|   war machine | 69% (11 of 16) | 37% (23 of 63) | 43% (34 of 79) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.2 (43%) | 2.6 (17%) | 3.8 (21%) |
| CHARGED: it charged | 0.2 (7%) | 1.2 (8%) | 1.4 (8%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.2 (7%) | 0.8 (5%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.8 (29%) | 2.8 (19%) | 3.6 (20%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.4 (9%) | 1.4 (8%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.6 (4%) | 0.6 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.4 (14%) | 4.8 (32%) | 5.2 (29%) |
| OTHER BAR | 0.0 (0%) | 0.6 (4%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 4.0 | 56% | 14.0 pts | 70 pts |
| chariot | 3.0 | 4.0 | 40% | 28.7 pts | 86 pts |
| infantry | 7.8 | 4.6 | 62% | 7.4 pts | 57 pts |
| war machine | 6.8 | 9.0 | 44% | 23.6 pts | 161 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.4 | 2.7 |
| Charges that made contact a game | 1.6 | 2.8 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 1.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.23 contact (35 units) | 0.44 declared, 0.39 contact (36 units) | 0.37 declared, 0.31 contact (71 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 17% (1 of 6) | 25% (1 of 4) | - | 20% (2 of 10) |
| Character in a unit | 82% (9 of 11) | 86% (6 of 7) | - | 83% (15 of 18) |
| Character on its own | 67% (2 of 3) | 0% (0 of 2) | 25% (1 of 4) | 33% (3 of 9) |
| Chariot | - | 25% (1 of 4) | - | 25% (1 of 4) |
| Infantry | 100% (1 of 1) | 33% (3 of 9) | 0% (0 of 2) | 33% (4 of 12) |
| Monster | 50% (2 of 4) | - | - | 50% (2 of 4) |
| War Machines | 79% (11 of 14) | 100% (1 of 1) | - | 80% (12 of 15) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 83% (5 of 6); on the table 100% | 25% (25 of 102) | 53% | 55% (12 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 2.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 1 | - | 25% (3 of 12) | 100% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Empire of Man | 3 | 67% (2 of 3); on the table 67% | 42% (5 of 12) | 63% | 43% (13 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 16% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 71% (5 of 7); on the table 71% | - | 56% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h7-opp-dcce224-p2, 5 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 78% (7) | 60% (3) | 71% (10) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.40 | 1.40 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.40 | 0.40 | 0.80 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.40 | 0.40 |

### Quality by phase: h7-opp-dcce224-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.8 | 1.6 |
| Strategy | Charge objectives carried out (made contact) | 50% (3 of 6) | 75% (12 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (13 of 28) | 45% (27 of 60) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 25% (1 of 4) |
| Strategy | Joined characters whose unit fought | 24% (4 of 17) | 56% (5 of 9) |
| Strategy | Lone characters that fought | 60% (6 of 10) | 58% (7 of 12) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 2.8 | 1.6 |
| Movement | Points that never moved of their own | 106.2 | 140.6 |
| Movement | Fights charged into per game | 1.4 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 4, net +76 | 1 of 13, net -96 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 1 of 13, net -136 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 2 of 13, net +88 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +60 | 2 of 13, net +85 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.2 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (14 of 21) | 57% (27 of 47) |
| Shooting | Points destroyed by shooting units | 7.2 | 39.0 |
| Shooting | War machine shots | 2.2 | 4.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (6 of 11) | 30% (7 of 23) |
| Shooting | Points destroyed by war machines | 0.0 | 124.0 |
| Magic | Magic missiles cast | 3.4 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 24% (4 of 17) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 8.2 | 2.2 |
| Magic | Wounds caused by other spells | 1.6 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 50.0 | 16.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 1.8 / 0.0 | 2.0 / 0.8 / 0.2 / 0.0 |
| Combat | Points destroyed in combat | 332.6 | 149.6 |
| Combat | Points run down | 0.0 | 49.2 |
| Combat | Net points per charged fight, damage counted | +116 | +50 |
| Combat | Net per 100 charger points, damage counted | +42.4 | +22.6 |
| Combat | First round won (charged fights) | 71% | 69% |
| Combat | Net points per charged fight | +101 | +77 |
| Combat | Net points per supported fight / lone fight | +325 / +64 | +886 / +9 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 7 | 4 of 13 |
| Game | Points lost | 615.6 | 392.6 |
| Game | VP from objectives | 694.0 | 752.0 |
| Game | Lone holders (player turns) | 3.7 | 5.0 |

- Mine won / drew / lost: 1 / 1 / 3 of 5 ended games (of 5); mean margin (Mine - Opponent) -222 VP
- The side that went first won 2 of 4 games with a winner
- Points traded per game (both sides' losses): 1008
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h7-opp-dcce224-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +10.3 | 0.0 | 0.0 | 0.2 | +65.4 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.8 | +0.0 | 0.0 | 93.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.2 | +0.3 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -3.1 | 0.0 | 0.0 | 0.4 | -70.8 | 63.4 | 39.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.8 | +0.0 | 17.0 | 25.0 |
| CANNON PLANNED TARGET | 2.2 | +1.5 | 14.4 | 0.0 | 4.0 | +35.3 | 315.0 | 0.0 |
| CANNON SIGHT KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -5.7 | 6.0 | 0.0 |
| CAST JOB | 0.6 | +10.4 | 0.0 | 0.0 | 0.4 | +18.4 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.6 | +33.3 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 3.2 | +0.0 | 0.0 | 26.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.4 | +13.8 | 0.0 | 16.2 | 0.6 | +22.2 | 0.0 | 14.4 |
| CHAFF PASSED | - | - | - | - | 1.0 | +0.0 | 0.0 | 13.2 |
| CHARGE LOSSES | 6.6 | -399.4 | 0.0 | 139.8 | 6.0 | -204.6 | 0.0 | 0.0 |
| CHARGE NOT DECLARED | 0.4 | +0.0 | 12.0 | 62.0 | 0.2 | +0.0 | 17.0 | 0.0 |
| CHARGE NOW FIRST | 0.6 | +0.0 | 12.0 | 62.0 | 1.6 | +0.0 | 82.6 | 39.0 |
| CHARGER SLAIN LOST | 0.2 | -1.2 | 45.8 | 0.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHEAPEST HOLDER | 0.6 | -28.3 | 12.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 86.2 |
| CONVEYANCE SEARCH | 4.0 | +480.0 | 63.4 | 93.0 | 0.2 | +4.8 | 0.0 | 0.0 |
| COVER ONCE | 3.8 | -239.1 | 0.0 | 13.0 | 7.6 | -362.5 | 0.0 | 72.0 |
| DEPLOY BY FIGURES | 7.8 | -25.4 | 0.0 | 0.0 | 7.8 | -140.3 | 0.0 | 24.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 0.8 | +0.0 | 12.0 | 16.8 | 2.6 | +2.9 | 159.8 | 125.2 |
| FALLBACK BY WORTH | - | - | - | - | 0.8 | +0.0 | 0.0 | 7.2 |
| FALLS SHORT | 15.4 | +312.5 | 0.0 | 242.4 | 11.0 | +146.8 | 0.0 | 72.2 |
| FEATURE BUFFS | 4.4 | +123.2 | 0.0 | 6.0 | 1.0 | +29.2 | 0.0 | 12.0 |
| FIGHT TO THE END | 0.4 | +2.3 | 0.0 | 0.0 | 1.2 | +31.8 | 49.4 | 125.2 |
| FIRE IN ORDER | - | - | - | - | 0.2 | +0.0 | 22.0 | 0.0 |
| FIVE ACTION | 38.0 | +2002.4 | 92.6 | 508.2 | 50.4 | +3446.5 | 938.0 | 311.6 |
| FLANK NOT WEIGHED | 5.8 | +0.0 | 0.0 | 162.4 | 4.8 | +0.0 | 0.0 | 7.2 |
| FOLLOW UP WEIGHED | 0.6 | +406.4 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.2 | +14.6 | 57.8 | 78.8 | 3.2 | +199.9 | 250.4 | 125.2 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.4 | -41.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.4 | -23.6 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -0.7 | 0.0 | 0.0 | 0.4 | -14.6 | 24.0 | 0.0 |
| GROUND FLIERS | 0.2 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 0.8 | +19.1 | 7.2 | 0.0 | 1.6 | +48.3 | 51.0 | 0.0 |
| GUN MASK | - | - | - | - | 2.2 | +85.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 1.6 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.2 | +0.0 | 0.0 | 24.0 | 2.4 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 0.0 | 16.8 | - | - | - | - |
| HIS CHARGE DENIED | 0.6 | +7.2 | 12.0 | 0.0 | 0.6 | +154.4 | 143.8 | 0.0 |
| HIS CHARGE LIST | 4.4 | +0.0 | 0.0 | 37.8 | 3.2 | +0.0 | 0.0 | 40.4 |
| HIS LEGAL MOVES | 1.6 | +0.0 | 0.0 | 22.0 | 4.4 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 0.4 | -8.3 | 0.0 | 74.4 | 1.0 | -23.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.2 | +0.0 | 0.0 | 12.0 |
| HIS SHOT LIST | 20.4 | +1067.3 | 0.0 | 259.0 | 23.0 | +942.8 | 0.0 | 39.2 |
| HIS TURN DENIED | 0.4 | +17.5 | 0.0 | 78.8 | 0.8 | +37.4 | 13.0 | 125.2 |
| HOLD ODDS | - | - | - | - | 13.2 | +0.0 | 0.0 | 26.4 |
| HOLDER ASSIGNMENT | - | - | - | - | 14.8 | +1476.7 | 0.0 | 38.4 |
| HOLDER AT DEPLOYMENT | 0.8 | +144.3 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.6 | -12.0 | 12.0 | 62.0 | 2.8 | -117.4 | 123.6 | 125.2 |
| HUNT IN PAIRS | - | - | - | - | 1.4 | +115.9 | 0.0 | 14.0 |
| IDLE COST | 7.0 | -72.3 | 0.0 | 71.6 | 5.0 | -108.2 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.4 | -13.2 | 126.8 | 0.0 |
| KEEP FALLS | 0.2 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 0.6 | +17.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.4 | +0.0 | 150.2 | 169.4 | 7.8 | +0.0 | 136.2 | 361.2 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.2 | +9.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 2.0 | +159.1 | 0.0 | 0.0 | 0.6 | +60.7 | 0.0 | 0.0 |
| LOST CHARGE | 0.2 | -0.5 | 12.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.2 | -25.9 | 0.0 | 7.2 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +13.8 | 0.0 | 13.2 |
| MANOEUVRE | 2.0 | +26.4 | 0.0 | 23.0 | 1.4 | +14.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.4 | +41.8 | 0.0 | 0.0 | 0.2 | +2.5 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +78.1 | 0.0 | 16.2 | - | - | - | - |
| MARCH OVER CASTS | 0.4 | +43.6 | 0.0 | 16.2 | 0.2 | -8.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 7.0 | +127.9 | 0.0 | 180.4 | 4.8 | +105.2 | 0.0 | 13.2 |
| MISSILES IN THE MOVE | 4.8 | +297.0 | 0.0 | 96.6 | 1.4 | +31.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.6 | +214.8 | 0.0 | 66.4 | 1.8 | +19.1 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.0 | -27.3 | 63.4 | 67.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 1.4 | +137.8 | 0.0 | 22.0 | 4.4 | +409.9 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.4 | +22.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 2.6 | +133.5 | 0.0 | 17.0 | 7.4 | +288.0 | 0.0 | 60.2 |
| NEXT CHARGE BY LIST | 2.6 | -135.5 | 0.0 | 102.4 | 7.4 | -127.4 | 26.0 | 12.0 |
| NEXT OBJECTIVE NEARER | 4.4 | -242.2 | 0.0 | 17.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 0.4 | -14.2 | 12.0 | 0.0 | 2.6 | -82.7 | 216.0 | 125.2 |
| NOT TURNED | - | - | - | - | 0.4 | +0.0 | 0.0 | 7.2 |
| NOT WORTH A CAST | 0.2 | -0.1 | 0.0 | 0.0 | 1.6 | -0.6 | 0.0 | 0.0 |
| OFF BEST | - | - | - | - | 0.4 | -10.5 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 4.0 | +0.0 | 0.0 | 68.4 | 1.4 | +0.0 | 0.0 | 13.2 |
| ONE FIGHT FORMULA | 3.8 | -57.1 | 0.0 | 97.0 | 5.6 | -106.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.6 | -74.4 | 0.0 | 0.0 | 5.6 | -42.2 | 0.0 | 26.4 |
| ONE TARGET A SHOOTER | 17.0 | +487.1 | 0.0 | 173.6 | 14.0 | +480.8 | 0.0 | 13.2 |
| OPENS A LANE | - | - | - | - | 0.4 | +5.6 | 13.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.4 | +58.1 | 24.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.4 | +20.1 | 23.4 | 0.0 |
| PATHS CROSS | 3.8 | +136.0 | 0.0 | 16.2 | 3.8 | +84.4 | 0.0 | 0.0 |
| PLAN RESULT | 33.2 | +200.2 | 92.0 | 643.0 | 45.2 | +668.1 | 356.0 | 660.8 |
| QUARTER ODDS | - | - | - | - | 5.8 | +808.9 | 89.8 | 89.2 |
| RANDOM MOVE BY FIGURES | 2.4 | +131.8 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.4 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.2 | -9.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.2 | +218.4 | 0.0 | 118.0 | 0.8 | +22.2 | 0.0 | 12.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.2 | -0.6 | 0.0 | 0.0 | 0.4 | -0.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | +28.6 | 57.8 | 16.8 | 1.4 | +51.4 | 63.4 | 39.0 |
| RISK BY HIS FIGURE | 14.0 | -384.2 | 0.0 | 274.6 | 11.4 | -138.0 | 0.0 | 25.2 |
| RUN DOWN | 0.2 | -0.5 | 0.0 | 62.0 | 2.8 | -22.6 | 187.0 | 39.0 |
| SCOUT SPOT | 0.4 | +1.4 | 0.0 | 0.0 | 0.8 | -0.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.4 | -50.1 | 0.0 | 14.4 |
| SEARCH SPOT | 6.4 | +217.0 | 0.0 | 33.2 | 4.8 | +303.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +13.8 | 0.0 | 13.2 |
| SET-UP ANY TARGET | - | - | - | - | 0.2 | +5.7 | 0.0 | 0.0 |
| SET-UP MISSED | 0.2 | +22.7 | 0.0 | 26.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.0 | +30.2 | 13.2 | 34.0 | 1.0 | +40.7 | 32.4 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -5.6 | 0.0 | 0.0 | 1.0 | -12.4 | 121.4 | 62.0 |
| SHOT RISK POINTS | 12.0 | -3.8 | 0.0 | 202.6 | 14.0 | +139.3 | 0.0 | 40.4 |
| SHOTS IN THE MOVE | 7.2 | +153.8 | 0.0 | 63.0 | 19.0 | +477.2 | 0.0 | 135.2 |
| SPELL SETS UP CHARGE | 1.0 | +496.5 | 0.0 | 0.0 | 0.2 | +5.7 | 0.0 | 0.0 |
| SPELL WORTH | 0.8 | +9.3 | 0.0 | 0.0 | 2.0 | +24.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.4 | -31.9 | 80.2 | 0.0 |
| STAND AND SHOOT | 0.2 | -2.5 | 0.0 | 62.0 | 0.4 | -2.6 | 13.0 | 0.0 |
| STANDS FOR A REASON | 0.8 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 47.0 |
| STANDS STILL | 12.8 | +0.0 | 34.8 | 152.0 | 21.6 | +0.0 | 687.6 | 148.0 |
| STAY WORTH | 8.8 | +0.5 | 21.6 | 78.0 | 21.6 | +137.5 | 380.0 | 257.2 |
| SUPPORT NARROWED | 0.6 | +0.0 | 45.8 | 62.0 | 1.4 | +0.0 | 48.8 | 39.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.6 | +2.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.2 | +0.0 | 0.0 | 16.2 | 4.4 | +0.0 | 0.0 | 13.2 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -4.2 | 63.4 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 1.2 | +0.0 | 0.0 | 13.2 |
| TIED UP BY THE SUM | 0.2 | +5.1 | 12.0 | 0.0 | 1.2 | +91.6 | 80.8 | 0.0 |
| TIME ON OUR SIDE | 12.6 | +233.8 | 0.0 | 51.4 | 21.4 | +375.1 | 0.0 | 0.0 |
| WAITS AGAIN | 0.2 | +0.0 | 0.0 | 0.0 | 2.2 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +19.6 | 0.0 | 62.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.2 | +11.7 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +1.0 | 45.8 | 0.0 | 0.2 | -9.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.2 | +0.7 | 63.4 | 0.0 |
| WIDER SPREAD | 0.8 | +0.0 | 57.8 | 62.0 | 2.0 | -1.1 | 147.0 | 39.0 |
| WOUNDS ON THE RANKS | 2.4 | +232.4 | 0.0 | 126.8 | 1.8 | +66.4 | 0.0 | 0.0 |

### Rule changes: h7-opp-dcce224-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 76 | 76 | 76 | 15.20 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 74 | 74 | 69 | 13.80 | +4584 | +66.4 |
| SEARCH SPOT | 56 | 56 | 51 | 10.20 | +2603 | +51.0 |
| HIS SHOT LIST | 217 | 217 | 50 | 10.00 | +1115 | +22.3 |
| TIME ON OUR SIDE | 170 | 152 | 49 | 9.80 | +307 | +6.3 |
| DEPLOY BY FIGURES | 78 | 78 | 48 | 9.60 | +616 | +12.8 |
| ONE TARGET A SHOOTER | 155 | 155 | 42 | 8.40 | +411 | +9.8 |
| PATHS CROSS | 38 | 38 | 38 | 7.60 | +1102 | +29.0 |
| SHOT RISK POINTS | 130 | 130 | 25 | 5.00 | +449 | +18.0 |
| FIVE ACTION | 442 | 441 | 19 | 3.80 | +1474 | +77.6 |
| MOVE TO CHARGE COMPUTED | 29 | 29 | 18 | 3.60 | +1040 | +57.8 |
| MAX FOR POSITIONING | 59 | 58 | 14 | 2.80 | +54 | +3.9 |
| FALLS SHORT | 132 | 110 | 13 | 2.60 | +68 | +5.3 |
| HARD STAY DROPPED | 13 | 13 | 13 | 2.60 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 2.60 | +1099 | +84.5 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 2.40 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 1.80 | +0 | +0.0 |
| RISK BY HIS FIGURE | 127 | 127 | 9 | 1.80 | +901 | +100.1 |
| WOUNDS ON THE RANKS | 21 | 21 | 9 | 1.80 | +356 | +39.5 |
| IDLE COST | 60 | 48 | 8 | 1.60 | +122 | +15.3 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 1.40 | +0 | +0.0 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 1.40 | +0 | +0.0 |
| CHARGE LOSSES | 63 | 63 | 7 | 1.40 | +770 | +109.9 |
| FEATURE BUFFS | 27 | 27 | 7 | 1.40 | +104 | +14.9 |
| MANOEUVRE | 17 | 17 | 7 | 1.40 | +213 | +30.4 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 7 | 1.40 | +111 | +15.8 |
| MISSILES IN THE MOVE | 31 | 24 | 6 | 1.20 | +129 | +21.4 |
| NEXT CHARGE BY LIST | 50 | 50 | 6 | 1.20 | +80 | +13.4 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 6 | 1.20 | +659 | +109.9 |
| SCOUT WAITS | 6 | 6 | 6 | 1.20 | +0 | +0.0 |
| SHOTS IN THE MOVE | 131 | 115 | 6 | 1.20 | +175 | +29.2 |
| CHAFF PASSED | 5 | 5 | 5 | 1.00 | +0 | +0.0 |
| COVER ONCE | 57 | 45 | 5 | 1.00 | +19 | +3.8 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.00 | +0 | +0.0 |
| CAST JOB | 5 | 5 | 4 | 0.80 | +37 | +9.1 |
| CHAFF IN THE MOVE | 5 | 5 | 4 | 0.80 | +34 | +8.4 |
| FOUR ROUNDS | 22 | 21 | 4 | 0.80 | +111 | +27.7 |
| ONE OBJECTIVE FORMULA | 51 | 37 | 4 | 0.80 | +110 | +27.6 |
| REDIRECT COUNTER | 20 | 18 | 4 | 0.80 | +433 | +108.2 |
| TIED UP BY THE SUM | 7 | 6 | 4 | 0.80 | +188 | +46.9 |
| CANNON PLANNED TARGET | 31 | 31 | 3 | 0.60 | -44 | -14.8 |
| CHARGE NOT DECLARED | 3 | 3 | 3 | 0.60 | -264 | -88.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 0.60 | +2032 | +677.3 |
| LANE BY FIGURES | 3 | 3 | 3 | 0.60 | +86 | +28.5 |
| MARCH BY THE SUM | 3 | 3 | 3 | 0.60 | +221 | +73.8 |
| MARCH CHECK | 5 | 5 | 3 | 0.60 | +69 | +23.0 |
| NEARER NOT NEEDED | 50 | 49 | 3 | 0.60 | +108 | +35.9 |
| NEXT OBJECTIVE NEARER | 22 | 22 | 3 | 0.60 | +39 | +13.0 |
| ONE FIGHT FORMULA | 47 | 27 | 3 | 0.60 | +13 | +4.5 |
| RISK BY ARC | 12 | 11 | 3 | 0.60 | +92 | +30.8 |
| STAY WORTH | 152 | 141 | 3 | 0.60 | +10 | +3.2 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.40 | +379 | +189.3 |
| CHARGE NOW FIRST | 11 | 11 | 2 | 0.40 | -94 | -47.1 |
| HOLDER AT DEPLOYMENT | 4 | 4 | 2 | 0.40 | +97 | +48.3 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.40 | +110 | +55.1 |
| OFF BEST | 2 | 2 | 2 | 0.40 | -53 | -26.3 |
| QUARTER ODDS | 29 | 29 | 2 | 0.40 | +228 | +113.8 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.40 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.20 | -29 | -28.7 |
| CASTING BLOCK | 3 | 3 | 1 | 0.20 | +0 | +0.2 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.20 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.20 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.20 | +0 | +0.0 |
| FRIEND SHOOTS FIRST | 2 | 2 | 1 | 0.20 | +10 | +10.2 |
| GUN MASK | 11 | 11 | 1 | 0.20 | +6 | +6.2 |
| HIS CHARGE DENIED | 6 | 6 | 1 | 0.20 | +357 | +357.0 |
| HIS MOVE AND SHOT | 7 | 7 | 1 | 0.20 | +14 | +14.2 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.20 | +24 | +23.7 |
| HUNT IN PAIRS | 7 | 2 | 1 | 0.20 | +38 | +38.3 |
| KEEP FALLS | 1 | 1 | 1 | 0.20 | +10 | +9.7 |
| OPENS UP | 2 | 2 | 1 | 0.20 | +72 | +72.2 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.20 | +28 | +28.3 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.20 | +46 | +46.4 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.20 | +4 | +3.7 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.20 | +5 | +5.0 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.20 | +24 | +23.7 |
| WAR ENGINE JOBS | 1 | 1 | 1 | 0.20 | -2 | -2.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.20 | +55 | +55.1 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 3 | 3 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 21 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 17 | 16 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 53 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 23 | 23 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 38 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 30 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 3 | 3 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 41 | 41 | 0 | 0.00 | - | - |
| HOLD ODDS | 66 | 66 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 16 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 42 | 31 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 15 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 9 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 27 | 27 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 392 | trace | - | - | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 172 | 172 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 10 | 10 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 38 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 6 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WIDER SPREAD | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: h7-opp-dcce224-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.20 | 19.8 |
| CHARGE NOT DECLARED | rule | 0.40 | 0.20 | 88.0 |
| CHARGE NOW FIRST | rule | - | 0.40 | 47.1 |
| AFTERMATH BAND | gate | - | 0.20 | 1.1 |
| CANNON PLANNED TARGET | rule | - | 0.20 | 44.4 |
| CARRIES OUT SET-UP | rule | - | 0.20 | 28.7 |
| JOB FIRST | gate | - | 0.20 | 51.4 |
| PATHS CROSS | rule | - | 0.20 | 8.3 |
| WAR ENGINE JOBS | rule | 0.20 | - | 2.0 |

### Plans: h7-opp-dcce224-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.2 | 50% | 70 | 64 | 92% |
| Mine | move | 27.4 | 93% | 1638 | 0 | 0% |
| Mine | shoot | 4.6 | 74% | 176 | 136 | 77% |
| Opponent | charge | 2.4 | 75% | 424 | 113 | 27% |
| Opponent | join | 1.0 | 100% | 41 | 0 | 0% |
| Opponent | move | 31.4 | 98% | 1747 | 0 | 0% |
| Opponent | shoot | 9.6 | 71% | 354 | 555 | 157% |
| Opponent | support | 0.8 | 75% | 2 | 0 | 0% |

### Battle groups: h7-opp-dcce224-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.2 | 50% | 75% | 0% | - | 12% | 0% | 12% | 75% | 0% |
| Opponent | REDIRECT COUNTER | 0.8 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h7-opp-dcce224-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 82 | 75% | 2.0 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Mine | Character | 22 | 21 (22) | 21 | 0 | 31 | 23% | 2.4 | 0 (3) | 28 (11) | 0 (2) | - | 20 (16) |
| Mine | Clean-up | 6 | 0 (6) | 0 | 0 | 33 | 50% | 3.7 | 0 (3) | 0 (2) | 0 (1) | 0 (2) | 0 (4) |
| Mine | Fast Hammer | 4 | 85 (4) | 85 | 0 | 75 | 25% | 3.3 | 170 (2) | 0 (2) | - | 71 (1) | 90 (3) |
| Mine | Hammer | 13 | 63 (13) | 27 | 36 | 24 | 31% | 2.7 | 0 (2) | 93 (9) | 11 (2) | 5 (3) | 79 (10) |
| Mine | Holder | 6 | 39 (6) | 0 | 39 | 32 | 83% | 4.0 | 220 (1) | 0 (4) | 0 (1) | 220 (1) | 0 (5) |
| Mine | Shooter | 4 | 208 (4) | 0 | 208 | 50 | 0% | 2.0 | 138 (1) | 162 (2) | 369 (1) | 215 (3) | 185 (1) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 42 | 0% | 1.2 | 0 (1) | 0 (3) | - | - | 0 (4) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 36 | 20% | 3.8 | 0 (1) | 0 (4) | - | - | 0 (5) |
| Opponent | Chaff | 6 | 120 (6) | 0 | 120 | 81 | 33% | 2.2 | 68 (2) | 0 (1) | 192 (3) | 135 (5) | 0 (1) |
| Opponent | Character | 18 | 30 (18) | 30 | 0 | 20 | 33% | 3.2 | 36 (8) | 29 (6) | 0 (4) | 32 (12) | 27 (6) |
| Opponent | Clean-up | 2 | 45 (2) | 0 | 45 | 0 | 50% | 2.0 | 76 (1) | 0 (1) | - | 45 (2) | - |
| Opponent | Fast Hammer | 9 | 39 (9) | 22 | 17 | 17 | 22% | 4.0 | 70 (4) | 27 (5) | - | 62 (5) | 23 (4) |
| Opponent | Hammer | 4 | 122 (4) | 70 | 52 | 0 | 25% | 3.0 | - | 165 (3) | 16 (1) | 122 (4) | - |
| Opponent | Holder | 3 | 39 (3) | 0 | 39 | 0 | 67% | 6.0 | - | 98 (1) | 0 (2) | - | 39 (3) |
| Opponent | Shooter | 8 | 73 (8) | 11 | 62 | 46 | 12% | 2.0 | 28 (2) | 180 (3) | 31 (3) | 96 (3) | 46 (5) |
| Opponent | War machine | 11 | 34 (11) | 34 | 0 | 27 | 0% | 3.4 | 34 (2) | 49 (5) | 16 (4) | 31 (2) | 35 (9) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 35 | 33% | 3.0 | - | 0 (1) | 0 (1) | 0 (2) | - |

### Charged fights: h7-opp-dcce224-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 62 | 178 | 1.8 | 1.1 | 101 | 0 | +101 | 1 of 7 | 5 of 7 | +325 | +64 |
| Mine | Chaos Dwarfs | 1 | 36 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 5 | 57 | 142 | 1.4 | 1.1 | 101 | 0 | +101 | 1 of 7 | 5 of 7 | +325 | +64 |
| Opponent | Empire of Man | 3 | 299 | 341 | 1.0 | 1.3 | 341 | 0 | +341 | 1 of 3 | 3 of 3 | +886 | +68 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 607 | 6.0 | 1.0 | 101 | 138 | -37 | 3 of 6 | 2 of 6 | - | -37 |
| Opponent | Vampire Counts | 1 | 0 | 196 | 4.0 | 1.0 | 49 | 0 | +49 | 0 of 4 | 4 of 4 | - | +49 |
| **Opponent** | all armies | 5 | 179 | 365 | 2.6 | 1.1 | 140 | 64 | +77 | 4 of 13 | 9 of 13 | +886 | +9 |

### Effective charges: h7-opp-dcce224-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 3 (net +76) | 0 | 0 | 0 | 0 | 1 (net +60) | 3 | 0% (0 of 4) |
| Opponent | Empire of Man | 3 | 0 | 0 | 0 | 2 (net +469) | 0 | 1 (net +85) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 6 | 1 (net -96) | 1 (net -131) | 1 (net -136) | 2 (net +38) | 1 (net +65) | 0 | 0 | 17% (1 of 6) |
| Opponent | Vampire Counts | 4 | 0 | 0 | 0 | 2 (net +0) | 1 (net +111) | 1 (net +85) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: h7-opp-dcce224-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 63 | 133 | +76 | 76 | 20 | +56 | +89.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 85 | 60 | +60 | 60 | 0 | +60 | +70.6 |
| Mine | No odds | 3 | 547 | 205 | +140 | 202 | 8 | +194 | +35.5 |
| Mine | All fights | 7 | 274 | 154 | +101 | 128 | 12 | +116 | +42.4 |
| Opponent | Long shot (under 50%) | 1 | 431 | 501 | -96 | 335 | 431 | -96 | -22.3 |
| Opponent | 50-54% | 1 | 195 | 322 | -131 | 130 | 261 | -131 | -67.2 |
| Opponent | Effective (55-75%) | 1 | 440 | 322 | -136 | 16 | 429 | -413 | -93.9 |
| Opponent | 76-89% | 6 | 170 | 114 | +169 | 169 | 11 | +158 | +92.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 120 | 85 | +85 | 85 | 0 | +85 | +71.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 284 | 48 | +88 | 88 | 0 | +88 | +30.9 |
| Opponent | All fights | 13 | 223 | 161 | +77 | 142 | 91 | +50 | +22.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h7-opp-dcce224-p2 | move | 30 | 4 (13%) | 3 (10%) | 2 (7%) | 24 (80%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224 |
| Invocation of Nehek | Opponent | L0224 |
| Ring of Doom | Mine | L0207, L0224 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

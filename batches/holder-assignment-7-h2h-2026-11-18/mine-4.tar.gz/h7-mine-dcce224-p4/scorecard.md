# Doctrine scorecard: h7-mine-dcce224-p4

### Scorecard: h7-mine-dcce224-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 8 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 6 | 3 | 3 | 3 | 0 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 0 | 6 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0216 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 100 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 370 |
| L0316 | 4 | 1 | Opponent | no | 7 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 4.0 | 0.2 | 2.0 | 0.0 | 0.0 | 0.0 | 135.0 |
| **Average** | | | Opponent | 25% | 3.8 | 2.5 | 2.0 | 1.5 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: h7-mine-dcce224-p4

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 4 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (5 of 19) | 0% (0 of 20) | 13% (5 of 39) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 36% (32 of 90) | 17% (1 of 6) | 34% (33 of 96) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 37% (26 of 70) | 17% (1 of 6) | 36% (27 of 76) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (1 of 1) | 90% (9 of 10) | 91% (10 of 11) |
| Points that never fought | lower | 48% (3695 of 7698) | 59% (4733 of 7999) | 54% (8428 of 15697) |
|   infantry points that never fought | lower | 56% (1543 of 2739) | 76% (1280 of 1679) | 64% (2823 of 4418) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (15 of 24) | 44% (12 of 27) | 53% (27 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 3.0 uses a game | 50% (1 of 2); 1.2 uses a game | 83% (5 of 6); 2.1 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.2 uses a game | 0.0 uses a game | 100% (2 of 2); 0.6 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (3 of 5); 0.8 uses a game | 100% (2 of 2); 0.5 uses a game | 71% (5 of 7); 0.6 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (3286 of 5559) | 44% (3075 of 6976) | 51% (6361 of 12535) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.5 (38%) | 1.0 (80%) | 6.5 (41%) |
| MARCHED: its unit marched | 3.5 (24%) | 0.2 (20%) | 3.8 (24%) |
| CHARGED: its unit charged | 0.5 (3%) | 0.0 (0%) | 0.5 (3%) |
| IN COMBAT: engaged in combat | 1.0 (7%) | 0.0 (0%) | 1.0 (6%) |
| REAR RANK: in a rear rank | 1.0 (7%) | 0.0 (0%) | 1.0 (6%) |
| GONE: slain | 2.5 (17%) | 0.0 (0%) | 2.5 (16%) |
| STUPIDITY: Stupidity | 0.5 (3%) | 0.0 (0%) | 0.5 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 7.8 | 4.5 | 8.2 | 1.2 |
| not cast | 8.8 | 4.5 | 15.8 | 16.8 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.2 (6%) | 6.5 (41%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.8 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.5 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.5 (11%) | 1.0 (6%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.8 (9%) | 0.0 (0%) | 1.0 (6%) | 0.0 (0%) |
| GONE: slain | 1.2 (14%) | 0.0 (0%) | 2.5 (16%) | 2.5 (15%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.5 (11%) | 0.5 (3%) | 0.5 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.5 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 6.2 (71%) | 3.2 (72%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.8 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 4.5 a game | 1.2 a game | 2.9 a game |
| stood (cast and not dispelled) | 78% (14 of 18) | - | 78% (14 of 18) |
| the unit moved after it | 71% (10 of 14) | - | 71% (10 of 14) |
| it charged on its next turn | 0% (0 of 14) | - | 0% (0 of 14) |
| the enemy charged it first | 14% (2 of 14) | - | 14% (2 of 14) |
| it fought by the end of its next turn | 0% (0 of 14) | - | 0% (0 of 14) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (2 of 14) | - | 14% (2 of 14) |
| none of these (no charge, no fight, no charge escaped) | 71% (10 of 14) | - | 71% (10 of 14) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (39 of 49) | 39% (33 of 84) | 54% (72 of 133) |
|   cavalry | - | 41% (7 of 17) | 41% (7 of 17) |
|   character | - | 21% (4 of 19) | 21% (4 of 19) |
|   chariot | 75% (9 of 12) | 50% (2 of 4) | 69% (11 of 16) |
|   infantry | 79% (19 of 24) | 38% (8 of 21) | 60% (27 of 45) |
|   war machine | 85% (11 of 13) | 52% (12 of 23) | 64% (23 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.2 (50%) | 3.2 (25%) | 4.5 (30%) |
| CHARGED: it charged | 0.0 (0%) | 0.5 (4%) | 0.5 (3%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (2%) | 0.2 (2%) |
| MOVED: a war machine that moved | 0.5 (20%) | 2.0 (16%) | 2.5 (16%) |
| NO TARGET IN RANGE | 0.2 (10%) | 4.0 (31%) | 4.2 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.8 (6%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.5 (20%) | 1.2 (10%) | 1.8 (11%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.2 (2%) | 0.2 (2%) |
| OTHER BAR | 0.0 (0%) | 0.5 (4%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.2 | 88% | 5.5 pts | 11 pts |
| character | 1.2 | 0.2 | 80% | 1.6 pts | 2 pts |
| chariot | 2.8 | 2.8 | 55% | 35.3 pts | 97 pts |
| infantry | 8.2 | 1.8 | 79% | 4.3 pts | 36 pts |
| war machine | 5.8 | 5.2 | 57% | 9.5 pts | 55 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.2 | 4.2 | 2.8 |
| Charges that made contact a game | 0.8 | 3.2 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.19 declared, 0.12 contact (26 units) | 0.59 declared, 0.45 contact (29 units) | 0.40 declared, 0.29 contact (55 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 4) | - | 0% (0 of 1) | 0% (0 of 5) |
| Character in a unit | 60% (3 of 5) | 60% (3 of 5) | - | 60% (6 of 10) |
| Character on its own | - | 60% (3 of 5) | 50% (3 of 6) | 55% (6 of 11) |
| Chariot | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| Infantry | 50% (2 of 4) | 30% (3 of 10) | - | 36% (5 of 14) |
| Monster | 100% (3 of 3) | - | - | 100% (3 of 3) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 67% (2 of 3); on the table 67% | 31% (26 of 84) | 38% | 50% (8 of 16) | 100% (4 of 4); 4.0 uses a game | 100% (2 of 2); 1.7 uses a game | 75% (3 of 4); 1.0 uses a game |
| Chaos Dwarfs | 1 | - | 100% (6 of 6) | 76% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 44% | 29% (2 of 7) | 50% (1 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (1 of 1); on the table 100% | - | 56% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Warriors of Chaos | 1 | - | - | 82% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h7-mine-dcce224-p4, 4 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (5) | 0% (0) | 45% (5) |
| ...free all their last turn and able to turn (per game) | 0.25 | 0.00 | 0.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 1.00 | 0.00 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.50 | 0.00 | 0.50 |

### Quality by phase: h7-mine-dcce224-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.5 | 2.8 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 25% (4 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (12 of 28) | 40% (8 of 20) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 59% (10 of 17) | 50% (1 of 2) |
| Strategy | Lone characters that fought | 50% (2 of 4) | 50% (5 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 1.5 |
| Movement | Points that never moved of their own | 135.0 | 110.0 |
| Movement | Fights charged into per game | 0.5 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net +0 | 3 of 11, net +90 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 2 of 11, net +115 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 3 of 11, net +49 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +0 | 1 of 11, net +170 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.0 | 6.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (12 of 28) | 52% (14 of 27) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 2.8 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 18% (2 of 11) | 17% (2 of 12) |
| Shooting | Points destroyed by war machines | 20.0 | 0.0 |
| Magic | Magic missiles cast | 5.2 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (7 of 21) | - |
| Magic | Wounds caused by magic missiles | 12.0 | 3.0 |
| Magic | Wounds caused by other spells | 0.2 | - |
| Magic | Points destroyed by magic (all spells) | 127.8 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.2 / 0.0 / 0.8 / 0.0 | 1.5 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 58.2 | 305.8 |
| Combat | Points run down | 0.0 | 65.0 |
| Combat | Net points per charged fight, damage counted | +90 | +62 |
| Combat | Net per 100 charger points, damage counted | +40.7 | +19.6 |
| Combat | First round won (charged fights) | 100% | 69% |
| Combat | Net points per charged fight | +0 | +81 |
| Combat | Net points per supported fight / lone fight | +0 / +0 | - / +81 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 4 of 13 |
| Game | Points lost | 359.5 | 266.0 |
| Game | VP from objectives | 715.0 | 667.5 |
| Game | Lone holders (player turns) | 3.0 | 3.8 |

- Mine won / drew / lost: 1 / 1 / 2 of 4 ended games (of 4); mean margin (Mine - Opponent) +17 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 626
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h7-mine-dcce224-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +27.4 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.2 | +0.0 | 0.0 | 120.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.5 | -9.3 | 48.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.5 | -89.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.2 | +0.0 | 0.0 | 27.5 | 0.8 | +0.0 | 62.8 | 0.0 |
| CANNON PLANNED TARGET | 2.5 | +9.8 | 80.0 | 120.0 | 2.2 | +37.8 | 0.0 | 50.0 |
| CANNON SIGHT KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.5 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.8 | +69.4 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 3.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.2 | +47.9 | 0.0 | 21.2 | 0.8 | +85.3 | 0.0 | 15.8 |
| CHAFF PASSED | - | - | - | - | 0.8 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.8 | -126.1 | 0.0 | 42.5 | 5.8 | -262.2 | 0.0 | 0.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.8 | +0.0 | 41.5 | 15.8 |
| CHARGE NOW FIRST | - | - | - | - | 2.5 | +0.0 | 182.8 | 49.8 |
| CHARGER SLAIN LOST | 0.2 | -13.7 | 0.0 | 0.0 | 0.2 | -0.4 | 27.5 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 0.0 | 28.8 |
| CHEAPEST HOLDER | - | - | - | - | 1.0 | -29.2 | 35.0 | 99.5 |
| CONVEYANCE SEARCH | 3.2 | +314.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 11.8 | -1470.0 | 0.0 | 70.5 | 3.2 | -168.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.5 | +76.4 | 0.0 | 0.0 | 7.5 | -17.0 | 0.0 | 15.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +13.3 | 57.5 | 0.0 |
| ENGINEER BY LORE | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 0.8 | +0.0 | 0.0 | 0.0 | 2.2 | +0.0 | 142.5 | 15.8 |
| FALLBACK BY WORTH | 0.5 | +0.0 | 0.0 | 21.2 | - | - | - | - |
| FALLS SHORT | 9.2 | +133.4 | 0.0 | 33.2 | 19.2 | +293.9 | 0.0 | 223.2 |
| FEATURE BUFFS | 6.2 | +329.2 | 0.0 | 0.0 | 1.5 | +53.5 | 0.0 | 57.5 |
| FIGHT TO THE END | - | - | - | - | 1.0 | +58.6 | 85.0 | 0.0 |
| FIVE ACTION | 38.8 | +4398.9 | 108.8 | 260.8 | 46.8 | +3379.6 | 365.8 | 416.2 |
| FLANK NOT WEIGHED | 10.2 | +0.0 | 0.0 | 54.5 | 3.0 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.8 | +41.5 | 0.0 | 0.0 | 4.0 | +364.6 | 303.0 | 65.5 |
| FRIEND SHOOTS FIRST | 0.2 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.5 | +6.5 | 0.0 | 49.8 |
| GUN FIGURES | 1.5 | +75.1 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 2.2 | +77.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.5 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.2 | +0.0 | 0.0 | 16.2 | 2.0 | +0.0 | 0.0 | 7.5 |
| HELPER ALREADY ASKED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 5.5 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 42.5 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 5.5 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 0.5 | -10.4 | 0.0 | 0.0 | 2.5 | -152.9 | 0.0 | 28.8 |
| HIS ONE QUARTER | 0.8 | +0.0 | 0.0 | 16.2 | - | - | - | - |
| HIS RANDOM MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 16.8 | +638.8 | 0.0 | 93.0 | 20.0 | +1518.0 | 0.0 | 113.0 |
| HIS TURN DENIED | 0.2 | +1.2 | 0.0 | 0.0 | 2.5 | +63.4 | 204.2 | 15.8 |
| HOLD ODDS | 19.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLDER ASSIGNMENT | 16.5 | +2068.3 | 0.0 | 16.2 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 2.0 | +277.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.2 | -5.4 | 0.0 | 0.0 | 3.5 | -220.5 | 303.0 | 49.8 |
| IDLE COST | 2.5 | -13.3 | 0.0 | 21.2 | 8.8 | -147.4 | 0.0 | 49.2 |
| KEEP FALLS | 0.2 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 1.2 | +34.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 169.0 | 16.2 | 2.8 | +0.0 | 16.2 | 20.0 |
| LONE WIZARD KEPT IN | 2.0 | +149.3 | 0.0 | 0.0 | 0.5 | +30.0 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.5 | +0.9 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +75.4 | 0.0 | 0.0 | 0.8 | +25.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.8 | +107.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.5 | +33.6 | 0.0 | 0.0 | 0.2 | +1.0 | 0.0 | 49.8 |
| MARCH CHECK | 1.5 | +65.8 | 0.0 | 0.0 | 0.8 | +58.8 | 0.0 | 49.8 |
| MARCH OVER CASTS | 0.8 | -8.5 | 0.0 | 0.0 | 0.2 | +54.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 7.8 | +126.2 | 0.0 | 0.0 | 4.8 | +37.9 | 0.0 | 56.2 |
| MISSILES IN THE MOVE | 7.8 | +701.8 | 0.0 | 20.2 | 1.2 | +18.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.8 | +460.8 | 0.0 | 20.2 | 1.5 | +9.3 | 0.0 | 49.8 |
| MOVE SPELL OUT OF RANGE | 2.0 | -47.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.0 | +173.0 | 0.0 | 0.0 | 3.5 | +551.5 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.2 | +13.8 | 0.0 | 0.0 | 0.2 | +1.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +276.4 | 0.0 | 0.0 | 5.8 | +301.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.5 | -354.0 | 0.0 | 0.0 | 6.5 | -476.8 | 0.0 | 28.8 |
| NEXT OBJECTIVE NEARER | 0.2 | -0.6 | 0.0 | 16.2 | 11.2 | -822.2 | 0.0 | 146.5 |
| NO DOUBLE ROUNDS | 0.5 | -14.9 | 0.0 | 0.0 | 4.0 | -89.7 | 303.0 | 65.5 |
| NOT TURNED | 0.5 | +0.0 | 0.0 | 21.2 | - | - | - | - |
| NOT WORTH A CAST | 0.8 | -0.7 | 0.0 | 0.0 | 0.8 | -0.9 | 0.0 | 0.0 |
| OFF BEST | - | - | - | - | 0.2 | -0.5 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 7.2 | +0.0 | 0.0 | 50.5 | 0.5 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -40.4 | 0.0 | 0.0 | 6.0 | -164.0 | 0.0 | 28.8 |
| ONE OBJECTIVE FORMULA | 6.0 | +273.0 | 0.0 | 0.0 | 3.8 | +19.6 | 0.0 | 63.0 |
| ONE TARGET A SHOOTER | 10.5 | +204.5 | 0.0 | 16.2 | 19.2 | +726.1 | 0.0 | 153.0 |
| OPENS UP | - | - | - | - | 0.2 | +13.0 | 27.5 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.2 | +3.1 | 16.2 | 0.0 |
| PATHS CROSS | 3.5 | +220.6 | 0.0 | 0.0 | 4.2 | +225.1 | 0.0 | 74.2 |
| PIVOT GUARDS FLANK | 0.2 | -1.1 | 0.0 | 0.0 | 0.2 | -0.9 | 0.0 | 0.0 |
| PLAN RESULT | 33.8 | +346.7 | 168.8 | 535.2 | 40.5 | +222.4 | 97.8 | 444.8 |
| QUARTER ODDS | 5.8 | +646.4 | 0.0 | 51.2 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.2 | +15.2 | 0.0 | 42.5 | 2.5 | +14.2 | 0.0 | 42.5 |
| REAL GROUND | 1.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.5 | -5.2 | 0.0 | 21.2 | 0.8 | -25.5 | 0.0 | 15.8 |
| REDIRECT COUNTER | 3.8 | +299.9 | 0.0 | 0.0 | 3.2 | +122.9 | 0.0 | 7.5 |
| REDIRECT WEIGHED | - | - | - | - | 0.2 | -6.2 | 13.0 | 0.0 |
| REFORMS TO MEET IT | 0.5 | -4.8 | 0.0 | 0.0 | 0.5 | -135.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.2 | +37.4 | 0.0 | 40.0 |
| RISK BY ARC | 0.2 | +10.5 | 0.0 | 0.0 | 2.8 | +18.5 | 261.5 | 65.5 |
| RISK BY HIS FIGURE | 18.2 | -111.6 | 0.0 | 113.2 | 12.8 | -140.4 | 0.0 | 41.8 |
| RUN DOWN | 0.5 | -4.6 | 0.0 | 0.0 | 3.2 | -28.1 | 260.5 | 49.8 |
| SCOUT SPOT | 0.2 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 5.5 | +295.6 | 0.0 | 0.0 | 7.0 | +442.0 | 0.0 | 68.5 |
| SELF MOVE SPELL | - | - | - | - | 1.5 | +83.9 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +4.9 | 0.0 | 20.0 |
| SET-UP ANY TARGET | 1.0 | +48.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.5 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.8 | +96.1 | 28.8 | 0.0 | 0.5 | +1.5 | 0.0 | 69.8 |
| SHOT OR CHARGE | - | - | - | - | 0.5 | -6.0 | 41.5 | 0.0 |
| SHOT RISK POINTS | 9.8 | +153.2 | 0.0 | 34.2 | 16.5 | +122.8 | 0.0 | 216.0 |
| SHOTS IN THE MOVE | 9.8 | +385.5 | 0.0 | 163.8 | 11.5 | +264.0 | 0.0 | 138.8 |
| SPELL SETS UP CHARGE | 1.0 | +48.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.5 | +21.6 | 0.0 | 88.8 | 1.8 | +22.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.2 | -2.9 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.2 | -0.6 | 0.0 | 0.0 | 0.2 | -1.9 | 16.2 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.5 | +0.0 | 0.0 | 49.8 |
| STANDS STILL | 13.5 | +0.0 | 108.8 | 147.5 | 9.8 | +0.0 | 62.8 | 119.8 |
| STAY WORTH | 5.5 | +15.8 | 0.0 | 0.0 | 14.5 | +108.2 | 42.5 | 188.8 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.2 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 35.0 | 49.8 |
| SURE REACH TOGETHER | - | - | - | - | 0.8 | +3.2 | 0.0 | 20.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.8 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 74.2 |
| THE PROMISE ADDS | 0.2 | -7.0 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | - | - | - | - | 1.2 | +115.0 | 125.2 | 49.8 |
| TIME ON OUR SIDE | 20.2 | +435.1 | 0.0 | 0.0 | 9.0 | +169.8 | 0.0 | 20.0 |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.2 | +2.1 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +93.5 | 0.0 | 0.0 | - | - | - | - |
| WIDER SPREAD | 0.5 | +3.0 | 0.0 | 0.0 | 2.5 | -5.4 | 168.8 | 15.8 |
| WOUNDS ON THE RANKS | 3.0 | +72.8 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: h7-mine-dcce224-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 66 | 66 | 61 | 15.25 | +4087 | +67.0 |
| SEARCH SPOT | 50 | 50 | 47 | 11.75 | +2951 | +62.8 |
| HIS SHOT LIST | 147 | 147 | 45 | 11.25 | +1418 | +31.5 |
| DEPLOY BY FIGURES | 60 | 60 | 40 | 10.00 | +494 | +12.3 |
| FIVE ACTION | 342 | 342 | 33 | 8.25 | +793 | +24.0 |
| LEGAL CHARGES ONLY | 31 | 31 | 31 | 7.75 | +0 | +0.0 |
| PATHS CROSS | 31 | 31 | 31 | 7.75 | +1783 | +57.5 |
| ONE TARGET A SHOOTER | 119 | 119 | 27 | 6.75 | +257 | +9.5 |
| TIME ON OUR SIDE | 117 | 101 | 21 | 5.25 | +244 | +11.6 |
| SHOT RISK POINTS | 105 | 105 | 18 | 4.50 | +920 | +51.1 |
| COVER ONCE | 60 | 43 | 14 | 3.50 | +171 | +12.2 |
| HARD STAY DROPPED | 14 | 14 | 14 | 3.50 | +0 | +0.0 |
| FOUR ROUNDS | 19 | 19 | 12 | 3.00 | +360 | +30.0 |
| MAX FOR POSITIONING | 50 | 49 | 11 | 2.75 | +17 | +1.5 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 2.50 | +717 | +71.7 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 10 | 2.50 | +118 | +11.8 |
| REDIRECT COUNTER | 28 | 19 | 10 | 2.50 | +867 | +86.7 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 2.25 | +0 | +0.0 |
| MANOEUVRE | 11 | 11 | 8 | 2.00 | +407 | +50.9 |
| MOVE TO CHARGE COMPUTED | 22 | 22 | 8 | 2.00 | +622 | +77.8 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 1.75 | +0 | +0.0 |
| FALLS SHORT | 114 | 91 | 7 | 1.75 | +1 | +0.2 |
| MISSILES IN THE MOVE | 36 | 22 | 7 | 1.75 | +388 | +55.5 |
| NEXT OBJECTIVE NEARER | 46 | 46 | 7 | 1.75 | +73 | +10.4 |
| CANNON PLANNED TARGET | 19 | 19 | 6 | 1.50 | -135 | -22.5 |
| FEATURE BUFFS | 31 | 31 | 6 | 1.50 | +330 | +55.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 1.50 | +0 | +0.0 |
| RISK BY HIS FIGURE | 124 | 124 | 6 | 1.50 | +204 | +34.0 |
| CHAFF IN THE MOVE | 8 | 8 | 5 | 1.25 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.25 | +136 | +27.3 |
| ONE OBJECTIVE FORMULA | 39 | 29 | 5 | 1.25 | +395 | +79.0 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.25 | +150 | +29.9 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 5 | 1.25 | +14 | +2.8 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 9 | 9 | 4 | 1.00 | +71 | +17.7 |
| NEARER NOT NEEDED | 47 | 45 | 4 | 1.00 | +205 | +51.2 |
| NEXT CHARGE BY LIST | 44 | 44 | 4 | 1.00 | +18 | +4.5 |
| QUARTER ODDS | 23 | 23 | 4 | 1.00 | +281 | +70.3 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.00 | +62 | +15.6 |
| WOUNDS ON THE RANKS | 12 | 12 | 4 | 1.00 | +71 | +17.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 0.75 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 0.75 | +0 | +0.0 |
| CHARGE NOT DECLARED | 3 | 3 | 3 | 0.75 | -167 | -55.6 |
| HIS TURN DENIED | 11 | 11 | 3 | 0.75 | +48 | +15.9 |
| MARCH BY THE SUM | 3 | 3 | 3 | 0.75 | +138 | +46.1 |
| RISK BY ARC | 12 | 12 | 3 | 0.75 | +75 | +25.2 |
| SHOTS IN THE MOVE | 85 | 72 | 3 | 0.75 | +50 | +16.8 |
| BEST PRIZE | 2 | 2 | 2 | 0.50 | -39 | -19.4 |
| CASTING BLOCK | 3 | 3 | 2 | 0.50 | +36 | +17.8 |
| CHARGE LOSSES | 46 | 46 | 2 | 0.50 | +61 | +30.7 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.50 | +26 | +13.1 |
| GUN MASK | 9 | 9 | 2 | 0.50 | +6 | +3.2 |
| HIS MOVE AND SHOT | 12 | 12 | 2 | 0.50 | +44 | +22.1 |
| HOLDER AT DEPLOYMENT | 8 | 8 | 2 | 0.50 | +95 | +47.5 |
| HONEST WORTH | 15 | 15 | 2 | 0.50 | +31 | +15.5 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.50 | +62 | +31.2 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.50 | -8 | -4.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.50 | +2 | +1.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.25 | +110 | +109.7 |
| CAST JOB | 2 | 2 | 1 | 0.25 | +0 | +0.0 |
| CHARGE NOW FIRST | 10 | 10 | 1 | 0.25 | -69 | -69.4 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.25 | +14 | +14.3 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.25 | +106 | +106.5 |
| IDLE COST | 45 | 36 | 1 | 0.25 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.25 | +10 | +10.5 |
| OFF BEST | 1 | 1 | 1 | 0.25 | -2 | -2.1 |
| ONE FIGHT FORMULA | 40 | 24 | 1 | 0.25 | +0 | +0.2 |
| OPENS UP | 1 | 1 | 1 | 0.25 | +42 | +42.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.25 | +183 | +182.8 |
| REFORMS TO MEET IT | 4 | 4 | 1 | 0.25 | +0 | +0.5 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.25 | +0 | +0.0 |
| SCOUT WAITS | 1 | 1 | 1 | 0.25 | +0 | +0.0 |
| STAY WORTH | 80 | 73 | 1 | 0.25 | +5 | +5.3 |
| STUCK PIVOT | 1 | 1 | 1 | 0.25 | +0 | +0.0 |
| SUPPORT NARROWED | 5 | 5 | 1 | 0.25 | -2 | -1.6 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.25 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.25 | +220 | +219.9 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 15 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 4 | 4 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 13 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 12 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 53 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 13 | 13 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 27 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 34 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 3 | 3 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 13 | 13 | 0 | 0.00 | - | - |
| HOLD ODDS | 78 | 78 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 37 | 23 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 8 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 31 | 31 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 297 | trace | - | - | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET UP TOGETHER | 4 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 93 | 93 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 35 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WIDER SPREAD | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: h7-mine-dcce224-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 2.25 | - | 13.9 |
| CHARGE NOT DECLARED | rule | - | 0.75 | 55.6 |
| BEST PRIZE | rule | - | 0.50 | 19.4 |
| CANNON PLANNED TARGET | rule | - | 0.50 | 70.8 |
| PATHS CROSS | rule | 0.25 | 0.25 | 6.2 |
| PIVOT GUARDS FLANK | rule | 0.25 | 0.25 | 4.0 |
| AFTERMATH BAND | gate | - | 0.25 | 2.1 |
| CHARGE NOW FIRST | rule | - | 0.25 | 69.4 |
| SUPPORT NARROWED | rule | 0.25 | - | 1.6 |

### Plans: h7-mine-dcce224-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.2 | 100% | 16 | 10 | 62% |
| Mine | move | 26.8 | 93% | 3207 | 0 | 0% |
| Mine | shoot | 6.2 | 60% | 331 | 337 | 102% |
| Mine | support | 0.5 | 50% | 0 | 0 | - |
| Opponent | charge | 3.0 | 50% | 453 | 192 | 42% |
| Opponent | move | 32.8 | 94% | 1979 | 0 | 0% |
| Opponent | shoot | 4.0 | 19% | 159 | 30 | 19% |
| Opponent | support | 0.8 | 67% | 0 | 0 | - |

### Battle groups: h7-mine-dcce224-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.8 | 20% | 67% | 0% | - | 33% | 0% | 0% | 33% | 33% |
| Opponent | REDIRECT COUNTER | 3.2 | 23% | 67% | 33% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h7-mine-dcce224-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 39 | 67% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 17 | 24 (17) | 24 | 0 | 16 | 18% | 2.6 | 13 (8) | 58 (4) | 23 (4) | 40 (8) | 15 (8) |
| Mine | Fast Hammer | 5 | 0 (5) | 0 | 0 | 42 | 40% | 5.0 | - | 0 (3) | 0 (2) | 0 (3) | 0 (2) |
| Mine | Hammer | 10 | 23 (10) | 2 | 21 | 9 | 30% | 2.4 | 61 (2) | 15 (5) | 8 (3) | 31 (7) | 7 (3) |
| Mine | Holder | 5 | 127 (5) | 0 | 127 | 0 | 80% | 5.0 | 179 (1) | 214 (2) | 17 (2) | 115 (4) | 179 (1) |
| Mine | Shooter | 4 | 173 (4) | 0 | 173 | 25 | 0% | 2.0 | - | 173 (4) | - | 69 (2) | 277 (2) |
| Mine | War machine | 4 | 14 (4) | 14 | 0 | 100 | 0% | 1.5 | 14 (4) | - | - | 36 (2) | 0 (2) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 4.3 | 0 (3) | 0 (1) | - | 0 (1) | 0 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 6 | 32 (6) | 0 | 32 | 58 | 50% | 3.3 | 0 (2) | 56 (2) | 27 (2) | 32 (6) | - |
| Opponent | Character | 10 | 38 (10) | 38 | 0 | 0 | 30% | 2.7 | 44 (2) | 27 (5) | 52 (3) | 44 (9) | 0 (1) |
| Opponent | Clean-up | 2 | 88 (2) | 0 | 88 | 22 | 100% | - | 0 (1) | 112 (1) | - | 88 (2) | - |
| Opponent | Fast Hammer | 6 | 29 (6) | 6 | 23 | 39 | 33% | 3.5 | 25 (2) | 109 (1) | 8 (3) | 30 (5) | 22 (1) |
| Opponent | Hammer | 5 | 3 (5) | 0 | 3 | 22 | 40% | 4.7 | 0 (1) | 0 (2) | 6 (2) | 0 (3) | 6 (2) |
| Opponent | Holder | 2 | 110 (2) | 0 | 110 | 0 | 100% | - | - | 140 (1) | 65 (1) | 110 (2) | - |
| Opponent | Shooter | 2 | 40 (2) | 0 | 40 | 0 | 0% | 2.5 | 48 (1) | 34 (1) | - | 34 (1) | 48 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 4 | 0 (4) | 0 | 0 | 25 | 0% | 2.8 | 0 (2) | 0 (1) | 0 (1) | - | 0 (4) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: h7-mine-dcce224-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 170 | 0 | 0.7 | 1.5 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | +0 | +0 |
| Mine | Chaos Dwarfs | 1 | 80 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 4 | 148 | 0 | 0.5 | 1.5 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | +0 | +0 |
| Opponent | High Elf Realms | 1 | 0 | 420 | 4.0 | 1.0 | 105 | 0 | +105 | 2 of 4 | 2 of 4 | - | +105 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 434 | 3.5 | 1.0 | 124 | 0 | +124 | 0 of 7 | 7 of 7 | - | +124 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 116 | -116 | 2 of 2 | 0 of 2 | - | -116 |
| **Opponent** | all armies | 4 | 0 | 322 | 3.2 | 1.0 | 99 | 18 | +81 | 4 of 13 | 9 of 13 | - | +81 |

### Effective charges: h7-mine-dcce224-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 4 | 1 (net +355) | 0 | 1 (net +0) | 0 | 2 (net +32) | 0 | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 7 | 1 (net +85) | 0 | 1 (net +230) | 2 (net +125) | 1 (net +81) | 1 (net +170) | 1 | 17% (1 of 6) |
| Opponent | Warriors of Chaos | 2 | 1 (net -170) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: h7-mine-dcce224-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 84 | 80 | +0 | 40 | 0 | +40 | +47.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 357 | 396 | +0 | 161 | 21 | +139 | +39.1 |
| Mine | All fights | 2 | 220 | 238 | +0 | 100 | 11 | +90 | +40.7 |
| Opponent | Long shot (under 50%) | 3 | 302 | 414 | +90 | 163 | 79 | +83 | +27.6 |
| Opponent | Effective (55-75%) | 2 | 434 | 276 | +115 | 119 | 124 | -5 | -1.2 |
| Opponent | 76-89% | 2 | 324 | 125 | +125 | 125 | 0 | +125 | +38.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 371 | 170 | +170 | 170 | 0 | +170 | +45.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 334 | 67 | +49 | 63 | 9 | +54 | +16.1 |
| Opponent | No odds | 2 | 169 | 444 | -6 | 26 | 32 | -6 | -3.3 |
| Opponent | All fights | 13 | 318 | 254 | +81 | 107 | 44 | +62 | +19.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h7-mine-dcce224-p4 | move | 27 | 5 (19%) | 4 (15%) | 2 (7%) | 20 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Ring of Doom | Mine | L0216 |
| Ring of Doom | Opponent | L0115 |

# Doctrine scorecard: h7-opp-dcce224-p3

### Scorecard: h7-opp-dcce224-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | yes | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 225 |
| L0111 | 3 | 1 | Opponent | yes | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 170 |
| L0211 | 1 | 1 | Opponent | yes | 13 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | yes | 9 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 140 |
| L0313 | 1 | 1 | Opponent | no | 10 | 2 | 2 | 0 | 1 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 195 |
| L0330 | 6 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 40% | 3.0 | 2.5 | 0.8 | 2.2 | 0.0 | 0.0 | 0.0 | 150.0 |
| **Average** | | | Opponent | 40% | 9.2 | 2.2 | 1.3 | 0.8 | 0.2 | 0.0 | 0.0 | 11.7 |

### KPIs: h7-opp-dcce224-p3

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 6 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (9 of 28) | 15% (4 of 27) | 24% (13 of 55) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 86% (6 of 7); on the table 86% | 89% (8 of 9); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 100% (3 of 3); on the table 100% | 83% (5 of 6); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 83% | 85% (11 of 13); on the table 85% | 84% (16 of 19); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 37% (47 of 126) | 35% (19 of 54) | 37% (66 of 180) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (47 of 110) | 50% (19 of 38) | 45% (66 of 148) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 30% (3 of 10) | - | 30% (3 of 10) |
| Points that never fought | lower | 54% (6227 of 11566) | 51% (6170 of 11998) | 53% (12397 of 23564) |
|   infantry points that never fought | lower | 54% (1984 of 3676) | 76% (1084 of 1428) | 60% (3068 of 5104) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 66% (25 of 38) | 41% (18 of 44) | 52% (43 of 82) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 2.5 uses a game | 100% (5 of 5); 3.2 uses a game | 91% (10 of 11); 2.8 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.0 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 88% (7 of 8); 1.2 uses a game | 33% (1 of 3); 0.2 uses a game | 73% (8 of 11); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (4829 of 8400) | 41% (4494 of 11046) | 48% (9323 of 19446) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 7.3 (56%) | 0.7 (11%) | 8.0 (42%) |
| MARCHED: its unit marched | 1.8 (14%) | 2.3 (40%) | 4.2 (22%) |
| IN COMBAT: engaged in combat | 1.3 (10%) | 2.0 (34%) | 3.3 (18%) |
| REAR RANK: in a rear rank | 0.8 (6%) | 0.0 (0%) | 0.8 (4%) |
| FLEEING: fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 1.0 (8%) | 0.7 (11%) | 1.7 (9%) |
| STUPIDITY: Stupidity | 0.5 (4%) | 0.2 (3%) | 0.7 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.2 | 2.7 | 2.0 | 11.0 | 0.3 | 2.0 |
| not cast | 3.8 | 7.0 | 4.0 | 19.0 | 1.7 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.8 (55%) | 0.0 (0%) | 8.0 (42%) | 0.7 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.2 (22%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | 1.0 (14%) | 0.2 (4%) | 3.3 (18%) | 0.7 (40%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.8 (21%) | 0.8 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.5 (2%) |
| GONE: slain | 0.7 (17%) | 0.0 (0%) | 1.2 (29%) | 1.7 (9%) | 0.0 (0%) | 3.2 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.2 (2%) | 0.2 (4%) | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (65%) | 1.7 (24%) | 1.7 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.3 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.8 a game | 0.2 a game | 1.5 a game |
| stood (cast and not dispelled) | 41% (7 of 17) | 100% (1 of 1) | 44% (8 of 18) |
| the unit moved after it | 43% (3 of 7) | 100% (1 of 1) | 50% (4 of 8) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| the enemy charged it first | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| it fought by the end of its next turn | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| none of these (no charge, no fight, no charge escaped) | 71% (5 of 7) | 100% (1 of 1) | 75% (6 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (46 of 81) | 49% (41 of 83) | 53% (87 of 164) |
|   cavalry | - | 57% (4 of 7) | 57% (4 of 7) |
|   character | - | 11% (1 of 9) | 11% (1 of 9) |
|   chariot | 64% (14 of 22) | 50% (4 of 8) | 60% (18 of 30) |
|   infantry | 47% (9 of 19) | 67% (16 of 24) | 58% (25 of 43) |
|   war machine | 58% (23 of 40) | 46% (16 of 35) | 52% (39 of 75) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (17%) | 2.3 (33%) | 3.3 (26%) |
| CHARGED: it charged | 0.0 (0%) | 0.5 (7%) | 0.5 (4%) |
| IN COMBAT: it fought this turn or the last | 0.5 (9%) | 0.0 (0%) | 0.5 (4%) |
| MOVED: a war machine that moved | 2.2 (37%) | 3.2 (45%) | 5.3 (42%) |
| NO TARGET IN RANGE | 1.3 (23%) | 1.0 (14%) | 2.3 (18%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| OTHER BAR | 0.5 (9%) | 0.0 (0%) | 0.5 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.7 | 0.3 | 50% | 7.0 pts | 5 pts |
| character | 0.2 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.0 | 3.2 | 39% | 43.3 pts | 130 pts |
| infantry | 7.3 | 3.0 | 68% | 7.5 pts | 55 pts |
| war machine | 6.5 | 6.2 | 62% | 25.0 pts | 162 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.3 | 2.2 |
| Charges that made contact a game | 1.7 | 2.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.80 declared, 0.80 contact (5 units) | 0.44 declared, 0.44 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.31 declared, 0.26 contact (39 units) | 0.28 declared, 0.21 contact (29 units) | 0.29 declared, 0.24 contact (68 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (2 of 5) | - | 33% (2 of 6) | 36% (4 of 11) |
| Character in a unit | 91% (10 of 11) | 77% (10 of 13) | 50% (1 of 2) | 81% (21 of 26) |
| Character on its own | 100% (1 of 1) | 40% (2 of 5) | 25% (1 of 4) | 40% (4 of 10) |
| Chariot | 100% (2 of 2) | 25% (1 of 4) | - | 50% (3 of 6) |
| Infantry | 20% (1 of 5) | 22% (2 of 9) | - | 21% (3 of 14) |
| Monster | 0% (0 of 2) | 0% (0 of 1) | - | 0% (0 of 3) |
| War Machines | 60% (6 of 10) | 100% (2 of 2) | - | 67% (8 of 12) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 83% (5 of 6); on the table 83% | 34% (35 of 102) | 49% | 68% (15 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 2 | - | 50% (12 of 24) | 63% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Grand Cathay | 2 | 88% (7 of 8); on the table 88% | 36% (13 of 36) | 33% | 31% (5 of 16) | 100% (4 of 4); 6.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 83% | 38% (3 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 80% (4 of 5); on the table 80% | 50% (6 of 12) | 53% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (h7-opp-dcce224-p3, 6 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 62% (5) | 50% (4) | 56% (9) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.00 | 0.17 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.50 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: h7-opp-dcce224-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 83% (10 of 12) | 50% (7 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (22 of 66) | 36% (16 of 44) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (3 of 6) |
| Strategy | Joined characters whose unit fought | 43% (9 of 21) | 46% (6 of 13) |
| Strategy | Lone characters that fought | 33% (3 of 9) | 67% (6 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.2 | 0.8 |
| Movement | Points that never moved of their own | 150.0 | 11.7 |
| Movement | Fights charged into per game | 1.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 8, net -72 | 1 of 11, net -173 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 8, net +165 | 2 of 11, net +148 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 8 | 3 of 11, net +345 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 8, net +14 | 2 of 11, net +155 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 4.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 71% (17 of 24) | 28% (8 of 29) |
| Shooting | Points destroyed by shooting units | 156.7 | 37.5 |
| Shooting | War machine shots | 3.8 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (9 of 23) | 50% (8 of 16) |
| Shooting | Points destroyed by war machines | 49.5 | 32.0 |
| Magic | Magic missiles cast | 2.3 | 2.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 57% (8 of 14) | 8% (1 of 13) |
| Magic | Wounds caused by magic missiles | 5.2 | 5.3 |
| Magic | Wounds caused by other spells | 0.7 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 6.8 | 52.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.0 / 0.3 / 0.0 | 0.2 / 1.7 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 22.7 | 356.7 |
| Combat | Points run down | 53.8 | 8.7 |
| Combat | Net points per charged fight, damage counted | +15 | +165 |
| Combat | Net per 100 charger points, damage counted | +5.5 | +46.7 |
| Combat | First round won (charged fights) | 62% | 92% |
| Combat | Net points per charged fight | -10 | +165 |
| Combat | Net points per supported fight / lone fight | -274 / +27 | - / +165 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 8 | 4 of 12 |
| Game | Points lost | 562.8 | 310.5 |
| Game | VP from objectives | 576.7 | 1026.7 |
| Game | Lone holders (player turns) | 3.0 | 9.2 |

- Mine won / drew / lost: 2 / 0 / 4 of 6 ended games (of 6); mean margin (Mine - Opponent) -682 VP
- The side that went first won 2 of 6 games with a winner
- Points traded per game (both sides' losses): 873
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h7-opp-dcce224-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +86.3 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 56.7 | 0.7 | +0.0 | 0.0 | 27.5 |
| BACKUP TARGETS | 0.2 | +0.7 | 0.0 | 10.8 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.2 | -3.5 | 18.3 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.3 | +9.5 | 0.0 | 25.0 |
| CANNON PLAN MISSED | 0.5 | +0.0 | 182.8 | 38.3 | 0.2 | +0.0 | 38.3 | 0.0 |
| CANNON PLANNED TARGET | 3.5 | +1.4 | 215.5 | 116.7 | 2.5 | +57.2 | 84.5 | 55.0 |
| CANNON SIGHT KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.7 | +40.1 | 173.0 | 0.0 | 0.7 | +30.5 | 75.5 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.3 | +111.3 | 38.7 | 0.0 | 0.2 | +4.1 | 10.8 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 118.3 | 0.2 | +0.0 | 0.0 | 66.7 |
| CHAFF IN THE MOVE | 0.3 | +15.2 | 0.0 | 14.2 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.7 | -128.8 | 0.0 | 29.2 | 6.0 | -324.3 | 0.0 | 256.5 |
| CHARGE NOT DECLARED | 1.0 | +0.0 | 31.8 | 31.5 | 0.2 | +0.0 | 38.3 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 160.5 | 0.0 | 1.3 | +0.0 | 152.7 | 28.8 |
| CHARGER SLAIN LOST | 0.8 | -80.1 | 25.0 | 31.5 | 0.2 | -0.6 | 18.3 | 0.0 |
| CHEAP HELPER | 0.3 | +0.0 | 0.0 | 8.7 | - | - | - | - |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 51.7 | - | - | - | - |
| CONVEYANCE SEARCH | 2.3 | +589.8 | 0.0 | 59.2 | 0.2 | +66.6 | 66.7 | 66.7 |
| COVER ONCE | 4.8 | -636.3 | 0.0 | 153.2 | 3.8 | -120.6 | 0.0 | 224.3 |
| DEPLOY BY FIGURES | 7.7 | +61.9 | 0.0 | 0.0 | 5.8 | -31.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +0.3 | 18.3 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +15.0 | 61.8 | 27.7 | 2.0 | +13.5 | 186.8 | 28.8 |
| FALLBACK BY WORTH | 0.2 | +6.0 | 0.0 | 5.0 | - | - | - | - |
| FALLS SHORT | 7.2 | +133.9 | 0.0 | 83.0 | 12.8 | +275.2 | 0.0 | 294.7 |
| FEATURE BUFFS | 3.8 | +110.2 | 0.0 | 13.7 | 0.8 | +20.8 | 0.0 | 0.0 |
| FIGHT LIFT | 0.2 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.8 | +1.4 | 59.3 | 0.0 | 0.8 | +69.2 | 67.5 | 28.8 |
| FIRE IN ORDER | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 41.2 | +2127.6 | 1176.7 | 532.5 | 35.2 | +3660.2 | 566.7 | 502.0 |
| FLANK NOT WEIGHED | 3.5 | +0.0 | 0.0 | 66.7 | 5.0 | +0.0 | 0.0 | 233.7 |
| FOLLOW UP WEIGHED | 0.3 | +32.1 | 0.0 | 62.0 | 0.7 | +108.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +221.5 | 86.8 | 45.0 | 2.3 | +363.1 | 239.2 | 28.8 |
| FRIEND SHOOTS FIRST | 0.5 | -5.1 | 0.0 | 51.7 | 0.3 | -15.4 | 0.0 | 66.7 |
| GIVES UP | - | - | - | - | 0.3 | -9.7 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.2 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.2 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.0 | +38.2 | 90.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 1.2 | +24.0 | 0.0 | 50.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE SHOOTS OR CHARGES | 3.5 | +0.0 | 0.0 | 33.5 | 1.5 | +0.0 | 0.0 | 80.3 |
| HELPER ALREADY ASKED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.2 | +0.0 | 0.0 | 13.5 | - | - | - | - |
| HIS CHARGE DENIED | 0.5 | +10.2 | 25.0 | 27.7 | 0.3 | +20.6 | 65.8 | 0.0 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 3.2 | +0.0 | 0.0 | 74.5 |
| HIS MOVE AND SHOT | 1.7 | -20.7 | 0.0 | 32.3 | 1.3 | -71.3 | 0.0 | 73.7 |
| HIS ONE QUARTER | - | - | - | - | 0.8 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 2.8 | +0.0 | 0.0 | 31.8 |
| HIS SHOT LIST | 14.2 | +347.6 | 0.0 | 133.0 | 17.5 | +790.3 | 0.0 | 354.5 |
| HIS TURN DENIED | 0.5 | +23.5 | 55.0 | 0.0 | 1.3 | +52.5 | 143.5 | 0.0 |
| HOLD ODDS | - | - | - | - | 14.7 | +0.0 | 0.0 | 18.5 |
| HOLDER ASSIGNMENT | - | - | - | - | 17.3 | +1717.0 | 0.0 | 18.5 |
| HOLDER AT DEPLOYMENT | 1.0 | +143.0 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -28.7 | 61.8 | 0.0 | 2.2 | -107.0 | 239.2 | 28.8 |
| HUNT KEPT | 0.2 | +8.1 | 27.5 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.2 | +27.5 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.2 | +55.8 | 27.5 | 0.0 | - | - | - | - |
| IDLE COST | 2.0 | -17.9 | 0.0 | 19.5 | 5.2 | -171.4 | 0.0 | 246.2 |
| KEEP FALLS | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 0.5 | +10.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.5 | +0.0 | 58.8 | 198.5 | 1.0 | +0.0 | 190.8 | 0.0 |
| LONE WIZARD KEPT IN | 1.7 | +141.1 | 0.0 | 0.0 | 0.3 | +35.6 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -11.0 | 0.0 | 13.5 | 0.2 | +0.1 | 0.0 | 28.8 |
| LOST CHARGE | - | - | - | - | 0.2 | -0.3 | 0.0 | 28.8 |
| MANOEUVRE | 1.3 | +27.8 | 0.0 | 13.5 | 1.5 | +14.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +9.7 | 0.0 | 0.0 |
| MARCH CHECK | 1.7 | +147.7 | 0.0 | 0.0 | 2.7 | +127.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.5 | +213.1 | 0.0 | 0.0 | 1.2 | +45.9 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.5 | +68.1 | 0.0 | 111.3 | 4.2 | +41.6 | 0.0 | 128.5 |
| MISSILES IN THE MOVE | 8.0 | +342.1 | 0.0 | 27.0 | 5.3 | +120.4 | 0.0 | 66.7 |
| MISSILES NEXT TURN | 8.5 | +196.1 | 0.0 | 27.0 | 6.3 | +82.4 | 0.0 | 133.3 |
| MOVE SPELL OUT OF RANGE | 1.0 | -197.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 66.7 |
| MOVE TO CHARGE COMPUTED | 1.7 | +213.8 | 0.0 | 83.2 | 2.3 | +473.6 | 0.0 | 190.7 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.5 | +290.2 | 0.0 | 61.0 | 6.2 | +263.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.2 | -201.1 | 0.0 | 83.2 | 4.7 | -281.6 | 75.5 | 282.8 |
| NEXT OBJECTIVE NEARER | 6.3 | -400.9 | 31.8 | 57.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.0 | -179.5 | 86.8 | 45.0 | 1.5 | -120.3 | 158.2 | 28.8 |
| NOT WORTH A CAST | 1.3 | -1.9 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 0.2 | -7.1 | 0.0 | 5.0 | 0.5 | -7.8 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.3 | +0.0 | 0.0 | 123.5 | - | - | - | - |
| ONE FIGHT FORMULA | 4.0 | -60.7 | 0.0 | 39.5 | 4.2 | -139.1 | 0.0 | 282.8 |
| ONE OBJECTIVE FORMULA | 4.7 | -33.8 | 0.0 | 53.3 | 6.5 | +28.7 | 0.0 | 18.5 |
| ONE TARGET A SHOOTER | 16.3 | +336.7 | 0.0 | 188.0 | 12.8 | +287.1 | 0.0 | 239.3 |
| OPENS A LANE | - | - | - | - | 0.2 | +0.5 | 14.2 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +52.0 | 45.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.5 | +40.5 | 68.2 | 0.0 |
| PATHS CROSS | 2.0 | +18.9 | 0.0 | 58.5 | 2.8 | +57.2 | 0.0 | 0.0 |
| PLAN RESULT | 36.8 | +1079.6 | 678.5 | 884.7 | 30.2 | +524.6 | 379.7 | 448.7 |
| PURSUES BIG PREY | 0.2 | -20.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | - | - | - | - | 6.8 | +779.1 | 168.2 | 101.2 |
| RANDOM MOVE BY FIGURES | 1.7 | +14.8 | 0.0 | 28.3 | - | - | - | - |
| REAL GROUND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -5.7 | 0.0 | 14.2 | - | - | - | - |
| REDIRECT COUNTER | 2.7 | +159.6 | 0.0 | 76.8 | 1.8 | +119.1 | 0.0 | 61.8 |
| REDIRECT WEIGHED | - | - | - | - | 0.2 | -3.5 | 18.3 | 0.0 |
| REFORMS TO MEET IT | 0.5 | -41.1 | 0.0 | 22.8 | 0.2 | -103.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| RESERVE FALL BACK | 0.2 | +2.7 | 0.0 | 0.0 | 0.3 | +19.2 | 0.0 | 25.0 |
| RISK BY ARC | 1.5 | +39.3 | 31.8 | 45.0 | 1.7 | -12.1 | 169.2 | 28.8 |
| RISK BY HIS FIGURE | 10.3 | -82.3 | 0.0 | 241.8 | 8.3 | -243.7 | 0.0 | 276.7 |
| RUN DOWN | 1.2 | -17.1 | 86.8 | 0.0 | 1.7 | -9.2 | 135.8 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -20.0 | 62.0 | 49.5 |
| SCOUT SPOT | 0.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.7 | -68.9 | 0.0 | 5.0 | - | - | - | - |
| SEARCH SPOT | 3.7 | +103.5 | 0.0 | 46.2 | 3.3 | +138.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.2 | -1.0 | 0.0 | 5.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.5 | +65.1 | 147.3 | 13.5 | 0.8 | +6.0 | 5.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -2.9 | 0.0 | 14.2 | 0.5 | -54.8 | 87.5 | 0.0 |
| SHOT RISK POINTS | 10.3 | +35.1 | 0.0 | 74.8 | 9.5 | -189.3 | 0.0 | 322.8 |
| SHOTS IN THE MOVE | 10.3 | +354.6 | 0.0 | 219.2 | 10.2 | +382.0 | 0.0 | 171.2 |
| SPELL SETS UP CHARGE | 0.2 | +101.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.3 | +37.2 | 0.0 | 0.0 | 0.3 | +9.7 | 133.3 | 133.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.2 | +0.5 | 13.5 | 0.0 |
| STAND AND SHOOT | 0.2 | -4.2 | 0.0 | 0.0 | 0.3 | -0.7 | 21.7 | 0.0 |
| STANDS FOR A REASON | 0.2 | +0.0 | 0.0 | 13.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 19.2 | +0.0 | 1089.8 | 261.3 | 11.0 | +0.0 | 327.5 | 71.3 |
| STAY WORTH | 11.2 | -139.5 | 497.0 | 58.3 | 13.0 | +178.8 | 262.2 | 287.8 |
| STOPS | 0.3 | +17.1 | 55.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 1.0 | +0.0 | 86.8 | 14.2 | 1.0 | +0.0 | 99.5 | 28.8 |
| SURE REACH TOGETHER | 0.2 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 58.5 | 2.8 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -2.6 | 0.0 | 8.7 | - | - | - | - |
| THE PROMISED MOVE | 0.2 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 49.5 |
| TIED UP BY THE SUM | 0.2 | +3.0 | 6.8 | 0.0 | 0.3 | +47.1 | 25.0 | 0.0 |
| TIME ON OUR SIDE | 25.8 | +443.4 | 13.7 | 200.2 | 7.0 | +150.0 | 0.0 | 50.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 60.3 | 1.2 | +0.0 | 0.0 | 25.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 156.7 | 51.7 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.5 | +11.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +20.7 | 0.0 | 17.3 | - | - | - | - |
| WIDER SPREAD | 1.5 | +19.4 | 61.8 | 31.5 | 2.0 | -4.6 | 225.2 | 28.8 |
| WOUNDS ON THE RANKS | 1.5 | +42.0 | 0.0 | 0.0 | 2.3 | +107.4 | 0.0 | 0.0 |

### Rule changes: h7-opp-dcce224-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 104 | 104 | 98 | 16.33 | +5299 | +54.1 |
| DEPLOY BY FIGURES | 81 | 81 | 51 | 8.50 | +908 | +17.8 |
| HIS SHOT LIST | 190 | 190 | 50 | 8.33 | +1076 | +21.5 |
| ONE TARGET A SHOOTER | 175 | 175 | 40 | 6.67 | +409 | +10.2 |
| LEGAL CHARGES ONLY | 39 | 39 | 39 | 6.50 | +0 | +0.0 |
| TIME ON OUR SIDE | 197 | 164 | 38 | 6.33 | +181 | +4.8 |
| SEARCH SPOT | 42 | 42 | 37 | 6.17 | +1452 | +39.3 |
| FIVE ACTION | 458 | 458 | 30 | 5.00 | +1560 | +52.0 |
| PATHS CROSS | 29 | 29 | 29 | 4.83 | +456 | +15.7 |
| FOUR ROUNDS | 26 | 26 | 21 | 3.50 | +1404 | +66.8 |
| MARCH CHECK | 26 | 26 | 21 | 3.50 | +498 | +23.7 |
| ARTILLERY RE-ROLL WEIGHED | 18 | 18 | 18 | 3.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 24 | 24 | 17 | 2.83 | +1797 | +105.7 |
| SHOT RISK POINTS | 119 | 119 | 17 | 2.83 | +360 | +21.2 |
| MISSILES IN THE MOVE | 80 | 62 | 15 | 2.50 | +561 | +37.4 |
| MAX FOR POSITIONING | 58 | 55 | 13 | 2.17 | +41 | +3.1 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 13 | 2.17 | +136 | +10.4 |
| COVER ONCE | 52 | 38 | 12 | 2.00 | +202 | +16.8 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 2.00 | +1060 | +88.4 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 1.67 | +0 | +0.0 |
| MANOEUVRE | 17 | 17 | 10 | 1.67 | +251 | +25.1 |
| SHOTS IN THE MOVE | 123 | 106 | 10 | 1.67 | +412 | +41.2 |
| CASTING BLOCK | 9 | 9 | 9 | 1.50 | +251 | +27.8 |
| FALLS SHORT | 120 | 107 | 9 | 1.50 | +71 | +7.9 |
| REDIRECT COUNTER | 27 | 22 | 9 | 1.50 | +708 | +78.7 |
| HARD STAY DROPPED | 8 | 8 | 8 | 1.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 7 | 7 | 7 | 1.17 | -500 | -71.4 |
| RISK BY HIS FIGURE | 112 | 112 | 7 | 1.17 | +945 | +135.1 |
| STAY WORTH | 145 | 135 | 7 | 1.17 | +132 | +18.8 |
| CHARGE LOSSES | 70 | 70 | 6 | 1.00 | +685 | +114.2 |
| CHARGE NOW FIRST | 14 | 14 | 6 | 1.00 | -290 | -48.4 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 1.00 | +845 | +140.9 |
| NEARER NOT NEEDED | 64 | 60 | 6 | 1.00 | +138 | +23.0 |
| NEXT OBJECTIVE NEARER | 38 | 38 | 6 | 1.00 | +134 | +22.4 |
| QUARTER ODDS | 41 | 41 | 6 | 1.00 | +611 | +101.8 |
| RISK BY ARC | 19 | 19 | 6 | 1.00 | +142 | +23.6 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 0.83 | +0 | +0.0 |
| HIS TURN DENIED | 11 | 11 | 5 | 0.83 | +157 | +31.4 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 0.83 | +0 | +0.0 |
| MARCH BY THE SUM | 4 | 4 | 4 | 0.67 | +58 | +14.5 |
| OFF BEST | 4 | 4 | 4 | 0.67 | -90 | -22.4 |
| ONE FIGHT FORMULA | 49 | 25 | 4 | 0.67 | +26 | +6.5 |
| OPENS UP | 4 | 4 | 4 | 0.67 | +192 | +48.0 |
| WOUNDS ON THE RANKS | 23 | 23 | 4 | 0.67 | +127 | +31.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 0.50 | +0 | +0.0 |
| CANNON PLANNED TARGET | 36 | 36 | 3 | 0.50 | +16 | +5.5 |
| CAST JOB | 14 | 14 | 3 | 0.50 | +27 | +9.2 |
| FIGHT TO THE END | 10 | 10 | 3 | 0.50 | +344 | +114.6 |
| HIS MOVE AND SHOT | 18 | 18 | 3 | 0.50 | +7 | +2.3 |
| HOLDER AT DEPLOYMENT | 6 | 6 | 3 | 0.50 | +154 | +51.2 |
| IDLE COST | 43 | 32 | 3 | 0.50 | +78 | +25.8 |
| LANE BY FIGURES | 3 | 3 | 3 | 0.50 | +63 | +21.1 |
| MISSILES NEXT TURN | 89 | 70 | 3 | 0.50 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 47 | 47 | 3 | 0.50 | +80 | +26.6 |
| ONE OBJECTIVE FORMULA | 67 | 54 | 3 | 0.50 | +55 | +18.5 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 3 | 0.50 | +88 | +29.5 |
| RESERVE FALL BACK | 3 | 3 | 3 | 0.50 | +131 | +43.7 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 0.50 | +82 | +27.2 |
| WHO HITS BACK | 3 | 3 | 3 | 0.50 | +57 | +18.9 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.33 | +518 | +258.8 |
| BOMBING RUN | 2 | 2 | 2 | 0.33 | +57 | +28.4 |
| CHAFF PASSED | 2 | 2 | 2 | 0.33 | -2 | -1.2 |
| FALL BACK GOOD ORDER | 20 | 20 | 2 | 0.33 | +35 | +17.3 |
| FEATURE BUFFS | 28 | 28 | 2 | 0.33 | +11 | +5.7 |
| HONEST WORTH | 19 | 19 | 2 | 0.33 | +13 | +6.3 |
| KEEP FALLS | 2 | 2 | 2 | 0.33 | +30 | +15.2 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.33 | +110 | +55.1 |
| SCOUT WAITS | 2 | 2 | 2 | 0.33 | +0 | +0.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.17 | -21 | -20.9 |
| CHAFF IN THE MOVE | 2 | 2 | 1 | 0.17 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.17 | +0 | +0.0 |
| FALLBACK BY WORTH | 1 | 1 | 1 | 0.17 | +36 | +36.1 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.17 | +0 | +0.0 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.17 | +66 | +65.9 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.17 | -120 | -120.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.17 | +206 | +206.0 |
| RUN DOWN | 17 | 17 | 1 | 0.17 | +14 | +14.1 |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 1 | 0.17 | +2 | +1.8 |
| STOPS | 2 | 2 | 1 | 0.17 | +48 | +48.4 |
| SUPPORT NARROWED | 12 | 12 | 1 | 0.17 | -8 | -7.5 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 15 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 51 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| GUN MASK | 7 | 7 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 30 | 30 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 5 | 5 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 17 | 17 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 88 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| LONG SHOT | 5 | 5 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 21 | 21 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 14 | 14 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 402 | trace | - | - | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 181 | 181 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | not checked | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 29 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 7 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 13 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 3 | 3 | 0 | 0.00 | - | - |
| WIDER SPREAD | 21 | 21 | 0 | 0.00 | - | - |

### Off best figure: h7-opp-dcce224-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 1.00 | 0.17 | 71.4 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 48.4 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 15.2 |
| PATHS CROSS | rule | 0.50 | 0.33 | 48.7 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 7.8 |
| NO REASON | gate | - | 0.33 | 22.5 |
| BEST PRIZE | rule | - | 0.17 | 20.9 |
| CHAFF PASSED | rule | - | 0.17 | 2.4 |
| DEPLOY BY FIGURES | rule | - | 0.17 | 4.7 |
| FIGHT ORDER BAND | gate | - | 0.17 | 2.1 |
| JOB FIRST | gate | 0.17 | - | 42.5 |
| PURSUES BIG PREY | rule | 0.17 | - | 120.0 |
| SUPPORT NARROWED | rule | - | 0.17 | 7.5 |

### Plans: h7-opp-dcce224-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.8 | 27% | 213 | 87 | 41% |
| Mine | move | 24.7 | 93% | 1569 | 0 | 0% |
| Mine | shoot | 9.7 | 57% | 489 | 992 | 203% |
| Mine | support | 0.7 | 75% | 11 | 0 | 0% |
| Opponent | charge | 2.0 | 67% | 470 | 209 | 44% |
| Opponent | move | 22.2 | 94% | 2026 | 0 | 0% |
| Opponent | shoot | 6.0 | 56% | 542 | 316 | 58% |

### Packages: hunt the guns, h7-opp-dcce224-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 335 | 165 | 0% | 32 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 335 | 165 | 0% | 48 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 297 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: h7-opp-dcce224-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 12% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.8 | 18% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h7-opp-dcce224-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 61 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 22 | 1 (22) | 1 | 0 | 16 | 36% | 2.0 | 6 (4) | 0 (17) | - | 2 (11) | 0 (10) |
| Mine | Clean-up | 6 | 103 (6) | 103 | 0 | 67 | 33% | 3.0 | 13 (1) | 0 (2) | 202 (3) | 206 (3) | 0 (3) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 100 | 50% | 2.0 | - | - | 0 (4) | 0 (2) | 0 (2) |
| Mine | Hammer | 16 | 52 (16) | 30 | 22 | 32 | 25% | 2.2 | 46 (3) | 56 (11) | 0 (2) | 60 (11) | 37 (5) |
| Mine | Holder | 8 | 95 (8) | 0 | 95 | 39 | 75% | 4.5 | 0 (2) | 132 (5) | 95 (1) | 139 (3) | 65 (5) |
| Mine | Shooter | 4 | 85 (4) | 0 | 85 | 50 | 25% | 2.0 | 46 (1) | 146 (2) | 0 (1) | 67 (3) | 138 (1) |
| Mine | War machine | 8 | 25 (8) | 25 | 0 | 50 | 0% | 1.5 | 0 (2) | 35 (6) | - | 0 (2) | 35 (6) |
| Mine | Wizard | 8 | 0 (8) | 0 | 0 | 0 | 25% | 4.0 | 0 (1) | 0 (7) | - | 0 (3) | 0 (5) |
| Opponent | Chaff | 5 | 103 (5) | 0 | 103 | 52 | 80% | 2.0 | 214 (1) | 107 (2) | 0 (2) | 120 (4) | 61 (1) |
| Opponent | Character | 19 | 49 (19) | 49 | 0 | 23 | 26% | 2.4 | 20 (3) | 34 (11) | 90 (5) | 21 (13) | 107 (6) |
| Opponent | Clean-up | 2 | 123 (2) | 0 | 123 | 0 | 0% | 3.0 | - | 123 (2) | - | 88 (1) | 158 (1) |
| Opponent | Fast Hammer | 13 | 54 (13) | 12 | 42 | 7 | 46% | 3.1 | 55 (3) | 33 (6) | 86 (4) | 64 (9) | 28 (4) |
| Opponent | Hammer | 1 | 35 (1) | 0 | 35 | 100 | 0% | 2.0 | - | - | 35 (1) | 35 (1) | - |
| Opponent | Holder | 2 | 165 (2) | 0 | 165 | 0 | 100% | - | - | 165 (2) | - | 157 (1) | 188 (1) |
| Opponent | Shooter | 5 | 86 (5) | 35 | 51 | 0 | 0% | 2.8 | 0 (2) | 150 (3) | - | 77 (3) | 99 (2) |
| Opponent | War machine | 6 | 24 (6) | 24 | 0 | 21 | 0% | 2.7 | 29 (4) | 0 (2) | - | - | 24 (6) |
| Opponent | Wizard | 3 | 8 (3) | 8 | 0 | 12 | 0% | 2.0 | - | 0 (1) | 4 (1) | 2 (2) | - |

### Charged fights: h7-opp-dcce224-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 10 | 89 | 2.0 | 1.2 | 44 | 55 | -10 | 5 of 8 | 5 of 8 | -274 | +27 |
| Mine | Chaos Dwarfs | 2 | 618 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 6 | 213 | 59 | 1.3 | 1.2 | 44 | 55 | -10 | 5 of 8 | 5 of 8 | -274 | +27 |
| Opponent | Grand Cathay | 2 | 252 | 550 | 2.5 | 1.0 | 220 | 0 | +220 | 0 of 5 | 5 of 5 | - | +220 |
| Opponent | High Elf Realms | 1 | 140 | 230 | 1.0 | 1.0 | 230 | 0 | +230 | 0 of 1 | 1 of 1 | - | +230 |
| Opponent | Warriors of Chaos | 3 | 28 | 274 | 2.0 | 1.0 | 137 | 29 | +108 | 4 of 6 | 5 of 6 | - | +108 |
| **Opponent** | all armies | 6 | 122 | 359 | 2.0 | 1.0 | 179 | 14 | +165 | 4 of 12 | 11 of 12 | - | +165 |

### Effective charges: h7-opp-dcce224-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 4 (net -72) | 0 | 1 (net +165) | 0 | 0 | 3 (net +14) | 0 | 12% (1 of 8) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 1 (net +65) | 1 (net +0) | 3 (net +345) | 0 | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 1 (net +230) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Warriors of Chaos | 6 | 1 (net -173) | 0 | 0 | 2 (net +210) | 0 | 2 (net +155) | 1 | 0% (0 of 5) |

### Charged fights, damage counted: h7-opp-dcce224-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 94 | 374 | -72 | 62 | 116 | -55 | -58.5 |
| Mine | Effective (55-75%) | 1 | 52 | 165 | +165 | 165 | 0 | +165 | +317.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 575 | 252 | +14 | 73 | 16 | +57 | +10.0 |
| Mine | All fights | 8 | 269 | 302 | -10 | 79 | 64 | +15 | +5.5 |
| Opponent | Long shot (under 50%) | 1 | 173 | 314 | -173 | 183 | 173 | +10 | +5.9 |
| Opponent | Effective (55-75%) | 2 | 288 | 148 | +148 | 148 | 0 | +148 | +51.3 |
| Opponent | 76-89% | 3 | 378 | 167 | +140 | 140 | 35 | +105 | +27.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 486 | 291 | +155 | 200 | 0 | +200 | +41.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 365 | 78 | +345 | 360 | 70 | +289 | +79.2 |
| Opponent | No odds | 1 | 285 | 91 | +91 | 91 | 0 | +91 | +31.9 |
| Opponent | All fights | 12 | 353 | 168 | +165 | 206 | 41 | +165 | +46.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h7-opp-dcce224-p3 | move | 36 | 7 (19%) | 5 (14%) | 6 (17%) | 23 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Elixir of Power | Opponent | L0111, L0211 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211 |
| Ring of Jet | Opponent | L0111, L0211 |
| Standard of the Fell Warrior | Opponent | L0313 |

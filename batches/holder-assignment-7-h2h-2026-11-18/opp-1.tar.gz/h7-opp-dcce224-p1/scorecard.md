# Doctrine scorecard: h7-opp-dcce224-p1

### Scorecard: h7-opp-dcce224-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 445 |
| L0120 | 6 | 1 | Mine | no | 10 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Mine | no | 6 | 4 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Opponent | no | 4 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L0219 | 3 | 1 | Opponent | yes | 8 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Opponent | no | 3 | 2 | 4 | 2 | 0 | 0 | 0 | 112 |
| L0321 | 3 | 1 | Mine | no | 4 | 3 | 1 | 1 | 0 | 0 | 0 | 225 |
| L0321 | 3 | 1 | Opponent | yes | 7 | - | 0 | 3 | 1 | 0 | 0 | 500 |
| L0406 | 4 | 1 | Mine | no | 3 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 550 |
| L0423 | 3 | 1 | Mine | no | 4 | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L0423 | 3 | 1 | Opponent | no | 8 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0510 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 350 |
| L0510 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 0 | 0 | 0 | 330 |
| L0525 | 3 | 1 | Mine | no | 10 | - | 0 | 2 | 0 | 0 | 0 | 383 |
| L0525 | 3 | 1 | Opponent | no | 4 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 10% | 4.5 | 3.2 | 1.7 | 1.5 | 0.1 | 0.0 | 0.0 | 112.8 |
| **Average** | | | Opponent | 20% | 4.0 | 1.8 | 1.7 | 1.8 | 0.2 | 0.0 | 0.0 | 193.7 |

### KPIs: h7-opp-dcce224-p1

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 10 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 37% (15 of 41) | 13% (6 of 46) | 24% (21 of 87) |
| Winner chose to follow up after the loser gave ground |  | 88% (7 of 8); on the table 88% | 75% (6 of 8); on the table 75% | 81% (13 of 16); on the table 81% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (3 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fled |  | 38% (3 of 8); on the table 50% | 75% (3 of 4); on the table 75% | 50% (6 of 12); on the table 58% |
| Winner chose to follow up or pursue (all three) |  | 68% (13 of 19); on the table 74% | 77% (10 of 13); on the table 77% | 72% (23 of 32); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 42% (58 of 138) | 35% (27 of 78) | 39% (85 of 216) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (58 of 118) | 46% (27 of 59) | 48% (85 of 177) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (7 of 11) | 67% (12 of 18) | 66% (19 of 29) |
| Points that never fought | lower | 47% (8829 of 18788) | 57% (11342 of 19993) | 52% (20171 of 38781) |
|   infantry points that never fought | lower | 67% (3649 of 5442) | 86% (4026 of 4683) | 76% (7675 of 10125) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (35 of 66) | 58% (46 of 79) | 56% (81 of 145) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.4 uses a game | 67% (2 of 3); 0.4 uses a game | 89% (8 of 9); 0.9 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 88% (7 of 8); 0.7 uses a game | 40% (2 of 5); 0.2 uses a game | 69% (9 of 13); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (6351 of 14152) | 54% (9189 of 17156) | 50% (15540 of 31308) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (46%) | 2.0 (39%) | 5.7 (44%) |
| MARCHED: its unit marched | 2.1 (26%) | 1.0 (20%) | 3.1 (24%) |
| CHARGED: its unit charged | 0.2 (2%) | 0.2 (4%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.5 (19%) | 1.5 (29%) | 3.0 (23%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.5 (6%) | 0.1 (2%) | 0.6 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.4 | 0.7 | 2.3 | 8.5 | 0.9 | 1.0 |
| not cast | 2.4 | 1.1 | 5.5 | 13.1 | 2.7 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.5 (45%) | 1.3 (24%) | 5.7 (44%) | 0.3 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.1 (24%) | 0.4 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (17%) | 0.0 (0%) | 1.0 (18%) | 3.0 (23%) | 0.9 (33%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.1 (4%) | 0.0 (0%) | 0.1 (2%) | 0.6 (5%) | 0.4 (15%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (8%) | 0.1 (9%) | 0.2 (4%) | 0.2 (2%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (19%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (71%) | 0.5 (45%) | 2.8 (51%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.5 a game | 0.5 a game | 1.5 a game |
| stood (cast and not dispelled) | 64% (16 of 25) | 60% (3 of 5) | 63% (19 of 30) |
| the unit moved after it | 69% (11 of 16) | 100% (3 of 3) | 74% (14 of 19) |
| it charged on its next turn | 0% (0 of 16) | 0% (0 of 3) | 0% (0 of 19) |
| the enemy charged it first | 6% (1 of 16) | 0% (0 of 3) | 5% (1 of 19) |
| it fought by the end of its next turn | 6% (1 of 16) | 0% (0 of 3) | 5% (1 of 19) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 16) | 0% (0 of 3) | 0% (0 of 19) |
| none of these (no charge, no fight, no charge escaped) | 94% (15 of 16) | 100% (3 of 3) | 95% (18 of 19) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (131 of 206) | 65% (133 of 204) | 64% (264 of 410) |
|   cavalry | 75% (6 of 8) | 70% (14 of 20) | 71% (20 of 28) |
|   character | 79% (23 of 29) | 60% (9 of 15) | 73% (32 of 44) |
|   chariot | 45% (15 of 33) | 53% (30 of 57) | 50% (45 of 90) |
|   infantry | 52% (23 of 44) | 63% (39 of 62) | 58% (62 of 106) |
|   monster | - | 100% (5 of 5) | 100% (5 of 5) |
|   war machine | 70% (64 of 92) | 80% (36 of 45) | 73% (100 of 137) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (33%) | 2.0 (28%) | 4.5 (31%) |
| CHARGED: it charged | 0.1 (1%) | 0.8 (11%) | 0.9 (6%) |
| IN COMBAT: it fought this turn or the last | 1.0 (13%) | 0.2 (3%) | 1.2 (8%) |
| MOVED: a war machine that moved | 1.3 (17%) | 0.1 (1%) | 1.4 (10%) |
| NO TARGET IN RANGE | 1.2 (16%) | 2.0 (28%) | 3.2 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (1%) | 0.5 (7%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (9%) | 1.0 (14%) | 1.7 (12%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.5 (7%) | 0.4 (6%) | 0.9 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.4 | 80% | 6.0 pts | 12 pts |
| character | 3.5 | 2.5 | 60% | 12.9 pts | 45 pts |
| chariot | 4.8 | 6.1 | 50% | 20.4 pts | 98 pts |
| infantry | 9.3 | 3.6 | 70% | 6.9 pts | 64 pts |
| monster | 0.5 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 10.0 | 6.2 | 68% | 15.7 pts | 157 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.1 | 3.7 | 3.4 |
| Charges that made contact a game | 2.4 | 2.7 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.83 declared, 0.83 contact (6 units) | 1.10 declared, 1.00 contact (10 units) | 1.00 declared, 0.94 contact (16 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.32 contact (60 units) | 0.31 declared, 0.19 contact (78 units) | 0.36 declared, 0.25 contact (138 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (2 of 6) | 100% (3 of 3) | - | 56% (5 of 9) |
| Character in a unit | 73% (11 of 15) | 44% (4 of 9) | - | 62% (15 of 24) |
| Character on its own | 91% (10 of 11) | 56% (5 of 9) | 18% (2 of 11) | 55% (17 of 31) |
| Chariot | 67% (2 of 3) | 42% (5 of 12) | - | 47% (7 of 15) |
| Infantry | 35% (8 of 23) | 40% (6 of 15) | - | 37% (14 of 38) |
| Monster | 80% (4 of 5) | 67% (2 of 3) | - | 75% (6 of 8) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |
| War Machines | 87% (13 of 15) | 100% (3 of 3) | - | 89% (16 of 18) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 56% (5 of 9); on the table 67% | 39% (40 of 102) | 45% | 41% (9 of 22) | 100% (6 of 6); 3.5 uses a game | 100% (2 of 2); 1.8 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 7 | 77% (10 of 13); on the table 77% | 52% (31 of 60) | 55% | 54% (29 of 54) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.1 uses a game |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 59% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 23% (7 of 30) | 48% | 40% (4 of 10) | 50% (1 of 2); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 17% (1 of 6) | 0% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 100% (2 of 2); on the table 100% | 33% (4 of 12) | 77% | 56% (9 of 16) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 75% (3 of 4); on the table 75% | - | 30% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 61% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h7-opp-dcce224-p1, 10 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 35% (6) | 38% (5) | 37% (11) |
| ...free all their last turn and able to turn (per game) | 0.20 | 0.50 | 0.70 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.30 | 0.00 | 0.30 |
| ...with the charger already in that arc before they moved (per game) | 0.20 | 0.30 | 0.50 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: h7-opp-dcce224-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 1.9 |
| Strategy | Charge objectives carried out (made contact) | 67% (20 of 30) | 48% (15 of 31) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (38 of 117) | 53% (45 of 85) |
| Strategy | Support requests answered (helper made contact too) | 75% (3 of 4) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (5 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 41% (12 of 29) | 0% (0 of 10) |
| Strategy | Lone characters that fought | 63% (12 of 19) | 65% (15 of 23) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.5 | 1.8 |
| Movement | Points that never moved of their own | 112.8 | 193.7 |
| Movement | Fights charged into per game | 2.1 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 21, net -339 | 6 of 18, net +193 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 21, net +11 | 2 of 18, net +95 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 21, net +79 | 1 of 18, net +110 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 of 21, net +55 | 4 of 18, net +179 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.7 | 10.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (21 of 67) | 45% (49 of 109) |
| Shooting | Points destroyed by shooting units | 103.0 | 19.2 |
| Shooting | War machine shots | 6.4 | 3.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (27 of 64) | 83% (30 of 36) |
| Shooting | Points destroyed by war machines | 60.1 | 6.5 |
| Magic | Magic missiles cast | 2.9 | 1.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (8 of 29) | 56% (10 of 18) |
| Magic | Wounds caused by magic missiles | 7.5 | 2.3 |
| Magic | Wounds caused by other spells | 0.4 | - |
| Magic | Points destroyed by magic (all spells) | 30.0 | 12.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 0.6 / 0.3 | 2.7 / 0.3 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 180.3 | 358.9 |
| Combat | Points run down | 0.0 | 37.8 |
| Combat | Net points per charged fight, damage counted | +83 | +123 |
| Combat | Net per 100 charger points, damage counted | +27.7 | +34.8 |
| Combat | First round won (charged fights) | 90% | 65% |
| Combat | Net points per charged fight | +60 | +146 |
| Combat | Net points per supported fight / lone fight | +28 / +68 | +95 / +148 |
| Combat | Charged fights on a top-3 enemy unit | 9 of 21 | 10 of 23 |
| Game | Points lost | 466.4 | 606.6 |
| Game | VP from objectives | 729.0 | 714.0 |
| Game | Lone holders (player turns) | 4.5 | 4.0 |

- Mine won / drew / lost: 5 / 2 / 3 of 10 ended games (of 10); mean margin (Mine - Opponent) +178 VP
- The side that went first won 3 of 8 games with a winner
- Points traded per game (both sides' losses): 1073
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h7-opp-dcce224-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +24.1 | 0.0 | 0.0 | 0.2 | +9.1 | 0.0 | 18.3 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 3.2 | +0.0 | 0.0 | 64.5 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.9 | 0.0 | 11.2 | 0.2 | +0.9 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.1 | -2.6 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 79.2 | 20.5 | 0.1 | +0.0 | 9.5 | 16.5 |
| CANNON PLANNED TARGET | 6.2 | +89.7 | 259.4 | 137.0 | 3.7 | +39.0 | 6.5 | 55.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +9.4 | 0.0 | 0.0 | 1.2 | +9.8 | 21.8 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.6 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 21.1 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.2 | +11.1 | 0.0 | 6.8 |
| CHAFF PASSED | - | - | - | - | 0.1 | +0.0 | 0.0 | 14.5 |
| CHARACTER GUNS | 0.2 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.4 | -254.4 | 0.0 | 92.2 | 4.9 | -178.3 | 0.0 | 35.0 |
| CHARGE NOT DECLARED | 0.9 | +0.0 | 31.1 | 47.6 | 0.4 | +0.0 | 20.5 | 0.0 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 138.1 | 33.9 | 1.7 | +0.0 | 127.4 | 19.5 |
| CHARGER SLAIN LOST | 0.4 | -3.0 | 5.5 | 13.7 | 0.2 | -1.6 | 9.5 | 6.0 |
| CHEAP HELPER | 0.2 | +0.0 | 12.4 | 0.0 | - | - | - | - |
| CHEAPEST HOLDER | 0.1 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 5.5 | 62.0 | 0.8 | +0.0 | 0.0 | 42.0 |
| CONVEYANCE SEARCH | 2.0 | +153.3 | 6.5 | 0.0 | 0.3 | +9.3 | 21.1 | 21.1 |
| COVER ONCE | 5.0 | -267.5 | 0.0 | 117.4 | 6.3 | -423.5 | 0.0 | 109.7 |
| DEPLOY BY FIGURES | 8.4 | +24.5 | 0.0 | 6.5 | 8.4 | +13.2 | 0.0 | 38.9 |
| EDGE GIVE GROUND | 0.1 | +0.9 | 6.5 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.4 | +0.8 | 82.1 | 8.5 | 2.5 | +2.6 | 199.0 | 19.5 |
| FALLBACK BY WORTH | 0.2 | +2.4 | 0.0 | 0.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| FALLS SHORT | 8.1 | +144.5 | 0.0 | 61.2 | 14.7 | +187.8 | 0.0 | 89.4 |
| FEATURE BUFFS | 2.2 | +68.5 | 0.0 | 11.0 | 0.5 | +19.5 | 0.0 | 12.4 |
| FIGHT TO THE END | 1.1 | +100.6 | 102.6 | 33.9 | 0.8 | +80.1 | 54.0 | 0.0 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 45.6 | +2412.2 | 612.4 | 560.9 | 47.7 | +2793.6 | 297.9 | 480.4 |
| FLANK NOT WEIGHED | 3.5 | +0.0 | 0.0 | 134.1 | 5.6 | +0.0 | 0.0 | 95.2 |
| FOLLOW UP WEIGHED | 0.3 | +56.1 | 0.0 | 0.0 | 0.7 | +223.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +340.3 | 179.2 | 52.8 | 3.0 | +333.1 | 225.3 | 44.7 |
| FRIEND CHARGES FIRST | 0.2 | -21.1 | 0.0 | 8.5 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.5 | -10.3 | 0.0 | 0.0 | 0.2 | -5.6 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.1 | -0.4 | 6.6 | 0.0 | 0.4 | -3.6 | 30.0 | 6.0 |
| GROUND FLIERS | 0.2 | +6.6 | 0.0 | 21.9 | - | - | - | - |
| GUN FIGURES | 1.6 | -0.2 | 11.5 | 31.0 | 1.9 | +7.7 | 23.7 | 6.5 |
| GUN MASK | 0.4 | +4.7 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 5.2 | 1.5 | +0.0 | 0.0 | 6.6 |
| HE SHOOTS OR CHARGES | 1.6 | +0.0 | 0.0 | 60.3 | 2.4 | +0.0 | 0.0 | 38.1 |
| HIS CHARGE DENIED | 0.1 | +4.8 | 19.5 | 0.0 | 0.1 | +3.9 | 11.2 | 19.5 |
| HIS CHARGE LIST | 2.6 | +0.0 | 0.0 | 20.7 | 1.0 | +0.0 | 0.0 | 3.8 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 31.0 | 2.7 | +0.0 | 0.0 | 16.7 |
| HIS MOVE AND SHOT | 2.9 | -43.2 | 0.0 | 20.5 | 0.8 | -40.8 | 0.0 | 14.5 |
| HIS ONE QUARTER | - | - | - | - | 1.1 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 2.0 | +0.0 | 0.0 | 5.5 | 1.4 | +0.0 | 0.0 | 17.9 |
| HIS SHOT LIST | 17.8 | +430.7 | 0.0 | 253.8 | 22.1 | +798.7 | 0.0 | 315.0 |
| HIS TURN DENIED | 1.1 | +30.2 | 75.7 | 33.9 | 1.8 | +48.5 | 171.1 | 25.2 |
| HOLD ODDS | - | - | - | - | 12.6 | +0.0 | 0.0 | 64.4 |
| HOLDER ASSIGNMENT | - | - | - | - | 14.7 | +1317.5 | 0.0 | 52.0 |
| HOLDER AT DEPLOYMENT | 1.0 | +189.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.1 | -84.5 | 173.7 | 39.1 | 2.9 | -155.6 | 215.8 | 38.7 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +22.8 | 0.0 | 19.5 |
| HUNT RESULT | - | - | - | - | 0.1 | +14.9 | 9.5 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +16.7 | 9.5 | 0.0 |
| IDLE COST | 5.0 | -50.3 | 0.0 | 29.9 | 11.1 | -146.7 | 0.0 | 75.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.9 | 18.3 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +5.4 | 0.0 | 0.0 | 0.9 | +29.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.5 | +0.0 | 60.5 | 167.5 | 4.3 | +0.0 | 267.8 | 31.6 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 1.0 | +61.8 | 0.0 | 11.5 | 0.3 | +32.6 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -1.7 | 0.0 | 0.0 | 0.1 | -0.8 | 18.9 | 0.0 |
| LOST CHARGE | 0.1 | -0.3 | 6.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.2 | +6.2 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +7.0 | 0.0 | 0.0 | 1.1 | +9.3 | 0.0 | 5.5 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +7.3 | 0.0 | 0.0 | 0.3 | +12.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.9 | +60.2 | 0.0 | 16.2 | 0.4 | +18.1 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.1 | -1.5 | 0.0 | 0.0 | 0.5 | +22.2 | 0.0 | 32.9 |
| MAX FOR POSITIONING | 3.8 | +38.5 | 0.0 | 33.0 | 4.0 | +45.5 | 0.0 | 76.8 |
| MISSILES IN THE MOVE | 4.8 | +238.0 | 0.0 | 16.2 | 3.5 | +47.3 | 0.0 | 21.1 |
| MISSILES NEXT TURN | 4.6 | +133.9 | 0.0 | 24.3 | 4.8 | +45.5 | 0.0 | 54.0 |
| MODEL FACING | - | - | - | - | 0.8 | +202.1 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.5 | +13.0 | 0.0 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.4 | -73.8 | 31.3 | 0.0 | 0.9 | -25.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.9 | +0.0 | 0.0 | 6.5 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.8 | +204.7 | 0.0 | 8.5 | 3.3 | +374.2 | 0.0 | 12.6 |
| MOVES UNITS SPELL | 0.2 | +11.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.5 | +175.7 | 0.0 | 0.0 | 5.3 | +210.1 | 0.0 | 51.2 |
| NEEDED THERE | - | - | - | - | 0.1 | +48.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.8 | -113.6 | 14.5 | 16.7 | 4.6 | -265.5 | 0.0 | 17.1 |
| NEXT OBJECTIVE NEARER | 5.9 | -233.2 | 16.7 | 44.1 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.2 | -111.2 | 125.7 | 52.8 | 2.4 | -85.3 | 180.7 | 38.7 |
| NOT WORTH A CAST | 0.5 | -0.8 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.4 | -30.0 | 0.0 | 0.0 | 0.4 | -5.1 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.4 | +0.0 | 0.0 | 99.7 | 1.9 | +0.0 | 0.0 | 54.3 |
| ONE FIGHT FORMULA | 4.1 | -53.5 | 0.0 | 8.5 | 5.3 | -120.9 | 0.0 | 64.6 |
| ONE OBJECTIVE FORMULA | 4.9 | +125.9 | 0.0 | 17.7 | 4.7 | -11.4 | 0.0 | 26.9 |
| ONE TARGET A SHOOTER | 13.9 | +376.1 | 0.0 | 183.2 | 19.7 | +519.3 | 0.0 | 293.5 |
| OPENS UP | 0.2 | +11.5 | 22.0 | 0.0 | 0.5 | +28.9 | 22.2 | 19.5 |
| OVERRUNS AWAY | 0.3 | +1.3 | 17.1 | 0.0 | 0.7 | +33.5 | 48.9 | 19.2 |
| PATHS CROSS | 2.6 | +47.7 | 0.0 | 23.0 | 3.6 | +100.3 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.2 | +16.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -7.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 39.9 | +727.8 | 394.4 | 704.9 | 42.7 | +471.5 | 166.5 | 852.5 |
| QUARTER ODDS | - | - | - | - | 8.8 | +1003.0 | 34.4 | 48.1 |
| RANDOM MOVE BY FIGURES | 1.1 | +3.1 | 0.0 | 0.0 | 1.8 | +39.7 | 0.0 | 113.0 |
| REAL GROUND | - | - | - | - | 0.8 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.2 | -4.4 | 0.0 | 6.8 |
| REDIRECT COUNTER | 1.4 | +128.5 | 0.0 | 27.8 | 1.4 | +43.5 | 0.0 | 42.1 |
| REDIRECT WEIGHED | 0.3 | +1.2 | 0.0 | 0.0 | 0.3 | +21.4 | 31.0 | 19.5 |
| REFORMS TO MEET IT | 0.6 | -24.2 | 0.0 | 0.0 | 0.5 | -6.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +21.4 | 0.0 | 0.0 | 0.5 | +11.8 | 0.0 | 11.2 |
| RESTRAINS TO SHOOT | 0.1 | +10.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.3 | +32.5 | 159.7 | 47.6 | 1.9 | -24.9 | 166.9 | 44.7 |
| RISK BY HIS FIGURE | 12.0 | -135.8 | 0.0 | 228.9 | 10.6 | -75.3 | 0.0 | 192.1 |
| RUN DOWN | 1.3 | -20.3 | 65.7 | 10.4 | 1.3 | -14.6 | 116.1 | 38.7 |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -1.4 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | +2.4 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.1 | -7.0 | 0.0 | 6.0 |
| SEARCH SPOT | 6.4 | +224.8 | 0.0 | 41.2 | 5.5 | +188.6 | 0.0 | 49.5 |
| SELF MOVE SPELL | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.4 | +10.0 | 0.0 | 0.0 | 0.5 | +18.2 | 0.0 | 12.6 |
| SET-UP ANY TARGET | 0.4 | +66.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +31.2 | 26.0 | 0.0 | 1.2 | +32.4 | 7.3 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -2.8 | 0.0 | 8.5 | 0.1 | -1.2 | 18.9 | 0.0 |
| SHOT RISK POINTS | 10.7 | -96.0 | 0.0 | 198.4 | 11.4 | +52.0 | 0.0 | 247.0 |
| SHOTS IN THE MOVE | 14.3 | +433.4 | 0.0 | 313.0 | 13.9 | +256.8 | 0.0 | 125.1 |
| SPELL SETS UP CHARGE | 0.4 | +66.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +6.2 | 0.0 | 0.0 | 1.6 | +14.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.5 | -1.0 | 56.1 | 0.0 | 0.4 | +3.2 | 34.5 | 0.0 |
| STAND AND SHOOT | 0.3 | -2.0 | 10.5 | 0.0 | 0.5 | -3.7 | 48.7 | 38.7 |
| STANDS FOR A REASON | 0.2 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 8.5 | 0.0 |
| STANDS STILL | 19.0 | +0.0 | 414.9 | 339.6 | 14.8 | +0.0 | 53.6 | 143.3 |
| STAY WORTH | 18.4 | -8.9 | 245.7 | 243.3 | 13.6 | +12.1 | 16.0 | 95.2 |
| STOPS | - | - | - | - | 0.1 | +0.8 | 9.5 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 42.0 |
| SUPPORT NARROWED | 1.1 | +0.0 | 40.3 | 8.5 | 0.6 | +0.0 | 53.3 | 19.5 |
| SURE REACH TOGETHER | 0.6 | +4.4 | 0.0 | 0.0 | 0.3 | +25.2 | 0.0 | 12.6 |
| THE DEARER SUM KEEPS ITS PLAN | 3.1 | +0.0 | 0.0 | 0.0 | 3.5 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -14.6 | 0.0 | 0.0 | 0.2 | -2.9 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.2 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 5.5 |
| TIED UP BY THE SUM | 0.6 | +55.3 | 50.2 | 0.0 | 0.5 | +49.8 | 65.7 | 19.5 |
| TIME ON OUR SIDE | 20.6 | +336.1 | 29.3 | 139.5 | 12.5 | +182.5 | 5.2 | 79.4 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 11.2 | 0.8 | +0.0 | 0.0 | 19.1 |
| WALK PROMISE | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +19.4 | 0.0 | 0.0 | 0.1 | +6.0 | 9.5 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 31.5 | 0.0 | 0.5 | +0.0 | 18.0 | 0.0 |
| WHO HITS BACK | 0.2 | +121.2 | 0.0 | 0.0 | 0.2 | +6.1 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +0.4 | 0.0 | 8.5 | - | - | - | - |
| WHOLE FIGHT GAIN | 0.3 | +12.2 | 30.7 | 5.2 | 0.1 | +2.7 | 18.9 | 0.0 |
| WIDER SPREAD | 1.9 | -1.1 | 142.3 | 52.8 | 2.1 | -2.6 | 176.1 | 6.0 |
| WOUNDS ON THE RANKS | 2.4 | +107.0 | 0.0 | 0.0 | 1.0 | +31.5 | 0.0 | 16.7 |

### Rule changes: h7-opp-dcce224-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 147 | 147 | 135 | 13.50 | +6131 | +45.4 |
| SEARCH SPOT | 119 | 119 | 112 | 11.20 | +4136 | +36.9 |
| HIS SHOT LIST | 399 | 399 | 107 | 10.70 | +1613 | +15.1 |
| DEPLOY BY FIGURES | 168 | 168 | 99 | 9.90 | +2187 | +22.1 |
| ONE TARGET A SHOOTER | 336 | 336 | 93 | 9.30 | +889 | +9.6 |
| LEGAL CHARGES ONLY | 78 | 78 | 78 | 7.80 | +0 | +0.0 |
| TIME ON OUR SIDE | 331 | 299 | 69 | 6.90 | +377 | +5.5 |
| PATHS CROSS | 62 | 62 | 62 | 6.20 | +1480 | +23.9 |
| FIVE ACTION | 933 | 933 | 52 | 5.20 | +1280 | +24.6 |
| MOVE TO CHARGE COMPUTED | 61 | 61 | 48 | 4.80 | +2082 | +43.4 |
| SHOT RISK POINTS | 221 | 221 | 42 | 4.20 | +920 | +21.9 |
| ARTILLERY RE-ROLL WEIGHED | 37 | 37 | 37 | 3.70 | +0 | +0.0 |
| FOUR ROUNDS | 57 | 57 | 37 | 3.70 | +2606 | +70.4 |
| COVER ONCE | 113 | 94 | 22 | 2.20 | +200 | +9.1 |
| HARD STAY DROPPED | 22 | 22 | 22 | 2.20 | +0 | +0.0 |
| IDLE COST | 161 | 124 | 19 | 1.90 | +107 | +5.6 |
| RANDOM MOVE BY FIGURES | 29 | 29 | 19 | 1.90 | +428 | +22.5 |
| SHOTS IN THE MOVE | 282 | 248 | 19 | 1.90 | +697 | +36.7 |
| CANNON PLANNED TARGET | 99 | 99 | 18 | 1.80 | -206 | -11.5 |
| CANNON SIGHT KEPT | 18 | 18 | 18 | 1.80 | +0 | +0.0 |
| FALLS SHORT | 228 | 191 | 17 | 1.70 | +224 | +13.2 |
| MAX FOR POSITIONING | 78 | 78 | 15 | 1.50 | +52 | +3.5 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 14 | 1.40 | +124 | +8.8 |
| CHARGE NOT DECLARED | 13 | 13 | 13 | 1.30 | -1900 | -146.2 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.30 | +944 | +72.7 |
| MISSILES IN THE MOVE | 83 | 65 | 13 | 1.30 | +318 | +24.4 |
| ONE OBJECTIVE FORMULA | 96 | 82 | 13 | 1.30 | +652 | +50.2 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 1.20 | +0 | +0.0 |
| COMBAT PIVOT | 12 | 12 | 12 | 1.20 | +0 | +0.0 |
| LANE BY FIGURES | 12 | 12 | 12 | 1.20 | +344 | +28.7 |
| MANOEUVRE | 21 | 21 | 12 | 1.20 | +229 | +19.1 |
| NEXT OBJECTIVE NEARER | 59 | 59 | 11 | 1.10 | +80 | +7.3 |
| RISK BY ARC | 42 | 42 | 11 | 1.10 | +231 | +21.0 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 1.00 | +2799 | +279.9 |
| CHARGE NOW FIRST | 33 | 33 | 9 | 0.90 | -885 | -98.3 |
| MARCH CHECK | 13 | 13 | 9 | 0.90 | +134 | +14.9 |
| TIED UP BY THE SUM | 11 | 11 | 9 | 0.90 | +164 | +18.2 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.80 | +0 | +0.0 |
| MODEL FACING | 8 | 8 | 8 | 0.80 | +2021 | +252.7 |
| OFF BEST | 8 | 8 | 8 | 0.80 | -351 | -43.9 |
| QUARTER ODDS | 88 | 88 | 8 | 0.80 | +307 | +38.4 |
| RESERVE FALL BACK | 8 | 8 | 8 | 0.80 | +332 | +41.5 |
| WOUNDS ON THE RANKS | 34 | 34 | 8 | 0.80 | +442 | +55.2 |
| CAST JOB | 25 | 25 | 7 | 0.70 | +17 | +2.4 |
| CHARGE LOSSES | 113 | 113 | 7 | 0.70 | +416 | +59.5 |
| NEXT CHARGE BY LIST | 84 | 84 | 7 | 0.70 | +85 | +12.2 |
| REDIRECT COUNTER | 28 | 20 | 7 | 0.70 | +1228 | +175.5 |
| SHOOTERS IN TWO RANKS | 7 | 7 | 7 | 0.70 | +17 | +2.4 |
| FEATURE BUFFS | 27 | 27 | 6 | 0.60 | +43 | +7.2 |
| HIS TURN DENIED | 29 | 29 | 6 | 0.60 | +65 | +10.8 |
| HOLDER AT DEPLOYMENT | 10 | 10 | 6 | 0.60 | +279 | +46.6 |
| MARCH BY THE SUM | 6 | 6 | 6 | 0.60 | +201 | +33.5 |
| NEARER NOT NEEDED | 88 | 83 | 6 | 0.60 | +202 | +33.6 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 0.60 | +311 | +51.8 |
| RISK BY HIS FIGURE | 226 | 226 | 6 | 0.60 | +364 | +60.6 |
| FIGHT TO THE END | 19 | 19 | 5 | 0.50 | +496 | +99.3 |
| CASTING BLOCK | 6 | 6 | 4 | 0.40 | +400 | +100.0 |
| OVERRUNS AWAY | 10 | 10 | 4 | 0.40 | +63 | +15.8 |
| SCOUT WAITS | 4 | 4 | 4 | 0.40 | +0 | +0.0 |
| STAY WORTH | 320 | 296 | 4 | 0.40 | +41 | +10.3 |
| STUCK PIVOT | 4 | 4 | 4 | 0.40 | +0 | +0.0 |
| SURE REACH TOGETHER | 9 | 9 | 4 | 0.40 | +36 | +9.1 |
| WAR ENGINE JOBS | 10 | 10 | 4 | 0.40 | -219 | -54.7 |
| WHO HITS BACK | 4 | 4 | 4 | 0.40 | +807 | +201.7 |
| WHOLE FIGHT GAIN | 4 | 4 | 4 | 0.40 | +24 | +6.1 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.30 | +332 | +110.5 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 0.30 | +0 | +0.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.30 | +114 | +38.2 |
| OPENS UP | 7 | 7 | 3 | 0.30 | +67 | +22.2 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.30 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.20 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.20 | +0 | +0.0 |
| FALLBACK BY WORTH | 5 | 5 | 2 | 0.20 | +26 | +12.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.20 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.20 | +41 | +20.3 |
| NO DOUBLE ROUNDS | 46 | 46 | 2 | 0.20 | +11 | +5.4 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.20 | +160 | +80.1 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.20 | -71 | -35.5 |
| SET UP TOGETHER | 9 | 4 | 2 | 0.20 | +94 | +47.2 |
| WIDER SPREAD | 40 | 40 | 2 | 0.20 | +5 | +2.3 |
| BACKUP TARGETS | 4 | 2 | 1 | 0.10 | +5 | +5.4 |
| CHAFF PASSED | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| FRIEND CHARGES FIRST | 2 | 2 | 1 | 0.10 | +1 | +1.3 |
| HIS MOVE AND SHOT | 37 | 37 | 1 | 0.10 | +9 | +9.4 |
| HONEST WORTH | 50 | 50 | 1 | 0.10 | +53 | +52.8 |
| HUNT IN PAIRS | 7 | 5 | 1 | 0.10 | +28 | +28.2 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| KILLS COUNT | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| LONG SHOT | 6 | 6 | 1 | 0.10 | +3 | +3.1 |
| MARCH ODDS | 1 | 1 | 1 | 0.10 | -0 | -0.4 |
| NEEDED THERE | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| ONE FIGHT FORMULA | 94 | 48 | 1 | 0.10 | +0 | +0.1 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.10 | -0 | -0.1 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.10 | +105 | +105.0 |
| RUN DOWN | 26 | 26 | 1 | 0.10 | +4 | +4.2 |
| STOPS | 1 | 1 | 1 | 0.10 | +3 | +3.3 |
| SUPPORT NARROWED | 17 | 17 | 1 | 0.10 | -54 | -53.8 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.10 | +13 | +13.5 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 19 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 11 | 11 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 1 | 1 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 23 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 39 | 39 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 91 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 35 | not checked | - | - | - | - |
| GUN MASK | 5 | 5 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 40 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 36 | 36 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 54 | 54 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 34 | 34 | 0 | 0.00 | - | - |
| HOLD ODDS | 126 | 126 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 94 | 71 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 33 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 53 | 53 | 0 | 0.00 | - | - |
| PLAN RESULT | 826 | trace | - | - | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 11 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 23 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 8 | 8 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 338 | 338 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 66 | not checked | - | - | - | - |
| THE PROMISE ADDS | 5 | 5 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 15 | not checked | - | - | - | - |
| WAITS AGAIN | 25 | 25 | 0 | 0.00 | - | - |
| WALK PROMISE | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: h7-opp-dcce224-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.40 | 14.0 |
| CHARGE NOT DECLARED | rule | 0.90 | 0.40 | 146.2 |
| CHARGE NOW FIRST | rule | 0.30 | 0.60 | 98.3 |
| PATHS CROSS | rule | 0.50 | 0.20 | 24.9 |
| CANNON PLANNED TARGET | rule | 0.40 | 0.20 | 40.1 |
| JOB FIRST | gate | 0.20 | 0.30 | 12.2 |
| WAR ENGINE JOBS | rule | 0.20 | 0.20 | 54.7 |
| PIVOT GUARDS FLANK | rule | 0.20 | - | 35.5 |
| AFTERMATH BAND | gate | - | 0.10 | 3.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.10 | - | 12.3 |
| RULE SWITCHED OFF | gate | 0.10 | - | 274.4 |
| SUPPORT NARROWED | rule | 0.10 | - | 53.8 |

### Plans: h7-opp-dcce224-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 78% | 353 | 231 | 65% |
| Mine | join | 0.6 | 100% | 20 | 0 | 0% |
| Mine | move | 26.9 | 94% | 1478 | 0 | 0% |
| Mine | shoot | 10.1 | 52% | 341 | 497 | 146% |
| Opponent | charge | 2.5 | 68% | 523 | 202 | 39% |
| Opponent | join | 0.5 | 100% | 28 | 0 | 0% |
| Opponent | move | 32.3 | 91% | 1632 | 0 | 0% |
| Opponent | shoot | 7.1 | 59% | 168 | 269 | 160% |
| Opponent | support | 0.3 | 67% | 0 | 0 | - |

### Packages: hunt the guns, h7-opp-dcce224-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 6 |
| Opponent | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 167 | 149 | 100% | 60 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 456 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 167 | 149 | 100% | 0 |

### Battle groups: h7-opp-dcce224-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.4 | 21% | 33% | 67% | 50% | 0% | 0% | 0% | 0% | 100% |
| Opponent | REDIRECT COUNTER | 1.4 | 36% | 100% | 0% | - | 40% | 0% | 0% | 60% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h7-opp-dcce224-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 9 | 76 (9) | 0 | 76 | 49 | 67% | 2.0 | 80 (1) | 101 (6) | 0 (2) | 105 (6) | 0 (3) |
| Mine | Character | 41 | 30 (41) | 30 | 0 | 17 | 10% | 2.5 | 59 (7) | 20 (21) | 29 (12) | 20 (24) | 44 (16) |
| Mine | Clean-up | 7 | 93 (7) | 5 | 88 | 42 | 71% | 5.0 | 0 (1) | 123 (4) | 25 (2) | 143 (4) | 51 (3) |
| Mine | Fast Hammer | 7 | 26 (7) | 26 | 0 | 55 | 14% | 4.0 | - | 6 (3) | 35 (4) | 23 (2) | 28 (5) |
| Mine | Hammer | 23 | 49 (23) | 17 | 32 | 18 | 26% | 2.7 | 35 (4) | 64 (10) | 36 (9) | 41 (13) | 60 (10) |
| Mine | Holder | 11 | 59 (11) | 3 | 56 | 18 | 64% | 4.0 | 0 (1) | 47 (8) | 161 (2) | 84 (5) | 40 (6) |
| Mine | Shooter | 2 | 327 (2) | 50 | 277 | 50 | 0% | 1.0 | 146 (1) | 508 (1) | - | 327 (2) | - |
| Mine | War machine | 18 | 28 (18) | 28 | 0 | 65 | 0% | 1.2 | 17 (7) | 69 (7) | 0 (4) | 0 (3) | 34 (15) |
| Mine | Wizard | 7 | 7 (7) | 7 | 0 | 18 | 14% | 2.5 | 26 (2) | 0 (1) | 0 (3) | 0 (3) | 18 (3) |
| Opponent | Chaff | 14 | 90 (14) | 10 | 81 | 85 | 36% | 2.4 | 118 (5) | 58 (3) | 78 (6) | 113 (6) | 73 (8) |
| Opponent | Character | 26 | 57 (26) | 57 | 0 | 11 | 31% | 2.4 | 40 (6) | 70 (9) | 71 (7) | 80 (10) | 41 (12) |
| Opponent | Clean-up | 12 | 38 (12) | 5 | 34 | 30 | 83% | 4.5 | 0 (5) | 62 (6) | 96 (1) | 57 (9) | 0 (3) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 6 | 7 (6) | 0 | 7 | 65 | 17% | 2.0 | 0 (1) | 18 (2) | 0 (3) | 54 (1) | 0 (5) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Hammer | 17 | 18 (17) | 9 | 9 | 22 | 24% | 3.2 | 13 (3) | 16 (12) | 34 (2) | 6 (7) | 27 (10) |
| Opponent | Holder | 14 | 149 (14) | 7 | 141 | 18 | 71% | 3.0 | 164 (4) | 134 (8) | 168 (2) | 139 (8) | 166 (6) |
| Opponent | Shooter | 11 | 20 (11) | 0 | 20 | 39 | 0% | 2.5 | 0 (3) | 35 (5) | 0 (3) | 31 (6) | 0 (5) |
| Opponent | War machine | 12 | 4 (12) | 4 | 0 | 58 | 8% | 1.9 | 0 (3) | 0 (3) | 7 (6) | 0 (2) | 5 (10) |
| Opponent | Wizard | 7 | 24 (7) | 24 | 0 | 65 | 14% | 2.3 | 43 (4) | 0 (1) | - | 87 (2) | 0 (3) |

### Charged fights: h7-opp-dcce224-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 80 | 84 | 1.8 | 1.6 | 48 | 20 | +28 | 2 of 7 | 6 of 7 | -24 | +68 |
| Mine | Chaos Dwarfs | 4 | 142 | 350 | 3.5 | 1.1 | 100 | 24 | +76 | 7 of 14 | 13 of 14 | +183 | +68 |
| Mine | Dwarfen Mountain Holds | 2 | 520 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 10 | 193 | 174 | 2.1 | 1.2 | 83 | 23 | +60 | 9 of 21 | 19 of 21 | +28 | +68 |
| Opponent | Chaos Dwarfs | 3 | 81 | 271 | 2.3 | 1.0 | 116 | 0 | +116 | 6 of 7 | 4 of 7 | - | +116 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 60 | -60 | 1 of 1 | 0 of 1 | - | -60 |
| Opponent | Grand Cathay | 1 | 138 | 592 | 5.0 | 1.4 | 118 | 0 | +118 | 0 of 5 | 4 of 5 | +95 | +124 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 52 | 1.0 | 1.0 | 52 | 0 | +52 | 0 of 1 | 1 of 1 | - | +52 |
| Opponent | Skaven | 2 | 0 | 88 | 1.0 | 1.0 | 88 | 0 | +88 | 0 of 2 | 2 of 2 | - | +88 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 809 | 3.0 | 1.0 | 270 | 0 | +270 | 2 of 3 | 3 of 3 | - | +270 |
| Opponent | Vampire Counts | 1 | 0 | 980 | 4.0 | 1.0 | 245 | 0 | +245 | 1 of 4 | 1 of 4 | - | +245 |
| **Opponent** | all armies | 10 | 38 | 342 | 2.3 | 1.1 | 149 | 3 | +146 | 10 of 23 | 15 of 23 | +95 | +148 |

### Effective charges: h7-opp-dcce224-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 0 | 2 (net -26) | 1 (net +271) | 0 | 4 (net -5) | 0 | 29% (2 of 7) |
| Mine | Chaos Dwarfs | 14 | 1 (net -339) | 0 | 2 (net +48) | 4 (net +152) | 3 (net +79) | 4 (net +114) | 0 | 14% (2 of 14) |
| Opponent | Chaos Dwarfs | 7 | 3 (net +111) | 0 | 0 | 1 (net +140) | 1 (net +110) | 1 (net +230) | 1 | 0% (0 of 6) |
| Opponent | Dwarfen Mountain Holds | 1 | 1 (net -60) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 1 (net +190) | 4 (net +100) | 0 | 0 | 0 | 20% (1 of 5) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +88) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +310) | 2 | 0% (0 of 1) |
| Opponent | Vampire Counts | 4 | 2 (net +442) | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 33% (1 of 3) |

### Charged fights, damage counted: h7-opp-dcce224-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 339 | 440 | -339 | 0 | 399 | -399 | -117.7 |
| Mine | Effective (55-75%) | 4 | 208 | 231 | +11 | 39 | 24 | +16 | +7.5 |
| Mine | 76-89% | 5 | 345 | 134 | +176 | 176 | 0 | +176 | +51.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 239 | 155 | +55 | 143 | 24 | +119 | +49.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 480 | 79 | +79 | 79 | 0 | +79 | +16.5 |
| Mine | All fights | 21 | 298 | 167 | +60 | 115 | 33 | +83 | +27.7 |
| Opponent | Long shot (under 50%) | 6 | 290 | 257 | +193 | 206 | 85 | +121 | +41.6 |
| Opponent | Effective (55-75%) | 2 | 230 | 106 | +95 | 95 | 32 | +63 | +27.6 |
| Opponent | 76-89% | 5 | 438 | 108 | +108 | 108 | 0 | +108 | +24.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 264 | 179 | +179 | 179 | 24 | +155 | +58.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 480 | 110 | +110 | 110 | 0 | +110 | +22.9 |
| Opponent | No odds | 5 | 436 | 182 | +129 | 140 | 0 | +140 | +32.0 |
| Opponent | All fights | 23 | 353 | 175 | +146 | 152 | 29 | +123 | +34.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h7-opp-dcce224-p1 | move | 67 | 16 (24%) | 9 (13%) | 11 (16%) | 40 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Charmed Shield | Opponent | L0525 |
| Elixir of Power | Opponent | L0219 |
| Invocation of Nehek | Opponent | L0525 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Ring of Jet | Opponent | L0510 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Opponent | L0510 |

# Doctrine scorecard: h7-mine-dcce224-p1

### Scorecard: h7-mine-dcce224-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 340 |
| L0120 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 1 | - | 0 | 4 | 0 | 0 | 0 | 210 |
| L0204 | 6 | 1 | Mine | no | 0 | 5 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0204 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | no | 8 | 2 | 4 | 0 | 1 | 0 | 0 | 255 |
| L0219 | 3 | 1 | Opponent | yes | 4 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 539 |
| L0304 | 4 | 1 | Opponent | no | 7 | 3 | 1 | 3 | 0 | 0 | 0 | 310 |
| L0321 | 3 | 1 | Mine | no | 7 | 5 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0321 | 3 | 1 | Opponent | no | 4 | - | 0 | 3 | 2 | 0 | 0 | 210 |
| L0406 | 4 | 1 | Mine | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 1027 |
| L0423 | 3 | 1 | Mine | no | 7 | 2 | 7 | 3 | 0 | 0 | 0 | 487 |
| L0423 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 90 |
| L0510 | 6 | 1 | Mine | no | 4 | - | 1 | 0 | 0 | 0 | 0 | 233 |
| L0510 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0525 | 3 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 276 |
| L0525 | 3 | 1 | Opponent | no | 3 | 3 | 1 | 4 | 0 | 0 | 0 | 85 |
| L0613 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 709 |
| L0613 | 1 | 1 | Opponent | no | 5 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.2 | 3.8 | 1.6 | 1.6 | 0.2 | 0.0 | 0.0 | 255.4 |
| **Average** | | | Opponent | 9% | 3.3 | 2.6 | 1.1 | 1.7 | 0.2 | 0.0 | 0.0 | 206.5 |

### KPIs: h7-mine-dcce224-p1

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 11 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 45% (19 of 42) | 15% (7 of 46) | 30% (26 of 88) |
| Winner chose to follow up after the loser gave ground |  | 67% (4 of 6); on the table 83% | 100% (10 of 10); on the table 100% | 88% (14 of 16); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 78% (7 of 9); on the table 89% | 80% (8 of 10); on the table 90% |
| Winner chose to follow up or pursue (all three) |  | 62% (5 of 8); on the table 75% | 90% (18 of 20); on the table 95% | 82% (23 of 28); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 46% (63 of 138) | 31% (26 of 84) | 40% (89 of 222) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (63 of 129) | 41% (26 of 63) | 46% (89 of 192) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | 85% (17 of 20) | 74% (20 of 27) |
| Points that never fought | lower | 61% (12667 of 20788) | 63% (13810 of 21993) | 62% (26477 of 42781) |
|   infantry points that never fought | lower | 71% (4470 of 6294) | 83% (4366 of 5252) | 77% (8836 of 11546) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (46 of 76) | 55% (48 of 87) | 58% (94 of 163) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 2.3 uses a game | 50% (2 of 4); 0.9 uses a game | 80% (8 of 10); 1.6 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.5 uses a game | 33% (1 of 3); 0.4 uses a game | 60% (3 of 5); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (6 of 8); 0.5 uses a game | 80% (4 of 5); 0.4 uses a game | 77% (10 of 13); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (8659 of 15642) | 50% (9518 of 19016) | 52% (18177 of 34658) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.8 (71%) | 1.8 (34%) | 6.6 (55%) |
| MARCHED: its unit marched | 0.8 (12%) | 1.3 (24%) | 2.1 (17%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.3 (5%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 0.5 (7%) | 1.2 (22%) | 1.6 (14%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.2 (3%) | 0.7 (14%) | 0.9 (8%) |
| STUPIDITY: Stupidity | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 0.5 | 2.8 | 8.1 | 0.6 | 0.7 |
| not cast | 2.8 | 1.2 | 4.8 | 12.1 | 2.6 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.5 (38%) | 1.0 (21%) | 6.6 (55%) | 0.4 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (17%) | 0.2 (7%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.2 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (15%) | 0.5 (9%) | 1.6 (14%) | 0.5 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (21%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.5 (3%) |
| GONE: slain | 0.5 (19%) | 0.1 (8%) | 0.4 (8%) | 0.9 (8%) | 0.1 (3%) | 1.2 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) | 0.3 (2%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (28%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (71%) | 0.5 (38%) | 2.9 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.6 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 1.1 a game | 1.7 a game |
| stood (cast and not dispelled) | 44% (11 of 25) | 33% (4 of 12) | 41% (15 of 37) |
| the unit moved after it | 36% (4 of 11) | 100% (4 of 4) | 53% (8 of 15) |
| it charged on its next turn | 0% (0 of 11) | 0% (0 of 4) | 0% (0 of 15) |
| the enemy charged it first | 0% (0 of 11) | 0% (0 of 4) | 0% (0 of 15) |
| it fought by the end of its next turn | 0% (0 of 11) | 0% (0 of 4) | 0% (0 of 15) |
| it moved out of a charge the enemy had planned (not charged first) | 9% (1 of 11) | 0% (0 of 4) | 7% (1 of 15) |
| none of these (no charge, no fight, no charge escaped) | 91% (10 of 11) | 100% (4 of 4) | 93% (14 of 15) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (168 of 265) | 71% (175 of 248) | 67% (343 of 513) |
|   cavalry | 36% (5 of 14) | 88% (21 of 24) | 68% (26 of 38) |
|   character | 73% (19 of 26) | 55% (11 of 20) | 65% (30 of 46) |
|   chariot | 25% (8 of 32) | 56% (31 of 55) | 45% (39 of 87) |
|   infantry | 54% (38 of 70) | 76% (56 of 74) | 65% (94 of 144) |
|   monster | 67% (4 of 6) | 67% (4 of 6) | 67% (8 of 12) |
|   war machine | 80% (94 of 117) | 75% (52 of 69) | 78% (146 of 186) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (27%) | 1.5 (22%) | 3.8 (25%) |
| CHARGED: it charged | 0.2 (2%) | 0.5 (8%) | 0.7 (5%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.4 (5%) | 1.3 (8%) |
| MOVED: a war machine that moved | 1.7 (20%) | 0.8 (12%) | 2.5 (16%) |
| NO TARGET IN RANGE | 1.5 (18%) | 1.6 (25%) | 3.2 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (18%) | 1.2 (18%) | 2.7 (18%) |
| OTHER BAR | 0.2 (2%) | 0.5 (8%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.4 | 0.6 | 77% | 6.4 pts | 15 pts |
| character | 2.9 | 1.9 | 56% | 20.5 pts | 60 pts |
| chariot | 3.6 | 3.0 | 50% | 13.7 pts | 50 pts |
| infantry | 13.1 | 3.7 | 79% | 8.6 pts | 113 pts |
| monster | 0.7 | 0.2 | 75% | 1.7 pts | 1 pts |
| war machine | 13.3 | 15.2 | 71% | 38.2 pts | 507 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.5 | 3.1 | 2.8 |
| Charges that made contact a game | 1.8 | 2.1 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.83 declared, 0.67 contact (6 units) | 0.55 declared, 0.45 contact (11 units) | 0.65 declared, 0.53 contact (17 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.31 declared, 0.23 contact (71 units) | 0.30 declared, 0.18 contact (87 units) | 0.30 declared, 0.20 contact (158 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 38% (3 of 8) | 33% (1 of 3) | - | 36% (4 of 11) |
| Character in a unit | 76% (16 of 21) | 70% (7 of 10) | - | 74% (23 of 31) |
| Character on its own | 83% (5 of 6) | 30% (3 of 10) | 33% (4 of 12) | 43% (12 of 28) |
| Chariot | 33% (1 of 3) | 75% (9 of 12) | - | 67% (10 of 15) |
| Infantry | 46% (13 of 28) | 29% (5 of 17) | - | 40% (18 of 45) |
| Monster | 83% (5 of 6) | 100% (3 of 3) | - | 89% (8 of 9) |
| Monstrous | - | 0% (0 of 2) | - | 0% (0 of 2) |
| War Machines | 89% (17 of 19) | 67% (2 of 3) | - | 86% (19 of 22) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (1 of 1); on the table 100% | 52% (53 of 102) | 72% | 64% (14 of 22) | 100% (6 of 6); 6.2 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 7 | 67% (4 of 6); on the table 83% | 30% (18 of 60) | 61% | 54% (29 of 54) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
| Dwarfen Mountain Holds | 4 | 67% (2 of 3); on the table 67% | - | 58% | 74% (25 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (5 of 5); on the table 100% | 20% (6 of 30) | 55% | 50% (5 of 10) | 0% (0 of 2); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 92% | 50% (4 of 8) | 100% (1 of 1); 5.0 uses a game | 50% (1 of 2); 4.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 27% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 2 | 100% (2 of 2); on the table 100% | 50% (6 of 12) | 85% | 62% (10 of 16) | 100% (1 of 1); 2.5 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 60% (3 of 5); on the table 80% | - | 10% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 63% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h7-mine-dcce224-p1, 11 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 74% (14) | 44% (7) | 60% (21) |
| ...free all their last turn and able to turn (per game) | 0.73 | 0.45 | 1.18 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.45 | 0.18 | 0.64 |
| ...with the charger already in that arc before they moved (per game) | 0.45 | 0.45 | 0.91 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.09 | 0.09 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.18 | 0.18 | 0.36 |

### Quality by phase: h7-mine-dcce224-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 52% (14 of 27) | 53% (16 of 30) |
| Strategy | Shoot objectives carried out (shot that target) | 28% (43 of 151) | 70% (73 of 105) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 24% (8 of 33) | 42% (5 of 12) |
| Strategy | Lone characters that fought | 67% (12 of 18) | 54% (13 of 24) |
| Movement | Charges halted short of contact | 0.1 | 0.0 |
| Movement | Idle units | 1.6 | 1.7 |
| Movement | Points that never moved of their own | 255.4 | 206.5 |
| Movement | Fights charged into per game | 1.8 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 20, net +16 | 6 of 20, net +106 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 20, net +0 | 3 of 20, net +71 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 20, net +64 | 4 of 20, net +147 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 20, net +88 | 4 of 20, net +203 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.9 | 12.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (34 of 76) | 44% (60 of 136) |
| Shooting | Points destroyed by shooting units | 159.9 | 101.9 |
| Shooting | War machine shots | 8.5 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (54 of 94) | 58% (30 of 52) |
| Shooting | Points destroyed by war machines | 153.0 | 0.0 |
| Magic | Magic missiles cast | 3.5 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (17 of 38) | 37% (7 of 19) |
| Magic | Wounds caused by magic missiles | 8.0 | 2.3 |
| Magic | Wounds caused by other spells | 0.5 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 99.8 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.0 / 0.2 / 0.4 | 2.7 / 0.1 / 0.1 / 0.3 |
| Combat | Points destroyed in combat | 117.5 | 262.2 |
| Combat | Points run down | 0.0 | 22.3 |
| Combat | Net points per charged fight, damage counted | +75 | +127 |
| Combat | Net per 100 charger points, damage counted | +28.6 | +41.8 |
| Combat | First round won (charged fights) | 65% | 76% |
| Combat | Net points per charged fight | +49 | +142 |
| Combat | Net points per supported fight / lone fight | +65 / +48 | - / +142 |
| Combat | Charged fights on a top-3 enemy unit | 7 of 20 | 11 of 22 |
| Game | Points lost | 503.7 | 539.6 |
| Game | VP from objectives | 645.5 | 771.8 |
| Game | Lone holders (player turns) | 3.2 | 3.3 |

- Mine won / drew / lost: 4 / 3 / 4 of 11 ended games (of 11); mean margin (Mine - Opponent) -72 VP
- The side that went first won 2 of 8 games with a winner
- Points traded per game (both sides' losses): 1043
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h7-mine-dcce224-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 10.2 | 1.2 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +34.9 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 3.4 | +0.0 | 0.0 | 72.3 | 0.5 | +0.0 | 0.0 | 15.0 |
| BACKUP TARGETS | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.2 | -2.3 | 10.9 | 40.2 |
| BLOWS WHERE AIMED | - | - | - | - | 0.2 | -59.2 | 0.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.1 | +0.0 | 167.7 | 33.6 | 0.1 | +0.0 | 10.9 | 0.0 |
| CANNON PLANNED TARGET | 7.9 | +237.5 | 1036.3 | 90.5 | 4.5 | +19.8 | 47.1 | 59.1 |
| CANNON SIGHT KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -30.1 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.5 | +5.6 | 0.0 | 7.7 | 0.3 | +2.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +27.0 | 5.9 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 36.4 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +13.7 | 0.0 | 15.5 | 0.4 | +25.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.4 | 21.4 | 28.2 | 0.2 | -0.3 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.1 | -130.0 | 0.0 | 184.3 | 7.4 | -293.3 | 0.0 | 229.1 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 11.8 | 0.0 | 0.4 | +0.0 | 31.5 | 0.0 |
| CHARGE NOW FIRST | 0.8 | +0.0 | 38.3 | 14.2 | 1.8 | +0.0 | 135.9 | 0.0 |
| CHARGER SLAIN LOST | 0.4 | -11.0 | 10.9 | 4.7 | 0.1 | -0.5 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 43.6 | 0.4 | +0.0 | 0.0 | 39.5 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.2 | +179.0 | 0.0 | 0.0 | 0.4 | +29.2 | 0.0 | 0.0 |
| COVER ONCE | 6.1 | -389.6 | 0.0 | 224.5 | 5.9 | -388.6 | 0.0 | 36.4 |
| DEPLOY BY FIGURES | 9.0 | +33.3 | 0.0 | 18.8 | 8.5 | +22.2 | 0.0 | 5.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +0.1 | 7.7 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +3.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.6 | +6.1 | 90.1 | 17.7 | 1.9 | +1.5 | 142.2 | 0.0 |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 6.5 | +126.3 | 0.0 | 42.1 | 17.3 | +224.4 | 0.0 | 288.1 |
| FEATURE BUFFS | 1.7 | +66.4 | 0.0 | 10.0 | 0.4 | +5.6 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.5 | +48.6 | 41.4 | 4.7 | 1.1 | +34.4 | 104.6 | 0.0 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 12.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 46.3 | +3152.2 | 1360.4 | 646.4 | 49.6 | +2410.9 | 424.0 | 742.5 |
| FLANK NOT WEIGHED | 4.6 | +0.0 | 0.0 | 119.9 | 4.3 | +0.0 | 0.0 | 66.8 |
| FOLLOW UP WEIGHED | 0.3 | +115.2 | 0.0 | 0.0 | 0.6 | +195.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.5 | +211.3 | 117.4 | 27.2 | 2.6 | +210.9 | 209.9 | 40.2 |
| FRIEND CHARGES FIRST | 0.1 | -0.5 | 0.0 | 0.0 | 0.2 | -29.3 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.4 | -4.1 | 0.0 | 56.4 | 0.5 | -11.2 | 0.0 | 40.2 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.2 | +10.3 | 0.0 | 39.5 |
| GIVES UP | 0.3 | -1.7 | 17.7 | 4.7 | 0.1 | -0.7 | 28.2 | 0.0 |
| GROUND FLIERS | 0.2 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.0 | +2.5 | 44.7 | 112.7 | 2.1 | +15.7 | 50.3 | 10.9 |
| GUN MASK | 0.5 | +9.1 | 0.0 | 0.0 | 0.2 | +10.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.9 | +0.0 | 0.0 | 28.2 | 0.5 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 3.1 | +0.0 | 0.0 | 64.2 | 2.1 | +0.0 | 0.0 | 64.5 |
| HIS CHARGE DENIED | 0.1 | +3.2 | 0.0 | 0.0 | 0.1 | +3.8 | 7.7 | 0.0 |
| HIS CHARGE LIST | 3.5 | +0.0 | 0.0 | 48.0 | 3.3 | +0.0 | 0.0 | 115.5 |
| HIS LEGAL MOVES | 1.9 | +0.0 | 0.0 | 28.2 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.4 | -18.0 | 0.0 | 28.2 | 1.4 | -33.9 | 0.0 | 46.9 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 68.9 | - | - | - | - |
| HIS RANDOM MOVE | 2.5 | +0.0 | 0.0 | 64.6 | 1.7 | +0.0 | 0.0 | 21.4 |
| HIS SHOT LIST | 18.7 | +510.3 | 0.0 | 347.1 | 22.8 | +975.3 | 0.0 | 453.1 |
| HIS TURN DENIED | 1.0 | +22.2 | 64.6 | 0.0 | 1.5 | +56.8 | 140.3 | 40.2 |
| HOLD ODDS | 11.9 | +0.0 | 0.0 | 28.5 | - | - | - | - |
| HOLDER ASSIGNMENT | 12.9 | +1336.5 | 0.0 | 38.6 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 2.0 | +352.8 | 0.0 | 5.0 |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.8 | -83.9 | 111.5 | 13.0 | 2.4 | -127.7 | 181.7 | 40.2 |
| HUNT IN PAIRS | - | - | - | - | 0.2 | +1.7 | 0.0 | 17.7 |
| IDLE COST | 5.3 | -56.6 | 0.0 | 52.5 | 10.5 | -146.1 | 0.0 | 340.2 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.5 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.4 | +9.5 | 0.0 | 0.0 | 1.0 | +53.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.1 | +0.0 | 76.9 | 140.9 | 3.0 | +0.0 | 129.6 | 11.5 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.1 | +5.8 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.9 | +56.2 | 0.0 | 0.0 | 0.3 | +29.7 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +1.7 | 5.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.4 | +2.4 | 0.0 | 0.0 | 0.3 | +2.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.4 | +3.7 | 0.0 | 46.7 | 0.9 | +43.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.1 | +0.6 | 0.0 | 0.0 | 0.4 | +11.1 | 0.0 | 36.4 |
| MARCH CHECK | 0.7 | +33.7 | 0.0 | 7.4 | 1.5 | +83.4 | 0.0 | 15.2 |
| MARCH OVER CASTS | 0.3 | +13.0 | 0.0 | 0.0 | 0.6 | +20.2 | 0.0 | 51.5 |
| MAX FOR POSITIONING | 4.4 | +41.3 | 0.0 | 146.6 | 3.2 | +35.1 | 0.0 | 147.3 |
| MISSILES IN THE MOVE | 4.0 | +189.6 | 0.0 | 29.8 | 3.5 | +64.2 | 0.0 | 88.5 |
| MISSILES NEXT TURN | 4.5 | +114.6 | 0.0 | 29.8 | 5.1 | +51.7 | 0.0 | 191.2 |
| MODEL FACING | 0.7 | +179.9 | 0.0 | 5.5 | 0.7 | +162.6 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.6 | +19.7 | 0.0 | 0.0 | 0.4 | +4.6 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.3 | -34.3 | 0.0 | 0.0 | 0.5 | -18.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 36.4 |
| MOVE TO CHARGE COMPUTED | 2.6 | +180.4 | 0.0 | 97.0 | 3.1 | +475.5 | 0.0 | 40.2 |
| MOVES UNITS SPELL | 0.2 | +10.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.8 | +244.3 | 0.0 | 0.0 | 6.0 | +236.5 | 0.0 | 10.0 |
| NEXT CHARGE BY LIST | 3.7 | -111.5 | 0.0 | 104.7 | 4.1 | -131.4 | 7.7 | 55.7 |
| NEXT OBJECTIVE NEARER | 0.1 | -1.7 | 0.0 | 0.0 | 11.8 | -538.4 | 59.1 | 79.9 |
| NO DOUBLE ROUNDS | 1.5 | -73.7 | 65.0 | 27.2 | 2.0 | -65.0 | 165.0 | 0.0 |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 15.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.6 | -0.8 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -63.7 | 0.0 | 10.6 | 0.5 | -5.7 | 0.0 | 5.0 |
| ONE CHARGE A CHARGER | 2.4 | +0.0 | 0.0 | 76.5 | 1.7 | +0.0 | 0.0 | 53.9 |
| ONE FIGHT FORMULA | 5.1 | -67.8 | 0.0 | 155.5 | 4.3 | -108.9 | 0.0 | 163.8 |
| ONE OBJECTIVE FORMULA | 5.1 | +61.7 | 0.0 | 20.2 | 2.8 | +6.1 | 0.0 | 10.5 |
| ONE TARGET A SHOOTER | 16.6 | +309.5 | 0.0 | 303.1 | 20.8 | +567.4 | 0.0 | 388.7 |
| OPENS UP | 0.5 | +39.1 | 25.0 | 0.0 | 0.3 | +10.0 | 13.2 | 40.2 |
| OVERRUNS AWAY | 0.5 | +45.5 | 40.9 | 0.0 | 0.1 | +1.3 | 5.9 | 0.0 |
| PATHS CROSS | 3.3 | +90.9 | 0.0 | 73.7 | 4.5 | +128.7 | 0.0 | 77.9 |
| PERIAPT WORTH | - | - | - | - | 0.2 | +13.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -7.6 | 0.0 | 0.0 |
| PLAN RESULT | 40.5 | +1276.9 | 413.3 | 736.0 | 44.2 | +614.1 | 247.6 | 940.5 |
| QUARTER ODDS | 9.6 | +976.4 | 219.6 | 100.5 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.6 | +7.0 | 0.0 | 30.9 | 1.8 | +32.5 | 0.0 | 140.9 |
| REAL GROUND | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.9 | 0.0 | 15.5 | 0.4 | -3.6 | 0.0 | 5.0 |
| REDIRECT COUNTER | 1.5 | +43.5 | 0.0 | 31.5 | 1.0 | +28.4 | 0.0 | 20.4 |
| REDIRECT WEIGHED | 0.1 | +5.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.5 | -32.0 | 0.0 | 4.7 | 0.5 | -12.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +27.5 | 0.0 | 0.0 | 0.5 | +27.8 | 0.0 | 16.2 |
| RISK BY ARC | 2.2 | -50.1 | 111.4 | 27.2 | 1.8 | +25.8 | 154.4 | 0.0 |
| RISK BY HIS FIGURE | 11.3 | -87.7 | 0.0 | 323.5 | 11.4 | -123.9 | 0.0 | 183.8 |
| RUN DOWN | 1.1 | -8.1 | 24.1 | 13.0 | 1.3 | -7.1 | 90.6 | 40.2 |
| SAFER THAN THE JOB | - | - | - | - | 0.1 | +11.9 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -1.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | +1.6 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -14.6 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 3.7 | +117.8 | 0.0 | 0.0 | 7.4 | +293.4 | 0.0 | 99.4 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | -1.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.5 | +3.9 | 0.0 | 0.0 | 0.5 | +8.1 | 0.0 | 27.5 |
| SET-UP ANY TARGET | 0.1 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.1 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +1.1 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +87.0 | 32.3 | 0.0 | 1.2 | +33.9 | 33.1 | 39.5 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -3.3 | 26.4 | 8.3 | 0.1 | -1.2 | 10.9 | 0.0 |
| SHOT RISK POINTS | 9.5 | +13.0 | 0.0 | 250.3 | 12.7 | +41.2 | 0.0 | 323.7 |
| SHOTS IN THE MOVE | 16.4 | +737.9 | 0.0 | 302.5 | 17.2 | +329.0 | 0.0 | 97.6 |
| SPELL SETS UP CHARGE | 0.1 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.5 | +3.6 | 0.0 | 0.0 | 1.2 | +18.8 | 121.8 | 121.8 |
| SPELLS IN THE FIGHT | 0.5 | -10.5 | 24.1 | 0.0 | 0.5 | +8.1 | 27.8 | 0.0 |
| STAND AND SHOOT | 0.5 | -4.9 | 40.5 | 8.3 | 0.5 | -9.9 | 78.7 | 40.2 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 7.4 | 0.7 | +0.0 | 0.0 | 6.0 |
| STANDS STILL | 21.5 | +0.0 | 1243.0 | 313.9 | 16.0 | +0.0 | 214.1 | 160.8 |
| STAY WORTH | 21.8 | +65.7 | 812.4 | 258.6 | 17.2 | +1.3 | 95.2 | 259.4 |
| STUCK PIVOT | - | - | - | - | 0.4 | +0.0 | 0.0 | 38.2 |
| SUPPORT NARROWED | 0.5 | +0.0 | 5.0 | 14.2 | 0.9 | +0.0 | 110.7 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +7.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 65.1 | 3.9 | +0.0 | 0.0 | 41.5 |
| THE PROMISE ADDS | 0.1 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.8 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.3 | +31.7 | 11.5 | 0.0 | 0.9 | +91.4 | 82.1 | 0.0 |
| TIME ON OUR SIDE | 23.3 | +380.5 | 4.1 | 353.2 | 11.5 | +161.0 | 0.0 | 5.9 |
| TWO OR MORE ARRIVE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 97.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALK PROMISE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +13.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 28.2 | 0.0 | 0.5 | +0.0 | 87.1 | 0.0 |
| WHO HITS BACK | 0.3 | +33.8 | 0.0 | 8.3 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.1 | +9.5 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +1.5 | 5.9 | 0.0 | 0.1 | +3.0 | 0.0 | 0.0 |
| WIDER SPREAD | 1.5 | -2.6 | 78.6 | 4.7 | 2.0 | -6.1 | 166.6 | 40.2 |
| WOUNDS ON THE RANKS | 1.5 | +57.4 | 0.0 | 0.0 | 1.1 | +39.7 | 0.0 | 15.2 |

### Rule changes: h7-mine-dcce224-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 457 | 457 | 160 | 14.55 | +2859 | +17.9 |
| HOLDER ASSIGNMENT | 142 | 142 | 132 | 12.00 | +6804 | +51.5 |
| DEPLOY BY FIGURES | 192 | 192 | 117 | 10.64 | +2275 | +19.4 |
| SEARCH SPOT | 122 | 122 | 116 | 10.55 | +4523 | +39.0 |
| ONE TARGET A SHOOTER | 412 | 412 | 95 | 8.64 | +961 | +10.1 |
| LEGAL CHARGES ONLY | 89 | 89 | 89 | 8.09 | +0 | +0.0 |
| TIME ON OUR SIDE | 383 | 351 | 87 | 7.91 | +245 | +2.8 |
| PATHS CROSS | 85 | 85 | 85 | 7.73 | +2416 | +28.4 |
| FIVE ACTION | 1055 | 1054 | 82 | 7.45 | +2803 | +34.2 |
| MOVE TO CHARGE COMPUTED | 63 | 63 | 44 | 4.00 | +3575 | +81.3 |
| ARTILLERY RE-ROLL WEIGHED | 43 | 43 | 43 | 3.91 | +0 | +0.0 |
| SHOT RISK POINTS | 245 | 245 | 42 | 3.82 | +1168 | +27.8 |
| SHOTS IN THE MOVE | 369 | 331 | 32 | 2.91 | +898 | +28.1 |
| HARD STAY DROPPED | 27 | 27 | 27 | 2.45 | +0 | +0.0 |
| CANNON PLANNED TARGET | 137 | 137 | 25 | 2.27 | -226 | -9.1 |
| FOUR ROUNDS | 56 | 55 | 25 | 2.27 | +1440 | +57.6 |
| COVER ONCE | 132 | 108 | 24 | 2.18 | +386 | +16.1 |
| ADVANCE LANE KEPT | 23 | 23 | 23 | 2.09 | +0 | +0.0 |
| IDLE COST | 173 | 140 | 20 | 1.82 | +159 | +7.9 |
| MARCH CHECK | 25 | 25 | 20 | 1.82 | +699 | +35.0 |
| MAX FOR POSITIONING | 83 | 82 | 20 | 1.82 | +67 | +3.3 |
| RANDOM MOVE BY FIGURES | 27 | 27 | 20 | 1.82 | +434 | +21.7 |
| SHOOTS FROM THE BEST SPOT | 27 | 27 | 20 | 1.82 | +205 | +10.3 |
| FALLS SHORT | 261 | 226 | 16 | 1.45 | +259 | +16.2 |
| MODEL FACING | 16 | 16 | 16 | 1.45 | +3768 | +235.5 |
| CANNON SIGHT KEPT | 15 | 15 | 15 | 1.36 | +0 | +0.0 |
| LANE BY FIGURES | 15 | 15 | 15 | 1.36 | +690 | +46.0 |
| MISSILES IN THE MOVE | 83 | 55 | 14 | 1.27 | +503 | +36.0 |
| HOLDER AT DEPLOYMENT | 22 | 22 | 13 | 1.18 | +640 | +49.2 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.18 | +944 | +72.7 |
| QUARTER ODDS | 106 | 105 | 13 | 1.18 | +995 | +76.5 |
| NEXT OBJECTIVE NEARER | 131 | 131 | 11 | 1.00 | +169 | +15.4 |
| RISK BY ARC | 44 | 43 | 11 | 1.00 | +318 | +28.9 |
| CHARGE LOSSES | 137 | 137 | 10 | 0.91 | +600 | +60.0 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 0.91 | +3417 | +341.7 |
| RESERVE FALL BACK | 10 | 10 | 10 | 0.91 | +609 | +60.9 |
| MANOEUVRE | 25 | 25 | 9 | 0.82 | +590 | +65.5 |
| OFF BEST | 9 | 9 | 9 | 0.82 | -764 | -84.9 |
| SHOOTERS IN TWO RANKS | 9 | 9 | 9 | 0.82 | +21 | +2.3 |
| TIED UP BY THE SUM | 13 | 12 | 9 | 0.82 | +294 | +32.7 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.73 | +0 | +0.0 |
| NEARER NOT NEEDED | 119 | 116 | 8 | 0.73 | +293 | +36.6 |
| NEXT CHARGE BY LIST | 86 | 86 | 8 | 0.73 | +73 | +9.1 |
| CHARGE NOW FIRST | 29 | 29 | 7 | 0.64 | -631 | -90.1 |
| COMBAT PIVOT | 7 | 7 | 7 | 0.64 | +0 | +0.0 |
| REDIRECT COUNTER | 27 | 20 | 7 | 0.64 | +346 | +49.4 |
| WOUNDS ON THE RANKS | 29 | 29 | 7 | 0.64 | +252 | +36.1 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 0.55 | +0 | +0.0 |
| CHARGE NOT DECLARED | 6 | 6 | 6 | 0.55 | -748 | -124.7 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 0.55 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 6 | 5 | 0.45 | +62 | +12.5 |
| FEATURE BUFFS | 23 | 23 | 5 | 0.45 | +148 | +29.6 |
| HIS TURN DENIED | 28 | 28 | 5 | 0.45 | +219 | +43.8 |
| MARCH BY THE SUM | 5 | 5 | 5 | 0.45 | +129 | +25.7 |
| CASTING BLOCK | 5 | 5 | 4 | 0.36 | +19 | +4.6 |
| CHAFF PASSED | 4 | 4 | 4 | 0.36 | -7 | -1.8 |
| FIGHT TO THE END | 17 | 16 | 4 | 0.36 | +168 | +42.1 |
| FIRE IN ORDER | 4 | 4 | 4 | 0.36 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 87 | 57 | 4 | 0.36 | +344 | +86.0 |
| OPENS UP | 8 | 8 | 4 | 0.36 | +259 | +64.7 |
| OVERRUNS AWAY | 7 | 7 | 4 | 0.36 | +117 | +29.3 |
| SCOUT WAITS | 4 | 4 | 4 | 0.36 | +0 | +0.0 |
| STAY WORTH | 429 | 407 | 4 | 0.36 | +27 | +6.7 |
| STUCK PIVOT | 4 | 4 | 4 | 0.36 | +0 | +0.0 |
| BOMBING RUN | 3 | 3 | 3 | 0.27 | +60 | +19.9 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.27 | +114 | +38.2 |
| ONE FIGHT FORMULA | 103 | 51 | 3 | 0.27 | +7 | +2.3 |
| RISK BY HIS FIGURE | 249 | 249 | 3 | 0.27 | +70 | +23.2 |
| SURE REACH TOGETHER | 3 | 3 | 3 | 0.27 | +5 | +1.7 |
| WHO HITS BACK | 3 | 3 | 3 | 0.27 | +215 | +71.8 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.18 | +384 | +191.8 |
| BEST PRIZE | 2 | 2 | 2 | 0.18 | -25 | -12.6 |
| CAST JOB | 8 | 8 | 2 | 0.18 | +2 | +0.9 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.18 | +113 | +56.4 |
| HONEST WORTH | 46 | 45 | 2 | 0.18 | +24 | +11.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.18 | +25 | +12.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| MISSILES NEXT TURN | 106 | 71 | 2 | 0.18 | +8 | +4.2 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.18 | +153 | +76.7 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.18 | +167 | +83.3 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.18 | -0 | -0.2 |
| SET UP TOGETHER | 12 | 9 | 2 | 0.18 | +12 | +6.2 |
| SUPPORT NARROWED | 15 | 15 | 2 | 0.18 | -43 | -21.7 |
| WAR ENGINE JOBS | 10 | 10 | 2 | 0.18 | -176 | -88.0 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.09 | -331 | -331.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.09 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.09 | +34 | +34.3 |
| GIVES UP | 4 | 4 | 1 | 0.09 | +5 | +5.0 |
| HIS MOVE AND SHOT | 30 | 30 | 1 | 0.09 | +0 | +0.0 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.09 | +10 | +9.8 |
| LONG SHOT | 1 | 1 | 1 | 0.09 | +10 | +10.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.09 | -83 | -83.4 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 1 | 0.09 | +86 | +85.6 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.09 | +131 | +130.9 |
| SPELLS IN THE FIGHT | 10 | 10 | 1 | 0.09 | +54 | +54.1 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.09 | +52 | +51.6 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.09 | +94 | +93.5 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.09 | +14 | +13.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 3 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 13 | 13 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 14 | trace | - | - | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 5 | 5 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 17 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 39 | 38 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 98 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 10 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 34 | not checked | - | - | - | - |
| GUN MASK | 8 | 8 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 57 | 57 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 75 | 75 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 62 | 62 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 47 | 0 | 0.00 | - | - |
| HOLD ODDS | 131 | 131 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| MAKE SURE TOGETHER | 7 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 30 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 39 | 38 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 45 | 45 | 0 | 0.00 | - | - |
| PLAN RESULT | 932 | trace | - | - | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 12 | 0 | 0.00 | - | - |
| RUN DOWN | 26 | 25 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 19 | not checked | - | - | - | - |
| STAND AND SHOOT | 12 | 12 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 413 | 413 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 79 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 13 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 28 | 28 | 0 | 0.00 | - | - |
| WALK PROMISE | 2 | 2 | 0 | 0.00 | - | - |
| WIDER SPREAD | 38 | 37 | 0 | 0.00 | - | - |

### Off best figure: h7-mine-dcce224-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 0.82 | - | 20.7 |
| CHARGE NOW FIRST | rule | 0.18 | 0.45 | 90.1 |
| JOB FIRST | gate | 0.09 | 0.45 | 10.1 |
| PATHS CROSS | rule | 0.18 | 0.36 | 10.5 |
| CHARGE NOT DECLARED | rule | 0.09 | 0.36 | 149.6 |
| CANNON PLANNED TARGET | rule | 0.27 | - | 75.7 |
| BEST PRIZE | rule | - | 0.18 | 12.6 |
| CHAFF PASSED | rule | 0.09 | 0.09 | 3.6 |
| SUPPORT NARROWED | rule | 0.09 | 0.09 | 21.7 |
| WAR ENGINE JOBS | rule | - | 0.18 | 88.0 |
| AFTERMATH BAND | gate | - | 0.09 | 3.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.09 | - | 48.8 |
| CARRIES OUT COUNTER | rule | 0.09 | - | 331.1 |
| NO REASON | gate | 0.09 | - | 651.4 |
| PIVOT GUARDS FLANK | rule | - | 0.09 | 83.4 |

### Plans: h7-mine-dcce224-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.8 | 50% | 194 | 100 | 52% |
| Mine | join | 0.5 | 100% | 16 | 0 | 0% |
| Mine | move | 26.2 | 95% | 1680 | 0 | 0% |
| Mine | shoot | 11.7 | 57% | 605 | 1181 | 195% |
| Mine | support | 0.3 | 33% | 0 | 0 | - |
| Opponent | charge | 2.3 | 56% | 348 | 187 | 54% |
| Opponent | join | 0.7 | 100% | 37 | 0 | 0% |
| Opponent | move | 32.6 | 92% | 1604 | 0 | 0% |
| Opponent | shoot | 8.2 | 62% | 187 | 427 | 229% |
| Opponent | support | 0.4 | 100% | 15 | 0 | 0% |

### Battle groups: h7-mine-dcce224-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.5 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 36% | 100% | 0% | - | 0% | 0% | 50% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h7-mine-dcce224-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 8 | 25 (8) | 0 | 25 | 31 | 62% | 2.3 | - | 29 (7) | 0 (1) | 38 (5) | 0 (3) |
| Mine | Character | 44 | 38 (44) | 38 | 0 | 11 | 20% | 2.7 | 43 (24) | 41 (12) | 31 (6) | 35 (32) | 50 (10) |
| Mine | Clean-up | 7 | 43 (7) | 0 | 43 | 41 | 29% | 4.2 | 119 (2) | 11 (4) | 0 (1) | 48 (6) | 25 (1) |
| Mine | Fast | 2 | 368 (2) | 368 | 0 | 50 | 0% | 2.0 | - | - | 368 (2) | 0 (1) | 737 (1) |
| Mine | Fast Hammer | 8 | 6 (8) | 6 | 0 | 86 | 25% | 3.2 | - | 11 (5) | 0 (3) | 23 (2) | 0 (6) |
| Mine | Hammer | 25 | 33 (25) | 2 | 30 | 27 | 40% | 2.9 | 66 (7) | 23 (11) | 7 (7) | 46 (15) | 7 (10) |
| Mine | Holder | 12 | 72 (12) | 0 | 72 | 32 | 75% | 2.0 | 167 (2) | 35 (6) | 99 (3) | 80 (6) | 75 (5) |
| Mine | Shooter | 5 | 92 (5) | 0 | 92 | 27 | 0% | 1.2 | 0 (1) | 124 (3) | 138 (1) | 126 (4) | 0 (1) |
| Mine | War machine | 24 | 61 (24) | 61 | 0 | 40 | 4% | 1.1 | 49 (13) | 24 (7) | 165 (4) | 135 (2) | 55 (22) |
| Mine | Wizard | 7 | 7 (7) | 7 | 0 | 14 | 14% | 4.3 | 13 (4) | 0 (1) | 0 (2) | 0 (2) | 10 (5) |
| Opponent | Chaff | 14 | 115 (14) | 13 | 102 | 48 | 50% | 2.0 | 101 (7) | 138 (5) | 86 (2) | 111 (10) | 128 (4) |
| Opponent | Character | 29 | 41 (29) | 41 | 0 | 28 | 31% | 2.0 | 26 (8) | 28 (14) | 81 (7) | 58 (12) | 27 (17) |
| Opponent | Clean-up | 11 | 47 (11) | 8 | 39 | 22 | 73% | 4.0 | 0 (1) | 43 (9) | 237 (1) | 94 (6) | 20 (5) |
| Opponent | Fast | 1 | 232 (1) | 232 | 0 | 0 | 0% | 1.0 | - | 232 (1) | - | 232 (1) | - |
| Opponent | Fast Hammer | 8 | 42 (8) | 34 | 9 | 30 | 38% | 3.0 | 201 (2) | 1 (5) | 64 (1) | 127 (3) | 11 (5) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |
| Opponent | Hammer | 18 | 35 (18) | 20 | 15 | 40 | 44% | 2.7 | 0 (3) | 44 (13) | 13 (2) | 13 (12) | 79 (6) |
| Opponent | Holder | 15 | 106 (15) | 7 | 100 | 10 | 67% | 2.8 | 164 (9) | 19 (3) | 94 (3) | 122 (8) | 88 (7) |
| Opponent | Shooter | 13 | 33 (13) | 10 | 23 | 23 | 8% | 1.6 | 0 (2) | 36 (11) | - | 79 (5) | 10 (8) |
| Opponent | War machine | 14 | 0 (14) | 0 | 0 | 36 | 7% | 1.5 | 0 (2) | 0 (4) | 0 (8) | 0 (3) | 0 (11) |
| Opponent | Wizard | 7 | 28 (7) | 28 | 0 | 0 | 29% | 1.8 | 0 (2) | 2 (4) | 135 (1) | 0 (3) | 37 (4) |

### Charged fights: h7-mine-dcce224-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 217 | 16 | 1.2 | 1.2 | 13 | 21 | -8 | 2 of 5 | 2 of 5 | +65 | -26 |
| Mine | Chaos Dwarfs | 4 | 436 | 307 | 3.5 | 1.0 | 88 | 15 | +72 | 4 of 14 | 11 of 14 | - | +72 |
| Mine | Dwarfen Mountain Holds | 3 | 642 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 11 | 413 | 117 | 1.8 | 1.1 | 65 | 16 | +49 | 7 of 20 | 13 of 20 | +65 | +48 |
| Opponent | Chaos Dwarfs | 3 | 91 | 208 | 1.0 | 1.0 | 208 | 0 | +208 | 2 of 3 | 2 of 3 | - | +208 |
| Opponent | Dwarfen Mountain Holds | 1 | 139 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 239 | 778 | 4.0 | 1.0 | 194 | 0 | +194 | 2 of 4 | 2 of 4 | - | +194 |
| Opponent | High Elf Realms | 1 | 160 | 186 | 1.0 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 503 | 5.0 | 1.0 | 101 | 0 | +101 | 0 of 5 | 5 of 5 | - | +101 |
| Opponent | Skaven | 2 | 155 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 620 | 4.0 | 1.0 | 155 | 0 | +155 | 3 of 4 | 3 of 4 | - | +155 |
| Opponent | Vampire Counts | 1 | 0 | 401 | 3.0 | 1.0 | 134 | 0 | +134 | 1 of 3 | 3 of 3 | - | +134 |
| **Opponent** | all armies | 11 | 102 | 283 | 2.0 | 1.0 | 142 | 0 | +142 | 11 of 22 | 16 of 21 | - | +142 |

### Effective charges: h7-mine-dcce224-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 2 (net -52) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +65) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 14 | 2 (net +92) | 0 | 2 (net +0) | 4 (net +86) | 3 (net +64) | 3 (net +96) | 0 | 14% (2 of 14) |
| Mine | Dwarfen Mountain Holds | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Chaos Dwarfs | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +312) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 4 | 2 (net +250) | 0 | 1 (net +117) | 1 (net +160) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +186) | 0 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 3 (net +140) | 0 | 2 | 0% (0 of 3) |
| Opponent | Skaven | 2 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 1 (net +0) | 2 (net +310) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Opponent | Vampire Counts | 3 | 1 (net +138) | 0 | 1 (net +95) | 0 | 1 (net +168) | 0 | 0 | 33% (1 of 3) |

### Charged fights, damage counted: h7-mine-dcce224-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 151 | 349 | +16 | 70 | 21 | +49 | +32.7 |
| Mine | Effective (55-75%) | 3 | 281 | 218 | +0 | 85 | 9 | +76 | +27.1 |
| Mine | 76-89% | 5 | 316 | 106 | +69 | 100 | 34 | +66 | +20.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 263 | 135 | +88 | 158 | 33 | +125 | +47.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 329 | 73 | +64 | 64 | 0 | +64 | +19.4 |
| Mine | All fights | 20 | 261 | 184 | +49 | 96 | 22 | +75 | +28.6 |
| Opponent | Long shot (under 50%) | 6 | 292 | 268 | +106 | 168 | 78 | +90 | +30.6 |
| Opponent | Effective (55-75%) | 3 | 300 | 231 | +71 | 71 | 0 | +71 | +23.6 |
| Opponent | 76-89% | 3 | 359 | 228 | +260 | 260 | 64 | +196 | +54.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 256 | 178 | +203 | 238 | 42 | +195 | +76.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 382 | 86 | +147 | 147 | 0 | +147 | +38.5 |
| Opponent | No odds | 2 | 199 | 41 | +41 | 41 | 0 | +41 | +20.6 |
| Opponent | All fights | 22 | 304 | 187 | +142 | 165 | 38 | +127 | +41.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h7-mine-dcce224-p1 | move | 69 | 13 (19%) | 11 (16%) | 10 (14%) | 46 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Charmed Shield | Opponent | L0525 |
| Elixir of Power | Opponent | L0219 |
| Invocation of Nehek | Opponent | L0525 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Opponent | L0613 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Opponent | L0510 |

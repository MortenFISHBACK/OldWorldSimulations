# Doctrine scorecard: h7-mine-dcce224-p2

### Scorecard: h7-mine-dcce224-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 55 |
| L0108 | 6 | 1 | Opponent | yes | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 225 |
| L0123 | 3 | 1 | Mine | no | 3 | 6 | 1 | 2 | 0 | 0 | 0 | 150 |
| L0123 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 70 |
| L0207 | 3 | 1 | Mine | no | 8 | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0224 | 2 | 1 | Mine | - | - | 5 | 3 | 5 | 0 | 0 | 0 | 85 |
| L0224 | 2 | 1 | Opponent | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 430 |
| L0325 | 1 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0325 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | yes | 8 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Mine | no | 4 | 2 | 2 | 3 | 0 | 0 | 0 | 65 |
| L0427 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 544 |
| L0513 | 3 | 1 | Opponent | no | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0530 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 595 |
| L0530 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 3 | - | 0 | 2 | 1 | 0 | 0 | 280 |
| L0618 | 6 | 1 | Opponent | no | 12 | - | 0 | 3 | 0 | 0 | 0 | 185 |
| L0633 | 3 | 1 | Mine | yes | 9 | 4 | 3 | 2 | 0 | 0 | 0 | 350 |
| L0633 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 11% | 3.9 | 3.9 | 1.2 | 2.2 | 0.1 | 0.0 | 0.0 | 200.3 |
| **Average** | | | Opponent | 22% | 3.0 | 2.7 | 1.3 | 1.9 | 0.0 | 0.0 | 0.0 | 87.5 |

### KPIs: h7-mine-dcce224-p2

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 49% (24 of 49) | 18% (10 of 56) | 32% (34 of 105) |
| Winner chose to follow up after the loser gave ground |  | 89% (8 of 9); on the table 100% | 71% (5 of 7); on the table 86% | 81% (13 of 16); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (4 of 4); on the table 100% | 83% (5 of 6); on the table 83% | 90% (9 of 10); on the table 90% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 60% (6 of 10); on the table 60% | 62% (8 of 13); on the table 62% |
| Winner chose to follow up or pursue (all three) |  | 88% (14 of 16); on the table 94% | 70% (16 of 23); on the table 74% | 77% (30 of 39); on the table 82% |
| Magic missiles tried each own turn | 50%+ | 53% (73 of 138) | 44% (21 of 48) | 51% (94 of 186) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (73 of 121) | 48% (21 of 44) | 57% (94 of 165) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (7 of 12) | - | 58% (7 of 12) |
| Points that never fought | lower | 63% (14860 of 23594) | 58% (13975 of 23995) | 61% (28835 of 47589) |
|   infantry points that never fought | lower | 63% (4624 of 7332) | 60% (2568 of 4287) | 62% (7192 of 11619) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (51 of 88) | 60% (56 of 93) | 59% (107 of 181) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.6 uses a game | 100% (6 of 6); 1.8 uses a game | 92% (11 of 12); 1.7 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 33% (1 of 3); 0.2 uses a game | 60% (3 of 5); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.4 uses a game | 50% (3 of 6); 0.2 uses a game | 57% (8 of 14); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (9088 of 17752) | 54% (11154 of 20774) | 53% (20242 of 38526) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (23%) | 0.8 (37%) | 2.1 (27%) |
| MARCHED: its unit marched | 1.4 (26%) | 0.3 (15%) | 1.8 (23%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.6 (11%) | 0.3 (15%) | 0.9 (12%) |
| REAR RANK: in a rear rank | 1.0 (18%) | 0.1 (4%) | 1.1 (14%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.7 (12%) | 0.0 (0%) | 0.7 (9%) |
| STUPIDITY: Stupidity | 0.3 (6%) | 0.1 (4%) | 0.4 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (15%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.2 | 3.2 | 7.8 | 0.8 | 1.2 |
| not cast | 2.8 | 1.7 | 4.3 | 7.7 | 1.2 | 20.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (90%) | 0.9 (21%) | 2.1 (27%) | 0.2 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (23%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.4 (10%) | 0.9 (12%) | 0.3 (27%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.9 (33%) | 0.0 (0%) | 0.4 (10%) | 1.1 (14%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.5 (2%) |
| GONE: slain | 0.2 (9%) | 0.0 (0%) | 0.2 (4%) | 0.7 (9%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.2 (4%) | 0.4 (5%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.6 (47%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (58%) | 0.2 (10%) | 2.2 (52%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.2 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.4 a game | 1.5 a game | 2.0 a game |
| stood (cast and not dispelled) | 76% (22 of 29) | 67% (12 of 18) | 72% (34 of 47) |
| the unit moved after it | 68% (15 of 22) | 100% (12 of 12) | 79% (27 of 34) |
| it charged on its next turn | 0% (0 of 22) | 0% (0 of 12) | 0% (0 of 34) |
| the enemy charged it first | 9% (2 of 22) | 0% (0 of 12) | 6% (2 of 34) |
| it fought by the end of its next turn | 9% (2 of 22) | 0% (0 of 12) | 6% (2 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 22) | 0% (0 of 12) | 0% (0 of 34) |
| none of these (no charge, no fight, no charge escaped) | 91% (20 of 22) | 100% (12 of 12) | 94% (32 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 56% (205 of 364) | 55% (152 of 278) | 56% (357 of 642) |
|   cavalry | 50% (13 of 26) | 59% (24 of 41) | 55% (37 of 67) |
|   character | 78% (32 of 41) | 39% (16 of 41) | 59% (48 of 82) |
|   chariot | 49% (23 of 47) | 73% (16 of 22) | 57% (39 of 69) |
|   infantry | 54% (44 of 81) | 54% (43 of 80) | 54% (87 of 161) |
|   monster | 50% (3 of 6) | 43% (3 of 7) | 46% (6 of 13) |
|   war machine | 55% (90 of 163) | 57% (50 of 87) | 56% (140 of 250) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (21%) | 2.7 (25%) | 5.5 (23%) |
| CHARGED: it charged | 0.8 (6%) | 0.8 (7%) | 1.6 (7%) |
| FLEEING: it fled or was fleeing | 0.2 (1%) | 0.2 (2%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.3 (3%) | 0.7 (3%) |
| MOVED: a war machine that moved | 2.1 (16%) | 1.5 (14%) | 3.6 (15%) |
| NO TARGET IN RANGE | 3.2 (25%) | 1.8 (17%) | 5.1 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (1%) | 0.2 (2%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (16%) | 2.4 (23%) | 4.6 (19%) |
| SHELTERED: the target was sheltered | 1.1 (8%) | 0.1 (1%) | 1.2 (5%) |
| OTHER BAR | 0.4 (3%) | 0.5 (5%) | 0.9 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.1 | 2.2 | 61% | 7.4 pts | 30 pts |
| character | 4.5 | 1.8 | 70% | 10.9 pts | 49 pts |
| chariot | 3.2 | 3.8 | 44% | 25.5 pts | 83 pts |
| infantry | 12.4 | 4.8 | 70% | 5.9 pts | 73 pts |
| monster | 0.5 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 11.7 | 10.9 | 60% | 18.3 pts | 213 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.1 | 3.7 | 2.9 |
| Charges that made contact a game | 1.4 | 2.5 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.17 declared, 0.17 contact (6 units) | 0.83 declared, 0.50 contact (6 units) | 0.50 declared, 0.33 contact (12 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.80 declared, 0.80 contact (5 units) | 0.80 declared, 0.80 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.20 contact (82 units) | 0.38 declared, 0.25 contact (91 units) | 0.34 declared, 0.23 contact (173 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (10 of 15) | 17% (1 of 6) | 50% (1 of 2) | 52% (12 of 23) |
| Character in a unit | 89% (17 of 19) | 50% (6 of 12) | 0% (0 of 1) | 72% (23 of 32) |
| Character on its own | 75% (9 of 12) | 60% (6 of 10) | 36% (4 of 11) | 58% (19 of 33) |
| Chariot | 100% (3 of 3) | 50% (5 of 10) | - | 62% (8 of 13) |
| Infantry | 33% (6 of 18) | 30% (6 of 20) | 50% (1 of 2) | 32% (13 of 40) |
| Monster | 83% (5 of 6) | 100% (2 of 2) | - | 88% (7 of 8) |
| Monstrous | 100% (1 of 1) | 50% (1 of 2) | - | 67% (2 of 3) |
| War Machines | 78% (21 of 27) | 100% (2 of 2) | - | 79% (23 of 29) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 86% (6 of 7); on the table 86% | 56% (57 of 102) | 54% | 45% (10 of 22) | 83% (5 of 6); 4.8 uses a game | 100% (2 of 2); 2.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (4 of 4); on the table 100% | 44% (16 of 36) | 68% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 4 | 80% (4 of 5); on the table 100% | - | 67% | 62% (21 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | 100% (1 of 1); on the table 100% | 58% (7 of 12) | 86% | 60% (18 of 30) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Grand Cathay | 1 | 100% (1 of 1); on the table 100% | 58% (7 of 12) | 33% | 62% (5 of 8) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 6) | 69% | 50% (4 of 8) | 100% (1 of 1); 3.0 uses a game | 50% (1 of 2); 2.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 17% (1 of 6) | 100% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 0% (0 of 2); on the table 0% | - | 23% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 56% (5 of 9); on the table 56% | 50% (6 of 12) | 42% | 74% (14 of 19) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (4 of 4); on the table 100% | - | 22% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 50% (1 of 2); on the table 100% | - | 68% | 70% (7 of 10) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h7-mine-dcce224-p2, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (9) | 36% (4) | 46% (13) |
| ...free all their last turn and able to turn (per game) | 0.42 | 0.25 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.08 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.17 | 0.25 | 0.42 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.25 | 0.33 | 0.58 |

### Quality by phase: h7-mine-dcce224-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 65% (15 of 23) | 41% (15 of 37) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (80 of 169) | 47% (47 of 99) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 75% (3 of 4) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 33% (2 of 6) |
| Strategy | Joined characters whose unit fought | 26% (8 of 31) | 22% (4 of 18) |
| Strategy | Lone characters that fought | 65% (15 of 23) | 50% (15 of 30) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 2.2 | 1.9 |
| Movement | Points that never moved of their own | 200.3 | 87.5 |
| Movement | Fights charged into per game | 1.2 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 15, net +90 | 6 of 23, net +5 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 15, net +0 | 1 of 23, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 15, net +22 | 5 of 23, net +74 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 15, net +115 | 4 of 23, net +2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.5 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (56 of 126) | 61% (64 of 105) |
| Shooting | Points destroyed by shooting units | 80.8 | 45.1 |
| Shooting | War machine shots | 7.5 | 4.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (41 of 90) | 62% (31 of 50) |
| Shooting | Points destroyed by war machines | 21.1 | 40.0 |
| Magic | Magic missiles cast | 3.3 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 48% (19 of 40) | 55% (6 of 11) |
| Magic | Wounds caused by magic missiles | 8.3 | 1.3 |
| Magic | Wounds caused by other spells | 0.5 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 71.9 | 46.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.6 / 0.0 / 0.7 / 0.0 | 2.2 / 0.8 / 0.3 / 0.5 |
| Combat | Points destroyed in combat | 133.7 | 239.8 |
| Combat | Points run down | 40.1 | 16.5 |
| Combat | Net points per charged fight, damage counted | +94 | +94 |
| Combat | Net per 100 charger points, damage counted | +37.8 | +30.1 |
| Combat | First round won (charged fights) | 67% | 80% |
| Combat | Net points per charged fight | +76 | +72 |
| Combat | Net points per supported fight / lone fight | +240 / +51 | +309 / +13 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 15 | 8 of 25 |
| Game | Points lost | 406.0 | 404.8 |
| Game | VP from objectives | 677.5 | 715.8 |
| Game | Lone holders (player turns) | 3.9 | 3.0 |

- Mine won / drew / lost: 3 / 5 / 4 of 12 ended games (of 12); mean margin (Mine - Opponent) -52 VP
- The side that went first won 3 of 7 games with a winner
- Points traded per game (both sides' losses): 811
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h7-mine-dcce224-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +2.0 | 0.0 | 0.0 | 0.2 | +31.8 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 7.9 | 1.1 | +0.0 | 0.0 | 13.8 |
| BACKUP TARGETS | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.5 | 7.1 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -1.9 | 18.4 | 0.0 | 0.1 | -8.1 | 5.4 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.1 | +2.2 | 0.0 | 12.5 |
| CANNON PLAN MISSED | 1.2 | +0.0 | 60.1 | 17.5 | 0.8 | +0.0 | 48.7 | 24.6 |
| CANNON PLANNED TARGET | 6.1 | +46.9 | 206.3 | 67.1 | 3.2 | +121.0 | 206.2 | 79.6 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -17.9 | 31.1 | 0.0 |
| CAST JOB | 0.6 | +5.8 | 11.2 | 7.1 | 0.2 | +3.4 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.7 | +73.0 | 46.7 | 0.0 | 0.1 | +2.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.8 | +0.0 | 0.0 | 88.8 | 1.1 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.4 | +19.6 | 0.0 | 6.8 | 0.8 | +32.3 | 0.0 | 35.2 |
| CHAFF PASSED | 0.2 | -1.1 | 11.2 | 25.8 | - | - | - | - |
| CHARACTER GUNS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.6 | -462.6 | 0.0 | 135.9 | 6.7 | -288.3 | 0.0 | 141.2 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 20.7 | 0.0 | 0.8 | +0.0 | 40.1 | 0.0 |
| CHARGE NOW FIRST | 0.9 | +0.0 | 69.6 | 8.8 | 0.8 | +0.0 | 35.4 | 32.5 |
| CHARGER SLAIN LOST | 0.1 | -0.1 | 8.2 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 18.4 | 0.0 | - | - | - | - |
| CHEAPEST HOLDER | - | - | - | - | 0.2 | -3.9 | 5.4 | 0.0 |
| COMBAT PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.2 | +351.7 | 10.8 | 70.0 | 0.6 | +15.2 | 34.6 | 0.0 |
| COVER ONCE | 7.0 | -377.2 | 0.0 | 80.3 | 5.6 | -301.2 | 0.0 | 55.1 |
| DEFENSIVE FLOOR | 0.1 | +16.5 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.6 | +3.8 | 0.0 | 9.6 | 7.8 | -40.5 | 0.0 | 10.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +6.1 | 5.4 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.2 | +7.1 | 128.2 | 13.1 | 2.2 | +0.0 | 99.5 | 37.5 |
| FALLBACK BY WORTH | 0.3 | +0.5 | 0.0 | 0.0 | 0.3 | +0.1 | 0.0 | 3.0 |
| FALLS SHORT | 5.8 | +140.3 | 0.0 | 78.0 | 18.8 | +292.4 | 0.0 | 103.5 |
| FEATURE BUFFS | 1.3 | +42.3 | 0.0 | 5.4 | 0.3 | +8.0 | 0.0 | 18.7 |
| FIGHT TO THE END | 0.6 | +6.0 | 78.3 | 8.8 | 0.8 | +16.6 | 39.9 | 28.8 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +4.1 | 0.0 | 13.7 |
| FIRE IN ORDER | 0.2 | +0.0 | 2.8 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 49.0 | +2511.7 | 681.3 | 394.7 | 47.7 | +2935.3 | 532.0 | 482.6 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 57.6 | 3.8 | +0.0 | 0.0 | 19.1 |
| FOCUS FIRE | 0.2 | +3.8 | 6.6 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.2 | +40.1 | 0.0 | 0.0 | 0.2 | +25.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.8 | +172.8 | 149.4 | 13.1 | 2.8 | +237.3 | 141.5 | 50.1 |
| FRIEND CHARGES FIRST | 0.1 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.4 | -1.9 | 0.0 | 0.0 | 0.2 | -11.9 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| GATEWAY ESCAPE | - | - | - | - | 0.1 | +5.2 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.4 | 6.2 | 0.0 | 0.4 | -3.0 | 31.2 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.2 | +2.3 | 0.0 | 0.0 |
| GUN FIGURES | 1.4 | +12.9 | 25.9 | 25.8 | 1.4 | +2.1 | 5.4 | 0.0 |
| GUN MASK | 0.7 | +15.4 | 0.0 | 0.0 | 1.2 | +24.0 | 0.0 | 12.6 |
| HARD STAY DROPPED | 2.4 | +0.0 | 0.0 | 9.3 | 1.1 | +0.0 | 0.0 | 14.9 |
| HE SHOOTS OR CHARGES | 1.2 | +0.0 | 0.0 | 52.5 | 2.3 | +0.0 | 0.0 | 33.9 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 7.9 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 5.4 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.1 | +10.9 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 19.8 | 4.3 | +0.0 | 0.0 | 63.8 |
| HIS LEGAL MOVES | 2.9 | +0.0 | 0.0 | 47.5 | 4.3 | +0.0 | 0.0 | 76.7 |
| HIS MOVE AND SHOT | 2.2 | -43.1 | 0.0 | 37.8 | 1.8 | -46.4 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.5 | +0.0 | 0.0 | 7.9 | - | - | - | - |
| HIS RANDOM MOVE | - | - | - | - | 3.4 | +0.0 | 0.0 | 19.9 |
| HIS SHOT LIST | 20.3 | +917.4 | 0.0 | 207.0 | 23.2 | +1310.8 | 0.0 | 183.7 |
| HIS TURN DENIED | 1.1 | +84.6 | 126.2 | 8.8 | 1.6 | +39.7 | 103.7 | 33.8 |
| HOLD ODDS | 11.4 | +0.0 | 0.0 | 37.4 | - | - | - | - |
| HOLDER ASSIGNMENT | 12.8 | +1263.3 | 0.0 | 61.5 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.1 | +196.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.8 | -58.1 | 167.8 | 13.1 | 2.2 | -90.3 | 108.2 | 21.2 |
| HUNT IN PAIRS | 0.3 | +4.4 | 0.0 | 0.0 | 0.7 | +24.2 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +41.3 | 7.9 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.4 | +67.5 | 33.3 | 0.0 |
| IDLE COST | 2.7 | -30.6 | 0.0 | 39.8 | 9.7 | -153.7 | 0.0 | 107.9 |
| KEEP FALLS | 0.2 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.1 | +9.0 | 18.4 | 0.0 | 0.1 | +0.5 | 9.2 | 0.0 |
| LANE BY FIGURES | 0.2 | +2.2 | 0.0 | 0.0 | 0.7 | +28.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.9 | +0.0 | 63.6 | 90.7 | 1.9 | +0.0 | 42.8 | 9.7 |
| LONE CHARACTER SAFE SPOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.7 | +61.6 | 0.0 | 0.0 | 0.3 | +31.3 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -11.4 | 0.0 | 0.0 | 0.2 | +3.4 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +4.2 | 0.0 | 0.0 | 0.4 | +27.5 | 0.0 | 0.0 |
| MANOEUVRE | 0.9 | +16.7 | 0.0 | 25.8 | 1.5 | +17.0 | 0.0 | 22.1 |
| MARCH AT ESCAPER | 0.2 | +2.1 | 0.0 | 5.4 | 0.1 | +1.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +12.8 | 0.0 | 0.0 | 0.2 | +6.2 | 0.0 | 0.0 |
| MARCH CHECK | 1.2 | +110.9 | 0.0 | 17.6 | 1.2 | +87.7 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.6 | +26.5 | 0.0 | 19.2 | 0.6 | +22.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.9 | +91.9 | 0.0 | 61.4 | 3.7 | +61.6 | 0.0 | 10.2 |
| MISSILES IN THE MOVE | 4.0 | +215.8 | 0.0 | 12.2 | 3.5 | +53.8 | 0.0 | 18.4 |
| MISSILES NEXT TURN | 4.6 | +150.8 | 0.0 | 31.4 | 4.3 | +51.9 | 0.0 | 18.4 |
| MODEL FACING | 0.8 | +255.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.1 | -0.1 | 0.0 | 29.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.2 | -40.4 | 0.0 | 70.0 | 0.2 | -7.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 14.9 |
| MOVE TO CHARGE COMPUTED | 2.0 | +296.1 | 0.0 | 5.0 | 2.8 | +452.7 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.2 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.2 | +302.5 | 0.0 | 60.0 | 6.2 | +350.9 | 0.0 | 43.4 |
| NEEDED THERE | 0.1 | +19.8 | 18.4 | 0.0 | 0.1 | +16.9 | 9.2 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | -44.4 | 0.0 | 14.2 | 4.9 | -318.1 | 0.0 | 51.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 11.2 | -683.8 | 14.2 | 76.0 |
| NO DOUBLE ROUNDS | 1.7 | -93.0 | 131.9 | 13.1 | 2.3 | -78.1 | 129.0 | 50.1 |
| NOT TURNED | 0.2 | +4.5 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 5.8 |
| NOT WORTH A CAST | 0.2 | -0.4 | 0.0 | 0.0 | 0.8 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 0.4 | -16.9 | 0.0 | 0.0 | 0.8 | -29.6 | 0.0 | 17.8 |
| ONE CHARGE A CHARGER | 1.6 | +0.0 | 0.0 | 27.0 | 1.4 | +0.0 | 0.0 | 12.2 |
| ONE FIGHT FORMULA | 4.0 | -94.9 | 0.0 | 90.8 | 3.4 | -112.6 | 0.0 | 51.8 |
| ONE OBJECTIVE FORMULA | 5.2 | +5.6 | 0.0 | 61.5 | 5.0 | -1.9 | 0.0 | 57.2 |
| ONE TARGET A SHOOTER | 14.8 | +548.7 | 0.0 | 90.2 | 20.0 | +669.9 | 0.0 | 232.3 |
| OPENS A LANE | 0.2 | +0.2 | 0.0 | 0.0 | 0.2 | +1.0 | 11.4 | 0.0 |
| OPENS UP | 0.2 | +10.6 | 14.3 | 0.0 | 0.2 | +16.6 | 7.1 | 0.0 |
| OVERRUNS AWAY | 0.2 | +16.6 | 19.7 | 0.0 | 0.2 | +25.1 | 5.4 | 0.0 |
| PATHS CROSS | 2.5 | +73.1 | 0.0 | 16.8 | 5.5 | +287.5 | 0.0 | 5.0 |
| PLAN RESULT | 43.9 | +699.2 | 411.1 | 491.5 | 42.7 | +561.1 | 446.8 | 646.2 |
| PURSUES BIG PREY | 0.1 | -8.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 7.3 | +574.5 | 84.2 | 7.9 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.0 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.2 | -8.0 | 0.0 | 0.0 | 0.3 | -13.6 | 0.0 | 11.7 |
| REDIRECT COUNTER | 2.1 | +176.8 | 0.0 | 47.7 | 2.4 | +131.4 | 0.0 | 28.4 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.2 | 13.8 | 0.0 |
| REFORMS TO MEET IT | 0.2 | -9.9 | 0.0 | 0.0 | 0.3 | -24.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.6 | +42.3 | 0.0 | 5.4 | 0.4 | +26.3 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +3.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.1 | +9.6 | 110.2 | 8.8 | 2.1 | +34.3 | 136.1 | 28.8 |
| RISK BY HIS FIGURE | 11.5 | -392.3 | 0.0 | 185.8 | 10.8 | -175.2 | 0.0 | 114.8 |
| RUN DOWN | 1.2 | -14.9 | 134.4 | 8.8 | 2.2 | -19.3 | 119.4 | 50.1 |
| SCOUT SPOT | 0.2 | +0.5 | 0.0 | 4.6 | 0.5 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 4.6 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.4 | 0.0 | 0.0 | 0.2 | -1.3 | 0.0 | 6.6 |
| SEARCH SPOT | 4.6 | +248.4 | 0.0 | 63.9 | 7.1 | +246.0 | 0.0 | 64.0 |
| SET UP TOGETHER | 0.3 | +4.2 | 0.0 | 0.0 | 0.5 | +50.1 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +35.7 | 0.0 | 0.0 | 0.1 | +2.4 | 14.9 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +104.3 | 61.7 | 8.8 | 1.0 | +18.8 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.1 | -2.6 | 12.5 | 0.0 | 0.8 | -65.4 | 66.1 | 48.0 |
| SHOT RISK POINTS | 12.2 | +107.6 | 0.0 | 141.4 | 13.2 | +36.2 | 0.0 | 174.0 |
| SHOTS IN THE MOVE | 18.3 | +585.9 | 0.0 | 177.8 | 15.6 | +546.8 | 0.0 | 253.5 |
| SPELL SETS UP CHARGE | 0.6 | +191.5 | 0.0 | 0.0 | 0.1 | +2.4 | 14.9 | 0.0 |
| SPELL WORTH | 0.5 | +12.2 | 5.4 | 59.2 | 2.2 | +32.6 | 19.7 | 0.0 |
| SPELLS IN THE FIGHT | 0.2 | -1.6 | 18.4 | 0.0 | 0.7 | +1.9 | 36.5 | 12.6 |
| STAND AND SHOOT | 0.2 | -6.8 | 47.0 | 0.0 | 0.6 | -4.5 | 59.0 | 12.6 |
| STANDS FOR A REASON | 0.2 | +0.0 | 13.7 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 26.4 | +0.0 | 518.2 | 160.3 | 14.0 | +0.0 | 350.2 | 167.6 |
| STAY WORTH | 24.5 | +154.0 | 430.8 | 142.1 | 17.5 | +188.7 | 247.9 | 289.2 |
| STOPS | - | - | - | - | 0.4 | +1.7 | 33.3 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.8 | +0.0 | 95.5 | 0.0 | 0.8 | +0.0 | 56.5 | 37.5 |
| SURE REACH TOGETHER | 0.2 | +8.3 | 0.0 | 0.0 | 0.8 | +18.8 | 0.0 | 8.2 |
| THE DEARER SUM KEEPS ITS PLAN | 2.8 | +0.0 | 0.0 | 9.8 | 6.1 | +0.0 | 0.0 | 42.5 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -24.8 | 9.2 | 0.0 |
| THE PROMISED MOVE | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.4 | +36.5 | 44.2 | 0.0 | 0.7 | +61.9 | 33.3 | 0.0 |
| TIME ON OUR SIDE | 28.3 | +407.5 | 49.7 | 216.5 | 9.2 | +157.0 | 0.0 | 131.2 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| WAITS AGAIN | 0.8 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +21.1 | 32.2 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 22.1 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.2 | +52.8 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | +14.5 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +1.1 | 18.4 | 0.0 | 0.3 | +23.4 | 42.4 | 0.0 |
| WIDER SPREAD | 1.2 | -6.5 | 132.9 | 13.1 | 1.8 | -0.9 | 72.8 | 33.8 |
| WOUNDS ON THE RANKS | 2.2 | +192.0 | 0.0 | 48.2 | 2.7 | +160.9 | 0.0 | 35.2 |

### Rule changes: h7-mine-dcce224-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 153 | 153 | 143 | 11.92 | +8594 | +60.1 |
| HIS SHOT LIST | 522 | 522 | 140 | 11.67 | +4046 | +28.9 |
| DEPLOY BY FIGURES | 208 | 208 | 133 | 11.08 | +2004 | +15.1 |
| SEARCH SPOT | 140 | 140 | 132 | 11.00 | +5932 | +44.9 |
| ONE TARGET A SHOOTER | 418 | 418 | 119 | 9.92 | +1951 | +16.4 |
| PATHS CROSS | 96 | 96 | 96 | 8.00 | +4328 | +45.1 |
| TIME ON OUR SIDE | 450 | 405 | 90 | 7.50 | +359 | +4.0 |
| FIVE ACTION | 1160 | 1159 | 86 | 7.17 | +3027 | +35.2 |
| LEGAL CHARGES ONLY | 70 | 70 | 70 | 5.83 | +0 | +0.0 |
| SHOT RISK POINTS | 305 | 305 | 54 | 4.50 | +2302 | +42.6 |
| HARD STAY DROPPED | 42 | 42 | 42 | 3.50 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 36 | 36 | 36 | 3.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 57 | 57 | 36 | 3.00 | +3646 | +101.3 |
| FOUR ROUNDS | 55 | 54 | 31 | 2.58 | +1331 | +42.9 |
| COVER ONCE | 151 | 120 | 28 | 2.33 | +579 | +20.7 |
| FALLS SHORT | 295 | 264 | 27 | 2.25 | +259 | +9.6 |
| SHOTS IN THE MOVE | 407 | 382 | 27 | 2.25 | +1050 | +38.9 |
| MAX FOR POSITIONING | 103 | 99 | 26 | 2.17 | +103 | +4.0 |
| CANNON SIGHT KEPT | 25 | 25 | 25 | 2.08 | +0 | +0.0 |
| IDLE COST | 148 | 121 | 21 | 1.75 | +170 | +8.1 |
| ADVANCE LANE KEPT | 20 | 20 | 20 | 1.67 | +0 | +0.0 |
| MARCH CHECK | 29 | 29 | 20 | 1.67 | +597 | +29.8 |
| NEXT OBJECTIVE NEARER | 135 | 135 | 20 | 1.67 | +240 | +12.0 |
| SHOOTS FROM THE BEST SPOT | 29 | 29 | 20 | 1.67 | +165 | +8.2 |
| CHARGE LOSSES | 159 | 159 | 19 | 1.58 | +1178 | +62.0 |
| WOUNDS ON THE RANKS | 58 | 58 | 18 | 1.50 | +878 | +48.8 |
| RISK BY ARC | 38 | 37 | 17 | 1.42 | +463 | +27.2 |
| CANNON PLANNED TARGET | 112 | 112 | 15 | 1.25 | +180 | +12.0 |
| OFF BEST | 15 | 15 | 15 | 1.25 | -559 | -37.3 |
| REDIRECT COUNTER | 54 | 51 | 15 | 1.25 | +921 | +61.4 |
| MANOEUVRE | 29 | 29 | 14 | 1.17 | +405 | +28.9 |
| RISK BY HIS FIGURE | 267 | 267 | 14 | 1.17 | +1381 | +98.6 |
| STAY WORTH | 504 | 484 | 13 | 1.08 | +472 | +36.3 |
| CHARGE NOT DECLARED | 12 | 12 | 12 | 1.00 | -1043 | -86.9 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 1.00 | +1114 | +92.9 |
| RESERVE FALL BACK | 12 | 12 | 12 | 1.00 | +823 | +68.6 |
| HIS TURN DENIED | 32 | 32 | 11 | 0.92 | +495 | +45.0 |
| MISSILES IN THE MOVE | 90 | 64 | 11 | 0.92 | +357 | +32.4 |
| NEXT CHARGE BY LIST | 99 | 99 | 11 | 0.92 | +280 | +25.4 |
| LANE BY FIGURES | 10 | 10 | 10 | 0.83 | +369 | +36.9 |
| MODEL FACING | 10 | 10 | 10 | 0.83 | +3064 | +306.4 |
| TIED UP BY THE SUM | 13 | 12 | 10 | 0.83 | +293 | +29.3 |
| SCOUT WAITS | 9 | 9 | 9 | 0.75 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 9 | 9 | 9 | 0.75 | +21 | +2.3 |
| CHAFF IN THE MOVE | 14 | 14 | 8 | 0.67 | +82 | +10.3 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.67 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 0.58 | +0 | +0.0 |
| CASTING BLOCK | 9 | 9 | 7 | 0.58 | +373 | +53.3 |
| HOLDER AT DEPLOYMENT | 13 | 13 | 7 | 0.58 | +570 | +81.5 |
| NEARER NOT NEEDED | 149 | 145 | 7 | 0.58 | +249 | +35.6 |
| ONE OBJECTIVE FORMULA | 122 | 104 | 7 | 0.58 | +207 | +29.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 7 | 0.58 | +74 | +10.6 |
| FEATURE BUFFS | 20 | 20 | 6 | 0.50 | +72 | +12.1 |
| FIRE IN ORDER | 6 | 6 | 6 | 0.50 | +0 | +0.0 |
| GUN MASK | 23 | 23 | 6 | 0.50 | +120 | +20.1 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.42 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 0.42 | +782 | +156.5 |
| MARCH BY THE SUM | 5 | 5 | 5 | 0.42 | +228 | +45.6 |
| QUARTER ODDS | 88 | 88 | 5 | 0.42 | +298 | +59.5 |
| CHARGE NOW FIRST | 21 | 21 | 4 | 0.33 | -258 | -64.5 |
| ONE FIGHT FORMULA | 89 | 54 | 4 | 0.33 | +27 | +6.7 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.33 | +155 | +38.7 |
| SURE REACH TOGETHER | 12 | 12 | 4 | 0.33 | +49 | +12.2 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.25 | +405 | +135.1 |
| CAST JOB | 9 | 9 | 3 | 0.25 | +6 | +2.0 |
| FALLBACK BY WORTH | 8 | 8 | 3 | 0.25 | +7 | +2.4 |
| HIS MOVE AND SHOT | 48 | 48 | 3 | 0.25 | +4 | +1.3 |
| KEEP FALLS | 3 | 3 | 3 | 0.25 | +36 | +11.9 |
| MISSILES NEXT TURN | 107 | 76 | 3 | 0.25 | +5 | +1.6 |
| WHO HITS BACK | 3 | 3 | 3 | 0.25 | +346 | +115.4 |
| WHOLE FIGHT GAIN | 6 | 6 | 3 | 0.25 | +130 | +43.3 |
| CHAFF PASSED | 2 | 2 | 2 | 0.17 | -13 | -6.7 |
| FIGHT TO THE END | 16 | 16 | 2 | 0.17 | +16 | +7.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.17 | +46 | +23.1 |
| HONEST WORTH | 48 | 47 | 2 | 0.17 | +16 | +7.9 |
| HUNT IN PAIRS | 12 | 7 | 2 | 0.17 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| KILLS COUNT | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.17 | +110 | +55.1 |
| NEEDED THERE | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| OVERRUNS AWAY | 5 | 5 | 2 | 0.17 | +128 | +63.9 |
| STOPS | 5 | 5 | 2 | 0.17 | +3 | +1.6 |
| STUCK PIVOT | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| SUPPORT NARROWED | 19 | 19 | 2 | 0.17 | -41 | -20.7 |
| WIDER SPREAD | 37 | 36 | 2 | 0.17 | +3 | +1.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.08 | -6 | -5.6 |
| BOMBING RUN | 1 | 1 | 1 | 0.08 | +26 | +26.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.08 | -215 | -215.2 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.08 | +133 | +132.6 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.08 | +71 | +70.8 |
| FALL BACK GOOD ORDER | 42 | 41 | 1 | 0.08 | +32 | +31.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.08 | +49 | +49.2 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.08 | +7 | +7.2 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.08 | +10 | +10.4 |
| LONG SHOT | 4 | 4 | 1 | 0.08 | +13 | +12.7 |
| MARCH ODDS | 1 | 1 | 1 | 0.08 | -44 | -44.5 |
| MOVE SPELL IN RANGE | 4 | 4 | 1 | 0.08 | +14 | +13.5 |
| OPENS A LANE | 5 | 1 | 1 | 0.08 | +3 | +3.0 |
| OPENS UP | 4 | 4 | 1 | 0.08 | +14 | +13.9 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.08 | -103 | -102.8 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.08 | +35 | +35.5 |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 1 | 0.08 | +51 | +51.0 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.08 | +32 | +31.8 |
| WHOLE FIGHT | 3 | 3 | 1 | 0.08 | +60 | +59.6 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CHARACTER GUNS | 9 | 9 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 2 | 2 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 102 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 34 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 43 | 43 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 92 | 92 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 87 | 87 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 41 | 41 | 0 | 0.00 | - | - |
| HOLD ODDS | 137 | 137 | 0 | 0.00 | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 9 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 48 | 47 | 0 | 0.00 | - | - |
| NOT TURNED | 7 | 7 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 13 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 1039 | trace | - | - | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 41 | 40 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 10 | 7 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SHOT OR CHARGE | 10 | 10 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 8 | not checked | - | - | - | - |
| SPELL WORTH | 33 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 10 | 9 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 10 | 10 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 485 | 485 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 106 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 7 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 21 | 21 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: h7-mine-dcce224-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.42 | - | 14.5 |
| CHARGE NOT DECLARED | rule | 0.25 | 0.75 | 86.9 |
| JOB FIRST | gate | 0.08 | 0.83 | 40.9 |
| PATHS CROSS | rule | 0.25 | 0.58 | 27.1 |
| CHARGE NOW FIRST | rule | 0.08 | 0.17 | 85.9 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 34.2 |
| CHAFF PASSED | rule | 0.17 | - | 6.7 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 20.7 |
| AFTERMATH BAND | gate | 0.08 | - | 1.8 |
| BEST PRIZE | rule | - | 0.08 | 5.6 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 215.2 |
| DEPLOY BY FIGURES | rule | - | 0.08 | 13.2 |
| FALLBACK | gate | 0.08 | - | 2.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | - | 56.5 |
| MARCH ODDS | rule | 0.08 | - | 44.5 |
| NO REASON | gate | 0.08 | - | 48.2 |
| PURSUES BIG PREY | rule | 0.08 | - | 102.8 |

### Plans: h7-mine-dcce224-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.2 | 73% | 241 | 113 | 47% |
| Mine | join | 1.0 | 100% | 46 | 0 | 0% |
| Mine | move | 29.4 | 93% | 1594 | 0 | 0% |
| Mine | shoot | 11.8 | 60% | 484 | 587 | 121% |
| Mine | support | 0.4 | 100% | 11 | 0 | 0% |
| Opponent | charge | 2.7 | 75% | 365 | 263 | 72% |
| Opponent | join | 1.1 | 100% | 52 | 0 | 0% |
| Opponent | move | 31.8 | 95% | 1696 | 0 | 0% |
| Opponent | shoot | 6.6 | 62% | 253 | 299 | 118% |
| Opponent | support | 0.5 | 50% | 9 | 0 | 0% |

### Packages: hunt the guns, h7-mine-dcce224-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Opponent | 0.4 | 5 | 1 | 100% | 100% | 0% | 2.0 | 134 | 124 | 100% | 24 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 268 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 1.3 | 4 | 1 | 100% | 100% | 0% | 2.0 | 127 | 119 | 100% | 0 |
| Warriors of Chaos | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 153 | 139 | 100% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |

### Battle groups: h7-mine-dcce224-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 44% | 82% | 0% | - | 0% | 9% | 36% | 55% | 0% |
| Opponent | REDIRECT COUNTER | 2.4 | 10% | 33% | 33% | 100% | 0% | 0% | 100% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h7-mine-dcce224-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 0 (9) | 0 | 0 | 40 | 56% | 3.2 | 0 (4) | 0 (3) | 0 (2) | 0 (6) | 0 (3) |
| Mine | Character | 51 | 19 (51) | 19 | 0 | 25 | 22% | 2.4 | 21 (27) | 7 (14) | 28 (6) | 16 (26) | 20 (21) |
| Mine | Clean-up | 14 | 53 (14) | 19 | 35 | 35 | 64% | 2.2 | 57 (5) | 35 (4) | 64 (5) | 105 (7) | 0 (7) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 50 | 100% | - | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 31 | 60 (31) | 26 | 34 | 16 | 32% | 2.8 | 76 (9) | 62 (18) | 10 (4) | 67 (17) | 52 (14) |
| Mine | Holder | 9 | 147 (9) | 36 | 111 | 28 | 67% | 5.0 | 230 (3) | 142 (4) | 0 (1) | 262 (3) | 86 (5) |
| Mine | Shooter | 13 | 88 (13) | 22 | 66 | 25 | 0% | 1.9 | 272 (2) | 60 (8) | 42 (3) | 116 (9) | 32 (4) |
| Mine | War machine | 30 | 9 (30) | 9 | 0 | 25 | 10% | 1.7 | 1 (15) | 0 (6) | 30 (9) | 0 (4) | 10 (26) |
| Mine | Wizard | 3 | 14 (3) | 14 | 0 | 0 | 33% | 5.5 | 0 (1) | 20 (2) | - | - | 14 (3) |
| Opponent | Chaff | 25 | 98 (25) | 20 | 79 | 40 | 56% | 2.5 | 99 (6) | 119 (9) | 78 (10) | 86 (19) | 131 (6) |
| Opponent | Character | 38 | 28 (38) | 28 | 0 | 14 | 42% | 2.3 | 26 (13) | 37 (15) | 19 (7) | 35 (20) | 22 (15) |
| Opponent | Clean-up | 7 | 23 (7) | 0 | 23 | 18 | 57% | 2.7 | 61 (2) | 13 (3) | 0 (2) | 38 (4) | 0 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 18 | 49 (18) | 24 | 24 | 27 | 39% | 3.0 | 105 (8) | 19 (9) | 0 (1) | 60 (11) | 31 (7) |
| Opponent | Hammer | 11 | 20 (11) | 0 | 20 | 18 | 45% | 2.7 | 61 (1) | 17 (7) | 12 (3) | 27 (7) | 9 (4) |
| Opponent | Holder | 7 | 85 (7) | 24 | 60 | 0 | 14% | 4.7 | 0 (1) | 125 (5) | 0 (1) | - | 85 (7) |
| Opponent | Shooter | 11 | 90 (11) | 16 | 73 | 32 | 0% | 1.6 | 122 (6) | 76 (4) | 0 (1) | 105 (8) | 61 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 15 | 37 (15) | 37 | 0 | 52 | 0% | 1.9 | 44 (4) | 32 (10) | 67 (1) | 78 (2) | 30 (13) |
| Opponent | Wizard | 10 | 0 (10) | 0 | 0 | 14 | 40% | 1.8 | 0 (2) | 0 (4) | 0 (2) | 0 (4) | 0 (4) |

### Charged fights: h7-mine-dcce224-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 194 | 38 | 1.0 | 1.0 | 38 | 46 | -8 | 1 of 4 | 2 of 4 | - | -8 |
| Mine | Chaos Dwarfs | 4 | 68 | 268 | 1.8 | 1.1 | 153 | 0 | +153 | 2 of 7 | 5 of 7 | +481 | +99 |
| Mine | Dwarfen Mountain Holds | 4 | 259 | 24 | 1.0 | 1.2 | 24 | 0 | +24 | 2 of 4 | 3 of 4 | +0 | +33 |
| **Mine** | all armies | 12 | 174 | 110 | 1.2 | 1.1 | 88 | 12 | +76 | 5 of 15 | 10 of 15 | +240 | +51 |
| Opponent | Empire of Man | 3 | 265 | 49 | 1.0 | 1.0 | 49 | 0 | +49 | 0 of 3 | 2 of 3 | - | +49 |
| Opponent | Grand Cathay | 1 | 0 | 65 | 1.0 | 1.0 | 65 | 0 | +65 | 0 of 1 | 1 of 1 | - | +65 |
| Opponent | High Elf Realms | 1 | 338 | 520 | 1.0 | 2.0 | 520 | 0 | +520 | 1 of 1 | 1 of 1 | +520 | - |
| Opponent | Ogre Kingdoms | 1 | 330 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 515 | 3.0 | 1.3 | 172 | 130 | +42 | 2 of 3 | 2 of 3 | +515 | -195 |
| Opponent | Vampire Counts | 3 | 0 | 133 | 3.7 | 1.2 | 36 | 12 | +24 | 3 of 11 | 9 of 11 | +110 | +5 |
| Opponent | Warriors of Chaos | 1 | 0 | 574 | 4.0 | 1.2 | 144 | 0 | +144 | 1 of 4 | 3 of 4 | +289 | +95 |
| Opponent | Wood Elf Realms | 1 | 120 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 1 of 2 | 2 of 2 | - | +52 |
| **Opponent** | all armies | 12 | 132 | 194 | 2.1 | 1.2 | 93 | 21 | +72 | 8 of 25 | 20 of 25 | +309 | +13 |

### Effective charges: h7-mine-dcce224-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net -52) | 0 | 1 (net +0) | 1 (net +60) | 0 | 1 (net -40) | 0 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 7 | 1 (net +233) | 0 | 0 | 2 (net +82) | 2 (net +22) | 2 (net +316) | 0 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 (net +33) | 0 | 25% (1 of 4) |
| Opponent | Empire of Man | 3 | 0 | 0 | 0 | 0 | 1 (net +65) | 2 (net +40) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +65) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 1 (net +520) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net -195) | 1 (net -195) | 0 | 1 (net +515) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Vampire Counts | 11 | 3 (net -20) | 2 (net +48) | 1 (net +0) | 0 | 4 (net +76) | 1 (net -75) | 0 | 9% (1 of 11) |
| Opponent | Warriors of Chaos | 4 | 2 (net +142) | 0 | 0 | 1 (net +289) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: h7-mine-dcce224-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 266 | 292 | +90 | 122 | 26 | +96 | +36.0 |
| Mine | Effective (55-75%) | 2 | 188 | 290 | +0 | 49 | 37 | +12 | +6.2 |
| Mine | 76-89% | 3 | 234 | 153 | +75 | 127 | 16 | +111 | +47.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 247 | 178 | +115 | 185 | 48 | +137 | +55.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 324 | 60 | +22 | 22 | 0 | +22 | +6.9 |
| Mine | All fights | 15 | 250 | 187 | +76 | 125 | 31 | +94 | +37.8 |
| Opponent | Long shot (under 50%) | 6 | 178 | 214 | +5 | 89 | 46 | +43 | +24.3 |
| Opponent | 50-54% | 3 | 131 | 320 | -33 | 37 | 65 | -28 | -21.7 |
| Opponent | Effective (55-75%) | 1 | 471 | 480 | +0 | 240 | 177 | +63 | +13.5 |
| Opponent | 76-89% | 4 | 708 | 152 | +347 | 347 | 4 | +343 | +48.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 213 | 156 | +2 | 77 | 32 | +45 | +21.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 440 | 91 | +74 | 90 | 16 | +73 | +16.7 |
| Opponent | No odds | 2 | 0 | 146 | +52 | 99 | 0 | +99 | - |
| Opponent | All fights | 25 | 313 | 188 | +72 | 129 | 35 | +94 | +30.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h7-mine-dcce224-p2 | move | 57 | 15 (26%) | 9 (16%) | 8 (14%) | 34 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224, L0325, L0427 |
| Elixir of Power | Opponent | L0411 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L0633 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427 |
| Ring of Doom | Mine | L0207, L0224 |
| Ring of Doom | Opponent | L0411, L0633 |
| Ring of Jet | Opponent | L0411 |
| Standard of the Fell Warrior | Opponent | L0513 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

# Doctrine scorecard: h7-opp-dcce224-p4

### Scorecard: h7-opp-dcce224-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 6 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 4 | 3 | 3 | 6 | 0 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 4 | 4 | 2 | 2 | 0 | 0 | 0 | 30 |
| L0216 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0232 | 4 | 1 | Mine | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0316 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Opponent | no | 4 | 2 | 0 | 4 | 0 | 0 | 0 | 424 |
| **Average** | | | Mine | 0% | 2.0 | 4.0 | 1.0 | 1.2 | 0.0 | 0.0 | 0.0 | 33.3 |
| **Average** | | | Opponent | 17% | 2.5 | 2.2 | 2.5 | 2.7 | 0.2 | 0.0 | 0.0 | 127.3 |

### KPIs: h7-opp-dcce224-p4

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 6 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 41% (9 of 22) | 0% (0 of 31) | 17% (9 of 53) |
| Winner chose to follow up after the loser gave ground |  | 60% (3 of 5); on the table 60% | 88% (7 of 8); on the table 88% | 77% (10 of 13); on the table 77% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 75% (3 of 4); on the table 75% | 100% (6 of 6); on the table 100% | 90% (9 of 10); on the table 90% |
| Winner chose to follow up or pursue (all three) |  | 67% (6 of 9); on the table 67% | 93% (13 of 14); on the table 93% | 83% (19 of 23); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 32% (38 of 120) | 42% (5 of 12) | 33% (43 of 132) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 35% (38 of 108) | 42% (5 of 12) | 36% (43 of 120) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 86% (6 of 7) | 62% (13 of 21) | 68% (19 of 28) |
| Points that never fought | lower | 59% (6787 of 11596) | 60% (7170 of 11998) | 59% (13957 of 23594) |
|   infantry points that never fought | lower | 55% (2007 of 3676) | 77% (1856 of 2410) | 63% (3863 of 6086) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (23 of 38) | 56% (25 of 45) | 58% (48 of 83) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 3.0 uses a game | 100% (4 of 4); 2.0 uses a game | 100% (10 of 10); 2.5 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.8 uses a game | 67% (2 of 3); 0.3 uses a game | 64% (7 of 11); 0.6 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (4366 of 8400) | 55% (5902 of 10814) | 53% (10268 of 19214) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 8.5 (62%) | 0.7 (57%) | 9.2 (62%) |
| MARCHED: its unit marched | 2.2 (16%) | 0.5 (43%) | 2.7 (18%) |
| CHARGED: its unit charged | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 1.5 (11%) | 0.0 (0%) | 1.5 (10%) |
| GONE: slain | 0.5 (4%) | 0.0 (0%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 5.5 | 4.3 | 7.2 | 0.0 |
| not cast | 7.5 | 3.7 | 14.8 | 14.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.5 (14%) | 9.2 (62%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.7 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (4%) | 0.5 (14%) | 1.5 (10%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.7 (9%) | 0.0 (0%) | 0.5 (3%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.5 (7%) | 0.3 (9%) | 0.7 (4%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (9%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.3 (71%) | 2.3 (64%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 4.3 a game | 0.8 a game | 2.6 a game |
| stood (cast and not dispelled) | 65% (17 of 26) | 0% (0 of 1) | 63% (17 of 27) |
| the unit moved after it | 76% (13 of 17) | - | 76% (13 of 17) |
| it charged on its next turn | 0% (0 of 17) | - | 0% (0 of 17) |
| the enemy charged it first | 12% (2 of 17) | - | 12% (2 of 17) |
| it fought by the end of its next turn | 0% (0 of 17) | - | 0% (0 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 18% (3 of 17) | - | 18% (3 of 17) |
| none of these (no charge, no fight, no charge escaped) | 71% (12 of 17) | - | 71% (12 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (46 of 76) | 39% (48 of 122) | 47% (94 of 198) |
|   cavalry | - | 61% (19 of 31) | 61% (19 of 31) |
|   character | - | 20% (6 of 30) | 20% (6 of 30) |
|   chariot | 46% (11 of 24) | 0% (0 of 3) | 41% (11 of 27) |
|   infantry | 94% (15 of 16) | 38% (13 of 34) | 56% (28 of 50) |
|   war machine | 56% (20 of 36) | 42% (10 of 24) | 50% (30 of 60) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.5 (10%) | 3.2 (26%) | 3.7 (21%) |
| CHARGED: it charged | 0.0 (0%) | 2.2 (18%) | 2.2 (12%) |
| IN COMBAT: it fought this turn or the last | 0.2 (3%) | 0.2 (1%) | 0.3 (2%) |
| MOVED: a war machine that moved | 2.3 (47%) | 0.8 (7%) | 3.2 (18%) |
| NO TARGET IN RANGE | 1.7 (33%) | 3.0 (24%) | 4.7 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.2 (3%) | 2.0 (16%) | 2.2 (12%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.5 (4%) | 0.5 (3%) |
| OTHER BAR | 0.2 (3%) | 0.2 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.2 | 1.2 | 79% | 4.2 pts | 13 pts |
| character | 1.2 | 0.5 | 57% | 2.6 pts | 3 pts |
| chariot | 1.8 | 2.5 | 18% | 59.4 pts | 109 pts |
| infantry | 6.5 | 1.3 | 82% | 4.0 pts | 26 pts |
| war machine | 5.0 | 5.0 | 67% | 36.1 pts | 181 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 4.8 | 3.6 |
| Charges that made contact a game | 1.2 | 3.5 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.35 declared, 0.17 contact (40 units) | 0.60 declared, 0.44 contact (48 units) | 0.49 declared, 0.32 contact (88 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (4 of 9) | - | 100% (1 of 1) | 50% (5 of 10) |
| Character in a unit | 86% (6 of 7) | 57% (4 of 7) | - | 71% (10 of 14) |
| Character on its own | 67% (2 of 3) | 67% (4 of 6) | 44% (4 of 9) | 56% (10 of 18) |
| Chariot | 0% (0 of 1) | 50% (2 of 4) | - | 40% (2 of 5) |
| Infantry | 50% (2 of 4) | 33% (5 of 15) | - | 37% (7 of 19) |
| Monster | 83% (5 of 6) | - | - | 83% (5 of 6) |
| Monstrous | 67% (2 of 3) | - | - | 67% (2 of 3) |
| War Machines | 100% (6 of 6) | 50% (1 of 2) | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 67% (6 of 9); on the table 67% | 31% (32 of 102) | 49% | 50% (11 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 1.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 2 | - | 33% (6 of 18) | 76% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 69% | 43% (3 of 7) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 89% (8 of 9); on the table 89% | - | 66% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (2 of 2); on the table 100% | - | 41% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 67% (4 of 6) | 75% | 60% (6 of 10) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h7-opp-dcce224-p4, 6 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (9) | 67% (4) | 62% (13) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.50 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.17 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.83 | 0.50 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: h7-opp-dcce224-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 44% (4 of 9) | 52% (13 of 25) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (15 of 61) | 15% (3 of 20) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 33% (6 of 18) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 50% (6 of 12) | 57% (8 of 14) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.2 | 2.7 |
| Movement | Points that never moved of their own | 33.3 | 127.3 |
| Movement | Fights charged into per game | 1.0 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 5, net -42 | 5 of 17, net +294 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 2 of 17, net +85 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 4 of 17, net +71 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +70 | 4 of 17, net +32 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.3 | 7.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (6 of 26) | 42% (19 of 45) |
| Shooting | Points destroyed by shooting units | 63.2 | 18.3 |
| Shooting | War machine shots | 3.3 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (9 of 20) | 60% (6 of 10) |
| Shooting | Points destroyed by war machines | 34.8 | 23.3 |
| Magic | Magic missiles cast | 4.0 | 0.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (6 of 24) | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 11.8 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 58.5 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 3.3 / 0.0 / 0.0 / 0.0 | 1.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 28.3 | 258.2 |
| Combat | Points run down | 22.8 | 119.3 |
| Combat | Net points per charged fight, damage counted | +29 | +91 |
| Combat | Net per 100 charger points, damage counted | +25.1 | +34.6 |
| Combat | First round won (charged fights) | 50% | 65% |
| Combat | Net points per charged fight | -4 | +108 |
| Combat | Net points per supported fight / lone fight | -85 / +12 | +0 / +114 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 7 of 20 |
| Game | Points lost | 438.5 | 402.7 |
| Game | VP from objectives | 606.7 | 655.0 |
| Game | Lone holders (player turns) | 2.0 | 2.5 |

- Mine won / drew / lost: 1 / 4 / 1 of 6 ended games (of 6); mean margin (Mine - Opponent) -84 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 841
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h7-opp-dcce224-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +141.0 | 0.0 | 0.0 | 0.2 | +1.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.2 | -7.8 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.5 | -224.2 | 61.2 | 0.0 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 20.5 | 36.7 | 0.3 | +0.0 | 0.0 | 16.7 |
| CANNON PLANNED TARGET | 2.7 | +152.8 | 23.7 | 41.7 | 1.3 | +49.2 | 46.7 | 16.7 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.2 | +0.0 | 13.5 | 0.0 |
| CAST JOB | 0.7 | +9.0 | 17.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.7 | +111.0 | 145.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.8 | +41.5 | 0.0 | 0.0 | 0.2 | +1.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.6 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.8 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.2 | -283.6 | 0.0 | 29.2 | 5.7 | -250.2 | 0.0 | 28.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.5 | +0.0 | 23.2 | 0.0 | 2.5 | +0.0 | 100.5 | 119.0 |
| CHARGER SLAIN LOST | 0.2 | -1.6 | 22.8 | 0.0 | 0.3 | -8.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.2 | +0.0 | 0.0 | 14.2 | - | - | - | - |
| CHEAPEST HOLDER | 1.3 | -93.1 | 119.0 | 61.2 | - | - | - | - |
| COMBAT PIVOT | 0.8 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.2 | +0.0 | 8.7 | 0.0 |
| CONVEYANCE SEARCH | 3.0 | +209.6 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.5 | -837.6 | 0.0 | 10.8 | 2.3 | -78.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.2 | +58.7 | 0.0 | 0.0 | 7.7 | +15.0 | 0.0 | 5.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +3.9 | 46.0 | 0.0 | 3.3 | +0.0 | 144.2 | 119.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 5.8 | +99.6 | 0.0 | 8.7 | 16.7 | +213.4 | 0.0 | 228.0 |
| FEATURE BUFFS | 5.3 | +159.1 | 0.0 | 0.0 | 1.0 | +68.5 | 0.0 | 19.2 |
| FIGHT TO THE END | 0.2 | +0.0 | 23.2 | 0.0 | 1.5 | +79.0 | 28.3 | 99.8 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 18.3 | - | - | - | - |
| FIVE ACTION | 42.7 | +2369.5 | 362.2 | 345.2 | 48.2 | +3710.9 | 298.7 | 457.7 |
| FLANK NOT WEIGHED | 10.0 | +0.0 | 0.0 | 8.7 | 4.3 | +0.0 | 0.0 | 92.8 |
| FOLLOW UP WEIGHED | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +108.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.5 | +18.0 | 46.0 | 13.5 | 4.0 | +321.2 | 172.5 | 119.0 |
| FRIEND CHARGES FIRST | 0.3 | -7.1 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -4.1 | 0.0 | 0.0 | 0.2 | -13.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +19.5 | 0.0 | 19.2 |
| GIVES UP | - | - | - | - | 0.2 | -0.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.2 | +40.6 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 0.3 | +6.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.5 | +0.0 | 0.0 | 39.2 | 2.0 | +0.0 | 0.0 | 19.2 |
| HIS CHARGE DENIED | 0.3 | +9.2 | 22.8 | 0.0 | 0.3 | +9.8 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.2 | +0.0 | 0.0 | 10.8 | 2.2 | +0.0 | 0.0 | 21.0 |
| HIS LEGAL MOVES | 2.8 | +0.0 | 0.0 | 0.0 | 2.8 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.8 | -22.4 | 0.0 | 18.3 | 1.2 | -58.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 2.5 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 2.7 | +0.0 | 0.0 | 28.3 | 1.7 | +0.0 | 0.0 | 13.3 |
| HIS SHOT LIST | 16.8 | +537.6 | 0.0 | 106.3 | 22.5 | +1174.1 | 0.0 | 159.2 |
| HIS TURN DENIED | - | - | - | - | 1.8 | +95.2 | 82.8 | 119.0 |
| HOLD ODDS | - | - | - | - | 11.5 | +0.0 | 0.0 | 91.5 |
| HOLDER ASSIGNMENT | - | - | - | - | 13.3 | +1273.1 | 0.0 | 110.7 |
| HOLDER AT DEPLOYMENT | 1.2 | +185.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.2 | -9.7 | 23.2 | 0.0 | 3.5 | -227.5 | 144.2 | 119.0 |
| HORN WORTH | - | - | - | - | 0.2 | +2.3 | 0.0 | 0.0 |
| IDLE COST | 2.2 | -9.8 | 0.0 | 14.2 | 12.7 | -203.6 | 0.0 | 77.0 |
| KEEP FALLS | 0.2 | +11.3 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 1.2 | +39.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 56.7 | 57.5 | 7.8 | +0.0 | 77.5 | 13.3 |
| LONE WIZARD KEPT IN | 1.7 | +108.3 | 0.0 | 0.0 | 0.3 | +20.0 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.5 | 0.0 | 13.5 | 0.3 | +1.2 | 10.8 | 0.0 |
| LOST CHARGE | 0.2 | -0.1 | 23.2 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.8 | +75.1 | 0.0 | 0.0 | 1.2 | +5.4 | 0.0 | 21.0 |
| MARCH AT ESCAPER | 0.3 | +23.9 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +4.9 | 0.0 | 0.0 | 0.7 | +18.8 | 0.0 | 0.0 |
| MARCH CHECK | 1.2 | +107.3 | 0.0 | 0.0 | 1.0 | +37.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +9.5 | 0.0 | 0.0 | 0.7 | -50.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 10.0 | +111.6 | 0.0 | 8.7 | 4.8 | +77.8 | 0.0 | 41.2 |
| MISSILES IN THE MOVE | 6.0 | +468.6 | 0.0 | 0.0 | 2.2 | +21.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.7 | +318.7 | 0.0 | 0.0 | 3.3 | +19.9 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.0 | -47.5 | 0.0 | 0.0 | 1.0 | -53.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.0 | +95.7 | 0.0 | 0.0 | 4.7 | +553.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | 0.2 | +1.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.8 | +176.7 | 0.0 | 10.8 | 4.3 | +180.2 | 0.0 | 212.7 |
| NEXT CHARGE BY LIST | 4.2 | -561.7 | 17.3 | 0.0 | 6.8 | -263.0 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 4.3 | -145.7 | 19.2 | 41.2 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.5 | -14.8 | 46.0 | 13.5 | 3.7 | -59.2 | 130.7 | 119.0 |
| NO RALLY LEFT | 0.2 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.7 | -0.4 | 0.0 | 0.0 | 0.5 | -0.5 | 0.0 | 0.0 |
| OFF BEST | - | - | - | - | 0.3 | -18.7 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.8 | +0.0 | 0.0 | 8.7 | 2.2 | +0.0 | 0.0 | 85.3 |
| ONE FIGHT FORMULA | 4.8 | -64.6 | 0.0 | 0.0 | 6.0 | -134.3 | 0.0 | 22.8 |
| ONE OBJECTIVE FORMULA | 4.2 | +3.6 | 0.0 | 26.0 | 4.5 | -92.1 | 0.0 | 68.7 |
| ONE TARGET A SHOOTER | 13.7 | +255.2 | 0.0 | 83.5 | 21.7 | +705.6 | 0.0 | 269.7 |
| OPENS UP | - | - | - | - | 0.2 | +5.3 | 10.8 | 0.0 |
| OVERRUNS AWAY | 0.2 | +0.4 | 0.0 | 0.0 | 0.3 | +14.2 | 0.0 | 0.0 |
| PATHS CROSS | 2.3 | +96.5 | 0.0 | 0.0 | 3.7 | +121.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -5.8 | 0.0 | 0.0 |
| PLAN RESULT | 37.5 | +515.9 | 57.0 | 479.5 | 41.3 | +161.4 | 98.7 | 534.2 |
| QUARTER ODDS | - | - | - | - | 8.7 | +1259.4 | 122.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.2 | +29.4 | 0.0 | 56.7 | 3.5 | +10.8 | 0.0 | 28.3 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 2.7 | +145.9 | 0.0 | 14.2 | 3.7 | +152.1 | 0.0 | 41.2 |
| REDIRECT WEIGHED | 0.3 | +10.5 | 23.2 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 0.7 | -11.5 | 0.0 | 0.0 | 0.7 | -95.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +54.6 | 0.0 | 0.0 |
| RISK BY ARC | 1.2 | +47.7 | 46.0 | 13.5 | 3.0 | +54.6 | 111.3 | 119.0 |
| RISK BY HIS FIGURE | 14.5 | -264.5 | 0.0 | 72.8 | 12.2 | -106.4 | 0.0 | 194.0 |
| RUN DOWN | 1.3 | -16.3 | 46.0 | 0.0 | 2.8 | -18.5 | 83.0 | 119.0 |
| SAME CHARGE LATER | - | - | - | - | 0.2 | -9.2 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -11.4 | 0.0 | 3.2 |
| SEARCH SPOT | 5.0 | +183.1 | 0.0 | 21.7 | 5.5 | +157.2 | 0.0 | 40.2 |
| SELF MOVE SPELL | - | - | - | - | 1.0 | +47.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.8 | +4.4 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.5 | +76.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.2 | +164.1 | 91.7 | 61.2 | 0.5 | +9.5 | 61.2 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -29.0 | 0.0 | 16.7 |
| SHOT RISK POINTS | 8.8 | +44.8 | 0.0 | 29.2 | 19.2 | +307.4 | 0.0 | 79.2 |
| SHOTS IN THE MOVE | 9.8 | +608.0 | 0.0 | 175.8 | 11.3 | +261.9 | 0.0 | 88.7 |
| SPELL OFF EDGE | 0.2 | +45.3 | 72.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.8 | +193.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.8 | +25.1 | 55.8 | 55.8 | 1.3 | +46.1 | 31.7 | 31.7 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.2 | -4.1 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.5 | -3.5 | 32.5 | 19.2 |
| STANDS FOR A REASON | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 19.7 | +0.0 | 316.2 | 261.2 | 14.0 | +0.0 | 126.2 | 100.0 |
| STAY WORTH | 9.3 | +13.6 | 192.0 | 260.8 | 13.0 | +141.4 | 65.0 | 88.7 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 46.0 | 0.0 | 1.2 | +0.0 | 58.7 | 19.2 |
| SURE REACH TOGETHER | 0.2 | +0.2 | 0.0 | 0.0 | 0.8 | +4.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.8 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -11.0 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 1.2 | +0.0 | 0.0 | 22.8 |
| TIED UP BY THE SUM | 0.3 | +7.9 | 23.2 | 0.0 | 1.2 | +88.9 | 72.2 | 19.2 |
| TIME ON OUR SIDE | 26.7 | +468.0 | 17.3 | 47.7 | 6.7 | +105.6 | 0.0 | 26.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 17.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +57.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +14.5 | 41.8 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +13.3 | 0.0 | 13.5 | 0.2 | +51.4 | 0.0 | 0.0 |
| WIDER SPREAD | 1.3 | -0.9 | 46.0 | 0.0 | 2.5 | -6.0 | 137.3 | 19.2 |
| WOUNDS ON THE RANKS | 2.0 | +41.0 | 0.0 | 0.0 | 1.3 | +120.8 | 0.0 | 0.0 |

### Rule changes: h7-opp-dcce224-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 81 | 81 | 81 | 13.50 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 80 | 80 | 74 | 12.33 | +3322 | +44.9 |
| HIS SHOT LIST | 236 | 236 | 69 | 11.50 | +2422 | +35.1 |
| SEARCH SPOT | 63 | 63 | 59 | 9.83 | +2061 | +34.9 |
| DEPLOY BY FIGURES | 95 | 95 | 56 | 9.33 | +693 | +12.4 |
| ONE TARGET A SHOOTER | 212 | 212 | 55 | 9.17 | +680 | +12.4 |
| PATHS CROSS | 36 | 36 | 36 | 6.00 | +1306 | +36.3 |
| TIME ON OUR SIDE | 200 | 169 | 34 | 5.67 | +74 | +2.2 |
| MAX FOR POSITIONING | 89 | 85 | 28 | 4.67 | +73 | +2.6 |
| SHOT RISK POINTS | 168 | 168 | 25 | 4.17 | +1024 | +41.0 |
| FIVE ACTION | 545 | 545 | 21 | 3.50 | +490 | +23.4 |
| MOVE TO CHARGE COMPUTED | 40 | 40 | 19 | 3.17 | +895 | +47.1 |
| RANDOM MOVE BY FIGURES | 28 | 28 | 19 | 3.17 | +241 | +12.7 |
| COVER ONCE | 59 | 46 | 15 | 2.50 | +290 | +19.3 |
| FALLS SHORT | 135 | 119 | 14 | 2.33 | +44 | +3.2 |
| FOUR ROUNDS | 33 | 33 | 14 | 2.33 | +376 | +26.8 |
| HARD STAY DROPPED | 14 | 14 | 14 | 2.33 | +0 | +0.0 |
| REDIRECT COUNTER | 38 | 31 | 13 | 2.17 | +474 | +36.5 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 2.00 | +770 | +64.2 |
| MANOEUVRE | 18 | 18 | 11 | 1.83 | +485 | +44.1 |
| QUARTER ODDS | 52 | 52 | 11 | 1.83 | +1352 | +122.9 |
| RISK BY ARC | 25 | 25 | 11 | 1.83 | +160 | +14.6 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 1.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 10 | 1.67 | +260 | +26.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 1.50 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 1.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 1.33 | +0 | +0.0 |
| IDLE COST | 89 | 75 | 8 | 1.33 | +105 | +13.1 |
| MISSILES IN THE MOVE | 49 | 38 | 8 | 1.33 | +128 | +16.0 |
| RESERVE FALL BACK | 8 | 8 | 8 | 1.33 | +328 | +40.9 |
| SHOTS IN THE MOVE | 127 | 113 | 8 | 1.33 | +274 | +34.2 |
| CASTING BLOCK | 10 | 10 | 7 | 1.17 | +139 | +19.9 |
| COMBAT PIVOT | 7 | 7 | 7 | 1.17 | +0 | +0.0 |
| FEATURE BUFFS | 38 | 38 | 7 | 1.17 | +322 | +45.9 |
| LANE BY FIGURES | 7 | 7 | 7 | 1.17 | +237 | +33.8 |
| MARCH CHECK | 13 | 13 | 7 | 1.17 | +216 | +30.9 |
| MARCH BY THE SUM | 6 | 6 | 6 | 1.00 | +142 | +23.7 |
| NEXT CHARGE BY LIST | 66 | 66 | 6 | 1.00 | +75 | +12.5 |
| CANNON PLANNED TARGET | 24 | 24 | 5 | 0.83 | +1 | +0.3 |
| CHAFF PASSED | 5 | 5 | 5 | 0.83 | -4 | -0.8 |
| STUCK PIVOT | 5 | 5 | 5 | 0.83 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 20 | 20 | 5 | 0.83 | +281 | +56.1 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 0.67 | +0 | +0.0 |
| CHARGE NOT DECLARED | 4 | 4 | 4 | 0.67 | -279 | -69.8 |
| CHARGE NOW FIRST | 18 | 18 | 4 | 0.67 | -83 | -20.8 |
| TIED UP BY THE SUM | 9 | 9 | 4 | 0.67 | +39 | +9.9 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.50 | +852 | +284.1 |
| CHAFF IN THE MOVE | 6 | 6 | 3 | 0.50 | +0 | +0.0 |
| CHARGE LOSSES | 71 | 71 | 3 | 0.50 | +239 | +79.7 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 0.50 | +649 | +216.3 |
| HIS TURN DENIED | 11 | 11 | 3 | 0.50 | +41 | +13.6 |
| HOLDER AT DEPLOYMENT | 7 | 7 | 3 | 0.50 | +258 | +86.0 |
| MISSILES NEXT TURN | 66 | 50 | 3 | 0.50 | +46 | +15.4 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.50 | +118 | +39.2 |
| NEXT OBJECTIVE NEARER | 26 | 26 | 3 | 0.50 | +7 | +2.5 |
| SURE REACH TOGETHER | 6 | 6 | 3 | 0.50 | +1 | +0.2 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.33 | +117 | +58.5 |
| HIS CHARGE DENIED | 4 | 4 | 2 | 0.33 | +26 | +13.2 |
| NEARER NOT NEEDED | 49 | 44 | 2 | 0.33 | +37 | +18.7 |
| OFF BEST | 2 | 2 | 2 | 0.33 | -112 | -56.0 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.33 | -35 | -17.4 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.33 | +63 | +31.4 |
| RISK BY HIS FIGURE | 160 | 160 | 2 | 0.33 | +48 | +24.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.33 | +2 | +1.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.33 | +284 | +141.8 |
| WHOLE FIGHT | 2 | 2 | 2 | 0.33 | +50 | +24.8 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.33 | +6 | +2.9 |
| WIDER SPREAD | 23 | 23 | 2 | 0.33 | +10 | +5.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.17 | -57 | -57.2 |
| BLOWS WHERE AIMED | 3 | 3 | 1 | 0.17 | +4 | +3.9 |
| CAST JOB | 4 | 4 | 1 | 0.17 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.17 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 26 | 26 | 1 | 0.17 | +19 | +19.0 |
| FIGHT TO THE END | 10 | 10 | 1 | 0.17 | +18 | +18.3 |
| GUN MASK | 2 | 2 | 1 | 0.17 | +28 | +28.0 |
| HORN WORTH | 1 | 1 | 1 | 0.17 | +14 | +13.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.17 | +81 | +80.7 |
| NO DOUBLE ROUNDS | 31 | 31 | 1 | 0.17 | +5 | +5.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.17 | +2 | +2.2 |
| ONE FIGHT FORMULA | 65 | 35 | 1 | 0.17 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 52 | 37 | 1 | 0.17 | +22 | +22.4 |
| OPENS UP | 1 | 1 | 1 | 0.17 | +9 | +9.0 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.17 | +45 | +45.3 |
| RUN DOWN | 25 | 25 | 1 | 0.17 | +2 | +2.5 |
| SCOUT WAITS | 1 | 1 | 1 | 0.17 | +0 | +0.0 |
| SET UP TOGETHER | 5 | 4 | 1 | 0.17 | +8 | +8.3 |
| STAY WORTH | 134 | 123 | 1 | 0.17 | +43 | +43.2 |
| SUPPORT NARROWED | 11 | 11 | 1 | 0.17 | -0 | -0.2 |
| ALREADY CARRIED | 6 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CHARACTER GUNS | 5 | 5 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 8 | 8 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 18 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 86 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 27 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 32 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 34 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 26 | 26 | 0 | 0.00 | - | - |
| HOLD ODDS | 69 | 69 | 0 | 0.00 | - | - |
| HONEST WORTH | 28 | 28 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 12 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 473 | trace | - | - | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 19 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 202 | 202 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 39 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 7 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 13 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: h7-opp-dcce224-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.50 | 10.7 |
| CHARGE NOT DECLARED | rule | 0.33 | 0.33 | 69.8 |
| CHARGE NOW FIRST | rule | - | 0.67 | 20.8 |
| PATHS CROSS | rule | 0.33 | 0.33 | 23.4 |
| CANNON PLANNED TARGET | rule | 0.50 | - | 3.9 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 17.4 |
| BEST PRIZE | rule | - | 0.17 | 57.2 |
| CHAFF PASSED | rule | 0.17 | - | 3.8 |
| FIGHT ORDER BAND | gate | - | 0.17 | 1.8 |
| NO REASON | gate | - | 0.17 | 110.2 |

### Plans: h7-opp-dcce224-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.2 | 86% | 41 | 227 | 548% |
| Mine | move | 27.3 | 96% | 1578 | 0 | 0% |
| Mine | shoot | 8.5 | 43% | 651 | 289 | 44% |
| Mine | support | 0.5 | 100% | 0 | 0 | - |
| Opponent | charge | 3.0 | 44% | 878 | 101 | 12% |
| Opponent | move | 35.5 | 95% | 2002 | 0 | 0% |
| Opponent | shoot | 2.7 | 31% | 165 | 60 | 37% |
| Opponent | support | 0.2 | 0% | 0 | 0 | - |

### Battle groups: h7-opp-dcce224-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 19% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.7 | 9% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h7-opp-dcce224-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Mine | Character | 25 | 11 (25) | 11 | 0 | 34 | 24% | 2.3 | 9 (6) | 18 (6) | 3 (7) | 12 (13) | 4 (6) |
| Mine | Clean-up | 1 | 99 (1) | 0 | 99 | 100 | 0% | 2.0 | 99 (1) | - | - | 99 (1) | - |
| Mine | Fast Hammer | 10 | 21 (10) | 21 | 0 | 34 | 40% | 4.3 | 263 (1) | 0 (3) | 0 (6) | 24 (9) | 0 (1) |
| Mine | Hammer | 16 | 42 (16) | 25 | 17 | 15 | 25% | 2.5 | 47 (4) | 50 (8) | 20 (4) | 37 (7) | 47 (9) |
| Mine | Holder | 7 | 90 (7) | 0 | 90 | 0 | 86% | 6.0 | - | 122 (5) | 0 (2) | 104 (4) | 70 (3) |
| Mine | Shooter | 4 | 92 (4) | 0 | 92 | 75 | 0% | 1.2 | - | 92 (4) | - | 0 (2) | 185 (2) |
| Mine | War machine | 8 | 18 (8) | 18 | 0 | 42 | 0% | 2.0 | 20 (7) | 0 (1) | - | 0 (2) | 22 (6) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 40% | 3.7 | 0 (4) | 0 (1) | - | 0 (3) | 0 (2) |
| Opponent | Chaff | 13 | 62 (13) | 13 | 49 | 31 | 62% | 1.8 | 39 (7) | 103 (4) | 0 (2) | 71 (12) | 0 (1) |
| Opponent | Character | 15 | 36 (15) | 36 | 0 | 16 | 20% | 2.2 | 25 (2) | 42 (8) | 33 (5) | 11 (8) | 64 (7) |
| Opponent | Clean-up | 4 | 50 (4) | 0 | 50 | 0 | 50% | 4.0 | 161 (2) | 16 (2) | - | 33 (2) | 61 (2) |
| Opponent | Fast Hammer | 8 | 26 (8) | 5 | 21 | 47 | 62% | 2.3 | 12 (2) | 52 (4) | 0 (2) | 32 (6) | 0 (2) |
| Opponent | Hammer | 8 | 25 (8) | 23 | 2 | 12 | 50% | 5.2 | - | 46 (5) | 4 (3) | 16 (3) | 29 (5) |
| Opponent | Holder | 3 | 18 (3) | 0 | 18 | 28 | 0% | 5.7 | 0 (1) | 65 (1) | 0 (1) | 0 (2) | 65 (1) |
| Opponent | Shooter | 4 | 79 (4) | 15 | 64 | 17 | 0% | 2.2 | 72 (2) | 72 (1) | 102 (1) | 109 (2) | 59 (2) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 4 | 35 (4) | 35 | 0 | 25 | 25% | 1.0 | 70 (2) | - | 0 (2) | - | 35 (4) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 61 | 33% | 1.5 | - | 0 (1) | 0 (1) | - | 0 (2) |

### Charged fights: h7-opp-dcce224-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 88 | 77 | 1.5 | 1.2 | 52 | 56 | -4 | 2 of 6 | 3 of 6 | -85 | +12 |
| Mine | Chaos Dwarfs | 2 | 294 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 6 | 156 | 52 | 1.0 | 1.2 | 52 | 56 | -4 | 2 of 6 | 3 of 6 | -85 | +12 |
| Opponent | High Elf Realms | 1 | 0 | 1051 | 4.0 | 1.0 | 263 | 0 | +263 | 3 of 4 | 2 of 4 | - | +263 |
| Opponent | Kingdom of Bretonnia | 2 | 70 | 109 | 3.0 | 1.0 | 36 | 0 | +36 | 1 of 6 | 4 of 6 | - | +36 |
| Opponent | Warriors of Chaos | 2 | 0 | 393 | 3.5 | 1.0 | 112 | 0 | +112 | 2 of 7 | 4 of 7 | - | +112 |
| Opponent | Wood Elf Realms | 1 | 110 | 110 | 3.0 | 1.3 | 37 | 0 | +37 | 1 of 3 | 3 of 3 | +0 | +55 |
| **Opponent** | all armies | 6 | 42 | 361 | 3.3 | 1.1 | 108 | 0 | +108 | 7 of 20 | 13 of 20 | +0 | +114 |

### Effective charges: h7-opp-dcce224-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 2 (net -42) | 0 | 1 (net +0) | 0 | 0 | 2 (net +70) | 1 | 20% (1 of 5) |
| Opponent | High Elf Realms | 4 | 2 (net +493) | 0 | 1 (net +0) | 0 | 0 | 1 (net +65) | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 6 | 1 (net +0) | 0 | 0 | 2 (net +0) | 3 (net +73) | 0 | 0 | 0% (0 of 6) |
| Opponent | Warriors of Chaos | 7 | 2 (net +243) | 0 | 1 (net +170) | 0 | 1 (net +65) | 3 (net +22) | 0 | 14% (1 of 7) |

### Charged fights, damage counted: h7-opp-dcce224-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 109 | 292 | -42 | 66 | 56 | +10 | +9.2 |
| Mine | Effective (55-75%) | 1 | 52 | 214 | +0 | 0 | 26 | -26 | -50.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 81 | 101 | +70 | 93 | 0 | +93 | +114.5 |
| Mine | No odds | 1 | 272 | 170 | -80 | 283 | 286 | -3 | -1.1 |
| Mine | All fights | 6 | 117 | 195 | -4 | 100 | 71 | +29 | +25.1 |
| Opponent | Long shot (under 50%) | 5 | 439 | 298 | +294 | 313 | 111 | +202 | +46.0 |
| Opponent | Effective (55-75%) | 2 | 316 | 246 | +85 | 105 | 0 | +105 | +33.3 |
| Opponent | 76-89% | 2 | 275 | 170 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 95 | 73 | +32 | 43 | 3 | +40 | +42.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 354 | 71 | +71 | 71 | 0 | +71 | +20.0 |
| Opponent | No odds | 3 | 35 | 170 | +37 | 81 | 27 | +54 | +156.8 |
| Opponent | All fights | 20 | 264 | 170 | +108 | 124 | 32 | +91 | +34.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h7-opp-dcce224-p4 | move | 46 | 11 (24%) | 9 (20%) | 5 (11%) | 30 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Ring of Doom | Mine | L0216, L0232 |
| Ring of Doom | Opponent | L0115, L0333 |

# Doctrine scorecard: h7-mine-dcce224-p3

### Scorecard: h7-mine-dcce224-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | yes | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | no | 6 | 4 | 2 | 0 | 0 | 0 | 0 | 165 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | 3 | 1 | 4 | 1 | 0 | 0 | 255 |
| L0211 | 1 | 1 | Opponent | yes | 17 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 11 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Opponent | no | 7 | 2 | 2 | 0 | 1 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 10 | - | 1 | 0 | 0 | 0 | 0 | 310 |
| L0330 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 310 |
| L0415 | 1 | 1 | Opponent | no | 20 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 138 |
| L0518 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0534 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 180 |
| L0534 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0621 | 3 | 1 | Mine | no | 1 | - | 2 | 3 | 0 | 0 | 0 | 246 |
| L0621 | 3 | 1 | Opponent | no | 1 | - | 1 | 6 | 0 | 0 | 0 | 500 |
| L0710 | 2 | 1 | Mine | - | - | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0710 | 2 | 1 | Opponent | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 369 |
| **Average** | | | Mine | 11% | 3.4 | 2.8 | 1.4 | 1.8 | 0.1 | 0.0 | 0.0 | 134.1 |
| **Average** | | | Opponent | 11% | 8.4 | 2.5 | 1.4 | 1.5 | 0.2 | 0.0 | 0.0 | 120.3 |

### KPIs: h7-mine-dcce224-p3

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE.

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 39% (22 of 56) | 9% (5 of 58) | 24% (27 of 114) |
| Winner chose to follow up after the loser gave ground |  | 67% (6 of 9); on the table 78% | 88% (7 of 8); on the table 88% | 76% (13 of 17); on the table 82% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (4 of 4); on the table 100% | 100% (6 of 6); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fled |  | 80% (8 of 10); on the table 80% | 67% (4 of 6); on the table 67% | 75% (12 of 16); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 78% (18 of 23); on the table 83% | 85% (17 of 20); on the table 85% | 81% (35 of 43); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 54% (74 of 138) | 34% (33 of 96) | 46% (107 of 234) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (74 of 130) | 49% (33 of 68) | 54% (107 of 198) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (5 of 8) | 33% (4 of 12) | 45% (9 of 20) |
| Points that never fought | lower | 58% (13592 of 23563) | 54% (13033 of 23993) | 56% (26625 of 47556) |
|   infantry points that never fought | lower | 63% (4155 of 6634) | 66% (2255 of 3402) | 64% (6410 of 10036) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (52 of 88) | 54% (50 of 93) | 56% (102 of 181) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.8 uses a game | 91% (10 of 11); 3.4 uses a game | 94% (16 of 17); 2.6 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 0.4 uses a game | 33% (1 of 3); 0.1 uses a game | 50% (3 of 6); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 78% (7 of 9); 0.6 uses a game | 33% (2 of 6); 0.2 uses a game | 60% (9 of 15); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (10467 of 18062) | 50% (10954 of 21888) | 54% (21421 of 39950) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.8 (53%) | 0.8 (16%) | 3.7 (35%) |
| MARCHED: its unit marched | 1.5 (28%) | 1.3 (25%) | 2.8 (27%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (3%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.4 (8%) | 0.8 (16%) | 1.2 (12%) |
| REAR RANK: in a rear rank | 0.3 (6%) | 0.2 (5%) | 0.6 (6%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (3%) | 0.2 (2%) |
| GONE: slain | 0.2 (5%) | 1.3 (25%) | 1.6 (15%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.2 | 1.9 | 1.8 | 8.9 | 0.4 | 1.3 |
| not cast | 2.8 | 5.3 | 2.8 | 10.6 | 1.6 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.9 (36%) | 0.0 (0%) | 3.7 (35%) | 0.3 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.8 (27%) | 0.2 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.2 (11%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (15%) | 0.1 (2%) | 0.0 (0%) | 1.2 (12%) | 0.2 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.0 (19%) | 0.0 (0%) | 0.6 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.2 (6%) | 0.5 (9%) | 1.0 (36%) | 1.6 (15%) | 0.5 (32%) | 2.5 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.4 (8%) | 0.0 (0%) | 0.0 (0%) | 0.2 (11%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (74%) | 1.2 (23%) | 1.7 (61%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.8 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.6 a game | 1.0 a game |
| stood (cast and not dispelled) | 56% (10 of 18) | 0% (0 of 1) | 53% (10 of 19) |
| the unit moved after it | 70% (7 of 10) | - | 70% (7 of 10) |
| it charged on its next turn | 0% (0 of 10) | - | 0% (0 of 10) |
| the enemy charged it first | 10% (1 of 10) | - | 10% (1 of 10) |
| it fought by the end of its next turn | 10% (1 of 10) | - | 10% (1 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | 10% (1 of 10) | - | 10% (1 of 10) |
| none of these (no charge, no fight, no charge escaped) | 80% (8 of 10) | - | 80% (8 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (216 of 347) | 55% (118 of 214) | 60% (334 of 561) |
|   cavalry | 57% (12 of 21) | 67% (14 of 21) | 62% (26 of 42) |
|   character | 74% (35 of 47) | 36% (15 of 42) | 56% (50 of 89) |
|   chariot | 40% (16 of 40) | 56% (15 of 27) | 46% (31 of 67) |
|   infantry | 51% (39 of 76) | 58% (39 of 67) | 55% (78 of 143) |
|   monster | 50% (3 of 6) | 36% (4 of 11) | 41% (7 of 17) |
|   war machine | 71% (111 of 157) | 67% (31 of 46) | 70% (142 of 203) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (24%) | 2.6 (32%) | 5.2 (27%) |
| CHARGED: it charged | 0.7 (6%) | 1.2 (16%) | 1.9 (10%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (9%) | 0.2 (2%) | 1.2 (6%) |
| MOVED: a war machine that moved | 2.2 (20%) | 0.9 (11%) | 3.1 (16%) |
| NO TARGET IN RANGE | 1.8 (16%) | 1.2 (15%) | 2.9 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (15%) | 0.9 (11%) | 2.5 (13%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.7 (8%) | 1.0 (5%) |
| OTHER BAR | 0.5 (5%) | 0.2 (2%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.1 | 0.8 | 78% | 5.9 pts | 18 pts |
| character | 4.8 | 2.7 | 71% | 9.5 pts | 46 pts |
| chariot | 2.6 | 1.8 | 61% | 13.9 pts | 36 pts |
| infantry | 11.0 | 3.6 | 76% | 6.7 pts | 74 pts |
| monster | 0.6 | 0.3 | 57% | 17.8 pts | 10 pts |
| war machine | 11.8 | 12.4 | 55% | 29.8 pts | 352 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 3.2 | 2.8 |
| Charges that made contact a game | 2.1 | 2.2 | 2.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (6 units) | 1.00 declared, 0.78 contact (9 units) | 0.73 declared, 0.60 contact (15 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.29 contact (78 units) | 0.35 declared, 0.23 contact (83 units) | 0.34 declared, 0.26 contact (161 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 39% (7 of 18) | 0% (0 of 1) | 14% (1 of 7) | 31% (8 of 26) |
| Character in a unit | 91% (21 of 23) | 82% (14 of 17) | 50% (1 of 2) | 86% (36 of 42) |
| Character on its own | 33% (1 of 3) | 67% (6 of 9) | 47% (7 of 15) | 52% (14 of 27) |
| Chariot | 88% (7 of 8) | 75% (6 of 8) | - | 81% (13 of 16) |
| Infantry | 24% (5 of 21) | 40% (6 of 15) | - | 31% (11 of 36) |
| Monster | 60% (3 of 5) | 33% (1 of 3) | - | 50% (4 of 8) |
| Monstrous | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| War Machines | 58% (11 of 19) | 50% (1 of 2) | - | 57% (12 of 21) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (1 of 1); on the table 100% | 56% (57 of 102) | 77% | 73% (16 of 22) | 100% (6 of 6); 5.2 uses a game | 50% (1 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 83% (10 of 12); on the table 83% | 47% (17 of 36) | 45% | 47% (15 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 67% (6 of 9); on the table 78% | - | 49% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | 100% (1 of 1); on the table 100% | - | 61% | 70% (7 of 10) | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Grand Cathay | 3 | 100% (3 of 3); on the table 100% | 33% (22 of 66) | 55% | 54% (14 of 26) | 83% (5 of 6); 6.3 uses a game | 100% (1 of 1); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 2 | 67% (4 of 6); on the table 67% | 0% (0 of 6) | 34% | 40% (6 of 15) | 100% (3 of 3); 8.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 98% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 77% | 78% (7 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 4 | 83% (5 of 6); on the table 83% | 75% (9 of 12) | 46% | 54% (15 of 28) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 1 | 100% (4 of 4); on the table 100% | - | 59% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h7-mine-dcce224-p3, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 35% (6) | 36% (5) | 35% (11) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.25 | 0.17 | 0.42 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.25 | 0.08 | 0.33 |

### Quality by phase: h7-mine-dcce224-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 79% (19 of 24) | 67% (22 of 33) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (75 of 196) | 45% (30 of 66) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 83% (5 of 6) |
| Strategy | Joined characters whose unit fought | 29% (11 of 38) | 33% (6 of 18) |
| Strategy | Lone characters that fought | 47% (8 of 17) | 74% (14 of 19) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.8 | 1.5 |
| Movement | Points that never moved of their own | 134.1 | 120.3 |
| Movement | Fights charged into per game | 1.8 | 2.2 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 20, net -17 | 1 of 23, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 20, net +198 | 4 of 23, net +32 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 20 | 5 of 23, net +38 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 20, net +75 | 6 of 23, net +193 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 8.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (37 of 108) | 40% (40 of 101) |
| Shooting | Points destroyed by shooting units | 70.3 | 9.8 |
| Shooting | War machine shots | 9.2 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (48 of 111) | 61% (19 of 31) |
| Shooting | Points destroyed by war machines | 157.0 | 62.9 |
| Magic | Magic missiles cast | 2.4 | 1.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 55% (16 of 29) | 39% (9 of 23) |
| Magic | Wounds caused by magic missiles | 4.8 | 3.6 |
| Magic | Wounds caused by other spells | 0.6 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 67.2 | 55.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.1 / 0.8 / 0.2 | 0.7 / 0.9 / 0.2 / 0.0 |
| Combat | Points destroyed in combat | 102.4 | 261.7 |
| Combat | Points run down | 68.8 | 14.3 |
| Combat | Net points per charged fight, damage counted | +67 | +76 |
| Combat | Net per 100 charger points, damage counted | +30.0 | +26.2 |
| Combat | First round won (charged fights) | 62% | 77% |
| Combat | Net points per charged fight | +64 | +94 |
| Combat | Net points per supported fight / lone fight | +146 / +55 | - / +94 |
| Combat | Charged fights on a top-3 enemy unit | 7 of 21 | 9 of 26 |
| Game | Points lost | 432.5 | 516.1 |
| Game | VP from objectives | 545.0 | 826.7 |
| Game | Lone holders (player turns) | 3.4 | 8.4 |

- Mine won / drew / lost: 2 / 4 / 6 of 12 ended games (of 12); mean margin (Mine - Opponent) -218 VP
- The side that went first won 4 of 8 games with a winner
- Points traded per game (both sides' losses): 949
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h7-mine-dcce224-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +60.8 | 0.0 | 25.8 | 0.2 | +30.4 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.5 | +0.0 | 0.0 | 7.9 | 0.7 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.3 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | -42.1 | 11.4 | 0.0 | 0.1 | -1.4 | 4.3 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.1 | -21.1 | 24.1 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.2 | +7.1 | 0.0 | 12.5 |
| CANNON PLAN MISSED | 2.0 | +0.0 | 126.0 | 25.4 | 0.7 | +0.0 | 6.4 | 0.0 |
| CANNON PLANNED TARGET | 8.5 | +206.7 | 482.5 | 35.8 | 1.8 | +38.0 | 89.2 | 0.0 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 36.8 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.9 | +16.1 | 73.9 | 7.1 | 0.6 | +6.6 | 4.6 | 16.6 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +39.3 | 30.8 | 0.0 | 0.2 | +0.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 32.9 |
| CHAFF IN THE MOVE | 0.8 | +27.7 | 0.0 | 18.8 | 0.9 | +32.8 | 0.0 | 19.3 |
| CHAFF PASSED | 0.3 | -1.9 | 0.0 | 9.6 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.1 | -199.5 | 0.0 | 211.8 | 5.8 | -238.7 | 0.0 | 123.2 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 28.1 | 0.0 | 0.7 | +0.0 | 76.1 | 8.2 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 25.6 | 0.0 | 1.5 | +0.0 | 187.0 | 49.5 |
| CHEAP HELPER | 0.2 | +0.0 | 7.7 | 0.0 | - | - | - | - |
| CHEAPEST HOLDER | - | - | - | - | 0.3 | -44.0 | 7.6 | 8.2 |
| COMBAT PIVOT | 0.2 | +0.0 | 11.2 | 25.8 | 0.3 | +0.0 | 15.5 | 19.2 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.2 | +174.1 | 63.3 | 63.3 | 0.1 | +3.1 | 0.0 | 0.0 |
| COVER ONCE | 5.6 | -422.5 | 0.0 | 56.7 | 4.4 | -221.0 | 0.0 | 102.8 |
| DEFENSIVE FLOOR | 0.1 | -6.3 | 0.0 | 6.8 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | +62.3 | 0.0 | 12.5 | 7.2 | +24.2 | 0.0 | 12.1 |
| EDGE GIVE GROUND | 0.1 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +1.5 | 31.1 | 7.1 | 2.2 | +1.6 | 215.0 | 56.5 |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 7.1 | 0.2 | +0.0 | 0.0 | 2.2 |
| FALLS SHORT | 4.7 | +91.4 | 0.0 | 116.1 | 16.8 | +317.8 | 0.0 | 207.8 |
| FEATURE BUFFS | 2.3 | +80.7 | 0.0 | 19.8 | 1.1 | +18.3 | 0.0 | 0.0 |
| FIGHT LIFT | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.8 | +42.3 | 40.2 | 0.0 | 1.1 | +165.4 | 135.3 | 40.8 |
| FIRE IN ORDER | 0.4 | +0.0 | 8.3 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 47.9 | +2912.1 | 876.3 | 521.7 | 39.8 | +3013.2 | 461.4 | 636.2 |
| FLANK NOT WEIGHED | 4.2 | +0.0 | 0.0 | 45.4 | 4.4 | +0.0 | 0.0 | 93.9 |
| FOLLOW UP WEIGHED | 0.4 | +108.6 | 0.0 | 15.5 | 0.8 | +189.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +211.1 | 89.9 | 20.9 | 2.7 | +484.9 | 251.6 | 56.5 |
| FRIEND CHARGES FIRST | 0.2 | -5.2 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.4 | -8.7 | 0.0 | 15.8 | 0.4 | -16.8 | 0.0 | 67.6 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.2 | +29.2 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -5.8 | 2.5 | 0.0 | 0.1 | -1.0 | 0.0 | 0.0 |
| GUN FIGURES | 1.2 | +9.2 | 21.7 | 35.4 | 0.1 | +4.6 | 5.4 | 0.0 |
| GUN MASK | 0.5 | +9.1 | 0.0 | 18.3 | 1.1 | +8.7 | 0.0 | 15.4 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 25.8 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.4 | +0.0 | 0.0 | 57.2 | 2.8 | +0.0 | 0.0 | 92.3 |
| HIS CHARGE DENIED | 0.1 | +3.9 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.9 | +0.0 | 0.0 | 6.4 | 2.5 | +0.0 | 0.0 | 34.5 |
| HIS LEGAL MOVES | 3.1 | +0.0 | 0.0 | 47.4 | 3.3 | +0.0 | 0.0 | 33.3 |
| HIS MOVE AND SHOT | 3.2 | -33.4 | 0.0 | 63.2 | 1.1 | -20.4 | 0.0 | 29.9 |
| HIS ONE QUARTER | 1.2 | +0.0 | 0.0 | 4.3 | - | - | - | - |
| HIS RANDOM MOVE | 1.6 | +0.0 | 0.0 | 25.8 | 1.1 | +0.0 | 0.0 | 50.8 |
| HIS SHOT LIST | 18.9 | +649.5 | 0.0 | 220.8 | 22.8 | +1466.8 | 0.0 | 426.0 |
| HIS TURN DENIED | 0.7 | +20.3 | 42.6 | 0.0 | 1.6 | +64.8 | 210.2 | 12.6 |
| HOLD ODDS | 12.5 | +0.0 | 0.0 | 76.8 | - | - | - | - |
| HOLDER ASSIGNMENT | 13.6 | +1468.7 | 0.0 | 89.9 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.4 | +212.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.5 | -41.4 | 89.9 | 0.0 | 2.4 | -91.9 | 243.7 | 41.3 |
| HUNT IN PAIRS | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| IDLE COST | 3.6 | -35.3 | 0.0 | 99.4 | 11.1 | -178.0 | 0.0 | 259.1 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -2.9 | 0.0 | 0.0 |
| KEEP FALLS | 0.2 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +15.4 | 0.0 | 0.0 | 0.7 | +24.1 | 0.0 | 67.6 |
| LEGAL CHARGES ONLY | 4.9 | +0.0 | 154.0 | 213.2 | 2.5 | +0.0 | 110.2 | 130.0 |
| LONE WIZARD KEPT IN | 0.8 | +70.6 | 0.0 | 0.0 | 0.2 | +32.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.9 | 0.0 | 6.8 | 0.1 | +0.1 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.2 | -35.9 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.5 | +9.8 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 24.8 |
| MANOEUVRE | 1.2 | +8.0 | 0.0 | 0.0 | 0.8 | +9.7 | 0.0 | 11.4 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +13.9 | 0.0 | 0.0 | 0.8 | +20.2 | 0.0 | 19.4 |
| MARCH CHECK | 0.8 | +57.5 | 0.0 | 0.0 | 2.6 | +157.3 | 0.0 | 19.4 |
| MARCH OVER CASTS | 0.5 | +2.8 | 0.0 | 0.0 | 0.8 | -8.9 | 0.0 | 36.0 |
| MAX FOR POSITIONING | 5.0 | +80.4 | 0.0 | 23.8 | 5.0 | +57.6 | 0.0 | 125.3 |
| MISSILES IN THE MOVE | 5.1 | +247.9 | 0.0 | 13.8 | 5.8 | +81.4 | 0.0 | 63.9 |
| MISSILES NEXT TURN | 4.8 | +172.4 | 0.0 | 13.8 | 6.6 | +58.1 | 0.0 | 133.4 |
| MODEL FACING | 0.6 | +153.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -92.0 | 0.0 | 63.3 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.9 | +273.7 | 0.0 | 63.2 | 3.6 | +607.4 | 0.0 | 139.8 |
| MOVES UNITS SPELL | 0.2 | +9.2 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.5 | +289.8 | 0.0 | 46.4 | 2.7 | +169.2 | 0.0 | 12.2 |
| NEXT CHARGE BY LIST | 5.5 | -120.0 | 0.0 | 110.0 | 4.7 | -203.7 | 0.0 | 177.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 7.2 | -359.9 | 0.0 | 79.6 |
| NO DOUBLE ROUNDS | 1.9 | -81.4 | 73.3 | 20.9 | 2.4 | -157.4 | 245.5 | 48.9 |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 7.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.8 | -1.1 | 0.0 | 0.0 | 0.5 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 0.2 | -4.3 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 4.6 |
| ONE CHARGE A CHARGER | 2.3 | +0.0 | 0.0 | 41.6 | 1.2 | +0.0 | 0.0 | 47.8 |
| ONE FIGHT FORMULA | 5.1 | -91.9 | 0.0 | 111.6 | 3.8 | -103.1 | 0.0 | 132.8 |
| ONE OBJECTIVE FORMULA | 6.8 | +197.6 | 0.0 | 59.7 | 4.4 | -121.9 | 0.0 | 84.9 |
| ONE TARGET A SHOOTER | 16.9 | +338.9 | 0.0 | 154.3 | 18.5 | +625.8 | 0.0 | 291.3 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.1 | 15.8 | 0.0 |
| OPENS UP | 0.1 | +5.6 | 2.5 | 0.0 | 0.2 | +11.6 | 15.8 | 0.0 |
| OVERRUNS AWAY | 0.2 | +30.1 | 14.8 | 0.0 | 0.4 | +9.6 | 59.6 | 12.6 |
| PATHS CROSS | 3.2 | +240.2 | 0.0 | 21.4 | 4.2 | +158.7 | 0.0 | 37.9 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -9.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 42.4 | +1028.0 | 417.6 | 717.4 | 35.6 | +404.9 | 341.2 | 737.8 |
| QUARTER ODDS | 5.4 | +547.2 | 24.2 | 23.5 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +25.3 | 0.0 | 42.5 | 1.0 | +2.9 | 0.0 | 64.6 |
| REAL GROUND | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.6 | -23.1 | 0.0 | 18.8 | 0.7 | -21.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.1 | +206.0 | 0.0 | 0.0 | 3.1 | +73.4 | 0.0 | 85.0 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -1.4 | 4.3 | 0.0 |
| REFORMS TO MEET IT | 0.8 | -33.7 | 0.0 | 15.8 | 1.0 | -50.1 | 0.0 | 36.4 |
| RESERVE FALL BACK | 0.2 | +5.8 | 0.0 | 0.0 | 0.2 | +9.3 | 0.0 | 0.0 |
| RISK BY ARC | 1.6 | +32.1 | 65.7 | 13.8 | 1.8 | -26.0 | 172.3 | 51.5 |
| RISK BY HIS FIGURE | 10.8 | -128.0 | 0.0 | 151.6 | 10.6 | -141.6 | 0.0 | 273.7 |
| RUN DOWN | 1.6 | -16.4 | 75.8 | 0.0 | 1.7 | -11.8 | 82.6 | 48.9 |
| SAME CHARGE LATER | 0.1 | -0.3 | 0.0 | 0.0 | 0.1 | -0.9 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +2.0 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -47.6 | 0.0 | 11.4 |
| SEARCH SPOT | 4.5 | +161.3 | 0.0 | 50.3 | 6.5 | +241.7 | 0.0 | 151.9 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | +88.1 | 0.0 | 65.8 |
| SET UP TOGETHER | 0.7 | +10.5 | 0.0 | 0.0 | 0.4 | +0.6 | 0.0 | 24.8 |
| SET-UP ANY TARGET | 0.1 | +13.1 | 31.7 | 31.7 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +1.0 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +47.9 | 0.0 | 0.0 | 0.8 | +9.3 | 37.8 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.2 | -1.7 | 12.5 | 0.0 |
| SHOT RISK POINTS | 10.0 | +74.1 | 0.0 | 203.5 | 12.2 | -104.9 | 0.0 | 292.9 |
| SHOTS IN THE MOVE | 18.2 | +810.1 | 0.0 | 255.0 | 11.8 | +280.4 | 0.0 | 116.8 |
| SPELL SETS UP CHARGE | 0.5 | +330.5 | 31.7 | 31.7 | - | - | - | - |
| SPELL WORTH | 0.2 | +5.8 | 0.0 | 0.0 | 0.8 | +18.1 | 66.7 | 66.7 |
| SPELLS IN THE FIGHT | 0.3 | +1.4 | 16.2 | 0.0 | 0.2 | -2.1 | 6.4 | 0.0 |
| STAND AND SHOOT | 0.3 | -2.4 | 12.2 | 0.0 | 0.6 | -6.0 | 65.3 | 5.0 |
| STANDS FOR A REASON | - | - | - | - | 0.9 | +0.0 | 30.2 | 33.3 |
| STANDS STILL | 23.7 | +0.0 | 786.4 | 257.7 | 7.9 | +0.0 | 203.8 | 94.2 |
| STAY WORTH | 25.9 | +155.6 | 614.1 | 123.1 | 13.1 | +84.7 | 127.9 | 142.8 |
| SUPPORT NARROWED | 0.3 | +0.0 | 14.8 | 0.0 | 0.7 | +0.0 | 43.8 | 24.8 |
| SURE REACH TOGETHER | 0.1 | +2.4 | 0.0 | 0.0 | 1.0 | +15.7 | 0.0 | 24.8 |
| THE DEARER SUM KEEPS ITS PLAN | 3.6 | +0.0 | 0.0 | 21.4 | 4.4 | +0.0 | 0.0 | 37.9 |
| THE PROMISE ADDS | 0.1 | -0.9 | 0.0 | 0.0 | 0.1 | -16.8 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.8 | +0.0 | 0.0 | 7.6 | 0.2 | +0.0 | 0.0 | 30.8 |
| TIED UP BY THE SUM | 0.3 | +22.6 | 17.3 | 0.0 | 0.5 | +53.1 | 15.8 | 0.0 |
| TIME ON OUR SIDE | 27.1 | +472.5 | 7.6 | 190.2 | 5.6 | +111.6 | 0.0 | 75.8 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 24.5 |
| WAR ENGINE JOBS | 0.2 | +0.0 | 21.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.5 | +79.1 | 0.0 | 25.8 | 0.1 | +6.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +5.9 | 0.0 | 0.0 | 0.2 | +4.9 | 0.0 | 7.6 |
| WHOLE FIGHT GAIN | 0.2 | +7.3 | 24.2 | 0.0 | 0.2 | +1.8 | 6.1 | 0.0 |
| WIDER SPREAD | 1.3 | -1.3 | 78.5 | 0.0 | 2.1 | -7.6 | 204.2 | 48.3 |
| WOUNDS ON THE RANKS | 1.6 | +72.6 | 0.0 | 0.0 | 1.4 | +45.3 | 0.0 | 0.0 |

### Rule changes: h7-mine-dcce224-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 500 | 500 | 162 | 13.50 | +4420 | +27.3 |
| HOLDER ASSIGNMENT | 163 | 163 | 152 | 12.67 | +9393 | +61.8 |
| SEARCH SPOT | 132 | 132 | 120 | 10.00 | +4883 | +40.7 |
| ONE TARGET A SHOOTER | 425 | 425 | 111 | 9.25 | +1205 | +10.9 |
| DEPLOY BY FIGURES | 187 | 187 | 107 | 8.92 | +1437 | +13.4 |
| LEGAL CHARGES ONLY | 89 | 89 | 89 | 7.42 | +0 | +0.0 |
| PATHS CROSS | 88 | 88 | 88 | 7.33 | +4787 | +54.4 |
| TIME ON OUR SIDE | 392 | 354 | 77 | 6.42 | +327 | +4.2 |
| FIVE ACTION | 1053 | 1053 | 73 | 6.08 | +4033 | +55.2 |
| MOVE TO CHARGE COMPUTED | 78 | 78 | 48 | 4.00 | +3954 | +82.4 |
| SHOT RISK POINTS | 266 | 266 | 47 | 3.92 | +1758 | +37.4 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 3.17 | +0 | +0.0 |
| FOUR ROUNDS | 56 | 56 | 32 | 2.67 | +2914 | +91.1 |
| IDLE COST | 176 | 152 | 29 | 2.42 | +276 | +9.5 |
| MARCH CHECK | 40 | 40 | 29 | 2.42 | +658 | +22.7 |
| CANNON PLANNED TARGET | 124 | 124 | 27 | 2.25 | -259 | -9.6 |
| CANNON SIGHT KEPT | 25 | 25 | 25 | 2.08 | +0 | +0.0 |
| MAX FOR POSITIONING | 120 | 120 | 23 | 1.92 | +64 | +2.8 |
| REDIRECT COUNTER | 62 | 52 | 23 | 1.92 | +1543 | +67.1 |
| SHOTS IN THE MOVE | 359 | 325 | 22 | 1.83 | +459 | +20.9 |
| COVER ONCE | 120 | 99 | 20 | 1.67 | +295 | +14.7 |
| HARD STAY DROPPED | 20 | 20 | 20 | 1.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 25 | 25 | 16 | 1.33 | +182 | +11.4 |
| CHARGE LOSSES | 143 | 143 | 15 | 1.25 | +992 | +66.1 |
| FOLLOW UP WEIGHED | 15 | 15 | 15 | 1.25 | +3582 | +238.8 |
| MISSILES IN THE MOVE | 130 | 104 | 15 | 1.25 | +433 | +28.9 |
| RISK BY ARC | 40 | 40 | 15 | 1.25 | +253 | +16.9 |
| CHAFF IN THE MOVE | 21 | 19 | 14 | 1.17 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.08 | +1236 | +95.0 |
| ONE OBJECTIVE FORMULA | 135 | 115 | 13 | 1.08 | +867 | +66.7 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 1.00 | +0 | +0.0 |
| CHARGE NOT DECLARED | 12 | 12 | 12 | 1.00 | -2485 | -207.1 |
| LANE BY FIGURES | 12 | 12 | 12 | 1.00 | +474 | +39.5 |
| MARCH BY THE SUM | 12 | 12 | 12 | 1.00 | +409 | +34.1 |
| NEARER NOT NEEDED | 110 | 104 | 12 | 1.00 | +351 | +29.3 |
| NEXT OBJECTIVE NEARER | 87 | 87 | 11 | 0.92 | +346 | +31.5 |
| FEATURE BUFFS | 41 | 41 | 10 | 0.83 | +199 | +19.9 |
| HOLDER AT DEPLOYMENT | 17 | 17 | 10 | 0.83 | +279 | +27.9 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.83 | +0 | +0.0 |
| RISK BY HIS FIGURE | 257 | 257 | 10 | 0.83 | +760 | +76.0 |
| TIED UP BY THE SUM | 10 | 10 | 10 | 0.83 | +332 | +33.2 |
| CAST JOB | 18 | 18 | 9 | 0.75 | +29 | +3.2 |
| MANOEUVRE | 25 | 25 | 9 | 0.75 | +279 | +31.0 |
| NEXT CHARGE BY LIST | 122 | 122 | 9 | 0.75 | +202 | +22.4 |
| QUARTER ODDS | 65 | 65 | 9 | 0.75 | +834 | +92.7 |
| RANDOM MOVE BY FIGURES | 20 | 20 | 9 | 0.75 | +339 | +37.6 |
| STAY WORTH | 468 | 444 | 9 | 0.75 | +56 | +6.2 |
| FIGHT TO THE END | 23 | 23 | 8 | 0.67 | +1068 | +133.5 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.67 | +14 | +1.8 |
| WOUNDS ON THE RANKS | 36 | 36 | 8 | 0.67 | +307 | +38.4 |
| COMBAT PIVOT | 7 | 7 | 7 | 0.58 | +0 | +0.0 |
| HIS TURN DENIED | 27 | 27 | 7 | 0.58 | +116 | +16.6 |
| MODEL FACING | 7 | 7 | 7 | 0.58 | +1839 | +262.8 |
| SCOUT WAITS | 7 | 7 | 7 | 0.58 | +0 | +0.0 |
| WHO HITS BACK | 7 | 7 | 7 | 0.58 | +782 | +111.8 |
| CASTING BLOCK | 9 | 9 | 6 | 0.50 | +62 | +10.4 |
| CHARGE NOW FIRST | 26 | 26 | 6 | 0.50 | -166 | -27.7 |
| FALLS SHORT | 257 | 225 | 6 | 0.50 | +78 | +13.0 |
| FIRE IN ORDER | 6 | 6 | 6 | 0.50 | +0 | +0.0 |
| SURE REACH TOGETHER | 13 | 13 | 6 | 0.50 | +23 | +3.8 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 0.42 | +0 | +0.0 |
| CHAFF PASSED | 5 | 5 | 5 | 0.42 | -24 | -4.8 |
| RESERVE FALL BACK | 5 | 5 | 5 | 0.42 | +181 | +36.2 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 0.33 | +1094 | +273.6 |
| ONE FIGHT FORMULA | 106 | 69 | 4 | 0.33 | +36 | +8.9 |
| BOMBING RUN | 3 | 3 | 3 | 0.25 | +85 | +28.3 |
| GUN MASK | 19 | 19 | 3 | 0.25 | +71 | +23.8 |
| KEEP FALLS | 3 | 3 | 3 | 0.25 | +75 | +25.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.25 | +118 | +39.2 |
| OFF BEST | 3 | 3 | 3 | 0.25 | -67 | -22.2 |
| OVERRUNS AWAY | 8 | 8 | 3 | 0.25 | +55 | +18.2 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.17 | -536 | -267.8 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.17 | +350 | +175.2 |
| HIS MOVE AND SHOT | 51 | 51 | 2 | 0.17 | +5 | +2.6 |
| NO DOUBLE ROUNDS | 52 | 52 | 2 | 0.17 | +66 | +32.8 |
| OPENS UP | 3 | 3 | 2 | 0.17 | +80 | +39.9 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.17 | +107 | +53.5 |
| SUPPORT NARROWED | 12 | 12 | 2 | 0.17 | -9 | -4.7 |
| WHOLE FIGHT GAIN | 4 | 4 | 2 | 0.17 | +4 | +2.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| HONEST WORTH | 47 | 47 | 1 | 0.08 | +2 | +1.6 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +58 | +58.3 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.08 | -115 | -115.1 |
| REFORMS TO MEET IT | 22 | 22 | 1 | 0.08 | +8 | +8.3 |
| SAME CHARGE LATER | 2 | 2 | 1 | 0.08 | +0 | +0.0 |
| SET UP TOGETHER | 13 | 9 | 1 | 0.08 | +36 | +36.1 |
| THE PROMISE ADDS | 2 | 2 | 1 | 0.08 | +2 | +2.4 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 32 | 32 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 12 | trace | - | - | - | - |
| CHARACTER GUNS | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 4 | 4 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 43 | 43 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 103 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 10 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 63 | 63 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 53 | 53 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 77 | 77 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 32 | 32 | 0 | 0.00 | - | - |
| HOLD ODDS | 150 | 150 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | not checked | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 16 | 16 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 136 | 103 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 16 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 43 | 43 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 936 | trace | - | - | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 15 | 15 | 0 | 0.00 | - | - |
| RUN DOWN | 39 | 39 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 11 | 11 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 379 | 379 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 96 | not checked | - | - | - | - |
| THE PROMISED MOVE | 12 | not checked | - | - | - | - |
| WAITS AGAIN | 25 | 25 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WIDER SPREAD | 41 | 41 | 0 | 0.00 | - | - |

### Off best figure: h7-mine-dcce224-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.33 | 0.67 | 207.1 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 20.7 |
| PATHS CROSS | rule | 0.17 | 0.58 | 35.8 |
| CANNON PLANNED TARGET | rule | 0.50 | - | 54.9 |
| CHARGE NOW FIRST | rule | 0.17 | 0.33 | 27.7 |
| CHAFF PASSED | rule | 0.17 | 0.08 | 8.0 |
| JOB FIRST | gate | 0.17 | 0.08 | 22.2 |
| BEST PRIZE | rule | 0.08 | 0.08 | 267.8 |
| SUPPORT NARROWED | rule | - | 0.17 | 4.7 |
| DEPLOY BY FIGURES | rule | - | 0.08 | 4.7 |
| PIVOT GUARDS FLANK | rule | 0.08 | - | 115.1 |
| REDIRECT WEIGHED | rule | - | 0.08 | 31.0 |

### Plans: h7-mine-dcce224-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.6 | 63% | 186 | 123 | 66% |
| Mine | join | 0.2 | 100% | 9 | 0 | 0% |
| Mine | move | 26.4 | 95% | 1690 | 0 | 0% |
| Mine | shoot | 13.6 | 64% | 626 | 905 | 144% |
| Mine | support | 0.6 | 86% | 4 | 0 | 0% |
| Opponent | charge | 2.1 | 44% | 531 | 185 | 35% |
| Opponent | move | 28.0 | 93% | 1956 | 0 | 0% |
| Opponent | shoot | 4.2 | 53% | 151 | 220 | 146% |
| Opponent | support | 1.2 | 87% | 0 | 0 | - |

### Battle groups: h7-mine-dcce224-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 24% | 67% | 17% | 100% | 40% | 0% | 0% | 40% | 20% |
| Opponent | REDIRECT COUNTER | 3.1 | 24% | 67% | 11% | 0% | 0% | 0% | 38% | 62% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h7-mine-dcce224-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 35 (9) | 21 | 14 | 37 | 44% | 2.8 | 44 (4) | 63 (2) | 0 (3) | 39 (8) | 0 (1) |
| Mine | Character | 47 | 24 (47) | 24 | 0 | 9 | 30% | 2.1 | 11 (12) | 31 (30) | 0 (5) | 18 (32) | 38 (15) |
| Mine | Clean-up | 9 | 38 (9) | 3 | 35 | 36 | 56% | 2.8 | 38 (1) | 53 (5) | 0 (3) | 83 (4) | 0 (5) |
| Mine | Fast Hammer | 7 | 10 (7) | 0 | 10 | 55 | 43% | 4.0 | 20 (3) | 0 (1) | 0 (3) | 11 (6) | 0 (1) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 26 | 24 (26) | 10 | 14 | 30 | 35% | 2.4 | 10 (9) | 27 (14) | 82 (3) | 29 (18) | 15 (8) |
| Mine | Holder | 15 | 90 (15) | 40 | 50 | 31 | 47% | 3.5 | 122 (3) | 31 (4) | 107 (8) | 99 (13) | 19 (2) |
| Mine | Shooter | 10 | 74 (10) | 26 | 49 | 21 | 10% | 1.6 | 66 (3) | 86 (6) | 0 (1) | 74 (6) | 74 (4) |
| Mine | War machine | 27 | 70 (27) | 70 | 0 | 26 | 4% | 1.1 | 120 (8) | 67 (13) | 6 (6) | 127 (9) | 46 (18) |
| Mine | Wizard | 8 | 20 (8) | 20 | 0 | 11 | 38% | 4.8 | - | 20 (8) | - | 0 (2) | 27 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 21 | 99 (21) | 6 | 93 | 44 | 48% | 3.5 | 128 (5) | 97 (9) | 80 (7) | 112 (16) | 51 (5) |
| Opponent | Character | 34 | 30 (34) | 30 | 0 | 25 | 32% | 2.1 | 31 (10) | 31 (20) | 14 (4) | 17 (19) | 46 (15) |
| Opponent | Clean-up | 3 | 176 (3) | 35 | 141 | 0 | 0% | 2.3 | 70 (1) | 377 (1) | 91 (1) | 219 (2) | 91 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 20 | 58 (20) | 4 | 54 | 29 | 35% | 2.2 | 30 (4) | 64 (11) | 64 (5) | 77 (13) | 12 (7) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 45 | 50% | 1.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Hammer | 15 | 39 (15) | 26 | 13 | 43 | 27% | 2.5 | - | 59 (6) | 22 (9) | 28 (7) | 46 (8) |
| Opponent | Holder | 8 | 144 (8) | 10 | 134 | 14 | 50% | 4.2 | 151 (4) | 139 (4) | - | 221 (4) | 80 (4) |
| Opponent | Shooter | 10 | 87 (10) | 7 | 80 | 22 | 20% | 2.4 | 124 (3) | 91 (6) | 0 (1) | 88 (7) | 84 (3) |
| Opponent | War machine | 8 | 61 (8) | 61 | 0 | 15 | 0% | 1.4 | 115 (2) | 9 (5) | 155 (1) | - | 61 (8) |
| Opponent | Wizard | 3 | 16 (3) | 16 | 0 | 0 | 0% | 3.7 | 89 (1) | 0 (1) | 12 (1) | 16 (3) | - |

### Charged fights: h7-mine-dcce224-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 158 | 105 | 1.5 | 1.0 | 70 | 42 | +28 | 3 of 6 | 3 of 6 | - | +28 |
| Mine | Chaos Dwarfs | 4 | 398 | 259 | 2.2 | 1.2 | 115 | 14 | +101 | 4 of 9 | 6 of 9 | +199 | +89 |
| Mine | Dwarfen Mountain Holds | 3 | 315 | 31 | 1.3 | 1.5 | 23 | 0 | +23 | 0 of 4 | 3 of 4 | +92 | +0 |
| Mine | Empire of Man | 1 | 369 | 165 | 2.0 | 1.0 | 82 | 0 | +82 | 0 of 2 | 1 of 2 | - | +82 |
| **Mine** | all armies | 12 | 295 | 143 | 1.8 | 1.2 | 82 | 18 | +64 | 7 of 21 | 13 of 21 | +146 | +55 |
| Opponent | Grand Cathay | 3 | 423 | 109 | 2.3 | 1.0 | 47 | 0 | +47 | 1 of 7 | 7 of 7 | - | +47 |
| Opponent | High Elf Realms | 2 | 42 | 202 | 3.0 | 1.0 | 68 | 50 | +18 | 2 of 6 | 4 of 6 | - | +18 |
| Opponent | Ogre Kingdoms | 1 | 182 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Opponent | Skaven | 1 | 0 | 416 | 1.0 | 1.0 | 416 | 0 | +416 | 1 of 1 | 0 of 1 | - | +416 |
| Opponent | Warriors of Chaos | 4 | 0 | 283 | 1.8 | 1.0 | 162 | 20 | +142 | 3 of 7 | 6 of 7 | - | +142 |
| Opponent | Wood Elf Realms | 1 | 0 | 642 | 4.0 | 1.0 | 160 | 0 | +160 | 2 of 4 | 3 of 4 | - | +160 |
| **Opponent** | all armies | 12 | 128 | 244 | 2.2 | 1.0 | 112 | 18 | +94 | 9 of 26 | 20 of 26 | - | +94 |

### Effective charges: h7-mine-dcce224-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 4 (net -26) | 0 | 0 | 1 (net +233) | 0 | 1 (net +41) | 0 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 9 | 1 (net +0) | 0 | 1 (net +395) | 3 (net +15) | 0 | 3 (net +112) | 1 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 2 (net +46) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 2 | 1 (net +0) | 0 | 0 | 1 (net +165) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 7 | 0 | 0 | 0 | 2 (net +62) | 4 (net +19) | 1 (net +125) | 0 | 0% (0 of 7) |
| Opponent | High Elf Realms | 6 | 0 | 0 | 1 (net +0) | 2 (net +6) | 0 | 2 (net +48) | 1 | 20% (1 of 5) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +416) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 7 | 0 | 1 (net +91) | 1 (net -41) | 1 (net +310) | 1 (net +112) | 2 (net +261) | 1 | 17% (1 of 6) |
| Opponent | Wood Elf Realms | 4 | 1 (net +0) | 1 (net +474) | 2 (net +84) | 0 | 0 | 0 | 0 | 50% (2 of 4) |

### Charged fights, damage counted: h7-mine-dcce224-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 98 | 363 | -17 | 47 | 70 | -24 | -24.1 |
| Mine | Effective (55-75%) | 2 | 309 | 255 | +198 | 244 | 0 | +244 | +78.8 |
| Mine | 76-89% | 7 | 224 | 175 | +77 | 108 | 24 | +84 | +37.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 279 | 119 | +75 | 93 | 0 | +93 | +33.5 |
| Mine | No odds | 1 | 480 | 137 | +135 | 135 | 137 | -2 | -0.4 |
| Mine | All fights | 21 | 222 | 221 | +64 | 101 | 35 | +67 | +30.0 |
| Opponent | Long shot (under 50%) | 1 | 109 | 239 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 50-54% | 2 | 298 | 165 | +282 | 282 | 0 | +282 | +94.6 |
| Opponent | Effective (55-75%) | 4 | 173 | 84 | +32 | 45 | 20 | +24 | +14.2 |
| Opponent | 76-89% | 5 | 359 | 232 | +90 | 164 | 110 | +54 | +14.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 335 | 223 | +193 | 209 | 62 | +147 | +43.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 354 | 77 | +38 | 52 | 8 | +45 | +12.6 |
| Opponent | No odds | 3 | 176 | 99 | -11 | 0 | 24 | -24 | -13.6 |
| Opponent | All fights | 26 | 289 | 157 | +94 | 118 | 43 | +76 | +26.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h7-mine-dcce224-p3 | move | 78 | 21 (27%) | 20 (26%) | 9 (12%) | 48 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Charmed Shield | Opponent | L0534 |
| Elixir of Power | Opponent | L0111, L0211 |
| Fistful of Laurels | Opponent | L0518 |
| Periapt of Soul Exchange | Opponent | L0621 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211, L0415 |
| Ring of Jet | Opponent | L0111, L0211, L0710 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621 |
| Twice-Blessed Armour | Mine | L0710 |
| Twice-Blessed Armour | Opponent | L0710 |
| Witch Hunter's Ward | Mine | L0710 |

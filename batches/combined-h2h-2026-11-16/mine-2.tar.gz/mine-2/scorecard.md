# Doctrine scorecard: ch-h2h-mine-ea652ef-p2

### Scorecard: ch-h2h-mine-ea652ef-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 5 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 1194 |
| L0122 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 1 | 0 | 0 | 322 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 0 | 2 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | - | 0 | 6 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 11 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 6 | 2 | 0 | 2 | 2 | 0 | 0 | 785 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 6 | - | 1 | 1 | 0 | 0 | 0 | 564 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 2 | 5 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 2 | 2 | 0 | 0 | 0 | 1448 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 2 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 5 | - | 1 | 2 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | 5 | 2 | 2 | 2 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 798 |
| L0616 | 4 | 1 | Opponent | no | 4 | 3 | 2 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 4 | 3 | 0 | 0 | 0 | 0 | 993 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 2 | - | 0 | 4 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 707 |
| L0810 | 6 | 1 | Opponent | no | 13 | 3 | 1 | 1 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 4 | 0 | 1 | 0 | 0 | 0 | 881 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 9 | - | 2 | 1 | 0 | 0 | 0 | 185 |
| L0934 | 4 | 1 | Mine | no | 3 | 1 | 1 | 0 | 1 | 0 | 0 | 1025 |
| L0934 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 1 | 0 | 0 | 40 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 697 |
| L1135 | 1 | 1 | Opponent | yes | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 5 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 7 | 3 | 5 | 1 | 0 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 0 | 1 | 3 | 2 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | no | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 6 | 2 | 0 | 0 | 0 | 0 | 539 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 617 |
| L2029 | 1 | 1 | Opponent | no | 4 | 2 | 6 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 7 | - | 4 | 3 | 0 | 0 | 0 | 500 |
| L2131 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 2 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 3 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 2 | 3 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 27% | 1.9 | 2.9 | 1.8 | 1.2 | 0.4 | 0.0 | 0.0 | 369.6 |
| **Average** | | | Opponent | 27% | 3.5 | 2.3 | 2.8 | 1.7 | 0.3 | 0.0 | 0.0 | 155.0 |

### KPIs: ch-h2h-mine-ea652ef-p2

Rules off - Opponent only: CHARGE BAND, HONEST WORTH, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (42 of 169) | 14% (26 of 181) | 19% (68 of 350) |
| Winner chose to follow up after the loser gave ground |  | 97% (65 of 67); on the table 97% | 97% (58 of 60); on the table 97% | 97% (123 of 127); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 78% (7 of 9); on the table 89% | 71% (10 of 14); on the table 93% | 74% (17 of 23); on the table 91% |
| Winner chose to pursue after the loser fled |  | 67% (12 of 18); on the table 72% | 74% (23 of 31); on the table 77% | 71% (35 of 49); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 89% (84 of 94); on the table 91% | 87% (91 of 105); on the table 90% | 88% (175 of 199); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 28% (95 of 342) | 33% (51 of 156) | 29% (146 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (95 of 210) | 46% (51 of 110) | 46% (146 of 320) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 24% (36 of 150) | 15% (12 of 78) | 21% (48 of 228) |
|     round 1 |  | 20% (5 of 25) | 8% (1 of 13) | 16% (6 of 38) |
|     rounds 2+ |  | 25% (31 of 125) | 17% (11 of 65) | 22% (42 of 190) |
|   other wizards | 50%+ | 31% (59 of 192) | 50% (39 of 78) | 36% (98 of 270) |
|     round 1 |  | 41% (13 of 32) | 54% (7 of 13) | 44% (20 of 45) |
|     rounds 2+ |  | 29% (46 of 160) | 49% (32 of 65) | 35% (78 of 225) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 59% (17 of 29) | 56% (33 of 59) | 57% (50 of 88) |
| Points that never fought | lower | 31% (22326 of 71583) | 42% (30324 of 71989) | 37% (52650 of 143572) |
|   infantry points that never fought | lower | 40% (6493 of 16324) | 63% (8779 of 14029) | 50% (15272 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (167 of 284) | 59% (174 of 297) | 59% (341 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.6 uses a game | 78% (14 of 18); 1.1 uses a game | 87% (33 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 67% (12 of 18); 0.7 uses a game | 100% (2 of 2); 0.1 uses a game | 70% (14 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32607 of 60231) | 52% (32746 of 63281) | 53% (65353 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (23%) | 0.6 (21%) | 2.2 (22%) |
| MARCHED: its unit marched | 1.1 (15%) | 0.5 (18%) | 1.6 (16%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.2 (8%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.9 (27%) | 0.5 (18%) | 2.4 (24%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.4 (21%) | 0.6 (19%) | 2.0 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.2 (7%) | 0.5 (5%) |
| STUPIDITY: Stupidity | 0.3 (4%) | 0.1 (2%) | 0.4 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.2 (7%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.4 | 1.3 | 4.1 | 0.4 | 2.0 |
| not cast | 3.6 | 3.5 | 3.7 | 9.8 | 1.9 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.5 (43%) | 0.2 (7%) | 2.2 (22%) | 0.4 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (16%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.4 (12%) | 0.5 (13%) | 2.4 (24%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.2 (6%) | 0.2 (6%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.8 (21%) | 0.4 (13%) | 1.0 (26%) | 2.0 (20%) | 0.6 (30%) | 3.8 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.6 (18%) | 0.2 (5%) | 0.5 (5%) | 0.0 (0%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (2%) | 0.2 (6%) | 0.4 (4%) | 0.0 (0%) | 0.5 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.4 (19%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (54%) | 0.1 (3%) | 1.3 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.2 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 71% (12 of 17) | 77% (20 of 26) | 74% (32 of 43) |
| the unit moved after it | 83% (10 of 12) | 55% (11 of 20) | 66% (21 of 32) |
| it charged on its next turn | 0% (0 of 12) | 5% (1 of 20) | 3% (1 of 32) |
| the enemy charged it first | 17% (2 of 12) | 10% (2 of 20) | 12% (4 of 32) |
| it fought by the end of its next turn | 8% (1 of 12) | 0% (0 of 20) | 3% (1 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 17% (2 of 12) | 15% (3 of 20) | 16% (5 of 32) |
| none of these (no charge, no fight, no charge escaped) | 67% (8 of 12) | 70% (14 of 20) | 69% (22 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (567 of 851) | 53% (421 of 790) | 60% (988 of 1641) |
|   cavalry | 63% (51 of 81) | 58% (92 of 160) | 59% (143 of 241) |
|   character | 53% (50 of 94) | 21% (24 of 115) | 35% (74 of 209) |
|   chariot | 56% (54 of 96) | 72% (29 of 40) | 61% (83 of 136) |
|   infantry | 59% (150 of 254) | 55% (169 of 309) | 57% (319 of 563) |
|   monster | 41% (20 of 49) | 69% (27 of 39) | 53% (47 of 88) |
|   war machine | 87% (242 of 277) | 63% (80 of 127) | 80% (322 of 404) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (22%) | 2.2 (21%) | 3.9 (22%) |
| CHARGED: it charged | 1.1 (14%) | 2.1 (20%) | 3.2 (18%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.1 (14%) | 0.4 (4%) | 1.5 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.4 (18%) | 2.2 (21%) | 3.6 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (8%) | 0.7 (7%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (15%) | 1.8 (17%) | 3.0 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.4 (4%) | 0.6 (3%) |
| OTHER BAR | 0.2 (3%) | 0.4 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.9 | 76% | 5.6 pts | 32 pts |
| character | 2.2 | 0.8 | 80% | 10.8 pts | 24 pts |
| chariot | 2.4 | 1.8 | 67% | 17.5 pts | 41 pts |
| infantry | 12.1 | 4.6 | 74% | 8.4 pts | 102 pts |
| monster | 1.5 | 0.4 | 80% | 5.5 pts | 8 pts |
| war machine | 8.9 | 7.2 | 64% | 26.2 pts | 234 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 6.6 | 5.3 |
| Charges that made contact a game | 2.9 | 4.7 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.92 declared, 0.76 contact (25 units) | 0.75 declared, 0.42 contact (12 units) | 0.86 declared, 0.65 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.17 contact (6 units) | 1.40 declared, 0.90 contact (10 units) | 1.00 declared, 0.62 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.35 contact (249 units) | 0.72 declared, 0.52 contact (297 units) | 0.62 declared, 0.44 contact (546 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (43 of 73) | 67% (12 of 18) | 58% (7 of 12) | 60% (62 of 103) |
| Character in a unit | 82% (23 of 28) | 55% (6 of 11) | 67% (2 of 3) | 74% (31 of 42) |
| Character on its own | 82% (36 of 44) | 47% (20 of 43) | 25% (16 of 63) | 48% (72 of 150) |
| Chariot | 76% (13 of 17) | 77% (10 of 13) | - | 77% (23 of 30) |
| Infantry | 57% (54 of 94) | 56% (19 of 34) | 33% (1 of 3) | 56% (74 of 131) |
| Monster | 48% (14 of 29) | 78% (7 of 9) | - | 55% (21 of 38) |
| Monstrous | 29% (4 of 14) | 79% (11 of 14) | - | 54% (15 of 28) |
| War Machines | 72% (41 of 57) | 100% (2 of 2) | - | 73% (43 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (13 of 13); on the table 100% | 27% (28 of 102) | 26% | 50% (11 of 22) | 100% (6 of 6); 4.5 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 94% (15 of 16); on the table 94% | 39% (14 of 36) | 45% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 85% (11 of 13); on the table 85% | - | 51% | 76% (41 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 73% (11 of 15); on the table 80% | 27% (13 of 48) | 52% | 62% (47 of 76) | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 90% (9 of 10); on the table 100% | 25% (34 of 138) | 41% | 44% (24 of 54) | 86% (12 of 14); 6.2 uses a game | 100% (2 of 2); 0.7 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 100% (9 of 9); on the table 100% | 11% (2 of 18) | 22% | 61% (20 of 33) | 100% (3 of 3); 2.2 uses a game | 64% (9 of 14); 5.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (5 of 5); on the table 100% | - | 48% | 33% (4 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 39% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 77% (10 of 13); on the table 92% | 0% (0 of 18) | 47% | 82% (23 of 28) | 100% (4 of 4); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 17% (2 of 12) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 80% (8 of 10); on the table 80% | 39% (7 of 18) | 22% | 68% (17 of 25) | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 5 | 100% (11 of 11); on the table 100% | - | 38% | 24% (6 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 81% (22 of 27); on the table 85% | 41% (27 of 66) | 30% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 89% (24 of 27); on the table 93% | 50% (9 of 18) | 19% | 47% (34 of 73) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 89% (24 of 27); on the table 89% | 42% (10 of 24) | 47% | 65% (51 of 78) | 57% (4 of 7); 1.6 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ch-h2h-mine-ea652ef-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (45) | 54% (32) | 48% (77) |
| ...free all their last turn and able to turn (per game) | 0.72 | 0.47 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.17 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.31 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.58 | 1.22 | 2.81 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.92 | 1.86 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.72 | 4.92 | 10.64 |

### Quality by phase: ch-h2h-mine-ea652ef-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 44% (54 of 123) | 44% (107 of 242) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (124 of 352) | 49% (110 of 225) |
| Strategy | Close-in objectives charged next turn | 14% (17 of 125) | 19% (42 of 217) |
| Strategy | Support requests answered (helper made contact too) | 54% (7 of 13) | 42% (15 of 36) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 0% (0 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (12 of 18) | 30% (3 of 10) |
| Strategy | Joined characters whose unit fought | 66% (29 of 44) | 19% (6 of 32) |
| Strategy | Lone characters that fought | 82% (83 of 101) | 69% (63 of 91) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 369.6 | 155.0 |
| Movement | Fights charged into per game | 2.6 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 80, net -44 | 24 of 127, net +150 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 80, net +45 | 20 of 127, net +56 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 80, net -25 | 9 of 127, net +116 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 80, net +62 | 41 of 127, net +151 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 10.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (123 of 352) | 48% (182 of 376) |
| Shooting | Points destroyed by shooting units | 91.3 | 32.9 |
| Shooting | War machine shots | 6.7 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (137 of 242) | 42% (34 of 80) |
| Shooting | Points destroyed by war machines | 95.5 | 34.6 |
| Magic | Magic missiles cast | 1.4 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (14 of 49) | 31% (11 of 36) |
| Magic | Wounds caused by magic missiles | 2.2 | 1.4 |
| Magic | Wounds caused by other spells | 1.7 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 53.4 | 41.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.6 / 1.0 / 0.1 | 1.9 / 0.3 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 285.5 | 469.4 |
| Combat | Points run down | 48.9 | 140.9 |
| Combat | Net points per charged fight, damage counted | +37 | +123 |
| Combat | Net per 100 charger points, damage counted | +13.2 | +45.1 |
| Combat | First round won (charged fights) | 72% | 71% |
| Combat | Net points per charged fight | +40 | +125 |
| Combat | Net points per supported fight / lone fight | -2 / +46 | +176 / +116 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 94 | 51 of 140 |
| Game | Points lost | 869.5 | 691.6 |
| Game | VP from objectives | 477.5 | 678.6 |
| Game | Lone holders (player turns) | 1.9 | 3.5 |

- Mine won / drew / lost: 10 / 6 / 20 of 36 ended games (of 36); mean margin (Mine - Opponent) -409 VP
- The side that went first won 18 of 30 games with a winner
- Points traded per game (both sides' losses): 1561
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: ch-h2h-mine-ea652ef-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 2.5 | 0.1 | +5.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 11.0 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.9 | +7.7 | 0.0 | 34.6 | 1.1 | +12.4 | 0.0 | 9.9 |
| BEST FACING | 0.7 | +33.6 | 0.0 | 47.3 | 0.7 | +18.6 | 0.0 | 45.2 |
| BEST FIRST | 4.4 | +171.2 | 111.7 | 84.3 | 4.4 | +206.2 | 171.1 | 119.0 |
| BEST MOVE FOR SHOOTERS | 0.9 | +66.0 | 0.0 | 5.0 | - | - | - | - |
| BEST OVERALL | 0.6 | +41.1 | 0.0 | 40.2 | 0.6 | +31.0 | 0.0 | 18.4 |
| BEST PREY | 0.8 | +28.3 | 29.7 | 3.6 | 0.6 | +33.5 | 34.3 | 9.6 |
| BEST PRIZE | 0.1 | +3.2 | 9.8 | 0.0 | 0.1 | +0.2 | 5.4 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.4 | 0.0 | 11.1 | 0.1 | -0.6 | 0.0 | 12.1 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +2.9 | 0.0 | 0.0 | 0.4 | -1.9 | 0.0 | 16.6 |
| BLOWS WHERE AIMED | 0.2 | -4.5 | 19.2 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 10.8 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.1 | +0.0 | 18.9 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 1.8 | +67.7 | 131.3 | 9.7 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 6.7 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -0.4 | 0.0 | 0.0 | 0.1 | +0.0 | 13.1 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | -1.4 | 0.0 | 0.0 | 0.2 | -5.8 | 24.1 | 0.0 |
| CAST JOB | 0.6 | +28.8 | 79.9 | 11.2 | 0.3 | +3.8 | 3.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +34.0 | 20.8 | 0.0 | 0.1 | +5.1 | 9.3 | 4.4 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 25.0 | 0.5 | +0.0 | 0.0 | 37.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.1 | +2.9 | 0.0 | 0.0 | 0.0 | +2.5 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.4 | -0.5 | 0.0 | 14.6 |
| CHARGE BAND | 0.1 | +0.0 | 9.5 | 8.6 | - | - | - | - |
| CHARGE NOW FIRST | 2.1 | +0.0 | 169.9 | 75.0 | 3.6 | +0.0 | 431.1 | 91.4 |
| CHARGE NOW WEIGHED | 0.4 | -31.5 | 12.3 | 7.8 | 0.4 | -67.4 | 3.8 | 55.5 |
| CHARGER SLAIN LOST | 0.3 | -17.2 | 15.0 | 34.8 | - | - | - | - |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 5.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 12.9 | 1.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 12.1 | 45.7 | 0.6 | +0.0 | 47.0 | 8.3 |
| CONVEYANCE SEARCH | 0.2 | +25.4 | 0.0 | 0.0 | 0.6 | +64.6 | 30.3 | 45.3 |
| COUNTER-CHARGE COVER | 10.5 | +960.3 | 0.0 | 298.9 | 6.3 | +508.3 | 0.0 | 161.8 |
| DEFENSIVE ARMY | 0.6 | +0.0 | 18.1 | 6.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +3.9 | 12.6 | 0.0 | 0.6 | +7.2 | 71.1 | 6.5 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | 11.1 | +0.0 | 584.5 | 231.0 | - | - | - | - |
| FACE THE CAST | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +118.9 | 0.0 | 70.3 | 1.2 | +111.0 | 0.0 | 68.1 |
| FALLBACK BY WORTH | 4.1 | +53.5 | 0.0 | 69.5 | 5.2 | +42.4 | 0.0 | 59.8 |
| FIGHT LIFT | 0.0 | +0.1 | 1.7 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +1.7 | 0.0 | 4.6 | 0.1 | +0.6 | 0.0 | 4.4 |
| FIRE IN ORDER | 0.8 | +0.0 | 53.9 | 18.3 | - | - | - | - |
| FIRE PLAN | 15.9 | +72.9 | 784.8 | 326.9 | - | - | - | - |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 207.9 | 4.6 | +0.0 | 0.0 | 119.1 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.3 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +112.9 | 0.0 | 43.1 | 1.2 | +217.4 | 0.0 | 34.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +14.9 | 0.0 | 0.0 | 0.2 | +19.8 | 0.0 | 5.2 |
| GIVES UP | 0.0 | -0.4 | 0.0 | 0.0 | 0.2 | -3.6 | 15.2 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.4 | 7.7 | 1.2 |
| GROUND FLIERS | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 19.4 | 2.7 |
| HELPER UNSEEN | 0.2 | +0.0 | 13.6 | 10.1 | 0.3 | +0.0 | 16.2 | 5.2 |
| HILL BY ITS CHANCE | 0.4 | -43.4 | 0.0 | 5.2 | 0.5 | -57.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 11.1 | +1577.3 | 584.5 | 231.0 | - | - | - | - |
| HONEST WORTH | 7.2 | -105.9 | 300.0 | 170.2 | - | - | - | - |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.9 | 5.6 | 4.6 | 0.2 | +1.4 | 2.4 | 5.2 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 3.2 | 0.1 | +0.0 | 15.7 | 3.1 |
| HUNT IN PAIRS | 0.2 | +19.1 | 0.0 | 0.0 | 0.6 | +27.7 | 0.0 | 36.2 |
| HUNT KEPT | 0.0 | +2.9 | 2.8 | 2.4 | 0.1 | +3.4 | 13.9 | 0.0 |
| HUNT RESULT | 0.1 | +11.9 | 0.0 | 5.6 | 0.3 | +47.2 | 27.9 | 7.5 |
| HUNT THE GUNS | 0.1 | +23.1 | 5.6 | 4.6 | 0.3 | +105.8 | 20.3 | 6.4 |
| INVITES THE FIGHT | 1.8 | +29.7 | 51.7 | 20.4 | 1.1 | +22.5 | 50.2 | 3.5 |
| JOINT CHARGE PLAN | 0.0 | +0.0 | 0.0 | 1.4 | 0.1 | +7.2 | 16.1 | 0.0 |
| KEEP FALLS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +1.0 | 3.5 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +45.0 | 125.8 | 64.8 | 2.4 | +72.5 | 295.8 | 47.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | 1.2 | -51.4 | 140.2 | 35.9 | - | - | - | - |
| KILLS COUNT | 1.6 | +81.6 | 124.8 | 22.7 | 2.9 | +146.5 | 231.1 | 51.8 |
| KILLS COUNT NEXT TURN | 4.4 | +142.5 | 119.5 | 108.4 | 6.7 | +254.4 | 271.2 | 179.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +24.9 | 0.0 | 16.2 | 0.2 | +1.3 | 0.0 | 4.9 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 10.9 | 0.0 | 0.3 | +0.0 | 1.5 | 21.8 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +4.8 | 26.3 | 2.9 | 0.8 | -5.0 | 55.2 | 0.0 |
| LOST CHARGE | 2.7 | -48.2 | 72.1 | 93.0 | 2.4 | -54.0 | 66.8 | 92.2 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.6 | 0.0 | 3.1 | 0.0 | -3.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +4.2 | 0.0 | 1.4 | 0.7 | +51.2 | 11.4 | 22.2 |
| MANOEUVRE | 0.3 | +3.7 | 0.0 | 12.2 | 0.2 | +12.1 | 0.0 | 11.7 |
| MARCH AT ESCAPER | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.4 | +7.2 | 0.0 | 10.2 | 0.3 | +7.2 | 0.0 | 13.5 |
| MARCH ODDS | 0.1 | +9.9 | 0.0 | 17.4 | 0.3 | +38.8 | 12.6 | 34.9 |
| MARCH OVER CASTS | 0.5 | +51.9 | 0.0 | 36.0 | 0.2 | +23.9 | 0.0 | 4.4 |
| MAX FOR POSITIONING | 4.8 | +156.3 | 0.0 | 157.1 | 4.3 | +165.7 | 0.0 | 142.9 |
| MISSILES IN THE FIRE PLAN | 1.6 | +9.6 | 95.6 | 14.7 | - | - | - | - |
| MISSILES IN THE MOVE | 3.5 | +104.0 | 0.0 | 82.0 | 2.6 | +40.8 | 0.0 | 69.0 |
| MISSILES NEXT TURN | 4.1 | +61.3 | 0.0 | 126.3 | 3.2 | +36.3 | 0.0 | 110.6 |
| MODEL FACING | 0.2 | +64.7 | 0.0 | 1.7 | 0.2 | +43.0 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 32.1 | 20.8 |
| MOVE AND CAST | 0.4 | +10.8 | 0.0 | 9.1 | 0.3 | +9.2 | 0.0 | 10.8 |
| MOVE SPELL IN RANGE | 0.2 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -4.3 | 0.0 | 0.0 | 0.3 | -11.5 | 0.0 | 22.8 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 25.0 | 0.1 | +0.0 | 0.0 | 22.3 |
| MOVE TO CHARGE | 2.2 | +88.2 | 73.9 | 76.8 | 5.0 | +310.8 | 251.7 | 151.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +3.7 | 2.8 | 0.0 | 0.1 | +6.8 | 0.9 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +6.3 | 0.0 | 0.0 |
| NOT NEEDED | 0.3 | -16.6 | 41.5 | 9.4 | 0.6 | -31.1 | 87.4 | 22.9 |
| NOT TURNED | 5.7 | +78.8 | 0.0 | 143.7 | 4.9 | +62.6 | 0.0 | 118.9 |
| NOT WORTH A CAST | 0.4 | -0.2 | 0.0 | 0.0 | 0.6 | -0.4 | 0.0 | 30.8 |
| OFF BEST | 15.1 | -683.1 | 0.0 | 338.7 | 14.9 | -820.4 | 5.2 | 268.8 |
| ONE YARDSTICK | 17.3 | -560.7 | 475.4 | 369.8 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.5 | 6.4 | 0.0 | 0.0 | +0.0 | 2.9 | 0.0 |
| OPENS UP | 0.1 | +1.6 | 3.2 | 0.0 | 0.2 | +13.4 | 13.6 | 0.0 |
| OVERRUNS AWAY | 0.4 | +6.0 | 65.4 | 7.1 | 0.5 | +8.5 | 80.9 | 5.2 |
| PATHS CROSS | 2.1 | +163.9 | 0.0 | 37.8 | 2.8 | +191.6 | 0.0 | 62.5 |
| PERIAPT WORTH | 0.1 | +3.3 | 0.0 | 15.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.2 | 0.0 | 22.5 | 0.1 | -1.8 | 0.0 | 22.4 |
| PLAN RESULT | 36.7 | +1209.4 | 1255.6 | 1146.2 | 40.4 | +1462.7 | 1559.4 | 879.8 |
| PURSUES BIG PREY | - | - | - | - | 0.2 | -18.9 | 0.0 | 12.0 |
| PURSUES ON | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +5.4 | 0.0 | 15.7 | 1.6 | +24.3 | 0.0 | 26.7 |
| RANDOM MOVER NO PROMISE | 0.2 | -13.3 | 4.0 | 5.8 | 0.4 | -29.1 | 28.0 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.6 | 0.0 | 2.5 | 0.2 | -4.7 | 0.0 | 0.9 |
| REDIRECT COUNTER | 2.3 | +144.5 | 0.0 | 50.2 | 3.4 | +313.3 | 0.0 | 48.8 |
| REDIRECT WEIGHED | 0.2 | +7.3 | 6.9 | 8.9 | 0.4 | +10.0 | 12.3 | 16.8 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 6.4 | - | - | - | - |
| RESERVE FALL BACK | 0.1 | +3.9 | 0.0 | 0.0 | 0.9 | +43.7 | 0.0 | 14.8 |
| RESTRAINS TO SHOOT | 0.2 | +9.6 | 0.0 | 22.4 | 0.0 | +0.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +77.5 | 175.9 | 82.1 | 4.0 | +102.4 | 373.1 | 78.9 |
| SAFE SURE CHARGE | 0.0 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +60.5 | 0.0 | 41.4 | 0.9 | +57.7 | 0.0 | 34.8 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.5 | 0.0 | 1.2 | 0.4 | -25.7 | 0.0 | 4.7 |
| SEARCH SPOT | 3.1 | +133.5 | 0.0 | 81.2 | 2.9 | +138.8 | 0.0 | 38.9 |
| SECOND HUNTER | 0.0 | -0.5 | 2.8 | 1.4 | 0.1 | -0.6 | 4.6 | 0.0 |
| SELF MOVE SPELL | 0.2 | +10.4 | 0.0 | 31.0 | - | - | - | - |
| SET UP TOGETHER | 0.4 | +9.9 | 8.2 | 1.4 | 1.7 | +142.0 | 67.6 | 29.9 |
| SET-UP ANY TARGET | 0.1 | +35.0 | 0.0 | 0.0 | 0.1 | +3.3 | 8.8 | 15.2 |
| SET-UP MISSED | - | - | - | - | 0.1 | +4.7 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | 2.1 | +131.2 | 177.9 | 51.4 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 1.9 | +23.1 | 0.0 | 9.3 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.8 | +27.9 | 25.0 | 8.6 | 0.6 | +22.1 | 19.4 | 27.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 15.3 | +0.0 | 726.1 | 321.0 | 12.1 | +0.0 | 381.9 | 205.2 |
| SHOT REPLANNED | - | - | - | - | 0.1 | +0.0 | 19.6 | 0.0 |
| SHOTS IN THE MOVE | 14.4 | +632.4 | 0.0 | 305.1 | 10.7 | +336.2 | 0.0 | 133.5 |
| SPELL CATCH ODDS | 0.1 | -2.3 | 0.0 | 0.0 | 0.0 | -0.2 | 1.4 | 0.0 |
| SPELL SETS UP CHARGE | 0.1 | +35.0 | 0.0 | 0.0 | 0.1 | +21.1 | 8.8 | 15.2 |
| SPELL WORTH | 0.9 | +21.6 | 96.5 | 82.4 | 1.8 | +34.5 | 52.2 | 52.2 |
| SPELLS IN THE FIGHT | 0.6 | -0.0 | 80.0 | 27.9 | - | - | - | - |
| STABLE ROLE | 10.4 | +0.0 | 344.8 | 209.6 | 11.4 | +0.0 | 434.6 | 196.1 |
| STANDS TO CAST | - | - | - | - | 0.0 | +2.1 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 2.0 |
| STAY WORTH | 14.6 | +82.0 | 374.7 | 250.2 | - | - | - | - |
| STOPS | 0.0 | +2.9 | 2.8 | 2.4 | 0.2 | +11.8 | 29.4 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.5 | +22.0 | 0.0 | 41.7 | 0.3 | +12.7 | 0.0 | 20.2 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 6.1 | -50.2 | 361.4 | 156.0 | 7.6 | -51.5 | 455.8 | 137.2 |
| SUPPORTS | 4.4 | +50.2 | 261.2 | 91.6 | 4.2 | +51.5 | 174.0 | 56.6 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.3 | 12.1 | 0.0 | 0.0 | -0.6 | 2.9 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +4.2 | 5.7 | 2.9 | 0.8 | +7.2 | 0.0 | 9.3 |
| THROUGH LINE OF FIRE | 0.1 | +8.8 | 0.0 | 0.0 | 0.2 | +3.0 | 0.0 | 6.9 |
| TURN WORTH | 0.2 | -10.0 | 15.3 | 15.5 | 0.6 | -44.1 | 53.2 | 15.1 |
| TWO OR MORE ARRIVE | 0.1 | +0.7 | 8.2 | 0.0 | 0.3 | +1.1 | 8.0 | 0.8 |
| WAIT AFTER COSTS | 5.9 | -236.5 | 158.4 | 118.0 | 8.4 | -406.6 | 406.4 | 192.6 |
| WALKS TO THE FIGHT | 1.6 | +29.5 | 35.9 | 19.3 | 1.7 | +37.1 | 77.2 | 17.7 |
| WAR ENGINE CHARGES | 0.1 | +7.7 | 0.0 | 8.3 | 0.1 | +3.6 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 23.9 | 7.8 | 0.2 | +0.0 | 11.9 | 10.3 |
| WEARS DOWN | 0.9 | +37.0 | 65.4 | 33.9 | 2.0 | +73.1 | 290.0 | 41.9 |
| WHO HITS BACK | 0.2 | +10.4 | 0.0 | 14.4 | 0.2 | +17.8 | 0.0 | 8.0 |
| WHOLE FIGHT | 0.2 | +0.8 | 8.7 | 4.2 | 0.4 | +10.4 | 48.9 | 15.0 |
| WHOLE FIGHT GAIN | 0.2 | +23.6 | 31.0 | 3.7 | 0.8 | +65.7 | 79.4 | 16.0 |
| WIDER SPREAD | 2.4 | -8.0 | 172.5 | 78.2 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: ch-h2h-mine-ea652ef-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1080 | 1080 | 1080 | 30.00 | -54122 | -50.1 |
| BEST FIRST | 317 | 317 | 317 | 8.81 | +13589 | +42.9 |
| SEARCH SPOT | 219 | 219 | 216 | 6.00 | +9829 | +45.5 |
| PATHS CROSS | 174 | 174 | 174 | 4.83 | +12800 | +73.6 |
| COUNTER-CHARGE COVER | 606 | 362 | 169 | 4.69 | +9216 | +54.5 |
| FIRE PLAN | 572 | 572 | 142 | 3.94 | +1523 | +10.7 |
| KILLS COUNT NEXT TURN | 401 | 401 | 123 | 3.42 | +3801 | +30.9 |
| MOVE TO CHARGE | 259 | 259 | 113 | 3.14 | +4197 | +37.1 |
| FACES THE THREAT | 101 | 101 | 101 | 2.81 | +8278 | +82.0 |
| SUPPORTS | 311 | 311 | 100 | 2.78 | +838 | +8.4 |
| EVERY WOUND COUNTS | 398 | 398 | 95 | 2.64 | +0 | +0.0 |
| SHOTS IN THE MOVE | 906 | 577 | 86 | 2.39 | +2010 | +23.4 |
| FOLLOW UP WEIGHED | 75 | 75 | 75 | 2.08 | +11892 | +158.6 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| WALKS TO THE FIGHT | 117 | 117 | 68 | 1.89 | +910 | +13.4 |
| SAFER THAN THE JOB | 67 | 67 | 67 | 1.86 | +4257 | +63.5 |
| FALLBACK BY WORTH | 333 | 333 | 66 | 1.83 | +3450 | +52.3 |
| WAIT AFTER COSTS | 515 | 515 | 64 | 1.78 | +1317 | +20.6 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 88 | 88 | 50 | 1.39 | +1071 | +21.4 |
| BEST FACING | 49 | 49 | 49 | 1.36 | +1878 | +38.3 |
| KILLS COUNT | 159 | 157 | 44 | 1.22 | +2298 | +52.2 |
| MAX FOR POSITIONING | 329 | 195 | 44 | 1.22 | +491 | +11.2 |
| ONE YARDSTICK | 622 | 235 | 43 | 1.19 | +563 | +13.1 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| BEST OVERALL | 42 | 42 | 42 | 1.17 | +2598 | +61.8 |
| RISK BY ARC | 221 | 214 | 42 | 1.17 | +1509 | +35.9 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| REDIRECT COUNTER | 205 | 114 | 39 | 1.08 | +3481 | +89.3 |
| RESERVE FALL BACK | 39 | 39 | 39 | 1.08 | +1715 | +44.0 |
| CHARGE NOW FIRST | 206 | 206 | 37 | 1.03 | -2064 | -55.8 |
| BEST MOVE FOR SHOOTERS | 33 | 33 | 33 | 0.92 | +2378 | +72.1 |
| COMBAT PIVOT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| MISSILES IN THE MOVE | 222 | 138 | 33 | 0.92 | +424 | +12.8 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SET UP TOGETHER | 75 | 61 | 31 | 0.86 | +2407 | +77.6 |
| FIRE IN ORDER | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 28 | 28 | 28 | 0.78 | +2771 | +99.0 |
| STOPS SHORT OF THE FLANK | 28 | 28 | 28 | 0.78 | +1247 | +44.5 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +36 | +1.3 |
| HONEST THREAT | 398 | 398 | 27 | 0.75 | +0 | +0.0 |
| MOVE AND CAST | 26 | 26 | 26 | 0.72 | +719 | +27.7 |
| SHOOTS FROM THE BEST SPOT | 51 | 51 | 26 | 0.72 | +590 | +22.7 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| WHOLE FIGHT GAIN | 36 | 33 | 22 | 0.61 | +1068 | +48.6 |
| MARCH CHECK | 24 | 22 | 21 | 0.58 | +509 | +24.3 |
| STAY WORTH | 524 | 423 | 21 | 0.58 | +204 | +9.7 |
| INVITES THE FIGHT | 104 | 104 | 20 | 0.56 | +359 | +18.0 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.56 | +866 | +43.3 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +1249 | +65.7 |
| KEEPS ITS TARGET | 141 | 139 | 19 | 0.53 | +333 | +17.5 |
| KEEPS THE TARGET | 44 | 44 | 18 | 0.50 | -2552 | -141.8 |
| MANOEUVRE | 20 | 20 | 18 | 0.50 | +568 | +31.6 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CASTING BLOCK | 19 | 19 | 15 | 0.42 | +804 | +53.6 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -18 | -1.2 |
| MARCH ODDS | 16 | 16 | 15 | 0.42 | +500 | +33.3 |
| MODEL FACING | 15 | 15 | 15 | 0.42 | +3878 | +258.5 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CAST JOB | 33 | 33 | 14 | 0.39 | +399 | +28.5 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WEARS DOWN | 104 | 102 | 14 | 0.39 | +751 | +53.6 |
| THROUGH LINE OF FIRE | 13 | 13 | 13 | 0.36 | +423 | +32.5 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +438 | +33.7 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -35 | -2.9 |
| HONEST WORTH | 258 | 256 | 12 | 0.33 | +160 | +13.3 |
| MAKE SURE TOGETHER | 35 | 19 | 11 | 0.31 | +540 | +49.1 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -144 | -14.4 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +375 | +41.7 |
| CANNON PLANNED TARGET | 65 | 65 | 7 | 0.19 | -154 | -22.0 |
| SUPPORT NARROWED | 491 | 491 | 7 | 0.19 | -100 | -14.3 |
| WHOLE FIGHT | 23 | 23 | 7 | 0.19 | +530 | +75.7 |
| BEST PREY | 50 | 50 | 6 | 0.17 | +423 | +70.6 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -548 | -91.3 |
| LOST CHARGE | 182 | 182 | 6 | 0.17 | +141 | +23.4 |
| OPENS UP | 10 | 10 | 6 | 0.17 | +222 | +37.0 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -680 | -113.3 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.2 |
| MISSILES NEXT TURN | 262 | 152 | 5 | 0.14 | +3 | +0.7 |
| NEEDED THERE | 7 | 7 | 5 | 0.14 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -71 | -14.3 |
| SURE REACH TOGETHER | 41 | 30 | 5 | 0.14 | +66 | +13.1 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| HUNT IN PAIRS | 29 | 19 | 4 | 0.11 | +143 | +35.7 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| SHOOTERS ARE THREATS | 75 | 75 | 4 | 0.11 | +0 | +0.0 |
| CARRIES OUT SET-UP | 8 | 8 | 3 | 0.08 | -259 | -86.4 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -81 | -26.9 |
| CHARGE BAND | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 3 | 3 | 3 | 0.08 | -249 | -83.0 |
| DEFENSIVE ARMY | 29 | 29 | 3 | 0.08 | -152 | -50.6 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +85 | +28.3 |
| HUNT ADVANCE | 9 | 9 | 3 | 0.08 | +18 | +6.1 |
| OVERRUNS AWAY | 35 | 35 | 3 | 0.08 | +181 | +60.5 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +170 | +56.8 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +183 | +61.1 |
| SHOOTERS TO THE PRIMARY | 70 | 52 | 3 | 0.08 | +0 | +0.0 |
| SHOT REPLANNED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| WAR ENGINE JOBS | 21 | 21 | 3 | 0.08 | -145 | -48.3 |
| BACKUP TARGETS | 75 | 37 | 2 | 0.06 | +62 | +30.8 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +11 | +5.3 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +47 | +23.7 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +78 | +39.1 |
| REFUSING RETIRES | 6 | 6 | 2 | 0.06 | -1 | -0.4 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +14 | +6.8 |
| STOPS | 8 | 8 | 2 | 0.06 | +100 | +49.9 |
| BLOWS WHERE AIMED | 9 | 8 | 1 | 0.03 | +26 | +25.9 |
| CARRIES OUT COUNTER | 5 | 5 | 1 | 0.03 | -14 | -13.6 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +32 | +31.9 |
| EDGE GIVE GROUND | 24 | 24 | 1 | 0.03 | +37 | +36.7 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +4.6 |
| JOINT CHARGE PLAN | 4 | 4 | 1 | 0.03 | +62 | +62.3 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 1 | 0.03 | +0 | +0.0 |
| MISSILES IN THE FIRE PLAN | 57 | 5 | 1 | 0.03 | +22 | +21.8 |
| MOVE SPELL IN RANGE | 6 | 6 | 1 | 0.03 | +1 | +1.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +169 | +169.2 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +6 | +5.9 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +165 | +164.9 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -22 | -21.9 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -0 | -0.2 |
| WIDER SPREAD | 88 | 85 | 1 | 0.03 | +2 | +1.9 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 30 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 12 | 12 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 28 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 376 | not checked | - | - | - | - |
| GIVES UP | 8 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 21 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 34 | 34 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 13 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 15 | not checked | - | - | - | - |
| LONG SHOT | 45 | 44 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 27 | 27 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 34 | 33 | 0 | 0.00 | - | - |
| NOT TURNED | 383 | 383 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 35 | not checked | - | - | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2773 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 24 | 24 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 18 | 18 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOT OPTIONS | 987 | 987 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 4 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 95 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 21 | 21 | 0 | 0.00 | - | - |
| STABLE ROLE | 784 | 783 | 0 | 0.00 | - | - |
| TURN WORTH | 27 | 27 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 13 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 8 | 8 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ch-h2h-mine-ea652ef-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.83 | 13.69 | 51.5 |
| CHARGE NOW FIRST | rule | 0.42 | 0.61 | 55.8 |
| FALLBACK | gate | 0.39 | 0.53 | 43.7 |
| TURN GATE | gate | 0.50 | 0.25 | 34.1 |
| KEEPS THE TARGET | rule | 0.47 | - | 151.7 |
| FIRE PLAN | rule | 0.44 | - | 87.7 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.14 | 14.4 |
| AFTERMATH BAND | gate | 0.08 | 0.14 | 2.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.11 | 21.4 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.08 | 8.3 |
| CHAFF PASSED | rule | - | 0.19 | 2.6 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.17 | 72.8 |
| BEST PRIZE | rule | 0.11 | 0.06 | 91.3 |
| PURSUES BIG PREY | rule | - | 0.17 | 113.3 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 16.6 |
| NO REASON | gate | 0.14 | - | 31.8 |
| SUPPORT REQUEST | gate | 0.03 | 0.11 | 65.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.03 | 14.3 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.06 | 4.1 |
| BLOCKED WHEEL | rule | 0.03 | 0.06 | 42.4 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 86.4 |
| CATCH ODDS | rule | 0.06 | 0.03 | 26.9 |
| CHARIOT NO STATIC JOB | rule | 0.08 | - | 83.0 |
| DEFENSIVE ARMY | rule | 0.03 | 0.06 | 50.6 |
| PATHS CROSS | rule | 0.03 | 0.06 | 7.9 |
| WAR ENGINE JOBS | rule | 0.08 | - | 48.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 17.3 |
| CANNON PLANNED TARGET | rule | - | 0.06 | 79.8 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 11.4 |
| WHO HITS BACK | rule | - | 0.06 | 2.0 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 13.6 |
| FIGHT ORDER BAND | gate | 0.03 | - | 2.0 |
| MARCH ODDS | rule | - | 0.03 | 20.2 |
| REDIRECT WEIGHED | rule | 0.03 | - | 77.6 |
| SAFE SURE CHARGE | rule | 0.03 | - | 21.9 |
| SAFER THAN THE JOB | rule | 0.03 | - | 18.9 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 30.3 |

### Plans: ch-h2h-mine-ea652ef-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.6 | 15% | 448 | 269 | 60% |
| Mine | charge | 2.9 | 61% | 240 | 266 | 111% |
| Mine | close in | 3.4 | 19% | 151 | 86 | 57% |
| Mine | hold | 4.0 | 32% | 268 | 0 | 0% |
| Mine | join | 0.6 | 95% | 18 | 0 | 0% |
| Mine | shoot | 8.4 | 55% | 328 | 588 | 179% |
| Mine | support | 4.7 | 86% | 34 | 0 | 0% |
| Opponent | advance | 13.4 | 15% | 341 | 344 | 101% |
| Opponent | charge | 6.1 | 58% | 652 | 601 | 92% |
| Opponent | close in | 6.0 | 32% | 452 | 167 | 37% |
| Opponent | hold | 4.3 | 41% | 338 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 38 | 0 | 0% |
| Opponent | shoot | 5.1 | 60% | 158 | 350 | 221% |
| Opponent | support | 4.6 | 92% | 36 | 0 | 0% |

### Packages: hunt the guns, ch-h2h-mine-ea652ef-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 0 | 33% | 67% | 0% | 2.5 | 277 | 142 | 33% | 38 |
| Opponent | 0.3 | 10 | 0 | 40% | 50% | 10% | 2.8 | 381 | 170 | 50% | 118 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 50% | 100% | 0% | 2.5 | 298 | 213 | 50% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 156 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 112 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 227 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.8 | 3 | 0 | 100% | 100% | 0% | 2.7 | 581 | 451 | 100% | 122 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.8 | 4 | 0 | 0% | 25% | 25% | 4.0 | 224 | 24 | 25% | 14 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 353 | 124 | 50% | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 467 | 0 | 0% | 121 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 71 |

### Battle groups: ch-h2h-mine-ea652ef-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.5 | 27% | 46% | 16% | 50% | 31% | 16% | 16% | 36% | 0% |
| Mine | REDIRECT COUNTER | 2.3 | 32% | 56% | 15% | 0% | 22% | 0% | 13% | 65% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.3 | 25% | 65% | 19% | 36% | 26% | 20% | 13% | 41% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 21% | 88% | 12% | 33% | 39% | 0% | 4% | 57% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ch-h2h-mine-ea652ef-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 48 | 0% | 2.8 | - | 0 (4) | 0 (1) | 0 (2) | 0 (3) |
| Mine | Chaff | 36 | 71 (36) | 32 | 39 | 55 | 42% | 2.1 | 42 (20) | 250 (7) | 4 (9) | 96 (25) | 5 (11) |
| Mine | Character | 123 | 43 (123) | 42 | 1 | 39 | 13% | 2.6 | 58 (39) | 41 (53) | 14 (13) | 57 (52) | 35 (53) |
| Mine | Clean-up | 20 | 44 (20) | 1 | 43 | 53 | 50% | 2.5 | 26 (5) | 42 (12) | 95 (3) | 93 (12) | 0 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 46 | 49 (46) | 31 | 18 | 67 | 28% | 2.7 | 43 (22) | 75 (16) | 14 (8) | 55 (27) | 40 (19) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.8 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 36 (57) | 24 | 12 | 44 | 16% | 2.7 | 21 (18) | 31 (29) | 80 (10) | 36 (38) | 36 (19) |
| Mine | Holder | 29 | 44 (29) | 16 | 28 | 33 | 28% | 3.5 | 26 (11) | 35 (12) | 98 (6) | 62 (21) | 0 (8) |
| Mine | Shooter | 41 | 77 (41) | 31 | 46 | 62 | 2% | 1.5 | 122 (5) | 78 (30) | 44 (6) | 105 (25) | 33 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 34 | 50% | 6.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | War machine | 59 | 59 (59) | 59 | 0 | 53 | 2% | 1.2 | 107 (10) | 58 (37) | 26 (12) | 47 (10) | 62 (49) |
| Mine | Wizard | 22 | 8 (22) | 8 | 0 | 58 | 14% | 2.3 | 0 (6) | 0 (6) | 33 (5) | 49 (5) | 0 (12) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 62 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Chaff | 76 | 67 (76) | 30 | 37 | 38 | 37% | 2.6 | 75 (31) | 44 (20) | 80 (25) | 82 (54) | 32 (22) |
| Opponent | Character | 94 | 73 (94) | 73 | 0 | 33 | 21% | 2.6 | 105 (41) | 48 (35) | 76 (6) | 73 (56) | 91 (26) |
| Opponent | Clean-up | 21 | 29 (21) | 18 | 11 | 26 | 33% | 2.7 | 22 (9) | 36 (12) | - | 26 (15) | 35 (6) |
| Opponent | Early | 2 | 83 (2) | 83 | 0 | 0 | 0% | 5.0 | - | 83 (2) | - | 0 (1) | 167 (1) |
| Opponent | Fast Hammer | 48 | 35 (48) | 28 | 7 | 51 | 19% | 2.3 | 25 (22) | 27 (16) | 73 (10) | 32 (28) | 40 (20) |
| Opponent | Fragile | 5 | 80 (5) | 80 | 0 | 61 | 40% | 2.0 | - | 130 (3) | 0 (2) | 98 (4) | 0 (1) |
| Opponent | Hammer | 68 | 19 (68) | 16 | 3 | 45 | 19% | 3.1 | 35 (17) | 14 (40) | 20 (11) | 17 (42) | 22 (26) |
| Opponent | Holder | 35 | 96 (35) | 15 | 81 | 18 | 34% | 2.9 | 114 (8) | 91 (19) | 92 (8) | 124 (24) | 34 (11) |
| Opponent | Shooter | 33 | 80 (33) | 13 | 67 | 17 | 0% | 1.8 | 66 (8) | 101 (19) | 23 (6) | 131 (22) | 0 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 33% | 4.5 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 49 (24) | 49 | 0 | 25 | 12% | 1.6 | 72 (6) | 49 (14) | 21 (4) | 0 (3) | 56 (21) |
| Opponent | Wizard | 29 | 49 (29) | 49 | 0 | 44 | 7% | 1.3 | 0 (10) | 107 (8) | 56 (6) | 112 (10) | 0 (14) |

### Charged fights: ch-h2h-mine-ea652ef-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 51 | 214 | 1.0 | 1.0 | 214 | 218 | -4 | 2 of 4 | 4 of 4 | - | -4 |
| Mine | Chaos Dwarfs | 4 | 261 | 240 | 1.8 | 1.3 | 137 | 0 | +137 | 4 of 7 | 5 of 7 | +114 | +146 |
| Mine | Dwarfen Mountain Holds | 4 | 510 | 28 | 1.5 | 1.2 | 18 | 59 | -40 | 2 of 6 | 5 of 6 | -233 | -2 |
| Mine | Empire of Man | 5 | 427 | 224 | 2.2 | 1.2 | 102 | 9 | +92 | 4 of 11 | 9 of 11 | +56 | +100 |
| Mine | Grand Cathay | 4 | 340 | 247 | 3.2 | 1.1 | 76 | 0 | +76 | 3 of 13 | 8 of 12 | +111 | +73 |
| Mine | High Elf Realms | 4 | 215 | 439 | 3.2 | 1.1 | 135 | 76 | +59 | 4 of 13 | 11 of 13 | +0 | +64 |
| Mine | Kingdom of Bretonnia | 1 | 465 | 410 | 4.0 | 1.0 | 102 | 118 | -15 | 1 of 4 | 4 of 4 | - | -15 |
| Mine | Lizardmen | 1 | 0 | 300 | 5.0 | 1.0 | 60 | 0 | +60 | 2 of 5 | 3 of 5 | - | +60 |
| Mine | Ogre Kingdoms | 1 | 236 | 186 | 6.0 | 1.0 | 31 | 54 | -23 | 1 of 6 | 2 of 5 | - | -23 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 235 | 3.0 | 1.3 | 78 | 0 | +78 | 1 of 3 | 2 of 3 | +45 | +95 |
| Mine | Skaven | 2 | 143 | 0 | 2.5 | 1.0 | 0 | 63 | -63 | 1 of 5 | 2 of 5 | - | -63 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 625 | 6.0 | 1.2 | 104 | 0 | +104 | 0 of 6 | 6 of 6 | +125 | +100 |
| Mine | Vampire Counts | 3 | 0 | 152 | 3.3 | 1.3 | 46 | 113 | -68 | 3 of 10 | 5 of 10 | -204 | -34 |
| Mine | Warriors of Chaos | 1 | 19 | 334 | 1.0 | 1.0 | 334 | 0 | +334 | 0 of 1 | 0 of 1 | - | +334 |
| **Mine** | all armies | 36 | 240 | 232 | 2.6 | 1.1 | 89 | 49 | +40 | 28 of 94 | 66 of 92 | -2 | +46 |
| Opponent | Dwarfen Mountain Holds | 2 | 110 | 100 | 4.0 | 1.1 | 25 | 22 | +3 | 2 of 8 | 4 of 8 | -60 | +12 |
| Opponent | Empire of Man | 2 | 468 | 116 | 1.5 | 1.3 | 77 | 0 | +77 | 0 of 3 | 2 of 3 | +91 | +70 |
| Opponent | Grand Cathay | 2 | 402 | 1065 | 3.0 | 1.7 | 355 | 0 | +355 | 4 of 6 | 5 of 6 | +760 | +152 |
| Opponent | Kingdom of Bretonnia | 1 | 380 | 165 | 3.0 | 1.0 | 55 | 0 | +55 | 1 of 3 | 2 of 3 | - | +55 |
| Opponent | Ogre Kingdoms | 3 | 0 | 225 | 4.0 | 1.1 | 56 | 10 | +46 | 3 of 12 | 5 of 12 | +0 | +50 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 148 | 850 | 5.5 | 1.3 | 154 | 40 | +114 | 7 of 22 | 17 of 22 | -7 | +159 |
| Opponent | Vampire Counts | 6 | 62 | 641 | 3.8 | 1.2 | 167 | 60 | +107 | 11 of 23 | 18 of 23 | -100 | +151 |
| Opponent | Warriors of Chaos | 8 | 8 | 513 | 3.0 | 1.3 | 171 | 11 | +160 | 11 of 24 | 20 of 24 | +344 | +112 |
| Opponent | Wood Elf Realms | 7 | 79 | 931 | 5.6 | 1.1 | 167 | 22 | +145 | 12 of 39 | 26 of 39 | +405 | +123 |
| **Opponent** | all armies | 36 | 109 | 591 | 3.9 | 1.2 | 152 | 26 | +125 | 51 of 140 | 99 of 140 | +176 | +116 |

### Effective charges: ch-h2h-mine-ea652ef-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 1 (net +100) | 0 | 0 | 2 (net -32) | 1 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 7 | 1 (net +277) | 0 | 1 (net +0) | 2 (net +227) | 0 | 3 (net +76) | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 0 | 0 | 1 (net -233) | 0 | 4 (net +13) | 1 | 0% (0 of 5) |
| Mine | Empire of Man | 11 | 0 | 0 | 1 (net +145) | 4 (net +192) | 1 (net +112) | 4 (net +23) | 1 | 10% (1 of 10) |
| Mine | Grand Cathay | 13 | 2 (net +0) | 0 | 1 (net +0) | 6 (net +66) | 3 (net +87) | 1 (net +329) | 0 | 8% (1 of 13) |
| Mine | High Elf Realms | 13 | 1 (net -60) | 0 | 2 (net +160) | 3 (net +139) | 3 (net -241) | 1 (net +702) | 3 | 20% (2 of 10) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +205) | 2 (net -133) | 0 | 0 | 1 | 33% (1 of 3) |
| Mine | Lizardmen | 5 | 1 (net +0) | 0 | 0 | 2 (net +125) | 1 (net +0) | 0 | 1 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 6 | 1 (net +0) | 0 | 1 (net +0) | 3 (net -16) | 0 | 0 | 1 | 20% (1 of 5) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 1 (net +45) | 0 | 0 | 1 (net +190) | 1 | 50% (1 of 2) |
| Mine | Skaven | 5 | 0 | 0 | 2 (net -32) | 0 | 0 | 3 (net -83) | 0 | 40% (2 of 5) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +110) | 0 | 1 (net +125) | 2 (net +70) | 2 | 25% (1 of 4) |
| Mine | Vampire Counts | 10 | 3 (net -205) | 0 | 2 (net -260) | 1 (net +205) | 0 | 2 (net +0) | 2 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1 (net +334) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Dwarfen Mountain Holds | 8 | 2 (net +0) | 1 (net -60) | 2 (net +73) | 2 (net -32) | 0 | 1 (net +0) | 0 | 25% (2 of 8) |
| Opponent | Empire of Man | 3 | 0 | 1 (net +0) | 0 | 1 (net +140) | 1 (net +91) | 0 | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 6 | 2 (net +306) | 0 | 1 (net +263) | 2 (net +502) | 0 | 1 (net +252) | 0 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 3 | 1 (net +0) | 0 | 0 | 0 | 1 (net +60) | 0 | 1 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 12 | 2 (net +165) | 0 | 1 (net +0) | 1 (net +45) | 0 | 3 (net +20) | 5 | 14% (1 of 7) |
| Opponent | Tomb Kings of Khemri | 22 | 4 (net +98) | 0 | 3 (net +217) | 6 (net +88) | 1 (net +77) | 8 (net +108) | 0 | 14% (3 of 22) |
| Opponent | Vampire Counts | 23 | 4 (net +174) | 1 (net +0) | 4 (net -81) | 5 (net +98) | 2 (net +148) | 6 (net +196) | 1 | 18% (4 of 22) |
| Opponent | Warriors of Chaos | 24 | 3 (net +38) | 1 (net +602) | 3 (net +10) | 4 (net +154) | 2 (net +225) | 10 (net +218) | 1 | 13% (3 of 23) |
| Opponent | Wood Elf Realms | 39 | 6 (net +242) | 1 (net +0) | 6 (net +60) | 7 (net +251) | 2 (net +38) | 12 (net +137) | 5 | 18% (6 of 34) |

### Charged fights, damage counted: ch-h2h-mine-ea652ef-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 186 | 216 | -44 | 48 | 101 | -53 | -28.6 |
| Mine | Effective (55-75%) | 15 | 243 | 234 | +45 | 112 | 61 | +51 | +21.1 |
| Mine | 76-89% | 24 | 317 | 193 | +81 | 130 | 70 | +60 | +19.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 256 | 186 | +62 | 140 | 73 | +68 | +26.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 444 | 106 | -25 | 63 | 90 | -27 | -6.2 |
| Mine | No odds | 14 | 250 | 141 | +25 | 69 | 38 | +31 | +12.6 |
| Mine | All fights | 94 | 280 | 184 | +40 | 106 | 69 | +37 | +13.2 |
| Opponent | Long shot (under 50%) | 24 | 283 | 282 | +150 | 216 | 71 | +145 | +51.1 |
| Opponent | 50-54% | 5 | 204 | 199 | +108 | 159 | 24 | +136 | +66.6 |
| Opponent | Effective (55-75%) | 20 | 244 | 220 | +56 | 151 | 84 | +67 | +27.4 |
| Opponent | 76-89% | 28 | 248 | 163 | +161 | 168 | 15 | +153 | +61.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 41 | 276 | 198 | +151 | 181 | 39 | +142 | +51.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 545 | 106 | +116 | 126 | 14 | +111 | +20.4 |
| Opponent | No odds | 13 | 184 | 242 | +44 | 115 | 65 | +50 | +27.2 |
| Opponent | All fights | 140 | 273 | 207 | +125 | 170 | 46 | +123 | +45.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ch-h2h-mine-ea652ef-p2 | move | 421 | 100 (24%) | 75 (18%) | 56 (13%) | 265 (63%) |
| ch-h2h-mine-ea652ef-p2 | objective | 342 | 59 (17%) | 47 (14%) | 47 (14%) | 236 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: ch-h2h-mine-ea652ef-p3

### Scorecard: ch-h2h-mine-ea652ef-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 2 | 0 | 2 | 0 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | yes | 14 | 2 | 2 | 2 | 1 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 1 | 3 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 15 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 1 | 4 | 3 | 1 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 2 | 1 | 3 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 1 | 1 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | no | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 2 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 7 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 5 | 2 | 2 | 0 | 0 | 0 | 771 |
| L0516 | 6 | 1 | Opponent | no | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 1 | 2 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 6 | 0 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 1 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | yes | 1 | - | 0 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 3 | - | 0 | 4 | 1 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 970 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 1 | 1 | 2 | 1 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 8 | 2 | 8 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 7 | 6 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 1 | 0 | 0 | 195 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 1 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 2 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 7 | - | 2 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 4 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 6 | 2 | 1 | 1 | 2 | 0 | 0 | 123 |
| L1422 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 1 | 0 | 0 | 72 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 2 | 1 | 3 | 0 | 0 | 0 | 750 |
| L1633 | 1 | 1 | Mine | yes | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 1 | 0 | 0 | 549 |
| L1731 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 4 | 2 | 1 | 1 | 3 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 8 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 235 |
| L1932 | 6 | 1 | Opponent | no | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | - | 1 | 5 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 1 | 6 | 0 | 1 | 0 | 0 | 297 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | no | - | 2 | 2 | 0 | 1 | 0 | 0 | 255 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 8 | 1 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 7 | 2 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | 2 | 3 | 0 | 2 | 0 | 0 | 287 |
| L2832 | 6 | 1 | Opponent | yes | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 1 | 0 | 0 | 0 | 549 |
| **Average** | | | Mine | 31% | 3.2 | 2.6 | 2.5 | 1.0 | 0.4 | 0.0 | 0.0 | 300.1 |
| **Average** | | | Opponent | 28% | 2.5 | 2.2 | 2.8 | 1.7 | 0.7 | 0.0 | 0.0 | 181.7 |

### KPIs: ch-h2h-mine-ea652ef-p3

Rules off - Opponent only: CHARGE BAND, HONEST WORTH, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (40 of 179) | 12% (22 of 177) | 17% (62 of 356) |
| Winner chose to follow up after the loser gave ground |  | 96% (70 of 73); on the table 96% | 100% (47 of 47); on the table 100% | 98% (117 of 120); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 82% (9 of 11); on the table 82% | 81% (13 of 16); on the table 81% | 81% (22 of 27); on the table 81% |
| Winner chose to pursue after the loser fled |  | 75% (18 of 24); on the table 88% | 52% (17 of 33); on the table 64% | 61% (35 of 57); on the table 74% |
| Winner chose to follow up or pursue (all three) |  | 90% (97 of 108); on the table 93% | 80% (77 of 96); on the table 84% | 85% (174 of 204); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 29% (100 of 342) | 35% (67 of 192) | 31% (167 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (100 of 211) | 47% (67 of 142) | 47% (167 of 353) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 32% (61 of 192) | 27% (37 of 138) | 30% (98 of 330) |
|     round 1 |  | 16% (5 of 32) | 35% (8 of 23) | 24% (13 of 55) |
|     rounds 2+ |  | 35% (56 of 160) | 25% (29 of 115) | 31% (85 of 275) |
|   other wizards | 50%+ | 26% (39 of 150) | 56% (30 of 54) | 34% (69 of 204) |
|     round 1 |  | 32% (8 of 25) | 22% (2 of 9) | 29% (10 of 34) |
|     rounds 2+ |  | 25% (31 of 125) | 62% (28 of 45) | 35% (59 of 170) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 47% (7 of 15) | 45% (25 of 55) | 46% (32 of 70) |
| Points that never fought | lower | 41% (28174 of 68801) | 39% (28360 of 71990) | 40% (56534 of 140791) |
|   infantry points that never fought | lower | 50% (7049 of 14174) | 58% (8237 of 14220) | 54% (15286 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (150 of 272) | 57% (163 of 285) | 56% (313 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.5 uses a game | 96% (23 of 24); 2.2 uses a game | 92% (45 of 49); 1.8 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.4 uses a game | 50% (3 of 6); 0.2 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 50% (7 of 14); 0.2 uses a game | 56% (19 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30671 of 59391) | 51% (32878 of 64043) | 51% (63549 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.9 (14%) | 1.1 (32%) | 2.1 (20%) |
| MARCHED: its unit marched | 1.5 (23%) | 0.7 (21%) | 2.2 (22%) |
| CHARGED: its unit charged | 0.5 (7%) | 0.1 (3%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.8 (27%) | 0.9 (25%) | 2.7 (26%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.1 (17%) | 0.5 (15%) | 1.7 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (8%) | 0.0 (0%) | 0.6 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.1 | 2.1 | 4.6 | 0.7 | 1.5 |
| not cast | 4.3 | 1.6 | 4.1 | 10.2 | 2.6 | 19.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.8 (52%) | 0.5 (13%) | 2.1 (20%) | 0.3 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (22%) | 0.5 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (12%) | 0.8 (19%) | 2.7 (26%) | 0.5 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) | 0.1 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (1%) | 0.2 (1%) |
| GONE: slain | 1.3 (31%) | 0.3 (20%) | 1.0 (24%) | 1.7 (16%) | 0.5 (19%) | 3.5 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (12%) | 0.0 (0%) | 0.3 (8%) | 0.6 (5%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.6 (22%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (45%) | 0.2 (12%) | 1.1 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 56% (22 of 39) | 55% (11 of 20) | 56% (33 of 59) |
| the unit moved after it | 68% (15 of 22) | 91% (10 of 11) | 76% (25 of 33) |
| it charged on its next turn | 9% (2 of 22) | 18% (2 of 11) | 12% (4 of 33) |
| the enemy charged it first | 23% (5 of 22) | 18% (2 of 11) | 21% (7 of 33) |
| it fought by the end of its next turn | 5% (1 of 22) | 18% (2 of 11) | 9% (3 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (3 of 22) | 0% (0 of 11) | 9% (3 of 33) |
| none of these (no charge, no fight, no charge escaped) | 59% (13 of 22) | 64% (7 of 11) | 61% (20 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (521 of 770) | 58% (353 of 613) | 63% (874 of 1383) |
|   cavalry | 67% (42 of 63) | 59% (66 of 112) | 62% (108 of 175) |
|   character | 62% (61 of 98) | 24% (28 of 117) | 41% (89 of 215) |
|   chariot | 48% (47 of 97) | 56% (18 of 32) | 50% (65 of 129) |
|   infantry | 59% (123 of 210) | 67% (173 of 260) | 63% (296 of 470) |
|   monster | 40% (14 of 35) | 100% (6 of 6) | 49% (20 of 41) |
|   war machine | 88% (234 of 267) | 72% (62 of 86) | 84% (296 of 353) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (28%) | 1.5 (21%) | 3.4 (24%) |
| CHARGED: it charged | 1.0 (14%) | 1.5 (20%) | 2.5 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.4 (6%) | 0.6 (8%) | 1.0 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.1 (15%) | 1.1 (15%) | 2.2 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (7%) | 0.9 (13%) | 1.4 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (21%) | 0.9 (13%) | 2.4 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.4 (5%) | 0.6 (4%) |
| OTHER BAR | 0.2 (3%) | 0.2 (3%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 1.3 | 78% | 6.3 pts | 30 pts |
| character | 2.8 | 0.8 | 78% | 5.0 pts | 14 pts |
| chariot | 1.8 | 0.9 | 62% | 15.7 pts | 28 pts |
| infantry | 12.7 | 4.8 | 72% | 11.2 pts | 143 pts |
| monster | 0.7 | 0.0 | 96% | 2.5 pts | 2 pts |
| war machine | 8.6 | 8.5 | 53% | 28.1 pts | 242 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 5.1 | 4.5 |
| Charges that made contact a game | 3.0 | 3.8 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.88 declared, 0.65 contact (26 units) | 1.00 declared, 0.89 contact (18 units) | 0.93 declared, 0.75 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 0.75 contact (4 units) | 1.22 declared, 0.89 contact (9 units) | 1.23 declared, 0.85 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.39 contact (223 units) | 0.57 declared, 0.42 contact (271 units) | 0.55 declared, 0.40 contact (494 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (38 of 77) | 60% (9 of 15) | 20% (2 of 10) | 48% (49 of 102) |
| Character in a unit | 91% (30 of 33) | 60% (9 of 15) | 40% (2 of 5) | 77% (41 of 53) |
| Character on its own | 80% (35 of 44) | 41% (17 of 41) | 41% (29 of 70) | 52% (81 of 155) |
| Chariot | 73% (8 of 11) | 33% (4 of 12) | - | 52% (12 of 23) |
| Infantry | 54% (38 of 70) | 48% (20 of 42) | 20% (1 of 5) | 50% (59 of 117) |
| Monster | 65% (22 of 34) | 86% (6 of 7) | - | 68% (28 of 41) |
| Monstrous | 60% (6 of 10) | 73% (8 of 11) | - | 67% (14 of 21) |
| War Machines | 63% (27 of 43) | 100% (2 of 2) | - | 64% (29 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (15 of 15); on the table 100% | 15% (14 of 96) | 12% | 55% (12 of 22) | 100% (6 of 6); 3.2 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 89% (8 of 9); on the table 89% | 56% (20 of 36) | 40% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 67% (4 of 6); on the table 67% | - | 78% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (4 of 5); on the table 80% | 60% (18 of 30) | 68% | 59% (35 of 59) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 74% (14 of 19); on the table 89% | 31% (60 of 192) | 48% | 49% (36 of 74) | 94% (17 of 18); 5.1 uses a game | 50% (2 of 4); 0.2 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 86% (18 of 21); on the table 86% | 21% (9 of 42) | 45% | 52% (28 of 54) | 78% (7 of 9); 3.7 uses a game | 50% (6 of 12); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 89% (8 of 9); on the table 100% | - | 45% | 28% (5 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (7 of 7); on the table 100% | 67% (4 of 6) | 49% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 27% | 43% (3 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 89% (8 of 9); on the table 100% | 8% (1 of 12) | 1% | 81% (13 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 33% (2 of 6); on the table 67% | 33% (4 of 12) | 65% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 89% (16 of 18); on the table 89% | 17% (1 of 6) | 30% | 58% (15 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 96% (27 of 28); on the table 96% | 39% (21 of 54) | 25% | 52% (24 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 83% (35 of 42); on the table 83% | 30% (9 of 30) | 31% | 54% (52 of 96) | 100% (4 of 4); 0.9 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 89% (8 of 9); on the table 89% | 50% (6 of 12) | 46% | 66% (41 of 62) | 91% (10 of 11); 6.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ch-h2h-mine-ea652ef-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (38) | 48% (36) | 48% (74) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.56 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.22 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.42 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.39 | 1.33 | 2.72 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.58 | 0.78 | 1.36 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.75 | 5.11 | 9.86 |

### Quality by phase: ch-h2h-mine-ea652ef-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 63% (74 of 118) | 43% (70 of 161) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (112 of 379) | 54% (105 of 193) |
| Strategy | Close-in objectives charged next turn | 18% (26 of 148) | 13% (30 of 226) |
| Strategy | Support requests answered (helper made contact too) | 45% (5 of 11) | 62% (16 of 26) |
| Strategy | Hexes on a unit its side charged or shot that turn | 59% (10 of 17) | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | 42% (15 of 36) | 25% (11 of 44) |
| Strategy | Lone characters that fought | 71% (70 of 99) | 72% (65 of 90) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 300.1 | 181.7 |
| Movement | Fights charged into per game | 2.8 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 89, net +28 | 11 of 92, net -16 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 89, net +16 | 13 of 92, net -13 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 89, net +104 | 13 of 92, net +117 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 of 89, net +91 | 28 of 92, net +233 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.4 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (108 of 304) | 41% (140 of 340) |
| Shooting | Points destroyed by shooting units | 61.5 | 55.1 |
| Shooting | War machine shots | 6.5 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (116 of 234) | 34% (26 of 76) |
| Shooting | Points destroyed by war machines | 102.1 | 32.3 |
| Magic | Magic missiles cast | 1.9 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (24 of 68) | 35% (14 of 40) |
| Magic | Wounds caused by magic missiles | 3.2 | 1.8 |
| Magic | Wounds caused by other spells | 1.3 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 76.2 | 40.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.5 / 0.1 | 1.9 / 0.2 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 357.9 | 361.7 |
| Combat | Points run down | 57.4 | 136.9 |
| Combat | Net points per charged fight, damage counted | +74 | +100 |
| Combat | Net per 100 charger points, damage counted | +27.7 | +33.1 |
| Combat | First round won (charged fights) | 78% | 74% |
| Combat | Net points per charged fight | +66 | +89 |
| Combat | Net points per supported fight / lone fight | +37 / +68 | +275 / +46 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 102 | 49 of 111 |
| Game | Points lost | 787.7 | 723.2 |
| Game | VP from objectives | 548.3 | 584.7 |
| Game | Lone holders (player turns) | 3.2 | 2.5 |

- Mine won / drew / lost: 11 / 10 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -115 VP
- The side that went first won 12 of 26 games with a winner
- Points traded per game (both sides' losses): 1511
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ch-h2h-mine-ea652ef-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 16.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +7.5 | 0.0 | 7.4 | 0.7 | +7.5 | 0.0 | 32.9 |
| BEST FACING | 0.5 | +15.2 | 0.0 | 3.4 | 0.7 | +22.2 | 0.0 | 40.6 |
| BEST FIRST | 4.5 | +204.0 | 166.6 | 101.5 | 3.2 | +134.4 | 192.6 | 81.7 |
| BEST MOVE FOR SHOOTERS | 0.7 | +61.2 | 0.0 | 34.7 | - | - | - | - |
| BEST OVERALL | 0.4 | +28.1 | 0.0 | 8.8 | 0.6 | +37.0 | 0.0 | 18.2 |
| BEST PREY | 0.7 | +31.4 | 29.6 | 14.7 | 0.8 | +50.1 | 30.4 | 4.7 |
| BEST PRIZE | 0.0 | -0.6 | 0.8 | 0.0 | 0.1 | +2.0 | 10.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.4 | 0.0 | 0.0 | 0.2 | -0.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 10.3 | 0.0 |
| BLOCKED WHEEL | 0.3 | -0.1 | 0.0 | 6.6 | 0.5 | +8.6 | 0.0 | 2.9 |
| BLOWS WHERE AIMED | 0.1 | -11.5 | 7.9 | 9.9 | - | - | - | - |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 4.2 |
| CANNON PLAN MISSED | - | - | - | - | 0.1 | +0.0 | 25.8 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 1.2 | +66.9 | 74.7 | 11.2 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -1.7 | 2.9 | 0.0 | 0.1 | -7.6 | 1.1 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -1.6 | 36.3 | 4.5 | 0.1 | -2.1 | 6.1 | 3.2 |
| CAST JOB | 1.1 | +45.7 | 133.6 | 2.2 | 0.4 | +10.8 | 19.8 | 13.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +28.5 | 3.2 | 8.9 | 0.1 | +1.3 | 3.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 46.1 | 0.4 | +0.0 | 0.0 | 22.9 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.2 | -0.8 | 6.3 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +1.4 | 8.9 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 26.9 | 12.1 | - | - | - | - |
| CHARGE NOW FIRST | 2.2 | +0.0 | 214.2 | 40.8 | 2.8 | +0.0 | 243.8 | 80.3 |
| CHARGE NOW WEIGHED | 0.6 | -60.3 | 29.1 | 6.9 | 0.3 | -26.2 | 15.7 | 16.4 |
| CHARGER SLAIN LOST | 0.3 | -13.8 | 49.7 | 9.1 | - | - | - | - |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -0.3 | 5.2 | 11.1 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 22.7 | 2.8 |
| COMBAT PIVOT | 0.4 | +0.0 | 11.1 | 41.7 | 0.7 | +0.0 | 68.2 | 37.9 |
| CONVEYANCE SEARCH | 1.0 | +142.0 | 55.1 | 48.8 | 0.5 | +41.1 | 7.9 | 18.3 |
| COUNTER-CHARGE COVER | 9.2 | +840.6 | 0.0 | 212.4 | 7.1 | +566.6 | 0.0 | 188.7 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 25.3 | 0.0 | 0.1 | +0.0 | 5.2 | 6.6 |
| DEFENSIVE FLOOR | 0.1 | +3.7 | 5.4 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.0 | 1.8 | 0.0 | 0.2 | +4.2 | 15.6 | 2.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.7 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | 9.8 | +0.0 | 710.1 | 136.1 | - | - | - | - |
| FACE THE CAST | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +102.3 | 0.0 | 34.2 | 1.3 | +87.5 | 0.0 | 55.8 |
| FALLBACK BY WORTH | 5.1 | +43.6 | 0.0 | 64.5 | 5.9 | +97.4 | 0.0 | 54.2 |
| FIGHT LIFT | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.6 | 1.7 | 1.7 |
| FIRE AND FLEE | 0.0 | +0.4 | 0.0 | 2.2 | - | - | - | - |
| FIRE IN ORDER | 0.8 | +0.0 | 61.5 | 14.4 | - | - | - | - |
| FIRE PLAN | 15.8 | +131.4 | 1044.6 | 249.0 | - | - | - | - |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 141.1 | 5.2 | +0.0 | 0.0 | 140.1 |
| FOCUS FIRE | - | - | - | - | 0.0 | +1.6 | 0.0 | 1.7 |
| FOLLOW UP WEIGHED | 1.2 | +163.1 | 0.0 | 38.8 | 1.1 | +177.9 | 0.0 | 42.5 |
| FRIENDS SHOTS CHECKED | 0.3 | +20.0 | 0.0 | 5.7 | 0.2 | +14.3 | 0.0 | 7.6 |
| GIVES UP | 0.1 | -0.9 | 0.0 | 0.0 | 0.1 | -2.6 | 10.8 | 2.9 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.7 | 15.6 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 15.6 | 10.5 | 0.1 | +0.0 | 5.2 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 23.7 | 12.2 |
| HILL BY ITS CHANCE | 0.2 | -30.0 | 0.0 | 1.8 | 0.5 | -54.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 9.8 | +1270.0 | 710.1 | 136.1 | - | - | - | - |
| HONEST WORTH | 7.2 | -122.4 | 382.9 | 182.7 | - | - | - | - |
| HORN WORTH | - | - | - | - | 0.1 | +1.8 | 0.0 | 14.0 |
| HUNT ADVANCE | 0.1 | +2.4 | 0.0 | 0.0 | 0.2 | +4.9 | 3.5 | 4.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 3.0 | 0.1 | +0.0 | 0.0 | 2.9 |
| HUNT IN PAIRS | 0.5 | +12.9 | 0.0 | 5.4 | 0.5 | +16.6 | 0.0 | 17.3 |
| HUNT KEPT | 0.1 | +1.8 | 0.0 | 0.0 | 0.1 | +1.6 | 6.9 | 2.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 3.0 | 0.1 | +12.7 | 0.0 | 6.1 |
| HUNT THE GUNS | 0.1 | +20.1 | 0.0 | 0.0 | 0.2 | +58.1 | 11.1 | 4.1 |
| INVITES THE FIGHT | 1.4 | +23.7 | 62.0 | 31.0 | 1.6 | +29.1 | 68.6 | 57.1 |
| JOINT CHARGE PLAN | 0.1 | +1.0 | 9.3 | 12.1 | 0.2 | +4.3 | 5.2 | 3.2 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.2 | +2.6 | 0.0 | 7.5 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.1 | 2.9 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 121.5 | 40.2 | 1.9 | +57.5 | 96.6 | 9.7 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | 1.4 | +12.5 | 206.8 | 33.7 | - | - | - | - |
| KILLS COUNT | 1.6 | +83.8 | 122.6 | 17.4 | 2.0 | +92.1 | 185.1 | 47.7 |
| KILLS COUNT NEXT TURN | 4.9 | +152.2 | 182.7 | 130.1 | 7.8 | +227.2 | 276.0 | 181.2 |
| LONE CHARACTER SAFE SPOT | 0.4 | +13.0 | 6.9 | 25.7 | 0.4 | +13.1 | 34.1 | 15.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 6.9 | 0.0 | 0.3 | +0.0 | 2.3 | 11.8 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.6 | 20.9 | 0.0 | 0.2 | -0.4 | 10.5 | 0.0 |
| LOST CHARGE | 2.8 | -41.1 | 134.2 | 86.4 | 2.6 | -37.4 | 97.4 | 74.7 |
| LURE BY WHAT IT DRAWS | 0.0 | -2.3 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.1 | +116.5 | 39.6 | 34.1 | 1.0 | +73.4 | 22.6 | 8.1 |
| MANOEUVRE | 0.4 | +8.1 | 0.0 | 6.3 | 0.1 | +2.4 | 0.0 | 6.5 |
| MARCH AT ESCAPER | 0.2 | +1.3 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +36.1 | 0.0 | 25.9 | 0.9 | +53.8 | 0.0 | 26.1 |
| MARCH ODDS | 0.2 | +20.4 | 9.4 | 0.0 | 0.4 | +27.7 | 10.9 | 0.0 |
| MARCH OVER CASTS | 0.6 | +55.1 | 0.0 | 38.9 | 0.4 | +26.7 | 0.0 | 6.5 |
| MAX FOR POSITIONING | 4.9 | +162.0 | 0.0 | 99.4 | 4.4 | +186.1 | 0.0 | 143.7 |
| MISSILES IN THE FIRE PLAN | 1.8 | +11.9 | 98.4 | 24.0 | - | - | - | - |
| MISSILES IN THE MOVE | 4.1 | +156.0 | 0.0 | 71.0 | 4.1 | +62.4 | 0.0 | 73.9 |
| MISSILES NEXT TURN | 5.3 | +103.8 | 0.0 | 127.8 | 5.1 | +52.1 | 0.0 | 90.8 |
| MODEL FACING | 0.1 | +29.7 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 9.3 | 40.6 | 0.1 | +0.0 | 17.9 | 0.0 |
| MOVE AND CAST | 0.6 | +31.0 | 0.0 | 0.0 | 0.4 | +22.6 | 0.0 | 11.7 |
| MOVE SPELL IN RANGE | 0.4 | +11.2 | 0.0 | 21.1 | 0.0 | +1.3 | 0.0 | 6.5 |
| MOVE SPELL OUT OF RANGE | 0.4 | -24.6 | 6.6 | 55.3 | 0.2 | -4.0 | 0.0 | 13.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 25.0 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 2.8 | +248.6 | 187.3 | 131.0 | 4.9 | +422.2 | 177.2 | 94.3 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +8.2 | 0.0 | 0.0 | 0.1 | +0.0 | 11.1 | 0.0 |
| NO RALLY LEFT | 0.1 | +0.1 | 0.0 | 1.4 | - | - | - | - |
| NOT NEEDED | 0.1 | -6.8 | 22.2 | 5.9 | 0.2 | -17.9 | 35.9 | 0.0 |
| NOT TURNED | 4.8 | +81.5 | 0.0 | 126.3 | 5.1 | +58.2 | 0.0 | 137.1 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 32.2 | 0.6 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 15.6 | -823.9 | 0.0 | 319.1 | 14.8 | -896.1 | 0.0 | 315.7 |
| ONE YARDSTICK | 16.6 | -568.9 | 644.9 | 309.9 | - | - | - | - |
| OPENS A LANE | 0.2 | +0.4 | 42.6 | 0.0 | 0.1 | +1.4 | 13.0 | 6.5 |
| OPENS UP | 0.1 | +1.2 | 0.0 | 0.0 | 0.2 | +28.7 | 10.1 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.7 | 45.2 | 8.4 | 0.6 | +7.7 | 45.8 | 15.8 |
| PATHS CROSS | 1.9 | +136.5 | 0.0 | 34.8 | 2.8 | +250.6 | 0.0 | 39.2 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.2 | 0.0 | 4.2 | 0.1 | -1.6 | 0.0 | 22.0 |
| PLAN RESULT | 35.8 | +1375.9 | 1436.2 | 912.6 | 37.3 | +1402.3 | 1329.4 | 1017.2 |
| PURSUES BIG PREY | 0.0 | -2.9 | 0.0 | 0.0 | 0.1 | -24.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +0.5 | 0.0 | 3.4 | 0.1 | +11.5 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 1.5 | 0.1 | +5.9 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.4 | +13.0 | 0.0 | 14.2 | 1.5 | +22.4 | 0.0 | 58.9 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.9 | 0.0 | 4.7 | 0.4 | -18.5 | 3.1 | 5.8 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.4 | 0.0 | 1.8 | 0.7 | -16.3 | 0.0 | 8.1 |
| REDIRECT COUNTER | 1.9 | +148.5 | 0.0 | 37.5 | 3.9 | +340.3 | 0.0 | 61.8 |
| REDIRECT WEIGHED | 0.2 | +0.7 | 3.7 | 7.6 | 0.3 | +2.0 | 13.2 | 1.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 10.3 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +10.1 | 0.0 | 4.2 | 0.8 | +30.2 | 0.0 | 4.9 |
| RESTRAINS TO SHOOT | 0.2 | +13.5 | 0.0 | 0.0 | 0.0 | +3.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +113.3 | 212.8 | 40.3 | 2.7 | +64.9 | 220.2 | 77.8 |
| SAFER THAN THE JOB | 0.6 | +28.6 | 0.0 | 3.1 | 0.8 | +56.8 | 0.0 | 6.4 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | +2.7 | 0.0 | 0.0 | 0.4 | -36.2 | 0.0 | 1.8 |
| SEARCH SPOT | 2.5 | +94.5 | 0.0 | 58.4 | 2.4 | +136.5 | 0.0 | 37.4 |
| SELF MOVE SPELL | 0.4 | +65.4 | 0.0 | 18.1 | 0.2 | +65.7 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.4 | +140.3 | 75.5 | 56.7 | 1.9 | +152.3 | 49.5 | 21.0 |
| SET-UP ANY TARGET | 0.7 | +121.2 | 35.6 | 35.6 | 0.1 | +13.8 | 6.5 | 13.0 |
| SHOOTERS ARE THREATS | 1.8 | +110.0 | 166.4 | 21.2 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 1.9 | +53.2 | 0.0 | 42.5 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.9 | +35.3 | 49.0 | 24.1 | 0.7 | +20.9 | 25.4 | 1.8 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OPTIONS | 15.1 | +0.0 | 897.6 | 292.8 | 10.1 | +0.0 | 455.8 | 192.2 |
| SHOT REPLANNED | - | - | - | - | 0.2 | +0.0 | 56.1 | 0.0 |
| SHOTS IN THE MOVE | 13.8 | +584.7 | 0.0 | 217.4 | 9.2 | +348.6 | 0.0 | 183.8 |
| SPELL SETS UP CHARGE | 0.9 | +174.1 | 35.6 | 35.6 | 0.1 | +13.8 | 6.5 | 13.0 |
| SPELL WORTH | 1.1 | +19.7 | 52.5 | 63.2 | 2.5 | +26.8 | 98.4 | 80.8 |
| SPELLS IN THE FIGHT | 0.5 | +0.6 | 39.0 | 14.0 | - | - | - | - |
| STABLE ROLE | 10.3 | +0.0 | 389.6 | 165.9 | 8.9 | +0.0 | 309.3 | 151.5 |
| STANDS TO CAST | 0.1 | +3.0 | 7.7 | 13.9 | - | - | - | - |
| STAY WEIGHED | 0.0 | +0.0 | 0.0 | 1.8 | - | - | - | - |
| STAY WORTH | 15.7 | +95.2 | 580.7 | 203.9 | - | - | - | - |
| STOPS | 0.1 | +2.0 | 0.0 | 0.0 | 0.1 | +1.7 | 11.1 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.3 | +16.1 | 0.0 | 1.7 | 0.4 | +33.2 | 0.0 | 1.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.2 | -41.7 | 335.7 | 97.8 | 6.3 | -35.2 | 406.5 | 91.4 |
| SUPPORTS | 3.4 | +49.7 | 168.6 | 50.1 | 4.0 | +36.8 | 219.1 | 38.4 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -5.9 | 17.0 | 21.7 | 0.1 | -3.2 | 1.7 | 3.8 |
| SURE REACH TOGETHER | 0.5 | +5.1 | 20.4 | 35.6 | 0.8 | +0.1 | 33.0 | 23.7 |
| THROUGH LINE OF FIRE | 0.3 | +10.3 | 0.0 | 1.7 | 0.1 | +5.5 | 0.0 | 0.5 |
| TURN WORTH | 0.4 | -25.2 | 39.8 | 0.0 | 0.4 | -37.4 | 30.1 | 0.0 |
| TWO OR MORE ARRIVE | 0.4 | +3.1 | 28.0 | 10.2 | 0.4 | +2.8 | 0.0 | 0.5 |
| WAIT AFTER COSTS | 6.1 | -295.1 | 285.1 | 181.2 | 8.3 | -441.6 | 287.7 | 209.3 |
| WALKS TO THE FIGHT | 1.5 | +25.4 | 33.3 | 13.8 | 1.2 | +25.2 | 21.4 | 25.4 |
| WAR ENGINE CHARGES | 0.2 | +16.8 | 17.4 | 22.4 | 0.0 | +0.2 | 1.7 | 2.1 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 47.9 | 11.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 0.9 | +43.2 | 80.6 | 48.6 | 0.9 | +45.2 | 51.6 | 40.5 |
| WHO HITS BACK | 0.2 | +5.9 | 0.0 | 0.0 | 0.2 | +38.7 | 0.0 | 5.4 |
| WHOLE FIGHT | 0.3 | +18.3 | 37.9 | 7.1 | 0.4 | -10.0 | 56.6 | 1.4 |
| WHOLE FIGHT GAIN | 0.3 | +30.6 | 53.3 | 5.9 | 0.5 | +45.2 | 70.6 | 14.1 |
| WIDER SPREAD | 2.1 | -5.8 | 181.8 | 58.0 | - | - | - | - |

### Rule changes: ch-h2h-mine-ea652ef-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1097 | 1097 | 1097 | 30.47 | -61917 | -56.4 |
| BEST FIRST | 278 | 278 | 278 | 7.72 | +12183 | +43.8 |
| SEARCH SPOT | 176 | 176 | 174 | 4.83 | +8347 | +48.0 |
| MOVE TO CHARGE | 279 | 279 | 170 | 4.72 | +11310 | +66.5 |
| PATHS CROSS | 169 | 169 | 169 | 4.69 | +13935 | +82.5 |
| COUNTER-CHARGE COVER | 584 | 327 | 147 | 4.08 | +9340 | +63.5 |
| FIRE PLAN | 569 | 569 | 145 | 4.03 | +3001 | +20.7 |
| KILLS COUNT NEXT TURN | 457 | 457 | 111 | 3.08 | +2508 | +22.6 |
| FACES THE THREAT | 98 | 98 | 98 | 2.72 | +6834 | +69.7 |
| SUPPORTS | 266 | 266 | 95 | 2.64 | +728 | +7.7 |
| EVERY WOUND COUNTS | 354 | 354 | 81 | 2.25 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 81 | 81 | 81 | 2.25 | +12274 | +151.5 |
| FALLBACK BY WORTH | 395 | 395 | 80 | 2.22 | +5076 | +63.4 |
| ARTILLERY RE-ROLL WEIGHED | 74 | 74 | 74 | 2.06 | +0 | +0.0 |
| WAIT AFTER COSTS | 520 | 520 | 73 | 2.03 | +1579 | +21.6 |
| SHOTS IN THE MOVE | 828 | 555 | 66 | 1.83 | +2123 | +32.2 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| ONE YARDSTICK | 597 | 261 | 54 | 1.50 | +773 | +14.3 |
| WALKS TO THE FIGHT | 97 | 97 | 51 | 1.42 | +634 | +12.4 |
| REDIRECT COUNTER | 209 | 124 | 49 | 1.36 | +3908 | +79.8 |
| SAFER THAN THE JOB | 49 | 49 | 49 | 1.36 | +3075 | +62.7 |
| RISK BY ARC | 183 | 175 | 48 | 1.33 | +1189 | +24.8 |
| MAX FOR POSITIONING | 334 | 189 | 46 | 1.28 | +536 | +11.7 |
| MISSILES IN THE MOVE | 293 | 166 | 46 | 1.28 | +808 | +17.6 |
| SET UP TOGETHER | 120 | 104 | 46 | 1.28 | +3396 | +73.8 |
| BEST FACING | 43 | 43 | 43 | 1.19 | +1347 | +31.3 |
| MARCH CHECK | 51 | 48 | 43 | 1.19 | +2226 | +51.8 |
| CHARGE NOW FIRST | 180 | 180 | 41 | 1.14 | -2494 | -60.8 |
| COMBAT PIVOT | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| RESERVE FALL BACK | 39 | 39 | 39 | 1.08 | +1452 | +37.2 |
| BEST OVERALL | 36 | 36 | 36 | 1.00 | +2341 | +65.0 |
| MOVE AND CAST | 36 | 36 | 36 | 1.00 | +1929 | +53.6 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +2865 | +81.9 |
| HONEST THREAT | 354 | 354 | 35 | 0.97 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| RANDOM MOVE BY FIGURES | 70 | 70 | 32 | 0.89 | +1274 | +39.8 |
| BLOCKED WHEEL | 29 | 29 | 29 | 0.81 | +306 | +10.6 |
| KILLS COUNT | 130 | 126 | 29 | 0.81 | +1221 | +42.1 |
| FIRE IN ORDER | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 27 | 27 | 27 | 0.75 | +1773 | +65.7 |
| SHOOTS FROM THE BEST SPOT | 58 | 58 | 26 | 0.72 | +851 | +32.7 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 24 | 24 | 24 | 0.67 | +2203 | +91.8 |
| CAST JOB | 57 | 57 | 23 | 0.64 | +885 | +38.5 |
| KEEPS THE TARGET | 50 | 50 | 23 | 0.64 | -138 | -6.0 |
| MARCH ODDS | 24 | 24 | 23 | 0.64 | +510 | +22.2 |
| INVITES THE FIGHT | 108 | 108 | 20 | 0.56 | +150 | +7.5 |
| KEEPS ITS TARGET | 122 | 120 | 20 | 0.56 | +312 | +15.6 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.56 | +660 | +33.0 |
| MANOEUVRE | 20 | 20 | 19 | 0.53 | +381 | +20.0 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| STAY WORTH | 565 | 462 | 18 | 0.50 | +408 | +22.7 |
| FRIENDS SHOTS CHECKED | 16 | 16 | 16 | 0.44 | +1236 | +77.3 |
| MAKE SURE TOGETHER | 75 | 43 | 16 | 0.44 | +1186 | +74.2 |
| THROUGH LINE OF FIRE | 15 | 15 | 15 | 0.42 | +568 | +37.9 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +1237 | +82.5 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -25 | -1.9 |
| CASTING BLOCK | 14 | 14 | 13 | 0.36 | +556 | +42.8 |
| HONEST WORTH | 259 | 255 | 12 | 0.33 | +158 | +13.2 |
| WHOLE FIGHT GAIN | 30 | 28 | 12 | 0.33 | +869 | +72.4 |
| LOST CHARGE | 194 | 193 | 11 | 0.31 | +375 | +34.1 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -326 | -29.6 |
| WAR ENGINE JOBS | 28 | 28 | 11 | 0.31 | -600 | -54.6 |
| BEST PREY | 56 | 56 | 10 | 0.28 | +428 | +42.8 |
| MISSILES NEXT TURN | 373 | 217 | 10 | 0.28 | +31 | +3.1 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHOT REPLANNED | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +600 | +75.1 |
| SHOOTERS ARE THREATS | 65 | 65 | 8 | 0.22 | +0 | +0.0 |
| WEARS DOWN | 65 | 62 | 8 | 0.22 | +219 | +27.3 |
| CHAFF PASSED | 7 | 7 | 7 | 0.19 | -28 | -4.0 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +334 | +47.7 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| OPENS UP | 9 | 9 | 6 | 0.17 | +654 | +109.0 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -175 | -29.2 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 6 | 0.17 | +180 | +30.0 |
| SUPPORT NARROWED | 413 | 413 | 6 | 0.17 | -19 | -3.2 |
| WHOLE FIGHT | 26 | 25 | 6 | 0.17 | +295 | +49.1 |
| CHARGE BAND | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| HUNT IN PAIRS | 35 | 17 | 5 | 0.14 | +86 | +17.2 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -967 | -193.3 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SURE REACH TOGETHER | 45 | 34 | 5 | 0.14 | +48 | +9.5 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -411 | -102.8 |
| CARRIES OUT COUNTER | 4 | 4 | 4 | 0.11 | -332 | -82.9 |
| EDGE GIVE GROUND | 11 | 10 | 4 | 0.11 | +30 | +7.5 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +1068 | +267.1 |
| FACE THE CAST | 3 | 3 | 3 | 0.08 | +6 | +1.9 |
| NEEDED THERE | 5 | 5 | 3 | 0.08 | +0 | +0.0 |
| OVERRUNS AWAY | 33 | 29 | 3 | 0.08 | +15 | +5.1 |
| SCREEN BY WHAT IT SAVES | 20 | 20 | 3 | 0.08 | +28 | +9.4 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +44 | +22.1 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.1 |
| CANNON PLANNED TARGET | 44 | 44 | 2 | 0.06 | +101 | +50.4 |
| CARRIES OUT SET-UP | 12 | 12 | 2 | 0.06 | -132 | -66.2 |
| DEFENSIVE ARMY | 10 | 10 | 2 | 0.06 | -112 | -56.1 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +65 | +32.4 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 2 | 0.06 | -202 | -100.8 |
| MOVE SPELL IN RANGE | 14 | 9 | 2 | 0.06 | +22 | +11.2 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +2 | +0.8 |
| RAIDS THE BAGGAGE | 3 | 3 | 2 | 0.06 | +383 | +191.6 |
| SHOOTERS TO THE PRIMARY | 70 | 52 | 2 | 0.06 | +28 | +13.9 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +33 | +16.7 |
| BACKUP TARGETS | 62 | 19 | 1 | 0.03 | +1 | +1.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.8 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -133 | -133.2 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +4 | +4.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +27 | +26.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +58 | +58.0 |
| HUNT ADVANCE | 8 | 8 | 1 | 0.03 | +0 | +0.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MISSILES IN THE FIRE PLAN | 63 | 8 | 1 | 0.03 | +16 | +15.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +99 | +99.4 |
| REDIRECT BY WHAT IT STOPS | 35 | 35 | 1 | 0.03 | +45 | +45.1 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| STOPS | 4 | 4 | 1 | 0.03 | +7 | +7.1 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | -28 | -27.6 |
| TWO OR MORE ARRIVE | 26 | 21 | 1 | 0.03 | +1 | +0.8 |
| WIDER SPREAD | 75 | 71 | 1 | 0.03 | +0 | +0.0 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 11 | 11 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 54 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 379 | not checked | - | - | - | - |
| GIVES UP | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 16 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 25 | 25 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 11 | 11 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 29 | not checked | - | - | - | - |
| LONG SHOT | 17 | 16 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 37 | 37 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT NEEDED | 11 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 355 | 355 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2632 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 15 | 15 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 30 | not checked | - | - | - | - |
| SHOT OPTIONS | 905 | 905 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 37 | not checked | - | - | - | - |
| SPELL WORTH | 128 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 18 | 16 | 0 | 0.00 | - | - |
| STABLE ROLE | 690 | 688 | 0 | 0.00 | - | - |
| TURN WORTH | 30 | 29 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: ch-h2h-mine-ea652ef-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.94 | 13.08 | 59.0 |
| FALLBACK | gate | 0.69 | 0.86 | 33.2 |
| CHARGE NOW FIRST | rule | 0.50 | 0.58 | 63.9 |
| TURN GATE | gate | 0.36 | 0.47 | 43.6 |
| FIRE PLAN | rule | 0.44 | - | 49.6 |
| KEEPS THE TARGET | rule | 0.42 | - | 73.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.14 | 85.2 |
| WAR ENGINE JOBS | rule | 0.17 | 0.14 | 54.6 |
| AFTERMATH BAND | gate | 0.17 | 0.11 | 1.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.19 | 0.08 | 32.5 |
| PATHS CROSS | rule | 0.14 | 0.06 | 35.6 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.08 | 10.9 |
| CHAFF PASSED | rule | - | 0.17 | 4.6 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 57.8 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.06 | 29.2 |
| SUPPORT NARROWED | rule | 0.14 | 0.03 | 3.2 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 1.5 |
| PURSUES BIG PREY | rule | 0.03 | 0.11 | 193.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | - | 39.5 |
| BEST PRIZE | rule | 0.03 | 0.08 | 102.8 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 62.6 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.08 | 82.9 |
| SUPPORT REQUEST | gate | 0.08 | 0.03 | 43.6 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 66.2 |
| DEFENSIVE ARMY | rule | 0.03 | 0.03 | 56.1 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 4.3 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.03 | 100.8 |
| MARCH ODDS | rule | 0.03 | 0.03 | 3.2 |
| NO REASON | gate | 0.06 | - | 33.4 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 16.6 |
| RULE SWITCHED OFF | gate | - | 0.06 | 7.1 |
| SAFER THAN THE JOB | rule | - | 0.06 | 10.9 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | - | 17.5 |
| CATCH ODDS | rule | 0.03 | - | 1.8 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 133.2 |
| FALLBACK BY WORTH | rule | - | 0.03 | 38.8 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 1.3 |
| SUPPORT JOB KEPT | rule | - | 0.03 | 27.6 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 4.8 |

### Plans: ch-h2h-mine-ea652ef-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.3 | 16% | 403 | 296 | 74% |
| Mine | charge | 2.7 | 67% | 229 | 296 | 129% |
| Mine | close in | 4.1 | 24% | 268 | 102 | 38% |
| Mine | hold | 4.7 | 36% | 282 | 0 | 0% |
| Mine | join | 0.5 | 100% | 11 | 0 | 0% |
| Mine | shoot | 8.8 | 60% | 315 | 681 | 216% |
| Mine | support | 3.7 | 93% | 37 | 0 | 0% |
| Opponent | advance | 12.9 | 16% | 370 | 355 | 96% |
| Opponent | charge | 4.1 | 61% | 476 | 430 | 90% |
| Opponent | close in | 6.2 | 27% | 449 | 212 | 47% |
| Opponent | hold | 3.8 | 27% | 270 | 0 | 0% |
| Opponent | join | 0.8 | 100% | 30 | 0 | 0% |
| Opponent | shoot | 4.6 | 63% | 168 | 406 | 241% |
| Opponent | support | 4.8 | 91% | 29 | 0 | 0% |

### Packages: hunt the guns, ch-h2h-mine-ea652ef-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 362 | 0 | 0% | 34 |
| Opponent | 0.2 | 6 | 1 | 20% | 20% | 0% | 2.0 | 369 | 91 | 20% | 99 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 362 | 0 | 0% | 27 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 62 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 142 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 130 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 283 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 270 |
| Tomb Kings of Khemri | 0.7 | 4 | 1 | 0% | 0% | 0% | - | 377 | 0 | 0% | 56 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 472 | 457 | 100% | 15 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 41 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 243 | 0 | 0% | 56 |

### Battle groups: ch-h2h-mine-ea652ef-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.2 | 23% | 49% | 12% | 22% | 36% | 14% | 9% | 41% | 0% |
| Mine | REDIRECT COUNTER | 1.9 | 24% | 59% | 24% | 0% | 8% | 8% | 23% | 62% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.1 | 19% | 53% | 16% | 38% | 24% | 15% | 5% | 56% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 24% | 85% | 12% | 50% | 38% | 0% | 7% | 55% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ch-h2h-mine-ea652ef-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 34 | 34 (34) | 7 | 26 | 57 | 35% | 2.4 | 47 (21) | 0 (4) | 10 (9) | 50 (24) | 0 (10) |
| Mine | Character | 118 | 42 (118) | 42 | 0 | 41 | 20% | 2.2 | 58 (38) | 40 (55) | 19 (7) | 40 (56) | 54 (44) |
| Mine | Clean-up | 20 | 48 (20) | 12 | 36 | 43 | 35% | 2.5 | 54 (5) | 27 (13) | 273 (2) | 58 (14) | 28 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 46 (44) | 27 | 19 | 48 | 25% | 2.9 | 47 (22) | 49 (14) | 38 (8) | 48 (30) | 44 (14) |
| Mine | Fragile | 3 | 10 (3) | 10 | 0 | 67 | 33% | 4.0 | 10 (3) | - | - | 0 (1) | 15 (2) |
| Mine | Hammer | 50 | 50 (50) | 41 | 9 | 42 | 12% | 2.4 | 5 (12) | 66 (35) | 38 (3) | 46 (34) | 56 (16) |
| Mine | Holder | 25 | 74 (25) | 22 | 52 | 24 | 44% | 3.2 | 37 (7) | 88 (13) | 81 (5) | 84 (12) | 64 (13) |
| Mine | Shooter | 37 | 89 (37) | 48 | 42 | 39 | 5% | 1.7 | 60 (6) | 101 (29) | 0 (2) | 89 (23) | 90 (14) |
| Mine | Support | 4 | 82 (4) | 82 | 0 | 19 | 25% | 2.0 | 0 (1) | 141 (3) | - | 67 (2) | 106 (2) |
| Mine | War machine | 52 | 55 (52) | 55 | 0 | 43 | 2% | 1.1 | 27 (13) | 61 (36) | 103 (3) | 67 (13) | 50 (39) |
| Mine | Wizard | 17 | 3 (17) | 3 | 0 | 55 | 12% | 1.7 | 7 (3) | 0 (5) | 0 (1) | 0 (5) | 6 (4) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 73 (68) | 39 | 33 | 54 | 43% | 2.7 | 100 (29) | 64 (11) | 54 (28) | 95 (48) | 20 (20) |
| Opponent | Character | 101 | 50 (101) | 50 | 0 | 37 | 20% | 2.0 | 43 (37) | 61 (52) | 16 (5) | 47 (56) | 59 (38) |
| Opponent | Clean-up | 9 | 44 (9) | 10 | 34 | 32 | 22% | 3.6 | 0 (3) | 35 (5) | 238 (1) | 57 (5) | 31 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 49 (60) | 31 | 17 | 33 | 27% | 2.6 | 46 (30) | 61 (20) | 29 (10) | 67 (28) | 30 (32) |
| Opponent | Fragile | 3 | 54 (3) | 54 | 0 | 100 | 0% | 2.0 | - | 0 (2) | 162 (1) | 81 (2) | 0 (1) |
| Opponent | Hammer | 50 | 35 (50) | 27 | 8 | 50 | 32% | 2.8 | 12 (17) | 44 (30) | 8 (3) | 31 (30) | 40 (20) |
| Opponent | Holder | 42 | 114 (42) | 44 | 71 | 19 | 38% | 2.8 | 49 (9) | 134 (26) | 140 (7) | 105 (28) | 130 (14) |
| Opponent | Shooter | 27 | 24 (27) | 13 | 11 | 46 | 0% | 1.1 | 13 (6) | 25 (19) | 72 (2) | 21 (16) | 29 (11) |
| Opponent | Support | 4 | 22 (4) | 22 | 0 | 33 | 75% | 6.0 | - | 65 (2) | 0 (1) | 0 (1) | 65 (2) |
| Opponent | War machine | 17 | 59 (17) | 59 | 0 | 30 | 0% | 1.5 | 46 (3) | 41 (10) | 104 (4) | 36 (3) | 63 (14) |
| Opponent | Wizard | 33 | 26 (33) | 26 | 0 | 38 | 21% | 2.2 | 14 (16) | 58 (9) | 0 (2) | 21 (13) | 30 (14) |

### Charged fights: ch-h2h-mine-ea652ef-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 10 | 316 | 3.0 | 1.2 | 105 | 28 | +77 | 2 of 12 | 11 of 12 | +50 | +80 |
| Mine | Chaos Dwarfs | 4 | 169 | 374 | 3.2 | 1.0 | 115 | 48 | +67 | 5 of 13 | 9 of 13 | - | +67 |
| Mine | Dwarfen Mountain Holds | 3 | 547 | 22 | 1.7 | 1.0 | 13 | 0 | +13 | 0 of 5 | 4 of 5 | - | +13 |
| Mine | Empire of Man | 5 | 433 | 30 | 0.6 | 1.0 | 50 | 0 | +50 | 1 of 3 | 3 of 3 | - | +50 |
| Mine | Grand Cathay | 5 | 565 | 214 | 2.4 | 1.2 | 89 | 14 | +76 | 2 of 12 | 11 of 12 | +0 | +91 |
| Mine | High Elf Realms | 4 | 173 | 318 | 2.8 | 1.0 | 116 | 44 | +72 | 5 of 11 | 9 of 11 | - | +72 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 1192 | 5.0 | 1.0 | 238 | 0 | +238 | 1 of 5 | 4 of 5 | - | +238 |
| Mine | Lizardmen | 1 | 201 | 456 | 3.0 | 1.3 | 152 | 228 | -76 | 0 of 3 | 3 of 3 | -69 | -80 |
| Mine | Ogre Kingdoms | 1 | 311 | 314 | 4.0 | 1.0 | 78 | 22 | +56 | 2 of 4 | 1 of 4 | - | +56 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 400 | 4.0 | 1.0 | 100 | 28 | +72 | 2 of 4 | 2 of 4 | - | +72 |
| Mine | Skaven | 1 | 19 | 0 | 1.0 | 1.0 | 0 | 38 | -38 | 0 of 1 | 1 of 1 | - | -38 |
| Mine | Tomb Kings of Khemri | 2 | 25 | 567 | 5.0 | 1.1 | 113 | 60 | +53 | 4 of 10 | 8 of 10 | -601 | +126 |
| Mine | Vampire Counts | 2 | 0 | 548 | 4.5 | 1.2 | 122 | 69 | +53 | 2 of 9 | 7 of 9 | +414 | +8 |
| Mine | Warriors of Chaos | 2 | 0 | 698 | 5.0 | 1.1 | 140 | 83 | +57 | 2 of 10 | 7 of 10 | +464 | +11 |
| **Mine** | all armies | 36 | 240 | 314 | 2.8 | 1.1 | 111 | 45 | +66 | 28 of 102 | 80 of 102 | +37 | +68 |
| Opponent | Empire of Man | 1 | 917 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 364 | 418 | 2.3 | 1.6 | 179 | 0 | +179 | 2 of 7 | 6 of 7 | +284 | +39 |
| Opponent | High Elf Realms | 3 | 112 | 522 | 2.7 | 1.0 | 196 | 87 | +109 | 3 of 8 | 8 of 8 | - | +109 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 481 | 2.5 | 1.2 | 192 | 55 | +137 | 4 of 5 | 3 of 5 | +434 | +63 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 199 | 4.0 | 1.0 | 50 | 14 | +36 | 2 of 4 | 3 of 4 | - | +36 |
| Opponent | Skaven | 1 | 165 | 115 | 3.0 | 1.0 | 38 | 70 | -32 | 2 of 3 | 2 of 3 | - | -32 |
| Opponent | Tomb Kings of Khemri | 4 | 358 | 544 | 5.5 | 1.1 | 99 | 42 | +57 | 12 of 22 | 17 of 22 | +392 | +23 |
| Opponent | Vampire Counts | 6 | 9 | 880 | 4.7 | 1.2 | 188 | 12 | +177 | 11 of 28 | 21 of 28 | +511 | +104 |
| Opponent | Warriors of Chaos | 9 | 0 | 253 | 2.3 | 1.4 | 108 | 37 | +71 | 12 of 21 | 14 of 21 | +79 | +67 |
| Opponent | Wood Elf Realms | 6 | 102 | 98 | 2.2 | 1.2 | 45 | 94 | -48 | 1 of 13 | 8 of 13 | +158 | -86 |
| **Opponent** | all armies | 36 | 128 | 400 | 3.1 | 1.2 | 130 | 40 | +89 | 49 of 111 | 82 of 111 | +275 | +46 |

### Effective charges: ch-h2h-mine-ea652ef-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 12 | 1 (net +0) | 0 | 1 (net +45) | 1 (net +0) | 0 | 4 (net +82) | 5 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 13 | 1 (net +0) | 0 | 1 (net +0) | 5 (net -12) | 0 | 6 (net +156) | 0 | 8% (1 of 13) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 0 | 2 (net +32) | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 3 | 0 | 0 | 0 | 0 | 1 (net +45) | 2 (net +52) | 0 | 0% (0 of 3) |
| Mine | Grand Cathay | 12 | 0 | 2 (net +142) | 5 (net +63) | 2 (net +0) | 1 (net +0) | 2 (net +154) | 0 | 42% (5 of 12) |
| Mine | High Elf Realms | 11 | 1 (net +260) | 2 (net +97) | 0 | 3 (net +78) | 0 | 4 (net +0) | 1 | 0% (0 of 10) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 3 (net +319) | 0 | 2 (net +118) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 3 | 1 (net -69) | 0 | 0 | 0 | 0 | 1 (net -159) | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +144) | 3 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +370) | 2 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 1 (net -38) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 10 | 1 (net +293) | 0 | 3 (net -110) | 3 (net +128) | 1 (net +60) | 1 (net +66) | 1 | 33% (3 of 9) |
| Mine | Vampire Counts | 9 | 1 (net -60) | 1 (net -60) | 0 | 2 (net -198) | 2 (net +207) | 3 (net +193) | 0 | 0% (0 of 9) |
| Mine | Warriors of Chaos | 10 | 2 (net -71) | 0 | 4 (net +62) | 1 (net +464) | 0 | 3 (net -0) | 0 | 40% (4 of 10) |
| Opponent | Grand Cathay | 7 | 0 | 0 | 1 (net +170) | 1 (net +52) | 3 (net +43) | 2 (net +451) | 0 | 14% (1 of 7) |
| Opponent | High Elf Realms | 8 | 0 | 0 | 3 (net -231) | 2 (net +320) | 0 | 1 (net +112) | 2 | 50% (3 of 6) |
| Opponent | Kingdom of Bretonnia | 5 | 2 (net +23) | 0 | 0 | 2 (net +102) | 0 | 1 (net +434) | 0 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 3 | 0% (0 of 1) |
| Opponent | Skaven | 3 | 1 (net +0) | 0 | 0 | 1 (net -210) | 0 | 1 (net +115) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 22 | 3 (net -162) | 0 | 2 (net -186) | 6 (net +48) | 2 (net +233) | 5 (net +136) | 4 | 11% (2 of 18) |
| Opponent | Vampire Counts | 28 | 4 (net +74) | 1 (net +85) | 3 (net +142) | 7 (net +56) | 4 (net +153) | 6 (net +402) | 3 | 12% (3 of 25) |
| Opponent | Warriors of Chaos | 21 | 1 (net -30) | 1 (net -465) | 2 (net +91) | 5 (net +0) | 2 (net +96) | 10 (net +162) | 0 | 10% (2 of 21) |
| Opponent | Wood Elf Realms | 13 | 0 | 0 | 2 (net +58) | 1 (net -104) | 2 (net +62) | 1 (net +255) | 7 | 33% (2 of 6) |

### Charged fights, damage counted: ch-h2h-mine-ea652ef-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 155 | 232 | +28 | 84 | 68 | +16 | +10.3 |
| Mine | 50-54% | 5 | 298 | 263 | +84 | 308 | 130 | +178 | +59.6 |
| Mine | Effective (55-75%) | 15 | 240 | 181 | +16 | 98 | 75 | +23 | +9.6 |
| Mine | 76-89% | 22 | 315 | 198 | +75 | 148 | 65 | +83 | +26.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 231 | 171 | +91 | 162 | 63 | +98 | +42.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 485 | 99 | +104 | 111 | 20 | +91 | +18.8 |
| Mine | No odds | 13 | 291 | 164 | +55 | 89 | 34 | +55 | +19.0 |
| Mine | All fights | 102 | 266 | 184 | +66 | 137 | 63 | +74 | +27.7 |
| Opponent | Long shot (under 50%) | 11 | 182 | 267 | -16 | 149 | 132 | +17 | +9.6 |
| Opponent | 50-54% | 2 | 238 | 198 | -190 | 42 | 232 | -190 | -80.0 |
| Opponent | Effective (55-75%) | 13 | 246 | 204 | -13 | 141 | 96 | +44 | +17.9 |
| Opponent | 76-89% | 25 | 324 | 206 | +51 | 95 | 48 | +47 | +14.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 401 | 251 | +233 | 262 | 27 | +235 | +58.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 374 | 85 | +117 | 129 | 9 | +120 | +32.1 |
| Opponent | No odds | 19 | 185 | 202 | +70 | 140 | 69 | +71 | +38.4 |
| Opponent | All fights | 111 | 301 | 208 | +89 | 159 | 59 | +100 | +33.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ch-h2h-mine-ea652ef-p3 | move | 448 | 87 (19%) | 66 (15%) | 45 (10%) | 316 (71%) |
| ch-h2h-mine-ea652ef-p3 | objective | 374 | 55 (15%) | 42 (11%) | 47 (13%) | 272 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

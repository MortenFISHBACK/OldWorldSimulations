# Doctrine scorecard: ch-h2h-opp-ea652ef-p4

### Scorecard: ch-h2h-opp-ea652ef-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 1 | 0 | 0 | 65 |
| L0114 | 6 | 1 | Opponent | no | 9 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 200 |
| L0214 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 5 | 4 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 0 | 2 | 1 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 14 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 7 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 1331 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 1 | 5 | 0 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 4 | 1 | 1 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 743 |
| L0624 | 6 | 1 | Opponent | no | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 497 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 0 | 2 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 724 |
| L0819 | 3 | 1 | Opponent | yes | 4 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 677 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 6 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 3 | 2 | 6 | 1 | 2 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 5 | 3 | 5 | 0 | 0 | 0 | 527 |
| L1126 | 4 | 1 | Mine | no | 3 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 4 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 4 | 5 | 0 | 0 | 0 | 197 |
| L1314 | 6 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | no | - | 4 | 0 | 4 | 2 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 2 | 0 | 0 | 251 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 6 | 3 | 4 | 0 | 0 | 0 | 355 |
| L1719 | 3 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 647 |
| L1819 | 1 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 0 | 0 | 0 | 126 |
| L2021 | 5 | 1 | Mine | no | - | - | 0 | 4 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 5 | 2 | 6 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 1 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 1 | 6 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 4 | 3 | 3 | 0 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 4 | 5 | 4 | 1 | 0 | 0 | 0 | 110 |
| L2634 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 1 | 0 | 0 | 56 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 25% | 1.0 | 2.7 | 2.5 | 1.3 | 0.3 | 0.0 | 0.0 | 286.9 |
| **Average** | | | Opponent | 39% | 3.1 | 2.4 | 3.1 | 2.1 | 0.5 | 0.0 | 0.0 | 120.3 |

### KPIs: ch-h2h-opp-ea652ef-p4

Rules off - Mine only: CHARGE BAND, HONEST WORTH, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (38 of 164) | 1% (2 of 182) | 12% (40 of 346) |
| Winner chose to follow up after the loser gave ground |  | 97% (64 of 66); on the table 97% | 99% (70 of 71); on the table 99% | 98% (134 of 137); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (5 of 10); on the table 60% | 85% (11 of 13); on the table 85% | 70% (16 of 23); on the table 74% |
| Winner chose to pursue after the loser fled |  | 75% (12 of 16); on the table 88% | 78% (21 of 27); on the table 81% | 77% (33 of 43); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 88% (81 of 92); on the table 91% | 92% (102 of 111); on the table 93% | 90% (183 of 203); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 32% (86 of 267) | 45% (79 of 176) | 37% (165 of 443) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (86 of 197) | 55% (79 of 143) | 49% (165 of 340) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 25% (34 of 136) | 33% (28 of 86) | 28% (62 of 222) |
|     round 1 |  | 13% (3 of 23) | 29% (4 of 14) | 19% (7 of 37) |
|     rounds 2+ |  | 27% (31 of 113) | 33% (24 of 72) | 30% (55 of 185) |
|   other wizards | 50%+ | 40% (52 of 131) | 51% (41 of 80) | 44% (93 of 211) |
|     round 1 |  | 14% (3 of 22) | 36% (5 of 14) | 22% (8 of 36) |
|     rounds 2+ |  | 45% (49 of 109) | 55% (36 of 66) | 49% (85 of 175) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (23 of 36) | 56% (40 of 71) | 59% (63 of 107) |
| Points that never fought | lower | 33% (22655 of 67942) | 33% (23579 of 71984) | 33% (46234 of 139926) |
|   infantry points that never fought | lower | 45% (6895 of 15347) | 58% (7988 of 13804) | 51% (14883 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (161 of 270) | 52% (147 of 280) | 56% (308 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.6 uses a game | 78% (7 of 9); 0.6 uses a game | 87% (27 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.2 uses a game | 40% (8 of 20); 0.3 uses a game | 36% (13 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 67% (10 of 15); 0.3 uses a game | 62% (21 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (31633 of 57750) | 44% (27990 of 63347) | 49% (59623 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (28%) | 0.9 (32%) | 2.3 (29%) |
| MARCHED: its unit marched | 1.3 (25%) | 0.4 (14%) | 1.7 (22%) |
| CHARGED: its unit charged | 0.4 (8%) | 0.4 (13%) | 0.8 (10%) |
| IN COMBAT: engaged in combat | 0.9 (19%) | 0.6 (21%) | 1.5 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.6 (13%) | 0.4 (13%) | 1.0 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.2 | 1.9 | 4.6 | 0.4 | 2.3 |
| not cast | 2.6 | 2.6 | 2.9 | 7.7 | 1.6 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (38%) | 0.3 (12%) | 2.3 (29%) | 0.3 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (22%) | 0.3 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (10%) | 0.1 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (7%) | 0.3 (11%) | 0.5 (17%) | 1.5 (19%) | 0.4 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.2 (6%) | 0.2 (8%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.6 (21%) | 0.5 (19%) | 0.4 (14%) | 1.0 (13%) | 0.3 (19%) | 2.0 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.1 (5%) | 0.2 (7%) | 0.3 (4%) | 0.1 (3%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.4 (15%) | 0.0 (0%) | 0.0 (0%) | 0.2 (14%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (59%) | 0.1 (5%) | 1.2 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 59% (24 of 41) | 53% (8 of 15) | 57% (32 of 56) |
| the unit moved after it | 75% (18 of 24) | 62% (5 of 8) | 72% (23 of 32) |
| it charged on its next turn | 12% (3 of 24) | 0% (0 of 8) | 9% (3 of 32) |
| the enemy charged it first | 21% (5 of 24) | 0% (0 of 8) | 16% (5 of 32) |
| it fought by the end of its next turn | 17% (4 of 24) | 0% (0 of 8) | 12% (4 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 21% (5 of 24) | 12% (1 of 8) | 19% (6 of 32) |
| none of these (no charge, no fight, no charge escaped) | 46% (11 of 24) | 88% (7 of 8) | 56% (18 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (572 of 902) | 55% (301 of 549) | 60% (873 of 1451) |
|   cavalry | 59% (48 of 82) | 64% (78 of 122) | 62% (126 of 204) |
|   character | 40% (39 of 97) | 15% (20 of 133) | 26% (59 of 230) |
|   chariot | 49% (50 of 103) | 56% (10 of 18) | 50% (60 of 121) |
|   infantry | 61% (170 of 280) | 69% (157 of 227) | 64% (327 of 507) |
|   monster | 41% (18 of 44) | 35% (7 of 20) | 39% (25 of 64) |
|   war machine | 83% (247 of 296) | 100% (29 of 29) | 85% (276 of 325) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (25%) | 1.4 (20%) | 3.6 (23%) |
| CHARGED: it charged | 1.2 (13%) | 1.9 (27%) | 3.0 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.2 (13%) | 0.3 (5%) | 1.6 (10%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.8 (20%) | 1.3 (19%) | 3.1 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.8 (12%) | 1.4 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (15%) | 1.1 (16%) | 2.5 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 2.0 | 76% | 6.3 pts | 38 pts |
| character | 1.9 | 0.5 | 81% | 6.5 pts | 12 pts |
| chariot | 1.7 | 1.2 | 65% | 17.8 pts | 31 pts |
| infantry | 13.3 | 5.2 | 74% | 9.4 pts | 125 pts |
| monster | 0.8 | 0.1 | 85% | 5.7 pts | 4 pts |
| war machine | 7.7 | 6.3 | 64% | 29.5 pts | 226 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 6.7 | 5.4 |
| Charges that made contact a game | 3.0 | 4.4 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.12 declared, 0.59 contact (17 units) | 0.93 declared, 0.40 contact (15 units) | 1.03 declared, 0.50 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.89 declared, 0.67 contact (9 units) | 1.18 declared, 0.73 contact (11 units) | 1.05 declared, 0.70 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.38 contact (248 units) | 0.73 declared, 0.48 contact (295 units) | 0.62 declared, 0.43 contact (543 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (43 of 81) | 44% (7 of 16) | 67% (4 of 6) | 52% (54 of 103) |
| Character in a unit | 93% (26 of 28) | 75% (12 of 16) | 100% (1 of 1) | 87% (39 of 45) |
| Character on its own | 73% (27 of 37) | 38% (10 of 26) | 26% (20 of 77) | 41% (57 of 140) |
| Chariot | 80% (12 of 15) | 42% (5 of 12) | - | 63% (17 of 27) |
| Infantry | 51% (42 of 83) | 48% (12 of 25) | 50% (3 of 6) | 50% (57 of 114) |
| Monster | 74% (25 of 34) | 57% (8 of 14) | - | 69% (33 of 48) |
| Monstrous | 79% (11 of 14) | 57% (8 of 14) | - | 68% (19 of 28) |
| War Machines | 72% (31 of 43) | 50% (1 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 71% (5 of 7); on the table 86% | 38% (39 of 102) | 26% | 64% (14 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 93% (13 of 14); on the table 93% | 58% (14 of 24) | 23% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (7 of 7); on the table 100% | - | 51% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (8 of 10); on the table 80% | 39% (7 of 18) | 46% | 63% (39 of 62) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 100% (7 of 7); on the table 100% | 26% (22 of 84) | 52% | 43% (16 of 37) | 100% (9 of 9); 7.8 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 86% (30 of 35); on the table 86% | 17% (6 of 36) | 32% | 47% (33 of 70) | 100% (7 of 7); 2.8 uses a game | 33% (10 of 30); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 39% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 91% (10 of 11); on the table 100% | 67% (4 of 6) | 36% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 80% (4 of 5); on the table 80% | 17% (1 of 6) | 32% | 79% (11 of 14) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 90% (9 of 10); on the table 90% | 45% (19 of 42) | 11% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 94% (16 of 17); on the table 94% | 38% (16 of 42) | 40% | 71% (32 of 45) | 67% (2 of 3); 0.5 uses a game | 0.0 uses a game | 50% (3 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 88% (15 of 17); on the table 94% | 50% (3 of 6) | 23% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 96% (23 of 24); on the table 96% | 44% (26 of 59) | 23% | 45% (19 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 95% (18 of 19); on the table 95% | 25% (3 of 12) | 28% | 54% (39 of 72) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 88% (15 of 17); on the table 94% | 83% (5 of 6) | 40% | 50% (28 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (ch-h2h-opp-ea652ef-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (43) | 47% (34) | 49% (77) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.56 | 1.22 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.19 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.36 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.69 | 0.97 | 2.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.44 | 1.39 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.36 | 5.53 | 10.89 |

### Quality by phase: ch-h2h-opp-ea652ef-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 48% (75 of 156) | 39% (78 of 202) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (172 of 383) | 32% (55 of 170) |
| Strategy | Close-in objectives charged next turn | 9% (14 of 151) | 14% (25 of 185) |
| Strategy | Support requests answered (helper made contact too) | 44% (8 of 18) | 32% (13 of 41) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 67% (2 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 12% (1 of 8) | 64% (7 of 11) |
| Strategy | Joined characters whose unit fought | 50% (17 of 34) | 48% (16 of 33) |
| Strategy | Lone characters that fought | 80% (71 of 89) | 82% (68 of 83) |
| Movement | Charges halted short of contact | 0.0 | 0.5 |
| Movement | Idle units | 1.3 | 2.1 |
| Movement | Points that never moved of their own | 286.9 | 120.3 |
| Movement | Fights charged into per game | 2.9 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 99, net +33 | 18 of 111, net +19 |
| Movement | Charges with odds: sweet spot (55-75%) | 20 of 99, net +87 | 25 of 111, net +83 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 99, net +102 | 15 of 111, net +99 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 of 99, net +23 | 29 of 111, net +140 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (158 of 358) | 43% (137 of 318) |
| Shooting | Points destroyed by shooting units | 69.9 | 44.1 |
| Shooting | War machine shots | 6.9 | 0.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (135 of 247) | 14% (4 of 29) |
| Shooting | Points destroyed by war machines | 96.6 | 15.4 |
| Magic | Magic missiles cast | 1.4 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (17 of 50) | 22% (11 of 50) |
| Magic | Wounds caused by magic missiles | 2.8 | 2.0 |
| Magic | Wounds caused by other spells | 1.6 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 99.2 | 31.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.3 / 0.9 / 0.2 | 2.0 / 0.4 / 0.9 / 0.1 |
| Combat | Points destroyed in combat | 372.8 | 449.1 |
| Combat | Points run down | 33.1 | 101.4 |
| Combat | Net points per charged fight, damage counted | +59 | +99 |
| Combat | Net per 100 charger points, damage counted | +23.0 | +31.6 |
| Combat | First round won (charged fights) | 74% | 74% |
| Combat | Net points per charged fight | +55 | +99 |
| Combat | Net points per supported fight / lone fight | +44 / +56 | +186 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 105 | 64 of 129 |
| Game | Points lost | 850.6 | 720.5 |
| Game | VP from objectives | 467.2 | 576.9 |
| Game | Lone holders (player turns) | 1.0 | 3.1 |

- Mine won / drew / lost: 10 / 8 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -288 VP
- The side that went first won 11 of 28 games with a winner
- Points traded per game (both sides' losses): 1571
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ch-h2h-opp-ea652ef-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 6.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +5.1 | 0.0 | 39.3 | 1.2 | +9.7 | 0.0 | 12.6 |
| BEST FACING | 0.6 | +38.2 | 0.0 | 28.4 | 0.5 | +14.9 | 0.0 | 32.9 |
| BEST FIRST | 3.9 | +143.6 | 123.6 | 103.9 | 4.5 | +150.5 | 100.8 | 92.6 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.6 | +38.8 | 0.0 | 17.8 |
| BEST OVERALL | 0.6 | +44.4 | 0.0 | 28.2 | 0.4 | +27.2 | 0.0 | 13.9 |
| BEST PREY | 0.8 | +44.6 | 35.4 | 6.4 | 1.0 | +50.5 | 16.4 | 42.0 |
| BEST PRIZE | 0.0 | -0.4 | 0.0 | 0.0 | 0.2 | -1.5 | 20.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.3 | 0.0 | 28.4 | 0.2 | -0.4 | 0.0 | 24.6 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.7 | 0.0 | 0.1 | +0.0 | 6.3 | 0.0 |
| BLOCKED WHEEL | 0.5 | +14.6 | 0.0 | 6.5 | 0.4 | +6.2 | 0.0 | 2.6 |
| BLOWS WHERE AIMED | - | - | - | - | 0.2 | -53.4 | 9.9 | 5.4 |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 100.6 | 8.2 | - | - | - | - |
| CANNON PLANNED TARGET | 5.3 | +178.8 | 437.2 | 70.1 | - | - | - | - |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 7.9 | 15.0 | 0.1 | -2.4 | 10.2 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | -1.3 | 0.0 | 2.0 |
| CAST JOB | 0.7 | +30.1 | 50.4 | 0.0 | 0.6 | +15.1 | 45.7 | 17.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +45.9 | 43.1 | 28.2 | 0.1 | +4.6 | 0.0 | 10.9 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 21.1 | 0.4 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.3 | 3.8 | 0.0 | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 2.6 | 0.0 | 0.0 | +0.3 | 9.9 | 0.0 |
| CHARGE BAND | - | - | - | - | 0.1 | +0.0 | 8.8 | 1.8 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 236.2 | 96.8 | 2.6 | +0.0 | 243.1 | 64.9 |
| CHARGE NOW WEIGHED | 0.4 | -41.1 | 1.5 | 30.0 | 0.7 | -51.3 | 17.7 | 15.9 |
| CHARGER SLAIN LOST | - | - | - | - | 0.7 | -25.3 | 49.0 | 25.6 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 13.9 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.4 | 10.1 | 0.0 | 0.3 | -0.9 | 6.6 | 11.1 |
| CHEAP HELPER | 0.2 | +0.0 | 19.3 | 7.9 | 0.1 | +0.0 | 14.1 | 3.2 |
| COMBAT PIVOT | 0.5 | +0.0 | 27.8 | 59.6 | 0.6 | +0.0 | 40.1 | 32.8 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 10.2 | - | - | - | - |
| CONVEYANCE SEARCH | 0.9 | +130.3 | 26.8 | 21.1 | 0.4 | +63.5 | 14.6 | 22.2 |
| COUNTER-CHARGE COVER | 9.1 | +645.3 | 0.0 | 261.2 | 6.9 | +589.9 | 0.0 | 156.5 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 28.6 | 3.5 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.7 | 0.0 | 0.0 | 0.1 | +9.5 | 17.2 | 0.0 |
| EDGE GIVE GROUND | 0.0 | +0.6 | 0.0 | 2.2 | 0.3 | +6.7 | 40.0 | 10.3 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.7 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | - | - | - | - | 5.8 | +0.0 | 229.0 | 70.1 |
| FACE THE CAST | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| FACES THE THREAT | 1.7 | +122.2 | 0.0 | 62.7 | 1.0 | +69.1 | 0.0 | 42.0 |
| FALLBACK BY WORTH | 4.8 | +46.9 | 0.0 | 53.2 | 6.8 | +58.7 | 0.0 | 67.5 |
| FIGHT LIFT | 0.1 | +2.4 | 0.0 | 9.9 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 3.1 | 0.1 | +1.0 | 0.0 | 5.9 |
| FIRE IN ORDER | - | - | - | - | 0.4 | +0.0 | 15.4 | 3.2 |
| FIRE PLAN | - | - | - | - | 8.4 | +21.8 | 343.1 | 99.3 |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 172.0 | 5.2 | +0.0 | 0.0 | 118.1 |
| FOLLOW UP WEIGHED | 1.0 | +125.6 | 0.0 | 26.5 | 1.2 | +202.4 | 0.0 | 35.9 |
| FRIENDS SHOTS CHECKED | 0.3 | +10.6 | 0.0 | 0.0 | 0.2 | +17.8 | 0.0 | 4.0 |
| GIVES UP | - | - | - | - | 0.2 | -2.3 | 30.9 | 7.2 |
| GIVES UP ITS SCREEN | 0.0 | -0.4 | 0.0 | 2.4 | 0.0 | -0.9 | 4.9 | 0.0 |
| GROUND FLIERS | 0.1 | +1.5 | 0.0 | 6.1 | 0.1 | +1.9 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.4 | +0.0 | 76.8 | 8.6 | 0.4 | +0.0 | 45.5 | 14.1 |
| HILL BY ITS CHANCE | 0.5 | -49.0 | 0.0 | 12.7 | 0.6 | -61.9 | 0.0 | 10.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 5.8 | +776.2 | 229.0 | 70.1 |
| HONEST WORTH | - | - | - | - | 8.8 | -204.6 | 522.7 | 212.0 |
| HUNT ADVANCE | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +1.8 | 3.5 | 7.9 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 3.2 |
| HUNT IN PAIRS | 0.2 | +8.6 | 0.0 | 0.0 | 0.6 | +38.5 | 0.0 | 26.1 |
| HUNT KEPT | 0.1 | +0.0 | 0.0 | 3.1 | 0.1 | +1.4 | 9.2 | 2.9 |
| HUNT RESULT | 0.1 | +14.5 | 0.0 | 3.1 | 0.2 | +19.7 | 4.6 | 12.0 |
| HUNT THE GUNS | 0.1 | +17.5 | 13.9 | 0.0 | 0.2 | +63.8 | 11.5 | 9.2 |
| INVITES THE FIGHT | 2.1 | +36.5 | 65.6 | 11.2 | 1.5 | +21.4 | 52.1 | 47.5 |
| JOINT CHARGE PLAN | 0.1 | +1.9 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 7.9 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -8.2 | 8.1 | 9.9 |
| KEEP FALLS | 0.1 | +4.1 | 0.0 | 6.6 | 0.0 | +0.4 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.6 | +46.7 | 100.3 | 64.3 | 1.6 | +47.5 | 153.5 | 48.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | - | - | - | - | 0.7 | -22.1 | 42.0 | 17.4 |
| KILLS COUNT | 1.9 | +64.9 | 175.7 | 69.5 | 2.3 | +141.7 | 227.2 | 64.3 |
| KILLS COUNT NEXT TURN | 5.0 | +149.7 | 165.8 | 175.7 | 6.1 | +230.7 | 262.3 | 188.1 |
| LONE CHARACTER SAFE SPOT | 0.4 | +4.8 | 0.0 | 18.8 | 0.1 | +3.3 | 2.0 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 3.7 | 10.8 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -2.8 | 53.7 | 10.1 | 0.6 | +1.1 | 62.6 | 10.3 |
| LOST CHARGE | 3.2 | -39.9 | 123.1 | 112.8 | 1.7 | -27.3 | 49.7 | 55.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -5.4 | 0.0 | 0.0 | 0.1 | -5.2 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +44.7 | 4.7 | 27.1 | 0.5 | +47.5 | 0.0 | 36.4 |
| MANOEUVRE | 0.2 | +9.1 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 5.5 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +39.2 | 0.0 | 6.8 | 0.2 | +6.0 | 0.0 | 8.6 |
| MARCH ODDS | 0.4 | +28.4 | 15.2 | 26.4 | 0.2 | +10.4 | 13.4 | 0.0 |
| MARCH OVER CASTS | 0.6 | +51.8 | 0.0 | 30.1 | 0.3 | +20.0 | 0.0 | 14.9 |
| MAX FOR POSITIONING | 4.8 | +158.6 | 0.0 | 177.4 | 4.6 | +177.0 | 0.0 | 108.9 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 0.7 | +3.1 | 34.1 | 15.2 |
| MISSILES IN THE MOVE | 3.6 | +137.0 | 0.0 | 75.4 | 2.6 | +50.4 | 0.0 | 60.2 |
| MISSILES NEXT TURN | 4.7 | +93.4 | 0.0 | 109.9 | 3.1 | +29.4 | 0.0 | 60.1 |
| MODEL FACING | 0.3 | +45.0 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 10.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +14.5 | 0.0 | 0.0 | 0.4 | +22.5 | 0.0 | 17.4 |
| MOVE SPELL IN RANGE | 0.3 | +7.6 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -27.9 | 20.0 | 0.0 | 0.2 | -4.8 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 24.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.3 | +204.9 | 77.8 | 108.1 | 3.7 | +230.6 | 142.8 | 117.4 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.8 | 0.0 | 3.4 | 0.1 | +15.1 | 9.2 | 5.2 |
| NO RALLY LEFT | 0.1 | +1.2 | 0.0 | 0.0 | 0.0 | +7.4 | 0.0 | 0.0 |
| NOT NEEDED | 0.3 | -11.5 | 17.9 | 5.8 | 0.3 | -21.4 | 35.1 | 5.7 |
| NOT TURNED | 5.4 | +64.3 | 0.0 | 101.9 | 5.5 | +77.1 | 0.0 | 136.7 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 14.7 | -699.5 | 32.6 | 270.3 | 13.4 | -738.1 | 4.9 | 227.3 |
| ONE YARDSTICK | - | - | - | - | 8.9 | -197.6 | 207.1 | 102.6 |
| OPENS A LANE | 0.4 | +0.9 | 43.5 | 0.0 | 0.1 | +0.3 | 12.9 | 0.0 |
| OPENS UP | 0.3 | +15.1 | 11.4 | 0.0 | 0.1 | +10.1 | 6.2 | 0.0 |
| OVERRUNS AWAY | 0.6 | +13.4 | 34.0 | 16.6 | 0.5 | +5.2 | 56.7 | 5.9 |
| PATHS CROSS | 2.6 | +194.8 | 0.0 | 46.6 | 2.9 | +234.9 | 0.0 | 66.6 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | 0.1 | +4.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -1.2 | 0.0 | 0.0 | 0.1 | -3.1 | 0.0 | 1.5 |
| PLAN RESULT | 38.4 | +1588.2 | 1587.5 | 1112.7 | 39.5 | +1402.6 | 1623.7 | 1101.2 |
| PURSUES BIG PREY | 0.1 | -3.8 | 0.0 | 0.0 | 0.1 | -1.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +3.9 | 0.0 | 0.0 | 0.1 | +13.9 | 0.0 | 3.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +22.2 | 0.0 | 48.1 | 2.0 | +30.0 | 0.0 | 59.9 |
| RANDOM MOVER NO PROMISE | 0.3 | -13.0 | 5.1 | 9.4 | 0.2 | -8.6 | 13.5 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -2.9 | 0.0 | 1.0 | 0.7 | -5.0 | 0.0 | 15.4 |
| REDIRECT COUNTER | 2.1 | +133.6 | 0.0 | 32.3 | 3.9 | +304.9 | 0.0 | 66.9 |
| REDIRECT WEIGHED | 0.2 | +5.5 | 9.7 | 10.2 | 0.4 | +6.4 | 10.2 | 12.4 |
| REFUSING RETIRES | - | - | - | - | 0.4 | +0.0 | 0.0 | 5.9 |
| RESERVE FALL BACK | 0.4 | +12.7 | 0.0 | 21.1 | 0.8 | +26.2 | 0.0 | 6.1 |
| RESTRAINS TO SHOOT | 0.2 | +6.4 | 0.0 | 10.5 | 0.0 | +2.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.9 | +91.2 | 298.1 | 81.3 | 3.4 | +59.4 | 278.8 | 112.9 |
| SAFE SURE CHARGE | 0.0 | -1.8 | 3.1 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +50.3 | 0.0 | 19.6 | 0.4 | +23.3 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -3.0 | 0.0 | 0.9 | 0.4 | -23.5 | 0.0 | 3.1 |
| SEARCH SPOT | 2.5 | +118.9 | 0.0 | 53.4 | 3.3 | +164.3 | 0.0 | 44.8 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.2 | 3.5 | 0.0 |
| SELF MOVE SPELL | 0.2 | +44.7 | 0.0 | 0.0 | 0.6 | +18.0 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.8 | +66.2 | 4.7 | 39.1 | 1.0 | +72.5 | 8.8 | 40.2 |
| SET-UP ANY TARGET | 0.6 | +86.9 | 9.0 | 11.2 | 0.1 | +34.5 | 0.0 | 11.1 |
| SET-UP MISSED | 0.1 | +8.9 | 0.0 | 0.0 | 0.1 | +16.7 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 2.4 | +116.5 | 94.0 | 42.5 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 0.8 | +10.5 | 0.0 | 26.6 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +22.3 | 33.1 | 0.0 | 0.8 | +30.5 | 44.6 | 3.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.9 | +0.0 | 852.1 | 274.9 | 8.8 | +0.0 | 351.6 | 114.9 |
| SHOT REPLANNED | 0.6 | +0.0 | 172.2 | 13.3 | - | - | - | - |
| SHOTS IN THE MOVE | 14.6 | +579.6 | 0.0 | 243.3 | 7.8 | +202.0 | 0.0 | 87.6 |
| SPELL CATCH ODDS | 0.1 | -0.6 | 0.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.6 | +108.0 | 9.0 | 11.2 | 0.1 | +53.4 | 0.0 | 11.1 |
| SPELL WORTH | 1.3 | +20.7 | 56.1 | 59.0 | 2.6 | +54.1 | 48.3 | 48.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.9 | -13.5 | 53.4 | 40.1 |
| STABLE ROLE | 11.1 | +0.0 | 455.3 | 213.1 | 9.6 | +0.0 | 368.6 | 154.9 |
| STAY WEIGHED | 0.1 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 8.1 | +60.3 | 140.3 | 104.1 |
| STOPS | 0.0 | +0.7 | 13.9 | 0.0 | 0.2 | +4.1 | 17.2 | 2.5 |
| STOPS SHORT OF THE FLANK | 0.5 | +13.0 | 0.0 | 38.0 | 0.3 | +7.4 | 0.0 | 24.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.3 | +0.0 | 0.0 | 9.9 |
| SUPPORT NARROWED | 6.6 | -56.2 | 402.5 | 138.5 | 7.5 | -50.1 | 328.9 | 119.1 |
| SUPPORTS | 4.2 | +65.0 | 193.5 | 73.4 | 5.1 | +54.0 | 150.0 | 73.5 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.9 | 4.9 | 7.4 | 0.1 | -3.0 | 0.0 | 3.8 |
| SURE REACH TOGETHER | 0.3 | -0.5 | 0.0 | 21.8 | 0.4 | -6.9 | 0.0 | 3.4 |
| THROUGH LINE OF FIRE | 0.2 | +8.8 | 0.0 | 5.6 | 0.2 | +24.1 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -53.2 | 44.4 | 24.4 | 0.2 | -24.6 | 23.6 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +0.8 | 4.7 | 0.0 | 0.4 | +2.2 | 0.0 | 13.7 |
| WAIT AFTER COSTS | 7.1 | -301.9 | 194.1 | 140.1 | 6.8 | -320.0 | 276.1 | 196.7 |
| WALKS TO THE FIGHT | 1.6 | +24.6 | 43.7 | 24.1 | 0.6 | +12.6 | 22.7 | 19.2 |
| WAR ENGINE CHARGES | 0.1 | +6.8 | 2.5 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 49.4 | 1.8 | 0.1 | +0.0 | 0.0 | 4.0 |
| WEARS DOWN | 1.1 | +46.1 | 109.6 | 42.8 | 1.6 | +56.3 | 126.6 | 41.6 |
| WHO HITS BACK | 0.3 | +30.6 | 0.0 | 4.0 | 0.2 | +16.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +1.7 | 52.6 | 1.4 | 0.6 | +49.7 | 65.5 | 2.1 |
| WHOLE FIGHT GAIN | 0.2 | +13.2 | 30.4 | 2.6 | 1.0 | +90.8 | 78.1 | 24.0 |
| WIDER SPREAD | - | - | - | - | 3.6 | -7.8 | 341.9 | 88.2 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 9.5 | 0.0 |

### Rule changes: ch-h2h-opp-ea652ef-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1011 | 1011 | 1011 | 28.08 | -51753 | -51.2 |
| BEST FIRST | 301 | 301 | 301 | 8.36 | +10587 | +35.2 |
| SEARCH SPOT | 209 | 209 | 205 | 5.69 | +10200 | +49.8 |
| PATHS CROSS | 201 | 201 | 201 | 5.58 | +15470 | +77.0 |
| COUNTER-CHARGE COVER | 576 | 318 | 148 | 4.11 | +8222 | +55.6 |
| MOVE TO CHARGE | 252 | 252 | 137 | 3.81 | +6536 | +47.7 |
| KILLS COUNT NEXT TURN | 400 | 400 | 117 | 3.25 | +3331 | +28.5 |
| SUPPORTS | 333 | 333 | 116 | 3.22 | +1479 | +12.8 |
| FACES THE THREAT | 96 | 96 | 96 | 2.67 | +6886 | +71.7 |
| SHOTS IN THE MOVE | 807 | 522 | 81 | 2.25 | +2135 | +26.4 |
| FALLBACK BY WORTH | 417 | 417 | 80 | 2.22 | +3801 | +47.5 |
| FOLLOW UP WEIGHED | 80 | 80 | 80 | 2.22 | +11806 | +147.6 |
| FIRE PLAN | 301 | 301 | 69 | 1.92 | +543 | +7.9 |
| RANDOM MOVE BY FIGURES | 107 | 107 | 63 | 1.75 | +1880 | +29.8 |
| WAIT AFTER COSTS | 497 | 497 | 60 | 1.67 | +944 | +15.7 |
| ARTILLERY RE-ROLL WEIGHED | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| ADVANCE LANE KEPT | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| SAFER THAN THE JOB | 50 | 50 | 50 | 1.39 | +2648 | +53.0 |
| MAX FOR POSITIONING | 337 | 203 | 49 | 1.36 | +796 | +16.2 |
| REDIRECT COUNTER | 218 | 124 | 47 | 1.31 | +3699 | +78.7 |
| WALKS TO THE FIGHT | 81 | 81 | 46 | 1.28 | +409 | +8.9 |
| EVERY WOUND COUNTS | 209 | 209 | 43 | 1.19 | +0 | +0.0 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RESERVE FALL BACK | 42 | 42 | 42 | 1.17 | +1401 | +33.4 |
| CHARGE NOW FIRST | 188 | 188 | 40 | 1.11 | -2131 | -53.3 |
| RISK BY ARC | 227 | 216 | 40 | 1.11 | +997 | +24.9 |
| BEST OVERALL | 39 | 39 | 39 | 1.08 | +2578 | +66.1 |
| BEST FACING | 38 | 38 | 38 | 1.06 | +1911 | +50.3 |
| COMBAT PIVOT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +2655 | +71.8 |
| CANNON PLANNED TARGET | 192 | 192 | 35 | 0.97 | +66 | +1.9 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 153 | 151 | 33 | 0.92 | +1621 | +49.1 |
| BLOCKED WHEEL | 31 | 31 | 31 | 0.86 | +751 | +24.2 |
| SET UP TOGETHER | 64 | 59 | 30 | 0.83 | +1738 | +57.9 |
| STOPS SHORT OF THE FLANK | 29 | 29 | 29 | 0.81 | +734 | +25.3 |
| INVITES THE FIGHT | 128 | 128 | 28 | 0.78 | +251 | +9.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MARCH CHECK | 31 | 30 | 26 | 0.72 | +1895 | +72.9 |
| MISSILES IN THE MOVE | 226 | 142 | 26 | 0.72 | +363 | +14.0 |
| MOVE AND CAST | 26 | 26 | 26 | 0.72 | +1333 | +51.3 |
| REDIRECT WEIGHED | 25 | 25 | 25 | 0.69 | +1427 | +57.1 |
| CAST JOB | 48 | 48 | 24 | 0.67 | +679 | +28.3 |
| WHOLE FIGHT GAIN | 44 | 40 | 24 | 0.67 | +1151 | +48.0 |
| BEST MOVE FOR SHOOTERS | 23 | 23 | 23 | 0.64 | +1398 | +60.8 |
| MARCH ODDS | 23 | 23 | 23 | 0.64 | +494 | +21.5 |
| SHOOTS FROM THE BEST SPOT | 54 | 54 | 23 | 0.64 | +683 | +29.7 |
| SHOT REPLANNED | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| ONE YARDSTICK | 321 | 101 | 20 | 0.56 | +92 | +4.6 |
| STAY WORTH | 291 | 218 | 20 | 0.56 | +108 | +5.4 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +1021 | +51.1 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| BEST PREY | 63 | 63 | 17 | 0.47 | +826 | +48.6 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| HONEST THREAT | 209 | 209 | 17 | 0.47 | +0 | +0.0 |
| STUCK PIVOT | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 16 | 16 | 16 | 0.44 | +1025 | +64.1 |
| KEEPS ITS TARGET | 113 | 112 | 16 | 0.44 | +236 | +14.8 |
| KEEPS THE TARGET | 25 | 25 | 16 | 0.44 | -940 | -58.7 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +1184 | +74.0 |
| FIRE IN ORDER | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -25 | -1.8 |
| HONEST WORTH | 317 | 315 | 14 | 0.39 | +168 | +12.0 |
| MAKE SURE TOGETHER | 39 | 29 | 13 | 0.36 | +892 | +68.6 |
| MODEL FACING | 12 | 12 | 12 | 0.33 | +1620 | +135.0 |
| WHOLE FIGHT | 36 | 35 | 12 | 0.33 | +717 | +59.8 |
| CASTING BLOCK | 16 | 16 | 10 | 0.28 | +641 | +64.1 |
| LOST CHARGE | 176 | 174 | 10 | 0.28 | +186 | +18.6 |
| MANOEUVRE | 12 | 12 | 10 | 0.28 | +418 | +41.8 |
| SUPPORT NARROWED | 507 | 507 | 10 | 0.28 | -137 | -13.7 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -154 | -17.2 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WEARS DOWN | 95 | 88 | 9 | 0.25 | +360 | +40.0 |
| BACKUP TARGETS | 82 | 47 | 8 | 0.22 | +29 | +3.7 |
| MISSILES NEXT TURN | 283 | 173 | 8 | 0.22 | +59 | +7.3 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +330 | +41.2 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -144 | -20.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| SHOOTERS ARE THREATS | 85 | 85 | 7 | 0.19 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -320 | -45.7 |
| WIDER SPREAD | 131 | 125 | 7 | 0.19 | +40 | +5.7 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +212 | +35.3 |
| LONG SHOT | 41 | 37 | 6 | 0.17 | -13 | -2.2 |
| WAR ENGINE JOBS | 23 | 23 | 6 | 0.17 | -120 | -20.0 |
| FIRE AND FLEE | 5 | 5 | 5 | 0.14 | +38 | +7.6 |
| OPENS UP | 13 | 13 | 5 | 0.14 | +261 | +52.2 |
| OVERRUNS AWAY | 39 | 39 | 5 | 0.14 | +89 | +17.8 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 5 | 0.14 | +227 | +45.3 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| DEFENSIVE FLOOR | 6 | 6 | 4 | 0.11 | +199 | +49.7 |
| NEEDED THERE | 5 | 5 | 4 | 0.11 | +0 | +0.0 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +216 | +54.1 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -207 | -51.8 |
| REFUSING RETIRES | 15 | 15 | 4 | 0.11 | -2 | -0.5 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +422 | +105.6 |
| CHAFF PASSED | 3 | 3 | 3 | 0.08 | -11 | -3.6 |
| HUNT IN PAIRS | 28 | 14 | 3 | 0.08 | +221 | +73.6 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +227 | +75.8 |
| SPELLS IN THE FIGHT | 34 | 30 | 3 | 0.08 | +61 | +20.3 |
| CARRIES OUT SET-UP | 4 | 4 | 2 | 0.06 | -48 | -23.9 |
| CHARGE BAND | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 2 | 0.06 | -174 | -87.0 |
| TWO OR MORE ARRIVE | 24 | 23 | 2 | 0.06 | +5 | +2.5 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.06 | +138 | +68.9 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CARRIES OUT COUNTER | 5 | 5 | 1 | 0.03 | -87 | -86.9 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 5 | 5 | 1 | 0.03 | -3 | -2.8 |
| EDGE GIVE GROUND | 13 | 13 | 1 | 0.03 | +7 | +6.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +24 | +24.5 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +7 | +6.6 |
| OPENS A LANE | 20 | 6 | 1 | 0.03 | +1 | +0.6 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -88 | -87.9 |
| STOPS | 7 | 7 | 1 | 0.03 | +10 | +9.5 |
| SURE REACH TOGETHER | 25 | 20 | 1 | 0.03 | +0 | +0.0 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 9 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 25 | 25 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 44 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 26 | 24 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 14 | 14 | 0 | 0.00 | - | - |
| CHEAP HELPER | 11 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 45 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 384 | not checked | - | - | - | - |
| GIVES UP | 6 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 31 | 29 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 40 | 40 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 10 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 7 | 7 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 10 | 8 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 26 | 2 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 16 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 12 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 28 | trace | - | - | - | - |
| MOVE SPELL SPOT | 23 | not checked | - | - | - | - |
| NOT NEEDED | 22 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 392 | 392 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 35 | not checked | - | - | - | - |
| PLAN RESULT | 2807 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 18 | 18 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 35 | 35 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 26 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTERS TO THE PRIMARY | 30 | 17 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 889 | 889 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 139 | not checked | - | - | - | - |
| STABLE ROLE | 746 | 745 | 0 | 0.00 | - | - |
| TURN WORTH | 32 | 32 | 0 | 0.00 | - | - |

### Off best figure: ch-h2h-opp-ea652ef-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.75 | 11.78 | 53.0 |
| FALLBACK | gate | 0.58 | 0.72 | 38.7 |
| CHARGE NOW FIRST | rule | 0.61 | 0.50 | 53.3 |
| TURN GATE | gate | 0.61 | 0.44 | 37.5 |
| FIRE PLAN | rule | - | 0.36 | 46.8 |
| KEEPS THE TARGET | rule | - | 0.36 | 81.3 |
| SUPPORT REQUEST | gate | 0.14 | 0.17 | 65.3 |
| FIGHT ORDER BAND | gate | 0.25 | 0.03 | 1.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.25 | 0.03 | 85.1 |
| SUPPORT NARROWED | rule | 0.14 | 0.14 | 13.7 |
| CANNON PLANNED TARGET | rule | 0.25 | - | 29.4 |
| PATHS CROSS | rule | 0.22 | 0.03 | 7.5 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.08 | 17.2 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 2.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.08 | 45.7 |
| BEST PRIZE | rule | 0.03 | 0.14 | 24.0 |
| WAR ENGINE JOBS | rule | 0.17 | - | 20.0 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.08 | 11.0 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.08 | 69.9 |
| PURSUES BIG PREY | rule | 0.06 | 0.06 | 51.8 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 8.4 |
| LONG SHOT | rule | - | 0.08 | 11.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.06 | 54.9 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 23.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 87.0 |
| MARCH ODDS | rule | 0.03 | 0.03 | 11.6 |
| NO REASON | gate | - | 0.06 | 3.5 |
| BLOCKED WHEEL | rule | 0.03 | - | 1.5 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 86.9 |
| CHAFF PASSED | rule | 0.03 | - | 10.3 |
| DEFENSIVE ARMY | rule | 0.03 | - | 2.8 |
| FALLBACK BY WORTH | rule | 0.03 | - | 15.9 |
| REDIRECT WEIGHED | rule | - | 0.03 | 8.6 |
| REFUSING RETIRES | rule | - | 0.03 | 0.9 |
| RULE SWITCHED OFF | gate | 0.03 | - | 15.7 |
| SAFE SURE CHARGE | rule | 0.03 | - | 87.9 |
| SAFER THAN THE JOB | rule | 0.03 | - | 21.2 |

### Plans: ch-h2h-opp-ea652ef-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.1 | 17% | 399 | 309 | 77% |
| Mine | charge | 3.6 | 58% | 258 | 345 | 134% |
| Mine | close in | 4.2 | 21% | 254 | 108 | 43% |
| Mine | hold | 4.4 | 36% | 240 | 0 | 0% |
| Mine | join | 0.6 | 95% | 9 | 0 | 0% |
| Mine | shoot | 9.0 | 63% | 342 | 826 | 241% |
| Mine | support | 4.5 | 90% | 55 | 0 | 0% |
| Opponent | advance | 14.2 | 21% | 344 | 489 | 142% |
| Opponent | charge | 5.0 | 59% | 389 | 523 | 134% |
| Opponent | close in | 5.0 | 25% | 278 | 150 | 54% |
| Opponent | hold | 4.7 | 31% | 319 | 0 | 0% |
| Opponent | join | 0.7 | 100% | 28 | 0 | 0% |
| Opponent | shoot | 3.9 | 53% | 146 | 244 | 168% |
| Opponent | support | 6.0 | 93% | 47 | 0 | 0% |

### Packages: hunt the guns, ch-h2h-opp-ea652ef-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 2.0 | 315 | 261 | 50% | 29 |
| Opponent | 0.2 | 8 | 0 | 25% | 38% | 0% | 2.3 | 287 | 88 | 38% | 121 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 545 | 523 | 100% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 185 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 84 | 0 | 0% | 128 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 188 | 0 | 0% | 94 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 424 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.6 | 5 | 0 | 40% | 60% | 0% | 2.3 | 367 | 142 | 60% | 19 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 85 | 0 | 0% | 34 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 200 |

### Battle groups: ch-h2h-opp-ea652ef-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.1 | 31% | 44% | 11% | 18% | 33% | 15% | 11% | 41% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 33% | 64% | 16% | 25% | 19% | 5% | 5% | 71% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.9 | 22% | 67% | 24% | 54% | 34% | 7% | 17% | 41% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 18% | 84% | 16% | 25% | 19% | 0% | 14% | 62% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ch-h2h-opp-ea652ef-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 171 (4) | 171 | 0 | 38 | 0% | 2.8 | - | 171 (4) | - | - | 171 (4) |
| Mine | Chaff | 34 | 21 (34) | 19 | 2 | 61 | 35% | 2.4 | 11 (14) | 0 (5) | 36 (15) | 14 (20) | 30 (14) |
| Mine | Character | 106 | 43 (106) | 43 | 0 | 41 | 14% | 2.4 | 54 (30) | 43 (50) | 52 (6) | 56 (41) | 40 (45) |
| Mine | Clean-up | 23 | 52 (23) | 22 | 30 | 48 | 35% | 2.3 | 0 (2) | 59 (17) | 54 (4) | 88 (11) | 29 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 55 (4) | 55 | 0 | 100 | 25% | 3.7 | 111 (2) | 0 (2) | - | 76 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 54 (41) | 34 | 20 | 56 | 20% | 2.5 | 36 (27) | 88 (9) | 86 (5) | 53 (25) | 54 (16) |
| Mine | Fragile | 4 | 57 (4) | 57 | 0 | 54 | 25% | 2.0 | 0 (1) | 78 (3) | - | 0 (1) | 78 (3) |
| Mine | Hammer | 64 | 34 (64) | 22 | 11 | 56 | 14% | 2.7 | 36 (13) | 35 (44) | 21 (7) | 43 (39) | 23 (25) |
| Mine | Holder | 31 | 68 (31) | 7 | 61 | 27 | 35% | 3.0 | 24 (5) | 109 (17) | 21 (8) | 91 (19) | 38 (11) |
| Mine | Shooter | 34 | 79 (34) | 45 | 34 | 51 | 3% | 1.6 | 54 (8) | 98 (21) | 40 (5) | 82 (25) | 70 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 64 (56) | 64 | 0 | 42 | 5% | 1.3 | 107 (16) | 55 (30) | 3 (10) | 81 (9) | 60 (47) |
| Mine | Wizard | 17 | 12 (17) | 12 | 0 | 14 | 0% | 2.9 | 63 (4) | 0 (9) | 0 (1) | 42 (6) | 0 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 77 | 33 (77) | 11 | 23 | 53 | 44% | 2.7 | 33 (32) | 26 (18) | 40 (27) | 40 (58) | 8 (19) |
| Opponent | Character | 97 | 67 (97) | 66 | 1 | 29 | 16% | 2.4 | 75 (44) | 57 (41) | 85 (8) | 68 (55) | 68 (38) |
| Opponent | Clean-up | 12 | 42 (12) | 17 | 25 | 66 | 25% | 3.6 | 29 (4) | 24 (5) | 87 (3) | 15 (7) | 60 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 36 (54) | 19 | 17 | 55 | 22% | 2.9 | 29 (22) | 43 (24) | 40 (8) | 42 (33) | 27 (21) |
| Opponent | Fragile | 17 | 27 (17) | 27 | 0 | 57 | 47% | 1.3 | 0 (5) | 55 (8) | 0 (4) | 33 (14) | 0 (3) |
| Opponent | Hammer | 65 | 51 (65) | 37 | 14 | 44 | 26% | 3.5 | 8 (20) | 71 (38) | 0 (7) | 55 (41) | 43 (24) |
| Opponent | Holder | 30 | 34 (30) | 4 | 30 | 20 | 57% | 4.2 | 0 (9) | 48 (15) | 39 (6) | 48 (17) | 17 (13) |
| Opponent | Shooter | 34 | 80 (34) | 19 | 60 | 30 | 0% | 1.6 | 44 (10) | 103 (21) | 37 (3) | 66 (19) | 96 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 49 | 50% | 2.0 | 0 (3) | - | - | - | 0 (3) |
| Opponent | War machine | 6 | 162 (6) | 162 | 0 | 40 | 17% | 1.0 | 117 (3) | 226 (3) | - | 117 (3) | 226 (3) |
| Opponent | Wizard | 20 | 10 (20) | 10 | 0 | 25 | 15% | 2.2 | 4 (12) | 3 (3) | 30 (4) | 12 (14) | 3 (5) |

### Charged fights: ch-h2h-opp-ea652ef-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 218 | 91 | 2.5 | 1.2 | 36 | 19 | +18 | 2 of 10 | 7 of 10 | +120 | -8 |
| Mine | Chaos Dwarfs | 4 | 133 | 232 | 3.2 | 1.2 | 72 | 5 | +67 | 4 of 13 | 11 of 13 | +221 | +38 |
| Mine | Dwarfen Mountain Holds | 3 | 212 | 384 | 2.3 | 1.3 | 165 | 125 | +39 | 4 of 7 | 6 of 7 | -386 | +209 |
| Mine | Empire of Man | 5 | 767 | 123 | 1.4 | 1.0 | 88 | 140 | -52 | 2 of 7 | 5 of 7 | - | -52 |
| Mine | Grand Cathay | 4 | 380 | 194 | 2.8 | 1.0 | 70 | 19 | +52 | 3 of 11 | 9 of 11 | - | +52 |
| Mine | High Elf Realms | 4 | 282 | 249 | 3.5 | 1.1 | 71 | 0 | +71 | 3 of 14 | 12 of 14 | +151 | +65 |
| Mine | Kingdom of Bretonnia | 1 | 210 | 1019 | 7.0 | 1.1 | 146 | 67 | +78 | 4 of 7 | 5 of 7 | +210 | +56 |
| Mine | Lizardmen | 1 | 0 | 917 | 4.0 | 1.0 | 229 | 0 | +229 | 2 of 4 | 4 of 4 | - | +229 |
| Mine | Ogre Kingdoms | 2 | 57 | 202 | 3.5 | 1.1 | 58 | 72 | -14 | 4 of 7 | 3 of 7 | +122 | -37 |
| Mine | Skaven | 2 | 278 | 36 | 0.5 | 1.0 | 72 | 0 | +72 | 0 of 1 | 1 of 1 | - | +72 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 546 | 4.0 | 1.0 | 137 | 144 | -7 | 3 of 8 | 2 of 8 | - | -7 |
| Mine | Vampire Counts | 2 | 83 | 278 | 3.5 | 1.0 | 79 | 0 | +79 | 2 of 7 | 6 of 7 | - | +79 |
| Mine | Warriors of Chaos | 2 | 0 | 670 | 4.5 | 1.0 | 149 | 0 | +149 | 3 of 9 | 7 of 9 | - | +149 |
| **Mine** | all armies | 36 | 266 | 284 | 2.9 | 1.1 | 97 | 42 | +55 | 36 of 105 | 78 of 105 | +44 | +56 |
| Opponent | Empire of Man | 1 | 675 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 206 | 729 | 3.0 | 1.3 | 243 | 33 | +210 | 9 of 15 | 11 of 15 | +406 | +139 |
| Opponent | Lizardmen | 2 | 0 | 745 | 4.5 | 1.0 | 166 | 19 | +146 | 5 of 9 | 8 of 9 | - | +146 |
| Opponent | Orc & Goblin Tribes | 3 | 42 | 509 | 4.7 | 1.4 | 109 | 25 | +84 | 4 of 14 | 11 of 14 | +261 | +13 |
| Opponent | Skaven | 4 | 105 | 24 | 1.2 | 1.0 | 19 | 29 | -10 | 1 of 5 | 4 of 5 | - | -10 |
| Opponent | Tomb Kings of Khemri | 2 | 148 | 1122 | 5.0 | 1.2 | 224 | 102 | +123 | 4 of 10 | 8 of 10 | +140 | +118 |
| Opponent | Vampire Counts | 6 | 60 | 439 | 4.8 | 1.1 | 91 | 40 | +50 | 21 of 29 | 21 of 29 | +48 | +51 |
| Opponent | Warriors of Chaos | 7 | 0 | 497 | 3.4 | 1.2 | 145 | 57 | +88 | 13 of 24 | 16 of 24 | +139 | +78 |
| Opponent | Wood Elf Realms | 6 | 64 | 391 | 3.8 | 1.1 | 102 | 1 | +101 | 7 of 23 | 17 of 23 | +69 | +106 |
| **Opponent** | all armies | 36 | 91 | 485 | 3.6 | 1.2 | 135 | 37 | +99 | 64 of 129 | 96 of 129 | +186 | +82 |

### Effective charges: ch-h2h-opp-ea652ef-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 3 (net -46) | 0 | 2 (net +72) | 3 (net +24) | 0 | 2 (net +49) | 0 | 20% (2 of 10) |
| Mine | Chaos Dwarfs | 13 | 2 (net +0) | 0 | 1 (net +0) | 2 (net +46) | 1 (net +160) | 6 (net +73) | 1 | 8% (1 of 12) |
| Mine | Dwarfen Mountain Holds | 7 | 1 (net +0) | 0 | 2 (net +311) | 2 (net -386) | 0 | 2 (net +212) | 0 | 29% (2 of 7) |
| Mine | Empire of Man | 7 | 1 (net -476) | 0 | 2 (net +0) | 3 (net +168) | 0 | 1 (net -395) | 0 | 29% (2 of 7) |
| Mine | Grand Cathay | 11 | 0 | 0 | 1 (net -205) | 5 (net +132) | 1 (net +0) | 4 (net +29) | 0 | 9% (1 of 11) |
| Mine | High Elf Realms | 14 | 2 (net +116) | 0 | 3 (net +132) | 3 (net +50) | 1 (net +151) | 5 (net +13) | 0 | 21% (3 of 14) |
| Mine | Kingdom of Bretonnia | 7 | 1 (net +362) | 0 | 0 | 1 (net +0) | 1 (net +92) | 3 (net -39) | 1 | 0% (0 of 6) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +497) | 1 (net +255) | 0 | 1 (net +110) | 1 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 7 | 0 | 0 | 1 (net +55) | 1 (net +122) | 0 | 2 (net -92) | 3 | 25% (1 of 4) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +72) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 8 | 2 (net +243) | 0 | 3 (net -258) | 3 (net +77) | 0 | 0 | 0 | 38% (3 of 8) |
| Mine | Vampire Counts | 7 | 1 (net +0) | 0 | 2 (net +250) | 0 | 2 (net +28) | 2 (net +0) | 0 | 29% (2 of 7) |
| Mine | Warriors of Chaos | 9 | 1 (net +0) | 0 | 2 (net +250) | 1 (net +285) | 3 (net +153) | 2 (net +49) | 0 | 22% (2 of 9) |
| Opponent | High Elf Realms | 15 | 1 (net +0) | 1 (net +219) | 2 (net +115) | 2 (net +0) | 2 (net +304) | 5 (net +451) | 2 | 15% (2 of 13) |
| Opponent | Lizardmen | 9 | 0 | 0 | 1 (net +0) | 1 (net +310) | 1 (net +65) | 2 (net +124) | 4 | 20% (1 of 5) |
| Opponent | Orc & Goblin Tribes | 14 | 2 (net -49) | 0 | 1 (net +102) | 3 (net +292) | 1 (net +0) | 4 (net +74) | 3 | 9% (1 of 11) |
| Opponent | Skaven | 5 | 1 (net +0) | 1 (net +0) | 1 (net -145) | 0 | 0 | 2 (net +48) | 0 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 10 | 1 (net +0) | 0 | 2 (net +85) | 4 (net +97) | 0 | 3 (net +223) | 0 | 20% (2 of 10) |
| Opponent | Vampire Counts | 29 | 4 (net -119) | 1 (net +0) | 10 (net +120) | 8 (net +38) | 2 (net -30) | 3 (net +129) | 1 | 36% (10 of 28) |
| Opponent | Warriors of Chaos | 24 | 6 (net +151) | 0 | 4 (net -18) | 1 (net +420) | 3 (net +134) | 5 (net -20) | 5 | 21% (4 of 19) |
| Opponent | Wood Elf Realms | 23 | 3 (net +0) | 0 | 4 (net +148) | 2 (net +18) | 6 (net +77) | 5 (net +43) | 3 | 20% (4 of 20) |

### Charged fights, damage counted: ch-h2h-opp-ea652ef-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 299 | 434 | +33 | 102 | 93 | +9 | +2.9 |
| Mine | Effective (55-75%) | 20 | 229 | 260 | +87 | 168 | 59 | +110 | +48.0 |
| Mine | 76-89% | 25 | 252 | 179 | +64 | 128 | 69 | +59 | +23.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 207 | 153 | +23 | 86 | 47 | +39 | +18.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 496 | 109 | +102 | 102 | 6 | +96 | +19.4 |
| Mine | No odds | 6 | 178 | 238 | +58 | 73 | 18 | +56 | +31.3 |
| Mine | All fights | 105 | 257 | 218 | +55 | 115 | 56 | +59 | +23.0 |
| Opponent | Long shot (under 50%) | 18 | 191 | 280 | +19 | 99 | 66 | +33 | +17.2 |
| Opponent | 50-54% | 3 | 199 | 201 | +73 | 78 | 24 | +54 | +27.1 |
| Opponent | Effective (55-75%) | 25 | 322 | 251 | +83 | 193 | 99 | +95 | +29.5 |
| Opponent | 76-89% | 21 | 386 | 264 | +111 | 137 | 42 | +95 | +24.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 262 | 173 | +140 | 185 | 56 | +129 | +49.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 470 | 102 | +99 | 116 | 14 | +102 | +21.7 |
| Opponent | No odds | 18 | 301 | 194 | +123 | 205 | 75 | +130 | +43.1 |
| Opponent | All fights | 129 | 312 | 213 | +99 | 159 | 60 | +99 | +31.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ch-h2h-opp-ea652ef-p4 | move | 434 | 90 (21%) | 65 (15%) | 64 (15%) | 280 (65%) |
| ch-h2h-opp-ea652ef-p4 | objective | 336 | 39 (12%) | 31 (9%) | 51 (15%) | 246 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

# Doctrine scorecard: ch-h2h-mine-ea652ef-p4

### Scorecard: ch-h2h-mine-ea652ef-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 4 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 4 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 3 | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 4 | 3 | 4 | 2 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 5 | 2 | 1 | 1 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 2 | 3 | 1 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 5 | 3 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 3 | 1 | 4 | 0 | 0 | 0 | 170 |
| L0417 | 3 | 1 | Mine | yes | 3 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 98 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1331 |
| L0520 | 4 | 1 | Opponent | no | 0 | 5 | 1 | 5 | 2 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 1012 |
| L0624 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 8 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 5 | 0 | 0 | 2 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 1 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 3 | 5 | 0 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 5 | 3 | 8 | 0 | 2 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 605 |
| L0819 | 3 | 1 | Opponent | no | 6 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 2 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 726 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 6 | 4 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 5 | 4 | 1 | 0 | 2 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 27 |
| L1126 | 4 | 1 | Mine | no | 0 | 4 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 4 | 2 | 8 | 1 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | no | - | 4 | 3 | 1 | 1 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 3 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 177 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 72 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 500 |
| L1719 | 3 | 1 | Mine | no | 3 | 2 | 7 | 0 | 1 | 0 | 0 | 184 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 0 | 4 | 7 | 1 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 0 | 0 | 0 | 0 | 255 |
| L1835 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 3 | 2 | 4 | 0 | 0 | 0 | 126 |
| L2021 | 5 | 1 | Mine | yes | - | - | 2 | 2 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 6 | 1 | 4 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | no | - | 3 | 0 | 4 | 1 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 2 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 3 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | yes | 5 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 2 | 5 | 2 | 1 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 4 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 5 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 1.7 | 3.0 | 2.6 | 1.0 | 0.4 | 0.0 | 0.0 | 279.5 |
| **Average** | | | Opponent | 43% | 2.5 | 2.5 | 3.1 | 1.9 | 0.5 | 0.0 | 0.0 | 109.6 |

### KPIs: ch-h2h-mine-ea652ef-p4

Rules off - Opponent only: CHARGE BAND, HONEST WORTH, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (39 of 174) | 2% (3 of 182) | 12% (42 of 356) |
| Winner chose to follow up after the loser gave ground |  | 97% (64 of 66); on the table 97% | 98% (61 of 62); on the table 98% | 98% (125 of 128); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (12 of 14); on the table 86% | 87% (20 of 23); on the table 87% | 86% (32 of 37); on the table 86% |
| Winner chose to pursue after the loser fled |  | 65% (13 of 20); on the table 70% | 73% (22 of 30); on the table 80% | 70% (35 of 50); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 89% (89 of 100); on the table 90% | 90% (103 of 115); on the table 91% | 89% (192 of 215); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 37% (98 of 268) | 42% (71 of 170) | 39% (169 of 438) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (98 of 194) | 53% (71 of 133) | 52% (169 of 327) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 36% (47 of 132) | 38% (33 of 87) | 37% (80 of 219) |
|     round 1 |  | 23% (5 of 22) | 27% (4 of 15) | 24% (9 of 37) |
|     rounds 2+ |  | 38% (42 of 110) | 40% (29 of 72) | 39% (71 of 182) |
|   other wizards | 50%+ | 38% (51 of 136) | 43% (34 of 79) | 40% (85 of 215) |
|     round 1 |  | 13% (3 of 23) | 36% (5 of 14) | 22% (8 of 37) |
|     rounds 2+ |  | 42% (48 of 113) | 45% (29 of 65) | 43% (77 of 178) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 61% (23 of 38) | 57% (32 of 56) | 59% (55 of 94) |
| Points that never fought | lower | 32% (21406 of 67942) | 32% (23229 of 71984) | 32% (44635 of 139926) |
|   infantry points that never fought | lower | 38% (5830 of 15347) | 60% (8331 of 13804) | 49% (14161 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (158 of 270) | 55% (155 of 280) | 57% (313 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 82% (18 of 22); 1.5 uses a game | 89% (8 of 9); 0.6 uses a game | 84% (26 of 31); 1.0 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.5 uses a game | 40% (8 of 20); 0.4 uses a game | 50% (18 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 67% (10 of 15); 0.3 uses a game | 56% (19 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (29931 of 57750) | 49% (30938 of 63347) | 50% (60869 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (25%) | 1.0 (36%) | 2.2 (29%) |
| MARCHED: its unit marched | 1.1 (24%) | 0.4 (14%) | 1.5 (20%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.1 (4%) | 0.4 (5%) |
| IN COMBAT: engaged in combat | 1.2 (26%) | 0.5 (18%) | 1.7 (23%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 0.7 (15%) | 0.4 (15%) | 1.1 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.0 (1%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.4 | 1.8 | 4.7 | 0.3 | 1.9 |
| not cast | 3.0 | 2.6 | 3.0 | 7.5 | 1.7 | 21.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (50%) | 0.2 (6%) | 2.2 (29%) | 0.6 (35%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (20%) | 0.6 (34%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (5%) | 0.2 (10%) | 0.6 (19%) | 1.7 (23%) | 0.3 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.1 (3%) | 0.2 (7%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (2%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.6 (21%) | 0.4 (15%) | 0.6 (19%) | 1.1 (15%) | 0.1 (3%) | 3.0 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (13%) | 0.1 (2%) | 0.2 (6%) | 0.2 (2%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (2%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.3 (13%) | 0.0 (0%) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (53%) | 0.1 (3%) | 1.2 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.2 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.5 a game | 1.0 a game |
| stood (cast and not dispelled) | 53% (25 of 47) | 86% (6 of 7) | 57% (31 of 54) |
| the unit moved after it | 64% (16 of 25) | 50% (3 of 6) | 61% (19 of 31) |
| it charged on its next turn | 4% (1 of 25) | 0% (0 of 6) | 3% (1 of 31) |
| the enemy charged it first | 16% (4 of 25) | 0% (0 of 6) | 13% (4 of 31) |
| it fought by the end of its next turn | 8% (2 of 25) | 0% (0 of 6) | 6% (2 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 24% (6 of 25) | 0% (0 of 6) | 19% (6 of 31) |
| none of these (no charge, no fight, no charge escaped) | 56% (14 of 25) | 100% (6 of 6) | 65% (20 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (559 of 868) | 51% (276 of 540) | 59% (835 of 1408) |
|   cavalry | 66% (55 of 83) | 65% (70 of 107) | 66% (125 of 190) |
|   character | 38% (38 of 101) | 15% (19 of 130) | 25% (57 of 231) |
|   chariot | 51% (55 of 107) | 53% (9 of 17) | 52% (64 of 124) |
|   infantry | 62% (164 of 263) | 61% (141 of 230) | 62% (305 of 493) |
|   monster | 49% (26 of 53) | 31% (8 of 26) | 43% (34 of 79) |
|   war machine | 85% (221 of 261) | 97% (29 of 30) | 86% (250 of 291) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.6 (18%) | 1.4 (19%) | 2.9 (18%) |
| CHARGED: it charged | 1.5 (17%) | 1.7 (23%) | 3.2 (20%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (3%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.4 (6%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.9 (22%) | 1.5 (20%) | 3.4 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.6 (9%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (17%) | 1.4 (19%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.2 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.5 | 1.6 | 80% | 6.2 pts | 34 pts |
| character | 1.8 | 0.4 | 86% | 8.0 pts | 15 pts |
| chariot | 1.8 | 0.9 | 75% | 13.1 pts | 24 pts |
| infantry | 12.5 | 4.1 | 76% | 8.7 pts | 109 pts |
| monster | 1.1 | 0.2 | 84% | 5.2 pts | 5 pts |
| war machine | 6.9 | 5.9 | 58% | 25.3 pts | 175 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 6.7 | 5.5 |
| Charges that made contact a game | 3.3 | 4.8 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.76 declared, 0.59 contact (17 units) | 0.53 declared, 0.47 contact (17 units) | 0.65 declared, 0.53 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.44 declared, 0.44 contact (9 units) | 1.75 declared, 1.08 contact (12 units) | 1.19 declared, 0.81 contact (21 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.44 contact (243 units) | 0.71 declared, 0.50 contact (300 units) | 0.64 declared, 0.47 contact (543 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (44 of 81) | 25% (4 of 16) | 67% (4 of 6) | 50% (52 of 103) |
| Character in a unit | 93% (26 of 28) | 75% (12 of 16) | 100% (1 of 1) | 87% (39 of 45) |
| Character on its own | 70% (26 of 37) | 42% (11 of 26) | 27% (21 of 77) | 41% (58 of 140) |
| Chariot | 80% (12 of 15) | 58% (7 of 12) | - | 70% (19 of 27) |
| Infantry | 60% (50 of 83) | 44% (11 of 25) | 50% (3 of 6) | 56% (64 of 114) |
| Monster | 74% (25 of 34) | 57% (8 of 14) | - | 69% (33 of 48) |
| Monstrous | 64% (9 of 14) | 57% (8 of 14) | - | 61% (17 of 28) |
| War Machines | 67% (29 of 43) | 100% (2 of 2) | - | 69% (31 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 81% (13 of 16); on the table 81% | 35% (36 of 102) | 11% | 68% (15 of 22) | 83% (5 of 6); 3.0 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (6 of 6); on the table 100% | 50% (12 of 24) | 17% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (13 of 13); on the table 100% | - | 57% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 71% (5 of 7); on the table 86% | 50% (9 of 18) | 53% | 60% (37 of 62) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 100% (19 of 19); on the table 100% | 40% (34 of 84) | 53% | 46% (17 of 37) | 89% (8 of 9); 7.5 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 94% (33 of 35); on the table 94% | 14% (5 of 36) | 24% | 43% (30 of 70) | 86% (6 of 7); 2.0 uses a game | 50% (15 of 30); 2.6 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 33% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 83% (5 of 6); on the table 83% | 83% (5 of 6) | 35% | 57% (12 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 86% (6 of 7); on the table 86% | 67% (4 of 6) | 37% | 79% (11 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 88% (7 of 8); on the table 100% | 45% (19 of 42) | 13% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 82% (9 of 11); on the table 82% | 31% (12 of 39) | 37% | 73% (33 of 45) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 79% (11 of 14); on the table 79% | 0% (0 of 6) | 33% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 91% (30 of 33); on the table 94% | 39% (22 of 57) | 26% | 45% (19 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 88% (21 of 24); on the table 88% | 58% (7 of 12) | 26% | 58% (42 of 72) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 87% (13 of 15); on the table 87% | 67% (4 of 6) | 34% | 61% (34 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (ch-h2h-mine-ea652ef-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (50) | 49% (39) | 47% (89) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.75 | 1.50 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.19 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.53 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.58 | 1.44 | 3.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.56 | 0.75 | 1.31 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.56 | 6.28 | 11.83 |

### Quality by phase: ch-h2h-mine-ea652ef-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 52% (72 of 139) | 50% (106 of 210) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (126 of 381) | 50% (77 of 153) |
| Strategy | Close-in objectives charged next turn | 15% (21 of 136) | 18% (40 of 226) |
| Strategy | Support requests answered (helper made contact too) | 68% (15 of 22) | 55% (18 of 33) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 69% (9 of 13) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 56% (19 of 34) | 45% (13 of 29) |
| Strategy | Lone characters that fought | 76% (68 of 89) | 82% (71 of 87) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 1.9 |
| Movement | Points that never moved of their own | 279.5 | 109.6 |
| Movement | Fights charged into per game | 3.1 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 99, net +74 | 30 of 129, net +51 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 99, net +8 | 16 of 129, net +34 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 99, net +79 | 14 of 129, net +103 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 of 99, net +91 | 39 of 129, net +106 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 8.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (146 of 362) | 43% (126 of 291) |
| Shooting | Points destroyed by shooting units | 106.1 | 55.3 |
| Shooting | War machine shots | 6.1 | 0.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (100 of 221) | 7% (2 of 29) |
| Shooting | Points destroyed by war machines | 82.5 | 13.8 |
| Magic | Magic missiles cast | 1.9 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (18 of 69) | 33% (16 of 48) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.7 |
| Magic | Wounds caused by other spells | 1.8 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 72.4 | 28.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.4 / 0.7 / 0.2 | 1.8 / 0.4 / 0.6 / 0.0 |
| Combat | Points destroyed in combat | 260.5 | 463.6 |
| Combat | Points run down | 92.3 | 73.6 |
| Combat | Net points per charged fight, damage counted | +38 | +85 |
| Combat | Net per 100 charger points, damage counted | +14.3 | +27.9 |
| Combat | First round won (charged fights) | 69% | 68% |
| Combat | Net points per charged fight | +43 | +92 |
| Combat | Net points per supported fight / lone fight | +30 / +44 | +146 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 110 | 69 of 145 |
| Game | Points lost | 808.2 | 691.4 |
| Game | VP from objectives | 470.6 | 541.1 |
| Game | Lone holders (player turns) | 1.7 | 2.5 |

- Mine won / drew / lost: 9 / 12 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -178 VP
- The side that went first won 12 of 24 games with a winner
- Points traded per game (both sides' losses): 1500
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ch-h2h-mine-ea652ef-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 12.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.8 | +5.7 | 0.0 | 35.8 | 1.3 | +13.5 | 0.0 | 38.9 |
| BEST FACING | 0.7 | +41.3 | 0.0 | 49.2 | 0.7 | +26.7 | 0.0 | 46.5 |
| BEST FIRST | 4.5 | +136.4 | 143.3 | 105.9 | 3.8 | +151.2 | 100.3 | 63.7 |
| BEST MOVE FOR SHOOTERS | 1.2 | +74.5 | 0.0 | 12.4 | - | - | - | - |
| BEST OVERALL | 0.4 | +51.2 | 0.0 | 0.0 | 0.7 | +34.5 | 0.0 | 34.5 |
| BEST PREY | 0.6 | +29.8 | 30.7 | 3.9 | 1.0 | +32.6 | 26.2 | 12.9 |
| BEST PRIZE | 0.0 | -0.1 | 1.5 | 0.0 | 0.1 | -2.1 | 1.4 | 5.4 |
| BIG CHARACTER SAFETY | 0.1 | -0.5 | 0.0 | 0.0 | 0.4 | -0.0 | 0.0 | 55.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.0 | 3.9 | 0.2 | +0.0 | 24.6 | 0.0 |
| BLOCKED WHEEL | 0.5 | +6.4 | 0.0 | 0.0 | 0.6 | -1.5 | 0.0 | 5.4 |
| BLOWS WHERE AIMED | 0.2 | -10.7 | 17.7 | 15.3 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.1 | +0.0 | 6.4 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 0.6 | +29.8 | 60.6 | 3.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 2.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 16.6 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -1.0 | 4.7 | 6.0 | 0.1 | +0.0 | 13.4 | 0.0 |
| CAST JOB | 0.7 | +24.5 | 32.5 | 14.5 | 0.4 | +8.5 | 24.2 | 14.1 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +33.1 | 3.4 | 0.0 | 0.0 | +2.1 | 3.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 18.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.2 | -1.4 | 3.3 | 5.3 |
| CHARGE BAND | 0.2 | +0.0 | 22.2 | 4.2 | - | - | - | - |
| CHARGE NOW FIRST | 2.6 | +0.0 | 241.7 | 82.0 | 3.0 | +0.0 | 290.1 | 25.4 |
| CHARGE NOW WEIGHED | 0.5 | -45.0 | 1.5 | 18.5 | 0.5 | -29.2 | 13.2 | 11.4 |
| CHARGER SLAIN LOST | 0.8 | -25.7 | 46.2 | 33.8 | - | - | - | - |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 4.7 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | -1.9 | 6.6 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.9 | 5.1 | 0.1 | +0.0 | 2.8 | 4.4 |
| COMBAT PIVOT | 0.5 | +0.0 | 15.4 | 14.4 | 0.6 | +0.0 | 7.4 | 24.6 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 1.7 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.9 | +131.4 | 12.6 | 20.4 | 0.1 | +34.5 | 0.0 | 7.6 |
| COUNTER-CHARGE COVER | 8.6 | +625.6 | 0.0 | 249.5 | 7.9 | +829.4 | 0.0 | 194.4 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 51.3 | 5.3 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.1 | 0.0 | 6.1 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +0.6 | 13.5 | 0.0 | 0.2 | +20.4 | 41.5 | 3.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | 10.2 | +0.0 | 723.8 | 212.2 | - | - | - | - |
| FACE THE CAST | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +121.3 | 0.0 | 53.2 | 1.4 | +97.9 | 0.0 | 78.7 |
| FALLBACK BY WORTH | 4.4 | +58.1 | 0.0 | 53.0 | 5.9 | +50.5 | 0.0 | 57.7 |
| FIGHT LIFT | 0.1 | +1.5 | 5.7 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.4 | 0.0 | 4.6 | - | - | - | - |
| FIRE IN ORDER | 0.7 | +0.0 | 64.5 | 16.2 | - | - | - | - |
| FIRE PLAN | 16.7 | +86.0 | 1170.9 | 320.2 | - | - | - | - |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 196.1 | 6.3 | +0.0 | 0.0 | 192.9 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.1 | 3.3 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +171.6 | 0.0 | 17.3 | 0.8 | +96.1 | 0.0 | 18.4 |
| FRIENDS SHOTS CHECKED | 0.1 | +6.0 | 0.0 | 20.6 | 0.2 | +11.1 | 0.0 | 8.5 |
| GIVES UP | 0.0 | -0.5 | 4.0 | 0.0 | 0.1 | -0.9 | 13.9 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.6 | 4.2 | 2.5 |
| GROUND FLIERS | 0.1 | +0.9 | 0.0 | 12.2 | 0.1 | +2.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 5.0 | 0.1 | +0.0 | 3.4 | 0.8 |
| HELPER UNSEEN | 0.3 | +0.0 | 6.2 | 9.4 | 0.6 | +0.0 | 32.7 | 12.5 |
| HILL BY ITS CHANCE | 0.5 | -54.8 | 0.0 | 5.8 | 0.6 | -69.0 | 0.0 | 10.4 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 10.2 | +1498.6 | 723.8 | 212.2 | - | - | - | - |
| HONEST WORTH | 7.1 | -138.3 | 344.1 | 125.3 | - | - | - | - |
| HUNT ADVANCE | 0.1 | +0.1 | 5.3 | 0.0 | 0.2 | +2.9 | 0.0 | 5.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 4.6 | 1.8 |
| HUNT IN PAIRS | 0.2 | +3.8 | 0.0 | 0.0 | 0.5 | +22.6 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.1 |
| HUNT RESULT | 0.1 | +5.4 | 0.0 | 0.0 | 0.3 | +7.0 | 4.6 | 12.9 |
| HUNT THE GUNS | 0.1 | +28.4 | 5.3 | 1.4 | 0.3 | +101.9 | 6.4 | 8.0 |
| INVITES THE FIGHT | 1.7 | +35.7 | 68.9 | 46.2 | 1.2 | +22.2 | 22.6 | 3.2 |
| JOINT CHARGE PLAN | 0.1 | +3.1 | 0.0 | 0.0 | 0.1 | +17.9 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.3 | 3.0 | 3.3 | - | - | - | - |
| KEEP FALLS | 0.1 | +2.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.1 | 1.5 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +47.5 | 155.3 | 24.2 | 2.1 | +63.3 | 189.1 | 9.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | 1.9 | -15.6 | 260.8 | 26.5 | - | - | - | - |
| KILLS COUNT | 1.4 | +55.1 | 89.7 | 51.6 | 2.2 | +101.0 | 212.2 | 23.1 |
| KILLS COUNT NEXT TURN | 4.6 | +135.2 | 132.1 | 72.2 | 7.9 | +273.4 | 270.1 | 172.4 |
| LONE CHARACTER SAFE SPOT | 0.3 | +18.9 | 7.1 | 1.2 | 0.2 | +13.7 | 4.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 10.7 | 7.6 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | +2.4 | 33.5 | 33.1 | 0.5 | -0.5 | 46.8 | 7.6 |
| LOST CHARGE | 3.1 | -39.2 | 104.5 | 63.1 | 1.6 | -26.5 | 85.2 | 65.6 |
| LURE BY WHAT IT DRAWS | 0.1 | -1.1 | 0.0 | 1.5 | - | - | - | - |
| MAKE SURE TOGETHER | 0.5 | +51.5 | 0.0 | 10.6 | 0.8 | +132.7 | 17.3 | 31.4 |
| MANOEUVRE | 0.4 | +13.3 | 0.0 | 10.3 | 0.2 | +7.5 | 0.0 | 3.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +19.5 | 0.0 | 2.2 | 0.3 | +8.0 | 0.0 | 19.4 |
| MARCH ODDS | 0.3 | +18.8 | 19.0 | 0.0 | 0.3 | +19.2 | 11.9 | 0.0 |
| MARCH OVER CASTS | 0.4 | +38.9 | 0.0 | 15.0 | 0.3 | +18.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.4 | +148.0 | 0.0 | 97.0 | 5.0 | +204.3 | 0.0 | 156.7 |
| MISSILES IN THE FIRE PLAN | 2.0 | +17.5 | 82.9 | 21.6 | - | - | - | - |
| MISSILES IN THE MOVE | 3.8 | +145.0 | 0.0 | 92.8 | 2.4 | +40.0 | 0.0 | 127.8 |
| MISSILES NEXT TURN | 4.6 | +90.1 | 0.0 | 110.1 | 2.9 | +30.5 | 0.0 | 111.4 |
| MODEL FACING | 0.2 | +30.6 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 9.1 | 10.6 | 0.1 | +0.0 | 4.8 | 0.0 |
| MOVE AND CAST | 0.3 | +14.2 | 0.0 | 5.5 | 0.2 | +9.6 | 0.0 | 3.2 |
| MOVE SPELL IN RANGE | 0.2 | +5.6 | 0.0 | 0.0 | 0.1 | +6.4 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.8 | -56.7 | 26.1 | 16.0 | 0.0 | -2.1 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 2.8 | +147.7 | 100.8 | 54.0 | 4.4 | +423.2 | 199.9 | 127.8 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.1 | 1.6 | 0.0 | 0.1 | +3.6 | 19.8 | 0.0 |
| NO RALLY LEFT | 0.1 | +5.3 | 0.0 | 6.9 | 0.0 | +4.8 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -12.5 | 51.7 | 0.0 | 0.5 | -21.4 | 74.6 | 3.8 |
| NOT TURNED | 5.6 | +113.5 | 0.0 | 169.4 | 6.3 | +62.6 | 0.0 | 120.2 |
| NOT WORTH A CAST | 0.6 | -17.5 | 0.0 | 0.0 | 0.5 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 16.1 | -795.9 | 4.8 | 309.7 | 13.5 | -779.9 | 9.3 | 235.3 |
| ONE YARDSTICK | 17.8 | -550.1 | 632.5 | 355.5 | - | - | - | - |
| OPENS A LANE | 0.2 | +1.5 | 43.4 | 2.1 | - | - | - | - |
| OPENS UP | 0.3 | +20.1 | 21.7 | 0.0 | 0.4 | +33.1 | 21.4 | 1.9 |
| OVERRUNS AWAY | 0.6 | +15.1 | 46.8 | 18.6 | 0.6 | +6.5 | 46.0 | 4.9 |
| PATHS CROSS | 2.2 | +145.4 | 0.0 | 48.2 | 3.1 | +289.1 | 0.0 | 47.4 |
| PERIAPT WORTH | 0.1 | +7.0 | 0.0 | 15.0 | 0.1 | +7.8 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.2 | -1.2 | 0.0 | 6.3 | 0.2 | -4.0 | 0.0 | 9.4 |
| PLAN RESULT | 38.1 | +1550.0 | 1656.4 | 1052.4 | 38.7 | +1459.4 | 1528.5 | 975.8 |
| PURSUES BIG PREY | 0.0 | -2.2 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.5 | 0.0 | 2.2 | 0.1 | +12.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.1 | +12.1 | 0.0 | 17.5 | 1.6 | +13.0 | 0.0 | 88.2 |
| RANDOM MOVER NO PROMISE | 0.4 | -18.1 | 5.9 | 9.4 | 0.3 | -17.4 | 0.0 | 24.4 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +1.1 | 0.0 | 2.0 | 0.3 | -10.2 | 0.0 | 1.9 |
| REDIRECT COUNTER | 2.4 | +190.5 | 0.0 | 39.4 | 3.8 | +294.4 | 0.0 | 99.9 |
| REDIRECT WEIGHED | 0.2 | +1.6 | 2.0 | 5.7 | 0.3 | +12.9 | 12.8 | 7.4 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 21.2 | - | - | - | - |
| RESERVE FALL BACK | 0.4 | +13.9 | 0.0 | 8.8 | 0.5 | +17.1 | 0.0 | 10.3 |
| RESTRAINS TO SHOOT | 0.1 | +3.2 | 0.0 | 0.0 | 0.1 | +2.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.6 | +81.8 | 192.1 | 98.9 | 3.1 | +63.3 | 287.4 | 49.9 |
| SAFE SURE CHARGE | 0.0 | -0.9 | 1.7 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.6 | +45.7 | 0.0 | 8.6 | 0.8 | +40.8 | 0.0 | 15.0 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -16.0 | 0.0 | 3.1 | 0.2 | -5.7 | 0.0 | 1.1 |
| SEARCH SPOT | 2.4 | +114.5 | 0.0 | 33.1 | 3.2 | +184.2 | 0.0 | 33.1 |
| SELF MOVE SPELL | 0.2 | +59.0 | 0.0 | 0.0 | 0.5 | +25.7 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.9 | +85.8 | 0.0 | 17.1 | 1.3 | +174.8 | 31.6 | 35.6 |
| SET-UP ANY TARGET | 0.6 | +67.4 | 10.2 | 18.1 | 0.0 | +5.3 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +17.4 | 10.1 | 9.3 | 0.1 | +19.1 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | 1.7 | +85.0 | 173.3 | 43.9 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 1.9 | +20.7 | 0.0 | 38.5 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.2 | +39.7 | 80.1 | 19.6 | 0.6 | +29.3 | 49.8 | 16.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 15.6 | +0.0 | 931.4 | 317.1 | 8.3 | +0.0 | 317.5 | 156.2 |
| SHOT REPLANNED | - | - | - | - | 0.2 | +0.0 | 43.2 | 0.0 |
| SHOTS IN THE MOVE | 14.9 | +636.9 | 0.0 | 266.1 | 7.0 | +173.6 | 0.0 | 109.3 |
| SPELL SETS UP CHARGE | 0.7 | +113.1 | 10.2 | 18.1 | 0.1 | +17.4 | 0.0 | 7.6 |
| SPELL WORTH | 1.5 | +27.0 | 64.0 | 54.9 | 2.1 | +39.1 | 80.2 | 77.5 |
| SPELLS IN THE FIGHT | 0.5 | -7.1 | 60.7 | 25.6 | - | - | - | - |
| STABLE ROLE | 10.8 | +0.0 | 468.9 | 238.9 | 9.9 | +0.0 | 283.2 | 101.9 |
| STANDS TO CAST | 0.0 | +1.3 | 3.4 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +6.4 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 17.2 | +124.7 | 705.6 | 240.8 | - | - | - | - |
| STOPS | 0.1 | +0.2 | 0.0 | 1.4 | 0.1 | +3.5 | 6.4 | 3.0 |
| STOPS SHORT OF THE FLANK | 0.3 | +25.7 | 0.0 | 7.8 | 0.6 | +18.5 | 0.0 | 31.3 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 14.6 |
| SUPPORT NARROWED | 5.4 | -37.9 | 365.3 | 91.5 | 8.7 | -63.1 | 492.0 | 117.5 |
| SUPPORTS | 3.3 | +43.7 | 214.2 | 51.2 | 5.6 | +63.1 | 176.3 | 63.0 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -11.2 | 24.1 | 1.4 | 0.1 | -2.8 | 3.8 | 1.7 |
| SURE REACH TOGETHER | 0.2 | -1.1 | 0.0 | 12.0 | 0.5 | -5.3 | 8.2 | 18.3 |
| THROUGH LINE OF FIRE | 0.3 | +23.9 | 0.0 | 15.0 | 0.2 | +4.0 | 0.0 | 4.5 |
| TURN WORTH | 0.2 | -13.6 | 19.8 | 0.0 | 0.5 | -50.2 | 31.3 | 3.3 |
| TWO OR MORE ARRIVE | 0.3 | +1.2 | 0.0 | 0.0 | 0.4 | +4.1 | 6.1 | 0.0 |
| WAIT AFTER COSTS | 6.1 | -286.1 | 224.7 | 110.9 | 7.8 | -398.3 | 277.8 | 182.8 |
| WALKS TO THE FIGHT | 1.3 | +18.0 | 49.2 | 10.6 | 1.2 | +23.3 | 17.2 | 9.8 |
| WAR ENGINE CHARGES | 0.2 | +17.7 | 21.5 | 5.1 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 51.9 | 24.0 | 0.2 | +0.0 | 2.2 | 12.1 |
| WEARS DOWN | 1.3 | +62.7 | 148.9 | 50.0 | 1.2 | +34.5 | 79.5 | 41.2 |
| WHO HITS BACK | 0.5 | +43.6 | 0.0 | 10.9 | 0.4 | +15.6 | 0.0 | 17.2 |
| WHOLE FIGHT | 0.4 | +19.3 | 25.5 | 25.2 | 0.6 | +21.8 | 71.4 | 5.3 |
| WHOLE FIGHT GAIN | 0.6 | +36.2 | 59.5 | 20.4 | 0.8 | +54.6 | 66.1 | 16.9 |
| WIDER SPREAD | 2.9 | -8.6 | 214.2 | 108.6 | - | - | - | - |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: ch-h2h-mine-ea652ef-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1065 | 1065 | 1065 | 29.58 | -56727 | -53.3 |
| BEST FIRST | 298 | 298 | 298 | 8.28 | +10354 | +34.7 |
| SEARCH SPOT | 204 | 204 | 202 | 5.61 | +10755 | +53.2 |
| PATHS CROSS | 190 | 190 | 190 | 5.28 | +15641 | +82.3 |
| FIRE PLAN | 602 | 602 | 162 | 4.50 | +1709 | +10.5 |
| MOVE TO CHARGE | 259 | 259 | 154 | 4.28 | +8511 | +55.3 |
| COUNTER-CHARGE COVER | 593 | 336 | 153 | 4.25 | +11659 | +76.2 |
| KILLS COUNT NEXT TURN | 449 | 449 | 124 | 3.44 | +3497 | +28.2 |
| FACES THE THREAT | 109 | 109 | 109 | 3.03 | +7889 | +72.4 |
| SUPPORTS | 319 | 319 | 101 | 2.81 | +1384 | +13.7 |
| EVERY WOUND COUNTS | 369 | 369 | 84 | 2.33 | +0 | +0.0 |
| FALLBACK BY WORTH | 371 | 371 | 83 | 2.31 | +3910 | +47.1 |
| WAIT AFTER COSTS | 501 | 501 | 72 | 2.00 | +1163 | +16.2 |
| FOLLOW UP WEIGHED | 70 | 70 | 70 | 1.94 | +9639 | +137.7 |
| SHOTS IN THE MOVE | 787 | 524 | 70 | 1.94 | +1911 | +27.3 |
| ONE YARDSTICK | 641 | 258 | 61 | 1.69 | +554 | +9.1 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 94 | 94 | 55 | 1.53 | +903 | +16.4 |
| CHARGE NOW FIRST | 200 | 200 | 53 | 1.47 | -3416 | -64.5 |
| WALKS TO THE FIGHT | 90 | 90 | 51 | 1.42 | +638 | +12.5 |
| BEST FACING | 49 | 49 | 49 | 1.36 | +2447 | +49.9 |
| REDIRECT COUNTER | 223 | 131 | 49 | 1.36 | +4590 | +93.7 |
| SAFER THAN THE JOB | 47 | 47 | 47 | 1.31 | +3114 | +66.2 |
| BEST MOVE FOR SHOOTERS | 43 | 43 | 43 | 1.19 | +2681 | +62.4 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| MAX FOR POSITIONING | 339 | 186 | 40 | 1.11 | +482 | +12.0 |
| BEST OVERALL | 38 | 38 | 38 | 1.06 | +3084 | +81.2 |
| COMBAT PIVOT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| BLOCKED WHEEL | 37 | 37 | 37 | 1.03 | +176 | +4.8 |
| SHOOTS FROM THE BEST SPOT | 65 | 65 | 36 | 1.00 | +1304 | +36.2 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 34 | 34 | 34 | 0.94 | +2172 | +63.9 |
| MISSILES IN THE MOVE | 224 | 133 | 33 | 0.92 | +869 | +26.3 |
| RESERVE FALL BACK | 33 | 33 | 33 | 0.92 | +1117 | +33.9 |
| SET UP TOGETHER | 80 | 67 | 33 | 0.92 | +3523 | +106.7 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +1591 | +48.2 |
| RISK BY ARC | 204 | 198 | 32 | 0.89 | +1463 | +45.7 |
| KILLS COUNT | 133 | 128 | 31 | 0.86 | +1419 | +45.8 |
| WHO HITS BACK | 31 | 31 | 31 | 0.86 | +1307 | +42.1 |
| KEEPS THE TARGET | 68 | 68 | 29 | 0.81 | -963 | -33.2 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| WHOLE FIGHT GAIN | 50 | 44 | 27 | 0.75 | +1077 | +39.9 |
| FIRE IN ORDER | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| STAY WORTH | 620 | 509 | 26 | 0.72 | +482 | +18.5 |
| CAST JOB | 39 | 39 | 24 | 0.67 | +470 | +19.6 |
| KEEPS ITS TARGET | 133 | 132 | 24 | 0.67 | +377 | +15.7 |
| INVITES THE FIGHT | 103 | 103 | 21 | 0.58 | +248 | +11.8 |
| MANOEUVRE | 24 | 24 | 21 | 0.58 | +751 | +35.7 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| MARCH CHECK | 24 | 22 | 20 | 0.56 | +819 | +40.9 |
| MARCH ODDS | 21 | 21 | 20 | 0.56 | +336 | +16.8 |
| BIG CHARACTER SAFETY | 18 | 18 | 18 | 0.50 | -19 | -1.1 |
| HONEST THREAT | 369 | 369 | 18 | 0.50 | +0 | +0.0 |
| MOVE AND CAST | 18 | 18 | 18 | 0.50 | +859 | +47.7 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +1001 | +55.6 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| OPENS UP | 26 | 26 | 17 | 0.47 | +643 | +37.8 |
| BEST PREY | 55 | 55 | 16 | 0.44 | +247 | +15.4 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +1003 | +62.7 |
| MAKE SURE TOGETHER | 48 | 35 | 14 | 0.39 | +2681 | +191.5 |
| WEARS DOWN | 91 | 87 | 14 | 0.39 | +513 | +36.7 |
| PIVOT GUARDS FLANK | 13 | 13 | 13 | 0.36 | -190 | -14.6 |
| WAR ENGINE JOBS | 35 | 35 | 13 | 0.36 | -603 | -46.4 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +618 | +51.5 |
| SURE CHARGE BEATS ADVANCE | 12 | 12 | 12 | 0.33 | -503 | -41.9 |
| WHOLE FIGHT | 36 | 36 | 12 | 0.33 | +827 | +68.9 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| CASTING BLOCK | 10 | 10 | 9 | 0.25 | +596 | +66.2 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SUPPORT NARROWED | 505 | 505 | 9 | 0.25 | -169 | -18.8 |
| SHOT REPLANNED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| CHAFF PASSED | 7 | 7 | 7 | 0.19 | -51 | -7.2 |
| HONEST WORTH | 256 | 254 | 7 | 0.19 | +97 | +13.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| SHOOTERS ARE THREATS | 61 | 61 | 7 | 0.19 | +0 | +0.0 |
| BACKUP TARGETS | 77 | 35 | 6 | 0.17 | +38 | +6.3 |
| CANNON PLANNED TARGET | 23 | 23 | 6 | 0.17 | -6 | -1.0 |
| CHARGE BAND | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +1100 | +183.3 |
| NO RALLY LEFT | 6 | 6 | 6 | 0.17 | +113 | +18.8 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 6 | 0.17 | +239 | +39.8 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +212 | +35.4 |
| WAR ENGINE CHARGES | 8 | 8 | 6 | 0.17 | +423 | +70.5 |
| LOST CHARGE | 172 | 171 | 5 | 0.14 | +45 | +9.0 |
| MISSILES NEXT TURN | 270 | 154 | 5 | 0.14 | +5 | +1.1 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +533 | +106.5 |
| JOINT CHARGE PLAN | 8 | 8 | 4 | 0.11 | +264 | +66.0 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 4 | 0.11 | -420 | -105.0 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +229 | +57.2 |
| SURE REACH TOGETHER | 28 | 24 | 4 | 0.11 | +6 | +1.4 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -79 | -26.4 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +38 | +12.7 |
| HUNT IN PAIRS | 28 | 13 | 3 | 0.08 | +133 | +44.3 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +141 | +46.9 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| DEFENSIVE ARMY | 7 | 7 | 2 | 0.06 | -23 | -11.3 |
| EDGE GIVE GROUND | 13 | 13 | 2 | 0.06 | +234 | +116.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 40 | 38 | 2 | 0.06 | +1 | +0.3 |
| MISSILES IN THE FIRE PLAN | 71 | 6 | 2 | 0.06 | +17 | +8.6 |
| OVERRUNS AWAY | 44 | 43 | 2 | 0.06 | +36 | +18.0 |
| REFUSING RETIRES | 5 | 5 | 2 | 0.06 | -0 | -0.2 |
| SHOOTERS TO THE PRIMARY | 67 | 45 | 2 | 0.06 | +9 | +4.5 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +10 | +5.0 |
| BLOWS WHERE AIMED | 6 | 6 | 1 | 0.03 | +127 | +127.4 |
| CARRIES OUT SET-UP | 5 | 5 | 1 | 0.03 | -36 | -36.5 |
| CHARGER SLAIN LOST | 27 | 24 | 1 | 0.03 | +14 | +14.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 3 | 3 | 1 | 0.03 | +5 | +5.4 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +30 | +29.7 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +5 | +5.2 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +14.9 |
| HILL BY ITS CHANCE | 39 | 39 | 1 | 0.03 | +25 | +24.6 |
| KEEPS ITS PREY | 5 | 5 | 1 | 0.03 | +0 | +0.0 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -79 | -78.6 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -32 | -32.3 |
| WIDER SPREAD | 104 | 100 | 1 | 0.03 | +2 | +2.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 37 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 413 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | not checked | - | - | - | - |
| GROUND FLIERS | 5 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 32 | 30 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 9 | 9 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 14 | trace | - | - | - | - |
| HUNT THE GUNS | 14 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 27 | 27 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 13 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 30 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NOT NEEDED | 27 | 27 | 0 | 0.00 | - | - |
| NOT TURNED | 426 | 426 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 38 | not checked | - | - | - | - |
| OPENS A LANE | 8 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2763 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 27 | 27 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 16 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 25 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 21 | not checked | - | - | - | - |
| SET-UP MISSED | 7 | trace | - | - | - | - |
| SHOT OPTIONS | 860 | 860 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 27 | not checked | - | - | - | - |
| SPELL WORTH | 129 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 18 | 16 | 0 | 0.00 | - | - |
| STABLE ROLE | 746 | 743 | 0 | 0.00 | - | - |
| STOPS | 5 | 5 | 0 | 0.00 | - | - |
| TURN WORTH | 26 | 26 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 27 | 26 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ch-h2h-mine-ea652ef-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.44 | 11.92 | 54.6 |
| CHARGE NOW FIRST | rule | 0.72 | 0.75 | 64.5 |
| FALLBACK | gate | 0.67 | 0.58 | 49.4 |
| TURN GATE | gate | 0.56 | 0.47 | 34.2 |
| KEEPS THE TARGET | rule | 0.64 | - | 58.9 |
| FIRE PLAN | rule | 0.56 | - | 61.7 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.19 | 14.6 |
| WAR ENGINE JOBS | rule | 0.33 | 0.03 | 46.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.25 | 0.06 | 45.7 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.19 | 6.2 |
| SUPPORT REQUEST | gate | 0.11 | 0.17 | 78.7 |
| AFTERMATH BAND | gate | 0.08 | 0.17 | 2.5 |
| SUPPORT NARROWED | rule | 0.06 | 0.19 | 18.8 |
| FIGHT ORDER BAND | gate | 0.17 | 0.06 | 1.7 |
| CHAFF PASSED | rule | - | 0.17 | 8.5 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.08 | 6.0 |
| BLOCKED WHEEL | rule | - | 0.14 | 49.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.08 | 105.0 |
| LONE WIZARD HOLDS BACK | rule | - | 0.11 | 105.0 |
| PATHS CROSS | rule | 0.06 | 0.06 | 16.5 |
| BEST PRIZE | rule | 0.03 | 0.06 | 26.4 |
| SAFER THAN THE JOB | rule | - | 0.08 | 7.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.06 | 85.8 |
| CHARGE NOW WEIGHED | rule | 0.06 | - | 88.1 |
| DEFENSIVE ARMY | rule | 0.06 | - | 11.3 |
| CANNON PLANNED TARGET | rule | - | 0.03 | 6.0 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 36.5 |
| FACES THE THREAT | rule | - | 0.03 | 3.5 |
| FALLBACK BY WORTH | rule | 0.03 | - | 20.4 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 3.1 |
| LONG SHOT | rule | - | 0.03 | 4.8 |
| NO REASON | gate | 0.03 | - | 22.0 |
| PURSUES BIG PREY | rule | 0.03 | - | 78.6 |
| REDIRECT WEIGHED | rule | - | 0.03 | 31.9 |
| SAFE SURE CHARGE | rule | 0.03 | - | 32.3 |
| STANDS TO CAST | rule | - | 0.03 | 30.1 |

### Plans: ch-h2h-mine-ea652ef-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.4 | 17% | 359 | 310 | 86% |
| Mine | charge | 3.6 | 58% | 223 | 266 | 119% |
| Mine | close in | 3.8 | 28% | 199 | 105 | 53% |
| Mine | hold | 5.1 | 32% | 291 | 0 | 0% |
| Mine | join | 0.5 | 94% | 9 | 0 | 0% |
| Mine | shoot | 9.2 | 63% | 449 | 869 | 194% |
| Mine | support | 3.6 | 94% | 33 | 0 | 0% |
| Opponent | advance | 13.5 | 17% | 362 | 424 | 117% |
| Opponent | charge | 5.1 | 58% | 513 | 518 | 101% |
| Opponent | close in | 6.2 | 28% | 542 | 197 | 36% |
| Opponent | hold | 3.9 | 30% | 282 | 0 | 0% |
| Opponent | join | 0.5 | 94% | 19 | 0 | 0% |
| Opponent | shoot | 3.6 | 64% | 132 | 326 | 247% |
| Opponent | support | 5.9 | 90% | 40 | 0 | 0% |

### Packages: hunt the guns, ch-h2h-mine-ea652ef-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 0% | 25% | 0% | 2.0 | 255 | 48 | 25% | 23 |
| Opponent | 0.3 | 10 | 0 | 20% | 10% | 0% | 2.0 | 367 | 25 | 10% | 109 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 534 | 0 | 0% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 185 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 77 | 0 | 0% | 90 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 205 | 126 | 50% | 58 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Tomb Kings of Khemri | 1.5 | 6 | 0 | 0% | 17% | 0% | 2.0 | 365 | 32 | 17% | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 33% | 0% | 0% | - | 332 | 0 | 0% | 43 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 486 | 0 | 0% | 191 |

### Battle groups: ch-h2h-mine-ea652ef-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.6 | 28% | 55% | 8% | 29% | 36% | 14% | 6% | 44% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 34% | 69% | 7% | 50% | 30% | 0% | 11% | 52% | 7% |
| Opponent | COUNTER-CHARGE COVER | 7.9 | 15% | 80% | 18% | 25% | 58% | 11% | 3% | 28% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 31% | 70% | 23% | 20% | 21% | 0% | 15% | 61% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ch-h2h-mine-ea652ef-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 79 | 0% | 2.5 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Mine | Chaff | 34 | 25 (34) | 9 | 16 | 70 | 26% | 2.2 | 27 (14) | 37 (7) | 17 (13) | 24 (22) | 26 (12) |
| Mine | Character | 106 | 50 (106) | 50 | 0 | 39 | 13% | 2.2 | 74 (31) | 49 (47) | 0 (8) | 53 (42) | 55 (44) |
| Mine | Clean-up | 22 | 50 (22) | 19 | 31 | 66 | 23% | 3.3 | 0 (2) | 64 (16) | 31 (4) | 56 (10) | 47 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | Fast | 4 | 45 (4) | 45 | 0 | 73 | 25% | 1.7 | 0 (2) | 89 (2) | - | 0 (3) | 166 (1) |
| Mine | Fast Hammer | 40 | 30 (40) | 18 | 11 | 47 | 12% | 2.7 | 24 (26) | 56 (9) | 7 (5) | 34 (25) | 23 (15) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 54 | 25% | 1.7 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 65 | 38 (65) | 26 | 11 | 46 | 14% | 2.4 | 30 (13) | 43 (45) | 10 (7) | 29 (40) | 48 (25) |
| Mine | Holder | 31 | 75 (31) | 6 | 69 | 24 | 42% | 2.7 | 23 (7) | 132 (16) | 25 (7) | 89 (19) | 57 (11) |
| Mine | Shooter | 35 | 75 (35) | 34 | 41 | 43 | 3% | 1.6 | 23 (9) | 118 (21) | 0 (5) | 67 (25) | 98 (10) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 57 (56) | 57 | 0 | 57 | 2% | 1.3 | 100 (16) | 35 (30) | 39 (10) | 61 (9) | 57 (47) |
| Mine | Wizard | 17 | 15 (17) | 15 | 0 | 56 | 6% | 2.0 | 49 (5) | 0 (6) | 0 (1) | 43 (6) | 0 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 75 | 37 (75) | 13 | 24 | 56 | 33% | 2.9 | 43 (31) | 21 (17) | 42 (27) | 44 (56) | 12 (19) |
| Opponent | Character | 97 | 57 (97) | 57 | 0 | 25 | 21% | 2.5 | 65 (45) | 55 (39) | 55 (6) | 63 (49) | 56 (41) |
| Opponent | Clean-up | 11 | 37 (11) | 7 | 30 | 37 | 45% | 3.2 | 0 (3) | 30 (6) | 83 (2) | 0 (6) | 58 (5) |
| Opponent | Fast | 1 | 383 (1) | 383 | 0 | 0 | 0% | 5.0 | - | 383 (1) | - | 383 (1) | - |
| Opponent | Fast Hammer | 60 | 45 (60) | 31 | 14 | 45 | 30% | 2.7 | 44 (26) | 38 (25) | 70 (9) | 37 (39) | 57 (21) |
| Opponent | Fragile | 17 | 60 (17) | 60 | 0 | 56 | 12% | 2.1 | 25 (5) | 94 (8) | 25 (4) | 65 (14) | 35 (3) |
| Opponent | Hammer | 65 | 41 (65) | 29 | 12 | 45 | 29% | 3.1 | 23 (20) | 48 (38) | 39 (7) | 44 (41) | 37 (24) |
| Opponent | Holder | 29 | 37 (29) | 12 | 25 | 26 | 69% | 3.3 | 33 (12) | 46 (13) | 0 (4) | 35 (18) | 42 (11) |
| Opponent | Shooter | 33 | 80 (33) | 24 | 56 | 35 | 3% | 1.5 | 59 (9) | 77 (21) | 178 (3) | 54 (18) | 108 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 49 | 33% | 2.8 | 0 (3) | 0 (1) | 0 (1) | 0 (2) | 0 (3) |
| Opponent | War machine | 6 | 128 (6) | 128 | 0 | 40 | 0% | 1.0 | 117 (3) | 143 (3) | - | 117 (3) | 143 (3) |
| Opponent | Wizard | 19 | 13 (19) | 13 | 0 | 50 | 16% | 1.7 | 11 (9) | 12 (2) | 0 (3) | 11 (9) | 0 (5) |

### Charged fights: ch-h2h-mine-ea652ef-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 48 | 174 | 2.0 | 1.2 | 87 | 17 | +70 | 2 of 8 | 7 of 8 | -68 | +116 |
| Mine | Chaos Dwarfs | 4 | 107 | 310 | 3.0 | 1.1 | 103 | 42 | +61 | 5 of 12 | 6 of 12 | +91 | +59 |
| Mine | Dwarfen Mountain Holds | 3 | 509 | 91 | 1.7 | 1.6 | 55 | 111 | -56 | 2 of 5 | 3 of 5 | -184 | +30 |
| Mine | Empire of Man | 5 | 656 | 25 | 1.0 | 1.0 | 25 | 0 | +25 | 1 of 5 | 3 of 5 | - | +25 |
| Mine | Grand Cathay | 4 | 430 | 396 | 3.2 | 1.2 | 122 | 34 | +88 | 4 of 13 | 10 of 13 | +109 | +86 |
| Mine | High Elf Realms | 4 | 340 | 191 | 3.2 | 1.1 | 59 | 91 | -32 | 2 of 13 | 9 of 13 | -151 | -22 |
| Mine | Kingdom of Bretonnia | 1 | 120 | 1040 | 6.0 | 1.2 | 173 | 0 | +173 | 4 of 6 | 4 of 6 | +540 | +100 |
| Mine | Lizardmen | 1 | 60 | 1289 | 5.0 | 1.0 | 258 | 81 | +177 | 3 of 5 | 5 of 5 | - | +177 |
| Mine | Ogre Kingdoms | 2 | 0 | 128 | 5.0 | 1.1 | 26 | 25 | +0 | 4 of 10 | 3 of 10 | +0 | +0 |
| Mine | Skaven | 2 | 230 | 0 | 3.0 | 1.0 | 0 | 210 | -210 | 3 of 6 | 4 of 6 | - | -210 |
| Mine | Tomb Kings of Khemri | 2 | 72 | 797 | 4.5 | 1.1 | 177 | 8 | +169 | 4 of 9 | 8 of 9 | +286 | +155 |
| Mine | Vampire Counts | 2 | 54 | 259 | 3.5 | 1.0 | 74 | 6 | +68 | 2 of 7 | 5 of 7 | - | +68 |
| Mine | Warriors of Chaos | 2 | 0 | 330 | 5.5 | 1.3 | 60 | 45 | +15 | 2 of 11 | 9 of 11 | -6 | +20 |
| **Mine** | all armies | 36 | 261 | 279 | 3.1 | 1.1 | 91 | 49 | +43 | 38 of 110 | 76 of 110 | +30 | +44 |
| Opponent | Empire of Man | 1 | 675 | 185 | 1.0 | 1.0 | 185 | 265 | -80 | 1 of 1 | 0 of 1 | - | -80 |
| Opponent | High Elf Realms | 5 | 141 | 869 | 5.6 | 1.1 | 155 | 16 | +139 | 15 of 28 | 21 of 28 | +215 | +127 |
| Opponent | Lizardmen | 2 | 0 | 211 | 2.5 | 1.0 | 84 | 35 | +49 | 4 of 5 | 3 of 5 | - | +49 |
| Opponent | Orc & Goblin Tribes | 3 | 47 | 909 | 3.7 | 1.0 | 248 | 24 | +224 | 2 of 11 | 10 of 11 | - | +224 |
| Opponent | Skaven | 4 | 20 | 118 | 1.2 | 1.0 | 95 | 27 | +68 | 2 of 5 | 2 of 5 | - | +68 |
| Opponent | Tomb Kings of Khemri | 2 | 248 | 343 | 5.5 | 1.1 | 62 | 6 | +56 | 5 of 11 | 10 of 11 | +0 | +62 |
| Opponent | Vampire Counts | 6 | 68 | 546 | 6.0 | 1.1 | 91 | 22 | +70 | 18 of 36 | 25 of 36 | +93 | +67 |
| Opponent | Warriors of Chaos | 7 | 17 | 338 | 3.7 | 1.2 | 91 | 31 | +60 | 16 of 26 | 13 of 26 | +254 | +25 |
| Opponent | Wood Elf Realms | 6 | 146 | 394 | 3.7 | 1.4 | 108 | 29 | +79 | 6 of 22 | 15 of 22 | +101 | +66 |
| **Opponent** | all armies | 36 | 97 | 468 | 4.0 | 1.1 | 116 | 25 | +92 | 69 of 145 | 99 of 145 | +146 | +82 |

### Effective charges: ch-h2h-mine-ea652ef-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 1 (net +123) | 0 | 1 (net +0) | 2 (net +138) | 0 | 3 (net -5) | 1 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 12 | 2 (net +0) | 2 (net -157) | 1 (net +599) | 4 (net -24) | 1 (net +332) | 2 (net +109) | 0 | 8% (1 of 12) |
| Mine | Dwarfen Mountain Holds | 5 | 2 (net +16) | 0 | 0 | 2 (net -63) | 0 | 1 (net -185) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 5 | 2 (net +0) | 0 | 0 | 1 (net +126) | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 5) |
| Mine | Grand Cathay | 13 | 0 | 0 | 3 (net -146) | 3 (net +382) | 1 (net +170) | 5 (net +53) | 1 | 25% (3 of 12) |
| Mine | High Elf Realms | 13 | 0 | 0 | 5 (net -55) | 4 (net -66) | 1 (net -151) | 3 (net +92) | 0 | 38% (5 of 13) |
| Mine | Kingdom of Bretonnia | 6 | 0 | 0 | 1 (net +0) | 1 (net +145) | 0 | 3 (net +298) | 1 | 20% (1 of 5) |
| Mine | Lizardmen | 5 | 1 (net +979) | 0 | 0 | 2 (net -175) | 0 | 1 (net +255) | 1 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 10 | 0 | 4 (net -55) | 2 (net +0) | 2 (net +128) | 0 | 0 | 2 | 25% (2 of 8) |
| Mine | Skaven | 6 | 1 (net -200) | 0 | 0 | 1 (net +0) | 0 | 3 (net +0) | 1 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net +0) | 0 | 1 (net +286) | 2 (net +125) | 2 (net +98) | 1 (net +693) | 2 | 14% (1 of 7) |
| Mine | Vampire Counts | 7 | 1 (net -40) | 1 (net +115) | 1 (net +0) | 3 (net +119) | 0 | 1 (net +45) | 0 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 11 | 1 (net +0) | 0 | 2 (net -15) | 2 (net +46) | 3 (net +56) | 1 (net -180) | 2 | 22% (2 of 9) |
| Opponent | Empire of Man | 1 | 1 (net -80) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 28 | 4 (net +138) | 0 | 3 (net +112) | 11 (net +149) | 2 (net +86) | 5 (net +181) | 3 | 12% (3 of 25) |
| Opponent | Lizardmen | 5 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 2 (net +211) | 1 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 11 | 1 (net +90) | 0 | 0 | 0 | 2 (net +183) | 2 (net +0) | 6 | 0% (0 of 5) |
| Opponent | Skaven | 5 | 1 (net +0) | 0 | 2 (net -66) | 1 (net +474) | 0 | 1 (net +0) | 0 | 40% (2 of 5) |
| Opponent | Tomb Kings of Khemri | 11 | 1 (net +0) | 0 | 0 | 2 (net +135) | 0 | 7 (net +49) | 1 | 0% (0 of 10) |
| Opponent | Vampire Counts | 36 | 11 (net +60) | 0 | 5 (net +24) | 6 (net +91) | 6 (net +73) | 8 (net +92) | 0 | 14% (5 of 36) |
| Opponent | Warriors of Chaos | 26 | 7 (net +5) | 0 | 2 (net +40) | 5 (net +22) | 1 (net +0) | 7 (net +164) | 4 | 9% (2 of 22) |
| Opponent | Wood Elf Realms | 22 | 4 (net +71) | 1 (net -56) | 3 (net +45) | 3 (net +12) | 3 (net +155) | 7 (net +84) | 1 | 14% (3 of 21) |

### Charged fights, damage counted: ch-h2h-mine-ea652ef-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 199 | 285 | +74 | 115 | 42 | +73 | +36.7 |
| Mine | 50-54% | 7 | 145 | 239 | -60 | 55 | 98 | -42 | -29.2 |
| Mine | Effective (55-75%) | 17 | 247 | 238 | +8 | 78 | 82 | -4 | -1.7 |
| Mine | 76-89% | 29 | 275 | 186 | +62 | 122 | 79 | +43 | +15.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 270 | 166 | +91 | 142 | 38 | +104 | +38.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 483 | 84 | +79 | 130 | 63 | +67 | +13.9 |
| Mine | No odds | 11 | 207 | 206 | -64 | 55 | 127 | -72 | -34.9 |
| Mine | All fights | 110 | 263 | 197 | +43 | 109 | 71 | +38 | +14.3 |
| Opponent | Long shot (under 50%) | 30 | 216 | 278 | +51 | 112 | 84 | +29 | +13.2 |
| Opponent | 50-54% | 2 | 449 | 414 | -28 | 227 | 111 | +116 | +25.8 |
| Opponent | Effective (55-75%) | 16 | 208 | 174 | +34 | 59 | 36 | +23 | +10.9 |
| Opponent | 76-89% | 28 | 318 | 175 | +110 | 135 | 23 | +111 | +35.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 362 | 222 | +106 | 153 | 43 | +110 | +30.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 425 | 99 | +103 | 116 | 7 | +109 | +25.6 |
| Opponent | No odds | 16 | 298 | 233 | +163 | 200 | 75 | +125 | +41.9 |
| Opponent | All fights | 145 | 307 | 211 | +92 | 133 | 48 | +85 | +27.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ch-h2h-mine-ea652ef-p4 | move | 443 | 100 (23%) | 74 (17%) | 55 (12%) | 288 (65%) |
| ch-h2h-mine-ea652ef-p4 | objective | 362 | 61 (17%) | 45 (12%) | 46 (13%) | 255 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

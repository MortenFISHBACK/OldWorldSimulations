# Margin of the changed side per pair (mean of both games), split shooting-heavy pairs v others, and paired against the charge worth batch (same pairs, seeds).
import csv,glob,statistics as st,math
HEAVY={'03','05','06','07','08','09','15','18','22'}
def margins(D):
  M={}
  for arm in ('mine','opp'):
    for f in glob.glob(f'{D}/{arm}-*/games.csv'):
      for r in csv.DictReader(open(f)):
        if r['ended']!='yes': continue
        m,o=map(int,r['vp_mine_opponent'].split('-')); M.setdefault(r['pair'],{})[arm]=(m-o) if arm=='mine' else (o-m)
  return {p:(v['mine']+v['opp'])/2 for p,v in M.items() if len(v)==2}
def b(x): return 1.96*st.stdev(x)/math.sqrt(len(x))
C=margins('/mnt/project-files/combined-h2h-2026-11-16'); W=margins('/mnt/project-files/charge-worth-h2h-2026-11-16')
heavy=lambda p:p[1:3] in HEAVY or p[3:5] in HEAVY
for lab,sel in (('All pairs',lambda p:True),('Pairs with a shooting-heavy list',heavy),('Other pairs',lambda p:not heavy(p))):
  ps=[p for p in C if sel(p)]; both=[p for p in ps if p in W]
  c=[C[p] for p in ps]; w=[W[p] for p in both]; d=[C[p]-W[p] for p in both]
  print(f"| {lab} | {len(ps)} | {st.mean(c):+.0f} ±{b(c):.0f} | {st.mean(w):+.0f} ±{b(w):.0f} | {st.mean(d):+.0f} ±{b(d):.0f} |")

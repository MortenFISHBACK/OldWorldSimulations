# (b) Close calls between shooting and charging, per brain (fix = changes on, off = main).
# A close call: a unit's chosen job and the runner-up named in its OpponentRule rows that turn are one shoot and one charge.
# Happened: shoot = VP of wounds its shooting did that turn (job_claims.happened); charge = target VP gone minus own VP lost over 2 turns.
import sys,glob,os,re,json,collections,statistics as st,math
sys.path.insert(0,'/home/user/WarhammerOldWorldSimulator/scripts')
import job_claims as jc
D=sys.argv[1] if len(sys.argv)>1 else '/mnt/project-files/combined-h2h-2026-11-16'
R=re.compile(r"^([A-Z' -]+): \S+ VP: (.*?) \| (SAME|CHANGED): (\S+) VP v (\S+) VP instead of (.*)$")
def k(s): s=s.lower(); return 'charge' if s.startswith('charge ') else ('shoot' if s.startswith('shoot ') else 'other')
def num(x): return float(x.replace('\\u002B','').replace('+',''))
res=collections.defaultdict(list); allpicks=collections.Counter(); games=collections.Counter()
for path in sorted(glob.glob(D+'/*-*/game-*.log.jsonl')):
  arm=os.path.basename(os.path.dirname(path)).split('-')[0]
  if arm not in ('mine','opp'): continue
  fx='Mine' if arm=='mine' else 'Opponent'
  g=jc.read_game(path); games[arm]+=1
  calls={}
  for l in open(path):
    if '"OpponentRule"' not in l: continue
    x=json.loads(l); m=R.match(x['summary'])
    if not m: continue
    a,b=k(m.group(2)),k(m.group(6))
    if {a,b}=={'shoot','charge'}: calls.setdefault((x['turn'],x['side'],x['actor']),(a,num(m.group(4)),num(m.group(5)),m.group(3)))
  for p in g['picks']:
    br='fix' if p['side']==fx else 'off'
    allpicks[(br,p['kind'])]+=1
    c=calls.get((p['turn'],p['side'],p['unit']))
    if not c or c[0]!=p['kind']: continue
    h=jc.happened(g,p)
    res[(br,p['kind'])].append((c[1],c[2],h.get('vp') if p['kind']=='shoot' else h.get('net'),h.get('declared'),path))
print('games',dict(games))
def m(v): v=[x for x in v if x is not None]; return (st.mean(v),1.96*st.stdev(v)/math.sqrt(len(v)) if len(v)>1 else 0,len(v)) if v else (None,0,0)
print('| Side | Close calls a game: shot instead of charging | charged instead of shooting | shoot picks a game (all) | charge picks a game (all) |')
for br,lab in (('fix','Changes on'),('off','Main')):
  n=sum(games.values())
  print(f"| {lab} | {len(res[(br,'shoot')])/n:.2f} ({len(res[(br,'shoot')])}) | {len(res[(br,'charge')])/n:.2f} ({len(res[(br,'charge')])}) | {allpicks[(br,'shoot')]/n:.1f} | {allpicks[(br,'charge')]/n:.1f} |")
print()
print('| Side | Choice | n | planned: taken v runner-up | happened (shoot: VP of wounds that turn; charge: net VP in 2 turns) | charge declared |')
for br,lab in (('fix','Changes on'),('off','Main')):
  for kind in ('shoot','charge'):
    v=res[(br,kind)]
    if not v: continue
    hm,hb,hn=m([x[2] for x in v]); dec=[x[3] for x in v if x[3] is not None]
    print(f"| {lab} | {kind} over {'charge' if kind=='shoot' else 'shoot'} | {len(v)} | {st.mean(x[0] for x in v):+.0f} v {st.mean(x[1] for x in v):+.0f} | {hm:+.0f} ±{hb:.0f} | {(sum(dec)/len(dec)) if dec else float('nan'):.0%} |")
# all shoot / charge picks happened, for scale
print()

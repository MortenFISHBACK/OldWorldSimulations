# Doctrine scorecard: ch-h2h-opp-ea652ef-p1

### Scorecard: ch-h2h-opp-ea652ef-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 13 | 5 | 1 | 0 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 1 | 3 | 2 | 4 | 1 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 4 | - | 1 | 3 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | yes | 2 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 3 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 2 | 4 | 2 | 1 | 1 | 0 | 0 | 274 |
| L0319 | 1 | 1 | Mine | no | 10 | 3 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 954 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 686 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 5 | 0 | 0 | 0 | 515 |
| L0524 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 901 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 1 | 2 | 0 | 0 | 0 | 798 |
| L0612 | 6 | 1 | Opponent | no | 5 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 1167 |
| L0628 | 4 | 1 | Opponent | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 111 |
| L0717 | 3 | 1 | Mine | yes | 7 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 8 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 2 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 2 | 0 | 0 | 255 |
| L0913 | 1 | 1 | Mine | no | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 1014 |
| L0913 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 501 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 420 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 4 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 3 | 0 | 1 | 0 | 0 | 427 |
| L1131 | 3 | 1 | Opponent | no | 2 | 4 | 2 | 2 | 0 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 4 | 2 | 4 | 1 | 2 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 7 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | yes | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 3 | - | 0 | 2 | 2 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 4 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 54 |
| L1625 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 2 | 5 | 0 | 3 | 0 | 0 | 135 |
| L1723 | 1 | 1 | Opponent | yes | 7 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | no | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 359 |
| L1923 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 2 | 0 | 0 | 90 |
| L2025 | 3 | 1 | Mine | yes | 6 | - | 0 | 1 | 1 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 8 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 787 |
| L2127 | 3 | 1 | Opponent | no | 5 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | no | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 3 | 0 | 0 | 933 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | - | 1 | 2 | 0 | 0 | 0 | 68 |
| L2531 | 5 | 1 | Opponent | yes | - | 3 | 0 | 4 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 2 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 3 | - | 0 | 0 | 1 | 0 | 0 | 207 |
| L2934 | 6 | 1 | Mine | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 3.2 | 2.6 | 2.6 | 1.0 | 0.2 | 0.0 | 0.0 | 317.4 |
| **Average** | | | Opponent | 21% | 2.4 | 2.6 | 2.4 | 1.8 | 0.5 | 0.0 | 0.0 | 183.0 |

### KPIs: ch-h2h-opp-ea652ef-p1

Rules off - Mine only: CHARGE BAND, HONEST WORTH, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (45 of 175) | 3% (5 of 177) | 14% (50 of 352) |
| Winner chose to follow up after the loser gave ground |  | 93% (67 of 72); on the table 99% | 97% (37 of 38); on the table 97% | 95% (104 of 110); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 86% | 94% (17 of 18); on the table 94% | 92% (23 of 25); on the table 92% |
| Winner chose to pursue after the loser fled |  | 72% (21 of 29); on the table 83% | 75% (24 of 32); on the table 75% | 74% (45 of 61); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 87% (94 of 108); on the table 94% | 89% (78 of 88); on the table 89% | 88% (172 of 196); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 41% (134 of 330) | 28% (58 of 210) | 36% (192 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 56% (134 of 240) | 40% (58 of 146) | 50% (192 of 386) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 31% (46 of 150) | 23% (19 of 84) | 28% (65 of 234) |
|     round 1 |  | 28% (7 of 25) | 21% (3 of 14) | 26% (10 of 39) |
|     rounds 2+ |  | 31% (39 of 125) | 23% (16 of 70) | 28% (55 of 195) |
|   other wizards | 50%+ | 49% (88 of 180) | 31% (39 of 126) | 42% (127 of 306) |
|     round 1 |  | 27% (8 of 30) | 38% (8 of 21) | 31% (16 of 51) |
|     rounds 2+ |  | 53% (80 of 150) | 30% (31 of 105) | 44% (111 of 255) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (15 of 26) | 62% (30 of 48) | 61% (45 of 74) |
| Points that never fought | lower | 41% (29393 of 71484) | 39% (27894 of 71889) | 40% (57287 of 143373) |
|   infantry points that never fought | lower | 51% (8549 of 16863) | 61% (8108 of 13348) | 55% (16657 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (149 of 279) | 61% (181 of 295) | 57% (330 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 100% (22 of 22); 2.4 uses a game | 75% (15 of 20); 1.7 uses a game | 88% (37 of 42); 2.1 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.6 uses a game | 12% (1 of 8); 0.0 uses a game | 42% (10 of 24); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 67% (8 of 12); 0.2 uses a game | 61% (19 of 31); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (28998 of 59666) | 54% (34146 of 62699) | 52% (63144 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (32%) | 1.6 (39%) | 3.4 (35%) |
| MARCHED: its unit marched | 0.9 (16%) | 0.4 (10%) | 1.3 (14%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (1%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.5 (27%) | 1.0 (24%) | 2.5 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| GONE: slain | 0.7 (13%) | 0.7 (16%) | 1.4 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (6%) | 0.1 (1%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (1%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.5 | 1.5 | 5.3 | 0.4 | 1.9 |
| not cast | 3.4 | 2.8 | 3.1 | 9.7 | 1.9 | 22.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (33%) | 0.3 (9%) | 3.4 (35%) | 0.3 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (14%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.3 (11%) | 0.7 (21%) | 2.5 (26%) | 0.5 (28%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.4 (13%) | 0.4 (14%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.6 (17%) | 0.6 (22%) | 0.4 (12%) | 1.4 (14%) | 0.1 (3%) | 2.9 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.1 (2%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.6 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (9%) | 0.1 (2%) | 0.1 (1%) | 0.7 (35%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (63%) | 0.3 (10%) | 1.2 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.2 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.5 a game | 0.9 a game |
| stood (cast and not dispelled) | 70% (30 of 43) | 58% (7 of 12) | 67% (37 of 55) |
| the unit moved after it | 63% (19 of 30) | 57% (4 of 7) | 62% (23 of 37) |
| it charged on its next turn | 0% (0 of 30) | 14% (1 of 7) | 3% (1 of 37) |
| the enemy charged it first | 7% (2 of 30) | 14% (1 of 7) | 8% (3 of 37) |
| it fought by the end of its next turn | 7% (2 of 30) | 14% (1 of 7) | 8% (3 of 37) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (6 of 30) | 0% (0 of 7) | 16% (6 of 37) |
| none of these (no charge, no fight, no charge escaped) | 73% (22 of 30) | 71% (5 of 7) | 73% (27 of 37) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (567 of 893) | 62% (367 of 594) | 63% (934 of 1487) |
|   cavalry | 51% (39 of 76) | 73% (94 of 128) | 65% (133 of 204) |
|   character | 43% (46 of 107) | 38% (47 of 124) | 40% (93 of 231) |
|   chariot | 51% (43 of 84) | 63% (24 of 38) | 55% (67 of 122) |
|   infantry | 61% (189 of 309) | 64% (145 of 225) | 63% (334 of 534) |
|   monster | 56% (19 of 34) | 52% (12 of 23) | 54% (31 of 57) |
|   war machine | 82% (231 of 283) | 80% (45 of 56) | 81% (276 of 339) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (29%) | 1.2 (19%) | 3.8 (25%) |
| CHARGED: it charged | 1.1 (12%) | 1.1 (17%) | 2.1 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (3%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.5 (7%) | 1.2 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.5 (17%) | 1.2 (19%) | 2.7 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.6 (10%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (19%) | 1.1 (17%) | 2.8 (18%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.3 (4%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.2 (3%) | 0.2 (4%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.7 | 74% | 5.7 pts | 31 pts |
| character | 3.0 | 0.6 | 81% | 5.3 pts | 16 pts |
| chariot | 1.9 | 1.1 | 63% | 10.5 pts | 20 pts |
| infantry | 13.8 | 4.1 | 79% | 7.0 pts | 97 pts |
| monster | 0.9 | 0.2 | 82% | 3.3 pts | 3 pts |
| war machine | 7.7 | 5.1 | 67% | 20.8 pts | 160 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 5.3 | 4.9 |
| Charges that made contact a game | 3.3 | 3.6 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.91 declared, 0.73 contact (22 units) | 0.57 declared, 0.43 contact (14 units) | 0.78 declared, 0.61 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.20 declared, 0.80 contact (5 units) | 1.14 declared, 0.86 contact (7 units) | 1.17 declared, 0.83 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.40 contact (252 units) | 0.63 declared, 0.42 contact (278 units) | 0.58 declared, 0.41 contact (530 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (41 of 70) | 48% (10 of 21) | 50% (4 of 8) | 56% (55 of 99) |
| Character in a unit | 82% (31 of 38) | 64% (16 of 25) | 100% (2 of 2) | 75% (49 of 65) |
| Character on its own | 88% (43 of 49) | 31% (11 of 35) | 28% (18 of 64) | 49% (72 of 148) |
| Chariot | 56% (9 of 16) | 60% (6 of 10) | - | 58% (15 of 26) |
| Infantry | 57% (51 of 89) | 33% (12 of 36) | 50% (1 of 2) | 50% (64 of 127) |
| Monster | 59% (19 of 32) | 90% (9 of 10) | - | 67% (28 of 42) |
| Monstrous | 64% (7 of 11) | 71% (10 of 14) | - | 68% (17 of 25) |
| War Machines | 71% (29 of 41) | 100% (1 of 1) | - | 71% (30 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 85% (11 of 13); on the table 92% | 54% (74 of 138) | 42% | 52% (17 of 33) | 100% (9 of 9); 6.0 uses a game | 100% (3 of 3); 1.7 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 100% (8 of 8); on the table 100% | 25% (6 of 24) | 46% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 95% (18 of 19); on the table 95% | - | 60% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 82% (9 of 11); on the table 100% | 39% (14 of 36) | 56% | 59% (38 of 64) | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 91% (10 of 11); on the table 91% | 28% (30 of 108) | 44% | 41% (18 of 44) | 100% (12 of 12); 10.2 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 74% (14 of 19); on the table 84% | 27% (8 of 30) | 41% | 47% (23 of 49) | 100% (5 of 5); 3.3 uses a game | 28% (5 of 18); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 37% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | - | 11% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (5 of 5); on the table 100% | 8% (1 of 12) | 60% | 81% (17 of 21) | 100% (3 of 3); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (13 of 13); on the table 100% | 19% (7 of 36) | 19% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (5 of 5); on the table 100% | 47% (14 of 30) | 41% | 56% (19 of 34) | 67% (2 of 3); 1.5 uses a game | 0.0 uses a game | 75% (3 of 4); 0.8 uses a game |
| Tomb Kings of Khemri | 6 | 72% (21 of 29); on the table 76% | 0% (0 of 12) | 25% | 30% (9 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (28 of 32); on the table 91% | 37% (20 of 54) | 32% | 56% (28 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 94% (16 of 17); on the table 94% | 37% (11 of 30) | 38% | 76% (56 of 74) | 100% (4 of 4); 2.4 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (6 of 6); on the table 100% | 23% (7 of 30) | 37% | 56% (37 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (ch-h2h-opp-ea652ef-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 54% (43) | 48% (34) | 51% (77) |
| ...free all their last turn and able to turn (per game) | 0.72 | 0.75 | 1.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.00 | 0.11 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.39 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.17 | 1.50 | 3.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.11 | 0.58 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.28 | 5.81 | 11.08 |

### Quality by phase: ch-h2h-opp-ea652ef-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 57% (84 of 148) | 42% (69 of 163) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (197 of 404) | 39% (71 of 184) |
| Strategy | Close-in objectives charged next turn | 14% (21 of 147) | 11% (24 of 227) |
| Strategy | Support requests answered (helper made contact too) | 33% (5 of 15) | 48% (13 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 80% (4 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 56% (9 of 16) | 69% (9 of 13) |
| Strategy | Joined characters whose unit fought | 47% (25 of 53) | 45% (20 of 44) |
| Strategy | Lone characters that fought | 73% (68 of 93) | 77% (71 of 92) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 317.4 | 183.0 |
| Movement | Fights charged into per game | 2.9 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 95, net +103 | 20 of 100, net +66 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 95, net +60 | 21 of 100, net +62 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 95, net +132 | 5 of 100, net +125 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 of 95, net +144 | 32 of 100, net +165 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (154 of 368) | 38% (137 of 359) |
| Shooting | Points destroyed by shooting units | 46.1 | 23.1 |
| Shooting | War machine shots | 6.4 | 1.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (105 of 231) | 20% (9 of 45) |
| Shooting | Points destroyed by war machines | 84.1 | 16.6 |
| Magic | Magic missiles cast | 2.5 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (23 of 90) | 43% (15 of 35) |
| Magic | Wounds caused by magic missiles | 6.2 | 1.5 |
| Magic | Wounds caused by other spells | 1.3 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 71.8 | 52.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.5 / 0.6 / 0.2 | 1.6 / 0.5 / 0.7 / 0.1 |
| Combat | Points destroyed in combat | 401.7 | 350.3 |
| Combat | Points run down | 59.4 | 77.8 |
| Combat | Net points per charged fight, damage counted | +115 | +91 |
| Combat | Net per 100 charger points, damage counted | +42.7 | +37.5 |
| Combat | First round won (charged fights) | 77% | 74% |
| Combat | Net points per charged fight | +123 | +92 |
| Combat | Net points per supported fight / lone fight | +144 / +120 | +140 / +84 |
| Combat | Charged fights on a top-3 enemy unit | 42 of 106 | 44 of 112 |
| Game | Points lost | 634.5 | 745.2 |
| Game | VP from objectives | 634.7 | 649.2 |
| Game | Lone holders (player turns) | 3.2 | 2.4 |

- Mine won / drew / lost: 18 / 4 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) +116 VP
- The side that went first won 14 of 32 games with a winner
- Points traded per game (both sides' losses): 1380
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ch-h2h-opp-ea652ef-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 12.9 | 0.2 | +0.0 | 0.0 | 3.6 |
| BACKUP TARGETS | 0.7 | +6.1 | 0.0 | 10.7 | 1.3 | +11.3 | 0.0 | 23.6 |
| BEST FACING | 0.8 | +38.7 | 0.0 | 12.5 | 0.6 | +51.0 | 0.0 | 20.0 |
| BEST FIRST | 4.3 | +198.9 | 152.1 | 67.2 | 4.2 | +174.2 | 96.4 | 50.3 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.6 | +23.9 | 0.0 | 18.9 |
| BEST OVERALL | 0.6 | +51.0 | 0.0 | 24.2 | 0.7 | +44.1 | 0.0 | 34.0 |
| BEST PREY | 1.1 | +46.8 | 32.9 | 16.4 | 1.2 | +43.9 | 23.9 | 14.3 |
| BEST PRIZE | 0.1 | +6.9 | 8.2 | 1.4 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.3 | -1.0 | 0.0 | 15.0 | 0.2 | +0.4 | 0.0 | 12.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.9 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.2 | +2.3 | 0.0 | 0.0 | 0.3 | +16.4 | 0.0 | 7.5 |
| BLOWS WHERE AIMED | - | - | - | - | 0.2 | -8.2 | 29.8 | 9.6 |
| BOMBING RUN | 0.1 | +1.7 | 8.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 65.0 | 15.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.2 | +154.0 | 303.7 | 52.2 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 6.5 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.2 | 5.8 | 16.2 | 0.1 | +0.0 | 4.9 | 0.0 |
| CAST JOB | 0.8 | +32.2 | 36.0 | 33.2 | 0.6 | +17.4 | 21.1 | 12.3 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +59.6 | 25.7 | 0.0 | 0.2 | +3.3 | 1.5 | 4.4 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 24.3 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.1 | 0.0 | 5.8 | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE BAND | - | - | - | - | 0.2 | +0.0 | 28.8 | 0.0 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 250.2 | 83.7 | 2.3 | +0.0 | 251.8 | 25.3 |
| CHARGE NOW WEIGHED | 0.5 | -44.7 | 18.8 | 35.7 | 0.7 | -93.2 | 12.8 | 15.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.7 | -19.3 | 58.2 | 21.5 |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.0 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.8 | 0.1 | +0.0 | 8.1 | 2.8 |
| COMBAT PIVOT | 0.4 | +0.0 | 27.4 | 13.1 | 0.3 | +0.0 | 16.1 | 30.5 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +62.8 | 11.1 | 11.1 | 0.2 | +17.1 | 3.5 | 22.8 |
| COUNTER-CHARGE COVER | 9.5 | +666.0 | 0.0 | 174.9 | 8.1 | +764.8 | 0.0 | 191.3 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +5.4 | 9.9 | 7.8 | 0.1 | +1.5 | 8.9 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +3.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | - | - | - | - | 6.9 | +0.0 | 288.1 | 91.0 |
| FACE THE CAST | - | - | - | - | 0.0 | +0.0 | 0.0 | 6.2 |
| FACES THE THREAT | 2.2 | +187.3 | 0.0 | 31.9 | 1.5 | +109.6 | 0.0 | 32.8 |
| FALLBACK BY WORTH | 4.4 | +50.3 | 0.0 | 44.1 | 5.7 | +58.7 | 0.0 | 67.2 |
| FIGHT LIFT | 0.0 | +0.8 | 7.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.6 | +0.0 | 42.3 | 4.3 |
| FIRE PLAN | - | - | - | - | 10.2 | +31.4 | 384.4 | 145.2 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 125.5 | 6.2 | +0.0 | 0.0 | 171.5 |
| FOCUS FIRE | 0.1 | +4.1 | 8.4 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.2 | +171.3 | 0.0 | 48.1 | 1.0 | +163.3 | 0.0 | 41.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +8.4 | 0.0 | 1.7 | 0.1 | +17.7 | 0.0 | 16.6 |
| GIVES UP | 0.0 | -1.5 | 0.0 | 0.0 | 0.1 | -0.7 | 4.6 | 7.9 |
| GIVES UP ITS SCREEN | 0.1 | -1.6 | 7.5 | 1.8 | - | - | - | - |
| GROUND FLIERS | 0.1 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 6.5 | 3.8 |
| HELPER UNSEEN | 0.2 | +0.0 | 29.7 | 9.4 | 0.4 | +0.0 | 15.2 | 17.9 |
| HILL BY ITS CHANCE | - | - | - | - | 0.2 | -25.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 6.9 | +721.9 | 288.1 | 91.0 |
| HONEST WORTH | - | - | - | - | 9.6 | -189.1 | 398.1 | 177.5 |
| HUNT ADVANCE | 0.0 | +0.0 | 5.3 | 0.0 | 0.1 | +8.9 | 0.0 | 6.1 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 1.5 |
| HUNT IN PAIRS | 0.4 | +37.5 | 0.0 | 16.7 | 0.6 | +44.7 | 0.0 | 19.4 |
| HUNT KEPT | 0.0 | +0.0 | 5.3 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.0 | +5.5 | 0.0 | 0.0 | 0.2 | +13.1 | 0.0 | 4.8 |
| HUNT THE GUNS | 0.0 | +5.7 | 5.3 | 0.0 | 0.2 | +77.1 | 12.2 | 6.1 |
| INVITES THE FIGHT | 1.5 | +28.2 | 59.7 | 22.2 | 1.6 | +24.0 | 18.2 | 13.1 |
| JOINT CHARGE PLAN | 0.1 | +0.7 | 6.2 | 0.0 | 0.2 | +14.0 | 0.0 | 0.8 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -9.2 | 25.0 | 3.1 |
| KEEP FALLS | - | - | - | - | 0.1 | +0.2 | 0.0 | 3.2 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.1 | 2.6 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +43.3 | 135.2 | 46.6 | 1.8 | +54.2 | 89.5 | 50.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | - | - | - | - | 0.9 | +11.9 | 56.3 | 8.8 |
| KILLS COUNT | 2.0 | +82.0 | 181.1 | 33.8 | 1.5 | +64.4 | 91.1 | 40.9 |
| KILLS COUNT NEXT TURN | 4.8 | +172.2 | 123.7 | 116.1 | 6.8 | +262.7 | 176.3 | 168.0 |
| LONE CHARACTER SAFE SPOT | 0.4 | +11.3 | 18.9 | 6.9 | 0.7 | +22.0 | 3.1 | 26.4 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 10.7 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -3.5 | 10.1 | 11.0 | 0.6 | +3.4 | 20.8 | 12.2 |
| LOST CHARGE | 3.0 | -51.8 | 108.9 | 91.0 | 3.1 | -37.9 | 60.4 | 73.5 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | -26.0 | 0.0 | 5.6 |
| MAKE SURE TOGETHER | 0.4 | +45.2 | 12.3 | 6.1 | 1.1 | +54.6 | 0.0 | 49.3 |
| MANOEUVRE | 0.2 | +6.5 | 0.0 | 1.8 | 0.4 | +11.0 | 0.0 | 7.3 |
| MARCH AT ESCAPER | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.6 | +46.9 | 0.0 | 0.0 | 0.2 | +17.4 | 0.0 | 5.4 |
| MARCH ODDS | 0.2 | +19.8 | 9.1 | 10.2 | 0.4 | +35.0 | 8.7 | 6.2 |
| MARCH OVER CASTS | 0.5 | +33.6 | 0.0 | 16.8 | 0.2 | +9.3 | 0.0 | 7.0 |
| MAX FOR POSITIONING | 5.2 | +197.1 | 0.0 | 94.8 | 5.3 | +180.4 | 0.0 | 112.2 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 1.1 | +4.4 | 55.1 | 19.7 |
| MISSILES IN THE MOVE | 4.6 | +197.1 | 0.0 | 76.1 | 3.8 | +61.3 | 0.0 | 96.6 |
| MISSILES NEXT TURN | 5.1 | +119.0 | 0.0 | 103.2 | 4.4 | +42.4 | 0.0 | 103.6 |
| MODEL FACING | 0.2 | +76.8 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 12.1 |
| MOVE AND CAST | 0.2 | +12.8 | 0.0 | 0.0 | 0.2 | +15.9 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -69.0 | 0.0 | 0.0 | 0.1 | -1.7 | 0.0 | 22.8 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.8 | +227.1 | 82.5 | 49.0 | 4.8 | +381.4 | 110.0 | 115.9 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +0.6 | 2.5 | 0.0 | 0.0 | +0.0 | 2.9 | 0.0 |
| NO RALLY LEFT | 0.0 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -18.5 | 32.1 | 5.2 | 0.2 | -9.1 | 16.4 | 7.8 |
| NOT TURNED | 5.3 | +72.4 | 0.0 | 105.2 | 5.8 | +52.1 | 0.0 | 122.1 |
| NOT WORTH A CAST | 0.8 | -0.8 | 0.0 | 21.1 | 0.4 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 15.3 | -775.0 | 0.0 | 220.3 | 16.2 | -838.4 | 11.7 | 270.4 |
| ONE YARDSTICK | - | - | - | - | 11.2 | -249.3 | 172.9 | 178.0 |
| OPENS A LANE | 0.2 | +1.4 | 33.6 | 0.0 | 0.1 | +0.3 | 0.0 | 7.6 |
| OPENS UP | 0.2 | +28.4 | 14.7 | 0.0 | 0.2 | +13.6 | 7.0 | 7.9 |
| OVERRUNS AWAY | 0.4 | +10.2 | 29.3 | 24.8 | 0.5 | +8.0 | 61.3 | 7.2 |
| PATHS CROSS | 1.6 | +113.2 | 0.0 | 23.8 | 2.6 | +198.8 | 0.0 | 60.0 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.1 | +6.9 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.0 | 0.0 | 1.5 | 0.1 | -5.4 | 0.0 | 16.6 |
| PLAN RESULT | 37.4 | +1252.9 | 1236.9 | 848.9 | 38.0 | +926.8 | 1026.1 | 940.7 |
| PURSUES BIG PREY | 0.1 | -6.3 | 0.0 | 0.0 | 0.0 | -0.7 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +2.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +13.1 | 0.0 | 43.8 | 1.3 | +19.5 | 0.0 | 51.4 |
| RANDOM MOVER NO PROMISE | 0.1 | -7.9 | 4.4 | 9.4 | 0.3 | -11.1 | 8.7 | 10.6 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.1 | 0.0 | 1.5 | 0.4 | -8.0 | 0.0 | 5.9 |
| REDIRECT COUNTER | 2.0 | +135.7 | 0.0 | 40.0 | 4.4 | +306.9 | 0.0 | 55.4 |
| REDIRECT WEIGHED | 0.4 | +9.9 | 13.2 | 1.4 | 0.2 | +4.3 | 13.9 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +8.7 | 0.0 | 7.1 | 0.7 | +38.7 | 0.0 | 20.0 |
| RESTRAINS TO SHOOT | 0.2 | +3.0 | 0.0 | 5.8 | - | - | - | - |
| RISK BY ARC | 2.8 | +79.3 | 206.4 | 102.3 | 2.6 | +65.2 | 219.2 | 77.2 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.7 | 5.8 | 0.0 |
| SAFER THAN THE JOB | 1.1 | +55.2 | 0.0 | 44.4 | 0.6 | +26.0 | 0.0 | 13.4 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -5.6 | 0.0 | 1.2 | 0.3 | -5.9 | 0.0 | 1.7 |
| SEARCH SPOT | 2.4 | +112.2 | 0.0 | 55.1 | 3.3 | +151.6 | 0.0 | 24.7 |
| SELF MOVE SPELL | 0.3 | +21.6 | 0.0 | 0.0 | 0.2 | +4.4 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.9 | +107.7 | 12.3 | 16.3 | 2.5 | +171.2 | 21.4 | 80.8 |
| SET-UP ANY TARGET | 0.2 | +15.5 | 11.1 | 11.1 | 0.2 | +15.9 | 3.5 | 15.2 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.3 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 1.8 | +72.9 | 88.0 | 12.5 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 1.3 | +14.9 | 0.0 | 13.2 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +42.0 | 25.2 | 5.6 | 0.6 | +22.2 | 36.6 | 26.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.7 | +0.0 | 558.9 | 230.1 | 10.4 | +0.0 | 369.9 | 146.5 |
| SHOT REPLANNED | 0.6 | +0.0 | 91.6 | 8.1 | - | - | - | - |
| SHOTS IN THE MOVE | 14.7 | +578.5 | 0.0 | 220.4 | 9.3 | +220.6 | 0.0 | 129.6 |
| SPELL SETS UP CHARGE | 0.3 | +41.4 | 11.1 | 11.1 | 0.2 | +61.1 | 3.5 | 15.2 |
| SPELL WORTH | 1.3 | +21.5 | 79.3 | 59.6 | 1.8 | +41.7 | 75.8 | 75.8 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.5 | -10.8 | 18.7 | 18.5 |
| STABLE ROLE | 11.3 | +0.0 | 360.3 | 185.1 | 10.6 | +0.0 | 265.1 | 182.8 |
| STANDS TO CAST | 0.1 | +4.2 | 3.2 | 0.0 | 0.0 | +1.3 | 3.2 | 0.0 |
| STAY WEIGHED | 0.1 | +4.1 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| STAY WORTH | - | - | - | - | 10.4 | +63.8 | 163.9 | 62.9 |
| STOPS | 0.0 | +0.0 | 5.3 | 0.0 | 0.1 | +2.7 | 12.2 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +20.3 | 0.0 | 18.5 | 0.6 | +43.6 | 0.0 | 25.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 5.8 | -36.4 | 333.3 | 134.9 | 7.6 | -61.8 | 352.9 | 103.9 |
| SUPPORTS | 3.4 | +37.3 | 132.9 | 79.5 | 4.9 | +61.8 | 129.2 | 51.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.4 | 4.2 | 0.0 | 0.1 | -0.4 | 7.6 | 0.0 |
| SURE REACH TOGETHER | 0.7 | -1.9 | 1.9 | 32.6 | 0.8 | +7.1 | 3.8 | 22.7 |
| THROUGH LINE OF FIRE | 0.6 | +26.6 | 0.0 | 7.9 | 0.1 | +9.0 | 0.0 | 0.0 |
| TURN WORTH | 0.7 | -46.5 | 50.9 | 6.2 | 0.2 | -9.5 | 19.2 | 0.0 |
| TWO OR MORE ARRIVE | 0.3 | +3.3 | 6.2 | 4.5 | 0.8 | +5.8 | 0.0 | 15.9 |
| WAIT AFTER COSTS | 6.6 | -288.5 | 219.4 | 118.3 | 8.5 | -455.8 | 170.0 | 161.4 |
| WALKS TO THE FIGHT | 1.9 | +49.1 | 57.9 | 21.6 | 1.0 | +23.4 | 26.4 | 8.9 |
| WAR ENGINE CHARGES | 0.0 | +1.0 | 0.0 | 1.8 | - | - | - | - |
| WAR ENGINE JOBS | 0.5 | +0.0 | 21.0 | 21.4 | 0.6 | +0.0 | 13.9 | 9.7 |
| WEARS DOWN | 1.0 | +56.9 | 85.6 | 54.9 | 1.3 | +34.3 | 143.2 | 30.9 |
| WHO HITS BACK | 0.3 | +19.4 | 0.0 | 5.7 | 0.2 | +28.3 | 0.0 | 7.0 |
| WHOLE FIGHT | 0.3 | +6.3 | 29.0 | 1.8 | 0.6 | +23.1 | 103.5 | 6.2 |
| WHOLE FIGHT GAIN | 0.3 | +20.6 | 8.0 | 5.6 | 0.6 | +36.0 | 40.9 | 18.9 |
| WIDER SPREAD | - | - | - | - | 3.0 | -6.1 | 232.1 | 77.3 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 2.6 | 0.0 | 0.0 | +0.0 | 2.0 | 0.0 |

### Rule changes: ch-h2h-opp-ea652ef-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1135 | 1135 | 1135 | 31.53 | -58085 | -51.2 |
| BEST FIRST | 305 | 305 | 305 | 8.47 | +13432 | +44.0 |
| SEARCH SPOT | 207 | 207 | 205 | 5.69 | +9497 | +46.3 |
| COUNTER-CHARGE COVER | 633 | 343 | 189 | 5.25 | +10119 | +53.5 |
| MOVE TO CHARGE | 274 | 274 | 155 | 4.31 | +8262 | +53.3 |
| PATHS CROSS | 150 | 150 | 150 | 4.17 | +11231 | +74.9 |
| FACES THE THREAT | 132 | 132 | 132 | 3.67 | +10687 | +81.0 |
| KILLS COUNT NEXT TURN | 418 | 418 | 111 | 3.08 | +3664 | +33.0 |
| SUPPORTS | 298 | 298 | 100 | 2.78 | +1075 | +10.8 |
| FIRE PLAN | 366 | 366 | 94 | 2.61 | +719 | +7.7 |
| FALLBACK BY WORTH | 366 | 366 | 81 | 2.25 | +3925 | +48.5 |
| FOLLOW UP WEIGHED | 77 | 77 | 77 | 2.14 | +12043 | +156.4 |
| SHOTS IN THE MOVE | 866 | 572 | 69 | 1.92 | +2288 | +33.2 |
| EVERY WOUND COUNTS | 249 | 249 | 67 | 1.86 | +0 | +0.0 |
| WALKS TO THE FIGHT | 107 | 107 | 66 | 1.83 | +1225 | +18.6 |
| WAIT AFTER COSTS | 543 | 543 | 63 | 1.75 | +1066 | +16.9 |
| SAFER THAN THE JOB | 61 | 61 | 61 | 1.69 | +2923 | +47.9 |
| BEST FACING | 53 | 53 | 53 | 1.47 | +3228 | +60.9 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| REDIRECT COUNTER | 232 | 125 | 50 | 1.39 | +4204 | +84.1 |
| BEST OVERALL | 49 | 49 | 49 | 1.36 | +3424 | +69.9 |
| ARTILLERY RE-ROLL WEIGHED | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| SET UP TOGETHER | 121 | 100 | 48 | 1.33 | +3446 | +71.8 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 74 | 74 | 45 | 1.25 | +1173 | +26.1 |
| CHARGE NOW WEIGHED | 44 | 44 | 44 | 1.22 | +3720 | +84.5 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| CHARGE NOW FIRST | 178 | 178 | 43 | 1.19 | -2692 | -62.6 |
| MAX FOR POSITIONING | 378 | 209 | 42 | 1.17 | +481 | +11.5 |
| RESERVE FALL BACK | 42 | 42 | 42 | 1.17 | +1703 | +40.6 |
| STOPS SHORT OF THE FLANK | 40 | 40 | 40 | 1.11 | +2298 | +57.4 |
| RISK BY ARC | 195 | 191 | 39 | 1.08 | +1209 | +31.0 |
| MISSILES IN THE MOVE | 303 | 159 | 36 | 1.00 | +1025 | +28.5 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SHOOTS FROM THE BEST SPOT | 61 | 61 | 34 | 0.94 | +782 | +23.0 |
| CANNON PLANNED TARGET | 188 | 188 | 32 | 0.89 | -121 | -3.8 |
| KILLS COUNT | 127 | 124 | 31 | 0.86 | +1301 | +42.0 |
| MARCH CHECK | 32 | 31 | 30 | 0.83 | +2140 | +71.3 |
| INVITES THE FIGHT | 111 | 111 | 29 | 0.81 | +392 | +13.5 |
| COMBAT PIVOT | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| CAST JOB | 48 | 48 | 26 | 0.72 | +620 | +23.9 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 26 | 26 | 26 | 0.72 | +1282 | +49.3 |
| BEST PREY | 81 | 81 | 24 | 0.67 | +687 | +28.6 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| BEST MOVE FOR SHOOTERS | 23 | 23 | 23 | 0.64 | +859 | +37.4 |
| KEEPS ITS TARGET | 117 | 117 | 23 | 0.64 | +420 | +18.3 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +822 | +35.8 |
| FIRE IN ORDER | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| MARCH ODDS | 23 | 23 | 22 | 0.61 | +233 | +10.6 |
| ONE YARDSTICK | 403 | 121 | 21 | 0.58 | +211 | +10.1 |
| SHOT REPLANNED | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 20 | 20 | 20 | 0.56 | -22 | -1.1 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +1067 | +56.2 |
| BLOCKED WHEEL | 18 | 18 | 18 | 0.50 | +671 | +37.3 |
| HONEST THREAT | 249 | 249 | 17 | 0.47 | +0 | +0.0 |
| MAKE SURE TOGETHER | 53 | 34 | 17 | 0.47 | +844 | +49.6 |
| MANOEUVRE | 20 | 20 | 17 | 0.47 | +633 | +37.2 |
| WAR ENGINE JOBS | 39 | 39 | 17 | 0.47 | -1379 | -81.1 |
| HONEST WORTH | 346 | 344 | 16 | 0.44 | +153 | +9.6 |
| STAY WORTH | 376 | 287 | 16 | 0.44 | +265 | +16.6 |
| CASTING BLOCK | 24 | 24 | 15 | 0.42 | +886 | +59.1 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +1033 | +68.9 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WEARS DOWN | 85 | 83 | 14 | 0.39 | +466 | +33.3 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +941 | +72.3 |
| HUNT IN PAIRS | 38 | 23 | 13 | 0.36 | +743 | +57.1 |
| KEEPS THE TARGET | 32 | 32 | 13 | 0.36 | +185 | +14.2 |
| WHOLE FIGHT GAIN | 32 | 29 | 13 | 0.36 | +410 | +31.5 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -231 | -25.6 |
| CHAFF PASSED | 8 | 8 | 8 | 0.22 | -4 | -0.6 |
| LOST CHARGE | 218 | 218 | 8 | 0.22 | +217 | +27.1 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +2766 | +345.8 |
| OPENS UP | 15 | 15 | 8 | 0.22 | +485 | +60.6 |
| SHOOTERS ARE THREATS | 63 | 63 | 8 | 0.22 | +0 | +0.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| WHOLE FIGHT | 31 | 31 | 7 | 0.19 | +362 | +51.7 |
| CHARGE BAND | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +108 | +18.0 |
| SURE REACH TOGETHER | 54 | 42 | 6 | 0.17 | +30 | +5.0 |
| OVERRUNS AWAY | 34 | 34 | 5 | 0.14 | +84 | +16.7 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -251 | -50.1 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -138 | -27.6 |
| BACKUP TARGETS | 72 | 29 | 4 | 0.11 | +10 | +2.6 |
| LONG SHOT | 39 | 38 | 4 | 0.11 | +55 | +13.7 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +148 | +36.9 |
| SUPPORT NARROWED | 482 | 482 | 4 | 0.11 | -18 | -4.5 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -83 | -27.6 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| HUNT ADVANCE | 5 | 5 | 3 | 0.08 | +158 | +52.8 |
| MISSILES NEXT TURN | 341 | 180 | 3 | 0.08 | +1 | +0.3 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +304 | +101.3 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +39 | +12.8 |
| WOUNDED STAYS OUT | 3 | 3 | 3 | 0.08 | -841 | -280.2 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +62 | +30.9 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +115 | +57.4 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +17 | +8.6 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +146 | +73.1 |
| JOINT CHARGE PLAN | 9 | 9 | 2 | 0.06 | +171 | +85.7 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +40 | +20.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| REFUSING RETIRES | 8 | 8 | 2 | 0.06 | -1 | -0.3 |
| SHOOTERS TO THE PRIMARY | 48 | 26 | 2 | 0.06 | +23 | +11.4 |
| WIDER SPREAD | 108 | 102 | 2 | 0.06 | +2 | +1.2 |
| CARRIES OUT SET-UP | 5 | 5 | 1 | 0.03 | -6 | -6.5 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -31 | -31.0 |
| CHARGER SLAIN LOST | 24 | 21 | 1 | 0.03 | +28 | +28.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| EDGE GIVE GROUND | 7 | 7 | 1 | 0.03 | +21 | +20.9 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +1 | +0.8 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 1 | 0.03 | -12 | -12.2 |
| MOVE SPELL IN RANGE | 3 | 2 | 1 | 0.03 | +4 | +3.9 |
| NEEDED THERE | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +225 | +224.8 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +28 | +28.3 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 1 | 0.03 | +2 | +2.0 |
| REDIRECT BY WHAT IT STOPS | 18 | 18 | 1 | 0.03 | +18 | +17.7 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -111 | -111.1 |
| STOPS | 4 | 4 | 1 | 0.03 | +15 | +15.0 |
| TWO OR MORE ARRIVE | 38 | 33 | 1 | 0.03 | +7 | +6.6 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 8 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 27 | 27 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 31 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 411 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 20 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 7 | 7 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 37 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 41 | 2 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 399 | 399 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 43 | not checked | - | - | - | - |
| OPENS A LANE | 11 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 2714 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 15 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 19 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 939 | 939 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 111 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 17 | 15 | 0 | 0.00 | - | - |
| STABLE ROLE | 790 | 789 | 0 | 0.00 | - | - |
| TURN WORTH | 31 | 31 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ch-h2h-opp-ea652ef-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.89 | 14.28 | 52.1 |
| FALLBACK | gate | 0.61 | 0.89 | 39.4 |
| CHARGE NOW FIRST | rule | 0.56 | 0.64 | 62.6 |
| TURN GATE | gate | 0.39 | 0.53 | 38.7 |
| WAR ENGINE JOBS | rule | 0.28 | 0.19 | 81.1 |
| FIRE PLAN | rule | - | 0.36 | 19.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.22 | 80.0 |
| BIG CHARACTER SAFETY | rule | 0.22 | 0.06 | 7.8 |
| PATHS CROSS | rule | 0.11 | 0.14 | 32.7 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.14 | 25.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.17 | 72.5 |
| AFTERMATH BAND | gate | 0.17 | 0.03 | 2.6 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.11 | 21.9 |
| KEEPS THE TARGET | rule | - | 0.14 | 32.4 |
| PURSUES BIG PREY | rule | 0.11 | 0.03 | 50.1 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | 0.03 | 8.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.06 | 27.6 |
| SAFER THAN THE JOB | rule | 0.08 | 0.03 | 4.3 |
| BEST PRIZE | rule | 0.08 | - | 27.6 |
| BLOCKED WHEEL | rule | 0.03 | 0.06 | 3.3 |
| CANNON PLANNED TARGET | rule | 0.08 | - | 86.7 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 2.0 |
| MARCH ODDS | rule | - | 0.08 | 78.0 |
| REDIRECT WEIGHED | rule | 0.08 | - | 25.2 |
| SUPPORT NARROWED | rule | 0.03 | 0.06 | 5.9 |
| WOUNDED STAYS OUT | rule | 0.06 | 0.03 | 280.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 157.4 |
| CHAFF PASSED | rule | 0.06 | - | 2.1 |
| NO REASON | gate | - | 0.06 | 1.6 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 33.5 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 6.5 |
| CATCH ODDS | rule | - | 0.03 | 31.0 |
| FACES THE THREAT | rule | 0.03 | - | 18.2 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 0.7 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 0.6 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 12.2 |
| LONG SHOT | rule | - | 0.03 | 6.0 |
| SAFE SURE CHARGE | rule | - | 0.03 | 111.1 |
| WHO HITS BACK | rule | 0.03 | - | 2.1 |

### Plans: ch-h2h-opp-ea652ef-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.2 | 18% | 428 | 264 | 62% |
| Mine | charge | 3.5 | 58% | 366 | 289 | 79% |
| Mine | close in | 4.0 | 25% | 278 | 117 | 42% |
| Mine | hold | 5.1 | 44% | 318 | 0 | 0% |
| Mine | join | 0.7 | 96% | 20 | 0 | 0% |
| Mine | shoot | 9.4 | 61% | 352 | 583 | 166% |
| Mine | support | 3.5 | 86% | 24 | 0 | 0% |
| Opponent | advance | 12.6 | 12% | 390 | 262 | 67% |
| Opponent | charge | 3.8 | 58% | 340 | 334 | 98% |
| Opponent | close in | 6.2 | 17% | 396 | 111 | 28% |
| Opponent | hold | 4.2 | 43% | 267 | 0 | 0% |
| Opponent | join | 1.4 | 98% | 78 | 0 | 0% |
| Opponent | shoot | 4.3 | 58% | 152 | 220 | 144% |
| Opponent | support | 5.5 | 93% | 44 | 0 | 0% |

### Packages: hunt the guns, ch-h2h-opp-ea652ef-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 3.0 | 206 | 200 | 100% | 15 |
| Opponent | 0.2 | 7 | 0 | 29% | 29% | 0% | 2.0 | 396 | 67 | 29% | 89 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 103 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 47 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 86 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 206 | 200 | 100% | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 104 | 0 | 0% | 0 |
| Skaven | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 234 | 224 | 100% | 86 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 569 | 0 | 0% | 22 |
| Warriors of Chaos | 0.4 | 3 | 0 | 33% | 33% | 0% | 2.0 | 513 | 83 | 33% | 65 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 45 |

### Battle groups: ch-h2h-opp-ea652ef-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.5 | 22% | 58% | 8% | 17% | 37% | 18% | 7% | 38% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 30% | 59% | 9% | 0% | 25% | 5% | 0% | 70% | 0% |
| Opponent | COUNTER-CHARGE COVER | 8.1 | 18% | 65% | 16% | 25% | 33% | 16% | 16% | 35% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 21% | 73% | 15% | 0% | 25% | 0% | 11% | 57% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ch-h2h-opp-ea652ef-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 19 | 67% | 6.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Mine | Chaff | 36 | 43 (36) | 35 | 8 | 70 | 28% | 2.6 | 76 (15) | 0 (9) | 41 (12) | 54 (23) | 28 (13) |
| Mine | Character | 123 | 53 (123) | 53 | 0 | 29 | 18% | 2.6 | 56 (36) | 61 (63) | 20 (10) | 70 (63) | 42 (46) |
| Mine | Clean-up | 24 | 75 (24) | 35 | 40 | 32 | 29% | 3.6 | 92 (9) | 73 (11) | 0 (4) | 132 (13) | 20 (11) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 47 | 0% | 1.5 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 42 | 32 (42) | 20 | 11 | 46 | 31% | 2.8 | 27 (19) | 52 (12) | 22 (11) | 37 (29) | 21 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 0% | 1.4 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 57 | 42 (57) | 25 | 16 | 40 | 16% | 2.7 | 48 (10) | 45 (37) | 24 (10) | 56 (34) | 25 (23) |
| Mine | Holder | 26 | 110 (26) | 15 | 95 | 12 | 38% | 3.4 | 145 (8) | 94 (14) | 120 (3) | 128 (13) | 98 (12) |
| Mine | Shooter | 44 | 85 (44) | 20 | 64 | 38 | 2% | 1.9 | 0 (5) | 119 (31) | 43 (7) | 112 (24) | 57 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 0% | 2.6 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 56 | 49 (56) | 49 | 0 | 27 | 5% | 1.4 | 67 (13) | 42 (37) | 55 (6) | 51 (11) | 48 (45) |
| Mine | Wizard | 23 | 13 (23) | 13 | 0 | 29 | 9% | 2.7 | 17 (6) | 21 (9) | 0 (2) | 46 (1) | 10 (16) |
| Opponent | Blocker | 1 | 69 (1) | 69 | 0 | 0 | 0% | 5.0 | - | - | 69 (1) | 69 (1) | - |
| Opponent | Chaff | 68 | 55 (68) | 17 | 38 | 53 | 35% | 3.0 | 91 (29) | 26 (17) | 32 (22) | 69 (50) | 11 (18) |
| Opponent | Character | 113 | 47 (113) | 47 | 0 | 34 | 22% | 2.8 | 49 (39) | 55 (54) | 36 (8) | 52 (65) | 50 (36) |
| Opponent | Clean-up | 17 | 27 (17) | 17 | 11 | 49 | 53% | 3.1 | 0 (5) | 43 (9) | 37 (3) | 38 (9) | 18 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 53 | 54 (53) | 33 | 21 | 46 | 34% | 2.9 | 71 (22) | 26 (17) | 53 (14) | 57 (38) | 48 (15) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 35 | 30% | 1.6 | 0 (3) | 0 (5) | 0 (2) | 0 (9) | 0 (1) |
| Opponent | Hammer | 64 | 30 (64) | 20 | 10 | 47 | 31% | 2.3 | 16 (16) | 34 (41) | 33 (7) | 29 (39) | 32 (25) |
| Opponent | Holder | 40 | 53 (40) | 2 | 51 | 25 | 40% | 3.8 | 16 (9) | 79 (21) | 25 (10) | 81 (22) | 20 (18) |
| Opponent | Shooter | 32 | 55 (32) | 9 | 46 | 57 | 0% | 1.3 | 37 (8) | 68 (19) | 28 (5) | 55 (17) | 55 (15) |
| Opponent | Support | 2 | 85 (2) | 85 | 0 | 50 | 0% | 5.0 | 0 (1) | 170 (1) | - | - | 85 (2) |
| Opponent | War machine | 13 | 37 (13) | 37 | 0 | 48 | 23% | 1.1 | 0 (5) | 51 (5) | 77 (3) | 0 (3) | 48 (10) |
| Opponent | Wizard | 24 | 17 (24) | 17 | 0 | 25 | 8% | 1.9 | 26 (13) | 16 (5) | 0 (3) | 28 (13) | 0 (8) |

### Charged fights: ch-h2h-opp-ea652ef-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 246 | 103 | 1.4 | 1.0 | 74 | 0 | +74 | 3 of 7 | 5 of 7 | - | +74 |
| Mine | Chaos Dwarfs | 3 | 72 | 912 | 3.3 | 1.1 | 274 | 0 | +274 | 5 of 10 | 8 of 10 | +117 | +291 |
| Mine | Dwarfen Mountain Holds | 4 | 252 | 92 | 1.8 | 1.4 | 53 | 0 | +53 | 4 of 7 | 5 of 7 | +0 | +92 |
| Mine | Empire of Man | 5 | 339 | 78 | 1.6 | 1.2 | 49 | 0 | +49 | 2 of 8 | 7 of 8 | +42 | +51 |
| Mine | Grand Cathay | 4 | 537 | 431 | 4.0 | 1.0 | 108 | 39 | +68 | 11 of 16 | 7 of 16 | - | +68 |
| Mine | High Elf Realms | 4 | 181 | 619 | 4.2 | 1.1 | 146 | 13 | +133 | 7 of 17 | 14 of 17 | +0 | +141 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 329 | 4.0 | 1.0 | 82 | 0 | +82 | 2 of 4 | 4 of 4 | - | +82 |
| Mine | Lizardmen | 1 | 0 | 461 | 4.0 | 1.0 | 115 | 0 | +115 | 0 of 4 | 4 of 4 | - | +115 |
| Mine | Ogre Kingdoms | 1 | 70 | 66 | 1.0 | 1.0 | 66 | 0 | +66 | 0 of 1 | 1 of 1 | - | +66 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 620 | 5.0 | 1.4 | 124 | 22 | +102 | 1 of 5 | 5 of 5 | +160 | +63 |
| Mine | Skaven | 2 | 93 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1478 | 6.0 | 1.1 | 246 | 6 | +240 | 4 of 12 | 10 of 12 | +662 | +202 |
| Mine | Vampire Counts | 2 | 0 | 846 | 5.0 | 1.3 | 169 | 46 | +123 | 2 of 10 | 7 of 10 | +260 | +64 |
| Mine | Warriors of Chaos | 1 | 0 | 422 | 5.0 | 1.2 | 84 | 40 | +44 | 1 of 5 | 5 of 5 | +61 | +40 |
| **Mine** | all armies | 36 | 202 | 410 | 2.9 | 1.1 | 139 | 16 | +123 | 42 of 106 | 82 of 106 | +144 | +120 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 85 | -85 | 2 of 3 | 2 of 3 | -85 | -85 |
| Opponent | Dwarfen Mountain Holds | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 138 | 1.0 | 1.0 | 138 | 0 | +138 | 1 of 1 | 1 of 1 | - | +138 |
| Opponent | Grand Cathay | 1 | 355 | 200 | 2.0 | 1.0 | 100 | 0 | +100 | 1 of 2 | 1 of 2 | - | +100 |
| Opponent | High Elf Realms | 2 | 136 | 674 | 2.5 | 1.2 | 270 | 69 | +200 | 3 of 5 | 4 of 5 | +212 | +198 |
| Opponent | Lizardmen | 1 | 0 | 728 | 3.0 | 1.0 | 243 | 0 | +243 | 2 of 3 | 3 of 3 | - | +243 |
| Opponent | Ogre Kingdoms | 2 | 52 | 90 | 3.0 | 1.3 | 30 | 6 | +24 | 0 of 6 | 4 of 6 | +58 | +8 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 398 | 3.5 | 1.0 | 114 | 79 | +35 | 4 of 7 | 4 of 7 | - | +35 |
| Opponent | Skaven | 2 | 426 | 0 | 1.0 | 1.5 | 0 | 105 | -105 | 1 of 2 | 1 of 2 | -210 | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 94 | 1060 | 5.5 | 1.3 | 193 | 15 | +178 | 7 of 22 | 18 of 22 | +300 | +142 |
| Opponent | Vampire Counts | 6 | 79 | 571 | 5.5 | 1.2 | 104 | 17 | +87 | 14 of 33 | 24 of 33 | +139 | +78 |
| Opponent | Warriors of Chaos | 7 | 0 | 190 | 1.6 | 1.1 | 121 | 0 | +121 | 3 of 11 | 8 of 11 | +55 | +128 |
| Opponent | Wood Elf Realms | 6 | 84 | 283 | 2.8 | 1.1 | 100 | 88 | +12 | 6 of 17 | 13 of 17 | +93 | +7 |
| **Opponent** | all armies | 36 | 92 | 391 | 3.1 | 1.2 | 126 | 34 | +92 | 44 of 112 | 83 of 112 | +140 | +84 |

### Effective charges: ch-h2h-opp-ea652ef-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +432) | 0 | 1 (net +0) | 1 (net +0) | 0 | 2 (net +0) | 2 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 10 | 1 (net +117) | 0 | 1 (net +210) | 2 (net +307) | 0 | 6 (net +299) | 0 | 10% (1 of 10) |
| Mine | Dwarfen Mountain Holds | 7 | 3 (net +72) | 0 | 1 (net +0) | 1 (net +111) | 0 | 2 (net +20) | 0 | 14% (1 of 7) |
| Mine | Empire of Man | 8 | 0 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +42) | 3 (net +79) | 1 | 14% (1 of 7) |
| Mine | Grand Cathay | 16 | 3 (net +121) | 0 | 6 (net +6) | 2 (net +235) | 2 (net +60) | 2 (net +76) | 1 | 40% (6 of 15) |
| Mine | High Elf Realms | 17 | 1 (net -162) | 0 | 5 (net +89) | 3 (net +313) | 2 (net +112) | 5 (net +128) | 1 | 31% (5 of 16) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 (net +110) | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 1 (net +0) | 1 (net +70) | 1 (net +325) | 1 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 1 | 1 (net +66) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +195) | 0 | 0 | 1 (net +125) | 3 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 12 | 1 (net +170) | 0 | 2 (net +126) | 1 (net +662) | 1 (net +757) | 6 (net +154) | 1 | 18% (2 of 11) |
| Mine | Vampire Counts | 10 | 3 (net +135) | 1 (net +170) | 0 | 1 (net +0) | 0 | 5 (net +131) | 0 | 0% (0 of 10) |
| Mine | Warriors of Chaos | 5 | 1 (net -63) | 0 | 0 | 0 | 2 (net +30) | 1 (net +109) | 1 | 0% (0 of 4) |
| Opponent | Beastmen Brayherds | 3 | 0 | 0 | 1 (net +0) | 1 (net -85) | 0 | 1 (net -170) | 0 | 33% (1 of 3) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +138) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 2 | 1 (net +95) | 0 | 0 | 0 | 0 | 1 (net +105) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 5 | 1 (net +296) | 0 | 1 (net +390) | 0 | 0 | 2 (net +158) | 1 | 25% (1 of 4) |
| Opponent | Lizardmen | 3 | 2 (net +309) | 0 | 0 | 1 (net +110) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Ogre Kingdoms | 6 | 2 (net -17) | 0 | 0 | 1 (net +85) | 0 | 2 (net +32) | 1 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 0 | 0 | 2 (net +166) | 5 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 2 (net -105) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 22 | 1 (net +175) | 0 | 8 (net +62) | 4 (net +239) | 1 (net +257) | 6 (net +316) | 2 | 40% (8 of 20) |
| Opponent | Vampire Counts | 33 | 7 (net -0) | 2 (net +65) | 6 (net +149) | 8 (net +38) | 3 (net +92) | 6 (net +200) | 1 | 19% (6 of 32) |
| Opponent | Warriors of Chaos | 11 | 2 (net +254) | 0 | 2 (net +97) | 2 (net +135) | 0 | 5 (net +72) | 0 | 18% (2 of 11) |
| Opponent | Wood Elf Realms | 17 | 2 (net -62) | 0 | 3 (net -225) | 3 (net +88) | 1 (net +93) | 6 (net +174) | 2 | 20% (3 of 15) |

### Charged fights, damage counted: ch-h2h-opp-ea652ef-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 198 | 205 | +103 | 147 | 37 | +110 | +55.6 |
| Mine | 50-54% | 1 | 401 | 170 | +170 | 170 | 64 | +106 | +26.6 |
| Mine | Effective (55-75%) | 19 | 238 | 262 | +60 | 78 | 37 | +42 | +17.5 |
| Mine | 76-89% | 13 | 299 | 232 | +215 | 227 | 67 | +159 | +53.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 257 | 178 | +144 | 172 | 21 | +151 | +58.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 404 | 101 | +132 | 142 | 15 | +127 | +31.3 |
| Mine | No odds | 11 | 304 | 102 | +71 | 104 | 33 | +71 | +23.2 |
| Mine | All fights | 106 | 270 | 188 | +123 | 149 | 33 | +115 | +42.7 |
| Opponent | Long shot (under 50%) | 20 | 193 | 225 | +66 | 102 | 41 | +61 | +31.6 |
| Opponent | 50-54% | 2 | 45 | 65 | +65 | 65 | 0 | +65 | +144.4 |
| Opponent | Effective (55-75%) | 21 | 223 | 229 | +62 | 128 | 83 | +45 | +20.1 |
| Opponent | 76-89% | 20 | 204 | 157 | +95 | 151 | 41 | +111 | +54.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 312 | 195 | +165 | 214 | 55 | +159 | +50.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 517 | 121 | +125 | 165 | 20 | +144 | +27.9 |
| Opponent | No odds | 12 | 160 | 195 | -22 | 52 | 61 | -9 | -5.5 |
| Opponent | All fights | 112 | 243 | 194 | +92 | 145 | 54 | +91 | +37.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ch-h2h-opp-ea652ef-p1 | move | 460 | 98 (21%) | 73 (16%) | 49 (11%) | 313 (68%) |
| ch-h2h-opp-ea652ef-p1 | objective | 374 | 45 (12%) | 32 (9%) | 54 (14%) | 275 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

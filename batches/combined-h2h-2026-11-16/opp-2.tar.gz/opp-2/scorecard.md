# Doctrine scorecard: ch-h2h-opp-ea652ef-p2

### Scorecard: ch-h2h-opp-ea652ef-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 3 | 1 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 7 | 5 | 1 | 4 | 1 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 7 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 749 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 5 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 2 | 1 | 0 | 0 | 0 | 1257 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 1 | 4 | 1 | 0 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0616 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 367 |
| L0632 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 717 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 10 | - | 2 | 1 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 912 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 6 | 3 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 5 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 274 |
| L1228 | 4 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | yes | 6 | 2 | 2 | 1 | 2 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 7 | 2 | 2 | 0 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 5 | 1 | 5 | 1 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 1 | - | 2 | 2 | 1 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 6 | - | 1 | 2 | 0 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | yes | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | no | - | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 10 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 0 | 0 | 0 | 158 |
| L3033 | 3 | 1 | Mine | yes | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 1 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 30% | 2.9 | 2.8 | 2.1 | 1.2 | 0.2 | 0.0 | 0.0 | 291.8 |
| **Average** | | | Opponent | 23% | 2.0 | 2.3 | 2.6 | 1.4 | 0.2 | 0.0 | 0.0 | 167.6 |

### KPIs: ch-h2h-opp-ea652ef-p2

Rules off - Mine only: CHARGE BAND, HONEST WORTH, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (39 of 175) | 14% (25 of 178) | 18% (64 of 353) |
| Winner chose to follow up after the loser gave ground |  | 96% (76 of 79); on the table 96% | 95% (63 of 66); on the table 95% | 96% (139 of 145); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 93% (13 of 14); on the table 93% | 89% (16 of 18); on the table 94% | 91% (29 of 32); on the table 94% |
| Winner chose to pursue after the loser fled |  | 76% (19 of 25); on the table 80% | 82% (18 of 22); on the table 82% | 79% (37 of 47); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 92% (108 of 118); on the table 92% | 92% (97 of 106); on the table 92% | 92% (205 of 224); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 32% (111 of 342) | 28% (44 of 156) | 31% (155 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (111 of 239) | 44% (44 of 100) | 46% (155 of 339) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 25% (38 of 150) | 22% (17 of 78) | 24% (55 of 228) |
|     round 1 |  | 16% (4 of 25) | 8% (1 of 13) | 13% (5 of 38) |
|     rounds 2+ |  | 27% (34 of 125) | 25% (16 of 65) | 26% (50 of 190) |
|   other wizards | 50%+ | 38% (73 of 192) | 35% (27 of 78) | 37% (100 of 270) |
|     round 1 |  | 41% (13 of 32) | 46% (6 of 13) | 42% (19 of 45) |
|     rounds 2+ |  | 38% (60 of 160) | 32% (21 of 65) | 36% (81 of 225) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (16 of 24) | 62% (33 of 53) | 64% (49 of 77) |
| Points that never fought | lower | 37% (26731 of 71583) | 37% (26670 of 71989) | 37% (53401 of 143572) |
|   infantry points that never fought | lower | 47% (7736 of 16324) | 50% (7060 of 14029) | 49% (14796 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (169 of 284) | 56% (166 of 297) | 58% (335 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.4 uses a game | 78% (14 of 18); 1.2 uses a game | 87% (33 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 44% (8 of 18); 0.5 uses a game | 50% (1 of 2); 0.1 uses a game | 45% (9 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33794 of 60231) | 50% (31747 of 63281) | 53% (65541 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (27%) | 0.8 (25%) | 2.5 (27%) |
| MARCHED: its unit marched | 1.2 (19%) | 0.4 (12%) | 1.6 (16%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.0 (1%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.6 (24%) | 0.6 (21%) | 2.2 (23%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 1.0 (15%) | 0.5 (16%) | 1.5 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.3 (11%) | 0.6 (7%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (8%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.6 | 0.9 | 4.3 | 0.5 | 2.1 |
| not cast | 3.9 | 3.3 | 4.1 | 9.5 | 1.8 | 19.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (44%) | 0.2 (6%) | 2.5 (27%) | 0.5 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (16%) | 0.4 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.3 (8%) | 0.5 (12%) | 2.2 (23%) | 0.3 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (10%) | 0.3 (10%) | 0.4 (10%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.7 (18%) | 0.2 (6%) | 0.8 (19%) | 1.5 (15%) | 0.2 (14%) | 2.3 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (14%) | 0.6 (18%) | 0.3 (8%) | 0.6 (7%) | 0.1 (5%) | 1.5 (8%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.3 (10%) | 0.0 (0%) | 0.1 (1%) | 0.3 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (47%) | 0.1 (3%) | 1.8 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.9 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.5 a game | 0.5 a game | 0.5 a game |
| stood (cast and not dispelled) | 59% (10 of 17) | 78% (14 of 18) | 69% (24 of 35) |
| the unit moved after it | 90% (9 of 10) | 57% (8 of 14) | 71% (17 of 24) |
| it charged on its next turn | 10% (1 of 10) | 7% (1 of 14) | 8% (2 of 24) |
| the enemy charged it first | 10% (1 of 10) | 7% (1 of 14) | 8% (2 of 24) |
| it fought by the end of its next turn | 10% (1 of 10) | 0% (0 of 14) | 4% (1 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 10% (1 of 10) | 7% (1 of 14) | 8% (2 of 24) |
| none of these (no charge, no fight, no charge escaped) | 70% (7 of 10) | 79% (11 of 14) | 75% (18 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (557 of 863) | 57% (453 of 799) | 61% (1010 of 1662) |
|   cavalry | 64% (49 of 77) | 62% (101 of 163) | 62% (150 of 240) |
|   character | 46% (44 of 96) | 33% (35 of 106) | 39% (79 of 202) |
|   chariot | 48% (47 of 98) | 71% (40 of 56) | 56% (87 of 154) |
|   infantry | 60% (150 of 251) | 58% (180 of 308) | 59% (330 of 559) |
|   monster | 50% (24 of 48) | 63% (24 of 38) | 56% (48 of 86) |
|   war machine | 83% (243 of 293) | 57% (73 of 128) | 75% (316 of 421) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (27%) | 1.8 (19%) | 4.1 (23%) |
| CHARGED: it charged | 0.9 (11%) | 1.8 (19%) | 2.7 (15%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.1 (12%) | 0.5 (5%) | 1.6 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.4 (16%) | 1.9 (20%) | 3.3 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.6 (6%) | 1.2 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.7 (18%) | 3.1 (17%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.4 (4%) | 0.6 (3%) |
| OTHER BAR | 0.4 (5%) | 0.6 (6%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 2.1 | 75% | 6.3 pts | 38 pts |
| character | 2.4 | 0.4 | 81% | 6.4 pts | 15 pts |
| chariot | 2.4 | 1.4 | 74% | 10.7 pts | 26 pts |
| infantry | 12.4 | 4.8 | 72% | 8.3 pts | 103 pts |
| monster | 1.6 | 0.5 | 76% | 6.8 pts | 11 pts |
| war machine | 8.8 | 7.3 | 62% | 25.2 pts | 222 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 6.1 | 5.2 |
| Charges that made contact a game | 3.3 | 4.2 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.96 declared, 0.62 contact (26 units) | 0.54 declared, 0.46 contact (13 units) | 0.82 declared, 0.56 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (6 units) | 1.17 declared, 1.00 contact (12 units) | 0.89 declared, 0.78 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.42 contact (243 units) | 0.69 declared, 0.47 contact (287 units) | 0.62 declared, 0.45 contact (530 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (44 of 73) | 50% (9 of 18) | 67% (8 of 12) | 59% (61 of 103) |
| Character in a unit | 77% (23 of 30) | 59% (10 of 17) | 50% (2 of 4) | 69% (35 of 51) |
| Character on its own | 76% (32 of 42) | 65% (24 of 37) | 26% (16 of 62) | 51% (72 of 141) |
| Chariot | 88% (15 of 17) | 54% (7 of 13) | - | 73% (22 of 30) |
| Infantry | 52% (49 of 94) | 56% (19 of 34) | 33% (1 of 3) | 53% (69 of 131) |
| Monster | 41% (12 of 29) | 78% (7 of 9) | - | 50% (19 of 38) |
| Monstrous | 36% (5 of 14) | 79% (11 of 14) | - | 57% (16 of 28) |
| War Machines | 68% (39 of 57) | 100% (2 of 2) | - | 69% (41 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 83% (5 of 6); on the table 83% | 36% (37 of 102) | 35% | 41% (9 of 22) | 100% (6 of 6); 3.8 uses a game | 50% (1 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 86% (12 of 14); on the table 86% | 39% (14 of 36) | 43% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 93% (13 of 14); on the table 93% | - | 63% | 72% (39 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 95% (18 of 19); on the table 95% | 27% (13 of 48) | 49% | 54% (41 of 76) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 91% (21 of 23); on the table 91% | 25% (35 of 138) | 45% | 52% (28 of 54) | 86% (12 of 14); 6.2 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 93% (14 of 15); on the table 93% | 22% (4 of 18) | 41% | 64% (21 of 33) | 100% (3 of 3); 2.0 uses a game | 36% (5 of 14); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 86% (6 of 7); on the table 86% | - | 38% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (8 of 8); on the table 100% | - | 35% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (7 of 7); on the table 100% | 0% (0 of 18) | 42% | 96% (27 of 28) | 100% (4 of 4); 2.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 8% (1 of 12) | 3% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 91% (10 of 11); on the table 91% | 56% (10 of 18) | 39% | 64% (16 of 25) | 100% (2 of 2); 2.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 70% (7 of 10); on the table 70% | - | 29% | 28% (7 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 91% (30 of 33); on the table 94% | 36% (24 of 66) | 21% | 59% (32 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 97% (29 of 30); on the table 97% | 61% (11 of 18) | 26% | 47% (34 of 73) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 91% (21 of 23); on the table 96% | 25% (6 of 24) | 36% | 63% (49 of 78) | 57% (4 of 7); 1.9 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ch-h2h-opp-ea652ef-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (46) | 52% (36) | 54% (82) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.75 | 1.44 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.03 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.42 | 1.08 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 1.28 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 0.97 | 1.78 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.25 | 5.39 | 11.64 |

### Quality by phase: ch-h2h-opp-ea652ef-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 60% (79 of 132) | 47% (100 of 213) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (161 of 353) | 35% (75 of 216) |
| Strategy | Close-in objectives charged next turn | 13% (17 of 127) | 19% (45 of 239) |
| Strategy | Support requests answered (helper made contact too) | 47% (9 of 19) | 39% (14 of 36) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 45% (9 of 20) | 67% (6 of 9) |
| Strategy | Joined characters whose unit fought | 49% (24 of 49) | 26% (9 of 34) |
| Strategy | Lone characters that fought | 76% (73 of 96) | 76% (68 of 89) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.2 | 1.4 |
| Movement | Points that never moved of their own | 291.8 | 167.6 |
| Movement | Fights charged into per game | 2.8 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 92, net +16 | 22 of 106, net +183 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 92, net +100 | 22 of 106, net +80 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 92, net +71 | 7 of 106, net +92 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 of 92, net +127 | 21 of 106, net +170 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.6 | 11.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (143 of 344) | 45% (187 of 411) |
| Shooting | Points destroyed by shooting units | 67.8 | 28.7 |
| Shooting | War machine shots | 6.8 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (125 of 243) | 49% (36 of 73) |
| Shooting | Points destroyed by war machines | 57.8 | 46.5 |
| Magic | Magic missiles cast | 1.8 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (27 of 65) | 63% (17 of 27) |
| Magic | Wounds caused by magic missiles | 2.9 | 1.0 |
| Magic | Wounds caused by other spells | 1.6 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 37.5 | 36.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.6 / 0.7 / 0.1 | 1.7 / 0.2 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 327.9 | 458.6 |
| Combat | Points run down | 93.4 | 42.5 |
| Combat | Net points per charged fight, damage counted | +96 | +108 |
| Combat | Net per 100 charger points, damage counted | +36.3 | +38.1 |
| Combat | First round won (charged fights) | 79% | 71% |
| Combat | Net points per charged fight | +88 | +107 |
| Combat | Net points per supported fight / lone fight | +138 / +78 | +191 / +85 |
| Combat | Charged fights on a top-3 enemy unit | 31 of 102 | 51 of 124 |
| Game | Points lost | 785.0 | 699.1 |
| Game | VP from objectives | 555.3 | 584.7 |
| Game | Lone holders (player turns) | 2.9 | 2.0 |

- Mine won / drew / lost: 15 / 4 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -93 VP
- The side that went first won 16 of 32 games with a winner
- Points traded per game (both sides' losses): 1484
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: ch-h2h-opp-ea652ef-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.9 | 0.0 | 2.4 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 8.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.2 | +8.3 | 0.0 | 4.2 | 0.7 | +7.0 | 0.0 | 28.5 |
| BEST FACING | 0.8 | +21.2 | 0.0 | 51.4 | 0.7 | +20.4 | 0.0 | 47.5 |
| BEST FIRST | 5.1 | +224.4 | 215.8 | 75.6 | 3.8 | +122.8 | 122.1 | 105.4 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.2 | +108.8 | 0.0 | 18.2 |
| BEST OVERALL | 0.7 | +51.1 | 0.0 | 34.5 | 0.5 | +23.8 | 0.0 | 15.2 |
| BEST PREY | 0.8 | +33.0 | 33.5 | 7.1 | 0.8 | +34.4 | 33.0 | 7.1 |
| BEST PRIZE | - | - | - | - | 0.2 | -9.6 | 13.2 | 21.5 |
| BIG CHARACTER SAFETY | 0.2 | -1.2 | 0.0 | 12.3 | 0.2 | -1.5 | 0.0 | 31.6 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 6.4 | 0.0 |
| BLOCKED WHEEL | 0.2 | -1.7 | 0.0 | 0.0 | 0.7 | +15.0 | 0.0 | 11.8 |
| BLOWS WHERE AIMED | - | - | - | - | 0.5 | -55.3 | 61.2 | 21.3 |
| BOMBING RUN | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.9 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 117.9 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.0 | +131.4 | 293.1 | 81.8 | - | - | - | - |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 17.7 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 5.4 | 0.0 | 0.1 | +0.0 | 5.7 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | -3.5 | 19.4 | 1.2 |
| CAST JOB | 0.7 | +10.0 | 26.2 | 16.2 | 0.2 | +14.9 | 20.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +17.5 | 15.0 | 0.0 | 0.1 | +5.8 | 5.2 | 4.4 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 34.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +2.2 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.3 | 2.9 | 6.5 | - | - | - | - |
| CHARGE BAND | - | - | - | - | 0.4 | +0.0 | 40.6 | 12.9 |
| CHARGE NOW FIRST | 2.4 | +0.0 | 267.3 | 47.2 | 3.2 | +0.0 | 329.9 | 136.4 |
| CHARGE NOW WEIGHED | 0.7 | -36.4 | 31.9 | 13.9 | 0.4 | -60.0 | 13.6 | 41.4 |
| CHARGER SLAIN LOST | - | - | - | - | 0.7 | -24.5 | 84.2 | 24.2 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 2.4 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.3 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 9.6 | 2.2 | 0.1 | +0.0 | 15.5 | 3.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 27.1 | 40.5 | 0.8 | +0.0 | 68.5 | 12.6 |
| CONVEYANCE SEARCH | 0.3 | +58.9 | 5.3 | 2.6 | 0.4 | +44.1 | 11.4 | 34.1 |
| COUNTER-CHARGE COVER | 10.5 | +877.9 | 0.0 | 202.1 | 7.4 | +619.4 | 0.0 | 191.4 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 27.3 | 7.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +1.4 | 9.6 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +8.8 | 41.3 | 0.0 | 0.4 | +6.6 | 51.8 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | - | - | - | - | 8.8 | +0.0 | 355.2 | 121.1 |
| FACE THE CAST | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| FACES THE THREAT | 1.8 | +123.6 | 0.0 | 87.1 | 1.3 | +76.8 | 0.0 | 59.8 |
| FALLBACK BY WORTH | 4.5 | +41.6 | 0.0 | 81.4 | 5.3 | +83.3 | 0.0 | 47.7 |
| FIGHT LIFT | 0.1 | +0.1 | 0.0 | 32.2 | 0.0 | +0.6 | 10.7 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.3 | 7.7 | 0.0 | 0.1 | +0.9 | 0.0 | 7.6 |
| FIRE IN ORDER | - | - | - | - | 0.4 | +0.0 | 8.1 | 15.9 |
| FIRE PLAN | - | - | - | - | 12.7 | +49.1 | 527.6 | 243.2 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 160.3 | 5.3 | +0.0 | 0.0 | 157.4 |
| FOLLOW UP WEIGHED | 1.1 | +193.4 | 0.0 | 108.2 | 1.4 | +197.9 | 0.0 | 29.2 |
| FRIENDS SHOTS CHECKED | 0.4 | +10.2 | 0.0 | 5.2 | 0.2 | +14.4 | 0.0 | 7.8 |
| GIVES UP | - | - | - | - | 0.2 | -3.1 | 20.8 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -1.1 | 9.8 | 0.0 | 0.0 | -0.0 | 3.4 | 0.0 |
| GROUND FLIERS | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 3.5 | 0.0 | 0.3 | +0.0 | 25.6 | 3.1 |
| HELPER UNSEEN | 0.2 | +0.0 | 3.9 | 21.5 | 0.6 | +0.0 | 60.9 | 15.0 |
| HILL BY ITS CHANCE | 0.3 | -21.8 | 0.0 | 6.9 | 0.6 | -55.9 | 0.0 | 1.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 8.8 | +1088.7 | 355.2 | 121.1 |
| HONEST WORTH | - | - | - | - | 10.6 | -227.6 | 626.1 | 261.3 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +0.3 | 15.0 | 0.0 | 0.2 | +2.0 | 9.3 | 1.9 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 7.8 | 1.9 |
| HUNT IN PAIRS | 0.3 | +20.8 | 0.0 | 23.8 | 0.4 | +26.4 | 0.0 | 30.1 |
| HUNT KEPT | 0.2 | +0.6 | 15.0 | 10.4 | 0.1 | +3.8 | 15.4 | 0.0 |
| HUNT RESULT | 0.1 | +27.6 | 0.0 | 4.0 | 0.3 | +49.6 | 13.6 | 2.9 |
| HUNT THE GUNS | 0.1 | +45.2 | 27.1 | 0.0 | 0.4 | +114.0 | 27.6 | 1.9 |
| INVITES THE FIGHT | 1.6 | +35.4 | 71.8 | 4.5 | 1.0 | +16.5 | 63.2 | 8.5 |
| JOINT CHARGE PLAN | 0.1 | +1.2 | 0.0 | 0.0 | 0.2 | +12.4 | 0.0 | 6.4 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -1.6 | 0.0 | 0.0 |
| KEEP FALLS | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.7 | 3.3 | 5.8 | 0.1 | +0.5 | 3.1 | 0.0 |
| KEEPS ITS TARGET | 1.2 | +37.5 | 130.0 | 57.5 | 2.6 | +77.5 | 198.9 | 99.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | - | - | - | - | 0.6 | -5.2 | 120.9 | 9.3 |
| KILLS COUNT | 1.6 | +60.3 | 141.3 | 24.9 | 2.4 | +107.5 | 173.3 | 58.9 |
| KILLS COUNT NEXT TURN | 4.2 | +171.2 | 133.2 | 160.4 | 7.8 | +265.1 | 284.8 | 154.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +6.3 | 5.2 | 1.2 | 0.3 | +10.6 | 2.9 | 6.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 11.2 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -0.4 | 9.2 | 3.1 | 0.8 | +7.2 | 31.9 | 24.8 |
| LOST CHARGE | 3.3 | -59.5 | 139.3 | 121.3 | 2.4 | -38.7 | 88.1 | 56.5 |
| LURE BY WHAT IT DRAWS | 0.1 | -3.2 | 0.0 | 0.0 | 0.1 | -12.7 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +21.0 | 1.8 | 3.1 | 0.8 | +37.9 | 11.5 | 12.1 |
| MANOEUVRE | 0.2 | +2.1 | 0.0 | 0.0 | 0.2 | +3.8 | 0.0 | 3.1 |
| MARCH CHECK | 0.6 | +16.8 | 0.0 | 0.0 | 0.5 | +20.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +13.8 | 0.0 | 0.0 | 0.2 | +16.6 | 11.2 | 15.9 |
| MARCH OVER CASTS | 0.6 | +60.5 | 0.0 | 19.4 | 0.2 | +19.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.8 | +165.0 | 0.0 | 108.3 | 4.9 | +194.5 | 0.0 | 112.6 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 0.4 | +1.9 | 10.0 | 10.5 |
| MISSILES IN THE MOVE | 4.0 | +95.5 | 0.0 | 73.5 | 2.8 | +59.6 | 0.0 | 111.1 |
| MISSILES NEXT TURN | 4.7 | +68.2 | 0.0 | 95.7 | 3.2 | +41.8 | 0.0 | 125.7 |
| MODEL FACING | 0.2 | +32.5 | 0.0 | 1.7 | 0.4 | +53.5 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 9.6 | 12.1 | 0.2 | +0.0 | 24.1 | 10.2 |
| MOVE AND CAST | 0.5 | +24.1 | 0.0 | 2.4 | 0.1 | +5.6 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -23.5 | 0.0 | 2.6 | 0.1 | -1.5 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE | 2.5 | +120.1 | 93.1 | 86.4 | 4.9 | +327.7 | 166.9 | 150.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +1.4 | 5.2 | 0.0 | 0.0 | +3.8 | 4.1 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -16.0 | 39.6 | 0.0 | 0.6 | -26.9 | 57.5 | 7.1 |
| NOT TURNED | 6.2 | +106.8 | 0.0 | 141.7 | 5.4 | +127.7 | 0.0 | 128.6 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 23.0 | 0.6 | -0.4 | 0.0 | 1.7 |
| OFF BEST | 15.6 | -693.5 | 11.5 | 235.2 | 15.4 | -832.2 | 11.5 | 262.8 |
| ONE YARDSTICK | - | - | - | - | 12.0 | -339.3 | 292.1 | 215.9 |
| OPENS A LANE | 0.2 | +2.4 | 23.1 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +34.4 | 10.5 | 0.0 | 0.1 | +6.6 | 9.0 | 5.4 |
| OVERRUN THREAT | 0.0 | +3.9 | 0.0 | 8.0 | - | - | - | - |
| OVERRUNS AWAY | 0.5 | +9.3 | 61.4 | 0.0 | 0.5 | +10.2 | 45.1 | 54.8 |
| PATHS CROSS | 1.9 | +131.3 | 0.0 | 15.3 | 3.1 | +214.9 | 0.0 | 75.3 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.7 | 0.0 | 4.8 | 0.1 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 37.3 | +1428.3 | 1379.0 | 1009.9 | 41.3 | +1304.9 | 1563.4 | 987.6 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -2.5 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.3 | 0.0 | 3.4 | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +27.1 | 0.0 | 26.2 | 1.5 | +29.0 | 0.0 | 30.3 |
| RANDOM MOVER NO PROMISE | 0.2 | -19.5 | 2.0 | 5.8 | 0.1 | -8.6 | 16.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -2.7 | 0.0 | 3.1 | 0.2 | -2.9 | 0.0 | 5.5 |
| REDIRECT COUNTER | 2.1 | +145.9 | 0.0 | 54.4 | 3.6 | +287.8 | 0.0 | 55.1 |
| REDIRECT WEIGHED | 0.4 | +6.7 | 7.8 | 2.5 | 0.5 | +0.3 | 32.2 | 28.8 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 36.1 |
| RESERVE FALL BACK | 0.3 | +11.9 | 0.0 | 3.4 | 1.4 | +35.5 | 0.0 | 31.3 |
| RESTRAINS TO SHOOT | 0.1 | +2.0 | 0.0 | 0.0 | 0.1 | +7.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +54.9 | 255.6 | 63.5 | 3.6 | +112.1 | 301.0 | 122.0 |
| SAFER THAN THE JOB | 0.8 | +55.2 | 0.0 | 20.6 | 1.0 | +55.8 | 0.0 | 48.2 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -13.7 | 0.0 | 0.0 | 0.4 | -22.8 | 0.0 | 3.3 |
| SEARCH SPOT | 2.8 | +142.7 | 0.0 | 73.2 | 3.4 | +136.7 | 0.0 | 38.8 |
| SECOND HUNTER | 0.1 | -0.0 | 0.0 | 0.0 | 0.1 | -0.7 | 9.2 | 0.0 |
| SELF MOVE SPELL | 0.1 | +7.0 | 0.0 | 20.0 | - | - | - | - |
| SET UP TOGETHER | 0.5 | +30.4 | 21.0 | 15.2 | 2.0 | +120.7 | 62.8 | 39.0 |
| SET-UP ANY TARGET | 0.1 | +6.0 | 0.0 | 0.0 | 0.1 | +18.2 | 0.0 | 11.2 |
| SET-UP MISSED | - | - | - | - | 0.0 | +2.0 | 3.5 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 3.2 | +125.4 | 153.2 | 38.4 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 1.5 | +25.6 | 0.0 | 30.7 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +45.3 | 89.9 | 13.7 | 0.5 | +26.1 | 23.4 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 15.2 | +0.0 | 638.1 | 239.2 | 12.8 | +0.0 | 397.8 | 219.9 |
| SHOT REPLANNED | 0.7 | +0.0 | 108.3 | 4.6 | - | - | - | - |
| SHOTS IN THE MOVE | 13.8 | +558.9 | 0.0 | 205.6 | 12.4 | +356.8 | 0.0 | 197.7 |
| SPELL SETS UP CHARGE | 0.2 | +57.1 | 0.0 | 0.0 | 0.1 | +23.3 | 0.0 | 11.2 |
| SPELL WORTH | 1.0 | +26.6 | 70.4 | 67.2 | 1.4 | +25.7 | 145.0 | 114.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.8 | -6.8 | 59.0 | 52.4 |
| STABLE ROLE | 11.4 | +0.0 | 457.9 | 174.0 | 12.2 | +0.0 | 416.0 | 150.7 |
| STANDS TO CAST | 0.1 | +0.6 | 0.0 | 0.0 | 0.0 | +1.9 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +0.4 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 2.0 |
| STAY WORTH | - | - | - | - | 12.7 | +109.9 | 283.3 | 183.4 |
| STOPS | 0.1 | +0.8 | 12.1 | 3.2 | 0.2 | +14.4 | 29.9 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +23.1 | 0.0 | 20.4 | 0.2 | +12.1 | 0.0 | 5.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 5.8 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 6.6 | -57.0 | 360.0 | 116.1 | 8.1 | -54.8 | 428.1 | 85.2 |
| SUPPORTS | 4.8 | +61.2 | 164.9 | 65.7 | 4.9 | +60.6 | 186.9 | 33.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.2 | 0.0 | 16.1 | 0.1 | -5.5 | 17.4 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +5.0 | 0.0 | 2.3 | 1.1 | +5.6 | 18.8 | 27.6 |
| THROUGH LINE OF FIRE | 0.3 | +14.7 | 0.0 | 4.6 | 0.2 | +18.8 | 0.0 | 5.4 |
| TURN WORTH | 0.4 | -35.4 | 28.1 | 4.0 | 0.3 | -18.9 | 39.8 | 5.4 |
| TWO OR MORE ARRIVE | 0.3 | +1.5 | 19.3 | 1.4 | 0.3 | +1.5 | 8.6 | 2.5 |
| WAIT AFTER COSTS | 5.9 | -268.6 | 198.1 | 112.1 | 8.0 | -386.4 | 302.0 | 173.1 |
| WALKS TO THE FIGHT | 1.5 | +32.6 | 21.3 | 15.0 | 1.2 | +16.2 | 35.2 | 3.5 |
| WAR ENGINE CHARGES | 0.1 | +4.4 | 3.5 | 8.6 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 50.2 | 5.8 | 0.2 | +0.0 | 4.6 | 5.1 |
| WEARS DOWN | 1.2 | +62.6 | 187.6 | 47.1 | 1.5 | +47.2 | 165.1 | 82.1 |
| WHO HITS BACK | 0.2 | +11.4 | 0.0 | 3.8 | 0.3 | +25.5 | 0.0 | 17.3 |
| WHOLE FIGHT | 0.2 | +3.8 | 45.6 | 0.0 | 0.4 | +18.2 | 89.9 | 9.6 |
| WHOLE FIGHT GAIN | 0.6 | +48.9 | 68.4 | 27.0 | 1.1 | +86.9 | 108.4 | 31.0 |
| WIDER SPREAD | - | - | - | - | 4.2 | -10.4 | 375.8 | 84.9 |

### Rule changes: ch-h2h-opp-ea652ef-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1115 | 1115 | 1115 | 30.97 | -54923 | -49.3 |
| BEST FIRST | 322 | 322 | 322 | 8.94 | +12498 | +38.8 |
| SEARCH SPOT | 221 | 221 | 216 | 6.00 | +10129 | +46.9 |
| PATHS CROSS | 181 | 181 | 181 | 5.03 | +12465 | +68.9 |
| COUNTER-CHARGE COVER | 646 | 385 | 171 | 4.75 | +9393 | +54.9 |
| KILLS COUNT NEXT TURN | 429 | 429 | 145 | 4.03 | +3984 | +27.5 |
| MOVE TO CHARGE | 267 | 267 | 140 | 3.89 | +5385 | +38.5 |
| SUPPORTS | 346 | 346 | 135 | 3.75 | +1340 | +9.9 |
| FIRE PLAN | 458 | 458 | 126 | 3.50 | +1019 | +8.1 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +7216 | +65.0 |
| SHOTS IN THE MOVE | 942 | 612 | 96 | 2.67 | +2417 | +25.2 |
| FOLLOW UP WEIGHED | 90 | 90 | 90 | 2.50 | +14087 | +156.5 |
| FALLBACK BY WORTH | 354 | 354 | 87 | 2.42 | +4499 | +51.7 |
| EVERY WOUND COUNTS | 315 | 315 | 79 | 2.19 | +0 | +0.0 |
| WAIT AFTER COSTS | 501 | 501 | 73 | 2.03 | +1326 | +18.2 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| SAFER THAN THE JOB | 64 | 64 | 64 | 1.78 | +3995 | +62.4 |
| RESERVE FALL BACK | 62 | 62 | 62 | 1.72 | +1707 | +27.5 |
| ARTILLERY RE-ROLL WEIGHED | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| BEST FACING | 51 | 51 | 51 | 1.42 | +1500 | +29.4 |
| WALKS TO THE FIGHT | 97 | 97 | 51 | 1.42 | +549 | +10.8 |
| RANDOM MOVE BY FIGURES | 77 | 77 | 49 | 1.36 | +2021 | +41.3 |
| COMBAT PIVOT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| MAX FOR POSITIONING | 350 | 216 | 46 | 1.28 | +574 | +12.5 |
| REDIRECT COUNTER | 207 | 104 | 46 | 1.28 | +3391 | +73.7 |
| BEST MOVE FOR SHOOTERS | 45 | 45 | 45 | 1.25 | +3917 | +87.1 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RISK BY ARC | 210 | 204 | 42 | 1.17 | +1392 | +33.2 |
| SET UP TOGETHER | 90 | 80 | 42 | 1.17 | +2243 | +53.4 |
| BEST OVERALL | 41 | 41 | 41 | 1.14 | +2698 | +65.8 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 38 | 38 | 38 | 1.06 | +3554 | +93.5 |
| CANNON PLANNED TARGET | 181 | 181 | 37 | 1.03 | -411 | -11.1 |
| CHARGE NOW FIRST | 203 | 203 | 36 | 1.00 | -1757 | -48.8 |
| MISSILES IN THE MOVE | 244 | 139 | 35 | 0.97 | +873 | +24.9 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | +479 | +14.1 |
| MARCH CHECK | 39 | 39 | 34 | 0.94 | +1196 | +35.2 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| REDIRECT WEIGHED | 32 | 32 | 32 | 0.89 | +1585 | +49.5 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 57 | 57 | 32 | 0.89 | +1043 | +32.6 |
| WHOLE FIGHT GAIN | 59 | 54 | 30 | 0.83 | +1735 | +57.8 |
| HONEST THREAT | 315 | 315 | 29 | 0.81 | +0 | +0.0 |
| ONE YARDSTICK | 433 | 127 | 29 | 0.81 | +553 | +19.1 |
| KILLS COUNT | 147 | 144 | 28 | 0.78 | +1494 | +53.4 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| STOPS SHORT OF THE FLANK | 25 | 25 | 25 | 0.69 | +1269 | +50.8 |
| INVITES THE FIGHT | 95 | 95 | 24 | 0.67 | +448 | +18.7 |
| SHOT REPLANNED | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 23 | 23 | 23 | 0.64 | +887 | +38.6 |
| KEEPS ITS TARGET | 138 | 137 | 23 | 0.64 | +360 | +15.7 |
| MODEL FACING | 23 | 23 | 23 | 0.64 | +3097 | +134.6 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +1068 | +48.6 |
| MAKE SURE TOGETHER | 40 | 32 | 21 | 0.58 | +923 | +43.9 |
| THROUGH LINE OF FIRE | 19 | 19 | 19 | 0.53 | +1208 | +63.6 |
| SHOOTERS ARE THREATS | 116 | 116 | 18 | 0.50 | +0 | +0.0 |
| STAY WORTH | 456 | 336 | 18 | 0.50 | +162 | +9.0 |
| BEST PREY | 55 | 55 | 17 | 0.47 | +546 | +32.1 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +993 | +58.4 |
| BIG CHARACTER SAFETY | 16 | 16 | 16 | 0.44 | -96 | -6.0 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| FIRE IN ORDER | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| HONEST WORTH | 380 | 375 | 16 | 0.44 | +65 | +4.1 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CAST JOB | 33 | 33 | 14 | 0.39 | +327 | +23.4 |
| MARCH ODDS | 14 | 14 | 14 | 0.39 | +302 | +21.6 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CHARGE BAND | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| WEARS DOWN | 100 | 97 | 13 | 0.36 | +419 | +32.2 |
| MANOEUVRE | 13 | 13 | 11 | 0.31 | +210 | +19.1 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| CASTING BLOCK | 13 | 13 | 10 | 0.28 | +479 | +47.9 |
| OPENS UP | 14 | 14 | 10 | 0.28 | +507 | +50.7 |
| WAR ENGINE JOBS | 33 | 33 | 10 | 0.28 | -177 | -17.7 |
| HUNT IN PAIRS | 26 | 15 | 8 | 0.22 | +858 | +107.3 |
| KEEPS THE TARGET | 23 | 23 | 8 | 0.22 | -532 | -66.5 |
| LOST CHARGE | 204 | 202 | 8 | 0.22 | +82 | +10.3 |
| OVERRUNS AWAY | 35 | 35 | 8 | 0.22 | +125 | +15.6 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -194 | -24.2 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -520 | -86.6 |
| CHAFF PASSED | 6 | 6 | 6 | 0.17 | -9 | -1.6 |
| SUPPORT NARROWED | 527 | 527 | 6 | 0.17 | -57 | -9.6 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.17 | -312 | -52.0 |
| DEFENSIVE ARMY | 12 | 12 | 5 | 0.14 | -78 | -15.6 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +348 | +69.5 |
| BACKUP TARGETS | 68 | 38 | 4 | 0.11 | +28 | +6.9 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +45 | +11.2 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 16 | 16 | 4 | 0.11 | -60 | -15.0 |
| LONG SHOT | 38 | 36 | 4 | 0.11 | +112 | +28.0 |
| MISSILES NEXT TURN | 284 | 164 | 4 | 0.11 | +14 | +3.6 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 4 | 0.11 | +267 | +66.7 |
| SURE REACH TOGETHER | 60 | 37 | 4 | 0.11 | +55 | +13.7 |
| WHOLE FIGHT | 22 | 22 | 4 | 0.11 | +297 | +74.2 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -26 | -8.6 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +21 | +7.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -42 | -20.8 |
| CHARGER SLAIN LOST | 24 | 24 | 2 | 0.06 | +192 | +96.2 |
| EDGE GIVE GROUND | 21 | 20 | 2 | 0.06 | +18 | +8.9 |
| JOINT CHARGE PLAN | 8 | 8 | 2 | 0.06 | +72 | +36.2 |
| MOVE SPELL IN RANGE | 2 | 2 | 2 | 0.06 | +31 | +15.4 |
| OPENS A LANE | 11 | 6 | 2 | 0.06 | +21 | +10.4 |
| REFUSING RETIRES | 7 | 7 | 2 | 0.06 | -0 | -0.2 |
| SHOOTERS TO THE PRIMARY | 54 | 31 | 2 | 0.06 | +2 | +0.9 |
| STOPS | 10 | 10 | 2 | 0.06 | +65 | +32.6 |
| WIDER SPREAD | 153 | 147 | 2 | 0.06 | +0 | +0.2 |
| BLOWS WHERE AIMED | 17 | 16 | 1 | 0.03 | +125 | +124.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +14 | +14.2 |
| CARRIES OUT SET-UP | 12 | 12 | 1 | 0.03 | -125 | -125.5 |
| CHARIOT NO STATIC JOB | 2 | 2 | 1 | 0.03 | -39 | -39.1 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +35 | +35.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +2 | +2.1 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +59 | +59.3 |
| NEEDED THERE | 2 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +57 | +57.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +52 | +51.9 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -88 | -88.5 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | -4 | -4.0 |
| REDIRECT BY WHAT IT STOPS | 16 | 16 | 1 | 0.03 | +3 | +2.9 |
| SPELLS IN THE FIGHT | 27 | 26 | 1 | 0.03 | +23 | +23.1 |
| TWO OR MORE ARRIVE | 20 | 20 | 1 | 0.03 | +10 | +10.5 |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 25 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 27 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 396 | not checked | - | - | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 11 | not checked | - | - | - | - |
| HELPER UNSEEN | 28 | 27 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 31 | 31 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 15 | 15 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 17 | trace | - | - | - | - |
| HUNT THE GUNS | 19 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 24 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 27 | 27 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 14 | 1 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT NEEDED | 28 | 28 | 0 | 0.00 | - | - |
| NOT TURNED | 419 | 419 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2832 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OPTIONS | 1005 | 1005 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 88 | not checked | - | - | - | - |
| STABLE ROLE | 847 | 845 | 0 | 0.00 | - | - |
| TURN WORTH | 26 | 26 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: ch-h2h-opp-ea652ef-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.75 | 14.03 | 51.3 |
| FALLBACK | gate | 0.56 | 0.58 | 29.0 |
| CHARGE NOW FIRST | rule | 0.44 | 0.56 | 48.8 |
| TURN GATE | gate | 0.69 | 0.31 | 27.6 |
| WAR ENGINE JOBS | rule | 0.22 | 0.06 | 17.7 |
| AFTERMATH BAND | gate | 0.19 | 0.06 | 1.9 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.14 | 15.5 |
| FIRE PLAN | rule | - | 0.25 | 27.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.11 | 28.9 |
| CANNON PLANNED TARGET | rule | 0.22 | - | 59.9 |
| FIGHT ORDER BAND | gate | 0.08 | 0.14 | 1.5 |
| KEEPS THE TARGET | rule | - | 0.22 | 66.5 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 24.2 |
| PATHS CROSS | rule | 0.11 | 0.08 | 30.6 |
| SUPPORT REQUEST | gate | 0.08 | 0.11 | 46.8 |
| BEST PRIZE | rule | - | 0.17 | 86.6 |
| SUPPORT NARROWED | rule | 0.17 | - | 9.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.11 | 52.0 |
| DEFENSIVE ARMY | rule | 0.11 | 0.03 | 15.6 |
| FACES THE THREAT | rule | 0.03 | 0.08 | 11.9 |
| REDIRECT WEIGHED | rule | - | 0.11 | 45.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | - | 134.7 |
| BLOCKED WHEEL | rule | 0.06 | 0.03 | 43.2 |
| MARCH ODDS | rule | 0.03 | 0.06 | 23.8 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 18.9 |
| CATCH ODDS | rule | 0.03 | 0.03 | 20.8 |
| CHAFF PASSED | rule | 0.06 | - | 4.5 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.03 | 25.0 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 17.4 |
| STANDS TO CAST | rule | 0.03 | 0.03 | 12.6 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 125.5 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 39.1 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 59.9 |
| NO REASON | gate | - | 0.03 | 441.7 |
| PURSUES BIG PREY | rule | - | 0.03 | 88.5 |
| PURSUES ON | rule | - | 0.03 | 4.0 |
| RULE SWITCHED OFF | gate | 0.03 | - | 1.4 |

### Plans: ch-h2h-opp-ea652ef-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.9 | 15% | 485 | 292 | 60% |
| Mine | charge | 3.0 | 76% | 298 | 332 | 112% |
| Mine | close in | 3.5 | 21% | 196 | 122 | 62% |
| Mine | hold | 4.6 | 28% | 293 | 0 | 0% |
| Mine | join | 0.8 | 96% | 23 | 0 | 0% |
| Mine | shoot | 8.4 | 62% | 249 | 682 | 274% |
| Mine | support | 5.1 | 91% | 36 | 0 | 0% |
| Opponent | advance | 14.1 | 15% | 391 | 314 | 80% |
| Opponent | charge | 5.0 | 49% | 431 | 415 | 96% |
| Opponent | close in | 6.5 | 28% | 390 | 173 | 44% |
| Opponent | hold | 4.4 | 36% | 313 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 44 | 0 | 0% |
| Opponent | shoot | 4.9 | 62% | 224 | 403 | 180% |
| Opponent | support | 5.4 | 90% | 46 | 0 | 0% |

### Packages: hunt the guns, ch-h2h-opp-ea652ef-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 40% | 40% | 0% | 2.5 | 326 | 199 | 40% | 49 |
| Opponent | 0.4 | 14 | 2 | 33% | 33% | 8% | 2.5 | 313 | 149 | 33% | 77 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 328 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 460 | 453 | 100% | 30 |
| Empire of Man | 0.3 | 2 | 0 | 0% | 50% | 0% | 3.0 | 359 | 270 | 50% | 19 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 180 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.8 | 7 | 0 | 57% | 57% | 0% | 2.5 | 411 | 255 | 57% | 105 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 118 |
| Tomb Kings of Khemri | 1.2 | 6 | 1 | 0% | 0% | 20% | - | 130 | 1 | 0% | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 5 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |
| Wood Elf Realms | 0.3 | 2 | 1 | 0% | 0% | 0% | - | 446 | 0 | 0% | 30 |

### Battle groups: ch-h2h-opp-ea652ef-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.5 | 25% | 52% | 8% | 25% | 35% | 7% | 14% | 44% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 35% | 63% | 7% | 0% | 8% | 0% | 20% | 72% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.4 | 22% | 64% | 14% | 38% | 37% | 16% | 8% | 39% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 22% | 62% | 17% | 40% | 17% | 4% | 8% | 67% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ch-h2h-opp-ea652ef-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 84 | 20% | 3.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Chaff | 33 | 84 (33) | 45 | 39 | 63 | 24% | 2.8 | 78 (18) | 176 (7) | 20 (8) | 120 (22) | 9 (11) |
| Mine | Character | 123 | 54 (123) | 53 | 1 | 34 | 19% | 2.6 | 72 (38) | 50 (50) | 19 (14) | 64 (53) | 49 (49) |
| Mine | Clean-up | 21 | 68 (21) | 35 | 33 | 45 | 29% | 3.1 | 9 (5) | 99 (13) | 79 (3) | 104 (13) | 30 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 46 | 40 (46) | 21 | 18 | 59 | 26% | 3.2 | 31 (22) | 71 (16) | 6 (8) | 44 (29) | 34 (17) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 1.6 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 38 (57) | 28 | 10 | 47 | 21% | 2.5 | 13 (18) | 42 (29) | 73 (10) | 36 (38) | 41 (19) |
| Mine | Holder | 28 | 59 (28) | 1 | 58 | 29 | 46% | 2.9 | 47 (11) | 89 (11) | 21 (6) | 79 (20) | 18 (8) |
| Mine | Shooter | 44 | 84 (44) | 34 | 50 | 52 | 5% | 1.6 | 107 (7) | 85 (30) | 61 (7) | 99 (26) | 63 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 38 (59) | 38 | 0 | 40 | 2% | 1.2 | 20 (10) | 49 (37) | 15 (12) | 33 (10) | 40 (49) |
| Mine | Wizard | 22 | 3 (22) | 3 | 0 | 51 | 18% | 2.5 | 0 (7) | 15 (6) | 0 (5) | 0 (5) | 5 (13) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 38 | 50% | 4.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 52 (76) | 28 | 24 | 45 | 36% | 2.8 | 69 (32) | 28 (19) | 53 (25) | 72 (54) | 4 (22) |
| Opponent | Character | 97 | 60 (97) | 60 | 0 | 35 | 20% | 2.6 | 77 (39) | 54 (40) | 52 (6) | 57 (58) | 79 (27) |
| Opponent | Clean-up | 19 | 41 (19) | 28 | 13 | 40 | 21% | 3.2 | 39 (9) | 44 (10) | - | 50 (14) | 16 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 0% | 4.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 35 (48) | 22 | 14 | 40 | 15% | 2.8 | 21 (22) | 28 (16) | 82 (10) | 28 (28) | 49 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 61 | 20% | 2.0 | - | 0 (3) | 0 (2) | 0 (4) | 0 (1) |
| Opponent | Hammer | 70 | 30 (70) | 27 | 3 | 44 | 16% | 3.2 | 38 (17) | 28 (42) | 26 (11) | 33 (43) | 25 (27) |
| Opponent | Holder | 35 | 82 (35) | 9 | 73 | 20 | 34% | 3.0 | 43 (8) | 81 (23) | 165 (4) | 100 (23) | 42 (12) |
| Opponent | Shooter | 33 | 78 (33) | 17 | 61 | 34 | 0% | 1.8 | 66 (8) | 90 (19) | 49 (6) | 117 (22) | 16 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 67% | 5.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 24 | 62 (24) | 62 | 0 | 33 | 12% | 1.4 | 71 (6) | 60 (14) | 56 (4) | 85 (3) | 58 (21) |
| Opponent | Wizard | 26 | 28 (26) | 28 | 0 | 41 | 8% | 1.5 | 0 (10) | 83 (5) | 24 (7) | 68 (8) | 3 (14) |

### Charged fights: ch-h2h-opp-ea652ef-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 80 | 88 | 1.2 | 1.4 | 70 | 10 | +60 | 1 of 5 | 5 of 5 | +86 | +42 |
| Mine | Chaos Dwarfs | 4 | 16 | 381 | 2.8 | 1.1 | 139 | 0 | +139 | 6 of 11 | 10 of 11 | +0 | +152 |
| Mine | Dwarfen Mountain Holds | 4 | 500 | 301 | 2.0 | 1.2 | 150 | 0 | +150 | 2 of 8 | 6 of 8 | +260 | +114 |
| Mine | Empire of Man | 5 | 408 | 126 | 1.0 | 1.4 | 126 | 0 | +126 | 2 of 5 | 4 of 5 | +522 | +28 |
| Mine | Grand Cathay | 4 | 304 | 274 | 4.0 | 1.1 | 69 | 56 | +13 | 6 of 16 | 13 of 16 | -217 | +45 |
| Mine | High Elf Realms | 4 | 16 | 576 | 2.8 | 1.2 | 210 | 69 | +141 | 5 of 11 | 8 of 11 | -76 | +189 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 525 | 7.0 | 1.0 | 75 | 31 | +44 | 1 of 7 | 6 of 7 | - | +44 |
| Mine | Lizardmen | 1 | 45 | 1039 | 3.0 | 1.3 | 346 | 0 | +346 | 1 of 3 | 3 of 3 | +853 | +93 |
| Mine | Ogre Kingdoms | 1 | 0 | 45 | 4.0 | 1.0 | 11 | 83 | -72 | 1 of 4 | 1 of 3 | - | -72 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 332 | 4.0 | 1.2 | 83 | 14 | +69 | 1 of 4 | 4 of 4 | +45 | +77 |
| Mine | Skaven | 2 | 0 | 248 | 2.5 | 1.0 | 99 | 39 | +60 | 2 of 5 | 4 of 5 | - | +60 |
| Mine | Tomb Kings of Khemri | 1 | 114 | 557 | 5.0 | 1.4 | 111 | 24 | +87 | 1 of 5 | 4 of 5 | +278 | -41 |
| Mine | Vampire Counts | 3 | 0 | 410 | 5.0 | 1.2 | 82 | 28 | +54 | 2 of 15 | 9 of 15 | +63 | +53 |
| Mine | Warriors of Chaos | 1 | 0 | 627 | 3.0 | 1.0 | 209 | 0 | +209 | 0 of 3 | 3 of 3 | - | +209 |
| **Mine** | all armies | 36 | 163 | 332 | 2.8 | 1.2 | 117 | 30 | +88 | 31 of 102 | 80 of 101 | +138 | +78 |
| Opponent | Dwarfen Mountain Holds | 2 | 135 | 75 | 2.0 | 1.2 | 38 | 24 | +14 | 1 of 4 | 1 of 4 | -95 | +50 |
| Opponent | Empire of Man | 2 | 698 | 425 | 2.5 | 1.2 | 170 | 104 | +66 | 4 of 5 | 5 of 5 | +0 | +83 |
| Opponent | Grand Cathay | 2 | 510 | 446 | 2.0 | 1.5 | 223 | 95 | +128 | 2 of 4 | 3 of 4 | +289 | +74 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 398 | 3.0 | 1.0 | 133 | 0 | +133 | 1 of 3 | 3 of 3 | - | +133 |
| Opponent | Ogre Kingdoms | 3 | 0 | 152 | 4.3 | 1.0 | 35 | 55 | -20 | 6 of 13 | 5 of 13 | - | -20 |
| Opponent | Skaven | 1 | 110 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 93 | 788 | 4.5 | 1.3 | 175 | 102 | +73 | 8 of 18 | 13 of 18 | +187 | +29 |
| Opponent | Vampire Counts | 6 | 30 | 706 | 4.2 | 1.2 | 169 | 29 | +141 | 12 of 25 | 19 of 25 | +95 | +155 |
| Opponent | Warriors of Chaos | 8 | 8 | 470 | 2.4 | 1.4 | 198 | 6 | +192 | 9 of 19 | 15 of 19 | +311 | +122 |
| Opponent | Wood Elf Realms | 7 | 88 | 624 | 4.7 | 1.2 | 132 | 19 | +114 | 8 of 33 | 24 of 33 | +219 | +95 |
| **Opponent** | all armies | 36 | 112 | 507 | 3.4 | 1.2 | 147 | 40 | +107 | 51 of 124 | 88 of 124 | +191 | +85 |

### Effective charges: ch-h2h-opp-ea652ef-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 0 | 0 | 1 (net +55) | 4 (net +61) | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 11 | 2 (net +488) | 0 | 0 | 3 (net +42) | 1 (net +0) | 5 (net +85) | 0 | 0% (0 of 11) |
| Mine | Dwarfen Mountain Holds | 8 | 1 (net +0) | 0 | 1 (net +137) | 1 (net +0) | 0 | 5 (net +213) | 0 | 12% (1 of 8) |
| Mine | Empire of Man | 5 | 0 | 0 | 1 (net +0) | 1 (net +65) | 1 (net +45) | 1 (net +522) | 1 | 25% (1 of 4) |
| Mine | Grand Cathay | 16 | 2 (net -326) | 1 (net +0) | 1 (net +0) | 3 (net +0) | 2 (net -102) | 7 (net +151) | 0 | 6% (1 of 16) |
| Mine | High Elf Realms | 11 | 1 (net +0) | 1 (net +743) | 0 | 5 (net +28) | 1 (net +261) | 1 (net -143) | 2 | 0% (0 of 9) |
| Mine | Kingdom of Bretonnia | 7 | 0 | 0 | 1 (net +0) | 3 (net +147) | 1 (net +85) | 2 (net -107) | 0 | 14% (1 of 7) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 2 (net +520) | 1 (net +0) | 0 | 0 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 2 (net +139) | 0 | 0 | 0 | 2 | 100% (2 of 2) |
| Mine | Skaven | 5 | 1 (net +0) | 0 | 1 (net +270) | 1 (net +0) | 0 | 2 (net +15) | 0 | 20% (1 of 5) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net -122) | 0 | 4 (net +139) | 0 | 0 | 20% (1 of 5) |
| Mine | Vampire Counts | 15 | 3 (net -54) | 0 | 2 (net +216) | 6 (net +14) | 1 (net +125) | 3 (net +110) | 0 | 13% (2 of 15) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net +19) | 0 | 1 (net +608) | 1 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net -95) | 2 (net +42) | 0 | 0 | 1 | 33% (1 of 3) |
| Opponent | Empire of Man | 5 | 2 (net +425) | 0 | 0 | 1 (net -519) | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Grand Cathay | 4 | 2 (net +149) | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 33% (1 of 3) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 1 (net +278) | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 13 | 4 (net +114) | 0 | 2 (net -150) | 2 (net -38) | 0 | 1 (net -185) | 4 | 22% (2 of 9) |
| Opponent | Tomb Kings of Khemri | 18 | 3 (net -43) | 0 | 3 (net +179) | 3 (net +47) | 2 (net +48) | 4 (net +121) | 3 | 20% (3 of 15) |
| Opponent | Vampire Counts | 25 | 3 (net +521) | 2 (net +0) | 4 (net +194) | 9 (net +19) | 3 (net +152) | 2 (net +128) | 2 | 17% (4 of 23) |
| Opponent | Warriors of Chaos | 19 | 1 (net +0) | 1 (net +563) | 6 (net +80) | 2 (net +72) | 1 (net +95) | 5 (net +348) | 3 | 38% (6 of 16) |
| Opponent | Wood Elf Realms | 33 | 7 (net +140) | 2 (net +134) | 5 (net +73) | 9 (net +79) | 0 | 8 (net +158) | 2 | 16% (5 of 31) |

### Charged fights, damage counted: ch-h2h-opp-ea652ef-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 254 | 219 | +16 | 117 | 85 | +32 | +12.4 |
| Mine | 50-54% | 2 | 550 | 226 | +372 | 372 | 0 | +372 | +67.6 |
| Mine | Effective (55-75%) | 10 | 271 | 234 | +100 | 150 | 45 | +105 | +38.7 |
| Mine | 76-89% | 26 | 274 | 186 | +74 | 117 | 45 | +72 | +26.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 227 | 172 | +127 | 162 | 25 | +138 | +60.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 355 | 87 | +71 | 114 | 21 | +93 | +26.2 |
| Mine | No odds | 10 | 179 | 152 | +26 | 74 | 44 | +30 | +16.8 |
| Mine | All fights | 102 | 264 | 174 | +88 | 134 | 39 | +96 | +36.3 |
| Opponent | Long shot (under 50%) | 22 | 295 | 223 | +183 | 286 | 114 | +172 | +58.4 |
| Opponent | 50-54% | 5 | 449 | 243 | +166 | 172 | 3 | +169 | +37.5 |
| Opponent | Effective (55-75%) | 22 | 242 | 191 | +80 | 111 | 44 | +68 | +27.9 |
| Opponent | 76-89% | 29 | 234 | 188 | +32 | 92 | 49 | +43 | +18.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 339 | 241 | +170 | 228 | 59 | +169 | +49.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 494 | 97 | +92 | 129 | 14 | +115 | +23.2 |
| Opponent | No odds | 18 | 200 | 162 | +84 | 121 | 29 | +91 | +45.5 |
| Opponent | All fights | 124 | 282 | 197 | +107 | 162 | 55 | +108 | +38.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ch-h2h-opp-ea652ef-p2 | move | 472 | 96 (20%) | 69 (15%) | 62 (13%) | 314 (67%) |
| ch-h2h-opp-ea652ef-p2 | objective | 366 | 62 (17%) | 41 (11%) | 41 (11%) | 263 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

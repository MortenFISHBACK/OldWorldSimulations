# Doctrine scorecard: ch-h2h-mine-ea652ef-p1

### Scorecard: ch-h2h-mine-ea652ef-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 7 | 5 | 0 | 1 | 0 | 0 | 0 | 322 |
| L0102 | 6 | 1 | Opponent | no | 6 | 1 | 3 | 3 | 0 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 317 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 68 |
| L0135 | 3 | 1 | Mine | no | 6 | 6 | 0 | 3 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 7 | 3 | 5 | 0 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 3 | 5 | 3 | 1 | 0 | 0 | 0 | 1258 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 2 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 771 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 971 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 1444 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | 4 | 3 | 1 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 798 |
| L0628 | 4 | 1 | Opponent | no | 2 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 11 | 4 | 2 | 1 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 3 | 3 | 2 | 3 | 0 | 0 | 0 | 144 |
| L0823 | 1 | 1 | Mine | no | 2 | - | 0 | 1 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 2 | 0 | 0 | 140 |
| L0913 | 1 | 1 | Mine | no | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 785 |
| L0913 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 2 | 0 | 0 | 0 | 0 | 689 |
| L0930 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 4 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 677 |
| L1131 | 3 | 1 | Mine | no | 3 | - | 2 | 0 | 2 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 286 |
| L1224 | 6 | 1 | Mine | no | 8 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 2 | 6 | 1 | 1 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 4 | 3 | 1 | 1 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | no | 8 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 1 | - | 6 | 1 | 2 | 0 | 0 | 170 |
| L1527 | 3 | 1 | Mine | yes | 0 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 4 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 1 | 4 | 1 | 0 | 0 | 0 | 68 |
| L1723 | 1 | 1 | Mine | no | 1 | 1 | 1 | 0 | 2 | 0 | 0 | 207 |
| L1723 | 1 | 1 | Opponent | yes | 8 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 3 | 1 | 0 | 0 | 0 | 419 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | no | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 1 | 2 | 2 | 1 | 2 | 0 | 0 | 612 |
| L2025 | 3 | 1 | Opponent | no | 5 | 4 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 722 |
| L2127 | 3 | 1 | Opponent | no | 7 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 2 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 327 |
| L2335 | 1 | 1 | Opponent | no | 4 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 6 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 24% | 2.7 | 2.6 | 2.4 | 1.0 | 0.4 | 0.0 | 0.0 | 346.0 |
| **Average** | | | Opponent | 18% | 1.9 | 2.3 | 2.8 | 1.9 | 0.5 | 0.0 | 0.0 | 159.3 |

### KPIs: ch-h2h-mine-ea652ef-p1

Rules off - Opponent only: CHARGE BAND, HONEST WORTH, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 33% (56 of 169) | 5% (8 of 174) | 19% (64 of 343) |
| Winner chose to follow up after the loser gave ground |  | 99% (66 of 67); on the table 99% | 100% (55 of 55); on the table 100% | 99% (121 of 122); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 93% (14 of 15); on the table 93% | 84% (16 of 19); on the table 84% | 88% (30 of 34); on the table 88% |
| Winner chose to pursue after the loser fled |  | 88% (21 of 24); on the table 96% | 74% (32 of 43); on the table 77% | 79% (53 of 67); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 95% (101 of 106); on the table 97% | 88% (103 of 117); on the table 89% | 91% (204 of 223); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 36% (119 of 330) | 34% (71 of 210) | 35% (190 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (119 of 242) | 42% (65 of 154) | 46% (184 of 396) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 26% (39 of 150) | 20% (17 of 84) | 24% (56 of 234) |
|     round 1 |  | 28% (7 of 25) | 14% (2 of 14) | 23% (9 of 39) |
|     rounds 2+ |  | 26% (32 of 125) | 21% (15 of 70) | 24% (47 of 195) |
|   other wizards | 50%+ | 44% (80 of 180) | 40% (48 of 120) | 43% (128 of 300) |
|     round 1 |  | 33% (10 of 30) | 35% (7 of 20) | 34% (17 of 50) |
|     rounds 2+ |  | 47% (70 of 150) | 41% (41 of 100) | 44% (111 of 250) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 71% (20 of 28) | 67% (35 of 52) | 69% (55 of 80) |
| Points that never fought | lower | 37% (26101 of 71484) | 43% (30716 of 71889) | 40% (56817 of 143373) |
|   infantry points that never fought | lower | 49% (8195 of 16863) | 66% (8868 of 13348) | 56% (17063 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (152 of 279) | 59% (175 of 295) | 57% (327 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.2 uses a game | 70% (14 of 20); 1.4 uses a game | 83% (35 of 42); 1.8 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.6 uses a game | 50% (4 of 8); 0.1 uses a game | 50% (12 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 67% (8 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (28978 of 59666) | 56% (35247 of 62699) | 52% (64225 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.6 (44%) | 1.3 (35%) | 3.9 (40%) |
| MARCHED: its unit marched | 0.6 (10%) | 0.4 (9%) | 1.0 (10%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.2 (6%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.5 (25%) | 0.4 (10%) | 1.9 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (11%) | 0.4 (4%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.4 (7%) | 0.9 (23%) | 1.3 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (8%) | 0.1 (3%) | 0.6 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.3 | 1.2 | 5.3 | 0.4 | 1.7 |
| not cast | 3.8 | 3.1 | 3.4 | 9.7 | 2.0 | 22.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.3 (44%) | 0.3 (10%) | 3.9 (40%) | 0.6 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (10%) | 0.2 (10%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.2 (11%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.2 (6%) | 0.4 (13%) | 1.9 (19%) | 0.4 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (11%) | 0.5 (15%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) | 0.0 (1%) | 0.8 (3%) |
| GONE: slain | 1.0 (26%) | 0.6 (18%) | 0.5 (14%) | 1.3 (13%) | 0.2 (8%) | 3.1 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.1 (4%) | 0.0 (0%) | 0.6 (6%) | 0.1 (4%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (57%) | 0.3 (10%) | 1.6 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.4 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.3 a game | 0.8 a game |
| stood (cast and not dispelled) | 54% (21 of 39) | 30% (3 of 10) | 49% (24 of 49) |
| the unit moved after it | 52% (11 of 21) | 100% (3 of 3) | 58% (14 of 24) |
| it charged on its next turn | 0% (0 of 21) | 33% (1 of 3) | 4% (1 of 24) |
| the enemy charged it first | 29% (6 of 21) | 33% (1 of 3) | 29% (7 of 24) |
| it fought by the end of its next turn | 19% (4 of 21) | 33% (1 of 3) | 21% (5 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (4 of 21) | 33% (1 of 3) | 21% (5 of 24) |
| none of these (no charge, no fight, no charge escaped) | 52% (11 of 21) | 33% (1 of 3) | 50% (12 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (590 of 932) | 59% (351 of 596) | 62% (941 of 1528) |
|   cavalry | 65% (52 of 80) | 59% (72 of 123) | 61% (124 of 203) |
|   character | 48% (61 of 128) | 35% (38 of 109) | 42% (99 of 237) |
|   chariot | 52% (48 of 93) | 69% (24 of 35) | 56% (72 of 128) |
|   infantry | 63% (191 of 304) | 61% (140 of 230) | 62% (331 of 534) |
|   monster | 62% (21 of 34) | 58% (19 of 33) | 60% (40 of 67) |
|   war machine | 74% (217 of 293) | 88% (58 of 66) | 77% (275 of 359) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (20%) | 1.5 (22%) | 3.4 (21%) |
| CHARGED: it charged | 1.1 (12%) | 1.5 (22%) | 2.6 (16%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.4 (6%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.6 (17%) | 1.6 (23%) | 3.2 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.7 (11%) | 1.4 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (23%) | 0.7 (11%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.2 (2%) | 0.6 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR | 0.5 (5%) | 0.1 (2%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.4 | 81% | 5.1 pts | 26 pts |
| character | 3.1 | 1.3 | 69% | 12.0 pts | 37 pts |
| chariot | 2.0 | 1.1 | 65% | 12.6 pts | 25 pts |
| infantry | 13.5 | 5.4 | 71% | 9.4 pts | 127 pts |
| monster | 1.2 | 0.3 | 81% | 3.7 pts | 4 pts |
| war machine | 7.6 | 5.4 | 63% | 21.8 pts | 167 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 6.2 | 5.1 |
| Charges that made contact a game | 3.1 | 4.0 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.10 declared, 0.90 contact (21 units) | 0.25 declared, 0.17 contact (12 units) | 0.79 declared, 0.64 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.62 declared, 0.25 contact (8 units) | 1.50 declared, 1.12 contact (8 units) | 1.06 declared, 0.69 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.36 contact (250 units) | 0.73 declared, 0.47 contact (282 units) | 0.61 declared, 0.42 contact (532 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (35 of 70) | 52% (11 of 21) | 62% (5 of 8) | 52% (51 of 99) |
| Character in a unit | 81% (26 of 32) | 59% (16 of 27) | 60% (3 of 5) | 70% (45 of 64) |
| Character on its own | 76% (42 of 55) | 58% (19 of 33) | 30% (18 of 61) | 53% (79 of 149) |
| Chariot | 62% (10 of 16) | 40% (4 of 10) | - | 54% (14 of 26) |
| Infantry | 54% (48 of 89) | 44% (16 of 36) | 50% (1 of 2) | 51% (65 of 127) |
| Monster | 69% (22 of 32) | 80% (8 of 10) | - | 71% (30 of 42) |
| Monstrous | 64% (7 of 11) | 64% (9 of 14) | - | 64% (16 of 25) |
| War Machines | 63% (26 of 41) | 100% (1 of 1) | - | 64% (27 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 92% (12 of 13); on the table 100% | 58% (80 of 138) | 53% | 61% (20 of 33) | 100% (9 of 9); 7.3 uses a game | 100% (3 of 3); 2.0 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 100% (11 of 11); on the table 100% | 17% (4 of 24) | 39% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 85% (11 of 13); on the table 92% | - | 63% | 78% (32 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 75% (3 of 4); on the table 75% | 36% (13 of 36) | 48% | 55% (35 of 64) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (17 of 17); on the table 100% | 28% (30 of 108) | 40% | 34% (15 of 44) | 92% (11 of 12); 7.6 uses a game | 100% (1 of 1); 0.4 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 95% (19 of 20); on the table 95% | 20% (6 of 30) | 24% | 53% (26 of 49) | 100% (5 of 5); 2.8 uses a game | 39% (7 of 18); 1.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 25% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | - | 23% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 80% (4 of 5); on the table 80% | 0% (0 of 12) | 62% | 71% (15 of 21) | 67% (2 of 3); 2.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (7 of 7); on the table 100% | 3% (1 of 36) | 4% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (17 of 17); on the table 100% | 30% (9 of 30) | 36% | 56% (19 of 34) | 67% (2 of 3); 0.5 uses a game | 0.0 uses a game | 100% (4 of 4); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 83% (15 of 18); on the table 83% | 25% (3 of 12) | 33% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 87% (41 of 47); on the table 89% | 43% (23 of 54) | 35% | 60% (30 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 88% (23 of 26); on the table 88% | 47% (14 of 30) | 42% | 68% (50 of 74) | 100% (4 of 4); 2.1 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 94% (17 of 18); on the table 94% | 23% (7 of 30) | 41% | 59% (39 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ch-h2h-mine-ea652ef-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (37) | 53% (36) | 49% (73) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.69 | 1.36 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.14 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.42 | 0.97 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.08 | 1.08 | 2.17 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.67 | 1.56 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.42 | 5.06 | 10.47 |

### Quality by phase: ch-h2h-mine-ea652ef-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 54% (69 of 128) | 44% (84 of 189) |
| Strategy | Shoot objectives carried out (shot that target) | 28% (120 of 422) | 60% (111 of 186) |
| Strategy | Close-in objectives charged next turn | 14% (21 of 152) | 15% (34 of 220) |
| Strategy | Support requests answered (helper made contact too) | 36% (5 of 14) | 44% (12 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 82% (9 of 11) | 62% (5 of 8) |
| Strategy | Joined characters whose unit fought | 42% (22 of 53) | 39% (17 of 44) |
| Strategy | Lone characters that fought | 82% (76 of 93) | 70% (64 of 92) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 1.9 |
| Movement | Points that never moved of their own | 346.0 | 159.3 |
| Movement | Fights charged into per game | 2.7 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 85, net +36 | 16 of 92, net +174 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 85, net +111 | 17 of 92, net +127 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 85, net +177 | 7 of 92, net +41 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 85, net +87 | 27 of 92, net +222 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.1 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (141 of 399) | 41% (135 of 328) |
| Shooting | Points destroyed by shooting units | 80.1 | 30.9 |
| Shooting | War machine shots | 6.0 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (114 of 217) | 33% (19 of 58) |
| Shooting | Points destroyed by war machines | 99.2 | 22.2 |
| Magic | Magic missiles cast | 2.1 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (24 of 77) | 38% (18 of 47) |
| Magic | Wounds caused by magic missiles | 5.9 | 1.7 |
| Magic | Wounds caused by other spells | 2.0 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 95.8 | 28.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.9 / 0.4 / 0.7 / 0.1 | 1.4 / 0.3 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 304.5 | 356.2 |
| Combat | Points run down | 43.1 | 126.3 |
| Combat | Net points per charged fight, damage counted | +78 | +128 |
| Combat | Net per 100 charger points, damage counted | +28.3 | +47.0 |
| Combat | First round won (charged fights) | 81% | 68% |
| Combat | Net points per charged fight | +69 | +126 |
| Combat | Net points per supported fight / lone fight | +196 / +46 | +127 / +126 |
| Combat | Charged fights on a top-3 enemy unit | 32 of 96 | 52 of 118 |
| Game | Points lost | 765.1 | 710.5 |
| Game | VP from objectives | 589.4 | 655.6 |
| Game | Lone holders (player turns) | 2.7 | 1.9 |

- Mine won / drew / lost: 14 / 5 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -144 VP
- The side that went first won 11 of 31 games with a winner
- Points traded per game (both sides' losses): 1476
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ch-h2h-mine-ea652ef-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 3.5 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.8 | +0.0 | 0.0 | 26.8 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +9.6 | 0.0 | 5.5 | 1.0 | +11.9 | 0.0 | 43.2 |
| BEST FACING | 0.6 | +11.9 | 0.0 | 32.4 | 0.4 | +30.4 | 0.0 | 20.8 |
| BEST FIRST | 4.0 | +166.8 | 119.4 | 83.2 | 4.0 | +183.1 | 84.2 | 59.8 |
| BEST MOVE FOR SHOOTERS | 1.1 | +107.3 | 0.0 | 12.0 | - | - | - | - |
| BEST OVERALL | 0.6 | +32.2 | 0.0 | 13.8 | 0.4 | +36.8 | 0.0 | 14.6 |
| BEST PREY | 0.6 | +29.0 | 11.3 | 24.0 | 0.9 | +32.5 | 32.7 | 19.2 |
| BEST PRIZE | 0.0 | -1.7 | 0.0 | 0.0 | 0.1 | +1.2 | 3.2 | 4.8 |
| BIG CHARACTER SAFETY | 0.2 | -0.4 | 0.0 | 0.0 | 0.1 | -1.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.9 | 0.0 | 0.1 | +0.0 | 11.7 | 0.0 |
| BLOCKED WHEEL | 0.2 | -0.5 | 0.0 | 4.0 | 0.3 | +7.7 | 0.0 | 6.5 |
| BLOWS WHERE AIMED | 0.2 | -13.2 | 18.8 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.1 | +1.7 | 8.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.1 | +0.0 | 1.8 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 1.4 | +47.0 | 31.0 | 7.9 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | -5.1 | 7.6 | 15.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 4.8 | 0.0 | 0.1 | +0.0 | 9.3 | 0.0 |
| CAST JOB | 0.9 | +30.4 | 61.5 | 11.4 | 0.4 | +7.9 | 19.5 | 6.5 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +54.7 | 9.1 | 0.0 | 0.3 | +7.6 | 1.9 | 4.4 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 13.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.0 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.2 | -0.4 | 8.0 | 3.8 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +1.1 | 6.6 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 7.7 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.6 | +0.0 | 200.3 | 126.6 | 2.9 | +0.0 | 286.7 | 61.4 |
| CHARGE NOW WEIGHED | 0.5 | -30.5 | 9.0 | 31.0 | 0.6 | -46.2 | 28.5 | 25.8 |
| CHARGER SLAIN LOST | 0.4 | -4.0 | 42.2 | 9.7 | - | - | - | - |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.2 | 8.0 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.4 |
| COMBAT PIVOT | 0.4 | +0.0 | 15.5 | 36.0 | 0.4 | +0.0 | 27.3 | 17.8 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 1.5 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +227.3 | 0.0 | 0.0 | 0.2 | +52.5 | 13.1 | 20.7 |
| COUNTER-CHARGE COVER | 9.4 | +897.5 | 0.0 | 217.4 | 7.3 | +685.8 | 0.0 | 169.3 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 11.7 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +2.7 | 0.0 | 1.8 | 0.0 | +0.5 | 2.2 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +10.7 | 16.1 | 12.1 | 0.1 | +5.6 | 11.0 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.0 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | 10.4 | +0.0 | 608.6 | 216.7 | - | - | - | - |
| FACE THE CAST | 0.1 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.1 | +103.2 | 0.0 | 56.1 | 1.1 | +103.8 | 0.0 | 52.4 |
| FALLBACK BY WORTH | 4.8 | +46.7 | 0.0 | 62.1 | 5.6 | +60.0 | 0.0 | 60.5 |
| FIGHT LIFT | 0.1 | +0.7 | 0.0 | 1.7 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 1.7 | - | - | - | - |
| FIRE IN ORDER | 0.9 | +0.0 | 28.8 | 5.3 | - | - | - | - |
| FIRE PLAN | 17.1 | +109.0 | 963.2 | 320.9 | - | - | - | - |
| FLANK NOT WEIGHED | 5.8 | +0.0 | 0.0 | 139.0 | 5.1 | +0.0 | 0.0 | 140.6 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.6 | 0.9 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +154.8 | 0.0 | 54.8 | 1.2 | +176.9 | 0.0 | 3.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +20.9 | 0.0 | 0.0 | 0.1 | +10.6 | 0.0 | 0.0 |
| GATEWAY ESCAPE | - | - | - | - | 0.0 | +3.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.2 | -1.8 | 6.0 | 1.4 |
| GIVES UP ITS SCREEN | 0.1 | -0.1 | 3.5 | 2.4 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 3.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.8 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 2.4 | 0.3 | +0.0 | 41.9 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -11.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 10.4 | +1587.0 | 608.6 | 216.7 | - | - | - | - |
| HONEST WORTH | 7.2 | -128.8 | 471.4 | 204.5 | - | - | - | - |
| HUNT ADVANCE | - | - | - | - | 0.1 | +3.2 | 6.5 | 4.4 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 2.4 | 1.5 |
| HUNT IN PAIRS | 0.4 | +18.1 | 0.0 | 10.0 | 0.4 | +32.4 | 0.0 | 17.5 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.0 | 5.6 | 2.8 |
| HUNT RESULT | - | - | - | - | 0.1 | +15.4 | 8.8 | 2.8 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +72.9 | 6.5 | 7.4 |
| INVITES THE FIGHT | 1.6 | +40.1 | 110.9 | 52.3 | 1.5 | +27.0 | 28.9 | 6.9 |
| JOINT CHARGE PLAN | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +10.2 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -2.0 | 0.0 | 7.8 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.5 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 1.8 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +46.7 | 105.9 | 61.1 | 2.1 | +63.3 | 143.0 | 74.7 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | 1.7 | -49.3 | 148.3 | 38.4 | - | - | - | - |
| KILLS COUNT | 1.6 | +83.6 | 95.7 | 72.9 | 2.1 | +95.1 | 184.1 | 53.9 |
| KILLS COUNT NEXT TURN | 4.2 | +141.1 | 200.3 | 105.6 | 6.3 | +226.1 | 262.2 | 198.1 |
| LONE CHARACTER SAFE SPOT | 0.4 | +5.9 | 7.1 | 15.0 | 0.4 | +4.3 | 8.3 | 24.9 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 4.7 | 0.0 | 0.3 | +0.0 | 0.0 | 5.9 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -1.4 | 10.9 | 14.9 | 0.5 | -1.3 | 35.6 | 0.0 |
| LOST CHARGE | 2.9 | -33.3 | 145.4 | 131.7 | 3.0 | -46.1 | 55.1 | 91.4 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | -1.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +45.6 | 4.8 | 28.6 | 0.7 | +95.8 | 0.0 | 14.4 |
| MANOEUVRE | 0.2 | +8.2 | 0.0 | 4.5 | 0.3 | +14.8 | 0.0 | 1.5 |
| MARCH AT ESCAPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 5.6 |
| MARCH CHECK | 0.2 | +18.4 | 0.0 | 0.0 | 0.5 | +31.4 | 0.0 | 3.0 |
| MARCH ODDS | 0.2 | +10.8 | 6.1 | 0.0 | 0.3 | +23.5 | 15.1 | 15.5 |
| MARCH OVER CASTS | 0.4 | +49.7 | 0.0 | 0.0 | 0.3 | +35.3 | 0.0 | 22.0 |
| MAX FOR POSITIONING | 4.8 | +179.7 | 0.0 | 111.7 | 4.4 | +141.5 | 0.0 | 103.3 |
| MISSILES IN THE FIRE PLAN | 2.1 | +25.1 | 123.5 | 26.4 | - | - | - | - |
| MISSILES IN THE MOVE | 4.4 | +199.9 | 0.0 | 84.9 | 3.8 | +56.0 | 0.0 | 61.9 |
| MISSILES NEXT TURN | 4.8 | +128.9 | 0.0 | 85.2 | 4.3 | +41.7 | 0.0 | 83.9 |
| MODEL FACING | 0.3 | +95.1 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +27.6 | 0.0 | 0.0 | 0.3 | +21.9 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -67.2 | 0.0 | 0.0 | 0.2 | -2.7 | 3.5 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 13.1 |
| MOVE TO CHARGE | 2.9 | +212.0 | 147.4 | 78.6 | 5.1 | +393.4 | 199.5 | 172.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.0 | 3.5 | 0.0 | 0.1 | +5.0 | 9.2 | 3.2 |
| NO RALLY LEFT | 0.1 | +2.6 | 0.0 | 5.6 | - | - | - | - |
| NOT NEEDED | 0.2 | -12.4 | 27.6 | 0.0 | 0.6 | -30.2 | 81.1 | 3.5 |
| NOT TURNED | 5.4 | +89.5 | 0.0 | 94.2 | 5.1 | +56.4 | 0.0 | 77.3 |
| NOT WORTH A CAST | 0.8 | -0.8 | 0.0 | 21.1 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.3 | -854.9 | 2.1 | 259.3 | 14.9 | -855.4 | 9.2 | 265.7 |
| ONE YARDSTICK | 18.7 | -601.8 | 635.0 | 304.6 | - | - | - | - |
| OPENS A LANE | 0.2 | +1.7 | 9.3 | 1.7 | 0.1 | +0.7 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +9.3 | 1.5 | 0.0 | 0.3 | +30.7 | 9.9 | 7.9 |
| OVERRUNS AWAY | 0.5 | +5.4 | 27.9 | 17.6 | 0.5 | +7.3 | 30.7 | 18.7 |
| PATHS CROSS | 1.8 | +109.0 | 0.0 | 14.4 | 2.3 | +171.2 | 0.0 | 60.8 |
| PERIAPT WORTH | 0.1 | +3.7 | 0.0 | 15.0 | 0.1 | +5.0 | 0.0 | 30.0 |
| PIVOT GUARDS FLANK | 0.0 | -1.0 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 6.9 |
| PLAN RESULT | 36.8 | +1650.2 | 1368.5 | 997.1 | 37.3 | +1169.7 | 1330.2 | 926.4 |
| PURSUES BIG PREY | 0.1 | -7.2 | 0.0 | 0.0 | 0.1 | -7.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +7.9 | 0.0 | 18.6 | 1.4 | +26.5 | 0.0 | 46.7 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.3 | 0.0 | 4.7 | 0.3 | -16.4 | 0.0 | 14.6 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.9 | 0.0 | 0.0 | 0.3 | -2.4 | 0.0 | 2.4 |
| REDIRECT COUNTER | 2.2 | +142.8 | 0.0 | 40.0 | 3.6 | +318.6 | 0.0 | 58.4 |
| REDIRECT WEIGHED | 0.2 | -1.3 | 3.1 | 0.0 | 0.4 | +10.5 | 10.1 | 5.7 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 11.9 | - | - | - | - |
| RESERVE FALL BACK | 0.5 | +11.3 | 0.0 | 2.0 | 0.8 | +47.7 | 0.0 | 9.2 |
| RESTRAINS TO SHOOT | 0.1 | +2.4 | 0.0 | 0.0 | 0.1 | +5.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +101.8 | 177.8 | 89.6 | 3.0 | +81.8 | 170.7 | 111.2 |
| SAFE SURE CHARGE | 0.0 | -0.8 | 1.2 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +44.3 | 0.0 | 12.4 | 0.7 | +44.6 | 0.0 | 27.5 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 1.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 1.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -8.8 | 0.0 | 0.0 | 0.2 | +2.0 | 0.0 | 1.7 |
| SEARCH SPOT | 2.5 | +113.7 | 0.0 | 43.3 | 2.6 | +151.0 | 0.0 | 54.7 |
| SELF MOVE SPELL | 0.2 | +23.0 | 0.0 | 18.1 | 0.2 | +14.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.2 | +89.0 | 4.8 | 38.0 | 1.3 | +159.8 | 18.5 | 23.6 |
| SET-UP ANY TARGET | 0.2 | +24.5 | 0.0 | 0.0 | 0.0 | +7.8 | 13.1 | 13.1 |
| SET-UP MISSED | 0.0 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.1 | -0.3 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | 1.5 | +49.6 | 66.8 | 48.8 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 1.9 | +32.6 | 0.0 | 17.2 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.5 | +79.6 | 104.7 | 21.0 | 0.8 | +20.9 | 23.3 | 1.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 15.8 | +0.0 | 772.2 | 294.3 | 10.0 | +0.0 | 313.7 | 165.1 |
| SHOT REPLANNED | - | - | - | - | 0.2 | +0.0 | 15.5 | 3.8 |
| SHOTS IN THE MOVE | 16.1 | +718.3 | 0.0 | 293.6 | 8.6 | +218.2 | 0.0 | 121.1 |
| SPELL SETS UP CHARGE | 0.4 | +166.2 | 0.0 | 0.0 | 0.1 | +38.9 | 13.1 | 13.1 |
| SPELL WORTH | 1.3 | +25.0 | 40.6 | 39.0 | 1.3 | +36.4 | 136.9 | 140.4 |
| SPELLS IN THE FIGHT | 0.3 | +0.3 | 68.6 | 16.7 | - | - | - | - |
| STABLE ROLE | 11.1 | +0.0 | 429.1 | 207.4 | 10.1 | +0.0 | 396.7 | 226.4 |
| STANDS TO CAST | 0.1 | +2.0 | 0.0 | 0.0 | 0.1 | +5.4 | 0.0 | 4.4 |
| STAY WEIGHED | 0.0 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 17.7 | +88.9 | 655.3 | 251.8 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +1.9 | 0.0 | 4.5 |
| STOPS SHORT OF THE FLANK | 0.5 | +19.0 | 0.0 | 12.9 | 0.5 | +29.8 | 0.0 | 5.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 10.6 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 4.8 | -33.5 | 232.2 | 122.5 | 7.5 | -49.0 | 390.7 | 164.9 |
| SUPPORTS | 2.9 | +34.4 | 122.2 | 32.7 | 4.7 | +50.7 | 224.8 | 93.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.8 | 8.4 | 0.0 | 0.1 | -3.8 | 11.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | -15.8 | 47.1 | 25.1 | 0.5 | +4.9 | 11.8 | 19.6 |
| THROUGH LINE OF FIRE | 0.5 | +15.6 | 0.0 | 0.0 | 0.2 | +8.6 | 0.0 | 3.5 |
| TURN WORTH | 0.2 | -20.1 | 8.3 | 13.3 | 0.4 | -21.6 | 28.1 | 8.0 |
| TWO OR MORE ARRIVE | 0.3 | +1.3 | 2.2 | 12.9 | 0.4 | +3.8 | 0.0 | 11.6 |
| WAIT AFTER COSTS | 6.3 | -336.6 | 370.0 | 148.0 | 8.5 | -425.8 | 299.9 | 213.2 |
| WALKS TO THE FIGHT | 1.3 | +33.7 | 79.2 | 6.8 | 1.1 | +29.6 | 19.8 | 23.4 |
| WAR ENGINE CHARGES | 0.0 | +4.7 | 0.0 | 8.6 | 0.0 | +1.8 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 20.4 | 1.8 | 0.4 | +0.0 | 7.5 | 9.2 |
| WEARS DOWN | 1.0 | +52.2 | 78.4 | 45.7 | 1.6 | +53.9 | 129.5 | 62.3 |
| WHO HITS BACK | 0.3 | +40.2 | 0.0 | 29.8 | 0.4 | +27.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +15.0 | 16.3 | 0.0 | 0.5 | +21.9 | 81.8 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +18.4 | 19.6 | 1.2 | 0.6 | +56.6 | 69.6 | 11.4 |
| WIDER SPREAD | 2.4 | -10.4 | 184.5 | 79.1 | - | - | - | - |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 5.9 | 0.0 | - | - | - | - |

### Rule changes: ch-h2h-mine-ea652ef-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1125 | 1125 | 1125 | 31.25 | -61571 | -54.7 |
| BEST FIRST | 287 | 287 | 287 | 7.97 | +12596 | +43.9 |
| FIRE PLAN | 616 | 616 | 199 | 5.53 | +2229 | +11.2 |
| SEARCH SPOT | 183 | 183 | 182 | 5.06 | +9538 | +52.4 |
| MOVE TO CHARGE | 286 | 286 | 170 | 4.72 | +8507 | +50.0 |
| COUNTER-CHARGE COVER | 601 | 314 | 159 | 4.42 | +10049 | +63.2 |
| PATHS CROSS | 148 | 148 | 148 | 4.11 | +10087 | +68.2 |
| KILLS COUNT NEXT TURN | 379 | 379 | 105 | 2.92 | +3797 | +36.2 |
| SHOTS IN THE MOVE | 890 | 570 | 94 | 2.61 | +2647 | +28.2 |
| SUPPORTS | 273 | 273 | 94 | 2.61 | +693 | +7.4 |
| FOLLOW UP WEIGHED | 84 | 84 | 84 | 2.33 | +11943 | +142.2 |
| EVERY WOUND COUNTS | 376 | 376 | 82 | 2.28 | +0 | +0.0 |
| FALLBACK BY WORTH | 376 | 376 | 79 | 2.19 | +3841 | +48.6 |
| FACES THE THREAT | 78 | 78 | 78 | 2.17 | +7452 | +95.5 |
| WAIT AFTER COSTS | 531 | 531 | 62 | 1.72 | +1211 | +19.5 |
| SAFER THAN THE JOB | 56 | 56 | 56 | 1.56 | +3203 | +57.2 |
| RANDOM MOVE BY FIGURES | 80 | 80 | 55 | 1.53 | +1238 | +22.5 |
| WALKS TO THE FIGHT | 84 | 84 | 55 | 1.53 | +911 | +16.6 |
| ONE YARDSTICK | 673 | 257 | 54 | 1.50 | +795 | +14.7 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| REDIRECT COUNTER | 209 | 121 | 48 | 1.33 | +3213 | +66.9 |
| RISK BY ARC | 196 | 190 | 47 | 1.31 | +1810 | +38.5 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.22 | +2124 | +48.3 |
| SET UP TOGETHER | 90 | 78 | 44 | 1.22 | +3906 | +88.8 |
| CHARGE NOW WEIGHED | 42 | 42 | 42 | 1.17 | +2508 | +59.7 |
| BEST MOVE FOR SHOOTERS | 39 | 39 | 39 | 1.08 | +3864 | +99.1 |
| STOPS SHORT OF THE FLANK | 38 | 38 | 38 | 1.06 | +1760 | +46.3 |
| BEST OVERALL | 37 | 37 | 37 | 1.03 | +2486 | +67.2 |
| BEST FACING | 36 | 36 | 36 | 1.00 | +1524 | +42.3 |
| MAX FOR POSITIONING | 331 | 176 | 36 | 1.00 | +418 | +11.6 |
| CHARGE NOW FIRST | 198 | 198 | 35 | 0.97 | -3357 | -95.9 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MISSILES IN THE MOVE | 293 | 164 | 32 | 0.89 | +833 | +26.0 |
| SHOOTS FROM THE BEST SPOT | 81 | 81 | 32 | 0.89 | +826 | +25.8 |
| FIRE IN ORDER | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| KILLS COUNT | 132 | 131 | 31 | 0.86 | +1566 | +50.5 |
| CAST JOB | 47 | 47 | 26 | 0.72 | +550 | +21.1 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| INVITES THE FIGHT | 111 | 111 | 26 | 0.72 | +489 | +18.8 |
| KEEPS ITS TARGET | 132 | 132 | 26 | 0.72 | +358 | +13.8 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| KEEPS THE TARGET | 61 | 61 | 25 | 0.69 | -2154 | -86.1 |
| MARCH CHECK | 26 | 26 | 25 | 0.69 | +1701 | +68.0 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +1783 | +74.3 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +871 | +36.3 |
| WHO HITS BACK | 24 | 24 | 24 | 0.67 | +1721 | +71.7 |
| MAKE SURE TOGETHER | 48 | 46 | 23 | 0.64 | +2250 | +97.8 |
| STAY WORTH | 638 | 512 | 23 | 0.64 | +323 | +14.0 |
| CASTING BLOCK | 27 | 27 | 22 | 0.61 | +1032 | +46.9 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +864 | +39.3 |
| BEST PREY | 54 | 54 | 21 | 0.58 | +388 | +18.5 |
| MANOEUVRE | 19 | 19 | 19 | 0.53 | +830 | +43.7 |
| MARCH ODDS | 18 | 18 | 18 | 0.50 | +188 | +10.5 |
| WHOLE FIGHT GAIN | 32 | 28 | 17 | 0.47 | +671 | +39.5 |
| BLOCKED WHEEL | 16 | 16 | 16 | 0.44 | +258 | +16.1 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| HONEST THREAT | 376 | 376 | 13 | 0.36 | +0 | +0.0 |
| WEARS DOWN | 94 | 89 | 13 | 0.36 | +502 | +38.6 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +1133 | +94.4 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +3422 | +311.1 |
| WAR ENGINE JOBS | 33 | 33 | 11 | 0.31 | -744 | -67.6 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -50 | -5.0 |
| LOST CHARGE | 215 | 215 | 10 | 0.28 | +231 | +23.1 |
| BLOCKED CHARGE SKIPPED | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CANNON PLANNED TARGET | 50 | 50 | 9 | 0.25 | +11 | +1.2 |
| HONEST WORTH | 260 | 259 | 8 | 0.22 | +122 | +15.2 |
| HUNT IN PAIRS | 29 | 20 | 8 | 0.22 | +238 | +29.8 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +290 | +36.2 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 443 | 443 | 8 | 0.22 | -113 | -14.1 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -276 | -34.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| STANDS TO CAST | 7 | 7 | 7 | 0.19 | +39 | +5.6 |
| CHAFF PASSED | 6 | 6 | 6 | 0.17 | -13 | -2.2 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -527 | -87.8 |
| SHOT REPLANNED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -216 | -43.2 |
| MISSILES NEXT TURN | 328 | 187 | 5 | 0.14 | +13 | +2.6 |
| OPENS UP | 13 | 13 | 5 | 0.14 | +360 | +72.0 |
| SURE REACH TOGETHER | 54 | 38 | 5 | 0.14 | +48 | +9.5 |
| WHOLE FIGHT | 29 | 28 | 5 | 0.14 | +389 | +77.8 |
| EDGE GIVE GROUND | 11 | 11 | 4 | 0.11 | +166 | +41.5 |
| LONG SHOT | 38 | 36 | 4 | 0.11 | +24 | +6.1 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +52 | +12.9 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +315 | +78.7 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -79 | -19.8 |
| SHOOTERS ARE THREATS | 54 | 54 | 4 | 0.11 | +0 | +0.0 |
| SHOOTERS TO THE PRIMARY | 67 | 45 | 4 | 0.11 | +29 | +7.2 |
| BACKUP TARGETS | 67 | 26 | 3 | 0.08 | +9 | +3.1 |
| CHARGE BAND | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| DEFENSIVE FLOOR | 5 | 5 | 3 | 0.08 | +32 | +10.7 |
| FACE THE CAST | 3 | 3 | 3 | 0.08 | +98 | +32.5 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +25 | +8.4 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 3 | 0.08 | -146 | -48.6 |
| OVERRUNS AWAY | 35 | 32 | 3 | 0.08 | +33 | +11.1 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 3 | 0.08 | +69 | +22.9 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +62 | +30.9 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +37 | +18.7 |
| HUNT ADVANCE | 5 | 5 | 2 | 0.06 | +41 | +20.7 |
| JOINT CHARGE PLAN | 5 | 5 | 2 | 0.06 | +105 | +52.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| REFUSING RETIRES | 5 | 5 | 2 | 0.06 | -0 | -0.1 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.03 | -185 | -185.3 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -186 | -186.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +4 | +4.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +22 | +21.7 |
| MISSILES IN THE FIRE PLAN | 74 | 4 | 1 | 0.03 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 4 | 2 | 1 | 0.03 | +18 | +18.1 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +174 | +174.5 |
| REDIRECT BY WHAT IT STOPS | 15 | 15 | 1 | 0.03 | +34 | +33.5 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -29 | -29.1 |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 1 | 0.03 | +17 | +16.9 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +103 | +102.9 |
| TWO OR MORE ARRIVE | 25 | 24 | 1 | 0.03 | +10 | +9.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 8 | 8 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 23 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 14 | 12 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 9 | 9 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 392 | not checked | - | - | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| GIVES UP | 7 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 13 | 13 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 30 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 26 | 26 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT NEEDED | 30 | 30 | 0 | 0.00 | - | - |
| NOT TURNED | 377 | 377 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 2668 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 929 | 929 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 17 | not checked | - | - | - | - |
| SPELL WORTH | 95 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 12 | 11 | 0 | 0.00 | - | - |
| STABLE ROLE | 763 | 761 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| TURN WORTH | 23 | 23 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WIDER SPREAD | 85 | 83 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ch-h2h-mine-ea652ef-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.58 | 13.25 | 56.5 |
| FALLBACK | gate | 0.67 | 0.61 | 42.8 |
| CHARGE NOW FIRST | rule | 0.47 | 0.50 | 95.9 |
| TURN GATE | gate | 0.44 | 0.33 | 42.1 |
| FIRE PLAN | rule | 0.75 | - | 75.2 |
| KEEPS THE TARGET | rule | 0.64 | - | 95.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.22 | 84.8 |
| WAR ENGINE JOBS | rule | 0.19 | 0.08 | 74.4 |
| AFTERMATH BAND | gate | 0.11 | 0.14 | 2.5 |
| FIGHT ORDER BAND | gate | 0.14 | 0.11 | 2.3 |
| SUPPORT REQUEST | gate | 0.08 | 0.17 | 56.5 |
| SUPPORT NARROWED | rule | 0.19 | 0.03 | 14.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.11 | 34.5 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.11 | 32.6 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.06 | 14.0 |
| BLOCKED WHEEL | rule | 0.06 | 0.11 | 24.2 |
| PURSUES BIG PREY | rule | 0.08 | 0.08 | 87.8 |
| BEST PRIZE | rule | 0.03 | 0.11 | 43.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.03 | 24.8 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.08 | 19.8 |
| CHAFF PASSED | rule | - | 0.08 | 4.2 |
| LONE WIZARD HOLDS BACK | rule | - | 0.08 | 48.6 |
| MARCH ODDS | rule | - | 0.08 | 21.8 |
| PATHS CROSS | rule | - | 0.08 | 25.5 |
| RULE SWITCHED OFF | gate | - | 0.08 | 1.9 |
| STANDS TO CAST | rule | 0.06 | 0.03 | 12.8 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | - | 10.3 |
| WHO HITS BACK | rule | - | 0.08 | 3.4 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 1.6 |
| NO REASON | gate | 0.06 | - | 1.8 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 15.7 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 185.3 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 186.4 |
| FACES THE THREAT | rule | - | 0.03 | 21.8 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 3.4 |
| REDIRECT WEIGHED | rule | 0.03 | - | 30.5 |
| SAFE SURE CHARGE | rule | 0.03 | - | 29.1 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 21.3 |

### Plans: ch-h2h-mine-ea652ef-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.8 | 19% | 435 | 389 | 89% |
| Mine | charge | 3.0 | 61% | 306 | 293 | 96% |
| Mine | close in | 4.2 | 31% | 233 | 152 | 65% |
| Mine | hold | 5.3 | 40% | 330 | 0 | 0% |
| Mine | join | 0.5 | 100% | 19 | 0 | 0% |
| Mine | shoot | 9.9 | 62% | 497 | 817 | 164% |
| Mine | support | 3.1 | 92% | 26 | 0 | 0% |
| Opponent | advance | 12.3 | 17% | 364 | 374 | 103% |
| Opponent | charge | 4.6 | 52% | 465 | 436 | 94% |
| Opponent | close in | 6.1 | 25% | 460 | 175 | 38% |
| Opponent | hold | 4.1 | 36% | 251 | 0 | 0% |
| Opponent | join | 1.0 | 94% | 41 | 0 | 0% |
| Opponent | shoot | 4.2 | 50% | 96 | 188 | 196% |
| Opponent | support | 5.0 | 88% | 49 | 0 | 0% |

### Packages: hunt the guns, ch-h2h-mine-ea652ef-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 26 |
| Opponent | 0.2 | 7 | 2 | 20% | 40% | 0% | 3.0 | 349 | 111 | 20% | 97 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 103 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 98 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 200 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 202 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 104 | 0 | 0% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 0% | 4.0 | 516 | 144 | 0% | 0 |
| Warriors of Chaos | 0.4 | 3 | 2 | 0% | 100% | 0% | 2.0 | 277 | 266 | 100% | 50 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 41 |

### Battle groups: ch-h2h-mine-ea652ef-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.4 | 26% | 59% | 14% | 17% | 25% | 11% | 17% | 47% | 0% |
| Mine | REDIRECT COUNTER | 2.2 | 37% | 55% | 0% | - | 17% | 0% | 10% | 72% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.3 | 16% | 53% | 23% | 30% | 27% | 9% | 15% | 48% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 21% | 74% | 19% | 0% | 27% | 0% | 5% | 68% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ch-h2h-mine-ea652ef-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 27 (3) | 27 | 0 | 81 | 33% | 3.0 | 73 (1) | 0 (1) | 0 (1) | 49 (2) | 0 (1) |
| Mine | Chaff | 37 | 6 (37) | 4 | 3 | 45 | 41% | 2.3 | 13 (16) | 5 (9) | 0 (12) | 11 (24) | 0 (13) |
| Mine | Character | 123 | 52 (123) | 52 | 0 | 35 | 14% | 2.4 | 61 (37) | 57 (64) | 15 (10) | 66 (64) | 44 (47) |
| Mine | Clean-up | 26 | 62 (26) | 24 | 38 | 37 | 27% | 2.9 | 45 (10) | 95 (12) | 8 (4) | 86 (14) | 38 (12) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 13 | 0% | 1.8 | 0 (1) | 0 (2) | 0 (1) | 0 (4) | - |
| Mine | Fast Hammer | 39 | 34 (39) | 18 | 16 | 61 | 18% | 2.9 | 31 (17) | 41 (11) | 34 (11) | 43 (28) | 16 (11) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 2.0 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 57 | 32 (57) | 13 | 19 | 44 | 19% | 2.2 | 34 (10) | 35 (37) | 21 (10) | 39 (34) | 25 (23) |
| Mine | Holder | 25 | 80 (25) | 13 | 67 | 29 | 40% | 3.1 | 76 (7) | 85 (11) | 106 (5) | 96 (11) | 77 (12) |
| Mine | Shooter | 45 | 114 (45) | 41 | 73 | 45 | 0% | 1.8 | 22 (5) | 148 (33) | 50 (7) | 134 (24) | 93 (21) |
| Mine | Support | 5 | 77 (5) | 77 | 0 | 42 | 0% | 2.6 | 181 (1) | 116 (1) | - | 116 (1) | 181 (1) |
| Mine | War machine | 56 | 53 (56) | 53 | 0 | 41 | 5% | 1.3 | 54 (13) | 44 (37) | 108 (6) | 81 (11) | 46 (45) |
| Mine | Wizard | 23 | 21 (23) | 21 | 0 | 59 | 4% | 2.2 | 14 (6) | 55 (8) | 0 (3) | 60 (3) | 19 (14) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 65 (66) | 27 | 38 | 35 | 42% | 2.6 | 89 (28) | 38 (16) | 58 (22) | 85 (48) | 9 (18) |
| Opponent | Character | 114 | 44 (114) | 44 | 0 | 36 | 21% | 2.5 | 58 (41) | 43 (56) | 0 (5) | 53 (67) | 39 (35) |
| Opponent | Clean-up | 17 | 55 (17) | 42 | 13 | 35 | 35% | 3.4 | 16 (5) | 89 (9) | 42 (3) | 47 (9) | 63 (8) |
| Opponent | Early | 1 | 27 (1) | 27 | 0 | 0 | 0% | 6.0 | - | - | 27 (1) | 27 (1) | - |
| Opponent | Fast Hammer | 58 | 57 (58) | 44 | 14 | 43 | 22% | 2.7 | 56 (25) | 59 (19) | 58 (14) | 42 (42) | 97 (16) |
| Opponent | Fragile | 10 | 69 (10) | 69 | 0 | 63 | 40% | 1.7 | 259 (3) | 0 (3) | 0 (4) | 75 (9) | 0 (1) |
| Opponent | Hammer | 64 | 39 (64) | 26 | 13 | 51 | 20% | 2.6 | 37 (16) | 41 (41) | 16 (7) | 31 (39) | 52 (25) |
| Opponent | Holder | 40 | 58 (40) | 9 | 49 | 23 | 52% | 3.7 | 58 (12) | 88 (17) | 8 (10) | 47 (20) | 72 (19) |
| Opponent | Shooter | 30 | 67 (30) | 18 | 50 | 35 | 7% | 1.2 | 50 (7) | 75 (18) | 61 (5) | 56 (16) | 83 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Opponent | War machine | 13 | 63 (13) | 63 | 0 | 31 | 8% | 1.0 | 68 (5) | 51 (5) | 79 (3) | 95 (3) | 54 (10) |
| Opponent | Wizard | 22 | 27 (22) | 27 | 0 | 18 | 5% | 2.1 | 30 (13) | 0 (4) | 0 (3) | 33 (11) | 0 (9) |

### Charged fights: ch-h2h-mine-ea652ef-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 277 | 85 | 1.8 | 1.2 | 47 | 9 | +38 | 0 of 9 | 7 of 9 | +58 | +32 |
| Mine | Chaos Dwarfs | 3 | 68 | 879 | 3.7 | 1.1 | 240 | 10 | +230 | 6 of 11 | 7 of 11 | +210 | +232 |
| Mine | Dwarfen Mountain Holds | 4 | 417 | 80 | 1.2 | 1.0 | 64 | 47 | +17 | 2 of 5 | 4 of 5 | - | +17 |
| Mine | Empire of Man | 5 | 511 | 90 | 1.4 | 1.1 | 64 | 189 | -125 | 0 of 7 | 4 of 7 | +83 | -160 |
| Mine | Grand Cathay | 4 | 686 | 542 | 3.2 | 1.2 | 167 | 28 | +138 | 3 of 13 | 12 of 13 | +478 | +36 |
| Mine | High Elf Realms | 4 | 191 | 305 | 3.0 | 1.0 | 102 | 49 | +53 | 7 of 12 | 10 of 12 | - | +53 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 938 | 5.0 | 1.2 | 188 | 0 | +188 | 2 of 5 | 5 of 5 | +339 | +150 |
| Mine | Lizardmen | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 70 | -70 | 2 of 2 | 2 of 2 | - | -70 |
| Mine | Ogre Kingdoms | 1 | 70 | 132 | 3.0 | 1.0 | 44 | 0 | +44 | 0 of 3 | 3 of 3 | - | +44 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 520 | 6.0 | 1.3 | 87 | 110 | -24 | 3 of 6 | 4 of 6 | +15 | -43 |
| Mine | Skaven | 2 | 48 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 210 | 336 | 3.5 | 1.4 | 96 | 0 | +96 | 2 of 7 | 6 of 7 | +278 | +23 |
| Mine | Vampire Counts | 2 | 0 | 348 | 5.5 | 1.3 | 63 | 10 | +53 | 3 of 11 | 9 of 11 | +57 | +52 |
| Mine | Warriors of Chaos | 1 | 0 | 107 | 4.0 | 1.0 | 27 | 0 | +27 | 1 of 4 | 4 of 4 | - | +27 |
| **Mine** | all armies | 36 | 275 | 286 | 2.7 | 1.2 | 107 | 38 | +69 | 32 of 96 | 78 of 96 | +196 | +46 |
| Opponent | Beastmen Brayherds | 1 | 0 | 65 | 4.0 | 1.2 | 16 | 85 | -69 | 3 of 4 | 1 of 4 | +0 | -92 |
| Opponent | Dwarfen Mountain Holds | 1 | 310 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Opponent | Empire of Man | 1 | 255 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 235 | 186 | 2.0 | 1.0 | 93 | 0 | +93 | 2 of 2 | 1 of 2 | - | +93 |
| Opponent | High Elf Realms | 2 | 260 | 642 | 3.0 | 1.5 | 214 | 0 | +214 | 2 of 6 | 5 of 6 | +233 | +205 |
| Opponent | Lizardmen | 1 | 299 | 391 | 3.0 | 1.0 | 130 | 0 | +130 | 1 of 3 | 3 of 3 | - | +130 |
| Opponent | Ogre Kingdoms | 2 | 54 | 48 | 3.0 | 1.2 | 16 | 0 | +16 | 0 of 6 | 4 of 6 | +65 | +6 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 1033 | 5.0 | 1.0 | 207 | 27 | +180 | 4 of 10 | 5 of 10 | - | +180 |
| Opponent | Skaven | 2 | 0 | 184 | 1.0 | 1.0 | 184 | 270 | -86 | 2 of 2 | 1 of 2 | - | -86 |
| Opponent | Tomb Kings of Khemri | 4 | 134 | 1052 | 4.0 | 1.2 | 263 | 12 | +251 | 11 of 16 | 16 of 16 | +426 | +210 |
| Opponent | Vampire Counts | 6 | 22 | 746 | 4.5 | 1.2 | 166 | 7 | +159 | 10 of 27 | 16 of 26 | +78 | +172 |
| Opponent | Warriors of Chaos | 7 | 0 | 373 | 2.7 | 1.1 | 138 | 22 | +116 | 10 of 19 | 12 of 18 | +133 | +114 |
| Opponent | Wood Elf Realms | 6 | 88 | 237 | 3.5 | 1.4 | 68 | 17 | +51 | 7 of 21 | 14 of 21 | -22 | +74 |
| **Opponent** | all armies | 36 | 81 | 477 | 3.3 | 1.2 | 146 | 19 | +126 | 52 of 118 | 79 of 116 | +127 | +126 |

### Effective charges: ch-h2h-mine-ea652ef-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 1 (net +0) | 1 (net +185) | 0 | 3 (net -15) | 0 | 3 (net +67) | 1 | 0% (0 of 8) |
| Mine | Chaos Dwarfs | 11 | 3 (net +413) | 0 | 1 (net +890) | 1 (net +0) | 0 | 6 (net +66) | 0 | 9% (1 of 11) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 1 (net +41) | 0 | 3 (net +15) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 7 | 2 (net -330) | 0 | 1 (net -190) | 1 (net -281) | 1 (net +83) | 2 (net +88) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 13 | 1 (net +229) | 0 | 2 (net +56) | 9 (net +148) | 0 | 1 (net +123) | 0 | 15% (2 of 13) |
| Mine | High Elf Realms | 12 | 3 (net -196) | 0 | 2 (net +130) | 1 (net +0) | 1 (net +102) | 4 (net +172) | 1 | 18% (2 of 11) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +268) | 0 | 0 | 3 (net +110) | 0 | 1 (net +339) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +0) | 1 (net +66) | 0 | 0 | 1 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 1 (net +195) | 0 | 0 | 0 | 5 | 100% (1 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 2 (net +0) | 0 | 2 (net +278) | 1 (net +0) | 2 | 40% (2 of 5) |
| Mine | Vampire Counts | 11 | 3 (net +18) | 1 (net -68) | 1 (net +170) | 1 (net +0) | 1 (net +144) | 4 (net +71) | 0 | 9% (1 of 11) |
| Mine | Warriors of Chaos | 4 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 2 (net +54) | 0 | 0% (0 of 4) |
| Opponent | Beastmen Brayherds | 4 | 2 (net -42) | 0 | 1 (net -255) | 1 (net +65) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 2 | 1 (net +0) | 0 | 0 | 1 (net +186) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 6 | 1 (net +0) | 0 | 2 (net +82) | 2 (net +560) | 1 (net +0) | 0 | 0 | 33% (2 of 6) |
| Opponent | Lizardmen | 3 | 0 | 0 | 1 (net +125) | 0 | 0 | 2 (net +133) | 0 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 6 | 0 | 0 | 1 (net +30) | 0 | 1 (net +65) | 2 (net +0) | 2 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 10 | 1 (net +620) | 0 | 1 (net +512) | 0 | 0 | 1 (net +230) | 7 | 33% (1 of 3) |
| Opponent | Skaven | 2 | 0 | 1 (net -540) | 0 | 0 | 0 | 1 (net +369) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 16 | 2 (net +452) | 1 (net +0) | 2 (net +86) | 3 (net +134) | 0 | 6 (net +352) | 2 | 14% (2 of 14) |
| Opponent | Vampire Counts | 27 | 3 (net +39) | 0 | 5 (net +263) | 7 (net +88) | 2 (net +98) | 5 (net +380) | 5 | 23% (5 of 22) |
| Opponent | Warriors of Chaos | 19 | 2 (net +611) | 1 (net +143) | 1 (net +0) | 5 (net +3) | 1 (net +0) | 3 (net +223) | 6 | 8% (1 of 13) |
| Opponent | Wood Elf Realms | 21 | 4 (net +0) | 0 | 2 (net +42) | 3 (net +14) | 2 (net +13) | 6 (net +74) | 4 | 12% (2 of 17) |

### Charged fights, damage counted: ch-h2h-mine-ea652ef-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 215 | 217 | +36 | 157 | 117 | +40 | +18.7 |
| Mine | 50-54% | 2 | 60 | 150 | +58 | 122 | 37 | +84 | +140.2 |
| Mine | Effective (55-75%) | 13 | 281 | 227 | +111 | 197 | 36 | +161 | +57.2 |
| Mine | 76-89% | 23 | 294 | 206 | +63 | 124 | 43 | +81 | +27.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 236 | 177 | +87 | 121 | 36 | +85 | +36.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 514 | 122 | +177 | 177 | 57 | +120 | +23.4 |
| Mine | No odds | 11 | 351 | 167 | -11 | 74 | 83 | -9 | -2.6 |
| Mine | All fights | 96 | 277 | 192 | +69 | 135 | 57 | +78 | +28.3 |
| Opponent | Long shot (under 50%) | 16 | 212 | 312 | +174 | 223 | 55 | +168 | +79.2 |
| Opponent | 50-54% | 3 | 371 | 306 | -132 | 48 | 180 | -132 | -35.7 |
| Opponent | Effective (55-75%) | 17 | 172 | 173 | +127 | 161 | 33 | +128 | +74.4 |
| Opponent | 76-89% | 22 | 337 | 207 | +111 | 166 | 11 | +155 | +46.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 340 | 231 | +222 | 243 | 50 | +193 | +56.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 520 | 97 | +41 | 77 | 37 | +40 | +7.6 |
| Opponent | No odds | 26 | 168 | 172 | +62 | 102 | 36 | +66 | +39.0 |
| Opponent | All fights | 118 | 272 | 210 | +126 | 168 | 41 | +128 | +47.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ch-h2h-mine-ea652ef-p1 | move | 431 | 109 (25%) | 73 (17%) | 68 (16%) | 254 (59%) |
| ch-h2h-mine-ea652ef-p1 | objective | 372 | 55 (15%) | 36 (10%) | 60 (16%) | 257 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

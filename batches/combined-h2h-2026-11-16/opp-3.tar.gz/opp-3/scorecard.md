# Doctrine scorecard: ch-h2h-opp-ea652ef-p3

### Scorecard: ch-h2h-opp-ea652ef-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | 3 | 2 | 1 | 0 | 0 | 0 | 65 |
| L0126 | 6 | 1 | Opponent | no | 7 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 1 | - | 0 | 4 | 1 | 0 | 0 | 30 |
| L0210 | 6 | 1 | Opponent | no | 5 | 2 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 4 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 1 | 4 | 3 | 0 | 0 | 0 | 0 | 685 |
| L0327 | 3 | 1 | Opponent | no | 9 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 1 | 0 | 0 | 479 |
| L0429 | 3 | 1 | Mine | yes | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 8 | 2 | 1 | 0 | 1 | 0 | 0 | 375 |
| L0516 | 6 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | yes | - | 6 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 144 |
| L0620 | 2 | 1 | Mine | - | - | 4 | 5 | 0 | 0 | 0 | 0 | 801 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 558 |
| L0709 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 926 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | no | - | 3 | 5 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 1 | 0 | 1 | 0 | 0 | 317 |
| L1030 | 4 | 1 | Mine | no | 3 | 3 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 144 |
| L1216 | 4 | 1 | Mine | no | 8 | 2 | 5 | 0 | 0 | 0 | 0 | 498 |
| L1216 | 4 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 475 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 4 | 1 | 1 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 10 | 4 | 4 | 0 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 190 |
| L1422 | 6 | 1 | Mine | no | 6 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 2 | 4 | 3 | 1 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | yes | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 144 |
| L1731 | 3 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 1 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 4 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 7 | 2 | 5 | 2 | 0 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | no | - | 6 | 0 | 4 | 2 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | no | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 1 | 7 | 0 | 2 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 8 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 7 | 1 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | no | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 6 | 3 | 7 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | - | 0 | 0 | 1 | 0 | 0 | 127 |
| L2832 | 6 | 1 | Opponent | no | 3 | 1 | 3 | 3 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 2 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 28% | 3.0 | 2.9 | 3.0 | 0.9 | 0.3 | 0.0 | 0.0 | 274.1 |
| **Average** | | | Opponent | 19% | 3.0 | 2.3 | 2.4 | 1.7 | 0.4 | 0.0 | 0.0 | 149.8 |

### KPIs: ch-h2h-opp-ea652ef-p3

Rules off - Mine only: CHARGE BAND, HONEST WORTH, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (41 of 176) | 11% (19 of 175) | 17% (60 of 351) |
| Winner chose to follow up after the loser gave ground |  | 98% (61 of 62); on the table 98% | 93% (40 of 43); on the table 95% | 96% (101 of 105); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 88% (7 of 8); on the table 88% | 92% (12 of 13); on the table 92% | 90% (19 of 21); on the table 90% |
| Winner chose to pursue after the loser fled |  | 64% (16 of 25); on the table 80% | 82% (33 of 40); on the table 82% | 75% (49 of 65); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 88% (84 of 95); on the table 93% | 89% (85 of 96); on the table 90% | 88% (169 of 191); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 29% (99 of 342) | 36% (69 of 192) | 31% (168 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (99 of 210) | 48% (69 of 144) | 47% (168 of 354) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 24% (46 of 192) | 34% (47 of 138) | 28% (93 of 330) |
|     round 1 |  | 9% (3 of 32) | 35% (8 of 23) | 20% (11 of 55) |
|     rounds 2+ |  | 27% (43 of 160) | 34% (39 of 115) | 30% (82 of 275) |
|   other wizards | 50%+ | 35% (53 of 150) | 41% (22 of 54) | 37% (75 of 204) |
|     round 1 |  | 36% (9 of 25) | 33% (3 of 9) | 35% (12 of 34) |
|     rounds 2+ |  | 35% (44 of 125) | 42% (19 of 45) | 37% (63 of 170) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 72% (18 of 25) | 50% (33 of 66) | 56% (51 of 91) |
| Points that never fought | lower | 33% (22886 of 68801) | 35% (25286 of 71990) | 34% (48172 of 140791) |
|   infantry points that never fought | lower | 45% (6373 of 14174) | 48% (6846 of 14220) | 47% (13219 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (147 of 272) | 56% (160 of 285) | 55% (307 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 92% (23 of 25); 1.6 uses a game | 96% (23 of 24); 2.2 uses a game | 94% (46 of 49); 1.9 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.4 uses a game | 50% (3 of 6); 0.2 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 50% (7 of 14); 0.2 uses a game | 56% (19 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (29241 of 59391) | 49% (31463 of 64043) | 49% (60704 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.9 (14%) | 0.9 (26%) | 1.8 (18%) |
| MARCHED: its unit marched | 1.7 (26%) | 1.0 (28%) | 2.7 (27%) |
| CHARGED: its unit charged | 0.2 (2%) | 0.2 (5%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.7 (25%) | 0.4 (13%) | 2.1 (21%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 1.5 (22%) | 0.8 (23%) | 2.3 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (3%) | 0.4 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 0.9 | 2.1 | 4.7 | 0.9 | 1.5 |
| not cast | 3.8 | 1.7 | 4.1 | 10.2 | 2.4 | 19.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.8 (47%) | 0.4 (9%) | 1.8 (18%) | 0.3 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (27%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (12%) | 0.8 (18%) | 2.1 (21%) | 0.5 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.1 (3%) | 0.2 (6%) | 0.2 (2%) | 0.2 (7%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (2%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.8 (22%) | 0.3 (18%) | 1.2 (30%) | 2.3 (22%) | 0.7 (29%) | 3.0 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.0 (2%) | 0.1 (3%) | 0.4 (4%) | 0.0 (0%) | 0.7 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (5%) | 0.0 (0%) | 0.1 (1%) | 0.2 (11%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (54%) | 0.2 (12%) | 1.3 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.8 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.8 a game | 1.1 a game |
| stood (cast and not dispelled) | 68% (27 of 40) | 62% (13 of 21) | 66% (40 of 61) |
| the unit moved after it | 78% (21 of 27) | 77% (10 of 13) | 78% (31 of 40) |
| it charged on its next turn | 0% (0 of 27) | 15% (2 of 13) | 5% (2 of 40) |
| the enemy charged it first | 15% (4 of 27) | 15% (2 of 13) | 15% (6 of 40) |
| it fought by the end of its next turn | 0% (0 of 27) | 0% (0 of 13) | 0% (0 of 40) |
| it moved out of a charge the enemy had planned (not charged first) | 22% (6 of 27) | 15% (2 of 13) | 20% (8 of 40) |
| none of these (no charge, no fight, no charge escaped) | 63% (17 of 27) | 54% (7 of 13) | 60% (24 of 40) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (496 of 752) | 60% (377 of 628) | 63% (873 of 1380) |
|   cavalry | 74% (46 of 62) | 61% (77 of 126) | 65% (123 of 188) |
|   character | 54% (53 of 99) | 21% (25 of 119) | 36% (78 of 218) |
|   chariot | 49% (48 of 97) | 77% (24 of 31) | 56% (72 of 128) |
|   infantry | 56% (110 of 198) | 69% (184 of 266) | 63% (294 of 464) |
|   monster | 22% (5 of 23) | 33% (1 of 3) | 23% (6 of 26) |
|   war machine | 86% (234 of 273) | 80% (66 of 83) | 84% (300 of 356) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (34%) | 1.6 (23%) | 4.0 (28%) |
| CHARGED: it charged | 1.1 (16%) | 1.5 (21%) | 2.6 (18%) |
| FLEEING: it fled or was fleeing | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.6 (8%) | 0.6 (9%) | 1.2 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 0.8 (11%) | 0.8 (12%) | 1.6 (11%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.6 (9%) | 0.9 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (16%) | 1.3 (19%) | 2.5 (18%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (3%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (5%) | 0.2 (2%) | 0.5 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.1 | 1.3 | 79% | 6.4 pts | 32 pts |
| character | 2.5 | 0.6 | 81% | 5.0 pts | 13 pts |
| chariot | 2.0 | 1.1 | 69% | 17.5 pts | 35 pts |
| infantry | 12.2 | 3.9 | 75% | 7.4 pts | 90 pts |
| monster | 0.2 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 8.8 | 7.1 | 64% | 24.1 pts | 211 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 5.0 | 4.6 |
| Charges that made contact a game | 3.1 | 3.5 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.88 contact (25 units) | 0.53 declared, 0.35 contact (17 units) | 0.81 declared, 0.67 contact (42 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.50 contact (4 units) | 1.14 declared, 1.00 contact (7 units) | 1.09 declared, 0.82 contact (11 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.39 contact (225 units) | 0.61 declared, 0.42 contact (266 units) | 0.58 declared, 0.41 contact (491 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (42 of 77) | 53% (8 of 15) | 50% (5 of 10) | 54% (55 of 102) |
| Character in a unit | 80% (33 of 41) | 60% (9 of 15) | 71% (5 of 7) | 75% (47 of 63) |
| Character on its own | 81% (29 of 36) | 44% (18 of 41) | 28% (19 of 68) | 46% (66 of 145) |
| Chariot | 73% (8 of 11) | 58% (7 of 12) | - | 65% (15 of 23) |
| Infantry | 60% (42 of 70) | 48% (20 of 42) | 0% (0 of 5) | 53% (62 of 117) |
| Monster | 53% (18 of 34) | 57% (4 of 7) | - | 54% (22 of 41) |
| Monstrous | 70% (7 of 10) | 45% (5 of 11) | - | 57% (12 of 21) |
| War Machines | 63% (27 of 43) | 50% (1 of 2) | - | 62% (28 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 88% (7 of 8); on the table 88% | 35% (34 of 96) | 25% | 55% (12 of 22) | 83% (5 of 6); 3.2 uses a game | 50% (1 of 2); 0.5 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 82% (14 of 17); on the table 94% | 33% (12 of 36) | 28% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (4 of 4); on the table 100% | - | 64% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 92% (11 of 12); on the table 92% | 50% (15 of 30) | 56% | 59% (35 of 59) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 76% (16 of 21); on the table 86% | 31% (60 of 192) | 42% | 45% (33 of 74) | 94% (17 of 18); 6.0 uses a game | 25% (1 of 4); 0.4 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 100% (16 of 16); on the table 100% | 24% (10 of 42) | 32% | 61% (33 of 54) | 100% (9 of 9); 3.1 uses a game | 58% (7 of 12); 1.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 86% (6 of 7); on the table 86% | - | 40% | 39% (7 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 8% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 6% | 43% (3 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (6 of 6); on the table 100% | 17% (2 of 12) | 3% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 88% (7 of 8); on the table 88% | 25% (3 of 12) | 59% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 89% (16 of 18); on the table 89% | 17% (1 of 6) | 28% | 46% (12 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 95% (20 of 21); on the table 95% | 28% (15 of 54) | 24% | 46% (21 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 81% (29 of 36); on the table 83% | 27% (8 of 30) | 29% | 54% (52 of 96) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (13 of 13); on the table 100% | 33% (4 of 12) | 39% | 69% (43 of 62) | 91% (10 of 11); 6.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ch-h2h-opp-ea652ef-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (31) | 48% (35) | 44% (66) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.58 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.14 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.25 | 0.61 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.97 | 0.92 | 2.89 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.97 | 0.69 | 1.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.56 | 5.17 | 10.72 |

### Quality by phase: ch-h2h-opp-ea652ef-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 47% (66 of 140) | 49% (68 of 138) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (169 of 371) | 37% (81 of 219) |
| Strategy | Close-in objectives charged next turn | 15% (24 of 156) | 18% (37 of 211) |
| Strategy | Support requests answered (helper made contact too) | 33% (5 of 15) | 54% (13 of 24) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 67% (2 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 54% (7 of 13) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 50% (21 of 42) | 45% (23 of 51) |
| Strategy | Lone characters that fought | 77% (72 of 93) | 80% (66 of 83) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 0.9 | 1.7 |
| Movement | Points that never moved of their own | 274.1 | 149.8 |
| Movement | Fights charged into per game | 2.9 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 97, net -16 | 20 of 88, net +15 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 97, net +173 | 10 of 88, net +167 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 97, net +73 | 6 of 88, net +71 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 97, net +71 | 25 of 88, net +170 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 9.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (118 of 284) | 41% (147 of 358) |
| Shooting | Points destroyed by shooting units | 27.3 | 30.8 |
| Shooting | War machine shots | 6.5 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (107 of 234) | 35% (29 of 82) |
| Shooting | Points destroyed by war machines | 71.5 | 25.8 |
| Magic | Magic missiles cast | 1.8 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (22 of 65) | 38% (18 of 47) |
| Magic | Wounds caused by magic missiles | 2.9 | 2.8 |
| Magic | Wounds caused by other spells | 2.2 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 75.2 | 69.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.4 / 0.6 / 0.1 | 2.1 / 0.2 / 0.2 / 0.3 |
| Combat | Points destroyed in combat | 300.7 | 335.6 |
| Combat | Points run down | 94.3 | 202.6 |
| Combat | Net points per charged fight, damage counted | +79 | +117 |
| Combat | Net per 100 charger points, damage counted | +26.9 | +39.0 |
| Combat | First round won (charged fights) | 76% | 75% |
| Combat | Net points per charged fight | +69 | +106 |
| Combat | Net points per supported fight / lone fight | +160 / +59 | +180 / +91 |
| Combat | Charged fights on a top-3 enemy unit | 34 of 105 | 45 of 103 |
| Game | Points lost | 829.7 | 640.6 |
| Game | VP from objectives | 478.6 | 601.7 |
| Game | Lone holders (player turns) | 3.0 | 3.0 |

- Mine won / drew / lost: 11 / 7 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -331 VP
- The side that went first won 16 of 29 games with a winner
- Points traded per game (both sides' losses): 1470
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ch-h2h-opp-ea652ef-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 2.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 31.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +6.1 | 0.0 | 35.1 | 0.8 | +6.4 | 0.0 | 43.0 |
| BEST FACING | 0.8 | +18.6 | 0.0 | 14.3 | 0.4 | +12.6 | 0.0 | 20.4 |
| BEST FIRST | 4.2 | +185.1 | 139.4 | 106.8 | 3.6 | +148.0 | 109.2 | 51.1 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.8 | +58.0 | 0.0 | 8.7 |
| BEST OVERALL | 0.6 | +39.8 | 0.0 | 12.2 | 0.5 | +39.9 | 0.0 | 18.1 |
| BEST PREY | 0.7 | +35.1 | 11.1 | 20.2 | 0.9 | +36.5 | 18.1 | 12.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.2 | 4.9 | 14.7 |
| BIG CHARACTER SAFETY | 0.1 | -1.1 | 0.0 | 0.0 | 0.2 | -1.3 | 0.0 | 15.0 |
| BLOCKED CHARGE HANDED OVER | - | - | - | - | 0.0 | +1.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 16.1 | 0.0 | 0.1 | +0.0 | 5.4 | 9.1 |
| BLOCKED WHEEL | 0.2 | +3.4 | 0.0 | 0.0 | 0.4 | +15.3 | 0.0 | 7.9 |
| BLOWS WHERE AIMED | - | - | - | - | 0.4 | -63.2 | 86.4 | 0.0 |
| BOMBING RUN | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.2 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 85.1 | 27.1 | - | - | - | - |
| CANNON PLANNED TARGET | 5.9 | +180.5 | 409.9 | 122.6 | - | - | - | - |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -2.7 | 16.6 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -7.1 | 27.8 | 9.2 | 0.2 | -0.3 | 56.4 | 8.8 |
| CAST JOB | 0.6 | +16.3 | 22.9 | 2.4 | 0.8 | +19.3 | 51.3 | 20.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +26.6 | 26.0 | 8.9 | 0.1 | -0.2 | 0.0 | 3.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 29.6 | 0.6 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.8 | 5.4 | 15.8 | - | - | - | - |
| CHARGE BAND | - | - | - | - | 0.2 | +0.0 | 34.8 | 0.0 |
| CHARGE NOW FIRST | 2.5 | +0.0 | 255.3 | 79.7 | 2.0 | +0.0 | 282.5 | 58.5 |
| CHARGE NOW WEIGHED | 0.2 | -17.6 | 6.8 | 21.9 | 0.6 | -61.5 | 32.5 | 12.4 |
| CHARGER SLAIN LOST | - | - | - | - | 0.5 | -9.5 | 46.2 | 25.8 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 27.2 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.6 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 8.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 28.4 | 12.9 | 0.3 | +0.0 | 0.0 | 34.0 |
| CONVEYANCE SEARCH | 0.8 | +75.2 | 19.5 | 23.1 | 0.5 | +52.5 | 11.1 | 17.6 |
| COUNTER-CHARGE COVER | 8.1 | +605.3 | 0.0 | 184.3 | 6.9 | +643.7 | 0.0 | 141.1 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 1.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +2.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +20.4 | 30.2 | 4.5 | 0.3 | +4.3 | 22.4 | 3.2 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | - | - | - | - | 6.8 | +0.0 | 255.6 | 95.9 |
| FACE THE CAST | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| FACES THE THREAT | 2.0 | +155.1 | 0.0 | 88.5 | 0.9 | +64.9 | 0.0 | 34.7 |
| FALLBACK BY WORTH | 4.6 | +38.5 | 0.0 | 125.5 | 5.9 | +59.1 | 0.0 | 69.7 |
| FIGHT LIFT | 0.1 | +0.6 | 3.9 | 0.0 | 0.0 | +1.4 | 5.9 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 0.0 | 2.2 | - | - | - | - |
| FIRE IN ORDER | - | - | - | - | 0.4 | +0.0 | 32.9 | 8.8 |
| FIRE PLAN | - | - | - | - | 10.9 | +48.7 | 442.5 | 150.6 |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 165.2 | 4.8 | +0.0 | 0.0 | 115.6 |
| FOLLOW UP WEIGHED | 1.4 | +216.9 | 0.0 | 41.5 | 0.7 | +106.1 | 0.0 | 40.3 |
| FRIENDS SHOTS CHECKED | 0.2 | +10.0 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.4 | 11.1 | 0.0 | 0.1 | -0.7 | 20.4 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 4.6 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 60.4 | 4.9 | 0.3 | +0.0 | 42.6 | 10.5 |
| HILL BY ITS CHANCE | 0.2 | -15.7 | 0.0 | 0.0 | 0.4 | -42.7 | 0.0 | 3.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 6.8 | +869.3 | 255.6 | 95.9 |
| HONEST WORTH | - | - | - | - | 7.9 | -180.6 | 604.3 | 192.4 |
| HORN WORTH | - | - | - | - | 0.1 | +0.6 | 0.0 | 14.0 |
| HUNT ADVANCE | 0.2 | +11.0 | 4.6 | 7.6 | 0.1 | +2.9 | 0.0 | 2.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.4 | 0.0 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.2 | +12.6 | 0.0 | 5.4 | 0.6 | +35.8 | 0.0 | 10.4 |
| HUNT KEPT | 0.2 | +6.5 | 4.6 | 7.6 | 0.0 | +1.5 | 0.0 | 2.9 |
| HUNT RESULT | 0.1 | +15.0 | 19.6 | 1.4 | 0.1 | +7.1 | 15.5 | 5.7 |
| HUNT THE GUNS | 0.1 | +60.2 | 15.0 | 1.4 | 0.1 | +39.7 | 15.5 | 2.8 |
| INVITES THE FIGHT | 1.4 | +34.6 | 64.4 | 23.2 | 1.0 | +18.4 | 62.3 | 13.3 |
| JOINT CHARGE PLAN | 0.2 | +17.7 | 0.0 | 3.2 | 0.4 | +13.3 | 47.8 | 9.7 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -2.1 | 14.1 | 3.2 |
| KEEP FALLS | 0.2 | +3.0 | 0.0 | 13.6 | 0.1 | +0.6 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 2.0 |
| KEEPS ITS TARGET | 1.6 | +47.5 | 145.4 | 38.9 | 1.9 | +56.7 | 204.3 | 48.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | - | - | - | - | 0.9 | -18.7 | 61.4 | 14.6 |
| KILLS COUNT | 1.6 | +75.1 | 161.0 | 24.4 | 1.6 | +82.2 | 161.1 | 23.8 |
| KILLS COUNT NEXT TURN | 6.0 | +236.2 | 225.2 | 143.8 | 7.6 | +232.0 | 314.8 | 162.6 |
| LONE CHARACTER SAFE SPOT | 0.4 | +17.1 | 7.9 | 12.3 | 0.3 | +4.9 | 17.1 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 7.2 | 5.4 | 0.2 | +0.0 | 8.4 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -4.4 | 25.2 | 7.2 | 0.2 | -0.6 | 22.8 | 0.0 |
| LOST CHARGE | 2.8 | -46.9 | 116.4 | 106.4 | 2.2 | -28.8 | 84.3 | 53.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -2.2 | 0.0 | 1.5 |
| MAKE SURE TOGETHER | 0.8 | +85.5 | 24.0 | 35.5 | 0.9 | +61.4 | 97.8 | 25.0 |
| MANOEUVRE | 0.3 | +4.3 | 0.0 | 0.0 | 0.1 | +10.8 | 0.0 | 7.2 |
| MARCH AT ESCAPER | 0.1 | +1.3 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +32.1 | 0.0 | 7.2 | 0.3 | +25.0 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +8.2 | 4.6 | 0.0 | 0.3 | +12.7 | 9.9 | 0.0 |
| MARCH OVER CASTS | 0.6 | +69.9 | 0.0 | 12.3 | 0.4 | +19.3 | 0.0 | 29.4 |
| MAX FOR POSITIONING | 4.4 | +149.7 | 0.0 | 94.6 | 3.7 | +147.7 | 0.0 | 67.6 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 1.1 | +7.3 | 91.8 | 0.0 |
| MISSILES IN THE MOVE | 3.6 | +121.5 | 0.0 | 88.0 | 4.2 | +75.4 | 0.0 | 100.9 |
| MISSILES NEXT TURN | 5.0 | +87.2 | 0.0 | 104.5 | 5.0 | +51.8 | 0.0 | 142.2 |
| MODEL FACING | 0.1 | +39.5 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 17.6 | 10.2 | 0.3 | +0.0 | 8.9 | 0.0 |
| MOVE AND CAST | 0.4 | +21.7 | 0.0 | 12.2 | 0.6 | +43.3 | 0.0 | 10.2 |
| MOVE SPELL IN RANGE | 0.2 | +7.9 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -7.4 | 0.0 | 40.8 | 0.1 | -1.1 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 6.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.4 | +259.5 | 130.4 | 104.1 | 4.5 | +324.8 | 246.4 | 164.7 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +13.5 | 0.0 | 0.0 | 0.0 | +6.6 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -14.4 | 34.3 | 0.0 | 0.2 | -10.8 | 17.3 | 3.9 |
| NOT TURNED | 5.6 | +71.1 | 0.0 | 144.3 | 5.2 | +60.6 | 0.0 | 109.5 |
| NOT WORTH A CAST | 0.6 | -0.3 | 0.0 | 31.0 | 0.9 | -0.9 | 0.0 | 16.6 |
| OFF BEST | 14.8 | -743.0 | 3.0 | 393.9 | 14.1 | -837.4 | 24.1 | 250.1 |
| ONE YARDSTICK | - | - | - | - | 12.6 | -317.8 | 366.9 | 147.7 |
| OPENS A LANE | 0.1 | +0.3 | 4.6 | 0.0 | 0.1 | +0.7 | 3.6 | 14.8 |
| OPENS UP | 0.2 | +29.5 | 8.8 | 6.0 | 0.1 | +8.9 | 8.6 | 0.0 |
| OVERRUNS AWAY | 0.2 | +2.2 | 23.6 | 13.8 | 0.3 | +2.2 | 56.4 | 2.8 |
| PATHS CROSS | 1.9 | +141.0 | 0.0 | 46.4 | 2.3 | +157.9 | 0.0 | 32.6 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.9 | 0.0 | 11.7 | 0.0 | -0.2 | 0.0 | 2.9 |
| PLAN RESULT | 36.1 | +1475.2 | 1400.9 | 1037.9 | 37.4 | +1390.7 | 1693.8 | 906.2 |
| PURSUES BIG PREY | 0.1 | -2.8 | 0.0 | 0.0 | 0.0 | -3.5 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +1.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 0.0 | 0.0 | +1.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +13.5 | 0.0 | 21.1 | 1.8 | +24.8 | 0.0 | 42.5 |
| RANDOM MOVER NO PROMISE | 0.4 | -31.4 | 0.0 | 4.7 | 0.7 | -35.3 | 19.2 | 9.4 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -4.9 | 0.0 | 4.3 | 0.6 | -17.0 | 0.0 | 9.2 |
| REDIRECT COUNTER | 2.2 | +122.6 | 0.0 | 52.3 | 3.3 | +262.9 | 0.0 | 61.8 |
| REDIRECT WEIGHED | 0.3 | +7.4 | 8.7 | 1.5 | 0.4 | -0.6 | 3.8 | 19.0 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +9.9 | 0.0 | 6.9 | 1.1 | +34.2 | 0.0 | 10.2 |
| RESTRAINS TO SHOOT | 0.0 | +1.3 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +69.4 | 229.6 | 87.8 | 2.3 | +54.4 | 242.6 | 60.5 |
| SAFER THAN THE JOB | 1.0 | +65.6 | 0.0 | 16.4 | 0.7 | +33.5 | 0.0 | 20.9 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -5.3 | 0.0 | 0.0 | 0.3 | -15.6 | 0.0 | 1.8 |
| SEARCH SPOT | 2.3 | +130.5 | 0.0 | 58.8 | 2.4 | +108.2 | 0.0 | 44.6 |
| SECOND HUNTER | 0.0 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.3 | +53.0 | 0.0 | 18.1 | 0.3 | +66.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.2 | +133.0 | 24.0 | 38.8 | 2.3 | +163.0 | 128.9 | 59.4 |
| SET-UP ANY TARGET | 0.4 | +81.0 | 19.5 | 13.2 | 0.2 | +24.6 | 11.1 | 17.6 |
| SET-UP MISSED | 0.1 | +7.2 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 2.2 | +106.5 | 36.0 | 42.6 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 1.8 | +36.2 | 0.0 | 16.6 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +48.9 | 55.2 | 17.8 | 0.9 | +47.0 | 33.9 | 20.2 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OPTIONS | 14.5 | +0.0 | 602.3 | 332.4 | 10.9 | +0.0 | 382.0 | 161.5 |
| SHOT REPLANNED | 0.4 | +0.0 | 91.4 | 3.5 | - | - | - | - |
| SHOTS IN THE MOVE | 13.4 | +538.4 | 0.0 | 285.9 | 10.1 | +337.6 | 0.0 | 118.7 |
| SPELL CATCH ODDS | 0.1 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +115.6 | 19.5 | 13.2 | 0.2 | +24.6 | 11.1 | 17.6 |
| SPELL WORTH | 1.4 | +19.2 | 34.7 | 43.7 | 2.2 | +29.4 | 76.2 | 76.8 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.4 | -6.0 | 53.6 | 25.4 |
| STABLE ROLE | 9.7 | +0.0 | 368.2 | 185.3 | 8.8 | +0.0 | 448.9 | 144.2 |
| STANDS TO CAST | 0.0 | +4.4 | 2.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +0.3 | 0.0 | 1.5 | 0.1 | +6.7 | 0.0 | 0.0 |
| STAY WORTH | - | - | - | - | 10.4 | +67.9 | 197.9 | 147.4 |
| STOPS | 0.1 | +2.8 | 15.0 | 0.0 | 0.1 | +3.2 | 15.5 | 2.8 |
| STOPS SHORT OF THE FLANK | 0.5 | +21.6 | 0.0 | 21.2 | 0.5 | +26.2 | 0.0 | 15.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.1 | -41.8 | 358.0 | 107.7 | 6.4 | -46.6 | 435.9 | 109.0 |
| SUPPORTS | 3.3 | +48.7 | 179.1 | 37.9 | 4.4 | +48.0 | 251.2 | 47.6 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -4.8 | 7.5 | 0.0 | 0.1 | -2.5 | 1.8 | 11.3 |
| SURE REACH TOGETHER | 0.3 | -6.6 | 18.3 | 16.3 | 0.9 | -7.2 | 48.5 | 8.7 |
| THROUGH LINE OF FIRE | 0.3 | +5.7 | 0.0 | 12.9 | 0.3 | +12.2 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -42.5 | 47.6 | 14.8 | 0.3 | -13.4 | 18.8 | 3.3 |
| TWO OR MORE ARRIVE | 0.3 | +2.3 | 0.0 | 4.5 | 0.7 | +5.2 | 18.8 | 33.9 |
| WAIT AFTER COSTS | 6.8 | -301.6 | 241.4 | 169.6 | 6.9 | -350.6 | 348.7 | 186.5 |
| WALKS TO THE FIGHT | 1.8 | +37.2 | 35.4 | 27.6 | 0.8 | +8.7 | 23.6 | 4.2 |
| WAR ENGINE CHARGES | 0.1 | +7.3 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 33.9 | 14.2 | 0.3 | +0.0 | 11.7 | 0.0 |
| WEARS DOWN | 1.1 | +61.8 | 93.2 | 54.1 | 1.1 | +53.4 | 164.6 | 50.0 |
| WHO HITS BACK | 0.1 | +23.9 | 0.0 | 12.1 | 0.1 | +11.9 | 0.0 | 4.2 |
| WHOLE FIGHT | 0.4 | -0.3 | 54.6 | 6.5 | 0.4 | +20.0 | 72.9 | 6.8 |
| WHOLE FIGHT GAIN | 0.2 | +23.3 | 27.0 | 2.3 | 0.6 | +50.6 | 31.0 | 3.2 |
| WIDER SPREAD | - | - | - | - | 2.9 | -10.9 | 362.5 | 24.4 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: ch-h2h-opp-ea652ef-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1041 | 1041 | 1041 | 28.92 | -56895 | -54.7 |
| BEST FIRST | 280 | 280 | 280 | 7.78 | +11991 | +42.8 |
| SEARCH SPOT | 170 | 170 | 169 | 4.69 | +8595 | +50.9 |
| PATHS CROSS | 153 | 153 | 153 | 4.25 | +10760 | +70.3 |
| MOVE TO CHARGE | 282 | 281 | 138 | 3.83 | +8179 | +59.3 |
| KILLS COUNT NEXT TURN | 488 | 488 | 135 | 3.75 | +3480 | +25.8 |
| COUNTER-CHARGE COVER | 541 | 303 | 130 | 3.61 | +8513 | +65.5 |
| FACES THE THREAT | 104 | 104 | 104 | 2.89 | +7920 | +76.2 |
| FIRE PLAN | 392 | 392 | 98 | 2.72 | +1003 | +10.2 |
| SHOTS IN THE MOVE | 847 | 594 | 86 | 2.39 | +2516 | +29.3 |
| SUPPORTS | 278 | 278 | 85 | 2.36 | +908 | +10.7 |
| FALLBACK BY WORTH | 378 | 378 | 78 | 2.17 | +3513 | +45.0 |
| FOLLOW UP WEIGHED | 76 | 76 | 76 | 2.11 | +11628 | +153.0 |
| ARTILLERY RE-ROLL WEIGHED | 72 | 72 | 72 | 2.00 | +0 | +0.0 |
| EVERY WOUND COUNTS | 243 | 243 | 61 | 1.69 | +0 | +0.0 |
| SAFER THAN THE JOB | 60 | 60 | 60 | 1.67 | +3568 | +59.5 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| SET UP TOGETHER | 126 | 106 | 56 | 1.56 | +2976 | +53.1 |
| WAIT AFTER COSTS | 490 | 489 | 56 | 1.56 | +1070 | +19.1 |
| RESERVE FALL BACK | 55 | 55 | 55 | 1.53 | +1588 | +28.9 |
| RANDOM MOVE BY FIGURES | 91 | 91 | 51 | 1.42 | +1376 | +27.0 |
| REDIRECT COUNTER | 199 | 101 | 50 | 1.39 | +4015 | +80.3 |
| BEST FACING | 42 | 42 | 42 | 1.17 | +1121 | +26.7 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| WALKS TO THE FIGHT | 92 | 92 | 39 | 1.08 | +597 | +15.3 |
| BEST OVERALL | 38 | 38 | 38 | 1.06 | +2867 | +75.5 |
| MAX FOR POSITIONING | 291 | 152 | 36 | 1.00 | +366 | +10.2 |
| MISSILES IN THE MOVE | 281 | 161 | 36 | 1.00 | +677 | +18.8 |
| MOVE AND CAST | 36 | 36 | 36 | 1.00 | +2338 | +64.9 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CANNON PLANNED TARGET | 212 | 212 | 34 | 0.94 | -70 | -2.1 |
| CHARGE NOW FIRST | 163 | 163 | 34 | 0.94 | -1856 | -54.6 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +1718 | +50.5 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 66 | 66 | 32 | 0.89 | +1212 | +37.9 |
| CHARGE NOW WEIGHED | 31 | 31 | 31 | 0.86 | +2099 | +67.7 |
| RISK BY ARC | 170 | 162 | 30 | 0.83 | +898 | +29.9 |
| BEST MOVE FOR SHOOTERS | 28 | 28 | 28 | 0.78 | +2087 | +74.5 |
| KILLS COUNT | 115 | 110 | 28 | 0.78 | +1250 | +44.6 |
| MARCH CHECK | 37 | 33 | 25 | 0.69 | +1214 | +48.5 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| BLOCKED WHEEL | 24 | 24 | 24 | 0.67 | +674 | +28.1 |
| INVITES THE FIGHT | 87 | 87 | 24 | 0.67 | +393 | +16.4 |
| KEEPS ITS TARGET | 125 | 122 | 24 | 0.67 | +393 | +16.4 |
| REDIRECT WEIGHED | 24 | 24 | 24 | 0.67 | +572 | +23.8 |
| HONEST THREAT | 243 | 243 | 23 | 0.64 | +0 | +0.0 |
| MAKE SURE TOGETHER | 60 | 43 | 22 | 0.61 | +1391 | +63.2 |
| ONE YARDSTICK | 452 | 141 | 22 | 0.61 | +336 | +15.3 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.61 | +644 | +29.3 |
| CAST JOB | 51 | 51 | 20 | 0.56 | +528 | +26.4 |
| STAY WORTH | 376 | 302 | 20 | 0.56 | +406 | +20.3 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| KEEPS THE TARGET | 34 | 34 | 17 | 0.47 | -793 | -46.6 |
| FIRE IN ORDER | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +237 | +14.8 |
| BEST PREY | 58 | 58 | 15 | 0.42 | +358 | +23.8 |
| SHOOTERS ARE THREATS | 78 | 78 | 15 | 0.42 | +0 | +0.0 |
| SHOT REPLANNED | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| WAR ENGINE JOBS | 32 | 32 | 15 | 0.42 | -465 | -31.0 |
| WEARS DOWN | 80 | 77 | 15 | 0.42 | +689 | +45.9 |
| WHOLE FIGHT GAIN | 29 | 27 | 14 | 0.39 | +781 | +55.8 |
| MANOEUVRE | 14 | 14 | 13 | 0.36 | +545 | +41.9 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -88 | -7.3 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -30 | -2.5 |
| HONEST WORTH | 285 | 284 | 11 | 0.31 | +118 | +10.7 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -265 | -24.1 |
| LOST CHARGE | 179 | 178 | 10 | 0.28 | +189 | +18.9 |
| WHOLE FIGHT | 28 | 28 | 10 | 0.28 | +609 | +60.9 |
| BLOCKED CHARGE SKIPPED | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTING BLOCK | 14 | 14 | 9 | 0.25 | +292 | +32.5 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| KEEP FALLS | 9 | 9 | 9 | 0.25 | +333 | +37.0 |
| WHO HITS BACK | 9 | 9 | 9 | 0.25 | +939 | +104.3 |
| CHARGE BAND | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| OPENS UP | 13 | 12 | 8 | 0.22 | +468 | +58.5 |
| FRIENDS SHOTS CHECKED | 7 | 7 | 7 | 0.19 | +360 | +51.5 |
| HUNT IN PAIRS | 30 | 18 | 7 | 0.19 | +331 | +47.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| SUPPORT NARROWED | 414 | 414 | 7 | 0.19 | -26 | -3.7 |
| MISSILES NEXT TURN | 360 | 205 | 5 | 0.14 | +31 | +6.2 |
| REFUSING RETIRES | 7 | 7 | 5 | 0.14 | -1 | -0.2 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| CARRIES OUT SET-UP | 14 | 14 | 4 | 0.11 | -267 | -66.8 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -113 | -28.3 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +108 | +26.9 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +180 | +45.0 |
| SHOOTERS TO THE PRIMARY | 63 | 39 | 4 | 0.11 | +18 | +4.5 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +255 | +63.7 |
| BACKUP TARGETS | 63 | 27 | 3 | 0.08 | +3 | +1.0 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -256 | -85.2 |
| CHARIOT NO STATIC JOB | 3 | 3 | 3 | 0.08 | -358 | -119.4 |
| EDGE GIVE GROUND | 18 | 18 | 3 | 0.08 | +292 | +97.2 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +21 | +7.1 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +1421 | +473.5 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -227 | -75.7 |
| REDIRECT BY WHAT IT STOPS | 29 | 29 | 3 | 0.08 | +127 | +42.5 |
| DEFENSIVE ARMY | 8 | 8 | 2 | 0.06 | -132 | -65.9 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +18 | +8.9 |
| JOINT CHARGE PLAN | 21 | 20 | 2 | 0.06 | +113 | +56.7 |
| LONE WIZARD HOLDS BACK | 11 | 11 | 2 | 0.06 | -247 | -123.3 |
| OVERRUNS AWAY | 19 | 19 | 2 | 0.06 | +15 | +7.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +109 | +54.4 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +309 | +154.3 |
| STOPS | 7 | 7 | 2 | 0.06 | +28 | +14.0 |
| SURE REACH TOGETHER | 42 | 32 | 2 | 0.06 | +10 | +5.0 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +40 | +40.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +9 | +9.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.03 | -97 | -97.1 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HUNT ADVANCE | 8 | 8 | 1 | 0.03 | +48 | +48.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 22 | 21 | 1 | 0.03 | -44 | -44.5 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +9 | +9.0 |
| OPENS A LANE | 7 | 3 | 1 | 0.03 | +0 | +0.4 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +38 | +38.1 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +110 | +109.7 |
| TWO OR MORE ARRIVE | 37 | 35 | 1 | 0.03 | +1 | +1.3 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +80 | +79.6 |
| WIDER SPREAD | 103 | 100 | 1 | 0.03 | +8 | +8.0 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 16 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 48 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 18 | 16 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 46 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 372 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 24 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 22 | 22 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 9 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 28 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 39 | 39 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 39 | 5 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 24 | 24 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 24 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 386 | 386 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 51 | not checked | - | - | - | - |
| PLAN RESULT | 2648 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 39 | 39 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOT OPTIONS | 913 | 913 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 133 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 15 | 13 | 0 | 0.00 | - | - |
| STABLE ROLE | 668 | 665 | 0 | 0.00 | - | - |
| TURN WORTH | 29 | 26 | 0 | 0.00 | - | - |

### Off best figure: ch-h2h-opp-ea652ef-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.92 | 12.58 | 55.8 |
| FALLBACK | gate | 0.75 | 0.50 | 45.4 |
| TURN GATE | gate | 0.67 | 0.47 | 61.0 |
| CHARGE NOW FIRST | rule | 0.50 | 0.42 | 56.2 |
| WAR ENGINE JOBS | rule | 0.33 | 0.08 | 31.0 |
| KEEPS THE TARGET | rule | - | 0.36 | 80.1 |
| AFTERMATH BAND | gate | 0.14 | 0.17 | 2.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.14 | 24.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.14 | 66.0 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.14 | 15.2 |
| FIRE PLAN | rule | - | 0.22 | 53.3 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 43.0 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.11 | 61.3 |
| PATHS CROSS | rule | 0.08 | 0.08 | 57.2 |
| SUPPORT NARROWED | rule | 0.08 | 0.06 | 5.0 |
| SUPPORT REQUEST | gate | 0.06 | 0.08 | 49.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.06 | 31.0 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 72.4 |
| CARRIES OUT SET-UP | rule | 0.08 | 0.03 | 66.8 |
| CHAFF PASSED | rule | 0.11 | - | 7.3 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.03 | 28.3 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 18.8 |
| BEST PRIZE | rule | - | 0.08 | 85.2 |
| CHARIOT NO STATIC JOB | rule | 0.08 | - | 119.4 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 1.1 |
| PURSUES BIG PREY | rule | 0.06 | 0.03 | 75.7 |
| DEFENSIVE ARMY | rule | 0.06 | - | 65.9 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 5.7 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 123.3 |
| MARCH ODDS | rule | - | 0.06 | 5.2 |
| NO REASON | gate | - | 0.06 | 5.4 |
| REDIRECT WEIGHED | rule | - | 0.06 | 93.7 |
| RULE SWITCHED OFF | gate | 0.06 | - | 23.2 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 17.5 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 7.1 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 97.1 |
| FALLBACK BY WORTH | rule | - | 0.03 | 2.4 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 0.9 |
| LONG SHOT | rule | 0.03 | - | 44.5 |
| MOVE AND CAST | rule | 0.03 | - | 2.8 |

### Plans: ch-h2h-opp-ea652ef-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.9 | 19% | 424 | 343 | 81% |
| Mine | charge | 3.1 | 61% | 304 | 323 | 106% |
| Mine | close in | 4.3 | 26% | 366 | 124 | 34% |
| Mine | hold | 4.0 | 34% | 237 | 0 | 0% |
| Mine | join | 0.3 | 92% | 7 | 0 | 0% |
| Mine | shoot | 8.9 | 63% | 247 | 686 | 278% |
| Mine | support | 3.6 | 93% | 36 | 0 | 0% |
| Opponent | advance | 13.1 | 18% | 328 | 477 | 145% |
| Opponent | charge | 3.7 | 65% | 345 | 404 | 117% |
| Opponent | close in | 5.8 | 26% | 341 | 215 | 63% |
| Opponent | hold | 3.7 | 31% | 237 | 0 | 0% |
| Opponent | join | 0.8 | 96% | 31 | 0 | 0% |
| Opponent | shoot | 5.1 | 58% | 176 | 295 | 168% |
| Opponent | support | 5.2 | 89% | 34 | 0 | 0% |

### Packages: hunt the guns, ch-h2h-opp-ea652ef-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 20% | 0% | 2.0 | 434 | 108 | 20% | 42 |
| Opponent | 0.1 | 4 | 0 | 25% | 25% | 0% | 2.0 | 357 | 64 | 25% | 64 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 0 | 0% | 0% | 0% | - | 405 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 79 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 548 | 540 | 100% | 32 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 104 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 25 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 190 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 342 | 128 | 50% | 24 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 447 | 0 | 0% | 39 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 63 |

### Battle groups: ch-h2h-opp-ea652ef-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.1 | 24% | 46% | 14% | 40% | 32% | 8% | 13% | 47% | 0% |
| Mine | REDIRECT COUNTER | 2.2 | 29% | 70% | 0% | - | 9% | 4% | 9% | 74% | 4% |
| Opponent | COUNTER-CHARGE COVER | 6.9 | 21% | 67% | 15% | 38% | 27% | 5% | 7% | 61% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 24% | 76% | 21% | 33% | 17% | 4% | 13% | 65% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ch-h2h-opp-ea652ef-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 41 (34) | 12 | 29 | 54 | 38% | 2.2 | 42 (21) | 0 (4) | 53 (9) | 61 (24) | 0 (10) |
| Mine | Character | 119 | 46 (119) | 46 | 0 | 31 | 13% | 2.6 | 66 (37) | 40 (56) | 33 (9) | 46 (57) | 53 (45) |
| Mine | Clean-up | 18 | 57 (18) | 19 | 38 | 79 | 22% | 2.3 | 59 (3) | 57 (13) | 52 (2) | 71 (12) | 35 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 44 (44) | 28 | 15 | 53 | 20% | 3.1 | 57 (22) | 38 (14) | 18 (8) | 57 (30) | 21 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 4.5 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 39 (52) | 21 | 19 | 47 | 12% | 2.9 | 52 (14) | 30 (35) | 84 (3) | 44 (36) | 30 (16) |
| Mine | Holder | 25 | 48 (25) | 3 | 46 | 29 | 40% | 3.3 | 32 (8) | 48 (14) | 169 (2) | 66 (14) | 30 (10) |
| Mine | Shooter | 37 | 45 (37) | 23 | 22 | 52 | 0% | 1.7 | 39 (6) | 43 (28) | 72 (3) | 54 (23) | 30 (14) |
| Mine | Support | 4 | 67 (4) | 67 | 0 | 100 | 0% | 2.8 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 52 | 35 (52) | 35 | 0 | 54 | 0% | 1.2 | 23 (13) | 43 (36) | 0 (3) | 47 (13) | 31 (39) |
| Mine | Wizard | 16 | 17 (16) | 17 | 0 | 52 | 25% | 1.7 | 13 (4) | 0 (5) | 0 (2) | 0 (6) | 11 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 54 (68) | 24 | 30 | 49 | 37% | 2.7 | 40 (29) | 62 (11) | 60 (28) | 70 (48) | 15 (20) |
| Opponent | Character | 102 | 55 (102) | 55 | 0 | 30 | 17% | 2.1 | 56 (38) | 61 (51) | 23 (7) | 64 (56) | 49 (40) |
| Opponent | Clean-up | 12 | 55 (12) | 9 | 46 | 49 | 17% | 4.1 | 0 (4) | 75 (7) | 93 (1) | 15 (6) | 83 (6) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 59 | 37 (59) | 25 | 11 | 45 | 24% | 2.8 | 38 (29) | 26 (20) | 57 (10) | 41 (27) | 33 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 61 (47) | 54 | 8 | 27 | 26% | 3.2 | 8 (16) | 83 (28) | 24 (3) | 76 (29) | 36 (18) |
| Opponent | Holder | 40 | 68 (40) | 4 | 64 | 29 | 40% | 2.7 | 54 (11) | 99 (19) | 17 (9) | 83 (29) | 39 (10) |
| Opponent | Shooter | 30 | 37 (30) | 20 | 18 | 38 | 0% | 1.2 | 33 (8) | 39 (20) | 29 (2) | 47 (18) | 23 (12) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 33 | 75% | 4.0 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | War machine | 17 | 74 (17) | 74 | 0 | 34 | 6% | 1.5 | 174 (3) | 44 (10) | 83 (4) | 28 (3) | 82 (14) |
| Opponent | Wizard | 32 | 18 (32) | 18 | 0 | 23 | 9% | 2.6 | 24 (16) | 25 (9) | 0 (2) | 24 (16) | 16 (11) |

### Charged fights: ch-h2h-opp-ea652ef-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 110 | 250 | 2.2 | 1.2 | 111 | 52 | +59 | 2 of 9 | 7 of 9 | +30 | +68 |
| Mine | Chaos Dwarfs | 4 | 146 | 491 | 4.2 | 1.2 | 115 | 28 | +87 | 8 of 17 | 13 of 17 | +289 | +44 |
| Mine | Dwarfen Mountain Holds | 3 | 346 | 13 | 1.0 | 1.0 | 13 | 20 | -7 | 0 of 3 | 1 of 3 | - | -7 |
| Mine | Empire of Man | 5 | 278 | 70 | 2.0 | 1.1 | 35 | 39 | -4 | 1 of 10 | 9 of 10 | +0 | -5 |
| Mine | Grand Cathay | 5 | 283 | 472 | 4.8 | 1.0 | 98 | 17 | +81 | 7 of 24 | 20 of 24 | +214 | +76 |
| Mine | High Elf Realms | 4 | 134 | 260 | 3.0 | 1.0 | 87 | 12 | +75 | 4 of 12 | 10 of 12 | - | +75 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1120 | 4.0 | 1.5 | 280 | 0 | +280 | 1 of 4 | 4 of 4 | +289 | +271 |
| Mine | Lizardmen | 1 | 0 | 395 | 3.0 | 1.0 | 132 | 193 | -62 | 2 of 3 | 2 of 3 | - | -62 |
| Mine | Ogre Kingdoms | 1 | 311 | 0 | 2.0 | 1.0 | 0 | 138 | -138 | 1 of 2 | 0 of 2 | - | -138 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 444 | 3.0 | 1.0 | 148 | 0 | +148 | 1 of 3 | 3 of 3 | - | +148 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 70 | 398 | 4.5 | 1.0 | 88 | 0 | +88 | 5 of 9 | 6 of 9 | - | +88 |
| Mine | Vampire Counts | 2 | 207 | 314 | 3.0 | 1.0 | 104 | 0 | +104 | 2 of 6 | 3 of 6 | - | +104 |
| Mine | Warriors of Chaos | 2 | 0 | 15 | 1.0 | 1.5 | 15 | 58 | -43 | 0 of 2 | 1 of 2 | -116 | +30 |
| **Mine** | all armies | 36 | 174 | 282 | 2.9 | 1.1 | 97 | 28 | +69 | 34 of 105 | 80 of 105 | +160 | +59 |
| Opponent | Empire of Man | 1 | 569 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 3 | 412 | 179 | 1.0 | 1.0 | 179 | 0 | +179 | 2 of 3 | 3 of 3 | - | +179 |
| Opponent | High Elf Realms | 3 | 292 | 90 | 1.7 | 1.0 | 54 | 145 | -91 | 3 of 5 | 4 of 5 | - | -91 |
| Opponent | Kingdom of Bretonnia | 2 | 48 | 192 | 2.0 | 1.0 | 96 | 89 | +7 | 2 of 4 | 3 of 4 | - | +7 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 561 | 5.0 | 1.2 | 112 | 0 | +112 | 1 of 5 | 5 of 5 | +176 | +96 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 56 | 439 | 4.0 | 1.2 | 110 | 39 | +71 | 10 of 16 | 11 of 16 | +73 | +70 |
| Opponent | Vampire Counts | 6 | 59 | 757 | 4.2 | 1.3 | 182 | 36 | +146 | 11 of 25 | 17 of 25 | +134 | +151 |
| Opponent | Warriors of Chaos | 9 | 9 | 727 | 3.3 | 1.1 | 218 | 46 | +172 | 13 of 30 | 22 of 30 | +561 | +129 |
| Opponent | Wood Elf Realms | 6 | 184 | 193 | 2.2 | 1.2 | 89 | 63 | +26 | 2 of 13 | 10 of 13 | +32 | +25 |
| **Opponent** | all armies | 36 | 126 | 438 | 2.9 | 1.2 | 153 | 47 | +106 | 45 of 103 | 77 of 103 | +180 | +91 |

### Effective charges: ch-h2h-opp-ea652ef-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 1 (net +45) | 0 | 1 (net +329) | 2 (net -234) | 0 | 4 (net +142) | 1 | 12% (1 of 8) |
| Mine | Chaos Dwarfs | 17 | 0 | 0 | 0 | 6 (net +77) | 1 (net +162) | 8 (net +85) | 2 | 0% (0 of 15) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 1 (net -60) | 0 | 1 (net +0) | 1 | 0% (0 of 2) |
| Mine | Empire of Man | 10 | 1 (net +0) | 0 | 1 (net +0) | 3 (net -11) | 0 | 5 (net -2) | 0 | 10% (1 of 10) |
| Mine | Grand Cathay | 24 | 2 (net -102) | 1 (net +0) | 4 (net +286) | 5 (net +82) | 4 (net +32) | 7 (net +48) | 1 | 17% (4 of 23) |
| Mine | High Elf Realms | 12 | 0 | 1 (net +599) | 2 (net +0) | 1 (net +0) | 3 (net +38) | 5 (net +36) | 0 | 17% (2 of 12) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +334) | 0 | 0 | 1 (net +208) | 1 (net +342) | 1 (net +236) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 3 | 2 (net -164) | 0 | 0 | 1 (net +144) | 0 | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +137) | 2 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net +0) | 0 | 1 (net +540) | 5 (net +39) | 2 (net +30) | 0 | 0 | 11% (1 of 9) |
| Mine | Vampire Counts | 6 | 2 (net +0) | 0 | 1 (net +0) | 1 (net +285) | 0 | 2 (net +171) | 0 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 2 | 0 | 1 (net +30) | 1 (net -116) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 3 | 1 (net +0) | 1 (net +485) | 0 | 1 (net +52) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 5 | 1 (net -347) | 0 | 0 | 3 (net -125) | 0 | 0 | 1 | 0% (0 of 4) |
| Opponent | Kingdom of Bretonnia | 4 | 2 (net +68) | 0 | 0 | 1 (net +168) | 0 | 0 | 1 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 2 (net +100) | 0 | 1 (net +176) | 2 | 0% (0 of 3) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 16 | 4 (net -17) | 0 | 2 (net +178) | 1 (net +0) | 3 (net +73) | 5 (net +81) | 1 | 13% (2 of 15) |
| Opponent | Vampire Counts | 25 | 4 (net -1) | 0 | 6 (net +181) | 7 (net +232) | 2 (net +104) | 3 (net +138) | 3 | 27% (6 of 22) |
| Opponent | Warriors of Chaos | 30 | 7 (net +84) | 3 (net -155) | 2 (net +112) | 7 (net +271) | 0 | 10 (net +292) | 1 | 7% (2 of 29) |
| Opponent | Wood Elf Realms | 13 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 6 (net +58) | 5 | 0% (0 of 8) |

### Charged fights, damage counted: ch-h2h-opp-ea652ef-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 254 | 248 | -16 | 122 | 90 | +32 | +12.7 |
| Mine | 50-54% | 3 | 248 | 288 | +210 | 210 | 94 | +115 | +46.6 |
| Mine | Effective (55-75%) | 11 | 322 | 239 | +173 | 199 | 52 | +147 | +45.6 |
| Mine | 76-89% | 27 | 302 | 208 | +42 | 96 | 40 | +56 | +18.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 250 | 156 | +71 | 121 | 27 | +94 | +37.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 391 | 75 | +73 | 82 | 6 | +76 | +19.5 |
| Mine | No odds | 8 | 348 | 154 | +56 | 90 | 44 | +46 | +13.1 |
| Mine | All fights | 105 | 293 | 182 | +69 | 119 | 40 | +79 | +26.9 |
| Opponent | Long shot (under 50%) | 20 | 222 | 245 | +15 | 144 | 134 | +10 | +4.6 |
| Opponent | 50-54% | 5 | 307 | 310 | +4 | 109 | 93 | +16 | +5.1 |
| Opponent | Effective (55-75%) | 10 | 368 | 175 | +167 | 222 | 47 | +175 | +47.6 |
| Opponent | 76-89% | 22 | 284 | 229 | +162 | 217 | 38 | +180 | +63.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 364 | 209 | +170 | 232 | 57 | +175 | +48.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 439 | 113 | +71 | 85 | 20 | +65 | +14.8 |
| Opponent | No odds | 15 | 224 | 164 | +48 | 123 | 35 | +89 | +39.7 |
| Opponent | All fights | 103 | 301 | 210 | +106 | 180 | 63 | +117 | +39.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ch-h2h-opp-ea652ef-p3 | move | 430 | 93 (22%) | 62 (14%) | 56 (13%) | 281 (65%) |
| ch-h2h-opp-ea652ef-p3 | objective | 367 | 60 (16%) | 45 (12%) | 56 (15%) | 251 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

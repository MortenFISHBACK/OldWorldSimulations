# Doctrine scorecard: nw22-19bea9b-p12

### Scorecard: nw22-19bea9b-p12

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | yes | - | 5 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 3 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 6 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 4 | 2 | 5 | 0 | 0 | 0 | 91 |
| **Average** | | | Mine | 33% | 3.0 | 3.7 | 3.0 | 2.7 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 33% | 2.0 | 4.0 | 0.7 | 3.0 | 0.0 | 0.0 | 0.0 | 87.0 |

### KPIs: nw22-19bea9b-p12

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 16) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 100% | 75% (3 of 4); on the table 100% | 80% (8 of 10); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 0% (0 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 71% (5 of 7); on the table 100% | 71% (5 of 7); on the table 86% | 71% (10 of 14); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 50% (3 of 6) | 58% (7 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (4 of 6) | 60% (3 of 5) | 64% (7 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | 43% (3 of 7) | 54% (7 of 13) |
| Points that never fought | lower | 70% (4191 of 5998) | 54% (3220 of 5998) | 62% (7411 of 11996) |
|   infantry points that never fought | lower | 57% (511 of 902) | 75% (808 of 1072) | 67% (1319 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (12 of 19) | 81% (21 of 26) | 73% (33 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (3142 of 5038) | 80% (4279 of 5360) | 71% (7421 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (100%) | 0.7 (67%) | 1.3 (80%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (33%) | 0.3 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 1.0 | 0.7 | 2.3 | 0.0 | 0.0 |
| not cast | 3.7 | 0.0 | 3.3 | 1.7 | 2.0 | 24.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.3 (80%) | 2.0 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (9%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (82%) | - | 3.0 (90%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.3 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | 0% (0 of 2) | - | 0% (0 of 2) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 30% (3 of 10) | 59% (22 of 37) | 53% (25 of 47) |
|   cavalry | 60% (3 of 5) | 78% (7 of 9) | 71% (10 of 14) |
|   character | 0% (0 of 5) | 25% (4 of 16) | 19% (4 of 21) |
|   infantry | - | 92% (11 of 12) | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (29%) | 2.0 (40%) | 2.7 (36%) |
| CHARGED: it charged | 1.0 (43%) | 1.3 (27%) | 2.3 (32%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (20%) | 1.0 (14%) |
| NO TARGET IN RANGE | 0.7 (29%) | 0.3 (7%) | 1.0 (14%) |
| STUPIDITY | 0.0 (0%) | 0.3 (7%) | 0.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.7 | 82% | 4.3 pts | 24 pts |
| character | 1.3 | 0.3 | 75% | 18.2 pts | 24 pts |
| infantry | 5.7 | 1.0 | 94% | 9.7 pts | 55 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.3 | 1.7 | 4.0 |
| Charges that made contact a game | 3.3 | 1.0 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.75 declared, 0.00 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.70 declared, 0.43 contact (23 units) | 0.22 declared, 0.13 contact (23 units) | 0.46 declared, 0.28 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (3 of 7) | 80% (4 of 5) | 0% (0 of 1) | 54% (7 of 13) |
| Character in a unit | 100% (5 of 5) | 100% (3 of 3) | 100% (1 of 1) | 100% (9 of 9) |
| Character on its own | 50% (1 of 2) | - | 71% (5 of 7) | 67% (6 of 9) |
| Infantry | 71% (5 of 7) | 0% (0 of 1) | - | 62% (5 of 8) |
| Monster | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 67% (4 of 6); on the table 100% | 67% (4 of 6) | 80% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 80% (4 of 5); on the table 100% | 50% (3 of 6) | 58% | 76% (19 of 25) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 35% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p12, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 50% (4) | 55% (6) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.33 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: nw22-19bea9b-p12

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 47% (8 of 17) | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | - | 30% (3 of 10) |
| Strategy | Support requests answered (helper made contact too) | 75% (3 of 4) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 29% (2 of 7) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 1.3 | 0.0 |
| Movement | Idle units | 2.7 | 3.0 |
| Movement | Points that never moved of their own | 0.0 | 87.0 |
| Movement | Fights charged into per game | 2.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 7, net +266 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 7, net +46 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 7, net +0 | 1 of 1, net +410 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.3 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 55% (12 of 22) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 100% (1 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.0 / 0.0 | 0.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 123.7 | 151.7 |
| Combat | Points run down | 254.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +141 | +123 |
| Combat | Net per 100 charger points, damage counted | +57.9 | +24.7 |
| Combat | First round won (charged fights) | 75% | 100% |
| Combat | Net points per charged fight | +135 | +142 |
| Combat | Net points per supported fight / lone fight | +173 / +130 | - / +142 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 8 | 0 of 3 |
| Game | Points lost | 310.0 | 420.0 |
| Game | VP from objectives | 473.3 | 546.7 |
| Game | Lone holders (player turns) | 3.0 | 2.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +37 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 730
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: nw22-19bea9b-p12

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +31.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 20.7 | +173.4 | 0.0 | 323.0 | 19.3 | +60.4 | 0.0 | 313.0 |
| BACKS UP THE FIGHT | 1.3 | +12.4 | 0.0 | 0.0 | 0.7 | +42.9 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.7 | +0.0 | 57.7 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.3 | +59.6 | 0.0 | 0.0 | 1.0 | +9.9 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.7 | +24.8 | 0.0 | 136.7 | 0.7 | +3.9 | 0.0 | 93.3 |
| CHARACTERS BY THEIR POINTS | 0.7 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.3 | -148.3 | 0.0 | 499.0 | 8.0 | -293.8 | 0.0 | 180.7 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 158.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 16.3 | +0.0 | 0.0 | 107.7 | 13.7 | +0.0 | 0.0 | 190.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 6.3 | -358.7 | 0.0 | 107.7 | 8.3 | -354.7 | 0.0 | 90.3 |
| DEPLOY BY FIGURES | 7.0 | +76.7 | 0.0 | 0.0 | 7.3 | -20.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +5.8 | 65.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 4.3 | +4.2 | 271.0 | 15.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 5.3 | +20.8 | 363.7 | 15.0 | 1.7 | +6.0 | 146.7 | 0.0 |
| FALLS SHORT | 24.3 | +253.5 | 0.0 | 225.3 | - | - | - | - |
| FEATURE BUFFS | 0.7 | +9.3 | 0.0 | 0.0 | 2.0 | +15.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +8.0 | 95.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 84.3 | +3660.2 | 394.0 | 602.3 | 89.0 | +5776.7 | 298.7 | 612.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 78.3 | 8.0 | +0.0 | 0.0 | 215.7 |
| FOLLOW UP WEIGHED | 2.0 | +249.9 | 0.0 | 0.0 | 1.0 | +116.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 6.3 | +304.2 | 394.0 | 15.0 | 1.7 | +66.3 | 146.7 | 0.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 136.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -24.3 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -2.8 | 63.0 | 0.0 | 0.7 | -22.3 | 136.7 | 0.0 |
| GOAL WALK | 10.7 | +896.6 | 0.0 | 430.7 | 13.7 | +1700.7 | 0.0 | 190.0 |
| HALF WHEN STILL FLEEING | 1.7 | -3.9 | 173.0 | 15.0 | 1.0 | -0.3 | 136.7 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 57.7 | 15.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 5.7 | +0.0 | 0.0 | 283.7 | 6.7 | +0.0 | 0.0 | 180.7 |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -13.0 | 0.0 | 68.3 | - | - | - | - |
| HIS ONE QUARTER | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 0.0 | 19.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.3 | +566.3 | 0.0 | 264.3 | 14.3 | +173.4 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 22.7 | +151.5 | 0.0 | 587.3 | 6.7 | +273.7 | 0.0 | 60.7 |
| HIS TURN DENIED | 0.3 | +3.0 | 0.0 | 0.0 | 0.3 | +5.9 | 0.0 | 0.0 |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 215.3 | 18.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +839.5 | 0.0 | 107.7 | 10.0 | +936.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.0 | -170.2 | 278.7 | 0.0 | 1.7 | -55.0 | 146.7 | 0.0 |
| IDLE COST | 21.7 | -319.7 | 0.0 | 68.3 | - | - | - | - |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | 2.3 | +59.8 | 205.7 | 15.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +18.4 | 0.0 | 0.0 | 1.0 | +19.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 195.3 | 205.0 | 5.3 | +0.0 | 15.0 | 1102.0 |
| LOST AFTER ESCAPE | 2.7 | +4.3 | 268.0 | 15.0 | 1.0 | +0.6 | 136.7 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 2.0 | -63.1 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 5.0 | +63.8 | 0.0 | 0.0 | 0.3 | +11.7 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | -1.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.3 | +74.9 | 0.0 | 0.0 | 4.3 | +70.1 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +231.2 | 0.0 | 0.0 | 3.3 | +136.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +4.3 | 0.0 | 0.0 | 2.0 | +32.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +3.3 | 0.0 | 0.0 | 3.0 | +27.3 | 0.0 | 0.0 |
| MOVE ORDER | 2.3 | +0.0 | 107.7 | 107.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 9.3 | +347.9 | 0.0 | 0.0 | 6.7 | +658.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.7 | +320.5 | 0.0 | 0.0 | 7.3 | +332.8 | 0.0 | 32.7 |
| NEXT CHARGE BY LIST | 8.3 | +323.5 | 0.0 | 0.0 | 4.0 | +355.8 | 0.0 | 0.0 |
| NO CHAFF EDGES | 2.7 | +83.5 | 32.7 | 136.7 | 1.7 | +18.9 | 68.3 | 0.0 |
| NO DOUBLE ROUNDS | 5.0 | -160.4 | 278.7 | 15.0 | 1.7 | -72.5 | 146.7 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +9.8 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | -8.3 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -62.9 | 0.0 | 0.0 | 5.3 | -235.8 | 68.3 | 0.0 |
| ONE CHALLENGE TEST | 0.7 | +2.0 | 30.3 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.0 | -47.7 | 0.0 | 0.0 | 6.0 | -103.0 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 1.3 | +8.6 | 173.0 | 15.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.3 | +3.7 | 0.0 | 107.7 | 5.3 | +14.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -12.0 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +55.5 | 60.7 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 2.0 | +75.9 | 93.3 | 0.0 | 1.0 | +16.4 | 68.3 | 0.0 |
| OVERRUNS AWAY | 1.7 | +9.1 | 60.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.3 | +10.8 | 0.0 | 0.0 | 1.3 | +37.7 | 0.0 | 0.0 |
| PLAN RESULT | 43.7 | +249.5 | 405.7 | 403.3 | 43.7 | +248.3 | 268.7 | 587.0 |
| PRIZE BY WORTH | 0.3 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.0 | -90.9 | 0.0 | 0.0 | 13.3 | -868.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | -0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -1.5 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| QUARTER ODDS | 7.7 | +677.6 | 0.0 | 15.0 | 6.7 | +963.1 | 30.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +12.1 | 0.0 | 0.0 | 2.3 | +2.2 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -14.9 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.3 | +353.0 | 0.0 | 10.0 | 3.0 | +117.9 | 0.0 | 9.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.7 | +2.1 | 0.0 | 25.0 | 2.7 | +0.0 | 0.0 | 9.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 3.3 | -86.5 | 0.0 | 0.0 | 0.3 | -33.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 30.3 |
| RISK BY ARC | 4.0 | +142.5 | 126.0 | 15.0 | 1.0 | +5.3 | 78.3 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -17.2 | 123.0 | 0.0 | 0.7 | -5.7 | 0.0 | 0.0 |
| RUN DOWN | 5.7 | -36.9 | 394.0 | 15.0 | 1.7 | -11.9 | 146.7 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.3 | -84.8 | 0.0 | 0.0 | 1.3 | -30.7 | 0.0 | 18.0 |
| SEARCH SPOT | 0.7 | +35.6 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +71.1 | 0.0 | 0.0 | 0.7 | +59.9 | 68.3 | 0.0 |
| SET CREDITED ONCE | 6.7 | -106.6 | 0.0 | 0.0 | 1.7 | -10.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 9.7 | +117.4 | 0.0 | 0.0 | 4.7 | -24.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 5.0 | +63.8 | 0.0 | 0.0 | 1.0 | +14.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 9.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 2.7 | +8.0 | 30.0 | 0.0 |
| SHOT RISK POINTS | 18.7 | -154.1 | 0.0 | 499.0 | 8.7 | +11.9 | 0.0 | 60.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.3 | +28.7 | 0.0 | 0.0 | 7.3 | +76.6 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 16.0 | +0.0 | 0.0 | 20.0 | 10.0 | +0.0 | 0.0 | 254.7 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 16.3 | +0.0 | 0.0 | 0.0 | 42.7 | +0.0 | 152.0 | 126.0 |
| STAY WORTH | 0.7 | +2.3 | 0.0 | 0.0 | 8.7 | +30.7 | 81.3 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.3 | 0.0 | 57.7 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 4.0 | +97.3 | 0.0 | 107.7 | 8.3 | +694.0 | 0.0 | 65.3 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.0 | +97.3 | 0.0 | 107.7 | 8.3 | +694.0 | 0.0 | 65.3 |
| SURE REACH TOGETHER | 2.7 | +15.4 | 0.0 | 0.0 | 1.0 | +13.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.3 | +12.5 | 160.3 | 0.0 | 0.3 | +0.1 | 68.3 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 6.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 10.0 | 1.0 | +0.0 | 0.0 | 57.7 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.7 | +0.0 | 0.0 | 293.7 | 44.3 | +0.0 | 0.0 | 315.0 |
| TIED UP BY THE SUM | 3.0 | +460.4 | 126.0 | 0.0 | 1.0 | +180.1 | 136.7 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 64.7 | +611.5 | 0.0 | 432.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -22.4 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | -7.4 | 115.3 | 0.0 | - | - | - | - |
| WHO GETS IN | 1.7 | -2.5 | 205.7 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +40.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -28.9 | 0.0 | 0.0 | 5.3 | -269.5 | 0.0 | 180.7 |
| WHOLE FIGHT GAIN | 1.3 | +28.1 | 173.0 | 15.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.0 | +18.9 | 0.0 | 10.0 | 2.3 | +375.8 | 15.0 | 57.7 |

### Rule changes: nw22-19bea9b-p12

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 120 | 120 | 78 | 26.00 | +730 | +9.4 |
| HOLDER ASSIGNMENT | 57 | 57 | 54 | 18.00 | +3824 | +70.8 |
| FIVE ACTION | 520 | 493 | 36 | 12.00 | +1890 | +52.5 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -896 | -25.6 |
| TIME ON OUR SIDE | 194 | 163 | 32 | 10.67 | +22 | +0.7 |
| PROMISE BY ITS OWN SUM | 70 | 70 | 30 | 10.00 | -2878 | -95.9 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 29 | 29 | 29 | 9.67 | +0 | +0.0 |
| HIS SHOT LIST | 155 | 146 | 26 | 8.67 | +111 | +4.3 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +127 | +5.3 |
| REDIRECT FOR A FRIEND IN REACH | 22 | 22 | 21 | 7.00 | +0 | +0.0 |
| GOAL WALK | 73 | 73 | 15 | 5.00 | +1436 | +95.7 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| IDLE COST | 65 | 49 | 14 | 4.67 | +152 | +10.9 |
| FOUR ROUNDS | 24 | 22 | 13 | 4.33 | +423 | +32.5 |
| HIS SHOTS BY HIS RUN | 88 | 84 | 13 | 4.33 | +86 | +6.6 |
| COVER ONCE | 44 | 33 | 11 | 3.67 | +201 | +18.2 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +575 | +52.3 |
| MOVE TO CHARGE COMPUTED | 48 | 33 | 10 | 3.33 | +266 | +26.6 |
| QUARTER ODDS | 43 | 41 | 10 | 3.33 | +776 | +77.6 |
| SET UP BY THE SET | 43 | 42 | 10 | 3.33 | +388 | +38.8 |
| SUPPORT ADDS | 37 | 36 | 10 | 3.33 | +396 | +39.6 |
| SUPPORT WORKED OUT | 37 | 36 | 10 | 3.33 | +396 | +39.6 |
| TIED UP BY THE SUM | 12 | 10 | 10 | 3.33 | +291 | +29.1 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +1099 | +122.1 |
| NO CHAFF EDGES | 13 | 11 | 9 | 3.00 | +230 | +25.5 |
| NEXT CHARGE BY LIST | 37 | 31 | 8 | 2.67 | +286 | +35.8 |
| PATHS CROSS | 8 | 8 | 8 | 2.67 | +145 | +18.2 |
| SHOT RISK POINTS | 82 | 77 | 8 | 2.67 | +37 | +4.7 |
| CHAFF IN THE MOVE | 10 | 9 | 7 | 2.33 | +7 | +1.0 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +86 | +12.3 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +180 | +25.7 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1184 | +169.2 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 7 | 2.33 | +43 | +6.1 |
| SURE REACH TOGETHER | 11 | 10 | 7 | 2.33 | +1 | +0.1 |
| CLEAR LANE AHEAD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +113 | +18.8 |
| MAX FOR POSITIONING | 26 | 22 | 6 | 2.00 | +8 | +1.3 |
| RISK BY ARC | 15 | 13 | 6 | 2.00 | +171 | +28.5 |
| WHOLE FIGHT DANGER | 22 | 22 | 6 | 2.00 | +208 | +34.6 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 13 | 13 | 5 | 1.67 | -307 | -61.3 |
| FALLS SHORT | 73 | 57 | 5 | 1.67 | +29 | +5.8 |
| OPENS UP IN FULL | 9 | 7 | 5 | 1.67 | +114 | +22.7 |
| WHO GETS IN | 5 | 5 | 5 | 1.67 | -8 | -1.5 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 55 | 50 | 4 | 1.33 | +236 | +58.9 |
| NEARER NOT NEEDED | 45 | 42 | 4 | 1.33 | +166 | +41.5 |
| REFUSING RETIRES | 4 | 4 | 4 | 1.33 | -14 | -3.6 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +393 | +98.2 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 4 | 1.33 | +1 | +0.2 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HONEST WORTH | 20 | 18 | 3 | 1.00 | +103 | +34.3 |
| OPENS UP | 3 | 3 | 3 | 1.00 | +81 | +26.9 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +107 | +35.8 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -36 | -18.0 |
| SET CREDITED ONCE | 25 | 24 | 2 | 0.67 | +7 | +3.5 |
| SET UP TOGETHER | 18 | 13 | 2 | 0.67 | +14 | +7.1 |
| SHOTS IN THE MOVE | 26 | 23 | 2 | 0.67 | +25 | +12.3 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -14 | -6.9 |
| WHOLE FIGHT REACTION | 10 | 10 | 2 | 0.67 | +73 | +36.3 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +93 | +92.8 |
| BACKS UP THE FIGHT | 6 | 5 | 1 | 0.33 | +126 | +125.5 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 1 | 0.33 | +1 | +0.6 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 11 | 9 | 1 | 0.33 | +1 | +0.6 |
| MISSILES IN THE MOVE | 11 | 5 | 1 | 0.33 | +23 | +23.4 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +13 | +13.3 |
| ONE FIGHT FORMULA | 33 | 11 | 1 | 0.33 | +32 | +32.3 |
| ONE JOINT FIGURE | 4 | 4 | 1 | 0.33 | +22 | +22.1 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +13 | +13.0 |
| PROMISE KNOWS THE FIGHT | 13 | 5 | 1 | 0.33 | -0 | -0.1 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | +31 | +30.7 |
| REDIRECT COUNTER | 22 | 19 | 1 | 0.33 | +60 | +59.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +13 | +13.0 |
| RUN DOWN | 22 | 20 | 1 | 0.33 | +27 | +27.1 |
| SCOUT BY DROPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STAY WORTH | 28 | 21 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| THE FIGHT MOVES | 8 | 7 | 1 | 0.33 | +10 | +9.8 |
| THE ROW IN ITS ORDER | 31 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +17 | +16.9 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.33 | +41 | +41.4 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CARRIES OUT SET-UP | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 90 | 89 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 14 | 14 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 21 | 19 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 18 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 8 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 11 | 11 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 37 | 34 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 36 | 29 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 9 | 9 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 10 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 44 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 93 | 88 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 16 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 102 | 102 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 16 | not checked | - | - | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 14 | 5 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 20 | 18 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 29 | 25 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 262 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 10 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 13 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 78 | 68 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 177 | 167 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 255 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 12 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p12

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 4.33 | 22.3 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 7.33 | 95.9 |
| ARMY TABLE | rule | 2.33 | 2.33 | 106.3 |
| CHARGE NOW FIRST | rule | 1.00 | 0.67 | 61.3 |
| REFUSING RETIRES | rule | 0.67 | 0.67 | 3.6 |
| JOINT CHARGE NOW | rule | 1.00 | - | 27.9 |
| WHO GETS IN | rule | 1.00 | - | 27.9 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.67 | 10.9 |
| NO REASON | gate | - | 0.67 | 29.9 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 18.0 |
| PATHS CROSS | rule | - | 0.67 | 11.3 |
| RULE SWITCHED OFF | gate | 0.67 | - | 12.3 |
| SUPPORT NARROWED | rule | 0.67 | - | 6.9 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 21.6 |
| SET UP BY THE SET | rule | 0.33 | - | 1.1 |
| TURN GATE | gate | - | 0.33 | 143.4 |

### Plans: nw22-19bea9b-p12

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.7 | 43% | 560 | 250 | 45% |
| Mine | join | 2.0 | 100% | 75 | 0 | 0% |
| Mine | move | 35.3 | 97% | 1258 | 0 | 0% |
| Mine | support | 1.7 | 100% | 2 | 0 | 0% |
| Opponent | charge | 1.3 | 100% | 93 | 167 | 179% |
| Opponent | join | 2.7 | 100% | 139 | 0 | 0% |
| Opponent | move | 36.3 | 98% | 1956 | 0 | 0% |
| Opponent | shoot | 2.0 | 33% | 195 | 81 | 42% |
| Opponent | support | 1.3 | 75% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p12

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 23% | 33% | 67% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 44% | 75% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p12

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 61 (9) | 33 | 29 | 14 | 67% | 5.0 | 70 (4) | 0 (3) | 111 (2) | 77 (7) | 0 (2) |
| Mine | Character | 9 | 4 (9) | 4 | 0 | 0 | 67% | 4.7 | 0 (2) | 6 (6) | 0 (1) | 8 (4) | 0 (5) |
| Mine | Clean-up | 3 | 205 (3) | 174 | 30 | 25 | 0% | 2.7 | - | 153 (1) | 236 (2) | 141 (2) | 310 (1) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 4 | 23 (4) | 9 | 13 | 36 | 50% | 4.0 | 0 (1) | 44 (2) | 0 (1) | 39 (1) | 14 (3) |
| Mine | Hammer | 2 | 6 (2) | 0 | 6 | 66 | 100% | - | - | 6 (2) | - | 0 (1) | 9 (1) |
| Mine | Holder | 1 | 282 (1) | 0 | 282 | 0 | 0% | 4.0 | 282 (1) | - | - | 282 (1) | - |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 0% | 4.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.7 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 3 | 218 (3) | 0 | 218 | 22 | 100% | - | 0 (1) | 386 (1) | 0 (1) | 218 (3) | - |
| Opponent | Character | 10 | 16 (10) | 16 | 0 | 16 | 60% | 1.8 | 26 (6) | 0 (4) | - | 0 (5) | 27 (5) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 38 (5) | 0 | 38 | 44 | 80% | 1.0 | 0 (3) | - | 86 (2) | 84 (3) | 0 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 11 (6) | 0 | 11 | 33 | 17% | 3.6 | - | 14 (4) | 0 (2) | 0 (3) | 24 (3) |
| Opponent | Holder | 6 | 21 (6) | 0 | 21 | 15 | 67% | 1.5 | 56 (1) | 36 (2) | - | 84 (1) | 24 (2) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: nw22-19bea9b-p12

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 518 | 2.5 | 1.4 | 207 | 9 | +198 | 3 of 5 | 3 of 5 | +173 | +204 |
| Mine | Warriors of Chaos | 1 | 0 | 91 | 3.0 | 1.0 | 30 | 0 | +30 | 0 of 3 | 3 of 3 | - | +30 |
| **Mine** | all armies | 3 | 0 | 375 | 2.7 | 1.2 | 141 | 6 | +135 | 3 of 8 | 6 of 8 | +173 | +130 |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 532 | 3.0 | 1.0 | 177 | 36 | +142 | 0 of 3 | 3 of 3 | - | +142 |
| **Opponent** | all armies | 3 | 0 | 177 | 1.0 | 1.0 | 177 | 36 | +142 | 0 of 3 | 3 of 3 | - | +142 |

### Effective charges: nw22-19bea9b-p12

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 5 | 2 (net +266) | 0 | 0 | 1 (net +173) | 0 | 1 (net +0) | 1 | 0% (0 of 4) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net +0) | 2 (net +46) | 0 | 0 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +410) | 2 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p12

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 116 | 337 | +266 | 317 | 65 | +251 | +217.7 |
| Mine | 76-89% | 2 | 177 | 141 | +86 | 114 | 4 | +110 | +62.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 186 | 285 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 494 | 91 | +46 | 87 | 27 | +59 | +12.0 |
| Mine | No odds | 1 | 186 | 173 | +285 | 285 | 0 | +285 | +153.2 |
| Mine | All fights | 8 | 243 | 200 | +135 | 165 | 24 | +141 | +57.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 205 | +410 | 410 | 55 | +355 | +71.1 |
| Opponent | No odds | 2 | 500 | 164 | +8 | 61 | 54 | +8 | +1.5 |
| Opponent | All fights | 3 | 499 | 177 | +142 | 177 | 54 | +123 | +24.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p12 | move | 19 | 4 (21%) | 2 (11%) | 4 (21%) | 11 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

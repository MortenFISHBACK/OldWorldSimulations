# Doctrine scorecard: nw22-19bea9b-p46

### Scorecard: nw22-19bea9b-p46

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 3 | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 490 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 1.0 | 2.5 | 2.3 | 0.7 | 0.3 | 0.0 | 0.0 | 163.3 |
| **Average** | | | Opponent | 0% | 0.0 | 2.3 | 3.3 | 1.3 | 0.0 | 0.0 | 0.0 | 56.7 |

### KPIs: nw22-19bea9b-p46

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 18) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 62% (5 of 8); on the table 75% | 100% (4 of 4); on the table 100% | 75% (9 of 12); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | - | 33% (1 of 3); on the table 33% | 33% (1 of 3); on the table 33% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 25% (1 of 4); on the table 25% | 40% (2 of 5); on the table 40% |
| Winner chose to follow up or pursue (all three) |  | 67% (6 of 9); on the table 78% | 55% (6 of 11); on the table 55% | 60% (12 of 20); on the table 65% |
| Magic missiles tried each own turn | 50%+ | 50% (12 of 24) | 50% (6 of 12) | 50% (18 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (12 of 20) | 50% (6 of 12) | 56% (18 of 32) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (3 of 9) | 80% (4 of 5) | 50% (7 of 14) |
| Points that never fought | lower | 18% (1071 of 5999) | 23% (1393 of 5999) | 21% (2464 of 11998) |
|   infantry points that never fought | lower | 31% (312 of 993) | 63% (497 of 793) | 45% (809 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 58% (11 of 19) | 63% (26 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (3440 of 5151) | 49% (2439 of 4976) | 58% (5879 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (25%) | 2.0 (100%) | 3.0 (50%) |
| MARCHED: its unit marched | 1.0 (25%) | 0.0 (0%) | 1.0 (17%) |
| CHARGED: its unit charged | 0.7 (17%) | 0.0 (0%) | 0.7 (11%) |
| IN COMBAT: engaged in combat | 0.7 (17%) | 0.0 (0%) | 0.7 (11%) |
| GONE: slain | 0.7 (17%) | 0.0 (0%) | 0.7 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 4.0 | 6.0 | 0.3 | 2.0 |
| not cast | 8.3 | 6.0 | 6.0 | 3.7 | 30.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 3.0 (50%) | 1.7 (45%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (17%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (8%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (10%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (55%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 7.7 (92%) | 6.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 26.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.0 a game | 1.0 a game | 2.0 a game |
| stood (cast and not dispelled) | 56% (5 of 9) | 33% (1 of 3) | 50% (6 of 12) |
| the unit moved after it | 40% (2 of 5) | 100% (1 of 1) | 50% (3 of 6) |
| it charged on its next turn | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 6) |
| the enemy charged it first | 40% (2 of 5) | 0% (0 of 1) | 33% (2 of 6) |
| it fought by the end of its next turn | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (1 of 5) | 0% (0 of 1) | 17% (1 of 6) |
| none of these (no charge, no fight, no charge escaped) | 40% (2 of 5) | 100% (1 of 1) | 50% (3 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 43% (28 of 65) | 12% (1 of 8) | 40% (29 of 73) |
|   cavalry | - | 50% (1 of 2) | 50% (1 of 2) |
|   character | 60% (3 of 5) | 0% (0 of 6) | 27% (3 of 11) |
|   chariot | 58% (7 of 12) | - | 58% (7 of 12) |
|   infantry | 21% (7 of 34) | - | 21% (7 of 34) |
|   monster | 79% (11 of 14) | - | 79% (11 of 14) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (22%) | 1.0 (43%) | 3.7 (25%) |
| CHARGED: it charged | 0.7 (5%) | 0.7 (29%) | 1.3 (9%) |
| IN COMBAT: it fought this turn or the last | 1.7 (14%) | 0.3 (14%) | 2.0 (14%) |
| NO TARGET IN RANGE | 5.3 (43%) | 0.3 (14%) | 5.7 (39%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (8%) | 0.0 (0%) | 1.0 (7%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.3 | 0.7 | 0% | 6.3 pts | 2 pts |
| character | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.3 | 1.0 | 71% | 25.2 pts | 59 pts |
| infantry | 2.3 | 2.0 | 57% | 17.8 pts | 42 pts |
| monster | 3.7 | 1.0 | 82% | 3.4 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 5.3 | 5.7 |
| Charges that made contact a game | 4.7 | 4.0 | 4.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.67 declared, 0.67 contact (3 units) | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.63 declared, 0.48 contact (27 units) | 0.58 declared, 0.42 contact (24 units) | 0.61 declared, 0.45 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | 67% (2 of 3) | 0% (0 of 2) | 56% (5 of 9) |
| Character in a unit | 60% (3 of 5) | 100% (1 of 1) | 100% (1 of 1) | 71% (5 of 7) |
| Character on its own | 100% (3 of 3) | 100% (2 of 2) | 40% (2 of 5) | 70% (7 of 10) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 75% (3 of 4) | 0% (0 of 1) | - | 60% (3 of 5) |
| Monster | 0% (0 of 1) | 100% (3 of 3) | - | 75% (3 of 4) |
| Monstrous | - | 50% (2 of 4) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 50% | 83% (5 of 6) | 42% | 71% (5 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 50% (1 of 2); on the table 100% | 33% (4 of 12) | 0% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 80% (4 of 5); on the table 80% | 50% (3 of 6) | 12% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 2 | 44% (4 of 9); on the table 44% | 50% (6 of 12) | 24% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 22% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p46, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 22% (2) | 67% (8) | 48% (10) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p46

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 70% (7 of 10) | 64% (9 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 10% (1 of 10) | 0% (0 of 2) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 100% (5 of 5) | 50% (2 of 4) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 80% (8 of 10) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 0.7 | 1.3 |
| Movement | Points that never moved of their own | 163.3 | 56.7 |
| Movement | Fights charged into per game | 4.7 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 8, net +0 | 1 of 10, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 8, net +0 | 1 of 10, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 8, net +95 | 2 of 10, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 8, net +186 | 5 of 10, net +105 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 71% (20 of 28) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.7 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (4 of 8) | 67% (2 of 3) |
| Magic | Wounds caused by magic missiles | 2.3 | - |
| Magic | Wounds caused by other spells | 0.7 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 1.0 / 0.0 | 1.3 / 0.0 / 1.0 / 0.3 |
| Combat | Points destroyed in combat | 488.0 | 361.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +79 | +40 |
| Combat | Net per 100 charger points, damage counted | +47.7 | +16.7 |
| Combat | First round won (charged fights) | 64% | 45% |
| Combat | Net points per charged fight | +77 | +48 |
| Combat | Net points per supported fight / lone fight | - / +77 | +35 / +49 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 14 | 4 of 11 |
| Game | Points lost | 523.7 | 476.3 |
| Game | VP from objectives | 720.0 | 626.7 |
| Game | Lone holders (player turns) | 1.0 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +77 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1000
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: nw22-19bea9b-p46

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.0 | +69.4 | 0.0 | 0.0 | 0.3 | +51.9 | 0.0 | 0.0 |
| ARMY TABLE | 19.0 | +66.8 | 0.0 | 299.3 | 21.7 | +561.7 | 0.0 | 170.0 |
| ASSAILMENT BY POINTS | 0.7 | +7.6 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 3.0 | +89.9 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.7 | +37.2 | 62.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +57.4 | 0.0 | 23.3 | 0.3 | +8.1 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +35.6 | 0.0 | 0.0 | 1.3 | +31.2 | 0.0 | 50.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -13.9 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.7 | -13.1 | 0.0 | 76.0 | 2.0 | -52.1 | 0.0 | 28.3 |
| CHARGE LOSSES | 9.3 | -949.3 | 0.0 | 270.3 | 12.3 | -384.7 | 0.0 | 33.3 |
| CHARGE NOT DECLARED | 1.3 | +0.0 | 80.0 | 0.0 | 0.3 | +0.0 | 85.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 25.0 | 0.0 | 3.7 | +0.0 | 85.0 | 62.0 |
| CLEAR LANE AHEAD | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 0.0 | 18.0 | +0.0 | 0.0 | 96.7 |
| COMBAT PIVOT | 1.7 | +0.0 | 62.0 | 70.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.7 | +328.0 | 0.0 | 0.0 | 1.0 | +23.3 | 0.0 | 0.0 |
| COVER ONCE | 2.0 | -61.4 | 0.0 | 0.0 | 5.0 | -226.5 | 0.0 | 50.0 |
| DEFENSIVE FLOOR | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -0.8 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -91.2 | 0.0 | 0.0 | 6.7 | +43.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -21.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +3.1 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +0.5 | 25.0 | 0.0 | 3.0 | +5.8 | 163.3 | 124.0 |
| FACES WHAT IT FOLLOWS | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 73.0 | 76.0 | 3.0 | +5.9 | 85.0 | 62.0 |
| FALLS SHORT | - | - | - | - | 22.3 | +272.8 | 0.0 | 225.0 |
| FEATURE BUFFS | 2.3 | +139.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +10.2 | 0.0 | 76.0 | 2.0 | +19.6 | 0.0 | 62.0 |
| FIVE ACTION | 86.3 | +5663.8 | 259.0 | 963.7 | 78.7 | +5688.9 | 163.3 | 788.3 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 45.0 | 4.0 | +0.0 | 0.0 | 51.3 |
| FOLLOW UP WEIGHED | 2.0 | +168.7 | 0.0 | 0.0 | 1.7 | +247.0 | 0.0 | 62.0 |
| FOUR ROUNDS | 3.7 | +204.2 | 197.0 | 76.0 | 5.7 | +344.1 | 163.3 | 152.3 |
| FREED FROM HIS FIGHT | 15.0 | +0.0 | 0.0 | 213.7 | 3.0 | +0.0 | 0.0 | 66.7 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -5.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -7.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.3 | -7.7 | 33.0 | 76.0 | 0.3 | -1.0 | 0.0 | 62.0 |
| GOAL WALK | 12.3 | +1043.0 | 0.0 | 85.0 | 11.3 | +1448.7 | 0.0 | 0.0 |
| GUN FIGURES | 4.0 | +8.3 | 56.7 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.0 | +0.4 | 0.0 | 76.0 | 2.3 | -4.2 | 78.3 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 7.0 | +0.0 | 0.0 | 21.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 142.3 | 4.3 | +0.0 | 0.0 | 33.3 |
| HIS CHARGE DENIED | 0.3 | +0.9 | 15.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 6.3 | +0.0 | 0.0 | 198.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -1.4 | 0.0 | 0.0 | 5.0 | -131.6 | 0.0 | 30.0 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 33.3 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 3.7 | +0.0 | 0.0 | 192.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 9.3 | +84.9 | 0.0 | 411.0 | 40.3 | +944.0 | 0.0 | 522.7 |
| HIS SHOTS BY HIS RUN | 11.3 | +34.6 | 0.0 | 70.0 | 29.3 | +349.4 | 0.0 | 133.3 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +5.5 | 0.0 | 0.0 |
| HOLD ODDS | 21.3 | +0.0 | 0.0 | 256.0 | 10.3 | +0.0 | 0.0 | 326.7 |
| HOLDER ASSIGNMENT | 11.3 | +946.6 | 0.0 | 128.0 | 6.3 | +662.7 | 0.0 | 163.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -66.7 | 197.0 | 76.0 | 4.7 | -129.0 | 163.3 | 152.3 |
| IDLE COST | - | - | - | - | 12.7 | -146.9 | 0.0 | 93.0 |
| JOINT CHARGE NOW | 0.3 | +13.0 | 0.0 | 0.0 | 1.3 | +36.4 | 0.0 | 62.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.9 | 0.0 | 0.0 | 1.3 | +43.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 8.7 | +0.0 | 319.0 | 306.3 | 7.7 | +0.0 | 300.3 | 444.7 |
| LONG SHOT | 0.7 | +5.9 | 15.0 | 76.0 | 0.3 | +5.7 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -1.0 | 0.0 | 76.0 | 3.7 | +48.7 | 78.3 | 90.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +1.8 | 0.0 | 15.0 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 143.3 |
| MARCH AT ESCAPER | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +21.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +20.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +21.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -18.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +16.0 | 0.0 | 23.3 | 3.3 | +93.6 | 0.0 | 30.0 |
| MEETS IN TIME | 4.7 | +279.3 | 0.0 | 0.0 | 2.7 | +216.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +141.1 | 0.0 | 0.0 | 2.7 | +7.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.3 | +71.2 | 0.0 | 0.0 | 3.3 | +4.9 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 20.0 | 25.0 |
| MOVE SPELL IN RANGE | 2.0 | +51.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.3 | -81.6 | 204.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.0 | +420.8 | 0.0 | 0.0 | 8.0 | +562.7 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEAR WALKS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.3 | +320.7 | 0.0 | 23.3 | 5.7 | +221.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +300.9 | 0.0 | 0.0 | 5.7 | +443.1 | 0.0 | 0.0 |
| NO CHAFF EDGES | 3.7 | +56.3 | 117.0 | 11.7 | 2.3 | +30.0 | 11.7 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -29.3 | 120.0 | 0.0 | 5.0 | -273.9 | 163.3 | 152.3 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.0 | -2.8 | 0.0 | 0.0 | 2.0 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 2.3 | -205.0 | 0.0 | 76.0 | 3.3 | -150.5 | 0.0 | 16.7 |
| ONE CHALLENGE TEST | 0.3 | -2.0 | 0.0 | 76.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -45.0 | 0.0 | 0.0 | 7.3 | -193.6 | 0.0 | 158.3 |
| ONE JOINT FIGURE | 0.3 | +2.1 | 0.0 | 0.0 | 0.3 | -4.8 | 0.0 | 62.0 |
| ONE OBJECTIVE FORMULA | 4.0 | +62.5 | 0.0 | 64.0 | 3.3 | -17.7 | 0.0 | 163.3 |
| ONE PROMISE A TARGET | 1.0 | -16.4 | 0.0 | 0.0 | 0.7 | +69.1 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +27.3 | 15.0 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 1.0 | +58.7 | 102.0 | 0.0 | 0.3 | +3.7 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +65.1 | 33.0 | 0.0 | 2.3 | +28.6 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +23.6 | 0.0 | 0.0 |
| PLAN RESULT | 43.0 | +184.9 | 0.0 | 735.0 | 41.0 | +245.6 | 40.0 | 816.0 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 62.0 |
| PROMISE BY ITS OWN SUM | 6.7 | -294.2 | 0.0 | 0.0 | 12.7 | -261.5 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 4.3 | -71.6 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 21.7 | +2194.5 | 80.0 | 235.0 | 18.0 | +2296.8 | 78.3 | 33.3 |
| RANDOM MOVE BY FIGURES | 3.0 | +3.7 | 0.0 | 140.0 | 1.7 | +35.9 | 0.0 | 0.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | -84.7 | 0.0 | 46.7 | - | - | - | - |
| REDIRECT COUNTER | 4.3 | +156.8 | 0.0 | 23.3 | 4.3 | +341.1 | 0.0 | 45.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +85.1 | 0.0 | 46.7 | 2.7 | +0.0 | 0.0 | 50.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 62.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.7 | -28.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.7 | +0.0 | 0.0 | 76.0 | 0.7 | +0.0 | 0.0 | 143.3 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +73.3 | 135.0 | 76.0 | 4.7 | -12.6 | 0.0 | 152.3 |
| RISK ON THE WAY | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -55.4 | 78.3 | 62.0 |
| RUN DOWN | - | - | - | - | 4.7 | -105.6 | 163.3 | 152.3 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.0 | +7.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -33.9 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.0 | +46.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +5.4 | 0.0 | 76.0 | 1.0 | +80.7 | 0.0 | 62.0 |
| SELF MOVE SPELL | 2.0 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -17.8 | 0.0 | 0.0 | 6.7 | -697.2 | 0.0 | 336.7 |
| SET UP BY THE SET | 0.3 | +17.8 | 0.0 | 0.0 | 9.0 | +562.6 | 0.0 | 372.7 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.8 | 0.0 | 15.0 |
| SET-UP MISSED | 0.3 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 23.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +9.7 | 0.0 | 0.0 | 1.0 | +2.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 3.7 | -0.1 | 0.0 | 0.0 | 28.3 | -170.8 | 0.0 | 233.3 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 7.7 | +139.8 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +3.4 | 0.0 | 0.0 | 2.0 | +18.0 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +2.3 | 85.0 | 0.0 |
| SPOT AS THE GAME MOVES | 10.7 | +0.0 | 0.0 | 251.7 | 14.0 | +0.0 | 0.0 | 238.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -4.9 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 30.0 | +0.0 | 62.0 | 326.7 | 14.0 | +0.0 | 0.0 | 46.7 |
| STAY WORTH | 9.0 | +63.4 | 62.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 1.7 | +73.0 | 286.7 | 76.0 | 1.7 | +35.9 | 0.0 | 16.7 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -2.7 | 0.0 | 0.0 |
| STUCK PIVOT | 1.0 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.3 | +357.5 | 0.0 | 362.7 | 7.7 | +297.8 | 0.0 | 100.0 |
| SUPPORT WORKED OUT | 6.3 | +357.5 | 0.0 | 362.7 | 7.7 | +297.8 | 0.0 | 100.0 |
| SURE REACH TOGETHER | - | - | - | - | 3.3 | +63.4 | 0.0 | 191.3 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 1.0 | +3.8 | 0.0 | 38.3 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.0 | +1.3 | 0.0 | 76.0 | 2.7 | +16.9 | 78.3 | 28.3 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 20.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 25.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 64.0 | 2.0 | +0.0 | 0.0 | 20.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 64.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.3 | +0.0 | 0.0 | 273.0 | 37.3 | +0.0 | 0.0 | 174.7 |
| TIED UP BY THE SUM | 1.0 | +101.6 | 58.0 | 0.0 | 1.0 | +100.4 | 0.0 | 90.3 |
| TIME ON OUR SIDE | 42.3 | +426.9 | 0.0 | 236.3 | - | - | - | - |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 286.7 |
| WHAT THE JOINER ADDS | 2.0 | +47.4 | 124.0 | 152.0 | 0.7 | -6.1 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 2.0 | +21.1 | 78.3 | 62.0 |
| WHO GETS IN | - | - | - | - | 0.3 | +5.3 | 0.0 | 62.0 |
| WHO HITS BACK | 0.7 | +88.4 | 0.0 | 0.0 | 0.3 | +30.8 | 0.0 | 0.0 |
| WHOLE FIGHT | 1.0 | -55.1 | 62.0 | 76.0 | 0.3 | +7.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 7.3 | -912.0 | 0.0 | 270.3 | 0.3 | -8.6 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +4.0 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 2.7 | +201.6 | 90.3 | 78.3 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +74.1 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p46

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 122 | 122 | 62 | 20.67 | +2084 | +33.6 |
| HOLDER ASSIGNMENT | 53 | 53 | 50 | 16.67 | +4294 | +85.9 |
| LEGAL CHARGES ONLY | 49 | 49 | 49 | 16.33 | +0 | +0.0 |
| HIS SHOT LIST | 149 | 142 | 32 | 10.67 | +242 | +7.6 |
| DEPLOY BY FIGURES | 42 | 42 | 26 | 8.67 | +278 | +10.7 |
| FIVE ACTION | 495 | 477 | 25 | 8.33 | +1270 | +50.8 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 122 | 120 | 22 | 7.33 | +226 | +10.3 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +236 | +11.8 |
| NO CHAFF EDGES | 18 | 18 | 17 | 5.67 | +162 | +9.5 |
| OFF BEST | 17 | 17 | 17 | 5.67 | -1066 | -62.7 |
| PROMISE BY ITS OWN SUM | 58 | 58 | 17 | 5.67 | -1668 | -98.1 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| GOAL WALK | 71 | 68 | 15 | 5.00 | +1384 | +92.3 |
| QUARTER ODDS | 119 | 115 | 15 | 5.00 | +544 | +36.3 |
| FOUR ROUNDS | 28 | 26 | 14 | 4.67 | +364 | +26.0 |
| TIME ON OUR SIDE | 127 | 110 | 14 | 4.67 | +38 | +2.7 |
| MOVE TO CHARGE COMPUTED | 39 | 33 | 13 | 4.33 | +549 | +42.2 |
| IDLE COST | 38 | 28 | 12 | 4.00 | +51 | +4.2 |
| FOLLOW UP WEIGHED | 11 | 11 | 11 | 3.67 | +1247 | +113.4 |
| SHOT RISK POINTS | 96 | 94 | 11 | 3.67 | +217 | +19.7 |
| SUPPORT ADDS | 42 | 39 | 11 | 3.67 | +567 | +51.5 |
| SUPPORT WORKED OUT | 42 | 39 | 11 | 3.67 | +567 | +51.5 |
| STRIKE BY THE ODDS | 10 | 10 | 10 | 3.33 | +327 | +32.7 |
| MEETS IN TIME | 22 | 22 | 9 | 3.00 | +676 | +75.2 |
| NEXT CHARGE BY LIST | 27 | 26 | 8 | 2.67 | +375 | +46.9 |
| SET UP BY THE SET | 28 | 26 | 8 | 2.67 | +507 | +63.4 |
| CAST JOB | 7 | 7 | 7 | 2.33 | +36 | +5.1 |
| RANDOM MOVE BY FIGURES | 14 | 14 | 7 | 2.33 | +119 | +17.0 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +200 | +33.4 |
| CHARGE NOW FIRST | 13 | 13 | 6 | 2.00 | -294 | -49.0 |
| FACES WHAT IT FOLLOWS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| RISK BY ARC | 22 | 21 | 6 | 2.00 | +90 | +15.1 |
| WHOLE FIGHT DANGER | 23 | 23 | 6 | 2.00 | +277 | +46.2 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| BACKS UP THE FIGHT | 11 | 10 | 5 | 1.67 | +174 | +34.9 |
| CHARGE LOSSES | 65 | 63 | 5 | 1.67 | +448 | +89.5 |
| CHARGE NOT DECLARED | 5 | 5 | 5 | 1.67 | -941 | -188.2 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +148 | +29.6 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +150 | +29.9 |
| MAX FOR POSITIONING | 19 | 18 | 5 | 1.67 | +2 | +0.5 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | +158 | +31.6 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +147 | +29.4 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 1.33 | +364 | +91.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 67 | 53 | 4 | 1.33 | +2 | +0.5 |
| FEATURE BUFFS | 7 | 7 | 4 | 1.33 | +158 | +39.6 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +258 | +64.6 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 4 | 1.33 | +7 | +1.7 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +24 | +7.9 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT COUNTER | 26 | 24 | 3 | 1.00 | +31 | +10.2 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +139 | +46.4 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SURE REACH TOGETHER | 10 | 9 | 3 | 1.00 | +5 | +1.8 |
| SWIFTSTRIDE BY POINTS | 3 | 3 | 3 | 1.00 | +12 | +3.8 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +160 | +53.3 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 2 | 0.67 | +37 | +18.5 |
| EXACT ROUND | 13 | 12 | 2 | 0.67 | +6 | +3.0 |
| FIGHT TO THE END | 9 | 8 | 2 | 0.67 | +51 | +25.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +65 | +32.7 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -66 | -32.8 |
| MISSILES NEXT TURN | 23 | 14 | 2 | 0.67 | +3 | +1.6 |
| NEARER NOT NEEDED | 39 | 33 | 2 | 0.67 | +67 | +33.7 |
| OPENS UP IN FULL | 4 | 4 | 2 | 0.67 | +8 | +4.0 |
| PROMISE KNOWS THE FIGHT | 19 | 17 | 2 | 0.67 | -215 | -107.3 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +95 | +47.6 |
| STAY WORTH | 29 | 23 | 2 | 0.67 | +29 | +14.6 |
| WHAT THE JOINER ADDS | 8 | 6 | 2 | 0.67 | +4 | +2.2 |
| WOUNDS ON THE RANKS | 10 | 10 | 2 | 0.67 | +131 | +65.5 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARACTERS BY THEIR POINTS | 8 | 7 | 1 | 0.33 | +12 | +11.7 |
| COVER ONCE | 21 | 15 | 1 | 0.33 | +0 | +0.0 |
| LONG SHOT | 3 | 2 | 1 | 0.33 | +26 | +26.1 |
| LOST AFTER ESCAPE | 14 | 12 | 1 | 0.33 | +59 | +59.1 |
| MISSILES IN THE MOVE | 20 | 11 | 1 | 0.33 | +86 | +85.8 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 21 | 20 | 1 | 0.33 | +8 | +8.0 |
| OVERRUNS AWAY | 9 | 9 | 1 | 0.33 | +179 | +179.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +71 | +70.9 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +16 | +16.2 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.5 |
| REFUSING RETIRES | 7 | 7 | 1 | 0.33 | -1 | -0.6 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| THE FIGHT MOVES | 11 | 10 | 1 | 0.33 | +6 | +6.1 |
| THE ROW IN ITS ORDER | 28 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +16 | +15.9 |
| WHOLE FIGHT | 4 | 3 | 1 | 0.33 | +3 | +3.2 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 84 | 81 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 11 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 14 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 54 | 52 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 10 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 22 | 21 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 37 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 18 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 21 | 21 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 28 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 36 | 34 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HOLD ODDS | 95 | 95 | 0 | 0.00 | - | - |
| HONEST WORTH | 25 | 24 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| NEAR WALKS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 15 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 35 | 21 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 22 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 252 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 21 | 19 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 16 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 24 | 17 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 74 | 62 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 132 | 128 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 12 | 10 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 227 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p46

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 3.67 | 98.1 |
| ARMY TABLE | rule | 2.33 | 2.00 | 59.5 |
| JOB FIRST | gate | 1.33 | 2.33 | 61.1 |
| CHARGE NOW FIRST | rule | 0.33 | 1.67 | 49.0 |
| CHARGE NOT DECLARED | rule | 1.33 | 0.33 | 188.2 |
| ONE PROMISE A TARGET | rule | 1.00 | - | 16.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | 0.33 | 131.4 |
| MARCH OF THE TABLE | rule | 0.67 | - | 32.8 |
| NO REASON | gate | 0.67 | - | 43.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 107.3 |
| AFTERMATH BAND | gate | - | 0.33 | 2.7 |
| JOINT CHARGE NOW | rule | - | 0.33 | 7.0 |
| REFUSING RETIRES | rule | 0.33 | - | 0.6 |
| RULE SWITCHED OFF | gate | - | 0.33 | 41.6 |

### Plans: nw22-19bea9b-p46

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 67% | 340 | 135 | 40% |
| Mine | move | 37.3 | 95% | 2171 | 0 | 0% |
| Mine | shoot | 2.0 | 33% | 157 | 50 | 32% |
| Mine | support | 0.7 | 50% | 43 | 0 | 0% |
| Opponent | charge | 5.0 | 40% | 689 | 246 | 36% |
| Opponent | join | 2.7 | 100% | 100 | 0 | 0% |
| Opponent | move | 32.7 | 95% | 2197 | 0 | 0% |
| Opponent | shoot | 0.3 | 0% | 44 | 0 | 0% |
| Opponent | support | 0.3 | 0% | 2 | 0 | 0% |

### Battle groups: nw22-19bea9b-p46

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 15% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 46% | 67% | 0% | - | 17% | 0% | 17% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p46

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 180 (7) | 28 | 152 | 0 | 14% | 4.0 | 186 (4) | 450 (1) | 0 (2) | 143 (6) | 450 (1) |
| Mine | Character | 6 | 37 (6) | 37 | 0 | 31 | 0% | 2.3 | 50 (2) | 0 (2) | 103 (1) | 80 (3) | 0 (2) |
| Mine | Clean-up | 2 | 0 (2) | 0 | 0 | 83 | 0% | 4.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Fast Hammer | 1 | 169 (1) | 169 | 0 | 0 | 0% | 3.0 | 169 (1) | - | - | 169 (1) | - |
| Mine | Hammer | 11 | 18 (11) | 13 | 5 | 30 | 0% | 2.6 | 15 (3) | 41 (4) | 0 (4) | 10 (9) | 44 (2) |
| Mine | Holder | 2 | 79 (2) | 0 | 79 | 15 | 50% | 2.0 | - | 514 (1) | 0 (1) | 79 (2) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 33 | 33% | 2.5 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 17 | 0% | 2.8 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 18 (9) | 0 | 18 | 50 | 33% | 3.5 | 0 (7) | 100 (2) | - | 24 (7) | 0 (2) |
| Opponent | Character | 10 | 31 (10) | 31 | 0 | 17 | 10% | 4.0 | 58 (5) | 0 (4) | - | 22 (4) | 41 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 8 | 38 (8) | 20 | 17 | 42 | 0% | 4.1 | 53 (2) | 36 (5) | 0 (1) | 44 (4) | 31 (4) |
| Opponent | Hammer | 2 | 91 (2) | 78 | 12 | 0 | 50% | 2.0 | - | 228 (1) | 19 (1) | 228 (1) | 19 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.7 | 0 (3) | 0 (1) | - | 0 (2) | 0 (2) |

### Charged fights: nw22-19bea9b-p46

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 391 | 7.0 | 1.0 | 56 | 33 | +23 | 2 of 7 | 4 of 7 | - | +23 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 1073 | 7.0 | 1.0 | 153 | 22 | +131 | 0 of 7 | 5 of 7 | - | +131 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 0 | 488 | 4.7 | 1.0 | 105 | 27 | +77 | 2 of 14 | 9 of 14 | - | +77 |
| Opponent | Vampire Counts | 2 | 0 | 245 | 3.5 | 1.0 | 70 | 0 | +70 | 3 of 7 | 3 of 7 | - | +70 |
| Opponent | Warriors of Chaos | 1 | 0 | 35 | 4.0 | 1.2 | 9 | 0 | +9 | 1 of 4 | 2 of 4 | +35 | +0 |
| **Opponent** | all armies | 3 | 0 | 175 | 3.7 | 1.1 | 48 | 0 | +48 | 4 of 11 | 5 of 11 | +35 | +49 |

### Effective charges: nw22-19bea9b-p46

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 7 | 1 (net +0) | 0 | 0 | 0 | 1 (net +205) | 1 (net +186) | 4 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +0) | 0 | 3 (net +58) | 1 (net +186) | 2 | 20% (1 of 5) |
| Opponent | Vampire Counts | 7 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 0 | 4 (net +122) | 0 | 14% (1 of 7) |
| Opponent | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 2 (net +0) | 1 (net +35) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: nw22-19bea9b-p46

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 90 | 380 | +0 | 32 | 18 | +14 | +15.2 |
| Mine | Effective (55-75%) | 1 | 60 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 195 | 186 | +186 | 186 | 1 | +185 | +94.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 337 | 55 | +95 | 109 | 0 | +109 | +32.5 |
| Mine | No odds | 6 | 73 | 138 | +55 | 119 | 71 | +48 | +65.4 |
| Mine | All fights | 14 | 166 | 142 | +77 | 111 | 32 | +79 | +47.7 |
| Opponent | Long shot (under 50%) | 1 | 186 | 185 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 1 | 186 | 235 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 186 | 251 | +0 | 63 | 0 | +63 | +33.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 331 | 200 | +105 | 131 | 43 | +88 | +26.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 122 | 38 | +0 | 0 | 30 | -30 | -25.0 |
| Opponent | No odds | 1 | 205 | 210 | +0 | 140 | 137 | +3 | +1.6 |
| Opponent | All fights | 11 | 242 | 178 | +48 | 78 | 37 | +40 | +16.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p46 | move | 21 | 9 (43%) | 7 (33%) | 2 (10%) | 10 (48%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

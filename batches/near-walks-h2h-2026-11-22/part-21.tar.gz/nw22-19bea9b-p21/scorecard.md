# Doctrine scorecard: nw22-19bea9b-p21

### Scorecard: nw22-19bea9b-p21

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 2 | 2 | 9 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 280 |
| L1629 | 3 | 1 | Opponent | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | no | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.0 | 1.7 | 5.0 | 0.3 | 0.3 | 0.0 | 0.0 | 93.3 |
| **Average** | | | Opponent | 33% | 1.5 | 1.7 | 4.3 | 1.7 | 0.3 | 0.0 | 0.0 | 113.3 |

### KPIs: nw22-19bea9b-p21

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 6% (1 of 17) | 0% (0 of 16) | 3% (1 of 33) |
| Winner chose to follow up after the loser gave ground |  | 75% (6 of 8); on the table 75% | 100% (2 of 2); on the table 100% | 80% (8 of 10); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 67% (4 of 6); on the table 67% | 50% (2 of 4); on the table 50% | 60% (6 of 10); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 71% (10 of 14); on the table 71% | 67% (4 of 6); on the table 67% | 70% (14 of 20); on the table 70% |
| Magic missiles tried each own turn | 50%+ | - | 42% (5 of 12) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 56% (5 of 9) | 56% (5 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 70% (7 of 10) | 70% (7 of 10) |
| Points that never fought | lower | 34% (2062 of 6000) | 34% (2046 of 5999) | 34% (4108 of 11999) |
|   infantry points that never fought | lower | 58% (778 of 1332) | 65% (553 of 855) | 61% (1331 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 45% (9 of 20) | 76% (19 of 25) | 62% (28 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 100% (1 of 1); 1.7 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 40% (2034 of 5135) | 63% (3437 of 5430) | 52% (5471 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.7 (29%) | 0.7 (29%) |
| MARCHED: its unit marched | - | 0.7 (29%) | 0.7 (29%) |
| FLEEING: fleeing | - | 0.3 (14%) | 0.3 (14%) |
| GONE: slain | - | 0.7 (29%) | 0.7 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.0 | 0.7 | 1.7 | 0.7 |
| not cast | 6.7 | 1.0 | 1.3 | 2.3 | 19.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) |
| GONE: slain | 1.3 (20%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (75%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.3 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 51% (42 of 83) | 0% (0 of 11) | 45% (42 of 94) |
|   cavalry | 67% (2 of 3) | 0% (0 of 5) | 25% (2 of 8) |
|   character | 50% (6 of 12) | 0% (0 of 6) | 33% (6 of 18) |
|   chariot | 17% (1 of 6) | - | 17% (1 of 6) |
|   infantry | 55% (21 of 38) | - | 55% (21 of 38) |
|   monster | 29% (5 of 17) | - | 29% (5 of 17) |
|   war machine | 100% (7 of 7) | - | 100% (7 of 7) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (29%) | 0.7 (18%) | 4.7 (27%) |
| CHARGED: it charged | 2.0 (15%) | 1.0 (27%) | 3.0 (17%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 1.0 (27%) | 1.0 (6%) |
| IN COMBAT: it fought this turn or the last | 2.0 (15%) | 0.0 (0%) | 2.0 (12%) |
| NO TARGET IN RANGE | 2.0 (15%) | 0.3 (9%) | 2.3 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 3.0 (22%) | 0.0 (0%) | 3.0 (17%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (5%) | 0.3 (9%) | 1.0 (6%) |
| OTHER BAR | 0.0 (0%) | 0.3 (9%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 2.3 | 0.7 | 86% | 8.1 pts | 19 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 12.0 | 1.7 | 89% | 4.2 pts | 51 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 2.3 | 2.0 | 57% | 36.2 pts | 85 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 6.0 | 5.8 |
| Charges that made contact a game | 4.7 | 4.7 | 4.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 3.00 declared, 3.00 contact (1 units) | 0.80 declared, 0.80 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.80 declared, 0.65 contact (20 units) | 0.68 declared, 0.50 contact (22 units) | 0.74 declared, 0.57 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (5 of 5) | 67% (2 of 3) | 0% (0 of 2) | 70% (7 of 10) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 100% (5 of 5) | 50% (1 of 2) | 44% (4 of 9) | 62% (10 of 16) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 57% (4 of 7) | 0% (0 of 3) | - | 40% (4 of 10) |
| Monster | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 50% (2 of 4); on the table 50% | - | 48% | 29% (2 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 80% (4 of 5); on the table 80% | - | 39% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 80% (4 of 5); on the table 80% | - | 16% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (4 of 6); on the table 67% | 67% (4 of 6) | 28% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | - | 17% (1 of 6) | 37% | 79% (15 of 19) | 100% (1 of 1); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p21, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 29% (2) | 75% (9) | 58% (11) |
| ...free all their last turn and able to turn (per game) | 0.00 | 2.00 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 1.00 | 1.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.33 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p21

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 64% (9 of 14) | 35% (6 of 17) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (8 of 19) | 0% (0 of 4) |
| Strategy | Support requests answered (helper made contact too) | - | 67% (2 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | - | 33% (1 of 3) |
| Strategy | Lone characters that fought | 78% (7 of 9) | 70% (7 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 1.7 |
| Movement | Points that never moved of their own | 93.3 | 113.3 |
| Movement | Fights charged into per game | 4.7 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 10 | 3 of 9, net +404 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 10 | 0 of 9 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 10, net +137 | 2 of 9, net +92 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 of 10, net +105 | 2 of 9, net +70 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (14 of 36) | - |
| Shooting | Points destroyed by shooting units | 56.7 | 0.0 |
| Shooting | War machine shots | 2.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (4 of 7) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 2.3 | - |
| Magic | Points destroyed by magic (all spells) | 38.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.7 / 0.0 / 0.0 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 245.3 | 446.7 |
| Combat | Points run down | 80.7 | 226.3 |
| Combat | Net points per charged fight, damage counted | +85 | +171 |
| Combat | Net per 100 charger points, damage counted | +25.1 | +54.8 |
| Combat | First round won (charged fights) | 93% | 50% |
| Combat | Net points per charged fight | +82 | +163 |
| Combat | Net points per supported fight / lone fight | - / +82 | +26 / +190 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 14 | 6 of 12 |
| Game | Points lost | 718.3 | 753.7 |
| Game | VP from objectives | 706.7 | 440.0 |
| Game | Lone holders (player turns) | 1.0 | 1.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +254 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 1472
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p21

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +51.7 | 0.0 | 112.0 | - | - | - | - |
| ARMY TABLE | 23.7 | +314.1 | 0.0 | 73.7 | 16.3 | -282.0 | 0.0 | 210.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 0.7 | +10.4 | 0.0 | 0.0 | 0.7 | +3.3 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 2.3 | +0.0 | 0.0 | 66.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.0 | +5.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +59.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +7.0 | 0.0 | 0.0 | 1.0 | +10.9 | 0.0 | 16.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.7 | -99.8 | 157.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 1.0 | -7.6 | 67.0 | 0.0 | 0.7 | +4.4 | 47.0 | 16.7 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +91.2 | 157.0 | 0.0 |
| CHARGE LOSSES | 9.0 | -258.6 | 0.0 | 0.0 | 9.3 | -860.0 | 0.0 | 447.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 47.0 | 0.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 356.0 | 0.0 | 3.0 | +0.0 | 298.3 | 72.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 15.0 | +0.0 | 0.0 | 343.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 159.0 | 0.0 |
| COVER ONCE | 7.3 | -413.0 | 0.0 | 33.3 | 9.7 | -1307.7 | 0.0 | 160.0 |
| DENIED BY THE FIGHT | 0.7 | -2.5 | 0.0 | 157.0 | 1.0 | -5.8 | 168.3 | 0.0 |
| DEPLOY BY FIGURES | 6.3 | -5.6 | 0.0 | 0.0 | 6.3 | +70.2 | 0.0 | 15.0 |
| DUEL STOPS AT THE KILL | 0.3 | -64.7 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 1.0 | +123.2 | 163.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.3 | +33.4 | 313.3 | 292.0 | 3.3 | +19.0 | 428.0 | 62.0 |
| FACES WHAT IT FOLLOWS | 1.3 | +0.0 | 0.0 | 159.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 3.3 | +1.4 | 244.0 | 292.0 | 5.0 | +8.5 | 429.0 | 88.7 |
| FALLS SHORT | - | - | - | - | 18.7 | +246.8 | 0.0 | 419.3 |
| FEATURE BUFFS | 0.7 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | 0.7 | +5.3 | 0.0 | 20.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +1.2 | 40.7 | 0.0 | 2.0 | +37.7 | 209.7 | 62.0 |
| FIRE AND FLEE | 0.3 | +1.6 | 0.0 | 26.7 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 56.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 78.3 | +7882.1 | 963.7 | 634.3 | 68.3 | +4839.1 | 799.3 | 1062.7 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 310.0 |
| FOLLOW UP WEIGHED | 1.0 | +60.9 | 0.0 | 159.0 | 0.7 | +10.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.0 | +449.4 | 439.0 | 292.0 | 6.3 | +390.0 | 799.3 | 88.7 |
| FREED FROM HIS FIGHT | 4.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 150.0 |
| FRIEND SHOOTS FIRST | 1.0 | -23.9 | 0.0 | 0.0 | 1.3 | -24.8 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -20.2 | 0.0 | 135.0 | 0.7 | -15.5 | 135.0 | 0.0 |
| GOAL WALK | 8.3 | +879.4 | 0.0 | 0.0 | 5.3 | +498.4 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 1.0 | +0.2 | 88.7 | 157.0 | 2.0 | -6.3 | 431.7 | 62.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 130.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.0 | +0.0 | 166.3 | 16.7 |
| HELPER UNSEEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 135.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 390.7 |
| HIS CHARGE DENIED | 1.3 | +51.8 | 38.7 | 157.0 | 0.7 | +52.6 | 135.0 | 0.0 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 55.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 26.7 | 3.7 | +0.0 | 0.0 | 68.7 |
| HIS MOVE AND SHOT | 2.0 | -36.0 | 0.0 | 53.3 | 0.7 | -2.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 96.0 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 26.7 | 7.0 | +0.0 | 0.0 | 109.3 |
| HIS RANDOM MOVE | 11.3 | +0.0 | 0.0 | 53.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 8.0 | +112.5 | 0.0 | 47.0 | 27.0 | +565.7 | 0.0 | 814.7 |
| HIS SHOTS BY HIS RUN | 13.0 | +105.1 | 0.0 | 80.0 | 25.3 | +791.1 | 0.0 | 910.7 |
| HIS TURN DENIED | 0.3 | +10.5 | 65.0 | 0.0 | 1.0 | +43.3 | 94.3 | 0.0 |
| HOLD ODDS | 11.7 | +0.0 | 0.0 | 53.3 | 8.0 | +0.0 | 0.0 | 147.0 |
| HOLDER ASSIGNMENT | 7.7 | +805.9 | 0.0 | 26.7 | 5.0 | +398.4 | 0.0 | 107.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -138.7 | 343.0 | 135.0 | 4.7 | -220.3 | 530.3 | 62.0 |
| IDLE COST | - | - | - | - | 11.7 | -161.9 | 0.0 | 130.7 |
| JOINT CHARGE NOW | - | - | - | - | 2.0 | +10.5 | 122.0 | 10.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 1.0 | +81.8 | 0.0 | 0.0 | 1.0 | +16.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 15.0 | 758.7 | 4.0 | +0.0 | 47.0 | 186.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 67.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.7 | +0.7 | 128.7 | 0.0 | 3.0 | +17.9 | 506.3 | 62.0 |
| MAKE SURE TOGETHER | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.0 | -0.5 | 0.0 | 0.0 | 1.0 | +11.7 | 0.0 | 40.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +18.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +25.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | -8.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| MAX FOR POSITIONING | 2.0 | +24.0 | 0.0 | 0.0 | 5.3 | +175.1 | 0.0 | 41.7 |
| MEETS IN TIME | 3.7 | +208.2 | 0.0 | 0.0 | 2.0 | +143.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +36.7 | 0.0 | 0.0 | 3.0 | +28.6 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 3.3 | +23.3 | 0.0 | 0.0 | 4.0 | +32.1 | 0.0 | 65.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 40.0 | 40.7 |
| MOVE TO CHARGE COMPUTED | 10.0 | +847.5 | 0.0 | 0.0 | 9.7 | +1033.2 | 0.0 | 70.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.7 | +372.8 | 0.0 | 81.0 | 5.0 | +224.6 | 0.0 | 135.0 |
| NEXT CHARGE BY LIST | 4.7 | +416.1 | 0.0 | 0.0 | 7.0 | +810.1 | 0.0 | 70.7 |
| NO CHAFF EDGES | 4.3 | +180.9 | 180.3 | 292.0 | 5.0 | +294.7 | 714.3 | 0.0 |
| NO DOUBLE ROUNDS | 5.0 | -219.0 | 439.0 | 292.0 | 4.0 | -215.4 | 368.0 | 62.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 40.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +5.8 | 0.0 | 112.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 1.7 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -132.0 | 0.0 | 250.3 | 5.3 | -277.0 | 166.3 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -85.3 | 157.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 40.7 |
| ONE FIGHT FORMULA | 7.3 | -218.3 | 0.0 | 0.0 | 6.7 | -117.0 | 0.0 | 118.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +0.6 | 0.0 | 10.0 |
| ONE OBJECTIVE FORMULA | 3.0 | -21.1 | 0.0 | 26.7 | 2.7 | +43.3 | 0.0 | 40.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -5.8 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +10.6 | 27.7 | 0.0 |
| OPENS UP IN FULL | 1.0 | +25.2 | 121.7 | 135.0 | 2.0 | +137.2 | 256.0 | 0.0 |
| OVERRUNS AWAY | 2.0 | +83.2 | 163.0 | 135.0 | 1.7 | +118.7 | 273.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +10.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.4 | 0.0 | 0.0 |
| PLAN RESULT | 36.3 | +914.8 | 188.7 | 1198.3 | 38.7 | +672.3 | 397.3 | 905.7 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +15.9 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 13.0 | -312.2 | 0.0 | 0.0 | 9.3 | -442.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | -13.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -11.9 | 0.0 | 0.0 | 0.7 | -7.6 | 0.0 | 0.0 |
| QUARTER ODDS | 20.3 | +2919.2 | 113.0 | 0.0 | 15.3 | +1634.9 | 603.7 | 112.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +168.6 | 0.0 | 113.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| REDIRECT COUNTER | 0.7 | +78.6 | 0.0 | 53.3 | 3.3 | +350.9 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 26.7 | 0.7 | +0.0 | 0.0 | 10.0 |
| REDIRECT WEIGHED | 0.7 | +38.1 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.0 | -128.2 | 0.0 | 0.0 | 2.3 | -75.7 | 0.0 | 40.7 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 27.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 4.3 | +47.7 | 343.7 | 292.0 | 6.0 | +127.0 | 664.3 | 88.7 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| ROUNDS AFTER TERROR | 0.7 | -13.0 | 132.0 | 0.0 | 1.7 | -46.2 | 88.7 | 16.7 |
| RUN DOWN | 3.3 | -142.3 | 347.3 | 157.0 | 4.0 | -80.3 | 575.7 | 62.0 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -65.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +4.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +59.6 | 0.0 | 157.0 | 0.7 | +36.4 | 166.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | +117.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.7 | -50.4 | 0.0 | 26.7 | 0.3 | -1.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +43.8 | 0.0 | 26.7 | 1.0 | -12.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +15.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 6.0 | +0.0 | 0.0 | 93.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +19.4 | 0.0 | 0.0 | 0.7 | +118.6 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -3.6 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 8.3 | -68.4 | 0.0 | 80.0 | 9.0 | -84.4 | 0.0 | 275.3 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 9.3 | +263.8 | 0.0 | 93.3 | 0.3 | +6.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +17.2 | 0.0 | 40.0 | 2.0 | +15.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -16.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 47.0 | 9.3 | +0.0 | 0.0 | 255.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -18.8 | 87.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 26.7 | +0.0 | 524.7 | 160.0 | 12.7 | +0.0 | 0.0 | 251.0 |
| STAY WORTH | 14.7 | -4.5 | 304.0 | 160.0 | - | - | - | - |
| STRIKE BY THE ODDS | 0.7 | +31.0 | 10.0 | 166.3 | 0.3 | +4.9 | 20.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.0 | +915.0 | 0.0 | 47.0 | 11.3 | +928.5 | 0.0 | 163.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 157.0 | 78.7 |
| SUPPORT WORKED OUT | 7.0 | +915.0 | 0.0 | 47.0 | 11.3 | +928.5 | 0.0 | 163.3 |
| SURE REACH TOGETHER | 1.0 | +4.8 | 0.0 | 0.0 | 0.7 | +0.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +1.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 26.7 | - | - | - | - |
| THE FIGHT MOVES | 2.0 | +16.1 | 243.7 | 0.0 | 1.7 | +51.5 | 306.0 | 62.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -2.3 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 10.0 | 40.7 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 155.7 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 40.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.3 | +0.0 | 0.0 | 147.7 | 33.0 | +0.0 | 0.0 | 449.7 |
| TIED UP BY THE SUM | 3.3 | +398.1 | 324.0 | 135.0 | 2.0 | +226.1 | 168.0 | 0.0 |
| TIME ON OUR SIDE | 33.3 | +443.3 | 30.0 | 107.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 47.0 | 5.0 | +0.0 | 0.0 | 33.3 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -93.1 | 426.7 | 0.0 |
| WHO FIGHTS | 0.7 | -6.6 | 96.0 | 0.0 | 1.0 | +8.7 | 112.0 | 62.0 |
| WHO HITS BACK | 1.7 | +240.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.7 | +26.7 | 213.3 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -181.9 | 0.0 | 0.0 | 4.7 | -678.9 | 0.0 | 390.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +27.4 | 27.7 | 10.0 |
| WHOLE FIGHT REACTION | 4.0 | +378.9 | 78.7 | 518.3 | 3.3 | +178.8 | 157.0 | 307.3 |
| WOUNDS ON THE RANKS | 1.0 | +4.8 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 134.0 |

### Rule changes: nw22-19bea9b-p21

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 120 | 120 | 79 | 26.33 | +129 | +1.6 |
| FIVE ACTION | 440 | 419 | 38 | 12.67 | +3239 | +85.2 |
| HOLDER ASSIGNMENT | 38 | 38 | 35 | 11.67 | +2012 | +57.5 |
| PROMISE BY ITS OWN SUM | 67 | 67 | 29 | 9.67 | -2262 | -78.0 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -1227 | -47.2 |
| LEGAL CHARGES ONLY | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 38 | 38 | 23 | 7.67 | +208 | +9.0 |
| MOVE TO CHARGE COMPUTED | 59 | 49 | 22 | 7.33 | +1119 | +50.9 |
| NO CHAFF EDGES | 28 | 28 | 22 | 7.33 | +1024 | +46.5 |
| HIS SHOT LIST | 105 | 99 | 19 | 6.33 | +183 | +9.6 |
| SUPPORT ADDS | 55 | 52 | 18 | 6.00 | +1318 | +73.2 |
| SUPPORT WORKED OUT | 55 | 52 | 18 | 6.00 | +1318 | +73.2 |
| FOUR ROUNDS | 34 | 31 | 16 | 5.33 | +804 | +50.3 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| QUARTER ODDS | 107 | 103 | 15 | 5.00 | +2334 | +155.6 |
| HIS SHOTS BY HIS RUN | 115 | 105 | 13 | 4.33 | +108 | +8.3 |
| NEXT CHARGE BY LIST | 35 | 33 | 13 | 4.33 | +891 | +68.5 |
| TIED UP BY THE SUM | 16 | 16 | 13 | 4.33 | +514 | +39.5 |
| GOAL WALK | 41 | 41 | 11 | 3.67 | +512 | +46.6 |
| COVER ONCE | 51 | 35 | 9 | 3.00 | +344 | +38.2 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MEETS IN TIME | 17 | 17 | 8 | 2.67 | +423 | +52.9 |
| TIME ON OUR SIDE | 100 | 83 | 8 | 2.67 | +13 | +1.7 |
| MAX FOR POSITIONING | 22 | 20 | 7 | 2.33 | +10 | +1.5 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 7 | 2.33 | +506 | +72.2 |
| RISK BY ARC | 31 | 28 | 7 | 2.33 | +199 | +28.4 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 7 | 2.33 | +40 | +5.8 |
| CAST JOB | 6 | 6 | 6 | 2.00 | +2 | +0.3 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| IDLE COST | 35 | 27 | 6 | 2.00 | +47 | +7.9 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +31 | +5.2 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +295 | +49.2 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +213 | +42.6 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +427 | +85.4 |
| BACKS UP THE FIGHT | 4 | 4 | 4 | 1.33 | +8 | +2.1 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +54 | +13.4 |
| CHARGE LOSSES | 55 | 51 | 4 | 1.33 | +163 | +40.7 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 6 | 5 | 4 | 1.33 | +98 | +24.6 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +713 | +178.3 |
| THE ROW IN ITS ORDER | 20 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 25 | 25 | 4 | 1.33 | +46 | +11.6 |
| WHOLE FIGHT REACTION | 22 | 22 | 4 | 1.33 | +44 | +10.9 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +88 | +29.4 |
| FALLS SHORT | 56 | 42 | 3 | 1.00 | +0 | +0.0 |
| OPENS UP IN FULL | 9 | 9 | 3 | 1.00 | +58 | +19.4 |
| OVERRUNS AWAY | 11 | 10 | 3 | 1.00 | +100 | +33.2 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REFUSING RETIRES | 5 | 5 | 3 | 1.00 | -43 | -14.3 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +288 | +95.9 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOT RISK POINTS | 52 | 45 | 3 | 1.00 | +21 | +7.1 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +108 | +35.9 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +155 | +77.5 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 17 | 17 | 2 | 0.67 | -113 | -56.4 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +35 | +17.6 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -77 | -38.3 |
| NO DOUBLE ROUNDS | 27 | 25 | 2 | 0.67 | +15 | +7.5 |
| PROMISE KNOWS THE FIGHT | 9 | 9 | 2 | 0.67 | -40 | -20.0 |
| SET UP BY THE SET | 10 | 9 | 2 | 0.67 | +172 | +85.9 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +6 | +2.8 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +23 | +11.6 |
| CANNON PLANNED TARGET | 7 | 7 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +274 | +273.5 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -20 | -20.3 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +149 | +149.0 |
| EXACT ROUND | 20 | 18 | 1 | 0.33 | +0 | +0.1 |
| FEATURE BUFFS | 2 | 2 | 1 | 0.33 | +4 | +4.3 |
| FIGHT TO THE END | 7 | 7 | 1 | 0.33 | +15 | +14.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +5 | +4.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | -20 | -19.5 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -18 | -17.6 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +30 | +30.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -7 | -7.2 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +48 | +47.6 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | +1 | +1.4 |
| REDIRECT COUNTER | 12 | 12 | 1 | 0.33 | +7 | +7.2 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +12 | +12.0 |
| SHOTS AFTER THE MOVES | 9 | 9 | 1 | 0.33 | +0 | +0.0 |
| STAY WORTH | 44 | 40 | 1 | 0.33 | +1 | +0.7 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 4 | 4 | 1 | 0.33 | -28 | -27.9 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 6 | 6 | 1 | 0.33 | +1 | +0.6 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 73 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 5 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 25 | 24 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 26 | 25 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 9 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 8 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 1 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 38 | 34 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 8 | 8 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 24 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 37 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 34 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HOLD ODDS | 59 | 59 | 0 | 0.00 | - | - |
| HONEST WORTH | 26 | 25 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 14 | 14 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 12 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 41 | 40 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 42 | 25 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 17 | 13 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 225 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 16 | 12 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 22 | 20 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 28 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 29 | 19 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 42 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 118 | 116 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 5 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE FIGHT MOVES | 11 | 10 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 208 | not checked | - | - | - | - |
| WAITS AGAIN | 19 | 16 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p21

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 5.33 | 4.67 | 58.8 |
| PROMISE BY ITS OWN SUM | rule | 6.00 | 3.67 | 78.0 |
| JOB FIRST | gate | 2.67 | 3.67 | 53.3 |
| JOINT CHARGE NOW | rule | - | 1.00 | 34.5 |
| REFUSING RETIRES | rule | 0.33 | 0.67 | 14.3 |
| CHARGE NOW FIRST | rule | - | 0.67 | 56.4 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 31.8 |
| MARCH OF THE TABLE | rule | - | 0.67 | 38.3 |
| NO REASON | gate | - | 0.67 | 91.7 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 20.0 |
| RULE SWITCHED OFF | gate | 0.67 | - | 8.4 |
| AFTERMATH BAND | gate | - | 0.33 | 2.5 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 20.3 |
| FIGHT ORDER BAND | gate | - | 0.33 | 1.2 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 9.5 |
| NO RALLY LEFT | rule | 0.33 | - | 19.5 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 17.6 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 7.2 |
| SUPPORT NARROWED | rule | - | 0.33 | 27.9 |

### Plans: nw22-19bea9b-p21

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.7 | 71% | 698 | 442 | 63% |
| Mine | move | 25.7 | 95% | 2114 | 0 | 0% |
| Mine | shoot | 6.0 | 72% | 433 | 473 | 109% |
| Opponent | charge | 5.7 | 71% | 726 | 672 | 93% |
| Opponent | join | 3.7 | 91% | 161 | 0 | 0% |
| Opponent | move | 28.0 | 87% | 1582 | 0 | 0% |
| Opponent | shoot | 1.0 | 0% | 119 | 0 | 0% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p21

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 100% | 100% | 50% | 100% | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 50% | 60% | 40% | 50% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p21

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 24 (3) | 24 | 0 | 0 | 0% | 3.0 | 24 (3) | - | - | 24 (3) | - |
| Mine | Chaff | 2 | 38 (2) | 0 | 38 | 100 | 0% | 1.5 | 75 (1) | 0 (1) | - | 75 (1) | 0 (1) |
| Mine | Character | 8 | 62 (8) | 62 | 0 | 55 | 12% | 3.4 | 46 (3) | 80 (4) | 44 (1) | 88 (5) | 13 (3) |
| Mine | Clean-up | 1 | 42 (1) | 0 | 42 | 0 | 100% | - | 42 (1) | - | - | 42 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 44 (4) | 44 | 0 | 0 | 25% | 1.7 | 58 (3) | 28 (1) | - | 58 (3) | 28 (1) |
| Mine | Hammer | 3 | 20 (3) | 11 | 9 | 49 | 0% | 1.3 | - | 20 (3) | - | 0 (1) | 26 (2) |
| Mine | Shooter | 6 | 55 (6) | 2 | 53 | 12 | 0% | 2.3 | 4 (2) | 99 (4) | - | 85 (3) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 50 | 20% | 2.8 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 55 (10) | 55 | 0 | 34 | 30% | 3.3 | 128 (4) | 36 (4) | 0 (1) | 94 (7) | 33 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 55 (6) | 55 | 0 | 28 | 33% | 2.8 | 18 (3) | 103 (3) | - | 15 (4) | 156 (2) |
| Opponent | Hammer | 5 | 38 (5) | 0 | 38 | 36 | 40% | 3.3 | 59 (3) | 0 (2) | - | 46 (4) | 0 (1) |
| Opponent | Holder | 4 | 12 (4) | 0 | 12 | 83 | 25% | 4.7 | 0 (1) | 17 (3) | - | - | 12 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 44 | 33% | 4.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: nw22-19bea9b-p21

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 286 | 974 | 8.0 | 1.0 | 122 | 0 | +122 | 2 of 8 | 8 of 8 | - | +122 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 122 | 3.0 | 1.0 | 41 | 80 | -39 | 1 of 3 | 2 of 3 | - | -39 |
| Mine | Lizardmen | 1 | 0 | 291 | 3.0 | 1.0 | 97 | 0 | +97 | 0 of 3 | 3 of 3 | - | +97 |
| **Mine** | all armies | 3 | 95 | 462 | 4.7 | 1.0 | 99 | 17 | +82 | 3 of 14 | 13 of 14 | - | +82 |
| Opponent | Vampire Counts | 1 | 0 | 1128 | 8.0 | 1.1 | 141 | 6 | +135 | 4 of 8 | 4 of 8 | +83 | +142 |
| Opponent | Warriors of Chaos | 2 | 0 | 454 | 2.0 | 1.2 | 227 | 8 | +219 | 2 of 4 | 2 of 4 | -30 | +302 |
| **Opponent** | all armies | 3 | 0 | 678 | 4.0 | 1.2 | 170 | 7 | +163 | 6 of 12 | 6 of 12 | +26 | +190 |

### Effective charges: nw22-19bea9b-p21

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 8 | 0 | 0 | 0 | 0 | 1 (net +120) | 5 (net +171) | 2 | 0% (0 of 6) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net -59) | 1 | 0% (0 of 2) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 2 (net +146) | 0 | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 8 | 2 (net +202) | 1 (net +0) | 0 | 0 | 1 (net +83) | 2 (net +70) | 2 | 0% (0 of 6) |
| Opponent | Warriors of Chaos | 4 | 1 (net +807) | 0 | 0 | 1 (net -30) | 1 (net +100) | 0 | 1 | 0% (0 of 3) |

### Charged fights, damage counted: nw22-19bea9b-p21

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 333 | 169 | +105 | 145 | 34 | +111 | +33.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 335 | 75 | +137 | 137 | 0 | +137 | +40.9 |
| Mine | No odds | 4 | 344 | 200 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 14 | 337 | 158 | +82 | 102 | 17 | +85 | +25.1 |
| Opponent | Long shot (under 50%) | 3 | 287 | 392 | +404 | 404 | 0 | +404 | +140.6 |
| Opponent | 50-54% | 1 | 186 | 185 | +0 | 74 | 0 | +74 | +39.8 |
| Opponent | 76-89% | 1 | 524 | 336 | -30 | 0 | 30 | -30 | -5.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 215 | 158 | +70 | 114 | 0 | +114 | +53.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 508 | 92 | +92 | 92 | 0 | +92 | +18.0 |
| Opponent | No odds | 3 | 242 | 205 | +150 | 166 | 39 | +128 | +52.7 |
| Opponent | All fights | 12 | 312 | 234 | +163 | 183 | 12 | +171 | +54.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p21 | move | 34 | 5 (15%) | 5 (15%) | 7 (21%) | 22 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

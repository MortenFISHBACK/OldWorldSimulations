# Doctrine scorecard: nw22-19bea9b-p45

### Scorecard: nw22-19bea9b-p45

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 2 | 2 | 9 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 4 | 4 | 2 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | no | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 2.3 | 4.7 | 0.3 | 0.0 | 0.0 | 0.0 | 66.7 |
| **Average** | | | Opponent | 33% | 1.0 | 1.7 | 3.3 | 1.7 | 0.3 | 0.0 | 0.0 | 113.3 |

### KPIs: nw22-19bea9b-p45

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 6% (1 of 17) | 0% (0 of 16) | 3% (1 of 33) |
| Winner chose to follow up after the loser gave ground |  | 67% (4 of 6); on the table 67% | 100% (3 of 3); on the table 100% | 78% (7 of 9); on the table 78% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (2 of 4); on the table 50% | 50% (2 of 4); on the table 50% | 50% (4 of 8); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 55% (6 of 11); on the table 64% | 71% (5 of 7); on the table 71% | 61% (11 of 18); on the table 67% |
| Magic missiles tried each own turn | 50%+ | - | 42% (5 of 12) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 56% (5 of 9) | 56% (5 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (6 of 8) | 75% (6 of 8) |
| Points that never fought | lower | 34% (2069 of 6000) | 40% (2380 of 5999) | 37% (4449 of 11999) |
|   infantry points that never fought | lower | 68% (900 of 1332) | 65% (553 of 855) | 66% (1453 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 40% (8 of 20) | 76% (19 of 25) | 60% (27 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 100% (1 of 1); 1.7 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 32% (1663 of 5135) | 65% (3520 of 5430) | 49% (5183 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.7 (29%) | 0.7 (29%) |
| MARCHED: its unit marched | - | 0.7 (29%) | 0.7 (29%) |
| FLEEING: fleeing | - | 0.3 (14%) | 0.3 (14%) |
| GONE: slain | - | 0.7 (29%) | 0.7 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 0.7 | 1.7 | 1.3 |
| not cast | 6.0 | 1.0 | 1.3 | 2.3 | 18.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (11%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (83%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 55% (51 of 93) | 22% (2 of 9) | 52% (53 of 102) |
|   cavalry | 80% (8 of 10) | 50% (2 of 4) | 71% (10 of 14) |
|   character | 50% (6 of 12) | 0% (0 of 5) | 35% (6 of 17) |
|   chariot | 17% (1 of 6) | - | 17% (1 of 6) |
|   infantry | 54% (20 of 37) | - | 54% (20 of 37) |
|   monster | 29% (5 of 17) | - | 29% (5 of 17) |
|   war machine | 100% (11 of 11) | - | 100% (11 of 11) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (26%) | 1.7 (71%) | 5.3 (33%) |
| CHARGED: it charged | 2.3 (17%) | 0.3 (14%) | 2.7 (16%) |
| FLEEING: it fled or was fleeing | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 2.0 (14%) | 0.0 (0%) | 2.0 (12%) |
| NO TARGET IN RANGE | 2.3 (17%) | 0.3 (14%) | 2.7 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 2.7 (19%) | 0.0 (0%) | 2.7 (16%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 1.3 | 60% | 14.3 pts | 48 pts |
| character | 2.3 | 0.7 | 86% | 8.1 pts | 19 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 11.3 | 1.7 | 88% | 4.5 pts | 51 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 3.7 | 2.3 | 73% | 14.3 pts | 52 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.3 | 4.7 | 5.0 |
| Charges that made contact a game | 4.7 | 3.3 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 2.00 declared, 2.00 contact (2 units) | 0.83 declared, 0.83 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.75 declared, 0.65 contact (20 units) | 0.48 declared, 0.29 contact (21 units) | 0.61 declared, 0.46 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (5 of 5) | 100% (3 of 3) | 0% (0 of 2) | 80% (8 of 10) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 100% (5 of 5) | 50% (1 of 2) | 33% (3 of 9) | 56% (9 of 16) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 43% (3 of 7) | 0% (0 of 3) | - | 30% (3 of 10) |
| Monster | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 50% (2 of 4); on the table 50% | - | 48% | 29% (2 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 0% (0 of 2); on the table 50% | - | 39% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 80% (4 of 5); on the table 80% | - | 16% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (4 of 6); on the table 67% | 67% (4 of 6) | 28% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 46% | 79% (15 of 19) | 100% (1 of 1); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p45, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 75% (9) | 71% (12) |
| ...free all their last turn and able to turn (per game) | 0.33 | 2.33 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.67 | 2.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p45

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 67% (8 of 12) | 33% (4 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (10 of 24) | 0% (0 of 4) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 70% (7 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 1.7 |
| Movement | Points that never moved of their own | 66.7 | 113.3 |
| Movement | Fights charged into per game | 4.7 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 9 | 2 of 7, net +202 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 9, net +137 | 1 of 7, net +83 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 9, net +142 | 3 of 7, net +47 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.7 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (18 of 41) | 33% (1 of 3) |
| Shooting | Points destroyed by shooting units | 56.7 | 0.0 |
| Shooting | War machine shots | 3.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (7 of 11) | - |
| Shooting | Points destroyed by war machines | 0.0 | 33.3 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 2.3 | - |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 38.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.7 / 0.0 / 0.0 | 0.7 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 292.0 | 209.7 |
| Combat | Points run down | 80.7 | 193.0 |
| Combat | Net points per charged fight, damage counted | +115 | +153 |
| Combat | Net per 100 charger points, damage counted | +36.1 | +51.5 |
| Combat | First round won (charged fights) | 100% | 56% |
| Combat | Net points per charged fight | +111 | +120 |
| Combat | Net points per supported fight / lone fight | - / +111 | +83 / +124 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 14 | 4 of 9 |
| Game | Points lost | 402.7 | 800.3 |
| Game | VP from objectives | 813.3 | 433.3 |
| Game | Lone holders (player turns) | 3.0 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +643 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1203
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p45

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +11.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 29.7 | +674.0 | 0.0 | 100.3 | 22.0 | +205.1 | 0.0 | 118.7 |
| BACKS UP THE FIGHT | 0.7 | +10.4 | 0.0 | 0.0 | 0.7 | +3.3 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 3.7 | +0.0 | 0.0 | 66.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.0 | +5.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +48.3 | 0.0 | 0.0 | 1.3 | +59.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +18.4 | 0.0 | 0.0 | 1.0 | +10.9 | 0.0 | 16.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -14.5 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.7 | -9.4 | 67.0 | 0.0 | 0.7 | +4.4 | 47.0 | 16.7 |
| CHARGE LOSSES | 9.0 | -406.3 | 0.0 | 0.0 | 10.3 | -945.9 | 0.0 | 325.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 47.0 | 0.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 412.7 | 0.0 | 1.7 | +0.0 | 74.7 | 62.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 343.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 47.0 | 0.0 |
| COVER ONCE | 7.7 | -452.0 | 0.0 | 0.0 | 11.0 | -1355.6 | 0.0 | 78.7 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -5.9 | 161.7 | 40.7 |
| DEPLOY BY FIGURES | 6.3 | -5.6 | 0.0 | 0.0 | 6.3 | +70.2 | 0.0 | 15.0 |
| DUEL STOPS AT THE KILL | 0.3 | -64.7 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 1.0 | +123.2 | 163.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.0 | +13.9 | 313.3 | 135.0 | 3.0 | +11.4 | 354.7 | 102.7 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 47.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 3.3 | +1.4 | 300.7 | 135.0 | 3.7 | +1.5 | 243.7 | 119.3 |
| FALLS SHORT | - | - | - | - | 19.7 | +271.0 | 0.0 | 256.7 |
| FEATURE BUFFS | 0.7 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | 0.3 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +1.6 | 40.7 | 0.0 | 2.0 | +37.7 | 209.7 | 62.0 |
| FIRE AND FLEE | 0.3 | +18.8 | 0.0 | 26.7 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 56.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 85.3 | +8254.1 | 1133.7 | 424.0 | 72.3 | +4670.2 | 457.0 | 1024.0 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 218.7 |
| FOLLOW UP WEIGHED | 0.7 | +61.0 | 0.0 | 47.0 | 1.0 | +136.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +396.5 | 495.7 | 135.0 | 4.7 | +264.1 | 457.0 | 119.3 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 53.3 | 5.0 | +0.0 | 0.0 | 150.0 |
| FRIEND SHOOTS FIRST | 0.7 | -2.8 | 0.0 | 0.0 | 1.3 | -24.8 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -20.2 | 0.0 | 135.0 | 1.0 | -18.6 | 135.0 | 0.0 |
| GOAL WALK | 9.3 | +929.1 | 0.0 | 0.0 | 5.3 | +508.5 | 0.0 | 0.0 |
| GUN MASK | 0.7 | +14.1 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.7 | +0.1 | 48.0 | 0.0 | 1.3 | -6.6 | 162.7 | 62.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 53.3 | 1.0 | +0.0 | 0.0 | 130.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.0 | +0.0 | 166.3 | 16.7 |
| HELPER UNSEEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 135.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 268.7 |
| HIS CHARGE DENIED | 0.3 | +12.2 | 38.7 | 0.0 | 0.7 | +52.6 | 135.0 | 0.0 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 55.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 68.7 |
| HIS MOVE AND SHOT | 1.7 | -41.2 | 0.0 | 0.0 | 0.7 | -2.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 96.0 |
| HIS OWN BEST MOVE | 7.0 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 68.7 |
| HIS RANDOM MOVE | 11.3 | +0.0 | 0.0 | 26.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 10.0 | +104.1 | 0.0 | 47.0 | 28.7 | +668.9 | 0.0 | 688.7 |
| HIS SHOTS BY HIS RUN | 16.3 | +117.5 | 0.0 | 53.3 | 33.7 | +974.3 | 0.0 | 841.3 |
| HIS TURN DENIED | 0.3 | +10.5 | 65.0 | 0.0 | 0.7 | +5.0 | 54.3 | 40.7 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 53.3 | 8.7 | +0.0 | 0.0 | 147.0 |
| HOLDER ASSIGNMENT | 10.0 | +843.1 | 0.0 | 26.7 | 5.3 | +399.9 | 0.0 | 107.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -137.9 | 399.7 | 135.0 | 4.0 | -176.9 | 457.0 | 102.7 |
| IDLE COST | - | - | - | - | 11.7 | -159.1 | 0.0 | 120.7 |
| JOINT CHARGE NOW | 0.3 | +18.9 | 56.7 | 0.0 | 1.3 | +21.0 | 108.7 | 40.7 |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 1.0 | +81.8 | 0.0 | 0.0 | 1.0 | +16.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 15.0 | 332.7 | 4.3 | +0.0 | 47.0 | 186.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 67.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +7.2 | 26.7 | 40.7 |
| LOST AFTER ESCAPE | 1.7 | +0.4 | 128.7 | 0.0 | 2.3 | +19.1 | 264.0 | 102.7 |
| MAKE SURE TOGETHER | 1.0 | +3.4 | 0.0 | 0.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | -0.5 | 0.0 | 0.0 | 0.7 | +8.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +18.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +25.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | -8.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 40.0 |
| MAX FOR POSITIONING | 3.3 | +37.5 | 0.0 | 0.0 | 5.0 | +104.1 | 0.0 | 31.7 |
| MEETS IN TIME | 3.7 | +208.2 | 0.0 | 0.0 | 2.0 | +143.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +36.7 | 0.0 | 0.0 | 3.0 | +28.6 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 3.3 | +23.3 | 0.0 | 0.0 | 4.0 | +32.1 | 0.0 | 65.0 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 40.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 9.3 | +804.0 | 0.0 | 0.0 | 11.3 | +1011.3 | 0.0 | 30.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEAR WALKS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 10.0 | +411.5 | 0.0 | 54.3 | 5.7 | +262.4 | 0.0 | 135.0 |
| NEXT CHARGE BY LIST | 5.3 | +516.0 | 0.0 | 0.0 | 7.0 | +591.9 | 0.0 | 30.0 |
| NO CHAFF EDGES | 3.0 | +72.9 | 180.3 | 135.0 | 2.0 | +40.7 | 161.7 | 0.0 |
| NO DOUBLE ROUNDS | 4.7 | -136.9 | 495.7 | 135.0 | 3.3 | -186.8 | 216.0 | 102.7 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 40.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 1.7 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -308.0 | 0.0 | 66.7 | 6.3 | -228.3 | 166.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 8.0 | -215.5 | 0.0 | 0.0 | 8.3 | -147.5 | 0.0 | 118.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -1.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | -50.6 | 0.0 | 26.7 | 2.3 | +41.0 | 0.0 | 40.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -5.8 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 40.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +10.6 | 27.7 | 0.0 |
| OPENS UP IN FULL | 1.0 | +25.2 | 121.7 | 135.0 | 1.0 | +29.1 | 189.3 | 0.0 |
| OVERRUNS AWAY | 1.3 | +81.5 | 163.0 | 135.0 | 1.0 | +44.9 | 213.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +10.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.4 | 0.0 | 0.0 |
| PLAN RESULT | 39.3 | +1029.1 | 229.3 | 705.7 | 39.3 | +421.6 | 397.3 | 999.0 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +48.3 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 11.7 | -267.4 | 0.0 | 0.0 | 10.0 | -357.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | -13.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -2.8 | 0.0 | 0.0 | 0.7 | -7.6 | 0.0 | 0.0 |
| QUARTER ODDS | 25.7 | +3608.6 | 113.0 | 66.7 | 17.3 | +2074.6 | 301.3 | 112.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +141.3 | 0.0 | 226.7 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 40.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +109.7 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 1.3 | +64.1 | 0.0 | 0.0 | 4.3 | +381.9 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +183.3 | 0.0 | 26.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +38.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.3 | -81.9 | 0.0 | 0.0 | 1.0 | -17.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 27.7 | - | - | - | - |
| RESERVE FALL BACK | 1.0 | +19.1 | 0.0 | 26.7 | - | - | - | - |
| RISK BY ARC | 4.0 | +74.6 | 400.3 | 135.0 | 4.0 | +18.2 | 322.0 | 119.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| ROUNDS AFTER TERROR | 0.7 | -13.0 | 132.0 | 0.0 | 1.0 | -31.3 | 55.3 | 16.7 |
| RUN DOWN | 2.7 | -107.7 | 347.3 | 0.0 | 3.0 | -71.2 | 430.3 | 102.7 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -65.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +4.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +36.4 | 166.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | +117.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -15.7 | 0.0 | 0.0 | 3.0 | -96.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +12.0 | 97.3 | 0.0 | 4.7 | +72.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 3.0 | +23.0 | 0.0 | 26.7 | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 66.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +19.4 | 0.0 | 0.0 | 0.7 | +118.6 | 0.0 | 0.0 |
| SHOT RISK POINTS | 8.0 | -79.4 | 0.0 | 0.0 | 13.7 | -270.4 | 0.0 | 265.3 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 11.7 | +332.7 | 0.0 | 66.7 | 1.0 | +30.6 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +40.2 | 0.0 | 0.0 | 2.0 | +15.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -13.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 73.7 | 11.0 | +0.0 | 0.0 | 230.3 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -5.6 | 81.0 | 40.7 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 28.7 | +0.0 | 638.0 | 133.3 | 12.0 | +0.0 | 0.0 | 364.3 |
| STAY WORTH | 17.0 | -20.6 | 360.7 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +29.4 | 0.0 | 166.3 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.3 | +719.3 | 0.0 | 47.0 | 10.3 | +642.0 | 0.0 | 153.3 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 78.7 |
| SUPPORT WORKED OUT | 6.3 | +719.3 | 0.0 | 47.0 | 10.3 | +642.0 | 0.0 | 153.3 |
| SURE REACH TOGETHER | 2.0 | +7.5 | 0.0 | 0.0 | 1.0 | +1.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE FIGHT MOVES | 2.3 | +15.8 | 243.7 | 0.0 | 1.7 | +50.5 | 220.7 | 102.7 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -23.8 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 115.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.3 | +0.0 | 0.0 | 121.0 | 36.0 | +0.0 | 0.0 | 358.3 |
| TIED UP BY THE SUM | 3.7 | +396.4 | 380.7 | 135.0 | 1.3 | +142.3 | 101.3 | 0.0 |
| TIME ON OUR SIDE | 36.7 | +468.5 | 30.0 | 54.3 | - | - | - | - |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 100.3 | 5.0 | +0.0 | 0.0 | 33.3 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -93.1 | 426.7 | 0.0 |
| WHO FIGHTS | 0.7 | -6.6 | 96.0 | 0.0 | 0.7 | +29.8 | 0.0 | 62.0 |
| WHO HITS BACK | 2.3 | +282.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.7 | +26.7 | 213.3 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -321.7 | 0.0 | 0.0 | 4.3 | -591.5 | 0.0 | 268.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +5.8 | 27.7 | 0.0 |
| WHOLE FIGHT REACTION | 2.3 | +272.2 | 119.3 | 189.3 | 3.0 | +99.2 | 0.0 | 307.3 |
| WOUNDS ON THE RANKS | 1.7 | +8.9 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 134.0 |

### Rule changes: nw22-19bea9b-p45

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 155 | 155 | 100 | 33.33 | +2109 | +21.1 |
| HOLDER ASSIGNMENT | 46 | 46 | 43 | 14.33 | +2142 | +49.8 |
| OFF BEST | 38 | 38 | 38 | 12.67 | -1609 | -42.3 |
| FIVE ACTION | 473 | 451 | 35 | 11.67 | +2535 | +72.4 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 65 | 65 | 26 | 8.67 | -1874 | -72.1 |
| DEPLOY BY FIGURES | 38 | 38 | 23 | 7.67 | +208 | +9.0 |
| QUARTER ODDS | 129 | 122 | 22 | 7.33 | +2420 | +110.0 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 62 | 50 | 21 | 7.00 | +808 | +38.5 |
| SUPPORT ADDS | 50 | 48 | 20 | 6.67 | +990 | +49.5 |
| SUPPORT WORKED OUT | 50 | 48 | 20 | 6.67 | +990 | +49.5 |
| HIS SHOT LIST | 116 | 111 | 18 | 6.00 | +203 | +11.3 |
| MOVE ORDER | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 37 | 34 | 14 | 4.67 | +649 | +46.4 |
| HIS SHOTS BY HIS RUN | 150 | 137 | 13 | 4.33 | +116 | +8.9 |
| FOUR ROUNDS | 28 | 26 | 12 | 4.00 | +674 | +56.1 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +458 | +38.2 |
| TIED UP BY THE SUM | 15 | 15 | 12 | 4.00 | +420 | +35.0 |
| GOAL WALK | 44 | 44 | 11 | 3.67 | +520 | +47.2 |
| NO CHAFF EDGES | 15 | 15 | 11 | 3.67 | +210 | +19.1 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MEETS IN TIME | 17 | 17 | 8 | 2.67 | +423 | +52.9 |
| COVER ONCE | 56 | 36 | 7 | 2.33 | +146 | +20.8 |
| TIME ON OUR SIDE | 110 | 92 | 7 | 2.33 | +1 | +0.1 |
| WHO HITS BACK | 7 | 7 | 7 | 2.33 | +492 | +70.3 |
| WHOLE FIGHT DANGER | 26 | 26 | 7 | 2.33 | +626 | +89.4 |
| CAST JOB | 6 | 6 | 6 | 2.00 | +2 | +0.3 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| IDLE COST | 35 | 26 | 6 | 2.00 | +47 | +7.9 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +295 | +49.2 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 6 | 2.00 | +424 | +70.6 |
| RISK BY ARC | 24 | 22 | 6 | 2.00 | +186 | +31.0 |
| THE ROW IN ITS ORDER | 30 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 58 | 52 | 5 | 1.67 | +651 | +130.2 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +591 | +118.2 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +120 | +23.9 |
| MAX FOR POSITIONING | 25 | 22 | 5 | 1.67 | +54 | +10.8 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 5 | 1.67 | +40 | +8.1 |
| BACKS UP THE FIGHT | 4 | 4 | 4 | 1.33 | +8 | +2.1 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +88 | +22.0 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 18 | 17 | 4 | 1.33 | +74 | +18.6 |
| SHOT RISK POINTS | 65 | 56 | 4 | 1.33 | +21 | +5.4 |
| CANNON PLANNED TARGET | 11 | 11 | 3 | 1.00 | -4 | -1.2 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 6 | 3 | 1.00 | +88 | +29.4 |
| FALLS SHORT | 59 | 45 | 3 | 1.00 | +0 | +0.0 |
| OVERRUNS AWAY | 7 | 6 | 3 | 1.00 | +100 | +33.2 |
| REDIRECT COUNTER | 17 | 14 | 3 | 1.00 | +60 | +20.1 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +57 | +19.1 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS AFTER THE MOVES | 10 | 10 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +34 | +17.1 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -77 | -38.3 |
| NO DOUBLE ROUNDS | 24 | 23 | 2 | 0.67 | +15 | +7.5 |
| ONE FIGHT FORMULA | 49 | 30 | 2 | 0.67 | +16 | +8.2 |
| OPENS UP IN FULL | 6 | 6 | 2 | 0.67 | +6 | +3.1 |
| PROMISE KNOWS THE FIGHT | 9 | 9 | 2 | 0.67 | -40 | -20.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +370 | +184.8 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +109 | +54.5 |
| WHOLE FIGHT REACTION | 16 | 16 | 2 | 0.67 | +32 | +16.1 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -20 | -20.3 |
| CHARGE NOW FIRST | 13 | 13 | 1 | 0.33 | -78 | -78.1 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +149 | +149.0 |
| EXACT ROUND | 18 | 17 | 1 | 0.33 | +0 | +0.1 |
| FEATURE BUFFS | 2 | 2 | 1 | 0.33 | +4 | +4.3 |
| FIGHT TO THE END | 8 | 8 | 1 | 0.33 | +15 | +14.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +56 | +56.5 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +9 | +9.3 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +25 | +25.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -18 | -17.6 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +30 | +30.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -7 | -7.2 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +145 | +145.0 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | +1 | +1.4 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -7 | -6.7 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +12 | +12.0 |
| STAY WORTH | 52 | 46 | 1 | 0.33 | +1 | +0.7 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +88 | +88.1 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -28 | -27.9 |
| SURE REACH TOGETHER | 9 | 6 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +15 | +14.9 |
| WOUNDS ON THE RANKS | 8 | 8 | 1 | 0.33 | +1 | +0.6 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 66 | 65 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 21 | 21 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 53 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 24 | 24 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 1 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 48 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 21 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 28 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 7 | 7 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 52 | 42 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 34 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 71 | 71 | 0 | 0.00 | - | - |
| HONEST WORTH | 24 | 23 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 12 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 47 | 45 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 17 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 236 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 11 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 11 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 32 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 38 | 24 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 53 | 50 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 122 | 118 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE FIGHT MOVES | 12 | 11 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 2 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 229 | not checked | - | - | - | - |
| WAITS AGAIN | 20 | 17 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p45

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 5.67 | 4.67 | 54.8 |
| JOB FIRST | gate | 5.00 | 4.67 | 47.3 |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 3.67 | 72.1 |
| NO REASON | gate | 1.00 | - | 13.3 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 1.0 |
| JOINT CHARGE NOW | rule | - | 0.67 | 23.6 |
| MARCH OF THE TABLE | rule | - | 0.67 | 38.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 20.0 |
| RULE SWITCHED OFF | gate | - | 0.67 | 91.7 |
| AFTERMATH BAND | gate | - | 0.33 | 2.5 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 3.6 |
| CHAFF PASSED | rule | 0.33 | - | 0.9 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 20.3 |
| CHARGE NOW FIRST | rule | - | 0.33 | 78.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 60.0 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 9.5 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 17.6 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 7.2 |
| REFUSING RETIRES | rule | 0.33 | - | 6.7 |
| SUPPORT NARROWED | rule | - | 0.33 | 27.9 |

### Plans: nw22-19bea9b-p45

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 77% | 679 | 451 | 66% |
| Mine | move | 27.0 | 95% | 2192 | 0 | 0% |
| Mine | shoot | 7.3 | 68% | 498 | 578 | 116% |
| Mine | support | 0.7 | 100% | 92 | 0 | 0% |
| Opponent | charge | 4.3 | 62% | 489 | 422 | 86% |
| Opponent | join | 3.7 | 91% | 161 | 0 | 0% |
| Opponent | move | 30.0 | 89% | 1730 | 0 | 0% |
| Opponent | shoot | 1.0 | 0% | 119 | 0 | 0% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p45

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 4.3 | 46% | 50% | 33% | 50% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p45

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 24 (3) | 24 | 0 | 0 | 0% | 3.0 | 24 (3) | - | - | 24 (3) | - |
| Mine | Chaff | 2 | 150 (2) | 0 | 150 | 50 | 0% | 1.0 | 225 (1) | 75 (1) | - | 225 (1) | 75 (1) |
| Mine | Character | 8 | 68 (8) | 68 | 0 | 38 | 0% | 3.4 | 60 (3) | 80 (4) | 44 (1) | 98 (5) | 13 (3) |
| Mine | Clean-up | 1 | 98 (1) | 0 | 98 | 0 | 0% | 4.0 | 98 (1) | - | - | 98 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 44 (4) | 44 | 0 | 0 | 25% | 1.7 | 58 (3) | 28 (1) | - | 58 (3) | 28 (1) |
| Mine | Hammer | 3 | 11 (3) | 7 | 4 | 0 | 33% | 1.0 | - | 11 (3) | - | 0 (1) | 15 (2) |
| Mine | Shooter | 6 | 55 (6) | 2 | 53 | 12 | 0% | 2.3 | 4 (2) | 99 (4) | - | 85 (3) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 50 (2) | 50 | 0 | 50 | 0% | 1.0 | 50 (2) | - | - | 0 (1) | 100 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 39 | 20% | 3.0 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 46 (10) | 46 | 0 | 34 | 20% | 3.2 | 128 (4) | 10 (4) | 0 (1) | 94 (7) | 9 (2) |
| Opponent | Clean-up | 1 | 49 (1) | 0 | 49 | 100 | 0% | 4.0 | - | 49 (1) | - | - | 49 (1) |
| Opponent | Fast Hammer | 6 | 10 (6) | 10 | 0 | 28 | 50% | 3.0 | 18 (3) | 0 (3) | - | 15 (4) | 0 (2) |
| Opponent | Hammer | 5 | 38 (5) | 0 | 38 | 54 | 40% | 3.0 | 59 (3) | 0 (2) | - | 46 (4) | 0 (1) |
| Opponent | Holder | 4 | 6 (4) | 0 | 6 | 83 | 0% | 4.8 | 0 (1) | 11 (2) | 0 (1) | - | 6 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 44 | 33% | 4.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: nw22-19bea9b-p45

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 286 | 974 | 8.0 | 1.0 | 122 | 0 | +122 | 2 of 8 | 8 of 8 | - | +122 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 292 | 3.0 | 1.0 | 97 | 0 | +97 | 0 of 3 | 3 of 3 | - | +97 |
| Mine | Lizardmen | 1 | 0 | 291 | 3.0 | 1.0 | 97 | 0 | +97 | 0 of 3 | 3 of 3 | - | +97 |
| **Mine** | all armies | 3 | 95 | 519 | 4.7 | 1.0 | 111 | 0 | +111 | 2 of 14 | 14 of 14 | - | +111 |
| Opponent | Vampire Counts | 1 | 0 | 1128 | 8.0 | 1.1 | 141 | 6 | +135 | 4 of 8 | 4 of 8 | +83 | +142 |
| Opponent | Warriors of Chaos | 2 | 50 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 33 | 376 | 3.0 | 1.1 | 125 | 6 | +120 | 4 of 9 | 5 of 9 | +83 | +124 |

### Effective charges: nw22-19bea9b-p45

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 8 | 0 | 0 | 0 | 0 | 1 (net +120) | 5 (net +171) | 2 | 0% (0 of 6) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 1) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 2 (net +146) | 0 | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 8 | 2 (net +202) | 1 (net +0) | 0 | 0 | 1 (net +83) | 2 (net +70) | 2 | 0% (0 of 6) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p45

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 300 | 147 | +142 | 150 | 0 | +150 | +49.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 335 | 75 | +137 | 137 | 0 | +137 | +40.9 |
| Mine | No odds | 5 | 331 | 120 | +58 | 72 | 12 | +60 | +18.1 |
| Mine | All fights | 14 | 319 | 122 | +111 | 119 | 4 | +115 | +36.1 |
| Opponent | Long shot (under 50%) | 2 | 328 | 402 | +202 | 202 | 0 | +202 | +61.6 |
| Opponent | 50-54% | 1 | 186 | 185 | +0 | 74 | 0 | +74 | +39.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 265 | 197 | +47 | 145 | 0 | +145 | +54.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 521 | 83 | +83 | 83 | 0 | +83 | +15.9 |
| Opponent | No odds | 2 | 260 | 267 | +224 | 250 | 58 | +191 | +73.4 |
| Opponent | All fights | 9 | 298 | 244 | +120 | 166 | 13 | +153 | +51.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p45 | move | 37 | 6 (16%) | 6 (16%) | 5 (14%) | 26 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

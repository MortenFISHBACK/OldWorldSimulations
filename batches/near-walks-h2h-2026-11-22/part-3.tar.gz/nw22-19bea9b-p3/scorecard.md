# Doctrine scorecard: nw22-19bea9b-p3

### Scorecard: nw22-19bea9b-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 9 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 588 |
| L0421 | 1 | 1 | Mine | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 1 | 5 | 0 | 0 | 0 | 500 |
| L0508 | 4 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 613 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 877 |
| **Average** | | | Mine | 0% | 6.3 | 2.0 | 2.0 | 2.0 | 0.0 | 0.0 | 0.0 | 204.3 |
| **Average** | | | Opponent | 0% | 0.0 | 3.0 | 0.7 | 3.3 | 0.0 | 0.0 | 0.0 | 655.0 |

### KPIs: nw22-19bea9b-p3

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 71% (5 of 7) | 28% (5 of 18) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% | 75% (3 of 4); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 25% (3 of 12) | 33% (2 of 6) | 28% (5 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (3 of 12) | 33% (2 of 6) | 28% (5 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 44% (4 of 9) | 44% (4 of 9) |
| Points that never fought | lower | 84% (5023 of 5998) | 91% (5457 of 5999) | 87% (10480 of 11997) |
|   infantry points that never fought | lower | 87% (1239 of 1424) | 95% (1611 of 1703) | 91% (2850 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (14 of 23) | 65% (17 of 26) | 63% (31 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (1 of 1); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3088 of 5120) | 69% (3205 of 4677) | 64% (6293 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (33%) | 1.3 (100%) | 2.3 (54%) |
| MARCHED: its unit marched | 1.7 (56%) | 0.0 (0%) | 1.7 (38%) |
| CHARGED: its unit charged | 0.3 (11%) | 0.0 (0%) | 0.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 0.3 | 1.7 | 1.0 | 0.0 |
| not cast | 3.0 | 3.7 | 4.3 | 3.0 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (82%) | 2.3 (54%) | 1.0 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.7 (38%) | 1.7 (56%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.3 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (100%) | 0.7 (18%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | - | 100% (1 of 1) |
| the unit moved after it | 0% (0 of 1) | - | 0% (0 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (42 of 78) | 79% (88 of 111) | 69% (130 of 189) |
|   cavalry | 38% (5 of 13) | 42% (5 of 12) | 40% (10 of 25) |
|   character | 85% (11 of 13) | 92% (22 of 24) | 89% (33 of 37) |
|   chariot | 41% (9 of 22) | 62% (8 of 13) | 49% (17 of 35) |
|   infantry | 33% (4 of 12) | 60% (9 of 15) | 48% (13 of 27) |
|   war machine | 72% (13 of 18) | 94% (44 of 47) | 88% (57 of 65) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (33%) | 0.3 (4%) | 4.3 (22%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.7 (9%) | 1.0 (5%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.7 (31%) | 2.3 (30%) | 6.0 (31%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (28%) | 3.3 (43%) | 6.7 (34%) |
| SHELTERED: the target was sheltered | 0.7 (6%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 0.7 | 87% | 2.0 pts | 10 pts |
| character | 11.0 | 4.3 | 73% | 11.5 pts | 126 pts |
| chariot | 5.7 | 6.7 | 65% | 17.4 pts | 99 pts |
| infantry | 8.0 | 3.3 | 71% | 13.4 pts | 107 pts |
| war machine | 19.0 | 20.7 | 53% | 22.6 pts | 429 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 0.7 | 1.2 |
| Charges that made contact a game | 0.7 | 0.3 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | - | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.09 contact (22 units) | 0.08 declared, 0.04 contact (24 units) | 0.13 declared, 0.07 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 0% (0 of 1) | - | 25% (1 of 4) |
| Character in a unit | 100% (8 of 8) | 100% (2 of 2) | 100% (1 of 1) | 100% (11 of 11) |
| Character on its own | 100% (4 of 4) | 0% (0 of 2) | 100% (2 of 2) | 75% (6 of 8) |
| Chariot | 0% (0 of 2) | 60% (3 of 5) | - | 43% (3 of 7) |
| Infantry | 50% (4 of 8) | 60% (3 of 5) | 100% (1 of 1) | 57% (8 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 50% (2 of 4) | - | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (1 of 1); on the table 100% | 25% (3 of 12) | 76% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 98% | 86% (12 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 67% (2 of 3); on the table 67% | 33% (2 of 6) | 78% | 56% (5 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p3, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: nw22-19bea9b-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 33% (1 of 3) | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 68% (19 of 28) | 58% (32 of 55) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 0% (0 of 10) |
| Strategy | Lone characters that fought | 25% (2 of 8) | 0% (0 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.3 |
| Movement | Points that never moved of their own | 204.3 | 655.0 |
| Movement | Fights charged into per game | 0.7 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 1, net +95 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (13 of 29) | 61% (27 of 44) |
| Shooting | Points destroyed by shooting units | 118.3 | 103.3 |
| Shooting | War machine shots | 4.3 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 15% (2 of 13) | 61% (27 of 44) |
| Shooting | Points destroyed by war machines | 103.3 | 239.0 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | - | 1.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.3 | 1.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 31.7 | 21.7 |
| Combat | Points run down | 39.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +139 | +30 |
| Combat | Net per 100 charger points, damage counted | +41.1 | +32.2 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +120 | +0 |
| Combat | Net points per supported fight / lone fight | - / +120 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 0 of 1 |
| Game | Points lost | 362.3 | 425.7 |
| Game | VP from objectives | 906.7 | 723.3 |
| Game | Lone holders (player turns) | 6.3 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +199 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 788
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 17.0 | +305.4 | 0.0 | 0.0 | 9.0 | +73.5 | 0.0 | 91.7 |
| ARTILLERY RE-ROLL WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 31.7 |
| BACKUP TARGETS | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BELL IN A UNIT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | +2.9 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 45.0 | 0.0 | 1.3 | +0.0 | 116.7 | 0.0 |
| CANNON PLANNED TARGET | 4.3 | +75.2 | 281.7 | 158.3 | 14.7 | +504.0 | 418.7 | 146.7 |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +38.6 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 19.7 | -1048.6 | 0.0 | 196.0 | 9.3 | -207.6 | 0.0 | 118.3 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 101.7 | 0.0 | - | - | - | - |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 70.0 |
| CONVEYANCE SEARCH | 0.3 | +32.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 4.0 | -190.9 | 0.0 | 103.3 | 4.7 | -699.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +9.9 | 0.0 | 31.7 | 9.0 | -42.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +56.3 | 70.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.3 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.7 | +23.3 | 101.7 | 0.0 | 0.3 | -26.0 | 0.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 39.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.1 | 31.7 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 12.0 | +167.6 | 0.0 | 103.3 | 6.0 | +117.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 94.3 | +5490.6 | 858.3 | 746.0 | 99.0 | +4980.2 | 980.7 | 933.3 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 125.0 | 4.3 | +0.0 | 0.0 | 39.0 |
| FOLLOW UP WEIGHED | 0.3 | +56.8 | 0.0 | 0.0 | 0.3 | +24.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +59.9 | 101.7 | 0.0 | 0.7 | +135.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.7 | -50.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 12.0 | +1335.8 | 0.0 | 43.3 | 4.0 | +308.5 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +21.1 | 48.3 | 103.3 | 1.3 | +42.1 | 0.0 | 21.7 |
| GUN MASK | 1.3 | -10.9 | 0.0 | 0.0 | 0.7 | +39.5 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 2.7 | +0.0 | 0.0 | 103.3 | 2.3 | +0.0 | 0.0 | 118.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +16.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| HIS MOVE AND SHOT | 0.7 | -0.1 | 0.0 | 0.0 | 4.3 | -57.8 | 0.0 | 48.3 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 5.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 52.0 | +2425.5 | 0.0 | 282.7 | 42.7 | +1027.3 | 0.0 | 360.0 |
| HIS SHOTS BY HIS RUN | 37.7 | +706.3 | 0.0 | 326.0 | 27.3 | +733.3 | 0.0 | 208.3 |
| HIS TURN DENIED | 0.7 | +21.8 | 31.7 | 0.0 | - | - | - | - |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 0.0 | 13.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.3 | +895.2 | 0.0 | 0.0 | 9.7 | +860.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -60.3 | 101.7 | 0.0 | 0.3 | -1.4 | 0.0 | 0.0 |
| HUNT IN PAIRS | 1.3 | +292.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 10.0 | -161.6 | 0.0 | 89.7 | 4.0 | -32.4 | 0.0 | 65.0 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 1.3 | +55.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 39.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | -18.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 0.3 | -0.0 | 0.0 | 0.0 |
| LOST CHARGE | 0.3 | -0.2 | 70.0 | 0.0 | - | - | - | - |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.3 | +67.5 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +18.3 | 0.0 | 0.0 | 0.7 | -2.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +105.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +56.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +30.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | -8.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.7 | +126.7 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 2.7 | +296.6 | 0.0 | 0.0 | 4.3 | +181.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +37.6 | 0.0 | 0.0 | 1.7 | +19.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +44.6 | 0.0 | 0.0 | 1.3 | +10.0 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 21.7 |
| MOVE SPELL IN RANGE | 3.0 | +47.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.7 | -214.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.3 | +417.4 | 0.0 | 103.3 | 0.7 | +4.5 | 0.0 | 0.0 |
| NEAR WALKS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +213.9 | 0.0 | 0.0 | 5.7 | +243.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 5.0 | +384.1 | 0.0 | 103.3 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 0.7 | -63.1 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 2.0 | +94.8 | 31.7 | 0.0 | 0.7 | +2.1 | 0.0 | 96.7 |
| NO DOUBLE ROUNDS | 1.7 | -11.6 | 101.7 | 0.0 | 0.7 | -82.9 | 0.0 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 39.0 |
| NOT WORTH A CAST | - | - | - | - | 1.3 | -0.9 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -227.1 | 0.0 | 95.0 | 1.3 | -76.5 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -145.9 | 0.0 | 103.3 | 0.3 | -0.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 1.7 | +43.3 | 0.0 | 0.0 | 3.3 | +49.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -2.6 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.3 | +63.6 | 31.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +66.0 | 70.0 | 0.0 | - | - | - | - |
| OWN CAST FIRST | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +391.5 | 395.7 | 437.7 | 46.3 | +975.8 | 288.7 | 686.3 |
| PRIZE BY WORTH | 0.3 | +73.8 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.0 | -267.2 | 0.0 | 0.0 | 1.3 | -4.5 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 27.7 | +2662.1 | 173.3 | 0.0 | 31.0 | +2015.7 | 0.0 | 253.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +37.7 | 0.0 | 333.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +40.8 | 0.0 | 21.7 | 1.0 | +43.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.7 | +25.1 | 39.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.3 | -166.8 | 101.7 | 0.0 | 0.7 | -2.8 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -1.4 | 31.7 | 0.0 | - | - | - | - |
| RUN DOWN | - | - | - | - | 0.7 | -19.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +111.6 | 70.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -78.2 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.0 | +23.6 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 2.0 | +72.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.7 | +0.0 | 0.0 | 158.3 | 18.7 | +0.0 | 0.0 | 185.7 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +126.7 | 193.3 | 0.0 | 2.0 | +29.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -7.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 29.3 | +346.2 | 0.0 | 282.7 | 26.0 | +173.7 | 0.0 | 343.3 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.0 | +366.4 | 0.0 | 261.7 | 27.0 | +1084.3 | 0.0 | 256.7 |
| SPELL WORTH | 0.3 | +0.4 | 0.0 | 0.0 | 2.7 | +12.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 166.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| STANDS FOR A REASON | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 41.0 | +0.0 | 756.7 | 420.0 | 67.7 | +0.0 | 980.7 | 636.7 |
| STAY WORTH | 26.3 | +471.1 | 476.7 | 681.7 | 40.0 | +447.1 | 588.7 | 441.7 |
| STRONG ENOUGH TO HOLD | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 0.7 | +36.1 | 0.0 | 0.0 | 1.0 | +42.4 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 0.7 | +36.1 | 0.0 | 0.0 | 1.0 | +42.4 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 2.0 | +44.7 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.3 | -0.0 | 70.0 | 0.0 | 0.3 | +12.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.0 | +0.0 | 0.0 | 43.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.0 | +0.0 | 0.0 | 43.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.7 | +0.0 | 0.0 | 373.0 | 47.3 | +0.0 | 0.0 | 289.7 |
| TIED UP BY THE SUM | 1.0 | +107.1 | 31.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 14.7 | +207.1 | 0.0 | 21.7 | 31.7 | +311.8 | 0.0 | 0.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.0 | +0.0 | 96.7 | 103.3 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -19.5 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +12.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 5.3 | -173.6 | 0.0 | 0.0 | 0.3 | -6.6 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 0.7 | +23.5 | 0.0 | 0.0 | 1.7 | +58.7 | 0.0 | 31.7 |
| WOUNDS ON THE RANKS | 2.0 | +292.8 | 0.0 | 0.0 | 5.3 | +94.8 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 284 | 279 | 60 | 20.00 | +1050 | +17.5 |
| ARMY TABLE | 78 | 78 | 56 | 18.67 | +869 | +15.5 |
| HOLDER ASSIGNMENT | 57 | 57 | 54 | 18.00 | +2429 | +45.0 |
| SHOT RISK POINTS | 166 | 165 | 41 | 13.67 | +1343 | +32.8 |
| HIS SHOTS BY HIS RUN | 195 | 186 | 37 | 12.33 | +499 | +13.5 |
| DEPLOY BY FIGURES | 53 | 53 | 29 | 9.67 | +502 | +17.3 |
| ARTILLERY RE-ROLL WEIGHED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 139 | 119 | 21 | 7.00 | +84 | +4.0 |
| GOAL WALK | 48 | 48 | 19 | 6.33 | +1064 | +56.0 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -911 | -47.9 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| FIVE ACTION | 580 | 570 | 13 | 4.33 | +713 | +54.9 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 13 | 4.33 | -815 | -62.7 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| IDLE COST | 42 | 34 | 12 | 4.00 | +72 | +6.0 |
| MOVE TO CHARGE COMPUTED | 18 | 16 | 11 | 3.67 | +505 | +45.9 |
| CANNON PLANNED TARGET | 57 | 57 | 10 | 3.33 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| QUARTER ODDS | 176 | 174 | 9 | 3.00 | +720 | +80.0 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CHARGE LOSSES | 87 | 86 | 8 | 2.67 | +313 | +39.1 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +437 | +54.6 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 8 | 2.67 | +156 | +19.5 |
| NEXT CHARGE BY LIST | 15 | 14 | 7 | 2.33 | +505 | +72.1 |
| WOUNDS ON THE RANKS | 22 | 22 | 7 | 2.33 | +163 | +23.2 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SET UP BY THE SET | 6 | 6 | 6 | 2.00 | -37 | -6.1 |
| SHOTS IN THE MOVE | 120 | 82 | 6 | 2.00 | +390 | +65.0 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| STAY WORTH | 199 | 175 | 5 | 1.67 | +82 | +16.4 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 26 | 20 | 4 | 1.33 | +5 | +1.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +165 | +41.3 |
| NO CHAFF EDGES | 8 | 7 | 4 | 1.33 | +100 | +25.0 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 4 | 1.33 | +113 | +28.3 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| WHOLE FIGHT DANGER | 17 | 17 | 4 | 1.33 | +69 | +17.2 |
| FALLS SHORT | 54 | 43 | 3 | 1.00 | +56 | +18.7 |
| FOUR ROUNDS | 7 | 6 | 3 | 1.00 | +209 | +69.5 |
| MANOEUVRE | 8 | 8 | 3 | 1.00 | +55 | +18.4 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +317 | +105.5 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +300 | +100.1 |
| SURE REACH TOGETHER | 6 | 6 | 3 | 1.00 | +22 | +7.2 |
| WHOLE FIGHT REACTION | 7 | 7 | 3 | 1.00 | +52 | +17.4 |
| CAST JOB | 3 | 3 | 2 | 0.67 | +4 | +2.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +243 | +121.5 |
| GUN MASK | 6 | 6 | 2 | 0.67 | +33 | +16.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MAX FOR POSITIONING | 11 | 9 | 2 | 0.67 | +27 | +13.7 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +335 | +167.4 |
| SHOTS AFTER THE MOVES | 22 | 22 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT ADDS | 5 | 5 | 2 | 0.67 | +9 | +4.7 |
| SUPPORT WORKED OUT | 5 | 5 | 2 | 0.67 | +9 | +4.7 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +30 | +30.5 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +57 | +57.2 |
| HUNT IN PAIRS | 4 | 4 | 1 | 0.33 | +147 | +147.3 |
| MAIN BODY KEEPS ITS BAND | 1 | 1 | 1 | 0.33 | +28 | +28.1 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -144 | -144.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -93 | -92.5 |
| NO DOUBLE ROUNDS | 7 | 6 | 1 | 0.33 | +30 | +30.5 |
| ONE FIGHT FORMULA | 18 | 8 | 1 | 0.33 | +2 | +1.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -8 | -7.7 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +55 | +54.7 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -11 | -10.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +7 | +6.7 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +222 | +221.5 |
| REDIRECT COUNTER | 4 | 2 | 1 | 0.33 | +68 | +68.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +29 | +28.9 |
| RISK BY ARC | 6 | 5 | 1 | 0.33 | +30 | +30.5 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 3 | 2 | 1 | 0.33 | +15 | +15.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 27 | 27 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 32 | 32 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 6 | 5 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 24 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 15 | 15 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 6 | 6 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 15 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 24 | 22 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 16 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 35 | 33 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 16 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 86 | 86 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 9 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 13 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 8 | trace | - | - | - | - |
| NEAR WALKS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 32 | 30 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 15 | 6 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 4 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 263 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 6 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 82 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 31 | 21 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 326 | 321 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE FIGHT MOVES | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 276 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 1.33 | 48.5 |
| ARMY TABLE | rule | 4.00 | 0.33 | 34.5 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 0.67 | 62.7 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 23.1 |
| SET UP BY THE SET | rule | 0.67 | - | 115.7 |
| MARCH ODDS | rule | 0.33 | - | 144.3 |
| MARCH OF THE TABLE | rule | 0.33 | - | 92.5 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 7.7 |
| OWN CAST FIRST | rule | 0.33 | - | 10.6 |
| RULE SWITCHED OFF | gate | 0.33 | - | 38.0 |

### Plans: nw22-19bea9b-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 172 | 102 | 59% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 31.0 | 97% | 1675 | 0 | 0% |
| Mine | shoot | 8.7 | 50% | 480 | 290 | 60% |
| Opponent | charge | 0.3 | 0% | 68 | 0 | 0% |
| Opponent | join | 2.7 | 100% | 92 | 0 | 0% |
| Opponent | move | 27.7 | 93% | 1315 | 0 | 0% |
| Opponent | shoot | 15.7 | 74% | 805 | 976 | 121% |

### Battle groups: nw22-19bea9b-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 16 (11) | 16 | 0 | 13 | 18% | 3.3 | 23 (5) | 0 (2) | 23 (3) | 0 (6) | 34 (4) |
| Mine | Clean-up | 2 | 150 (2) | 0 | 150 | 0 | 50% | 2.0 | 150 (2) | - | - | 150 (2) | - |
| Mine | Hammer | 8 | 27 (8) | 16 | 11 | 20 | 25% | 2.5 | 0 (2) | 33 (6) | - | 39 (5) | 16 (3) |
| Mine | Holder | 5 | 47 (5) | 0 | 47 | 22 | 80% | 6.0 | 36 (2) | 54 (3) | - | 108 (1) | 30 (4) |
| Mine | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 5 | 65 (5) | 65 | 0 | 60 | 0% | 1.0 | 46 (4) | 142 (1) | - | - | 65 (5) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (2) | 0 (1) | 0 (2) |
| Opponent | Character | 13 | 0 (13) | 0 | 0 | 10 | 46% | 2.6 | 0 (9) | 0 (3) | 0 (1) | 0 (9) | 0 (4) |
| Opponent | Clean-up | 2 | 132 (2) | 0 | 132 | 0 | 100% | - | - | 132 (2) | - | 132 (2) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 8 | 44 (8) | 28 | 16 | 27 | 25% | 2.0 | 87 (3) | 16 (2) | 18 (3) | 44 (8) | - |
| Opponent | Holder | 3 | 76 (3) | 0 | 76 | 0 | 67% | 6.0 | - | 118 (2) | 0 (1) | 163 (1) | 40 (2) |
| Opponent | Shooter | 4 | 73 (4) | 0 | 73 | 26 | 25% | 1.7 | - | 73 (4) | - | 73 (4) | - |
| Opponent | War machine | 9 | 72 (9) | 72 | 0 | 49 | 11% | 1.0 | 72 (9) | - | - | 0 (1) | 84 (8) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: nw22-19bea9b-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 178 | 152 | 1.0 | 1.0 | 152 | 32 | +120 | 1 of 2 | 2 of 2 | - | +120 |
| Mine | Dwarfen Mountain Holds | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 222 | 102 | 0.7 | 1.0 | 152 | 32 | +120 | 1 of 2 | 2 of 2 | - | +120 |
| Opponent | Dwarfen Mountain Holds | 1 | 449 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 578 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 342 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |

### Effective charges: nw22-19bea9b-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 1 (net +95) | 0 | 1 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 95 | +95 | 95 | 0 | +95 | +28.0 |
| Mine | No odds | 1 | 339 | 210 | +145 | 297 | 113 | +184 | +54.2 |
| Mine | All fights | 2 | 339 | 152 | +120 | 196 | 57 | +139 | +41.1 |
| Opponent | 76-89% | 1 | 92 | 112 | +0 | 48 | 18 | +30 | +32.2 |
| Opponent | All fights | 1 | 92 | 112 | +0 | 48 | 18 | +30 | +32.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p3 | move | 14 | 2 (14%) | 1 (7%) | 1 (7%) | 11 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

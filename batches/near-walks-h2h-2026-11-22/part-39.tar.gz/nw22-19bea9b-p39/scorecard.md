# Doctrine scorecard: nw22-19bea9b-p39

### Scorecard: nw22-19bea9b-p39

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 5 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 5 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 473 |
| L0512 | 2 | 1 | Opponent | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 330 |
| **Average** | | | Mine | 50% | 5.0 | 4.0 | 1.7 | 3.0 | 0.0 | 0.0 | 0.0 | 179.3 |
| **Average** | | | Opponent | 0% | 3.0 | 4.0 | 0.3 | 2.0 | 0.0 | 0.0 | 0.0 | 250.0 |

### KPIs: nw22-19bea9b-p39

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 9% (1 of 11) | 0% (0 of 11) | 5% (1 of 22) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 0% | - | 0% (0 of 2); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 60% | 100% (2 of 2); on the table 100% | 71% (5 of 7); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 33% (4 of 12) | 36% (13 of 36) | 35% (17 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (4 of 8) | 38% (13 of 34) | 40% (17 of 42) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 69% (4153 of 5998) | 80% (4824 of 5998) | 75% (8977 of 11996) |
|   infantry points that never fought | lower | 100% (1424 of 1424) | 82% (978 of 1187) | 92% (2402 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (16 of 23) | 78% (21 of 27) | 74% (37 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.3 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3338 of 5120) | 82% (4481 of 5442) | 74% (7819 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (12%) | 4.3 (57%) | 4.7 (45%) |
| MARCHED: its unit marched | 0.7 (25%) | 2.7 (35%) | 3.3 (32%) |
| IN COMBAT: engaged in combat | 1.3 (50%) | 0.3 (4%) | 1.7 (16%) |
| GONE: slain | 0.0 (0%) | 0.3 (4%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (12%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 1.0 | 1.7 | 5.7 | 1.0 | 1.3 |
| not cast | 4.3 | 5.0 | 4.3 | 10.3 | 1.0 | 18.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (93%) | 2.0 (46%) | 4.7 (45%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (32%) | 0.3 (33%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (15%) | 0.0 (0%) | 1.3 (31%) | 1.7 (16%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) | 0.7 (67%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (69%) | 0.0 (0%) | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.3 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 40% (2 of 5) | 40% (2 of 5) |
| the unit moved after it | - | 100% (2 of 2) | 100% (2 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 50% (1 of 2) | 50% (1 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 50% (1 of 2) | 50% (1 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 0% (0 of 2) | 0% (0 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (51 of 83) | 68% (41 of 60) | 64% (92 of 143) |
|   cavalry | 25% (3 of 12) | - | 25% (3 of 12) |
|   character | 60% (6 of 10) | 83% (5 of 6) | 69% (11 of 16) |
|   chariot | 58% (14 of 24) | 100% (6 of 6) | 67% (20 of 30) |
|   infantry | 33% (4 of 12) | 52% (13 of 25) | 46% (17 of 37) |
|   monster | - | 50% (3 of 6) | 50% (3 of 6) |
|   war machine | 96% (24 of 25) | 82% (14 of 17) | 90% (38 of 42) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (38%) | 2.7 (42%) | 6.7 (39%) |
| CHARGED: it charged | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.0 (28%) | 1.0 (16%) | 4.0 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.3 (5%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (25%) | 1.0 (16%) | 3.7 (22%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (16%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 3.7 | 1.3 | 82% | 7.0 pts | 26 pts |
| chariot | 6.7 | 8.3 | 45% | 14.7 pts | 98 pts |
| infantry | 7.0 | 1.3 | 81% | 6.9 pts | 48 pts |
| monster | 2.0 | 0.7 | 67% | 16.1 pts | 32 pts |
| war machine | 12.7 | 8.0 | 66% | 19.2 pts | 243 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 1.0 | 1.7 |
| Charges that made contact a game | 1.7 | 0.7 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) | 0.40 declared, 0.40 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.24 declared, 0.14 contact (21 units) | 0.17 declared, 0.11 contact (18 units) | 0.21 declared, 0.13 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 100% (6 of 6) | 100% (1 of 1) | - | 100% (7 of 7) |
| Character on its own | 100% (1 of 1) | 67% (4 of 6) | 50% (2 of 4) | 64% (7 of 11) |
| Chariot | - | 100% (5 of 5) | - | 100% (5 of 5) |
| Infantry | 50% (6 of 12) | 100% (3 of 3) | - | 60% (9 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 80% (4 of 5) | - | - | 80% (4 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 60% (3 of 5); on the table 60% | 33% (4 of 12) | 56% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 95% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | 100% (1 of 1); on the table 100% | 33% (4 of 12) | 80% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 28% (5 of 18) | 90% | 67% (6 of 9) | 100% (3 of 3); 10.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 72% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p39, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 100% (2) | 75% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p39

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 57% (4 of 7) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (12 of 31) | 57% (17 of 30) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 50% (5 of 10) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 179.3 | 250.0 |
| Movement | Fights charged into per game | 1.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +0 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +157 | 1 of 2, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (11 of 27) | 67% (18 of 27) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 8.0 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (5 of 24) | 29% (4 of 14) |
| Shooting | Points destroyed by war machines | 111.0 | 31.7 |
| Magic | Magic missiles cast | 1.0 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 30% (3 of 10) |
| Magic | Wounds caused by magic missiles | 1.3 | 9.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 0.3 / 0.0 | 1.3 / 0.3 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 206.0 | 31.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +133 | +7 |
| Combat | Net per 100 charger points, damage counted | +43.8 | +5.1 |
| Combat | First round won (charged fights) | 80% | 100% |
| Combat | Net points per charged fight | +124 | +48 |
| Combat | Net points per supported fight / lone fight | - / +124 | - / +48 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 5 | 1 of 2 |
| Game | Points lost | 63.3 | 383.7 |
| Game | VP from objectives | 633.3 | 583.3 |
| Game | Lone holders (player turns) | 5.0 | 3.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +350 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 447
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: nw22-19bea9b-p39

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 18.0 | +138.8 | 0.0 | 0.0 | 21.0 | -51.8 | 0.0 | 30.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 31.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +13.5 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | -92.7 | 86.3 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 56.0 | 31.7 | - | - | - | - |
| CANNON PLANNED TARGET | 7.0 | +94.5 | 280.0 | 63.3 | 4.3 | +59.0 | 31.7 | 166.7 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 3.7 | +29.8 | 63.3 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +9.6 | 0.0 | 0.0 | 0.7 | +7.3 | 0.0 | 30.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +107.0 | 0.0 | 84.7 |
| CHARACTER GUNS | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.7 | -47.2 | 172.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 16.3 | -304.5 | 0.0 | 0.0 | 13.3 | -388.5 | 0.0 | 281.3 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 171.0 | 0.0 | - | - | - | - |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +119.4 | 0.0 | 0.0 |
| COVER ONCE | 5.7 | -197.1 | 0.0 | 0.0 | 8.7 | -967.0 | 0.0 | 84.7 |
| DEPLOY BY FIGURES | 8.7 | +68.3 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 55.0 |
| DUEL STOPS AT THE KILL | 0.3 | -3.5 | 86.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | -19.6 | 86.3 | 0.0 | 1.0 | +29.8 | 31.7 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 257.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 3.3 | +53.6 | 0.0 | 0.0 | 22.3 | +202.8 | 0.0 | 366.0 |
| FEATURE BUFFS | 1.3 | +3.2 | 0.0 | 0.0 | 2.0 | +15.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | -5.7 | 86.3 | 0.0 | - | - | - | - |
| FIVE ACTION | 98.7 | +5466.9 | 944.3 | 126.7 | 91.3 | +3723.9 | 158.3 | 754.7 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 84.7 |
| FOLLOW UP WEIGHED | 1.0 | +215.3 | 0.0 | 0.0 | 0.3 | +9.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +145.1 | 272.3 | 0.0 | 1.0 | +58.3 | 31.7 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +14.9 | 0.0 | 86.3 |
| GIVES UP | - | - | - | - | 0.3 | -13.6 | 31.7 | 0.0 |
| GOAL WALK | 17.7 | +1609.9 | 0.0 | 0.0 | 5.3 | +267.3 | 0.0 | 0.0 |
| GUN FIGURES | 3.3 | +0.9 | 15.0 | 0.0 | 1.7 | +15.4 | 0.0 | 0.0 |
| GUN MASK | 0.7 | +20.7 | 0.0 | 0.0 | 3.0 | -6.6 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 1.0 | +2.5 | 86.3 | 0.0 | 0.7 | +0.3 | 31.7 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 169.3 |
| HIS CHARGE LIST | 7.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS MOVE AND SHOT | 3.0 | -17.4 | 0.0 | 0.0 | 1.7 | -55.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 5.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.0 | +2746.5 | 0.0 | 0.0 | 50.0 | +3545.8 | 0.0 | 222.0 |
| HIS SHOTS BY HIS RUN | 36.3 | +747.2 | 0.0 | 0.0 | 33.3 | +782.6 | 0.0 | 281.3 |
| HIS TURN DENIED | 0.7 | +12.6 | 86.3 | 0.0 | - | - | - | - |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 8.0 | +662.2 | 0.0 | 0.0 | 8.7 | +944.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -108.5 | 272.3 | 0.0 | 1.0 | -24.2 | 31.7 | 0.0 |
| HUNT IN PAIRS | 2.0 | +195.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 3.0 | -57.3 | 0.0 | 0.0 | 15.3 | -265.2 | 0.0 | 15.0 |
| JOINT CHARGE NOW | 0.7 | +23.8 | 172.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +85.7 | 0.0 | 0.0 | - | - | - | - |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 171.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -2.7 | 187.7 | 0.0 | 0.7 | -0.3 | 31.7 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +5.9 | 0.0 | 0.0 | 1.3 | +3.1 | 0.0 | 0.0 |
| MANOEUVRE | 3.0 | -20.3 | 0.0 | 0.0 | 2.3 | +21.7 | 0.0 | 140.7 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +69.7 | 0.0 | 0.0 | 2.3 | +115.6 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +7.8 | 0.0 | 0.0 | 0.7 | +30.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +5.0 | 0.0 | 0.0 | 0.7 | -28.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +67.7 | 0.0 | 0.0 | 2.3 | +12.8 | 0.0 | 56.0 |
| MEETS IN TIME | 5.3 | +153.3 | 0.0 | 0.0 | 2.3 | +27.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +86.0 | 0.0 | 0.0 | 8.7 | +83.6 | 0.0 | 112.0 |
| MISSILES NEXT TURN | 2.3 | +48.6 | 0.0 | 0.0 | 11.3 | +73.3 | 0.0 | 112.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.0 | +70.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.0 | -101.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 0.3 | +3.9 | 0.0 | 0.0 | 2.0 | +47.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 10.0 | +418.8 | 0.0 | 0.0 | 8.3 | +355.5 | 0.0 | 140.7 |
| NEXT CHARGE BY LIST | 0.3 | +3.9 | 0.0 | 0.0 | 0.7 | +34.6 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.7 | +29.6 | 172.7 | 0.0 | 1.0 | +19.7 | 31.7 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -70.7 | 186.0 | 0.0 | 0.3 | -13.8 | 0.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -81.2 | 0.0 | 0.0 | 4.7 | -152.7 | 0.0 | 84.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.0 | -40.7 | 0.0 | 0.0 | 1.7 | -37.7 | 0.0 | 56.0 |
| ONE JOINT FIGURE | 0.7 | +31.6 | 172.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.7 | +3.8 | 0.0 | 0.0 | 3.7 | -70.0 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.0 | +14.0 | 172.7 | 0.0 | 0.7 | +7.2 | 31.7 | 0.0 |
| OVERRUNS AWAY | 1.3 | +14.0 | 172.7 | 0.0 | 0.7 | +1.6 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | -4.2 | 0.0 | 0.0 | 0.7 | -0.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 45.3 | +556.3 | 425.3 | 126.7 | 41.3 | +173.0 | 0.0 | 354.0 |
| PROMISE BY ITS OWN SUM | 2.7 | -60.8 | 0.0 | 0.0 | 4.0 | -82.4 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 17.7 | +1828.6 | 172.7 | 0.0 | 16.0 | +1434.7 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +28.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 30.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 15.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.7 | -88.0 | 187.7 | 0.0 | 1.0 | -43.0 | 31.7 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -3.8 | 172.7 | 0.0 | - | - | - | - |
| RUN DOWN | 0.3 | -3.0 | 0.0 | 0.0 | 0.3 | -2.6 | 0.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.0 | -73.3 | 0.0 | 0.0 | 0.7 | -33.9 | 0.0 | 30.0 |
| SEARCH SPOT | 0.7 | +16.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.0 | -136.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.0 | +129.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.3 | +5.9 | 0.0 | 0.0 | 1.3 | +3.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.0 | +0.0 | 0.0 | 63.3 | 11.3 | +0.0 | 0.0 | 181.7 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +70.5 | 0.0 | 0.0 | 1.3 | +102.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -9.9 | 31.7 | 0.0 |
| SHOT RISK POINTS | 28.3 | +74.7 | 0.0 | 0.0 | 21.7 | -141.1 | 0.0 | 281.3 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +487.7 | 0.0 | 63.3 | 14.7 | +334.5 | 0.0 | 221.7 |
| SPELL WORTH | 0.7 | +18.1 | 0.0 | 0.0 | 2.0 | +29.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -5.1 | 0.0 | 0.0 | 0.7 | +6.1 | 31.7 | 0.0 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 84.7 |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 55.3 | +0.0 | 672.0 | 126.7 | 32.0 | +0.0 | 126.7 | 612.7 |
| STAY WORTH | 26.7 | +79.7 | 560.0 | 95.0 | 25.3 | -77.7 | 126.7 | 555.0 |
| STRIKE BY THE ODDS | 1.0 | -0.3 | 192.7 | 0.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.3 | +54.0 | 0.0 | 0.0 | 5.0 | +255.1 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +54.0 | 0.0 | 0.0 | 5.0 | +255.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +9.5 | 0.0 | 0.0 | 1.0 | +2.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.0 | -1.6 | 187.7 | 0.0 | 0.3 | +17.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 56.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.0 | +0.0 | 0.0 | 63.3 | 46.7 | +0.0 | 0.0 | 337.3 |
| TIED UP BY THE SUM | 0.3 | +29.4 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 50.3 | +546.2 | 112.0 | 0.0 | 8.7 | +90.3 | 0.0 | 0.0 |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 0.3 | -12.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | 0.3 | +34.2 | 86.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.0 | +82.3 | 0.0 | 31.7 | 0.3 | +112.4 | 0.0 | 86.3 |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 4.0 | +68.3 | 0.0 | 0.0 | 3.3 | +52.4 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p39

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 297 | 292 | 95 | 31.67 | +1674 | +17.6 |
| ARMY TABLE | 117 | 117 | 85 | 28.33 | +406 | +4.8 |
| HIS SHOTS BY HIS RUN | 209 | 207 | 62 | 20.67 | +805 | +13.0 |
| HOLDER ASSIGNMENT | 50 | 50 | 48 | 16.00 | +3725 | +77.6 |
| SHOT RISK POINTS | 150 | 150 | 28 | 9.33 | +519 | +18.5 |
| GOAL WALK | 69 | 69 | 26 | 8.67 | +1491 | +57.4 |
| TIME ON OUR SIDE | 177 | 169 | 25 | 8.33 | +136 | +5.4 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -702 | -31.9 |
| DEPLOY BY FIGURES | 45 | 45 | 21 | 7.00 | +420 | +20.0 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| QUARTER ODDS | 101 | 98 | 13 | 4.33 | +1031 | +79.3 |
| MEETS IN TIME | 23 | 23 | 12 | 4.00 | +398 | +33.1 |
| LEGAL CHARGES ONLY | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| FIVE ACTION | 570 | 565 | 10 | 3.33 | +725 | +72.5 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 9 | 3.00 | +109 | +12.1 |
| SUPPORT ADDS | 19 | 19 | 9 | 3.00 | +189 | +21.0 |
| SUPPORT WORKED OUT | 19 | 19 | 9 | 3.00 | +189 | +21.0 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 55 | 40 | 8 | 2.67 | +86 | +10.8 |
| MARCH CHECK | 10 | 9 | 8 | 2.67 | +115 | +14.4 |
| PROMISE BY ITS OWN SUM | 20 | 20 | 8 | 2.67 | -430 | -53.7 |
| CHARGE LOSSES | 89 | 89 | 6 | 2.00 | +283 | +47.2 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| COVER ONCE | 43 | 31 | 5 | 1.67 | +139 | +27.9 |
| FOUR ROUNDS | 10 | 10 | 5 | 1.67 | +83 | +16.6 |
| NO CHAFF EDGES | 8 | 8 | 5 | 1.67 | +127 | +25.5 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 77 | 68 | 4 | 1.33 | +36 | +9.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +675 | +168.7 |
| GUN MASK | 11 | 11 | 4 | 1.33 | +86 | +21.5 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +257 | +64.3 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 22 | 22 | 4 | 1.33 | +8 | +1.9 |
| MANOEUVRE | 16 | 16 | 3 | 1.00 | +69 | +22.9 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -116 | -38.5 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 19 | 17 | 3 | 1.00 | +278 | +92.5 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | -15 | -4.9 |
| SET UP BY THE SET | 6 | 6 | 3 | 1.00 | +136 | +45.4 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| THE ROW IN ITS ORDER | 18 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 34 | 34 | 2 | 0.67 | +0 | +0.0 |
| CAST JOB | 11 | 11 | 2 | 0.67 | +2 | +0.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +321 | +160.5 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +72 | +35.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MAX FOR POSITIONING | 13 | 12 | 2 | 0.67 | +7 | +3.4 |
| MISSILES IN THE MOVE | 30 | 24 | 2 | 0.67 | +77 | +38.5 |
| MOVE TO CHARGE COMPUTED | 7 | 7 | 2 | 0.67 | +59 | +29.7 |
| NEARER NOT NEEDED | 55 | 53 | 2 | 0.67 | +85 | +42.5 |
| NEXT CHARGE BY LIST | 3 | 3 | 2 | 0.67 | +59 | +29.7 |
| OPENS UP IN FULL | 5 | 5 | 2 | 0.67 | +43 | +21.5 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +17 | +8.5 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +51 | +25.3 |
| SHOTS IN THE MOVE | 91 | 72 | 2 | 0.67 | +25 | +12.6 |
| STAY WORTH | 156 | 141 | 2 | 0.67 | +26 | +13.0 |
| STRIKE BY THE ODDS | 3 | 3 | 2 | 0.67 | +54 | +27.1 |
| SURE REACH TOGETHER | 6 | 6 | 2 | 0.67 | +4 | +1.8 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -183 | -182.9 |
| EXACT ROUND | 6 | 6 | 1 | 0.33 | +10 | +9.8 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +45 | +44.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +5 | +4.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -17 | -16.7 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -132 | -131.9 |
| RISK BY ARC | 8 | 8 | 1 | 0.33 | +0 | +0.4 |
| SHOTS AFTER THE MOVES | 21 | 21 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 3 | 3 | 1 | 0.33 | +10 | +9.8 |
| THE FIGHT MOVES | 4 | 4 | 1 | 0.33 | +0 | +0.4 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +5 | +4.8 |
| BACKS UP THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 3 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 54 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 11 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 35 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 11 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 14 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 37 | 34 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 11 | 11 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 87 | 87 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 6 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 41 | 34 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| NO DOUBLE ROUNDS | 7 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 11 | 8 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 260 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 73 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 26 | 24 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 262 | 260 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 287 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p39

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 4.67 | 31.9 |
| ARMY TABLE | rule | 1.33 | 2.33 | 112.8 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 2.00 | 53.7 |
| MARCH OF THE TABLE | rule | 0.33 | 0.67 | 38.5 |
| PATHS CROSS | rule | 0.33 | 0.33 | 7.3 |
| CHARGE NOW FIRST | rule | 0.33 | - | 182.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 9.1 |
| JOINT CHARGE NOW | rule | 0.33 | - | 15.2 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 16.7 |
| REFUSING RETIRES | rule | 0.33 | - | 131.9 |

### Plans: nw22-19bea9b-p39

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 60% | 272 | 133 | 49% |
| Mine | join | 1.7 | 100% | 58 | 0 | 0% |
| Mine | move | 32.7 | 99% | 1832 | 0 | 0% |
| Mine | shoot | 8.7 | 50% | 331 | 423 | 128% |
| Mine | support | 0.7 | 100% | 0 | 0 | - |
| Opponent | charge | 0.3 | 100% | 0 | 32 | - |
| Opponent | join | 2.0 | 100% | 114 | 0 | 0% |
| Opponent | move | 30.7 | 98% | 1036 | 0 | 0% |
| Opponent | shoot | 8.0 | 50% | 486 | 141 | 29% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p39

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 100% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p39

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 22 (11) | 22 | 0 | 0 | 45% | 3.3 | 36 (6) | 0 (5) | - | 29 (7) | 12 (4) |
| Mine | Clean-up | 7 | 57 (7) | 6 | 51 | 0 | 86% | 2.0 | 9 (4) | 148 (2) | 125 (1) | 37 (5) | 103 (2) |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 0 | 33% | 2.5 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Holder | 2 | 76 (2) | 0 | 76 | 0 | 100% | - | 151 (1) | 0 (1) | - | 76 (2) | - |
| Mine | Shooter | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 5 | 70 (5) | 70 | 0 | 40 | 0% | 1.0 | 175 (2) | 0 (1) | 0 (2) | - | 70 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 18 | 75% | 2.0 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 5 (9) | 5 | 0 | 0 | 33% | 3.3 | 0 (3) | 10 (5) | 0 (1) | 6 (6) | 0 (3) |
| Opponent | Clean-up | 2 | 34 (2) | 0 | 34 | 57 | 50% | 3.0 | 79 (1) | 0 (1) | - | 79 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 37 | 0% | 2.7 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 75 (3) | 0 | 75 | 31 | 33% | 3.0 | - | 109 (2) | 0 (1) | 110 (2) | 0 (1) |
| Opponent | Shooter | 3 | 48 (3) | 0 | 48 | 0 | 0% | 1.0 | - | 87 (1) | 29 (2) | 72 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 13 (5) | 13 | 0 | 59 | 20% | 1.0 | - | - | 13 (5) | - | 13 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 8 | 0% | 2.8 | 0 (3) | 0 (1) | - | 0 (2) | 0 (2) |

### Charged fights: nw22-19bea9b-p39

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 309 | 2.5 | 1.0 | 124 | 0 | +124 | 3 of 5 | 4 of 5 | - | +124 |
| Mine | Dwarfen Mountain Holds | 1 | 333 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 111 | 206 | 1.7 | 1.0 | 124 | 0 | +124 | 3 of 5 | 4 of 5 | - | +124 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 95 | 95 | 1.0 | 1.0 | 95 | 0 | +95 | 0 of 1 | 1 of 1 | - | +95 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 32 | 32 | 0.7 | 1.0 | 48 | 0 | +48 | 1 of 2 | 2 of 2 | - | +48 |

### Effective charges: nw22-19bea9b-p39

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 5 | 1 (net +0) | 0 | 0 | 1 (net +45) | 0 | 2 (net +157) | 1 | 0% (0 of 4) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +95) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p39

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 112 | 211 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 112 | 45 | +45 | 45 | 0 | +45 | +40.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 480 | 232 | +157 | 230 | 0 | +230 | +47.8 |
| Mine | No odds | 1 | 339 | 209 | +259 | 259 | 97 | +162 | +47.8 |
| Mine | All fights | 5 | 305 | 186 | +124 | 153 | 19 | +133 | +43.8 |
| Opponent | 76-89% | 1 | 205 | 95 | +95 | 170 | 157 | +13 | +6.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 50 | 339 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 2 | 128 | 217 | +48 | 85 | 78 | +7 | +5.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p39 | move | 6 | 2 (33%) | 1 (17%) | 0 (0%) | 4 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

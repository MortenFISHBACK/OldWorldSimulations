# Doctrine scorecard: nw22-19bea9b-p48

### Scorecard: nw22-19bea9b-p48

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 4 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | yes | 6 | 4 | 3 | 3 | 0 | 0 | 0 | 125 |
| L2735 | 5 | 1 | Mine | no | - | - | 1 | 4 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 5 | 5 | 0 | 0 | 0 | 250 |
| L3033 | 3 | 1 | Mine | yes | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 1 | 0 | 0 | 38 |
| **Average** | | | Mine | 33% | 6.0 | 2.0 | 2.0 | 2.0 | 0.3 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 67% | 3.0 | 3.0 | 3.7 | 3.3 | 0.3 | 0.0 | 0.0 | 137.7 |

### KPIs: nw22-19bea9b-p48

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 31% (5 of 16) | 16% (5 of 31) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (9 of 9); on the table 100% | 91% (10 of 11); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 33% (1 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 50% (1 of 2); on the table 100% | 60% (3 of 5); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 43% (3 of 7); on the table 71% | 92% (11 of 12); on the table 100% | 74% (14 of 19); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 54% (13 of 24) | 39% (7 of 18) | 48% (20 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 62% (13 of 21) | 47% (7 of 15) | 56% (20 of 36) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 12% (745 of 5999) | 50% (2999 of 6000) | 31% (3744 of 11999) |
|   infantry points that never fought | lower | 42% (330 of 780) | 64% (1224 of 1918) | 58% (1554 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (9 of 18) | 71% (24 of 34) | 63% (33 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 1.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (2198 of 4808) | 68% (4077 of 5962) | 58% (6275 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (36%) | 2.0 (55%) | 3.3 (45%) |
| MARCHED: its unit marched | 0.3 (9%) | 0.3 (9%) | 0.7 (9%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | 0.3 (9%) | 0.7 (9%) |
| GONE: slain | 0.7 (18%) | 0.7 (18%) | 1.3 (18%) |
| STUPIDITY: Stupidity | 1.0 (27%) | 0.0 (0%) | 1.0 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 2.0 | 2.0 | 6.7 | 1.0 | 0.0 |
| not cast | 5.0 | 0.7 | 4.0 | 7.3 | 5.0 | 24.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 3.3 (45%) | 2.0 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.3 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (17%) | 0.7 (9%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (13%) | 0.0 (0%) | 0.7 (17%) | 1.3 (18%) | 1.3 (27%) | 1.7 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (14%) | 0.0 (0%) | 2.0 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 1.3 (27%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (47%) | 0.0 (0%) | 2.3 (58%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 1.3 a game | 1.0 a game |
| stood (cast and not dispelled) | 100% (2 of 2) | 25% (1 of 4) | 50% (3 of 6) |
| the unit moved after it | 100% (2 of 2) | 100% (1 of 1) | 100% (3 of 3) |
| it charged on its next turn | 0% (0 of 2) | 100% (1 of 1) | 33% (1 of 3) |
| the enemy charged it first | 0% (0 of 2) | 0% (0 of 1) | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 2) | 0% (0 of 1) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 0% (0 of 1) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | 0% (0 of 1) | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 4) | 60% (61 of 101) | 58% (61 of 105) |
|   cavalry | - | 68% (32 of 47) | 68% (32 of 47) |
|   character | 0% (0 of 4) | 53% (9 of 17) | 43% (9 of 21) |
|   infantry | - | 54% (20 of 37) | 54% (20 of 37) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (25%) | 5.7 (42%) | 6.0 (41%) |
| CHARGED: it charged | 0.7 (50%) | 4.3 (32%) | 5.0 (34%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 2.0 (15%) | 2.0 (14%) |
| NO TARGET IN RANGE | 0.3 (25%) | 0.7 (5%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (5%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.3 | 4.3 | 81% | 2.5 pts | 36 pts |
| character | 3.0 | 1.3 | 56% | 10.8 pts | 32 pts |
| infantry | 8.3 | 8.0 | 52% | 16.4 pts | 136 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 5.7 | 4.5 |
| Charges that made contact a game | 2.7 | 5.0 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | - | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.40 contact (20 units) | 0.55 declared, 0.48 contact (31 units) | 0.53 declared, 0.45 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (7 of 11) | 0% (0 of 2) | 100% (1 of 1) | 57% (8 of 14) |
| Character in a unit | 75% (3 of 4) | 60% (3 of 5) | 0% (0 of 1) | 60% (6 of 10) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 40% (2 of 5) | 57% (4 of 7) |
| Infantry | 67% (8 of 12) | 100% (3 of 3) | - | 73% (11 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 40% (2 of 5); on the table 80% | 54% (13 of 24) | 17% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | - | 4% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 92% (11 of 12); on the table 100% | 39% (7 of 18) | 50% | 71% (24 of 34) | 50% (2 of 4); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p48, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 62% (8) | 0% (0) | 57% (8) |
| ...free all their last turn and able to turn (per game) | 2.67 | 0.00 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.67 | 0.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p48

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 71% (5 of 7) | 64% (9 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 5) | 36% (4 of 11) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 25% (1 of 4) |
| Strategy | Joined characters whose unit fought | 71% (5 of 7) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 57% (4 of 7) | 100% (3 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.3 |
| Movement | Points that never moved of their own | 0.0 | 137.7 |
| Movement | Fights charged into per game | 2.3 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 3 of 12, net -12 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 2 of 12, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 5, net +170 | 1 of 12, net +190 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +140 | 3 of 12, net +169 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.7 | 20.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 42% (26 of 62) |
| Shooting | Points destroyed by shooting units | 0.0 | 15.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 3.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (2 of 10) | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | - | 6.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.3 / 0.0 / 0.7 | 1.0 / 1.3 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 195.0 | 440.7 |
| Combat | Points run down | 0.0 | 23.3 |
| Combat | Net points per charged fight, damage counted | +80 | +80 |
| Combat | Net per 100 charger points, damage counted | +23.2 | +26.7 |
| Combat | First round won (charged fights) | 71% | 62% |
| Combat | Net points per charged fight | +71 | +81 |
| Combat | Net points per supported fight / lone fight | +104 / +66 | +45 / +88 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 7 | 6 of 13 |
| Game | Points lost | 536.7 | 326.7 |
| Game | VP from objectives | 533.3 | 630.0 |
| Game | Lone holders (player turns) | 6.0 | 3.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -288 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 863
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: nw22-19bea9b-p48

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +35.7 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 21.3 | +366.7 | 0.0 | 289.3 | 32.7 | +328.5 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -4.5 | 20.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | -7.6 | 46.7 | 0.0 | 0.3 | -1.2 | 23.3 | 0.0 |
| CAST JOB | 2.3 | +13.8 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.3 | +13.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 3.3 | +113.7 | 0.0 | 30.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 3.0 | -1.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +2.7 | 0.0 | 0.0 | 0.3 | +21.4 | 0.0 | 78.7 |
| CHARACTER GUNS | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.3 | +0.0 | 78.7 | 0.0 | 1.3 | -92.0 | 20.0 | 34.0 |
| CHARGE LOSSES | 27.0 | -1148.5 | 0.0 | 703.3 | 14.0 | -433.6 | 0.0 | 0.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 34.7 | 0.0 | 0.3 | +0.0 | 23.3 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 125.3 | 0.0 | 2.7 | +0.0 | 161.0 | 0.0 |
| CLEAR LANE AHEAD | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.3 | +0.0 | 0.0 | 193.7 | 6.7 | +0.0 | 0.0 | 69.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 95.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +14.2 | 0.0 | 0.0 | 1.3 | +97.5 | 0.0 | 0.0 |
| COVER ONCE | 11.0 | -1086.3 | 0.0 | 288.3 | 14.7 | -550.6 | 0.0 | 0.0 |
| DEFENSIVE ARMY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.7 | -4.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +59.8 | 0.0 | 0.0 | 9.3 | -113.8 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -9.7 | 0.0 | 0.0 | 0.3 | -47.7 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +12.7 | 125.3 | 0.0 | 0.7 | +60.4 | 25.0 | 46.7 |
| EXACT ROUND | 2.0 | +3.6 | 87.7 | 0.0 | 3.3 | +22.6 | 179.3 | 88.7 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +8.1 | 75.7 | 0.0 | 4.0 | +0.0 | 274.0 | 122.7 |
| FALLS SHORT | 23.7 | +291.7 | 0.0 | 422.7 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +0.6 | 0.0 | 0.0 | 1.0 | +23.8 | 72.3 | 0.0 |
| FIVE ACTION | 82.7 | +4192.3 | 201.0 | 1218.0 | 100.3 | +7280.0 | 464.0 | 458.7 |
| FLANK NOT WEIGHED | 11.3 | +0.0 | 0.0 | 317.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +45.0 | 0.0 | 0.0 | 2.0 | +215.6 | 0.0 | 80.7 |
| FOUR ROUNDS | 3.0 | +144.6 | 201.0 | 0.0 | 4.7 | +480.4 | 274.0 | 122.7 |
| FREED FROM HIS FIGHT | 5.0 | +0.0 | 0.0 | 222.3 | 6.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -3.1 | 0.0 | 0.0 | 0.7 | -2.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +4.6 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -48.7 | 34.7 | 0.0 | 1.0 | -7.1 | 85.3 | 0.0 |
| GOAL WALK | 5.7 | +623.9 | 0.0 | 124.0 | 20.0 | +1612.5 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.3 | -0.1 | 0.0 | 0.0 | 2.3 | +0.7 | 23.3 | 76.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 127.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 76.0 |
| HIS CHARGE BY HIS RUN | 19.7 | +0.0 | 0.0 | 579.3 | 11.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.7 | +7.6 | 69.3 | 0.0 | 0.7 | +18.2 | 0.0 | 0.0 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 282.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 186.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 7.0 | -61.5 | 0.0 | 252.0 | 1.3 | -7.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 42.0 |
| HIS OWN BEST MOVE | 12.3 | +0.0 | 0.0 | 186.0 | 12.7 | +0.0 | 0.0 | 69.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 60.7 | +1135.0 | 0.0 | 790.0 | 33.0 | +413.9 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 66.3 | +871.8 | 0.0 | 1090.7 | 27.3 | +210.7 | 0.0 | 0.0 |
| HIS TURN DENIED | 1.0 | +19.7 | 46.7 | 0.0 | 1.0 | +6.5 | 20.0 | 34.0 |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 86.7 | 9.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +496.4 | 0.0 | 43.3 | 6.3 | +460.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 3.0 | -89.8 | 201.0 | 0.0 | 4.3 | -192.8 | 274.0 | 80.7 |
| HORN WORTH | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| IDLE COST | 17.0 | -216.1 | 0.0 | 210.0 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +129.1 | 0.0 | 76.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +25.3 | 0.0 | 0.0 | 0.7 | +40.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 180.7 | 402.7 | 4.3 | +0.0 | 197.7 | 68.0 |
| LONG SHOT | 0.7 | +3.5 | 34.7 | 0.0 | 0.7 | -1.5 | 48.3 | 46.7 |
| LOST AFTER ESCAPE | 0.7 | +0.2 | 0.0 | 0.0 | 2.7 | -0.3 | 56.0 | 76.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +21.4 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 82.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +8.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +2.5 | 0.0 | 0.0 | 0.7 | +30.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -2.7 | 0.0 | 0.0 | 0.7 | +68.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +36.7 | 0.0 | 25.0 | 1.3 | +14.3 | 0.0 | 6.3 |
| MEETS IN TIME | 3.3 | +190.8 | 0.0 | 0.0 | 5.0 | +92.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +21.6 | 0.0 | 20.0 | 6.0 | +194.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +11.6 | 0.0 | 20.0 | 5.7 | +109.0 | 0.0 | 0.0 |
| MOVE ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 69.3 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.7 | -39.3 | 0.0 | 78.0 |
| MOVE TO CHARGE COMPUTED | 8.7 | +1163.8 | 0.0 | 0.0 | 8.7 | +725.7 | 0.0 | 153.3 |
| NEAR WALKS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.0 | +240.4 | 0.0 | 82.0 | 8.0 | +350.2 | 0.0 | 78.7 |
| NEXT CHARGE BY LIST | 6.7 | +947.8 | 0.0 | 0.0 | 7.3 | +594.3 | 0.0 | 111.3 |
| NO CHAFF EDGES | 1.7 | +75.5 | 0.0 | 57.7 | 4.0 | +85.4 | 132.0 | 102.0 |
| NO DOUBLE ROUNDS | 2.7 | -76.5 | 201.0 | 0.0 | 2.7 | -254.0 | 187.0 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.0 | -2.0 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -171.3 | 0.0 | 15.0 | 7.0 | -236.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -105.1 | 0.0 | 120.0 | 9.0 | -160.4 | 0.0 | 76.7 |
| ONE JOINT FIGURE | 0.3 | +1.3 | 0.0 | 0.0 | 1.0 | +49.6 | 0.0 | 76.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -98.8 | 0.0 | 43.3 | 2.0 | -55.1 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.3 | -76.5 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +13.8 | 34.7 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 0.7 | +21.0 | 34.7 | 0.0 | 1.0 | +12.1 | 62.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +33.4 | 85.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 1.0 | +24.3 | 0.0 | 0.0 |
| PLAN RESULT | 43.3 | +270.3 | 0.0 | 842.7 | 45.3 | +489.5 | 142.3 | 450.0 |
| PRIZE BY WORTH | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.3 | -410.8 | 0.0 | 0.0 | 14.3 | -530.9 | 0.0 | 42.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.7 | -16.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -3.1 | 0.0 | 0.0 | 0.3 | -41.7 | 0.0 | 0.0 |
| QUARTER ODDS | 19.0 | +1842.2 | 78.7 | 209.3 | 27.0 | +3150.0 | 94.7 | 126.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 5.3 | +384.5 | 0.0 | 78.3 | 0.3 | -4.1 | 0.0 | 6.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 50.0 | 0.7 | +0.0 | 0.0 | 12.7 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.7 | -22.7 | 0.0 | 0.0 | 4.7 | -44.3 | 0.0 | 42.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +17.2 | 0.0 | 0.0 | 1.0 | +93.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | -66.7 | 154.3 | 0.0 | 3.0 | +145.1 | 274.0 | 46.7 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.0 | -13.0 | 46.7 | 0.0 | - | - | - | - |
| RUN DOWN | 3.0 | -26.6 | 201.0 | 0.0 | 0.7 | -9.0 | 56.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.0 | -0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.0 | -75.2 | 0.0 | 30.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +9.1 | 34.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 6.3 | -161.9 | 0.0 | 146.7 | 1.3 | -245.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 7.7 | +109.2 | 0.0 | 146.7 | 3.0 | +332.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +21.4 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +21.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.3 | +0.0 | 0.0 | 15.0 | 4.3 | +0.0 | 0.0 | 78.7 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +109.8 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 48.0 | -509.1 | 0.0 | 905.0 | 11.7 | +93.0 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +70.2 | 0.0 | 0.0 | 19.0 | +219.8 | 0.0 | 78.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +21.3 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +3.2 | 0.0 | 0.0 | 1.0 | +1.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 14.7 | +0.0 | 0.0 | 485.7 | 8.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 13.0 | +0.0 | 0.0 | 219.3 | 45.3 | +0.0 | 190.0 | 182.7 |
| STAY WORTH | 0.3 | +0.3 | 0.0 | 0.0 | 13.0 | +54.2 | 50.0 | 42.0 |
| STRIKE BY THE ODDS | 0.3 | +1.9 | 0.0 | 23.3 | 1.3 | +7.8 | 0.0 | 102.7 |
| STRONG ENOUGH TO HOLD | 2.7 | -19.2 | 0.0 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| STUBBORN ONCE | - | - | - | - | 0.7 | -15.7 | 0.0 | 34.0 |
| STUPIDITY NEXT TURN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.7 | +627.4 | 0.0 | 124.0 | 1.7 | +53.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 46.7 | 0.0 | 0.3 | +0.0 | 23.3 | 0.0 |
| SUPPORT WORKED OUT | 3.7 | +627.4 | 0.0 | 124.0 | 1.7 | +53.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +2.8 | 0.0 | 0.0 | 0.7 | +5.6 | 0.0 | 34.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 87.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.0 | +3.1 | 78.7 | 0.0 | 1.7 | +2.1 | 56.0 | 42.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -98.3 | 0.0 | 42.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 32.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.7 | +0.0 | 0.0 | 23.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 23.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.3 | +0.0 | 0.0 | 614.0 | 47.0 | +0.0 | 0.0 | 168.0 |
| TIED UP BY THE SUM | 1.3 | +171.1 | 166.3 | 0.0 | 0.7 | +93.8 | 124.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 55.7 | +562.8 | 50.0 | 151.3 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -2.9 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | -2.5 | 6.3 | 0.0 | 0.3 | -0.8 | 62.0 | 0.0 |
| WHO HITS BACK | 0.7 | +204.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -622.2 | 0.0 | 233.0 | 3.0 | -379.6 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +8.3 | 0.0 | 76.0 |
| WHOLE FIGHT REACTION | 1.0 | +111.8 | 0.0 | 56.0 | 2.0 | +81.6 | 0.0 | 131.7 |
| WOUNDS ON THE RANKS | 8.7 | +355.2 | 0.0 | 0.0 | 2.3 | +18.8 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p48

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 162 | 162 | 127 | 42.33 | +1978 | +15.6 |
| HIS SHOT LIST | 281 | 265 | 48 | 16.00 | +416 | +8.7 |
| HOLDER ASSIGNMENT | 46 | 46 | 40 | 13.33 | +2296 | +57.4 |
| HIS SHOTS BY HIS RUN | 281 | 266 | 33 | 11.00 | +432 | +13.1 |
| FIVE ACTION | 549 | 516 | 32 | 10.67 | +1380 | +43.1 |
| OFF BEST | 32 | 32 | 32 | 10.67 | -1223 | -38.2 |
| MOVE TO CHARGE COMPUTED | 52 | 43 | 31 | 10.33 | +1190 | +38.4 |
| DEPLOY BY FIGURES | 49 | 49 | 30 | 10.00 | +280 | +9.3 |
| LEGAL CHARGES ONLY | 30 | 30 | 30 | 10.00 | +0 | +0.0 |
| HARD STAY DROPPED | 29 | 29 | 29 | 9.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 74 | 74 | 28 | 9.33 | -2825 | -100.9 |
| GOAL WALK | 77 | 75 | 25 | 8.33 | +1293 | +51.7 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 42 | 38 | 24 | 8.00 | +1026 | +42.8 |
| QUARTER ODDS | 138 | 133 | 23 | 7.67 | +1849 | +80.4 |
| TIME ON OUR SIDE | 167 | 129 | 23 | 7.67 | +79 | +3.4 |
| MOVE ORDER | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| COVER ONCE | 77 | 49 | 16 | 5.33 | +287 | +17.9 |
| NO CHAFF EDGES | 17 | 17 | 13 | 4.33 | +425 | +32.7 |
| SET UP BY THE SET | 32 | 30 | 13 | 4.33 | +971 | +74.7 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SHOT RISK POINTS | 179 | 175 | 11 | 3.67 | +33 | +3.0 |
| FOUR ROUNDS | 23 | 21 | 10 | 3.33 | +481 | +48.1 |
| WOUNDS ON THE RANKS | 33 | 33 | 10 | 3.33 | +123 | +12.3 |
| CHAFF PASSED | 9 | 9 | 9 | 3.00 | -5 | -0.6 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +782 | +86.9 |
| IDLE COST | 51 | 36 | 8 | 2.67 | +29 | +3.7 |
| MEETS IN TIME | 25 | 25 | 8 | 2.67 | +212 | +26.5 |
| CAST JOB | 7 | 7 | 7 | 2.33 | +5 | +0.6 |
| CHAFF IN THE MOVE | 10 | 10 | 6 | 2.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 6 | 6 | 6 | 2.00 | +2 | +0.3 |
| CHARGE LOSSES | 123 | 115 | 5 | 1.67 | +304 | +60.7 |
| MAX FOR POSITIONING | 11 | 10 | 5 | 1.67 | +9 | +1.8 |
| RISK BY ARC | 17 | 16 | 5 | 1.67 | +58 | +11.6 |
| STRIKE BY THE ODDS | 5 | 5 | 5 | 1.67 | +29 | +5.8 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +72 | +18.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +197 | +49.2 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -229 | -57.4 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 4 | 1.33 | -48 | -12.1 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +331 | +82.8 |
| SURE REACH TOGETHER | 5 | 5 | 4 | 1.33 | +4 | +1.1 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +387 | +129.1 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +73 | +24.3 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 3 | 1.00 | +144 | +47.9 |
| SUPPORT ADDS | 16 | 14 | 3 | 1.00 | +66 | +22.1 |
| SUPPORT WORKED OUT | 16 | 14 | 3 | 1.00 | +66 | +22.1 |
| TIED UP BY THE SUM | 6 | 5 | 3 | 1.00 | +103 | +34.4 |
| CARRIES OUT SET-UP | 2 | 2 | 2 | 0.67 | -26 | -13.2 |
| CHARGE NOT DECLARED | 2 | 2 | 2 | 0.67 | -35 | -17.6 |
| EDGE GIVE GROUND | 4 | 3 | 2 | 0.67 | +56 | +27.9 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 22 | 20 | 2 | 0.67 | +47 | +23.7 |
| ONE JOINT FIGURE | 4 | 4 | 2 | 0.67 | +61 | +30.5 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -10 | -5.2 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +10 | +4.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +376 | +187.9 |
| WHOLE FIGHT DANGER | 19 | 13 | 2 | 0.67 | +42 | +21.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +107 | +107.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 1 | 1 | 1 | 0.33 | +34 | +33.8 |
| CHARGE NOW FIRST | 11 | 11 | 1 | 0.33 | -26 | -26.5 |
| EXACT ROUND | 16 | 14 | 1 | 0.33 | +2 | +1.8 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 71 | 58 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +14 | +13.8 |
| HIS CHARGE DENIED | 4 | 4 | 1 | 0.33 | +8 | +8.3 |
| HIS TURN DENIED | 6 | 5 | 1 | 0.33 | +3 | +2.9 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +3 | +3.3 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +70 | +69.6 |
| MISSILES IN THE MOVE | 30 | 18 | 1 | 0.33 | +31 | +30.8 |
| NEARER NOT NEEDED | 45 | 43 | 1 | 0.33 | +19 | +18.6 |
| ONE OBJECTIVE FORMULA | 22 | 16 | 1 | 0.33 | +4 | +3.8 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +27 | +27.3 |
| OPENS UP IN FULL | 5 | 5 | 1 | 0.33 | +27 | +27.3 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +65 | +65.2 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| PROMISE READS THE TABLE | 5 | 5 | 1 | 0.33 | -123 | -123.3 |
| REDIRECT COUNTER | 17 | 15 | 1 | 0.33 | +13 | +13.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +118 | +117.6 |
| SAME CHARGE LATER | 1 | 1 | 1 | 0.33 | +4 | +3.6 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +27 | +27.3 |
| SHOTS AFTER THE MOVES | 10 | 10 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 59 | 36 | 1 | 0.33 | +16 | +15.9 |
| STAY WORTH | 40 | 30 | 1 | 0.33 | +4 | +3.8 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.3 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -40 | -40.1 |
| THE ROW IN ITS ORDER | 18 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -9 | -8.6 |
| WHOLE FIGHT REACTION | 9 | 9 | 1 | 0.33 | +0 | +0.1 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 19 | 18 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 35 | 34 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 8 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 16 | 16 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 94 | 86 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 32 | 30 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 40 | 32 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 75 | 62 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 74 | 74 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 9 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 31 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| NEAR WALKS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 16 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 44 | 23 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 266 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 19 | 14 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 23 | 21 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 20 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 70 | 65 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 175 | 158 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 8 | 8 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 14 | not checked | - | - | - | - |
| THE FIGHT MOVES | 8 | 7 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 265 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 12 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p48

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 6.00 | 42.8 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 6.33 | 100.9 |
| ARMY TABLE | rule | 2.33 | 3.67 | 49.2 |
| ONE PROMISE A TARGET | rule | 1.33 | - | 57.4 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.33 | 12.1 |
| CHAFF PASSED | rule | - | 1.00 | 1.7 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 6.3 |
| MAIN BODY KEEPS ITS BAND | rule | - | 1.00 | 48.8 |
| RULE SWITCHED OFF | gate | - | 1.00 | 7.7 |
| CARRIES OUT SET-UP | rule | 0.33 | 0.33 | 13.2 |
| CHARGE NOT DECLARED | rule | 0.33 | 0.33 | 17.6 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 5.2 |
| CHARGE NOW FIRST | rule | - | 0.33 | 26.5 |
| JOINT CHARGE NOW | rule | - | 0.33 | 9.9 |
| NO REASON | gate | 0.33 | - | 0.7 |
| PATHS CROSS | rule | - | 0.33 | 1.0 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 123.3 |
| SUPPORT NARROWED | rule | - | 0.33 | 40.1 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 8.6 |

### Plans: nw22-19bea9b-p48

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 88% | 221 | 247 | 112% |
| Mine | join | 2.7 | 100% | 97 | 0 | 0% |
| Mine | move | 36.0 | 93% | 1516 | 0 | 0% |
| Mine | shoot | 1.0 | 67% | 2 | 24 | 973% |
| Mine | support | 1.0 | 100% | 5 | 0 | 0% |
| Opponent | charge | 3.7 | 73% | 832 | 401 | 48% |
| Opponent | move | 38.3 | 97% | 2560 | 0 | 0% |
| Opponent | shoot | 3.3 | 50% | 104 | 89 | 86% |

### Battle groups: nw22-19bea9b-p48

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.3 | 12% | 50% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 0% | 100% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p48

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 121 (9) | 41 | 80 | 52 | 56% | 4.0 | 156 (7) | 0 (1) | 0 (1) | 137 (8) | 0 (1) |
| Mine | Character | 10 | 15 (10) | 15 | 0 | 2 | 30% | 4.7 | 15 (8) | 15 (2) | - | 21 (5) | 10 (5) |
| Mine | Clean-up | 1 | 55 (1) | 55 | 0 | 0 | 0% | 5.0 | 55 (1) | - | - | - | 55 (1) |
| Mine | Fast Hammer | 8 | 24 (8) | 12 | 12 | 42 | 0% | 4.1 | 29 (3) | 0 (3) | 41 (2) | 20 (2) | 25 (6) |
| Mine | Hammer | 2 | 36 (2) | 8 | 28 | 100 | 0% | 3.0 | 67 (1) | 0 (1) | - | - | 36 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 35 | 0% | 2.2 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 50% | 2.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 44 (7) | 44 | 0 | 10 | 0% | 1.9 | 42 (3) | 54 (3) | - | 87 (3) | 0 (3) |
| Opponent | Clean-up | 2 | 160 (2) | 77 | 83 | 0 | 0% | 2.5 | - | 160 (2) | - | - | 160 (2) |
| Opponent | Fast Hammer | 5 | 40 (5) | 0 | 40 | 34 | 0% | 1.2 | 85 (2) | 0 (2) | 0 (1) | 0 (2) | 70 (3) |
| Opponent | Hammer | 11 | 11 (11) | 11 | 0 | 7 | 82% | 4.5 | 0 (4) | 19 (6) | 0 (1) | 32 (4) | 0 (7) |
| Opponent | Shooter | 8 | 22 (8) | 14 | 8 | 32 | 0% | 1.8 | 0 (1) | 38 (4) | 13 (3) | - | 22 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |

### Charged fights: nw22-19bea9b-p48

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 70 | 1.0 | 1.0 | 70 | 0 | +70 | 0 of 2 | 1 of 2 | - | +70 |
| Mine | Warriors of Chaos | 1 | 0 | 359 | 5.0 | 1.2 | 72 | 0 | +72 | 1 of 5 | 4 of 5 | +104 | +64 |
| **Mine** | all armies | 3 | 0 | 166 | 2.3 | 1.1 | 71 | 0 | +71 | 1 of 7 | 5 of 7 | +104 | +66 |
| Opponent | Wood Elf Realms | 3 | 15 | 505 | 4.3 | 1.2 | 117 | 36 | +81 | 6 of 13 | 8 of 13 | +45 | +88 |

### Effective charges: nw22-19bea9b-p48

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +140) | 0 | 0% (0 of 2) |
| Mine | Warriors of Chaos | 5 | 0 | 0 | 0 | 1 (net +0) | 2 (net +170) | 0 | 2 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 13 | 3 (net -12) | 1 (net +0) | 2 (net +0) | 2 (net -33) | 1 (net +190) | 3 (net +169) | 1 | 17% (2 of 12) |

### Charged fights, damage counted: nw22-19bea9b-p48

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 262 | 159 | +0 | 31 | 0 | +31 | +11.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 254 | 140 | +140 | 140 | 0 | +140 | +55.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 684 | 170 | +170 | 170 | 0 | +170 | +24.8 |
| Mine | No odds | 2 | 136 | 64 | +10 | 10 | 0 | +10 | +7.0 |
| Mine | All fights | 7 | 345 | 132 | +71 | 80 | 0 | +80 | +23.2 |
| Opponent | Long shot (under 50%) | 3 | 276 | 433 | -12 | 185 | 120 | +64 | +23.3 |
| Opponent | 50-54% | 1 | 217 | 70 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 2 | 499 | 430 | +0 | 0 | 19 | -19 | -3.8 |
| Opponent | 76-89% | 2 | 105 | 122 | -33 | 84 | 117 | -33 | -31.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 379 | 149 | +169 | 176 | 6 | +170 | +44.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 60 | +190 | 190 | 0 | +190 | +38.1 |
| Opponent | No odds | 1 | 0 | 285 | +458 | 458 | 209 | +249 | - |
| Opponent | All fights | 13 | 299 | 251 | +81 | 146 | 66 | +80 | +26.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p48 | move | 23 | 2 (9%) | 2 (9%) | 1 (4%) | 20 (87%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

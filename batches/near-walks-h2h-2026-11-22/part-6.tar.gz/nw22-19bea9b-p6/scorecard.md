# Doctrine scorecard: nw22-19bea9b-p6

### Scorecard: nw22-19bea9b-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 11 | 3 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 125 |
| L0930 | 6 | 1 | Opponent | no | 9 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 12 | 3 | 2 | 0 | 2 | 0 | 0 | 453 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 4.0 | 3.0 | 0.7 | 1.0 | 0.7 | 0.0 | 0.0 | 332.7 |
| **Average** | | | Opponent | 0% | 6.7 | 2.5 | 1.3 | 2.3 | 0.0 | 0.0 | 0.0 | 143.3 |

### KPIs: nw22-19bea9b-p6

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 77% (10 of 13) | 0% (0 of 14) | 37% (10 of 27) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 2); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 2); on the table 50% | 0% (0 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | - | 0% (0 of 4); on the table 25% | 0% (0 of 4); on the table 25% |
| Magic missiles tried each own turn | 50%+ | 48% (23 of 48) | 25% (3 of 12) | 43% (26 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (23 of 45) | 33% (3 of 9) | 48% (26 of 54) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 64% (7 of 11) | 64% (7 of 11) |
| Points that never fought | lower | 78% (4704 of 5997) | 79% (4714 of 5999) | 79% (9418 of 11996) |
|   infantry points that never fought | lower | 93% (1487 of 1591) | 88% (1456 of 1660) | 91% (2943 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (21 of 34) | 65% (15 of 23) | 63% (36 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 1.3 uses a game | 100% (2 of 2); 3.0 uses a game | 75% (3 of 4); 2.2 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 1.0 uses a game | 0% (0 of 2); 0.0 uses a game | 33% (1 of 3); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (3604 of 5667) | 66% (3419 of 5150) | 65% (7023 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (44%) | 2.0 (67%) | 5.7 (50%) |
| MARCHED: its unit marched | 3.7 (44%) | 0.0 (0%) | 3.7 (32%) |
| IN COMBAT: engaged in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.7 (8%) | 1.0 (33%) | 1.7 (15%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 3.7 | 1.0 | 8.7 | 0.3 | 0.3 |
| not cast | 1.0 | 4.0 | 1.0 | 11.3 | 1.7 | 19.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (75%) | 0.0 (0%) | 5.7 (50%) | 0.7 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (32%) | 0.7 (40%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 1.0 (100%) | 0.7 (17%) | 1.0 (100%) | 1.7 (15%) | 0.0 (0%) | 3.0 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 100% (3 of 3) | 100% (3 of 3) |
| the unit moved after it | - | 33% (1 of 3) | 33% (1 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (83 of 117) | 76% (37 of 49) | 72% (120 of 166) |
|   character | 100% (11 of 11) | 46% (6 of 13) | 71% (17 of 24) |
|   chariot | 53% (8 of 15) | 60% (3 of 5) | 55% (11 of 20) |
|   infantry | 57% (27 of 47) | 84% (16 of 19) | 65% (43 of 66) |
|   monster | 50% (2 of 4) | - | 50% (2 of 4) |
|   war machine | 88% (35 of 40) | 100% (12 of 12) | 90% (47 of 52) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (35%) | 0.7 (17%) | 4.7 (30%) |
| CHARGED: it charged | 0.7 (6%) | 1.7 (42%) | 2.3 (15%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.0 (9%) | 0.0 (0%) | 1.0 (7%) |
| NO TARGET IN RANGE | 2.7 (24%) | 1.3 (33%) | 4.0 (26%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (18%) | 0.3 (8%) | 2.3 (15%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 7.0 | 1.0 | 86% | 1.0 pts | 7 pts |
| chariot | 3.7 | 1.7 | 82% | 19.9 pts | 73 pts |
| infantry | 18.3 | 9.0 | 71% | 8.1 pts | 148 pts |
| monster | 1.0 | 0.3 | 67% | 10.1 pts | 10 pts |
| war machine | 15.7 | 12.3 | 60% | 27.9 pts | 437 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 1.7 | 1.3 |
| Charges that made contact a game | 1.0 | 0.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.25 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (20 units) | 0.22 declared, 0.09 contact (23 units) | 0.16 declared, 0.09 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Character in a unit | 83% (5 of 6) | 100% (2 of 2) | 100% (1 of 1) | 89% (8 of 9) |
| Character on its own | 100% (1 of 1) | 25% (1 of 4) | 67% (2 of 3) | 50% (4 of 8) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 29% (4 of 14) | 75% (3 of 4) | - | 39% (7 of 18) |
| Monster | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 62% (5 of 8) | - | - | 62% (5 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 54% (13 of 24) | 91% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 42% (10 of 24) | 54% | 50% (5 of 10) | 50% (1 of 2); 4.0 uses a game | 100% (1 of 1); 3.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 88% | 50% (4 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 0% (0 of 3); on the table 33% | 50% (3 of 6) | 72% | 67% (6 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 76% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p6, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (3) | 100% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.67 | 0.00 | 0.67 |

### Quality by phase: nw22-19bea9b-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 20% (1 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (12 of 48) | 71% (15 of 21) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 8) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 50% (2 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 332.7 | 143.3 |
| Movement | Fights charged into per game | 1.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 3, net +0 | 1 of 1, net +104 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.3 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (21 of 49) | 67% (18 of 27) |
| Shooting | Points destroyed by shooting units | 50.3 | 41.7 |
| Shooting | War machine shots | 11.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 66% (23 of 35) | 58% (7 of 12) |
| Shooting | Points destroyed by war machines | 272.0 | 0.0 |
| Magic | Magic missiles cast | 4.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 23% (3 of 13) | 100% (3 of 3) |
| Magic | Wounds caused by magic missiles | 10.0 | 3.3 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 133.3 | 198.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.3 / 0.0 | 2.7 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 198.0 |
| Combat | Points run down | 0.0 | 105.7 |
| Combat | Net points per charged fight, damage counted | -3 | +101 |
| Combat | Net per 100 charger points, damage counted | -1.3 | +27.7 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +0 | +207 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +207 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 1 of 2 |
| Game | Points lost | 759.0 | 509.7 |
| Game | VP from objectives | 813.3 | 886.7 |
| Game | Lone holders (player turns) | 4.0 | 6.7 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -345 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1269
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 13.7 | -42.8 | 0.0 | 151.3 | 25.0 | +570.7 | 0.0 | 563.7 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 96.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.4 | 0.0 | 0.0 | 0.7 | +0.8 | 0.0 | 0.0 |
| BELL IN A UNIT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 68.7 | 41.7 | - | - | - | - |
| CANNON PLANNED TARGET | 11.7 | +369.1 | 841.3 | 235.0 | 4.0 | +249.1 | 469.3 | 0.0 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.7 | +53.8 | 131.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 266.7 |
| CHAFF PASSED | 1.7 | -2.5 | 0.0 | 41.7 | - | - | - | - |
| CHARACTER GUNS | 6.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 14.7 | -464.1 | 0.0 | 466.7 | 29.0 | -1319.1 | 0.0 | 1126.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 110.3 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 397.3 | 13.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 21.7 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +177.1 | 266.7 | 266.7 |
| COVER ONCE | 10.3 | -721.5 | 0.0 | 248.3 | 5.0 | -182.6 | 0.0 | 43.3 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -10.2 | 34.7 | 0.0 |
| DEPLOY BY FIGURES | 8.3 | +4.6 | 0.0 | 41.7 | 7.0 | +32.4 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +0.3 | 48.3 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +3.9 | 0.0 | 108.0 |
| EXACT ROUND | 1.0 | +4.5 | 48.3 | 0.0 | 1.0 | +11.9 | 71.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.4 | 0.0 | 0.0 | 1.3 | +15.2 | 167.0 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 28.7 | +285.3 | 0.0 | 599.0 |
| FEATURE BUFFS | 2.7 | +9.4 | 0.0 | 0.0 | 2.3 | +33.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 96.3 | +7117.6 | 2904.0 | 1372.7 | 94.7 | +6241.0 | 1135.7 | 1845.3 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 228.7 | 4.7 | +0.0 | 0.0 | 100.0 |
| FOUR ROUNDS | 1.0 | +49.4 | 48.3 | 0.0 | 1.7 | +123.3 | 182.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 151.3 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -22.7 | 0.0 | 0.0 | 0.7 | -9.9 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 7.7 | +361.0 | 0.0 | 151.3 | 13.3 | +1971.7 | 0.0 | 65.3 |
| GUN FIGURES | 1.0 | +0.0 | 0.0 | 88.3 | 1.3 | +1.1 | 0.0 | 65.0 |
| GUN MASK | 4.7 | +61.5 | 0.0 | 176.7 | 1.3 | +61.6 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.7 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 151.3 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 466.7 | 14.7 | +0.0 | 0.0 | 308.3 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 65.3 |
| HIS MOVE AND SHOT | 4.0 | -101.7 | 0.0 | 246.0 | 8.0 | -121.4 | 0.0 | 198.7 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 198.7 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 65.3 |
| HIS RANDOM MOVE | 12.3 | +0.0 | 0.0 | 108.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 32.0 | +876.7 | 0.0 | 372.0 | 76.7 | +5901.9 | 0.0 | 1645.7 |
| HIS SHOTS BY HIS RUN | 36.0 | +651.5 | 0.0 | 751.3 | 58.3 | +1643.9 | 0.0 | 1503.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +20.2 | 76.3 | 0.0 |
| HOLD ODDS | 26.0 | +0.0 | 0.0 | 0.0 | 28.0 | +0.0 | 0.0 | 65.3 |
| HOLDER ASSIGNMENT | 15.0 | +1615.7 | 0.0 | 0.0 | 15.0 | +1463.3 | 0.0 | 32.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -18.6 | 48.3 | 0.0 | 1.7 | -73.1 | 182.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +156.5 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 12.0 | -264.7 | 0.0 | 421.7 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.1 | 0.0 | 0.0 | 0.7 | +37.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 0.0 | 132.3 | 0.3 | +0.0 | 0.0 | 30.7 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +0.4 | 0.0 | 0.0 | 0.3 | +0.1 | 34.7 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +27.6 | 0.0 | 0.0 |
| MANOEUVRE | 3.7 | +43.2 | 0.0 | 54.0 | 3.0 | +20.0 | 0.0 | 21.7 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.7 | +113.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 3.7 | +311.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.0 | +45.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -49.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +85.8 | 0.0 | 123.0 | 1.3 | +36.6 | 0.0 | 18.3 |
| MEETS IN TIME | 3.7 | +429.5 | 0.0 | 0.0 | 2.7 | +345.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.0 | +245.1 | 0.0 | 123.0 | 3.3 | +102.5 | 0.0 | 108.0 |
| MISSILES NEXT TURN | 14.0 | +203.6 | 0.0 | 177.0 | 4.3 | +67.1 | 0.0 | 320.7 |
| MISSILES ON ONE TARGET | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 21.7 | 21.7 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 266.7 |
| MOVE TO CHARGE COMPUTED | 3.3 | +166.7 | 0.0 | 0.0 | 3.0 | +271.4 | 0.0 | 0.0 |
| NEAR WALKS ONLY | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 11.7 | +566.6 | 0.0 | 88.7 | 9.0 | +394.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.7 | +145.0 | 0.0 | 0.0 | 3.0 | +271.4 | 0.0 | 0.0 |
| NO CHAFF EDGES | 0.7 | +11.3 | 48.3 | 55.7 | 2.3 | +53.1 | 117.3 | 54.3 |
| NO DOUBLE ROUNDS | 1.0 | -23.9 | 48.3 | 0.0 | 1.3 | -48.5 | 167.0 | 0.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.7 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| OFF BEST | 4.3 | -97.1 | 0.0 | 0.0 | 1.7 | -56.6 | 0.0 | 133.3 |
| OGRE LOADER SECOND SHOT | 1.7 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -80.3 | 0.0 | 123.0 | 4.3 | -102.2 | 0.0 | 83.0 |
| ONE OBJECTIVE FORMULA | 6.0 | +193.4 | 0.0 | 0.0 | 6.7 | +118.3 | 0.0 | 32.7 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +20.8 | 15.0 | 0.0 |
| OPENS UP IN FULL | 0.3 | +9.3 | 48.3 | 0.0 | 1.0 | +52.2 | 132.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +12.0 | 0.0 | 0.0 | 1.7 | +79.7 | 182.0 | 0.0 |
| OWN CAST FIRST | 0.7 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.7 | +40.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 43.3 | +1371.2 | 632.0 | 1189.3 | 43.0 | +558.6 | 364.3 | 940.3 |
| PRIZE BY WORTH | - | - | - | - | 0.7 | +103.1 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.3 | -208.1 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -5.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 14.3 | +1868.2 | 494.7 | 549.3 | 16.0 | +1441.4 | 280.0 | 476.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.7 | +165.6 | 0.0 | 193.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.3 | +10.1 | 0.0 | 36.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 36.7 |
| REDIRECT WEIGHED | - | - | - | - | 1.3 | +25.5 | 88.3 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -28.9 | 0.0 | 0.0 | 1.3 | -37.3 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -35.0 | 48.3 | 0.0 | 1.7 | -246.0 | 182.0 | 0.0 |
| RUN DOWN | 1.0 | -19.4 | 48.3 | 0.0 | 0.7 | -3.7 | 110.3 | 0.0 |
| SCOUT BY DROPS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +2.2 | 0.0 | 0.0 | 0.3 | +7.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -77.8 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.7 | +28.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | - | - | - | - | 1.0 | +27.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 235.0 | 6.7 | +0.0 | 0.0 | 75.7 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +154.3 | 332.0 | 0.0 | 1.7 | +27.1 | 83.3 | 151.3 |
| SHOT OR CHARGE | 0.7 | -43.9 | 48.3 | 0.0 | 0.3 | -8.8 | 15.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 15.3 | -274.0 | 0.0 | 466.7 | 44.7 | -330.5 | 0.0 | 1356.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 28.7 | +1099.9 | 0.0 | 509.3 | 13.0 | +630.9 | 0.0 | 306.3 |
| SPELL WORTH | - | - | - | - | 3.0 | +47.8 | 266.7 | 266.7 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 123.0 | 8.3 | +0.0 | 0.0 | 262.7 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -3.6 | 110.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 266.7 |
| STANDS STILL | 43.7 | +0.0 | 2855.7 | 578.0 | 34.7 | +0.0 | 953.7 | 840.0 |
| STAY WORTH | 42.3 | -34.7 | 1963.7 | 400.3 | 19.7 | +563.7 | 772.0 | 385.7 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -15.9 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 0.3 | +7.0 | 0.0 | 0.0 | 7.7 | +214.3 | 0.0 | 123.3 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 0.3 | +7.0 | 0.0 | 0.0 | 7.7 | +214.3 | 0.0 | 123.3 |
| SURE REACH TOGETHER | 0.7 | +5.4 | 0.0 | 0.0 | 1.3 | +19.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.3 | +8.3 | 0.0 | 0.0 | 0.3 | +1.6 | 34.7 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 198.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 75.7 | 5.0 | +0.0 | 0.0 | 119.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 50.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.3 | +0.0 | 0.0 | 701.3 | 44.7 | +0.0 | 0.0 | 826.0 |
| TIED UP BY THE SUM | 0.7 | +46.0 | 48.3 | 0.0 | 1.0 | +140.9 | 152.0 | 0.0 |
| TIME ON OUR SIDE | 38.3 | +564.4 | 0.0 | 451.3 | - | - | - | - |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.7 | +60.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -7.7 | 0.0 | 0.0 | 3.3 | -230.9 | 0.0 | 181.7 |
| WHOLE FIGHT REACTION | 1.0 | +30.8 | 0.0 | 125.3 | 0.7 | +9.4 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.3 | +72.9 | 0.0 | 0.0 | 2.0 | +72.2 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 326 | 319 | 97 | 32.33 | +2227 | +23.0 |
| ARMY TABLE | 116 | 116 | 81 | 27.00 | +1632 | +20.2 |
| HOLDER ASSIGNMENT | 90 | 90 | 81 | 27.00 | +5556 | +68.6 |
| HIS SHOTS BY HIS RUN | 283 | 276 | 60 | 20.00 | +1051 | +17.5 |
| SHOT RISK POINTS | 180 | 175 | 35 | 11.67 | +363 | +10.4 |
| DEPLOY BY FIGURES | 46 | 46 | 29 | 9.67 | +567 | +19.6 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| GOAL WALK | 63 | 63 | 21 | 7.00 | +1701 | +81.0 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -461 | -25.6 |
| STAY WORTH | 186 | 168 | 14 | 4.67 | +128 | +9.2 |
| FIVE ACTION | 573 | 562 | 13 | 4.33 | +379 | +29.2 |
| QUARTER ODDS | 91 | 91 | 13 | 4.33 | +1111 | +85.5 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CHARGE LOSSES | 131 | 126 | 10 | 3.33 | +404 | +40.4 |
| MOVE TO CHARGE COMPUTED | 19 | 16 | 10 | 3.33 | +538 | +53.8 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 10 | 3.33 | -624 | -62.4 |
| TIME ON OUR SIDE | 115 | 97 | 10 | 3.33 | +24 | +2.4 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 9 | 3.00 | +131 | +14.5 |
| CANNON SIGHT KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MARCH CHECK | 11 | 10 | 8 | 2.67 | +153 | +19.1 |
| NEXT CHARGE BY LIST | 20 | 18 | 8 | 2.67 | +404 | +50.5 |
| SUPPORT ADDS | 24 | 24 | 8 | 2.67 | +122 | +15.2 |
| SUPPORT WORKED OUT | 24 | 24 | 8 | 2.67 | +122 | +15.2 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1246 | +177.9 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 7 | 2.33 | +497 | +71.0 |
| FALLS SHORT | 86 | 71 | 6 | 2.00 | +101 | +16.9 |
| LEGAL CHARGES ONLY | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| NO CHAFF EDGES | 9 | 9 | 6 | 2.00 | +71 | +11.9 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 6 | 2.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 16 | 14 | 6 | 2.00 | +64 | +10.7 |
| CAST JOB | 5 | 5 | 5 | 1.67 | +41 | +8.3 |
| CHAFF PASSED | 5 | 5 | 5 | 1.67 | -7 | -1.5 |
| IDLE COST | 36 | 32 | 5 | 1.67 | +43 | +8.6 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| MANOEUVRE | 20 | 20 | 5 | 1.67 | +203 | +40.6 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +341 | +68.2 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +760 | +152.1 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +8 | +1.6 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +251 | +50.3 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOUR ROUNDS | 8 | 8 | 4 | 1.33 | +102 | +25.4 |
| GUN MASK | 18 | 18 | 4 | 1.33 | +169 | +42.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +147 | +36.7 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +697 | +174.2 |
| WHOLE FIGHT DANGER | 12 | 12 | 4 | 1.33 | +31 | +7.8 |
| CHARGE NOW FIRST | 3 | 3 | 3 | 1.00 | -73 | -24.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -136 | -45.3 |
| MAX FOR POSITIONING | 18 | 15 | 3 | 1.00 | +5 | +1.7 |
| SHOTS IN THE MOVE | 125 | 94 | 3 | 1.00 | +41 | +13.6 |
| SURE REACH TOGETHER | 6 | 5 | 3 | 1.00 | +30 | +10.0 |
| CANNON PLANNED TARGET | 47 | 47 | 2 | 0.67 | +111 | +55.5 |
| EXACT ROUND | 6 | 6 | 2 | 0.67 | +2 | +1.1 |
| FEATURE BUFFS | 15 | 15 | 2 | 0.67 | +6 | +3.1 |
| MISSILES IN THE MOVE | 43 | 31 | 2 | 0.67 | +6 | +3.1 |
| NEARER NOT NEEDED | 62 | 58 | 2 | 0.67 | +24 | +11.9 |
| ONE FIGHT FORMULA | 26 | 14 | 2 | 0.67 | +8 | +3.8 |
| ONE OBJECTIVE FORMULA | 38 | 28 | 2 | 0.67 | +101 | +50.7 |
| OVERRUNS AWAY | 6 | 6 | 2 | 0.67 | +35 | +17.3 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -4 | -1.8 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +121 | +60.5 |
| PRIZE BY WORTH | 2 | 2 | 2 | 0.67 | +309 | +154.6 |
| PROMISE READS THE TABLE | 2 | 2 | 2 | 0.67 | +102 | +51.1 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -0 | -0.1 |
| RISK BY ARC | 7 | 7 | 2 | 0.67 | +2 | +1.1 |
| SCOUT BY DROPS | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +30 | +15.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +129 | +64.6 |
| WHOLE FIGHT REACTION | 5 | 5 | 2 | 0.67 | +61 | +30.5 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COVER ONCE | 46 | 31 | 1 | 0.33 | +23 | +23.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +226 | +226.2 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 55 | 41 | 1 | 0.33 | +7 | +6.7 |
| NO DOUBLE ROUNDS | 7 | 7 | 1 | 0.33 | +1 | +0.8 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| OPENS UP IN FULL | 4 | 4 | 1 | 0.33 | +1 | +0.8 |
| REDIRECT COUNTER | 4 | 3 | 1 | 0.33 | +0 | +0.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +6 | +6.4 |
| SET UP TOGETHER | 3 | 2 | 1 | 0.33 | +18 | +17.5 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 25 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARACTER GUNS | 30 | 28 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 57 | 57 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 63 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 36 | 34 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 27 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 37 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 162 | 162 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 19 | 19 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEAR WALKS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 9 | 9 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 259 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | not checked | - | - | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 5 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 65 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 40 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 235 | 228 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE FIGHT MOVES | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 28 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 270 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 1.33 | 27.5 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | - | 62.4 |
| ARMY TABLE | rule | 1.33 | 1.67 | 113.9 |
| CHAFF PASSED | rule | 1.00 | - | 2.3 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 24.4 |
| MARCH OF THE TABLE | rule | 1.00 | - | 45.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 23.3 |
| OWN CAST FIRST | rule | 0.67 | - | 1.8 |
| AFTERMATH BAND | gate | 0.33 | - | 1.2 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 21.2 |
| NO REASON | gate | - | 0.33 | 19.0 |

### Plans: nw22-19bea9b-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 22 | 64 | 285% |
| Mine | join | 1.0 | 67% | 9 | 0 | 0% |
| Mine | move | 28.0 | 94% | 1678 | 0 | 0% |
| Mine | shoot | 13.7 | 71% | 947 | 1308 | 138% |
| Opponent | charge | 1.0 | 100% | 132 | 152 | 115% |
| Opponent | move | 36.0 | 93% | 2370 | 0 | 0% |
| Opponent | shoot | 6.0 | 56% | 529 | 407 | 77% |

### Battle groups: nw22-19bea9b-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 18 (10) | 18 | 0 | 36 | 30% | 3.0 | 24 (4) | 10 (5) | 0 (1) | 7 (5) | 34 (5) |
| Mine | Clean-up | 3 | 109 (3) | 0 | 109 | 0 | 100% | - | - | 117 (2) | 95 (1) | 109 (3) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 71 | 0% | 4.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 51 | 50% | 1.3 | 0 (2) | 0 (4) | - | 0 (4) | 0 (2) |
| Mine | Shooter | 6 | 161 (6) | 50 | 111 | 17 | 0% | 1.3 | 144 (2) | 216 (3) | 29 (1) | 176 (5) | 87 (1) |
| Mine | War machine | 8 | 76 (8) | 76 | 0 | 50 | 0% | 1.5 | - | 147 (3) | 38 (5) | - | 76 (8) |
| Mine | Wizard | 4 | 41 (4) | 41 | 0 | 0 | 25% | 2.0 | 0 (1) | 82 (2) | 0 (1) | 54 (3) | 0 (1) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 44 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Character | 8 | 53 (8) | 53 | 0 | 18 | 50% | 2.2 | 138 (1) | 0 (4) | 60 (1) | 49 (5) | 0 (1) |
| Opponent | Clean-up | 2 | 210 (2) | 0 | 210 | 0 | 100% | - | - | 210 (2) | - | 210 (2) | - |
| Opponent | Fast Hammer | 6 | 46 (6) | 0 | 46 | 41 | 83% | 3.0 | - | 45 (4) | 48 (2) | 65 (5) | 0 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 5 | 51 (5) | 51 | 0 | 32 | 40% | 3.0 | - | 128 (2) | 0 (3) | 63 (4) | 0 (1) |
| Opponent | Holder | 4 | 61 (4) | 0 | 61 | 23 | 50% | 4.5 | - | 85 (3) | - | 0 (1) | 125 (2) |
| Opponent | Shooter | 4 | 48 (4) | 48 | 0 | 62 | 0% | 1.8 | - | 0 (1) | 56 (3) | 48 (4) | - |
| Opponent | War machine | 2 | 89 (2) | 89 | 0 | 0 | 0% | 1.0 | - | - | 89 (2) | 179 (1) | 0 (1) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | - | - | - |

### Charged fights: nw22-19bea9b-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 400 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 567 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 0 of 3 | 2 of 3 | - | +0 |
| **Mine** | all armies | 3 | 456 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 3 | 2 of 3 | - | +0 |
| Opponent | High Elf Realms | 1 | 352 | 104 | 1.0 | 1.0 | 104 | 0 | +104 | 0 of 1 | 1 of 1 | - | +104 |
| Opponent | Skaven | 1 | 369 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 310 | 1.0 | 1.0 | 310 | 0 | +310 | 1 of 1 | 1 of 1 | - | +310 |
| **Opponent** | all armies | 3 | 240 | 138 | 0.7 | 1.0 | 207 | 0 | +207 | 1 of 2 | 2 of 2 | - | +207 |

### Effective charges: nw22-19bea9b-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +0) | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +104) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 201 | 116 | +0 | 20 | 22 | -3 | -1.3 |
| Mine | All fights | 3 | 201 | 116 | +0 | 20 | 22 | -3 | -1.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 104 | +104 | 104 | 0 | +104 | +42.1 |
| Opponent | No odds | 1 | 479 | 265 | +310 | 310 | 213 | +97 | +20.3 |
| Opponent | All fights | 2 | 363 | 184 | +207 | 207 | 106 | +101 | +27.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p6 | move | 18 | 3 (17%) | 3 (17%) | 4 (22%) | 11 (61%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

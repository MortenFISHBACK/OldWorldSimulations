# Doctrine scorecard: nw22-19bea9b-p22

### Scorecard: nw22-19bea9b-p22

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 77 |
| L1827 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 490 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 2.0 | 2.0 | 2.0 | 0.3 | 0.0 | 0.0 | 0.0 | 189.0 |
| **Average** | | | Opponent | 0% | 0.0 | 2.3 | 3.0 | 2.7 | 0.0 | 0.0 | 0.0 | 56.7 |

### KPIs: nw22-19bea9b-p22

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 18) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 86% (6 of 7); on the table 100% | 100% (1 of 1); on the table 100% | 88% (7 of 8); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 2); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 40% (2 of 5); on the table 40% | 50% (3 of 6); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 88% (7 of 8); on the table 100% | 38% (3 of 8); on the table 38% | 62% (10 of 16); on the table 69% |
| Magic missiles tried each own turn | 50%+ | 58% (14 of 24) | 67% (8 of 12) | 61% (22 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 74% (14 of 19) | 67% (8 of 12) | 71% (22 of 31) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 30% (3 of 10) | 50% (1 of 2) | 33% (4 of 12) |
| Points that never fought | lower | 23% (1373 of 5999) | 35% (2095 of 5999) | 29% (3468 of 11998) |
|   infantry points that never fought | lower | 35% (352 of 993) | 45% (356 of 793) | 40% (708 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (12 of 22) | 58% (11 of 19) | 56% (23 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (2649 of 5151) | 42% (2085 of 4976) | 47% (4734 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (100%) | 1.3 (29%) |
| MARCHED: its unit marched | 1.0 (30%) | 0.0 (0%) | 1.0 (21%) |
| CHARGED: its unit charged | 0.7 (20%) | 0.0 (0%) | 0.7 (14%) |
| IN COMBAT: engaged in combat | 1.0 (30%) | 0.0 (0%) | 1.0 (21%) |
| GONE: slain | 0.7 (20%) | 0.0 (0%) | 0.7 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 3.0 | 7.3 | 0.3 | 2.0 |
| not cast | 8.3 | 7.0 | 4.7 | 3.7 | 30.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (5%) | 1.3 (29%) | 2.0 (55%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (21%) | 0.3 (9%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 1.0 (21%) | 0.3 (9%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.3 (9%) | 0.3 (1%) |
| GONE: slain | 1.0 (12%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (18%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 7.3 (88%) | 6.0 (86%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 26.7 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 1.3 a game | 1.5 a game |
| stood (cast and not dispelled) | 40% (2 of 5) | 50% (2 of 4) | 44% (4 of 9) |
| the unit moved after it | 0% (0 of 2) | 100% (2 of 2) | 50% (2 of 4) |
| it charged on its next turn | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| the enemy charged it first | 50% (1 of 2) | 0% (0 of 2) | 25% (1 of 4) |
| it fought by the end of its next turn | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | 100% (2 of 2) | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (31 of 54) | 22% (2 of 9) | 52% (33 of 63) |
|   cavalry | - | 50% (2 of 4) | 50% (2 of 4) |
|   character | 100% (6 of 6) | 0% (0 of 5) | 55% (6 of 11) |
|   chariot | 100% (7 of 7) | - | 100% (7 of 7) |
|   infantry | 31% (10 of 32) | - | 31% (10 of 32) |
|   monster | 89% (8 of 9) | - | 89% (8 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (22%) | 0.7 (29%) | 2.3 (23%) |
| CHARGED: it charged | 0.7 (9%) | 0.7 (29%) | 1.3 (13%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (14%) | 0.3 (3%) |
| NO TARGET IN RANGE | 3.3 (43%) | 0.7 (29%) | 4.0 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (22%) | 0.0 (0%) | 1.7 (17%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.0 | 1.7 | 0% | 26.0 pts | 26 pts |
| character | 2.0 | 0.7 | 67% | 12.9 pts | 26 pts |
| chariot | 2.3 | 0.7 | 71% | 8.8 pts | 21 pts |
| infantry | 3.3 | 1.3 | 80% | 3.1 pts | 10 pts |
| monster | 2.7 | 1.7 | 62% | 11.0 pts | 29 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 5.0 | 5.3 |
| Charges that made contact a game | 4.0 | 3.3 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.33 contact (3 units) | 1.00 declared, 0.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.41 contact (27 units) | 0.50 declared, 0.38 contact (24 units) | 0.55 declared, 0.39 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 67% (2 of 3) | 0% (0 of 2) | 44% (4 of 9) |
| Character in a unit | 80% (4 of 5) | 100% (1 of 1) | 100% (1 of 1) | 86% (6 of 7) |
| Character on its own | 100% (3 of 3) | 0% (0 of 2) | 20% (1 of 5) | 40% (4 of 10) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (2 of 4) | 0% (0 of 1) | - | 40% (2 of 5) |
| Monster | 100% (1 of 1) | 100% (3 of 3) | - | 100% (4 of 4) |
| Monstrous | - | 25% (1 of 4) | - | 25% (1 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (5 of 5); on the table 100% | 100% (6 of 6) | 57% | 43% (3 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 50% (1 of 2); on the table 100% | 33% (4 of 12) | 0% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 12% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 2 | 17% (1 of 6); on the table 17% | 67% (8 of 12) | 34% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 36% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p22, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 11% (1) | 56% (5) | 33% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.67 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p22

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 54% (7 of 13) | 62% (8 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 11% (1 of 9) | 0% (0 of 4) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 100% (5 of 5) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 90% (9 of 10) |
| Movement | Charges halted short of contact | 0.7 | 0.3 |
| Movement | Idle units | 0.3 | 2.7 |
| Movement | Points that never moved of their own | 189.0 | 56.7 |
| Movement | Fights charged into per game | 4.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 10, net -30 | 2 of 9, net +92 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 10, net +0 | 1 of 9, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 10, net +68 | 0 of 9 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 10, net +186 | 4 of 9, net +219 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (14 of 31) | 0% (0 of 4) |
| Shooting | Points destroyed by shooting units | 25.0 | 21.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 3.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (2 of 10) | 100% (4 of 4) |
| Magic | Wounds caused by magic missiles | 3.7 | - |
| Magic | Wounds caused by other spells | 1.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 62.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 1.3 / 0.0 | 1.0 / 0.0 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 412.7 | 380.3 |
| Combat | Points run down | 68.3 | 61.7 |
| Combat | Net points per charged fight, damage counted | +79 | +108 |
| Combat | Net per 100 charger points, damage counted | +41.8 | +44.0 |
| Combat | First round won (charged fights) | 67% | 67% |
| Combat | Net points per charged fight | +83 | +95 |
| Combat | Net points per supported fight / lone fight | - / +83 | +0 / +107 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 12 | 2 of 9 |
| Game | Points lost | 631.3 | 518.0 |
| Game | VP from objectives | 790.0 | 533.3 |
| Game | Lone holders (player turns) | 2.0 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +157 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1149
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: nw22-19bea9b-p22

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 18.7 | +344.8 | 0.0 | 124.0 | 21.7 | +898.3 | 0.0 | 210.0 |
| ARRIVAL HUNT | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 0.3 | +6.5 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.7 | +51.9 | 0.0 | 0.0 | 1.3 | +4.4 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +35.0 | 0.0 | 0.0 | 1.0 | +23.4 | 0.0 | 20.0 |
| CHAFF PASSED | 0.7 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +28.5 | 0.0 | 0.0 | 1.0 | +7.0 | 0.0 | 36.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -12.4 | 0.0 | 68.3 |
| CHARACTERS BY THEIR POINTS | 0.3 | +4.4 | 0.0 | 0.0 | 1.0 | -78.4 | 64.0 | 68.3 |
| CHARGE LOSSES | 6.0 | -370.2 | 0.0 | 206.3 | 11.7 | -420.7 | 0.0 | 73.3 |
| CHARGE NOT DECLARED | 1.3 | +0.0 | 80.0 | 30.0 | 0.3 | +0.0 | 85.0 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 60.0 | 0.0 | 2.3 | +0.0 | 219.0 | 130.3 |
| CLEAR LANE AHEAD | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.7 | +0.0 | 0.0 | 187.3 | 18.0 | +0.0 | 0.0 | 63.3 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +200.8 | 61.7 | 0.0 | 1.3 | +24.3 | 0.0 | 0.0 |
| COVER ONCE | 4.0 | -116.3 | 0.0 | 99.7 | 3.3 | -214.4 | 0.0 | 36.7 |
| DEFENSIVE FLOOR | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -0.4 | 0.0 | 68.3 |
| DEPLOY BY FIGURES | 7.3 | -91.2 | 0.0 | 0.0 | 6.7 | +43.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -1.3 | 64.0 | 0.0 |
| EXACT ROUND | 2.7 | -8.6 | 149.0 | 30.0 | 2.7 | +20.8 | 303.0 | 124.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +0.0 | 93.0 | 0.0 | 3.3 | +4.9 | 288.7 | 130.3 |
| FALLS SHORT | - | - | - | - | 22.0 | +280.5 | 0.0 | 270.3 |
| FEATURE BUFFS | 1.7 | +63.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.7 | -14.8 | 62.0 | 0.0 | 1.3 | +18.4 | 61.7 | 130.3 |
| FIVE ACTION | 85.0 | +6483.7 | 304.0 | 1308.3 | 82.7 | +5769.9 | 480.3 | 942.3 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 85.7 | 2.3 | +0.0 | 0.0 | 18.0 |
| FOLLOW UP WEIGHED | 1.0 | +75.5 | 0.0 | 0.0 | 0.7 | +92.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.3 | +170.3 | 279.0 | 30.0 | 5.0 | +199.8 | 437.0 | 192.3 |
| FREED FROM HIS FIGHT | 8.7 | +0.0 | 0.0 | 213.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 1.0 | -39.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.7 | -2.4 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -5.3 | 33.0 | 0.0 | 0.7 | -4.6 | 139.7 | 62.0 |
| GOAL WALK | 12.0 | +1051.5 | 0.0 | 208.3 | 11.3 | +1448.7 | 0.0 | 0.0 |
| GUN FIGURES | 3.7 | +13.2 | 0.0 | 61.7 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.0 | +0.2 | 0.0 | 0.0 | 2.0 | -6.5 | 78.3 | 68.3 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 4.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.7 | +0.0 | 62.0 | 30.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 206.3 | 4.0 | +0.0 | 0.0 | 73.3 |
| HIS CHARGE DENIED | 1.0 | +119.1 | 124.0 | 30.0 | - | - | - | - |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 134.0 | 2.0 | +0.0 | 0.0 | 50.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -3.3 | 0.0 | 0.0 | 3.7 | -36.9 | 0.0 | 90.0 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 149.7 | 7.0 | +0.0 | 0.0 | 65.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 124.0 |
| HIS RANDOM MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 3.7 | +0.0 | 0.0 | 128.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 12.0 | +84.6 | 0.0 | 304.7 | 44.0 | +714.2 | 0.0 | 462.7 |
| HIS SHOTS BY HIS RUN | 8.3 | +54.2 | 0.0 | 198.0 | 34.0 | +374.3 | 0.0 | 223.3 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +4.4 | 78.0 | 68.3 |
| HOLD ODDS | 18.0 | +0.0 | 0.0 | 256.0 | 12.0 | +0.0 | 0.0 | 286.7 |
| HOLDER ASSIGNMENT | 10.3 | +883.5 | 0.0 | 128.0 | 7.3 | +596.5 | 0.0 | 143.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -76.6 | 279.0 | 0.0 | 4.0 | -103.3 | 437.0 | 124.0 |
| IDLE COST | - | - | - | - | 16.3 | -205.5 | 0.0 | 79.7 |
| JOINT CHARGE NOW | 0.7 | +124.9 | 124.0 | 0.0 | 1.3 | +20.2 | 0.0 | 62.0 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.9 | 0.0 | 0.0 | 1.3 | +43.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.7 | +0.0 | 246.7 | 78.3 | 5.3 | +0.0 | 148.3 | 230.0 |
| LONG SHOT | 0.3 | -6.5 | 15.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -1.6 | 62.0 | 0.0 | 2.7 | +33.3 | 140.0 | 130.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | -1.3 | 0.0 | 64.0 | 1.0 | +0.0 | 0.0 | 143.3 |
| MARCH AT ESCAPER | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +18.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +19.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +40.1 | 0.0 | 0.0 | 2.7 | +51.5 | 0.0 | 15.0 |
| MEETS IN TIME | 4.7 | +279.3 | 0.0 | 0.0 | 2.7 | +216.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.3 | +122.9 | 0.0 | 0.0 | 3.0 | +8.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.0 | +64.9 | 0.0 | 0.0 | 3.3 | +6.0 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 61.7 | 64.0 | 4.7 | +0.0 | 20.0 | 25.0 |
| MOVE SPELL IN RANGE | 2.0 | +50.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.7 | -58.8 | 128.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +122.6 | 0.0 | 0.0 | 9.0 | +622.6 | 0.0 | 124.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEAR WALKS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +299.2 | 0.0 | 25.7 | 6.3 | +235.0 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 2.3 | +116.1 | 0.0 | 0.0 | 5.3 | +488.8 | 0.0 | 0.0 |
| NO CHAFF EDGES | 2.7 | +60.2 | 127.0 | 0.0 | 2.3 | +29.6 | 142.0 | 50.0 |
| NO DOUBLE ROUNDS | 2.7 | -51.6 | 140.0 | 0.0 | 3.7 | -146.3 | 437.0 | 192.3 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.7 | -2.0 | 0.0 | 0.0 | 2.0 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -135.4 | 0.0 | 30.0 | 4.3 | -194.0 | 0.0 | 36.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.3 | -31.6 | 0.0 | 21.7 | 5.7 | -162.2 | 0.0 | 220.3 |
| ONE JOINT FIGURE | 0.3 | +10.2 | 62.0 | 0.0 | 0.7 | -0.7 | 61.7 | 62.0 |
| ONE OBJECTIVE FORMULA | 3.7 | +68.3 | 0.0 | 128.0 | 3.3 | +39.7 | 0.0 | 143.3 |
| ONE PROMISE A TARGET | - | - | - | - | 1.0 | +52.2 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +27.3 | 15.0 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 1.0 | +58.7 | 102.0 | 0.0 | 1.0 | +24.0 | 142.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +67.1 | 48.0 | 0.0 | 1.0 | +4.5 | 0.0 | 68.3 |
| PATHS CROSS | - | - | - | - | 0.3 | +23.6 | 0.0 | 0.0 |
| PLAN RESULT | 42.0 | +268.6 | 20.0 | 888.7 | 42.7 | +413.4 | 110.0 | 835.7 |
| PRIZE BY WORTH | - | - | - | - | 0.7 | +22.0 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 62.0 |
| PROMISE BY ITS OWN SUM | 4.7 | -219.9 | 0.0 | 0.0 | 13.3 | -242.7 | 0.0 | 124.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | -0.7 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -1.7 | 0.0 | 0.0 |
| PURSUES BIG PREY | 0.3 | -62.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 21.3 | +2873.2 | 105.0 | 496.3 | 20.0 | +2723.9 | 185.7 | 90.0 |
| RANDOM MOVE BY FIGURES | 3.3 | +2.0 | 0.0 | 140.0 | 0.7 | +1.6 | 0.0 | 0.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +55.3 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 5.0 | +154.4 | 0.0 | 0.0 | 5.3 | +327.8 | 0.0 | 65.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +88.7 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 45.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +0.0 | 0.0 | 62.0 |
| REFORMS TO MEET IT | - | - | - | - | 2.0 | -43.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 280.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +3.7 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +89.9 | 217.0 | 0.0 | 4.3 | +45.6 | 273.7 | 192.3 |
| RISK ON THE WAY | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.0 | -46.8 | 204.0 | 62.0 |
| RUN DOWN | 0.3 | -1.3 | 0.0 | 0.0 | 3.7 | -51.9 | 367.0 | 192.3 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.0 | +7.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -47.5 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.0 | +42.7 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +62.4 | 70.0 | 62.0 |
| SELF MOVE SPELL | 2.0 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -49.0 | 0.0 | 0.0 | 3.3 | -531.9 | 0.0 | 286.7 |
| SET UP BY THE SET | 0.7 | +46.8 | 0.0 | 0.0 | 6.0 | +438.6 | 0.0 | 322.7 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +2.1 | 0.0 | 0.0 |
| SET-UP MISSED | 0.3 | +160.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 21.7 | 3.3 | +0.0 | 0.0 | 20.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +47.0 | 25.0 | 21.7 | 0.7 | +2.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -1.2 | 0.0 | 30.0 | - | - | - | - |
| SHOT RISK POINTS | 4.0 | -4.6 | 0.0 | 21.7 | 25.7 | -39.8 | 0.0 | 193.3 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 8.0 | +168.0 | 0.0 | 99.7 | 1.0 | +17.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +16.5 | 0.0 | 0.0 | 1.7 | +11.3 | 40.0 | 40.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 1.3 | -17.9 | 163.0 | 0.0 |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 435.7 | 14.7 | +0.0 | 0.0 | 310.3 |
| STAND AND SHOOT | 0.3 | -0.3 | 0.0 | 0.0 | 0.7 | -3.0 | 78.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 33.7 | +0.0 | 25.0 | 351.3 | 12.3 | +0.0 | 43.3 | 30.0 |
| STAY WORTH | 9.0 | +54.8 | 0.0 | 99.7 | 0.3 | +0.5 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +67.0 | 286.7 | 0.0 | 1.3 | +13.5 | 0.0 | 85.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.3 | -6.9 | 0.0 | 0.0 |
| STUCK PIVOT | 1.0 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.0 | +212.4 | 0.0 | 213.0 | 7.0 | +226.2 | 0.0 | 30.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 62.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.0 | +212.4 | 0.0 | 213.0 | 7.0 | +226.2 | 0.0 | 30.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +38.6 | 0.0 | 176.3 |
| SWIFTSTRIDE BY POINTS | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.7 | +1.9 | 124.0 | 0.0 | 1.7 | +41.6 | 142.3 | 68.3 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 64.0 | 7.0 | +0.0 | 20.0 | 45.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.3 | +0.0 | 0.0 | 445.0 | 41.3 | +0.0 | 0.0 | 251.7 |
| TIED UP BY THE SUM | 1.0 | +101.6 | 58.0 | 0.0 | 1.0 | +146.0 | 148.0 | 62.0 |
| TIME ON OUR SIDE | 44.3 | +421.3 | 0.0 | 501.7 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 286.7 |
| WHAT THE JOINER ADDS | 0.7 | +3.1 | 0.0 | 0.0 | 0.7 | -6.1 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.5 | 0.0 | 0.0 | 1.0 | +6.4 | 78.3 | 62.0 |
| WHO GETS IN | - | - | - | - | 0.3 | +5.3 | 0.0 | 62.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +30.8 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +7.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -363.3 | 0.0 | 206.3 | 2.3 | -223.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +22.0 | 62.0 | 0.0 | 0.3 | +4.0 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 2.7 | +341.9 | 130.3 | 282.0 | 0.3 | +7.9 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +24.4 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p22

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 121 | 121 | 74 | 24.67 | +2908 | +39.3 |
| HOLDER ASSIGNMENT | 53 | 53 | 50 | 16.67 | +2461 | +49.2 |
| LEGAL CHARGES ONLY | 39 | 39 | 39 | 13.00 | +0 | +0.0 |
| FIVE ACTION | 503 | 492 | 33 | 11.00 | +2097 | +63.5 |
| HIS SHOT LIST | 168 | 162 | 33 | 11.00 | +135 | +4.1 |
| DEPLOY BY FIGURES | 42 | 42 | 26 | 8.67 | +278 | +10.7 |
| HIS SHOTS BY HIS RUN | 127 | 127 | 26 | 8.67 | +117 | +4.5 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -988 | -43.0 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 22 | 7.33 | +132 | +6.0 |
| QUARTER ODDS | 124 | 121 | 20 | 6.67 | +1613 | +80.6 |
| MOVE ORDER | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 54 | 54 | 16 | 5.33 | -1388 | -86.7 |
| TIME ON OUR SIDE | 133 | 119 | 15 | 5.00 | +47 | +3.1 |
| FOUR ROUNDS | 28 | 28 | 14 | 4.67 | +377 | +26.9 |
| IDLE COST | 49 | 37 | 14 | 4.67 | +112 | +8.0 |
| MOVE TO CHARGE COMPUTED | 35 | 34 | 14 | 4.67 | +220 | +15.8 |
| NO CHAFF EDGES | 15 | 15 | 13 | 4.33 | +137 | +10.5 |
| CAST JOB | 12 | 12 | 12 | 4.00 | +31 | +2.6 |
| GOAL WALK | 70 | 67 | 12 | 4.00 | +1211 | +100.9 |
| SHOT RISK POINTS | 89 | 89 | 12 | 4.00 | +43 | +3.6 |
| MEETS IN TIME | 22 | 22 | 9 | 3.00 | +676 | +75.2 |
| CHARGE LOSSES | 53 | 53 | 7 | 2.33 | +392 | +55.9 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 12 | 12 | 6 | 2.00 | -235 | -39.1 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +435 | +72.5 |
| NEXT CHARGE BY LIST | 23 | 23 | 6 | 2.00 | +184 | +30.6 |
| RISK BY ARC | 23 | 23 | 6 | 2.00 | +119 | +19.8 |
| STRIKE BY THE ODDS | 6 | 6 | 6 | 2.00 | +242 | +40.3 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE NOT DECLARED | 5 | 5 | 5 | 1.67 | -1097 | -219.3 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 66 | 50 | 5 | 1.67 | +42 | +8.4 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +504 | +100.8 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +150 | +29.9 |
| REDIRECT COUNTER | 31 | 30 | 5 | 1.67 | +156 | +31.1 |
| SET UP BY THE SET | 20 | 18 | 5 | 1.67 | +427 | +85.5 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 5 | 1.67 | +58 | +11.6 |
| SUPPORT ADDS | 33 | 33 | 5 | 1.67 | +90 | +17.9 |
| SUPPORT WORKED OUT | 33 | 33 | 5 | 1.67 | +90 | +17.9 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +125 | +25.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +106 | +26.6 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 15 | 15 | 4 | 1.33 | +2 | +0.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 4 | 1.33 | +11 | +2.7 |
| CHAFF IN THE MOVE | 6 | 6 | 3 | 1.00 | +37 | +12.3 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ONE FIGHT FORMULA | 27 | 18 | 3 | 1.00 | +73 | +24.2 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| OPENS UP IN FULL | 6 | 6 | 3 | 1.00 | +33 | +11.0 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +145 | +48.4 |
| REFUSING RETIRES | 7 | 7 | 3 | 1.00 | -25 | -8.3 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +128 | +42.7 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -1 | -0.3 |
| EXACT ROUND | 16 | 16 | 2 | 0.67 | +6 | +3.0 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 5 | 5 | 2 | 0.67 | +2 | +1.2 |
| FIGHT TO THE END | 9 | 9 | 2 | 0.67 | +51 | +25.6 |
| HIS CHARGE DENIED | 3 | 3 | 2 | 0.67 | +42 | +21.0 |
| MISSILES IN THE MOVE | 22 | 14 | 2 | 0.67 | +111 | +55.5 |
| MISSILES NEXT TURN | 22 | 16 | 2 | 0.67 | +3 | +1.6 |
| PRIZE BY WORTH | 2 | 2 | 2 | 0.67 | +66 | +33.0 |
| PROMISE KNOWS THE FIGHT | 8 | 8 | 2 | 0.67 | -2 | -1.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +187 | +93.6 |
| WHOLE FIGHT DANGER | 20 | 20 | 2 | 0.67 | +37 | +18.7 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +9 | +4.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +55 | +55.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.1 |
| BACKS UP THE FIGHT | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COVER ONCE | 22 | 15 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 12 | 12 | 1 | 0.33 | +44 | +44.1 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +16 | +16.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -59 | -59.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 40 | 35 | 1 | 0.33 | +65 | +64.6 |
| ONE JOINT FIGURE | 3 | 3 | 1 | 0.33 | +4 | +4.2 |
| ONE OBJECTIVE FORMULA | 21 | 16 | 1 | 0.33 | +108 | +107.9 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +179 | +179.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +71 | +70.9 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -188 | -187.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +11 | +11.1 |
| SHOTS IN THE MOVE | 27 | 16 | 1 | 0.33 | +14 | +13.9 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -32 | -32.0 |
| SURE REACH TOGETHER | 6 | 5 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.1 |
| THE FIGHT MOVES | 10 | 10 | 1 | 0.33 | +6 | +6.1 |
| THE ROW IN ITS ORDER | 31 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +16 | +15.9 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +7 | +6.7 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.33 | +3 | +3.2 |
| WHOLE FIGHT REACTION | 9 | 9 | 1 | 0.33 | +39 | +39.3 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 89 | 87 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 18 | 18 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 36 | 36 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 9 | 9 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 22 | 22 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 25 | 25 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 29 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 20 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 39 | 37 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 30 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 29 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HOLD ODDS | 90 | 90 | 0 | 0.00 | - | - |
| HONEST WORTH | 24 | 24 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 8 | trace | - | - | - | - |
| NEAR WALKS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 19 | 19 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 14 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 254 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 9 | 9 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 12 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 19 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 71 | 62 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 138 | 133 | 0 | 0.00 | - | - |
| STAY WORTH | 28 | 21 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 233 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p22

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 3.33 | 41.8 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 4.33 | 86.7 |
| ARMY TABLE | rule | 3.00 | 1.00 | 41.8 |
| CHARGE NOW FIRST | rule | 0.67 | 1.33 | 39.1 |
| CHARGE NOT DECLARED | rule | 1.33 | 0.33 | 219.3 |
| REFUSING RETIRES | rule | 0.33 | 0.67 | 8.3 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 11.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 1.0 |
| AFTERMATH BAND | gate | - | 0.33 | 2.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 183.1 |
| CHAFF PASSED | rule | 0.33 | - | 0.6 |
| FIGHT ORDER BAND | gate | 0.33 | - | 2.5 |
| JOINT CHARGE NOW | rule | - | 0.33 | 7.0 |
| MARCH OF THE TABLE | rule | 0.33 | - | 59.4 |
| NO REASON | gate | - | 0.33 | 41.6 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 10.5 |
| PURSUES BIG PREY | rule | 0.33 | - | 187.8 |
| RULE SWITCHED OFF | gate | 0.33 | - | 6.9 |
| SUPPORT NARROWED | rule | 0.33 | - | 32.0 |

### Plans: nw22-19bea9b-p22

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 73% | 466 | 241 | 52% |
| Mine | move | 36.0 | 92% | 2216 | 0 | 0% |
| Mine | shoot | 2.0 | 33% | 177 | 28 | 16% |
| Mine | support | 0.3 | 100% | 44 | 0 | 0% |
| Opponent | charge | 3.7 | 73% | 459 | 392 | 85% |
| Opponent | join | 3.3 | 100% | 125 | 0 | 0% |
| Opponent | move | 34.0 | 94% | 2229 | 0 | 0% |
| Opponent | shoot | 1.0 | 33% | 160 | 22 | 14% |
| Opponent | support | 0.7 | 100% | 2 | 0 | 0% |

### Battle groups: nw22-19bea9b-p22

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.0 | 13% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 5.3 | 44% | 86% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p22

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 161 (7) | 0 | 161 | 23 | 14% | 3.7 | 145 (4) | 525 (1) | 0 (2) | 112 (6) | 525 (1) |
| Mine | Character | 6 | 56 (6) | 56 | 0 | 15 | 0% | 2.5 | 50 (2) | 49 (2) | 103 (1) | 80 (3) | 49 (2) |
| Mine | Clean-up | 2 | 65 (2) | 0 | 65 | 83 | 0% | 5.0 | 0 (1) | 78 (1) | - | 0 (1) | 78 (1) |
| Mine | Fast Hammer | 1 | 169 (1) | 169 | 0 | 0 | 0% | 3.0 | 169 (1) | - | - | 169 (1) | - |
| Mine | Hammer | 11 | 19 (11) | 16 | 3 | 48 | 0% | 2.8 | 0 (3) | 49 (4) | 5 (4) | 17 (9) | 23 (2) |
| Mine | Holder | 2 | 53 (2) | 0 | 53 | 0 | 50% | 2.0 | - | 343 (1) | 0 (1) | 53 (2) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 33 | 0% | 3.7 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 17 | 0% | 3.5 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 18 (9) | 0 | 18 | 59 | 44% | 3.0 | 0 (7) | 100 (2) | - | 24 (7) | 0 (2) |
| Opponent | Character | 10 | 42 (10) | 42 | 0 | 12 | 20% | 4.5 | 71 (5) | 10 (4) | - | 62 (4) | 29 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 8 | 50 (8) | 30 | 20 | 53 | 38% | 3.6 | 64 (2) | 52 (5) | 0 (1) | 44 (4) | 57 (4) |
| Opponent | Hammer | 2 | 24 (2) | 0 | 24 | 0 | 0% | 3.5 | - | 0 (1) | 37 (1) | 0 (1) | 37 (1) |
| Opponent | Holder | 1 | 76 (1) | 76 | 0 | 0 | 0% | 5.0 | - | - | 76 (1) | 76 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 12 | 25% | 2.0 | 0 (3) | 0 (1) | - | 0 (2) | 0 (2) |

### Charged fights: nw22-19bea9b-p22

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 261 | 165 | 4.0 | 1.0 | 41 | 22 | +19 | 1 of 4 | 3 of 4 | - | +19 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 1073 | 7.0 | 1.0 | 153 | 22 | +131 | 0 of 7 | 5 of 7 | - | +131 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 3 | 87 | 413 | 4.0 | 1.0 | 103 | 20 | +83 | 1 of 12 | 8 of 12 | - | +83 |
| Opponent | Vampire Counts | 2 | 0 | 338 | 3.0 | 1.2 | 112 | 0 | +112 | 2 of 6 | 4 of 6 | +0 | +135 |
| Opponent | Warriors of Chaos | 1 | 65 | 387 | 3.0 | 1.0 | 129 | 68 | +61 | 0 of 3 | 2 of 3 | - | +61 |
| **Opponent** | all armies | 3 | 22 | 354 | 3.0 | 1.1 | 118 | 23 | +95 | 2 of 9 | 6 of 9 | +0 | +107 |

### Effective charges: nw22-19bea9b-p22

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 4 | 2 (net -45) | 0 | 0 | 0 | 2 (net +82) | 0 | 0 | 0% (0 of 4) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +0) | 0 | 3 (net +58) | 1 (net +186) | 2 | 20% (1 of 5) |
| Mine | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 6 | 2 (net +92) | 0 | 1 (net +0) | 0 | 0 | 3 (net +163) | 0 | 17% (1 of 6) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 2 (net -102) | 0 | 1 (net +387) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: nw22-19bea9b-p22

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 54 | 210 | -30 | 11 | 52 | -41 | -75.6 |
| Mine | Effective (55-75%) | 1 | 60 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 350 | 186 | +186 | 186 | 0 | +186 | +53.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 320 | 56 | +68 | 75 | 3 | +72 | +22.5 |
| Mine | No odds | 2 | 55 | 118 | +278 | 356 | 92 | +265 | +481.4 |
| Mine | All fights | 12 | 190 | 126 | +83 | 109 | 30 | +79 | +41.8 |
| Opponent | Long shot (under 50%) | 2 | 143 | 241 | +92 | 92 | 0 | +92 | +64.7 |
| Opponent | Effective (55-75%) | 1 | 186 | 235 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 2 | 264 | 197 | -102 | 49 | 111 | -61 | -23.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 300 | 186 | +219 | 227 | 0 | +227 | +75.5 |
| Opponent | All fights | 9 | 245 | 206 | +95 | 132 | 25 | +108 | +44.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p22 | move | 14 | 4 (29%) | 4 (29%) | 1 (7%) | 9 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

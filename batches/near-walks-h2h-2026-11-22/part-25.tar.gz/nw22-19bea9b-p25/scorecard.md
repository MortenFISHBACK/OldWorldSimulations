# Doctrine scorecard: nw22-19bea9b-p25

### Scorecard: nw22-19bea9b-p25

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 9 | 5 | 0 | 1 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 0 | - | 0 | 7 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | yes | 2 | 6 | 4 | 2 | 0 | 0 | 0 | 117 |
| L0135 | 3 | 1 | Mine | no | 9 | 3 | 1 | 2 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 6.0 | 4.0 | 0.3 | 1.7 | 0.0 | 0.0 | 0.0 | 36.7 |
| **Average** | | | Opponent | 33% | 2.0 | 4.0 | 2.0 | 3.7 | 0.0 | 0.0 | 0.0 | 95.7 |

### KPIs: nw22-19bea9b-p25

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 16) | 0% (0 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 50% (1 of 2); on the table 50% | 60% (3 of 5); on the table 60% |
| Magic missiles tried each own turn | 50%+ | 33% (30 of 90) | 42% (10 of 24) | 35% (40 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 35% (30 of 86) | 42% (10 of 24) | 36% (40 of 110) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (3 of 4) | 75% (3 of 4) |
| Points that never fought | lower | 81% (4602 of 5700) | 80% (4717 of 5899) | 80% (9319 of 11599) |
|   infantry points that never fought | lower | 79% (2124 of 2703) | 70% (859 of 1219) | 76% (2983 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (8 of 15) | 68% (17 of 25) | 62% (25 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.7 uses a game | 75% (3 of 4); 4.0 uses a game | 86% (6 of 7); 4.3 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 0.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 100% (2 of 2); 0.7 uses a game | 100% (5 of 5); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2204 of 4077) | 67% (3273 of 4883) | 61% (5477 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 13.7 (68%) | 4.3 (93%) | 18.0 (73%) |
| MARCHED: its unit marched | 3.7 (18%) | 0.3 (7%) | 4.0 (16%) |
| CHARGED: its unit charged | 1.3 (7%) | 0.0 (0%) | 1.3 (5%) |
| IN COMBAT: engaged in combat | 1.3 (7%) | 0.0 (0%) | 1.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 12.0 | 3.3 | 10.0 | 13.3 | 0.7 |
| not cast | 6.0 | 6.7 | 6.0 | 24.7 | 43.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (30%) | 1.0 (17%) | 18.0 (73%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.3 (89%) | 4.7 (70%) | 5.0 (83%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 42.7 (98%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.3 a game | 2.3 a game | 5.3 a game |
| stood (cast and not dispelled) | 60% (15 of 25) | 29% (2 of 7) | 53% (17 of 32) |
| the unit moved after it | 87% (13 of 15) | 0% (0 of 2) | 76% (13 of 17) |
| it charged on its next turn | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
| the enemy charged it first | 7% (1 of 15) | 0% (0 of 2) | 6% (1 of 17) |
| it fought by the end of its next turn | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
| none of these (no charge, no fight, no charge escaped) | 93% (14 of 15) | 100% (2 of 2) | 94% (16 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (19 of 31) | 62% (51 of 82) | 62% (70 of 113) |
|   cavalry | - | 61% (11 of 18) | 61% (11 of 18) |
|   character | - | 75% (9 of 12) | 75% (9 of 12) |
|   chariot | - | 83% (10 of 12) | 83% (10 of 12) |
|   infantry | 61% (19 of 31) | 32% (9 of 28) | 47% (28 of 59) |
|   monster | - | 100% (12 of 12) | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (58%) | 3.0 (29%) | 5.3 (37%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| FLEEING: it fled or was fleeing | 0.3 (8%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.3 (33%) | 5.7 (55%) | 7.0 (49%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (6%) | 0.7 (5%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 3.3 | 56% | 4.8 pts | 26 pts |
| character | 3.0 | 3.0 | 56% | 8.3 pts | 25 pts |
| chariot | 3.3 | 7.3 | 40% | 16.4 pts | 55 pts |
| infantry | 10.0 | 5.0 | 67% | 7.1 pts | 71 pts |
| monster | 4.0 | 1.7 | 75% | 3.1 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 2.3 | 1.7 |
| Charges that made contact a game | 0.3 | 1.7 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.07 contact (15 units) | 0.19 declared, 0.13 contact (31 units) | 0.20 declared, 0.11 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | - | - | 33% (1 of 3) |
| Character in a unit | 60% (3 of 5) | 78% (7 of 9) | - | 71% (10 of 14) |
| Character on its own | - | 100% (2 of 2) | 100% (1 of 1) | 100% (3 of 3) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 80% (4 of 5) | 29% (2 of 7) | - | 50% (6 of 12) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 67% (2 of 3); on the table 67% | 34% (37 of 108) | 83% | 57% (12 of 21) | 100% (5 of 5); 5.8 uses a game | 67% (2 of 3); 0.5 uses a game | 100% (5 of 5); 1.2 uses a game |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 50% | - | 72% | 71% (5 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 50% (3 of 6) | 77% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p25, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 0% (0) | 33% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p25

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 80% (4 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 15% (3 of 20) | 46% (11 of 24) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | 89% (8 of 9) |
| Strategy | Joined characters whose unit fought | 17% (3 of 18) | 0% (0 of 6) |
| Strategy | Lone characters that fought | - | 0% (0 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 3.7 |
| Movement | Points that never moved of their own | 36.7 | 95.7 |
| Movement | Fights charged into per game | 0.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 2 of 4, net +28 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 4, net +77 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 4, net +65 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.0 | 17.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (10 of 21) | 44% (23 of 52) |
| Shooting | Points destroyed by shooting units | 72.0 | 18.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.7 | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 12% (2 of 17) | 71% (5 of 7) |
| Magic | Wounds caused by magic missiles | 12.3 | 7.3 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 144.3 | 25.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 7.3 / 0.3 / 0.7 / 0.0 | 2.7 / 3.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 41.7 | 40.0 |
| Combat | Points run down | 36.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +444 | +50 |
| Combat | Net per 100 charger points, damage counted | +53.1 | +38.4 |
| Combat | First round won (charged fights) | 100% | 40% |
| Combat | Net points per charged fight | +235 | +39 |
| Combat | Net points per supported fight / lone fight | - / +235 | - / +39 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 1 of 5 |
| Game | Points lost | 153.0 | 312.0 |
| Game | VP from objectives | 743.3 | 956.7 |
| Game | Lone holders (player turns) | 6.0 | 2.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -54 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 465
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: nw22-19bea9b-p25

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.0 | +337.4 | 0.0 | 87.3 | 22.0 | +38.3 | 0.0 | 166.7 |
| BACKS UP THE FIGHT | - | - | - | - | 1.0 | +16.4 | 0.0 | 41.7 |
| BACKUP TARGETS | 0.3 | +2.0 | 0.0 | 25.7 | 0.3 | +2.8 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -8.2 | 25.7 | 0.0 |
| CAST JOB | - | - | - | - | 2.7 | +16.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 5.3 | +711.3 | 367.7 | 0.0 | 1.3 | +23.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 4.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.3 | +58.4 | 0.0 | 62.3 | 1.7 | +33.8 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +11.6 | 0.0 | 25.7 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.7 | -18.8 | 0.0 | 34.0 |
| CHARGE LOSSES | 14.7 | -410.2 | 0.0 | 43.3 | 12.7 | -400.7 | 0.0 | 319.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 41.7 | 0.0 | 1.3 | +0.0 | 61.7 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 124.3 | 15.7 | +0.0 | 0.0 | 83.3 |
| CONVEYANCE SEARCH | 6.7 | +2019.8 | 0.0 | 0.0 | 2.3 | +96.1 | 0.0 | 0.0 |
| COVER ONCE | 4.7 | -264.8 | 0.0 | 21.7 | 4.7 | -82.3 | 0.0 | 75.7 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -6.8 | 21.7 | 34.0 |
| DEPLOY BY FIGURES | 6.0 | +24.3 | 0.0 | 0.0 | 9.3 | -119.9 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +18.1 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.0 | -1.2 | 40.0 | 34.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 0.7 | +0.0 | 44.0 | 0.0 |
| FALLS SHORT | 4.3 | +97.5 | 0.0 | 18.3 | 21.0 | +236.9 | 0.0 | 139.3 |
| FEATURE BUFFS | 13.0 | +337.0 | 0.0 | 138.3 | 1.0 | +34.4 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.0 | -0.3 | 18.3 | 34.0 |
| FIRE AND FLEE | - | - | - | - | 0.3 | +3.8 | 0.0 | 38.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 53.7 | +9281.4 | 553.3 | 349.3 | 118.7 | +5117.1 | 473.3 | 844.0 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 25.7 | 3.0 | +0.0 | 0.0 | 34.0 |
| FOLLOW UP WEIGHED | 0.3 | +16.3 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | - | - | - | - | 1.7 | -16.7 | 65.7 | 34.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 3.0 | +0.0 | 0.0 | 68.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -10.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -0.6 | 0.0 | 18.3 | - | - | - | - |
| GOAL WALK | 3.7 | +1206.6 | 0.0 | 0.0 | 2.7 | +95.6 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.3 | +4.8 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 3.3 | +36.5 | 94.7 | 0.0 |
| HALF WHEN STILL FLEEING | - | - | - | - | 0.7 | +0.1 | 21.7 | 34.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.0 | +0.0 | 0.0 | 68.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 34.0 |
| HIS CHARGE BY HIS RUN | 10.0 | +0.0 | 0.0 | 43.3 | 8.0 | +0.0 | 0.0 | 284.3 |
| HIS CHARGE LIST | - | - | - | - | 2.3 | +0.0 | 0.0 | 41.7 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 36.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -32.5 | 0.0 | 36.7 | 6.0 | -110.3 | 0.0 | 92.0 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 94.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 36.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.3 | +0.0 | 0.0 | 65.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 26.7 | +400.1 | 0.0 | 241.0 | 51.7 | +2589.8 | 0.0 | 338.7 |
| HIS SHOTS BY HIS RUN | 28.3 | +349.1 | 0.0 | 219.3 | 57.3 | +2195.5 | 0.0 | 616.3 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +47.0 | 21.7 | 34.0 |
| HOLD ODDS | 33.3 | +0.0 | 0.0 | 320.0 | 17.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 14.7 | +1773.7 | 0.0 | 83.3 | 13.0 | +1218.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.7 | -24.1 | 65.7 | 34.0 |
| IDLE COST | 3.0 | -104.7 | 0.0 | 0.0 | 21.3 | -197.6 | 0.0 | 169.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -11.4 | 18.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 117.3 | 2.3 | +0.0 | 0.0 | 108.7 |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.0 | +0.3 | 40.0 | 34.0 |
| MAIN BODY KEEPS ITS BAND | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +26.5 | 0.0 | 0.0 | 1.7 | +3.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +29.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +31.4 | 0.0 | 0.0 | 0.3 | +3.5 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.7 | +105.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +2.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -31.9 | 0.0 | 0.0 | 0.7 | -73.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +43.6 | 0.0 | 44.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +271.9 | 0.0 | 0.0 | 8.0 | +263.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.3 | +920.7 | 0.0 | 0.0 | 6.0 | +83.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.0 | +443.1 | 0.0 | 0.0 | 6.7 | +70.5 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 2.7 | -44.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 21.7 | 2.3 | +0.0 | 0.0 | 17.3 |
| MOVE SPELL IN RANGE | - | - | - | - | 2.0 | +175.6 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.3 | -178.4 | 0.0 | 0.0 | 2.0 | -79.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 5.3 | +232.4 | 0.0 | 41.7 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.7 | +412.0 | 0.0 | 21.7 | 5.0 | +241.5 | 0.0 | 36.7 |
| NEXT CHARGE BY LIST | - | - | - | - | 5.7 | +236.0 | 43.3 | 41.7 |
| NO CHAFF EDGES | 1.0 | +13.9 | 0.0 | 51.3 | 1.7 | +43.6 | 40.0 | 34.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.7 | -26.0 | 65.7 | 34.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 5.0 | -7.4 | 0.0 | 0.0 | 1.0 | -2.2 | 0.0 | 0.0 |
| OFF BEST | 1.7 | -53.4 | 0.0 | 18.3 | 3.3 | -110.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -29.1 | 0.0 | 65.7 | 3.7 | -51.4 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | -12.1 | 18.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.3 | +279.5 | 0.0 | 83.3 | 3.7 | +25.0 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 1.3 | -40.2 | 0.0 | 41.7 |
| ONE ROUTE | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.0 | +9.2 | 125.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +1.1 | 18.3 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -24.9 | 0.0 | 17.3 |
| PLAN RESULT | 23.3 | +204.4 | 204.7 | 233.0 | 53.0 | +220.1 | 174.0 | 624.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 0.3 | +0.0 | 0.0 | 0.0 | 9.0 | -205.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| QUARTER ODDS | 8.7 | +1071.7 | 228.0 | 138.0 | 24.0 | +2264.1 | 163.7 | 265.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.3 | +60.0 | 0.0 | 56.7 |
| REAL GROUND | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +14.9 | 0.0 | 18.3 | - | - | - | - |
| REDIRECT COUNTER | 2.0 | +46.5 | 0.0 | 44.0 | 2.7 | +92.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +19.3 | 0.0 | 36.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.0 | -23.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +11.6 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 0.7 | +10.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.0 | -6.4 | 18.3 | 34.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.0 | -6.3 | 65.7 | 0.0 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +9.2 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -69.3 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +118.8 | 0.0 | 0.0 | 1.0 | +21.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | -0.3 | 0.0 | 18.3 | 0.3 | +5.1 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +2.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.7 | +0.0 | 0.0 | 21.7 | 7.7 | +0.0 | 0.0 | 76.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +279.1 | 41.7 | 0.0 | 1.3 | +16.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.7 | 21.7 | 0.0 |
| SHOT RISK POINTS | 22.0 | -248.0 | 0.0 | 211.3 | 55.0 | +751.3 | 0.0 | 584.7 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 6.3 | +193.6 | 0.0 | 86.7 | 16.7 | +175.6 | 0.0 | 112.7 |
| SPELL SETS UP CHARGE | 1.0 | +483.7 | 0.0 | 0.0 | 0.3 | +58.0 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +9.3 | 0.0 | 0.0 | 3.0 | +49.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 47.3 | 6.7 | +0.0 | 0.0 | 112.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.3 | 21.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 19.7 | +0.0 | 553.3 | 153.0 | 51.7 | +0.0 | 407.7 | 478.0 |
| STAY WORTH | 8.3 | +211.7 | 212.0 | 130.0 | 24.0 | +125.0 | 309.0 | 36.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +5.4 | 0.0 | 75.7 |
| STRONG ENOUGH TO HOLD | 1.0 | -13.6 | 0.0 | 0.0 | 1.3 | -0.9 | 0.0 | 0.0 |
| STUBBORN ONCE | - | - | - | - | 0.7 | -6.3 | 0.0 | 34.0 |
| SUPPORT ADDS | 2.7 | +116.7 | 0.0 | 36.7 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +116.7 | 0.0 | 36.7 | - | - | - | - |
| SURE REACH TOGETHER | - | - | - | - | 1.3 | +1.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 0.7 | +0.4 | 40.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 53.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 17.3 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 25.7 | +0.0 | 0.0 | 174.7 | 58.0 | +0.0 | 0.0 | 376.7 |
| TIME ON OUR SIDE | 17.7 | +442.8 | 0.0 | 87.3 | 26.7 | +214.8 | 43.3 | 0.0 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -197.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +11.4 | 18.3 | 0.0 |
| WHOLE FIGHT REACTION | 2.3 | +104.4 | 34.0 | 65.7 | 0.7 | +28.6 | 0.0 | 55.3 |
| WOUNDS ON THE RANKS | 7.0 | +214.1 | 0.0 | 0.0 | 1.0 | +52.4 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p25

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 235 | 233 | 88 | 29.33 | +1306 | +14.8 |
| HIS SHOTS BY HIS RUN | 257 | 255 | 84 | 28.00 | +1220 | +14.5 |
| HOLDER ASSIGNMENT | 83 | 83 | 78 | 26.00 | +4736 | +60.7 |
| SHOT RISK POINTS | 231 | 230 | 67 | 22.33 | +2391 | +35.7 |
| ARMY TABLE | 99 | 99 | 65 | 21.67 | +1118 | +17.2 |
| DEPLOY BY FIGURES | 46 | 46 | 27 | 9.00 | +317 | +11.7 |
| TIME ON OUR SIDE | 133 | 114 | 26 | 8.67 | +169 | +6.5 |
| FIVE ACTION | 517 | 505 | 25 | 8.33 | +1077 | +43.1 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| MEETS IN TIME | 33 | 33 | 18 | 6.00 | +281 | +15.6 |
| QUARTER ODDS | 98 | 96 | 18 | 6.00 | +1016 | +56.4 |
| CASTING BLOCK | 20 | 20 | 17 | 5.67 | +555 | +32.6 |
| NEXT CHARGE BY LIST | 17 | 17 | 15 | 5.00 | +433 | +28.8 |
| OFF BEST | 15 | 15 | 15 | 5.00 | -493 | -32.8 |
| MOVE TO CHARGE COMPUTED | 16 | 16 | 14 | 4.67 | +430 | +30.7 |
| LEGAL CHARGES ONLY | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 28 | 28 | 13 | 4.33 | -618 | -47.5 |
| CASTER AWAY FROM SCREEN | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| MAIN BODY KEEPS ITS BAND | 10 | 10 | 10 | 3.33 | +764 | +76.4 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| GOAL WALK | 19 | 19 | 9 | 3.00 | +727 | +80.8 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| STAY WORTH | 97 | 79 | 9 | 3.00 | +236 | +26.2 |
| IDLE COST | 73 | 59 | 8 | 2.67 | +169 | +21.1 |
| NO CHAFF EDGES | 8 | 8 | 8 | 2.67 | +173 | +21.6 |
| MISSILES IN THE MOVE | 37 | 29 | 7 | 2.33 | +1174 | +167.6 |
| CAST JOB | 8 | 8 | 6 | 2.00 | +1 | +0.1 |
| CLEAR LANE AHEAD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 6 | 2.00 | +352 | +58.7 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 9 | 7 | 5 | 1.67 | +43 | +8.5 |
| FEATURE BUFFS | 42 | 42 | 5 | 1.67 | +35 | +7.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +420 | +83.9 |
| SHOTS IN THE MOVE | 69 | 44 | 5 | 1.67 | +60 | +12.0 |
| CHARGE LOSSES | 82 | 81 | 4 | 1.33 | +130 | +32.5 |
| FALLS SHORT | 76 | 63 | 4 | 1.33 | +162 | +40.5 |
| MANOEUVRE | 9 | 9 | 4 | 1.33 | +93 | +23.3 |
| MAX FOR POSITIONING | 6 | 6 | 4 | 1.33 | +3 | +0.8 |
| ONE OBJECTIVE FORMULA | 33 | 23 | 4 | 1.33 | +296 | +74.0 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -121 | -30.2 |
| SCOUT BY DROPS | 7 | 7 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +35 | +11.7 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 5 | 4 | 3 | 1.00 | +116 | +38.6 |
| NEARER NOT NEEDED | 41 | 38 | 3 | 1.00 | +92 | +30.8 |
| RANDOM MOVE BY FIGURES | 4 | 4 | 3 | 1.00 | +180 | +60.0 |
| REFUSING RETIRES | 3 | 3 | 3 | 1.00 | -27 | -9.0 |
| THE ROW IN ITS ORDER | 14 | 3 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 24 | 23 | 3 | 1.00 | +19 | +6.2 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -96 | -48.0 |
| HIS TURN DENIED | 3 | 3 | 2 | 0.67 | +58 | +28.8 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +104 | +52.2 |
| RESERVE MOVE SPELL | 2 | 2 | 2 | 0.67 | +31 | +15.4 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +16 | +8.1 |
| SUPPORT ADDS | 8 | 8 | 2 | 0.67 | +27 | +13.6 |
| SUPPORT WORKED OUT | 8 | 8 | 2 | 0.67 | +27 | +13.6 |
| SURE REACH TOGETHER | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| BACKS UP THE FIGHT | 3 | 3 | 1 | 0.33 | +12 | +11.6 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -24 | -24.5 |
| COVER ONCE | 28 | 19 | 1 | 0.33 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +12 | +11.5 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +49 | +48.9 |
| FOUR ROUNDS | 5 | 4 | 1 | 0.33 | +10 | +10.4 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -2 | -1.9 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -34 | -34.2 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +55 | +55.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -6 | -6.1 |
| MOVE SPELL IN RANGE | 6 | 4 | 1 | 0.33 | +82 | +82.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| OPENS A LANE | 4 | 2 | 1 | 0.33 | +1 | +1.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -75 | -74.6 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +35 | +34.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS AFTER THE MOVES | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +35 | +35.1 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +10 | +10.4 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 15 | trace | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 71 | 71 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 27 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 2 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 54 | 54 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 7 | 6 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 15 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 26 | 26 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 19 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 152 | 152 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 41 | 32 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 8 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 5 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 18 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 19 | 12 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 229 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 14 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| RISK BY ARC | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 37 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 34 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 20 | 17 | 0 | 0.00 | - | - |
| STANDS STILL | 214 | 206 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 7 | 7 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE FIGHT MOVES | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 251 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 8 | 8 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p25

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.33 | 3.33 | 35.1 |
| PROMISE BY ITS OWN SUM | rule | - | 4.33 | 47.5 |
| ARMY TABLE | rule | 0.67 | 2.00 | 40.6 |
| HOLDER ASSIGNMENT | rule | 1.33 | 1.00 | 17.1 |
| ONE PROMISE A TARGET | rule | - | 1.33 | 30.2 |
| MAIN BODY KEEPS ITS BAND | rule | 0.67 | 0.33 | 26.7 |
| REFUSING RETIRES | rule | - | 1.00 | 9.0 |
| CHARGE NOW FIRST | rule | - | 0.67 | 48.0 |
| AFTERMATH BAND | gate | 0.33 | - | 1.9 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 24.5 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 1.9 |
| JOINT CHARGE NOW | rule | - | 0.33 | 34.2 |
| MARCH OF THE TABLE | rule | - | 0.33 | 6.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 74.6 |

### Plans: nw22-19bea9b-p25

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 17.7 | 92% | 2504 | 0 | 0% |
| Mine | shoot | 5.3 | 56% | 1309 | 204 | 16% |
| Mine | support | 0.3 | 0% | 19 | 0 | 0% |
| Opponent | charge | 1.0 | 33% | 22 | 21 | 95% |
| Opponent | move | 45.3 | 95% | 1564 | 0 | 0% |
| Opponent | shoot | 5.7 | 65% | 378 | 199 | 53% |
| Opponent | support | 1.0 | 100% | 4 | 0 | 0% |

### Battle groups: nw22-19bea9b-p25

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 33% | 0% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p25

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Mine | Character | 18 | 17 (18) | 17 | 0 | 0 | 28% | 1.9 | 16 (3) | 36 (6) | 6 (9) | 12 (6) | 20 (12) |
| Mine | Hammer | 6 | 36 (6) | 8 | 28 | 0 | 83% | 3.0 | 152 (1) | 14 (2) | 13 (3) | 75 (2) | 16 (4) |
| Mine | Holder | 3 | 65 (3) | 0 | 65 | 67 | 67% | 4.0 | 156 (1) | 39 (1) | 0 (1) | 156 (1) | 19 (2) |
| Mine | Shooter | 6 | 155 (6) | 55 | 100 | 50 | 0% | 1.8 | 231 (2) | 118 (4) | - | 151 (5) | 175 (1) |
| Opponent | Chaff | 6 | 141 (6) | 0 | 141 | 13 | 50% | 3.0 | 0 (2) | 261 (4) | - | 202 (5) | 0 (1) |
| Opponent | Character | 8 | 4 (8) | 4 | 0 | 0 | 25% | 2.3 | 10 (2) | 0 (6) | - | 6 (5) | 0 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 7 | 10 (7) | 0 | 10 | 26 | 71% | 1.0 | 19 (4) | 0 (1) | 0 (2) | 14 (5) | 0 (2) |
| Opponent | Hammer | 13 | 38 (13) | 12 | 27 | 23 | 23% | 2.2 | - | 37 (7) | 40 (6) | 53 (7) | 9 (6) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 3 | 98 (3) | 15 | 82 | 62 | 0% | 1.7 | 140 (2) | 0 (1) | - | 140 (2) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: nw22-19bea9b-p25

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 216 | 78 | 0.3 | 1.0 | 235 | 0 | +235 | 0 of 1 | 1 of 1 | - | +235 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 1 | 0 | 197 | 4.0 | 1.0 | 49 | 0 | +49 | 0 of 4 | 2 of 4 | - | +49 |
| Opponent | Wood Elf Realms | 1 | 132 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 44 | 66 | 1.7 | 1.0 | 39 | 0 | +39 | 1 of 5 | 2 of 5 | - | +39 |

### Effective charges: nw22-19bea9b-p25

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Ogre Kingdoms | 4 | 1 (net +55) | 0 | 0 | 0 | 1 (net +77) | 1 (net +65) | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p25

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 1 | 836 | 125 | +235 | 500 | 55 | +444 | +53.1 |
| Mine | All fights | 1 | 836 | 125 | +235 | 500 | 55 | +444 | +53.1 |
| Opponent | Long shot (under 50%) | 2 | 68 | 446 | +28 | 28 | 13 | +15 | +21.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 185 | 65 | +65 | 65 | 0 | +65 | +35.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 297 | 77 | +77 | 77 | 16 | +60 | +20.4 |
| Opponent | No odds | 1 | 34 | 77 | +0 | 121 | 26 | +95 | +280.1 |
| Opponent | All fights | 5 | 130 | 222 | +39 | 64 | 14 | +50 | +38.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p25 | move | 13 | 2 (15%) | 2 (15%) | 0 (0%) | 11 (85%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

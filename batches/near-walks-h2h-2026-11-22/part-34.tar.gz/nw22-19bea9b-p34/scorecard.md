# Doctrine scorecard: nw22-19bea9b-p34

### Scorecard: nw22-19bea9b-p34

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | yes | - | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 5 | 3 | 6 | 0 | 1 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | yes | 11 | 2 | 6 | 2 | 0 | 0 | 0 | 278 |
| L2025 | 3 | 1 | Mine | no | 1 | 5 | 1 | 2 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.0 | 4.0 | 3.3 | 1.0 | 0.3 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 67% | 7.5 | 2.0 | 4.7 | 1.7 | 0.3 | 0.0 | 0.0 | 92.7 |

### KPIs: nw22-19bea9b-p34

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 18) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 100% (4 of 4); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 4); on the table 0% | 0% (0 of 4); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 50% (4 of 8); on the table 50% | 58% (7 of 12); on the table 58% |
| Magic missiles tried each own turn | 50%+ | 27% (8 of 30) | 50% (9 of 18) | 35% (17 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (8 of 22) | 50% (9 of 18) | 42% (17 of 40) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 29% (2 of 7) | - | 29% (2 of 7) |
| Points that never fought | lower | 38% (2296 of 5999) | 41% (2473 of 5999) | 40% (4769 of 11998) |
|   infantry points that never fought | lower | 71% (701 of 993) | 56% (585 of 1037) | 63% (1286 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (11 of 22) | 62% (10 of 16) | 55% (21 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2666 of 5151) | 48% (2175 of 4500) | 50% (4841 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (14%) | 3.0 (100%) | 4.0 (39%) |
| MARCHED: its unit marched | 1.7 (23%) | 0.0 (0%) | 1.7 (16%) |
| IN COMBAT: engaged in combat | 1.7 (23%) | 0.0 (0%) | 1.7 (16%) |
| REAR RANK: in a rear rank | 1.7 (23%) | 0.0 (0%) | 1.7 (16%) |
| GONE: slain | 1.0 (14%) | 0.0 (0%) | 1.0 (10%) |
| NOT OFFERED: not in the cast list | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.0 | 0.3 | 5.7 | 0.3 |
| not cast | 6.7 | 1.0 | 5.7 | 10.3 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (39%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (16%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) | 1.7 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (30%) | 0.0 (0%) | 2.0 (35%) | 1.7 (16%) | 0.0 (0%) |
| GONE: slain | 0.7 (10%) | 0.3 (33%) | 0.3 (6%) | 1.0 (10%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (60%) | 0.0 (0%) | 3.3 (59%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.7 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.3 a game | 0.2 a game |
| stood (cast and not dispelled) | - | 100% (1 of 1) | 100% (1 of 1) |
| the unit moved after it | - | 100% (1 of 1) | 100% (1 of 1) |
| it charged on its next turn | - | 100% (1 of 1) | 100% (1 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 0% (0 of 1) | 0% (0 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 55% (32 of 58) | 51% (42 of 82) | 53% (74 of 140) |
|   cavalry | - | 89% (16 of 18) | 89% (16 of 18) |
|   character | 100% (6 of 6) | 0% (0 of 24) | 20% (6 of 30) |
|   chariot | 90% (9 of 10) | - | 90% (9 of 10) |
|   infantry | 29% (10 of 34) | 65% (26 of 40) | 49% (36 of 74) |
|   monster | 88% (7 of 8) | - | 88% (7 of 8) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (12%) | 2.7 (20%) | 3.7 (17%) |
| CHARGED: it charged | 0.3 (4%) | 2.7 (20%) | 3.0 (14%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (5%) | 0.7 (3%) |
| NO TARGET IN RANGE | 5.0 (58%) | 4.3 (32%) | 9.3 (42%) |
| ONLY IN COMBAT: the only targets were in combat | 1.7 (19%) | 2.0 (15%) | 3.7 (17%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (4%) | 0.7 (5%) | 1.0 (5%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.7 | 69% | 5.6 pts | 30 pts |
| character | 2.0 | 0.7 | 67% | 10.8 pts | 22 pts |
| chariot | 3.0 | 0.7 | 78% | 6.2 pts | 19 pts |
| infantry | 15.0 | 1.7 | 89% | 1.6 pts | 24 pts |
| monster | 2.3 | 1.0 | 71% | 12.6 pts | 29 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 6.3 | 5.2 |
| Charges that made contact a game | 3.7 | 3.3 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 1.00 contact (1 units) | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.39 contact (28 units) | 0.59 declared, 0.31 contact (29 units) | 0.51 declared, 0.35 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 33% (1 of 3) | - | 33% (1 of 3) |
| Character in a unit | 100% (1 of 1) | 100% (2 of 2) | 100% (1 of 1) | 100% (4 of 4) |
| Character on its own | 25% (1 of 4) | 50% (1 of 2) | 17% (1 of 6) | 25% (3 of 12) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Monster | 75% (3 of 4) | 33% (1 of 3) | - | 57% (4 of 7) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 52% | 86% (6 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 3% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 50% (6 of 12) | 60% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 33% (2 of 6); on the table 33% | 17% (1 of 6) | 36% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 67% (8 of 12) | 51% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p34, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (5) | 100% (4) | 69% (9) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p34

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 39% (7 of 18) |
| Strategy | Shoot objectives carried out (shot that target) | 54% (13 of 24) | 18% (3 of 17) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 225.0 | 92.7 |
| Movement | Fights charged into per game | 3.7 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net +195 | 2 of 9, net -33 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 4 of 9, net +271 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 9 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | 3 of 9, net +197 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 14.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (13 of 32) | 26% (11 of 42) |
| Shooting | Points destroyed by shooting units | 0.0 | 29.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 2.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 0.3 / 0.0 | 1.0 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 441.0 | 658.0 |
| Combat | Points run down | 0.0 | 100.3 |
| Combat | Net points per charged fight, damage counted | +40 | +175 |
| Combat | Net per 100 charger points, damage counted | +21.9 | +59.6 |
| Combat | First round won (charged fights) | 45% | 70% |
| Combat | Net points per charged fight | +49 | +179 |
| Combat | Net points per supported fight / lone fight | - / +49 | - / +179 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 11 | 5 of 10 |
| Game | Points lost | 878.3 | 407.7 |
| Game | VP from objectives | 590.0 | 750.0 |
| Game | Lone holders (player turns) | 3.0 | 7.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -687 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1286
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: nw22-19bea9b-p34

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +61.3 | 0.0 | 0.0 | 0.3 | +28.3 | 0.0 | 193.3 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 1.0 | +166.8 | 0.0 | 0.0 |
| ARMY TABLE | 21.0 | +211.9 | 0.0 | 459.3 | 24.3 | +207.4 | 0.0 | 121.3 |
| ASSAILMENT BY POINTS | 0.3 | +0.1 | 0.0 | 108.7 | - | - | - | - |
| BACKS UP THE FIGHT | 0.3 | +65.5 | 0.0 | 0.0 | 2.0 | +551.3 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +6.1 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -214.5 | 131.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.7 | -21.3 | 70.0 | 65.0 |
| CAST JOB | 3.0 | +36.6 | 0.0 | 0.0 | 1.3 | +9.3 | 22.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +22.7 | 0.0 | 0.0 | 1.7 | +51.4 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.3 | +30.4 | 193.3 | 0.0 | 1.3 | -102.1 | 262.0 | 65.0 |
| CHARGE LOSSES | 15.3 | -714.0 | 0.0 | 546.7 | 14.0 | -295.9 | 0.0 | 20.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 65.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 1.0 | +0.0 | 22.0 | 0.0 | 3.7 | +0.0 | 437.0 | 130.0 |
| CLEAR LANE AHEAD | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 237.3 | 15.0 | +0.0 | 0.0 | 30.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 65.0 | 0.0 | 0.3 | +0.0 | 87.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.3 | +34.6 | 0.0 | 0.0 |
| COVER ONCE | 6.0 | -194.5 | 0.0 | 100.3 | 7.0 | -358.4 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.3 | -17.2 | 193.3 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -9.0 | 371.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +18.1 | 0.0 | 0.0 | 8.3 | +77.0 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -137.3 | 131.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 1.0 | +27.1 | 85.0 | 130.0 |
| ELIXIR WORTH | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +12.2 | 130.0 | 0.0 | 5.3 | +50.1 | 567.7 | 410.3 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 131.0 | 0.3 | +0.0 | 0.0 | 65.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 22.0 | 0.0 | 4.3 | +4.8 | 541.3 | 323.3 |
| FALLS SHORT | 3.7 | +27.6 | 0.0 | 55.0 | 17.0 | +129.0 | 0.0 | 38.7 |
| FEATURE BUFFS | 0.7 | +3.3 | 0.0 | 0.0 | 0.7 | +3.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -7.8 | 258.3 | 0.0 | 1.3 | +21.1 | 201.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 80.0 | +7081.5 | 992.0 | 1409.7 | 102.3 | +7627.3 | 1306.0 | 645.7 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 148.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | - | - | - | - | 0.3 | +5.8 | 18.3 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.7 | +97.1 | 0.0 | 65.0 |
| FOUR ROUNDS | 1.3 | +39.8 | 345.3 | 0.0 | 6.3 | +518.4 | 768.7 | 410.3 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 487.3 | - | - | - | - |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -1.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -2.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -27.8 | 131.0 | 0.0 |
| GOAL WALK | 9.0 | +837.7 | 0.0 | 85.0 | 7.3 | +997.2 | 0.0 | 0.0 |
| GUN FIGURES | 4.0 | +144.4 | 386.7 | 61.7 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.7 | +1.2 | 258.3 | 0.0 | 0.7 | -0.1 | 100.3 | 65.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 487.3 | - | - | - | - |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.7 | +0.0 | 131.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.7 | +0.0 | 0.0 | 546.7 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 218.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -15.3 | 0.0 | 36.7 | 4.3 | -51.9 | 0.0 | 22.0 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 11.3 | 11.0 | +0.0 | 0.0 | 16.7 |
| HIS RANDOM MOVE | - | - | - | - | 13.0 | +0.0 | 0.0 | 63.3 |
| HIS RANDOM MOVER COMES | - | - | - | - | 3.0 | +0.0 | 0.0 | 30.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 33.3 | +408.3 | 0.0 | 1110.3 | 47.7 | +910.4 | 0.0 | 148.7 |
| HIS SHOTS BY HIS RUN | 41.3 | +205.9 | 0.0 | 1098.7 | 40.3 | +662.9 | 0.0 | 110.7 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +49.9 | 471.3 | 0.0 |
| HOLD ODDS | 11.0 | +0.0 | 0.0 | 36.7 | 14.3 | +0.0 | 0.0 | 20.0 |
| HOLDER ASSIGNMENT | 8.0 | +547.9 | 0.0 | 18.3 | 9.7 | +896.8 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -28.2 | 280.3 | 0.0 | 5.3 | -203.1 | 768.7 | 323.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +120.1 | 0.0 | 0.0 |
| IDLE COST | 2.3 | -71.0 | 0.0 | 0.0 | 13.0 | -188.2 | 0.0 | 15.0 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +66.5 | 200.7 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -15.7 | 131.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.5 | 0.0 | 0.0 | 1.3 | +61.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 109.0 | 429.0 | 2.0 | +0.0 | 131.0 | 580.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -1.3 | 258.3 | 0.0 | 2.3 | +1.1 | 293.0 | 65.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 100.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +0.8 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | -2.7 | 0.0 | 126.0 | 0.7 | -5.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +69.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.0 | +206.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +34.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 4.7 | +212.5 | 0.0 | 0.0 | 3.0 | +142.7 | 0.0 | 31.7 |
| MEETS IN TIME | 4.3 | +196.4 | 0.0 | 0.0 | 3.3 | +171.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +34.1 | 0.0 | 0.0 | 3.3 | +22.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.0 | +61.4 | 0.0 | 0.0 | 4.3 | +15.9 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.0 | -8.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.7 | +263.6 | 0.0 | 11.3 | 10.7 | +1322.8 | 0.0 | 33.3 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 11.7 | +497.0 | 0.0 | 126.0 | 9.7 | +312.7 | 0.0 | 44.0 |
| NEXT CHARGE BY LIST | 4.0 | +214.4 | 0.0 | 0.0 | 7.3 | +951.7 | 0.0 | 16.7 |
| NO CHAFF EDGES | 2.3 | +46.6 | 280.3 | 271.0 | 4.0 | +118.2 | 693.3 | 85.0 |
| NO DOUBLE ROUNDS | 0.3 | -0.3 | 22.0 | 0.0 | 5.7 | -232.5 | 637.7 | 388.3 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.0 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.0 | -163.4 | 0.0 | 0.0 | 6.7 | -117.6 | 78.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -52.6 | 0.0 | 0.0 | 6.7 | -152.3 | 0.0 | 31.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +7.6 | 131.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -62.2 | 0.0 | 0.0 | 4.0 | +50.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.3 | -28.8 | 0.0 | 0.0 | 1.7 | -202.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +2.8 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.0 | +128.7 | 0.0 | 258.3 |
| OPENS UP IN FULL | 0.7 | +11.0 | 87.0 | 0.0 | 3.3 | +206.6 | 425.3 | 323.3 |
| OVERRUNS AWAY | 0.7 | +6.2 | 87.0 | 0.0 | 3.0 | +71.3 | 320.7 | 323.3 |
| PATHS CROSS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PLAN RESULT | 38.7 | +707.2 | 390.0 | 1179.3 | 48.7 | +997.1 | 540.7 | 867.0 |
| PRIZE BY WORTH | - | - | - | - | 1.3 | +126.9 | 0.0 | 258.3 |
| PROMISE BELOW ZERO | - | - | - | - | 1.3 | +0.0 | 0.0 | 87.0 |
| PROMISE BY ITS OWN SUM | 6.0 | -115.0 | 0.0 | 0.0 | 12.3 | -774.6 | 0.0 | 22.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 17.7 | +2165.2 | 645.0 | 261.0 | 27.7 | +2586.6 | 479.3 | 87.0 |
| RANDOM MOVE BY FIGURES | 2.3 | +26.5 | 0.0 | 140.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +12.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.3 | +267.6 | 0.0 | 25.7 | 3.0 | +68.2 | 0.0 | 37.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 92.0 | 3.7 | +23.6 | 0.0 | 59.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.7 | +32.1 | 61.7 | 258.3 |
| REFORMS TO MEET IT | 1.0 | -11.0 | 0.0 | 11.3 | 2.7 | -92.4 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 2.7 | +73.0 | 0.0 | 22.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +121.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | +5.6 | 280.3 | 0.0 | 6.0 | -153.2 | 683.7 | 410.3 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.7 | -139.4 | 509.0 | 195.0 |
| RUN DOWN | - | - | - | - | 5.0 | -37.1 | 567.7 | 195.0 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 1.0 | +6.7 | 0.0 | 0.0 | 0.7 | -0.2 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -32.5 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 0.7 | +1.5 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +38.8 | 22.0 | 0.0 | 0.3 | +50.5 | 78.0 | 0.0 |
| SELF MOVE SPELL | 1.7 | -3.1 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -17.4 | 0.0 | 0.0 | 0.7 | -142.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +39.6 | 0.0 | 0.0 | 2.0 | +183.1 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +1.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +43.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.0 | +0.0 | 0.0 | 78.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +30.4 | 386.7 | 0.0 | 2.3 | +25.6 | 131.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.3 | 193.3 | 0.0 | 1.3 | -17.0 | 242.7 | 22.0 |
| SHOT RISK POINTS | 15.7 | -80.0 | 0.0 | 485.7 | 25.0 | +160.6 | 0.0 | 105.3 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.0 | +380.2 | 0.0 | 265.7 | 12.3 | +80.4 | 0.0 | 86.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +43.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 114.7 | 6.3 | +0.0 | 0.0 | 193.3 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -6.8 | 278.7 | 193.3 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 131.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 33.3 | +0.0 | 646.7 | 445.3 | 41.3 | +0.0 | 537.3 | 124.7 |
| STAY WORTH | 9.0 | +116.8 | 0.0 | 0.0 | 13.7 | +33.8 | 406.3 | 62.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | -161.2 | 131.0 | 65.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.7 | +1311.3 | 0.0 | 317.0 | 4.7 | +220.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 193.3 |
| SUPPORT WORKED OUT | 9.7 | +1311.3 | 0.0 | 317.0 | 4.7 | +220.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +9.6 | 0.0 | 15.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.8 | 0.0 | 18.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 18.3 | 1.3 | +0.0 | 0.0 | 20.0 |
| THE FIGHT MOVES | - | - | - | - | 1.7 | +133.5 | 216.0 | 130.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 36.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 36.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.7 | +0.0 | 0.0 | 382.0 | 49.0 | +0.0 | 0.0 | 117.7 |
| TIED UP BY THE SUM | 0.3 | +29.6 | 22.0 | 0.0 | 2.0 | +195.1 | 151.0 | 258.3 |
| TIME ON OUR SIDE | 31.7 | +372.3 | 0.0 | 622.3 | 21.7 | +150.1 | 36.7 | 108.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 20.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 130.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.3 | -46.0 | 260.0 | 0.0 | 0.7 | -45.8 | 262.0 | 0.0 |
| WHO FIGHTS | 0.3 | -94.0 | 193.3 | 0.0 | 1.7 | +17.1 | 100.3 | 130.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +3.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.7 | +19.5 | 130.0 | 0.0 | 0.3 | +2.8 | 131.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -571.4 | 0.0 | 285.7 | 0.3 | -7.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +3.1 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 2.7 | +389.4 | 323.3 | 301.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.3 | +9.0 | 0.0 | 0.0 | 2.3 | +70.6 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p34

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 136 | 136 | 79 | 26.33 | +1859 | +23.5 |
| HOLDER ASSIGNMENT | 53 | 53 | 46 | 15.33 | +2068 | +45.0 |
| HIS SHOT LIST | 243 | 234 | 40 | 13.33 | +344 | +8.6 |
| HIS SHOTS BY HIS RUN | 245 | 237 | 33 | 11.00 | +261 | +7.9 |
| FIVE ACTION | 547 | 531 | 31 | 10.33 | +2370 | +76.4 |
| MOVE TO CHARGE COMPUTED | 49 | 44 | 29 | 9.67 | +1424 | +49.1 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -843 | -29.1 |
| QUARTER ODDS | 136 | 134 | 28 | 9.33 | +2469 | +88.2 |
| THE TABLE AGAIN | 35 | 35 | 25 | 8.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 48 | 48 | 24 | 8.00 | +222 | +9.2 |
| NEXT CHARGE BY LIST | 34 | 34 | 24 | 8.00 | +1305 | +54.4 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 160 | 141 | 21 | 7.00 | +65 | +3.1 |
| PROMISE BY ITS OWN SUM | 55 | 55 | 18 | 6.00 | -2669 | -148.3 |
| LEGAL CHARGES ONLY | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| SUPPORT ADDS | 43 | 43 | 14 | 4.67 | +870 | +62.1 |
| SUPPORT WORKED OUT | 43 | 43 | 14 | 4.67 | +870 | +62.1 |
| GOAL WALK | 49 | 48 | 13 | 4.33 | +1447 | +111.3 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +668 | +60.8 |
| NO CHAFF EDGES | 19 | 17 | 11 | 3.67 | +255 | +23.2 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 11 | 3.67 | +32 | +2.9 |
| SHOT RISK POINTS | 122 | 116 | 10 | 3.33 | +102 | +10.2 |
| CAST JOB | 13 | 13 | 9 | 3.00 | +6 | +0.7 |
| CHARGE LOSSES | 88 | 84 | 9 | 3.00 | +438 | +48.7 |
| ONE PROMISE A TARGET | 9 | 9 | 9 | 3.00 | -694 | -77.1 |
| RESERVE FALL BACK | 8 | 8 | 8 | 2.67 | +219 | +27.4 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CLEAR LANE AHEAD | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| IDLE COST | 46 | 30 | 7 | 2.33 | +67 | +9.6 |
| MAX FOR POSITIONING | 23 | 22 | 7 | 2.33 | +12 | +1.8 |
| SCOUTS HUNT GUNS ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 39 | 27 | 6 | 2.00 | +41 | +6.8 |
| FOUR ROUNDS | 23 | 20 | 6 | 2.00 | +434 | +72.3 |
| REDIRECT COUNTER | 22 | 21 | 6 | 2.00 | +318 | +52.9 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +291 | +58.3 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +190 | +38.0 |
| NEARER NOT NEEDED | 64 | 52 | 5 | 1.67 | +115 | +23.0 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 1.67 | +1062 | +212.4 |
| SCOUT BY DROPS | 7 | 7 | 5 | 1.67 | +0 | +0.0 |
| BACKS UP THE FIGHT | 7 | 6 | 4 | 1.33 | +525 | +131.3 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 5 | 4 | 1.33 | +3 | +0.8 |
| CHARGE NOW FIRST | 14 | 14 | 4 | 1.33 | -118 | -29.4 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| PRIZE BY WORTH | 4 | 4 | 4 | 1.33 | +381 | +95.2 |
| SET UP BY THE SET | 8 | 8 | 4 | 1.33 | +598 | +149.4 |
| SHOTS IN THE MOVE | 70 | 59 | 4 | 1.33 | +75 | +18.8 |
| SUPPORT NARROWED | 5 | 5 | 4 | 1.33 | -783 | -195.8 |
| TIED UP BY THE SUM | 7 | 4 | 4 | 1.33 | +192 | +48.1 |
| AFTERMATH WITH FRIENDS | 3 | 3 | 3 | 1.00 | +500 | +166.8 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +199 | +66.5 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| MARCH CHECK | 6 | 6 | 3 | 1.00 | +399 | +132.9 |
| ONE FIGHT FORMULA | 34 | 26 | 3 | 1.00 | +0 | +0.0 |
| OVERRUNS AWAY | 11 | 8 | 3 | 1.00 | +11 | +3.8 |
| SURE REACH TOGETHER | 6 | 6 | 3 | 1.00 | +2 | +0.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +269 | +134.4 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 18 | 16 | 2 | 0.67 | +2 | +0.8 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 62 | 51 | 2 | 0.67 | +27 | +13.5 |
| FIGHT TO THE END | 6 | 6 | 2 | 0.67 | +25 | +12.6 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 2 | 2 | 2 | 0.67 | -28 | -13.9 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +210 | +104.8 |
| OPENS A LANE | 2 | 2 | 2 | 0.67 | +8 | +4.1 |
| OPENS UP IN FULL | 12 | 10 | 2 | 0.67 | +65 | +32.7 |
| RANDOM MOVE BY FIGURES | 7 | 7 | 2 | 0.67 | +79 | +39.7 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| RISK BY ARC | 21 | 18 | 2 | 0.67 | +2 | +1.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +268 | +134.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +10 | +5.0 |
| WHOLE FIGHT DANGER | 14 | 14 | 2 | 0.67 | +101 | +50.5 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.33 | -64 | -64.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -0 | -0.5 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARACTERS BY THEIR POINTS | 5 | 5 | 1 | 0.33 | +25 | +25.1 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -208 | -208.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +10 | +9.9 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +17 | +17.3 |
| HIS MOVE AND SHOT | 27 | 27 | 1 | 0.33 | +40 | +39.9 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +133 | +132.6 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | -26 | -26.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 28 | 14 | 1 | 0.33 | +24 | +23.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 18 | 15 | 1 | 0.33 | +44 | +43.9 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +38 | +38.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -30 | -30.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +364 | +363.5 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +4 | +4.5 |
| STAY WORTH | 68 | 61 | 1 | 0.33 | +11 | +11.0 |
| STRIKE BY THE ODDS | 2 | 2 | 1 | 0.33 | +112 | +112.4 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.5 |
| THE FIGHT MOVES | 5 | 4 | 1 | 0.33 | +1 | +1.4 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 6 | 1 | 0.33 | +1 | +1.4 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +13 | +12.8 |
| WHOLE FIGHT REACTION | 8 | 8 | 1 | 0.33 | +19 | +18.9 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 77 | 77 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 9 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 61 | 58 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 24 | 24 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 56 | 52 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 39 | 39 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 9 | 9 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 4 | 0 | 0.00 | - | - |
| HOLD ODDS | 76 | 76 | 0 | 0.00 | - | - |
| HONEST WORTH | 19 | 16 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 18 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 9 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 25 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 262 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 7 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 11 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 38 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 11 | 11 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 43 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 224 | 218 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 254 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 17 | 17 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p34

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 5.67 | 31.3 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 4.33 | 148.3 |
| ONE PROMISE A TARGET | rule | 1.33 | 1.67 | 77.1 |
| ARMY TABLE | rule | 0.67 | 1.67 | 63.6 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 29.4 |
| SUPPORT NARROWED | rule | 1.33 | - | 195.8 |
| RULE SWITCHED OFF | gate | - | 0.67 | 29.2 |
| AFTERMATH BAND | gate | - | 0.33 | 1.7 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 64.0 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 208.0 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 2.5 |
| FALLBACK | gate | 0.33 | - | 0.9 |
| FOLLOW UP WEIGHED | rule | - | 0.33 | 1.7 |
| INFANTRY NOT BEHIND INFANTRY | rule | 0.33 | - | 26.0 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 27.9 |
| REFUSING RETIRES | rule | - | 0.33 | 30.0 |
| RESERVE FALL BACK | rule | - | 0.33 | 1.2 |
| SET UP BY THE SET | rule | - | 0.33 | 6.6 |

### Plans: nw22-19bea9b-p34

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 100% | 73 | 280 | 382% |
| Mine | move | 31.7 | 92% | 2002 | 0 | 0% |
| Mine | shoot | 5.7 | 76% | 1102 | 427 | 39% |
| Mine | support | 0.3 | 0% | 0 | 0 | 0% |
| Opponent | charge | 6.0 | 61% | 1149 | 755 | 66% |
| Opponent | join | 1.7 | 100% | 52 | 0 | 0% |
| Opponent | move | 37.0 | 96% | 1748 | 0 | 0% |
| Opponent | shoot | 3.7 | 73% | 259 | 243 | 94% |
| Opponent | support | 0.3 | 100% | 12 | 0 | 0% |

### Battle groups: nw22-19bea9b-p34

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 15% | 50% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 11% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p34

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 73 (1) | 73 | 0 | 0 | 0% | 5.0 | - | 73 (1) | - | - | 73 (1) |
| Mine | Chaff | 7 | 45 (7) | 0 | 45 | 76 | 29% | 3.0 | 66 (4) | 0 (3) | - | 58 (6) | 0 (1) |
| Mine | Character | 7 | 65 (7) | 65 | 0 | 39 | 0% | 3.1 | 33 (4) | 9 (1) | - | 30 (5) | - |
| Mine | Clean-up | 4 | 77 (4) | 35 | 43 | 0 | 75% | 4.0 | 66 (1) | 106 (2) | 0 (1) | 66 (1) | 91 (3) |
| Mine | Fast Hammer | 1 | 6 (1) | 6 | 0 | 115 | 0% | 3.0 | - | 6 (1) | - | - | 6 (1) |
| Mine | Hammer | 11 | 26 (11) | 4 | 22 | 58 | 9% | 2.0 | 45 (4) | 13 (6) | 0 (1) | 48 (4) | 12 (7) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 0 | 0% | 3.7 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 59 | 0% | 2.3 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 8 | 40 (8) | 17 | 23 | 47 | 38% | 1.2 | 29 (3) | 52 (1) | 47 (4) | 29 (3) | 48 (5) |
| Opponent | Character | 8 | 87 (8) | 87 | 0 | 25 | 25% | 3.5 | 95 (6) | 62 (2) | - | 129 (3) | 74 (5) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 50% | 3.5 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 7 | 43 (7) | 26 | 17 | 31 | 43% | 3.8 | 51 (3) | 36 (4) | - | 0 (2) | 62 (5) |
| Opponent | Holder | 4 | 159 (4) | 0 | 159 | 23 | 0% | 2.2 | 159 (4) | - | - | 350 (2) | 0 (2) |
| Opponent | Shooter | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | - | 0 (2) | 0 (1) | - | 0 (3) |

### Charged fights: nw22-19bea9b-p34

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 195 | 3.0 | 1.0 | 65 | 0 | +65 | 1 of 3 | 1 of 3 | - | +65 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 327 | 7.0 | 1.0 | 47 | 53 | -6 | 3 of 7 | 4 of 7 | - | -6 |
| Mine | Skaven | 1 | 0 | 580 | 1.0 | 1.0 | 580 | 195 | +385 | 1 of 1 | 0 of 1 | - | +385 |
| **Mine** | all armies | 3 | 0 | 367 | 3.7 | 1.0 | 100 | 51 | +49 | 5 of 11 | 5 of 11 | - | +49 |
| Opponent | Tomb Kings of Khemri | 2 | 44 | 877 | 4.5 | 1.0 | 195 | 14 | +181 | 4 of 9 | 6 of 9 | - | +181 |
| Opponent | Vampire Counts | 1 | 0 | 210 | 1.0 | 1.0 | 210 | 45 | +165 | 1 of 1 | 1 of 1 | - | +165 |
| **Opponent** | all armies | 3 | 30 | 655 | 3.3 | 1.0 | 196 | 17 | +179 | 5 of 10 | 7 of 10 | - | +179 |

### Effective charges: nw22-19bea9b-p34

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 3 | 1 (net +195) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 1 (net +195) | 0 | 0 | 6 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 1 (net +385) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 9 | 2 (net -33) | 0 | 3 (net +306) | 0 | 0 | 3 (net +197) | 1 | 38% (3 of 8) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1 (net +165) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p34

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 40 | 195 | +195 | 195 | 0 | +195 | +487.5 |
| Mine | 50-54% | 1 | 192 | 480 | +385 | 580 | 266 | +314 | +163.4 |
| Mine | 76-89% | 1 | 350 | 195 | +195 | 195 | 0 | +195 | +55.7 |
| Mine | No odds | 8 | 180 | 172 | -30 | 17 | 50 | -33 | -18.1 |
| Mine | All fights | 11 | 184 | 204 | +49 | 101 | 60 | +40 | +21.9 |
| Opponent | Long shot (under 50%) | 2 | 130 | 194 | -33 | 0 | 33 | -33 | -25.3 |
| Opponent | Effective (55-75%) | 4 | 386 | 283 | +271 | 297 | 26 | +271 | +70.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 232 | 175 | +197 | 202 | 26 | +176 | +75.6 |
| Opponent | No odds | 1 | 431 | 185 | +185 | 205 | 0 | +205 | +47.6 |
| Opponent | All fights | 10 | 293 | 223 | +179 | 200 | 25 | +175 | +59.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p34 | move | 18 | 6 (33%) | 3 (17%) | 3 (17%) | 9 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

# Doctrine scorecard: nw22-19bea9b-p5

### Scorecard: nw22-19bea9b-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 654 |
| L0717 | 3 | 1 | Opponent | yes | 4 | 2 | 4 | 1 | 2 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 15 | 2 | 2 | 1 | 0 | 0 | 0 | 125 |
| L0733 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 2 | 0 | 0 | 0 | 236 |
| L0823 | 1 | 1 | Mine | no | 13 | 5 | 1 | 1 | 0 | 0 | 0 | 551 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 2 | 0 | 0 | 66 |
| **Average** | | | Mine | 0% | 9.3 | 3.3 | 2.3 | 1.0 | 0.0 | 0.0 | 0.0 | 443.3 |
| **Average** | | | Opponent | 33% | 1.3 | 2.3 | 3.3 | 2.0 | 1.3 | 0.0 | 0.0 | 100.7 |

### KPIs: nw22-19bea9b-p5

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 59% (10 of 17) | 0% (0 of 15) | 31% (10 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (6 of 6); on the table 100% | 83% (5 of 6); on the table 83% | 92% (11 of 12); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | - | 33% (1 of 3); on the table 33% | 33% (1 of 3); on the table 33% |
| Winner chose to pursue after the loser fled |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 100% (6 of 6); on the table 100% | 67% (8 of 12); on the table 67% | 78% (14 of 18); on the table 78% |
| Magic missiles tried each own turn | 50%+ | 67% (8 of 12) | 17% (2 of 12) | 42% (10 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 89% (8 of 9) | 25% (2 of 8) | 59% (10 of 17) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 43% (2579 of 5998) | 33% (2009 of 6000) | 38% (4588 of 11998) |
|   infantry points that never fought | lower | 27% (190 of 715) | 62% (886 of 1418) | 50% (1076 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (17 of 30) | 45% (10 of 22) | 52% (27 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.3 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2611 of 5389) | 33% (1668 of 5023) | 41% (4279 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (60%) | 2.0 (43%) |
| CHARGED: its unit charged | 0.3 (25%) | 0.0 (0%) | 0.3 (7%) |
| IN COMBAT: engaged in combat | 1.0 (75%) | 0.0 (0%) | 1.0 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.3 (40%) | 1.3 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 1.7 | 3.3 | 0.3 | 1.3 |
| not cast | 5.0 | 0.3 | 4.7 | 1.7 | 10.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 2.0 (43%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.0 (21%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (27%) | 0.0 (0%) | 1.3 (29%) | 1.3 (80%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.3 (88%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (64 of 84) | 52% (47 of 90) | 64% (111 of 174) |
|   cavalry | 82% (9 of 11) | 50% (3 of 6) | 71% (12 of 17) |
|   character | - | 47% (7 of 15) | 47% (7 of 15) |
|   chariot | 80% (4 of 5) | - | 80% (4 of 5) |
|   infantry | 79% (15 of 19) | 59% (32 of 54) | 64% (47 of 73) |
|   monster | - | 33% (5 of 15) | 33% (5 of 15) |
|   war machine | 73% (36 of 49) | - | 73% (36 of 49) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (25%) | 2.0 (14%) | 3.7 (17%) |
| CHARGED: it charged | 0.0 (0%) | 3.7 (26%) | 3.7 (17%) |
| IN COMBAT: it fought this turn or the last | 0.7 (10%) | 1.0 (7%) | 1.7 (8%) |
| MOVED: a war machine that moved | 1.3 (20%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET IN RANGE | 0.0 (0%) | 6.3 (44%) | 6.3 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.0 (7%) | 1.0 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (35%) | 0.3 (2%) | 2.7 (13%) |
| OTHER BAR | 0.7 (10%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.0 | 1.3 | 81% | 3.9 pts | 27 pts |
| character | 2.3 | 1.0 | 57% | 23.3 pts | 54 pts |
| chariot | 1.3 | 0.3 | 75% | 8.1 pts | 11 pts |
| infantry | 21.7 | 7.7 | 71% | 8.0 pts | 173 pts |
| monster | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 12.0 | 10.3 | 64% | 24.0 pts | 288 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 7.3 | 5.0 |
| Charges that made contact a game | 1.7 | 4.3 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.50 declared, 1.00 contact (2 units) | - | 1.50 declared, 1.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.33 declared, 0.33 contact (3 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.23 declared, 0.14 contact (22 units) | 0.78 declared, 0.44 contact (27 units) | 0.53 declared, 0.31 contact (49 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (5 of 9) | 33% (1 of 3) | - | 50% (6 of 12) |
| Character in a unit | 75% (3 of 4) | - | 0% (0 of 1) | 60% (3 of 5) |
| Character on its own | 80% (4 of 5) | 100% (1 of 1) | 0% (0 of 6) | 42% (5 of 12) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | 0% (0 of 1) | 17% (1 of 6) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 70% (7 of 10) | - | - | 70% (7 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (6 of 6); on the table 100% | 67% (8 of 12) | 43% | 57% (17 of 30) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Lizardmen | 1 | 60% (3 of 5); on the table 60% | - | 22% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 43% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (2 of 4); on the table 50% | 0% (0 of 6) | 35% | 70% (7 of 10) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p5, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (3) | - | 38% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 1.33 | 0.00 | 1.33 |

### Quality by phase: nw22-19bea9b-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 25% (2 of 8) | 39% (7 of 18) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (16 of 51) | 77% (10 of 13) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | - |
| Strategy | Joined characters whose unit fought | 50% (1 of 2) | 75% (3 of 4) |
| Strategy | Lone characters that fought | 55% (6 of 11) | 83% (5 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 443.3 | 100.7 |
| Movement | Fights charged into per game | 1.7 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 8, net +526 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 5, net +98 | 3 of 8, net +23 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 0 of 8 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +88 | 2 of 8, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 16.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (12 of 29) | 60% (30 of 50) |
| Shooting | Points destroyed by shooting units | 132.3 | 30.0 |
| Shooting | War machine shots | 12.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (18 of 36) | - |
| Shooting | Points destroyed by war machines | 53.3 | 0.0 |
| Magic | Magic missiles cast | 2.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 8) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 3.0 | 3.0 |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 41.0 | 36.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.7 / 0.7 / 0.0 | 1.3 / 0.0 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 307.7 | 365.0 |
| Combat | Points run down | 0.0 | 63.0 |
| Combat | Net points per charged fight, damage counted | +83 | +119 |
| Combat | Net per 100 charger points, damage counted | +31.2 | +52.1 |
| Combat | First round won (charged fights) | 100% | 92% |
| Combat | Net points per charged fight | +94 | +127 |
| Combat | Net points per supported fight / lone fight | - / +94 | -180 / +155 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 9 of 12 |
| Game | Points lost | 822.0 | 648.3 |
| Game | VP from objectives | 783.3 | 913.3 |
| Game | Lone holders (player turns) | 9.3 | 1.3 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -447 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1470
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: nw22-19bea9b-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +12.3 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +74.8 | 0.0 | 23.3 |
| ARMY TABLE | 12.3 | +27.3 | 0.0 | 124.7 | 21.0 | +506.0 | 0.0 | 267.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +13.5 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.7 | +4.3 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 11.0 | +402.9 | 508.3 | 256.7 | - | - | - | - |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -46.5 | 34.7 | 0.0 | - | - | - | - |
| CAST JOB | 1.7 | +113.3 | 116.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -1.7 | 0.0 | 22.0 |
| CHALLENGE BY POINTS | 1.0 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.3 | +1.6 | 0.0 | 0.0 | 2.7 | -124.3 | 96.0 | 23.3 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.7 | +74.9 | 0.0 | 23.3 |
| CHARGE LOSSES | 15.3 | -460.3 | 0.0 | 109.3 | 14.0 | -876.3 | 0.0 | 411.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 257.3 | 63.0 | 2.0 | +0.0 | 112.3 | 0.0 |
| CLEAR LANE AHEAD | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 384.0 | 14.3 | +0.0 | 0.0 | 34.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 123.3 |
| COVER ONCE | 13.0 | -500.4 | 0.0 | 140.3 | 7.3 | -315.5 | 0.0 | 118.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -2.6 | 67.3 | 47.0 |
| DEPLOY BY FIGURES | 9.7 | -94.6 | 0.0 | 0.0 | 7.3 | +17.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -6.5 | 96.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +36.7 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +2.6 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | +14.8 | 254.0 | 63.0 | 4.0 | +86.1 | 216.7 | 47.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.3 | +11.5 | 195.7 | 63.0 | 3.3 | +7.1 | 154.0 | 47.0 |
| FALLBACK BY WORTH | 1.0 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 20.3 | +203.2 | 0.0 | 234.7 |
| FEATURE BUFFS | 0.7 | +12.3 | 0.0 | 0.0 | 1.0 | +20.4 | 0.0 | 22.0 |
| FIGHT TO THE END | 0.3 | +0.0 | 78.7 | 0.0 | 1.0 | +5.4 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 25.7 | - | - | - | - |
| FIVE ACTION | 93.3 | +6455.2 | 2081.0 | 1494.3 | 75.3 | +6189.9 | 628.7 | 974.7 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 30.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +154.8 | 0.0 | 0.0 | 0.7 | +190.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +104.2 | 254.0 | 63.0 | 6.0 | +411.3 | 338.3 | 70.3 |
| FREED FROM HIS FIGHT | 5.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 47.0 |
| FRIEND SHOOTS FIRST | 1.7 | -20.6 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.7 | +4.6 | 0.0 | 63.0 | - | - | - | - |
| GIVES UP | 0.3 | -0.2 | 34.7 | 0.0 | 1.0 | -21.4 | 182.7 | 47.0 |
| GOAL WALK | 2.0 | +163.5 | 0.0 | 0.0 | 16.7 | +1438.0 | 0.0 | 59.3 |
| GUN FIGURES | 1.0 | +18.1 | 87.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.7 | +23.0 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.0 | +0.3 | 58.3 | 63.0 | 1.3 | +0.4 | 137.7 | 47.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 88.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 0.0 | 63.0 | 1.0 | +0.0 | 0.0 | 23.3 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 223.0 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 73.3 | 9.0 | +0.0 | 0.0 | 47.0 |
| HIS LEGAL MOVES | 6.7 | +0.0 | 0.0 | 109.3 | 4.0 | +0.0 | 0.0 | 65.0 |
| HIS MOVE AND SHOT | 5.3 | -82.4 | 0.0 | 0.0 | 1.0 | -20.0 | 0.0 | 34.7 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 69.3 |
| HIS OWN BEST MOVE | 10.0 | +0.0 | 0.0 | 109.3 | 5.3 | +0.0 | 0.0 | 65.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.7 | +1182.4 | 0.0 | 384.7 | 47.7 | +2389.6 | 0.0 | 475.7 |
| HIS SHOTS BY HIS RUN | 35.7 | +848.8 | 0.0 | 578.3 | 46.7 | +2024.1 | 0.0 | 480.3 |
| HIS TURN DENIED | 0.3 | +7.3 | 0.0 | 0.0 | 1.7 | +93.1 | 155.7 | 47.0 |
| HOLD ODDS | 17.0 | +0.0 | 0.0 | 182.7 | 15.7 | +0.0 | 0.0 | 66.0 |
| HOLDER ASSIGNMENT | 12.3 | +1218.8 | 0.0 | 91.3 | 12.0 | +1108.6 | 0.0 | 46.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -39.1 | 254.0 | 0.0 | 4.0 | -177.6 | 338.3 | 47.0 |
| HORN WORTH | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 12.3 | -184.4 | 0.0 | 211.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +242.6 | 0.0 | 23.3 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +109.9 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 73.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +20.1 | 0.0 | 0.0 | 0.7 | +27.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 260.0 | 0.0 | 5.3 | +0.0 | 268.3 | 498.0 |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +12.7 | 0.0 | 0.0 | 1.0 | +7.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | -1.6 | 219.3 | 63.0 | 2.0 | +1.8 | 137.7 | 47.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 2.3 | +74.3 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 96.0 | 1.3 | -31.3 | 0.0 | 58.3 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +18.8 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -4.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +122.6 | 0.0 | 0.0 | 1.0 | +2.2 | 0.0 | 71.3 |
| MEETS IN TIME | 4.0 | +390.9 | 0.0 | 0.0 | 4.3 | +232.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +148.0 | 0.0 | 0.0 | 3.0 | +36.1 | 0.0 | 72.0 |
| MISSILES NEXT TURN | 2.3 | +71.3 | 0.0 | 0.0 | 3.7 | +38.6 | 0.0 | 72.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 30.0 | 1.7 | +0.0 | 0.0 | 36.0 |
| MOVE TO CHARGE COMPUTED | 8.0 | +593.7 | 0.0 | 0.0 | 5.3 | +418.7 | 0.0 | 0.0 |
| NEAR WALKS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.3 | +251.2 | 0.0 | 121.7 | 8.7 | +398.7 | 0.0 | 82.0 |
| NEXT CHARGE BY LIST | 4.7 | +408.6 | 0.0 | 0.0 | 6.0 | +382.0 | 41.7 | 58.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| NO CHAFF EDGES | 2.7 | +55.7 | 117.0 | 96.0 | 4.7 | +150.8 | 334.0 | 149.7 |
| NO DOUBLE ROUNDS | 2.3 | -71.7 | 195.7 | 63.0 | 5.0 | -156.6 | 242.3 | 70.3 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 1.3 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 28.3 | - | - | - | - |
| OFF BEST | 4.3 | -128.5 | 0.0 | 99.7 | 4.0 | -119.5 | 0.0 | 22.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 58.3 |
| ONE FIGHT FORMULA | 6.0 | -113.7 | 0.0 | 54.7 | 4.7 | -123.1 | 0.0 | 58.3 |
| ONE JOINT FIGURE | 0.3 | +6.3 | 0.0 | 63.0 | 1.0 | +53.3 | 0.0 | 23.3 |
| ONE OBJECTIVE FORMULA | 5.0 | -27.1 | 0.0 | 0.0 | 4.3 | +34.9 | 0.0 | 22.0 |
| ONE PROMISE A TARGET | 1.0 | -61.5 | 0.0 | 0.0 | 1.0 | -39.2 | 0.0 | 58.3 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +1.6 | 69.3 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +9.9 | 25.7 | 0.0 |
| OPENS UP IN FULL | 0.7 | +2.9 | 93.0 | 0.0 | 3.3 | +131.0 | 296.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.2 | 0.0 | 0.0 | 0.7 | +3.9 | 45.0 | 0.0 |
| PATHS CROSS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +28.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.7 | -19.3 | 0.0 | 58.3 |
| PLAN RESULT | 45.7 | +1269.8 | 1286.7 | 1122.7 | 36.7 | +556.9 | 368.7 | 837.0 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +36.7 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.0 | -105.2 | 0.0 | 0.0 | 6.0 | -126.6 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | -0.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -5.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 23.0 | +2447.9 | 549.0 | 262.3 | 17.3 | +2566.0 | 237.7 | 292.7 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +61.0 | 0.0 | 34.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 34.7 |
| REDIRECT WEIGHED | 0.7 | +0.5 | 0.0 | 0.0 | 1.0 | +58.0 | 63.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -10.1 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +95.8 | 254.0 | 63.0 | 4.0 | -290.0 | 338.3 | 70.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 73.3 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -40.9 | 139.3 | 0.0 |
| RUN DOWN | 1.3 | -5.0 | 137.3 | 0.0 | 4.3 | -26.9 | 296.7 | 47.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 22.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +13.5 | 0.0 | 22.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 22.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -2.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -54.8 | 0.0 | 0.0 | 0.3 | -3.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +38.9 | 0.0 | 0.0 | 2.0 | -63.1 | 0.0 | 65.0 |
| SET UP TOGETHER | 2.3 | +74.3 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 18.7 | +0.0 | 0.0 | 346.7 | 4.3 | +0.0 | 0.0 | 94.3 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +30.2 | 0.0 | 0.0 | 1.0 | +20.3 | 41.7 | 58.3 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.7 | -41.5 | 220.7 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| SHOT RISK POINTS | 25.0 | -261.1 | 0.0 | 192.7 | 25.7 | +894.9 | 0.0 | 497.7 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.3 | +1032.7 | 0.0 | 465.3 | 14.3 | +279.1 | 0.0 | 293.0 |
| SPELL WORTH | 0.3 | +2.7 | 28.3 | 28.3 | 2.7 | +49.5 | 36.0 | 156.0 |
| SPELLS IN THE FIGHT | 1.3 | +4.3 | 151.3 | 63.0 | 1.0 | -4.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 107.0 |
| STAND AND SHOOT | 2.0 | -15.3 | 219.3 | 0.0 | 0.3 | -0.7 | 25.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 116.7 |
| STANDS STILL | 56.0 | +0.0 | 1827.0 | 947.3 | 20.3 | +0.0 | 290.3 | 271.0 |
| STAY WORTH | 35.0 | +217.4 | 1059.3 | 468.3 | 11.7 | +92.8 | 248.7 | 60.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +23.6 | 96.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +10.4 | 63.0 | 0.0 |
| STUBBORN ONCE | - | - | - | - | 0.3 | -0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +44.8 | 0.0 | 0.0 | 3.3 | +66.1 | 0.0 | 12.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +44.8 | 0.0 | 0.0 | 3.3 | +66.1 | 0.0 | 12.7 |
| SURE REACH TOGETHER | 1.3 | +39.0 | 0.0 | 0.0 | 0.3 | +4.9 | 0.0 | 34.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 54.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.7 | +10.7 | 195.3 | 63.0 | 2.0 | +22.6 | 137.7 | 47.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -16.4 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.7 | +0.0 | 0.0 | 707.3 | 33.0 | +0.0 | 0.0 | 428.7 |
| TIED UP BY THE SUM | 1.0 | +89.8 | 117.0 | 0.0 | 2.0 | +223.2 | 200.7 | 0.0 |
| TIME ON OUR SIDE | 35.3 | +399.3 | 0.0 | 639.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -6.4 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +14.7 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | -1.7 | 78.7 | 0.0 | 1.0 | +16.5 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +11.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | - | - | - | - | 2.3 | -169.9 | 0.0 | 140.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +11.6 | 0.0 | 23.3 |
| WHOLE FIGHT REACTION | 5.3 | +434.8 | 47.0 | 314.7 | 1.3 | +84.2 | 0.0 | 137.3 |
| WOUNDS ON THE RANKS | 4.0 | +101.5 | 0.0 | 0.0 | 2.3 | +61.1 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 100 | 100 | 76 | 25.33 | +1737 | +22.9 |
| HOLDER ASSIGNMENT | 73 | 73 | 66 | 22.00 | +5364 | +81.3 |
| HIS SHOT LIST | 262 | 256 | 57 | 19.00 | +1086 | +19.1 |
| HIS SHOTS BY HIS RUN | 247 | 241 | 50 | 16.67 | +989 | +19.8 |
| DEPLOY BY FIGURES | 51 | 51 | 29 | 9.67 | +407 | +14.0 |
| FIVE ACTION | 506 | 494 | 26 | 8.67 | +972 | +37.4 |
| LEGAL CHARGES ONLY | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 40 | 35 | 26 | 8.67 | +1364 | +52.5 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -744 | -29.8 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| SHOT RISK POINTS | 152 | 144 | 21 | 7.00 | +904 | +43.1 |
| NEXT CHARGE BY LIST | 32 | 30 | 20 | 6.67 | +1218 | +60.9 |
| TIME ON OUR SIDE | 106 | 98 | 20 | 6.67 | +28 | +1.4 |
| QUARTER ODDS | 121 | 118 | 15 | 5.00 | +1415 | +94.3 |
| FOUR ROUNDS | 26 | 25 | 14 | 4.67 | +371 | +26.5 |
| GOAL WALK | 56 | 54 | 14 | 4.67 | +1129 | +80.6 |
| NO CHAFF EDGES | 22 | 21 | 14 | 4.67 | +325 | +23.2 |
| MEETS IN TIME | 25 | 25 | 13 | 4.33 | +516 | +39.7 |
| COVER ONCE | 61 | 43 | 11 | 3.67 | +241 | +21.9 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 10 | 3.33 | -696 | -69.6 |
| CHARGE LOSSES | 88 | 84 | 8 | 2.67 | +708 | +88.5 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 8 | 2.67 | +83 | +10.4 |
| ARTILLERY RE-ROLL WEIGHED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 12 | 12 | 7 | 2.33 | -374 | -53.5 |
| TIED UP BY THE SUM | 9 | 8 | 7 | 2.33 | +333 | +47.6 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1037 | +172.8 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -302 | -50.3 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 33 | 33 | 5 | 1.67 | -78 | -15.5 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +518 | +103.5 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 1.67 | +693 | +138.6 |
| EXACT ROUND | 19 | 18 | 4 | 1.33 | +98 | +24.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +142 | +35.4 |
| MAX FOR POSITIONING | 13 | 10 | 4 | 1.33 | +70 | +17.4 |
| MISSILES IN THE MOVE | 17 | 12 | 4 | 1.33 | +110 | +27.5 |
| SCOUT BY DROPS | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 110 | 78 | 4 | 1.33 | +66 | +16.5 |
| WHOLE FIGHT REACTION | 20 | 20 | 4 | 1.33 | +57 | +14.2 |
| CAST JOB | 5 | 5 | 3 | 1.00 | +46 | +15.3 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +87 | +29.1 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 6 | 6 | 3 | 1.00 | +32 | +10.7 |
| IDLE COST | 37 | 17 | 3 | 1.00 | +2 | +0.7 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +728 | +242.7 |
| NO DOUBLE ROUNDS | 22 | 21 | 3 | 1.00 | +87 | +29.1 |
| OPENS UP IN FULL | 12 | 11 | 3 | 1.00 | +77 | +25.8 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +86 | +28.7 |
| SET UP BY THE SET | 8 | 8 | 3 | 1.00 | -101 | -33.6 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +71 | +23.6 |
| SURE REACH TOGETHER | 5 | 5 | 3 | 1.00 | +45 | +14.9 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.67 | +225 | +112.3 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +14 | +7.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| NEARER NOT NEEDED | 45 | 45 | 2 | 0.67 | +60 | +29.9 |
| ONE JOINT FIGURE | 4 | 4 | 2 | 0.67 | +15 | +7.6 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -58 | -28.9 |
| REDIRECT COUNTER | 7 | 3 | 2 | 0.67 | +18 | +9.1 |
| RISK BY ARC | 20 | 19 | 2 | 0.67 | +8 | +3.8 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SHOTS AFTER THE MOVES | 25 | 25 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 140 | 128 | 2 | 0.67 | +34 | +17.1 |
| SUPPORT ADDS | 17 | 15 | 2 | 0.67 | +47 | +23.7 |
| SUPPORT WORKED OUT | 17 | 15 | 2 | 0.67 | +47 | +23.7 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +15 | +7.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +37 | +36.8 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +224 | +224.4 |
| BACKS UP THE FIGHT | 1 | 1 | 1 | 0.33 | +11 | +11.3 |
| BLOWS WHERE AIMED | 2 | 2 | 1 | 0.33 | +8 | +8.5 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -139 | -139.3 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -5 | -5.0 |
| CHARACTERS BY THEIR POINTS | 9 | 9 | 1 | 0.33 | +10 | +10.1 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -13 | -13.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +87 | +86.8 |
| EVASIVE BY THE ODDS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 17 | 16 | 1 | 0.33 | +2 | +2.4 |
| FRIEND SHOOTS FIRST | 6 | 5 | 1 | 0.33 | +24 | +24.0 |
| GUN MASK | 5 | 5 | 1 | 0.33 | +3 | +3.2 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +330 | +329.6 |
| LONG SHOT | 4 | 4 | 1 | 0.33 | +8 | +8.5 |
| LOST AFTER ESCAPE | 12 | 12 | 1 | 0.33 | +7 | +7.1 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +56 | +56.5 |
| MISSILES NEXT TURN | 18 | 15 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 32 | 13 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 28 | 19 | 1 | 0.33 | +22 | +22.0 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +110 | +110.2 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 1 | 0.33 | -1 | -1.3 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 7 | 6 | 1 | 0.33 | +7 | +7.1 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +31 | +31.3 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -135 | -134.9 |
| THE FIGHT MOVES | 11 | 11 | 1 | 0.33 | +8 | +7.7 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -19 | -19.2 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +28 | +28.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +10 | +10.1 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 15 | 13 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 56 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 3 | 3 | 0 | 0.00 | - | - |
| FALLS SHORT | 61 | 49 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 26 | 25 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 14 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 54 | 51 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 44 | 43 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 28 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 16 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 46 | 41 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 98 | 97 | 0 | 0.00 | - | - |
| HONEST WORTH | 19 | 18 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 247 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 8 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 69 | not checked | - | - | - | - |
| SHOT OR CHARGE | 6 | 5 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 30 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 229 | 226 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 5 | not checked | - | - | - | - |
| THE TABLE BINDS | 233 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 7 | 7 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 19 | 19 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 3.00 | 34.4 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 1.33 | 69.5 |
| HOLDER ASSIGNMENT | rule | 1.33 | 1.33 | 15.1 |
| ARMY TABLE | rule | 1.67 | 0.67 | 52.0 |
| CHARGE NOW FIRST | rule | 1.00 | 1.33 | 53.5 |
| ONE PROMISE A TARGET | rule | 1.00 | 0.67 | 60.3 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 63.6 |
| NO REASON | gate | - | 0.67 | 7.1 |
| PIVOT GUARDS FLANK | rule | - | 0.67 | 28.9 |
| AFTERMATH BAND | gate | 0.33 | - | 3.7 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 139.3 |
| CHAFF PASSED | rule | - | 0.33 | 5.0 |
| CHARGE LIST READ AGAIN | rule | - | 0.33 | 96.5 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 13.0 |
| FIGHT ORDER BAND | gate | - | 0.33 | 3.3 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 3.7 |
| JOINT CHARGE NOW | rule | - | 0.33 | 18.0 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 6.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.3 |
| SET UP BY THE SET | rule | - | 0.33 | 195.0 |
| SUPPORT NARROWED | rule | - | 0.33 | 134.9 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 19.2 |

### Plans: nw22-19bea9b-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 57% | 255 | 171 | 67% |
| Mine | join | 3.3 | 80% | 45 | 0 | 0% |
| Mine | move | 25.7 | 94% | 1575 | 0 | 0% |
| Mine | shoot | 14.3 | 56% | 1029 | 1099 | 107% |
| Opponent | charge | 4.7 | 57% | 753 | 387 | 51% |
| Opponent | move | 28.3 | 93% | 2037 | 0 | 0% |
| Opponent | shoot | 3.7 | 73% | 331 | 170 | 51% |

### Battle groups: nw22-19bea9b-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 27 (12) | 27 | 0 | 30 | 50% | 2.7 | 62 (5) | 13 (5) | 21 (1) | 40 (6) | 0 (5) |
| Mine | Clean-up | 1 | 273 (1) | 0 | 273 | 0 | 100% | - | - | 273 (1) | - | 273 (1) | - |
| Mine | Fast Hammer | 8 | 54 (8) | 24 | 29 | 66 | 25% | 2.5 | 79 (2) | 48 (6) | - | 102 (4) | 9 (4) |
| Mine | Hammer | 2 | 83 (2) | 36 | 47 | 0 | 0% | 1.5 | - | 0 (1) | 143 (1) | 143 (1) | 0 (1) |
| Mine | Shooter | 5 | 95 (5) | 0 | 95 | 51 | 0% | 1.0 | 95 (5) | - | - | 95 (5) | - |
| Mine | War machine | 10 | 38 (10) | 38 | 0 | 60 | 0% | 1.0 | 38 (10) | - | - | 242 (1) | 14 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 100 | 75% | 1.0 | 0 (2) | 0 (2) | - | 0 (4) | - |
| Opponent | Character | 9 | 55 (9) | 55 | 0 | 14 | 0% | 2.8 | - | 59 (6) | 65 (2) | 36 (2) | 74 (6) |
| Opponent | Clean-up | 3 | 17 (3) | 17 | 0 | 56 | 67% | 2.0 | 30 (2) | 0 (1) | - | 17 (3) | - |
| Opponent | Fast Hammer | 5 | 5 (5) | 5 | 0 | 76 | 20% | 2.5 | 22 (1) | 0 (1) | 0 (3) | 0 (3) | 11 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (3) | - | - | 0 (3) |
| Opponent | Hammer | 3 | 19 (3) | 19 | 0 | 61 | 0% | 3.3 | - | 0 (2) | 63 (1) | - | 19 (3) |
| Opponent | Holder | 3 | 47 (3) | 0 | 47 | 0 | 0% | 2.3 | 0 (1) | 68 (2) | - | 75 (2) | 0 (1) |
| Opponent | Shooter | 7 | 124 (7) | 4 | 120 | 31 | 14% | 1.5 | 217 (2) | 132 (4) | 38 (1) | 114 (3) | 136 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |

### Charged fights: nw22-19bea9b-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 227 | 219 | 1.7 | 1.0 | 132 | 38 | +94 | 2 of 5 | 5 of 5 | - | +94 |
| Opponent | Lizardmen | 1 | 155 | 965 | 5.0 | 1.0 | 193 | 0 | +193 | 3 of 5 | 5 of 5 | - | +193 |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 350 | 3.0 | 1.3 | 117 | 88 | +28 | 3 of 3 | 2 of 3 | -180 | +132 |
| Opponent | Wood Elf Realms | 1 | 0 | 471 | 4.0 | 1.0 | 118 | 0 | +118 | 3 of 4 | 4 of 4 | - | +118 |
| **Opponent** | all armies | 3 | 67 | 595 | 4.0 | 1.1 | 149 | 22 | +127 | 9 of 12 | 11 of 12 | -180 | +155 |

### Effective charges: nw22-19bea9b-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 5 | 0 | 0 | 3 (net +98) | 0 | 0 | 2 (net +88) | 0 | 60% (3 of 5) |
| Opponent | Lizardmen | 5 | 1 (net +526) | 0 | 1 (net +250) | 1 (net +0) | 0 | 0 | 2 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 1 (net -180) | 0 | 0 | 1 (net +0) | 1 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 1 | 33% (1 of 3) |

### Charged fights, damage counted: nw22-19bea9b-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 3 | 253 | 199 | +98 | 186 | 106 | +79 | +31.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 284 | 124 | +88 | 88 | 0 | +88 | +30.8 |
| Mine | All fights | 5 | 265 | 169 | +94 | 146 | 64 | +83 | +31.2 |
| Opponent | Long shot (under 50%) | 1 | 405 | 238 | +526 | 526 | 0 | +526 | +129.9 |
| Opponent | Effective (55-75%) | 3 | 210 | 292 | +23 | 195 | 111 | +84 | +40.2 |
| Opponent | 76-89% | 2 | 144 | 214 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 220 | 171 | +0 | 7 | 24 | -17 | -7.9 |
| Opponent | No odds | 4 | 243 | 192 | +231 | 231 | 61 | +170 | +70.2 |
| Opponent | All fights | 12 | 228 | 221 | +127 | 171 | 52 | +119 | +52.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p5 | move | 22 | 9 (41%) | 8 (36%) | 4 (18%) | 9 (41%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

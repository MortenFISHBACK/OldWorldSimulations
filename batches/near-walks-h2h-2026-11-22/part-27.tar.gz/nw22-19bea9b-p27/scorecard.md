# Doctrine scorecard: nw22-19bea9b-p27

### Scorecard: nw22-19bea9b-p27

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 2 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 588 |
| L0421 | 1 | 1 | Mine | no | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 6 | - | 0 | 4 | 0 | 0 | 0 | 500 |
| L0508 | 4 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 518 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 760 |
| **Average** | | | Mine | 0% | 3.0 | 2.0 | 2.0 | 2.0 | 0.0 | 0.0 | 0.0 | 172.7 |
| **Average** | | | Opponent | 0% | 2.0 | 3.0 | 0.3 | 3.0 | 0.0 | 0.0 | 0.0 | 616.0 |

### KPIs: nw22-19bea9b-p27

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 62% (5 of 8) | 26% (5 of 19) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | - | 67% (2 of 3); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | 50% (3 of 6) | 44% (8 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (5 of 10) | 50% (3 of 6) | 50% (8 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 62% (5 of 8) | 62% (5 of 8) |
| Points that never fought | lower | 78% (4655 of 5998) | 89% (5312 of 5999) | 83% (9967 of 11997) |
|   infantry points that never fought | lower | 87% (1239 of 1424) | 95% (1611 of 1703) | 91% (2850 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (13 of 23) | 58% (15 of 26) | 57% (28 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (1 of 1); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (2630 of 5120) | 62% (2884 of 4677) | 56% (5514 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (14%) | 1.0 (100%) | 1.3 (40%) |
| MARCHED: its unit marched | 1.0 (43%) | 0.0 (0%) | 1.0 (30%) |
| CHARGED: its unit charged | 0.3 (14%) | 0.0 (0%) | 0.3 (10%) |
| IN COMBAT: engaged in combat | 0.7 (29%) | 0.0 (0%) | 0.7 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 0.0 | 2.7 | 1.7 | 0.3 |
| not cast | 3.0 | 4.0 | 3.3 | 2.3 | 11.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (67%) | 1.3 (40%) | 0.3 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (30%) | 1.0 (43%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.3 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (17%) | 0.7 (20%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (100%) | 0.7 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.3 (97%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (56 of 87) | 79% (82 of 104) | 72% (138 of 191) |
|   cavalry | 50% (6 of 12) | 29% (2 of 7) | 42% (8 of 19) |
|   character | 90% (18 of 20) | 92% (22 of 24) | 91% (40 of 44) |
|   chariot | 36% (8 of 22) | 50% (6 of 12) | 41% (14 of 34) |
|   infantry | 50% (6 of 12) | 60% (9 of 15) | 56% (15 of 27) |
|   war machine | 86% (18 of 21) | 93% (43 of 46) | 91% (61 of 67) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.7 (45%) | 0.3 (5%) | 5.0 (28%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.0 (29%) | 2.3 (32%) | 5.3 (30%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (26%) | 4.0 (55%) | 6.7 (38%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 1.3 | 70% | 5.7 pts | 19 pts |
| character | 13.3 | 9.3 | 52% | 16.7 pts | 222 pts |
| chariot | 4.7 | 5.7 | 57% | 7.2 pts | 33 pts |
| infantry | 9.7 | 3.3 | 72% | 8.1 pts | 78 pts |
| war machine | 20.3 | 22.3 | 49% | 29.5 pts | 600 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 0.3 | 1.5 |
| Charges that made contact a game | 1.7 | 0.0 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.50 declared, 1.00 contact (2 units) | - | 1.50 declared, 1.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.23 declared, 0.14 contact (22 units) | 0.04 declared, 0.00 contact (24 units) | 0.13 declared, 0.07 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 0% (0 of 1) | - | 50% (2 of 4) |
| Character in a unit | 88% (7 of 8) | 50% (1 of 2) | 100% (1 of 1) | 82% (9 of 11) |
| Character on its own | 100% (4 of 4) | 0% (0 of 2) | 50% (1 of 2) | 62% (5 of 8) |
| Chariot | 0% (0 of 2) | 80% (4 of 5) | - | 57% (4 of 7) |
| Infantry | 50% (4 of 8) | 40% (2 of 5) | 100% (1 of 1) | 50% (7 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 25% (1 of 4) | - | - | 25% (1 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 67% (2 of 3); on the table 67% | 42% (5 of 12) | 66% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 98% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 50% (3 of 6) | 70% | 44% (4 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p27, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 25% (1) | 25% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: nw22-19bea9b-p27

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 43% (3 of 7) | 0% (0 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (24 of 36) | 60% (31 of 52) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 0% (0 of 10) |
| Strategy | Lone characters that fought | 38% (3 of 8) | 0% (0 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.0 |
| Movement | Points that never moved of their own | 172.7 | 616.0 |
| Movement | Fights charged into per game | 1.3 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 4, net +80 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 4 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.7 | 13.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (21 of 38) | 64% (25 of 39) |
| Shooting | Points destroyed by shooting units | 107.0 | 103.3 |
| Shooting | War machine shots | 6.0 | 14.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 11% (2 of 18) | 65% (28 of 43) |
| Shooting | Points destroyed by war machines | 103.3 | 318.7 |
| Magic | Magic missiles cast | 1.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 2.3 | 0.3 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.7 | 1.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 128.3 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +127 | - |
| Combat | Net per 100 charger points, damage counted | +28.8 | - |
| Combat | First round won (charged fights) | 100% | - |
| Combat | Net points per charged fight | +132 | - |
| Combat | Net points per supported fight / lone fight | +0 / +177 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | - |
| Game | Points lost | 410.3 | 444.0 |
| Game | VP from objectives | 963.3 | 640.0 |
| Game | Lone holders (player turns) | 3.0 | 2.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +362 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 854
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p27

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 16.7 | +10.8 | 0.0 | 0.0 | 8.3 | +1.0 | 0.0 | 188.3 |
| ARTILLERY RE-ROLL WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 75.0 |
| BACKUP TARGETS | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BELL IN A UNIT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | +2.9 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 45.0 | 0.0 | 0.3 | +0.0 | 31.7 | 0.0 |
| CANNON PLANNED TARGET | 5.7 | +67.0 | 326.7 | 95.0 | 14.7 | +470.2 | 620.7 | 106.7 |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +38.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 30.7 |
| CHARACTER GUNS | - | - | - | - | 7.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.0 | -1077.2 | 0.0 | 514.7 | 11.7 | -351.7 | 0.0 | 269.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 132.3 | 0.0 | - | - | - | - |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 70.0 |
| COVER ONCE | 2.3 | -90.9 | 0.0 | 103.3 | 4.0 | -661.6 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +9.9 | 0.0 | 31.7 | 9.0 | -42.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +56.3 | 70.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.3 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.0 | +23.8 | 150.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.6 | 80.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 12.3 | +167.2 | 0.0 | 103.3 | 4.3 | +106.6 | 0.0 | 0.0 |
| FIVE ACTION | 96.0 | +5947.5 | 1223.3 | 938.0 | 89.7 | +4251.6 | 1544.0 | 937.3 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 125.0 | 4.7 | +0.0 | 0.0 | 30.7 |
| FOLLOW UP WEIGHED | 0.3 | +65.9 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.7 | +83.3 | 211.3 | 0.0 | 0.3 | +115.2 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 13.3 | +1326.6 | 0.0 | 43.3 | 4.7 | +319.1 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +15.6 | 30.7 | 103.3 | 1.3 | +69.0 | 0.0 | 21.7 |
| GUN MASK | 0.7 | -25.5 | 0.0 | 0.0 | 0.7 | +39.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 54.7 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 3.3 | +0.0 | 0.0 | 103.3 | 5.0 | +0.0 | 0.0 | 179.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +16.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| HIS MOVE AND SHOT | 1.3 | -1.5 | 0.0 | 0.0 | 4.0 | -49.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 159.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| HIS RANDOM MOVE | 4.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 46.0 | +2175.5 | 0.0 | 442.0 | 36.7 | +956.0 | 0.0 | 383.0 |
| HIS SHOTS BY HIS RUN | 37.0 | +810.2 | 0.0 | 644.7 | 27.7 | +789.4 | 0.0 | 269.7 |
| HIS TURN DENIED | 0.7 | +24.5 | 31.7 | 0.0 | - | - | - | - |
| HOLD ODDS | 19.0 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 11.7 | +1123.5 | 0.0 | 0.0 | 8.7 | +815.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -93.1 | 211.3 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 1.3 | +292.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 11.0 | -158.6 | 0.0 | 89.7 | 4.3 | -35.0 | 0.0 | 95.7 |
| JOINT CHARGE NOW | 0.7 | +44.5 | 61.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 1.3 | +55.0 | 0.0 | 0.0 | - | - | - | - |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +12.3 | 30.7 | 0.0 | 0.3 | -18.1 | 0.0 | 0.0 |
| LOST CHARGE | 0.3 | -0.2 | 70.0 | 0.0 | - | - | - | - |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +52.6 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +30.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +38.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +30.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +39.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.0 | +124.6 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 2.7 | +296.6 | 0.0 | 0.0 | 4.3 | +181.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +39.8 | 0.0 | 0.0 | 1.7 | +21.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.3 | +38.6 | 0.0 | 0.0 | 1.3 | +9.1 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 21.7 |
| MOVE SPELL IN RANGE | 2.3 | +53.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.0 | -218.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.3 | +190.7 | 0.0 | 103.3 | - | - | - | - |
| NEAR WALKS ONLY | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.0 | +232.7 | 0.0 | 0.0 | 4.0 | +149.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +190.7 | 0.0 | 103.3 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 0.7 | -46.9 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 4.0 | +105.8 | 101.7 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.7 | -41.2 | 211.3 | 0.0 | 0.3 | -78.4 | 0.0 | 0.0 |
| NO LATE CUT | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.3 | -0.9 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -212.0 | 0.0 | 31.7 | 1.3 | -17.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -97.2 | 0.0 | 103.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.0 | +80.0 | 0.0 | 0.0 | 3.0 | +33.1 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.7 | +68.9 | 101.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +65.3 | 79.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +2.2 | 0.0 | 0.0 |
| PLAN RESULT | 42.0 | +678.4 | 375.3 | 533.7 | 42.3 | +882.4 | 687.0 | 654.7 |
| PRIZE BY WORTH | 0.3 | +73.8 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 7.3 | -196.4 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.3 | +2871.4 | 86.7 | 318.7 | 26.0 | +1540.6 | 796.7 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +53.2 | 0.0 | 333.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +40.8 | 0.0 | 21.7 | 0.3 | +13.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.7 | +25.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +15.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | -179.7 | 180.7 | 0.0 | 0.3 | -2.5 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -1.4 | 31.7 | 0.0 | - | - | - | - |
| RUN DOWN | 1.0 | -4.1 | 109.7 | 0.0 | 0.3 | -18.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +17.4 | 0.0 | 0.0 | 0.3 | +8.3 | 0.0 | 15.0 |
| SECOND LOOK | 0.3 | +53.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -70.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | -24.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 1.0 | +57.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.7 | +0.0 | 0.0 | 95.0 | 18.0 | +0.0 | 0.0 | 161.3 |
| SHOOTS FROM THE BEST SPOT | 5.0 | +60.2 | 0.0 | 0.0 | 1.3 | +22.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -19.9 | 30.7 | 0.0 | 0.3 | -7.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 28.7 | +507.5 | 0.0 | 601.3 | 26.3 | +14.7 | 0.0 | 453.0 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.3 | +375.9 | 0.0 | 198.3 | 26.3 | +1124.7 | 0.0 | 228.0 |
| SPELL WORTH | 0.3 | +0.4 | 0.0 | 0.0 | 2.7 | +21.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 197.3 |
| STAND AND SHOOT | 0.3 | -1.1 | 48.3 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 44.3 | +0.0 | 1012.0 | 293.3 | 60.3 | +0.0 | 1544.0 | 579.3 |
| STAY WORTH | 32.7 | +466.6 | 1012.0 | 571.3 | 37.7 | +420.3 | 674.0 | 519.0 |
| STRONG ENOUGH TO HOLD | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.0 | +5.8 | 0.0 | 0.0 | 0.7 | +47.7 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.0 | +5.8 | 0.0 | 0.0 | 0.7 | +47.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +24.9 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.3 | -0.0 | 70.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 43.3 | 2.0 | +0.0 | 0.0 | 30.7 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 43.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.3 | +0.0 | 0.0 | 469.0 | 43.3 | +0.0 | 0.0 | 257.0 |
| TIED UP BY THE SUM | 1.7 | +227.2 | 110.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 12.7 | +177.1 | 0.0 | 21.7 | 29.7 | +299.4 | 0.0 | 69.7 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| WHO HITS BACK | 0.3 | +12.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -59.1 | 0.0 | 0.0 | 1.3 | -37.5 | 0.0 | 109.7 |
| WHOLE FIGHT REACTION | 0.3 | +10.9 | 0.0 | 0.0 | 2.3 | +71.4 | 0.0 | 62.3 |
| WOUNDS ON THE RANKS | 2.0 | +393.3 | 0.0 | 159.3 | 7.0 | +225.0 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p27

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 248 | 245 | 71 | 23.67 | +1280 | +18.0 |
| HOLDER ASSIGNMENT | 61 | 61 | 58 | 19.33 | +3018 | +52.0 |
| ARMY TABLE | 75 | 75 | 53 | 17.67 | +259 | +4.9 |
| SHOT RISK POINTS | 165 | 163 | 50 | 16.67 | +1375 | +27.5 |
| HIS SHOTS BY HIS RUN | 194 | 186 | 37 | 12.33 | +561 | +15.2 |
| DEPLOY BY FIGURES | 53 | 53 | 29 | 9.67 | +502 | +17.3 |
| GOAL WALK | 54 | 54 | 21 | 7.00 | +1034 | +49.2 |
| TIME ON OUR SIDE | 127 | 109 | 21 | 7.00 | +130 | +6.2 |
| ARTILLERY RE-ROLL WEIGHED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| OFF BEST | 16 | 16 | 16 | 5.33 | -690 | -43.1 |
| THE TABLE AGAIN | 36 | 36 | 14 | 4.67 | +0 | +0.0 |
| IDLE COST | 46 | 38 | 13 | 4.33 | +74 | +5.7 |
| CANNON PLANNED TARGET | 61 | 61 | 12 | 4.00 | +0 | +0.0 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +437 | +54.6 |
| NO CHAFF EDGES | 12 | 11 | 8 | 2.67 | +111 | +13.9 |
| PROMISE BY ITS OWN SUM | 22 | 22 | 8 | 2.67 | -590 | -73.7 |
| STAY WORTH | 211 | 188 | 8 | 2.67 | +63 | +7.9 |
| WOUNDS ON THE RANKS | 27 | 27 | 8 | 2.67 | +241 | +30.1 |
| FIVE ACTION | 557 | 547 | 7 | 2.33 | +425 | +60.7 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 6 | 2.00 | +38 | +6.3 |
| CHARGE LOSSES | 89 | 87 | 5 | 1.67 | +211 | +42.1 |
| FOUR ROUNDS | 9 | 8 | 5 | 1.67 | +191 | +38.2 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 5 | 1.67 | +160 | +31.9 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 19 | 16 | 4 | 1.33 | +5 | +1.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +165 | +41.3 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| WHOLE FIGHT REACTION | 8 | 8 | 4 | 1.33 | +64 | +16.0 |
| MAX FOR POSITIONING | 9 | 8 | 3 | 1.00 | +28 | +9.4 |
| MOVE TO CHARGE COMPUTED | 7 | 7 | 3 | 1.00 | +195 | +64.9 |
| NEXT CHARGE BY LIST | 7 | 7 | 3 | 1.00 | +195 | +64.9 |
| QUARTER ODDS | 163 | 161 | 3 | 1.00 | +101 | +33.6 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +300 | +100.1 |
| SHOTS AFTER THE MOVES | 21 | 21 | 3 | 1.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 122 | 89 | 3 | 1.00 | +42 | +14.1 |
| TIED UP BY THE SUM | 5 | 4 | 3 | 1.00 | +51 | +17.0 |
| CAST JOB | 3 | 3 | 2 | 0.67 | +4 | +2.2 |
| FALLS SHORT | 50 | 39 | 2 | 0.67 | +20 | +9.8 |
| GUN MASK | 4 | 4 | 2 | 0.67 | +77 | +38.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +133 | +66.7 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +66 | +33.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +45 | +22.4 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +77 | +38.5 |
| SET UP BY THE SET | 2 | 2 | 2 | 0.67 | -231 | -115.7 |
| SUPPORT ADDS | 5 | 5 | 2 | 0.67 | +9 | +4.5 |
| SUPPORT WORKED OUT | 5 | 5 | 2 | 0.67 | +9 | +4.5 |
| SURE REACH TOGETHER | 3 | 3 | 2 | 0.67 | +22 | +10.8 |
| WHOLE FIGHT DANGER | 12 | 12 | 2 | 0.67 | +5 | +2.3 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.4 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +18 | +18.1 |
| EXACT ROUND | 6 | 5 | 1 | 0.33 | +1 | +0.7 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +198 | +197.6 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +57 | +57.2 |
| HUNT IN PAIRS | 4 | 4 | 1 | 0.33 | +147 | +147.3 |
| LEGAL CHARGES ONLY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 1 | 1 | 1 | 0.33 | +28 | +28.1 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +90 | +90.4 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -110 | -109.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -93 | -92.5 |
| NEARER NOT NEEDED | 27 | 24 | 1 | 0.33 | +48 | +48.4 |
| NO DOUBLE ROUNDS | 9 | 8 | 1 | 0.33 | +1 | +0.7 |
| ONE FIGHT FORMULA | 11 | 8 | 1 | 0.33 | +2 | +1.7 |
| ONE OBJECTIVE FORMULA | 15 | 7 | 1 | 0.33 | +44 | +43.5 |
| OPENS UP IN FULL | 5 | 4 | 1 | 0.33 | +1 | +0.7 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +55 | +54.7 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +222 | +221.5 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -1.5 |
| REDIRECT COUNTER | 2 | 2 | 1 | 0.33 | +68 | +68.3 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | +1 | +1.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +161 | +161.4 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 21 | 21 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 40 | 40 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 22 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 25 | 23 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 6 | 6 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 8 | 8 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 10 | 10 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 13 | 13 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 92 | 92 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 10 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 11 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| NEAR WALKS ONLY | 12 | 12 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 11 | 11 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 253 | trace | - | - | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| RISK BY ARC | 7 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 89 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 29 | 16 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 314 | 308 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE FIGHT MOVES | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 266 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p27

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 1.33 | 43.4 |
| ARMY TABLE | rule | 4.33 | - | 49.0 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | - | 73.7 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 20.4 |
| SET UP BY THE SET | rule | 0.67 | - | 115.7 |
| MARCH ODDS | rule | 0.33 | - | 109.7 |
| MARCH OF THE TABLE | rule | 0.33 | - | 92.5 |
| NO REASON | gate | 0.33 | - | 38.0 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 1.5 |

### Plans: nw22-19bea9b-p27

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 257 | 181 | 70% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 29.3 | 97% | 1739 | 0 | 0% |
| Mine | shoot | 10.0 | 47% | 589 | 498 | 85% |
| Opponent | charge | 0.3 | 0% | 68 | 0 | 0% |
| Opponent | join | 2.7 | 100% | 92 | 0 | 0% |
| Opponent | move | 24.7 | 89% | 1002 | 0 | 0% |
| Opponent | shoot | 14.7 | 68% | 756 | 882 | 117% |

### Battle groups: nw22-19bea9b-p27

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p27

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 30 (11) | 30 | 0 | 13 | 18% | 2.1 | 56 (5) | 23 (2) | 10 (3) | 25 (6) | 37 (4) |
| Mine | Clean-up | 2 | 150 (2) | 0 | 150 | 0 | 50% | 4.0 | 150 (2) | - | - | 150 (2) | - |
| Mine | Hammer | 8 | 13 (8) | 5 | 8 | 33 | 25% | 1.8 | 0 (2) | 16 (6) | - | 27 (5) | 0 (3) |
| Mine | Holder | 5 | 52 (5) | 0 | 52 | 22 | 80% | 6.0 | 60 (2) | 46 (3) | - | 86 (1) | 42 (4) |
| Mine | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 5 | 65 (5) | 65 | 0 | 40 | 0% | 1.0 | 82 (4) | 0 (1) | - | - | 65 (5) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (2) | 0 (1) | 0 (2) |
| Opponent | Character | 13 | 20 (13) | 20 | 0 | 3 | 46% | 2.7 | 30 (9) | 0 (3) | 0 (1) | 22 (11) | 0 (2) |
| Opponent | Clean-up | 2 | 66 (2) | 0 | 66 | 45 | 100% | - | - | 66 (2) | - | 66 (2) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 8 | 37 (8) | 11 | 26 | 27 | 25% | 2.0 | 69 (3) | 16 (2) | 18 (3) | 37 (8) | - |
| Opponent | Holder | 3 | 38 (3) | 0 | 38 | 29 | 67% | 4.0 | - | 59 (2) | 0 (1) | 59 (2) | 0 (1) |
| Opponent | Shooter | 4 | 73 (4) | 0 | 73 | 59 | 25% | 1.7 | - | 73 (4) | - | 73 (4) | - |
| Opponent | War machine | 9 | 97 (9) | 97 | 0 | 36 | 11% | 1.0 | 97 (9) | - | - | 0 (1) | 112 (8) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | 0 (1) | 0 (2) | - |

### Charged fights: nw22-19bea9b-p27

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 78 | 298 | 2.0 | 1.2 | 149 | 16 | +132 | 1 of 4 | 4 of 4 | +0 | +177 |
| Mine | Dwarfen Mountain Holds | 1 | 474 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 210 | 198 | 1.3 | 1.2 | 149 | 16 | +132 | 1 of 4 | 4 of 4 | +0 | +177 |
| Opponent | Dwarfen Mountain Holds | 1 | 449 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 817 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 422 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: nw22-19bea9b-p27

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 0 | 0 | 0 | 1 (net +290) | 3 (net +80) | 0 | 0 | 0% (0 of 4) |

### Charged fights, damage counted: nw22-19bea9b-p27

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 339 | 210 | +290 | 355 | 65 | +290 | +85.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 473 | 111 | +80 | 103 | 31 | +72 | +15.3 |
| Mine | All fights | 4 | 440 | 136 | +132 | 166 | 40 | +127 | +28.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p27 | move | 8 | 2 (25%) | 1 (12%) | 1 (12%) | 5 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

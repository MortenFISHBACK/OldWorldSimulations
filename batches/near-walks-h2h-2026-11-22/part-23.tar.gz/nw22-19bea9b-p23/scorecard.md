# Doctrine scorecard: nw22-19bea9b-p23

### Scorecard: nw22-19bea9b-p23

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 9 | - | 0 | 1 | 0 | 0 | 0 | 200 |
| L2131 | 1 | 1 | Opponent | no | 0 | 6 | 2 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 266 |
| L2429 | 5 | 1 | Mine | no | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 6.0 | 2.5 | 1.7 | 1.0 | 0.0 | 0.0 | 0.0 | 66.7 |
| **Average** | | | Opponent | 33% | 0.0 | 4.0 | 2.7 | 2.3 | 0.3 | 0.0 | 0.0 | 145.3 |

### KPIs: nw22-19bea9b-p23

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 12% (2 of 16) | 0% (0 of 15) | 6% (2 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (6 of 6); on the table 100% | 100% (4 of 4); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 20% (1 of 5); on the table 20% | 0% (0 of 1); on the table 0% | 17% (1 of 6); on the table 17% |
| Winner chose to follow up or pursue (all three) |  | 64% (7 of 11); on the table 64% | 67% (4 of 6); on the table 67% | 65% (11 of 17); on the table 65% |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | - | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (5 of 10) | - | 50% (5 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (6 of 9) | 47% (7 of 15) | 54% (13 of 24) |
| Points that never fought | lower | 45% (2708 of 5997) | 64% (3812 of 5999) | 54% (6520 of 11996) |
|   infantry points that never fought | lower | 51% (856 of 1675) | 63% (826 of 1306) | 56% (1682 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 71% (15 of 21) | 81% (25 of 31) | 77% (40 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 100% (2 of 2); 1.7 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (3432 of 4866) | 79% (4646 of 5884) | 75% (8078 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (57%) | - | 1.3 (57%) |
| IN COMBAT: engaged in combat | 0.3 (14%) | - | 0.3 (14%) |
| GONE: slain | 0.3 (14%) | - | 0.3 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (14%) | - | 0.3 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 8.7 | 1.7 | 1.7 | 1.7 | 0.7 |
| not cast | 1.3 | 6.3 | 0.3 | 2.3 | 23.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (58%) | 0.0 (0%) | 1.3 (57%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) |
| GONE: slain | 0.3 (25%) | 0.7 (11%) | 0.0 (0%) | 0.3 (14%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (11%) | 0.3 (100%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.0 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 40% (2 of 5) | 40% (2 of 5) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (39 of 60) | 55% (18 of 33) | 61% (57 of 93) |
|   cavalry | 100% (8 of 8) | 60% (9 of 15) | 74% (17 of 23) |
|   character | 0% (0 of 12) | 27% (3 of 11) | 13% (3 of 23) |
|   chariot | 80% (8 of 10) | - | 80% (8 of 10) |
|   infantry | 77% (23 of 30) | 86% (6 of 7) | 78% (29 of 37) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (19%) | 1.3 (27%) | 2.7 (22%) |
| CHARGED: it charged | 2.0 (29%) | 1.7 (33%) | 3.7 (31%) |
| IN COMBAT: it fought this turn or the last | 0.3 (5%) | 0.3 (7%) | 0.7 (6%) |
| NO TARGET IN RANGE | 2.3 (33%) | 1.7 (33%) | 4.0 (33%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (10%) | 0.0 (0%) | 0.7 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.0 | 1.0 | 90% | 3.8 pts | 38 pts |
| character | 1.0 | 0.7 | 33% | 5.7 pts | 6 pts |
| chariot | 2.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 10.7 | 1.7 | 88% | 3.8 pts | 41 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 2.7 | 3.2 |
| Charges that made contact a game | 3.0 | 2.0 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.00 contact (1 units) | - | 1.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.32 contact (28 units) | 0.32 declared, 0.24 contact (25 units) | 0.34 declared, 0.28 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | 100% (4 of 4) | - | 80% (8 of 10) |
| Character in a unit | 75% (3 of 4) | 100% (1 of 1) | 100% (2 of 2) | 86% (6 of 7) |
| Character on its own | 100% (3 of 3) | 100% (1 of 1) | 50% (3 of 6) | 70% (7 of 10) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 91% (10 of 11) | 100% (4 of 4) | - | 93% (14 of 15) |
| Monster | 40% (2 of 5) | 100% (1 of 1) | - | 50% (3 of 6) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 50% (2 of 4); on the table 50% | 50% (3 of 6) | 57% | 67% (6 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 33% (1 of 3); on the table 33% | - | 42% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 37% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 67% (4 of 6); on the table 67% | - | 72% | 79% (15 of 19) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 47% | 83% (10 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p23, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 50% (2) | 50% (4) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: nw22-19bea9b-p23

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 64% (7 of 11) | 57% (4 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (3 of 7) | 33% (2 of 6) |
| Strategy | Support requests answered (helper made contact too) | 33% (1 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 66.7 | 145.3 |
| Movement | Fights charged into per game | 2.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 6, net +0 | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 6, net +53 | 2 of 5, net +144 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 6 | 3 of 5, net -19 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.3 | 6.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 28% (11 of 40) | 28% (5 of 18) |
| Shooting | Points destroyed by shooting units | 0.0 | 45.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (2 of 5) | - |
| Magic | Wounds caused by magic missiles | 3.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 38.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 7.0 / 0.0 / 0.0 / 0.0 | 0.0 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 233.7 | 427.3 |
| Combat | Points run down | 38.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +12 | +27 |
| Combat | Net per 100 charger points, damage counted | +2.9 | +7.3 |
| Combat | First round won (charged fights) | 71% | 50% |
| Combat | Net points per charged fight | +15 | +39 |
| Combat | Net points per supported fight / lone fight | -66 / +47 | - / +39 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 7 | 2 of 6 |
| Game | Points lost | 555.3 | 588.0 |
| Game | VP from objectives | 833.3 | 360.0 |
| Game | Lone holders (player turns) | 6.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +575 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1143
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: nw22-19bea9b-p23

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +10.3 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 25.0 | +551.8 | 0.0 | 453.0 | 23.3 | +179.7 | 0.0 | 333.3 |
| BACKS UP THE FIGHT | 1.0 | +168.4 | 0.0 | 313.3 | 1.0 | +46.5 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.0 | +4.5 | 0.0 | 52.7 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.7 | -2.3 | 0.0 | 38.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +31.5 | 0.0 | 41.7 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.3 | +14.4 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.0 | -369.0 | 0.0 | 123.0 | 17.7 | -391.9 | 0.0 | 626.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 248.7 | 0.0 | 1.3 | +0.0 | 200.7 | 199.7 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 74.7 | 9.0 | +0.0 | 0.0 | 83.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 38.7 | 205.0 | 1.3 | +0.0 | 194.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +98.2 | 52.7 | 91.3 |
| COVER ONCE | 7.7 | -532.2 | 0.0 | 0.0 | 7.0 | -412.3 | 0.0 | 271.7 |
| DENIED BY THE FIGHT | 0.7 | -4.2 | 93.3 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | +55.2 | 0.0 | 0.0 | 7.3 | +60.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +4.6 | 140.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 2.7 | +962.1 | 48.0 | 441.3 |
| EXACT ROUND | 2.7 | -12.5 | 142.7 | 78.3 | 1.3 | +21.1 | 257.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 1.0 | +0.0 | 0.0 | 37.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.3 | +8.5 | 179.3 | 78.3 | 1.7 | +0.0 | 257.0 | 199.7 |
| FALLS SHORT | 10.0 | +33.0 | 0.0 | 176.7 | 14.3 | +186.7 | 0.0 | 442.3 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +5.8 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -26.5 | 0.0 | 78.3 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.3 | +0.7 | 0.0 | 38.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 87.0 | +5061.8 | 858.0 | 1098.3 | 79.3 | +4041.8 | 325.0 | 1337.0 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 108.3 | 4.7 | +0.0 | 0.0 | 275.3 |
| FOLLOW UP WEIGHED | 1.7 | +97.8 | 0.0 | 37.3 | 1.3 | +363.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.3 | +79.5 | 319.3 | 78.3 | 2.3 | +237.8 | 277.0 | 199.7 |
| FREED FROM HIS FIGHT | 5.7 | +0.0 | 0.0 | 201.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -6.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -5.1 | 34.0 | 0.0 | - | - | - | - |
| GOAL WALK | 7.7 | +585.5 | 0.0 | 0.0 | 8.7 | +459.4 | 0.0 | 122.0 |
| GUN FIGURES | 0.7 | +3.5 | 38.7 | 43.3 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.7 | -0.7 | 0.0 | 0.0 | 0.7 | -0.2 | 76.3 | 0.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 42.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 48.3 | 9.3 | +0.0 | 0.0 | 550.7 |
| HIS CHARGE DENIED | 0.7 | +65.2 | 0.0 | 78.3 | 0.3 | +59.3 | 0.0 | 199.7 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 36.7 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -16.2 | 0.0 | 48.0 | 5.0 | -28.1 | 0.0 | 36.7 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 151.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 40.0 | 9.3 | +0.0 | 0.0 | 399.3 |
| HIS RANDOM MOVE | 24.3 | +0.0 | 0.0 | 362.0 | 14.0 | +0.0 | 0.0 | 154.7 |
| HIS RANDOM MOVER COMES | 7.7 | +0.0 | 0.0 | 187.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 30.3 | +629.6 | 0.0 | 562.0 | 36.3 | +896.9 | 0.0 | 791.7 |
| HIS SHOTS BY HIS RUN | 31.3 | +260.4 | 0.0 | 192.0 | 32.0 | +499.6 | 0.0 | 824.0 |
| HIS TURN DENIED | 1.3 | +16.2 | 168.0 | 0.0 | 0.3 | +5.5 | 24.0 | 0.0 |
| HOLD ODDS | 19.0 | +0.0 | 0.0 | 96.0 | 11.7 | +0.0 | 0.0 | 52.7 |
| HOLDER ASSIGNMENT | 12.7 | +839.2 | 0.0 | 48.0 | 6.7 | +314.5 | 0.0 | 52.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -109.7 | 319.3 | 78.3 | 2.3 | -84.3 | 277.0 | 199.7 |
| IDLE COST | 4.0 | -70.3 | 0.0 | 156.7 | 10.0 | -137.4 | 0.0 | 314.0 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | 1.7 | +520.1 | 93.3 | 78.3 | - | - | - | - |
| JOINT LOOK BACK | 0.3 | +16.6 | 46.7 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | 0.3 | +297.8 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 52.7 |
| LANE BY FIGURES | 0.7 | +24.5 | 0.0 | 0.0 | 0.7 | +11.3 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 0.0 | 387.7 | 4.0 | +0.0 | 235.0 | 93.3 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | -5.0 | 0.0 | 0.0 | 0.3 | +4.5 | 24.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +1.3 | 0.0 | 78.3 | 0.7 | +0.2 | 76.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.3 | +15.0 | 0.0 | 0.0 | 1.3 | +26.5 | 0.0 | 77.3 |
| MANOEUVRE | 1.3 | -7.3 | 0.0 | 0.0 | 1.3 | -14.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +33.1 | 0.0 | 0.0 | 1.7 | +47.5 | 0.0 | 77.3 |
| MEETS IN TIME | 5.3 | +209.8 | 0.0 | 0.0 | 3.3 | +63.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +62.5 | 0.0 | 156.7 | 3.0 | +35.5 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 2.7 | +31.6 | 0.0 | 156.7 | 3.0 | +23.0 | 0.0 | 52.7 |
| MISSILES ON ONE TARGET | 0.7 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 21.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.0 | +520.0 | 0.0 | 353.3 | 6.7 | +312.0 | 0.0 | 438.0 |
| NEARER NOT NEEDED | 9.3 | +354.7 | 0.0 | 0.0 | 5.7 | +249.4 | 0.0 | 46.7 |
| NEXT CHARGE BY LIST | 4.0 | +309.3 | 0.0 | 0.0 | 4.7 | +248.3 | 0.0 | 38.7 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -40.7 | 0.0 | 52.7 |
| NO CHAFF EDGES | 3.7 | +108.3 | 236.0 | 13.7 | 4.0 | +85.3 | 127.3 | 199.7 |
| NO DOUBLE ROUNDS | 4.0 | -153.9 | 319.3 | 78.3 | 2.3 | -141.1 | 277.0 | 199.7 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 1.7 | -90.7 | 0.0 | 0.0 | 3.3 | -94.1 | 0.0 | 94.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -70.9 | 0.0 | 37.3 | 6.0 | -83.6 | 0.0 | 277.0 |
| ONE JOINT FIGURE | 1.0 | +102.2 | 0.0 | 78.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 6.7 | -93.3 | 0.0 | 48.0 | 2.0 | -28.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -3.0 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +35.7 | 36.7 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 2.7 | +93.8 | 272.7 | 0.0 | 1.0 | +24.0 | 76.3 | 199.7 |
| OVERRUNS AWAY | 1.0 | +6.9 | 120.0 | 0.0 | 0.7 | +2.9 | 180.7 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +484.7 | 157.3 | 1065.7 | 38.3 | +264.3 | 156.7 | 971.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 156.7 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 7.7 | -317.0 | 0.0 | 353.3 | 11.7 | -332.9 | 0.0 | 522.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 313.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 19.3 | +2177.1 | 472.7 | 227.3 | 22.0 | +2155.6 | 233.0 | 378.3 |
| RANDOM MOVE BY FIGURES | 3.0 | +45.3 | 0.0 | 96.7 | 5.0 | +71.4 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.0 | +133.6 | 0.0 | 104.0 | 0.3 | +4.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +0.0 | 0.0 | 100.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.3 | -68.9 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 2.3 | +64.3 | 0.0 | 72.0 | 0.7 | +11.5 | 0.0 | 0.0 |
| RISK BY ARC | 3.7 | -4.8 | 319.3 | 0.0 | 2.3 | -0.7 | 277.0 | 199.7 |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.3 | -24.2 | 176.7 | 0.0 | - | - | - | - |
| RUN DOWN | 3.7 | -20.3 | 285.3 | 78.3 | 0.3 | -5.2 | 0.0 | 0.0 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +2.9 | 0.0 | 0.0 | 0.3 | -2.2 | 0.0 | 52.7 |
| SECOND LOOK | 0.3 | +14.0 | 46.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -3.4 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 2.3 | +18.7 | 0.0 | 76.3 | 1.3 | +26.5 | 0.0 | 77.3 |
| SET-UP ANY TARGET | - | - | - | - | 0.7 | +46.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 99.3 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +13.1 | 399.3 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -7.9 | 34.0 | 0.0 | 0.3 | -0.3 | 24.0 | 0.0 |
| SHOT RISK POINTS | 19.0 | -151.4 | 0.0 | 96.0 | 19.7 | -121.1 | 0.0 | 701.3 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.7 | +190.7 | 0.0 | 139.3 | 5.0 | +98.6 | 0.0 | 179.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.7 | +46.8 | 0.0 | 0.0 |
| SPELL WORTH | 4.7 | +115.9 | 313.3 | 313.3 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | +5.6 | 0.0 | 0.0 | 0.7 | -6.5 | 156.7 | 0.0 |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 280.0 | 7.7 | +0.0 | 0.0 | 110.7 |
| STAND AND SHOOT | 0.3 | -4.0 | 36.7 | 0.0 | 0.3 | -0.3 | 24.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 0.0 | 84.0 |
| STANDS STILL | 36.3 | +0.0 | 538.7 | 313.0 | 31.7 | +0.0 | 48.0 | 268.7 |
| STAY WORTH | 10.0 | +38.9 | 34.0 | 43.3 | 5.3 | +28.1 | 0.0 | 184.0 |
| STRONG ENOUGH TO HOLD | 1.0 | -24.7 | 0.0 | 0.0 | 0.7 | -23.6 | 0.0 | 0.0 |
| STUBBORN ONCE | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 48.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.0 | +72.4 | 0.0 | 0.0 | 4.3 | +63.9 | 0.0 | 116.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 24.0 | 0.0 |
| SUPPORT WORKED OUT | 6.0 | +72.4 | 0.0 | 0.0 | 4.3 | +63.9 | 0.0 | 116.0 |
| SURE REACH TOGETHER | 1.0 | +3.9 | 0.0 | 0.0 | 0.7 | +20.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.3 | +1.0 | 140.0 | 0.0 | 1.0 | -0.1 | 233.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -6.9 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 61.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.3 | +0.0 | 0.0 | 461.7 | 35.7 | +0.0 | 0.0 | 568.7 |
| TIED UP BY THE SUM | 2.3 | +258.9 | 282.7 | 0.0 | 0.7 | +100.8 | 20.0 | 199.7 |
| TIME ON OUR SIDE | 31.3 | +322.8 | 0.0 | 283.3 | 20.0 | +159.8 | 0.0 | 0.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 77.3 |
| WHO GETS IN | 1.0 | +583.1 | 0.0 | 78.3 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +36.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.7 | -278.1 | 0.0 | 123.0 | 2.0 | -152.5 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +7.2 | 0.0 | 78.3 | - | - | - | - |
| WHOLE FIGHT REACTION | 0.7 | +27.5 | 0.0 | 0.0 | 1.3 | +50.5 | 78.3 | 111.3 |
| WOUNDS ON THE RANKS | - | - | - | - | 2.3 | +168.9 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p23

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 145 | 145 | 97 | 32.33 | +2464 | +25.4 |
| HIS SHOT LIST | 200 | 181 | 54 | 18.00 | +575 | +10.7 |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +3124 | +57.9 |
| HIS SHOTS BY HIS RUN | 190 | 177 | 40 | 13.33 | +387 | +9.7 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 58 | 58 | 27 | 9.00 | -1949 | -72.2 |
| MOVE TO CHARGE COMPUTED | 38 | 30 | 26 | 8.67 | +965 | +37.1 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 47 | 47 | 24 | 8.00 | +212 | +8.8 |
| FIVE ACTION | 499 | 476 | 23 | 7.67 | +891 | +38.7 |
| GOAL WALK | 49 | 45 | 18 | 6.00 | +1045 | +58.0 |
| NEXT CHARGE BY LIST | 26 | 23 | 18 | 6.00 | +809 | +44.9 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 154 | 133 | 16 | 5.33 | +23 | +1.4 |
| OFF BEST | 15 | 15 | 15 | 5.00 | -554 | -37.0 |
| NO CHAFF EDGES | 23 | 21 | 14 | 4.67 | +338 | +24.1 |
| RANDOM MOVE BY FIGURES | 24 | 24 | 13 | 4.33 | +350 | +26.9 |
| MEETS IN TIME | 26 | 26 | 12 | 4.00 | +505 | +42.0 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +1384 | +153.8 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| QUARTER ODDS | 124 | 122 | 9 | 3.00 | +1075 | +119.4 |
| RESERVE FALL BACK | 9 | 9 | 9 | 3.00 | +227 | +25.3 |
| SHOT RISK POINTS | 116 | 112 | 9 | 3.00 | +133 | +14.8 |
| FOUR ROUNDS | 20 | 18 | 8 | 2.67 | +432 | +54.0 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 98 | 95 | 6 | 2.00 | +53 | +8.8 |
| CLEAR LANE AHEAD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COMBAT PIVOT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 14 | 13 | 6 | 2.00 | +9 | +1.4 |
| SUPPORT ADDS | 31 | 29 | 6 | 2.00 | +49 | +8.1 |
| SUPPORT WORKED OUT | 31 | 29 | 6 | 2.00 | +49 | +8.1 |
| COVER ONCE | 44 | 32 | 5 | 1.67 | +145 | +28.9 |
| EVASIVE BY THE ODDS | 8 | 8 | 5 | 1.67 | +2856 | +571.3 |
| IDLE COST | 42 | 27 | 5 | 1.67 | +10 | +2.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +1560 | +312.1 |
| FACES WHAT IT FOLLOWS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +107 | +26.8 |
| MAIN BODY KEEPS ITS BAND | 4 | 4 | 4 | 1.33 | +206 | +51.6 |
| STAY WORTH | 46 | 35 | 4 | 1.33 | +29 | +7.2 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 9 | 7 | 4 | 1.33 | +127 | +31.8 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| NEARER NOT NEEDED | 45 | 44 | 3 | 1.00 | +110 | +36.7 |
| ONE OBJECTIVE FORMULA | 26 | 22 | 3 | 1.00 | +94 | +31.3 |
| WHO GETS IN | 3 | 3 | 3 | 1.00 | +1749 | +583.1 |
| WHOLE FIGHT DANGER | 23 | 22 | 3 | 1.00 | +43 | +14.5 |
| WOUNDS ON THE RANKS | 7 | 7 | 3 | 1.00 | +199 | +66.3 |
| BACKS UP THE FIGHT | 6 | 3 | 2 | 0.67 | +116 | +57.8 |
| CAST JOB | 6 | 6 | 2 | 0.67 | +3 | +1.3 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -7 | -3.4 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +94 | +47.2 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 19 | 17 | 2 | 0.67 | +77 | +38.7 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -9 | -4.5 |
| OPENS UP IN FULL | 11 | 9 | 2 | 0.67 | +60 | +30.2 |
| PROMISE READS THE TABLE | 2 | 2 | 2 | 0.67 | -15 | -7.3 |
| RISK BY ARC | 18 | 16 | 2 | 0.67 | +70 | +35.1 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SET UP BY THE SET | 4 | 4 | 2 | 0.67 | +66 | +33.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 2 | 0.67 | +11 | +5.4 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -147 | -73.4 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +2 | +0.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +31 | +30.9 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 1 | 0.33 | +37 | +37.4 |
| EXACT ROUND | 12 | 12 | 1 | 0.33 | +2 | +1.9 |
| FALL BACK GOOD ORDER | 15 | 15 | 1 | 0.33 | +3 | +3.1 |
| FALLS SHORT | 73 | 61 | 1 | 0.33 | +21 | +21.4 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +2 | +2.2 |
| HIS TURN DENIED | 5 | 3 | 1 | 0.33 | +3 | +3.1 |
| HONEST WORTH | 19 | 17 | 1 | 0.33 | +2 | +1.9 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +50 | +49.9 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +894 | +893.5 |
| ONE FIGHT FORMULA | 34 | 16 | 1 | 0.33 | +1 | +1.2 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +57 | +57.4 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +3 | +3.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -2 | -1.8 |
| REDIRECT COUNTER | 13 | 10 | 1 | 0.33 | +3 | +3.0 |
| SCOUT BY DROPS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +9 | +8.7 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +42 | +41.9 |
| SHOTS AFTER THE MOVES | 7 | 7 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 16 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +62 | +61.7 |
| WHOLE FIGHT REACTION | 6 | 6 | 1 | 0.33 | +1 | +1.1 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 12 | 11 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 11 | 11 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 3 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 6 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 56 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 27 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 36 | 35 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 47 | 43 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 115 | 112 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 28 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 92 | 92 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 26 | 26 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 11 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 13 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 239 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 11 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 13 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 56 | 43 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 39 | 35 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 204 | 194 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 5 | 5 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE FIGHT MOVES | 7 | 5 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 228 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 9 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p23

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 6.00 | 72.2 |
| ARMY TABLE | rule | 1.67 | 3.33 | 64.5 |
| JOB FIRST | gate | 1.67 | 3.00 | 39.4 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.00 | 26.2 |
| CHAFF PASSED | rule | - | 0.67 | 3.4 |
| JOINT CHARGE NOW | rule | 0.67 | - | 94.5 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.67 | 2.5 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 4.5 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 73.4 |
| NO REASON | gate | - | 0.33 | 3.2 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 1.8 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 18.6 |

### Plans: nw22-19bea9b-p23

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 70% | 824 | 251 | 30% |
| Mine | join | 0.7 | 100% | 26 | 0 | 0% |
| Mine | move | 35.7 | 93% | 1401 | 0 | 0% |
| Mine | shoot | 1.7 | 80% | 158 | 234 | 148% |
| Opponent | charge | 1.7 | 60% | 413 | 220 | 53% |
| Opponent | join | 0.3 | 100% | 37 | 0 | 0% |
| Opponent | move | 34.7 | 92% | 1200 | 0 | 0% |
| Opponent | shoot | 1.7 | 80% | 72 | 44 | 61% |

### Battle groups: nw22-19bea9b-p23

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.0 | 17% | 50% | 0% | - | 0% | 0% | 50% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p23

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 38 (5) | 0 | 38 | 81 | 20% | 2.2 | 0 (2) | 91 (2) | 0 (1) | 0 (2) | 59 (3) |
| Mine | Character | 7 | 28 (7) | 28 | 0 | 40 | 29% | 2.4 | 29 (6) | 24 (1) | - | 57 (2) | 17 (5) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 142 (4) | 142 | 0 | 0 | 50% | 2.0 | 156 (3) | 0 (1) | - | 294 (2) | 0 (2) |
| Mine | Hammer | 5 | 7 (5) | 7 | 0 | 33 | 20% | 2.5 | 0 (1) | 0 (2) | 22 (2) | 0 (3) | 21 (2) |
| Mine | Holder | 7 | 35 (7) | 0 | 35 | 45 | 29% | 4.4 | 121 (2) | 6 (3) | 0 (1) | 67 (4) | 0 (2) |
| Mine | Shooter | 5 | 205 (5) | 43 | 163 | 44 | 0% | 1.0 | 655 (1) | 205 (2) | 0 (2) | 195 (3) | 224 (2) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Character | 8 | 42 (8) | 42 | 0 | 42 | 62% | 1.3 | 137 (3) | 0 (4) | - | 0 (5) | 100 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 15 (5) | 8 | 7 | 32 | 60% | 1.0 | 36 (2) | 0 (3) | - | 0 (1) | 19 (4) |
| Opponent | Hammer | 10 | 42 (10) | 42 | 0 | 15 | 20% | 3.2 | 55 (6) | 19 (3) | 0 (1) | 60 (6) | 0 (4) |
| Opponent | Holder | 4 | 24 (4) | 0 | 24 | 0 | 75% | 6.0 | - | 45 (2) | 0 (1) | - | 29 (3) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 100 | 0% | 1.3 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |

### Charged fights: nw22-19bea9b-p23

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 116 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 0 | 337 | 6.0 | 1.2 | 56 | 0 | +56 | 0 of 6 | 5 of 6 | +102 | +47 |
| Mine | Vampire Counts | 1 | 0 | 0 | 1.0 | 2.0 | 0 | 235 | -235 | 1 of 1 | 0 of 1 | -235 | - |
| **Mine** | all armies | 3 | 39 | 112 | 2.3 | 1.3 | 48 | 34 | +15 | 1 of 7 | 5 of 7 | -66 | +47 |
| Opponent | Warriors of Chaos | 2 | 32 | 380 | 2.0 | 1.0 | 190 | 0 | +190 | 1 of 4 | 2 of 4 | - | +190 |
| Opponent | Wood Elf Realms | 1 | 72 | 72 | 2.0 | 1.0 | 36 | 300 | -264 | 1 of 2 | 1 of 2 | - | -264 |
| **Opponent** | all armies | 3 | 46 | 277 | 2.0 | 1.0 | 138 | 100 | +39 | 2 of 6 | 3 of 6 | - | +39 |

### Effective charges: nw22-19bea9b-p23

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 6 | 1 (net +0) | 0 | 0 | 0 | 4 (net +53) | 0 | 1 | 0% (0 of 5) |
| Mine | Vampire Counts | 1 | 0 | 0 | 0 | 1 (net -235) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 2 (net +144) | 1 (net +470) | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -264) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: nw22-19bea9b-p23

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 55 | 102 | +0 | 0 | 15 | -15 | -27.3 |
| Mine | 76-89% | 1 | 440 | 494 | -235 | 0 | 256 | -256 | -58.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 480 | 110 | +53 | 69 | 0 | +69 | +14.3 |
| Mine | No odds | 1 | 411 | 125 | +125 | 125 | 46 | +79 | +19.3 |
| Mine | All fights | 7 | 404 | 166 | +15 | 57 | 45 | +12 | +2.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 365 | 246 | -19 | 202 | 200 | +3 | +0.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 494 | 94 | +144 | 144 | 0 | +144 | +29.3 |
| Opponent | No odds | 1 | 120 | 92 | +0 | 18 | 154 | -136 | -113.2 |
| Opponent | All fights | 6 | 367 | 170 | +39 | 152 | 126 | +27 | +7.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p23 | move | 23 | 3 (13%) | 1 (4%) | 3 (13%) | 17 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

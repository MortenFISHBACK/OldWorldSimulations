# Doctrine scorecard: nw22-19bea9b-p26

### Scorecard: nw22-19bea9b-p26

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | 6 | 1 | 7 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | - | 0 | 7 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 340 |
| L0319 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 320 |
| **Average** | | | Mine | 0% | 0.5 | 4.5 | 0.7 | 4.7 | 0.0 | 0.0 | 0.0 | 226.7 |
| **Average** | | | Opponent | 0% | 2.0 | 2.0 | 1.7 | 2.0 | 0.3 | 0.0 | 0.0 | 106.7 |

### KPIs: nw22-19bea9b-p26

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (3 of 12) | 0% (0 of 12) | 12% (3 of 24) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 100% | 100% (6 of 6); on the table 100% | 89% (8 of 9); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 75% | - | 25% (1 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 38% (3 of 8); on the table 75% | 100% (6 of 6); on the table 100% | 64% (9 of 14); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 36% (15 of 42) | 17% (4 of 24) | 29% (19 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (15 of 42) | 21% (4 of 19) | 31% (19 of 61) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (5 of 10) | - | 50% (5 of 10) |
| Points that never fought | lower | 55% (3196 of 5797) | 62% (3734 of 6000) | 59% (6930 of 11797) |
|   infantry points that never fought | lower | 68% (940 of 1374) | 56% (475 of 842) | 64% (1415 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (12 of 20) | 52% (14 of 27) | 55% (26 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.3 uses a game | 50% (1 of 2); 1.3 uses a game | 83% (5 of 6); 2.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (1992 of 4039) | 48% (2626 of 5515) | 48% (4618 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (67%) | 0.0 (0%) | 6.0 (38%) |
| MARCHED: its unit marched | 3.0 (33%) | 1.0 (15%) | 4.0 (26%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (10%) | 0.7 (4%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.7 (40%) | 2.7 (17%) |
| GONE: slain | 0.0 (0%) | 1.0 (15%) | 1.0 (6%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (20%) | 1.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.7 | 3.7 | 6.3 | 0.3 |
| not cast | 2.3 | 6.3 | 15.7 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (11%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (14%) | 0.3 (5%) | 6.0 (38%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 4.0 (26%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (86%) | 3.0 (47%) | 2.7 (17%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| GONE: slain | 0.0 (0%) | 0.3 (5%) | 1.0 (6%) | 2.3 (8%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 2.7 (42%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.7 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.0 a game | 0.7 a game | 1.8 a game |
| stood (cast and not dispelled) | 78% (7 of 9) | 100% (2 of 2) | 82% (9 of 11) |
| the unit moved after it | 29% (2 of 7) | 0% (0 of 2) | 22% (2 of 9) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 2) | 0% (0 of 9) |
| the enemy charged it first | 0% (0 of 7) | 0% (0 of 2) | 0% (0 of 9) |
| it fought by the end of its next turn | 0% (0 of 7) | 0% (0 of 2) | 0% (0 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 7) | 0% (0 of 2) | 0% (0 of 9) |
| none of these (no charge, no fight, no charge escaped) | 100% (7 of 7) | 100% (2 of 2) | 100% (9 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (24 of 36) | 65% (54 of 83) | 66% (78 of 119) |
|   cavalry | - | 47% (8 of 17) | 47% (8 of 17) |
|   character | - | 67% (8 of 12) | 67% (8 of 12) |
|   chariot | 42% (5 of 12) | 100% (12 of 12) | 71% (17 of 24) |
|   infantry | - | 47% (14 of 30) | 47% (14 of 30) |
|   monster | - | 100% (12 of 12) | 100% (12 of 12) |
|   war machine | 79% (19 of 24) | - | 79% (19 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (33%) | 5.0 (52%) | 6.3 (46%) |
| CHARGED: it charged | 0.3 (8%) | 0.7 (7%) | 1.0 (7%) |
| IN COMBAT: it fought this turn or the last | 0.7 (17%) | 0.3 (3%) | 1.0 (7%) |
| MOVED: a war machine that moved | 1.3 (33%) | 0.0 (0%) | 1.3 (10%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.3 (24%) | 2.3 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.0 (10%) | 1.0 (7%) |
| OTHER BAR | 0.3 (8%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 2.7 | 58% | 6.7 pts | 27 pts |
| character | 2.7 | 0.7 | 75% | 1.5 pts | 4 pts |
| chariot | 5.7 | 7.7 | 35% | 49.2 pts | 279 pts |
| infantry | 4.7 | 2.7 | 57% | 6.1 pts | 28 pts |
| monster | 4.0 | 1.7 | 75% | 5.8 pts | 23 pts |
| war machine | 6.7 | 5.3 | 65% | 10.2 pts | 68 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 3.7 | 2.2 |
| Charges that made contact a game | 0.7 | 1.7 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.08 declared, 0.08 contact (24 units) | 0.38 declared, 0.17 contact (29 units) | 0.25 declared, 0.13 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (1 of 1) | - | 50% (2 of 4) |
| Character in a unit | 100% (5 of 5) | 60% (3 of 5) | - | 80% (8 of 10) |
| Character on its own | 100% (3 of 3) | 67% (2 of 3) | 0% (0 of 2) | 62% (5 of 8) |
| Chariot | 0% (0 of 2) | 0% (0 of 2) | - | 0% (0 of 4) |
| Infantry | 40% (2 of 5) | 33% (1 of 3) | - | 38% (3 of 8) |
| Monster | 0% (0 of 2) | 100% (1 of 1) | - | 33% (1 of 3) |
| Monstrous | 100% (2 of 2) | 50% (2 of 4) | - | 67% (4 of 6) |
| War Machines | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 60% (3 of 5); on the table 60% | 50% (15 of 30) | 48% | 67% (8 of 12) | 100% (4 of 4); 6.5 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | 0% (0 of 3); on the table 100% | 0% (0 of 12) | 69% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 79% | 43% (3 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 12) | 50% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 67% (4 of 6) | 57% | 50% (6 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p26, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | 50% (1) | 33% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: nw22-19bea9b-p26

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 0% (0 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 57% (12 of 21) | 67% (10 of 15) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 45% (5 of 11) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 25% (1 of 4) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 4.7 | 2.0 |
| Movement | Points that never moved of their own | 226.7 | 106.7 |
| Movement | Fights charged into per game | 0.7 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +0 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.7 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (2 of 5) | 17% (9 of 54) |
| Shooting | Points destroyed by shooting units | 213.7 | 0.0 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 15% (3 of 20) | - |
| Shooting | Points destroyed by war machines | 18.3 | 74.0 |
| Magic | Magic missiles cast | 1.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (1 of 5) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 5.7 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 17.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 0.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 243.7 | 85.0 |
| Combat | Points run down | 0.0 | 28.3 |
| Combat | Net points per charged fight, damage counted | +396 | +52 |
| Combat | Net per 100 charger points, damage counted | +202.6 | +23.2 |
| Combat | First round won (charged fights) | 100% | 60% |
| Combat | Net points per charged fight | +274 | +101 |
| Combat | Net points per supported fight / lone fight | - / +274 | - / +101 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 2 of 5 |
| Game | Points lost | 352.3 | 469.0 |
| Game | VP from objectives | 530.0 | 976.7 |
| Game | Lone holders (player turns) | 0.5 | 2.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -297 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 821
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: nw22-19bea9b-p26

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +13.3 | 0.0 | 131.0 |
| ARMY TABLE | 16.3 | -88.9 | 0.0 | 163.0 | 35.0 | +444.7 | 0.0 | 76.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 1.3 | +197.9 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | -58.4 | 131.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.3 | +48.9 | 218.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.3 | +141.2 | 0.0 | 0.0 | 0.7 | +15.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.7 | +75.6 | 0.0 | 85.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.3 | -150.6 | 131.0 | 0.0 | 0.3 | -0.7 | 27.0 | 0.0 |
| CHARGE LOSSES | 15.0 | -869.9 | 0.0 | 167.3 | 14.0 | -454.4 | 0.0 | 76.0 |
| CHARGE NOW FIRST | - | - | - | - | 1.0 | +0.0 | 55.3 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| CLEAR LANE AHEAD | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 14.0 | +0.0 | 0.0 | 113.3 | 8.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 2.7 | +980.0 | 0.0 | 0.0 | 0.7 | +230.0 | 0.0 | 0.0 |
| COVER ONCE | 5.7 | -249.4 | 0.0 | 27.0 | 5.7 | -111.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.3 | +16.8 | 0.0 | 0.0 | 7.3 | +57.0 | 0.0 | 18.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +20.7 | 27.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | +4.0 | 131.0 | 0.0 | 1.3 | -2.5 | 56.7 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 28.3 | 0.3 | +0.0 | 0.0 | 131.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.4 | 131.0 | 0.0 | 1.0 | +0.3 | 56.7 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| FALLS SHORT | 13.3 | +329.1 | 0.0 | 128.0 | 2.7 | +52.8 | 0.0 | 0.0 |
| FEATURE BUFFS | 10.0 | +492.3 | 0.0 | 108.0 | 0.7 | +92.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +21.8 | 131.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 89.7 | +6554.4 | 531.7 | 578.0 | 94.7 | +7684.2 | 351.3 | 391.0 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 56.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +63.5 | 0.0 | 85.0 | 0.7 | +246.2 | 0.0 | 131.0 |
| FOUR ROUNDS | 0.7 | +39.6 | 131.0 | 0.0 | 1.7 | +20.5 | 83.7 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -8.2 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| GOAL WALK | 9.7 | +1419.5 | 0.0 | 56.7 | 18.3 | +2379.9 | 0.0 | 0.0 |
| GROUND FLIERS | 0.3 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.7 | +85.1 | 213.7 | 0.0 | 1.7 | +65.6 | 45.7 | 0.0 |
| HALF WHEN STILL FLEEING | 0.7 | -1.8 | 131.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.7 | +0.0 | 56.7 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 167.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 76.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 76.0 |
| HIS MOVE AND SHOT | 6.3 | -51.7 | 0.0 | 56.7 | 6.3 | -249.5 | 0.0 | 110.0 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 76.0 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 56.7 | 5.7 | +0.0 | 0.0 | 76.0 |
| HIS RANDOM MOVE | - | - | - | - | 23.7 | +0.0 | 0.0 | 121.3 |
| HIS RANDOM MOVER COMES | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 60.7 | +1936.9 | 0.0 | 521.3 | 49.7 | +1662.2 | 0.0 | 86.3 |
| HIS SHOTS BY HIS RUN | 46.7 | +914.8 | 0.0 | 517.3 | 44.7 | +1308.8 | 0.0 | 151.0 |
| HOLD ODDS | 31.3 | +0.0 | 0.0 | 216.0 | 18.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 13.0 | +1419.6 | 0.0 | 54.0 | 13.0 | +1109.2 | 0.0 | 18.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -9.0 | 131.0 | 0.0 | 1.3 | -33.0 | 55.3 | 0.0 |
| IDLE COST | 14.0 | -97.9 | 0.0 | 119.7 | 2.7 | -44.7 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -0.1 | 28.3 | 0.0 |
| KEEP FALLS | 0.3 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +11.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 300.0 | 28.3 | 1.0 | +0.0 | 85.0 | 131.0 |
| LONE WIZARD KEPT IN | 0.7 | +58.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +1.9 | 131.0 | 0.0 | 0.7 | -0.1 | 28.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +2.6 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 4.3 | -36.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +162.7 | 0.0 | 0.0 | 0.7 | +55.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +21.9 | 0.0 | 0.0 | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +9.6 | 0.0 | 0.0 | 1.0 | +3.9 | 0.0 | 108.7 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +197.9 | 0.0 | 85.0 | 1.3 | +8.9 | 0.0 | 11.3 |
| MEETS IN TIME | 2.7 | +208.0 | 0.0 | 0.0 | 2.7 | +252.4 | 0.0 | 18.3 |
| MISSILES IN THE MOVE | 5.7 | +370.4 | 0.0 | 27.0 | 3.3 | +39.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.7 | +245.0 | 0.0 | 54.0 | 4.0 | +42.3 | 0.0 | 108.7 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.7 | -140.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.3 | +428.1 | 0.0 | 56.7 | 3.0 | +117.6 | 0.0 | 34.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEAR WALKS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.3 | +267.5 | 0.0 | 30.3 | 10.3 | +450.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +245.4 | 0.0 | 0.0 | 3.0 | +169.2 | 34.7 | 34.0 |
| NO CHAFF EDGES | 1.3 | +36.1 | 0.0 | 0.0 | 1.0 | +14.9 | 57.3 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -81.0 | 131.0 | 0.0 | 1.7 | -35.3 | 83.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +8.2 | 0.0 | 28.3 | - | - | - | - |
| OFF BEST | 2.3 | -298.9 | 131.0 | 0.0 | 4.0 | -151.2 | 0.0 | 108.7 |
| OGRE LOADER SECOND SHOT | 2.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -33.7 | 0.0 | 85.0 | 7.3 | -123.3 | 0.0 | 49.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +2.4 | 56.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.7 | +129.9 | 0.0 | 54.0 | 5.3 | -231.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -29.0 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | - | - | - | - | 0.3 | +3.1 | 27.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +41.1 | 55.3 | 0.0 |
| PATHS CROSS | 0.3 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 41.3 | +252.2 | 353.7 | 478.3 | 42.3 | +132.2 | 119.7 | 428.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.3 | -126.8 | 0.0 | 28.3 | 4.0 | -16.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -8.2 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.0 | +1204.8 | 217.3 | 0.0 | 16.0 | +2534.0 | 0.0 | 76.0 |
| RANDOM MOVE BY FIGURES | 3.3 | +81.6 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.0 | +11.8 | 0.0 | 56.7 | - | - | - | - |
| REDIRECT COUNTER | 3.7 | +311.2 | 0.0 | 56.7 | 3.0 | +139.1 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 6.3 | +27.8 | 0.0 | 141.7 | 2.0 | +0.0 | 0.0 | 41.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -14.4 | 0.0 | 28.3 | 2.7 | -22.7 | 0.0 | 34.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +12.9 | 0.0 | 0.0 |
| RISK BY ARC | 0.3 | -3.2 | 131.0 | 0.0 | 1.3 | -32.4 | 83.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -12.1 | 27.0 | 0.0 |
| RUN DOWN | 0.3 | -7.8 | 0.0 | 0.0 | 1.7 | -18.5 | 83.7 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.0 | +6.5 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -22.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +6.5 | 0.0 | 0.0 | 1.0 | +8.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +110.3 | 131.0 | 0.0 | 0.3 | +4.4 | 28.3 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 0.7 | -0.7 | 0.0 | 108.7 |
| SET CREDITED ONCE | 0.7 | -96.3 | 0.0 | 0.0 | 2.0 | -288.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +393.2 | 0.0 | 0.0 | 3.3 | +368.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +2.6 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 108.7 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +831.1 | 0.0 | 0.0 | 2.3 | +124.7 | 0.0 | 217.3 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 47.0 | +325.5 | 0.0 | 463.3 | 37.7 | -256.7 | 0.0 | 173.7 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 9.3 | +193.4 | 0.0 | 0.0 | 19.3 | +404.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +8.1 | 0.0 | 0.0 | 0.3 | +246.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 170.0 | 8.0 | +0.0 | 0.0 | 11.3 |
| STANDS FOR A REASON | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 29.0 | +0.0 | 400.7 | 128.0 | 34.7 | +0.0 | 267.7 | 262.7 |
| STAY WORTH | 17.3 | -88.7 | 183.3 | 0.0 | 23.3 | +151.5 | 176.3 | 38.0 |
| STRIKE BY THE ODDS | 1.3 | +46.6 | 445.0 | 0.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | 0.7 | -23.9 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 5.3 | +321.1 | 0.0 | 89.0 | 4.0 | +139.2 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 5.3 | +321.1 | 0.0 | 89.0 | 4.0 | +139.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +11.8 | 0.0 | 0.0 | 1.7 | +23.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 1.0 | +2.6 | 55.3 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 28.3 | 4.3 | +0.0 | 0.0 | 108.7 |
| THE ROW KEEPS ITS WAY | 5.3 | +0.0 | 0.0 | 85.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.7 | +0.0 | 0.0 | 85.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.3 | +0.0 | 0.0 | 232.3 | 43.7 | +0.0 | 0.0 | 180.7 |
| TIME ON OUR SIDE | 8.3 | +130.7 | 0.0 | 30.3 | 49.7 | +505.5 | 0.0 | 79.3 |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 28.3 | 1.0 | +0.0 | 0.0 | 11.3 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.7 | -147.4 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +118.8 | 131.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 198.3 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -17.1 | 262.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +6.4 | 131.0 | 0.0 | 1.0 | +4.0 | 56.7 | 0.0 |
| WHO HITS BACK | 0.3 | +16.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +0.1 | 131.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -635.3 | 0.0 | 54.0 | 2.0 | -62.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +0.1 | 28.3 | 0.0 |
| WHOLE FIGHT REACTION | 2.3 | +99.3 | 11.3 | 83.7 | 0.3 | +2.5 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.7 | +198.3 | 0.0 | 0.0 | 1.0 | +114.8 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p26

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 154 | 154 | 97 | 32.33 | +758 | +7.8 |
| HIS SHOTS BY HIS RUN | 274 | 266 | 85 | 28.33 | +1019 | +12.0 |
| HIS SHOT LIST | 331 | 327 | 80 | 26.67 | +815 | +10.2 |
| HOLDER ASSIGNMENT | 78 | 78 | 74 | 24.67 | +4996 | +67.5 |
| SHOT RISK POINTS | 254 | 246 | 60 | 20.00 | +1187 | +19.8 |
| GOAL WALK | 84 | 84 | 36 | 12.00 | +3367 | +93.5 |
| DEPLOY BY FIGURES | 50 | 50 | 32 | 10.67 | +425 | +13.3 |
| REDIRECT FOR A FRIEND IN REACH | 25 | 25 | 25 | 8.33 | +11 | +0.4 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| FIVE ACTION | 553 | 544 | 24 | 8.00 | +797 | +33.2 |
| QUARTER ODDS | 93 | 92 | 22 | 7.33 | +2060 | +93.6 |
| TIME ON OUR SIDE | 174 | 146 | 20 | 6.67 | +66 | +3.3 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -1350 | -71.1 |
| MOVE TO CHARGE COMPUTED | 28 | 25 | 14 | 4.67 | +246 | +17.5 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 12 | 4.00 | -431 | -35.9 |
| LEGAL CHARGES ONLY | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MEETS IN TIME | 16 | 16 | 10 | 3.33 | +684 | +68.4 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FEATURE BUFFS | 32 | 30 | 8 | 2.67 | +205 | +25.6 |
| STAY WORTH | 122 | 107 | 8 | 2.67 | +96 | +12.0 |
| MAX FOR POSITIONING | 20 | 16 | 7 | 2.33 | +13 | +1.8 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +7 | +1.0 |
| SET UP BY THE SET | 12 | 12 | 7 | 2.33 | +1339 | +191.2 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 7 | 2.33 | +1502 | +214.6 |
| SHOTS IN THE MOVE | 86 | 67 | 7 | 2.33 | +176 | +25.1 |
| NO CHAFF EDGES | 7 | 7 | 6 | 2.00 | +144 | +24.0 |
| SUPPORT ADDS | 28 | 25 | 6 | 2.00 | +31 | +5.2 |
| SUPPORT WORKED OUT | 28 | 25 | 6 | 2.00 | +31 | +5.2 |
| CASTING BLOCK | 6 | 6 | 5 | 1.67 | +76 | +15.3 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +929 | +185.9 |
| HIS MOVE AND SHOT | 38 | 38 | 5 | 1.67 | +96 | +19.2 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 5 | 1.67 | +245 | +48.9 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 13 | 13 | 4 | 1.33 | +220 | +54.9 |
| SCOUT BY DROPS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 4 | 3 | 1.00 | +11 | +3.6 |
| FOUR ROUNDS | 7 | 6 | 3 | 1.00 | +41 | +13.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +505 | +168.2 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +654 | +218.1 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 3 | 1.00 | +11 | +3.6 |
| REDIRECT COUNTER | 20 | 19 | 3 | 1.00 | +94 | +31.2 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 4 | 3 | 3 | 1.00 | +48 | +16.1 |
| SURE REACH TOGETHER | 8 | 8 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 17 | 17 | 3 | 1.00 | +107 | +35.6 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 16 | 16 | 2 | 0.67 | +43 | +21.7 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 34 | 19 | 2 | 0.67 | +18 | +9.2 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 48 | 27 | 2 | 0.67 | +21 | +10.7 |
| IDLE COST | 50 | 34 | 2 | 0.67 | +37 | +18.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +175 | +87.5 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +42 | +21.1 |
| MISSILES IN THE MOVE | 27 | 22 | 2 | 0.67 | +201 | +100.5 |
| NEARER NOT NEEDED | 47 | 42 | 2 | 0.67 | +59 | +29.3 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +85 | +42.3 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +39 | +19.4 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +45 | +22.7 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +344 | +172.1 |
| SHOTS AFTER THE MOVES | 15 | 15 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 24 | 2 | 2 | 0.67 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.67 | -442 | -221.1 |
| WAR ENGINE JOBS | 16 | 16 | 2 | 0.67 | -517 | -258.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +40 | +39.8 |
| BACKS UP THE FIGHT | 4 | 2 | 1 | 0.33 | +79 | +79.3 |
| CHARGE LOSSES | 87 | 87 | 1 | 0.33 | +23 | +22.6 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +16 | +16.4 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +2 | +1.9 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +11 | +11.2 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +34 | +33.7 |
| MANOEUVRE | 17 | 17 | 1 | 0.33 | +10 | +9.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -3 | -3.3 |
| ONE FIGHT FORMULA | 34 | 20 | 1 | 0.33 | +1 | +1.3 |
| ONE OBJECTIVE FORMULA | 39 | 24 | 1 | 0.33 | +24 | +24.3 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -87 | -87.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +8 | +7.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +166 | +165.9 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -2 | -2.1 |
| RISK BY ARC | 5 | 4 | 1 | 0.33 | +7 | +7.0 |
| SET CREDITED ONCE | 8 | 8 | 1 | 0.33 | +3 | +2.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| WHO FIGHTS | 4 | 3 | 1 | 0.33 | +7 | +7.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +42 | +42.3 |
| WHOLE FIGHT REACTION | 8 | 8 | 1 | 0.33 | +7 | +6.9 |
| BLOWS WHERE AIMED | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 2 | 1 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 67 | 66 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 5 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 3 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 37 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 24 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 29 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 71 | 69 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 16 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 150 | 146 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 35 | 23 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEAR WALKS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 251 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 16 | 16 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 2 | not checked | - | - | - | - |
| SET UP TOGETHER | 3 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 37 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 49 | 48 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 191 | 187 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1 | not checked | - | - | - | - |
| THE FIGHT MOVES | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 21 | not checked | - | - | - | - |
| THE TABLE BINDS | 252 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 11 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | not checked | - | - | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT DANGER | 12 | 12 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p26

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 2.33 | 2.67 | 56.5 |
| JOB FIRST | gate | 2.00 | 3.00 | 34.0 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 0.67 | 35.9 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.00 | 55.4 |
| RULE SWITCHED OFF | gate | - | 0.67 | 93.8 |
| WALKS ON ITS ROUTE | rule | - | 0.67 | 221.1 |
| WAR ENGINE JOBS | rule | 0.33 | 0.33 | 258.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 54.7 |
| MARCH OF THE TABLE | rule | 0.33 | - | 3.3 |
| NO REASON | gate | 0.33 | - | 598.0 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 87.0 |
| REFUSING RETIRES | rule | 0.33 | - | 2.1 |

### Plans: nw22-19bea9b-p26

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 110 | 97 | 88% |
| Mine | move | 34.3 | 92% | 2492 | 0 | 0% |
| Mine | shoot | 6.0 | 56% | 415 | 155 | 37% |
| Mine | support | 0.7 | 50% | 8 | 0 | 0% |
| Opponent | charge | 1.3 | 100% | 116 | 85 | 73% |
| Opponent | move | 37.0 | 96% | 2855 | 0 | 0% |
| Opponent | shoot | 4.0 | 33% | 223 | 47 | 21% |

### Battle groups: nw22-19bea9b-p26

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 27% | 33% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 11% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p26

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 0 (11) | 0 | 0 | 21 | 45% | 2.5 | 0 (1) | 1 (6) | 0 (3) | 1 (10) | - |
| Mine | Clean-up | 3 | 139 (3) | 0 | 139 | 38 | 100% | - | 204 (2) | - | 33 (1) | 139 (3) | - |
| Mine | Fast Hammer | 9 | 0 (9) | 0 | 0 | 74 | 89% | 3.0 | 0 (6) | 0 (1) | 0 (2) | 0 (7) | 0 (2) |
| Mine | Hammer | 9 | 102 (9) | 69 | 33 | 13 | 22% | 2.4 | 143 (2) | 117 (5) | 0 (2) | 102 (9) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 4 | 9 (4) | 9 | 0 | 0 | 0% | 1.2 | 9 (4) | - | - | - | 9 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 3.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Chaff | 8 | 185 (8) | 0 | 185 | 45 | 38% | 3.0 | 16 (3) | 473 (4) | 0 (1) | 206 (7) | 0 (1) |
| Opponent | Character | 7 | 40 (7) | 40 | 0 | 16 | 14% | 1.7 | 15 (2) | 34 (3) | 63 (2) | 49 (5) | 22 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 1.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 115 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 30 (10) | 19 | 10 | 6 | 40% | 1.7 | 31 (5) | 20 (3) | 40 (2) | 44 (7) | 8 (3) |
| Opponent | Shooter | 4 | 103 (4) | 0 | 103 | 22 | 0% | 1.8 | 70 (2) | 273 (1) | 26 (1) | 103 (4) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 126 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: nw22-19bea9b-p26

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Chaos Dwarfs | 1 | 696 | 549 | 1.0 | 1.0 | 549 | 0 | +549 | 1 of 1 | 1 of 1 | - | +549 |
| **Mine** | all armies | 3 | 232 | 183 | 0.7 | 1.0 | 274 | 0 | +274 | 1 of 2 | 2 of 2 | - | +274 |
| Opponent | Ogre Kingdoms | 1 | 274 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 1 of 1 | 0 of 1 | - | -34 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 0 | 537 | 3.0 | 1.0 | 179 | 0 | +179 | 0 of 3 | 2 of 3 | - | +179 |
| **Opponent** | all armies | 3 | 91 | 179 | 1.7 | 1.0 | 107 | 7 | +101 | 2 of 5 | 3 of 5 | - | +101 |

### Effective charges: nw22-19bea9b-p26

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 1 (net +452) | 0 | 0 | 2 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p26

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 81 | 77 | +0 | 38 | 12 | +27 | +33.2 |
| Mine | No odds | 1 | 310 | 343 | +549 | 942 | 177 | +765 | +246.9 |
| Mine | All fights | 2 | 196 | 210 | +274 | 490 | 94 | +396 | +202.6 |
| Opponent | 76-89% | 1 | 499 | 81 | +452 | 452 | 55 | +397 | +79.5 |
| Opponent | No odds | 4 | 157 | 209 | +13 | 38 | 72 | -34 | -21.5 |
| Opponent | All fights | 5 | 225 | 184 | +101 | 121 | 68 | +52 | +23.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p26 | move | 21 | 4 (19%) | 1 (5%) | 0 (0%) | 17 (81%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

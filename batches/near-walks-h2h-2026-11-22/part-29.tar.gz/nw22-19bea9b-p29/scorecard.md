# Doctrine scorecard: nw22-19bea9b-p29

### Scorecard: nw22-19bea9b-p29

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 609 |
| L0717 | 3 | 1 | Opponent | no | 0 | 2 | 0 | 3 | 3 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 15 | 2 | 2 | 1 | 0 | 0 | 0 | 125 |
| L0733 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 2 | 0 | 0 | 0 | 236 |
| L0823 | 1 | 1 | Mine | no | 13 | 5 | 1 | 1 | 0 | 0 | 0 | 551 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 2 | 0 | 0 | 66 |
| **Average** | | | Mine | 0% | 9.7 | 3.0 | 1.3 | 0.7 | 0.0 | 0.0 | 0.0 | 428.3 |
| **Average** | | | Opponent | 0% | 0.0 | 2.3 | 2.0 | 2.7 | 1.7 | 0.0 | 0.0 | 100.7 |

### KPIs: nw22-19bea9b-p29

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 71% (12 of 17) | 0% (0 of 15) | 38% (12 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (7 of 7); on the table 100% | 100% (4 of 4); on the table 100% | 100% (11 of 11); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | 80% (4 of 5); on the table 80% | 67% (4 of 6); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 89% (8 of 9); on the table 100% | 80% (8 of 10); on the table 80% | 84% (16 of 19); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 75% (9 of 12) | 17% (2 of 12) | 46% (11 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 75% (9 of 12) | 25% (2 of 8) | 55% (11 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 57% (3398 of 5998) | 49% (2949 of 6000) | 53% (6347 of 11998) |
|   infantry points that never fought | lower | 16% (113 of 715) | 62% (886 of 1418) | 47% (999 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (16 of 30) | 55% (12 of 22) | 54% (28 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.3 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (2373 of 5389) | 45% (2248 of 5023) | 44% (4621 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (33%) | 2.0 (60%) | 2.3 (54%) |
| CHARGED: its unit charged | 0.7 (67%) | 0.0 (0%) | 0.7 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.3 (40%) | 1.3 (31%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 1.7 | 3.7 | 0.3 | 0.0 |
| not cast | 5.0 | 0.3 | 4.3 | 1.7 | 12.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 2.3 (54%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (27%) | 0.0 (0%) | 1.3 (31%) | 1.3 (80%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.7 (97%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 78% (66 of 85) | 58% (50 of 86) | 68% (116 of 171) |
|   cavalry | 82% (9 of 11) | 50% (3 of 6) | 71% (12 of 17) |
|   character | - | 47% (7 of 15) | 47% (7 of 15) |
|   chariot | 80% (4 of 5) | - | 80% (4 of 5) |
|   infantry | 75% (15 of 20) | 69% (38 of 55) | 71% (53 of 75) |
|   monster | - | 20% (2 of 10) | 20% (2 of 10) |
|   war machine | 78% (38 of 49) | - | 78% (38 of 49) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (26%) | 1.7 (14%) | 3.3 (18%) |
| CHARGED: it charged | 0.3 (5%) | 3.3 (28%) | 3.7 (20%) |
| FLEEING: it fled or was fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (6%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.3 (21%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET IN RANGE | 0.0 (0%) | 5.7 (47%) | 5.7 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (37%) | 0.3 (3%) | 2.7 (15%) |
| OTHER BAR | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.0 | 1.3 | 81% | 3.9 pts | 27 pts |
| character | 2.3 | 1.0 | 57% | 23.3 pts | 54 pts |
| chariot | 1.3 | 0.3 | 75% | 8.1 pts | 11 pts |
| infantry | 25.3 | 6.7 | 76% | 5.9 pts | 149 pts |
| monster | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 12.7 | 12.0 | 58% | 29.7 pts | 376 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 6.3 | 4.5 |
| Charges that made contact a game | 1.3 | 3.3 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.00 contact (2 units) | - | 1.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.18 contact (22 units) | 0.63 declared, 0.33 contact (30 units) | 0.48 declared, 0.27 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (5 of 9) | 0% (0 of 3) | - | 42% (5 of 12) |
| Character in a unit | 80% (4 of 5) | - | 0% (0 of 1) | 67% (4 of 6) |
| Character on its own | 75% (3 of 4) | 100% (1 of 1) | 17% (1 of 6) | 45% (5 of 11) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | 0% (0 of 1) | 17% (1 of 6) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 70% (7 of 10) | - | - | 70% (7 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 89% (8 of 9); on the table 100% | 75% (9 of 12) | 57% | 53% (16 of 30) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 69% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 43% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (2 of 4); on the table 50% | 0% (0 of 6) | 35% | 70% (7 of 10) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p29, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 17% (1) | 0% (0) | 14% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 1.33 | 0.00 | 1.33 |

### Quality by phase: nw22-19bea9b-p29

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 25% (2 of 8) | 31% (5 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (16 of 52) | 93% (13 of 14) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | - |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 75% (3 of 4) |
| Strategy | Lone characters that fought | 40% (4 of 10) | 67% (4 of 6) |
| Movement | Charges halted short of contact | 0.3 | 0.7 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 428.3 | 100.7 |
| Movement | Fights charged into per game | 1.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +236 | 2 of 5, net -90 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +72 | 2 of 5, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 17.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (13 of 29) | 52% (27 of 52) |
| Shooting | Points destroyed by shooting units | 132.3 | 40.7 |
| Shooting | War machine shots | 12.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (21 of 38) | - |
| Shooting | Points destroyed by war machines | 64.7 | 0.0 |
| Magic | Magic missiles cast | 2.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 12% (1 of 8) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 88.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.7 / 0.0 / 0.0 | 1.3 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 167.0 | 106.3 |
| Combat | Points run down | 24.0 | 25.7 |
| Combat | Net points per charged fight, damage counted | +76 | +86 |
| Combat | Net per 100 charger points, damage counted | +40.2 | +34.2 |
| Combat | First round won (charged fights) | 100% | 89% |
| Combat | Net points per charged fight | +66 | +91 |
| Combat | Net points per supported fight / lone fight | -110 / +154 | -180 / +125 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 7 of 9 |
| Game | Points lost | 602.7 | 648.3 |
| Game | VP from objectives | 1020.0 | 790.0 |
| Game | Lone holders (player turns) | 9.7 | 0.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +196 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1251
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: nw22-19bea9b-p29

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +12.8 | 0.0 | 0.0 | 0.3 | +74.8 | 0.0 | 23.3 |
| ARMY TABLE | 16.3 | +158.3 | 0.0 | 0.0 | 24.0 | +634.4 | 0.0 | 384.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +13.5 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.7 | +4.3 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 58.3 | 41.7 | - | - | - | - |
| CANNON PLANNED TARGET | 11.7 | +368.9 | 753.0 | 256.7 | - | - | - | - |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -46.5 | 34.7 | 0.0 | - | - | - | - |
| CAST JOB | 1.3 | +64.2 | 58.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -1.7 | 0.0 | 22.0 |
| CHALLENGE BY POINTS | 1.0 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.3 | +1.6 | 0.0 | 0.0 | 2.3 | -106.3 | 0.0 | 23.3 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.7 | +74.9 | 0.0 | 23.3 |
| CHARGE LOSSES | 16.0 | -452.2 | 0.0 | 109.3 | 18.0 | -1010.1 | 0.0 | 586.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 24.0 | 36.7 | 2.0 | +0.0 | 149.7 | 0.0 |
| CLEAR LANE AHEAD | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 34.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 65.0 |
| COVER ONCE | 13.3 | -646.3 | 0.0 | 25.7 | 8.3 | -432.4 | 0.0 | 118.3 |
| DENIED BY THE FIGHT | 0.3 | -0.5 | 0.0 | 36.7 | - | - | - | - |
| DEPLOY BY FIGURES | 9.7 | -94.6 | 0.0 | 0.0 | 7.3 | +17.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +36.7 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +2.6 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | -15.6 | 137.3 | 36.7 | 4.3 | +98.8 | 279.7 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +8.4 | 137.3 | 0.0 | 3.3 | +6.9 | 191.3 | 0.0 |
| FALLBACK BY WORTH | 1.3 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 18.7 | +185.9 | 0.0 | 152.3 |
| FEATURE BUFFS | 0.7 | +12.3 | 0.0 | 0.0 | 1.0 | +20.4 | 0.0 | 22.0 |
| FIGHT TO THE END | 1.0 | -1.4 | 78.7 | 36.7 | 0.7 | +4.8 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 58.3 | 41.7 | - | - | - | - |
| FIVE ACTION | 99.3 | +6904.2 | 2009.7 | 993.3 | 74.3 | +5931.1 | 579.7 | 997.3 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 30.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +127.5 | 0.0 | 0.0 | 0.7 | +190.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +62.5 | 137.3 | 36.7 | 5.7 | +362.5 | 279.7 | 23.3 |
| FREED FROM HIS FIGHT | 5.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 3.0 | -55.8 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.7 | +22.6 | 0.0 | 36.7 | - | - | - | - |
| GIVES UP | 0.3 | -0.2 | 34.7 | 0.0 | 0.3 | -2.7 | 45.0 | 0.0 |
| GOAL WALK | 2.0 | +163.5 | 0.0 | 0.0 | 16.0 | +1360.6 | 0.0 | 292.7 |
| GUN FIGURES | 1.0 | +18.1 | 87.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.7 | +23.0 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.7 | -0.2 | 24.0 | 0.0 | 0.7 | +0.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 25.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 23.3 |
| HIS CHARGE BY HIS RUN | 10.0 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 140.7 |
| HIS CHARGE DENIED | 1.0 | +13.6 | 0.0 | 36.7 | - | - | - | - |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 24.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 109.3 | 3.3 | +0.0 | 0.0 | 65.0 |
| HIS MOVE AND SHOT | 5.3 | -80.4 | 0.0 | 0.0 | 1.3 | -26.8 | 0.0 | 58.7 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 69.3 |
| HIS OWN BEST MOVE | 10.0 | +0.0 | 0.0 | 109.3 | 5.0 | +0.0 | 0.0 | 65.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.0 | +1324.3 | 0.0 | 109.3 | 42.0 | +1999.7 | 0.0 | 603.7 |
| HIS SHOTS BY HIS RUN | 37.3 | +974.5 | 0.0 | 218.7 | 46.7 | +2062.1 | 0.0 | 772.0 |
| HIS TURN DENIED | 0.3 | +7.3 | 0.0 | 0.0 | 1.3 | +85.7 | 130.0 | 0.0 |
| HOLD ODDS | 20.3 | +0.0 | 0.0 | 109.3 | 13.3 | +0.0 | 0.0 | 90.0 |
| HOLDER ASSIGNMENT | 14.7 | +1320.2 | 0.0 | 54.7 | 11.0 | +1044.8 | 0.0 | 46.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -32.5 | 137.3 | 0.0 | 3.7 | -189.6 | 279.7 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 13.0 | -207.5 | 0.0 | 375.0 |
| JOINT CHARGE NOW | 1.0 | +7.6 | 0.0 | 36.7 | 1.0 | +242.6 | 0.0 | 23.3 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +109.9 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +20.1 | 0.0 | 0.0 | 0.7 | +27.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 201.7 | 63.0 | 4.0 | +0.0 | 125.3 | 392.7 |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | +7.9 | 0.0 | 0.0 | 1.0 | +7.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +2.9 | 102.7 | 36.7 | 1.3 | -0.1 | 63.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 3.0 | +78.2 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | -29.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +18.8 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -4.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +120.5 | 0.0 | 0.0 | 1.7 | +12.6 | 0.0 | 118.3 |
| MEETS IN TIME | 4.0 | +390.9 | 0.0 | 0.0 | 4.3 | +232.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +145.4 | 0.0 | 0.0 | 3.0 | +36.1 | 0.0 | 72.0 |
| MISSILES NEXT TURN | 2.7 | +71.3 | 0.0 | 0.0 | 3.7 | +38.6 | 0.0 | 72.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 30.0 | 3.0 | +0.0 | 0.0 | 36.0 |
| MOVE TO CHARGE COMPUTED | 7.3 | +491.6 | 0.0 | 0.0 | 6.0 | +455.4 | 0.0 | 116.7 |
| NEAR WALKS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.0 | +292.5 | 0.0 | 0.0 | 10.7 | +465.9 | 0.0 | 82.0 |
| NEXT CHARGE BY LIST | 4.0 | +307.7 | 0.0 | 0.0 | 5.0 | +414.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| NO CHAFF EDGES | 2.0 | +57.4 | 34.7 | 0.0 | 4.0 | +179.3 | 242.3 | 102.7 |
| NO DOUBLE ROUNDS | 2.7 | -44.3 | 137.3 | 36.7 | 5.0 | -173.5 | 279.7 | 23.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 1.3 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 28.3 | - | - | - | - |
| OFF BEST | 5.0 | -152.0 | 0.0 | 0.0 | 5.3 | -161.5 | 63.0 | 22.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.3 | -158.9 | 0.0 | 80.3 | 4.7 | -113.9 | 0.0 | 105.3 |
| ONE JOINT FIGURE | 0.7 | +8.3 | 0.0 | 36.7 | 1.0 | +53.3 | 0.0 | 23.3 |
| ONE OBJECTIVE FORMULA | 5.3 | +0.0 | 0.0 | 0.0 | 4.7 | -41.5 | 0.0 | 22.0 |
| ONE PROMISE A TARGET | 1.0 | -61.5 | 0.0 | 0.0 | 0.7 | -39.0 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +1.6 | 69.3 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 0.7 | +10.0 | 34.7 | 0.0 | 3.0 | +155.8 | 216.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.2 | 0.0 | 0.0 | 1.0 | +7.6 | 86.7 | 0.0 |
| PATHS CROSS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +33.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -13.3 | 0.0 | 0.0 |
| PLAN RESULT | 47.3 | +1718.0 | 1160.0 | 794.3 | 35.3 | +517.9 | 368.7 | 731.7 |
| PRIZE BY WORTH | - | - | - | - | 1.0 | +98.9 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.0 | -67.7 | 0.0 | 0.0 | 7.7 | -129.6 | 0.0 | 116.7 |
| PROMISE KNOWS THE FIGHT | 1.3 | -0.4 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 116.7 |
| PROMISE READS THE TABLE | 1.0 | -45.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 26.3 | +3125.3 | 326.7 | 250.7 | 16.0 | +2388.9 | 154.3 | 106.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +61.0 | 0.0 | 34.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 34.7 |
| REDIRECT WEIGHED | 0.7 | +0.5 | 0.0 | 0.0 | 1.3 | +24.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -7.6 | 0.0 | 0.0 | 1.3 | -20.6 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +55.6 | 137.3 | 0.0 | 3.7 | -342.4 | 279.7 | 23.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -40.3 | 148.0 | 0.0 |
| RUN DOWN | 2.3 | -12.0 | 137.3 | 36.7 | 3.3 | -24.6 | 196.3 | 0.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 22.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +13.5 | 0.0 | 22.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 22.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -2.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +27.6 | 63.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -54.8 | 0.0 | 0.0 | 0.7 | -12.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +38.9 | 0.0 | 0.0 | 2.0 | -39.8 | 0.0 | 89.0 |
| SET UP TOGETHER | 3.0 | +78.2 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 18.7 | +0.0 | 0.0 | 357.3 | 4.7 | +0.0 | 0.0 | 36.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +43.9 | 0.0 | 0.0 | 1.3 | +73.2 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.0 | -12.7 | 104.0 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| SHOT RISK POINTS | 23.0 | -190.5 | 0.0 | 109.3 | 29.7 | +628.4 | 0.0 | 883.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.7 | +1012.3 | 0.0 | 423.7 | 14.0 | +311.2 | 0.0 | 94.0 |
| SPELL WORTH | 0.3 | +2.7 | 28.3 | 28.3 | 2.7 | +49.5 | 36.0 | 156.0 |
| SPELLS IN THE FIGHT | 0.7 | +4.9 | 34.7 | 0.0 | 0.7 | -9.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 131.0 |
| STAND AND SHOOT | 1.3 | -12.4 | 102.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 57.3 | +0.0 | 1872.3 | 738.0 | 19.0 | +0.0 | 300.0 | 72.0 |
| STAY WORTH | 34.0 | -43.5 | 1351.0 | 401.0 | 12.0 | +82.7 | 300.0 | 36.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.3 | +48.4 | 25.7 | 47.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +62.1 | 0.0 | 0.0 | 2.0 | +63.1 | 0.0 | 12.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +62.1 | 0.0 | 0.0 | 2.0 | +63.1 | 0.0 | 12.7 |
| SURE REACH TOGETHER | 2.0 | +40.2 | 0.0 | 0.0 | 0.7 | +6.3 | 0.0 | 81.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 54.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.3 | +6.3 | 78.7 | 36.7 | 1.3 | +17.4 | 63.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.7 | +0.0 | 0.0 | 496.7 | 33.3 | +0.0 | 0.0 | 487.0 |
| TIED UP BY THE SUM | 1.0 | +97.0 | 58.7 | 0.0 | 2.3 | +271.3 | 279.7 | 0.0 |
| TIME ON OUR SIDE | 38.0 | +428.8 | 58.3 | 84.7 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -6.4 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +14.7 | 0.0 | 0.0 |
| WHO FIGHTS | 1.0 | +1.7 | 78.7 | 36.7 | 1.3 | +15.8 | 63.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | - | - | - | - | 1.3 | -116.7 | 0.0 | 116.7 |
| WHOLE FIGHT GAIN | 0.3 | +27.9 | 0.0 | 0.0 | 0.7 | +11.6 | 0.0 | 23.3 |
| WHOLE FIGHT REACTION | 3.7 | +269.2 | 0.0 | 151.3 | 1.7 | +100.3 | 0.0 | 137.3 |
| WOUNDS ON THE RANKS | 4.7 | +151.1 | 0.0 | 0.0 | 2.3 | +61.1 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p29

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 121 | 121 | 93 | 31.00 | +2380 | +25.6 |
| HOLDER ASSIGNMENT | 77 | 77 | 70 | 23.33 | +4037 | +57.7 |
| HIS SHOT LIST | 246 | 238 | 57 | 19.00 | +737 | +12.9 |
| HIS SHOTS BY HIS RUN | 252 | 243 | 47 | 15.67 | +1039 | +22.1 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -940 | -30.3 |
| DEPLOY BY FIGURES | 51 | 51 | 29 | 9.67 | +407 | +14.0 |
| FIVE ACTION | 521 | 505 | 28 | 9.33 | +1168 | +41.7 |
| MOVE TO CHARGE COMPUTED | 40 | 35 | 27 | 9.00 | +1266 | +46.9 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| SHOT RISK POINTS | 158 | 148 | 21 | 7.00 | +1009 | +48.1 |
| TIME ON OUR SIDE | 114 | 107 | 21 | 7.00 | +12 | +0.6 |
| NEXT CHARGE BY LIST | 27 | 26 | 19 | 6.33 | +1120 | +58.9 |
| QUARTER ODDS | 127 | 121 | 18 | 6.00 | +2210 | +122.8 |
| GOAL WALK | 54 | 52 | 15 | 5.00 | +1061 | +70.7 |
| COVER ONCE | 65 | 50 | 13 | 4.33 | +192 | +14.8 |
| MEETS IN TIME | 25 | 25 | 13 | 4.33 | +516 | +39.7 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 11 | 3.67 | +83 | +7.6 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 41 | 41 | 10 | 3.33 | -592 | -59.2 |
| NO CHAFF EDGES | 18 | 17 | 9 | 3.00 | +283 | +31.4 |
| CHARGE LOSSES | 102 | 96 | 8 | 2.67 | +668 | +83.4 |
| FOUR ROUNDS | 25 | 23 | 8 | 2.67 | +282 | +35.3 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 15 | 12 | 7 | 2.33 | +78 | +11.1 |
| TIED UP BY THE SUM | 10 | 8 | 7 | 2.33 | +401 | +57.3 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +751 | +125.1 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 2.00 | +709 | +118.2 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +955 | +191.0 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +518 | +103.5 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -302 | -60.3 |
| SET UP BY THE SET | 8 | 8 | 5 | 1.67 | +113 | +22.7 |
| SURE REACH TOGETHER | 8 | 8 | 5 | 1.67 | +45 | +8.9 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +75 | +18.7 |
| CHARGE NOW FIRST | 10 | 10 | 4 | 1.33 | -239 | -59.8 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +142 | +35.4 |
| NEARER NOT NEEDED | 53 | 52 | 4 | 1.33 | +119 | +29.8 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +101 | +25.2 |
| SCOUT BY DROPS | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +145 | +36.3 |
| WHOLE FIGHT REACTION | 16 | 16 | 4 | 1.33 | +99 | +24.8 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +87 | +29.1 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 18 | 11 | 3 | 1.00 | +86 | +28.7 |
| PRIZE BY WORTH | 3 | 3 | 3 | 1.00 | +297 | +98.9 |
| SHOTS IN THE MOVE | 110 | 78 | 3 | 1.00 | +65 | +21.8 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +263 | +131.4 |
| CANNON PLANNED TARGET | 35 | 35 | 2 | 0.67 | +50 | +24.8 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.67 | +225 | +112.3 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 20 | 18 | 2 | 0.67 | +31 | +15.4 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +68 | +34.0 |
| HIS TURN DENIED | 5 | 5 | 2 | 0.67 | +6 | +2.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| NO DOUBLE ROUNDS | 23 | 21 | 2 | 0.67 | +21 | +10.4 |
| ONE JOINT FIGURE | 5 | 5 | 2 | 0.67 | +19 | +9.5 |
| OPENS UP IN FULL | 11 | 10 | 2 | 0.67 | +70 | +35.1 |
| REDIRECT COUNTER | 7 | 3 | 2 | 0.67 | +18 | +9.1 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SHOTS AFTER THE MOVES | 27 | 27 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 138 | 127 | 2 | 0.67 | +34 | +17.1 |
| SUPPORT ADDS | 14 | 12 | 2 | 0.67 | +47 | +23.7 |
| SUPPORT WORKED OUT | 14 | 12 | 2 | 0.67 | +47 | +23.7 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +15 | +7.5 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +19 | +9.5 |
| BACKS UP THE FIGHT | 1 | 1 | 1 | 0.33 | +11 | +11.3 |
| BLOWS WHERE AIMED | 2 | 2 | 1 | 0.33 | +8 | +8.5 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -139 | -139.3 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -5 | -5.0 |
| CHARACTERS BY THEIR POINTS | 8 | 8 | 1 | 0.33 | +10 | +10.1 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -13 | -13.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +87 | +86.8 |
| EVASIVE BY THE ODDS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GUN MASK | 5 | 5 | 1 | 0.33 | +3 | +3.2 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +9 | +8.9 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| IDLE COST | 39 | 20 | 1 | 0.33 | +0 | +0.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +330 | +329.6 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +7 | +7.1 |
| LONG SHOT | 5 | 5 | 1 | 0.33 | +8 | +8.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +56 | +56.5 |
| MISSILES NEXT TURN | 19 | 14 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 33 | 15 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 30 | 25 | 1 | 0.33 | +22 | +22.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -40 | -39.9 |
| PROMISE KNOWS THE FIGHT | 7 | 5 | 1 | 0.33 | -1 | -1.3 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -95 | -94.8 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +83 | +82.9 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -135 | -134.9 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -19 | -19.2 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 15 | 13 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 48 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 13 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 4 | 4 | 0 | 0.00 | - | - |
| FALLS SHORT | 56 | 47 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 22 | 21 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 13 | 12 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 58 | 56 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 34 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 24 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 20 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 23 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 45 | 42 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 101 | 100 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 10 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 10 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 3 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 248 | trace | - | - | - | - |
| REAL GROUND | 4 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 8 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| RISK BY ARC | 17 | 15 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 10 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 70 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 34 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 229 | 225 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE FIGHT MOVES | 8 | 7 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 14 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 3 | not checked | - | - | - | - |
| THE TABLE BINDS | 243 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 7 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 21 | 21 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p29

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 4.00 | 31.6 |
| ARMY TABLE | rule | 2.00 | 1.33 | 63.6 |
| HOLDER ASSIGNMENT | rule | 2.00 | 1.33 | 16.2 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 2.00 | 59.2 |
| ONE PROMISE A TARGET | rule | 1.00 | 0.67 | 60.3 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 59.8 |
| RULE SWITCHED OFF | gate | - | 1.33 | 22.1 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 35.9 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 139.3 |
| CHAFF PASSED | rule | - | 0.33 | 5.0 |
| CHARGE LIST READ AGAIN | rule | - | 0.33 | 96.5 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 13.0 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 6.6 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 39.9 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.3 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 94.8 |
| SET UP BY THE SET | rule | - | 0.33 | 195.0 |
| SUPPORT NARROWED | rule | - | 0.33 | 134.9 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 19.2 |

### Plans: nw22-19bea9b-p29

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 177 | 224 | 127% |
| Mine | join | 3.0 | 89% | 40 | 0 | 0% |
| Mine | move | 27.0 | 99% | 1758 | 0 | 0% |
| Mine | shoot | 15.0 | 71% | 831 | 1494 | 180% |
| Opponent | charge | 4.0 | 58% | 686 | 317 | 46% |
| Opponent | move | 27.0 | 90% | 1694 | 0 | 0% |
| Opponent | shoot | 4.3 | 62% | 449 | 201 | 45% |

### Battle groups: nw22-19bea9b-p29

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p29

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 16 (12) | 16 | 0 | 15 | 58% | 2.6 | 25 (5) | 13 (5) | 21 (1) | 24 (6) | 0 (5) |
| Mine | Clean-up | 1 | 273 (1) | 0 | 273 | 0 | 100% | - | - | 273 (1) | - | 273 (1) | - |
| Mine | Fast Hammer | 8 | 61 (8) | 24 | 37 | 35 | 25% | 2.5 | 79 (2) | 57 (6) | - | 102 (4) | 24 (4) |
| Mine | Hammer | 2 | 83 (2) | 36 | 47 | 0 | 0% | 1.5 | - | 0 (1) | 143 (1) | 143 (1) | 0 (1) |
| Mine | Shooter | 5 | 114 (5) | 0 | 114 | 67 | 0% | 1.2 | 114 (5) | - | - | 114 (5) | - |
| Mine | War machine | 10 | 41 (10) | 41 | 0 | 51 | 0% | 1.0 | 41 (10) | - | - | 242 (1) | 17 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 100 | 75% | 1.0 | 0 (2) | 0 (2) | - | 0 (4) | - |
| Opponent | Character | 9 | 31 (9) | 31 | 0 | 14 | 11% | 2.5 | - | 32 (6) | 41 (2) | 36 (2) | 33 (6) |
| Opponent | Clean-up | 3 | 17 (3) | 17 | 0 | 56 | 67% | 2.0 | 30 (2) | 0 (1) | - | 17 (3) | - |
| Opponent | Fast Hammer | 5 | 5 (5) | 5 | 0 | 76 | 40% | 2.0 | 22 (1) | 0 (1) | 0 (3) | 0 (3) | 11 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (3) | - | - | 0 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 61 | 33% | 4.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Holder | 3 | 47 (3) | 0 | 47 | 0 | 0% | 2.3 | 0 (1) | 68 (2) | - | 75 (2) | 0 (1) |
| Opponent | Shooter | 7 | 115 (7) | 8 | 108 | 31 | 14% | 1.5 | 72 (2) | 158 (4) | 38 (1) | 68 (3) | 168 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |

### Charged fights: nw22-19bea9b-p29

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 285 | 103 | 1.0 | 1.3 | 103 | 37 | +66 | 1 of 3 | 3 of 3 | -110 | +154 |
| Opponent | Lizardmen | 1 | 77 | 266 | 2.0 | 1.0 | 133 | 0 | +133 | 1 of 2 | 2 of 2 | - | +133 |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 350 | 3.0 | 1.3 | 117 | 88 | +28 | 3 of 3 | 2 of 3 | -180 | +132 |
| Opponent | Wood Elf Realms | 1 | 0 | 471 | 4.0 | 1.0 | 118 | 0 | +118 | 3 of 4 | 4 of 4 | - | +118 |
| **Opponent** | all armies | 3 | 41 | 362 | 3.0 | 1.1 | 121 | 29 | +91 | 7 of 9 | 8 of 9 | -180 | +125 |

### Effective charges: nw22-19bea9b-p29

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 0 | 0 | 1 (net +236) | 1 (net -110) | 0 | 1 (net +72) | 0 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 1 (net -180) | 0 | 0 | 1 (net +0) | 1 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 1 | 33% (1 of 3) |

### Charged fights, damage counted: nw22-19bea9b-p29

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 189 | 236 | +236 | 236 | 21 | +215 | +113.8 |
| Mine | 76-89% | 1 | 187 | 141 | -110 | 141 | 180 | -39 | -20.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 189 | 72 | +72 | 72 | 21 | +51 | +27.0 |
| Mine | All fights | 3 | 188 | 150 | +66 | 150 | 74 | +76 | +40.2 |
| Opponent | Effective (55-75%) | 2 | 244 | 376 | -90 | 168 | 143 | +25 | +10.2 |
| Opponent | 76-89% | 1 | 104 | 238 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 220 | 171 | +0 | 7 | 24 | -17 | -7.9 |
| Opponent | No odds | 4 | 307 | 192 | +250 | 250 | 61 | +190 | +61.7 |
| Opponent | All fights | 9 | 251 | 233 | +91 | 150 | 64 | +86 | +34.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p29 | move | 20 | 6 (30%) | 5 (25%) | 3 (15%) | 11 (55%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

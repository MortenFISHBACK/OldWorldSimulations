# Doctrine scorecard: nw22-19bea9b-p31

### Scorecard: nw22-19bea9b-p31

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 1 | 0 | 0 | 165 |
| L1114 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 3 | - | 2 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | - | 1 | 3 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 14 | 3 | 7 | 0 | 0 | 0 | 0 | 165 |
| L1224 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 5.7 | 4.0 | 3.3 | 0.0 | 0.3 | 0.0 | 0.0 | 220.0 |
| **Average** | | | Opponent | 0% | 3.0 | 2.0 | 1.7 | 1.7 | 0.7 | 0.0 | 0.0 | 56.7 |

### KPIs: nw22-19bea9b-p31

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 50% (8 of 16) | 0% (0 of 15) | 26% (8 of 31) |
| Winner chose to follow up after the loser gave ground |  | 38% (3 of 8); on the table 38% | 100% (2 of 2); on the table 100% | 50% (5 of 10); on the table 50% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 100% | 50% (1 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 100% | - | 50% (1 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 40% (4 of 10); on the table 50% | 75% (3 of 4); on the table 100% | 50% (7 of 14); on the table 64% |
| Magic missiles tried each own turn | 50%+ | 30% (20 of 66) | 44% (8 of 18) | 33% (28 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (20 of 56) | 47% (8 of 17) | 38% (28 of 73) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (6 of 12) | 50% (6 of 12) |
| Points that never fought | lower | 35% (2120 of 5998) | 57% (3400 of 5998) | 46% (5520 of 11996) |
|   infantry points that never fought | lower | 100% (730 of 730) | 80% (733 of 913) | 89% (1463 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (12 of 25) | 64% (18 of 28) | 57% (30 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 7.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (8 of 8); 4.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 67% (4 of 6); 2.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 38% (2138 of 5614) | 59% (3422 of 5828) | 49% (5560 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (24%) | 2.3 (70%) | 6.0 (32%) |
| MARCHED: its unit marched | 6.0 (39%) | 0.7 (20%) | 6.7 (36%) |
| CHARGED: its unit charged | 2.0 (13%) | 0.0 (0%) | 2.0 (11%) |
| IN COMBAT: engaged in combat | 3.0 (20%) | 0.3 (10%) | 3.3 (18%) |
| GONE: slain | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 7.0 | 3.3 | 9.3 | 2.0 | 2.7 |
| not cast | 0.3 | 5.0 | 0.7 | 18.7 | 6.0 | 33.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (93%) | 0.0 (0%) | 6.0 (32%) | 1.0 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.7 (36%) | 2.7 (44%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (11%) | 1.0 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (50%) | 3.3 (18%) | 0.7 (11%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.3 (6%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 33.0 (99%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 3.3 a game | 1.7 a game |
| stood (cast and not dispelled) | - | 70% (7 of 10) | 70% (7 of 10) |
| the unit moved after it | - | 43% (3 of 7) | 43% (3 of 7) |
| it charged on its next turn | - | 0% (0 of 7) | 0% (0 of 7) |
| the enemy charged it first | - | 14% (1 of 7) | 14% (1 of 7) |
| it fought by the end of its next turn | - | 0% (0 of 7) | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 7) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | - | 86% (6 of 7) | 86% (6 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 86% (43 of 50) | 28% (8 of 29) | 65% (51 of 79) |
|   cavalry | - | 17% (2 of 12) | 17% (2 of 12) |
|   character | - | 0% (0 of 11) | 0% (0 of 11) |
|   chariot | 73% (8 of 11) | - | 73% (8 of 11) |
|   infantry | 83% (10 of 12) | 100% (6 of 6) | 89% (16 of 18) |
|   war machine | 93% (25 of 27) | - | 93% (25 of 27) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (57%) | 1.3 (19%) | 2.7 (29%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (24%) | 1.7 (18%) |
| IN COMBAT: it fought this turn or the last | 0.3 (14%) | 0.3 (5%) | 0.7 (7%) |
| MOVED: a war machine that moved | 0.7 (29%) | 0.0 (0%) | 0.7 (7%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.3 (19%) | 1.3 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.7 (24%) | 1.7 (18%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (10%) | 0.7 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.7 | 1.0 | 62% | 13.6 pts | 36 pts |
| infantry | 10.3 | 1.7 | 87% | 5.2 pts | 54 pts |
| war machine | 9.0 | 6.7 | 59% | 26.9 pts | 242 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 4.0 | 3.7 |
| Charges that made contact a game | 1.7 | 3.7 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.57 contact (7 units) | 0.50 declared, 0.50 contact (2 units) | 0.89 declared, 0.56 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.10 contact (10 units) | 0.50 declared, 0.45 contact (22 units) | 0.44 declared, 0.34 contact (32 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (6 of 11) | 100% (2 of 2) | 0% (0 of 2) | 53% (8 of 15) |
| Character in a unit | 50% (1 of 2) | 100% (1 of 1) | 100% (1 of 1) | 75% (3 of 4) |
| Character on its own | 100% (5 of 5) | 40% (2 of 5) | 17% (1 of 6) | 50% (8 of 16) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (3 of 6) | 0% (0 of 2) | - | 38% (3 of 8) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 40% (4 of 10); on the table 50% | 30% (20 of 66) | 35% | 48% (12 of 25) | 100% (7 of 7); 7.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 22% | 44% (4 of 9) | 0.0 uses a game | 67% (4 of 6); 6.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (2 of 3); on the table 100% | 0% (0 of 6) | 62% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 83% (5 of 6) | 86% | 83% (10 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p31, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 75% (3) | 21% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.33 | 1.33 |

### Quality by phase: nw22-19bea9b-p31

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (5 of 10) | 90% (9 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (14 of 42) | 67% (2 of 3) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 71% (5 of 7) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 89% (8 of 9) | 38% (3 of 8) |
| Movement | Charges halted short of contact | 0.7 | 0.0 |
| Movement | Idle units | 0.0 | 1.7 |
| Movement | Points that never moved of their own | 220.0 | 56.7 |
| Movement | Fights charged into per game | 1.7 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 3 of 9, net -20 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 9 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 5, net +90 | 0 of 9 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +62 | 3 of 9, net +154 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.0 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (6 of 18) | 33% (3 of 9) |
| Shooting | Points destroyed by shooting units | 38.7 | 55.0 |
| Shooting | War machine shots | 8.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (10 of 26) | - |
| Shooting | Points destroyed by war machines | 56.7 | 0.0 |
| Magic | Magic missiles cast | 5.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 15) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 7.7 | 1.3 |
| Magic | Wounds caused by other spells | 2.3 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 168.3 | 127.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 2.3 / 0.7 / 0.7 | 2.0 / 0.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 40.0 | 208.7 |
| Combat | Points run down | 88.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +51 | +63 |
| Combat | Net per 100 charger points, damage counted | +20.6 | +19.4 |
| Combat | First round won (charged fights) | 60% | 40% |
| Combat | Net points per charged fight | +61 | +57 |
| Combat | Net points per supported fight / lone fight | - / +61 | +296 / +30 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 5 of 10 |
| Game | Points lost | 413.0 | 432.7 |
| Game | VP from objectives | 836.7 | 396.7 |
| Game | Lone holders (player turns) | 5.7 | 3.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +446 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 846
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p31

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.7 | +435.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 9.7 | +80.4 | 0.0 | 0.0 | 25.7 | +44.3 | 0.0 | 153.3 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 0.7 | +45.0 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 1.0 | +8.1 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -124.4 | 0.0 | 0.0 |
| BOMBING RUN | 0.7 | +32.5 | 38.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +287.6 | 152.0 | 275.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -9.0 | 20.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 4.7 | +132.8 | 313.3 | 155.3 | 0.7 | +2.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +2.1 | 0.0 | 0.0 | 0.7 | +21.7 | 0.0 | 41.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -9.4 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 1.0 | -7.4 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.7 | -1208.5 | 0.0 | 210.0 | 29.7 | -1387.0 | 0.0 | 820.7 |
| CHARGE NOW FIRST | 3.7 | +0.0 | 252.3 | 0.0 | 0.7 | +0.0 | 50.0 | 0.0 |
| CLEAR LANE AHEAD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 117.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 3.3 | +377.5 | 0.0 | 0.0 |
| COVER ONCE | 7.7 | -450.1 | 0.0 | 110.0 | 10.7 | -863.4 | 0.0 | 199.3 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -2.1 | 105.0 | 0.0 |
| DEPLOY BY FIGURES | 4.7 | -28.4 | 0.0 | 0.0 | 5.7 | +153.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -32.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +8.0 | 41.0 | 0.0 | 0.3 | +9.9 | 55.0 | 0.0 |
| EXACT ROUND | 2.3 | +19.3 | 133.7 | 0.0 | 2.7 | +5.7 | 160.0 | 20.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +0.0 | 80.0 | 0.0 | 2.3 | +1.5 | 0.0 | 20.0 |
| FALLS SHORT | - | - | - | - | 24.0 | +239.5 | 0.0 | 403.7 |
| FIGHT TO THE END | 0.7 | +11.3 | 40.0 | 0.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| FIVE ACTION | 83.0 | +6424.6 | 1250.7 | 915.3 | 75.0 | +4774.9 | 270.0 | 1036.0 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 50.0 | 8.3 | +0.0 | 0.0 | 349.0 |
| FOLLOW UP WEIGHED | 0.7 | +108.4 | 0.0 | 0.0 | 1.0 | +68.5 | 0.0 | 20.0 |
| FOUR ROUNDS | 3.3 | +204.1 | 222.7 | 0.0 | 3.7 | +298.3 | 160.0 | 20.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 197.7 |
| GIVES UP | 0.3 | -5.3 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 1.3 | +191.4 | 0.0 | 0.0 | 15.7 | +2455.1 | 0.0 | 194.7 |
| GUN MASK | 1.3 | +83.1 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | +1.7 | 40.0 | 0.0 | 1.3 | -5.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 41.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 197.7 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 210.0 | 18.7 | +0.0 | 0.0 | 707.3 |
| HIS CHARGE DENIED | - | - | - | - | 1.3 | +117.0 | 50.0 | 20.0 |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 224.0 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 100.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -27.2 | 0.0 | 100.0 | 8.0 | -111.6 | 0.0 | 140.7 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.3 | +0.0 | 0.0 | 100.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 15.7 | +256.1 | 0.0 | 110.0 | 62.0 | +2814.7 | 0.0 | 894.0 |
| HIS SHOTS BY HIS RUN | 22.3 | +296.9 | 0.0 | 210.0 | 58.7 | +2340.2 | 0.0 | 820.7 |
| HIS TURN DENIED | 0.3 | +1.2 | 0.0 | 0.0 | 0.3 | +12.8 | 55.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 10.7 | +1028.8 | 0.0 | 0.0 | 8.0 | +818.6 | 0.0 | 40.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -90.2 | 222.7 | 0.0 | 2.7 | -167.4 | 160.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +6.1 | 0.0 | 0.0 | 0.7 | +27.7 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 18.3 | -317.8 | 0.0 | 352.7 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +30.4 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +18.9 | 0.0 | 0.0 | 0.7 | +18.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 118.7 | 150.0 | 2.0 | +0.0 | 0.0 | 61.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +11.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -1.7 | 40.0 | 0.0 | 2.3 | +9.5 | 50.0 | 20.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 2.3 | +7.1 | 0.0 | 77.7 | 2.0 | +90.1 | 0.0 | 53.7 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +1.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 3.0 | +160.3 | 0.0 | 0.0 | 0.3 | +27.2 | 0.0 | 0.0 |
| MARCH CHECK | 3.0 | +115.6 | 0.0 | 0.0 | 1.0 | +40.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 2.3 | +115.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 3.7 | +105.3 | 0.0 | 0.0 | 1.3 | +81.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 7.0 | +146.9 | 0.0 | 77.7 | 4.3 | +147.6 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +347.8 | 0.0 | 0.0 | 2.3 | +358.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.7 | +260.4 | 0.0 | 77.7 | 4.7 | +31.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 16.0 | +215.0 | 0.0 | 77.7 | 6.7 | +26.3 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.7 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +436.6 | 0.0 | 0.0 | 4.3 | +358.7 | 0.0 | 0.0 |
| NEAR WALKS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.3 | +182.0 | 0.0 | 0.0 | 4.3 | +165.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 7.0 | +661.4 | 110.7 | 0.0 | 3.3 | +308.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -5.7 | 0.0 | 0.0 |
| NO CHAFF EDGES | 3.3 | +106.2 | 128.0 | 0.0 | 1.3 | +59.1 | 55.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -76.9 | 149.0 | 0.0 | 3.3 | -90.4 | 160.0 | 20.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.3 | +7.9 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -324.4 | 0.0 | 110.0 | 3.7 | -135.4 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 6.0 | +57.0 | 0.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.0 | -161.5 | 0.0 | 127.7 | 5.0 | -128.1 | 0.0 | 77.3 |
| ONE JOINT FIGURE | 0.3 | -12.1 | 0.0 | 0.0 | 0.7 | +21.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.7 | +5.9 | 0.0 | 0.0 | 3.0 | +20.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.0 | +34.6 | 0.0 | 0.0 | 0.7 | -20.0 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 1.3 | +34.9 | 128.0 | 0.0 | 1.3 | +59.1 | 55.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +3.8 | 89.0 | 0.0 | 2.0 | +25.4 | 110.0 | 0.0 |
| OWN CAST FIRST | 1.7 | -8.2 | 0.0 | 0.0 | 0.7 | -3.0 | 0.0 | 0.0 |
| PLAN RESULT | 37.3 | +840.2 | 374.7 | 640.3 | 38.7 | +273.2 | 155.0 | 620.3 |
| PRIZE BY WORTH | 0.3 | +75.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.3 | -238.0 | 0.0 | 0.0 | 6.7 | -84.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | -21.6 | 33.3 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 13.0 | +2067.6 | 368.3 | 265.3 | 13.7 | +1594.1 | 110.0 | 113.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +57.6 | 0.0 | 113.3 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.7 | +206.3 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.3 | -80.3 | 0.0 | 0.0 | 0.7 | -82.9 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.3 | +0.0 | 0.0 | 53.7 |
| RISK BY ARC | 3.0 | +165.1 | 222.7 | 0.0 | 2.7 | -212.7 | 160.0 | 20.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -59.3 | 110.0 | 0.0 |
| RUN DOWN | 1.0 | -2.8 | 129.0 | 0.0 | 3.0 | -64.5 | 105.0 | 20.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +2.8 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | +0.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -334.5 | 0.0 | 100.7 |
| SET UP BY THE SET | 1.7 | +27.6 | 0.0 | 0.0 | 3.0 | +195.6 | 0.0 | 100.7 |
| SET UP TOGETHER | 2.7 | +7.3 | 0.0 | 77.7 | 2.0 | +90.1 | 0.0 | 53.7 |
| SET-UP MISSED | - | - | - | - | 0.3 | +54.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.3 | +0.0 | 0.0 | 352.7 | 3.0 | +0.0 | 0.0 | 41.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +81.4 | 107.3 | 0.0 | 1.0 | +3.9 | 0.0 | 82.0 |
| SHOT OR CHARGE | 1.0 | -14.3 | 53.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 12.0 | -208.1 | 0.0 | 100.0 | 39.7 | +246.4 | 0.0 | 647.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +808.1 | 0.0 | 330.0 | 3.0 | +111.0 | 0.0 | 41.0 |
| SPELL WORTH | 1.7 | +4.7 | 0.0 | 0.0 | 2.0 | +38.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | -17.2 | 20.0 | 0.0 | 1.3 | -11.0 | 50.0 | 20.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 77.7 | 7.3 | +0.0 | 0.0 | 147.0 |
| STAND AND SHOOT | 0.3 | -0.3 | 41.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 82.0 |
| STANDS STILL | 44.3 | +0.0 | 1028.0 | 815.3 | 18.3 | +0.0 | 110.0 | 267.3 |
| STAY WORTH | 27.7 | -61.5 | 563.7 | 650.3 | 3.0 | +43.8 | 110.0 | 41.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +15.8 | 0.0 | 0.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +4.3 | 0.0 | 55.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +342.7 | 0.0 | 0.0 | 2.0 | +264.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +342.7 | 0.0 | 0.0 | 2.0 | +264.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 2.0 | +10.3 | 0.0 | 0.0 | 1.3 | +12.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.3 | +0.9 | 41.0 | 0.0 | 2.3 | +81.5 | 105.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -27.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 16.7 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.7 | +0.0 | 0.0 | 402.7 | 36.0 | +0.0 | 0.0 | 431.3 |
| TIED UP BY THE SUM | 2.0 | +215.1 | 222.7 | 0.0 | 0.7 | +81.6 | 55.0 | 0.0 |
| TIME ON OUR SIDE | 32.7 | +534.8 | 0.0 | 50.0 | - | - | - | - |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | +28.4 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | -33.8 | 40.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | -1.3 | 20.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.7 | -922.9 | 0.0 | 110.0 | 2.7 | -199.0 | 0.0 | 274.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +80.3 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 3.7 | +434.5 | 60.0 | 160.0 | 1.0 | +33.5 | 0.0 | 129.0 |
| WOUNDS ON THE RANKS | 1.7 | +53.2 | 0.0 | 0.0 | 2.7 | +99.6 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p31

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 106 | 106 | 76 | 25.33 | +1021 | +13.4 |
| FIVE ACTION | 474 | 454 | 51 | 17.00 | +3767 | +73.9 |
| HOLDER ASSIGNMENT | 56 | 56 | 51 | 17.00 | +3431 | +67.3 |
| HIS SHOTS BY HIS RUN | 243 | 226 | 44 | 14.67 | +1024 | +23.3 |
| HIS SHOT LIST | 233 | 223 | 42 | 14.00 | +970 | +23.1 |
| SHOT RISK POINTS | 155 | 147 | 33 | 11.00 | +853 | +25.8 |
| GOAL WALK | 51 | 51 | 28 | 9.33 | +3758 | +134.2 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -1379 | -51.1 |
| MOVE TO CHARGE COMPUTED | 32 | 30 | 22 | 7.33 | +735 | +33.4 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| QUARTER ODDS | 80 | 76 | 21 | 7.00 | +1732 | +82.5 |
| HARD STAY DROPPED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 31 | 31 | 19 | 6.33 | +811 | +42.7 |
| LEGAL CHARGES ONLY | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 18 | 18 | 18 | 6.00 | +171 | +9.5 |
| PROMISE BY ITS OWN SUM | 51 | 51 | 18 | 6.00 | -966 | -53.7 |
| CHARGE LOSSES | 136 | 129 | 17 | 5.67 | +633 | +37.2 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CAST JOB | 16 | 16 | 12 | 4.00 | +76 | +6.4 |
| DEPLOY BY FIGURES | 31 | 31 | 12 | 4.00 | +186 | +15.5 |
| FOUR ROUNDS | 21 | 20 | 12 | 4.00 | +467 | +38.9 |
| COVER ONCE | 55 | 34 | 10 | 3.33 | +164 | +16.4 |
| MARCH BY THE SUM | 10 | 10 | 10 | 3.33 | +562 | +56.2 |
| MARCH CHECK | 12 | 12 | 9 | 3.00 | +110 | +12.2 |
| MAX FOR POSITIONING | 34 | 29 | 9 | 3.00 | +55 | +6.1 |
| NO CHAFF EDGES | 14 | 13 | 9 | 3.00 | +237 | +26.3 |
| SET UP BY THE SET | 14 | 14 | 8 | 2.67 | +657 | +82.2 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 8 | 2.67 | +43 | +5.3 |
| MARCH OF THE TABLE | 7 | 7 | 7 | 2.33 | -345 | -49.3 |
| OWN CAST FIRST | 7 | 7 | 7 | 2.33 | -33 | -4.8 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +112 | +18.6 |
| MEETS IN TIME | 16 | 16 | 6 | 2.00 | +223 | +37.1 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 6 | 2.00 | +173 | +28.8 |
| STAY WORTH | 92 | 81 | 6 | 2.00 | +41 | +6.8 |
| AFTERMATH IN POINTS | 5 | 5 | 5 | 1.67 | +1307 | +261.4 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 13 | 13 | 5 | 1.67 | -597 | -119.4 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +531 | +106.2 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 55 | 34 | 5 | 1.67 | +59 | +11.8 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | +44 | +8.8 |
| RISK BY ARC | 17 | 16 | 5 | 1.67 | +103 | +20.6 |
| SUPPORT ADDS | 12 | 12 | 5 | 1.67 | +534 | +106.8 |
| SUPPORT WORKED OUT | 12 | 12 | 5 | 1.67 | +534 | +106.8 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 9 | 9 | 4 | 1.33 | -65 | -16.2 |
| SCOUT BY DROPS | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 21 | 21 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 54 | 38 | 4 | 1.33 | +116 | +28.9 |
| SUPPORT NARROWED | 4 | 4 | 4 | 1.33 | -982 | -245.6 |
| WHOLE FIGHT DANGER | 22 | 22 | 4 | 1.33 | +295 | +73.7 |
| WOUNDS ON THE RANKS | 13 | 13 | 4 | 1.33 | +72 | +18.1 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +72 | +23.8 |
| FALLS SHORT | 72 | 54 | 3 | 1.00 | +10 | +3.2 |
| MISSILES IN THE MOVE | 49 | 28 | 3 | 1.00 | +91 | +30.3 |
| ONE OBJECTIVE FORMULA | 20 | 19 | 3 | 1.00 | +22 | +7.2 |
| OPENS UP IN FULL | 8 | 7 | 3 | 1.00 | +23 | +7.7 |
| SURE REACH TOGETHER | 10 | 8 | 3 | 1.00 | +3 | +0.9 |
| TIED UP BY THE SUM | 8 | 7 | 3 | 1.00 | +23 | +7.7 |
| TIME ON OUR SIDE | 98 | 72 | 3 | 1.00 | +25 | +8.3 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| BACKS UP THE FIGHT | 2 | 2 | 2 | 0.67 | +41 | +20.7 |
| BOMBING RUN | 2 | 2 | 2 | 0.67 | +98 | +48.8 |
| CANNON PLANNED TARGET | 24 | 24 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 15 | 14 | 2 | 0.67 | +13 | +6.5 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS CHARGE DENIED | 4 | 4 | 2 | 0.67 | +148 | +74.0 |
| HUNT IN PAIRS | 4 | 3 | 2 | 0.67 | +2 | +1.1 |
| INFANTRY NOT BEHIND INFANTRY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +91 | +45.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MISSILES NEXT TURN | 68 | 39 | 2 | 0.67 | +21 | +10.6 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.67 | -12 | -6.2 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +48 | +23.8 |
| THE ROW IN ITS ORDER | 17 | 2 | 2 | 0.67 | +0 | +0.0 |
| BACKUP TARGETS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.33 | -27 | -27.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CLEAR LANE AHEAD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GUN MASK | 4 | 4 | 1 | 0.33 | +73 | +72.9 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +35 | +35.1 |
| HONEST WORTH | 18 | 17 | 1 | 0.33 | +35 | +35.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| LONG SHOT | 2 | 2 | 1 | 0.33 | +7 | +6.8 |
| MAIN BODY KEEPS ITS BAND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 3 | 3 | 1 | 0.33 | +6 | +5.7 |
| NEARER NOT NEEDED | 26 | 23 | 1 | 0.33 | +0 | +0.0 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +227 | +226.9 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +227 | +226.9 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +1 | +1.1 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +13 | +12.7 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE FIGHT MOVES | 11 | 11 | 1 | 0.33 | +57 | +56.7 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +85 | +85.1 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +55 | +55.3 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 13 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 32 | 32 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 8 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 84 | 82 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 41 | 41 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 19 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 38 | 34 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 29 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 34 | 34 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 80 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 13 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 15 | 15 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEAR WALKS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 16 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 36 | 15 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 8 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 228 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 14 | 2 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 52 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 6 | 5 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 34 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 188 | 176 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 221 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT REACTION | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p31

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.00 | 47.8 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 1.67 | 53.7 |
| ARMY TABLE | rule | 1.00 | 2.33 | 75.2 |
| OWN CAST FIRST | rule | 1.67 | 0.67 | 4.8 |
| MARCH OF THE TABLE | rule | 2.00 | - | 57.5 |
| CHARGE NOW FIRST | rule | 1.33 | 0.33 | 119.4 |
| SUPPORT NARROWED | rule | 0.67 | 0.67 | 245.6 |
| ONE PROMISE A TARGET | rule | 0.33 | 0.67 | 34.3 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 21.5 |
| REFUSING RETIRES | rule | - | 0.67 | 6.2 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 27.0 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 49.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 34.9 |
| NO REASON | gate | 0.33 | - | 218.1 |
| RULE SWITCHED OFF | gate | - | 0.33 | 13.3 |
| TURN GATE | gate | - | 0.33 | 0.7 |

### Plans: nw22-19bea9b-p31

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 44% | 379 | 161 | 42% |
| Mine | move | 22.3 | 100% | 1416 | 0 | 0% |
| Mine | shoot | 12.0 | 53% | 1001 | 679 | 68% |
| Opponent | charge | 2.7 | 50% | 219 | 205 | 94% |
| Opponent | join | 3.3 | 100% | 188 | 0 | 0% |
| Opponent | move | 31.7 | 92% | 2307 | 0 | 0% |
| Opponent | shoot | 1.0 | 67% | 121 | 68 | 56% |

### Battle groups: nw22-19bea9b-p31

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.7 | 100% | 100% | 0% | - | 0% | 0% | 50% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p31

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 26 (9) | 26 | 0 | 13 | 11% | 2.5 | 51 (3) | 21 (5) | - | 8 (4) | 40 (4) |
| Mine | Clean-up | 2 | 90 (2) | 0 | 90 | 0 | 0% | 2.5 | 0 (1) | 170 (1) | - | 90 (2) | - |
| Mine | Fast Hammer | 4 | 53 (4) | 0 | 53 | 15 | 0% | 2.0 | 50 (1) | 71 (2) | 0 (1) | 62 (3) | 0 (1) |
| Mine | Holder | 1 | 53 (1) | 0 | 53 | 0 | 0% | 2.0 | 53 (1) | - | - | 53 (1) | - |
| Mine | Shooter | 4 | 80 (4) | 52 | 28 | 0 | 0% | 3.0 | 89 (1) | 60 (2) | 120 (1) | 57 (2) | 103 (2) |
| Mine | War machine | 6 | 17 (6) | 17 | 0 | 67 | 0% | 1.2 | 0 (1) | 26 (4) | 0 (1) | 0 (1) | 21 (5) |
| Mine | Wizard | 3 | 38 (3) | 38 | 0 | 33 | 0% | 2.0 | 0 (2) | 72 (1) | - | 0 (2) | 72 (1) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.5 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Opponent | Character | 10 | 17 (10) | 17 | 0 | 6 | 70% | 1.3 | 8 (4) | 29 (5) | 0 (1) | 29 (6) | 0 (4) |
| Opponent | Fast Hammer | 9 | 40 (9) | 20 | 19 | 38 | 44% | 3.8 | 0 (1) | 51 (7) | 0 (1) | 59 (6) | 0 (3) |
| Opponent | Hammer | 3 | 36 (3) | 36 | 0 | 37 | 33% | 4.0 | 0 (1) | 49 (2) | - | 0 (1) | 49 (2) |
| Opponent | Holder | 5 | 46 (5) | 0 | 46 | 31 | 80% | 3.0 | 0 (1) | 101 (2) | 15 (1) | 9 (2) | 101 (2) |
| Opponent | Shooter | 1 | 93 (1) | 93 | 0 | 0 | 0% | 1.0 | - | 93 (1) | - | 93 (1) | - |
| Opponent | Wizard | 1 | 119 (1) | 119 | 0 | 0 | 0% | 3.0 | 119 (1) | - | - | - | 119 (1) |

### Charged fights: nw22-19bea9b-p31

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 264 | 101 | 1.7 | 1.0 | 61 | 0 | +61 | 1 of 5 | 3 of 5 | - | +61 |
| Opponent | High Elf Realms | 1 | 315 | 461 | 7.0 | 1.1 | 66 | 0 | +66 | 3 of 7 | 2 of 7 | +296 | +28 |
| Opponent | Vampire Counts | 1 | 0 | 165 | 2.0 | 1.0 | 82 | 30 | +52 | 1 of 2 | 2 of 2 | - | +52 |
| Opponent | Warriors of Chaos | 1 | 233 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 183 | 209 | 3.3 | 1.1 | 63 | 6 | +57 | 5 of 10 | 4 of 10 | +296 | +30 |

### Effective charges: nw22-19bea9b-p31

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 5 | 0 | 0 | 0 | 1 (net +0) | 2 (net +90) | 2 (net +62) | 0 | 0% (0 of 5) |
| Opponent | High Elf Realms | 7 | 2 (net +0) | 0 | 0 | 2 (net +0) | 0 | 3 (net +154) | 0 | 0% (0 of 7) |
| Opponent | Vampire Counts | 2 | 1 (net -60) | 0 | 0 | 1 (net +165) | 0 | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: nw22-19bea9b-p31

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 205 | 470 | +0 | 0 | 68 | -68 | -33.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 225 | 142 | +62 | 78 | 19 | +58 | +25.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 287 | 90 | +90 | 130 | 28 | +103 | +35.7 |
| Mine | All fights | 5 | 246 | 187 | +61 | 83 | 32 | +51 | +20.6 |
| Opponent | Long shot (under 50%) | 3 | 231 | 354 | -20 | 0 | 36 | -36 | -15.6 |
| Opponent | 76-89% | 3 | 154 | 155 | +55 | 62 | 35 | +27 | +17.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 656 | 229 | +154 | 180 | 0 | +180 | +27.4 |
| Opponent | No odds | 1 | 120 | 233 | +0 | 116 | 0 | +116 | +97.1 |
| Opponent | All fights | 10 | 324 | 245 | +57 | 84 | 21 | +63 | +19.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p31 | move | 23 | 5 (22%) | 5 (22%) | 1 (4%) | 17 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

# Doctrine scorecard: nw22-19bea9b-p35

### Scorecard: nw22-19bea9b-p35

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 3 | 6 | 0 | 2 | 0 | 0 | 0 | 410 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 3 | 1 | 2 | 2 | 0 | 0 | 757 |
| L2335 | 1 | 1 | Mine | no | 0 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 158 |
| **Average** | | | Mine | 67% | 1.5 | 4.3 | 2.7 | 0.7 | 0.7 | 0.0 | 0.0 | 136.7 |
| **Average** | | | Opponent | 0% | 0.5 | 2.3 | 2.3 | 2.0 | 0.7 | 0.0 | 0.0 | 305.0 |

### KPIs: nw22-19bea9b-p35

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 19% (3 of 16) | 0% (0 of 17) | 9% (3 of 33) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 67% | - | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 100% (3 of 3); on the table 100% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 50% (9 of 18) | 50% (12 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (3 of 5) | 64% (9 of 14) | 63% (12 of 19) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (7 of 11) | 33% (2 of 6) | 53% (9 of 17) |
| Points that never fought | lower | 33% (2007 of 5999) | 31% (1856 of 6000) | 32% (3863 of 11999) |
|   infantry points that never fought | lower | 80% (1238 of 1552) | 27% (284 of 1035) | 59% (1522 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 37% (7 of 19) | 77% (23 of 30) | 61% (30 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.7 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (2 of 3); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 30% (1353 of 4484) | 69% (3851 of 5546) | 52% (5204 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (67%) | 1.7 (56%) | 2.3 (58%) |
| IN COMBAT: engaged in combat | 0.3 (33%) | 0.0 (0%) | 0.3 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.3 (44%) | 1.3 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 10.7 | 0.3 | 0.7 | 4.0 | 1.3 | 1.0 |
| not cast | 3.3 | 1.7 | 1.3 | 4.0 | 0.7 | 15.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 2.3 (58%) | 0.7 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.3 (80%) | 1.3 (100%) | 1.3 (33%) | 0.0 (0%) | 2.3 (16%) |
| STUPIDITY: Stupidity | 0.7 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (80%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.3 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 0% (0 of 2) | 0% (0 of 2) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (73 of 118) | 77% (20 of 26) | 65% (93 of 144) |
|   cavalry | 83% (20 of 24) | 92% (11 of 12) | 86% (31 of 36) |
|   character | 0% (0 of 22) | 50% (3 of 6) | 11% (3 of 28) |
|   chariot | 100% (10 of 10) | - | 100% (10 of 10) |
|   infantry | 69% (43 of 62) | 75% (6 of 8) | 70% (49 of 70) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (18%) | 1.0 (50%) | 3.7 (22%) |
| CHARGED: it charged | 2.3 (16%) | 0.7 (33%) | 3.0 (18%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (17%) | 0.3 (2%) |
| NO TARGET IN RANGE | 6.7 (44%) | 0.0 (0%) | 6.7 (39%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (7%) | 0.0 (0%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (16%) | 0.0 (0%) | 2.3 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 15.3 | 1.3 | 91% | 2.9 pts | 44 pts |
| character | 1.0 | 0.3 | 67% | 7.8 pts | 8 pts |
| chariot | 3.3 | 0.3 | 90% | 3.9 pts | 13 pts |
| infantry | 18.3 | 4.7 | 82% | 6.1 pts | 111 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.3 | 3.7 | 5.0 |
| Charges that made contact a game | 4.7 | 2.7 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.44 contact (32 units) | 0.36 declared, 0.24 contact (25 units) | 0.49 declared, 0.35 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 71% (5 of 7) | 100% (1 of 1) | 100% (1 of 1) | 78% (7 of 9) |
| Character in a unit | 67% (2 of 3) | - | 0% (0 of 1) | 50% (2 of 4) |
| Character on its own | 80% (4 of 5) | 100% (1 of 1) | 29% (2 of 7) | 54% (7 of 13) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 64% (7 of 11) | 0% (0 of 1) | - | 58% (7 of 12) |
| Monster | 33% (2 of 6) | 100% (1 of 1) | - | 43% (3 of 7) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | - | 50% (3 of 6) | 32% | 56% (5 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 67% (2 of 3); on the table 67% | - | 34% | 20% (2 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 83% (5 of 6) | 56% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 26% | 83% (10 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 11% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p35, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (4) | 67% (4) | 62% (8) |
| ...free all their last turn and able to turn (per game) | 1.33 | 1.33 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 1.00 | 2.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: nw22-19bea9b-p35

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 59% (10 of 17) | 43% (3 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (13 of 26) | 20% (2 of 10) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 0% (0 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 40% (2 of 5) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 100% (5 of 5) | 60% (6 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.0 |
| Movement | Points that never moved of their own | 136.7 | 305.0 |
| Movement | Fights charged into per game | 4.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 9 | 2 of 5, net +48 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 9, net +664 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 9, net +39 | 2 of 5, net +35 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 9, net +174 | 1 of 5, net +210 |
| Shooting | Shots by shooting units (incl. breath weapons) | 25.0 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 32% (24 of 75) | 65% (13 of 20) |
| Shooting | Points destroyed by shooting units | 38.7 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 1.7 | 1.0 |
| Magic | Wounds caused by other spells | 2.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 78.7 | 24.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.3 / 0.0 / 0.7 / 0.0 | 3.3 / 0.3 / 0.3 / 1.0 |
| Combat | Points destroyed in combat | 407.0 | 206.7 |
| Combat | Points run down | 83.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +189 | +85 |
| Combat | Net per 100 charger points, damage counted | +56.1 | +24.0 |
| Combat | First round won (charged fights) | 100% | 86% |
| Combat | Net points per charged fight | +177 | +84 |
| Combat | Net points per supported fight / lone fight | +58 / +201 | +145 / +74 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 12 | 3 of 7 |
| Game | Points lost | 349.0 | 949.0 |
| Game | VP from objectives | 1256.7 | 393.3 |
| Game | Lone holders (player turns) | 1.5 | 0.5 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1537 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1298
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: nw22-19bea9b-p35

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +0.5 | 0.0 | 65.0 | - | - | - | - |
| ARMY TABLE | 31.3 | +373.2 | 0.0 | 116.7 | 23.0 | +19.5 | 0.0 | 700.3 |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +4.2 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +11.0 | 0.0 | 0.0 | - | - | - | - |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST FACING | - | - | - | - | 0.3 | +29.7 | 0.0 | 38.7 |
| CARRIES OUT SET-UP | 1.0 | -106.8 | 85.3 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 3.3 | +41.5 | 130.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.3 | +5.2 | 0.0 | 24.0 | 0.7 | +17.5 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +19.2 | 0.0 | 0.0 | 1.3 | +64.4 | 0.0 | 163.7 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 1.0 | -99.2 | 198.3 | 65.0 | 0.3 | -9.9 | 0.0 | 15.0 |
| CHARGE LIST READ AGAIN | 0.3 | +30.1 | 36.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 13.7 | -440.8 | 0.0 | 355.0 | 25.3 | -1656.4 | 0.0 | 1034.0 |
| CHARGE NOW FIRST | 5.0 | +0.0 | 554.3 | 88.3 | 3.0 | +0.0 | 118.3 | 92.3 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 14.0 | +0.0 | 0.0 | 165.0 | 10.0 | +0.0 | 0.0 | 214.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 83.7 | 70.0 | 0.3 | +0.0 | 70.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +27.4 | 0.0 | 91.3 |
| COVER ONCE | 10.3 | -570.6 | 0.0 | 23.3 | 8.7 | -374.5 | 0.0 | 261.7 |
| DEFENSIVE FLOOR | 0.3 | -21.3 | 62.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 1.3 | -3.9 | 168.0 | 0.0 | 0.7 | -0.6 | 0.0 | 55.3 |
| DEPLOY BY FIGURES | 8.7 | +49.0 | 0.0 | 0.0 | 7.3 | +77.4 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.3 | +39.5 | 212.3 | 23.3 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 4.3 | +1428.8 | 0.0 | 41.7 |
| EXACT ROUND | 4.3 | +91.4 | 516.7 | 88.3 | 3.0 | +7.3 | 213.3 | 55.3 |
| FACES THE THREAT | - | - | - | - | 0.3 | +36.5 | 0.0 | 38.7 |
| FALL BACK GOOD ORDER | 5.7 | +24.8 | 609.3 | 88.3 | 2.3 | +4.0 | 46.7 | 70.3 |
| FALLS SHORT | 3.7 | +27.4 | 0.0 | 0.0 | 23.0 | +280.8 | 0.0 | 386.3 |
| FEATURE BUFFS | 2.0 | +16.9 | 0.0 | 0.0 | 1.3 | +4.7 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +54.7 | 70.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.3 | +2.3 | 0.0 | 42.0 |
| FIVE ACTION | 112.0 | +10237.8 | 1636.3 | 539.7 | 83.3 | +2933.6 | 343.3 | 1614.3 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 70.7 | 9.0 | +0.0 | 0.0 | 275.0 |
| FOLLOW UP WEIGHED | 1.7 | +133.7 | 0.0 | 0.0 | 1.3 | +182.2 | 0.0 | 38.7 |
| FOUR ROUNDS | 6.3 | +417.0 | 728.0 | 88.3 | 3.7 | +264.4 | 213.3 | 70.3 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 48.3 | 7.7 | +0.0 | 0.0 | 161.0 |
| FRIEND SHOOTS FIRST | 2.3 | -28.5 | 77.3 | 0.0 | 0.7 | -1.6 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 11.3 | +1338.4 | 0.0 | 46.7 | 10.7 | +523.5 | 0.0 | 83.3 |
| GUN FIGURES | 1.3 | +0.0 | 31.7 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | -0.9 | 100.7 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 52.7 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 48.3 | 6.7 | +0.0 | 0.0 | 161.0 |
| HELP BY WHAT IT ADDS | 1.0 | +0.0 | 78.3 | 23.3 | - | - | - | - |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 308.3 | 12.3 | +0.0 | 0.0 | 748.0 |
| HIS CHARGE DENIED | 0.3 | +1.2 | 62.0 | 0.0 | 0.3 | +40.3 | 0.0 | 38.7 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 109.3 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -7.5 | 0.0 | 95.0 | 6.0 | -62.7 | 0.0 | 170.3 |
| HIS ONE QUARTER | 8.7 | +0.0 | 0.0 | 95.0 | 5.7 | +0.0 | 0.0 | 154.7 |
| HIS OWN BEST MOVE | 10.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 30.0 |
| HIS RANDOM MOVE | 11.0 | +0.0 | 0.0 | 48.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.0 | +435.8 | 0.0 | 308.0 | 50.0 | +876.1 | 0.0 | 1242.0 |
| HIS SHOTS BY HIS RUN | 34.3 | +322.4 | 0.0 | 236.3 | 52.7 | +598.6 | 0.0 | 1198.0 |
| HIS TURN DENIED | 1.3 | +15.5 | 168.0 | 0.0 | 0.7 | +8.3 | 48.3 | 16.7 |
| HOLD ODDS | 28.3 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 124.0 |
| HOLDER ASSIGNMENT | 18.7 | +1330.2 | 0.0 | 0.0 | 7.7 | +701.9 | 0.0 | 114.7 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -160.0 | 451.3 | 0.0 | 3.0 | -121.1 | 213.3 | 16.7 |
| IDLE COST | 2.3 | -50.8 | 0.0 | 23.3 | 17.0 | -184.2 | 0.0 | 198.0 |
| JOINT CHARGE NOW | 2.0 | +8.5 | 236.0 | 0.0 | 0.3 | -0.6 | 0.0 | 16.7 |
| JOINT ON THE TABLE | 0.7 | +56.4 | 98.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 62.0 |
| LANE BY FIGURES | 1.3 | +41.4 | 0.0 | 0.0 | 0.7 | +2.4 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 179.0 | 0.0 | 3.0 | +0.0 | 153.3 | 187.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.7 | -4.6 | 62.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +3.7 | 184.3 | 65.0 | 1.3 | +0.9 | 48.3 | 38.7 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.3 | +8.3 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +12.5 | 0.0 | 0.0 | 1.7 | -21.4 | 0.0 | 125.3 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +8.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +35.3 | 0.0 | 0.0 | 3.7 | +62.5 | 0.0 | 176.0 |
| MEETS IN TIME | 4.0 | +218.7 | 0.0 | 0.0 | 4.0 | +488.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +48.3 | 0.0 | 0.0 | 5.7 | +98.3 | 0.0 | 258.7 |
| MISSILES NEXT TURN | 1.7 | +33.4 | 0.0 | 0.0 | 5.7 | +62.0 | 0.0 | 258.7 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.7 | +1093.3 | 0.0 | 0.0 | 6.7 | +416.8 | 0.0 | 71.7 |
| NEAR WALKS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 14.0 | +580.8 | 0.0 | 0.0 | 7.7 | +298.1 | 0.0 | 220.0 |
| NEXT CHARGE BY LIST | 8.7 | +927.9 | 116.0 | 0.0 | 7.3 | +754.8 | 0.0 | 71.7 |
| NEXT OBJECTIVE NEARER | 0.3 | -36.4 | 0.0 | 0.0 | 0.3 | -3.7 | 0.0 | 0.0 |
| NO CHAFF EDGES | 5.0 | +153.6 | 525.7 | 65.0 | 4.0 | +97.2 | 160.0 | 122.7 |
| NO DOUBLE ROUNDS | 5.7 | -262.1 | 627.3 | 88.3 | 2.7 | -128.5 | 166.7 | 70.3 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +1.7 | 0.0 | 38.7 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -211.8 | 0.0 | 0.0 | 3.7 | -96.4 | 0.0 | 83.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.0 | -162.1 | 0.0 | 0.0 | 6.3 | -89.7 | 0.0 | 92.3 |
| ONE JOINT FIGURE | 0.3 | -4.4 | 41.7 | 23.3 | 0.3 | -2.3 | 0.0 | 16.7 |
| ONE OBJECTIVE FORMULA | 9.0 | +62.9 | 0.0 | 0.0 | 2.7 | -51.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -15.5 | 0.0 | 41.7 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +33.9 | 38.7 | 0.0 | 0.3 | +28.5 | 23.3 | 0.0 |
| OPENS UP IN FULL | 4.3 | +126.9 | 525.7 | 65.0 | 1.3 | +59.9 | 95.0 | 0.0 |
| OVERRUNS AWAY | 2.7 | +177.8 | 360.0 | 65.0 | 1.0 | +9.2 | 96.7 | 16.7 |
| PATHS CROSS | - | - | - | - | 0.7 | -2.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -0.6 | 0.0 | 0.0 | 0.3 | -0.9 | 0.0 | 0.0 |
| PLAN RESULT | 51.0 | +664.9 | 344.7 | 516.3 | 42.0 | +341.7 | 456.0 | 1430.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 23.3 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 12.0 | -1036.0 | 0.0 | 0.0 | 9.3 | -147.3 | 0.0 | 0.0 |
| PROMISE HOLDS THE SPOT | 0.3 | +34.7 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | -2.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 34.0 | +3328.9 | 569.7 | 118.3 | 20.7 | +1624.0 | 130.0 | 408.3 |
| RANDOM MOVE BY FIGURES | 3.7 | +154.0 | 0.0 | 263.3 | 2.0 | +0.4 | 0.0 | 226.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.0 | +145.9 | 0.0 | 24.0 | 1.0 | +10.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 30.0 |
| REDIRECT WEIGHED | 0.3 | +22.4 | 34.0 | 0.0 | 0.3 | +0.0 | 0.0 | 16.7 |
| REFORMS TO MEET IT | 1.3 | -7.1 | 0.0 | 0.0 | 1.0 | -3.8 | 0.0 | 30.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 1.3 | +12.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 4.7 | -206.2 | 594.0 | 88.3 | 3.0 | -93.3 | 190.0 | 70.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -42.0 | 221.7 | 65.0 | 0.3 | -2.8 | 0.0 | 0.0 |
| RUN DOWN | 4.7 | -95.0 | 500.7 | 88.3 | 1.7 | -5.8 | 96.7 | 16.7 |
| SAME CHARGE LATER | 0.7 | -22.9 | 77.3 | 0.0 | 0.7 | -2.7 | 0.0 | 0.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | -0.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -62.8 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +55.5 | 0.0 | 0.0 | 1.0 | +2.2 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +32.2 | 41.7 | 0.0 | 0.7 | +47.8 | 23.3 | 0.0 |
| SET CREDITED ONCE | 0.7 | -10.2 | 0.0 | 0.0 | 0.7 | -8.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +2.2 | 0.0 | 0.0 | 2.3 | +69.8 | 96.7 | 0.0 |
| SET UP TOGETHER | 1.3 | +8.3 | 0.0 | 0.0 | 1.7 | +10.7 | 0.0 | 122.3 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 36.7 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +52.3 | 214.3 | 0.0 | 1.7 | +3.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -48.6 | 142.0 | 0.0 | 0.3 | -0.0 | 0.0 | 15.0 |
| SHOT RISK POINTS | 20.3 | -176.8 | 0.0 | 236.3 | 31.3 | -459.3 | 0.0 | 704.0 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.7 | +288.3 | 0.0 | 24.0 | 6.0 | +55.2 | 0.0 | 131.3 |
| SPELL WORTH | 0.7 | +2.7 | 0.0 | 0.0 | 3.3 | +3.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 9.3 | +0.0 | 0.0 | 215.0 | 8.0 | +0.0 | 0.0 | 464.7 |
| STAND AND SHOOT | 1.3 | -19.3 | 178.0 | 0.0 | 0.3 | -1.1 | 48.3 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 44.0 | +0.0 | 908.3 | 46.7 | 20.7 | +0.0 | 130.0 | 186.7 |
| STAY WORTH | 20.7 | +68.2 | 360.7 | 0.0 | 6.7 | +42.4 | 130.0 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +81.3 | 136.3 | 65.0 | 0.7 | +4.5 | 46.7 | 30.0 |
| STRONG ENOUGH TO HOLD | 2.7 | -42.7 | 0.0 | 0.0 | 1.0 | -21.3 | 0.0 | 62.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +7.4 | 0.0 | 34.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 48.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.0 | +799.0 | 0.0 | 0.0 | 6.3 | +429.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 38.7 |
| SUPPORT WORKED OUT | 7.0 | +799.0 | 0.0 | 0.0 | 6.3 | +429.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +3.3 | 0.0 | 0.0 | 4.3 | +44.8 | 0.0 | 176.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 41.7 |
| THE FIGHT MOVES | 2.3 | +72.9 | 308.0 | 88.3 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 75.7 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 164.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 209.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 51.0 | +0.0 | 0.0 | 94.0 | 39.7 | +0.0 | 0.0 | 697.3 |
| TIED UP BY THE SUM | 2.0 | +240.2 | 167.0 | 0.0 | 1.3 | +145.8 | 141.7 | 0.0 |
| TIME ON OUR SIDE | 44.0 | +428.5 | 226.7 | 47.3 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +1.0 | 0.0 | 83.7 |
| WAITS AGAIN | 4.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 1.3 | +3.5 | 162.0 | 88.3 | 0.7 | +2.7 | 48.3 | 15.0 |
| WHO GETS IN | 1.3 | +38.2 | 197.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -298.5 | 0.0 | 215.0 | 3.7 | -1199.3 | 0.0 | 527.3 |
| WHOLE FIGHT GAIN | 0.7 | +12.7 | 36.7 | 0.0 | 0.3 | +0.6 | 0.0 | 16.7 |
| WHOLE FIGHT REACTION | 1.3 | +98.1 | 31.7 | 0.0 | 2.0 | +118.9 | 65.0 | 300.3 |
| WOUNDS ON THE RANKS | 0.7 | +3.2 | 0.0 | 0.0 | 6.7 | +75.2 | 0.0 | 334.7 |

### Rule changes: nw22-19bea9b-p35

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 163 | 163 | 115 | 38.33 | +1396 | +12.1 |
| HOLDER ASSIGNMENT | 79 | 79 | 72 | 24.00 | +2309 | +32.1 |
| HIS SHOT LIST | 261 | 249 | 49 | 16.33 | +362 | +7.4 |
| FIVE ACTION | 586 | 561 | 44 | 14.67 | +2084 | +47.4 |
| HIS SHOTS BY HIS RUN | 261 | 246 | 32 | 10.67 | +366 | +11.5 |
| NEXT CHARGE BY LIST | 48 | 47 | 30 | 10.00 | +1835 | +61.2 |
| MOVE TO CHARGE COMPUTED | 52 | 45 | 29 | 9.67 | +1597 | +55.1 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -924 | -33.0 |
| DEPLOY BY FIGURES | 48 | 48 | 27 | 9.00 | +251 | +9.3 |
| PROMISE BY ITS OWN SUM | 64 | 64 | 24 | 8.00 | -3550 | -147.9 |
| QUARTER ODDS | 164 | 158 | 20 | 6.67 | +1298 | +64.9 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| GOAL WALK | 66 | 63 | 18 | 6.00 | +690 | +38.3 |
| NO CHAFF EDGES | 27 | 26 | 16 | 5.33 | +447 | +27.9 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| SUPPORT ADDS | 40 | 38 | 15 | 5.00 | +1019 | +67.9 |
| SUPPORT WORKED OUT | 40 | 38 | 15 | 5.00 | +1019 | +67.9 |
| FOUR ROUNDS | 30 | 26 | 12 | 4.00 | +447 | +37.2 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 24 | 24 | 11 | 3.67 | -579 | -52.6 |
| EVASIVE BY THE ODDS | 13 | 13 | 11 | 3.67 | +3251 | +295.5 |
| MEETS IN TIME | 24 | 24 | 11 | 3.67 | +567 | +51.5 |
| SHOT RISK POINTS | 155 | 150 | 10 | 3.33 | +72 | +7.2 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +948 | +105.3 |
| IDLE COST | 58 | 34 | 9 | 3.00 | +14 | +1.6 |
| RANDOM MOVE BY FIGURES | 17 | 17 | 9 | 3.00 | +463 | +51.5 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 8 | 2.67 | +40 | +4.9 |
| STAY WORTH | 82 | 70 | 8 | 2.67 | +15 | +1.9 |
| TIME ON OUR SIDE | 132 | 112 | 8 | 2.67 | +7 | +0.9 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CAST JOB | 10 | 10 | 7 | 2.33 | +97 | +13.9 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +24 | +3.4 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +131 | +21.9 |
| MAIN BODY KEEPS ITS BAND | 6 | 6 | 6 | 2.00 | +1361 | +226.8 |
| SEARCH SPOT | 6 | 6 | 6 | 2.00 | +173 | +28.9 |
| SURE REACH TOGETHER | 14 | 14 | 6 | 2.00 | +41 | +6.8 |
| TIED UP BY THE SUM | 10 | 10 | 6 | 2.00 | +238 | +39.7 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +251 | +50.2 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| MAX FOR POSITIONING | 18 | 18 | 4 | 1.33 | +31 | +7.7 |
| MISSILES IN THE MOVE | 21 | 14 | 4 | 1.33 | +83 | +20.7 |
| NEARER NOT NEEDED | 65 | 64 | 4 | 1.33 | +106 | +26.4 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +37 | +9.2 |
| RISK BY ARC | 23 | 20 | 4 | 1.33 | +104 | +25.9 |
| SCOUTS HUNT GUNS ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +240 | +60.0 |
| SET UP BY THE SET | 11 | 11 | 4 | 1.33 | +247 | +61.8 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +178 | +44.4 |
| WHO GETS IN | 4 | 4 | 4 | 1.33 | +115 | +28.7 |
| WOUNDS ON THE RANKS | 22 | 22 | 4 | 1.33 | +38 | +9.4 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 57 | 34 | 3 | 1.00 | +30 | +9.9 |
| OPENS UP IN FULL | 17 | 16 | 3 | 1.00 | +68 | +22.5 |
| OVERRUNS AWAY | 11 | 10 | 3 | 1.00 | +97 | +32.5 |
| PROMISE KNOWS THE FIGHT | 9 | 7 | 3 | 1.00 | -6 | -2.2 |
| SCOUT BY DROPS | 5 | 5 | 3 | 1.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| CARRIES OUT SET-UP | 3 | 3 | 2 | 0.67 | -320 | -160.1 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 5 | 2 | 0.67 | +10 | +5.0 |
| CHARGE LOSSES | 117 | 112 | 2 | 0.67 | +105 | +52.6 |
| EXACT ROUND | 22 | 19 | 2 | 0.67 | +184 | +91.9 |
| FALLS SHORT | 80 | 63 | 2 | 0.67 | +32 | +16.0 |
| FIGHT TO THE END | 2 | 2 | 2 | 0.67 | +60 | +30.2 |
| HIS TURN DENIED | 6 | 6 | 2 | 0.67 | +26 | +13.1 |
| JOINT ON THE TABLE | 2 | 2 | 2 | 0.67 | +169 | +84.7 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +62 | +31.2 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -8 | -3.9 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -4 | -2.2 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +144 | +71.8 |
| SHOTS IN THE MOVE | 86 | 61 | 2 | 0.67 | +47 | +23.7 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -44 | -21.8 |
| WHOLE FIGHT REACTION | 10 | 10 | 2 | 0.67 | +12 | +5.9 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BEST FACING | 1 | 1 | 1 | 0.33 | +89 | +89.0 |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 1 | 0.33 | +43 | +42.9 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +90 | +90.2 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +109 | +109.4 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +7 | +6.8 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -2 | -2.5 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +76 | +75.9 |
| HIS MOVE AND SHOT | 24 | 24 | 1 | 0.33 | +13 | +13.4 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +14 | +14.0 |
| MISSILES NEXT TURN | 22 | 16 | 1 | 0.33 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +2 | +2.1 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -47 | -46.6 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.33 | +104 | +104.0 |
| REDIRECT COUNTER | 15 | 11 | 1 | 0.33 | +13 | +13.1 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -14 | -13.9 |
| SAME CHARGE LATER | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 14 | 14 | 1 | 0.33 | +0 | +0.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +22 | +22.4 |
| THE FIGHT MOVES | 7 | 6 | 1 | 0.33 | +43 | +42.9 |
| THE ROW IN ITS ORDER | 17 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 5 | 1 | 0.33 | +8 | +8.1 |
| WHOLE FIGHT DANGER | 21 | 20 | 1 | 0.33 | +24 | +24.2 |
| WHOLE FIGHT GAIN | 3 | 2 | 1 | 0.33 | +11 | +11.3 |
| BACKS UP THE FIGHT | 1 | not checked | - | - | - | - |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 72 | 72 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 24 | 20 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 10 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 26 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 9 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 5 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 23 | 22 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 2 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 39 | 39 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 43 | 41 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 42 | 38 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 45 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 120 | 120 | 0 | 0.00 | - | - |
| HONEST WORTH | 23 | 19 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 25 | 21 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 40 | 16 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 35 | 27 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 279 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 9 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 40 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 52 | 48 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 194 | 188 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 11 | 11 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 272 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 15 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p35

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 3.67 | 35.9 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | 3.33 | 147.9 |
| ARMY TABLE | rule | 1.67 | 4.33 | 47.0 |
| CHARGE NOW FIRST | rule | 2.00 | 1.67 | 52.6 |
| HOLDER ASSIGNMENT | rule | 2.67 | 0.67 | 25.8 |
| JOINT CHARGE NOW | rule | 1.00 | 0.33 | 43.9 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 2.2 |
| CARRIES OUT SET-UP | rule | 0.67 | - | 160.1 |
| NO REASON | gate | 0.67 | - | 28.8 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 2.2 |
| SUPPORT NARROWED | rule | - | 0.67 | 21.8 |
| AFTERMATH BAND | gate | 0.33 | - | 2.5 |
| FIGHT ORDER BAND | gate | 0.33 | - | 2.7 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 2.5 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 1.5 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 46.6 |
| PATHS CROSS | rule | - | 0.33 | 68.1 |
| REFUSING RETIRES | rule | 0.33 | - | 13.9 |
| WHO GETS IN | rule | 0.33 | - | 84.7 |

### Plans: nw22-19bea9b-p35

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 67% | 601 | 402 | 67% |
| Mine | move | 40.7 | 97% | 3039 | 0 | 0% |
| Mine | shoot | 6.3 | 47% | 601 | 263 | 44% |
| Opponent | charge | 3.0 | 56% | 306 | 212 | 69% |
| Opponent | join | 2.3 | 86% | 91 | 0 | 0% |
| Opponent | move | 33.3 | 91% | 1371 | 0 | 0% |
| Opponent | shoot | 3.0 | 22% | 305 | 130 | 43% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p35

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.0 | 17% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p35

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 133 (6) | 29 | 104 | 18 | 17% | 1.2 | 273 (1) | 54 (3) | 198 (2) | 114 (3) | 153 (3) |
| Mine | Character | 6 | 35 (6) | 35 | 0 | 7 | 0% | 4.0 | 23 (2) | 56 (2) | 16 (1) | 23 (2) | 51 (3) |
| Mine | Clean-up | 1 | 805 (1) | 0 | 805 | 0 | 100% | - | - | 805 (1) | - | - | 805 (1) |
| Mine | Fast Hammer | 6 | 209 (6) | 209 | 0 | 36 | 0% | 3.7 | 28 (3) | 313 (3) | - | 237 (4) | 171 (2) |
| Mine | Hammer | 5 | 25 (5) | 2 | 23 | 55 | 0% | 2.4 | 0 (3) | 56 (2) | - | 38 (3) | 11 (2) |
| Mine | Holder | 8 | 86 (8) | 0 | 86 | 0 | 38% | 2.2 | 204 (2) | 108 (3) | 0 (2) | 204 (2) | 59 (5) |
| Mine | Shooter | 5 | 29 (5) | 0 | 29 | 0 | 0% | 2.2 | 0 (2) | 65 (3) | - | 20 (3) | 48 (2) |
| Mine | Wizard | 4 | 36 (4) | 36 | 0 | 0 | 0% | 1.5 | 0 (2) | 0 (1) | 56 (1) | 0 (3) | 56 (1) |
| Opponent | Chaff | 4 | 108 (4) | 58 | 50 | 19 | 75% | 5.0 | 144 (3) | - | 0 (1) | 144 (3) | 0 (1) |
| Opponent | Character | 11 | 15 (11) | 15 | 0 | 43 | 45% | 2.7 | 10 (3) | 0 (5) | 29 (2) | 17 (4) | 17 (6) |
| Opponent | Fast Hammer | 6 | 17 (6) | 17 | 0 | 58 | 17% | 2.4 | 0 (1) | 24 (4) | 0 (1) | 0 (2) | 22 (4) |
| Opponent | Hammer | 8 | 0 (8) | 0 | 0 | 90 | 0% | 3.8 | - | 0 (7) | 0 (1) | 0 (6) | 0 (2) |
| Opponent | Holder | 3 | 48 (3) | 48 | 0 | 0 | 67% | 5.0 | 0 (1) | 74 (2) | - | - | 48 (3) |
| Opponent | Shooter | 3 | 58 (3) | 0 | 58 | 69 | 0% | 1.3 | - | 158 (1) | 12 (2) | 94 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: nw22-19bea9b-p35

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 236 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | +0 | - |
| Mine | Tomb Kings of Khemri | 2 | 58 | 1160 | 5.5 | 1.1 | 211 | 18 | +193 | 2 of 11 | 11 of 11 | +116 | +201 |
| **Mine** | all armies | 3 | 117 | 773 | 4.0 | 1.2 | 193 | 16 | +177 | 2 of 12 | 12 of 12 | +58 | +201 |
| Opponent | Vampire Counts | 1 | 0 | 495 | 4.0 | 1.2 | 124 | 11 | +112 | 2 of 4 | 3 of 4 | +145 | +102 |
| Opponent | Warriors of Chaos | 1 | 72 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 0 | 140 | 2.0 | 1.0 | 70 | 0 | +70 | 0 of 2 | 2 of 2 | - | +70 |
| **Opponent** | all armies | 3 | 24 | 212 | 2.3 | 1.1 | 91 | 6 | +84 | 3 of 7 | 6 of 7 | +145 | +74 |

### Effective charges: nw22-19bea9b-p35

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 11 | 0 | 0 | 1 (net +664) | 1 (net +170) | 3 (net +39) | 3 (net +233) | 3 | 12% (1 of 8) |
| Opponent | Vampire Counts | 4 | 1 (net +95) | 0 | 0 | 0 | 1 (net +0) | 1 (net +210) | 1 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +70) | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p35

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 195 | 201 | +664 | 859 | 195 | +664 | +340.5 |
| Mine | 76-89% | 1 | 411 | 170 | +170 | 170 | 0 | +170 | +41.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 225 | 152 | +174 | 174 | 10 | +165 | +73.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 489 | 113 | +39 | 99 | 0 | +99 | +20.3 |
| Mine | No odds | 3 | 355 | 117 | +159 | 159 | 0 | +159 | +44.7 |
| Mine | All fights | 12 | 337 | 139 | +177 | 208 | 20 | +189 | +56.1 |
| Opponent | Long shot (under 50%) | 2 | 80 | 208 | +48 | 70 | 22 | +48 | +59.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 186 | 210 | +210 | 210 | 0 | +210 | +112.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 485 | 81 | +35 | 37 | 0 | +37 | +7.7 |
| Opponent | No odds | 2 | 578 | 108 | +108 | 108 | 0 | +108 | +18.6 |
| Opponent | All fights | 7 | 353 | 143 | +84 | 91 | 6 | +85 | +24.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p35 | move | 26 | 6 (23%) | 3 (12%) | 8 (31%) | 12 (46%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

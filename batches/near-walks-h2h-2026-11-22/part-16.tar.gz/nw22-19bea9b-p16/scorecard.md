# Doctrine scorecard: nw22-19bea9b-p16

### Scorecard: nw22-19bea9b-p16

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 735 |
| L0528 | 6 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 516 |
| L0616 | 4 | 1 | Opponent | no | 8 | 4 | 1 | 1 | 0 | 0 | 0 | 280 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 5 | 1 | 0 | 0 | 0 | 275 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.5 | 3.0 | 2.0 | 2.0 | 0.0 | 0.0 | 0.0 | 508.7 |
| **Average** | | | Opponent | 0% | 4.0 | 3.5 | 0.7 | 2.7 | 0.0 | 0.0 | 0.0 | 93.3 |

### KPIs: nw22-19bea9b-p16

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (12 of 12) | 0% (0 of 13) | 48% (12 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% | 100% (6 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 17% (1 of 6) | 17% (1 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 20% (1 of 5) | 20% (1 of 5) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 83% (10 of 12) | 83% (10 of 12) |
| Points that never fought | lower | 92% (5518 of 6000) | 88% (5260 of 5999) | 90% (10778 of 11999) |
|   infantry points that never fought | lower | 81% (1810 of 2232) | 91% (657 of 720) | 84% (2467 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (20 of 27) | 76% (16 of 21) | 75% (36 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (2847 of 4232) | 78% (4225 of 5415) | 73% (7072 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (60%) | 1.0 (60%) |
| MARCHED: its unit marched | - | 0.3 (20%) | 0.3 (20%) |
| GONE: slain | - | 0.3 (20%) | 0.3 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.3 | 0.0 | 0.3 | 0.0 |
| not cast | 2.7 | 2.0 | 1.7 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (50%) | 1.0 (60%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 0.3 (12%) | 0.3 (17%) | 0.3 (20%) | 1.0 (25%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (62%) | 0.7 (33%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (75%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (141 of 200) | 25% (8 of 32) | 64% (149 of 232) |
|   cavalry | 47% (9 of 19) | 30% (3 of 10) | 41% (12 of 29) |
|   character | 81% (25 of 31) | 0% (0 of 12) | 58% (25 of 43) |
|   infantry | 63% (32 of 51) | 0% (0 of 2) | 60% (32 of 53) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |
|   war machine | 77% (67 of 87) | 62% (5 of 8) | 76% (72 of 95) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (22%) | 2.7 (33%) | 7.0 (25%) |
| CHARGED: it charged | 2.0 (10%) | 0.3 (4%) | 2.3 (8%) |
| IN COMBAT: it fought this turn or the last | 1.0 (5%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET IN RANGE | 5.0 (25%) | 3.7 (46%) | 8.7 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.7 (29%) | 0.7 (8%) | 6.3 (23%) |
| SHELTERED: the target was sheltered | 0.7 (3%) | 0.7 (8%) | 1.3 (5%) |
| OTHER BAR | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 2.3 | 54% | 10.9 pts | 47 pts |
| character | 8.3 | 6.0 | 64% | 15.4 pts | 129 pts |
| infantry | 20.7 | 10.0 | 63% | 13.7 pts | 284 pts |
| monster | 2.7 | 0.3 | 88% | 0.9 pts | 2 pts |
| war machine | 24.0 | 17.0 | 60% | 22.3 pts | 535 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 1.3 | 2.3 |
| Charges that made contact a game | 0.7 | 0.7 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.10 contact (21 units) | 0.20 declared, 0.10 contact (20 units) | 0.34 declared, 0.10 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | 50% (1 of 2) | 50% (3 of 6) |
| Character in a unit | 83% (5 of 6) | 0% (0 of 1) | - | 71% (5 of 7) |
| Character on its own | 100% (1 of 1) | 100% (4 of 4) | 75% (3 of 4) | 89% (8 of 9) |
| Infantry | 71% (5 of 7) | 50% (3 of 6) | - | 62% (8 of 13) |
| Monster | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 92% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 81% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 91% | 80% (12 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p16, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (1) | 100% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: nw22-19bea9b-p16

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 14% (1 of 7) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 71% (62 of 87) | 0% (0 of 6) |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 11% (1 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 2.7 |
| Movement | Points that never moved of their own | 508.7 | 93.3 |
| Movement | Fights charged into per game | 0.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 1, net +0 | 1 of 2, net +186 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 2, net +186 |
| Shooting | Shots by shooting units (incl. breath weapons) | 25.7 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (41 of 77) | 0% (0 of 3) |
| Shooting | Points destroyed by shooting units | 303.3 | 0.0 |
| Shooting | War machine shots | 22.3 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (39 of 67) | 20% (1 of 5) |
| Shooting | Points destroyed by war machines | 117.0 | 111.7 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 100% (1 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 62.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +8 | +155 |
| Combat | Net per 100 charger points, damage counted | +13.6 | +71.5 |
| Combat | First round won (charged fights) | 50% | 100% |
| Combat | Net points per charged fight | +0 | +186 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +186 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 2 of 2 |
| Game | Points lost | 294.0 | 793.0 |
| Game | VP from objectives | 473.3 | 356.7 |
| Game | Lone holders (player turns) | 2.5 | 4.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +695 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1087
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p16

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 4.3 | +112.7 | 0.0 | 0.0 | 15.3 | +308.5 | 0.0 | 154.7 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 2.0 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 119.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 21.3 | +98.4 | 1484.7 | 33.3 | 1.0 | +32.1 | 38.3 | 66.7 |
| CANNON SIGHT KEPT | 4.0 | +0.0 | 0.0 | 60.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +60.4 | 0.0 | 47.3 |
| CHALLENGE BY POINTS | 0.3 | +17.3 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.7 | 62.0 | 0.0 |
| CHARACTER GUNS | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.0 | -86.8 | 0.0 | 120.0 | 25.3 | -1081.6 | 0.0 | 1530.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 62.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 82.0 | 0.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -5.1 | 62.0 | 0.0 |
| CLEAR LANE AHEAD | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 86.7 | 10.7 | +0.0 | 0.0 | 117.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 6.0 | -518.9 | 0.0 | 0.0 | 4.3 | -241.6 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -4.2 | 62.0 | 0.0 |
| DEPLOY BY FIGURES | 10.7 | -119.8 | 0.0 | 21.7 | 6.0 | +70.9 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +7.2 | 62.0 | 0.0 |
| EXACT ROUND | 2.3 | +2.2 | 0.0 | 0.0 | 0.7 | +2.8 | 20.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +0.1 | 10.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 14.3 | +274.6 | 0.0 | 539.3 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +2.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 126.0 | +5341.1 | 3574.7 | 230.0 | 68.7 | +2966.5 | 318.7 | 1910.0 |
| FLANK NOT WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 97.3 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +199.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +41.3 | 10.0 | 0.0 | 1.3 | +55.1 | 82.0 | 0.0 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.7 | -25.0 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | - | - | - | - | 13.3 | +1150.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +5.0 | 46.3 | 0.0 | - | - | - | - |
| GUN MASK | 4.3 | +54.4 | 0.0 | 0.0 | 1.7 | +74.3 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.7 | +1.5 | 0.0 | 0.0 | 0.3 | +0.0 | 62.0 | 0.0 |
| HARD STAY DROPPED | 4.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELP BY WHAT IT ADDS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 3.3 | +0.0 | 0.0 | 40.0 | 11.7 | +0.0 | 0.0 | 154.7 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 80.0 | 22.3 | +0.0 | 0.0 | 139.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -26.9 | 0.0 | 40.0 | 5.3 | -56.6 | 0.0 | 10.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 13.0 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 28.7 | +1054.9 | 0.0 | 80.0 | 59.3 | +5174.9 | 0.0 | 1776.7 |
| HIS SHOTS BY HIS RUN | 8.0 | +90.9 | 0.0 | 120.0 | 44.0 | +1124.8 | 0.0 | 1730.3 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +26.2 | 62.0 | 0.0 |
| HOLD ODDS | 7.7 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 1077.3 |
| HOLDER ASSIGNMENT | 8.3 | +1037.8 | 0.0 | 0.0 | 7.0 | +760.2 | 0.0 | 538.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -13.7 | 10.0 | 0.0 | 1.0 | -48.7 | 20.0 | 0.0 |
| IDLE COST | - | - | - | - | 19.3 | -386.2 | 0.0 | 468.0 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.7 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.3 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 329.3 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +67.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 124.0 | 1.3 | +0.0 | 186.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.2 | 62.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -0.7 | 0.0 | 0.0 | 0.3 | -0.1 | 62.0 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.3 | -5.8 | 0.0 | 0.0 | 1.7 | -0.8 | 0.0 | 119.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +19.0 | 0.0 | 119.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.7 | +3.1 | 0.0 | 0.0 | 0.3 | +12.8 | 0.0 | 0.0 |
| MEETS IN TIME | 6.3 | +318.2 | 0.0 | 0.0 | 3.3 | +286.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 1.0 | +4.2 | 0.0 | 119.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +3.9 | 0.0 | 238.0 |
| MODEL FACING | 4.7 | +957.3 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 37.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.0 | +314.8 | 0.0 | 40.0 | 2.3 | +124.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +213.1 | 0.0 | 0.0 | 1.7 | +71.7 | 0.0 | 119.0 |
| NEXT CHARGE BY LIST | 3.3 | +104.5 | 0.0 | 0.0 | 2.3 | +124.5 | 0.0 | 0.0 |
| NO CHAFF EDGES | 0.7 | +6.1 | 0.0 | 62.0 | 1.7 | +31.0 | 0.0 | 10.0 |
| NO DOUBLE ROUNDS | 3.0 | -45.9 | 10.0 | 0.0 | 1.3 | -43.9 | 82.0 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 10.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -0.9 | 0.0 | 117.0 |
| OFF BEST | 6.7 | -184.3 | 0.0 | 0.0 | 3.0 | -71.7 | 0.0 | 77.3 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -2.7 | 62.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -40.6 | 0.0 | 41.7 | 4.0 | -83.6 | 0.0 | 46.3 |
| ONE JOINT FIGURE | 0.7 | -8.0 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.3 | +13.7 | 0.0 | 0.0 | 2.0 | -19.4 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -9.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.3 | +4.4 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +2.8 | 0.0 | 0.0 | 1.3 | +73.1 | 82.0 | 0.0 |
| PLAN RESULT | 55.3 | +1744.1 | 1309.0 | 248.7 | 33.0 | +135.8 | 204.0 | 758.0 |
| PRIZE BY WORTH | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 12.0 | -206.9 | 0.0 | 40.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 2.0 | -15.4 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -40.1 | 80.0 | 33.3 |
| QUARTER ODDS | 11.7 | +762.6 | 0.0 | 0.0 | 8.7 | +1292.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +73.3 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +23.0 | 0.0 | 21.7 | 0.7 | +9.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 33.7 |
| REDIRECT WEIGHED | 1.3 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.3 | -48.1 | 0.0 | 40.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +42.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +58.2 | 10.0 | 0.0 | 1.3 | -108.5 | 82.0 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -3.6 | 0.0 | 0.0 |
| RUN DOWN | 3.0 | -15.4 | 10.0 | 0.0 | 1.0 | -4.1 | 82.0 | 0.0 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 3.3 | -174.5 | 0.0 | 47.3 |
| SEARCH SPOT | 0.3 | +7.6 | 0.0 | 20.0 | - | - | - | - |
| SECOND LOOK | 1.0 | +19.3 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 3.7 | -112.1 | 0.0 | 0.0 | 0.3 | -8.7 | 0.0 | 26.7 |
| SET UP BY THE SET | 3.7 | +109.0 | 0.0 | 0.0 | 0.7 | +6.3 | 0.0 | 26.7 |
| SET UP TOGETHER | 1.3 | +3.4 | 0.0 | 0.0 | 0.7 | +0.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 29.0 | +0.0 | 0.0 | 33.3 | 2.3 | +0.0 | 0.0 | 66.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +10.3 | 0.0 | 0.0 | 1.3 | +5.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 1.3 | -6.6 | 10.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 16.0 | +639.8 | 0.0 | 120.0 | 38.7 | -413.9 | 0.0 | 1532.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 39.0 | +1108.1 | 0.0 | 53.3 | 2.7 | +169.7 | 0.0 | 66.7 |
| SPELL WORTH | - | - | - | - | 1.3 | +20.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 41.7 | 7.0 | +0.0 | 0.0 | 166.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -42.2 | 62.0 | 0.0 |
| STANDS STILL | 90.7 | +0.0 | 3564.7 | 146.7 | 17.0 | +0.0 | 236.7 | 186.7 |
| STAY WORTH | 75.0 | +337.1 | 2065.3 | 100.0 | 6.0 | +202.9 | 236.7 | 200.0 |
| STRIKE BY THE ODDS | 0.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.3 | -6.7 | 0.0 | 329.3 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +35.8 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +35.8 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 2.0 | +17.5 | 0.0 | 0.0 | 0.7 | +3.2 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.3 | 0.0 | 10.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 37.0 |
| THE FIGHT MOVES | 1.0 | +3.5 | 0.0 | 0.0 | 0.7 | +6.8 | 62.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 20.0 | 3.7 | +0.0 | 0.0 | 252.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 178.3 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 164.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 53.7 | +0.0 | 0.0 | 75.0 | 30.3 | +0.0 | 0.0 | 955.0 |
| TIED UP BY THE SUM | 1.0 | +28.2 | 0.0 | 0.0 | 1.0 | +111.1 | 20.0 | 0.0 |
| TIME ON OUR SIDE | 46.0 | +582.9 | 74.0 | 41.7 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -10.4 | 0.0 | 0.0 | 0.3 | +1.1 | 20.0 | 0.0 |
| WHOLE FIGHT DANGER | - | - | - | - | 4.0 | -200.3 | 0.0 | 154.7 |
| WHOLE FIGHT GAIN | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.3 | +66.2 | 0.0 | 82.0 | 3.3 | +100.5 | 0.0 | 20.0 |
| WOUNDS ON THE RANKS | 2.7 | +13.5 | 0.0 | 0.0 | 8.7 | +393.7 | 0.0 | 1134.7 |

### Rule changes: nw22-19bea9b-p16

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 264 | 261 | 64 | 21.33 | +1781 | +27.8 |
| ARMY TABLE | 59 | 59 | 49 | 16.33 | +1063 | +21.7 |
| HOLDER ASSIGNMENT | 46 | 46 | 41 | 13.67 | +2852 | +69.6 |
| SHOT RISK POINTS | 164 | 161 | 39 | 13.00 | +1297 | +33.3 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -768 | -26.5 |
| DEPLOY BY FIGURES | 50 | 50 | 26 | 8.67 | +480 | +18.5 |
| HIS SHOTS BY HIS RUN | 156 | 155 | 26 | 8.67 | +691 | +26.6 |
| FIVE ACTION | 584 | 568 | 21 | 7.00 | +433 | +20.6 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 20 | 6.67 | -621 | -31.0 |
| TIME ON OUR SIDE | 138 | 128 | 20 | 6.67 | +62 | +3.1 |
| CANNON PLANNED TARGET | 67 | 67 | 18 | 6.00 | -469 | -26.1 |
| MOVE TO CHARGE COMPUTED | 31 | 24 | 18 | 6.00 | +377 | +20.9 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +2872 | +205.1 |
| CANNON SIGHT KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| IDLE COST | 58 | 44 | 10 | 3.33 | +215 | +21.5 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 10 | 3.33 | +220 | +22.0 |
| SET UP BY THE SET | 13 | 11 | 9 | 3.00 | +212 | +23.6 |
| MEETS IN TIME | 29 | 29 | 8 | 2.67 | +96 | +12.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FOUR ROUNDS | 14 | 12 | 7 | 2.33 | +62 | +8.8 |
| GOAL WALK | 40 | 40 | 7 | 2.33 | +325 | +46.4 |
| GUN MASK | 18 | 17 | 7 | 2.33 | +114 | +16.3 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 17 | 12 | 7 | 2.33 | +259 | +36.9 |
| CHAFF IN THE MOVE | 8 | 7 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 94 | 93 | 6 | 2.00 | +587 | +97.9 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| NO CHAFF EDGES | 7 | 6 | 5 | 1.67 | +89 | +17.7 |
| QUARTER ODDS | 61 | 56 | 5 | 1.67 | +578 | +115.7 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 21 | 21 | 5 | 1.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 6 | 5 | 5 | 1.67 | +133 | +26.6 |
| WHOLE FIGHT REACTION | 14 | 14 | 5 | 1.67 | +56 | +11.3 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +598 | +149.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +204 | +50.9 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +111 | +27.8 |
| RISK BY ARC | 12 | 10 | 4 | 1.33 | +34 | +8.5 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 4 | 1.33 | +8 | +2.1 |
| SHOTS IN THE MOVE | 125 | 107 | 4 | 1.33 | +69 | +17.2 |
| EXACT ROUND | 9 | 7 | 3 | 1.00 | +2 | +0.8 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +766 | +255.5 |
| OVERRUNS AWAY | 6 | 6 | 3 | 1.00 | +28 | +9.2 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +127 | +42.3 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +58 | +19.3 |
| STAY WORTH | 243 | 224 | 3 | 1.00 | +21 | +7.0 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SURE REACH TOGETHER | 8 | 5 | 3 | 1.00 | +5 | +1.7 |
| THE ROW IN ITS ORDER | 15 | 3 | 3 | 1.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| BACKS UP THE FIGHT | 6 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -34 | -17.1 |
| HIS MOVE AND SHOT | 24 | 24 | 2 | 0.67 | +8 | +4.0 |
| HIS TURN DENIED | 3 | 3 | 2 | 0.67 | +33 | +16.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +4 | +1.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -120 | -60.1 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 2 | 0.67 | +0 | +0.0 |
| THE FIGHT MOVES | 5 | 4 | 2 | 0.67 | +11 | +5.5 |
| WOUNDS ON THE RANKS | 34 | 34 | 2 | 0.67 | +113 | +56.6 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +52 | +52.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +20 | +19.6 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -9 | -8.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COVER ONCE | 31 | 22 | 1 | 0.33 | +5 | +4.6 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| FALLS SHORT | 43 | 32 | 1 | 0.33 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| MAX FOR POSITIONING | 3 | 3 | 1 | 0.33 | +29 | +28.9 |
| NEARER NOT NEEDED | 19 | 18 | 1 | 0.33 | +30 | +29.9 |
| ONE FIGHT FORMULA | 26 | 18 | 1 | 0.33 | +6 | +6.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -29 | -29.2 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +6 | +6.4 |
| REDIRECT COUNTER | 3 | 2 | 1 | 0.33 | +11 | +11.2 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +23 | +22.8 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -13 | -13.3 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 2 | 1 | 0.33 | +0 | +0.4 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +10 | +10.3 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 16 | 16 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 58 | 56 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 6 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 2 | not checked | - | - | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 8 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 45 | 45 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 79 | 78 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 39 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 58 | 57 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 8 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 9 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 3 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 4 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 13 | 9 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 265 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 8 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 7 | 7 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 6 | 4 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 94 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 32 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 323 | 316 | 0 | 0.00 | - | - |
| STRIKE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 6 | 2 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 6 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 5 | not checked | - | - | - | - |
| THE TABLE BINDS | 252 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p16

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 2.67 | 28.1 |
| PROMISE BY ITS OWN SUM | rule | 6.67 | - | 31.0 |
| CANNON PLANNED TARGET | rule | 3.33 | - | 49.0 |
| ARMY TABLE | rule | - | 2.00 | 3.3 |
| RULE SWITCHED OFF | gate | 1.00 | - | 6.7 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 17.1 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 60.1 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 8.7 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 19.2 |
| JOINT CHARGE NOW | rule | 0.33 | - | 11.4 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 46.7 |
| NO REASON | gate | - | 0.33 | 45.8 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 29.2 |
| SUPPORT NARROWED | rule | 0.33 | - | 13.3 |

### Plans: nw22-19bea9b-p16

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 25% | 125 | 49 | 40% |
| Mine | join | 0.7 | 100% | 23 | 0 | 0% |
| Mine | move | 27.3 | 96% | 691 | 0 | 0% |
| Mine | shoot | 24.7 | 74% | 1425 | 1695 | 119% |
| Opponent | charge | 1.3 | 75% | 42 | 98 | 230% |
| Opponent | move | 28.7 | 93% | 1243 | 0 | 0% |
| Opponent | shoot | 1.3 | 25% | 103 | 38 | 37% |
| Opponent | support | 1.7 | 60% | 20 | 0 | 0% |

### Battle groups: nw22-19bea9b-p16

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p16

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 22 (13) | 22 | 0 | 0 | 38% | 2.1 | 0 (1) | 25 (9) | 23 (3) | 27 (10) | 0 (3) |
| Mine | Clean-up | 4 | 22 (4) | 22 | 0 | 0 | 50% | 1.0 | 0 (1) | 232 (1) | 0 (2) | 38 (3) | 0 (1) |
| Mine | Hammer | 5 | 145 (5) | 63 | 81 | 0 | 40% | 3.0 | - | 212 (3) | 66 (2) | 145 (5) | - |
| Mine | Shooter | 10 | 39 (10) | 0 | 39 | 30 | 0% | 1.7 | 0 (1) | 67 (5) | 0 (4) | 49 (8) | 0 (2) |
| Mine | War machine | 17 | 22 (17) | 22 | 0 | 20 | 12% | 1.4 | 0 (3) | 0 (5) | 44 (9) | 0 (3) | 27 (14) |
| Opponent | Chaff | 5 | 23 (5) | 0 | 23 | 69 | 80% | 2.0 | 0 (2) | 38 (2) | 0 (1) | 0 (4) | 75 (1) |
| Opponent | Character | 8 | 7 (8) | 7 | 0 | 31 | 88% | 4.0 | 0 (2) | 29 (2) | 0 (1) | 16 (3) | 0 (2) |
| Opponent | Clean-up | 2 | 86 (2) | 0 | 86 | 0 | 50% | 6.0 | - | 86 (2) | - | 86 (2) | - |
| Opponent | Fast Hammer | 4 | 25 (4) | 0 | 25 | 76 | 100% | - | 0 (1) | 50 (1) | 16 (2) | 25 (4) | - |
| Opponent | Hammer | 4 | 25 (4) | 25 | 0 | 0 | 50% | 4.5 | - | 0 (2) | 47 (2) | 25 (4) | - |
| Opponent | Holder | 2 | 12 (2) | 0 | 12 | 100 | 100% | - | 0 (1) | 27 (1) | - | 12 (2) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | War machine | 2 | 168 (2) | 168 | 0 | 50 | 0% | 1.0 | - | 168 (2) | - | - | 168 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 85 | 0% | 2.5 | - | - | 0 (1) | 0 (1) | - |

### Charged fights: nw22-19bea9b-p16

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 420 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Opponent | Kingdom of Bretonnia | 1 | 335 | 186 | 1.0 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |
| Opponent | Warriors of Chaos | 2 | 0 | 93 | 0.5 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |
| **Opponent** | all armies | 3 | 112 | 124 | 0.7 | 1.0 | 186 | 0 | +186 | 2 of 2 | 2 of 2 | - | +186 |

### Effective charges: nw22-19bea9b-p16

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +186) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 1 (net +186) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p16

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 50 | 170 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 1 | 60 | 135 | +0 | 15 | 0 | +15 | +25.0 |
| Mine | All fights | 2 | 55 | 152 | +0 | 8 | 0 | +8 | +13.6 |
| Opponent | Long shot (under 50%) | 1 | 63 | 186 | +186 | 186 | 0 | +186 | +295.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 371 | 186 | +186 | 186 | 62 | +124 | +33.5 |
| Opponent | All fights | 2 | 217 | 186 | +186 | 186 | 31 | +155 | +71.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p16 | move | 17 | 3 (18%) | 1 (6%) | 2 (12%) | 12 (71%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

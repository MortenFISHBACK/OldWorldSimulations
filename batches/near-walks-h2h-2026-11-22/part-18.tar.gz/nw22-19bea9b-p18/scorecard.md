# Doctrine scorecard: nw22-19bea9b-p18

### Scorecard: nw22-19bea9b-p18

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 375 |
| L0918 | 6 | 1 | Opponent | no | 11 | - | 4 | 2 | 1 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 477 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 6 | 4 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 11 | 2 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1026 | 6 | 1 | Opponent | no | 7 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.0 | 2.0 | 1.0 | 0.7 | 0.0 | 0.0 | 0.0 | 339.0 |
| **Average** | | | Opponent | 0% | 6.0 | 3.0 | 3.7 | 2.3 | 0.3 | 0.0 | 0.0 | 78.0 |

### KPIs: nw22-19bea9b-p18

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 64% (9 of 14) | 0% (0 of 14) | 32% (9 of 28) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | 100% (2 of 2); on the table 100% | 86% (6 of 7); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% | 0% (0 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 83% | 67% (2 of 3); on the table 100% | 67% (6 of 9); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 33% (16 of 48) | 17% (2 of 12) | 30% (18 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (16 of 40) | 20% (2 of 10) | 36% (18 of 50) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 51% (3070 of 5997) | 46% (2749 of 5998) | 49% (5819 of 11995) |
|   infantry points that never fought | lower | 58% (919 of 1591) | 82% (936 of 1147) | 68% (1855 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (21 of 34) | 50% (10 of 20) | 57% (31 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 0.7 uses a game | 100% (1 of 1); 1.3 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3398 of 5667) | 53% (2753 of 5186) | 57% (6151 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.7 (53%) | 0.0 (0%) | 5.7 (40%) |
| MARCHED: its unit marched | 1.7 (16%) | 0.7 (20%) | 2.3 (17%) |
| CHARGED: its unit charged | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |
| IN COMBAT: engaged in combat | 2.7 (25%) | 0.3 (10%) | 3.0 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (20%) | 0.7 (5%) |
| GONE: slain | 0.0 (0%) | 0.3 (10%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (40%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 2.3 | 6.0 | 0.7 | 2.3 |
| not cast | 2.3 | 3.7 | 14.0 | 3.3 | 13.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (36%) | 5.7 (40%) | 0.3 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.3 (17%) | 1.0 (30%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.3 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 3.0 (21%) | 0.7 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (86%) | 2.0 (55%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (14%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (90%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (87 of 124) | 55% (38 of 69) | 65% (125 of 193) |
|   cavalry | - | 58% (7 of 12) | 58% (7 of 12) |
|   character | 100% (12 of 12) | 56% (10 of 18) | 73% (22 of 30) |
|   chariot | 81% (13 of 16) | 100% (2 of 2) | 83% (15 of 18) |
|   infantry | 51% (22 of 43) | 43% (13 of 30) | 48% (35 of 73) |
|   monster | 75% (9 of 12) | 86% (6 of 7) | 79% (15 of 19) |
|   war machine | 76% (31 of 41) | - | 76% (31 of 41) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (14%) | 5.0 (48%) | 6.7 (29%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (19%) | 2.0 (9%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 1.3 (11%) | 0.0 (0%) | 1.3 (6%) |
| MOVED: a war machine that moved | 1.0 (8%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET IN RANGE | 3.0 (24%) | 2.7 (26%) | 5.7 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.0 (24%) | 0.7 (6%) | 3.7 (16%) |
| SHELTERED: the target was sheltered | 0.7 (5%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR | 1.0 (8%) | 0.0 (0%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 0.3 | 93% | 0.9 pts | 4 pts |
| character | 8.0 | 2.0 | 75% | 2.9 pts | 23 pts |
| chariot | 5.0 | 3.3 | 60% | 10.9 pts | 54 pts |
| infantry | 13.7 | 4.0 | 76% | 4.1 pts | 56 pts |
| monster | 8.3 | 2.7 | 84% | 4.3 pts | 36 pts |
| war machine | 10.3 | 10.3 | 58% | 36.1 pts | 373 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 6.3 | 4.8 |
| Charges that made contact a game | 2.3 | 5.3 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 2.00 declared, 1.33 contact (3 units) | 1.00 declared, 1.00 contact (1 units) | 1.75 declared, 1.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.21 declared, 0.16 contact (19 units) | 0.55 declared, 0.45 contact (31 units) | 0.42 declared, 0.34 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | - | - | 25% (1 of 4) |
| Character in a unit | 80% (4 of 5) | 100% (1 of 1) | - | 83% (5 of 6) |
| Character on its own | - | 67% (2 of 3) | 40% (2 of 5) | 50% (4 of 8) |
| Chariot | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Infantry | 36% (4 of 11) | 100% (2 of 2) | 0% (0 of 1) | 43% (6 of 14) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 0% (0 of 2) | 80% (4 of 5) | - | 57% (4 of 7) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 50% (1 of 2); on the table 100% | 29% (7 of 24) | 64% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 75% (3 of 4); on the table 75% | 38% (9 of 24) | 25% | 40% (4 of 10) | 50% (1 of 2); 2.0 uses a game | 100% (1 of 1); 2.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 94% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 33% (2 of 6) | 20% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 67% (2 of 3); on the table 100% | - | 24% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p18, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 50% (2) | 50% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: nw22-19bea9b-p18

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 56% (5 of 9) | 79% (11 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (16 of 55) | 55% (12 of 22) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 20% (1 of 5) | - |
| Strategy | Joined characters whose unit fought | 30% (3 of 10) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 75% (3 of 4) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 339.0 | 78.0 |
| Movement | Fights charged into per game | 1.7 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +599 | 0 of 10 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 2 of 10, net +68 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +60 | 2 of 10, net +125 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +30 | 5 of 10, net +86 |
| Shooting | Shots by shooting units (incl. breath weapons) | 19.7 | 12.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (26 of 59) | 55% (21 of 38) |
| Shooting | Points destroyed by shooting units | 73.0 | 0.0 |
| Shooting | War machine shots | 10.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (19 of 31) | - |
| Shooting | Points destroyed by war machines | 87.0 | 41.7 |
| Magic | Magic missiles cast | 2.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (2 of 8) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 2.3 | 0.3 |
| Magic | Wounds caused by other spells | 3.0 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.7 / 1.0 / 0.3 | 3.0 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 268.0 | 206.3 |
| Combat | Points run down | 0.0 | 45.0 |
| Combat | Net points per charged fight, damage counted | +142 | +66 |
| Combat | Net per 100 charger points, damage counted | +39.9 | +24.3 |
| Combat | First round won (charged fights) | 100% | 62% |
| Combat | Net points per charged fight | +144 | +63 |
| Combat | Net points per supported fight / lone fight | +30 / +220 | +110 / +54 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 4 of 13 |
| Game | Points lost | 362.3 | 456.3 |
| Game | VP from objectives | 683.3 | 780.0 |
| Game | Lone holders (player turns) | 4.0 | 6.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +113 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 819
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: nw22-19bea9b-p18

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +57.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 12.7 | +249.0 | 0.0 | 173.3 | 19.3 | +296.1 | 0.0 | 269.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +8.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 83.3 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.7 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 0.7 | +111.3 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 15.0 |
| CANNON PLANNED TARGET | 9.3 | +446.9 | 347.3 | 208.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 6.0 | +108.9 | 59.7 | 0.0 | 0.7 | +66.7 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 1.3 | +29.1 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +35.3 | 0.0 | 11.3 |
| CHALLENGE BY POINTS | 0.7 | +1.7 | 0.0 | 0.0 | 0.7 | +2.0 | 0.0 | 199.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 1.0 | +13.6 | 40.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 21.0 | -552.3 | 0.0 | 315.3 | 23.3 | -775.9 | 0.0 | 646.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 88.3 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 86.7 | 0.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -3.4 | 0.0 | 0.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 16.3 | +0.0 | 0.0 | 439.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 11.3 | -441.8 | 0.0 | 237.3 | 6.7 | -475.7 | 0.0 | 199.7 |
| DENIED BY THE FIGHT | 0.3 | -2.1 | 199.7 | 0.0 | 1.7 | -10.9 | 246.0 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | -60.4 | 0.0 | 41.7 | 8.3 | +44.5 | 0.0 | 61.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +16.6 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | -7.6 | 274.7 | 0.0 | 3.0 | -7.4 | 364.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 239.7 | 0.0 | 3.7 | +5.5 | 267.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 32.0 | +338.8 | 0.0 | 465.7 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +6.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +11.5 | 20.0 | 0.0 | 1.3 | +1.8 | 79.7 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 88.3 | 0.3 | +0.0 | 0.0 | 61.7 |
| FIVE ACTION | 98.7 | +5696.4 | 1345.7 | 1137.3 | 97.3 | +5698.4 | 615.3 | 976.3 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 176.7 | 3.3 | +0.0 | 0.0 | 211.0 |
| FOLLOW UP WEIGHED | 1.3 | +215.0 | 0.0 | 0.0 | 1.7 | +51.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +128.6 | 314.7 | 0.0 | 5.0 | +241.7 | 532.0 | 15.0 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 11.3 |
| FRIEND CHARGES FIRST | 0.3 | -13.9 | 15.0 | 0.0 | 0.3 | -8.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -15.6 | 40.0 | 0.0 | 0.3 | -2.7 | 34.7 | 0.0 |
| GOAL WALK | 7.7 | +457.5 | 0.0 | 0.0 | 19.3 | +1785.1 | 0.0 | 123.3 |
| GUN FIGURES | 3.3 | +36.1 | 0.0 | 176.7 | 0.7 | +35.3 | 41.7 | 123.3 |
| GUN MASK | 4.0 | +190.1 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | +4.2 | 199.7 | 0.0 | 1.3 | +2.4 | 211.3 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 78.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.0 | +0.0 | 45.0 | 15.0 |
| HIS CHARGE BY HIS RUN | 13.3 | +0.0 | 0.0 | 315.3 | 11.7 | +0.0 | 0.0 | 399.3 |
| HIS CHARGE DENIED | 0.3 | +80.1 | 199.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 138.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 6.3 | +0.0 | 0.0 | 157.7 | 8.3 | +0.0 | 0.0 | 399.3 |
| HIS MOVE AND SHOT | 2.7 | -22.6 | 0.0 | 0.0 | 18.0 | -166.4 | 0.0 | 55.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 353.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.3 | +0.0 | 0.0 | 246.0 | 11.3 | +0.0 | 0.0 | 399.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 33.0 | +880.9 | 0.0 | 630.7 | 63.3 | +4699.9 | 0.0 | 366.0 |
| HIS SHOTS BY HIS RUN | 37.7 | +384.0 | 0.0 | 561.3 | 57.7 | +1362.1 | 0.0 | 763.7 |
| HIS TURN DENIED | - | - | - | - | 2.3 | +226.9 | 329.3 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 69.3 | 21.3 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 12.0 | +1273.3 | 0.0 | 34.7 | 15.0 | +1380.4 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -56.1 | 115.0 | 0.0 | 3.3 | -111.8 | 310.3 | 0.0 |
| HUNT IN PAIRS | 0.7 | +42.1 | 0.0 | 0.0 | 0.7 | +32.1 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 20.0 | -269.6 | 0.0 | 28.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 1.3 | +26.0 | 40.0 | 0.0 | 2.0 | +171.6 | 310.0 | 15.0 |
| JOINT LOOK BACK | 0.3 | +4.3 | 20.0 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +48.9 | 88.3 | 0.0 |
| KEEP FALLS | 0.3 | +12.9 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 0.7 | +10.8 | 0.0 | 0.0 | 1.3 | +97.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 0.0 | 204.3 | 4.0 | +0.0 | 79.7 | 15.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | +3.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -4.5 | 219.7 | 0.0 | 2.7 | -0.6 | 291.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 3.3 | +64.8 | 0.0 | 211.0 |
| MANOEUVRE | 1.3 | +17.8 | 0.0 | 0.0 | 1.3 | -2.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +114.0 | 0.0 | 0.0 | 0.3 | +53.4 | 0.0 | 0.0 |
| MARCH CHECK | 2.3 | +102.2 | 0.0 | 0.0 | 0.7 | +26.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +13.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +151.8 | 0.0 | 0.0 | 0.7 | +46.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| MAX FOR POSITIONING | 2.0 | +39.4 | 0.0 | 0.0 | 5.0 | +128.1 | 0.0 | 220.0 |
| MEETS IN TIME | 3.7 | +358.9 | 0.0 | 0.0 | 4.7 | +505.4 | 0.0 | 61.7 |
| MISSILES IN THE MOVE | 8.7 | +174.4 | 0.0 | 0.0 | 2.0 | +98.0 | 0.0 | 199.7 |
| MISSILES NEXT TURN | 11.7 | +108.0 | 0.0 | 0.0 | 3.0 | +58.7 | 0.0 | 199.7 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 9.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.3 | +155.7 | 0.0 | 176.7 | 4.0 | +259.9 | 0.0 | 15.0 |
| NEAR WALKS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +356.3 | 0.0 | 0.0 | 4.7 | +229.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.0 | +268.6 | 15.0 | 88.3 | 4.0 | +508.0 | 0.0 | 15.0 |
| NO CHAFF EDGES | 3.7 | +56.4 | 30.0 | 69.3 | 4.3 | +108.6 | 345.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -47.1 | 115.0 | 0.0 | 3.7 | -291.4 | 320.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 8.7 | -369.6 | 0.0 | 76.3 | 4.7 | -57.7 | 0.0 | 11.3 |
| OGRE LOADER SECOND SHOT | 2.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -45.9 | 0.0 | 157.7 | 7.7 | -150.3 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +5.4 | 133.3 | 15.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -10.5 | 0.0 | 34.7 | 4.3 | +119.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -18.6 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.3 | +6.5 | 15.0 | 0.0 | 1.7 | +68.3 | 206.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.7 | +28.1 | 86.7 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -23.7 | 0.0 | 0.0 |
| PLAN RESULT | 44.0 | +1171.4 | 390.3 | 641.3 | 45.7 | +365.6 | 149.0 | 696.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.0 | -188.9 | 0.0 | 88.3 | 4.3 | -25.9 | 0.0 | 15.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | -2.1 | 0.0 | 0.0 | 1.0 | -16.1 | 0.0 | 15.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -6.6 | 0.0 | 0.0 |
| QUARTER ODDS | 6.0 | +157.0 | 0.0 | 589.3 | 11.0 | +1284.9 | 287.7 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -7.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +173.3 | 0.0 | 60.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 6.3 | +0.2 | 0.0 | 63.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -70.3 | 0.0 | 176.7 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +7.7 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +73.0 | 299.7 | 0.0 | 3.0 | -110.7 | 190.7 | 15.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 40.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -23.5 | 163.0 | 0.0 |
| RUN DOWN | - | - | - | - | 2.7 | -32.9 | 183.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -0.0 | 0.0 | 0.0 | 0.3 | -33.9 | 0.0 | 0.0 |
| SCOUT BY DROPS | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +13.5 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -163.7 | 0.0 | 18.0 |
| SEARCH SPOT | 0.3 | +2.2 | 0.0 | 0.0 | 1.3 | +29.9 | 0.0 | 9.0 |
| SET CREDITED ONCE | 0.7 | -10.9 | 0.0 | 0.0 | 2.0 | -38.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +26.5 | 0.0 | 88.3 | 3.3 | -32.9 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 3.3 | +64.8 | 0.0 | 211.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 18.0 | +0.0 | 0.0 | 253.3 | 7.3 | +0.0 | 0.0 | 87.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +91.4 | 156.0 | 0.0 | 0.7 | +6.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -3.4 | 15.0 | 0.0 | 0.3 | -4.6 | 0.0 | 0.0 |
| SHOT RISK POINTS | 20.7 | -171.0 | 0.0 | 176.7 | 46.0 | -309.8 | 0.0 | 752.7 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 31.3 | +1484.7 | 0.0 | 480.3 | 12.3 | +187.8 | 0.0 | 201.3 |
| SPELL WORTH | - | - | - | - | 3.7 | +47.4 | 199.7 | 199.7 |
| SPELLS IN THE FIGHT | 1.7 | +4.2 | 80.0 | 0.0 | 0.3 | -4.1 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 73.0 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -31.1 | 123.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 83.3 | 156.0 |
| STANDS STILL | 54.0 | +0.0 | 1031.0 | 645.3 | 30.3 | +0.0 | 83.3 | 171.0 |
| STAY WORTH | 39.7 | +266.5 | 692.0 | 409.7 | 26.3 | +198.4 | 83.3 | 357.3 |
| STRIKE BY THE ODDS | 0.7 | +5.5 | 15.0 | 88.3 | 1.0 | +20.6 | 0.0 | 0.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.3 | -0.2 | 0.0 | 40.0 |
| SUPPORT ADDS | 1.3 | +336.7 | 0.0 | 0.0 | 1.7 | +154.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 45.0 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +336.7 | 0.0 | 0.0 | 1.7 | +154.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.4 | 0.0 | 0.0 | 1.3 | +16.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +2.7 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.3 | +1.3 | 279.7 | 0.0 | 2.7 | +29.8 | 227.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 1.0 | -14.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 73.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 75.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 75.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.3 | +0.0 | 0.0 | 534.0 | 46.3 | +0.0 | 0.0 | 489.7 |
| TIED UP BY THE SUM | 1.7 | +186.2 | 95.0 | 0.0 | 0.7 | +102.5 | 76.3 | 0.0 |
| TIME ON OUR SIDE | 44.0 | +615.9 | 44.7 | 239.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 88.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 90.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 1.3 | -23.3 | 0.0 | 0.0 | 0.7 | -26.4 | 69.3 | 0.0 |
| WHO FIGHTS | 1.0 | -2.6 | 40.0 | 0.0 | - | - | - | - |
| WHO GETS IN | 0.7 | +31.8 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.7 | -0.3 | 0.0 | 0.0 | 0.3 | +9.1 | 34.7 | 0.0 |
| WHOLE FIGHT DANGER | 3.0 | -258.4 | 0.0 | 138.7 | 2.3 | -36.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.3 | +20.7 | 133.3 | 15.0 |
| WHOLE FIGHT REACTION | 4.3 | +312.7 | 15.0 | 197.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 7.0 | +107.3 | 0.0 | 0.0 | 2.0 | +63.8 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p18

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 289 | 275 | 88 | 29.33 | +2472 | +28.1 |
| ARMY TABLE | 96 | 96 | 82 | 27.33 | +2063 | +25.2 |
| HOLDER ASSIGNMENT | 81 | 81 | 75 | 25.00 | +3822 | +51.0 |
| HIS SHOTS BY HIS RUN | 286 | 272 | 67 | 22.33 | +793 | +11.8 |
| OFF BEST | 40 | 40 | 40 | 13.33 | -1282 | -32.1 |
| GOAL WALK | 81 | 81 | 33 | 11.00 | +2076 | +62.9 |
| DEPLOY BY FIGURES | 54 | 54 | 29 | 9.67 | +367 | +12.6 |
| SHOT RISK POINTS | 200 | 198 | 29 | 9.67 | +907 | +31.3 |
| STAY WORTH | 198 | 176 | 23 | 7.67 | +63 | +2.8 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| NO CHAFF EDGES | 24 | 24 | 20 | 6.67 | +298 | +14.9 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 18 | 6.00 | +0 | +0.0 |
| FIVE ACTION | 588 | 567 | 17 | 5.67 | +679 | +40.0 |
| NEXT CHARGE BY LIST | 21 | 18 | 15 | 5.00 | +844 | +56.2 |
| CAST JOB | 20 | 20 | 14 | 4.67 | +128 | +9.2 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 14 | 4.67 | -644 | -46.0 |
| TIME ON OUR SIDE | 132 | 109 | 14 | 4.67 | +80 | +5.7 |
| MEETS IN TIME | 25 | 25 | 13 | 4.33 | +1148 | +88.3 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 133 | 132 | 12 | 4.00 | +1811 | +150.9 |
| IDLE COST | 60 | 34 | 12 | 4.00 | +120 | +10.0 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 19 | 13 | 12 | 4.00 | +651 | +54.2 |
| FOUR ROUNDS | 25 | 25 | 11 | 3.67 | +328 | +29.8 |
| FALLS SHORT | 96 | 70 | 10 | 3.33 | +83 | +8.3 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 10 | 10 | 10 | 3.33 | +593 | +59.3 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +799 | +88.8 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 8 | 2.67 | +88 | +11.0 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1166 | +166.5 |
| MARCH CHECK | 9 | 8 | 7 | 2.33 | +144 | +20.6 |
| MISSILES IN THE MOVE | 32 | 25 | 7 | 2.33 | +181 | +25.8 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +10 | +1.4 |
| TIED UP BY THE SUM | 7 | 7 | 7 | 2.33 | +177 | +25.3 |
| COVER ONCE | 54 | 36 | 6 | 2.00 | +257 | +42.8 |
| GUN MASK | 12 | 12 | 6 | 2.00 | +227 | +37.9 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +324 | +53.9 |
| QUARTER ODDS | 51 | 49 | 6 | 2.00 | +359 | +59.8 |
| SHOTS IN THE MOVE | 131 | 106 | 6 | 2.00 | +90 | +15.0 |
| WOUNDS ON THE RANKS | 27 | 27 | 6 | 2.00 | +61 | +10.2 |
| MAX FOR POSITIONING | 21 | 18 | 5 | 1.67 | +84 | +16.8 |
| RISK BY ARC | 18 | 18 | 5 | 1.67 | +46 | +9.3 |
| SET UP BY THE SET | 13 | 12 | 5 | 1.67 | +137 | +27.4 |
| STRIKE BY THE ODDS | 5 | 5 | 5 | 1.67 | +78 | +15.7 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +502 | +125.5 |
| ONE OBJECTIVE FORMULA | 28 | 22 | 4 | 1.33 | +208 | +52.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 4 | 1.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 5 | 5 | 4 | 1.33 | +5 | +1.3 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 5 | 3 | 1.00 | +1 | +0.2 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 7 | 7 | 3 | 1.00 | +110 | +36.8 |
| MANOEUVRE | 8 | 8 | 3 | 1.00 | +53 | +17.7 |
| NEARER NOT NEEDED | 36 | 34 | 3 | 1.00 | +136 | +45.2 |
| PROMISE KNOWS THE FIGHT | 7 | 6 | 3 | 1.00 | -55 | -18.2 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT ADDS | 9 | 8 | 3 | 1.00 | +160 | +53.3 |
| SUPPORT WORKED OUT | 9 | 8 | 3 | 1.00 | +160 | +53.3 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +21 | +10.5 |
| BACKS UP THE FIGHT | 3 | 2 | 2 | 0.67 | +121 | +60.6 |
| FACES WHAT IT FOLLOWS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS MOVE AND SHOT | 62 | 62 | 2 | 0.67 | +8 | +4.2 |
| HONEST WORTH | 17 | 17 | 2 | 0.67 | +198 | +99.1 |
| INFANTRY NOT BEHIND INFANTRY | 2 | 2 | 2 | 0.67 | +360 | +180.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -56 | -27.9 |
| OPENS UP IN FULL | 6 | 6 | 2 | 0.67 | +28 | +13.8 |
| OVERRUNS AWAY | 5 | 5 | 2 | 0.67 | +35 | +17.3 |
| REDIRECT COUNTER | 10 | 7 | 2 | 0.67 | +14 | +6.8 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +23 | +11.6 |
| SCOUT BY DROPS | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 5 | 5 | 2 | 0.67 | +99 | +49.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -117 | -58.4 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +9 | +4.3 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -13 | -6.6 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +95 | +47.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +172 | +171.5 |
| CANNON PLANNED TARGET | 28 | 28 | 1 | 0.33 | -3 | -3.2 |
| CASTING BLOCK | 4 | 4 | 1 | 0.33 | +4 | +3.8 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -135 | -134.6 |
| CHARGE NOW FIRST | 10 | 10 | 1 | 0.33 | -12 | -12.3 |
| EXACT ROUND | 15 | 15 | 1 | 0.33 | +15 | +15.2 |
| FALL BACK GOOD ORDER | 14 | 14 | 1 | 0.33 | +11 | +10.8 |
| FIGHT TO THE END | 6 | 6 | 1 | 0.33 | +33 | +33.1 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +25 | +24.7 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HUNT IN PAIRS | 4 | 2 | 1 | 0.33 | +43 | +43.0 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +13 | +12.8 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +147 | +146.6 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +217 | +217.2 |
| LONG SHOT | 2 | 2 | 1 | 0.33 | +2 | +2.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -39 | -38.9 |
| NO DOUBLE ROUNDS | 19 | 19 | 1 | 0.33 | +111 | +110.9 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -71 | -71.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +302 | +301.8 |
| ROUNDS AFTER TERROR | 5 | 5 | 1 | 0.33 | +12 | +12.4 |
| SET UP TOGETHER | 10 | 8 | 1 | 0.33 | +24 | +24.5 |
| WHOLE FIGHT REACTION | 13 | 13 | 1 | 0.33 | +8 | +7.7 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 18 | 18 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 68 | 67 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 18 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 8 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 75 | 74 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 33 | 33 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 44 | 40 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 56 | 49 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 111 | 108 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 6 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 13 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 10 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 44 | 31 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 32 | 19 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 76 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 26 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 253 | 243 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE FIGHT MOVES | 15 | 15 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 3 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 266 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 16 | 16 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p18

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 8.33 | 3.00 | 34.8 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 0.67 | 46.0 |
| ARMY TABLE | rule | 1.67 | 1.67 | 17.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | 2.67 | 27.7 |
| NO REASON | gate | - | 1.67 | 13.8 |
| JOINT CHARGE NOW | rule | 0.67 | 0.33 | 8.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | 0.33 | 18.2 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 58.4 |
| WAR ENGINE JOBS | rule | 0.67 | - | 6.6 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 3.2 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 134.6 |
| CHARGE NOW FIRST | rule | - | 0.33 | 12.3 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 1.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 38.9 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 163.9 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 71.1 |
| RULE SWITCHED OFF | gate | 0.33 | - | 30.2 |

### Plans: nw22-19bea9b-p18

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 112 | 109 | 97% |
| Mine | join | 0.3 | 100% | 4 | 0 | 0% |
| Mine | move | 25.3 | 97% | 1532 | 0 | 0% |
| Mine | shoot | 16.0 | 50% | 1097 | 1062 | 97% |
| Opponent | charge | 3.0 | 56% | 345 | 280 | 81% |
| Opponent | move | 34.7 | 92% | 1916 | 0 | 0% |
| Opponent | shoot | 7.0 | 52% | 449 | 85 | 19% |
| Opponent | support | 1.0 | 67% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p18

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 30% | 100% | 0% | - | 0% | 0% | 33% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p18

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 41 (12) | 41 | 0 | 0 | 33% | 3.0 | 123 (3) | 5 (5) | 0 (4) | 54 (8) | 5 (4) |
| Mine | Clean-up | 1 | 70 (1) | 0 | 70 | 0 | 0% | 6.0 | - | - | 70 (1) | 70 (1) | - |
| Mine | Fast Hammer | 3 | 127 (3) | 10 | 116 | 29 | 33% | 2.0 | - | 101 (2) | 172 (1) | 178 (2) | 0 (1) |
| Mine | Hammer | 8 | 13 (8) | 0 | 13 | 15 | 38% | 2.8 | - | 7 (6) | 38 (2) | 11 (6) | 22 (2) |
| Mine | Shooter | 6 | 155 (6) | 35 | 120 | 50 | 0% | 1.3 | 0 (1) | 305 (2) | 107 (3) | 155 (6) | - |
| Mine | War machine | 8 | 24 (8) | 24 | 0 | 35 | 0% | 1.2 | 187 (1) | 0 (1) | 3 (6) | - | 24 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Opponent | Chaff | 11 | 136 (11) | 0 | 136 | 55 | 55% | 2.8 | 0 (4) | 825 (1) | 114 (6) | 136 (11) | - |
| Opponent | Character | 6 | 23 (6) | 23 | 0 | 24 | 0% | 2.0 | 26 (5) | 0 (1) | - | 34 (3) | 15 (3) |
| Opponent | Clean-up | 4 | 53 (4) | 39 | 14 | 0 | 25% | 1.7 | - | 123 (1) | 30 (3) | 60 (2) | 46 (2) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 21 (10) | 18 | 3 | 32 | 20% | 2.6 | 34 (2) | 11 (6) | 40 (2) | 20 (8) | 32 (2) |
| Opponent | Holder | 1 | 101 (1) | 0 | 101 | 0 | 100% | - | - | 101 (1) | - | 101 (1) | - |
| Opponent | Shooter | 1 | 188 (1) | 0 | 188 | 0 | 0% | 1.0 | - | 188 (1) | - | 188 (1) | - |

### Charged fights: nw22-19bea9b-p18

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 240 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 0 | 719 | 5.0 | 1.4 | 144 | 0 | +144 | 1 of 5 | 5 of 5 | +30 | +220 |
| **Mine** | all armies | 3 | 160 | 240 | 1.7 | 1.4 | 144 | 0 | +144 | 1 of 5 | 5 of 5 | +30 | +220 |
| Opponent | Ogre Kingdoms | 1 | 125 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 0 of 2 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 135 | 3.0 | 1.3 | 45 | 15 | +30 | 2 of 3 | 1 of 3 | -45 | +68 |
| Opponent | Wood Elf Realms | 1 | 0 | 723 | 8.0 | 1.2 | 90 | 0 | +90 | 2 of 8 | 7 of 8 | +265 | +65 |
| **Opponent** | all armies | 3 | 42 | 286 | 4.3 | 1.2 | 66 | 3 | +63 | 4 of 13 | 8 of 13 | +110 | +54 |

### Effective charges: nw22-19bea9b-p18

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 5 | 1 (net +599) | 0 | 0 | 1 (net +0) | 1 (net +60) | 2 (net +30) | 0 | 0% (0 of 5) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 1 (net +135) | 0 | 0 | 1 (net -45) | 1 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 8 | 0 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +125) | 4 (net +118) | 0 | 12% (1 of 8) |

### Charged fights, damage counted: nw22-19bea9b-p18

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 369 | 499 | +599 | 599 | 53 | +546 | +148.0 |
| Mine | 76-89% | 1 | 205 | 329 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 252 | 194 | +30 | 108 | 56 | +52 | +20.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 703 | 60 | +60 | 60 | 0 | +60 | +8.5 |
| Mine | All fights | 5 | 356 | 255 | +144 | 175 | 33 | +142 | +39.9 |
| Opponent | Effective (55-75%) | 2 | 100 | 181 | +68 | 105 | 9 | +96 | +95.8 |
| Opponent | 76-89% | 1 | 109 | 104 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 317 | 189 | +86 | 95 | 22 | +73 | +22.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 499 | 125 | +125 | 125 | 0 | +125 | +25.1 |
| Opponent | No odds | 3 | 208 | 209 | +0 | 27 | 12 | +16 | +7.5 |
| Opponent | All fights | 13 | 271 | 176 | +63 | 78 | 12 | +66 | +24.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p18 | move | 19 | 4 (21%) | 3 (16%) | 2 (11%) | 13 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

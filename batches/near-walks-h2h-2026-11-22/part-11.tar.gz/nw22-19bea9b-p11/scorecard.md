# Doctrine scorecard: nw22-19bea9b-p11

### Scorecard: nw22-19bea9b-p11

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 3 | - | 0 | 2 | 0 | 0 | 0 | 410 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 3 | 1 | 2 | 2 | 0 | 0 | 757 |
| L2335 | 1 | 1 | Mine | no | 4 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 3.5 | 3.0 | 2.0 | 0.7 | 0.7 | 0.0 | 0.0 | 136.7 |
| **Average** | | | Opponent | 0% | 0.0 | 2.3 | 2.7 | 1.7 | 0.7 | 0.0 | 0.0 | 252.3 |

### KPIs: nw22-19bea9b-p11

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 12% (2 of 16) | 0% (0 of 18) | 6% (2 of 34) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 3); on the table 0% | - | 0% (0 of 3); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 50% (3 of 6); on the table 50% | 100% (3 of 3); on the table 100% | 67% (6 of 9); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 83% (5 of 6) | 56% (10 of 18) | 62% (15 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 83% (5 of 6) | 56% (10 of 18) | 62% (15 of 24) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (6 of 10) | 33% (2 of 6) | 50% (8 of 16) |
| Points that never fought | lower | 37% (2232 of 5999) | 33% (1951 of 6000) | 35% (4183 of 11999) |
|   infantry points that never fought | lower | 78% (1218 of 1552) | 17% (174 of 1035) | 54% (1392 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (11 of 19) | 77% (23 of 30) | 69% (34 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (2614 of 4484) | 65% (3585 of 5546) | 62% (6199 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (100%) | 2.7 (100%) | 3.0 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 11.3 | 1.3 | 1.7 | 5.0 | 0.7 | 0.0 |
| not cast | 2.7 | 0.7 | 0.3 | 3.0 | 1.3 | 16.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 3.0 (100%) | 1.3 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (50%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 40% (2 of 5) | 40% (2 of 5) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 50% (1 of 2) | 50% (1 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 50% (1 of 2) | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (84 of 118) | 65% (22 of 34) | 70% (106 of 152) |
|   cavalry | 92% (22 of 24) | 73% (11 of 15) | 85% (33 of 39) |
|   character | 0% (0 of 20) | 33% (2 of 6) | 8% (2 of 26) |
|   chariot | 100% (10 of 10) | - | 100% (10 of 10) |
|   infantry | 81% (52 of 64) | 69% (9 of 13) | 79% (61 of 77) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (24%) | 3.0 (75%) | 5.7 (37%) |
| CHARGED: it charged | 2.3 (21%) | 0.7 (17%) | 3.0 (20%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.3 (38%) | 0.0 (0%) | 4.3 (28%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (18%) | 0.0 (0%) | 2.0 (13%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 17.0 | 2.7 | 88% | 4.3 pts | 74 pts |
| character | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.7 | 0.3 | 91% | 3.5 pts | 13 pts |
| infantry | 23.0 | 6.7 | 81% | 6.7 pts | 154 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.3 | 3.7 | 4.5 |
| Charges that made contact a game | 4.0 | 2.7 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.38 contact (32 units) | 0.36 declared, 0.24 contact (25 units) | 0.44 declared, 0.32 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 86% (6 of 7) | 100% (1 of 1) | 0% (0 of 1) | 78% (7 of 9) |
| Character in a unit | 75% (3 of 4) | 100% (1 of 1) | 100% (1 of 1) | 83% (5 of 6) |
| Character on its own | 75% (3 of 4) | - | 43% (3 of 7) | 55% (6 of 11) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 64% (7 of 11) | 0% (0 of 1) | - | 58% (7 of 12) |
| Monster | 67% (4 of 6) | 100% (1 of 1) | - | 71% (5 of 7) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 83% (5 of 6) | 22% | 67% (6 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 25% (1 of 4); on the table 25% | - | 45% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 49% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 26% | 83% (10 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 67% (4 of 6) | 22% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p11, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 67% (4) | 55% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: nw22-19bea9b-p11

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 67% (10 of 15) | 27% (3 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 55% (18 of 33) | 12% (1 of 8) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 0% (0 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 50% (3 of 6) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 75% (3 of 4) | 67% (6 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 1.7 |
| Movement | Points that never moved of their own | 136.7 | 252.3 |
| Movement | Fights charged into per game | 3.7 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 11 | 1 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 11, net +354 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 11, net +126 | 3 of 6, net +120 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 11, net +67 | 2 of 6, net +202 |
| Shooting | Shots by shooting units (incl. breath weapons) | 29.3 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 26% (23 of 88) | 73% (16 of 22) |
| Shooting | Points destroyed by shooting units | 38.7 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 40% (2 of 5) |
| Magic | Wounds caused by magic missiles | 2.0 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 24.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.0 / 0.0 / 0.0 / 0.0 | 3.7 / 0.7 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 367.7 | 250.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +151 | +84 |
| Combat | Net per 100 charger points, damage counted | +49.1 | +23.7 |
| Combat | First round won (charged fights) | 100% | 86% |
| Combat | Net points per charged fight | +154 | +102 |
| Combat | Net points per supported fight / lone fight | +116 / +158 | +145 / +95 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 11 | 4 of 7 |
| Game | Points lost | 344.0 | 730.0 |
| Game | VP from objectives | 1133.3 | 416.7 |
| Game | Lone holders (player turns) | 3.5 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1166 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1074
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: nw22-19bea9b-p11

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +0.5 | 0.0 | 65.0 | - | - | - | - |
| ARMY TABLE | 33.0 | +471.4 | 0.0 | 165.0 | 27.7 | +179.8 | 0.0 | 510.0 |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +4.2 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST FACING | - | - | - | - | 0.3 | +29.7 | 0.0 | 38.7 |
| CARRIES OUT SET-UP | 0.7 | -88.8 | 38.7 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 1.7 | +37.0 | 130.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.3 | +4.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 2.0 | +49.2 | 0.0 | 24.0 | 0.7 | +17.5 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -0.6 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +1.2 | 0.0 | 0.0 | 1.3 | +66.4 | 0.0 | 122.0 |
| CHARACTER GUNS | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.7 | -139.3 | 83.7 | 65.0 | 0.3 | -0.4 | 0.0 | 16.7 |
| CHARGE LOSSES | 18.7 | -475.5 | 0.0 | 521.7 | 32.7 | -2074.4 | 0.0 | 857.7 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 298.0 | 65.0 | 1.7 | +0.0 | 118.3 | 77.3 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.7 | +0.0 | 0.0 | 118.3 | 9.7 | +0.0 | 0.0 | 125.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 83.7 | 70.0 | 0.7 | +0.0 | 70.0 | 25.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +117.3 | 0.0 | 0.0 |
| COVER ONCE | 10.7 | -620.2 | 0.0 | 130.0 | 12.0 | -520.9 | 0.0 | 321.0 |
| DENIED BY THE FIGHT | 1.0 | -4.6 | 93.3 | 0.0 | 0.3 | -0.3 | 0.0 | 38.7 |
| DEPLOY BY FIGURES | 8.7 | +49.0 | 0.0 | 0.0 | 7.3 | +77.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -0.8 | 41.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 3.7 | +313.2 | 0.0 | 0.0 |
| EXACT ROUND | 2.7 | +84.1 | 272.3 | 65.0 | 3.0 | +15.8 | 238.3 | 38.7 |
| FACES THE THREAT | - | - | - | - | 0.3 | +36.5 | 0.0 | 38.7 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 5.0 | +70.9 | 456.0 | 65.0 | 1.7 | +0.0 | 23.3 | 55.3 |
| FALLS SHORT | 1.7 | +14.6 | 0.0 | 0.0 | 23.3 | +296.6 | 0.0 | 282.0 |
| FEATURE BUFFS | 2.7 | +17.2 | 0.0 | 0.0 | 1.3 | +4.7 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +54.7 | 70.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 114.0 | +10577.1 | 1224.3 | 729.7 | 89.0 | +3816.7 | 563.3 | 1340.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 112.3 | 13.0 | +0.0 | 0.0 | 261.0 |
| FOLLOW UP WEIGHED | 1.7 | +113.0 | 0.0 | 0.0 | 1.3 | +218.7 | 0.0 | 38.7 |
| FOUR ROUNDS | 5.3 | +441.3 | 512.7 | 65.0 | 3.7 | +221.9 | 303.3 | 55.3 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 48.3 | 15.3 | +0.0 | 0.0 | 237.0 |
| FRIEND SHOOTS FIRST | 1.7 | -19.3 | 77.3 | 0.0 | 1.0 | -6.3 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -10.0 | 83.3 | 0.0 | 1.0 | -8.0 | 161.7 | 0.0 |
| GOAL WALK | 10.7 | +1286.2 | 0.0 | 0.0 | 13.0 | +625.8 | 0.0 | 166.7 |
| GUN FIGURES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | -1.3 | 75.3 | 0.0 | 0.3 | -0.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 46.7 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 48.3 | 12.3 | +0.0 | 0.0 | 237.0 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 16.7 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 521.7 | 18.7 | +0.0 | 0.0 | 633.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +78.6 | 65.0 | 38.7 |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 56.7 |
| HIS LEGAL MOVES | 6.3 | +0.0 | 0.0 | 260.0 | 6.7 | +0.0 | 0.0 | 38.0 |
| HIS MOVE AND SHOT | 4.7 | -15.6 | 0.0 | 130.0 | 6.0 | -88.7 | 0.0 | 140.3 |
| HIS ONE QUARTER | 9.7 | +0.0 | 0.0 | 46.7 | 8.3 | +0.0 | 0.0 | 154.7 |
| HIS OWN BEST MOVE | 12.0 | +0.0 | 0.0 | 260.0 | 9.0 | +0.0 | 0.0 | 38.0 |
| HIS RANDOM MOVE | 11.0 | +0.0 | 0.0 | 48.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.7 | +481.7 | 0.0 | 414.7 | 54.7 | +955.8 | 0.0 | 1158.0 |
| HIS SHOTS BY HIS RUN | 37.3 | +484.9 | 0.0 | 401.3 | 60.7 | +717.2 | 0.0 | 1023.7 |
| HIS TURN DENIED | 1.0 | +12.1 | 93.3 | 0.0 | 0.3 | +0.3 | 0.0 | 16.7 |
| HOLD ODDS | 26.3 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 73.3 |
| HOLDER ASSIGNMENT | 17.3 | +1290.2 | 0.0 | 0.0 | 9.7 | +829.1 | 0.0 | 36.7 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -147.5 | 387.3 | 0.0 | 3.0 | -97.1 | 303.3 | 0.0 |
| IDLE COST | 2.0 | -38.9 | 0.0 | 65.0 | 18.0 | -185.2 | 0.0 | 160.0 |
| JOINT CHARGE NOW | 1.3 | -84.7 | 132.0 | 0.0 | 1.3 | -7.9 | 48.3 | 16.7 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +41.4 | 0.0 | 0.0 | 0.7 | +2.4 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 194.0 | 65.0 | 5.7 | +0.0 | 200.0 | 284.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.3 | +4.1 | 242.3 | 65.0 | 0.7 | +0.0 | 0.0 | 38.7 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +7.7 | 0.0 | 0.0 | 0.7 | +6.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | -8.3 | 0.0 | 0.0 | 1.3 | -2.8 | 0.0 | 83.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +5.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | -32.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +27.8 | 0.0 | 0.0 | 3.7 | +47.9 | 0.0 | 161.0 |
| MEETS IN TIME | 4.0 | +218.7 | 0.0 | 0.0 | 4.0 | +488.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +64.9 | 0.0 | 0.0 | 5.3 | +102.4 | 0.0 | 206.0 |
| MISSILES NEXT TURN | 1.7 | +34.0 | 0.0 | 0.0 | 6.3 | +69.6 | 0.0 | 206.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 41.7 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -28.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.0 | +1390.4 | 0.0 | 260.0 | 9.3 | +577.1 | 0.0 | 0.0 |
| NEAR WALKS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 15.0 | +638.5 | 0.0 | 0.0 | 8.3 | +350.3 | 0.0 | 167.3 |
| NEXT CHARGE BY LIST | 6.7 | +923.4 | 116.0 | 130.0 | 7.0 | +573.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -32.5 | 0.0 | 0.0 | 1.7 | -59.5 | 65.0 | 0.0 |
| NO CHAFF EDGES | 4.3 | +99.8 | 436.0 | 65.0 | 4.0 | +209.3 | 250.0 | 36.7 |
| NO DOUBLE ROUNDS | 4.7 | -292.8 | 449.0 | 65.0 | 3.0 | -124.6 | 280.0 | 38.7 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +1.7 | 0.0 | 38.7 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.7 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -177.6 | 0.0 | 0.0 | 4.7 | -108.9 | 0.0 | 83.7 |
| ONE FIGHT FORMULA | 6.0 | -165.1 | 0.0 | 130.0 | 8.3 | -101.8 | 0.0 | 140.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -39.8 | 0.0 | 16.7 |
| ONE OBJECTIVE FORMULA | 10.3 | -39.6 | 0.0 | 0.0 | 3.0 | -14.7 | 0.0 | 36.7 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +23.5 | 38.7 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 3.3 | +95.5 | 436.0 | 65.0 | 1.3 | +86.9 | 185.0 | 0.0 |
| OVERRUNS AWAY | 1.7 | +17.5 | 213.7 | 65.0 | 0.7 | +13.9 | 96.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | -2.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.7 | -3.3 | 0.0 | 0.0 | 0.3 | -0.9 | 0.0 | 0.0 |
| PLAN RESULT | 51.7 | +525.0 | 312.7 | 558.0 | 43.7 | +316.1 | 479.3 | 1118.7 |
| PROMISE BY ITS OWN SUM | 13.0 | -888.2 | 0.0 | 130.0 | 12.0 | -132.1 | 0.0 | 0.0 |
| PROMISE HOLDS THE SPOT | 0.3 | +34.7 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 3.7 | -2.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -4.3 | 0.0 | 0.0 | 0.3 | -4.7 | 0.0 | 0.0 |
| QUARTER ODDS | 32.7 | +3613.5 | 393.0 | 93.3 | 22.7 | +2032.0 | 153.3 | 298.0 |
| RANDOM MOVE BY FIGURES | 3.3 | +114.8 | 0.0 | 263.3 | 2.0 | +0.4 | 0.0 | 226.7 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +13.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 5.3 | +225.3 | 0.0 | 24.0 | 2.0 | +26.1 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +21.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 25.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -61.9 | 0.0 | 0.0 | 1.0 | -0.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 1.0 | +1.5 | 0.0 | 0.0 | 1.0 | +23.4 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | -43.9 | 378.7 | 65.0 | 2.3 | -80.1 | 280.0 | 38.7 |
| ROUNDS AFTER TERROR | 1.7 | -32.3 | 215.7 | 65.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| RUN DOWN | 4.0 | -94.5 | 416.0 | 65.0 | 1.7 | -0.6 | 145.0 | 0.0 |
| SAME CHARGE LATER | 0.7 | -22.9 | 77.3 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | -0.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -62.8 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +39.0 | 0.0 | 0.0 | 1.3 | -2.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -10.2 | 0.0 | 0.0 | 2.0 | -68.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +10.2 | 0.0 | 0.0 | 4.3 | +67.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +7.7 | 0.0 | 0.0 | 2.0 | +17.0 | 0.0 | 122.3 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 46.7 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +58.2 | 116.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -4.5 | 137.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 24.7 | -147.9 | 0.0 | 319.7 | 35.3 | -513.8 | 0.0 | 593.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 28.3 | +370.6 | 0.0 | 24.0 | 6.3 | +66.1 | 0.0 | 84.7 |
| SPELL WORTH | 0.3 | +0.2 | 0.0 | 0.0 | 4.0 | +4.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 280.0 | 8.7 | +0.0 | 0.0 | 316.0 |
| STAND AND SHOOT | 0.7 | -10.1 | 93.3 | 0.0 | 1.0 | -2.8 | 145.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 49.0 | +0.0 | 711.7 | 70.0 | 20.3 | +0.0 | 260.0 | 328.0 |
| STAY WORTH | 25.3 | +76.6 | 402.3 | 0.0 | 9.0 | -25.2 | 130.0 | 76.0 |
| STRIKE BY THE ODDS | 0.3 | +79.3 | 83.7 | 65.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | 1.3 | -3.5 | 0.0 | 0.0 | 2.0 | -7.0 | 0.0 | 0.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 48.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.0 | +866.0 | 0.0 | 0.0 | 10.3 | +734.3 | 0.0 | 194.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| SUPPORT WORKED OUT | 8.0 | +866.0 | 0.0 | 0.0 | 10.3 | +734.3 | 0.0 | 194.7 |
| SURE REACH TOGETHER | 1.3 | +16.6 | 0.0 | 65.0 | 3.7 | +23.8 | 0.0 | 161.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +4.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 23.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.7 | +35.7 | 177.0 | 65.0 | 0.3 | -0.1 | 65.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 83.3 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 122.3 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 167.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 51.7 | +0.0 | 0.0 | 200.7 | 42.7 | +0.0 | 0.0 | 567.7 |
| TIED UP BY THE SUM | 1.3 | +164.1 | 125.0 | 0.0 | 1.7 | +160.9 | 215.0 | 0.0 |
| TIME ON OUR SIDE | 54.3 | +475.2 | 226.7 | 89.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 1.0 | +1.3 | 0.0 | 83.7 |
| WAITS AGAIN | 3.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | +7.0 | 135.3 | 65.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +10.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 5.3 | -323.7 | 0.0 | 368.3 | 5.3 | -1461.1 | 0.0 | 464.7 |
| WHOLE FIGHT GAIN | 0.3 | +5.3 | 0.0 | 0.0 | 0.7 | +12.7 | 0.0 | 16.7 |
| WHOLE FIGHT REACTION | 1.0 | +266.4 | 16.7 | 0.0 | 1.7 | +146.6 | 65.0 | 205.7 |
| WOUNDS ON THE RANKS | 1.7 | +2.2 | 0.0 | 0.0 | 8.3 | +103.5 | 0.0 | 334.7 |

### Rule changes: nw22-19bea9b-p11

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 182 | 182 | 120 | 40.00 | +1397 | +11.6 |
| HOLDER ASSIGNMENT | 81 | 81 | 74 | 24.67 | +3312 | +44.8 |
| FIVE ACTION | 609 | 583 | 55 | 18.33 | +2819 | +51.3 |
| HIS SHOTS BY HIS RUN | 294 | 276 | 44 | 14.67 | +462 | +10.5 |
| HIS SHOT LIST | 286 | 272 | 41 | 13.67 | +590 | +14.4 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -860 | -27.7 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 75 | 75 | 28 | 9.33 | -3061 | -109.3 |
| DEPLOY BY FIGURES | 48 | 48 | 27 | 9.00 | +251 | +9.3 |
| LEGAL CHARGES ONLY | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 58 | 47 | 26 | 8.67 | +1011 | +38.9 |
| QUARTER ODDS | 166 | 159 | 26 | 8.67 | +1790 | +68.8 |
| SUPPORT ADDS | 55 | 53 | 24 | 8.00 | +1638 | +68.2 |
| SUPPORT WORKED OUT | 55 | 53 | 24 | 8.00 | +1638 | +68.2 |
| NEXT CHARGE BY LIST | 41 | 39 | 22 | 7.33 | +956 | +43.5 |
| REDIRECT FOR A FRIEND IN REACH | 16 | 16 | 16 | 5.33 | +59 | +3.7 |
| GOAL WALK | 71 | 71 | 14 | 4.67 | +681 | +48.6 |
| NO CHAFF EDGES | 25 | 25 | 13 | 4.33 | +501 | +38.5 |
| MEETS IN TIME | 24 | 24 | 11 | 3.67 | +567 | +51.5 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SHOT RISK POINTS | 180 | 173 | 11 | 3.67 | +173 | +15.7 |
| STAY WORTH | 103 | 88 | 11 | 3.67 | +51 | +4.7 |
| COVER ONCE | 68 | 45 | 9 | 3.00 | +263 | +29.2 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +995 | +110.6 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | -278 | -34.7 |
| RANDOM MOVE BY FIGURES | 16 | 16 | 8 | 2.67 | +345 | +43.2 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 11 | 11 | 7 | 2.33 | +904 | +129.1 |
| FOUR ROUNDS | 27 | 25 | 7 | 2.33 | +303 | +43.3 |
| IDLE COST | 60 | 32 | 7 | 2.33 | +19 | +2.6 |
| TIED UP BY THE SUM | 9 | 9 | 7 | 2.33 | +371 | +53.0 |
| TIME ON OUR SIDE | 163 | 139 | 7 | 2.33 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +131 | +21.9 |
| MAIN BODY KEEPS ITS BAND | 6 | 6 | 6 | 2.00 | +1361 | +226.8 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +75 | +12.5 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 6 | 2.00 | +50 | +8.3 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +203 | +40.5 |
| CHARGE LOSSES | 154 | 145 | 5 | 1.67 | +191 | +38.2 |
| SEARCH SPOT | 7 | 7 | 5 | 1.67 | +124 | +24.7 |
| CHAFF IN THE MOVE | 8 | 7 | 4 | 1.33 | +69 | +17.4 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| MISSILES IN THE MOVE | 21 | 14 | 4 | 1.33 | +83 | +20.7 |
| SCOUTS HUNT GUNS ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 15 | 14 | 4 | 1.33 | +8 | +1.9 |
| WHOLE FIGHT DANGER | 32 | 30 | 4 | 1.33 | +61 | +15.4 |
| CHARGE NOW FIRST | 13 | 13 | 3 | 1.00 | -85 | -28.3 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 17 | 17 | 3 | 1.00 | +0 | +0.1 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 1.00 | -12 | -4.1 |
| PROMISE KNOWS THE FIGHT | 11 | 8 | 3 | 1.00 | -6 | -2.2 |
| RISK BY ARC | 19 | 18 | 3 | 1.00 | +74 | +24.7 |
| SCOUT BY DROPS | 5 | 5 | 3 | 1.00 | +0 | +0.0 |
| SET UP BY THE SET | 15 | 15 | 3 | 1.00 | +162 | +54.1 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| CAST JOB | 5 | 5 | 2 | 0.67 | +91 | +45.4 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -2 | -0.9 |
| FIGHT TO THE END | 2 | 2 | 2 | 0.67 | +60 | +30.2 |
| NEARER NOT NEEDED | 70 | 66 | 2 | 0.67 | +42 | +21.0 |
| NEXT OBJECTIVE NEARER | 7 | 7 | 2 | 0.67 | +53 | +26.6 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -8 | -3.9 |
| REDIRECT COUNTER | 22 | 18 | 2 | 0.67 | +24 | +11.8 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +146 | +73.0 |
| SHOTS AFTER THE MOVES | 13 | 13 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 104 | 71 | 2 | 0.67 | +30 | +15.2 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 17 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 30 | 30 | 2 | 0.67 | +20 | +10.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BEST FACING | 1 | 1 | 1 | 0.33 | +89 | +89.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.33 | -266 | -266.4 |
| CASTING BLOCK | 1 | 1 | 1 | 0.33 | +8 | +8.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 17 | 16 | 1 | 0.33 | +158 | +158.4 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +109 | +109.4 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 20 | 18 | 1 | 0.33 | +101 | +100.7 |
| FALLS SHORT | 75 | 58 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +76 | +75.9 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +14 | +14.0 |
| MISSILES NEXT TURN | 24 | 18 | 1 | 0.33 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +2 | +2.1 |
| OPENS UP IN FULL | 14 | 14 | 1 | 0.33 | +50 | +50.3 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.33 | +104 | +104.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -14 | -13.9 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +1 | +1.4 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +158 | +158.4 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -28 | -27.5 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +12 | +12.0 |
| THE FIGHT MOVES | 6 | 5 | 1 | 0.33 | +23 | +22.7 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -11 | -10.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +18 | +18.1 |
| BACKS UP THE FIGHT | 1 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 11 | 11 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 64 | 64 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 12 | 12 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 63 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 50 | 46 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 5 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 40 | 37 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 1 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 92 | 87 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 33 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 39 | 31 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 32 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 54 | 50 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 63 | 52 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 45 | 44 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HOLD ODDS | 127 | 126 | 0 | 0.00 | - | - |
| HONEST WORTH | 23 | 21 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEAR WALKS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 23 | 21 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 43 | 20 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 40 | 27 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 7 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 286 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 15 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 9 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 39 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 50 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 208 | 198 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 10 | 10 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 283 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 13 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 3 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p11

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 4.00 | 109.3 |
| JOB FIRST | gate | 4.67 | 4.33 | 28.8 |
| ARMY TABLE | rule | 2.33 | 3.33 | 48.6 |
| HOLDER ASSIGNMENT | rule | 1.33 | 0.33 | 7.5 |
| JOINT CHARGE NOW | rule | 1.00 | 0.67 | 81.3 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 28.3 |
| PIVOT GUARDS FLANK | rule | 0.67 | 0.33 | 4.1 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 2.2 |
| RULE SWITCHED OFF | gate | 1.00 | - | 26.8 |
| CHAFF PASSED | rule | - | 0.67 | 0.9 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 266.4 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 1.5 |
| NO REASON | gate | - | 0.33 | 1.3 |
| PATHS CROSS | rule | - | 0.33 | 68.1 |
| REFUSING RETIRES | rule | 0.33 | - | 13.9 |
| SET UP BY THE SET | rule | - | 0.33 | 56.3 |
| SUPPORT NARROWED | rule | - | 0.33 | 27.5 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 10.6 |

### Plans: nw22-19bea9b-p11

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 56% | 437 | 200 | 46% |
| Mine | move | 40.0 | 97% | 3024 | 0 | 0% |
| Mine | shoot | 8.3 | 56% | 738 | 325 | 44% |
| Mine | support | 0.3 | 100% | 10 | 0 | 0% |
| Opponent | charge | 2.3 | 86% | 327 | 243 | 74% |
| Opponent | join | 2.3 | 86% | 91 | 0 | 0% |
| Opponent | move | 36.0 | 94% | 1732 | 0 | 0% |
| Opponent | shoot | 2.7 | 25% | 211 | 73 | 35% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p11

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p11

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 6 | 118 (6) | 29 | 89 | 18 | 17% | 1.4 | 0 (1) | 54 (3) | 298 (2) | 171 (3) | 60 (3) |
| Mine | Character | 6 | 25 (6) | 25 | 0 | 0 | 0% | 3.8 | 23 (2) | 29 (2) | - | 23 (2) | 29 (2) |
| Mine | Clean-up | 1 | 549 (1) | 110 | 439 | 0 | 0% | 4.0 | - | 549 (1) | - | - | 549 (1) |
| Mine | Fast Hammer | 6 | 134 (6) | 134 | 0 | 50 | 0% | 4.5 | 61 (3) | 176 (3) | - | 215 (4) | 24 (2) |
| Mine | Hammer | 5 | 53 (5) | 0 | 53 | 55 | 0% | 2.6 | 0 (3) | 118 (2) | - | 76 (3) | 28 (2) |
| Mine | Holder | 8 | 113 (8) | 12 | 101 | 0 | 25% | 2.3 | 224 (2) | 128 (4) | 0 (1) | 224 (2) | 102 (5) |
| Mine | Shooter | 5 | 0 (5) | 0 | 0 | 0 | 0% | 2.4 | 0 (2) | 0 (3) | - | 0 (3) | 0 (2) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.5 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Chaff | 4 | 25 (4) | 0 | 25 | 50 | 50% | 5.0 | 33 (3) | - | 0 (1) | 33 (3) | 0 (1) |
| Opponent | Character | 11 | 26 (11) | 26 | 0 | 32 | 36% | 3.0 | 10 (3) | 0 (5) | 45 (3) | 24 (5) | 28 (6) |
| Opponent | Fast Hammer | 6 | 24 (6) | 17 | 7 | 20 | 17% | 2.8 | 0 (1) | 34 (4) | 0 (1) | 0 (2) | 31 (4) |
| Opponent | Hammer | 8 | 0 (8) | 0 | 0 | 80 | 25% | 3.2 | - | 0 (7) | 0 (1) | 0 (6) | 0 (2) |
| Opponent | Holder | 3 | 48 (3) | 48 | 0 | 0 | 67% | 5.0 | 0 (1) | 74 (2) | - | - | 48 (3) |
| Opponent | Shooter | 3 | 41 (3) | 0 | 41 | 100 | 0% | 1.0 | - | 0 (1) | 60 (2) | 67 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: nw22-19bea9b-p11

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 120 | 2.0 | 1.0 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | - | +60 |
| Mine | Tomb Kings of Khemri | 2 | 58 | 885 | 4.5 | 1.1 | 197 | 22 | +175 | 2 of 9 | 9 of 9 | +116 | +182 |
| **Mine** | all armies | 3 | 39 | 630 | 3.7 | 1.1 | 172 | 18 | +154 | 2 of 11 | 11 of 11 | +116 | +158 |
| Opponent | Vampire Counts | 1 | 0 | 500 | 4.0 | 1.2 | 125 | 12 | +112 | 2 of 4 | 3 of 4 | +145 | +102 |
| Opponent | Warriors of Chaos | 1 | 72 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 0 | 265 | 2.0 | 1.0 | 132 | 0 | +132 | 1 of 2 | 2 of 2 | - | +132 |
| **Opponent** | all armies | 3 | 24 | 255 | 2.3 | 1.1 | 109 | 7 | +102 | 4 of 7 | 6 of 7 | +145 | +95 |

### Effective charges: nw22-19bea9b-p11

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 2 | 0 | 0 | 1 (net +45) | 0 | 0 | 1 (net +75) | 0 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 9 | 0 | 0 | 1 (net +664) | 2 (net +140) | 4 (net +126) | 2 (net +62) | 0 | 11% (1 of 9) |
| Opponent | Vampire Counts | 4 | 0 | 0 | 0 | 0 | 2 (net +145) | 1 (net +210) | 1 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +70) | 1 (net +195) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: nw22-19bea9b-p11

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 118 | 123 | +354 | 452 | 98 | +354 | +300.4 |
| Mine | 76-89% | 2 | 240 | 140 | +140 | 140 | 12 | +128 | +53.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 249 | 119 | +67 | 67 | 47 | +20 | +7.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 479 | 125 | +126 | 159 | 0 | +159 | +33.2 |
| Mine | All fights | 11 | 307 | 126 | +154 | 184 | 33 | +151 | +49.1 |
| Opponent | Long shot (under 50%) | 1 | 116 | 195 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 342 | 202 | +202 | 202 | 50 | +153 | +44.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 542 | 120 | +120 | 131 | 21 | +110 | +20.3 |
| Opponent | No odds | 1 | 50 | 222 | -50 | 0 | 50 | -50 | -100.0 |
| Opponent | All fights | 7 | 354 | 169 | +102 | 114 | 30 | +84 | +23.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p11 | move | 32 | 5 (16%) | 4 (12%) | 5 (16%) | 22 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

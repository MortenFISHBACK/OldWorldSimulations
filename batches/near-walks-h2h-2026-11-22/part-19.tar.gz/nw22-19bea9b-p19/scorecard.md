# Doctrine scorecard: nw22-19bea9b-p19

### Scorecard: nw22-19bea9b-p19

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 0 | 5 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Opponent | yes | 0 | - | 1 | 2 | 0 | 0 | 0 | 126 |
| L1228 | 4 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Opponent | no | 1 | - | 0 | 2 | 1 | 0 | 0 | 287 |
| **Average** | | | Mine | 50% | 2.0 | 2.7 | 1.7 | 1.0 | 0.0 | 0.0 | 0.0 | 110.0 |
| **Average** | | | Opponent | 50% | 0.5 | 2.0 | 0.3 | 3.0 | 0.3 | 0.0 | 0.0 | 137.7 |

### KPIs: nw22-19bea9b-p19

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (6 of 15) | 0% (0 of 10) | 24% (6 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | - | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | - | 100% (5 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 22% (16 of 72) | 28% (5 of 18) | 23% (21 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 30% (16 of 53) | 38% (5 of 13) | 32% (21 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 68% (4095 of 5998) | 72% (4344 of 6000) | 70% (8439 of 11998) |
|   infantry points that never fought | lower | 100% (730 of 730) | 68% (532 of 782) | 83% (1262 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (14 of 25) | 77% (20 of 26) | 67% (34 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 6.3 uses a game | 50% (1 of 2); 0.3 uses a game | 78% (7 of 9); 3.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (2885 of 5614) | 83% (4708 of 5644) | 67% (7593 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.0 (21%) | 0.7 (15%) | 4.7 (20%) |
| MARCHED: its unit marched | 5.3 (29%) | 0.0 (0%) | 5.3 (23%) |
| CHARGED: its unit charged | 3.0 (16%) | 0.0 (0%) | 3.0 (13%) |
| IN COMBAT: engaged in combat | 3.7 (20%) | 0.0 (0%) | 3.7 (16%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.7 (38%) | 1.7 (7%) |
| GONE: slain | 2.7 (14%) | 0.0 (0%) | 2.7 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.7 (38%) | 1.7 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (8%) | 0.3 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 3.0 | 1.0 | 7.0 | 0.0 | 3.3 |
| not cast | 1.0 | 13.0 | 5.0 | 23.0 | 4.0 | 24.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.7 (44%) | 0.3 (7%) | 4.7 (20%) | 0.7 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.3 (23%) | 1.0 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (13%) | 1.3 (33%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 3.7 (16%) | 1.0 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (15%) | 2.0 (40%) | 1.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.0 (0%) | 2.7 (21%) | 0.0 (0%) | 2.7 (12%) | 0.0 (0%) | 3.0 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.7 (13%) | 1.7 (33%) | 1.7 (7%) | 0.0 (0%) | 3.3 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (100%) | 0.0 (0%) | 1.0 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 33% (1 of 3) | 33% (1 of 3) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (31 of 48) | 59% (48 of 81) | 61% (79 of 129) |
|   cavalry | - | 78% (14 of 18) | 78% (14 of 18) |
|   character | - | 50% (6 of 12) | 50% (6 of 12) |
|   chariot | 83% (10 of 12) | 67% (8 of 12) | 75% (18 of 24) |
|   infantry | 70% (7 of 10) | 37% (10 of 27) | 46% (17 of 37) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 54% (14 of 26) | - | 54% (14 of 26) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (18%) | 1.3 (12%) | 2.3 (14%) |
| CHARGED: it charged | 0.3 (6%) | 0.3 (3%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.3 (3%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.3 (24%) | 0.0 (0%) | 1.3 (8%) |
| NO TARGET IN RANGE | 0.0 (0%) | 5.0 (45%) | 5.0 (30%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | 2.3 (21%) | 3.0 (18%) |
| SHELTERED: the target was sheltered | 2.0 (35%) | 0.0 (0%) | 2.0 (12%) |
| STUPIDITY | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 1.3 (12%) | 1.3 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 0.7 | 89% | 1.8 pts | 12 pts |
| character | 2.0 | 1.3 | 67% | 25.5 pts | 51 pts |
| chariot | 6.0 | 5.0 | 61% | 21.7 pts | 130 pts |
| infantry | 7.7 | 1.3 | 83% | 2.7 pts | 21 pts |
| monster | 3.7 | 1.3 | 73% | 13.5 pts | 49 pts |
| war machine | 5.7 | 6.0 | 53% | 27.0 pts | 153 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 1.0 | 2.8 |
| Charges that made contact a game | 2.0 | 0.7 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.67 declared, 0.83 contact (6 units) | - | 1.67 declared, 0.83 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 1.00 contact (1 units) | - | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.22 declared, 0.00 contact (9 units) | 0.12 declared, 0.08 contact (26 units) | 0.14 declared, 0.06 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | - | 75% (3 of 4) | 60% (6 of 10) |
| Character in a unit | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| Character on its own | 100% (1 of 1) | 50% (4 of 8) | 60% (3 of 5) | 57% (8 of 14) |
| Chariot | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Infantry | 50% (4 of 8) | - | - | 50% (4 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 100% (5 of 5); on the table 100% | 22% (16 of 72) | 68% | 56% (14 of 25) | 86% (6 of 7); 6.3 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 86% | 71% (5 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 0% (0 of 6) | 49% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 83% (5 of 6) | 82% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p19, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 0% (0) | 33% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: nw22-19bea9b-p19

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 31% (4 of 13) | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (14 of 35) | 87% (13 of 15) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (2 of 6) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 4) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.7 | 0.0 |
| Movement | Idle units | 1.0 | 3.0 |
| Movement | Points that never moved of their own | 110.0 | 137.7 |
| Movement | Fights charged into per game | 1.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +428 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +0 | 1 of 1, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +111 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (7 of 17) | 53% (26 of 49) |
| Shooting | Points destroyed by shooting units | 11.3 | 55.0 |
| Shooting | War machine shots | 5.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (5 of 17) | - |
| Shooting | Points destroyed by war machines | 34.0 | 123.0 |
| Magic | Magic missiles cast | 3.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (3 of 10) | 33% (1 of 3) |
| Magic | Wounds caused by magic missiles | 5.3 | 2.7 |
| Magic | Wounds caused by other spells | 3.3 | - |
| Magic | Points destroyed by magic (all spells) | 164.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 2.0 / 1.0 / 0.0 | 1.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 294.7 | 0.0 |
| Combat | Points run down | 46.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +194 | -82 |
| Combat | Net per 100 charger points, damage counted | +54.9 | -120.5 |
| Combat | First round won (charged fights) | 80% | 50% |
| Combat | Net points per charged fight | +203 | -17 |
| Combat | Net points per supported fight / lone fight | +428 / +147 | - / -17 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 1 of 2 |
| Game | Points lost | 265.3 | 895.3 |
| Game | VP from objectives | 1060.0 | 526.7 |
| Game | Lone holders (player turns) | 2.0 | 0.5 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +1230 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1161
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p19

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 7.7 | +42.1 | 0.0 | 64.7 | 19.0 | +88.2 | 0.0 | 450.7 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.7 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 0.3 | +6.7 | 0.0 | 0.0 | 0.7 | +27.9 | 0.0 | 0.0 |
| BOMBING RUN | 1.0 | +23.3 | 11.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 4.7 | +95.4 | 224.7 | 110.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.7 | +61.5 | 52.3 | 246.0 | - | - | - | - |
| CASTING BLOCK | 0.7 | +12.3 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +23.7 | 0.0 | 11.3 |
| CHAFF PASSED | - | - | - | - | 1.0 | +0.0 | 0.0 | 84.0 |
| CHARACTERS BY THEIR POINTS | 1.0 | -155.9 | 329.3 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 20.7 | -502.9 | 0.0 | 343.0 | 19.7 | -919.0 | 0.0 | 907.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 125.3 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLEAR LANE AHEAD | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 159.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +57.9 | 0.0 | 0.0 |
| COVER ONCE | 4.7 | -211.0 | 0.0 | 32.3 | 5.3 | -287.1 | 0.0 | 122.3 |
| DENIED BY THE FIGHT | 1.0 | -1.9 | 164.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | -83.3 | 0.0 | 110.0 | 7.3 | +61.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 1.0 | -6.0 | 41.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.0 | +39.9 | 273.7 | 0.0 | 0.7 | +7.1 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 4.0 | +1.1 | 582.7 | 0.0 | 0.7 | +6.7 | 0.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 8.0 | +60.5 | 0.0 | 123.0 | 10.7 | +99.8 | 0.0 | 249.7 |
| FEATURE BUFFS | 1.3 | +5.3 | 0.0 | 0.0 | 0.7 | +103.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +5.9 | 371.0 | 0.0 | 0.3 | +8.3 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 76.0 | +6105.3 | 1520.7 | 841.3 | 81.7 | +3613.7 | 822.0 | 1218.3 |
| FLANK NOT WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 109.7 |
| FOLLOW UP WEIGHED | 1.3 | +346.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 4.7 | +326.7 | 695.3 | 0.0 | 0.7 | +42.1 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 83.3 |
| FRIEND SHOOTS FIRST | 2.7 | -33.9 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.7 | +60.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.1 | 75.7 | 0.0 | - | - | - | - |
| GOAL WALK | 5.3 | +965.5 | 0.0 | 246.0 | 10.7 | +994.9 | 0.0 | 650.7 |
| GUN FIGURES | - | - | - | - | 2.3 | +0.0 | 123.0 | 0.0 |
| GUN MASK | 4.3 | +123.9 | 0.0 | 97.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 2.0 | -2.5 | 240.3 | 0.0 | 0.3 | -3.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 84.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 1.3 | +0.0 | 405.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 5.7 | +0.0 | 0.0 | 64.7 | 10.3 | +0.0 | 0.0 | 669.0 |
| HIS CHARGE DENIED | 0.3 | +6.4 | 164.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 1.0 | +0.0 | 0.0 | 32.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 329.3 |
| HIS MOVE AND SHOT | 5.7 | -64.2 | 0.0 | 32.3 | 8.0 | -71.5 | 0.0 | 118.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 95.3 |
| HIS OWN BEST MOVE | 8.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 329.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 30.3 | +1161.9 | 0.0 | 375.3 | 59.7 | +2835.9 | 0.0 | 1057.0 |
| HIS SHOTS BY HIS RUN | 29.3 | +701.0 | 0.0 | 375.3 | 45.7 | +1047.9 | 0.0 | 1125.0 |
| HIS TURN DENIED | 1.0 | +23.0 | 46.7 | 0.0 | - | - | - | - |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 129.3 | 13.7 | +0.0 | 0.0 | 275.0 |
| HOLDER ASSIGNMENT | 11.3 | +923.5 | 0.0 | 64.7 | 8.0 | +862.2 | 0.0 | 156.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -176.4 | 695.3 | 0.0 | 0.7 | -5.2 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +99.6 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 3.7 | -54.0 | 0.0 | 123.0 | 8.7 | -166.0 | 0.0 | 414.0 |
| JOINT CHARGE NOW | 2.0 | +203.6 | 556.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +37.9 | 0.0 | 0.0 | 0.3 | +25.9 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 357.7 | 32.3 | 3.7 | +0.0 | 0.0 | 648.0 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -6.9 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | +3.4 | 446.7 | 0.0 | 0.3 | +5.7 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | -15.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.3 | +53.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +67.0 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +31.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.0 | +30.7 | 0.0 | 0.0 | 0.3 | +55.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +54.4 | 0.0 | 0.0 | 2.3 | +86.1 | 0.0 | 25.0 |
| MEETS IN TIME | 1.7 | +156.8 | 0.0 | 0.0 | 2.7 | +164.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.3 | +80.0 | 0.0 | 246.0 | 3.0 | +50.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 12.0 | +109.5 | 0.0 | 246.0 | 3.7 | +37.2 | 0.0 | 119.0 |
| MOVE ORDER | 2.3 | +0.0 | 32.3 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 3.7 | -210.5 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.3 | +545.3 | 0.0 | 0.0 | 2.3 | +145.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.3 | +185.8 | 0.0 | 64.7 | 8.0 | +355.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 6.0 | +500.1 | 11.3 | 0.0 | 1.7 | +59.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -15.8 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 4.3 | +73.6 | 329.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -114.0 | 290.3 | 0.0 | 0.7 | -66.9 | 0.0 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.3 | -55.0 | 0.0 | 0.0 | 4.7 | -130.6 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 4.7 | +36.7 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -65.8 | 0.0 | 0.0 | 1.3 | -22.1 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 1.7 | +223.5 | 480.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 6.7 | -114.4 | 0.0 | 32.3 | 4.3 | -240.0 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -71.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 2.7 | +23.4 | 329.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.0 | +42.6 | 88.3 | 0.0 | - | - | - | - |
| OWN CAST FIRST | 0.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 33.3 | +783.6 | 873.7 | 187.7 | 36.0 | +439.6 | 0.0 | 985.3 |
| PRIZE BY WORTH | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 34.0 |
| PROMISE BY ITS OWN SUM | 8.0 | -84.3 | 0.0 | 0.0 | 4.0 | -146.4 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | -3.5 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.0 | -20.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 2.7 | -12.1 | 101.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.3 | +2064.1 | 683.7 | 0.0 | 8.7 | +761.6 | 0.0 | 246.7 |
| REDIRECT COUNTER | - | - | - | - | 4.0 | +121.2 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.7 | +0.0 | 0.0 | 22.7 |
| REDIRECT WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 3.7 | -110.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +20.8 | 0.0 | 0.0 | 1.0 | +13.1 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +11.8 | 379.3 | 0.0 | 0.7 | -30.3 | 0.0 | 0.0 |
| RUN DOWN | 3.3 | -26.1 | 243.7 | 0.0 | 0.7 | -7.3 | 0.0 | 0.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +8.2 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -49.7 | 0.0 | 11.3 |
| SEARCH SPOT | 0.3 | -3.4 | 0.0 | 0.0 | 1.0 | +33.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +2.4 | 41.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -3.1 | 0.0 | 0.0 | 1.3 | -7.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +6.9 | 0.0 | 0.0 | 1.3 | +19.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 12.0 | +0.0 | 0.0 | 233.0 | 5.0 | +0.0 | 0.0 | 46.7 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +26.3 | 74.0 | 0.0 | 1.3 | +13.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -86.2 | 169.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 22.0 | -392.3 | 0.0 | 343.0 | 33.7 | -296.6 | 0.0 | 607.3 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.7 | +481.0 | 0.0 | 142.3 | 18.0 | +455.3 | 0.0 | 130.7 |
| SPELL WORTH | 1.0 | +17.8 | 0.0 | 0.0 | 2.0 | +30.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.0 | +23.2 | 227.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 50.7 |
| STAND AND SHOOT | 1.3 | -8.8 | 83.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 246.0 | 2.7 | +0.0 | 0.0 | 261.3 |
| STANDS STILL | 36.3 | +0.0 | 825.3 | 466.0 | 36.0 | +0.0 | 822.0 | 261.3 |
| STAY WORTH | 27.7 | +296.3 | 567.7 | 608.3 | 18.0 | +128.1 | 822.0 | 84.0 |
| STRIKE BY THE ODDS | 0.3 | +15.2 | 164.7 | 0.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -118.8 | 0.0 | 0.0 |
| STUBBORN ONCE | 0.3 | -0.2 | 164.7 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +96.0 | 0.0 | 32.3 | 6.7 | +199.5 | 0.0 | 90.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +96.0 | 0.0 | 32.3 | 6.7 | +199.5 | 0.0 | 90.7 |
| SURE REACH TOGETHER | 0.7 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +1.1 | 0.0 | 13.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 64.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.7 | +53.6 | 446.7 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 130.3 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 13.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 33.0 | +0.0 | 0.0 | 420.7 | 39.3 | +0.0 | 0.0 | 590.7 |
| TIED UP BY THE SUM | 1.0 | +79.2 | 83.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 19.7 | +321.5 | 74.0 | 187.7 | 37.0 | +314.5 | 110.0 | 11.3 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 2.3 | +0.0 | 114.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +64.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.3 | -1.6 | 0.0 | 0.0 | 3.0 | -357.6 | 0.0 | 517.7 |
| WHOLE FIGHT GAIN | 1.7 | +104.0 | 480.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.0 | +76.3 | 11.3 | 0.0 | 2.3 | +408.5 | 0.0 | 362.7 |
| WOUNDS ON THE RANKS | 10.7 | +242.6 | 0.0 | 0.0 | 3.7 | +115.6 | 0.0 | 402.7 |

### Rule changes: nw22-19bea9b-p19

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 270 | 260 | 79 | 26.33 | +2146 | +27.2 |
| ARMY TABLE | 80 | 80 | 56 | 18.67 | +618 | +11.0 |
| HIS SHOTS BY HIS RUN | 225 | 217 | 53 | 17.67 | +870 | +16.4 |
| HOLDER ASSIGNMENT | 58 | 58 | 52 | 17.33 | +3028 | +58.2 |
| FIVE ACTION | 473 | 461 | 24 | 8.00 | +1391 | +58.0 |
| DEPLOY BY FIGURES | 40 | 40 | 21 | 7.00 | +360 | +17.1 |
| GOAL WALK | 48 | 46 | 21 | 7.00 | +3093 | +147.3 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -557 | -26.5 |
| TIME ON OUR SIDE | 170 | 150 | 21 | 7.00 | +124 | +5.9 |
| MOVE TO CHARGE COMPUTED | 29 | 25 | 19 | 6.33 | +828 | +43.6 |
| THE TABLE AGAIN | 35 | 35 | 19 | 6.33 | +0 | +0.0 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 14 | 14 | 14 | 4.67 | +110 | +7.9 |
| SHOT RISK POINTS | 167 | 158 | 14 | 4.67 | +365 | +26.1 |
| NEXT CHARGE BY LIST | 23 | 19 | 13 | 4.33 | +713 | +54.8 |
| QUARTER ODDS | 75 | 74 | 11 | 3.67 | +1108 | +100.7 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 36 | 36 | 10 | 3.33 | -692 | -69.2 |
| CAST JOB | 14 | 14 | 9 | 3.00 | +63 | +6.9 |
| SUPPORT ADDS | 27 | 27 | 9 | 3.00 | +151 | +16.7 |
| SUPPORT WORKED OUT | 27 | 27 | 9 | 3.00 | +151 | +16.7 |
| FOUR ROUNDS | 16 | 15 | 8 | 2.67 | +333 | +41.7 |
| PROMISE SHOT AWAY | 8 | 8 | 8 | 2.67 | -36 | -4.5 |
| REDIRECT FOR A FRIEND IN REACH | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 8 | 2.67 | +41 | +5.1 |
| CHARGE LOSSES | 121 | 115 | 7 | 2.33 | +206 | +29.4 |
| MEETS IN TIME | 13 | 13 | 7 | 2.33 | +64 | +9.2 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +611 | +101.8 |
| NO CHAFF EDGES | 14 | 13 | 6 | 2.00 | +151 | +25.2 |
| WOUNDS ON THE RANKS | 43 | 43 | 6 | 2.00 | +113 | +18.8 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +191 | +38.3 |
| MAX FOR POSITIONING | 16 | 14 | 5 | 1.67 | +7 | +1.4 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +102 | +20.3 |
| WAR ENGINE JOBS | 7 | 7 | 5 | 1.67 | -142 | -28.4 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +1038 | +259.6 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 4 | 4 | 4 | 1.33 | +537 | +134.3 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +197 | +49.3 |
| SET UP BY THE SET | 9 | 9 | 4 | 1.33 | +49 | +12.3 |
| BOMBING RUN | 3 | 3 | 3 | 1.00 | +70 | +23.3 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +3 | +1.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| GUN MASK | 13 | 13 | 3 | 1.00 | +50 | +16.5 |
| MARCH CHECK | 5 | 5 | 3 | 1.00 | +75 | +25.1 |
| RISK BY ARC | 12 | 11 | 3 | 1.00 | +42 | +14.0 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +99 | +33.1 |
| THE ROW IN ITS ORDER | 13 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +72 | +24.0 |
| WHOLE FIGHT REACTION | 10 | 10 | 3 | 1.00 | +90 | +30.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +34 | +17.2 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +22 | +11.0 |
| COVER ONCE | 30 | 19 | 2 | 0.67 | +98 | +49.1 |
| FALLS SHORT | 56 | 46 | 2 | 0.67 | +43 | +21.5 |
| FEATURE BUFFS | 6 | 6 | 2 | 0.67 | +73 | +36.6 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +182 | +91.0 |
| HUNT IN PAIRS | 2 | 2 | 2 | 0.67 | +278 | +138.9 |
| IDLE COST | 37 | 24 | 2 | 0.67 | +38 | +18.8 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -95 | -47.7 |
| ONE JOINT FIGURE | 5 | 5 | 2 | 0.67 | +271 | +135.3 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -213 | -106.5 |
| PROMISE KNOWS THE FIGHT | 7 | 4 | 2 | 0.67 | -10 | -5.2 |
| PROMISE READS THE TABLE | 6 | 6 | 2 | 0.67 | +37 | +18.5 |
| REDIRECT COUNTER | 12 | 7 | 2 | 0.67 | +40 | +19.8 |
| SCOUT BY DROPS | 8 | 8 | 2 | 0.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 20 | 20 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 92 | 75 | 2 | 0.67 | +74 | +37.1 |
| STAY WORTH | 137 | 126 | 2 | 0.67 | +17 | +8.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +7 | +6.6 |
| CHARGE NOW FIRST | 7 | 7 | 1 | 0.33 | -5 | -5.2 |
| EXACT ROUND | 8 | 8 | 1 | 0.33 | +29 | +29.3 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +29 | +29.3 |
| MISSILES IN THE MOVE | 28 | 19 | 1 | 0.33 | +4 | +3.7 |
| NEARER NOT NEEDED | 37 | 34 | 1 | 0.33 | +66 | +66.4 |
| OVERRUNS AWAY | 6 | 5 | 1 | 0.33 | +40 | +39.6 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -6 | -5.6 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +4 | +4.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +46 | +45.6 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.2 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +167 | +167.0 |
| WHOLE FIGHT GAIN | 5 | 5 | 1 | 0.33 | +97 | +96.8 |
| BACKS UP THE FIGHT | 3 | not checked | - | - | - | - |
| CANNON PLANNED TARGET | 14 | 14 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 45 | 44 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 13 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 24 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 13 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 48 | 46 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 17 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 14 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 41 | 40 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 89 | 89 | 0 | 0.00 | - | - |
| HONEST WORTH | 16 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 13 | 13 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 47 | 31 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 35 | 35 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 16 | 7 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 33 | 28 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 35 | 35 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP IN FULL | 8 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 208 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 11 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 51 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 23 | 22 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 217 | 210 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE FIGHT MOVES | 9 | 8 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 217 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p19

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 4.33 | 27.5 |
| ARMY TABLE | rule | 0.67 | 3.00 | 17.4 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 1.67 | 69.2 |
| PROMISE SHOT AWAY | rule | 2.67 | - | 4.5 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 9.0 |
| WAR ENGINE JOBS | rule | 1.67 | - | 28.4 |
| JOINT CHARGE NOW | rule | 1.00 | - | 51.3 |
| MARCH OF THE TABLE | rule | 0.67 | - | 47.7 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 106.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 5.2 |
| CHARGE NOW FIRST | rule | 0.33 | - | 5.2 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.33 | 3.7 |
| NO REASON | gate | - | 0.33 | 6.2 |
| OWN CAST FIRST | rule | 0.33 | - | 5.6 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 3.3 |

### Plans: nw22-19bea9b-p19

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 40% | 554 | 438 | 79% |
| Mine | move | 19.7 | 98% | 1675 | 0 | 0% |
| Mine | shoot | 10.3 | 39% | 582 | 346 | 59% |
| Opponent | charge | 0.7 | 0% | 30 | 0 | 0% |
| Opponent | move | 30.7 | 95% | 1402 | 0 | 0% |
| Opponent | shoot | 4.0 | 58% | 206 | 440 | 213% |
| Opponent | support | 0.7 | 50% | 1 | 0 | 0% |

### Battle groups: nw22-19bea9b-p19

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.0 | 17% | 100% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p19

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 55 (12) | 55 | 0 | 13 | 25% | 3.0 | 38 (1) | 75 (9) | 0 (2) | 22 (8) | 98 (4) |
| Mine | Fast Hammer | 4 | 15 (4) | 3 | 12 | 0 | 50% | 1.0 | 11 (2) | 17 (2) | - | 23 (3) | 0 (1) |
| Mine | Holder | 5 | 135 (5) | 0 | 135 | 0 | 40% | 2.7 | - | 135 (5) | - | 220 (3) | 0 (2) |
| Mine | Shooter | 2 | 110 (2) | 18 | 93 | 50 | 0% | 1.5 | 186 (1) | 35 (1) | - | 110 (2) | - |
| Mine | War machine | 6 | 10 (6) | 10 | 0 | 33 | 17% | 1.0 | 0 (1) | 21 (3) | 0 (2) | 0 (1) | 12 (5) |
| Opponent | Chaff | 6 | 188 (6) | 0 | 188 | 41 | 67% | 3.5 | 0 (3) | 1250 (1) | 0 (2) | 265 (5) | 0 (1) |
| Opponent | Character | 7 | 8 (7) | 8 | 0 | 43 | 14% | 2.0 | 0 (1) | 11 (5) | - | 18 (4) | 0 (2) |
| Opponent | Clean-up | 3 | 19 (3) | 0 | 19 | 32 | 33% | 2.5 | - | 19 (3) | - | 0 (2) | 53 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 21 (4) | 0 | 21 | 86 | 25% | 1.7 | 152 (1) | 0 (1) | 0 (2) | 24 (3) | 0 (1) |
| Opponent | Hammer | 8 | 24 (8) | 24 | 0 | 16 | 25% | 1.8 | 61 (3) | 0 (1) | 0 (4) | 49 (4) | 0 (4) |
| Opponent | Holder | 1 | 135 (1) | 0 | 135 | 100 | 0% | 2.0 | - | 135 (1) | - | 135 (1) | - |
| Opponent | Shooter | 2 | 12 (2) | 0 | 12 | 56 | 0% | 2.0 | - | 0 (1) | 21 (1) | 12 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |

### Charged fights: nw22-19bea9b-p19

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 210 | 339 | 1.7 | 1.2 | 203 | 0 | +203 | 2 of 5 | 4 of 5 | +428 | +147 |
| Opponent | Ogre Kingdoms | 1 | 534 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 178 | 0 | 0.7 | 1.0 | 0 | 17 | -17 | 1 of 2 | 1 of 2 | - | -17 |

### Effective charges: nw22-19bea9b-p19

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 5 | 1 (net +428) | 1 (net +227) | 1 (net +0) | 0 | 0 | 1 (net +111) | 1 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p19

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 713 | 494 | +428 | 675 | 143 | +532 | +74.6 |
| Mine | 50-54% | 1 | 379 | 127 | +227 | 227 | 0 | +227 | +59.9 |
| Mine | Effective (55-75%) | 1 | 233 | 251 | +0 | 29 | 181 | -152 | -65.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 205 | 111 | +111 | 111 | 0 | +111 | +54.1 |
| Mine | No odds | 1 | 233 | 125 | +250 | 250 | 0 | +250 | +107.3 |
| Mine | All fights | 5 | 353 | 222 | +203 | 258 | 65 | +194 | +54.9 |
| Opponent | Effective (55-75%) | 1 | 102 | 369 | +0 | 32 | 162 | -130 | -127.4 |
| Opponent | No odds | 1 | 34 | 150 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 2 | 68 | 260 | -17 | 16 | 98 | -82 | -120.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p19 | move | 12 | 4 (33%) | 2 (17%) | 3 (25%) | 5 (42%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

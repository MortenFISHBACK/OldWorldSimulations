# Doctrine scorecard: nw22-19bea9b-p4

### Scorecard: nw22-19bea9b-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 473 |
| L0524 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 675 |
| L0612 | 6 | 1 | Opponent | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 773 |
| L0628 | 4 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 3.0 | 0.3 | 3.3 | 0.0 | 0.0 | 0.0 | 640.3 |
| **Average** | | | Opponent | 0% | 4.0 | - | 0.0 | 2.0 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: nw22-19bea9b-p4

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 92% (12 of 13) | 0% (0 of 14) | 44% (12 of 27) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | - | - |
| Magic missiles tried each own turn | 50%+ | - | 43% (13 of 30) | 43% (13 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 45% (13 of 29) | 45% (13 of 29) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 85% (5077 of 6000) | 97% (5796 of 5998) | 91% (10873 of 11998) |
|   infantry points that never fought | lower | 89% (1993 of 2232) | 100% (694 of 694) | 92% (2687 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (19 of 27) | 61% (14 of 23) | 66% (33 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (2814 of 4232) | 67% (3870 of 5787) | 67% (6684 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (24%) | 1.3 (24%) |
| MARCHED: its unit marched | - | 3.3 (59%) | 3.3 (59%) |
| GONE: slain | - | 0.3 (6%) | 0.3 (6%) |
| STUPIDITY: Stupidity | - | 0.7 (12%) | 0.7 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 1.3 | 4.3 | 1.0 | 0.0 |
| not cast | 2.3 | 2.7 | 5.7 | 3.0 | 24.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (88%) | 1.3 (24%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.3 (59%) | 1.7 (56%) | 0.0 (0%) |
| GONE: slain | 0.3 (14%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 1.0 (4%) |
| STUPIDITY: Stupidity | 0.7 (29%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 2.0 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) | 1.3 (44%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (57%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (88%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (128 of 202) | 93% (13 of 14) | 65% (141 of 216) |
|   cavalry | 53% (9 of 17) | 50% (1 of 2) | 53% (10 of 19) |
|   character | 81% (22 of 27) | - | 81% (22 of 27) |
|   infantry | 40% (22 of 55) | - | 40% (22 of 55) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |
|   war machine | 73% (66 of 91) | 100% (12 of 12) | 76% (78 of 103) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 5.3 (22%) | 0.0 (0%) | 5.3 (21%) |
| CHARGED: it charged | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET IN RANGE | 8.0 (32%) | 0.3 (100%) | 8.3 (33%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 6.7 (27%) | 0.0 (0%) | 6.7 (27%) |
| SHELTERED: the target was sheltered | 2.0 (8%) | 0.0 (0%) | 2.0 (8%) |
| OTHER BAR | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 1.0 | 70% | 14.2 pts | 47 pts |
| character | 7.3 | 7.3 | 55% | 17.6 pts | 129 pts |
| infantry | 14.3 | 6.0 | 67% | 13.2 pts | 190 pts |
| monster | 3.0 | 0.3 | 89% | 13.0 pts | 39 pts |
| war machine | 26.3 | 14.0 | 71% | 13.5 pts | 356 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 0.7 | 0.7 |
| Charges that made contact a game | 0.7 | 0.3 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (21 units) | 0.15 declared, 0.08 contact (13 units) | 0.12 declared, 0.09 contact (34 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | 100% (1 of 1) | 50% (1 of 2) | 43% (3 of 7) |
| Character in a unit | 71% (5 of 7) | 67% (2 of 3) | - | 70% (7 of 10) |
| Character on its own | 100% (1 of 1) | 100% (4 of 4) | 67% (2 of 3) | 88% (7 of 8) |
| Infantry | 43% (3 of 7) | 67% (4 of 6) | - | 54% (7 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | - | - | 85% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 56% (10 of 18) | 100% | 33% (3 of 9) | 100% (3 of 3); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 92% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 50% (3 of 6) | 98% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p4, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.67 | 0.00 | 0.67 |

### Quality by phase: nw22-19bea9b-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 56% (41 of 73) | 53% (9 of 17) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 25% (3 of 12) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 0% (0 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.3 | 2.0 |
| Movement | Points that never moved of their own | 640.3 | 110.0 |
| Movement | Fights charged into per game | 0.7 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 1 of 1, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +161 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 21.0 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (37 of 63) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 199.7 | 0.0 |
| Shooting | War machine shots | 22.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (44 of 66) | 8% (1 of 12) |
| Shooting | Points destroyed by war machines | 139.0 | 98.3 |
| Magic | Magic missiles cast | - | 2.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 38% (3 of 8) |
| Magic | Wounds caused by magic missiles | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 3.3 / 0.7 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 67.3 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +282 | +0 |
| Combat | Net per 100 charger points, damage counted | +163.9 | +0.0 |
| Combat | First round won (charged fights) | 100% | 0% |
| Combat | Net points per charged fight | +101 | +0 |
| Combat | Net points per supported fight / lone fight | - / +101 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 0 of 1 |
| Game | Points lost | 173.3 | 409.7 |
| Game | VP from objectives | 636.7 | 606.7 |
| Game | Lone holders (player turns) | 2.0 | 4.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +319 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 583
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 5.0 | -170.7 | 0.0 | 0.0 | 13.7 | +293.9 | 0.0 | 74.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 0.7 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 144.7 | 38.3 | - | - | - | - |
| CANNON PLANNED TARGET | 18.0 | +468.4 | 1250.7 | 135.0 | 4.0 | +183.0 | 138.3 | 110.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.0 | +22.5 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +20.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +1.6 | 0.0 | 53.7 |
| CHARACTER GUNS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.3 | +7.3 | 53.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 9.7 | -194.0 | 0.0 | 0.0 | 22.0 | -1176.3 | 0.0 | 627.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 356.7 | 0.0 | 0.3 | +0.0 | 0.0 | 53.7 |
| CLEAR LANE AHEAD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 10.7 | -901.1 | 0.0 | 0.0 | 4.0 | -125.6 | 0.0 | 326.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 12.7 | -143.8 | 0.0 | 20.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | +1.0 | 13.7 | 0.0 | 0.7 | -4.1 | 0.0 | 53.7 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 13.7 | 0.0 | 0.7 | +0.0 | 0.0 | 53.7 |
| FALLBACK BY WORTH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 24.0 | +234.3 | 0.0 | 346.3 |
| FEATURE BUFFS | 0.7 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| FIVE ACTION | 132.7 | +6669.1 | 3964.0 | 350.0 | 69.0 | +1806.6 | 236.7 | 1099.0 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 289.3 |
| FOUR ROUNDS | 0.7 | +39.4 | 67.3 | 0.0 | 0.7 | +3.7 | 0.0 | 53.7 |
| FRIEND SHOOTS FIRST | 0.7 | -7.9 | 0.0 | 0.0 | 1.7 | -58.1 | 0.0 | 0.0 |
| GOAL WALK | 5.0 | +322.7 | 0.0 | 0.0 | 6.3 | +500.5 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +1.8 | 37.0 | 38.3 | - | - | - | - |
| GUN MASK | 6.0 | +51.7 | 0.0 | 0.0 | 2.0 | +82.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 434.0 |
| HIS CHARGE DENIED | 0.3 | +12.7 | 53.7 | 0.0 | 0.3 | +3.5 | 0.0 | 0.0 |
| HIS CHARGE LIST | 13.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 263.7 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 263.7 |
| HIS MOVE AND SHOT | 6.7 | -44.5 | 0.0 | 0.0 | 5.7 | -63.3 | 0.0 | 408.3 |
| HIS ONE QUARTER | - | - | - | - | 0.3 | +0.0 | 0.0 | 119.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 263.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.0 | +1021.3 | 0.0 | 80.0 | 46.3 | +4262.3 | 0.0 | 825.3 |
| HIS SHOTS BY HIS RUN | 30.3 | +554.7 | 0.0 | 80.0 | 41.0 | +1273.8 | 0.0 | 825.3 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 11.3 | +1217.2 | 0.0 | 0.0 | 7.3 | +927.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -23.0 | 67.3 | 0.0 | 0.7 | -6.4 | 0.0 | 53.7 |
| IDLE COST | - | - | - | - | 17.7 | -383.7 | 0.0 | 326.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 27.3 | 0.0 | 1.0 | +0.0 | 0.0 | 27.3 |
| LONG SHOT | 0.3 | -6.3 | 53.7 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | - | - | - | - | 0.3 | -1.3 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 1.7 | +98.0 | 0.0 | 0.0 |
| MANOEUVRE | 2.3 | -11.3 | 0.0 | 0.0 | 1.7 | +9.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 2.0 | +97.5 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +137.6 | 0.0 | 144.7 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +46.1 | 0.0 | 144.7 |
| MARCH OVER CASTS | - | - | - | - | 2.7 | +80.9 | 0.0 | 144.7 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | - | - | - | - | 2.7 | +27.9 | 0.0 | 289.3 |
| MEETS IN TIME | 9.0 | +209.9 | 0.0 | 20.0 | 2.0 | +354.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 6.7 | +49.5 | 0.0 | 144.7 |
| MISSILES NEXT TURN | - | - | - | - | 9.7 | +51.3 | 0.0 | 289.3 |
| MODEL FACING | 3.0 | +980.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +376.2 | 0.0 | 0.0 | 2.7 | +155.8 | 0.0 | 144.7 |
| NEAR WALKS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +233.2 | 0.0 | 0.0 | 4.0 | +184.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +340.1 | 0.0 | 0.0 | 2.3 | +129.3 | 0.0 | 144.7 |
| NO CHAFF EDGES | 0.7 | +0.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -12.1 | 67.3 | 0.0 | 0.7 | -5.1 | 0.0 | 53.7 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.7 | -10.6 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.0 | -251.1 | 13.7 | 0.0 | 5.3 | -147.4 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 3.7 | +7.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -29.6 | 0.0 | 0.0 | 4.0 | -90.4 | 0.0 | 346.3 |
| ONE OBJECTIVE FORMULA | 6.0 | +166.5 | 0.0 | 0.0 | 2.3 | -203.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -7.9 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +9.7 | 40.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +24.6 | 0.0 | 0.0 |
| PLAN RESULT | 58.3 | +1959.0 | 1361.3 | 235.0 | 31.7 | +120.4 | 20.0 | 886.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| PROMISE BY ITS OWN SUM | 5.7 | -60.1 | 0.0 | 0.0 | 5.3 | -27.7 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.3 | -30.5 | 0.0 | 0.0 |
| QUARTER ODDS | 17.3 | +1100.1 | 1190.0 | 0.0 | 3.0 | +754.9 | 0.0 | 119.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +54.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 33.7 |
| REFORMS TO MEET IT | 0.7 | -10.4 | 0.0 | 0.0 | 0.7 | -4.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.7 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | +20.2 | 13.7 | 0.0 | 0.7 | +30.0 | 0.0 | 53.7 |
| RUN DOWN | 0.3 | -3.4 | 13.7 | 0.0 | 0.7 | -0.6 | 0.0 | 53.7 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +15.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +5.1 | 13.7 | 0.0 | 0.3 | +3.4 | 0.0 | 53.7 |
| SET CREDITED ONCE | - | - | - | - | 3.0 | -155.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +2.9 | 0.0 | 0.0 | 4.3 | +124.7 | 0.0 | 74.0 |
| SET UP TOGETHER | - | - | - | - | 2.7 | +103.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 24.7 | +0.0 | 0.0 | 135.0 | 6.0 | +0.0 | 0.0 | 110.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +123.5 | 289.3 | 0.0 | 1.3 | +8.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 19.7 | +311.2 | 0.0 | 80.0 | 27.7 | -547.5 | 0.0 | 377.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 36.0 | +1803.4 | 0.0 | 135.0 | 4.3 | +207.4 | 0.0 | 147.0 |
| SPELL WORTH | - | - | - | - | 5.7 | +129.9 | 289.3 | 289.3 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 215.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.7 | +0.0 | 0.0 | 144.7 |
| STANDS STILL | 98.0 | +0.0 | 3896.7 | 350.0 | 19.3 | +0.0 | 236.7 | 220.0 |
| STAY WORTH | 59.3 | +203.8 | 2314.7 | 175.0 | 10.0 | +97.7 | 236.7 | 165.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.3 | -10.2 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +175.3 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +175.3 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +44.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 55.0 | +0.0 | 0.0 | 135.0 | 34.0 | +0.0 | 0.0 | 456.3 |
| TIED UP BY THE SUM | 0.3 | +12.1 | 13.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 57.0 | +596.4 | 363.3 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +1.1 | 0.0 | 0.0 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 144.7 |
| WHO FIGHTS | 0.3 | -0.2 | 13.7 | 0.0 | 0.7 | +3.2 | 0.0 | 53.7 |
| WHOLE FIGHT DANGER | 0.7 | -13.3 | 0.0 | 0.0 | 1.3 | -115.0 | 0.0 | 289.3 |
| WHOLE FIGHT REACTION | 0.3 | +7.6 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +68.2 | 0.0 | 0.0 | 5.0 | +792.4 | 0.0 | 119.0 |

### Rule changes: nw22-19bea9b-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 250 | 244 | 79 | 26.33 | +2219 | +28.1 |
| HIS SHOTS BY HIS RUN | 214 | 201 | 53 | 17.67 | +655 | +12.4 |
| HOLDER ASSIGNMENT | 56 | 56 | 52 | 17.33 | +3865 | +74.3 |
| ARMY TABLE | 56 | 56 | 49 | 16.33 | +292 | +6.0 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -1195 | -35.2 |
| SHOT RISK POINTS | 142 | 139 | 34 | 11.33 | +912 | +26.8 |
| DEPLOY BY FIGURES | 51 | 51 | 32 | 10.67 | +306 | +9.6 |
| TIME ON OUR SIDE | 171 | 153 | 27 | 9.00 | +81 | +3.0 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| IDLE COST | 53 | 41 | 16 | 5.33 | +245 | +15.3 |
| GOAL WALK | 34 | 34 | 15 | 5.00 | +1272 | +84.8 |
| MEETS IN TIME | 33 | 33 | 14 | 4.67 | +432 | +30.9 |
| FIVE ACTION | 605 | 591 | 12 | 4.00 | +812 | +67.7 |
| COVER ONCE | 44 | 35 | 11 | 3.67 | +3 | +0.3 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +24 | +2.2 |
| WOUNDS ON THE RANKS | 23 | 23 | 11 | 3.67 | +367 | +33.4 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| THE TABLE AGAIN | 35 | 35 | 10 | 3.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 95 | 94 | 9 | 3.00 | +493 | +54.7 |
| MODEL FACING | 9 | 9 | 9 | 3.00 | +2940 | +326.7 |
| MOVE TO CHARGE COMPUTED | 20 | 16 | 9 | 3.00 | +262 | +29.1 |
| PROMISE BY ITS OWN SUM | 33 | 33 | 9 | 3.00 | -264 | -29.3 |
| NEXT CHARGE BY LIST | 13 | 13 | 7 | 2.33 | +210 | +30.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 7 | 2.33 | +0 | +0.0 |
| MARCH BY THE SUM | 6 | 6 | 6 | 2.00 | +292 | +48.7 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 121 | 105 | 6 | 2.00 | +202 | +33.6 |
| LEGAL CHARGES ONLY | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CAST JOB | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 25 | 22 | 4 | 1.33 | +198 | +49.6 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 4 | 1.33 | +71 | +17.7 |
| SUPPORT ADDS | 8 | 8 | 4 | 1.33 | +23 | +5.6 |
| SUPPORT WORKED OUT | 8 | 8 | 4 | 1.33 | +23 | +5.6 |
| CANNON PLANNED TARGET | 66 | 66 | 3 | 1.00 | +0 | +0.0 |
| FOUR ROUNDS | 4 | 3 | 3 | 1.00 | +38 | +12.7 |
| GUN MASK | 24 | 24 | 3 | 1.00 | +26 | +8.7 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +532 | +177.2 |
| MARCH CHECK | 4 | 3 | 3 | 1.00 | +209 | +69.6 |
| NO CHAFF EDGES | 3 | 3 | 3 | 1.00 | +2 | +0.6 |
| SURE REACH TOGETHER | 5 | 5 | 3 | 1.00 | +11 | +3.7 |
| THE ROW IN ITS ORDER | 10 | 3 | 3 | 1.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -63 | -31.7 |
| FALLS SHORT | 72 | 63 | 2 | 0.67 | +63 | +31.7 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +38 | +18.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -24 | -11.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +74 | +37.0 |
| QUARTER ODDS | 61 | 61 | 2 | 0.67 | +12 | +5.8 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.67 | +29 | +14.3 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +25 | +12.7 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| CLEAR LANE AHEAD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 4 | 3 | 1 | 0.33 | +0 | +0.5 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +29 | +28.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -138 | -138.2 |
| MAX FOR POSITIONING | 8 | 8 | 1 | 0.33 | +1 | +1.1 |
| MISSILES IN THE MOVE | 20 | 14 | 1 | 0.33 | +1 | +1.3 |
| MISSILES NEXT TURN | 29 | 24 | 1 | 0.33 | +3 | +3.1 |
| NEARER NOT NEEDED | 27 | 24 | 1 | 0.33 | +61 | +61.4 |
| NO DOUBLE ROUNDS | 4 | 3 | 1 | 0.33 | +0 | +0.5 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | +26 | +26.5 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RISK BY ARC | 3 | 2 | 1 | 0.33 | +3 | +2.8 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +48 | +47.7 |
| WHO FIGHTS | 3 | 2 | 1 | 0.33 | +3 | +2.8 |
| BACKS UP THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 18 | 18 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 47 | 42 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 3 | 2 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 7 | 5 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 39 | 38 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 64 | 64 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 37 | 37 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 1 | 1 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 34 | 29 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 85 | 85 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 20 | 16 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 270 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 7 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 14 | 12 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 8 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 92 | not checked | - | - | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 25 | 21 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 352 | 349 | 0 | 0.00 | - | - |
| STAY WORTH | 208 | 193 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE FIGHT MOVES | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 267 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 9 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 4.33 | 37.7 |
| ARMY TABLE | rule | 2.33 | 2.00 | 49.0 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 0.33 | 29.3 |
| NO REASON | gate | - | 1.00 | 18.9 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 31.7 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 11.9 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 7.4 |
| MARCH OF THE TABLE | rule | - | 0.33 | 138.2 |
| RULE SWITCHED OFF | gate | 0.33 | - | 13.2 |
| TURN GATE | gate | 0.33 | - | 31.9 |

### Plans: nw22-19bea9b-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 62 | 67 | 108% |
| Mine | join | 2.0 | 100% | 70 | 0 | 0% |
| Mine | move | 36.0 | 98% | 1440 | 0 | 0% |
| Mine | shoot | 19.7 | 61% | 959 | 1892 | 197% |
| Opponent | charge | 0.7 | 0% | 7 | 0 | 0% |
| Opponent | join | 1.7 | 100% | 80 | 0 | 0% |
| Opponent | move | 25.3 | 93% | 889 | 0 | 0% |
| Opponent | shoot | 3.7 | 45% | 150 | 120 | 80% |
| Opponent | support | 0.3 | 100% | 15 | 0 | 0% |

### Battle groups: nw22-19bea9b-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 100% | 100% | 100% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 8 (13) | 8 | 0 | 0 | 31% | 2.6 | 16 (5) | 0 (7) | 0 (1) | 9 (11) | 0 (2) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | - | 0 (3) | 0 (1) | 0 (4) | - |
| Mine | Fast | 3 | 73 (3) | 73 | 0 | 27 | 33% | 1.0 | - | 275 (1) | 0 (2) | 73 (3) | - |
| Mine | Hammer | 4 | 7 (4) | 7 | 0 | 0 | 50% | 2.0 | 17 (1) | 0 (3) | - | 7 (4) | - |
| Mine | Holder | 2 | 215 (2) | 118 | 98 | 0 | 0% | 1.5 | 0 (1) | 427 (1) | - | 427 (1) | 0 (1) |
| Mine | Shooter | 6 | 55 (6) | 5 | 50 | 0 | 17% | 3.8 | 122 (2) | 0 (1) | 9 (3) | 68 (5) | 0 (1) |
| Mine | War machine | 17 | 24 (17) | 24 | 0 | 24 | 12% | 1.3 | 15 (4) | 38 (9) | 0 (4) | 0 (3) | 31 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 63 | 67% | 1.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 2 (10) | 2 | 0 | 18 | 70% | 1.0 | 0 (2) | 5 (5) | 0 (2) | 3 (8) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 3 | 8 (3) | 0 | 8 | 30 | 100% | - | - | 13 (2) | 0 (1) | 11 (2) | 0 (1) |
| Opponent | Holder | 6 | 145 (6) | 0 | 145 | 10 | 67% | 1.5 | - | 145 (6) | - | 229 (4) | 7 (2) |
| Opponent | War machine | 2 | 89 (2) | 89 | 0 | 50 | 0% | 1.0 | - | 109 (1) | 70 (1) | - | 89 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |

### Charged fights: nw22-19bea9b-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 339 | 67 | 0.7 | 1.0 | 101 | 0 | +101 | 0 of 2 | 2 of 2 | - | +101 |
| Opponent | Grand Cathay | 1 | 355 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 118 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |

### Effective charges: nw22-19bea9b-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +161) | 1 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 239 | 161 | +161 | 161 | 15 | +146 | +61.1 |
| Mine | No odds | 1 | 105 | 41 | +41 | 418 | 0 | +418 | +397.7 |
| Mine | All fights | 2 | 172 | 101 | +101 | 289 | 7 | +282 | +163.9 |
| Opponent | Long shot (under 50%) | 1 | 41 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 1 | 41 | 60 | +0 | 0 | 0 | +0 | +0.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p4 | move | 14 | 1 (7%) | 1 (7%) | 1 (7%) | 12 (86%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

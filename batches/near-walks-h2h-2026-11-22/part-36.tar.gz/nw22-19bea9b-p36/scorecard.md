# Doctrine scorecard: nw22-19bea9b-p36

### Scorecard: nw22-19bea9b-p36

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | yes | - | 5 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 3 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 9 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 256 |
| **Average** | | | Mine | 33% | 4.5 | 3.7 | 3.3 | 2.7 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 33% | 2.0 | 3.0 | 0.3 | 2.3 | 0.0 | 0.0 | 0.0 | 142.0 |

### KPIs: nw22-19bea9b-p36

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 16) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 100% | 75% (3 of 4); on the table 100% | 78% (7 of 9); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 50% | - | 0% (0 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 57% (4 of 7); on the table 86% | 80% (4 of 5); on the table 100% | 67% (8 of 12); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 50% (3 of 6) | 58% (7 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (4 of 6) | 60% (3 of 5) | 64% (7 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | 43% (3 of 7) | 54% (7 of 13) |
| Points that never fought | lower | 67% (4025 of 5998) | 54% (3209 of 5998) | 60% (7234 of 11996) |
|   infantry points that never fought | lower | 34% (310 of 902) | 67% (717 of 1072) | 52% (1027 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (12 of 19) | 85% (22 of 26) | 76% (34 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (3177 of 5038) | 89% (4778 of 5360) | 77% (7955 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (100%) | 0.7 (67%) | 1.3 (80%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (33%) | 0.3 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 1.0 | 0.7 | 2.3 | 0.0 | 0.0 |
| not cast | 3.7 | 0.0 | 3.3 | 1.7 | 2.0 | 24.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.3 (80%) | 2.0 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (9%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (82%) | - | 3.0 (90%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.3 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | 0% (0 of 2) | - | 0% (0 of 2) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 9% (1 of 11) | 70% (28 of 40) | 57% (29 of 51) |
|   cavalry | 20% (1 of 5) | 92% (11 of 12) | 71% (12 of 17) |
|   character | 0% (0 of 6) | 38% (6 of 16) | 27% (6 of 22) |
|   infantry | - | 92% (11 of 12) | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (30%) | 2.0 (50%) | 3.0 (41%) |
| CHARGED: it charged | 0.7 (20%) | 1.0 (25%) | 1.7 (23%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (17%) | 0.7 (9%) |
| NO TARGET IN RANGE | 1.0 (30%) | 0.0 (0%) | 1.0 (14%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (20%) | 0.0 (0%) | 0.7 (9%) |
| STUPIDITY | 0.0 (0%) | 0.3 (8%) | 0.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 0.7 | 91% | 1.3 pts | 10 pts |
| character | 2.0 | 1.0 | 50% | 19.7 pts | 39 pts |
| infantry | 5.7 | 0.3 | 94% | 3.2 pts | 18 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 1.7 | 3.8 |
| Charges that made contact a game | 2.7 | 1.3 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.75 declared, 0.00 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.65 declared, 0.35 contact (23 units) | 0.22 declared, 0.17 contact (23 units) | 0.43 declared, 0.26 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (3 of 7) | 100% (5 of 5) | 0% (0 of 1) | 62% (8 of 13) |
| Character in a unit | 100% (5 of 5) | 100% (3 of 3) | 100% (1 of 1) | 100% (9 of 9) |
| Character on its own | 50% (1 of 2) | - | 86% (6 of 7) | 78% (7 of 9) |
| Infantry | 71% (5 of 7) | 0% (0 of 1) | - | 62% (5 of 8) |
| Monster | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 67% (4 of 6); on the table 100% | 67% (4 of 6) | 80% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 60% (3 of 5); on the table 80% | 50% (3 of 6) | 56% | 76% (19 of 25) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 34% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p36, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 50% (3) | 56% (5) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: nw22-19bea9b-p36

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 33% (5 of 15) | 80% (4 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | - | 25% (2 of 8) |
| Strategy | Support requests answered (helper made contact too) | 75% (3 of 4) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 29% (2 of 7) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 1.3 | 0.0 |
| Movement | Idle units | 2.7 | 2.3 |
| Movement | Points that never moved of their own | 0.0 | 142.0 |
| Movement | Fights charged into per game | 2.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 4, net +266 | 1 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 1 of 3, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +0 | 1 of 3, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.3 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 61% (17 of 28) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 100% (1 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.0 / 0.0 | 0.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 97.0 | 15.0 |
| Combat | Points run down | 254.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +165 | +33 |
| Combat | Net per 100 charger points, damage counted | +79.4 | +6.1 |
| Combat | First round won (charged fights) | 67% | 67% |
| Combat | Net points per charged fight | +180 | +0 |
| Combat | Net points per supported fight / lone fight | +173 / +182 | +0 / +0 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 6 | 2 of 3 |
| Game | Points lost | 25.0 | 414.7 |
| Game | VP from objectives | 600.0 | 576.7 |
| Game | Lone holders (player turns) | 4.5 | 2.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +413 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 440
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: nw22-19bea9b-p36

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +31.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 24.3 | +367.1 | 0.0 | 0.0 | 22.7 | +85.5 | 0.0 | 373.7 |
| BACKS UP THE FIGHT | 1.3 | +12.4 | 0.0 | 0.0 | 0.3 | +42.7 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.7 | +0.0 | 57.7 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.3 | +59.6 | 0.0 | 0.0 | 2.0 | +31.2 | 0.0 | 18.0 |
| CHALLENGE BY POINTS | 1.0 | +19.8 | 0.0 | 0.0 | 0.3 | +3.1 | 0.0 | 57.7 |
| CHARACTERS BY THEIR POINTS | 0.7 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.7 | -292.7 | 0.0 | 0.0 | 8.0 | -289.5 | 0.0 | 241.3 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 158.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 18.0 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 190.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | 0.7 | +0.0 | 9.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.7 | -369.7 | 0.0 | 0.0 | 9.7 | -412.4 | 0.0 | 120.7 |
| DEPLOY BY FIGURES | 7.0 | +76.7 | 0.0 | 0.0 | 7.3 | -20.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -29.4 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +5.8 | 65.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.7 | +1.7 | 240.7 | 15.0 | 0.3 | +3.8 | 0.0 | 0.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 5.0 | +1.7 | 333.3 | 15.0 | 1.7 | +9.3 | 0.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 25.7 | +272.3 | 0.0 | 0.0 | - | - | - | - |
| FEATURE BUFFS | 0.7 | +9.3 | 0.0 | 0.0 | 2.0 | +15.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +8.0 | 95.0 | 0.0 | 0.7 | +6.3 | 0.0 | 0.0 |
| FIVE ACTION | 91.3 | +3886.7 | 363.7 | 15.0 | 89.7 | +6316.2 | 30.0 | 672.7 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 215.7 |
| FOLLOW UP WEIGHED | 1.7 | +158.6 | 0.0 | 0.0 | 1.0 | +116.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 6.0 | +255.0 | 363.7 | 15.0 | 1.7 | +161.9 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -1.6 | 32.7 | 0.0 | - | - | - | - |
| GOAL WALK | 10.3 | +931.4 | 0.0 | 0.0 | 13.7 | +1700.7 | 0.0 | 190.0 |
| HALF WHEN STILL FLEEING | 1.7 | -3.9 | 173.0 | 15.0 | 0.7 | -0.6 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 57.7 | 15.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 180.7 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -10.1 | 0.0 | 0.0 | 0.7 | -2.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 8.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 0.0 | 21.3 | +0.0 | 0.0 | 121.3 |
| HIS RANDOM MOVER COMES | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 60.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 43.7 | +580.4 | 0.0 | 0.0 | 13.7 | +177.7 | 0.0 | 60.7 |
| HIS SHOTS BY HIS RUN | 30.7 | +278.3 | 0.0 | 0.0 | 6.0 | +247.0 | 0.0 | 60.7 |
| HIS TURN DENIED | 0.3 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 18.7 | +0.0 | 0.0 | 0.0 | 20.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.7 | +992.9 | 0.0 | 0.0 | 10.3 | +996.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -158.7 | 248.3 | 0.0 | 1.7 | -122.1 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +37.9 | 0.0 | 0.0 |
| IDLE COST | 24.0 | -370.9 | 0.0 | 0.0 | - | - | - | - |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | 2.3 | +59.8 | 205.7 | 15.0 | 0.7 | +26.8 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.7 | -26.0 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +2.1 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +18.4 | 0.0 | 0.0 | 1.0 | +19.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 159.7 | 0.0 | 5.7 | +0.0 | 15.0 | 1066.3 |
| LOST AFTER ESCAPE | 2.3 | +4.4 | 268.0 | 15.0 | 1.0 | +0.2 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -63.1 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 6.0 | +70.1 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | -1.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +85.0 | 0.0 | 0.0 | 4.7 | +60.0 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +231.2 | 0.0 | 0.0 | 3.3 | +136.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +4.3 | 0.0 | 0.0 | 2.0 | +32.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +3.3 | 0.0 | 0.0 | 3.0 | +27.3 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.0 | +372.2 | 0.0 | 0.0 | 9.3 | +1203.6 | 0.0 | 0.0 |
| NEAR WALKS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.3 | +306.4 | 0.0 | 0.0 | 7.7 | +344.8 | 0.0 | 32.7 |
| NEXT CHARGE BY LIST | 9.0 | +347.8 | 0.0 | 0.0 | 6.3 | +829.7 | 0.0 | 0.0 |
| NO CHAFF EDGES | 3.7 | +110.9 | 63.0 | 0.0 | 1.7 | +25.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.7 | -140.3 | 248.3 | 15.0 | 1.0 | -17.6 | 0.0 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | -8.3 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.3 | -102.7 | 0.0 | 0.0 | 5.0 | -238.7 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | 0.7 | +2.0 | 30.3 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.0 | -59.1 | 0.0 | 0.0 | 6.3 | -149.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 1.3 | +8.6 | 173.0 | 15.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 5.0 | +39.2 | 0.0 | 0.0 | 5.7 | +5.5 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 1.3 | -61.5 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +31.8 | 30.3 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 1.7 | +52.2 | 63.0 | 0.0 | 0.7 | +15.2 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +6.4 | 30.3 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.3 | +10.8 | 0.0 | 0.0 | 1.3 | +37.7 | 0.0 | 0.0 |
| PLAN RESULT | 45.3 | +225.3 | 375.3 | 40.0 | 43.7 | +93.6 | 10.0 | 612.0 |
| PRIZE BY WORTH | 0.3 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.7 | -90.9 | 0.0 | 0.0 | 14.3 | -1040.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | -0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -1.5 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| QUARTER ODDS | 7.7 | +677.6 | 0.0 | 15.0 | 6.7 | +963.1 | 30.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +41.8 | 0.0 | 0.0 | 2.3 | +2.2 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -14.9 | 0.0 | 0.0 | 0.7 | -0.8 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.0 | +347.0 | 0.0 | 0.0 | 3.7 | +188.8 | 0.0 | 9.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +2.1 | 0.0 | 15.0 | 3.3 | +13.7 | 0.0 | 9.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 3.3 | -86.5 | 0.0 | 0.0 | 2.0 | -80.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 30.3 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| RISK BY ARC | 3.7 | +164.3 | 95.7 | 15.0 | 1.0 | +5.9 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -17.2 | 123.0 | 0.0 | 0.7 | -37.4 | 0.0 | 0.0 |
| RUN DOWN | 5.7 | -37.2 | 363.7 | 15.0 | 1.3 | -10.1 | 0.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.3 | -84.8 | 0.0 | 0.0 | 1.3 | -30.7 | 0.0 | 18.0 |
| SEARCH SPOT | 1.0 | +53.3 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 1.0 | +103.2 | 30.3 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 7.0 | -112.3 | 0.0 | 0.0 | 1.7 | -22.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 10.0 | +126.3 | 0.0 | 0.0 | 4.7 | +32.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 6.0 | +70.1 | 0.0 | 0.0 | 1.0 | +0.8 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 9.0 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +9.5 | 0.0 | 0.0 | 1.7 | +4.9 | 30.0 | 0.0 |
| SHOT RISK POINTS | 19.3 | -200.4 | 0.0 | 0.0 | 8.0 | +14.8 | 0.0 | 121.3 |
| SHOTS AFTER THE MOVES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.0 | +18.6 | 0.0 | 0.0 | 9.3 | +88.3 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 18.0 | +0.0 | 0.0 | 10.0 | 9.7 | +0.0 | 0.0 | 254.7 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 17.3 | +0.0 | 0.0 | 0.0 | 40.7 | +0.0 | 30.0 | 126.0 |
| STAY WORTH | 0.3 | +1.5 | 0.0 | 0.0 | 11.0 | +34.4 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +1.5 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 57.7 |
| STUBBORN ONCE | - | - | - | - | 0.3 | -11.5 | 0.0 | 0.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 4.3 | +100.5 | 0.0 | 0.0 | 6.7 | +688.8 | 0.0 | 65.3 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.3 | +100.5 | 0.0 | 0.0 | 6.7 | +688.8 | 0.0 | 65.3 |
| SURE REACH TOGETHER | 3.3 | +20.7 | 0.0 | 0.0 | 1.0 | +12.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.9 | 0.0 | 10.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.0 | +12.2 | 160.3 | 0.0 | 0.3 | -4.8 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 6.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 57.7 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.0 | +0.0 | 0.0 | 0.0 | 44.3 | +0.0 | 0.0 | 345.3 |
| TIED UP BY THE SUM | 2.7 | +417.0 | 95.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 61.0 | +625.9 | 0.0 | 462.3 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -22.4 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | -7.4 | 115.3 | 0.0 | 0.3 | -3.1 | 0.0 | 0.0 |
| WHO GETS IN | 1.7 | -2.5 | 205.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +40.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -151.5 | 0.0 | 0.0 | 6.0 | -271.4 | 0.0 | 241.3 |
| WHOLE FIGHT GAIN | 1.3 | +28.1 | 173.0 | 15.0 | 0.7 | +16.9 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.0 | +127.9 | 0.0 | 0.0 | 3.0 | +384.9 | 15.0 | 57.7 |

### Rule changes: nw22-19bea9b-p36

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 141 | 141 | 97 | 32.33 | +1164 | +12.0 |
| HOLDER ASSIGNMENT | 63 | 63 | 60 | 20.00 | +4351 | +72.5 |
| FIVE ACTION | 543 | 515 | 38 | 12.67 | +2246 | +59.1 |
| OFF BEST | 37 | 37 | 37 | 12.33 | -1024 | -27.7 |
| PROMISE BY ITS OWN SUM | 75 | 75 | 32 | 10.67 | -3395 | -106.1 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| HIS SHOT LIST | 172 | 162 | 28 | 9.33 | +171 | +6.1 |
| TIME ON OUR SIDE | 183 | 152 | 28 | 9.33 | +24 | +0.8 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +127 | +5.3 |
| REDIRECT FOR A FRIEND IN REACH | 22 | 22 | 19 | 6.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 110 | 105 | 18 | 6.00 | +195 | +10.8 |
| GOAL WALK | 72 | 69 | 17 | 5.67 | +1560 | +91.8 |
| MOVE TO CHARGE COMPUTED | 58 | 42 | 15 | 5.00 | +761 | +50.7 |
| NO CHAFF EDGES | 16 | 16 | 14 | 4.67 | +350 | +25.0 |
| IDLE COST | 72 | 53 | 13 | 4.33 | +122 | +9.4 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 46 | 38 | 13 | 4.33 | +777 | +59.8 |
| SET UP BY THE SET | 44 | 43 | 12 | 4.00 | +625 | +52.1 |
| WHOLE FIGHT DANGER | 28 | 28 | 12 | 4.00 | +502 | +41.9 |
| CHAFF IN THE MOVE | 13 | 13 | 11 | 3.67 | +48 | +4.4 |
| COVER ONCE | 52 | 37 | 11 | 3.67 | +335 | +30.4 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +575 | +52.3 |
| MAX FOR POSITIONING | 30 | 27 | 10 | 3.33 | +24 | +2.4 |
| QUARTER ODDS | 43 | 41 | 10 | 3.33 | +776 | +77.6 |
| SUPPORT ADDS | 33 | 32 | 10 | 3.33 | +449 | +44.9 |
| SUPPORT WORKED OUT | 33 | 32 | 10 | 3.33 | +449 | +44.9 |
| FOUR ROUNDS | 23 | 22 | 9 | 3.00 | +270 | +30.0 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +260 | +28.9 |
| SHOT RISK POINTS | 82 | 76 | 9 | 3.00 | +180 | +19.9 |
| SURE REACH TOGETHER | 13 | 12 | 9 | 3.00 | +0 | +0.1 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +825 | +103.2 |
| PATHS CROSS | 8 | 8 | 8 | 2.67 | +145 | +18.2 |
| FALLS SHORT | 77 | 59 | 7 | 2.33 | +32 | +4.5 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1184 | +169.2 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 7 | 2.33 | +132 | +18.8 |
| TIED UP BY THE SUM | 8 | 7 | 7 | 2.33 | +210 | +30.1 |
| CLEAR LANE AHEAD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +113 | +18.8 |
| RISK BY ARC | 14 | 13 | 6 | 2.00 | +180 | +29.9 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 31 | 22 | 5 | 1.67 | +27 | +5.4 |
| WHO GETS IN | 5 | 5 | 5 | 1.67 | -8 | -1.5 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +69 | +17.1 |
| CHARGE NOW FIRST | 11 | 11 | 4 | 1.33 | -258 | -64.5 |
| NEARER NOT NEEDED | 45 | 42 | 4 | 1.33 | +166 | +41.5 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -184 | -46.1 |
| OPENS UP IN FULL | 7 | 6 | 4 | 1.33 | +69 | +17.3 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 4 | 1.33 | +10 | +2.5 |
| HONEST WORTH | 19 | 18 | 3 | 1.00 | +114 | +38.1 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +160 | +53.4 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +310 | +103.2 |
| WHOLE FIGHT REACTION | 12 | 12 | 3 | 1.00 | +79 | +26.2 |
| CHARGE LOSSES | 62 | 57 | 2 | 0.67 | +215 | +107.7 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -8 | -3.9 |
| SET CREDITED ONCE | 26 | 25 | 2 | 0.67 | +7 | +3.5 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +5 | +2.7 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -14 | -6.9 |
| WHOLE FIGHT GAIN | 6 | 6 | 2 | 0.67 | +45 | +22.3 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +93 | +92.8 |
| BACKS UP THE FIGHT | 5 | 5 | 1 | 0.33 | +126 | +125.5 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARACTERS BY THEIR POINTS | 2 | 2 | 1 | 0.33 | +1 | +0.6 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +14 | +14.2 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +11 | +11.3 |
| LOST AFTER ESCAPE | 10 | 10 | 1 | 0.33 | +1 | +0.6 |
| MISSILES IN THE MOVE | 11 | 5 | 1 | 0.33 | +23 | +23.4 |
| ONE FIGHT FORMULA | 37 | 12 | 1 | 0.33 | +32 | +32.3 |
| ONE JOINT FIGURE | 4 | 4 | 1 | 0.33 | +22 | +22.1 |
| OPENS UP | 2 | 1 | 1 | 0.33 | +22 | +22.1 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +13 | +13.0 |
| PROMISE KNOWS THE FIGHT | 12 | 5 | 1 | 0.33 | -0 | -0.1 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | +31 | +30.7 |
| REDIRECT COUNTER | 23 | 20 | 1 | 0.33 | +60 | +59.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +13 | +13.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +26 | +26.2 |
| RUN DOWN | 21 | 20 | 1 | 0.33 | +27 | +27.1 |
| SCOUT BY DROPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SET UP TOGETHER | 21 | 16 | 1 | 0.33 | +4 | +4.2 |
| SHOTS AFTER THE MOVES | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| THE FIGHT MOVES | 7 | 7 | 1 | 0.33 | +10 | +9.8 |
| THE ROW IN ITS ORDER | 33 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| CARRIES OUT SET-UP | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 91 | 91 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 12 | 11 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 20 | 20 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 15 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 41 | 38 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 47 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 15 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 6 | 6 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 10 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 49 | 38 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 100 | 94 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 20 | 20 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 116 | 115 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 18 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 14 | 5 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 17 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 32 | 28 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 267 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 16 | 14 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 83 | 73 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 174 | 165 | 0 | 0.00 | - | - |
| STAY WORTH | 34 | 26 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 265 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 12 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p36

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.33 | 4.67 | 24.2 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 8.00 | 106.1 |
| ARMY TABLE | rule | 2.33 | 3.00 | 96.5 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 64.5 |
| ONE PROMISE A TARGET | rule | - | 1.33 | 46.1 |
| JOINT CHARGE NOW | rule | 1.00 | - | 27.9 |
| NO REASON | gate | 1.00 | - | 27.3 |
| WHO GETS IN | rule | 1.00 | - | 27.9 |
| MAIN BODY KEEPS ITS BAND | rule | - | 0.67 | 10.9 |
| PATHS CROSS | rule | - | 0.67 | 11.3 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 3.9 |
| SUPPORT NARROWED | rule | 0.67 | - | 6.9 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 21.6 |
| SET UP BY THE SET | rule | 0.33 | - | 1.1 |
| TURN GATE | gate | - | 0.33 | 143.4 |

### Plans: nw22-19bea9b-p36

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 46% | 482 | 225 | 47% |
| Mine | join | 2.0 | 100% | 75 | 0 | 0% |
| Mine | move | 37.3 | 99% | 1463 | 0 | 0% |
| Mine | support | 1.7 | 100% | 2 | 0 | 0% |
| Opponent | charge | 1.0 | 33% | 86 | 70 | 81% |
| Opponent | join | 2.7 | 100% | 139 | 0 | 0% |
| Opponent | move | 36.3 | 97% | 2277 | 0 | 0% |
| Opponent | shoot | 2.0 | 33% | 109 | 24 | 22% |
| Opponent | support | 1.7 | 80% | 7 | 0 | 0% |

### Battle groups: nw22-19bea9b-p36

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.0 | 17% | 50% | 0% | - | 0% | 0% | 100% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 45% | 80% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p36

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 61 (9) | 33 | 29 | 14 | 67% | 5.0 | 70 (4) | 0 (3) | 111 (2) | 77 (7) | 0 (2) |
| Mine | Character | 9 | 4 (9) | 4 | 0 | 0 | 67% | 4.7 | 0 (2) | 6 (6) | 0 (1) | 8 (4) | 0 (5) |
| Mine | Clean-up | 3 | 229 (3) | 174 | 55 | 0 | 33% | 2.0 | - | 153 (1) | 275 (2) | 180 (2) | 310 (1) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 4 | 13 (4) | 0 | 13 | 0 | 75% | 6.0 | 0 (1) | 26 (2) | 0 (1) | 39 (1) | 0 (3) |
| Mine | Hammer | 2 | 42 (2) | 24 | 18 | 0 | 0% | 3.5 | - | 42 (2) | - | 69 (1) | 28 (1) |
| Mine | Holder | 1 | 282 (1) | 0 | 282 | 0 | 0% | 6.0 | 282 (1) | - | - | 282 (1) | - |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 0% | 4.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.7 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 3 | 218 (3) | 0 | 218 | 22 | 67% | 4.0 | 0 (1) | 386 (1) | 0 (1) | 218 (3) | - |
| Opponent | Character | 10 | 2 (10) | 2 | 0 | 16 | 60% | 1.8 | 3 (6) | 0 (4) | - | 0 (5) | 3 (5) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 38 (5) | 0 | 38 | 44 | 80% | 1.0 | 0 (3) | - | 86 (2) | 84 (3) | 0 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 11 (6) | 0 | 11 | 44 | 0% | 3.8 | - | 14 (4) | 0 (2) | 0 (3) | 24 (3) |
| Opponent | Holder | 6 | 34 (6) | 0 | 34 | 0 | 67% | 1.5 | 84 (1) | 60 (2) | - | 140 (1) | 36 (2) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: nw22-19bea9b-p36

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 518 | 2.5 | 1.4 | 207 | 9 | +198 | 3 of 5 | 3 of 5 | +173 | +204 |
| Mine | Warriors of Chaos | 1 | 0 | 91 | 1.0 | 1.0 | 91 | 0 | +91 | 0 of 1 | 1 of 1 | - | +91 |
| **Mine** | all armies | 3 | 0 | 375 | 2.0 | 1.3 | 188 | 8 | +180 | 3 of 6 | 4 of 6 | +173 | +182 |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 0 | +0 | 2 of 3 | 2 of 3 | +0 | +0 |
| **Opponent** | all armies | 3 | 0 | 0 | 1.0 | 1.3 | 0 | 0 | +0 | 2 of 3 | 2 of 3 | +0 | +0 |

### Effective charges: nw22-19bea9b-p36

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 5 | 2 (net +266) | 0 | 0 | 1 (net +173) | 0 | 1 (net +0) | 1 | 0% (0 of 4) |
| Opponent | Wood Elf Realms | 3 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: nw22-19bea9b-p36

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 116 | 337 | +266 | 317 | 65 | +251 | +217.7 |
| Mine | 76-89% | 1 | 149 | 173 | +173 | 173 | 8 | +166 | +111.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 186 | 285 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 2 | 340 | 132 | +188 | 188 | 27 | +161 | +47.2 |
| Mine | All fights | 6 | 208 | 233 | +180 | 197 | 32 | +165 | +79.4 |
| Opponent | Long shot (under 50%) | 1 | 609 | 323 | +0 | 0 | 18 | -18 | -3.0 |
| Opponent | Effective (55-75%) | 1 | 499 | 323 | +0 | 48 | 0 | +48 | +9.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 500 | 205 | +0 | 68 | 0 | +68 | +13.7 |
| Opponent | All fights | 3 | 536 | 284 | +0 | 39 | 6 | +33 | +6.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p36 | move | 20 | 4 (20%) | 2 (10%) | 3 (15%) | 13 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

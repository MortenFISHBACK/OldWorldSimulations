# Doctrine scorecard: nw22-19bea9b-p9

### Scorecard: nw22-19bea9b-p9

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 3 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 5 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 4.0 | 2.5 | 3.3 | 0.7 | 0.7 | 0.0 | 0.0 | 33.3 |
| **Average** | | | Opponent | 33% | 1.0 | 2.3 | 3.7 | 2.3 | 0.3 | 0.0 | 0.0 | 0.0 |

### KPIs: nw22-19bea9b-p9

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 16) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 67% (6 of 9); on the table 78% | 70% (7 of 10); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 2); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 55% (6 of 11); on the table 64% | 58% (7 of 12); on the table 67% |
| Magic missiles tried each own turn | 50%+ | - | 67% (12 of 18) | 67% (12 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 67% (6 of 9) | 67% (6 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 30% (1818 of 6000) | 33% (1962 of 5999) | 32% (3780 of 11999) |
|   infantry points that never fought | lower | 74% (988 of 1332) | 63% (529 of 834) | 70% (1517 of 2166) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (11 of 20) | 47% (8 of 17) | 51% (19 of 37) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2770 of 5135) | 40% (1837 of 4600) | 47% (4607 of 9735) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (50%) | 1.0 (50%) |
| GONE: slain | - | 1.0 (50%) | 1.0 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 2.3 | 1.0 | 4.0 | 0.0 | 1.7 |
| not cast | 6.7 | 1.7 | 1.0 | 2.0 | 2.0 | 26.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 1.0 (50%) | 2.0 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 2.0 (30%) | 0.0 (0%) | 0.0 (0%) | 1.0 (50%) | 0.0 (0%) | 5.3 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (65%) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 52% (44 of 85) | 60% (21 of 35) | 54% (65 of 120) |
|   cavalry | 40% (4 of 10) | 100% (8 of 8) | 67% (12 of 18) |
|   character | 27% (3 of 11) | 0% (0 of 12) | 13% (3 of 23) |
|   chariot | 50% (2 of 4) | - | 50% (2 of 4) |
|   infantry | 66% (23 of 35) | 87% (13 of 15) | 72% (36 of 50) |
|   monster | 38% (5 of 13) | - | 38% (5 of 13) |
|   war machine | 58% (7 of 12) | - | 58% (7 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (20%) | 1.0 (21%) | 3.7 (20%) |
| CHARGED: it charged | 2.7 (20%) | 2.3 (50%) | 5.0 (27%) |
| FLEEING: it fled or was fleeing | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 2.0 (15%) | 0.7 (14%) | 2.7 (15%) |
| MOVED: a war machine that moved | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 3.0 (22%) | 0.7 (14%) | 3.7 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (10%) | 0.0 (0%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (7%) | 0.0 (0%) | 1.0 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.0 | 83% | 1.6 pts | 6 pts |
| character | 1.7 | 0.7 | 80% | 1.2 pts | 2 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 19.7 | 6.0 | 80% | 9.0 pts | 177 pts |
| monster | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 2.3 | 0.7 | 86% | 5.4 pts | 12 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.3 | 7.0 | 6.2 |
| Charges that made contact a game | 5.3 | 4.0 | 4.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (4 units) | 1.00 declared, 0.50 contact (2 units) | 1.00 declared, 0.83 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.60 contact (20 units) | 0.73 declared, 0.42 contact (26 units) | 0.67 declared, 0.50 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 50% (1 of 2) | 50% (1 of 2) | 29% (2 of 7) |
| Character in a unit | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Character on its own | 100% (2 of 2) | 50% (1 of 2) | 33% (3 of 9) | 46% (6 of 13) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 67% (4 of 6) | 100% (2 of 2) | - | 75% (6 of 8) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | - | - | 19% | 14% (1 of 7) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 64% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 8% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 50% (2 of 4); on the table 50% | - | 10% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 57% (4 of 7); on the table 71% | 67% (12 of 18) | 44% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p9, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 50% (5) | 57% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.33 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: nw22-19bea9b-p9

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 85% (11 of 13) | 30% (6 of 20) |
| Strategy | Shoot objectives carried out (shot that target) | 28% (5 of 18) | 0% (0 of 7) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 33% (1 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 78% (7 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 33.3 | 0.0 |
| Movement | Fights charged into per game | 5.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 12, net +0 | 1 of 8, net +30 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 12, net +154 | 0 of 8 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 12, net +70 | 2 of 8, net +129 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 12, net +50 | 3 of 8, net +134 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.3 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 68% (27 of 40) | 27% (6 of 22) |
| Shooting | Points destroyed by shooting units | 25.0 | 0.0 |
| Shooting | War machine shots | 2.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (2 of 7) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 33% (3 of 9) |
| Magic | Wounds caused by magic missiles | 0.7 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 26.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 0.7 / 0.0 | 2.0 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 577.0 | 312.0 |
| Combat | Points run down | 0.0 | 93.0 |
| Combat | Net points per charged fight, damage counted | +40 | +100 |
| Combat | Net per 100 charger points, damage counted | +13.8 | +27.4 |
| Combat | First round won (charged fights) | 60% | 67% |
| Combat | Net points per charged fight | +70 | +105 |
| Combat | Net points per supported fight / lone fight | +70 / +70 | +128 / +94 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 15 | 1 of 9 |
| Game | Points lost | 553.3 | 616.0 |
| Game | VP from objectives | 630.0 | 440.0 |
| Game | Lone holders (player turns) | 4.0 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +260 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1169
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: nw22-19bea9b-p9

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +67.6 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.7 | +30.5 | 0.0 | 0.0 |
| ARMY TABLE | 20.0 | +212.5 | 0.0 | 200.3 | 20.3 | +146.8 | 0.0 | 140.7 |
| ASSAILMENT BY POINTS | 0.3 | +2.0 | 0.0 | 61.7 | 1.0 | +3.0 | 0.0 | 380.7 |
| BACKS UP THE FIGHT | - | - | - | - | 2.3 | +60.8 | 0.0 | 56.7 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +5.6 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 2.3 | +44.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.3 | +10.3 | 0.0 | 132.7 | 1.3 | +4.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +126.3 | 0.0 | 0.0 |
| CHAFF PASSED | 1.3 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +25.9 | 0.0 | 91.7 | 0.7 | +12.8 | 0.0 | 63.3 |
| CHAMPION KNOWS CHALLENGE | 0.7 | -18.2 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.7 | -66.6 | 0.0 | 0.0 | 0.7 | -0.2 | 45.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.3 | +7.8 | 15.0 | 38.3 | - | - | - | - |
| CHARGE LOSSES | 12.7 | -489.2 | 0.0 | 340.0 | 12.0 | -1057.9 | 0.0 | 180.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 23.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 163.3 | 58.3 | 4.3 | +0.0 | 365.0 | 105.0 |
| CLEAR LANE AHEAD | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.3 | +0.0 | 0.0 | 126.0 | 21.7 | +0.0 | 0.0 | 53.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 25.0 |
| COVER ONCE | 15.3 | -577.1 | 0.0 | 172.0 | 8.7 | -547.9 | 0.0 | 56.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -11.8 | 45.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -35.2 | 0.0 | 0.0 | 6.7 | +23.0 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 1.0 | -50.9 | 45.0 | 0.0 |
| EXACT ROUND | 3.3 | +32.7 | 243.3 | 85.0 | 5.7 | +54.9 | 716.3 | 145.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +0.0 | 98.3 | 58.3 | 5.0 | +2.0 | 623.0 | 96.7 |
| FALLS SHORT | - | - | - | - | 19.7 | +281.2 | 0.0 | 248.7 |
| FEATURE BUFFS | 2.3 | +58.2 | 0.0 | 0.0 | 1.3 | +26.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +73.6 | 0.0 | 0.0 | 0.7 | -0.5 | 62.0 | 15.0 |
| FIVE ACTION | 83.3 | +5745.4 | 428.3 | 1180.3 | 88.7 | +4597.8 | 878.0 | 909.7 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 324.7 | 8.0 | +0.0 | 0.0 | 232.3 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +98.5 | 0.0 | 15.0 |
| FOUR ROUNDS | 4.7 | +416.1 | 283.3 | 85.0 | 7.3 | +313.8 | 761.3 | 161.7 |
| FREED FROM HIS FIGHT | 12.0 | +0.0 | 0.0 | 306.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -6.3 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.7 | -27.3 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -11.4 | 20.0 | 0.0 | 1.7 | -37.8 | 241.3 | 81.7 |
| GOAL WALK | 11.3 | +902.4 | 0.0 | 0.0 | 2.7 | +265.7 | 0.0 | 0.0 |
| GUN MASK | 0.7 | -4.1 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.0 | +3.1 | 0.0 | 0.0 | 1.7 | -6.5 | 132.7 | 16.7 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 6.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 1.0 | +0.0 | 95.0 | 26.7 | 0.7 | +0.0 | 0.0 | 16.7 |
| HELPER UNSEEN | 1.0 | +0.0 | 95.0 | 26.7 | 0.3 | +0.0 | 66.3 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.3 | +0.0 | 0.0 | 340.0 | 10.7 | +0.0 | 0.0 | 180.0 |
| HIS CHARGE LIST | 9.0 | +0.0 | 0.0 | 66.3 | 7.7 | +0.0 | 0.0 | 90.7 |
| HIS LEGAL MOVES | 8.7 | +0.0 | 0.0 | 100.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -3.8 | 0.0 | 116.7 | 8.7 | -84.1 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 53.3 | 1.7 | +0.0 | 0.0 | 66.7 |
| HIS OWN BEST MOVE | 14.7 | +0.0 | 0.0 | 100.0 | 11.3 | +0.0 | 0.0 | 23.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 33.3 | +266.5 | 0.0 | 545.0 | 43.3 | +1315.8 | 0.0 | 347.3 |
| HIS SHOTS BY HIS RUN | 21.3 | +180.7 | 0.0 | 295.3 | 34.3 | +425.4 | 0.0 | 269.3 |
| HIS TURN DENIED | - | - | - | - | 3.0 | +29.6 | 372.7 | 65.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 150.3 | 12.3 | +0.0 | 0.0 | 60.0 |
| HOLDER ASSIGNMENT | 9.7 | +807.3 | 0.0 | 174.7 | 8.0 | +598.8 | 0.0 | 60.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -136.9 | 260.0 | 85.0 | 6.3 | -215.5 | 703.0 | 145.0 |
| HUNT IN PAIRS | 1.7 | +13.5 | 0.0 | 58.3 | - | - | - | - |
| IDLE COST | - | - | - | - | 18.0 | -183.4 | 0.0 | 141.7 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | 1.0 | -77.5 | 88.3 | 0.0 | 3.0 | -34.4 | 289.7 | 146.7 |
| JOINT KNOWS CHALLENGE | 0.3 | -5.8 | 0.0 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +5.2 | 27.7 | 65.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.3 | 0.0 | 0.0 | 1.0 | +42.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.7 | +0.0 | 747.7 | 325.0 | 12.0 | +0.0 | 504.3 | 1370.3 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -3.4 | 0.0 | 0.0 | 3.3 | +7.6 | 236.7 | 31.7 |
| LOST CHARGE | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -99.5 | 0.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 3.3 | +20.3 | 0.0 | 16.7 |
| MANOEUVRE | 2.0 | -5.2 | 0.0 | 0.0 | 1.7 | +13.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +9.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +130.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +24.3 | 0.0 | 61.7 | 5.3 | +106.6 | 0.0 | 22.0 |
| MEETS IN TIME | 4.0 | +240.1 | 0.0 | 0.0 | 4.3 | +151.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +40.4 | 0.0 | 132.7 | 4.0 | +56.3 | 0.0 | 63.3 |
| MISSILES NEXT TURN | 3.0 | +41.5 | 0.0 | 66.3 | 4.3 | +45.4 | 0.0 | 63.3 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 20.0 |
| MOVE TO CHARGE COMPUTED | 10.7 | +563.4 | 0.0 | 183.3 | 10.3 | +709.5 | 0.0 | 80.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEAR WALKS ONLY | - | - | - | - | 3.3 | +0.0 | 0.0 | 40.0 |
| NEARER NOT NEEDED | 11.0 | +418.5 | 0.0 | 69.7 | 8.3 | +330.8 | 0.0 | 62.0 |
| NEXT CHARGE BY LIST | 7.7 | +412.7 | 0.0 | 183.3 | 6.0 | +436.0 | 0.0 | 0.0 |
| NO CHAFF EDGES | 3.7 | +70.1 | 86.7 | 116.7 | 4.3 | +97.0 | 306.0 | 195.0 |
| NO DOUBLE ROUNDS | 3.7 | -128.0 | 230.0 | 46.7 | 5.3 | -134.1 | 579.7 | 65.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -194.7 | 0.0 | 158.0 | 2.3 | -23.0 | 20.0 | 62.0 |
| ONE FIGHT FORMULA | 7.0 | -130.3 | 0.0 | 191.7 | 6.7 | -152.5 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +33.0 | 80.0 | 26.7 | 2.0 | +19.0 | 169.7 | 16.7 |
| ONE OBJECTIVE FORMULA | 5.0 | +1.9 | 0.0 | 42.0 | 3.0 | +10.4 | 0.0 | 20.0 |
| ONE PROMISE A TARGET | 1.0 | -41.8 | 0.0 | 0.0 | 1.0 | -38.7 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +15.7 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.0 | +3.2 | 43.3 | 20.0 | 3.3 | +88.8 | 306.0 | 130.0 |
| OVERRUNS AWAY | 1.3 | +4.0 | 115.0 | 26.7 | 1.3 | +29.1 | 128.3 | 15.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +25.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -16.8 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 38.3 | +452.9 | 515.7 | 963.7 | 46.3 | +570.4 | 538.3 | 831.3 |
| PROMISE BELOW ZERO | - | - | - | - | 1.0 | +0.0 | 0.0 | 23.3 |
| PROMISE BY ITS OWN SUM | 13.7 | -301.3 | 0.0 | 183.3 | 11.0 | -297.5 | 0.0 | 106.7 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 183.3 | 2.3 | +0.0 | 0.0 | 56.7 |
| PROMISE READS THE TABLE | 0.7 | -3.1 | 0.0 | 0.0 | 0.3 | -15.6 | 0.0 | 23.3 |
| QUARTER ODDS | 19.3 | +2031.5 | 90.0 | 372.0 | 19.3 | +2368.7 | 132.7 | 243.3 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +91.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +38.6 | 0.0 | 26.7 | 4.7 | +518.1 | 0.0 | 44.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 26.7 | 3.0 | +116.3 | 0.0 | 37.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -65.9 | 0.0 | 0.0 | 2.0 | -26.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +22.9 | 0.0 | 26.7 | 0.7 | +7.7 | 0.0 | 78.3 |
| RISK BY ARC | 3.7 | +193.4 | 213.3 | 85.0 | 5.0 | -108.5 | 506.0 | 146.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.0 | -27.1 | 261.7 | 16.7 |
| RUN DOWN | - | - | - | - | 5.0 | -43.4 | 409.7 | 96.7 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -22.7 | 0.0 | 0.0 |
| SEARCH SPOT | 1.3 | +16.5 | 0.0 | 38.3 | 1.0 | +6.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +30.6 | 20.0 | 0.0 | 0.3 | +13.8 | 20.0 | 15.0 |
| SELF MOVE SPELL | 2.0 | +37.1 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -31.9 | 0.0 | 115.0 | 2.0 | -105.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.7 | +0.8 | 0.0 | 115.0 | 4.3 | +78.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +5.2 | 0.0 | 61.7 | 3.3 | +20.3 | 0.0 | 16.7 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 132.7 | 4.7 | +0.0 | 0.0 | 125.3 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +36.4 | 0.0 | 66.3 | 0.7 | +12.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -5.6 | 0.0 | 38.3 | 0.3 | -25.5 | 58.3 | 0.0 |
| SHOT RISK POINTS | 12.0 | +32.5 | 0.0 | 108.7 | 29.3 | -168.0 | 0.0 | 307.3 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.3 | +358.8 | 0.0 | 180.7 | 7.0 | +51.0 | 0.0 | 202.3 |
| SPELL WORTH | 1.3 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.7 | +0.0 | 0.0 | 181.0 | 6.7 | +0.0 | 0.0 | 46.7 |
| STAND AND SHOOT | 0.7 | -0.9 | 40.0 | 0.0 | 2.3 | -32.0 | 247.7 | 65.0 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 0.0 | 156.7 |
| STANDS STILL | 29.3 | +0.0 | 145.0 | 482.3 | 15.3 | +0.0 | 116.7 | 172.7 |
| STAY WORTH | 11.3 | +113.6 | 130.0 | 38.3 | 5.7 | +28.7 | 58.3 | 162.3 |
| STRIKE BY THE ODDS | 0.7 | +1.9 | 80.0 | 78.3 | 1.0 | +7.6 | 43.0 | 38.3 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 2.3 | -8.0 | 0.0 | 0.0 |
| STUBBORN ONCE | 0.3 | -0.3 | 65.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +289.5 | 0.0 | 55.3 | 6.7 | +253.1 | 0.0 | 45.3 |
| SUPPORT NARROWED | 1.0 | +0.0 | 15.0 | 46.7 | 0.3 | +0.0 | 42.0 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +289.5 | 0.0 | 55.3 | 6.7 | +253.1 | 0.0 | 45.3 |
| SURE REACH TOGETHER | 1.3 | +11.7 | 0.0 | 61.7 | 1.3 | +15.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 26.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.3 | -3.5 | 15.0 | 26.7 | 1.3 | +27.2 | 145.3 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.2 | 0.0 | 0.0 | 0.3 | -15.6 | 0.0 | 23.3 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 38.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 46.7 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 128.0 | 2.7 | +0.0 | 0.0 | 46.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.0 | +0.0 | 0.0 | 547.7 | 44.3 | +0.0 | 0.0 | 359.0 |
| TIED UP BY THE SUM | 1.7 | +109.6 | 118.3 | 58.3 | 2.7 | +252.9 | 286.7 | 65.0 |
| TIME ON OUR SIDE | 38.3 | +523.8 | 0.0 | 690.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -7.1 | 30.0 | 0.0 | 0.7 | +7.3 | 40.0 | 30.0 |
| WHO FIGHTS | 0.3 | -1.4 | 15.0 | 26.7 | 0.3 | +1.0 | 0.0 | 0.0 |
| WHO GETS IN | 0.3 | -21.0 | 23.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | -2.1 | 15.0 | 0.0 | 0.3 | +3.0 | 20.0 | 15.0 |
| WHOLE FIGHT DANGER | 4.3 | -439.3 | 0.0 | 284.7 | 3.3 | -844.6 | 0.0 | 156.7 |
| WHOLE FIGHT GAIN | 0.7 | +56.8 | 65.0 | 0.0 | 1.7 | +61.8 | 103.3 | 16.7 |
| WHOLE FIGHT REACTION | 3.3 | +211.7 | 130.0 | 294.7 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.7 | +0.0 | 132.7 | 0.0 |
| WOUNDS ON THE RANKS | 0.3 | +2.3 | 0.0 | 0.0 | 5.0 | +67.0 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p9

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 121 | 121 | 89 | 29.67 | +1282 | +14.4 |
| LEGAL CHARGES ONLY | 56 | 56 | 56 | 18.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 53 | 53 | 49 | 16.33 | +3381 | +69.0 |
| HIS SHOT LIST | 230 | 215 | 44 | 14.67 | +337 | +7.7 |
| FIVE ACTION | 516 | 488 | 34 | 11.33 | +1314 | +38.7 |
| PROMISE BY ITS OWN SUM | 74 | 74 | 31 | 10.33 | -1796 | -57.9 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -654 | -27.2 |
| MOVE TO CHARGE COMPUTED | 63 | 53 | 22 | 7.33 | +285 | +12.9 |
| QUARTER ODDS | 116 | 105 | 22 | 7.33 | +1406 | +63.9 |
| HIS SHOTS BY HIS RUN | 167 | 160 | 20 | 6.67 | +58 | +2.9 |
| DEPLOY BY FIGURES | 42 | 42 | 17 | 5.67 | +216 | +12.7 |
| MEETS IN TIME | 25 | 25 | 15 | 5.00 | +893 | +59.5 |
| NEXT CHARGE BY LIST | 41 | 39 | 14 | 4.67 | +188 | +13.5 |
| NO CHAFF EDGES | 24 | 24 | 14 | 4.67 | +295 | +21.1 |
| FOUR ROUNDS | 36 | 34 | 13 | 4.33 | +531 | +40.8 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +244 | +18.8 |
| JOINT CHARGE NOW | 12 | 12 | 12 | 4.00 | -336 | -28.0 |
| SET UP BY THE SET | 24 | 22 | 12 | 4.00 | +247 | +20.6 |
| COVER ONCE | 72 | 45 | 11 | 3.67 | +239 | +21.7 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SUPPORT ADDS | 29 | 29 | 9 | 3.00 | +169 | +18.8 |
| SUPPORT WORKED OUT | 29 | 29 | 9 | 3.00 | +169 | +18.8 |
| TIED UP BY THE SUM | 13 | 12 | 9 | 3.00 | +366 | +40.6 |
| GOAL WALK | 42 | 42 | 8 | 2.67 | +538 | +67.3 |
| SHOT RISK POINTS | 124 | 118 | 8 | 2.67 | +65 | +8.1 |
| IDLE COST | 54 | 45 | 7 | 2.33 | +56 | +8.0 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +236 | +33.7 |
| TIME ON OUR SIDE | 115 | 87 | 7 | 2.33 | +31 | +4.4 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 9 | 9 | 6 | 2.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 24 | 22 | 6 | 2.00 | +13 | +2.1 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -242 | -40.3 |
| RISK BY ARC | 26 | 25 | 6 | 2.00 | +196 | +32.6 |
| SEARCH SPOT | 7 | 7 | 6 | 2.00 | +69 | +11.4 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 6 | 2.00 | +41 | +6.8 |
| CHARGE NOW FIRST | 19 | 19 | 5 | 1.67 | -188 | -37.5 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +374 | +74.8 |
| STRIKE BY THE ODDS | 5 | 5 | 5 | 1.67 | +29 | +5.7 |
| SURE REACH TOGETHER | 8 | 8 | 5 | 1.67 | +5 | +1.1 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +15 | +3.8 |
| BACKS UP THE FIGHT | 7 | 5 | 4 | 1.33 | +17 | +4.2 |
| CAST JOB | 8 | 8 | 4 | 1.33 | +6 | +1.6 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| EXACT ROUND | 27 | 26 | 4 | 1.33 | +8 | +2.1 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +295 | +73.8 |
| NEARER NOT NEEDED | 58 | 55 | 4 | 1.33 | +139 | +34.7 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +92 | +23.0 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| WHOLE FIGHT DANGER | 23 | 23 | 4 | 1.33 | +94 | +23.6 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +116 | +38.7 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| OPENS UP IN FULL | 13 | 13 | 3 | 1.00 | +77 | +25.8 |
| OVERRUNS AWAY | 8 | 6 | 3 | 1.00 | +15 | +5.1 |
| STAY WORTH | 51 | 43 | 3 | 1.00 | +52 | +17.4 |
| WHOLE FIGHT GAIN | 7 | 7 | 3 | 1.00 | +162 | +54.1 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +203 | +101.5 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +92 | +45.8 |
| CHARGE LOSSES | 74 | 74 | 2 | 0.67 | +27 | +13.3 |
| CHARGE NOT DECLARED | 2 | 2 | 2 | 0.67 | -279 | -139.7 |
| HUNT IN PAIRS | 5 | 5 | 2 | 0.67 | +7 | +3.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +43 | +21.5 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +75 | +37.7 |
| REDIRECT COUNTER | 18 | 16 | 2 | 0.67 | +75 | +37.3 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +403 | +201.5 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -15 | -7.4 |
| SCOUT BY DROPS | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +133 | +66.6 |
| SUPPORT NARROWED | 4 | 4 | 2 | 0.67 | -119 | -59.7 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 10 | 10 | 2 | 0.67 | +5 | +2.4 |
| WOUNDS ON THE RANKS | 16 | 16 | 2 | 0.67 | +56 | +28.2 |
| CANNON PLANNED TARGET | 7 | 7 | 1 | 0.33 | -26 | -26.4 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +23 | +23.4 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 11 | 11 | 1 | 0.33 | +18 | +17.9 |
| HIS TURN DENIED | 9 | 9 | 1 | 0.33 | +14 | +13.8 |
| HONEST WORTH | 32 | 30 | 1 | 0.33 | +2 | +2.4 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +16 | +15.6 |
| LOST AFTER ESCAPE | 13 | 12 | 1 | 0.33 | +0 | +0.1 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +6 | +6.3 |
| MISSILES IN THE MOVE | 21 | 12 | 1 | 0.33 | +26 | +25.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NO DOUBLE ROUNDS | 27 | 26 | 1 | 0.33 | +2 | +2.4 |
| ONE JOINT FIGURE | 8 | 8 | 1 | 0.33 | +54 | +54.0 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +34 | +33.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -50 | -50.3 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -5 | -4.8 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 1 | 0.33 | +102 | +101.7 |
| REFORMS TO MEET IT | 12 | 12 | 1 | 0.33 | +4 | +3.5 |
| RUN DOWN | 15 | 14 | 1 | 0.33 | +2 | +2.4 |
| SET UP TOGETHER | 12 | 7 | 1 | 0.33 | +6 | +5.7 |
| STAND AND SHOOT | 9 | 8 | 1 | 0.33 | +2 | +2.4 |
| THE FIGHT MOVES | 8 | 8 | 1 | 0.33 | +43 | +43.4 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -63 | -63.0 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.33 | -59 | -59.2 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 99 | 94 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 22 | 20 | 0 | 0.00 | - | - |
| FALLS SHORT | 59 | 53 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 51 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 50 | 42 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 8 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 27 | 24 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 5 | 5 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 66 | 66 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 50 | 47 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 46 | 44 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 38 | 36 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 13 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 78 | 72 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 82 | 82 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 10 | not checked | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 17 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 41 | 26 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 24 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 254 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 11 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 10 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 31 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 14 | 14 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 64 | 47 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 46 | 41 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 134 | 129 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 7 | 7 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 244 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p9

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.67 | 4.67 | 57.9 |
| JOB FIRST | gate | 3.67 | 1.67 | 35.1 |
| ARMY TABLE | rule | 2.33 | 1.00 | 48.8 |
| JOINT CHARGE NOW | rule | 1.00 | 2.00 | 73.3 |
| CHARGE NOW FIRST | rule | 0.33 | 1.33 | 37.5 |
| ONE PROMISE A TARGET | rule | 0.67 | 1.00 | 48.4 |
| RULE SWITCHED OFF | gate | 1.00 | - | 26.3 |
| AFTERMATH BAND | gate | 0.67 | - | 2.7 |
| CHARGE NOT DECLARED | rule | 0.33 | 0.33 | 139.7 |
| REFUSING RETIRES | rule | 0.67 | - | 7.4 |
| SUPPORT NARROWED | rule | 0.67 | - | 59.7 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 26.4 |
| FIGHT ORDER BAND | gate | 0.33 | - | 2.0 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 1.1 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 8.5 |
| NO REASON | gate | - | 0.33 | 3.7 |
| PATHS CROSS | rule | - | 0.33 | 6.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 50.3 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 4.8 |
| RESERVE FALL BACK | rule | - | 0.33 | 2.2 |
| TURN GATE | gate | - | 0.33 | 1.8 |
| WHO GETS IN | rule | 0.33 | - | 63.0 |
| WOUNDED STAYS OUT | rule | - | 0.33 | 59.2 |

### Plans: nw22-19bea9b-p9

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 90% | 372 | 264 | 71% |
| Mine | move | 30.0 | 96% | 1748 | 0 | 0% |
| Mine | shoot | 5.0 | 53% | 339 | 189 | 56% |
| Opponent | charge | 6.3 | 58% | 794 | 512 | 64% |
| Opponent | join | 2.7 | 88% | 110 | 0 | 0% |
| Opponent | move | 34.3 | 93% | 1204 | 0 | 0% |
| Opponent | shoot | 1.3 | 25% | 157 | 58 | 37% |
| Opponent | support | 1.7 | 100% | 58 | 0 | 0% |

### Battle groups: nw22-19bea9b-p9

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 4.7 | 7% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p9

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 2 | 28 (2) | 28 | 0 | 100 | 0% | 2.0 | 28 (2) | - | - | - | 28 (2) |
| Mine | Character | 8 | 46 (8) | 46 | 0 | 10 | 12% | 3.0 | 29 (5) | 74 (3) | - | 31 (7) | 115 (1) |
| Mine | Clean-up | 1 | 15 (1) | 15 | 0 | 100 | 0% | 3.0 | 15 (1) | - | - | 15 (1) | - |
| Mine | Fast Hammer | 4 | 36 (4) | 4 | 32 | 54 | 0% | 2.8 | - | 36 (4) | - | 151 (1) | 5 (3) |
| Mine | Hammer | 4 | 36 (4) | 36 | 0 | 19 | 50% | 1.0 | 0 (1) | 64 (2) | 0 (1) | 93 (2) | 0 (2) |
| Mine | Shooter | 6 | 69 (6) | 11 | 58 | 51 | 0% | 1.7 | 71 (1) | 57 (3) | 97 (2) | 94 (4) | 29 (2) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 0% | 4.0 | - | - | - | - | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 35 (8) | 35 | 0 | 45 | 62% | 3.0 | 0 (4) | 71 (4) | - | 0 (3) | 54 (5) |
| Opponent | Character | 9 | 40 (9) | 40 | 0 | 30 | 33% | 3.8 | 59 (5) | 18 (3) | 0 (1) | 46 (5) | 26 (4) |
| Opponent | Clean-up | 2 | 20 (2) | 20 | 0 | 0 | 100% | - | 31 (1) | 0 (1) | - | 20 (2) | - |
| Opponent | Fast Hammer | 10 | 37 (10) | 23 | 14 | 27 | 10% | 3.1 | 30 (3) | 16 (4) | 74 (3) | 0 (6) | 68 (4) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 127 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | Holder | 3 | 16 (3) | 0 | 16 | 62 | 0% | 1.7 | 0 (1) | 25 (2) | - | 25 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 5 | 13 (5) | 13 | 0 | 44 | 20% | 2.0 | 16 (3) | 0 (1) | - | 20 (2) | 0 (2) |

### Charged fights: nw22-19bea9b-p9

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 75 | 806 | 6.0 | 1.0 | 134 | 19 | +115 | 4 of 6 | 2 of 6 | - | +115 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 45 | 2.0 | 1.0 | 22 | 0 | +22 | 0 of 2 | 2 of 2 | - | +22 |
| Mine | Lizardmen | 1 | 0 | 780 | 7.0 | 1.1 | 111 | 67 | +45 | 2 of 7 | 5 of 7 | +70 | +40 |
| **Mine** | all armies | 3 | 25 | 544 | 5.0 | 1.1 | 109 | 39 | +70 | 6 of 15 | 9 of 15 | +70 | +70 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 258 | 4.0 | 1.5 | 64 | 0 | +64 | 0 of 4 | 3 of 4 | +129 | +0 |
| Opponent | Vampire Counts | 2 | 40 | 370 | 2.5 | 1.2 | 148 | 10 | +138 | 1 of 5 | 3 of 5 | +126 | +141 |
| **Opponent** | all armies | 3 | 27 | 333 | 3.0 | 1.3 | 111 | 6 | +105 | 1 of 9 | 6 of 9 | +128 | +94 |

### Effective charges: nw22-19bea9b-p9

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 6 | 1 (net +0) | 0 | 2 (net +286) | 0 | 0 | 3 (net +40) | 0 | 33% (2 of 6) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 2 (net +22) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Mine | Lizardmen | 7 | 0 | 0 | 0 | 1 (net -272) | 1 (net +70) | 2 (net +65) | 3 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 1 (net +0) | 2 (net +129) | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Vampire Counts | 5 | 1 (net +30) | 0 | 0 | 1 (net +0) | 0 | 2 (net +200) | 1 | 0% (0 of 4) |

### Charged fights, damage counted: nw22-19bea9b-p9

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 432 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 4 | 272 | 235 | +154 | 164 | 110 | +54 | +19.7 |
| Mine | 76-89% | 1 | 175 | 195 | -272 | 195 | 467 | -272 | -155.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 184 | 88 | +50 | 75 | 39 | +36 | +19.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 804 | 70 | +70 | 70 | 0 | +70 | +8.7 |
| Mine | No odds | 3 | 317 | 147 | +128 | 136 | 0 | +136 | +42.8 |
| Mine | All fights | 15 | 291 | 164 | +70 | 114 | 74 | +40 | +13.8 |
| Opponent | Long shot (under 50%) | 1 | 50 | 277 | +30 | 80 | 50 | +30 | +60.0 |
| Opponent | 76-89% | 2 | 308 | 104 | +0 | 31 | 0 | +31 | +10.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 431 | 192 | +134 | 149 | 21 | +129 | +29.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 630 | 155 | +129 | 129 | 0 | +129 | +20.5 |
| Opponent | No odds | 1 | 45 | 60 | +259 | 259 | 100 | +160 | +354.4 |
| Opponent | All fights | 9 | 363 | 159 | +105 | 123 | 24 | +100 | +27.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p9 | move | 31 | 9 (29%) | 7 (23%) | 4 (13%) | 18 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

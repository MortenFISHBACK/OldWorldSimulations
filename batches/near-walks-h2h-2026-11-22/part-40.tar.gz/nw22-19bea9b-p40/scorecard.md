# Doctrine scorecard: nw22-19bea9b-p40

### Scorecard: nw22-19bea9b-p40

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 335 |
| L0528 | 6 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 2 | - | 1 | 3 | 0 | 0 | 0 | 466 |
| L0616 | 4 | 1 | Opponent | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 280 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 5 | 1 | 0 | 0 | 0 | 275 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.0 | 3.0 | 2.0 | 1.7 | 0.0 | 0.0 | 0.0 | 358.7 |
| **Average** | | | Opponent | 0% | 0.0 | 3.0 | 0.3 | 2.3 | 0.3 | 0.0 | 0.0 | 93.3 |

### KPIs: nw22-19bea9b-p40

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (16 of 16) | 0% (0 of 15) | 52% (16 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 100% (2 of 2); on the table 100% | 75% (3 of 4); on the table 75% |
| Magic missiles tried each own turn | 50%+ | - | 33% (2 of 6) | 33% (2 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 33% (2 of 6) | 33% (2 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 83% (10 of 12) | 83% (10 of 12) |
| Points that never fought | lower | 89% (5361 of 6000) | 89% (5315 of 5999) | 89% (10676 of 11999) |
|   infantry points that never fought | lower | 81% (1813 of 2232) | 91% (657 of 720) | 84% (2470 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (20 of 27) | 81% (17 of 21) | 77% (37 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (3005 of 4232) | 85% (4596 of 5415) | 79% (7601 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.3 (25%) | 0.3 (25%) |
| MARCHED: its unit marched | - | 0.3 (25%) | 0.3 (25%) |
| STUPIDITY: Stupidity | - | 0.7 (50%) | 0.7 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.7 | 0.0 | 0.7 | 0.0 |
| not cast | 2.3 | 2.0 | 1.3 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (33%) | 0.3 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.7 (29%) | 0.7 (33%) | 0.7 (50%) | 1.0 (25%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (57%) | 0.7 (33%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (75%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (139 of 199) | 32% (11 of 34) | 64% (150 of 233) |
|   cavalry | 47% (9 of 19) | 42% (5 of 12) | 45% (14 of 31) |
|   character | 87% (26 of 30) | 0% (0 of 12) | 62% (26 of 42) |
|   infantry | 58% (29 of 50) | 0% (0 of 2) | 56% (29 of 52) |
|   monster | 58% (7 of 12) | - | 58% (7 of 12) |
|   war machine | 77% (68 of 88) | 75% (6 of 8) | 77% (74 of 96) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.7 (23%) | 2.3 (30%) | 7.0 (25%) |
| CHARGED: it charged | 2.0 (10%) | 0.3 (4%) | 2.3 (8%) |
| IN COMBAT: it fought this turn or the last | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 2.3 (12%) | 4.0 (52%) | 6.3 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 8.3 (42%) | 0.3 (4%) | 8.7 (31%) |
| SHELTERED: the target was sheltered | 1.3 (7%) | 0.7 (9%) | 2.0 (7%) |
| OTHER BAR | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 2.7 | 53% | 13.6 pts | 68 pts |
| character | 8.7 | 4.3 | 65% | 15.7 pts | 136 pts |
| infantry | 19.0 | 7.0 | 74% | 11.0 pts | 210 pts |
| monster | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 24.7 | 17.0 | 61% | 15.9 pts | 391 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 1.0 | 2.5 |
| Charges that made contact a game | 1.7 | 0.3 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.24 contact (21 units) | 0.15 declared, 0.05 contact (20 units) | 0.37 declared, 0.15 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | 50% (1 of 2) | 50% (3 of 6) |
| Character in a unit | 86% (6 of 7) | 100% (2 of 2) | - | 89% (8 of 9) |
| Character on its own | - | 100% (3 of 3) | 100% (4 of 4) | 100% (7 of 7) |
| Infantry | 43% (3 of 7) | 67% (4 of 6) | - | 54% (7 of 13) |
| Monster | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 89% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 86% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 90% | 80% (12 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p40, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 50% (2) | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: nw22-19bea9b-p40

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 44% (4 of 9) | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 62% (55 of 88) | 0% (0 of 6) |
| Strategy | Joined characters whose unit fought | 8% (1 of 12) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 14% (1 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 2.3 |
| Movement | Points that never moved of their own | 358.7 | 93.3 |
| Movement | Fights charged into per game | 1.7 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +0 | 1 of 1, net +186 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +0 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 24.7 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 66% (49 of 74) | 40% (2 of 5) |
| Shooting | Points destroyed by shooting units | 332.3 | 0.0 |
| Shooting | War machine shots | 22.7 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (41 of 68) | 17% (1 of 6) |
| Shooting | Points destroyed by war machines | 37.0 | 78.3 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 100% (2 of 2) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 1.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 62.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +14 | +186 |
| Combat | Net per 100 charger points, damage counted | +17.1 | +295.2 |
| Combat | First round won (charged fights) | 60% | 100% |
| Combat | Net points per charged fight | +0 | +186 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +186 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 1 of 1 |
| Game | Points lost | 210.3 | 406.0 |
| Game | VP from objectives | 456.7 | 516.7 |
| Game | Lone holders (player turns) | 1.0 | 0.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +290 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 616
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p40

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 6.3 | +85.8 | 0.0 | 0.0 | 17.0 | +279.8 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 2.3 | +0.0 | 828.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 20.7 | +662.7 | 1953.7 | 66.7 | 1.0 | +32.1 | 38.3 | 66.7 |
| CANNON SIGHT KEPT | 4.0 | +0.0 | 0.0 | 38.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 0.3 | +0.7 | 0.0 | 119.0 |
| CHAFF IN THE MOVE | - | - | - | - | 4.7 | +120.0 | 0.0 | 20.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +78.4 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.7 | 62.0 | 0.0 |
| CHARACTER GUNS | 8.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 5.7 | -91.4 | 0.0 | 120.0 | 24.7 | -1569.7 | 0.0 | 1106.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 62.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 82.0 | 0.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -5.1 | 62.0 | 0.0 |
| CLEAR LANE AHEAD | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 90.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 6.7 | -654.8 | 0.0 | 0.0 | 4.7 | -198.8 | 0.0 | 74.0 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.8 | 62.0 | 0.0 |
| DEPLOY BY FIGURES | 10.7 | -119.8 | 0.0 | 0.0 | 6.0 | +70.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +7.2 | 62.0 | 0.0 |
| EXACT ROUND | 2.7 | +7.3 | 0.0 | 0.0 | 0.7 | +2.8 | 20.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.7 | +0.1 | 10.0 | 0.0 | - | - | - | - |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 15.0 | +289.0 | 0.0 | 449.7 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +2.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 132.0 | +6854.6 | 5961.3 | 253.3 | 69.0 | +2453.3 | 318.7 | 1578.3 |
| FLANK NOT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 334.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.0 | +54.3 | 10.0 | 0.0 | 1.0 | +37.1 | 82.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 4.7 | -155.4 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | - | - | - | - | 13.3 | +1116.0 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +5.0 | 46.3 | 0.0 | - | - | - | - |
| GUN MASK | 3.7 | +97.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 1.0 | -1.8 | 0.0 | 0.0 | 0.3 | +0.0 | 62.0 | 0.0 |
| HARD STAY DROPPED | 5.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 2.7 | +0.0 | 0.0 | 40.0 | 12.3 | +0.0 | 0.0 | 776.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 80.0 | 20.0 | +0.0 | 0.0 | 453.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 314.0 |
| HIS MOVE AND SHOT | 3.3 | -30.1 | 0.0 | 40.0 | 5.3 | -64.7 | 0.0 | 638.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 314.0 |
| HIS RANDOM MOVE | 13.0 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 33.7 | +1174.1 | 0.0 | 80.0 | 61.0 | +5463.7 | 0.0 | 1326.0 |
| HIS SHOTS BY HIS RUN | 9.0 | +93.1 | 0.0 | 120.0 | 46.3 | +1406.4 | 0.0 | 1279.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +22.1 | 62.0 | 0.0 |
| HOLD ODDS | 10.3 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 0.0 | 492.7 |
| HOLDER ASSIGNMENT | 9.0 | +1050.5 | 0.0 | 0.0 | 8.7 | +981.3 | 0.0 | 365.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -18.5 | 10.0 | 0.0 | 0.7 | -28.3 | 20.0 | 0.0 |
| IDLE COST | - | - | - | - | 18.3 | -326.1 | 0.0 | 213.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 1.3 | +67.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 0.0 | 62.0 | 0.7 | +0.0 | 62.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +16.0 | 0.0 | 0.0 | 0.3 | +0.2 | 62.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +2.8 | 0.0 | 0.0 | 0.3 | -0.1 | 62.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.3 | 0.0 | 0.0 | 0.7 | +6.0 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | -1.5 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 74.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +46.9 | 0.0 | 119.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -18.1 | 0.0 | 119.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.7 | +19.0 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 6.3 | +318.2 | 0.0 | 0.0 | 3.3 | +286.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 1.0 | +4.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.3 | +4.5 | 0.0 | 119.0 |
| MODEL FACING | 4.0 | +702.0 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.0 | +297.3 | 0.0 | 40.0 | 3.7 | +213.1 | 0.0 | 0.0 |
| NEAR WALKS ONLY | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.3 | +204.8 | 0.0 | 0.0 | 1.7 | +58.3 | 0.0 | 37.0 |
| NEXT CHARGE BY LIST | 2.7 | +139.9 | 0.0 | 0.0 | 2.7 | +127.5 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.0 | +12.7 | 0.0 | 62.0 | 1.7 | +28.3 | 0.0 | 10.0 |
| NO DOUBLE ROUNDS | 3.3 | -51.9 | 10.0 | 0.0 | 1.0 | -17.1 | 82.0 | 0.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 10.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -1.2 | 0.0 | 0.0 |
| OFF BEST | 6.0 | -207.3 | 0.0 | 0.0 | 3.0 | -67.4 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -2.7 | 62.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -44.8 | 0.0 | 20.0 | 3.3 | -76.6 | 0.0 | 46.3 |
| ONE JOINT FIGURE | 0.7 | -8.0 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.0 | -48.4 | 0.0 | 0.0 | 3.3 | -20.0 | 0.0 | 193.0 |
| ONE PROMISE A TARGET | 0.3 | -9.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.3 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +2.8 | 0.0 | 0.0 | 1.0 | +62.6 | 82.0 | 0.0 |
| PLAN RESULT | 59.0 | +2522.1 | 3088.3 | 248.7 | 34.0 | +115.2 | 142.0 | 752.3 |
| PRIZE BY WORTH | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 157.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -187.3 | 0.0 | 40.0 | 4.0 | -63.1 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 4.0 | -149.1 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 2.0 | -17.3 | 74.0 | 0.0 | 0.7 | -40.1 | 80.0 | 33.3 |
| QUARTER ODDS | 13.3 | +690.4 | 1570.0 | 0.0 | 8.7 | +1051.1 | 0.0 | 314.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +73.3 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +25.7 | 0.0 | 0.0 | 1.0 | +22.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 20.0 |
| REDIRECT WEIGHED | 1.3 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.3 | -48.1 | 0.0 | 40.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +45.4 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +83.0 | 10.0 | 0.0 | 1.0 | -77.7 | 82.0 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 3.3 | -18.2 | 10.0 | 0.0 | 0.7 | -1.8 | 82.0 | 0.0 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 4.7 | -157.9 | 0.0 | 20.0 |
| SEARCH SPOT | 0.7 | +18.0 | 0.0 | 20.0 | - | - | - | - |
| SECOND LOOK | 1.0 | +19.3 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 5.3 | -335.0 | 0.0 | 0.0 | 1.7 | -33.6 | 0.0 | 26.7 |
| SET UP BY THE SET | 6.3 | +398.4 | 157.0 | 0.0 | 2.0 | +31.2 | 0.0 | 26.7 |
| SET UP TOGETHER | 0.7 | +0.5 | 0.0 | 0.0 | 1.3 | +6.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 29.3 | +0.0 | 0.0 | 66.7 | 3.0 | +0.0 | 0.0 | 66.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +136.2 | 314.0 | 0.0 | 0.7 | +3.9 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 1.7 | -8.3 | 10.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 17.3 | +700.8 | 0.0 | 120.0 | 39.0 | -456.9 | 0.0 | 1188.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 41.0 | +1944.7 | 0.0 | 86.7 | 4.3 | +208.9 | 0.0 | 140.7 |
| SPELL WORTH | - | - | - | - | 1.7 | +25.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 20.0 | 7.7 | +0.0 | 0.0 | 166.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -8.1 | 62.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 95.3 | +0.0 | 5951.3 | 213.3 | 17.3 | +0.0 | 236.7 | 305.7 |
| STAY WORTH | 74.3 | +823.8 | 4133.3 | 200.0 | 6.7 | +218.8 | 236.7 | 237.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.7 | -32.5 | 0.0 | 238.0 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.7 | +54.3 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.7 | +54.3 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 1.7 | +14.7 | 0.0 | 0.0 | 0.7 | +19.2 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.3 | 0.0 | 10.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.0 | +3.3 | 0.0 | 0.0 | 0.3 | +4.5 | 62.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 20.0 | 3.3 | +0.0 | 0.0 | 10.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 56.0 | +0.0 | 0.0 | 86.7 | 31.7 | +0.0 | 0.0 | 729.7 |
| TIED UP BY THE SUM | 1.0 | +28.2 | 0.0 | 0.0 | 0.7 | +58.1 | 20.0 | 0.0 |
| TIME ON OUR SIDE | 52.0 | +593.6 | 550.0 | 20.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | -18.6 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.7 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -8.3 | 0.0 | 0.0 | 0.3 | +1.1 | 20.0 | 0.0 |
| WHOLE FIGHT DANGER | - | - | - | - | 3.3 | -140.2 | 0.0 | 388.0 |
| WHOLE FIGHT REACTION | 1.0 | +63.5 | 0.0 | 82.0 | 3.7 | +60.6 | 0.0 | 20.0 |
| WOUNDS ON THE RANKS | 2.7 | +16.9 | 0.0 | 0.0 | 8.7 | +383.0 | 0.0 | 238.0 |

### Rule changes: nw22-19bea9b-p40

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 284 | 280 | 73 | 24.33 | +1929 | +26.4 |
| ARMY TABLE | 70 | 70 | 54 | 18.00 | +852 | +15.8 |
| HOLDER ASSIGNMENT | 53 | 53 | 48 | 16.00 | +3305 | +68.8 |
| SHOT RISK POINTS | 169 | 166 | 31 | 10.33 | +1092 | +35.2 |
| FIVE ACTION | 603 | 589 | 27 | 9.00 | +1324 | +49.0 |
| HIS SHOTS BY HIS RUN | 166 | 164 | 27 | 9.00 | +740 | +27.4 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -824 | -30.5 |
| DEPLOY BY FIGURES | 50 | 50 | 26 | 8.67 | +480 | +18.5 |
| TIME ON OUR SIDE | 156 | 142 | 24 | 8.00 | +135 | +5.6 |
| CANNON PLANNED TARGET | 65 | 65 | 21 | 7.00 | -143 | -6.8 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 29 | 24 | 16 | 5.33 | +377 | +23.5 |
| PROMISE BY ITS OWN SUM | 38 | 38 | 14 | 4.67 | -751 | -53.7 |
| CANNON SIGHT KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +2106 | +175.5 |
| SET UP BY THE SET | 25 | 22 | 12 | 4.00 | +527 | +43.9 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 10 | 3.33 | +220 | +22.0 |
| CHAFF IN THE MOVE | 14 | 13 | 8 | 2.67 | +33 | +4.1 |
| FOUR ROUNDS | 15 | 13 | 8 | 2.67 | +84 | +10.5 |
| GOAL WALK | 40 | 40 | 8 | 2.67 | +458 | +57.3 |
| MEETS IN TIME | 29 | 29 | 8 | 2.67 | +96 | +12.0 |
| PROMISE SHOT AWAY | 8 | 8 | 8 | 2.67 | -172 | -21.5 |
| IDLE COST | 55 | 37 | 7 | 2.33 | +130 | +18.5 |
| NEXT CHARGE BY LIST | 16 | 15 | 7 | 2.33 | +259 | +36.9 |
| NO CHAFF EDGES | 8 | 7 | 7 | 2.33 | +110 | +15.7 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 20 | 20 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 136 | 118 | 6 | 2.00 | +389 | +64.8 |
| CHARGE LOSSES | 91 | 89 | 5 | 1.67 | +512 | +102.5 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RISK BY ARC | 12 | 10 | 5 | 1.67 | +46 | +9.3 |
| SURE REACH TOGETHER | 7 | 6 | 5 | 1.67 | +36 | +7.2 |
| WHOLE FIGHT REACTION | 14 | 14 | 5 | 1.67 | +56 | +11.3 |
| ARTILLERY RE-ROLL WEIGHED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +204 | +50.9 |
| LEGAL CHARGES ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +111 | +27.8 |
| THE ROW IN ITS ORDER | 16 | 4 | 4 | 1.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 5 | 4 | 4 | 1.33 | +29 | +7.2 |
| EXACT ROUND | 10 | 8 | 3 | 1.00 | +2 | +0.8 |
| GUN MASK | 12 | 11 | 3 | 1.00 | +43 | +14.2 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +766 | +255.5 |
| MAX FOR POSITIONING | 5 | 5 | 3 | 1.00 | +0 | +0.0 |
| OVERRUNS AWAY | 5 | 5 | 3 | 1.00 | +28 | +9.2 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +58 | +19.3 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 34 | 32 | 3 | 1.00 | +298 | +99.5 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 4 | 4 | 2 | 0.67 | -34 | -17.1 |
| COVER ONCE | 34 | 21 | 2 | 0.67 | +44 | +22.2 |
| FALLS SHORT | 45 | 34 | 2 | 0.67 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 2 | 2 | 2 | 0.67 | +33 | +16.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 19 | 15 | 2 | 0.67 | +166 | +82.8 |
| QUARTER ODDS | 66 | 62 | 2 | 0.67 | +111 | +55.4 |
| REDIRECT COUNTER | 4 | 3 | 2 | 0.67 | +44 | +22.2 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +136 | +68.0 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +54 | +27.0 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 2 | 0.67 | +106 | +52.8 |
| THE FIGHT MOVES | 4 | 3 | 2 | 0.67 | +11 | +5.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +9 | +9.2 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +235 | +235.2 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +20 | +19.6 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -9 | -8.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| HIS MOVE AND SHOT | 26 | 26 | 1 | 0.33 | +2 | +2.5 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +15 | +14.9 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +141 | +140.7 |
| NEARER NOT NEEDED | 18 | 15 | 1 | 0.33 | +30 | +29.9 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -29 | -29.2 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +6 | +6.4 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -13 | -13.3 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -56 | -55.9 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.33 | +12 | +12.3 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 2 | 1 | 0.33 | +0 | +0.4 |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 24 | 23 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 37 | 37 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 9 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 15 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 15 | 11 | 0 | 0.00 | - | - |
| GIVES UP | 2 | not checked | - | - | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 45 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 68 | 68 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 21 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 14 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 30 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 39 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 73 | 72 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 5 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MANOEUVRE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 3 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 4 | 2 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 16 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 1 | not checked | - | - | - | - |
| PLAN RESULT | 279 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 13 | 13 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 21 | 18 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 6 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 97 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 37 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 338 | 336 | 0 | 0.00 | - | - |
| STAY WORTH | 243 | 229 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 5 | 5 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 11 | 6 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 11 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 263 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p40

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 2.33 | 25.1 |
| CANNON PLANNED TARGET | rule | 5.00 | - | 10.6 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 0.67 | 53.7 |
| PROMISE SHOT AWAY | rule | 2.00 | 0.67 | 21.5 |
| ARMY TABLE | rule | 0.67 | 1.33 | 11.8 |
| NO REASON | gate | 1.67 | - | 58.4 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 33.7 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 17.1 |
| FALLBACK | gate | 0.33 | 0.33 | 4.9 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 8.7 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 46.7 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 29.2 |
| RULE SWITCHED OFF | gate | - | 0.33 | 45.8 |
| SUPPORT NARROWED | rule | 0.33 | - | 13.3 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 55.9 |

### Plans: nw22-19bea9b-p40

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 22% | 144 | 72 | 50% |
| Mine | join | 1.7 | 100% | 52 | 0 | 0% |
| Mine | move | 30.0 | 98% | 1198 | 0 | 0% |
| Mine | shoot | 24.3 | 81% | 1823 | 2450 | 134% |
| Opponent | charge | 1.0 | 67% | 32 | 77 | 243% |
| Opponent | move | 29.3 | 92% | 1228 | 0 | 0% |
| Opponent | shoot | 1.3 | 25% | 103 | 38 | 37% |
| Opponent | support | 2.3 | 86% | 45 | 0 | 0% |

### Battle groups: nw22-19bea9b-p40

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 67% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p40

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 23 (13) | 23 | 0 | 0 | 23% | 2.8 | 0 (1) | 27 (11) | 0 (1) | 28 (10) | 0 (3) |
| Mine | Clean-up | 4 | 22 (4) | 22 | 0 | 0 | 50% | 1.0 | 0 (1) | 232 (1) | 0 (2) | 38 (3) | 0 (1) |
| Mine | Hammer | 5 | 57 (5) | 0 | 57 | 0 | 40% | 3.7 | - | 106 (3) | 0 (2) | 57 (5) | - |
| Mine | Shooter | 10 | 72 (10) | 33 | 39 | 17 | 0% | 1.8 | 0 (1) | 67 (5) | 115 (4) | 49 (8) | 162 (2) |
| Mine | War machine | 17 | 8 (17) | 8 | 0 | 20 | 12% | 1.5 | 0 (3) | 21 (5) | 3 (9) | 0 (3) | 10 (14) |
| Opponent | Chaff | 5 | 23 (5) | 0 | 23 | 54 | 60% | 3.5 | 0 (2) | 38 (2) | 0 (1) | 0 (4) | 75 (1) |
| Opponent | Character | 8 | 0 (8) | 0 | 0 | 18 | 88% | 5.0 | 0 (2) | 0 (2) | 0 (3) | 0 (5) | 0 (2) |
| Opponent | Clean-up | 2 | 86 (2) | 0 | 86 | 0 | 50% | 6.0 | - | 86 (2) | - | 86 (2) | - |
| Opponent | Fast Hammer | 4 | 25 (4) | 0 | 25 | 32 | 100% | - | 0 (1) | 50 (1) | 16 (2) | 25 (4) | - |
| Opponent | Hammer | 4 | 25 (4) | 25 | 0 | 0 | 50% | 4.5 | - | 0 (2) | 47 (2) | 25 (4) | - |
| Opponent | Holder | 2 | 84 (2) | 0 | 84 | 100 | 50% | 3.0 | 0 (1) | 189 (1) | - | 84 (2) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | War machine | 2 | 118 (2) | 118 | 0 | 50 | 0% | 1.0 | - | 118 (2) | - | - | 118 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | - | 0 (1) | 0 (1) | - |

### Charged fights: nw22-19bea9b-p40

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 369 | 0 | 1.7 | 1.0 | 0 | 0 | +0 | 1 of 5 | 3 of 5 | - | +0 |
| Opponent | Kingdom of Bretonnia | 1 | 235 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 2 | 0 | 93 | 0.5 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |
| **Opponent** | all armies | 3 | 78 | 62 | 0.3 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |

### Effective charges: nw22-19bea9b-p40

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 1 (net +0) | 1 | 0% (0 of 4) |
| Opponent | Warriors of Chaos | 1 | 1 (net +186) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p40

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 50 | 170 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 2 | 65 | 41 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 183 | 275 | +0 | 84 | 26 | +57 | +31.3 |
| Mine | No odds | 1 | 60 | 135 | +0 | 15 | 0 | +15 | +25.0 |
| Mine | All fights | 5 | 85 | 132 | +0 | 20 | 5 | +14 | +17.1 |
| Opponent | Long shot (under 50%) | 1 | 63 | 186 | +186 | 186 | 0 | +186 | +295.2 |
| Opponent | All fights | 1 | 63 | 186 | +186 | 186 | 0 | +186 | +295.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p40 | move | 17 | 3 (18%) | 1 (6%) | 2 (12%) | 12 (71%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

# Doctrine scorecard: nw22-19bea9b-p32

### Scorecard: nw22-19bea9b-p32

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | yes | 6 | 3 | 2 | 1 | 0 | 0 | 0 | 375 |
| L1431 | 3 | 1 | Mine | yes | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 0 | 3 | 0 | 0 | 562 |
| **Average** | | | Mine | 67% | 2.0 | 2.0 | 2.7 | 0.7 | 0.0 | 0.0 | 0.0 | 206.3 |
| **Average** | | | Opponent | 67% | 3.0 | 2.0 | 2.3 | 2.0 | 1.0 | 0.0 | 0.0 | 312.3 |

### KPIs: nw22-19bea9b-p32

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 6% (1 of 16) | 0% (0 of 13) | 3% (1 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 80% | 100% (4 of 4); on the table 100% | 78% (7 of 9); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 17% (3 of 18) | 25% (6 of 24) | 21% (9 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 27% (3 of 11) | 29% (6 of 21) | 28% (9 of 32) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 62% (5 of 8) | 62% (5 of 8) |
| Points that never fought | lower | 48% (2904 of 6000) | 30% (1800 of 6000) | 39% (4704 of 12000) |
|   infantry points that never fought | lower | 57% (746 of 1315) | 46% (426 of 921) | 52% (1172 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 44% (11 of 25) | 84% (27 of 32) | 67% (38 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.7 uses a game | 50% (1 of 2); 1.0 uses a game | 75% (3 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 10% (1 of 10); 0.7 uses a game | 0.0 uses a game | 10% (1 of 10); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (2488 of 5720) | 82% (4773 of 5830) | 63% (7261 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (33%) | 1.0 (17%) | 2.7 (24%) |
| MARCHED: its unit marched | 0.7 (13%) | 0.0 (0%) | 0.7 (6%) |
| CHARGED: its unit charged | 0.3 (7%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.0 (20%) | 0.3 (6%) | 1.3 (12%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.0 (67%) | 4.0 (36%) |
| GONE: slain | 1.3 (27%) | 0.0 (0%) | 1.3 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (11%) | 0.7 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 0.7 | 2.7 | 3.0 | 0.0 | 2.0 |
| not cast | 3.7 | 3.3 | 3.3 | 11.0 | 2.0 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (50%) | 0.0 (0%) | 2.7 (24%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (10%) | 0.7 (20%) | 1.3 (12%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (55%) | 0.0 (0%) | 2.0 (60%) | 4.0 (36%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.0 (0%) | 1.3 (40%) | 0.0 (0%) | 1.3 (12%) | 1.3 (67%) | 5.0 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (45%) | 0.0 (0%) | 0.7 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 75% (6 of 8) | - | 75% (6 of 8) |
| the unit moved after it | 33% (2 of 6) | - | 33% (2 of 6) |
| it charged on its next turn | 17% (1 of 6) | - | 17% (1 of 6) |
| the enemy charged it first | 0% (0 of 6) | - | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 6) | - | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | - | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 83% (5 of 6) | - | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (64 of 93) | 59% (16 of 27) | 67% (80 of 120) |
|   cavalry | 43% (3 of 7) | 69% (11 of 16) | 61% (14 of 23) |
|   character | 34% (11 of 32) | 17% (1 of 6) | 32% (12 of 38) |
|   infantry | 87% (26 of 30) | 80% (4 of 5) | 86% (30 of 35) |
|   war machine | 100% (24 of 24) | - | 100% (24 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (38%) | 2.7 (73%) | 6.3 (48%) |
| CHARGED: it charged | 3.3 (34%) | 0.3 (9%) | 3.7 (28%) |
| IN COMBAT: it fought this turn or the last | 1.0 (10%) | 0.3 (9%) | 1.3 (10%) |
| NO TARGET IN RANGE | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (7%) | 0.3 (9%) | 1.0 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 1.7 | 78% | 12.4 pts | 95 pts |
| character | 5.7 | 1.3 | 82% | 3.6 pts | 20 pts |
| infantry | 18.7 | 6.7 | 75% | 8.5 pts | 158 pts |
| war machine | 8.0 | 5.3 | 54% | 16.0 pts | 128 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 3.3 | 4.5 |
| Charges that made contact a game | 3.3 | 1.7 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | - | 1.00 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.64 declared, 0.36 contact (22 units) | 0.43 declared, 0.22 contact (23 units) | 0.53 declared, 0.29 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (7 of 15) | 100% (2 of 2) | - | 53% (9 of 17) |
| Character in a unit | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Character on its own | 75% (3 of 4) | 75% (3 of 4) | 43% (3 of 7) | 60% (9 of 15) |
| Infantry | 75% (9 of 12) | 50% (1 of 2) | - | 71% (10 of 14) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 60% (3 of 5); on the table 80% | 17% (3 of 18) | 48% | 44% (11 of 25) | 100% (2 of 2); 3.7 uses a game | 10% (1 of 10); 0.7 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 12) | 33% | 100% (8 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | 33% (2 of 6) | 6% | 83% (10 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 51% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p32, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 20% (1) | 38% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: nw22-19bea9b-p32

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 57% (8 of 14) | 29% (2 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (16 of 40) | 40% (2 of 5) |
| Strategy | Support requests answered (helper made contact too) | 60% (3 of 5) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | - | 80% (4 of 5) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 100% (7 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.7 | 2.0 |
| Movement | Points that never moved of their own | 206.3 | 312.3 |
| Movement | Fights charged into per game | 2.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 6, net +0 | 1 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +446 | 1 of 3, net +330 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 1 of 3, net +151 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +72 | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.7 | 5.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (14 of 41) | 81% (13 of 16) |
| Shooting | Points destroyed by shooting units | 75.3 | 0.0 |
| Shooting | War machine shots | 8.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (10 of 24) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 2.3 | 2.0 |
| Magic | Wounds caused by other spells | 3.7 | - |
| Magic | Points destroyed by magic (all spells) | 76.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.7 / 0.0 / 1.7 / 0.0 | 0.3 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 437.0 | 166.7 |
| Combat | Points run down | 0.0 | 41.0 |
| Combat | Net points per charged fight, damage counted | +192 | +74 |
| Combat | Net per 100 charger points, damage counted | +43.5 | +31.1 |
| Combat | First round won (charged fights) | 86% | 40% |
| Combat | Net points per charged fight | +208 | +38 |
| Combat | Net points per supported fight / lone fight | +350 / +185 | - / +38 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 7 | 2 of 5 |
| Game | Points lost | 258.0 | 905.7 |
| Game | VP from objectives | 843.3 | 386.7 |
| Game | Lone holders (player turns) | 2.0 | 3.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1154 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1164
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: nw22-19bea9b-p32

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 25.0 | -11.2 | 0.0 | 182.7 | 24.3 | +418.4 | 0.0 | 287.7 |
| ASSAILMENT BY POINTS | 0.7 | +2.9 | 0.0 | 333.3 | - | - | - | - |
| BACKS UP THE FIGHT | 2.3 | +147.1 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.3 | +0.0 | 0.0 | 50.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 36.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +58.0 | 73.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +13.2 | 46.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +16.8 | 0.0 | 50.3 | 1.3 | +102.4 | 0.0 | 158.3 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -5.4 | 116.7 | 0.0 | 0.3 | +10.9 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 1.0 | -181.6 | 131.7 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +56.5 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.3 | -403.1 | 0.0 | 41.0 | 20.3 | -1471.8 | 0.0 | 730.7 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.7 | +0.0 | 554.0 | 0.0 | 2.0 | +0.0 | 207.7 | 77.3 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 150.0 |
| CONVEYANCE SEARCH | 2.0 | +144.1 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 6.3 | -337.4 | 0.0 | 41.0 | 5.7 | -471.1 | 0.0 | 160.7 |
| DENIED BY THE FIGHT | 1.7 | -8.6 | 276.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.7 | -7.2 | 0.0 | 0.0 | 7.0 | +48.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | +23.6 | 83.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 1.0 | +36.0 | 142.7 | 0.0 | 0.3 | +3.8 | 50.3 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.3 | +2.5 | 0.0 | 116.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 5.7 | +2391.5 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +28.9 | 489.7 | 0.0 | 1.0 | +14.0 | 166.7 | 38.7 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.3 | +5.7 | 276.0 | 0.0 | 2.0 | +0.1 | 258.0 | 77.3 |
| FALLS SHORT | - | - | - | - | 16.0 | +290.0 | 0.0 | 534.0 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +1.8 | 116.7 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.3 | +11.4 | 0.0 | 38.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 99.7 | +6500.5 | 1626.7 | 283.3 | 63.7 | +3365.0 | 258.0 | 1439.3 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 100.7 | 5.3 | +0.0 | 0.0 | 77.3 |
| FOCUS FIRE | 0.7 | +34.7 | 38.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +332.1 | 0.0 | 0.0 | 0.3 | +27.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.3 | +327.2 | 987.3 | 0.0 | 2.3 | +173.5 | 258.0 | 77.3 |
| FREED FROM HIS FIGHT | - | - | - | - | 3.3 | +0.0 | 0.0 | 172.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -6.4 | 153.3 | 0.0 | - | - | - | - |
| GOAL WALK | 6.0 | +453.3 | 0.0 | 0.0 | 14.0 | +957.8 | 0.0 | 167.3 |
| GUN FIGURES | 1.0 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.7 | +0.0 | 0.0 | 144.0 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 116.7 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 521.3 |
| HIS CHARGE DENIED | 1.7 | +30.6 | 583.3 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 36.7 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.3 | -23.2 | 0.0 | 0.0 | 4.3 | -12.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 100.7 | 5.3 | +0.0 | 0.0 | 190.7 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 154.7 |
| HIS RANDOM MOVE | 10.3 | +0.0 | 0.0 | 82.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 41.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.0 | +849.9 | 0.0 | 82.0 | 36.7 | +951.1 | 0.0 | 832.0 |
| HIS SHOTS BY HIS RUN | 29.7 | +585.4 | 0.0 | 242.3 | 46.0 | +1011.8 | 0.0 | 1172.7 |
| HIS TURN DENIED | 1.3 | +71.7 | 159.3 | 0.0 | - | - | - | - |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 48.0 |
| HOLDER ASSIGNMENT | 9.7 | +661.6 | 0.0 | 0.0 | 4.3 | +323.9 | 0.0 | 48.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -147.5 | 404.0 | 0.0 | 2.0 | -57.7 | 91.3 | 38.7 |
| HUNT RESULT | - | - | - | - | 0.3 | +209.6 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +224.0 | 166.7 | 38.7 |
| IDLE COST | - | - | - | - | 10.0 | -147.3 | 0.0 | 164.0 |
| JOINT CHARGE NOW | 2.3 | -17.4 | 659.3 | 0.0 | 0.7 | +37.9 | 0.0 | 0.0 |
| JOINT ON THE TABLE | 0.3 | +31.6 | 116.7 | 0.0 | 0.3 | +38.9 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 48.0 |
| LANE BY FIGURES | 1.3 | +134.5 | 0.0 | 0.0 | 0.7 | +21.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 298.7 | 456.3 | 3.7 | +0.0 | 0.0 | 802.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +0.7 | 317.0 | 0.0 | 0.7 | -0.0 | 0.0 | 0.0 |
| LOST CHARGE | 0.7 | -3.1 | 153.3 | 0.0 | - | - | - | - |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +2.8 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | -1.5 | 0.0 | 0.0 | 0.7 | +5.2 | 0.0 | 40.0 |
| MARCH BY THE SUM | 0.3 | +12.2 | 0.0 | 0.0 | 0.7 | +3.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +53.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +19.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -14.2 | 0.0 | 0.0 | 0.3 | -6.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.0 |
| MAX FOR POSITIONING | 1.0 | +36.0 | 0.0 | 0.0 | 1.3 | +34.7 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | +193.0 | 0.0 | 0.0 | 3.7 | +48.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.3 | +76.5 | 0.0 | 0.0 | 5.3 | +111.7 | 0.0 | 148.7 |
| MISSILES NEXT TURN | 5.3 | +45.9 | 0.0 | 0.0 | 6.0 | +110.8 | 0.0 | 148.7 |
| MOVE ORDER | 1.7 | +0.0 | 82.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 7.7 | +633.9 | 0.0 | 100.7 | 4.7 | +179.2 | 0.0 | 154.7 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEAR WALKS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.0 | +306.2 | 0.0 | 0.0 | 4.0 | +141.4 | 0.0 | 94.7 |
| NEXT CHARGE BY LIST | 3.0 | +366.7 | 0.0 | 0.0 | 4.7 | +147.4 | 0.0 | 77.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -0.6 | 0.0 | 48.0 |
| NO CHAFF EDGES | 3.0 | +103.0 | 222.0 | 0.0 | 1.7 | +25.0 | 500.0 | 85.3 |
| NO DOUBLE ROUNDS | 4.0 | -304.6 | 637.3 | 0.0 | 2.0 | -66.8 | 207.7 | 77.3 |
| NO LATE CUT | 3.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +57.9 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 1.3 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -126.6 | 0.0 | 0.0 | 3.3 | -65.3 | 0.0 | 161.0 |
| ONE CHALLENGE TEST | 0.3 | -5.4 | 116.7 | 0.0 | 0.3 | +10.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 50.3 | 1.0 | +0.0 | 0.0 | 48.0 |
| ONE FIGHT FORMULA | 5.3 | -110.2 | 0.0 | 50.3 | 4.7 | -111.2 | 0.0 | 209.0 |
| ONE JOINT FIGURE | 1.7 | +120.6 | 583.3 | 0.0 | 0.7 | +44.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -7.0 | 0.0 | 0.0 | 0.7 | +8.3 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.0 | +9.8 | 148.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +39.3 | 211.3 | 0.0 | 0.3 | +0.8 | 166.7 | 38.7 |
| PATHS CROSS | - | - | - | - | 0.3 | +20.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -9.9 | 0.0 | 0.0 |
| PLAN RESULT | 44.0 | +1659.5 | 533.0 | 308.3 | 32.3 | +374.0 | 301.3 | 1068.3 |
| PRIZE BY WORTH | 0.3 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.3 | -202.4 | 0.0 | 100.7 | 5.0 | -2.5 | 0.0 | 77.3 |
| PROMISE KNOWS THE FIGHT | 2.7 | -5.8 | 0.0 | 0.0 | 1.7 | -7.3 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -5.6 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 33.0 | +2855.3 | 134.7 | 201.3 | 17.3 | +2326.2 | 50.3 | 230.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +42.1 | 0.0 | 170.0 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +35.3 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 38.7 |
| REFORMS TO MEET IT | 1.0 | -32.4 | 0.0 | 0.0 | 0.7 | -39.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| RESERVE FALL BACK | - | - | - | - | 1.7 | +78.2 | 0.0 | 38.0 |
| RISK BY ARC | 4.7 | +54.5 | 939.3 | 0.0 | 1.7 | +62.8 | 207.7 | 77.3 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.0 |
| ROUNDS AFTER TERROR | 1.0 | -27.2 | 196.7 | 0.0 | 0.3 | -6.8 | 50.3 | 0.0 |
| RUN DOWN | 4.3 | -142.8 | 754.0 | 0.0 | 2.0 | -5.7 | 258.0 | 77.3 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | -0.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +71.0 | 48.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -14.8 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | -0.4 | 0.0 | 0.0 | 1.0 | -12.9 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +22.9 | 0.0 | 0.0 | 1.0 | +3.1 | 0.0 | 48.0 |
| SET-UP ANY TARGET | 0.3 | +35.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 46.7 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +8.9 | 134.7 | 0.0 | 1.3 | +8.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -31.5 | 164.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 16.3 | -245.3 | 0.0 | 82.0 | 24.7 | -496.0 | 0.0 | 618.0 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 20.3 | +482.6 | 0.0 | 0.0 | 4.7 | +124.0 | 0.0 | 121.3 |
| SPELL SETS UP CHARGE | 0.3 | +35.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 3.7 | +92.6 | 0.0 | 0.0 | 0.7 | +0.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.7 | +14.9 | 356.0 | 0.0 | 0.3 | -9.6 | 166.7 | 38.7 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 290.7 |
| STAND AND SHOOT | 1.0 | -20.3 | 112.7 | 0.0 | 0.7 | -7.4 | 41.0 | 38.7 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 46.7 |
| STANDS STILL | 57.3 | +0.0 | 639.3 | 100.7 | 15.3 | +0.0 | 0.0 | 357.3 |
| STAY WORTH | 34.3 | +77.7 | 341.3 | 0.0 | 6.7 | +19.8 | 0.0 | 36.7 |
| STOPS | - | - | - | - | 0.3 | +19.0 | 166.7 | 38.7 |
| STRIKE BY THE ODDS | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.0 | +482.9 | 0.0 | 0.0 | 4.3 | +258.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.0 | +482.9 | 0.0 | 0.0 | 4.3 | +258.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 3.3 | +16.3 | 0.0 | 0.0 | 1.3 | +5.6 | 0.0 | 38.7 |
| SWIFTSTRIDE BY POINTS | 0.3 | +13.6 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 3.7 | +21.3 | 846.3 | 0.0 | 1.7 | +0.7 | 217.0 | 38.7 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 55.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | - | - | - | - | 2.3 | +0.0 | 0.0 | 40.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.0 | +0.0 | 0.0 | 141.7 | 29.0 | +0.0 | 0.0 | 617.7 |
| TIED UP BY THE SUM | 2.0 | +189.9 | 197.7 | 0.0 | 0.3 | +18.5 | 41.0 | 38.7 |
| TIME ON OUR SIDE | 40.7 | +439.6 | 73.3 | 41.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -63.6 | 333.3 | 77.3 |
| WHO FIGHTS | 1.0 | +0.4 | 154.7 | 0.0 | - | - | - | - |
| WHO GETS IN | - | - | - | - | 0.7 | +37.9 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +40.5 | 166.7 | 38.7 |
| WHOLE FIGHT DANGER | 1.0 | -91.9 | 0.0 | 0.0 | 3.3 | -925.4 | 0.0 | 396.0 |
| WHOLE FIGHT GAIN | 1.7 | +152.7 | 583.3 | 0.0 | 0.7 | +21.1 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 2.3 | +103.6 | 78.7 | 91.3 | 3.3 | +162.0 | 0.0 | 366.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +224.9 | 0.0 | 167.3 |

### Rule changes: nw22-19bea9b-p32

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 148 | 148 | 102 | 34.00 | +1393 | +13.7 |
| HIS SHOT LIST | 203 | 196 | 55 | 18.33 | +998 | +18.1 |
| HIS SHOTS BY HIS RUN | 227 | 224 | 46 | 15.33 | +491 | +10.7 |
| HOLDER ASSIGNMENT | 42 | 42 | 37 | 12.33 | +2613 | +70.6 |
| FIVE ACTION | 490 | 481 | 26 | 8.67 | +1445 | +55.6 |
| QUARTER ODDS | 151 | 148 | 26 | 8.67 | +2908 | +111.8 |
| DEPLOY BY FIGURES | 41 | 41 | 24 | 8.00 | +227 | +9.5 |
| LEGAL CHARGES ONLY | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| SHOT RISK POINTS | 123 | 121 | 22 | 7.33 | +571 | +26.0 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| HARD STAY DROPPED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 37 | 33 | 19 | 6.33 | +719 | +37.8 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -576 | -32.0 |
| GOAL WALK | 60 | 60 | 15 | 5.00 | +974 | +64.9 |
| PROMISE BY ITS OWN SUM | 43 | 43 | 14 | 4.67 | -615 | -43.9 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| CHARGE LOSSES | 98 | 97 | 12 | 4.00 | +342 | +28.5 |
| FOUR ROUNDS | 23 | 23 | 12 | 4.00 | +295 | +24.6 |
| NO CHAFF EDGES | 14 | 14 | 12 | 4.00 | +363 | +30.3 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 122 | 104 | 11 | 3.67 | +32 | +3.0 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +62 | +6.9 |
| NEXT CHARGE BY LIST | 23 | 23 | 9 | 3.00 | +393 | +43.7 |
| EVASIVE BY THE ODDS | 17 | 17 | 7 | 2.33 | +3772 | +538.9 |
| SUPPORT ADDS | 25 | 25 | 7 | 2.33 | +220 | +31.4 |
| SUPPORT WORKED OUT | 25 | 25 | 7 | 2.33 | +220 | +31.4 |
| CANNON PLANNED TARGET | 24 | 24 | 6 | 2.00 | -5 | -0.9 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +357 | +59.6 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +466 | +77.8 |
| MEETS IN TIME | 19 | 19 | 6 | 2.00 | +162 | +27.0 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 5 | 1.67 | +126 | +25.3 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +235 | +46.9 |
| RISK BY ARC | 19 | 19 | 5 | 1.67 | +55 | +11.0 |
| SET UP BY THE SET | 7 | 7 | 5 | 1.67 | -35 | -7.0 |
| TIED UP BY THE SUM | 7 | 7 | 5 | 1.67 | +166 | +33.1 |
| COVER ONCE | 36 | 22 | 4 | 1.33 | +108 | +26.9 |
| FALLS SHORT | 48 | 40 | 4 | 1.33 | +19 | +4.7 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +1079 | +269.7 |
| MISSILES IN THE MOVE | 32 | 23 | 4 | 1.33 | +31 | +7.8 |
| ONE JOINT FIGURE | 7 | 7 | 4 | 1.33 | +107 | +26.7 |
| PROMISE KNOWS THE FIGHT | 13 | 11 | 4 | 1.33 | -39 | -9.9 |
| STAY WORTH | 123 | 104 | 4 | 1.33 | +71 | +17.7 |
| SURE REACH TOGETHER | 14 | 12 | 4 | 1.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 7 | 7 | 4 | 1.33 | +107 | +26.7 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 30 | 16 | 3 | 1.00 | +18 | +5.8 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +303 | +101.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +46 | +15.4 |
| MAX FOR POSITIONING | 7 | 7 | 3 | 1.00 | +5 | +1.7 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +531 | +177.0 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +8 | +2.7 |
| WHOLE FIGHT REACTION | 17 | 17 | 3 | 1.00 | +62 | +20.6 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +9 | +4.4 |
| BACKS UP THE FIGHT | 7 | 5 | 2 | 0.67 | +37 | +18.4 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +18 | +8.8 |
| EXACT ROUND | 9 | 9 | 2 | 0.67 | +42 | +20.8 |
| FOCUS FIRE | 2 | 2 | 2 | 0.67 | +104 | +52.0 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +22 | +10.8 |
| JOINT ON THE TABLE | 2 | 2 | 2 | 0.67 | +212 | +105.8 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +16 | +7.8 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +90 | +45.1 |
| NEARER NOT NEEDED | 30 | 27 | 2 | 0.67 | +101 | +50.5 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +213 | +106.6 |
| SHOTS AFTER THE MOVES | 17 | 17 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 75 | 54 | 2 | 0.67 | +28 | +14.0 |
| SPELLS IN THE FIGHT | 6 | 6 | 2 | 0.67 | +7 | +3.7 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +114 | +56.9 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| CANNON SIGHT KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -4 | -4.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +169 | +169.4 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -3 | -3.1 |
| CHARGE NOW FIRST | 14 | 14 | 1 | 0.33 | -56 | -55.6 |
| DUEL STOPS AT THE KILL | 1 | 1 | 1 | 0.33 | +8 | +8.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +34 | +34.2 |
| HIS CHARGE DENIED | 5 | 5 | 1 | 0.33 | +3 | +3.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -60 | -59.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +65 | +65.1 |
| ONE OBJECTIVE FORMULA | 15 | 10 | 1 | 0.33 | +3 | +3.0 |
| OPENS UP IN FULL | 3 | 3 | 1 | 0.33 | +8 | +8.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +62 | +62.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -30 | -29.6 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +28 | +28.0 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | +51 | +51.3 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -5 | -5.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +5 | +4.7 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +41 | +40.9 |
| THE FIGHT MOVES | 16 | 16 | 1 | 0.33 | +8 | +8.5 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +3 | +3.1 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +102 | +102.4 |
| WHOLE FIGHT DANGER | 13 | 13 | 1 | 0.33 | +4 | +3.9 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 40 | 40 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 7 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 49 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 24 | 24 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 20 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 27 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 35 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 31 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 1 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 64 | 64 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 17 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 34 | 23 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEAR WALKS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 18 | 18 | 0 | 0.00 | - | - |
| NO LATE CUT | 11 | 11 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 6 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 30 | 13 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 229 | trace | - | - | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 19 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 48 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 38 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 218 | 217 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 9 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 228 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p32

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 2.33 | 3.00 | 46.3 |
| JOB FIRST | gate | 2.00 | 3.00 | 25.7 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 0.67 | 43.9 |
| CANNON PLANNED TARGET | rule | 1.33 | - | 1.3 |
| HOLDER ASSIGNMENT | rule | 1.33 | - | 22.0 |
| JOINT CHARGE NOW | rule | 1.00 | 0.33 | 65.3 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 1.00 | 9.9 |
| SET UP BY THE SET | rule | - | 0.67 | 37.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 169.8 |
| CHAFF PASSED | rule | 0.33 | - | 4.0 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 3.1 |
| CHARGE NOW FIRST | rule | 0.33 | - | 55.6 |
| MARCH OF THE TABLE | rule | - | 0.33 | 59.7 |
| NO REASON | gate | 0.33 | - | 1.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 29.6 |
| REFUSING RETIRES | rule | - | 0.33 | 5.0 |
| RULE SWITCHED OFF | gate | - | 0.33 | 19.2 |
| WHO GETS IN | rule | - | 0.33 | 2.8 |

### Plans: nw22-19bea9b-p32

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.3 | 75% | 649 | 939 | 145% |
| Mine | move | 28.3 | 98% | 1832 | 0 | 0% |
| Mine | shoot | 10.3 | 65% | 412 | 721 | 175% |
| Opponent | charge | 1.7 | 80% | 209 | 355 | 170% |
| Opponent | join | 1.7 | 80% | 73 | 0 | 0% |
| Opponent | move | 27.3 | 90% | 1492 | 0 | 0% |
| Opponent | shoot | 1.7 | 20% | 55 | 19 | 35% |

### Packages: hunt the guns, nw22-19bea9b-p32

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 672 | 629 | 100% | 18 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Warriors of Chaos | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 672 | 629 | 100% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: nw22-19bea9b-p32

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p32

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 77 (8) | 77 | 0 | 17 | 12% | 2.0 | 69 (3) | 80 (5) | - | 95 (2) | 71 (6) |
| Mine | Clean-up | 2 | 98 (2) | 0 | 98 | 50 | 50% | 2.0 | - | 98 (2) | - | 98 (2) | - |
| Mine | Fast Hammer | 8 | 49 (8) | 21 | 28 | 13 | 75% | 3.5 | 42 (4) | 56 (4) | - | 56 (3) | 45 (5) |
| Mine | Holder | 2 | 78 (2) | 0 | 78 | 0 | 50% | 1.0 | 78 (2) | - | - | 78 (2) | - |
| Mine | Shooter | 5 | 33 (5) | 33 | 0 | 0 | 0% | 1.0 | 45 (3) | 16 (2) | - | 41 (4) | 0 (1) |
| Mine | War machine | 4 | 20 (4) | 20 | 0 | 0 | 0% | 1.0 | 0 (2) | 39 (2) | - | 0 (2) | 39 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 29 (9) | 29 | 0 | 50 | 0% | 3.0 | 0 (5) | 54 (4) | - | 0 (4) | 48 (5) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 33% | 4.0 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 47 (3) | 0 | 47 | 36 | 0% | 2.7 | 47 (3) | - | - | 209 (1) | 0 (2) |
| Opponent | Hammer | 8 | 13 (8) | 13 | 0 | 35 | 50% | 3.2 | 0 (4) | 36 (3) | 0 (1) | 0 (4) | 31 (4) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Shooter | 3 | 8 (3) | 0 | 8 | 100 | 0% | 1.0 | - | 26 (1) | 0 (2) | - | 8 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 34 | 0% | 4.0 | 0 (2) | 0 (1) | - | - | 0 (3) |

### Charged fights: nw22-19bea9b-p32

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 152 | 486 | 2.3 | 1.4 | 208 | 0 | +208 | 3 of 7 | 6 of 7 | +350 | +185 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 500 | 2.0 | 1.0 | 250 | 230 | +20 | 2 of 2 | 0 of 2 | - | +20 |
| Opponent | Wood Elf Realms | 1 | 0 | 151 | 2.0 | 1.0 | 76 | 0 | +76 | 0 of 2 | 1 of 2 | - | +76 |
| **Opponent** | all armies | 3 | 0 | 217 | 1.7 | 1.0 | 130 | 92 | +38 | 2 of 5 | 2 of 5 | - | +38 |

### Effective charges: nw22-19bea9b-p32

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 7 | 1 (net +0) | 0 | 1 (net +446) | 2 (net +362) | 0 | 2 (net +72) | 1 | 17% (1 of 6) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 1 (net +330) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Wood Elf Realms | 2 | 1 (net +0) | 0 | 0 | 0 | 1 (net +151) | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: nw22-19bea9b-p32

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 400 | 343 | +0 | 79 | 229 | -149 | -37.4 |
| Mine | Effective (55-75%) | 1 | 489 | 201 | +446 | 446 | 0 | +446 | +91.2 |
| Mine | 76-89% | 2 | 658 | 230 | +362 | 436 | 41 | +395 | +60.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 199 | 142 | +72 | 72 | 15 | +57 | +28.6 |
| Mine | No odds | 1 | 489 | 144 | +144 | 144 | 0 | +144 | +29.4 |
| Mine | All fights | 7 | 442 | 205 | +208 | 241 | 49 | +192 | +43.5 |
| Opponent | Long shot (under 50%) | 1 | 102 | 162 | +0 | 77 | 0 | +77 | +75.9 |
| Opponent | Effective (55-75%) | 1 | 116 | 500 | +330 | 500 | 170 | +330 | +284.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 151 | +151 | 151 | 55 | +96 | +19.1 |
| Opponent | No odds | 2 | 235 | 360 | -145 | 78 | 145 | -67 | -28.4 |
| Opponent | All fights | 5 | 237 | 306 | +38 | 177 | 103 | +74 | +31.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p32 | move | 14 | 2 (14%) | 2 (14%) | 1 (7%) | 11 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

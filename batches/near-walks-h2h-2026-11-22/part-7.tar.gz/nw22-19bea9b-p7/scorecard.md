# Doctrine scorecard: nw22-19bea9b-p7

### Scorecard: nw22-19bea9b-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 1 | 4 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1131 | 3 | 1 | Opponent | no | 7 | 5 | 1 | 3 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1224 | 6 | 1 | Opponent | no | 5 | - | 1 | 4 | 2 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 3.3 | 2.7 | 0.0 | 0.0 | 0.0 | 0.0 | 220.0 |
| **Average** | | | Opponent | 0% | 4.0 | 3.5 | 1.3 | 3.0 | 1.3 | 0.0 | 0.0 | 56.7 |

### KPIs: nw22-19bea9b-p7

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 50% (8 of 16) | 0% (0 of 15) | 26% (8 of 31) |
| Winner chose to follow up after the loser gave ground |  | 67% (4 of 6); on the table 67% | - | 67% (4 of 6); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | - | 67% (2 of 3); on the table 100% | 67% (2 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 57% (4 of 7); on the table 71% | 67% (2 of 3); on the table 100% | 60% (6 of 10); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 39% (26 of 66) | 28% (5 of 18) | 37% (31 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (26 of 53) | 36% (5 of 14) | 46% (31 of 67) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 56% (5 of 9) | 56% (5 of 9) |
| Points that never fought | lower | 44% (2634 of 5998) | 54% (3257 of 5998) | 49% (5891 of 11996) |
|   infantry points that never fought | lower | 100% (730 of 730) | 42% (385 of 913) | 68% (1115 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 40% (10 of 25) | 79% (22 of 28) | 60% (32 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 7.3 uses a game | 0% (0 of 1); 0.0 uses a game | 75% (6 of 8); 3.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 17% (1 of 6); 0.3 uses a game | 17% (1 of 6); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 32% (1811 of 5614) | 78% (4542 of 5828) | 56% (6353 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (45%) | 1.0 (23%) | 7.0 (40%) |
| MARCHED: its unit marched | 2.3 (18%) | 2.0 (46%) | 4.3 (25%) |
| CHARGED: its unit charged | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: engaged in combat | 4.3 (32%) | 0.3 (8%) | 4.7 (26%) |
| GONE: slain | 0.0 (0%) | 1.0 (23%) | 1.0 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 4.3 | 2.7 | 10.3 | 2.0 | 2.7 |
| not cast | 1.3 | 7.7 | 1.3 | 17.7 | 6.0 | 33.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.7 (74%) | 0.0 (0%) | 7.0 (40%) | 1.7 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (25%) | 0.7 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.3 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (9%) | 0.3 (25%) | 4.7 (26%) | 1.0 (17%) | 0.0 (0%) |
| GONE: slain | 0.3 (25%) | 1.0 (13%) | 1.0 (75%) | 1.0 (6%) | 0.0 (0%) | 3.3 (10%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) | 2.3 (39%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 28.7 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.7 a game | 1.3 a game |
| stood (cast and not dispelled) | - | 50% (4 of 8) | 50% (4 of 8) |
| the unit moved after it | - | 50% (2 of 4) | 50% (2 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 50% (2 of 4) | 50% (2 of 4) |
| it fought by the end of its next turn | - | 25% (1 of 4) | 25% (1 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 50% (2 of 4) | 50% (2 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (43 of 54) | 35% (8 of 23) | 66% (51 of 77) |
|   cavalry | - | 36% (4 of 11) | 36% (4 of 11) |
|   character | - | 0% (0 of 7) | 0% (0 of 7) |
|   chariot | 70% (7 of 10) | - | 70% (7 of 10) |
|   infantry | 67% (8 of 12) | 80% (4 of 5) | 71% (12 of 17) |
|   war machine | 88% (28 of 32) | - | 88% (28 of 32) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (36%) | 2.0 (40%) | 3.3 (38%) |
| CHARGED: it charged | 0.7 (18%) | 1.0 (20%) | 1.7 (19%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (13%) | 0.7 (8%) |
| MOVED: a war machine that moved | 1.0 (27%) | 0.0 (0%) | 1.0 (12%) |
| NO TARGET IN RANGE | 0.3 (9%) | 0.7 (13%) | 1.0 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (7%) | 0.3 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (7%) | 0.3 (4%) |
| SHELTERED: the target was sheltered | 0.3 (9%) | 0.0 (0%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.3 | 1.0 | 57% | 18.5 pts | 43 pts |
| infantry | 8.0 | 1.3 | 88% | 5.0 pts | 40 pts |
| war machine | 10.3 | 11.0 | 55% | 36.3 pts | 375 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 2.3 | 3.0 |
| Charges that made contact a game | 2.3 | 1.7 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.86 contact (7 units) | 0.00 declared, 0.00 contact (2 units) | 0.78 declared, 0.67 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.10 contact (10 units) | 0.33 declared, 0.24 contact (21 units) | 0.35 declared, 0.19 contact (31 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 45% (5 of 11) | 100% (2 of 2) | 0% (0 of 2) | 47% (7 of 15) |
| Character in a unit | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Character on its own | 100% (5 of 5) | 40% (2 of 5) | 43% (3 of 7) | 59% (10 of 17) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 57% (4 of 7); on the table 71% | 39% (26 of 66) | 44% | 40% (10 of 25) | 86% (6 of 7); 7.3 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 1 | - | 33% (2 of 6) | 27% | 67% (6 of 9) | 0.0 uses a game | 17% (1 of 6); 1.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 0% (0 of 1); on the table 100% | 17% (1 of 6) | 62% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 74% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p7, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 80% (4) | 100% (6) | 91% (10) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.33 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.33 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: nw22-19bea9b-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 45% (5 of 11) | 60% (3 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (22 of 48) | - |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (3 of 3) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 60% (6 of 10) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.0 | 3.0 |
| Movement | Points that never moved of their own | 220.0 | 56.7 |
| Movement | Fights charged into per game | 2.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 1 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 6, net +116 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 6, net +117 | 1 of 3, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (6 of 15) | 45% (5 of 11) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 9.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (16 of 29) | - |
| Shooting | Points destroyed by war machines | 155.0 | 0.0 |
| Magic | Magic missiles cast | 5.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 19% (3 of 16) | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 7.3 | - |
| Magic | Wounds caused by other spells | 5.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 304.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 1.3 / 1.0 | 1.7 / 0.3 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 234.0 | 50.0 |
| Combat | Points run down | 100.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +166 | +39 |
| Combat | Net per 100 charger points, damage counted | +44.6 | +15.1 |
| Combat | First round won (charged fights) | 100% | 60% |
| Combat | Net points per charged fight | +156 | -27 |
| Combat | Net points per supported fight / lone fight | +235 / +140 | - / -27 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 3 of 5 |
| Game | Points lost | 160.0 | 1059.3 |
| Game | VP from objectives | 783.3 | 530.0 |
| Game | Lone holders (player turns) | 2.0 | 4.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1169 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1219
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +303.6 | 0.0 | 0.0 | 0.7 | +9.1 | 0.0 | 55.3 |
| ARMY TABLE | 9.3 | +166.4 | 0.0 | 100.0 | 23.0 | -421.8 | 0.0 | 927.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +2.1 | 0.0 | 0.0 | 0.3 | +4.4 | 0.0 | 166.7 |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +24.8 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +3.7 | 0.0 | 50.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| BOMBING RUN | 0.7 | +70.2 | 67.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 38.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.3 | +231.8 | 789.3 | 220.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 6.0 | +148.1 | 1037.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 156.7 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +5.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +0.1 | 0.0 | 0.0 | 1.3 | +85.7 | 0.0 | 234.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.3 | -2.8 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.0 | -815.2 | 0.0 | 150.0 | 25.7 | -984.6 | 0.0 | 1232.3 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 282.0 | 0.0 | 1.3 | +0.0 | 100.0 | 55.3 |
| CLEAR LANE AHEAD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 334.3 |
| CONVEYANCE SEARCH | - | - | - | - | 2.3 | +423.0 | 480.0 | 480.0 |
| COVER ONCE | 8.7 | -560.1 | 0.0 | 50.0 | 8.0 | -500.5 | 0.0 | 576.3 |
| DENIED BY THE FIGHT | 0.7 | -8.9 | 48.0 | 0.0 | 0.3 | -11.7 | 0.0 | 16.7 |
| DEPLOY BY FIGURES | 4.7 | -28.4 | 0.0 | 0.0 | 5.7 | +153.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -21.5 | 156.7 | 0.0 | 0.3 | -21.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +89.5 | 156.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.0 | +37.3 | 301.0 | 0.0 | 1.7 | -7.8 | 155.0 | 89.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +2.1 | 125.3 | 0.0 | 2.3 | +1.5 | 155.0 | 105.7 |
| FALLS SHORT | - | - | - | - | 24.3 | +305.3 | 0.0 | 1161.3 |
| FIGHT TO THE END | 0.7 | +10.5 | 38.7 | 0.0 | 0.7 | +5.0 | 0.0 | 55.3 |
| FIVE ACTION | 87.3 | +5819.8 | 3988.3 | 640.0 | 75.7 | +5337.8 | 155.0 | 2772.3 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 100.0 | 4.3 | +0.0 | 0.0 | 426.7 |
| FOLLOW UP WEIGHED | 1.3 | +247.3 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 3.7 | +211.4 | 496.3 | 0.0 | 2.3 | +238.1 | 155.0 | 105.7 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 137.0 |
| FRIEND SHOOTS FIRST | 2.0 | -33.0 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 1.3 | +37.7 | 0.0 | 0.0 | 14.7 | +2442.2 | 0.0 | 388.0 |
| GUN MASK | 0.7 | +34.5 | 0.0 | 100.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.3 | -0.2 | 313.3 | 0.0 | 1.0 | -4.0 | 0.0 | 105.7 |
| HARD STAY DROPPED | 5.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 53.7 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.3 | +0.0 | 50.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 150.0 | 14.3 | +0.0 | 0.0 | 782.7 |
| HIS CHARGE DENIED | 0.7 | +46.8 | 48.0 | 0.0 | 0.3 | +55.6 | 0.0 | 16.7 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 541.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 440.7 |
| HIS MOVE AND SHOT | 6.3 | -24.9 | 0.0 | 100.0 | 8.0 | -83.3 | 0.0 | 244.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 440.7 |
| HIS RANDOM MOVE | 7.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 15.3 | +188.0 | 0.0 | 50.0 | 63.7 | +3559.2 | 0.0 | 2226.3 |
| HIS SHOTS BY HIS RUN | 23.7 | +317.4 | 0.0 | 150.0 | 58.3 | +2153.2 | 0.0 | 2212.0 |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 0.0 | 18.0 | +0.0 | 0.0 | 313.3 |
| HOLDER ASSIGNMENT | 10.0 | +927.5 | 0.0 | 0.0 | 10.7 | +1062.3 | 0.0 | 156.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -87.1 | 448.3 | 0.0 | 1.7 | -104.8 | 105.0 | 55.3 |
| HUNT IN PAIRS | 1.3 | +16.8 | 0.0 | 0.0 | 0.7 | +27.7 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +81.0 | 0.0 | 38.7 |
| IDLE COST | - | - | - | - | 15.0 | -269.0 | 0.0 | 703.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.7 | -28.4 | 156.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +18.9 | 0.0 | 0.0 | 0.7 | +18.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 254.3 | 0.0 | 2.0 | +0.0 | 50.0 | 636.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +34.2 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | +0.0 | 352.0 | 0.0 | 1.0 | +6.8 | 0.0 | 105.7 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +4.9 | 0.0 | 0.0 | 1.0 | +43.4 | 0.0 | 214.7 |
| MANOEUVRE | 1.0 | -1.6 | 0.0 | 50.0 | 1.7 | +1.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 1.3 | +8.0 | 0.0 | 134.0 |
| MARCH BY THE SUM | 1.3 | +177.5 | 0.0 | 0.0 | 0.3 | +35.6 | 0.0 | 38.7 |
| MARCH CHECK | 2.7 | +145.9 | 0.0 | 0.0 | 1.0 | +40.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +9.0 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 2.3 | +56.8 | 0.0 | 0.0 | 2.0 | +159.0 | 0.0 | 172.7 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 5.0 | +74.4 | 0.0 | 0.0 | 4.0 | +280.0 | 0.0 | 280.0 |
| MEETS IN TIME | 3.0 | +347.8 | 0.0 | 0.0 | 2.3 | +358.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 13.3 | +311.9 | 0.0 | 0.0 | 1.3 | +10.6 | 0.0 | 323.3 |
| MISSILES NEXT TURN | 16.0 | +297.5 | 0.0 | 0.0 | 5.0 | +22.1 | 0.0 | 585.7 |
| MOVE ORDER | - | - | - | - | 1.3 | +0.0 | 0.0 | 38.7 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 156.7 |
| MOVE TO CHARGE COMPUTED | 6.0 | +563.7 | 0.0 | 100.0 | 3.0 | +238.7 | 0.0 | 0.0 |
| NEAR WALKS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +157.0 | 0.0 | 0.0 | 5.7 | +185.6 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.7 | +246.1 | 0.0 | 100.0 | 1.3 | +135.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -76.3 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 3.0 | +67.9 | 558.7 | 50.0 | 1.0 | +78.3 | 155.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -131.9 | 282.0 | 0.0 | 2.3 | -84.5 | 155.0 | 105.7 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 38.7 |
| NOT WORTH A CAST | 1.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.7 | -448.9 | 0.0 | 105.0 | 5.3 | -279.5 | 0.0 | 222.3 |
| OGRE LOADER SECOND SHOT | 5.3 | +51.3 | 166.7 | 55.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.3 | -137.5 | 0.0 | 50.0 | 5.0 | -91.4 | 0.0 | 415.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +0.3 | 50.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -42.9 | 0.0 | 0.0 | 3.7 | -6.4 | 0.0 | 156.7 |
| ONE PROMISE A TARGET | 0.7 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +16.0 | 16.7 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 1.7 | +37.9 | 331.3 | 0.0 | 0.7 | +54.3 | 105.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +14.4 | 50.0 | 67.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +3.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -71.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 38.3 | +1897.7 | 1177.7 | 320.0 | 39.0 | +227.2 | 105.0 | 2005.7 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +13.8 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 53.7 |
| PROMISE BY ITS OWN SUM | 14.0 | -527.3 | 0.0 | 0.0 | 5.7 | -97.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -0.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -18.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 14.0 | +2112.7 | 448.0 | 0.0 | 10.0 | +1325.3 | 0.0 | 388.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +40.6 | 0.0 | 113.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +318.9 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 20.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -227.1 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.7 | +101.6 | 339.7 | 0.0 | 2.3 | -149.9 | 155.0 | 105.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -31.4 | 55.0 | 16.7 |
| RUN DOWN | 1.7 | -9.7 | 125.3 | 0.0 | 1.7 | -40.5 | 50.0 | 105.7 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +2.8 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.0 | +12.1 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +0.7 | 0.0 | 50.3 |
| SET CREDITED ONCE | - | - | - | - | 2.7 | -148.9 | 0.0 | 206.7 |
| SET UP BY THE SET | 1.3 | +7.5 | 0.0 | 0.0 | 3.0 | +106.6 | 50.0 | 206.7 |
| SET UP TOGETHER | 0.3 | +4.9 | 0.0 | 0.0 | 1.0 | +43.4 | 0.0 | 214.7 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +52.2 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 16.0 | +0.0 | 0.0 | 270.0 | 1.3 | +0.0 | 0.0 | 105.7 |
| SHOOTS FROM THE BEST SPOT | 5.3 | +126.8 | 513.7 | 0.0 | 0.3 | +16.9 | 0.0 | 67.0 |
| SHOT OR CHARGE | 2.0 | -95.5 | 508.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 10.3 | -143.8 | 0.0 | 150.0 | 42.0 | +620.4 | 0.0 | 1738.3 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 15.7 | +779.4 | 0.0 | 270.0 | 3.7 | +81.6 | 0.0 | 225.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +52.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +2.7 | 0.0 | 0.0 | 1.7 | +40.5 | 313.3 | 313.3 |
| SPELLS IN THE FIGHT | 0.7 | -13.1 | 156.7 | 0.0 | 0.7 | +1.8 | 50.0 | 50.3 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 50.0 | 7.3 | +0.0 | 0.0 | 421.3 |
| STAND AND SHOOT | 0.3 | -0.5 | 41.0 | 0.0 | 0.3 | -3.1 | 50.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 0.0 | 490.0 |
| STANDS STILL | 49.7 | +0.0 | 3492.0 | 490.0 | 14.3 | +0.0 | 0.0 | 311.7 |
| STAY WORTH | 31.3 | -63.8 | 2061.7 | 330.0 | 2.3 | +21.0 | 0.0 | 59.0 |
| STOPS | - | - | - | - | 0.3 | +0.4 | 0.0 | 38.7 |
| STRIKE BY THE ODDS | 0.3 | +21.6 | 50.3 | 0.0 | 0.3 | +7.8 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +221.9 | 0.0 | 0.0 | 6.0 | +633.6 | 0.0 | 78.3 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 50.0 | 16.7 |
| SUPPORT WORKED OUT | 2.3 | +221.9 | 0.0 | 0.0 | 6.0 | +633.6 | 0.0 | 78.3 |
| SURE REACH TOGETHER | 0.3 | +5.3 | 0.0 | 0.0 | 1.3 | +30.0 | 0.0 | 20.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.3 | +1.2 | 195.3 | 0.0 | 1.3 | +73.5 | 0.0 | 105.7 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 38.7 | 67.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 179.7 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 101.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.7 | +0.0 | 0.0 | 320.0 | 37.0 | +0.0 | 0.0 | 1315.3 |
| TIED UP BY THE SUM | 1.0 | +141.6 | 77.3 | 0.0 | 1.0 | +88.8 | 105.0 | 16.7 |
| TIME ON OUR SIDE | 38.0 | +557.3 | 352.3 | 100.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 100.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +23.4 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 166.7 | 50.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | -7.0 | 33.3 | 0.0 | 0.7 | -0.5 | 0.0 | 100.7 |
| WHO HITS BACK | 0.3 | +32.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | -2.6 | 16.7 | 0.0 | 0.3 | +24.1 | 0.0 | 50.3 |
| WHOLE FIGHT DANGER | 3.0 | -647.2 | 0.0 | 50.0 | 0.3 | -28.0 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 2.0 | +145.4 | 55.3 | 155.0 | 2.0 | +55.4 | 0.0 | 166.3 |
| WOUNDS ON THE RANKS | 1.7 | +54.0 | 0.0 | 0.0 | 3.0 | +128.5 | 0.0 | 259.0 |

### Rule changes: nw22-19bea9b-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 97 | 97 | 72 | 24.00 | +321 | +4.5 |
| HOLDER ASSIGNMENT | 62 | 62 | 57 | 19.00 | +3066 | +53.8 |
| HIS SHOT LIST | 237 | 226 | 48 | 16.00 | +1121 | +23.4 |
| HIS SHOTS BY HIS RUN | 246 | 231 | 39 | 13.00 | +1398 | +35.9 |
| OFF BEST | 39 | 39 | 39 | 13.00 | -2185 | -56.0 |
| FIVE ACTION | 489 | 462 | 35 | 11.67 | +4495 | +128.4 |
| GOAL WALK | 48 | 48 | 25 | 8.33 | +3685 | +147.4 |
| PROMISE BY ITS OWN SUM | 59 | 59 | 23 | 7.67 | -1874 | -81.5 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| CHARGE LOSSES | 116 | 107 | 20 | 6.67 | +3208 | +160.4 |
| HARD STAY DROPPED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| QUARTER ODDS | 72 | 67 | 17 | 5.67 | +1862 | +109.5 |
| CAST JOB | 18 | 18 | 16 | 5.33 | +138 | +8.6 |
| OGRE LOADER SECOND SHOT | 16 | 16 | 16 | 5.33 | +154 | +9.6 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 16 | 5.33 | +169 | +10.6 |
| TIME ON OUR SIDE | 114 | 92 | 16 | 5.33 | +54 | +3.4 |
| SHOT RISK POINTS | 157 | 149 | 15 | 5.00 | +564 | +37.6 |
| MOVE TO CHARGE COMPUTED | 27 | 21 | 13 | 4.33 | +1278 | +98.3 |
| DEPLOY BY FIGURES | 31 | 31 | 12 | 4.00 | +186 | +15.5 |
| SUPPORT ADDS | 25 | 25 | 12 | 4.00 | +432 | +36.0 |
| SUPPORT WORKED OUT | 25 | 25 | 12 | 4.00 | +432 | +36.0 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MARCH CHECK | 11 | 11 | 7 | 2.33 | +160 | +22.9 |
| COVER ONCE | 50 | 29 | 6 | 2.00 | +61 | +10.2 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +112 | +18.6 |
| MAX FOR POSITIONING | 27 | 25 | 6 | 2.00 | +53 | +8.8 |
| MEETS IN TIME | 16 | 16 | 6 | 2.00 | +223 | +37.1 |
| NO CHAFF EDGES | 12 | 12 | 6 | 2.00 | +210 | +35.0 |
| STAY WORTH | 101 | 92 | 6 | 2.00 | +111 | +18.6 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +257 | +51.5 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +640 | +127.9 |
| NEXT CHARGE BY LIST | 12 | 12 | 5 | 1.67 | +746 | +149.2 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 5 | 1.67 | +122 | +24.3 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +300 | +60.0 |
| WHOLE FIGHT DANGER | 10 | 8 | 5 | 1.67 | +701 | +140.2 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 1.33 | +938 | +234.5 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +742 | +185.4 |
| FOUR ROUNDS | 18 | 17 | 4 | 1.33 | +205 | +51.2 |
| MISSILES IN THE MOVE | 44 | 32 | 4 | 1.33 | +167 | +41.8 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SCOUT BY DROPS | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 73 | 56 | 3 | 1.00 | +0 | +0.2 |
| IDLE COST | 45 | 26 | 3 | 1.00 | +28 | +9.4 |
| RISK BY ARC | 15 | 14 | 3 | 1.00 | +32 | +10.7 |
| SET UP BY THE SET | 13 | 13 | 3 | 1.00 | +89 | +29.6 |
| SURE REACH TOGETHER | 5 | 4 | 3 | 1.00 | +9 | +3.1 |
| THE ROW IN ITS ORDER | 12 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 12 | 12 | 3 | 1.00 | +15 | +4.9 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +19 | +9.7 |
| BOMBING RUN | 2 | 2 | 2 | 0.67 | +210 | +105.2 |
| CANNON PLANNED TARGET | 28 | 28 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 11 | 10 | 2 | 0.67 | +44 | +22.0 |
| HIS MOVE AND SHOT | 43 | 38 | 2 | 0.67 | +0 | +0.2 |
| INFANTRY NOT BEHIND INFANTRY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -85 | -42.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +6 | +3.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -30 | -14.8 |
| ONE FIGHT FORMULA | 34 | 19 | 2 | 0.67 | +144 | +71.9 |
| ONE OBJECTIVE FORMULA | 24 | 19 | 2 | 0.67 | +57 | +28.6 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | +24 | +12.1 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +10 | +4.8 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 2 | 0.67 | -1 | -0.3 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +403 | +201.7 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +88 | +44.1 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| BACKS UP THE FIGHT | 1 | 1 | 1 | 0.33 | +2 | +2.4 |
| BACKUP TARGETS | 2 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 9 | 9 | 1 | 0.33 | -54 | -53.7 |
| CLEAR LANE AHEAD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +2 | +2.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +1 | +1.1 |
| HONEST WORTH | 15 | 15 | 1 | 0.33 | +2 | +2.0 |
| HUNT IN PAIRS | 6 | 3 | 1 | 0.33 | +2 | +2.1 |
| LOST AFTER ESCAPE | 9 | 8 | 1 | 0.33 | +2 | +2.0 |
| MAIN BODY KEEPS ITS BAND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 63 | 44 | 1 | 0.33 | +5 | +5.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -214 | -213.7 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +42 | +41.5 |
| REDIRECT COUNTER | 5 | 5 | 1 | 0.33 | +42 | +42.5 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +36 | +36.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +2 | +2.2 |
| SHOTS AFTER THE MOVES | 16 | 16 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 58 | 43 | 1 | 0.33 | +11 | +11.4 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -20 | -19.5 |
| THE FIGHT MOVES | 8 | 7 | 1 | 0.33 | +47 | +46.7 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +69 | +69.2 |
| WOUNDS ON THE RANKS | 14 | 14 | 1 | 0.33 | +26 | +25.6 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 58 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 11 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 7 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 7 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 5 | 4 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 68 | 65 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 37 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 9 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 23 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 86 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 8 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEAR WALKS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 28 | 25 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 7 | 7 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 232 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 52 | not checked | - | - | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 34 | 29 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 192 | 181 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 230 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.67 | 4.33 | 53.8 |
| PROMISE BY ITS OWN SUM | rule | 6.00 | 1.67 | 81.5 |
| ARMY TABLE | rule | 0.67 | 3.67 | 116.5 |
| RULE SWITCHED OFF | gate | 1.00 | - | 85.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 27.7 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 14.8 |
| CHARGE NOW FIRST | rule | - | 0.33 | 53.7 |
| FALLBACK | gate | - | 0.33 | 6.0 |
| JOINT CHARGE NOW | rule | 0.33 | - | 90.1 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 64.2 |
| NO REASON | gate | - | 0.33 | 83.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 213.7 |
| SUPPORT NARROWED | rule | - | 0.33 | 19.5 |

### Plans: nw22-19bea9b-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 320 | 309 | 96% |
| Mine | move | 22.7 | 99% | 1388 | 0 | 0% |
| Mine | shoot | 13.3 | 75% | 802 | 1589 | 198% |
| Opponent | charge | 2.3 | 43% | 243 | 227 | 94% |
| Opponent | join | 2.3 | 71% | 133 | 0 | 0% |
| Opponent | move | 34.3 | 93% | 2563 | 0 | 0% |

### Packages: hunt the guns, nw22-19bea9b-p7

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 155 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 179 |
| Warriors of Chaos | 1.0 | 1 | 1 | - | - | - | - | - | - | - | 286 |

### Battle groups: nw22-19bea9b-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 79 (9) | 79 | 0 | 0 | 0% | 2.8 | 27 (3) | 95 (6) | - | 22 (5) | 118 (4) |
| Mine | Clean-up | 2 | 99 (2) | 0 | 99 | 0 | 0% | 1.5 | 0 (1) | 186 (1) | - | 99 (2) | - |
| Mine | Fast Hammer | 4 | 70 (4) | 26 | 44 | 15 | 0% | 1.8 | 25 (1) | 71 (2) | 173 (1) | 52 (3) | 173 (1) |
| Mine | Holder | 1 | 88 (1) | 0 | 88 | 0 | 0% | 2.0 | 88 (1) | - | - | 88 (1) | - |
| Mine | Shooter | 4 | 75 (4) | 30 | 45 | 0 | 0% | 2.2 | 109 (2) | 0 (1) | 31 (1) | 60 (2) | 91 (2) |
| Mine | War machine | 6 | 47 (6) | 47 | 0 | 33 | 0% | 1.0 | 173 (1) | 27 (4) | 0 (1) | 173 (1) | 22 (5) |
| Mine | Wizard | 3 | 33 (3) | 33 | 0 | 0 | 33% | 1.5 | 35 (2) | 31 (1) | - | 35 (2) | 31 (1) |
| Opponent | Chaff | 2 | 100 (2) | 0 | 100 | 50 | 100% | - | - | 200 (1) | 0 (1) | 100 (2) | - |
| Opponent | Character | 10 | 6 (10) | 6 | 0 | 58 | 40% | 3.0 | 0 (3) | 12 (5) | 0 (1) | 10 (6) | 0 (3) |
| Opponent | Fast Hammer | 9 | 19 (9) | 0 | 19 | 51 | 56% | 3.0 | 0 (1) | 25 (7) | 0 (1) | 29 (6) | 0 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 63 | 33% | 2.5 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | Holder | 5 | 50 (5) | 0 | 50 | 45 | 80% | 6.0 | 11 (2) | 103 (2) | 0 (1) | 9 (2) | 78 (3) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | - | - | - | - |

### Charged fights: nw22-19bea9b-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 460 | 312 | 2.0 | 1.2 | 156 | 0 | +156 | 1 of 6 | 6 of 6 | +235 | +140 |
| Opponent | High Elf Realms | 1 | 0 | 315 | 3.0 | 1.0 | 105 | 150 | -45 | 2 of 3 | 1 of 3 | - | -45 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 0 | 105 | 1.7 | 1.0 | 63 | 90 | -27 | 3 of 5 | 3 of 5 | - | -27 |

### Effective charges: nw22-19bea9b-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 6 | 0 | 0 | 0 | 2 (net +235) | 1 (net +116) | 3 (net +117) | 0 | 0% (0 of 6) |
| Opponent | High Elf Realms | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 356 | 260 | +235 | 235 | 0 | +235 | +65.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 384 | 167 | +117 | 154 | 0 | +154 | +40.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 369 | 116 | +116 | 116 | 53 | +63 | +17.2 |
| Mine | All fights | 6 | 372 | 190 | +156 | 175 | 9 | +166 | +44.6 |
| Opponent | Long shot (under 50%) | 1 | 489 | 358 | +0 | 143 | 48 | +96 | +19.5 |
| Opponent | 76-89% | 1 | 116 | 233 | +0 | 155 | 0 | +155 | +133.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 50 | 205 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 2 | 320 | 260 | -68 | 210 | 238 | -28 | -8.6 |
| Opponent | All fights | 5 | 259 | 263 | -27 | 144 | 105 | +39 | +15.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p7 | move | 21 | 3 (14%) | 2 (10%) | 2 (10%) | 16 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

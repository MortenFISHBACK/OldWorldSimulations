# Doctrine scorecard: nw22-19bea9b-p2

### Scorecard: nw22-19bea9b-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | 6 | 1 | 7 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | - | 0 | 7 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 250 |
| L0319 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.5 | 6.0 | 0.3 | 4.7 | 0.0 | 0.0 | 0.0 | 196.7 |
| **Average** | | | Opponent | 0% | 2.0 | 2.0 | 1.3 | 2.3 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: nw22-19bea9b-p2

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 10% (1 of 10) | 0% (0 of 13) | 4% (1 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 60% | 100% (4 of 4); on the table 100% | 78% (7 of 9); on the table 78% |
| Magic missiles tried each own turn | 50%+ | 36% (15 of 42) | 17% (4 of 24) | 29% (19 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (15 of 42) | 17% (4 of 24) | 29% (19 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (5 of 10) | - | 50% (5 of 10) |
| Points that never fought | lower | 48% (2763 of 5797) | 73% (4374 of 6000) | 60% (7137 of 11797) |
|   infantry points that never fought | lower | 46% (626 of 1374) | 56% (475 of 842) | 50% (1101 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 75% (15 of 20) | 52% (14 of 27) | 62% (29 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.3 uses a game | 50% (1 of 2); 1.3 uses a game | 83% (5 of 6); 2.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 100% (1 of 1); 0.3 uses a game | 83% (5 of 6); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 70% (2842 of 4039) | 48% (2626 of 5515) | 57% (5468 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.3 (70%) | 0.0 (0%) | 6.3 (40%) |
| MARCHED: its unit marched | 2.7 (30%) | 0.7 (10%) | 3.3 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.7 (70%) | 4.7 (30%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (20%) | 1.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.7 | 3.7 | 6.3 | 0.3 |
| not cast | 2.3 | 6.3 | 15.7 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (14%) | 0.3 (5%) | 6.3 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.3 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (86%) | 4.0 (63%) | 4.7 (30%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 2.0 (32%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 27.3 (99%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.0 a game | 0.7 a game | 1.8 a game |
| stood (cast and not dispelled) | 78% (7 of 9) | 100% (2 of 2) | 82% (9 of 11) |
| the unit moved after it | 29% (2 of 7) | 0% (0 of 2) | 22% (2 of 9) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 2) | 0% (0 of 9) |
| the enemy charged it first | 0% (0 of 7) | 0% (0 of 2) | 0% (0 of 9) |
| it fought by the end of its next turn | 0% (0 of 7) | 0% (0 of 2) | 0% (0 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 7) | 0% (0 of 2) | 0% (0 of 9) |
| none of these (no charge, no fight, no charge escaped) | 100% (7 of 7) | 100% (2 of 2) | 100% (9 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (24 of 35) | 65% (54 of 83) | 66% (78 of 118) |
|   cavalry | - | 47% (8 of 17) | 47% (8 of 17) |
|   character | - | 67% (8 of 12) | 67% (8 of 12) |
|   chariot | 45% (5 of 11) | 100% (12 of 12) | 74% (17 of 23) |
|   infantry | - | 47% (14 of 30) | 47% (14 of 30) |
|   monster | - | 100% (12 of 12) | 100% (12 of 12) |
|   war machine | 79% (19 of 24) | - | 79% (19 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (27%) | 5.0 (52%) | 6.0 (45%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (7%) | 0.7 (5%) |
| IN COMBAT: it fought this turn or the last | 0.7 (18%) | 0.3 (3%) | 1.0 (8%) |
| MOVED: a war machine that moved | 0.7 (18%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET IN RANGE | 0.3 (9%) | 2.3 (24%) | 2.7 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (9%) | 1.0 (10%) | 1.3 (10%) |
| OTHER BAR | 0.7 (18%) | 0.0 (0%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 2.7 | 58% | 6.7 pts | 27 pts |
| character | 2.7 | 0.7 | 75% | 1.5 pts | 4 pts |
| chariot | 5.7 | 6.7 | 35% | 26.3 pts | 149 pts |
| infantry | 4.7 | 2.7 | 57% | 6.1 pts | 28 pts |
| monster | 4.0 | 1.7 | 75% | 5.8 pts | 23 pts |
| war machine | 6.7 | 3.3 | 75% | 7.4 pts | 49 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 3.0 | 1.7 |
| Charges that made contact a game | 0.3 | 1.7 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.04 declared, 0.04 contact (24 units) | 0.31 declared, 0.17 contact (29 units) | 0.19 declared, 0.11 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (1 of 1) | - | 50% (2 of 4) |
| Character in a unit | 100% (7 of 7) | 67% (4 of 6) | - | 85% (11 of 13) |
| Character on its own | 100% (1 of 1) | 50% (1 of 2) | 0% (0 of 2) | 40% (2 of 5) |
| Chariot | 0% (0 of 2) | 100% (2 of 2) | - | 50% (2 of 4) |
| Infantry | 40% (2 of 5) | 33% (1 of 3) | - | 38% (3 of 8) |
| Monster | 0% (0 of 2) | 100% (1 of 1) | - | 33% (1 of 3) |
| Monstrous | 100% (2 of 2) | 50% (2 of 4) | - | 67% (4 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 60% (3 of 5); on the table 60% | 50% (15 of 30) | 48% | 67% (8 of 12) | 100% (4 of 4); 6.5 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | - | 0% (0 of 12) | 47% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 79% | 43% (3 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 82% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 67% (4 of 6) | 57% | 50% (6 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p2, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 0% (0) | 40% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: nw22-19bea9b-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 0% (0 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 64% (14 of 22) | 67% (10 of 15) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 50% (5 of 10) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 100% (3 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 4.7 | 2.3 |
| Movement | Points that never moved of their own | 196.7 | 0.0 |
| Movement | Fights charged into per game | 0.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +0 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.7 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 100% (5 of 5) | 17% (9 of 54) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (12 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 74.0 |
| Magic | Magic missiles cast | 1.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (1 of 5) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 5.7 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 17.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 0.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 60.7 | 364.7 |
| Combat | Points run down | 0.0 | 58.7 |
| Combat | Net points per charged fight, damage counted | +27 | +182 |
| Combat | Net per 100 charger points, damage counted | +33.2 | +80.4 |
| Combat | First round won (charged fights) | 100% | 60% |
| Combat | Net points per charged fight | +0 | +268 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +268 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 2 of 5 |
| Game | Points lost | 598.7 | 120.7 |
| Game | VP from objectives | 343.3 | 1160.0 |
| Game | Lone holders (player turns) | 1.5 | 2.0 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -1362 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 719
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: nw22-19bea9b-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 17.0 | -89.2 | 0.0 | 309.0 | 37.0 | +439.3 | 0.0 | 76.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 1.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.0 | +18.0 | 73.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.3 | +8.9 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.3 | +141.2 | 0.0 | 0.0 | 0.7 | +15.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +14.1 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.7 | +75.6 | 0.0 | 85.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +3.3 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.3 | -0.7 | 27.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -886.1 | 0.0 | 374.0 | 15.7 | -527.4 | 0.0 | 76.0 |
| CHARGE NOW FIRST | - | - | - | - | 1.0 | +0.0 | 55.3 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| CLEAR LANE AHEAD | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 14.0 | +0.0 | 0.0 | 174.0 | 8.3 | +0.0 | 0.0 | 36.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| CONVEYANCE SEARCH | 2.7 | +980.0 | 0.0 | 0.0 | 0.7 | +230.0 | 0.0 | 0.0 |
| COVER ONCE | 6.0 | -342.6 | 0.0 | 130.3 | 5.7 | -94.6 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.3 | +16.8 | 0.0 | 0.0 | 7.3 | +57.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +20.7 | 27.0 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | - | - | - | - | 1.3 | -2.5 | 56.7 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.3 | 56.7 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| FALLS SHORT | 13.3 | +329.1 | 0.0 | 128.0 | 5.0 | +102.6 | 0.0 | 0.0 |
| FEATURE BUFFS | 10.0 | +492.3 | 0.0 | 108.0 | 0.7 | +92.9 | 0.0 | 0.0 |
| FIVE ACTION | 89.3 | +6224.5 | 110.0 | 1052.0 | 99.0 | +7822.1 | 351.3 | 192.0 |
| FLANK NOT WEIGHED | 12.0 | +0.0 | 0.0 | 293.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +63.5 | 0.0 | 85.0 | 0.3 | +130.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.3 | +7.4 | 0.0 | 0.0 | 1.7 | +20.5 | 83.7 | 0.0 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 206.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -10.1 | 0.0 | 206.7 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| GOAL WALK | 10.3 | +1394.7 | 0.0 | 117.3 | 16.7 | +2192.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +0.7 | 0.0 | 206.7 | 1.7 | +65.6 | 45.7 | 0.0 |
| HALF WHEN STILL FLEEING | 0.3 | -1.8 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.7 | +0.0 | 56.7 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 374.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 76.0 |
| HIS LEGAL MOVES | - | - | - | - | 5.7 | +0.0 | 0.0 | 76.0 |
| HIS MOVE AND SHOT | 7.7 | -53.7 | 0.0 | 56.7 | 5.7 | -229.6 | 0.0 | 110.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 206.7 | 2.7 | +0.0 | 0.0 | 76.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 56.7 | 6.0 | +0.0 | 0.0 | 76.0 |
| HIS RANDOM MOVE | - | - | - | - | 23.7 | +0.0 | 0.0 | 121.3 |
| HIS RANDOM MOVER COMES | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 57.0 | +1922.7 | 0.0 | 582.0 | 56.0 | +1943.1 | 0.0 | 104.7 |
| HIS SHOTS BY HIS RUN | 50.7 | +935.6 | 0.0 | 930.7 | 45.3 | +1530.3 | 0.0 | 169.3 |
| HOLD ODDS | 29.3 | +0.0 | 0.0 | 337.3 | 21.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.0 | +1318.7 | 0.0 | 114.7 | 14.3 | +1282.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.3 | -33.0 | 55.3 | 0.0 |
| IDLE COST | 14.0 | -97.9 | 0.0 | 119.7 | 3.3 | -49.0 | 0.0 | 18.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -0.1 | 28.3 | 0.0 |
| KEEP FALLS | 0.3 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +11.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 38.0 | 131.7 | 3.3 | +0.0 | 188.3 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +58.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +1.8 | 0.0 | 0.0 | 0.7 | -0.1 | 28.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +2.6 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 0.0 | 5.0 | -36.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +162.7 | 0.0 | 0.0 | 1.0 | +55.8 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +22.3 | 0.0 | 0.0 | 0.7 | +37.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +9.6 | 0.0 | 0.0 | 1.0 | +14.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.0 | +167.9 | 0.0 | 188.3 | 1.3 | +8.9 | 0.0 | 11.3 |
| MEETS IN TIME | 2.7 | +208.0 | 0.0 | 0.0 | 2.7 | +252.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.7 | +377.1 | 0.0 | 27.0 | 4.7 | +64.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.0 | +205.8 | 0.0 | 54.0 | 5.0 | +54.2 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.7 | -140.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.0 | +521.1 | 0.0 | 263.3 | 3.3 | +136.8 | 0.0 | 34.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +245.5 | 0.0 | 30.3 | 11.7 | +489.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +48.7 | 0.0 | 0.0 | 3.3 | +188.4 | 34.7 | 34.0 |
| NO CHAFF EDGES | 1.7 | +52.6 | 0.0 | 0.0 | 0.7 | +8.0 | 27.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -3.5 | 0.0 | 0.0 | 1.7 | -35.3 | 83.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +8.2 | 0.0 | 28.3 | - | - | - | - |
| OFF BEST | 3.0 | -516.9 | 0.0 | 103.3 | 4.3 | -149.4 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 2.0 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -35.9 | 0.0 | 188.3 | 7.7 | -136.5 | 0.0 | 49.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +2.4 | 56.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.0 | +81.0 | 0.0 | 114.7 | 5.7 | -180.5 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -29.0 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | - | - | - | - | 0.3 | +3.1 | 27.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +41.1 | 55.3 | 0.0 |
| PLAN RESULT | 41.3 | +131.6 | 18.3 | 861.3 | 43.7 | +132.2 | 119.7 | 170.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.3 | -1306.6 | 0.0 | 235.0 | 4.3 | -16.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -8.2 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 2.0 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.0 | +632.2 | 0.0 | 206.7 | 18.3 | +2576.9 | 0.0 | 76.0 |
| RANDOM MOVE BY FIGURES | 3.3 | +81.6 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.0 | +11.8 | 0.0 | 56.7 | - | - | - | - |
| REDIRECT COUNTER | 3.7 | +311.2 | 0.0 | 56.7 | 3.0 | +139.1 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 6.3 | +27.8 | 0.0 | 141.7 | 2.0 | +0.0 | 0.0 | 22.7 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -14.4 | 0.0 | 28.3 | 2.7 | -22.7 | 0.0 | 34.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +12.9 | 0.0 | 0.0 |
| RISK BY ARC | - | - | - | - | 1.3 | -32.4 | 83.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -12.1 | 27.0 | 0.0 |
| RUN DOWN | 0.3 | -7.8 | 0.0 | 0.0 | 1.7 | -18.5 | 83.7 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.0 | +6.5 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -22.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +6.5 | 0.0 | 0.0 | 1.0 | +8.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +4.4 | 28.3 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -288.9 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 3.3 | +368.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +2.6 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +831.1 | 0.0 | 0.0 | 2.3 | +53.3 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 49.7 | +337.4 | 0.0 | 670.0 | 38.0 | -347.7 | 0.0 | 192.0 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 8.7 | +170.1 | 0.0 | 103.3 | 19.3 | +404.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +8.1 | 0.0 | 0.0 | 0.3 | +246.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.7 | +0.0 | 0.0 | 303.7 | 8.3 | +0.0 | 0.0 | 29.7 |
| STANDS FOR A REASON | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 29.3 | +0.0 | 110.0 | 128.0 | 38.3 | +0.0 | 267.7 | 45.3 |
| STAY WORTH | 17.3 | -70.8 | 110.0 | 0.0 | 23.3 | +151.5 | 176.3 | 38.0 |
| STRONG ENOUGH TO HOLD | 0.7 | -23.9 | 0.0 | 0.0 | 0.7 | -31.6 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.3 | +986.8 | 0.0 | 441.7 | 3.7 | +30.1 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 8.3 | +986.8 | 0.0 | 441.7 | 3.7 | +30.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +11.8 | 0.0 | 0.0 | 1.7 | +23.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | - | - | - | - | 1.0 | +2.6 | 55.3 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 30.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 58.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 6.3 | +0.0 | 0.0 | 189.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.7 | +0.0 | 0.0 | 158.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.0 | +0.0 | 0.0 | 469.3 | 46.3 | +0.0 | 0.0 | 90.3 |
| TIME ON OUR SIDE | 8.7 | +151.5 | 0.0 | 164.0 | 49.7 | +505.5 | 0.0 | 79.3 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 28.3 | 0.7 | +0.0 | 0.0 | 11.3 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.7 | -147.4 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 5.0 | +0.0 | 198.3 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | +4.0 | 56.7 | 0.0 |
| WHO HITS BACK | 0.3 | +16.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -636.5 | 0.0 | 54.0 | 1.7 | -48.3 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +0.1 | 28.3 | 0.0 |
| WHOLE FIGHT REACTION | 2.0 | +91.4 | 11.3 | 83.7 | 0.3 | +2.5 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 6.0 | +202.3 | 0.0 | 0.0 | 2.7 | +258.7 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 162 | 162 | 99 | 33.00 | +439 | +4.4 |
| HIS SHOTS BY HIS RUN | 288 | 274 | 88 | 29.33 | +1147 | +13.0 |
| HIS SHOT LIST | 339 | 335 | 86 | 28.67 | +903 | +10.5 |
| HOLDER ASSIGNMENT | 79 | 79 | 75 | 25.00 | +4004 | +53.4 |
| SHOT RISK POINTS | 263 | 253 | 60 | 20.00 | +1247 | +20.8 |
| GOAL WALK | 81 | 81 | 39 | 13.00 | +3356 | +86.1 |
| DEPLOY BY FIGURES | 50 | 50 | 32 | 10.67 | +425 | +13.3 |
| REDIRECT FOR A FRIEND IN REACH | 25 | 25 | 25 | 8.33 | +11 | +0.4 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| FIVE ACTION | 565 | 551 | 22 | 7.33 | +1555 | +70.7 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -1999 | -90.9 |
| TIME ON OUR SIDE | 175 | 145 | 20 | 6.67 | +62 | +3.1 |
| QUARTER ODDS | 100 | 99 | 19 | 6.33 | +1784 | +93.9 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 44 | 44 | 16 | 5.33 | -3970 | -248.2 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 28 | 25 | 14 | 4.67 | +1021 | +72.9 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MEETS IN TIME | 16 | 16 | 10 | 3.33 | +684 | +68.4 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FEATURE BUFFS | 32 | 30 | 8 | 2.67 | +205 | +25.6 |
| MAX FOR POSITIONING | 22 | 19 | 7 | 2.33 | +13 | +1.8 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 7 | 2.33 | +1454 | +207.7 |
| STAY WORTH | 122 | 105 | 7 | 2.33 | +47 | +6.7 |
| SUPPORT ADDS | 36 | 27 | 7 | 2.33 | +219 | +31.2 |
| SUPPORT WORKED OUT | 36 | 27 | 7 | 2.33 | +219 | +31.2 |
| NO CHAFF EDGES | 7 | 7 | 6 | 2.00 | +172 | +28.7 |
| OGRE LOADER SECOND SHOT | 6 | 6 | 6 | 2.00 | +17 | +2.8 |
| PROMISE SHOT AWAY | 6 | 6 | 6 | 2.00 | -8 | -1.3 |
| SET UP BY THE SET | 10 | 10 | 6 | 2.00 | +475 | +79.2 |
| CASTING BLOCK | 6 | 6 | 5 | 1.67 | +76 | +15.3 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 5 | 1.67 | +245 | +48.9 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +582 | +145.5 |
| HIS MOVE AND SHOT | 40 | 40 | 4 | 1.33 | +73 | +18.3 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +656 | +163.9 |
| MARCH CHECK | 5 | 5 | 4 | 1.33 | +99 | +24.7 |
| NEXT CHARGE BY LIST | 13 | 13 | 4 | 1.33 | +175 | +43.7 |
| SCOUT BY DROPS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 84 | 62 | 4 | 1.33 | +126 | +31.5 |
| WOUNDS ON THE RANKS | 26 | 26 | 4 | 1.33 | +276 | +68.9 |
| CHAFF IN THE MOVE | 5 | 4 | 3 | 1.00 | +11 | +3.6 |
| CHARGE LOSSES | 100 | 98 | 3 | 1.00 | +60 | +20.1 |
| FALLS SHORT | 55 | 33 | 3 | 1.00 | +96 | +32.2 |
| FOUR ROUNDS | 6 | 6 | 3 | 1.00 | +41 | +13.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +505 | +168.2 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 3 | 1.00 | +11 | +3.6 |
| REDIRECT COUNTER | 20 | 19 | 3 | 1.00 | +94 | +31.2 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +234 | +77.9 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SURE REACH TOGETHER | 8 | 8 | 3 | 1.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 15 | 15 | 2 | 0.67 | +0 | +0.2 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 35 | 19 | 2 | 0.67 | +18 | +9.2 |
| IDLE COST | 52 | 36 | 2 | 0.67 | +37 | +18.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +175 | +87.5 |
| MISSILES IN THE MOVE | 34 | 25 | 2 | 0.67 | +201 | +100.5 |
| NEARER NOT NEEDED | 49 | 44 | 2 | 0.67 | +59 | +29.3 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +85 | +42.3 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +39 | +19.4 |
| SEARCH SPOT | 5 | 5 | 2 | 0.67 | +45 | +22.7 |
| THE ROW IN ITS ORDER | 23 | 2 | 2 | 0.67 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.67 | -442 | -221.1 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +10 | +10.1 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +16 | +16.4 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +8 | +8.1 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +2 | +1.9 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +11 | +11.2 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +34 | +33.7 |
| MANOEUVRE | 21 | 21 | 1 | 0.33 | +10 | +9.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -3 | -3.3 |
| ONE FIGHT FORMULA | 35 | 19 | 1 | 0.33 | +1 | +1.3 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -87 | -87.0 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -2 | -2.1 |
| RISK BY ARC | 4 | 4 | 1 | 0.33 | +7 | +7.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +13 | +13.1 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 15 | 15 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| WAR ENGINE JOBS | 15 | 15 | 1 | 0.33 | -83 | -82.8 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +7 | +7.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +42 | +42.3 |
| WHOLE FIGHT REACTION | 7 | 7 | 1 | 0.33 | +7 | +6.9 |
| BACKS UP THE FIGHT | 3 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CAST JOB | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 67 | 66 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 5 | 5 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 36 | 34 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 24 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 71 | 69 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 16 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 153 | 149 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 36 | 24 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 6 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 41 | 25 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 255 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 16 | 16 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 39 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 47 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 203 | 195 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE FIGHT MOVES | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 28 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 22 | not checked | - | - | - | - |
| THE TABLE BINDS | 259 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 9 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 13 | 13 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 3.33 | 92.5 |
| ARMY TABLE | rule | 3.00 | 3.00 | 66.8 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | 0.67 | 248.1 |
| HOLDER ASSIGNMENT | rule | 1.67 | 1.67 | 43.6 |
| PROMISE SHOT AWAY | rule | 2.00 | - | 1.3 |
| NO REASON | gate | - | 0.67 | 93.8 |
| WALKS ON ITS ROUTE | rule | - | 0.67 | 221.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 54.7 |
| MARCH OF THE TABLE | rule | 0.33 | - | 3.3 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 87.0 |
| REFUSING RETIRES | rule | 0.33 | - | 2.1 |
| WAR ENGINE JOBS | rule | - | 0.33 | 82.8 |

### Plans: nw22-19bea9b-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 34.7 | 92% | 2492 | 0 | 0% |
| Mine | shoot | 6.0 | 61% | 342 | 132 | 38% |
| Mine | support | 0.7 | 50% | 8 | 0 | 0% |
| Opponent | charge | 1.3 | 100% | 116 | 85 | 73% |
| Opponent | move | 38.7 | 97% | 2992 | 0 | 0% |
| Opponent | shoot | 3.7 | 36% | 223 | 47 | 21% |

### Battle groups: nw22-19bea9b-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 27% | 33% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 3.0 | 11% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 0 (11) | 0 | 0 | 33 | 36% | 3.0 | 0 (1) | 1 (5) | 0 (3) | 1 (9) | - |
| Mine | Clean-up | 3 | 164 (3) | 0 | 164 | 38 | 100% | - | 204 (2) | - | 99 (1) | 164 (3) | - |
| Mine | Fast Hammer | 9 | 0 (9) | 0 | 0 | 74 | 89% | 3.0 | 0 (6) | 0 (1) | 0 (2) | 0 (7) | 0 (2) |
| Mine | Hammer | 9 | 28 (9) | 9 | 20 | 44 | 11% | 3.1 | 7 (2) | 46 (5) | 0 (2) | 28 (9) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 3.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Chaff | 8 | 223 (8) | 0 | 223 | 31 | 38% | 3.0 | 94 (3) | 473 (4) | 0 (1) | 248 (7) | 0 (1) |
| Opponent | Character | 7 | 83 (7) | 83 | 0 | 0 | 29% | 2.0 | 149 (2) | 34 (3) | 63 (2) | 49 (5) | 150 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 1.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 30 (10) | 19 | 10 | 6 | 40% | 1.7 | 25 (5) | 30 (3) | 40 (2) | 39 (7) | 15 (3) |
| Opponent | Shooter | 4 | 103 (4) | 0 | 103 | 22 | 0% | 1.8 | 70 (2) | 273 (1) | 26 (1) | 103 (4) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |

### Charged fights: nw22-19bea9b-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 0 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Ogre Kingdoms | 1 | 274 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 1 of 1 | 0 of 1 | - | -34 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 839 | 1.0 | 1.0 | 839 | 0 | +839 | 1 of 1 | 1 of 1 | - | +839 |
| Opponent | Wood Elf Realms | 1 | 0 | 537 | 3.0 | 1.0 | 179 | 0 | +179 | 0 of 3 | 2 of 3 | - | +179 |
| **Opponent** | all armies | 3 | 91 | 459 | 1.7 | 1.0 | 275 | 7 | +268 | 2 of 5 | 3 of 5 | - | +268 |

### Effective charges: nw22-19bea9b-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 1 (net +452) | 0 | 0 | 2 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 81 | 77 | +0 | 38 | 12 | +27 | +33.2 |
| Mine | All fights | 1 | 81 | 77 | +0 | 38 | 12 | +27 | +33.2 |
| Opponent | 76-89% | 1 | 499 | 81 | +452 | 452 | 55 | +397 | +79.5 |
| Opponent | No odds | 4 | 158 | 209 | +222 | 248 | 119 | +128 | +81.1 |
| Opponent | All fights | 5 | 227 | 184 | +268 | 289 | 106 | +182 | +80.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p2 | move | 22 | 5 (23%) | 1 (5%) | 0 (0%) | 17 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

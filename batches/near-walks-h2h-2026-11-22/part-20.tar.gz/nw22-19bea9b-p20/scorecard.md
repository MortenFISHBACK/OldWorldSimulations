# Doctrine scorecard: nw22-19bea9b-p20

### Scorecard: nw22-19bea9b-p20

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 2 | 6 | 1 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | yes | 1 | 1 | 5 | 3 | 2 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 507 |
| **Average** | | | Mine | 0% | 4.5 | 3.3 | 3.7 | 1.7 | 0.0 | 0.0 | 0.0 | 46.7 |
| **Average** | | | Opponent | 50% | 0.5 | 2.3 | 3.0 | 2.0 | 0.7 | 0.0 | 0.0 | 169.0 |

### KPIs: nw22-19bea9b-p20

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 17) | 0% (0 of 34) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 25% | 25% (1 of 4); on the table 25% | 25% (2 of 8); on the table 25% |
| Winner chose to follow up or pursue (all three) |  | 25% (1 of 4); on the table 25% | 62% (5 of 8); on the table 62% | 50% (6 of 12); on the table 50% |
| Magic missiles tried each own turn | 50%+ | 28% (5 of 18) | - | 28% (5 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 31% (5 of 16) | - | 31% (5 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 44% (2650 of 6000) | 52% (3091 of 6000) | 48% (5741 of 12000) |
|   infantry points that never fought | lower | 25% (230 of 923) | 65% (752 of 1159) | 47% (982 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 46% (12 of 26) | 75% (18 of 24) | 60% (30 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 50% (1 of 2); 0.3 uses a game | 67% (2 of 3); 0.8 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 2.7 uses a game | 0.0 uses a game | 36% (5 of 14); 1.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 34% (2001 of 5860) | 63% (3218 of 5131) | 47% (5219 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (38%) | - | 1.7 (38%) |
| MARCHED: its unit marched | 1.3 (31%) | - | 1.3 (31%) |
| CHARGED: its unit charged | 0.7 (15%) | - | 0.7 (15%) |
| IN COMBAT: engaged in combat | 0.7 (15%) | - | 0.7 (15%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.7 | 4.0 | 1.7 | 1.3 |
| not cast | 3.7 | 7.3 | 4.0 | 4.3 | 26.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (23%) | 0.7 (17%) | 1.7 (38%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (31%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (15%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (17%) | 0.7 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.7 (18%) | 0.7 (9%) | 0.7 (17%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (36%) | 1.3 (18%) | 1.3 (33%) | 0.0 (0%) | 3.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 1.7 (45%) | 3.7 (50%) | 0.0 (0%) | 0.0 (0%) | 4.0 (15%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.0 (0%) | 0.7 (17%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.7 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 4.0 a game | 0.0 a game | 2.0 a game |
| stood (cast and not dispelled) | 92% (11 of 12) | - | 92% (11 of 12) |
| the unit moved after it | 45% (5 of 11) | - | 45% (5 of 11) |
| it charged on its next turn | 9% (1 of 11) | - | 9% (1 of 11) |
| the enemy charged it first | 9% (1 of 11) | - | 9% (1 of 11) |
| it fought by the end of its next turn | 9% (1 of 11) | - | 9% (1 of 11) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 11) | - | 0% (0 of 11) |
| none of these (no charge, no fight, no charge escaped) | 82% (9 of 11) | - | 82% (9 of 11) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 55% (42 of 76) | 54% (55 of 102) | 54% (97 of 178) |
|   cavalry | 56% (10 of 18) | 88% (14 of 16) | 71% (24 of 34) |
|   character | 21% (6 of 29) | 16% (3 of 19) | 19% (9 of 48) |
|   chariot | - | 71% (5 of 7) | 71% (5 of 7) |
|   infantry | 82% (14 of 17) | 49% (25 of 51) | 57% (39 of 68) |
|   monster | - | 89% (8 of 9) | 89% (8 of 9) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (32%) | 2.7 (17%) | 6.3 (23%) |
| CHARGED: it charged | 3.0 (26%) | 3.0 (19%) | 6.0 (22%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (9%) | 0.7 (4%) | 1.7 (6%) |
| NO TARGET IN RANGE | 2.7 (24%) | 6.3 (40%) | 9.0 (33%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.3 (2%) | 0.7 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (3%) | 1.7 (11%) | 2.0 (7%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 0.7 (4%) | 0.7 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.7 | 0.7 | 94% | 0.8 pts | 10 pts |
| character | 4.0 | 2.7 | 50% | 15.6 pts | 63 pts |
| chariot | 1.7 | 0.7 | 80% | 9.8 pts | 16 pts |
| infantry | 19.7 | 5.0 | 78% | 9.0 pts | 177 pts |
| monster | 3.0 | 1.0 | 67% | 10.5 pts | 31 pts |
| war machine | 4.0 | 2.0 | 75% | 16.2 pts | 65 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 6.0 | 5.0 |
| Charges that made contact a game | 2.0 | 3.7 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 0.67 contact (3 units) | - | 1.33 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.35 declared, 0.17 contact (23 units) | 0.55 declared, 0.33 contact (33 units) | 0.46 declared, 0.27 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (10 of 17) | - | - | 59% (10 of 17) |
| Character on its own | - | 80% (4 of 5) | 0% (0 of 8) | 31% (4 of 13) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 90% (9 of 10) | 0% (0 of 1) | - | 82% (9 of 11) |
| Monster | 50% (1 of 2) | 0% (0 of 1) | - | 33% (1 of 3) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 25% (1 of 4); on the table 25% | 28% (5 of 18) | 44% | 46% (12 of 26) | 100% (1 of 1); 1.3 uses a game | 36% (5 of 14); 2.7 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (4 of 4); on the table 100% | - | 60% | 86% (6 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 33% (1 of 3); on the table 33% | - | 43% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | - | 51% | 83% (10 of 12) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p20, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 50% (2) | 60% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p20

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 55% (6 of 11) | 33% (4 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 68% (13 of 19) | 32% (8 of 25) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | - |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 1) |
| Strategy | Lone characters that fought | 57% (4 of 7) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.7 | 2.0 |
| Movement | Points that never moved of their own | 46.7 | 169.0 |
| Movement | Fights charged into per game | 2.0 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +0 | 2 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 6, net +62 | 2 of 6, net +236 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 6, net +0 | 2 of 6, net +170 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.0 | 19.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (20 of 39) | 61% (35 of 57) |
| Shooting | Points destroyed by shooting units | 22.0 | 0.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (8 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | - |
| Magic | Wounds caused by magic missiles | 5.0 | 1.3 |
| Magic | Wounds caused by other spells | 4.3 | - |
| Magic | Points destroyed by magic (all spells) | 247.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 1.0 / 0.7 / 0.0 | 2.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 34.0 | 188.3 |
| Combat | Points run down | 365.3 | 109.3 |
| Combat | Net points per charged fight, damage counted | +38 | +116 |
| Combat | Net per 100 charger points, damage counted | +10.0 | +40.0 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +42 | +134 |
| Combat | Net points per supported fight / lone fight | - / +42 | +328 / +113 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 4 of 10 |
| Game | Points lost | 587.3 | 1094.3 |
| Game | VP from objectives | 946.7 | 490.0 |
| Game | Lone holders (player turns) | 4.5 | 0.5 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +994 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1682
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: nw22-19bea9b-p20

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 26.7 | -272.0 | 0.0 | 665.0 | 25.0 | +182.4 | 0.0 | 1241.3 |
| BACKUP TARGETS | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.7 | +0.1 | 0.0 | 95.3 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +195.5 | 260.0 | 46.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +12.8 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +12.5 | 0.0 | 22.7 |
| CHALLENGE BY POINTS | 1.3 | +59.2 | 0.0 | 208.3 | 0.3 | +4.5 | 0.0 | 41.7 |
| CHARACTERS BY THEIR POINTS | 0.3 | +20.6 | 52.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 22.7 | -933.0 | 0.0 | 792.0 | 14.7 | -855.4 | 0.0 | 658.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 408.0 | 0.0 | 4.3 | +0.0 | 453.3 | 279.3 |
| CLEAR LANE AHEAD | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 95.3 | 14.7 | +0.0 | 0.0 | 314.7 |
| CONVEYANCE SEARCH | 3.3 | +293.3 | 147.3 | 0.0 | - | - | - | - |
| COVER ONCE | 11.7 | -812.3 | 0.0 | 141.7 | 4.0 | -421.9 | 0.0 | 156.3 |
| DENIED BY THE FIGHT | 0.7 | -11.9 | 136.3 | 0.0 | 1.3 | -7.2 | 54.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -63.7 | 0.0 | 0.0 | 8.3 | +31.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +1.0 | 41.7 | 0.0 | 0.7 | +29.8 | 54.0 | 0.0 |
| EVASIVE BY THE ODDS | 1.0 | +158.3 | 0.0 | 0.0 | 2.7 | +959.4 | 118.0 | 0.0 |
| EXACT ROUND | 2.3 | +25.8 | 335.3 | 0.0 | 3.7 | +43.8 | 262.0 | 112.0 |
| FALL BACK GOOD ORDER | 1.7 | +5.3 | 212.0 | 0.0 | 4.0 | +19.0 | 334.0 | 34.0 |
| FALLS SHORT | 4.0 | +55.9 | 0.0 | 95.0 | 19.0 | +124.3 | 0.0 | 441.3 |
| FEATURE BUFFS | 1.0 | +2.9 | 0.0 | 0.0 | 0.7 | +7.4 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +7.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 41.0 | - | - | - | - |
| FIVE ACTION | 87.0 | +6942.2 | 1033.3 | 1687.3 | 87.7 | +5557.0 | 719.0 | 2487.3 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 98.0 | 8.3 | +0.0 | 0.0 | 311.3 |
| FOUR ROUNDS | 3.7 | +293.2 | 429.7 | 0.0 | 5.3 | +422.4 | 476.7 | 112.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 108.0 | 1.7 | +0.0 | 0.0 | 41.7 |
| FRIEND SHOOTS FIRST | 2.3 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -2.9 | 41.7 | 0.0 | 0.7 | -10.6 | 0.0 | 0.0 |
| GOAL WALK | 9.3 | +542.2 | 0.0 | 100.7 | 8.0 | +530.4 | 0.0 | 698.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +0.0 | 41.0 | 123.3 |
| GUN MASK | 1.7 | +13.5 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.0 | -0.1 | 105.7 | 0.0 | 1.0 | +0.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 108.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.7 | +0.0 | 0.0 | 483.3 | 9.0 | +0.0 | 0.0 | 398.3 |
| HIS CHARGE DENIED | 0.3 | +11.2 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 0.0 |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 490.7 | 3.0 | +0.0 | 0.0 | 174.7 |
| HIS LEGAL MOVES | 9.7 | +0.0 | 0.0 | 376.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -50.1 | 0.0 | 47.7 | 6.7 | -72.6 | 0.0 | 145.7 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 100.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 14.0 | +0.0 | 0.0 | 477.3 | 4.7 | +0.0 | 0.0 | 46.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 54.3 | +2195.3 | 0.0 | 1476.0 | 38.0 | +853.7 | 0.0 | 1161.3 |
| HIS SHOTS BY HIS RUN | 57.7 | +1463.7 | 0.0 | 1493.3 | 46.3 | +885.4 | 0.0 | 1168.0 |
| HIS TURN DENIED | 1.3 | +20.7 | 236.3 | 0.0 | 2.0 | +112.3 | 131.3 | 0.0 |
| HOLD ODDS | 18.0 | +0.0 | 0.0 | 82.0 | 12.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.0 | +970.2 | 0.0 | 41.0 | 9.0 | +774.0 | 0.0 | 52.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -120.1 | 234.0 | 0.0 | 5.0 | -187.8 | 476.7 | 112.0 |
| IDLE COST | 1.7 | -42.2 | 0.0 | 147.3 | 14.0 | -170.2 | 0.0 | 373.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +46.1 | 0.0 | 0.0 | 1.0 | +34.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 22.0 | 41.0 | 3.0 | +0.0 | 170.7 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 167.3 |
| LOST AFTER ESCAPE | 1.0 | +0.1 | 105.7 | 0.0 | 1.0 | -0.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 3.0 | +25.1 | 0.0 | 41.0 | 1.0 | +14.0 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +4.2 | 0.0 | 0.0 | 1.7 | -5.8 | 0.0 | 34.0 |
| MARCH AT ESCAPER | 0.3 | +23.5 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 115.7 |
| MARCH BY THE SUM | 1.0 | +24.6 | 0.0 | 0.0 | 0.3 | +3.7 | 0.0 | 115.7 |
| MARCH CHECK | - | - | - | - | 0.3 | +10.2 | 0.0 | 115.7 |
| MARCH OF THE TABLE | 0.3 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +47.0 | 0.0 | 0.0 | 0.3 | -27.0 | 0.0 | 115.7 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +70.3 | 0.0 | 149.0 | 0.7 | +22.3 | 0.0 | 65.0 |
| MEETS IN TIME | 3.0 | +80.0 | 0.0 | 0.0 | 4.0 | +131.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +85.2 | 0.0 | 108.0 | 0.7 | +19.7 | 0.0 | 168.3 |
| MISSILES NEXT TURN | 6.0 | +53.5 | 0.0 | 108.0 | 1.0 | +17.5 | 0.0 | 284.0 |
| MOVE ORDER | 1.0 | +0.0 | 50.3 | 0.0 | 1.0 | +0.0 | 61.7 | 115.7 |
| MOVE SPELL SPOT | 3.7 | +0.0 | 0.0 | 147.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 12.0 | +1013.6 | 0.0 | 100.7 | 4.7 | +621.0 | 0.0 | 46.7 |
| NEAR WALKS ONLY | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +233.1 | 0.0 | 50.3 | 9.0 | +280.2 | 0.0 | 90.7 |
| NEXT CHARGE BY LIST | 9.3 | +906.5 | 83.7 | 0.0 | 4.7 | +587.7 | 0.0 | 202.7 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| NO CHAFF EDGES | 6.0 | +198.1 | 290.0 | 41.0 | 3.0 | +111.2 | 142.7 | 154.0 |
| NO DOUBLE ROUNDS | 3.7 | -134.6 | 429.7 | 0.0 | 5.3 | -355.5 | 476.7 | 112.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -116.5 | 0.0 | 47.7 | 4.3 | -248.1 | 147.3 | 61.7 |
| ONE CHALLENGE TEST | 0.3 | +3.4 | 41.7 | 0.0 | 0.3 | -1.7 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 34.0 |
| ONE FIGHT FORMULA | 9.0 | -206.3 | 0.0 | 41.0 | 3.3 | -76.9 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +4.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | +55.2 | 0.0 | 41.0 | 3.3 | -273.3 | 0.0 | 52.7 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +0.2 | 22.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +28.7 | 23.3 | 0.0 |
| OPENS UP IN FULL | 2.3 | +117.0 | 290.0 | 0.0 | 2.7 | +120.9 | 166.0 | 78.0 |
| OVERRUNS AWAY | 1.0 | +11.8 | 188.0 | 0.0 | 2.0 | +28.7 | 358.3 | 34.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| PLAN RESULT | 40.3 | +961.7 | 428.7 | 1093.7 | 43.0 | +949.3 | 559.0 | 1377.3 |
| PRIZE BY WORTH | 0.7 | +36.0 | 38.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 12.0 | -447.1 | 0.0 | 196.0 | 9.7 | -375.5 | 0.0 | 123.3 |
| PROMISE KNOWS THE FIGHT | 1.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 12.0 | +1682.9 | 97.7 | 194.0 | 16.0 | +1749.4 | 329.0 | 234.7 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.7 | +217.4 | 0.0 | 55.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.7 | +0.0 | 0.0 | 44.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 34.0 |
| REFORMS TO MEET IT | 1.3 | -13.7 | 0.0 | 0.0 | 1.0 | -26.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +9.8 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | -48.8 | 429.7 | 0.0 | 4.3 | +46.1 | 453.3 | 112.0 |
| ROUNDS AFTER TERROR | 1.0 | +5.1 | 52.7 | 0.0 | 1.0 | -15.6 | 47.7 | 0.0 |
| RUN DOWN | 2.7 | -20.4 | 332.0 | 0.0 | 4.7 | -23.8 | 412.3 | 34.0 |
| SAME CHARGE LATER | 1.0 | -29.6 | 83.7 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +0.3 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -43.4 | 0.0 | 11.3 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +12.9 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 1.3 | +184.4 | 147.3 | 0.0 |
| SET CREDITED ONCE | 0.7 | -25.6 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.7 | +17.3 | 0.0 | 0.0 | 1.3 | -62.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 3.0 | +25.1 | 0.0 | 41.0 | 1.0 | +14.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 1.0 | +111.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.0 | +0.0 | 0.0 | 46.7 | 8.0 | +0.0 | 0.0 | 274.3 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +46.9 | 83.7 | 0.0 | 5.3 | +219.3 | 50.3 | 156.0 |
| SHOT OR CHARGE | 0.3 | -7.5 | 83.7 | 0.0 | 0.3 | -59.5 | 50.3 | 34.0 |
| SHOT RISK POINTS | 32.7 | -30.6 | 0.0 | 782.7 | 21.7 | -93.1 | 0.0 | 672.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +553.2 | 0.0 | 354.7 | 19.7 | +446.2 | 0.0 | 692.0 |
| SPELL SETS UP CHARGE | 1.3 | +193.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.0 | +39.4 | 0.0 | 0.0 | 0.3 | +3.6 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 1.3 | +18.8 | 225.3 | 0.0 | 1.0 | -9.2 | 50.3 | 34.0 |
| SPOT AS THE GAME MOVES | 8.7 | +0.0 | 0.0 | 147.3 | 5.7 | +0.0 | 0.0 | 275.3 |
| STAND AND SHOOT | 1.7 | -17.0 | 234.3 | 0.0 | 1.7 | -22.3 | 149.0 | 78.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 211.3 |
| STANDS STILL | 33.0 | +0.0 | 603.7 | 402.0 | 32.3 | +0.0 | 242.3 | 988.0 |
| STAY WORTH | 18.0 | +42.9 | 520.0 | 59.0 | 18.0 | +329.0 | 41.0 | 728.3 |
| SUPPORT ADDS | 4.0 | +546.4 | 0.0 | 201.3 | 4.3 | +278.8 | 0.0 | 235.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 41.0 | 234.0 |
| SUPPORT WORKED OUT | 4.0 | +546.4 | 0.0 | 201.3 | 4.3 | +278.8 | 0.0 | 235.3 |
| SURE REACH TOGETHER | 1.3 | +11.4 | 0.0 | 0.0 | 0.3 | +5.3 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +1.3 | 0.0 | 47.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 41.0 | 2.3 | +0.0 | 0.0 | 53.0 |
| THE FIGHT MOVES | 0.7 | +32.1 | 94.3 | 0.0 | 1.0 | +24.3 | 201.3 | 0.0 |
| THE PROMISE ADDS | 0.7 | -59.4 | 0.0 | 0.0 | 0.3 | -14.3 | 0.0 | 23.3 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 379.7 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 47.7 | 3.0 | +0.0 | 0.0 | 83.7 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 161.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.7 | +0.0 | 0.0 | 843.7 | 41.3 | +0.0 | 0.0 | 1182.0 |
| TIED UP BY THE SUM | 1.3 | +209.2 | 151.7 | 0.0 | 2.7 | +392.1 | 255.7 | 78.0 |
| TIME ON OUR SIDE | 37.3 | +505.9 | 0.0 | 641.0 | 9.7 | +103.2 | 0.0 | 670.0 |
| TWO OR MORE ARRIVE | 0.7 | +0.6 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| WAITS AGAIN | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.0 | -10.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -422.4 | 0.0 | 300.7 | 2.0 | -437.5 | 0.0 | 315.0 |
| WHOLE FIGHT REACTION | 4.0 | +191.3 | 134.7 | 350.7 | 2.7 | +53.5 | 0.0 | 428.0 |

### Rule changes: nw22-19bea9b-p20

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 155 | 155 | 108 | 36.00 | +682 | +6.3 |
| HIS SHOTS BY HIS RUN | 312 | 298 | 79 | 26.33 | +1263 | +16.0 |
| HIS SHOT LIST | 277 | 264 | 66 | 22.00 | +773 | +11.7 |
| HOLDER ASSIGNMENT | 57 | 57 | 54 | 18.00 | +3865 | +71.6 |
| SHOT RISK POINTS | 163 | 155 | 32 | 10.67 | +1178 | +36.8 |
| DEPLOY BY FIGURES | 49 | 49 | 28 | 9.33 | +268 | +9.6 |
| FIVE ACTION | 524 | 505 | 28 | 9.33 | +1206 | +43.1 |
| NEXT CHARGE BY LIST | 42 | 42 | 28 | 9.33 | +1748 | +62.4 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -1094 | -39.1 |
| MOVE TO CHARGE COMPUTED | 50 | 46 | 26 | 8.67 | +1536 | +59.1 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 65 | 65 | 24 | 8.00 | -2468 | -102.8 |
| GOAL WALK | 52 | 52 | 21 | 7.00 | +964 | +45.9 |
| NO CHAFF EDGES | 27 | 24 | 18 | 6.00 | +512 | +28.4 |
| CHARGE LOSSES | 112 | 106 | 17 | 5.67 | +1310 | +77.0 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 14 | 4.67 | +69 | +4.9 |
| TIME ON OUR SIDE | 141 | 113 | 14 | 4.67 | +47 | +3.4 |
| SUPPORT ADDS | 25 | 25 | 13 | 4.33 | +492 | +37.8 |
| SUPPORT WORKED OUT | 25 | 25 | 13 | 4.33 | +492 | +37.8 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CLEAR LANE AHEAD | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 27 | 23 | 12 | 4.00 | +427 | +35.6 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 12 | 10 | 10 | 3.33 | +363 | +36.3 |
| MEETS IN TIME | 21 | 21 | 9 | 3.00 | +103 | +11.4 |
| QUARTER ODDS | 84 | 83 | 8 | 2.67 | +534 | +66.7 |
| REDIRECT FOR A FRIEND IN REACH | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 20 | 20 | 7 | 2.33 | -415 | -59.3 |
| EVASIVE BY THE ODDS | 11 | 11 | 7 | 2.33 | +2205 | +315.0 |
| IDLE COST | 47 | 30 | 7 | 2.33 | +15 | +2.2 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +242 | +34.6 |
| STAY WORTH | 108 | 93 | 7 | 2.33 | +512 | +73.2 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 20 | 20 | 6 | 2.00 | +59 | +9.8 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +191 | +38.2 |
| MAX FOR POSITIONING | 17 | 15 | 5 | 1.67 | +6 | +1.2 |
| OPENS UP IN FULL | 15 | 12 | 5 | 1.67 | +211 | +42.2 |
| SHOTS IN THE MOVE | 105 | 71 | 5 | 1.67 | +117 | +23.4 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +85 | +21.2 |
| RISK BY ARC | 23 | 19 | 4 | 1.33 | +172 | +43.0 |
| SCOUT BY DROPS | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +553 | +138.2 |
| SET UP BY THE SET | 9 | 9 | 4 | 1.33 | +291 | +72.7 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +14 | +4.6 |
| FALLS SHORT | 69 | 60 | 3 | 1.00 | +32 | +10.8 |
| HIS MOVE AND SHOT | 31 | 28 | 3 | 1.00 | +17 | +5.5 |
| REDIRECT COUNTER | 11 | 10 | 3 | 1.00 | +48 | +16.2 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT NARROWED | 5 | 5 | 3 | 1.00 | -78 | -26.2 |
| WHOLE FIGHT DANGER | 19 | 19 | 3 | 1.00 | +293 | +97.6 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.67 | +0 | +0.1 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +22 | +11.2 |
| COVER ONCE | 47 | 25 | 2 | 0.67 | +14 | +6.9 |
| EXACT ROUND | 18 | 15 | 2 | 0.67 | +51 | +25.3 |
| HIS TURN DENIED | 10 | 9 | 2 | 0.67 | +50 | +25.1 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 44 | 42 | 2 | 0.67 | +74 | +37.2 |
| ONE OBJECTIVE FORMULA | 29 | 23 | 2 | 0.67 | +22 | +11.0 |
| PRIZE BY WORTH | 2 | 2 | 2 | 0.67 | +108 | +54.1 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 2 | 0.67 | -0 | -0.2 |
| PROMISE READS THE TABLE | 4 | 4 | 2 | 0.67 | +5 | +2.6 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +107 | +53.4 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 17 | 13 | 1 | 0.33 | +6 | +6.4 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 1 | 1 | 0.33 | +4 | +3.5 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +13 | +12.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -81 | -81.1 |
| NO DOUBLE ROUNDS | 27 | 23 | 1 | 0.33 | +6 | +6.4 |
| ONE FIGHT FORMULA | 37 | 14 | 1 | 0.33 | +3 | +3.3 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +6 | +6.4 |
| OVERRUNS AWAY | 9 | 7 | 1 | 0.33 | +38 | +38.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -4 | -4.2 |
| REFORMS TO MEET IT | 7 | 5 | 1 | 0.33 | +10 | +9.8 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -22 | -22.5 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +29 | +29.3 |
| RUN DOWN | 22 | 18 | 1 | 0.33 | +6 | +6.4 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +39 | +38.6 |
| SET UP TOGETHER | 12 | 6 | 1 | 0.33 | +9 | +8.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SURE REACH TOGETHER | 5 | 4 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| THE FIGHT MOVES | 5 | 4 | 1 | 0.33 | +65 | +65.2 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 11 | trace | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 67 | 67 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 6 | 5 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 15 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| GUN MASK | 5 | 5 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 11 | 11 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 71 | 67 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 36 | 34 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 56 | 51 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 90 | 90 | 0 | 0.00 | - | - |
| HONEST WORTH | 23 | 19 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 12 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 13 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NEAR WALKS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 2 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 250 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 5 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 45 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 21 | 21 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 7 | 6 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 43 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 10 | 10 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 196 | 188 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 246 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 10 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p20

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.00 | 37.2 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | 3.33 | 102.8 |
| ARMY TABLE | rule | 4.33 | 2.00 | 65.2 |
| CHARGE NOW FIRST | rule | 1.33 | 1.00 | 59.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 43.9 |
| NO REASON | gate | - | 1.00 | 62.8 |
| SUPPORT NARROWED | rule | - | 1.00 | 26.2 |
| FALLBACK | gate | - | 0.33 | 11.4 |
| MARCH OF THE TABLE | rule | 0.33 | - | 81.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 4.2 |
| REFUSING RETIRES | rule | 0.33 | - | 22.5 |

### Plans: nw22-19bea9b-p20

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 100% | 521 | 397 | 76% |
| Mine | move | 32.3 | 92% | 1840 | 0 | 0% |
| Mine | shoot | 5.7 | 82% | 368 | 565 | 154% |
| Opponent | charge | 4.7 | 64% | 774 | 450 | 58% |
| Opponent | move | 31.0 | 87% | 1452 | 0 | 0% |
| Opponent | shoot | 6.7 | 30% | 550 | 500 | 91% |
| Opponent | support | 0.7 | 50% | 4 | 0 | 0% |

### Battle groups: nw22-19bea9b-p20

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.7 | 9% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p20

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 84 (7) | 84 | 0 | 15 | 0% | 2.0 | 33 (4) | 166 (2) | 72 (1) | 84 (7) | - |
| Mine | Clean-up | 1 | 39 (1) | 0 | 39 | 0 | 100% | - | 39 (1) | - | - | 39 (1) | - |
| Mine | Fast Hammer | 14 | 76 (14) | 18 | 58 | 42 | 43% | 3.1 | 47 (7) | 64 (5) | 199 (2) | 72 (9) | 84 (5) |
| Mine | Shooter | 4 | 10 (4) | 10 | 0 | 74 | 0% | 1.0 | 14 (3) | 0 (1) | - | 14 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 7 | 101 (7) | 0 | 101 | 56 | 0% | 2.7 | - | 190 (4) | 16 (3) | 154 (5) | 21 (2) |
| Opponent | Character | 4 | 71 (4) | 71 | 0 | 14 | 0% | 2.0 | 0 (1) | 38 (1) | 104 (2) | 93 (1) | 61 (3) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 50 | 75% | 5.0 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 22 (4) | 22 | 0 | 52 | 25% | 1.3 | 77 (1) | 0 (2) | 0 (1) | 43 (2) | 0 (2) |
| Opponent | Hammer | 8 | 8 (8) | 8 | 0 | 103 | 25% | 2.0 | 0 (3) | 18 (4) | 0 (1) | 0 (4) | 16 (4) |
| Opponent | Holder | 3 | 156 (3) | 0 | 156 | 0 | 0% | 2.3 | 250 (2) | - | 0 (1) | 450 (1) | 23 (2) |
| Opponent | Shooter | 4 | 11 (4) | 0 | 11 | 41 | 25% | 1.0 | 0 (1) | 53 (1) | 0 (2) | 15 (3) | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 101 | 33% | 1.0 | 0 (1) | - | - | 0 (1) | - |

### Charged fights: nw22-19bea9b-p20

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 269 | 83 | 2.0 | 1.0 | 42 | 0 | +42 | 1 of 6 | 6 of 6 | - | +42 |
| Opponent | Ogre Kingdoms | 1 | 0 | 123 | 3.0 | 1.0 | 41 | 0 | +41 | 1 of 3 | 0 of 3 | - | +41 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 1002 | 3.0 | 1.3 | 334 | 0 | +334 | 1 of 3 | 3 of 3 | +328 | +337 |
| Opponent | Wood Elf Realms | 1 | 0 | 320 | 4.0 | 1.0 | 80 | 26 | +54 | 2 of 4 | 2 of 4 | - | +54 |
| **Opponent** | all armies | 3 | 0 | 482 | 3.3 | 1.1 | 144 | 10 | +134 | 4 of 10 | 5 of 10 | +328 | +113 |

### Effective charges: nw22-19bea9b-p20

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 6 | 0 | 0 | 1 (net +0) | 0 | 4 (net +62) | 1 (net +0) | 0 | 17% (1 of 6) |
| Opponent | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 1 (net +328) | 1 (net +162) | 1 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 1 (net +0) | 0 | 1 (net +143) | 1 (net +177) | 1 | 33% (1 of 3) |

### Charged fights, damage counted: nw22-19bea9b-p20

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 143 | 251 | +0 | 20 | 72 | -52 | -36.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 151 | 66 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 494 | 98 | +62 | 70 | 0 | +70 | +14.1 |
| Mine | All fights | 6 | 379 | 118 | +42 | 50 | 12 | +38 | +10.0 |
| Opponent | Effective (55-75%) | 2 | 108 | 150 | +0 | 66 | 32 | +35 | +32.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 465 | 170 | +170 | 170 | 0 | +170 | +36.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 567 | 160 | +236 | 248 | 32 | +215 | +38.0 |
| Opponent | No odds | 4 | 152 | 274 | +133 | 178 | 98 | +79 | +52.1 |
| Opponent | All fights | 10 | 289 | 206 | +134 | 168 | 52 | +116 | +40.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p20 | move | 24 | 8 (33%) | 5 (21%) | 4 (17%) | 12 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

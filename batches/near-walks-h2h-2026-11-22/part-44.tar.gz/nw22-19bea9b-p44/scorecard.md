# Doctrine scorecard: nw22-19bea9b-p44

### Scorecard: nw22-19bea9b-p44

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 5 | 4 | 2 | 0 | 0 | 0 | 0 | 540 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 1 | 5 | 1 | 2 | 0 | 0 | 72 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 0 | 0 | 0 | 158 |
| **Average** | | | Mine | 0% | 5.5 | 2.7 | 3.3 | 1.3 | 0.0 | 0.0 | 0.0 | 180.0 |
| **Average** | | | Opponent | 50% | 0.0 | 2.3 | 2.3 | 1.0 | 0.7 | 0.0 | 0.0 | 76.7 |

### KPIs: nw22-19bea9b-p44

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 17) | 0% (0 of 34) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 33% | 50% (1 of 2); on the table 50% | 40% (2 of 5); on the table 40% |
| Winner chose to follow up or pursue (all three) |  | 71% (5 of 7); on the table 71% | 83% (5 of 6); on the table 83% | 77% (10 of 13); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 22% (4 of 18) | - | 22% (4 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (4 of 12) | - | 33% (4 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 32% (1907 of 6000) | 51% (3045 of 6000) | 41% (4952 of 12000) |
|   infantry points that never fought | lower | 18% (162 of 923) | 65% (752 of 1159) | 44% (914 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (14 of 26) | 83% (20 of 24) | 68% (34 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 50% (1 of 2); 0.3 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 21% (3 of 14); 2.0 uses a game | 0.0 uses a game | 21% (3 of 14); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (2524 of 5860) | 75% (3844 of 5131) | 58% (6368 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (29%) | - | 1.3 (29%) |
| MARCHED: its unit marched | 0.7 (14%) | - | 0.7 (14%) |
| CHARGED: its unit charged | 0.7 (14%) | - | 0.7 (14%) |
| IN COMBAT: engaged in combat | 1.3 (29%) | - | 1.3 (29%) |
| GONE: slain | 0.7 (14%) | - | 0.7 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 2.0 | 3.3 | 1.3 | 2.3 |
| not cast | 4.3 | 8.0 | 4.7 | 4.7 | 25.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (25%) | 0.3 (7%) | 1.3 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.3 (29%) | 1.3 (29%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.7 (15%) | 0.7 (8%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 2.0 (46%) | 1.3 (17%) | 2.0 (43%) | 0.7 (14%) | 4.3 (17%) |
| OFF THE TABLE: off the table or not arrived | 1.7 (38%) | 3.3 (42%) | 0.0 (0%) | 0.0 (0%) | 3.3 (13%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (60%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.3 a game | 0.0 a game | 1.7 a game |
| stood (cast and not dispelled) | 100% (10 of 10) | - | 100% (10 of 10) |
| the unit moved after it | 50% (5 of 10) | - | 50% (5 of 10) |
| it charged on its next turn | 0% (0 of 10) | - | 0% (0 of 10) |
| the enemy charged it first | 20% (2 of 10) | - | 20% (2 of 10) |
| it fought by the end of its next turn | 20% (2 of 10) | - | 20% (2 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 10) | - | 0% (0 of 10) |
| none of these (no charge, no fight, no charge escaped) | 80% (8 of 10) | - | 80% (8 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 53% (39 of 73) | 57% (58 of 101) | 56% (97 of 174) |
|   cavalry | 67% (10 of 15) | 100% (18 of 18) | 85% (28 of 33) |
|   character | 14% (4 of 29) | 12% (2 of 17) | 13% (6 of 46) |
|   chariot | - | 71% (5 of 7) | 71% (5 of 7) |
|   infantry | 83% (15 of 18) | 50% (25 of 50) | 59% (40 of 68) |
|   monster | - | 89% (8 of 9) | 89% (8 of 9) |
|   war machine | 91% (10 of 11) | - | 91% (10 of 11) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (26%) | 1.0 (7%) | 4.0 (16%) |
| CHARGED: it charged | 4.0 (35%) | 3.3 (23%) | 7.3 (29%) |
| IN COMBAT: it fought this turn or the last | 1.3 (12%) | 0.3 (2%) | 1.7 (6%) |
| NO TARGET IN RANGE | 1.7 (15%) | 6.7 (47%) | 8.3 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 1.0 (7%) | 1.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (9%) | 1.3 (9%) | 2.3 (9%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.0 | 2.0 | 87% | 8.2 pts | 107 pts |
| character | 3.7 | 0.7 | 82% | 2.0 pts | 7 pts |
| chariot | 1.7 | 0.7 | 80% | 9.8 pts | 16 pts |
| infantry | 19.0 | 5.3 | 77% | 8.2 pts | 157 pts |
| monster | 3.0 | 1.0 | 67% | 10.5 pts | 31 pts |
| war machine | 3.3 | 1.0 | 80% | 11.3 pts | 38 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 6.0 | 5.5 |
| Charges that made contact a game | 3.0 | 4.0 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 2.00 declared, 1.33 contact (3 units) | - | 2.00 declared, 1.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.22 contact (23 units) | 0.55 declared, 0.36 contact (33 units) | 0.48 declared, 0.30 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 65% (11 of 17) | - | - | 65% (11 of 17) |
| Character on its own | - | 80% (4 of 5) | 25% (2 of 8) | 46% (6 of 13) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 90% (9 of 10) | 0% (0 of 1) | - | 82% (9 of 11) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 71% (5 of 7); on the table 71% | 22% (4 of 18) | 32% | 54% (14 of 26) | 100% (1 of 1); 1.7 uses a game | 21% (3 of 14); 2.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (4 of 4); on the table 100% | - | 60% | 86% (6 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | - | 40% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | - | 52% | 83% (10 of 12) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p44, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 83% (5) | 73% (8) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.67 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 1.33 | 2.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p44

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 62% (8 of 13) | 53% (8 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (9 of 20) | 54% (13 of 24) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | - |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 1) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 1.0 |
| Movement | Points that never moved of their own | 180.0 | 76.7 |
| Movement | Fights charged into per game | 3.0 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 8 | 0 of 9 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 8, net +0 | 2 of 9, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 8, net +96 | 1 of 9, net +143 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 8, net +66 | 6 of 9, net +204 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 20.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (20 of 34) | 61% (37 of 61) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 3.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (6 of 10) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | - |
| Magic | Wounds caused by magic missiles | 3.7 | - |
| Magic | Wounds caused by other spells | 3.3 | - |
| Magic | Points destroyed by magic (all spells) | 151.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.7 / 1.0 / 0.0 | 1.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 144.3 | 380.7 |
| Combat | Points run down | 328.7 | 59.0 |
| Combat | Net points per charged fight, damage counted | +46 | +140 |
| Combat | Net per 100 charger points, damage counted | +11.8 | +38.7 |
| Combat | First round won (charged fights) | 100% | 64% |
| Combat | Net points per charged fight | +68 | +135 |
| Combat | Net points per supported fight / lone fight | - / +68 | -195 / +168 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 9 | 4 of 11 |
| Game | Points lost | 657.3 | 1054.0 |
| Game | VP from objectives | 826.7 | 663.3 |
| Game | Lone holders (player turns) | 5.5 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +453 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1711
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: nw22-19bea9b-p44

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 28.0 | +219.8 | 0.0 | 1132.7 | 23.3 | +316.0 | 0.0 | 1060.3 |
| ASSAILMENT BY POINTS | 0.3 | +2.0 | 0.0 | 133.3 | - | - | - | - |
| BACKS UP THE FIGHT | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 1.0 | +0.1 | 0.0 | 145.7 | - | - | - | - |
| CANNON PLANNED TARGET | 3.3 | +0.0 | 130.0 | 46.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +12.8 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 3.3 | +0.0 | 0.0 | 266.7 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +35.3 | 0.0 | 22.7 |
| CHALLENGE BY POINTS | 2.0 | +83.2 | 0.0 | 263.7 | 0.3 | +16.3 | 0.0 | 41.7 |
| CHARACTERS BY THEIR POINTS | 0.3 | +20.6 | 52.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 20.0 | -711.3 | 0.0 | 724.0 | 15.7 | -710.3 | 0.0 | 680.0 |
| CHARGE NOW FIRST | 3.7 | +0.0 | 515.0 | 0.0 | 5.3 | +0.0 | 537.7 | 310.3 |
| CLEAR LANE AHEAD | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 294.7 | 18.7 | +0.0 | 0.0 | 348.7 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 59.0 | 65.0 |
| CONVEYANCE SEARCH | 3.0 | +105.9 | 428.0 | 266.7 | - | - | - | - |
| COVER ONCE | 9.3 | -569.5 | 0.0 | 150.3 | 3.0 | -383.0 | 0.0 | 101.3 |
| DENIED BY THE FIGHT | 0.7 | -2.8 | 136.3 | 0.0 | 0.7 | -1.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -63.7 | 0.0 | 0.0 | 8.3 | +31.9 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.0 | 41.7 | 0.0 | 0.7 | -70.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +10.0 | 41.7 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | 1.3 | +180.8 | 0.0 | 59.0 | 2.7 | +1348.6 | 200.0 | 0.0 |
| EXACT ROUND | 3.3 | +46.4 | 434.7 | 0.0 | 3.0 | +46.6 | 345.0 | 78.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.3 | +22.7 | 329.7 | 0.0 | 4.0 | +14.2 | 472.3 | 65.0 |
| FALLS SHORT | 2.3 | +22.9 | 0.0 | 41.0 | 16.7 | +159.3 | 0.0 | 340.0 |
| FEATURE BUFFS | 0.7 | +1.9 | 0.0 | 0.0 | 0.7 | +7.4 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +10.5 | 0.0 | 65.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 41.0 | - | - | - | - |
| FIVE ACTION | 84.0 | +6291.7 | 1091.0 | 2380.0 | 86.3 | +6208.1 | 602.0 | 2307.7 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 98.0 | 8.3 | +0.0 | 0.0 | 267.0 |
| FOLLOW UP WEIGHED | 0.7 | +32.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 4.7 | +301.2 | 529.0 | 0.0 | 5.3 | +357.9 | 561.0 | 143.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 167.3 |
| FRIEND SHOOTS FIRST | 2.3 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -11.5 | 23.3 | 0.0 |
| GOAL WALK | 10.0 | +596.4 | 0.0 | 523.3 | 9.3 | +597.1 | 0.0 | 614.7 |
| GUN FIGURES | - | - | - | - | 1.7 | +0.0 | 41.0 | 123.3 |
| GUN MASK | 2.0 | +12.7 | 0.0 | 147.3 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.7 | -0.1 | 83.7 | 0.0 | 0.7 | -1.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 3.7 | +0.0 | 0.0 | 83.3 |
| HELP BY WHAT IT ADDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 65.0 |
| HIS CHARGE BY HIS RUN | 11.0 | +0.0 | 0.0 | 415.3 | 10.7 | +0.0 | 0.0 | 596.3 |
| HIS CHARGE DENIED | 0.3 | +11.2 | 0.0 | 0.0 | 0.7 | +4.1 | 47.7 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 342.3 | 3.7 | +0.0 | 0.0 | 174.7 |
| HIS LEGAL MOVES | 6.3 | +0.0 | 0.0 | 177.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -40.5 | 0.0 | 47.7 | 3.3 | -52.7 | 0.0 | 34.0 |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 177.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 50.7 | +2000.9 | 0.0 | 2098.0 | 41.7 | +883.5 | 0.0 | 1185.7 |
| HIS SHOTS BY HIS RUN | 53.7 | +1312.0 | 0.0 | 1156.3 | 40.0 | +637.1 | 0.0 | 993.3 |
| HIS TURN DENIED | 1.3 | +10.9 | 236.3 | 0.0 | 1.0 | +32.2 | 82.3 | 0.0 |
| HOLD ODDS | 18.3 | +0.0 | 0.0 | 82.0 | 12.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.3 | +962.9 | 0.0 | 41.0 | 9.7 | +769.5 | 0.0 | 52.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -160.4 | 333.3 | 0.0 | 5.0 | -225.7 | 561.0 | 143.0 |
| IDLE COST | 1.3 | -32.7 | 0.0 | 0.0 | 13.0 | -144.2 | 0.0 | 330.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | +56.0 | 0.0 | 65.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +46.1 | 0.0 | 0.0 | 1.0 | +34.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 0.0 | 100.0 | 3.3 | +0.0 | 41.0 | 34.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 167.3 |
| LOST AFTER ESCAPE | 0.7 | +0.1 | 83.7 | 0.0 | 1.0 | +1.2 | 0.0 | 65.0 |
| MAKE SURE TOGETHER | 2.3 | +25.2 | 0.0 | 41.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +29.9 | 0.0 | 0.0 | 2.0 | -7.0 | 0.0 | 75.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 115.7 |
| MARCH BY THE SUM | 0.7 | +17.1 | 0.0 | 0.0 | 0.3 | +3.7 | 0.0 | 115.7 |
| MARCH CHECK | - | - | - | - | 0.3 | +10.2 | 0.0 | 115.7 |
| MARCH OF THE TABLE | 0.3 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +116.7 | 0.0 | 133.3 | 0.3 | -27.0 | 0.0 | 115.7 |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +68.5 | 0.0 | 41.0 | 0.3 | +21.7 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +80.0 | 0.0 | 0.0 | 4.0 | +131.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.3 | +49.0 | 0.0 | 0.0 | 0.7 | +19.7 | 0.0 | 168.3 |
| MISSILES NEXT TURN | 5.0 | +31.0 | 0.0 | 266.7 | 1.0 | +17.5 | 0.0 | 284.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 147.3 | 1.0 | +0.0 | 61.7 | 115.7 |
| MOVE SPELL SPOT | 3.3 | +0.0 | 0.0 | 428.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.0 | +870.9 | 0.0 | 0.0 | 4.0 | +348.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +253.4 | 0.0 | 82.0 | 10.0 | +353.8 | 0.0 | 52.7 |
| NEXT CHARGE BY LIST | 6.7 | +808.4 | 83.7 | 0.0 | 5.3 | +435.1 | 0.0 | 156.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -6.8 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 9.7 | +388.3 | 400.0 | 41.0 | 4.0 | +83.5 | 257.0 | 253.0 |
| NO DOUBLE ROUNDS | 4.0 | -140.3 | 473.0 | 0.0 | 4.7 | -361.7 | 561.0 | 143.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -63.6 | 0.0 | 73.7 | 4.7 | -258.5 | 0.0 | 103.7 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -155.4 | 0.0 | 41.0 | 3.3 | -98.7 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +26.6 | 0.0 | 65.0 |
| ONE OBJECTIVE FORMULA | 6.7 | +40.9 | 0.0 | 41.0 | 5.0 | -306.5 | 0.0 | 52.7 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.0 | +2.3 | 67.3 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +15.2 | 0.0 | 0.0 | 0.3 | +17.6 | 23.3 | 0.0 |
| OPENS UP IN FULL | 3.3 | +204.5 | 400.0 | 0.0 | 3.7 | +99.0 | 280.3 | 143.0 |
| OVERRUNS AWAY | 1.3 | +95.4 | 229.7 | 0.0 | 0.3 | +0.4 | 133.3 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| PLAN RESULT | 39.7 | +858.2 | 275.3 | 1292.7 | 42.3 | +904.3 | 492.7 | 1342.3 |
| PRIZE BY WORTH | 1.0 | +73.7 | 0.0 | 0.0 | 0.3 | +8.4 | 0.0 | 0.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -368.1 | 0.0 | 0.0 | 7.0 | -310.6 | 0.0 | 165.3 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 12.0 | +1624.6 | 56.0 | 147.3 | 16.3 | +2050.8 | 73.7 | 112.0 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +24.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +185.3 | 0.0 | 55.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.0 | +33.6 | 0.0 | 44.0 |
| REDIRECT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -9.7 | 0.0 | 0.0 | 0.7 | -27.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 41.7 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +36.2 | 0.0 | 22.0 |
| RISK BY ARC | 4.3 | -112.8 | 529.0 | 0.0 | 4.7 | -11.2 | 561.0 | 143.0 |
| ROUNDS AFTER TERROR | 0.7 | +8.2 | 52.7 | 0.0 | 2.0 | -44.7 | 231.3 | 65.0 |
| RUN DOWN | 3.7 | -20.9 | 449.7 | 0.0 | 4.7 | -30.2 | 496.7 | 65.0 |
| SAME CHARGE LATER | 1.0 | -29.6 | 83.7 | 0.0 | 0.3 | -7.3 | 0.0 | 0.0 |
| SCOUT BY DROPS | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +0.3 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -43.4 | 0.0 | 11.3 |
| SEARCH SPOT | 0.3 | +15.2 | 0.0 | 0.0 | 0.3 | +12.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +12.2 | 0.0 | 0.0 | 0.3 | +9.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -25.6 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +14.3 | 0.0 | 0.0 | 1.0 | +18.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 2.3 | +25.2 | 0.0 | 41.0 | 0.7 | +1.1 | 0.0 | 42.0 |
| SET-UP ANY TARGET | 0.7 | +96.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.7 | +0.0 | 0.0 | 146.7 | 8.3 | +0.0 | 0.0 | 214.3 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +29.4 | 83.7 | 0.0 | 4.7 | +246.9 | 0.0 | 156.0 |
| SHOT OR CHARGE | 0.7 | -9.5 | 107.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 27.7 | -309.3 | 0.0 | 682.0 | 19.7 | -135.8 | 0.0 | 570.7 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.0 | +256.8 | 0.0 | 387.7 | 20.0 | +752.4 | 0.0 | 659.3 |
| SPELL SETS UP CHARGE | 1.0 | +177.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.3 | +15.8 | 266.7 | 266.7 | 0.3 | +3.6 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 0.7 | +16.5 | 161.7 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 428.0 | 4.7 | +0.0 | 0.0 | 202.7 |
| STAND AND SHOOT | 2.0 | -17.8 | 276.3 | 0.0 | 0.3 | -3.3 | 41.0 | 78.0 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 253.3 |
| STANDS STILL | 32.3 | +0.0 | 562.0 | 869.3 | 31.7 | +0.0 | 41.0 | 824.0 |
| STAY WORTH | 15.0 | -14.5 | 390.0 | 182.0 | 16.7 | +308.1 | 41.0 | 748.3 |
| SUPPORT ADDS | 4.0 | +434.6 | 0.0 | 0.0 | 3.7 | +262.5 | 0.0 | 220.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 41.0 | 234.0 |
| SUPPORT WORKED OUT | 4.0 | +434.6 | 0.0 | 0.0 | 3.7 | +262.5 | 0.0 | 220.0 |
| SURE REACH TOGETHER | 0.7 | +6.6 | 0.0 | 0.0 | 1.0 | +1.7 | 0.0 | 22.0 |
| SWIFTSTRIDE BY POINTS | 0.7 | +5.3 | 0.0 | 98.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 41.0 | 1.7 | +0.0 | 0.0 | 11.3 |
| THE FIGHT MOVES | 1.3 | +32.3 | 159.3 | 0.0 | 1.0 | +37.0 | 280.7 | 65.0 |
| THE PROMISE ADDS | 0.7 | -59.4 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 273.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 392.7 | 3.7 | +0.0 | 0.0 | 148.7 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 50.3 | 3.0 | +0.0 | 0.0 | 237.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.7 | +0.0 | 0.0 | 1190.0 | 40.7 | +0.0 | 0.0 | 1076.7 |
| TIED UP BY THE SUM | 2.3 | +358.8 | 235.3 | 0.0 | 2.3 | +339.9 | 280.3 | 78.0 |
| TIME ON OUR SIDE | 39.3 | +485.4 | 0.0 | 1739.3 | 9.7 | +103.2 | 0.0 | 670.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -2.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.0 | -288.0 | 0.0 | 333.3 | 3.3 | -459.9 | 0.0 | 383.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +39.1 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 4.0 | +289.5 | 100.7 | 484.0 | 2.3 | +59.2 | 0.0 | 395.3 |

### Rule changes: nw22-19bea9b-p44

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 154 | 154 | 110 | 36.67 | +1840 | +16.7 |
| HIS SHOT LIST | 277 | 270 | 72 | 24.00 | +1097 | +15.2 |
| HIS SHOTS BY HIS RUN | 281 | 274 | 65 | 21.67 | +747 | +11.5 |
| HOLDER ASSIGNMENT | 60 | 60 | 57 | 19.00 | +3278 | +57.5 |
| NO CHAFF EDGES | 41 | 40 | 30 | 10.00 | +794 | +26.5 |
| DEPLOY BY FIGURES | 49 | 49 | 28 | 9.33 | +268 | +9.6 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -966 | -34.5 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 36 | 35 | 26 | 8.67 | +1347 | +51.8 |
| FIVE ACTION | 511 | 500 | 23 | 7.67 | +928 | +40.4 |
| GOAL WALK | 58 | 58 | 23 | 7.67 | +1003 | +43.6 |
| MOVE TO CHARGE COMPUTED | 36 | 31 | 22 | 7.33 | +1049 | +47.7 |
| SHOT RISK POINTS | 142 | 138 | 18 | 6.00 | +278 | +15.4 |
| PROMISE BY ITS OWN SUM | 47 | 47 | 16 | 5.33 | -2036 | -127.3 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| QUARTER ODDS | 85 | 84 | 15 | 5.00 | +1156 | +77.1 |
| TIME ON OUR SIDE | 147 | 126 | 15 | 5.00 | +43 | +2.8 |
| FOUR ROUNDS | 30 | 28 | 14 | 4.67 | +398 | +28.4 |
| TIED UP BY THE SUM | 14 | 13 | 13 | 4.33 | +536 | +41.2 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CLEAR LANE AHEAD | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 27 | 27 | 11 | 3.67 | -482 | -43.8 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 11 | 3.67 | +34 | +3.1 |
| CHARGE LOSSES | 107 | 103 | 10 | 3.33 | +868 | +86.8 |
| EVASIVE BY THE ODDS | 12 | 12 | 10 | 3.33 | +3431 | +343.1 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MEETS IN TIME | 21 | 21 | 9 | 3.00 | +103 | +11.4 |
| OPENS UP IN FULL | 21 | 19 | 9 | 3.00 | +198 | +22.0 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +88 | +9.8 |
| SUPPORT ADDS | 23 | 23 | 9 | 3.00 | +354 | +39.3 |
| SUPPORT WORKED OUT | 23 | 23 | 9 | 3.00 | +354 | +39.3 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +299 | +42.7 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +242 | +34.6 |
| STAY WORTH | 95 | 80 | 7 | 2.33 | +512 | +73.2 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 102 | 72 | 6 | 2.00 | +467 | +77.9 |
| IDLE COST | 43 | 27 | 5 | 1.67 | +11 | +2.1 |
| COVER ONCE | 37 | 22 | 4 | 1.33 | +95 | +23.8 |
| EXACT ROUND | 19 | 17 | 4 | 1.33 | +63 | +15.7 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +168 | +42.0 |
| MAX FOR POSITIONING | 12 | 11 | 4 | 1.33 | +6 | +1.5 |
| ONE OBJECTIVE FORMULA | 35 | 29 | 4 | 1.33 | +83 | +20.6 |
| PRIZE BY WORTH | 4 | 4 | 4 | 1.33 | +246 | +61.6 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +109 | +27.2 |
| SCOUT BY DROPS | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 1.00 | +0 | +0.1 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 6 | 3 | 1.00 | +14 | +4.6 |
| FALLS SHORT | 57 | 49 | 3 | 1.00 | +32 | +10.8 |
| MANOEUVRE | 9 | 9 | 3 | 1.00 | +98 | +32.7 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +62 | +20.7 |
| NEARER NOT NEEDED | 50 | 47 | 3 | 1.00 | +121 | +40.4 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +136 | +45.4 |
| RISK BY ARC | 27 | 25 | 3 | 1.00 | +90 | +29.8 |
| SCOUTS HUNT GUNS ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT NARROWED | 5 | 5 | 3 | 1.00 | -78 | -26.2 |
| WHOLE FIGHT REACTION | 19 | 19 | 3 | 1.00 | +187 | +62.2 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +22 | +11.2 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +96 | +48.0 |
| HIS TURN DENIED | 7 | 7 | 2 | 0.67 | +54 | +27.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +21 | +10.4 |
| PROMISE READS THE TABLE | 4 | 4 | 2 | 0.67 | +5 | +2.6 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -27 | -13.3 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +84 | +42.1 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +64 | +32.2 |
| SET UP BY THE SET | 5 | 5 | 2 | 0.67 | +80 | +40.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +16 | +8.0 |
| THE FIGHT MOVES | 7 | 7 | 2 | 0.67 | +60 | +30.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 19 | 18 | 1 | 0.33 | +20 | +19.6 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 2 | 1 | 0.33 | +4 | +3.5 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -81 | -81.1 |
| NO DOUBLE ROUNDS | 26 | 24 | 1 | 0.33 | +51 | +50.7 |
| ONE FIGHT FORMULA | 30 | 13 | 1 | 0.33 | +3 | +3.3 |
| OPENS A LANE | 3 | 1 | 1 | 0.33 | +0 | +0.0 |
| OPENS UP | 2 | 1 | 1 | 0.33 | +8 | +7.8 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +124 | +123.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -4 | -4.2 |
| REDIRECT COUNTER | 10 | 8 | 1 | 0.33 | +32 | +31.7 |
| SET UP TOGETHER | 9 | 3 | 1 | 0.33 | +8 | +7.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS AFTER THE MOVES | 23 | 23 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 5 | 4 | 1 | 0.33 | +2 | +1.7 |
| THE ROW IN ITS ORDER | 21 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 22 | 22 | 1 | 0.33 | +166 | +165.8 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +4 | +3.6 |
| BACKS UP THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLANNED TARGET | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 10 | trace | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 76 | 76 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 11 | 11 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 65 | 64 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 23 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 33 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 93 | 0 | 0.00 | - | - |
| HONEST WORTH | 26 | 24 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 7 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 12 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 246 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 25 | 23 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 45 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 39 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 192 | 190 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 238 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p44

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 4.00 | 37.6 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 2.33 | 127.3 |
| ARMY TABLE | rule | 3.33 | 1.67 | 43.0 |
| CHARGE NOW FIRST | rule | 2.00 | 1.67 | 43.8 |
| SUPPORT NARROWED | rule | - | 1.00 | 26.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 25.8 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 13.3 |
| FALLBACK | gate | - | 0.33 | 11.4 |
| JOINT CHARGE NOW | rule | - | 0.33 | 50.1 |
| MARCH OF THE TABLE | rule | 0.33 | - | 81.1 |
| NO REASON | gate | 0.33 | - | 8.7 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 4.2 |
| RULE SWITCHED OFF | gate | - | 0.33 | 7.1 |

### Plans: nw22-19bea9b-p44

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 91% | 791 | 510 | 64% |
| Mine | move | 29.7 | 92% | 1745 | 0 | 0% |
| Mine | shoot | 6.3 | 63% | 207 | 348 | 168% |
| Opponent | charge | 5.0 | 60% | 752 | 672 | 89% |
| Opponent | move | 30.7 | 87% | 1591 | 0 | 0% |
| Opponent | shoot | 5.7 | 35% | 441 | 232 | 53% |
| Opponent | support | 1.0 | 67% | 21 | 0 | 0% |

### Battle groups: nw22-19bea9b-p44

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 10% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p44

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 77 (7) | 77 | 0 | 28 | 0% | 1.9 | 20 (4) | 168 (2) | 70 (1) | 77 (7) | - |
| Mine | Clean-up | 1 | 150 (1) | 85 | 65 | 0 | 0% | 2.0 | 150 (1) | - | - | 150 (1) | - |
| Mine | Fast Hammer | 14 | 85 (14) | 18 | 68 | 41 | 36% | 2.9 | 62 (7) | 69 (5) | 199 (2) | 86 (9) | 84 (5) |
| Mine | Shooter | 4 | 10 (4) | 10 | 0 | 51 | 0% | 1.0 | 13 (3) | 0 (1) | - | 13 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 7 | 92 (7) | 0 | 92 | 56 | 0% | 2.7 | - | 172 (4) | 16 (3) | 154 (5) | 0 (2) |
| Opponent | Character | 4 | 97 (4) | 97 | 0 | 14 | 0% | 1.8 | 0 (1) | 0 (1) | 165 (2) | 93 (1) | 99 (3) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 80 | 25% | 3.7 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 0 (4) | 0 | 0 | 71 | 25% | 1.3 | 0 (1) | 0 (2) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Hammer | 8 | 8 (8) | 8 | 0 | 95 | 25% | 1.8 | 0 (3) | 18 (4) | 0 (1) | 0 (4) | 16 (4) |
| Opponent | Holder | 3 | 219 (3) | 0 | 219 | 0 | 0% | 3.7 | 219 (3) | - | - | 450 (1) | 114 (2) |
| Opponent | Shooter | 4 | 44 (4) | 0 | 44 | 0 | 25% | 1.0 | 0 (1) | 211 (1) | 0 (2) | 59 (3) | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 101 | 33% | 1.0 | 0 (1) | - | - | 0 (1) | - |

### Charged fights: nw22-19bea9b-p44

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 151 | 205 | 3.0 | 1.0 | 68 | 0 | +68 | 1 of 9 | 9 of 9 | - | +68 |
| Opponent | Ogre Kingdoms | 1 | 0 | 123 | 3.0 | 1.0 | 41 | 0 | +41 | 1 of 3 | 0 of 3 | - | +41 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 1240 | 6.0 | 1.2 | 207 | 32 | +174 | 2 of 6 | 5 of 6 | -195 | +248 |
| Opponent | Wood Elf Realms | 1 | 0 | 320 | 2.0 | 1.0 | 160 | 0 | +160 | 1 of 2 | 2 of 2 | - | +160 |
| **Opponent** | all armies | 3 | 0 | 561 | 3.7 | 1.1 | 153 | 18 | +135 | 4 of 11 | 7 of 11 | -195 | +168 |

### Effective charges: nw22-19bea9b-p44

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 9 | 0 | 0 | 1 (net +0) | 1 (net +70) | 5 (net +96) | 1 (net +66) | 1 | 12% (1 of 8) |
| Opponent | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +0) | 0 | 0 | 5 (net +209) | 0 | 17% (1 of 6) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +143) | 1 (net +177) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: nw22-19bea9b-p44

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 143 | 251 | +0 | 20 | 72 | -52 | -36.0 |
| Mine | 76-89% | 1 | 247 | 70 | +70 | 70 | 0 | +70 | +28.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 151 | 66 | +66 | 66 | 30 | +36 | +23.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 498 | 99 | +96 | 105 | 0 | +105 | +21.1 |
| Mine | No odds | 1 | 489 | 102 | +0 | 0 | 163 | -163 | -33.3 |
| Mine | All fights | 9 | 391 | 109 | +68 | 76 | 29 | +46 | +11.8 |
| Opponent | Effective (55-75%) | 2 | 260 | 204 | +0 | 71 | 0 | +71 | +27.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 479 | 246 | +204 | 236 | 32 | +204 | +42.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 143 | +143 | 143 | 0 | +143 | +28.7 |
| Opponent | No odds | 2 | 34 | 133 | +62 | 62 | 48 | +14 | +41.2 |
| Opponent | All fights | 11 | 360 | 208 | +135 | 166 | 26 | +140 | +38.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p44 | move | 22 | 7 (32%) | 5 (23%) | 5 (23%) | 10 (45%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

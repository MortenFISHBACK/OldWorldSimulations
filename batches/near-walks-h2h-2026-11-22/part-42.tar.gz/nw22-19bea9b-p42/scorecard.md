# Doctrine scorecard: nw22-19bea9b-p42

### Scorecard: nw22-19bea9b-p42

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 375 |
| L0918 | 6 | 1 | Opponent | no | 8 | - | 3 | 2 | 1 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 477 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 6 | 4 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 6 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.3 | 2.0 | 0.3 | 1.0 | 0.0 | 0.0 | 0.0 | 394.0 |
| **Average** | | | Opponent | 0% | 4.7 | 3.0 | 4.0 | 2.3 | 0.7 | 0.0 | 0.0 | 78.0 |

### KPIs: nw22-19bea9b-p42

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 71% (10 of 14) | 0% (0 of 15) | 34% (10 of 29) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 83% | 100% (2 of 2); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% | 0% (0 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 71% (5 of 7); on the table 86% | 75% (3 of 4); on the table 100% | 73% (8 of 11); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 23% (11 of 48) | 8% (1 of 12) | 20% (12 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 30% (11 of 37) | 9% (1 of 11) | 25% (12 of 48) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 54% (3241 of 5997) | 41% (2452 of 5998) | 47% (5693 of 11995) |
|   infantry points that never fought | lower | 69% (1090 of 1591) | 56% (639 of 1147) | 63% (1729 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (22 of 34) | 50% (10 of 20) | 59% (32 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 1.7 uses a game | 100% (1 of 1); 1.7 uses a game | 67% (2 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (3490 of 5667) | 46% (2364 of 5186) | 54% (5854 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (49%) | 0.0 (0%) | 6.0 (38%) |
| MARCHED: its unit marched | 1.7 (14%) | 0.7 (18%) | 2.3 (15%) |
| CHARGED: its unit charged | 1.0 (8%) | 0.7 (18%) | 1.7 (10%) |
| IN COMBAT: engaged in combat | 3.7 (30%) | 0.3 (9%) | 4.0 (25%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (9%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.7 (45%) | 1.7 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 2.3 | 4.0 | 0.7 | 3.3 |
| not cast | 2.0 | 3.7 | 16.0 | 3.3 | 12.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (45%) | 6.0 (38%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.3 (15%) | 0.7 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 1.7 (10%) | 0.3 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 4.0 (25%) | 0.7 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (55%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (50%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.7 (10%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (97%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (90 of 123) | 57% (39 of 69) | 67% (129 of 192) |
|   cavalry | - | 58% (7 of 12) | 58% (7 of 12) |
|   character | 100% (11 of 11) | 56% (10 of 18) | 72% (21 of 29) |
|   chariot | 94% (15 of 16) | 100% (2 of 2) | 94% (17 of 18) |
|   infantry | 50% (22 of 44) | 47% (14 of 30) | 49% (36 of 74) |
|   monster | 67% (8 of 12) | 86% (6 of 7) | 74% (14 of 19) |
|   war machine | 85% (34 of 40) | - | 85% (34 of 40) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (12%) | 5.0 (50%) | 6.3 (30%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (20%) | 2.0 (10%) |
| IN COMBAT: it fought this turn or the last | 1.3 (12%) | 0.0 (0%) | 1.3 (6%) |
| MOVED: a war machine that moved | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 2.7 (24%) | 2.3 (23%) | 5.0 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.0 (27%) | 0.7 (7%) | 3.7 (17%) |
| SHELTERED: the target was sheltered | 1.0 (9%) | 0.0 (0%) | 1.0 (5%) |
| OTHER BAR | 1.0 (9%) | 0.0 (0%) | 1.0 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 0.3 | 93% | 0.9 pts | 4 pts |
| character | 7.3 | 1.0 | 86% | 1.2 pts | 9 pts |
| chariot | 5.7 | 3.0 | 59% | 13.0 pts | 74 pts |
| infantry | 14.0 | 3.7 | 76% | 3.6 pts | 51 pts |
| monster | 7.7 | 2.7 | 83% | 4.7 pts | 36 pts |
| war machine | 11.3 | 11.3 | 59% | 34.7 pts | 394 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 6.3 | 4.7 |
| Charges that made contact a game | 2.3 | 4.7 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 3.00 declared, 2.33 contact (3 units) | 3.00 declared, 1.00 contact (1 units) | 3.00 declared, 2.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 1.00 contact (1 units) | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (19 units) | 0.45 declared, 0.39 contact (31 units) | 0.28 declared, 0.24 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | - | - | 25% (1 of 4) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| Character on its own | - | 33% (1 of 3) | 20% (1 of 5) | 25% (2 of 8) |
| Chariot | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Infantry | 45% (5 of 11) | 100% (2 of 2) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 0% (0 of 2) | 80% (4 of 5) | - | 57% (4 of 7) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 75% (3 of 4); on the table 100% | 21% (5 of 24) | 64% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 67% (2 of 3); on the table 67% | 25% (6 of 24) | 33% | 50% (5 of 10) | 50% (1 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 94% | 71% (5 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 5% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 67% (2 of 3); on the table 100% | - | 24% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p42, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 25% (1) | 29% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: nw22-19bea9b-p42

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 62% (5 of 8) | 73% (11 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (19 of 60) | 57% (13 of 23) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 25% (1 of 4) | - |
| Strategy | Joined characters whose unit fought | 30% (3 of 10) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 75% (3 of 4) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 394.0 | 78.0 |
| Movement | Fights charged into per game | 1.7 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +110 | 0 of 10 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 1 of 10, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +45 | 3 of 10, net +183 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +329 | 5 of 10, net +95 |
| Shooting | Shots by shooting units (incl. breath weapons) | 19.7 | 13.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (29 of 59) | 51% (20 of 39) |
| Shooting | Points destroyed by shooting units | 73.0 | 0.0 |
| Shooting | War machine shots | 11.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (22 of 34) | - |
| Shooting | Points destroyed by war machines | 87.0 | 41.7 |
| Magic | Magic missiles cast | 2.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (4 of 6) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 2.3 | 1.3 |
| Magic | Wounds caused by other spells | 5.3 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.3 / 2.0 / 0.3 | 2.0 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 181.3 | 251.3 |
| Combat | Points run down | 0.0 | 55.0 |
| Combat | Net points per charged fight, damage counted | +116 | +97 |
| Combat | Net per 100 charger points, damage counted | +26.5 | +34.8 |
| Combat | First round won (charged fights) | 80% | 75% |
| Combat | Net points per charged fight | +109 | +85 |
| Combat | Net points per supported fight / lone fight | +164 / +72 | +265 / +69 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 2 of 12 |
| Game | Points lost | 528.3 | 403.0 |
| Game | VP from objectives | 526.7 | 760.0 |
| Game | Lone holders (player turns) | 1.3 | 4.7 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -202 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 931
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: nw22-19bea9b-p42

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 12.7 | +144.7 | 0.0 | 218.3 | 20.0 | +219.3 | 0.0 | 415.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +8.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 83.3 | - | - | - | - |
| CANNON PLANNED TARGET | 10.3 | +386.5 | 327.3 | 318.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 6.7 | +109.1 | 18.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 1.3 | +29.1 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +12.7 | 0.0 | 11.3 |
| CHALLENGE BY POINTS | 0.7 | +49.9 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 109.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| CHARACTER GUNS | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.3 | -19.1 | 0.0 | 0.0 |
| CHARGE LOSSES | 19.7 | -516.2 | 0.0 | 315.3 | 20.7 | -1037.3 | 0.0 | 539.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 88.3 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 249.3 | 0.0 | 1.0 | +0.0 | 98.7 | 0.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -3.4 | 0.0 | 0.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 4.3 | +0.0 | 0.0 | 102.0 | 14.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 9.0 | -370.9 | 0.0 | 192.3 | 6.7 | -553.0 | 0.0 | 146.3 |
| DENIED BY THE FIGHT | - | - | - | - | 1.7 | -10.9 | 246.0 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | -60.4 | 0.0 | 41.7 | 8.3 | +44.5 | 0.0 | 61.7 |
| DUEL STOPS AT THE KILL | 0.7 | -5.0 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +0.4 | 15.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +16.6 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +2.6 | 196.3 | 0.0 | 3.0 | -13.4 | 464.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 311.0 | 0.0 | 3.7 | +12.6 | 378.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 31.0 | +304.6 | 0.0 | 342.3 |
| FEATURE BUFFS | 0.3 | +14.6 | 0.0 | 0.0 | 0.7 | +6.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +25.3 | 256.0 | 0.0 | 0.7 | +0.0 | 34.7 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 88.3 | 0.3 | +0.0 | 0.0 | 61.7 |
| FIVE ACTION | 97.7 | +5192.9 | 1255.3 | 1777.3 | 97.3 | +4962.2 | 781.3 | 788.0 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 176.7 | 3.7 | +0.0 | 0.0 | 121.0 |
| FOLLOW UP WEIGHED | 1.3 | +132.1 | 0.0 | 0.0 | 1.7 | +51.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +219.5 | 326.0 | 0.0 | 5.3 | +285.6 | 698.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 54.0 | 7.7 | +0.0 | 0.0 | 267.3 |
| FRIENDS SHOTS CHECKED | 0.3 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -15.1 | 40.0 | 0.0 | 0.7 | -5.6 | 88.7 | 0.0 |
| GOAL WALK | 7.7 | +473.0 | 0.0 | 0.0 | 21.3 | +1857.8 | 0.0 | 416.0 |
| GUN FIGURES | 3.3 | +36.1 | 0.0 | 176.7 | 0.7 | +35.3 | 41.7 | 123.3 |
| GUN MASK | 2.3 | +63.9 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 1.7 | +32.0 | 256.0 | 0.0 | 1.7 | -2.6 | 211.3 | 0.0 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 45.0 | 2.7 | +0.0 | 0.0 | 78.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 36.7 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 36.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.0 | +0.0 | 0.0 | 315.3 | 11.3 | +0.0 | 0.0 | 292.7 |
| HIS CHARGE LIST | 7.3 | +0.0 | 0.0 | 138.7 | 6.0 | +0.0 | 0.0 | 36.7 |
| HIS LEGAL MOVES | 6.7 | +0.0 | 0.0 | 157.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -13.0 | 0.0 | 0.0 | 17.7 | -146.9 | 0.0 | 36.7 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 353.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 246.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.7 | +896.2 | 0.0 | 720.7 | 62.7 | +4431.5 | 0.0 | 602.0 |
| HIS SHOTS BY HIS RUN | 38.3 | +395.2 | 0.0 | 873.3 | 58.0 | +1348.2 | 0.0 | 632.0 |
| HIS TURN DENIED | - | - | - | - | 2.3 | +226.9 | 329.3 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 399.3 | 20.0 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 12.3 | +1161.5 | 0.0 | 199.7 | 14.3 | +1406.8 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -138.9 | 326.0 | 0.0 | 4.3 | -194.1 | 521.3 | 0.0 |
| HUNT IN PAIRS | 0.7 | +54.5 | 0.0 | 0.0 | 1.3 | +37.0 | 0.0 | 36.7 |
| IDLE COST | - | - | - | - | 20.0 | -271.1 | 0.0 | 51.7 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 1.7 | +21.1 | 239.3 | 0.0 | 1.3 | +127.0 | 265.0 | 0.0 |
| JOINT LOOK BACK | 0.3 | +4.3 | 20.0 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +48.9 | 88.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 0.7 | +10.8 | 0.0 | 0.0 | 1.3 | +97.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 69.3 | 3.0 | +0.0 | 34.7 | 166.3 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | +3.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -46.6 | 256.0 | 0.0 | 2.3 | +2.9 | 246.0 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 2.7 | +63.9 | 0.0 | 11.3 |
| MANOEUVRE | 1.7 | +16.3 | 0.0 | 54.0 | 0.7 | -2.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +55.2 | 0.0 | 0.0 | 0.3 | +53.4 | 0.0 | 0.0 |
| MARCH CHECK | 2.7 | +113.6 | 0.0 | 0.0 | 0.7 | +26.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +2.4 | 0.0 | 0.0 | 0.3 | +14.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.3 | -33.4 | 0.0 | 0.0 | 0.7 | +7.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| MAX FOR POSITIONING | 2.3 | +19.6 | 0.0 | 0.0 | 3.7 | +107.3 | 0.0 | 20.3 |
| MEETS IN TIME | 3.7 | +358.9 | 0.0 | 0.0 | 4.7 | +505.4 | 0.0 | 61.7 |
| MISSILES IN THE MOVE | 9.3 | +180.2 | 0.0 | 54.0 | 2.0 | +39.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 11.3 | +109.0 | 0.0 | 108.0 | 2.3 | +25.3 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 9.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.7 | +222.7 | 0.0 | 176.7 | 4.3 | +230.3 | 0.0 | 0.0 |
| NEAR WALKS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.7 | +356.2 | 0.0 | 108.0 | 4.7 | +217.0 | 0.0 | 109.7 |
| NEXT CHARGE BY LIST | 2.0 | +130.4 | 0.0 | 88.3 | 3.3 | +178.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -18.5 | 0.0 | 0.0 | 0.3 | -22.9 | 0.0 | 0.0 |
| NO CHAFF EDGES | 3.7 | +34.9 | 51.7 | 69.3 | 5.3 | +153.0 | 556.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -90.0 | 326.0 | 0.0 | 4.3 | -206.5 | 486.7 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.0 | -253.9 | 0.0 | 131.3 | 4.7 | -54.1 | 0.0 | 11.3 |
| OGRE LOADER SECOND SHOT | 2.0 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | -3.1 | 109.7 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 54.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -32.9 | 0.0 | 157.7 | 8.3 | -157.4 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 1.0 | +97.1 | 36.7 | 0.0 | 0.3 | +14.8 | 88.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -136.0 | 0.0 | 145.7 | 4.0 | +85.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.7 | +7.5 | 51.7 | 0.0 | 2.7 | +112.7 | 417.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.7 | +21.2 | 195.7 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -23.7 | 0.0 | 0.0 |
| PLAN RESULT | 44.3 | +1421.5 | 358.7 | 973.3 | 45.3 | +423.2 | 161.0 | 523.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 15.0 |
| PROMISE BY ITS OWN SUM | 6.7 | -153.6 | 0.0 | 88.3 | 5.3 | -55.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -6.6 | 0.0 | 0.0 |
| QUARTER ODDS | 6.0 | +157.0 | 0.0 | 589.3 | 11.0 | +1284.9 | 287.7 | 0.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -7.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +181.2 | 0.0 | 40.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 6.0 | +0.2 | 0.0 | 35.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -34.5 | 0.0 | 176.7 | - | - | - | - |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +38.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +115.2 | 311.0 | 0.0 | 3.0 | -246.5 | 356.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 40.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -24.1 | 163.0 | 0.0 |
| RUN DOWN | - | - | - | - | 3.3 | -45.1 | 349.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -3.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | +13.5 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -133.3 | 0.0 | 18.0 |
| SEARCH SPOT | 0.3 | +2.2 | 0.0 | 0.0 | 0.7 | -1.1 | 0.0 | 9.0 |
| SET CREDITED ONCE | - | - | - | - | 4.7 | -136.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +15.6 | 0.0 | 88.3 | 6.3 | +116.3 | 54.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 2.7 | +63.9 | 0.0 | 11.3 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 19.3 | +0.0 | 0.0 | 318.3 | 7.3 | +0.0 | 0.0 | 87.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +90.0 | 156.0 | 0.0 | 1.3 | +11.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -4.6 | 0.0 | 0.0 |
| SHOT RISK POINTS | 19.7 | -171.7 | 0.0 | 176.7 | 42.0 | -283.9 | 0.0 | 360.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 32.3 | +1532.2 | 0.0 | 635.3 | 12.7 | +186.2 | 0.0 | 201.3 |
| SPELL WORTH | - | - | - | - | 4.0 | +55.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +1.8 | 40.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 2.3 | +0.0 | 0.0 | 54.0 | 7.7 | +0.0 | 0.0 | 254.3 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -31.1 | 123.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 6.7 | +0.0 | 83.3 | 156.0 |
| STANDS STILL | 57.3 | +0.0 | 929.3 | 877.3 | 30.3 | +0.0 | 83.3 | 156.0 |
| STAY WORTH | 44.0 | +146.9 | 632.0 | 619.7 | 26.7 | +196.5 | 83.3 | 357.3 |
| STRIKE BY THE ODDS | 0.3 | +1.8 | 0.0 | 88.3 | 0.3 | +0.5 | 0.0 | 0.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.3 | -3.4 | 0.0 | 40.0 |
| SUPPORT ADDS | 1.7 | +390.4 | 0.0 | 0.0 | 1.7 | +59.5 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +390.4 | 0.0 | 0.0 | 1.7 | +59.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +15.4 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 2.3 | +13.1 | 296.0 | 0.0 | 2.7 | +35.3 | 272.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 1.0 | -14.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 36.7 | 182.7 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 99.0 | 6.3 | +0.0 | 0.0 | 61.7 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 45.0 | 5.3 | +0.0 | 0.0 | 61.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.3 | +0.0 | 0.0 | 854.0 | 46.0 | +0.0 | 0.0 | 403.0 |
| TIED UP BY THE SUM | 1.3 | +151.2 | 70.0 | 0.0 | 1.7 | +275.9 | 230.3 | 0.0 |
| TIME ON OUR SIDE | 48.0 | +604.8 | 18.0 | 404.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 88.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -26.4 | 69.3 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -1.0 | 57.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +9.1 | 34.7 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -254.1 | 0.0 | 138.7 | 3.7 | -412.5 | 0.0 | 219.3 |
| WHOLE FIGHT GAIN | 0.7 | +31.8 | 0.0 | 0.0 | 0.7 | +12.1 | 88.3 | 0.0 |
| WHOLE FIGHT REACTION | 4.3 | +268.0 | 0.0 | 309.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 7.7 | +99.1 | 0.0 | 0.0 | 2.0 | +63.8 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p42

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 98 | 98 | 87 | 29.00 | +1385 | +15.9 |
| HOLDER ASSIGNMENT | 80 | 80 | 74 | 24.67 | +3405 | +46.0 |
| HIS SHOT LIST | 292 | 277 | 70 | 23.33 | +1992 | +28.5 |
| HIS SHOTS BY HIS RUN | 289 | 274 | 68 | 22.67 | +786 | +11.6 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -924 | -26.4 |
| DEPLOY BY FIGURES | 54 | 54 | 29 | 9.67 | +367 | +12.6 |
| GOAL WALK | 87 | 87 | 29 | 9.67 | +1548 | +53.4 |
| STAY WORTH | 212 | 189 | 26 | 8.67 | +65 | +2.5 |
| NO CHAFF EDGES | 27 | 27 | 21 | 7.00 | +258 | +12.3 |
| SHOT RISK POINTS | 185 | 183 | 21 | 7.00 | +604 | +28.8 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 17 | 5.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 144 | 124 | 16 | 5.33 | +87 | +5.4 |
| CAST JOB | 20 | 20 | 15 | 5.00 | +109 | +7.2 |
| FOUR ROUNDS | 25 | 25 | 15 | 5.00 | +422 | +28.1 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| FIVE ACTION | 585 | 566 | 13 | 4.33 | +559 | +43.0 |
| MEETS IN TIME | 25 | 25 | 13 | 4.33 | +1148 | +88.3 |
| IDLE COST | 60 | 32 | 12 | 4.00 | +78 | +6.5 |
| LEGAL CHARGES ONLY | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 36 | 36 | 12 | 4.00 | -626 | -52.2 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 12 | 4.00 | +83 | +6.9 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 21 | 13 | 11 | 3.67 | +345 | +31.3 |
| NEXT CHARGE BY LIST | 16 | 13 | 10 | 3.33 | +364 | +36.4 |
| CHARGE LOSSES | 121 | 120 | 9 | 3.00 | +1089 | +121.0 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +550 | +61.1 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +445 | +49.4 |
| MARCH CHECK | 10 | 10 | 8 | 2.67 | +142 | +17.7 |
| TIED UP BY THE SUM | 9 | 9 | 8 | 2.67 | +213 | +26.7 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1166 | +166.5 |
| FALLS SHORT | 93 | 68 | 6 | 2.00 | +33 | +5.5 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +324 | +53.9 |
| MISSILES IN THE MOVE | 34 | 27 | 6 | 2.00 | +101 | +16.8 |
| OGRE LOADER SECOND SHOT | 6 | 6 | 6 | 2.00 | +11 | +1.8 |
| QUARTER ODDS | 51 | 49 | 6 | 2.00 | +359 | +59.8 |
| RISK BY ARC | 17 | 17 | 6 | 2.00 | +158 | +26.3 |
| SET UP BY THE SET | 20 | 19 | 6 | 2.00 | +328 | +54.7 |
| WOUNDS ON THE RANKS | 29 | 29 | 6 | 2.00 | +63 | +10.5 |
| MAX FOR POSITIONING | 18 | 16 | 5 | 1.67 | +84 | +16.8 |
| SHOTS IN THE MOVE | 135 | 112 | 5 | 1.67 | +79 | +15.8 |
| CHARGE NOW FIRST | 8 | 8 | 4 | 1.33 | -98 | -24.4 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| OPENS UP IN FULL | 10 | 10 | 4 | 1.33 | +54 | +13.6 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 3 | 1.00 | +43 | +14.3 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +153 | +50.9 |
| COVER ONCE | 47 | 32 | 3 | 1.00 | +103 | +34.4 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 7 | 7 | 3 | 1.00 | +110 | +36.8 |
| MANOEUVRE | 7 | 7 | 3 | 1.00 | +53 | +17.7 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +326 | +108.6 |
| NEARER NOT NEEDED | 37 | 35 | 3 | 1.00 | +93 | +31.1 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +115 | +38.2 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 27 | 27 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT ADDS | 10 | 8 | 3 | 1.00 | +160 | +53.3 |
| SUPPORT WORKED OUT | 10 | 8 | 3 | 1.00 | +160 | +53.3 |
| SURE REACH TOGETHER | 3 | 3 | 3 | 1.00 | +5 | +1.5 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 14 | 14 | 2 | 0.67 | +9 | +4.4 |
| GUN MASK | 7 | 7 | 2 | 0.67 | +65 | +32.7 |
| HALF WHEN STILL FLEEING | 10 | 10 | 2 | 0.67 | +55 | +27.4 |
| HIS MOVE AND SHOT | 64 | 64 | 2 | 0.67 | +8 | +4.2 |
| HONEST WORTH | 22 | 22 | 2 | 0.67 | +198 | +99.1 |
| INFANTRY NOT BEHIND INFANTRY | 2 | 2 | 2 | 0.67 | +360 | +180.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -50 | -24.8 |
| NO DOUBLE ROUNDS | 20 | 20 | 2 | 0.67 | +155 | +77.6 |
| ONE JOINT FIGURE | 4 | 4 | 2 | 0.67 | +55 | +27.4 |
| REDIRECT COUNTER | 10 | 7 | 2 | 0.67 | +14 | +6.8 |
| SCOUT BY DROPS | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +7 | +3.4 |
| WHOLE FIGHT GAIN | 4 | 4 | 2 | 0.67 | +55 | +27.4 |
| WHOLE FIGHT REACTION | 13 | 13 | 2 | 0.67 | +32 | +16.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| CANNON PLANNED TARGET | 31 | 31 | 1 | 0.33 | -3 | -3.2 |
| CHAFF IN THE MOVE | 5 | 3 | 1 | 0.33 | +1 | +0.6 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -135 | -134.6 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 17 | 17 | 1 | 0.33 | +11 | +10.8 |
| FIGHT TO THE END | 5 | 5 | 1 | 0.33 | +9 | +8.8 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +43 | +43.1 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HUNT IN PAIRS | 6 | 3 | 1 | 0.33 | +78 | +77.7 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +13 | +12.8 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +147 | +146.6 |
| LONG SHOT | 2 | 2 | 1 | 0.33 | +2 | +2.1 |
| ONE OBJECTIVE FORMULA | 28 | 23 | 1 | 0.33 | +31 | +30.9 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +2 | +2.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -71 | -71.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +302 | +301.8 |
| ROUNDS AFTER TERROR | 5 | 5 | 1 | 0.33 | +12 | +12.4 |
| RUN DOWN | 10 | 10 | 1 | 0.33 | +44 | +44.2 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +7 | +6.6 |
| SET UP TOGETHER | 8 | 6 | 1 | 0.33 | +24 | +24.5 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| THE FIGHT MOVES | 15 | 15 | 1 | 0.33 | +5 | +5.5 |
| THE ROW IN ITS ORDER | 13 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 19 | 19 | 1 | 0.33 | +2 | +2.2 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 16 | 16 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 54 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 31 | 29 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 15 | 15 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 76 | 75 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 38 | 35 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 53 | 46 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 108 | 107 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 11 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 41 | 30 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 32 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 14 | 13 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 80 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 30 | 27 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 20 | 20 | 0 | 0.00 | - | - |
| STANDS STILL | 263 | 253 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 268 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p42

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.00 | 3.00 | 28.5 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 1.00 | 52.2 |
| ARMY TABLE | rule | 2.67 | 1.00 | 23.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | 2.33 | 28.7 |
| RULE SWITCHED OFF | gate | - | 1.67 | 13.8 |
| CHARGE NOW FIRST | rule | 0.67 | 0.67 | 24.4 |
| JOINT CHARGE NOW | rule | 0.67 | 0.33 | 29.7 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 24.8 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 3.2 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 134.6 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 1.8 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 71.1 |

### Plans: nw22-19bea9b-p42

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 86% | 156 | 311 | 199% |
| Mine | join | 0.3 | 100% | 4 | 0 | 0% |
| Mine | move | 24.7 | 95% | 1469 | 0 | 0% |
| Mine | shoot | 17.0 | 53% | 948 | 1110 | 117% |
| Opponent | charge | 3.0 | 89% | 281 | 343 | 122% |
| Opponent | move | 34.7 | 95% | 1852 | 0 | 0% |
| Opponent | shoot | 7.0 | 43% | 297 | 80 | 27% |
| Opponent | support | 0.7 | 50% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p42

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 10% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p42

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 31 (12) | 31 | 0 | 0 | 33% | 3.4 | 19 (3) | 52 (5) | 0 (4) | 26 (8) | 45 (4) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Fast Hammer | 3 | 84 (3) | 0 | 84 | 64 | 33% | 3.5 | - | 51 (2) | 144 (1) | 119 (2) | 0 (1) |
| Mine | Hammer | 8 | 13 (8) | 0 | 13 | 15 | 38% | 2.6 | - | 7 (6) | 38 (2) | 11 (6) | 22 (2) |
| Mine | Shooter | 6 | 155 (6) | 35 | 120 | 50 | 0% | 1.3 | 0 (1) | 305 (2) | 107 (3) | 155 (6) | - |
| Mine | War machine | 8 | 24 (8) | 24 | 0 | 50 | 0% | 1.2 | 187 (1) | 0 (1) | 3 (6) | - | 24 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Opponent | Chaff | 11 | 143 (11) | 0 | 143 | 34 | 55% | 3.4 | 77 (4) | 600 (1) | 114 (6) | 143 (11) | - |
| Opponent | Character | 6 | 41 (6) | 41 | 0 | 0 | 0% | 2.3 | 47 (5) | 0 (1) | - | 34 (3) | 46 (3) |
| Opponent | Clean-up | 4 | 22 (4) | 9 | 14 | 25 | 25% | 1.7 | - | 0 (1) | 30 (3) | 0 (2) | 46 (2) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 21 (10) | 18 | 3 | 50 | 20% | 2.6 | 34 (2) | 11 (6) | 40 (2) | 20 (8) | 32 (2) |
| Opponent | Holder | 1 | 76 (1) | 0 | 76 | 0 | 0% | 6.0 | - | 76 (1) | - | 76 (1) | - |
| Opponent | Shooter | 1 | 188 (1) | 0 | 188 | 0 | 0% | 1.0 | - | 188 (1) | - | 188 (1) | - |

### Charged fights: nw22-19bea9b-p42

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 240 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 0 | 544 | 5.0 | 1.4 | 109 | 0 | +109 | 1 of 5 | 4 of 5 | +164 | +72 |
| **Mine** | all armies | 3 | 160 | 181 | 1.7 | 1.4 | 109 | 0 | +109 | 1 of 5 | 4 of 5 | +164 | +72 |
| Opponent | Ogre Kingdoms | 1 | 125 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 0 of 2 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 300 | 2.0 | 1.0 | 150 | 0 | +150 | 0 of 2 | 2 of 2 | - | +150 |
| Opponent | Wood Elf Realms | 1 | 0 | 723 | 8.0 | 1.2 | 90 | 0 | +90 | 2 of 8 | 7 of 8 | +265 | +65 |
| **Opponent** | all armies | 3 | 42 | 341 | 4.0 | 1.2 | 85 | 0 | +85 | 2 of 12 | 9 of 12 | +265 | +69 |

### Effective charges: nw22-19bea9b-p42

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 5 | 1 (net +110) | 0 | 0 | 1 (net +0) | 1 (net +45) | 1 (net +329) | 1 | 0% (0 of 4) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 1 (net +300) | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 8 | 0 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +125) | 4 (net +118) | 0 | 12% (1 of 8) |

### Charged fights, damage counted: nw22-19bea9b-p42

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 205 | 110 | +110 | 110 | 0 | +110 | +53.7 |
| Mine | 76-89% | 1 | 703 | 357 | +0 | 243 | 105 | +137 | +19.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 539 | 329 | +329 | 329 | 102 | +226 | +42.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 369 | 45 | +45 | 45 | 0 | +45 | +12.2 |
| Mine | No odds | 1 | 369 | 60 | +60 | 60 | 0 | +60 | +16.3 |
| Mine | All fights | 5 | 437 | 180 | +109 | 157 | 42 | +116 | +26.5 |
| Opponent | Effective (55-75%) | 1 | 91 | 227 | +0 | 76 | 18 | +57 | +63.2 |
| Opponent | 76-89% | 1 | 109 | 104 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 308 | 149 | +95 | 117 | 13 | +104 | +33.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 499 | 128 | +183 | 183 | 0 | +183 | +36.7 |
| Opponent | No odds | 2 | 62 | 146 | +0 | 39 | 18 | +22 | +34.7 |
| Opponent | All fights | 12 | 280 | 146 | +85 | 107 | 10 | +97 | +34.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p42 | move | 21 | 5 (24%) | 4 (19%) | 2 (10%) | 14 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

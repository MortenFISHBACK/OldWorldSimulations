# Doctrine scorecard: nw22-19bea9b-p33

### Scorecard: nw22-19bea9b-p33

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 141 |
| L1723 | 1 | 1 | Opponent | yes | 1 | 2 | 9 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.0 | 2.5 | 2.0 | 0.7 | 0.3 | 0.0 | 0.0 | 80.3 |
| **Average** | | | Opponent | 67% | 1.5 | 2.3 | 5.0 | 2.7 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: nw22-19bea9b-p33

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 16) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (7 of 7); on the table 100% | 86% (6 of 7); on the table 86% | 93% (13 of 14); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 2); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 100% (7 of 7); on the table 100% | 70% (7 of 10); on the table 70% | 82% (14 of 17); on the table 82% |
| Magic missiles tried each own turn | 50%+ | - | 83% (15 of 18) | 83% (15 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 75% (9 of 12) | 75% (9 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 40% (2400 of 6000) | 52% (3104 of 5999) | 46% (5504 of 11999) |
|   infantry points that never fought | lower | 84% (1123 of 1332) | 93% (774 of 834) | 88% (1897 of 2166) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (14 of 20) | 53% (9 of 17) | 62% (23 of 37) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3334 of 5135) | 48% (2208 of 4600) | 57% (5542 of 9735) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (100%) | 1.0 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.0 | 1.7 | 5.0 | 0.0 | 2.0 |
| not cast | 5.7 | 2.0 | 0.3 | 1.0 | 2.0 | 26.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 1.0 (100%) | 2.0 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.7 (100%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.0 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 52% (39 of 75) | 62% (23 of 37) | 55% (62 of 112) |
|   cavalry | 40% (4 of 10) | 75% (6 of 8) | 56% (10 of 18) |
|   character | 40% (4 of 10) | 0% (0 of 11) | 19% (4 of 21) |
|   chariot | 50% (3 of 6) | - | 50% (3 of 6) |
|   infantry | 60% (18 of 30) | 94% (17 of 18) | 73% (35 of 48) |
|   monster | 43% (3 of 7) | - | 43% (3 of 7) |
|   war machine | 58% (7 of 12) | - | 58% (7 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (25%) | 0.7 (14%) | 3.7 (22%) |
| CHARGED: it charged | 1.3 (11%) | 2.0 (43%) | 3.3 (20%) |
| IN COMBAT: it fought this turn or the last | 2.0 (17%) | 0.0 (0%) | 2.0 (12%) |
| MOVED: a war machine that moved | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 2.3 (19%) | 0.7 (14%) | 3.0 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (8%) | 0.3 (7%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (14%) | 1.0 (21%) | 2.7 (16%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 1.0 | 73% | 6.6 pts | 24 pts |
| character | 2.3 | 0.3 | 86% | 2.7 pts | 6 pts |
| chariot | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 18.3 | 4.0 | 84% | 5.9 pts | 108 pts |
| monster | 1.0 | 0.3 | 67% | 16.3 pts | 16 pts |
| war machine | 2.3 | 0.7 | 86% | 5.4 pts | 12 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 8.3 | 5.7 |
| Charges that made contact a game | 2.7 | 5.7 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 1.50 declared, 1.00 contact (2 units) | 0.75 declared, 0.50 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.36 contact (22 units) | 0.88 declared, 0.60 contact (25 units) | 0.66 declared, 0.49 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 50% (1 of 2) | 100% (2 of 2) | 57% (4 of 7) |
| Character in a unit | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character on its own | 100% (1 of 1) | 50% (1 of 2) | 33% (3 of 9) | 42% (5 of 12) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 83% (5 of 6) | 100% (2 of 2) | - | 88% (7 of 8) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (7 of 7); on the table 100% | - | 24% | 57% (4 of 7) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 64% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | - | - | 31% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 75% (3 of 4); on the table 75% | - | 33% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 67% (4 of 6); on the table 67% | 83% (15 of 18) | 61% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p33, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (5) | 100% (4) | 69% (9) |
| ...free all their last turn and able to turn (per game) | 1.33 | 1.00 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 1.00 | 2.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: nw22-19bea9b-p33

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 83% (5 of 6) | 32% (7 of 22) |
| Strategy | Shoot objectives carried out (shot that target) | 21% (4 of 19) | 0% (0 of 10) |
| Strategy | Support requests answered (helper made contact too) | - | 75% (3 of 4) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 0% (0 of 7) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 100% (7 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 80.3 | 0.0 |
| Movement | Fights charged into per game | 2.7 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 5 of 11, net +6 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 5, net +30 | 0 of 11 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 5, net +63 | 2 of 11, net +129 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 5 | 2 of 11, net +200 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.7 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 66% (25 of 38) | 62% (15 of 24) |
| Shooting | Points destroyed by shooting units | 0.0 | 24.0 |
| Shooting | War machine shots | 2.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (2 of 7) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 2.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 12% (1 of 8) |
| Magic | Wounds caused by magic missiles | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 25.0 | 26.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 0.0 / 0.0 | 3.0 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 135.3 | 325.0 |
| Combat | Points run down | 0.0 | 26.7 |
| Combat | Net points per charged fight, damage counted | +40 | +86 |
| Combat | Net per 100 charger points, damage counted | +13.8 | +27.4 |
| Combat | First round won (charged fights) | 88% | 62% |
| Combat | Net points per charged fight | +44 | +88 |
| Combat | Net points per supported fight / lone fight | - / +44 | +100 / +84 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 8 | 5 of 13 |
| Game | Points lost | 524.0 | 160.3 |
| Game | VP from objectives | 493.3 | 690.0 |
| Game | Lone holders (player turns) | 3.0 | 1.5 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -560 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 684
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p33

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +38.3 | 0.0 | 0.0 |
| ARMY TABLE | 21.0 | -169.9 | 0.0 | 162.0 | 22.3 | +199.3 | 0.0 | 130.7 |
| ASSAILMENT BY POINTS | - | - | - | - | 1.3 | +4.5 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 0.3 | +0.9 | 0.0 | 0.0 | 1.7 | +52.1 | 0.0 | 23.3 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +5.4 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -12.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 2.3 | +44.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -55.0 | 45.0 | 0.0 |
| CAST JOB | 0.7 | +4.3 | 0.0 | 0.0 | 2.7 | +26.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +103.3 | 0.0 | 80.0 |
| CHAFF PASSED | 2.0 | -1.2 | 0.0 | 24.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +29.5 | 0.0 | 119.3 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.3 | +4.1 | 0.0 | 0.0 | 0.7 | -2.9 | 90.0 | 0.0 |
| CHARGE LOSSES | 14.0 | -474.8 | 0.0 | 307.0 | 12.3 | -257.0 | 0.0 | 66.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 37.0 | 0.0 | 4.3 | +0.0 | 450.3 | 0.0 |
| CLEAR LANE AHEAD | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.0 | +0.0 | 0.0 | 0.0 | 25.3 | +0.0 | 0.0 | 126.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 18.0 | -740.0 | 0.0 | 91.7 | 8.0 | -528.8 | 0.0 | 20.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -12.3 | 90.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -35.2 | 0.0 | 0.0 | 6.7 | +23.0 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -75.7 | 90.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.2 | 27.7 | 0.0 |
| EXACT ROUND | 2.0 | +21.2 | 68.3 | 26.7 | 6.7 | +33.1 | 417.7 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 80.3 | 0.0 | 6.7 | +24.9 | 434.0 | 16.7 |
| FALLBACK BY WORTH | - | - | - | - | 0.7 | +0.0 | 0.0 | 40.0 |
| FALLS SHORT | - | - | - | - | 19.7 | +291.0 | 0.0 | 84.0 |
| FEATURE BUFFS | 2.7 | +64.5 | 0.0 | 0.0 | 1.0 | +23.9 | 0.0 | 22.0 |
| FIGHT TO THE END | 0.7 | +66.7 | 0.0 | 0.0 | 0.7 | +1.4 | 0.0 | 0.0 |
| FIVE ACTION | 83.0 | +5282.5 | 245.3 | 929.7 | 94.0 | +5366.9 | 617.7 | 404.7 |
| FLANK NOT WEIGHED | 13.0 | +0.0 | 0.0 | 208.3 | 4.3 | +0.0 | 0.0 | 71.7 |
| FOLLOW UP WEIGHED | 0.7 | +22.8 | 0.0 | 0.0 | 1.7 | +161.9 | 0.0 | 15.0 |
| FOUR ROUNDS | 2.7 | +194.5 | 110.3 | 26.7 | 8.3 | +315.6 | 535.3 | 16.7 |
| FREED FROM HIS FIGHT | 13.0 | +0.0 | 0.0 | 300.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -6.3 | 0.0 | 0.0 | 0.7 | -23.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -1.2 | 0.0 | 0.0 | 1.0 | -5.6 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -0.3 | 23.3 | 0.0 | 1.0 | -2.1 | 58.3 | 16.7 |
| GOAL WALK | 11.7 | +929.2 | 0.0 | 116.7 | 3.3 | +299.3 | 0.0 | 0.0 |
| GUN MASK | 0.7 | -4.1 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.7 | +0.5 | 0.0 | 0.0 | 3.0 | -5.0 | 24.0 | 16.7 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 10.0 | +0.0 | 0.0 | 116.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 30.0 | 26.7 | 2.3 | +0.0 | 0.0 | 16.7 |
| HELPER UNSEEN | 0.7 | +0.0 | 30.0 | 26.7 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 11.7 | +0.0 | 0.0 | 307.0 | 6.7 | +0.0 | 0.0 | 66.7 |
| HIS CHARGE DENIED | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 9.0 | +0.0 | 0.0 | 102.3 | 12.7 | +0.0 | 0.0 | 22.0 |
| HIS LEGAL MOVES | 11.7 | +0.0 | 0.0 | 48.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -26.8 | 0.0 | 48.0 | 5.7 | -80.3 | 0.0 | 66.7 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 53.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 16.0 | +0.0 | 0.0 | 48.0 | 10.7 | +0.0 | 0.0 | 23.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 32.0 | +231.7 | 0.0 | 567.0 | 40.3 | +945.9 | 0.0 | 113.3 |
| HIS SHOTS BY HIS RUN | 21.3 | +157.4 | 0.0 | 281.3 | 35.3 | +548.4 | 0.0 | 204.0 |
| HIS TURN DENIED | 0.3 | +1.0 | 0.0 | 0.0 | 3.0 | +80.3 | 175.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 132.0 | 15.0 | +0.0 | 0.0 | 108.0 |
| HOLDER ASSIGNMENT | 9.7 | +717.3 | 0.0 | 93.7 | 9.7 | +663.6 | 0.0 | 64.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -81.1 | 95.3 | 26.7 | 6.3 | -220.5 | 535.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +26.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 18.3 | -193.4 | 0.0 | 40.0 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 3.3 | +192.1 | 132.0 | 16.7 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.3 | 0.0 | 0.0 | 1.0 | +42.4 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.3 | +0.0 | 30.0 | 373.0 | 6.0 | +0.0 | 187.0 | 150.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +3.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.6 | 0.0 | 0.0 | 4.7 | +7.4 | 156.0 | 16.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -99.5 | 0.0 | 50.0 |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +1.8 | 0.0 | 27.7 | 2.3 | +21.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 42.0 | 0.7 | +15.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +120.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +61.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +14.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +23.3 | 0.0 | 27.7 | 6.0 | +109.9 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +240.1 | 0.0 | 0.0 | 4.3 | +151.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +60.2 | 0.0 | 0.0 | 5.0 | +43.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +49.3 | 0.0 | 0.0 | 5.0 | +31.8 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 22.0 | 22.0 |
| MOVE TO CHARGE COMPUTED | 11.7 | +571.2 | 0.0 | 241.7 | 11.3 | +899.5 | 0.0 | 46.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 11.3 | +446.5 | 0.0 | 166.3 | 7.0 | +272.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 7.3 | +364.2 | 0.0 | 241.7 | 10.0 | +738.4 | 24.0 | 23.3 |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 2.7 | +71.1 | 42.0 | 58.3 | 4.0 | +121.8 | 333.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -86.4 | 95.3 | 26.7 | 6.7 | -233.7 | 445.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 25.0 |
| NOT WORTH A CAST | 0.7 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.0 | -327.7 | 23.3 | 53.3 | 2.0 | -45.1 | 24.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -112.4 | 0.0 | 150.0 | 5.3 | -101.9 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +0.2 | 15.0 | 26.7 | 2.7 | +40.6 | 90.0 | 16.7 |
| ONE OBJECTIVE FORMULA | 5.3 | -6.4 | 0.0 | 93.7 | 4.7 | -164.0 | 0.0 | 42.0 |
| ONE PROMISE A TARGET | 1.7 | -68.4 | 0.0 | 0.0 | 2.7 | -100.6 | 24.0 | 23.3 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 0.7 | +31.8 | 42.0 | 0.0 | 2.7 | +82.7 | 309.0 | 0.0 |
| OVERRUNS AWAY | 2.0 | +14.8 | 110.3 | 26.7 | 2.0 | +13.3 | 45.0 | 0.0 |
| OWN CAST FIRST | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +7.2 | 0.0 | 0.0 | 0.7 | -0.2 | 0.0 | 0.0 |
| PLAN RESULT | 38.0 | +215.6 | 70.0 | 844.7 | 47.7 | +682.7 | 401.3 | 283.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 15.7 | -373.2 | 0.0 | 183.3 | 7.7 | -163.5 | 0.0 | 23.3 |
| PROMISE KNOWS THE FIGHT | 2.3 | +0.0 | 0.0 | 241.7 | 3.0 | -5.5 | 0.0 | 23.3 |
| PROMISE READS THE TABLE | 1.0 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.9 | 25.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 21.0 | +2168.9 | 0.0 | 106.7 | 23.3 | +2568.8 | 75.7 | 156.7 |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +38.6 | 0.0 | 26.7 | 3.3 | +301.8 | 0.0 | 62.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 26.7 | 2.0 | +0.0 | 0.0 | 15.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +38.7 | 58.3 | 0.0 |
| REFORMS TO MEET IT | 3.7 | -127.2 | 0.0 | 0.0 | 3.0 | -51.0 | 0.0 | 23.3 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +22.9 | 0.0 | 26.7 | - | - | - | - |
| RISK BY ARC | 2.7 | +70.5 | 110.3 | 26.7 | 7.0 | -30.2 | 403.3 | 16.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 4.0 | -46.4 | 211.3 | 16.7 |
| RUN DOWN | - | - | - | - | 6.0 | -32.3 | 300.3 | 16.7 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -47.5 | 0.0 | 30.0 |
| SEARCH SPOT | 0.3 | +3.5 | 0.0 | 0.0 | 0.3 | +4.6 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +0.3 | 23.3 | 0.0 | 1.0 | +160.8 | 129.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | +55.9 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -1.3 | 0.0 | 53.3 | 1.3 | -61.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.3 | +34.9 | 0.0 | 53.3 | 5.3 | +66.5 | 0.0 | 46.7 |
| SET UP TOGETHER | 1.0 | +1.8 | 0.0 | 27.7 | 2.3 | +21.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 72.7 | 4.0 | +0.0 | 0.0 | 20.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +49.6 | 20.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -4.0 | 58.3 | 0.0 |
| SHOT RISK POINTS | 11.3 | -128.3 | 0.0 | 159.7 | 30.0 | -127.2 | 0.0 | 180.7 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.7 | +291.5 | 0.0 | 114.7 | 8.3 | +53.2 | 0.0 | 84.0 |
| SPELL WORTH | 1.3 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -3.7 | 0.0 | 0.0 | 1.0 | -21.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 100.3 | 7.7 | +0.0 | 0.0 | 15.0 |
| STAND AND SHOOT | 0.3 | -0.6 | 22.0 | 0.0 | 1.7 | -26.2 | 182.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 29.0 | +0.0 | 135.0 | 387.0 | 19.3 | +0.0 | 82.3 | 106.7 |
| STAY WORTH | 8.0 | +28.5 | 50.0 | 27.7 | 5.7 | +24.0 | 24.0 | 22.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +5.8 | 26.7 | 15.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.7 | -9.2 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.0 | +12.9 | 0.0 | 0.0 | 2.3 | +118.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 15.0 | 26.7 | 0.3 | +0.0 | 42.0 | 0.0 |
| SUPPORT WORKED OUT | 1.0 | +12.9 | 0.0 | 0.0 | 2.3 | +118.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +2.9 | 0.0 | 0.0 | 1.7 | +12.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 26.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.0 | -0.6 | 15.0 | 26.7 | 3.0 | +37.7 | 218.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 22.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.0 | +0.0 | 0.0 | 428.0 | 46.3 | +0.0 | 0.0 | 234.0 |
| TIED UP BY THE SUM | 1.0 | +105.2 | 65.3 | 0.0 | 2.7 | +284.4 | 285.0 | 0.0 |
| TIME ON OUR SIDE | 36.0 | +518.3 | 0.0 | 616.3 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| WAITS AGAIN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 0.0 | 50.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -7.1 | 30.0 | 0.0 | 0.7 | -8.4 | 0.0 | 0.0 |
| WHO FIGHTS | 1.0 | -5.8 | 30.0 | 26.7 | 1.0 | +22.9 | 42.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | -2.1 | 15.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.7 | -310.7 | 0.0 | 200.7 | 0.7 | -28.1 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.7 | +44.4 | 90.0 | 16.7 |
| WHOLE FIGHT REACTION | 3.0 | +329.7 | 0.0 | 141.3 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 6.0 | +73.2 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p33

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 130 | 130 | 96 | 32.00 | +973 | +10.1 |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +3256 | +60.3 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| HIS SHOT LIST | 217 | 207 | 33 | 11.00 | +203 | +6.1 |
| HIS SHOTS BY HIS RUN | 170 | 166 | 33 | 11.00 | +144 | +4.4 |
| FIVE ACTION | 531 | 504 | 32 | 10.67 | +1390 | +43.4 |
| PROMISE BY ITS OWN SUM | 70 | 70 | 27 | 9.00 | -1610 | -59.6 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -1119 | -46.6 |
| MOVE TO CHARGE COMPUTED | 69 | 60 | 23 | 7.67 | +514 | +22.4 |
| QUARTER ODDS | 133 | 127 | 21 | 7.00 | +1271 | +60.5 |
| NEXT CHARGE BY LIST | 52 | 50 | 20 | 6.67 | +364 | +18.2 |
| DEPLOY BY FIGURES | 42 | 42 | 17 | 5.67 | +216 | +12.7 |
| MEETS IN TIME | 25 | 25 | 15 | 5.00 | +893 | +59.5 |
| NO CHAFF EDGES | 20 | 19 | 15 | 5.00 | +337 | +22.4 |
| FOUR ROUNDS | 33 | 30 | 14 | 4.67 | +689 | +49.2 |
| ONE PROMISE A TARGET | 13 | 13 | 13 | 4.33 | -507 | -39.0 |
| SHOT RISK POINTS | 124 | 123 | 13 | 4.33 | +62 | +4.8 |
| MAX FOR POSITIONING | 24 | 24 | 11 | 3.67 | +58 | +5.3 |
| COVER ONCE | 78 | 49 | 10 | 3.33 | +170 | +17.0 |
| JOINT CHARGE NOW | 10 | 10 | 10 | 3.33 | +576 | +57.6 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SET UP BY THE SET | 26 | 24 | 10 | 3.33 | +190 | +19.0 |
| CLEAR LANE AHEAD | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| GOAL WALK | 45 | 45 | 9 | 3.00 | +615 | +68.3 |
| TIED UP BY THE SUM | 11 | 9 | 9 | 3.00 | +308 | +34.2 |
| CAST JOB | 10 | 10 | 8 | 2.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 55 | 43 | 8 | 2.67 | +39 | +4.9 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CHAFF PASSED | 7 | 7 | 7 | 2.33 | -5 | -0.7 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +554 | +79.1 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +236 | +33.7 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 18 | 18 | 6 | 2.00 | -138 | -22.9 |
| BACKS UP THE FIGHT | 6 | 6 | 5 | 1.67 | +10 | +2.0 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 5 | 5 | 5 | 1.67 | +374 | +74.8 |
| OPENS UP IN FULL | 10 | 9 | 5 | 1.67 | +101 | +20.2 |
| RISK BY ARC | 29 | 26 | 5 | 1.67 | +150 | +30.0 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 5 | 1.67 | +0 | +0.1 |
| TIME ON OUR SIDE | 108 | 79 | 5 | 1.67 | +19 | +3.8 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +13 | +3.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 79 | 79 | 4 | 1.33 | +112 | +28.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +483 | +120.8 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| NEARER NOT NEEDED | 55 | 52 | 3 | 1.00 | +80 | +26.5 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +21 | +7.0 |
| SURE REACH TOGETHER | 6 | 5 | 3 | 1.00 | +8 | +2.6 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +88 | +44.2 |
| EXACT ROUND | 26 | 24 | 2 | 0.67 | +24 | +11.9 |
| HIS TURN DENIED | 10 | 9 | 2 | 0.67 | +58 | +28.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MANOEUVRE | 7 | 7 | 2 | 0.67 | +47 | +23.4 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +35 | +17.7 |
| MISSILES IN THE MOVE | 23 | 18 | 2 | 0.67 | +43 | +21.4 |
| NO DOUBLE ROUNDS | 27 | 25 | 2 | 0.67 | +85 | +42.7 |
| PROMISE KNOWS THE FIGHT | 16 | 13 | 2 | 0.67 | -16 | -8.2 |
| REDIRECT COUNTER | 14 | 13 | 2 | 0.67 | +119 | +59.5 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +298 | +148.9 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +69 | +34.3 |
| SCOUT BY DROPS | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +24 | +12.2 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 18 | 18 | 2 | 0.67 | +56 | +28.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +115 | +114.8 |
| CANNON PLANNED TARGET | 7 | 7 | 1 | 0.33 | -26 | -26.4 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -165 | -164.9 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -83 | -83.1 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 59 | 48 | 1 | 0.33 | +3 | +3.2 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +362 | +361.9 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -6 | -6.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE FIGHT FORMULA | 36 | 19 | 1 | 0.33 | +17 | +17.1 |
| ONE JOINT FIGURE | 9 | 8 | 1 | 0.33 | +58 | +57.9 |
| OVERRUNS AWAY | 12 | 11 | 1 | 0.33 | +1 | +1.3 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -3 | -2.7 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -5 | -4.8 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -3 | -2.9 |
| ROUNDS AFTER TERROR | 12 | 10 | 1 | 0.33 | +4 | +4.1 |
| RUN DOWN | 18 | 16 | 1 | 0.33 | +4 | +4.1 |
| SHOTS IN THE MOVE | 63 | 37 | 1 | 0.33 | +3 | +3.2 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +17 | +17.4 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -3 | -2.8 |
| THE FIGHT MOVES | 12 | 11 | 1 | 0.33 | +58 | +57.9 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +5 | +5.3 |
| WHOLE FIGHT GAIN | 5 | 4 | 1 | 0.33 | +58 | +57.9 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 115 | 108 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 25 | 22 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 11 | 11 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 52 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 41 | 33 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 11 | 10 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 32 | 29 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 9 | 9 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 55 | 55 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 65 | 61 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 53 | 48 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 27 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 80 | 71 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 93 | 0 | 0.00 | - | - |
| HONEST WORTH | 26 | 23 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 16 | 14 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 10 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 25 | 21 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 30 | 25 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 257 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 20 | 20 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 10 | 6 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 17 | 17 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 43 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 145 | 138 | 0 | 0.00 | - | - |
| STAY WORTH | 41 | 31 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 10 | 7 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 10 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 253 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | not checked | - | - | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 16 | 16 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p33

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 7.33 | 1.67 | 59.6 |
| ARMY TABLE | rule | 3.67 | 2.33 | 33.3 |
| JOB FIRST | gate | 4.00 | 1.33 | 51.8 |
| ONE PROMISE A TARGET | rule | 1.33 | 2.67 | 42.2 |
| CHARGE NOW FIRST | rule | 1.00 | 1.00 | 22.9 |
| NO REASON | gate | 1.67 | - | 43.4 |
| AFTERMATH BAND | gate | 0.33 | 0.33 | 2.4 |
| CHAFF PASSED | rule | 0.33 | 0.33 | 2.3 |
| JOINT CHARGE NOW | rule | - | 0.67 | 47.7 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 8.2 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 26.4 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 164.9 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 83.1 |
| FOLLOW UP WEIGHED | rule | - | 0.33 | 3.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 30.0 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 8.5 |
| MARCH OF THE TABLE | rule | 0.33 | - | 6.0 |
| OWN CAST FIRST | rule | 0.33 | - | 2.7 |
| PATHS CROSS | rule | - | 0.33 | 6.0 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 4.8 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 2.9 |
| RULE SWITCHED OFF | gate | - | 0.33 | 67.6 |
| SUPPORT NARROWED | rule | 0.33 | - | 2.8 |

### Plans: nw22-19bea9b-p33

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 88% | 262 | 103 | 39% |
| Mine | move | 30.0 | 96% | 1656 | 0 | 0% |
| Mine | shoot | 5.3 | 44% | 299 | 113 | 38% |
| Opponent | charge | 7.7 | 57% | 1183 | 586 | 50% |
| Opponent | join | 2.3 | 100% | 91 | 0 | 0% |
| Opponent | move | 34.3 | 98% | 1278 | 0 | 0% |
| Opponent | shoot | 1.7 | 60% | 90 | 96 | 107% |
| Opponent | support | 1.7 | 60% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p33

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p33

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 2 | 28 (2) | 28 | 0 | 100 | 0% | 2.0 | 28 (2) | - | - | - | 28 (2) |
| Mine | Character | 8 | 14 (8) | 14 | 0 | 15 | 12% | 3.0 | 18 (5) | 7 (3) | - | 17 (7) | 0 (1) |
| Mine | Clean-up | 1 | 75 (1) | 75 | 0 | 0 | 0% | 3.0 | 75 (1) | - | - | 75 (1) | - |
| Mine | Fast Hammer | 4 | 26 (4) | 0 | 26 | 0 | 0% | 2.8 | - | 26 (4) | - | 121 (1) | 0 (3) |
| Mine | Hammer | 4 | 0 (4) | 0 | 0 | 39 | 50% | 1.0 | 0 (1) | 0 (2) | 0 (1) | 0 (2) | 0 (2) |
| Mine | Shooter | 6 | 36 (6) | 0 | 36 | 74 | 0% | 1.7 | 95 (1) | 8 (3) | 58 (2) | 58 (4) | 0 (2) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 42 (8) | 0 | 42 | 33 | 75% | 3.0 | 85 (4) | 0 (4) | - | 121 (3) | 0 (5) |
| Opponent | Character | 9 | 44 (9) | 44 | 0 | 2 | 22% | 3.7 | 58 (5) | 27 (3) | 0 (1) | 46 (5) | 38 (4) |
| Opponent | Clean-up | 2 | 20 (2) | 20 | 0 | 0 | 100% | - | 31 (1) | 0 (1) | - | 20 (2) | - |
| Opponent | Fast Hammer | 10 | 20 (10) | 20 | 0 | 12 | 30% | 3.0 | 0 (3) | 43 (4) | 29 (3) | 17 (6) | 22 (4) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | Holder | 3 | 147 (3) | 38 | 109 | 31 | 0% | 2.3 | - | 175 (2) | 100 (1) | 147 (3) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 5 | 13 (5) | 13 | 0 | 0 | 40% | 1.3 | 16 (3) | 0 (1) | 0 (1) | 20 (2) | 0 (3) |

### Charged fights: nw22-19bea9b-p33

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 75 | 45 | 2.0 | 1.0 | 22 | 0 | +22 | 1 of 2 | 1 of 2 | - | +22 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 45 | 2.0 | 1.0 | 22 | 0 | +22 | 0 of 2 | 2 of 2 | - | +22 |
| Mine | Lizardmen | 1 | 0 | 266 | 4.0 | 1.0 | 66 | 0 | +66 | 0 of 4 | 4 of 4 | - | +66 |
| **Mine** | all armies | 3 | 25 | 119 | 2.7 | 1.0 | 44 | 0 | +44 | 1 of 8 | 7 of 8 | - | +44 |
| Opponent | Tomb Kings of Khemri | 1 | 72 | 709 | 5.0 | 1.2 | 142 | 0 | +142 | 0 of 5 | 4 of 5 | +175 | +134 |
| Opponent | Vampire Counts | 2 | 40 | 240 | 4.0 | 1.4 | 60 | 6 | +54 | 5 of 8 | 4 of 8 | +63 | +51 |
| **Opponent** | all armies | 3 | 51 | 397 | 4.3 | 1.3 | 92 | 4 | +88 | 5 of 13 | 8 of 13 | +100 | +84 |

### Effective charges: nw22-19bea9b-p33

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 2 | 0 | 0 | 1 (net +45) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 2 (net +22) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 0 | 2 (net +63) | 0 | 2 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net +310) | 2 (net +129) | 0 | 2 | 0% (0 of 3) |
| Opponent | Vampire Counts | 8 | 5 (net +6) | 0 | 0 | 1 (net +0) | 0 | 2 (net +200) | 0 | 0% (0 of 8) |

### Charged fights, damage counted: nw22-19bea9b-p33

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 3 | 73 | 45 | +30 | 30 | 0 | +30 | +40.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 405 | 63 | +63 | 103 | 58 | +45 | +11.2 |
| Mine | No odds | 3 | 432 | 204 | +47 | 47 | 0 | +47 | +10.8 |
| Mine | All fights | 8 | 291 | 109 | +44 | 55 | 14 | +40 | +13.8 |
| Opponent | Long shot (under 50%) | 5 | 181 | 420 | +6 | 35 | 47 | -11 | -6.3 |
| Opponent | 76-89% | 2 | 190 | 134 | +155 | 155 | 0 | +155 | +81.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 426 | 200 | +200 | 200 | 0 | +200 | +47.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 656 | 129 | +129 | 129 | 0 | +129 | +19.7 |
| Opponent | No odds | 2 | 313 | 158 | +70 | 104 | 0 | +104 | +33.1 |
| Opponent | All fights | 13 | 314 | 257 | +88 | 104 | 18 | +86 | +27.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p33 | move | 27 | 7 (26%) | 3 (11%) | 6 (22%) | 14 (52%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

# Doctrine scorecard: nw22-19bea9b-p15

### Scorecard: nw22-19bea9b-p15

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 1 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 12 | - | 0 | 1 | 0 | 0 | 0 | 250 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 5 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 473 |
| L0512 | 2 | 1 | Opponent | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 330 |
| **Average** | | | Mine | 50% | 1.0 | 4.0 | 1.3 | 2.7 | 0.0 | 0.0 | 0.0 | 179.3 |
| **Average** | | | Opponent | 0% | 12.0 | 4.0 | 0.3 | 2.3 | 0.0 | 0.0 | 0.0 | 193.3 |

### KPIs: nw22-19bea9b-p15

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 9% (1 of 11) | 0% (0 of 14) | 4% (1 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (6 of 12) | 44% (16 of 36) | 46% (22 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (6 of 10) | 44% (16 of 36) | 48% (22 of 46) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 82% (4907 of 5998) | 86% (5129 of 5998) | 84% (10036 of 11996) |
|   infantry points that never fought | lower | 95% (1359 of 1424) | 91% (1083 of 1187) | 94% (2442 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (18 of 23) | 78% (21 of 27) | 78% (39 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.3 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 81% (4157 of 5120) | 82% (4481 of 5442) | 82% (8638 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (55%) | 3.7 (42%) |
| MARCHED: its unit marched | 1.0 (50%) | 3.0 (45%) | 4.0 (46%) |
| IN COMBAT: engaged in combat | 0.7 (33%) | 0.0 (0%) | 0.7 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (17%) | 0.0 (0%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.0 | 3.0 | 7.3 | 1.0 | 0.7 |
| not cast | 4.0 | 5.0 | 3.0 | 8.7 | 1.0 | 19.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (93%) | 1.7 (56%) | 3.7 (42%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (46%) | 0.3 (33%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (8%) | 0.0 (0%) | 0.7 (22%) | 0.7 (8%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 0.3 (4%) | 0.7 (67%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (75%) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 1.7 a game | 1.5 a game |
| stood (cast and not dispelled) | 50% (2 of 4) | 40% (2 of 5) | 44% (4 of 9) |
| the unit moved after it | 100% (2 of 2) | 100% (2 of 2) | 100% (4 of 4) |
| it charged on its next turn | 50% (1 of 2) | 0% (0 of 2) | 25% (1 of 4) |
| the enemy charged it first | 0% (0 of 2) | 50% (1 of 2) | 25% (1 of 4) |
| it fought by the end of its next turn | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 50% (1 of 2) | 25% (1 of 4) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | 0% (0 of 2) | 25% (1 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (53 of 83) | 72% (47 of 65) | 68% (100 of 148) |
|   cavalry | 42% (5 of 12) | - | 42% (5 of 12) |
|   character | 60% (6 of 10) | 100% (6 of 6) | 75% (12 of 16) |
|   chariot | 58% (14 of 24) | 100% (6 of 6) | 67% (20 of 30) |
|   infantry | 33% (4 of 12) | 48% (11 of 23) | 43% (15 of 35) |
|   monster | - | 67% (4 of 6) | 67% (4 of 6) |
|   war machine | 96% (24 of 25) | 83% (20 of 24) | 90% (44 of 49) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (40%) | 2.3 (39%) | 6.3 (40%) |
| CHARGED: it charged | 0.7 (7%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (11%) | 0.7 (4%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.0 (30%) | 1.3 (22%) | 4.3 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (23%) | 0.0 (0%) | 2.3 (15%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (17%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 4.0 | 1.3 | 75% | 11.8 pts | 47 pts |
| chariot | 6.7 | 9.7 | 40% | 22.1 pts | 148 pts |
| infantry | 6.3 | 1.7 | 74% | 10.6 pts | 67 pts |
| monster | 2.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 14.7 | 13.0 | 50% | 25.0 pts | 367 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 1.0 | 1.3 |
| Charges that made contact a game | 1.3 | 0.7 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.00 declared, 0.00 contact (3 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.19 declared, 0.14 contact (21 units) | 0.17 declared, 0.11 contact (18 units) | 0.18 declared, 0.13 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 100% (7 of 7) | 100% (1 of 1) | - | 100% (8 of 8) |
| Character on its own | - | 83% (5 of 6) | 75% (3 of 4) | 80% (8 of 10) |
| Chariot | - | 100% (5 of 5) | - | 100% (5 of 5) |
| Infantry | 50% (6 of 12) | 100% (3 of 3) | - | 60% (9 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 80% (4 of 5) | - | - | 80% (4 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (3 of 3); on the table 100% | 50% (6 of 12) | 75% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 95% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 58% (7 of 12) | 95% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 28% (5 of 18) | 90% | 67% (6 of 9) | 100% (3 of 3); 10.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 72% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p15, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 67% (2) | 60% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p15

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 80% (4 of 5) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (13 of 33) | 60% (21 of 35) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 38% (3 of 8) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 2.7 | 2.3 |
| Movement | Points that never moved of their own | 179.3 | 193.3 |
| Movement | Fights charged into per game | 1.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +0 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +127 | 1 of 2, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (12 of 29) | 44% (12 of 27) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 8.0 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (5 of 24) | 30% (6 of 20) |
| Shooting | Points destroyed by war machines | 111.0 | 31.7 |
| Magic | Magic missiles cast | 1.3 | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | 56% (5 of 9) |
| Magic | Wounds caused by magic missiles | 2.0 | 4.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 0.0 / 0.0 | 1.3 / 0.3 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 99.7 | 31.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +84 | +7 |
| Combat | Net per 100 charger points, damage counted | +43.8 | +5.1 |
| Combat | First round won (charged fights) | 75% | 100% |
| Combat | Net points per charged fight | +75 | +48 |
| Combat | Net points per supported fight / lone fight | - / +75 | - / +48 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 1 of 2 |
| Game | Points lost | 103.3 | 287.0 |
| Game | VP from objectives | 460.0 | 713.3 |
| Game | Lone holders (player turns) | 1.0 | 12.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -126 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 390
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: nw22-19bea9b-p15

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 23.3 | -67.0 | 0.0 | 40.0 | 18.7 | +52.3 | 0.0 | 30.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 31.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 56.0 | 31.7 | - | - | - | - |
| CANNON PLANNED TARGET | 7.0 | +94.5 | 280.0 | 63.3 | 6.3 | +61.0 | 111.7 | 41.7 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +8.9 | 0.0 | 0.0 | 3.0 | +28.8 | 63.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +3.2 | 0.0 | 0.0 | 0.7 | +7.3 | 0.0 | 30.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +41.3 | 0.0 | 84.7 |
| CHARACTER GUNS | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.3 | -541.8 | 0.0 | 80.0 | 15.0 | -373.8 | 0.0 | 281.3 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 84.7 | 0.0 | - | - | - | - |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.3 | +171.2 | 40.0 | 0.0 | 1.0 | +119.4 | 0.0 | 0.0 |
| COVER ONCE | 6.0 | -207.1 | 0.0 | 0.0 | 7.3 | -874.0 | 0.0 | 84.7 |
| DENIED BY THE FIGHT | 0.3 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +68.3 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 55.0 |
| EVASIVE BY THE ODDS | 0.3 | +2.9 | 34.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +12.6 | 0.0 | 0.0 | 1.0 | +29.8 | 31.7 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 84.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 7.7 | +132.1 | 0.0 | 0.0 | 17.3 | +113.7 | 0.0 | 366.0 |
| FEATURE BUFFS | 1.3 | +3.2 | 0.0 | 0.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 100.3 | +4921.6 | 771.7 | 206.7 | 94.7 | +3751.3 | 318.3 | 574.0 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 84.7 |
| FOLLOW UP WEIGHED | 1.0 | +99.3 | 0.0 | 0.0 | 0.3 | +9.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +118.3 | 99.7 | 0.0 | 1.0 | +58.3 | 31.7 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -3.4 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -13.6 | 31.7 | 0.0 |
| GOAL WALK | 17.3 | +1589.7 | 0.0 | 0.0 | 5.0 | +255.3 | 0.0 | 0.0 |
| GUN FIGURES | 3.3 | +3.5 | 84.3 | 0.0 | 1.3 | +0.0 | 40.0 | 0.0 |
| GUN MASK | 0.7 | +20.7 | 0.0 | 0.0 | 2.7 | -11.9 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 0.7 | +1.2 | 0.0 | 0.0 | 0.7 | +0.3 | 31.7 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 169.3 |
| HIS CHARGE LIST | 7.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -51.5 | 0.0 | 0.0 | 2.0 | -44.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 6.3 | +0.0 | 0.0 | 80.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 50.7 | +4168.6 | 0.0 | 80.0 | 49.3 | +3359.6 | 0.0 | 222.0 |
| HIS SHOTS BY HIS RUN | 37.7 | +779.8 | 0.0 | 80.0 | 34.3 | +771.9 | 0.0 | 281.3 |
| HIS TURN DENIED | 0.3 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 12.7 | +0.0 | 0.0 | 80.0 | 14.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.0 | +590.8 | 0.0 | 40.0 | 9.7 | +1009.9 | 0.0 | 34.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -37.4 | 99.7 | 0.0 | 1.0 | -24.2 | 31.7 | 0.0 |
| HUNT IN PAIRS | 2.0 | +226.1 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 4.7 | -84.1 | 0.0 | 0.0 | 15.0 | -264.0 | 0.0 | 15.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +85.7 | 0.0 | 0.0 | - | - | - | - |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 84.7 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -1.3 | 15.0 | 0.0 | 0.7 | -0.3 | 31.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +1.7 | 0.0 | 0.0 |
| MANOEUVRE | 2.7 | -6.7 | 0.0 | 0.0 | 3.3 | -21.0 | 0.0 | 140.7 |
| MARCH BY THE SUM | 0.3 | +4.7 | 0.0 | 0.0 | 0.3 | +8.2 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +100.7 | 0.0 | 0.0 | 1.3 | +53.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +4.8 | 0.0 | 0.0 | 0.7 | +4.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -27.2 | 0.0 | 0.0 | 0.7 | +26.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.7 | +47.4 | 0.0 | 0.0 | 1.3 | +6.3 | 0.0 | 56.0 |
| MEETS IN TIME | 5.3 | +153.3 | 0.0 | 0.0 | 2.3 | +27.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +91.9 | 0.0 | 0.0 | 9.0 | +137.9 | 0.0 | 112.0 |
| MISSILES NEXT TURN | 2.7 | +50.6 | 0.0 | 0.0 | 11.7 | +99.9 | 0.0 | 112.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.7 | +97.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.0 | -96.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.3 | +63.9 | 0.0 | 0.0 | 2.0 | +47.4 | 0.0 | 0.0 |
| NEAR WALKS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.3 | +390.7 | 0.0 | 0.0 | 9.3 | +408.6 | 0.0 | 140.7 |
| NEXT CHARGE BY LIST | 1.3 | +63.9 | 0.0 | 0.0 | 2.0 | +81.1 | 0.0 | 0.0 |
| NO CHAFF EDGES | 0.7 | +4.9 | 0.0 | 0.0 | 1.3 | +20.0 | 31.7 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -61.5 | 99.7 | 0.0 | 0.3 | -13.8 | 0.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -158.0 | 0.0 | 0.0 | 4.0 | -101.9 | 0.0 | 84.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.0 | -58.9 | 0.0 | 0.0 | 2.7 | -62.5 | 0.0 | 56.0 |
| ONE OBJECTIVE FORMULA | 3.3 | +3.9 | 0.0 | 40.0 | 4.3 | -144.1 | 0.0 | 34.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -11.0 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | - | - | - | - | 0.7 | +7.2 | 31.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +12.4 | 0.0 | 0.0 | 0.7 | +1.6 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | -4.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 45.7 | +495.7 | 287.3 | 206.7 | 43.3 | +541.6 | 160.0 | 337.0 |
| PROMISE BY ITS OWN SUM | 4.3 | -128.5 | 0.0 | 0.0 | 2.7 | -12.8 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | -2.9 | 0.0 | 0.0 |
| QUARTER ODDS | 20.0 | +1572.2 | 0.0 | 80.0 | 16.0 | +1409.1 | 80.0 | 152.7 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +28.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 30.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 15.0 |
| RESERVE FALL BACK | 0.7 | +5.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | +39.0 | 15.0 | 0.0 | 1.0 | -43.0 | 31.7 | 0.0 |
| RUN DOWN | 0.3 | -1.2 | 0.0 | 0.0 | 0.3 | -2.6 | 0.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -64.0 | 0.0 | 0.0 | 0.7 | -33.9 | 0.0 | 30.0 |
| SEARCH SPOT | 0.7 | +21.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.0 | -294.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.0 | +147.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.7 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +32.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.0 | +0.0 | 0.0 | 63.3 | 13.0 | +0.0 | 0.0 | 91.3 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +86.1 | 0.0 | 0.0 | 3.3 | +95.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -9.9 | 31.7 | 0.0 |
| SHOT RISK POINTS | 28.3 | +351.1 | 0.0 | 80.0 | 22.7 | -121.3 | 0.0 | 281.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +491.5 | 0.0 | 63.3 | 17.0 | +414.5 | 0.0 | 131.3 |
| SPELL SETS UP CHARGE | 0.3 | +32.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +18.1 | 0.0 | 0.0 | 2.0 | +29.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -5.1 | 0.0 | 0.0 | 0.7 | +6.1 | 31.7 | 0.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 40.0 | 2.7 | +0.0 | 0.0 | 84.7 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 55.0 | +0.0 | 672.0 | 126.7 | 35.0 | +0.0 | 286.7 | 432.0 |
| STAY WORTH | 27.0 | +73.0 | 560.0 | 95.0 | 29.3 | -160.9 | 286.7 | 180.0 |
| STRONG ENOUGH TO HOLD | 0.7 | -46.2 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.3 | +54.0 | 0.0 | 0.0 | 2.0 | +16.3 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +54.0 | 0.0 | 0.0 | 2.0 | +16.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.7 | +0.3 | 15.0 | 0.0 | 0.3 | +17.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 40.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 40.0 | 3.3 | +0.0 | 0.0 | 56.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.3 | +0.0 | 0.0 | 103.3 | 47.7 | +0.0 | 0.0 | 247.0 |
| TIED UP BY THE SUM | 0.3 | +29.4 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 40.7 | +437.0 | 112.0 | 0.0 | 14.0 | +180.7 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 0.3 | -12.0 | 0.0 | 0.0 | 0.7 | -14.7 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.0 | +82.3 | 0.0 | 31.7 | 0.3 | +9.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.0 | +68.3 | 0.0 | 0.0 | 4.7 | +88.4 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p15

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 300 | 295 | 99 | 33.00 | +2143 | +21.6 |
| ARMY TABLE | 126 | 126 | 89 | 29.67 | +488 | +5.5 |
| HIS SHOTS BY HIS RUN | 216 | 212 | 55 | 18.33 | +773 | +14.1 |
| HOLDER ASSIGNMENT | 50 | 50 | 48 | 16.00 | +3805 | +79.3 |
| SHOT RISK POINTS | 153 | 153 | 28 | 9.33 | +573 | +20.5 |
| GOAL WALK | 67 | 67 | 26 | 8.67 | +1422 | +54.7 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -780 | -31.2 |
| TIME ON OUR SIDE | 164 | 154 | 22 | 7.33 | +74 | +3.3 |
| DEPLOY BY FIGURES | 45 | 45 | 21 | 7.00 | +420 | +20.0 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| QUARTER ODDS | 108 | 107 | 14 | 4.67 | +857 | +61.2 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 13 | 4.33 | +188 | +14.4 |
| MEETS IN TIME | 23 | 23 | 12 | 4.00 | +398 | +33.1 |
| IDLE COST | 59 | 44 | 11 | 3.67 | +99 | +9.0 |
| LEGAL CHARGES ONLY | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| FIVE ACTION | 585 | 580 | 8 | 2.67 | +353 | +44.1 |
| PROMISE BY ITS OWN SUM | 21 | 21 | 8 | 2.67 | -424 | -53.0 |
| CAST JOB | 12 | 12 | 7 | 2.33 | +26 | +3.7 |
| NEXT CHARGE BY LIST | 10 | 10 | 6 | 2.00 | +191 | +31.9 |
| CHARGE LOSSES | 97 | 97 | 5 | 1.67 | +242 | +48.5 |
| FOUR ROUNDS | 8 | 8 | 5 | 1.67 | +96 | +19.1 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MARCH CHECK | 8 | 7 | 5 | 1.67 | +78 | +15.7 |
| NO CHAFF EDGES | 6 | 6 | 5 | 1.67 | +63 | +12.6 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +327 | +81.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +257 | +64.3 |
| MANOEUVRE | 18 | 18 | 4 | 1.33 | +43 | +10.8 |
| MOVE TO CHARGE COMPUTED | 10 | 10 | 4 | 1.33 | +142 | +35.4 |
| WOUNDS ON THE RANKS | 26 | 26 | 4 | 1.33 | +71 | +17.8 |
| COVER ONCE | 40 | 27 | 3 | 1.00 | +1 | +0.3 |
| FALLS SHORT | 75 | 65 | 3 | 1.00 | +49 | +16.2 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -29 | -9.6 |
| MISSILES IN THE MOVE | 33 | 24 | 3 | 1.00 | +122 | +40.8 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS AFTER THE MOVES | 23 | 23 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 17 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 40 | 40 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 6 | 6 | 2 | 0.67 | +27 | +13.7 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 10 | 10 | 2 | 0.67 | +59 | +29.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +39 | +19.4 |
| MAX FOR POSITIONING | 9 | 8 | 2 | 0.67 | +7 | +3.4 |
| ONE OBJECTIVE FORMULA | 23 | 17 | 2 | 0.67 | +216 | +107.9 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -33 | -16.5 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -13 | -6.3 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 2 | 0.67 | -9 | -4.4 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +15 | +7.6 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +64 | +31.8 |
| SHOTS IN THE MOVE | 99 | 76 | 2 | 0.67 | +38 | +18.9 |
| SUPPORT ADDS | 10 | 10 | 2 | 0.67 | +68 | +33.9 |
| SUPPORT WORKED OUT | 10 | 10 | 2 | 0.67 | +68 | +33.9 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +124 | +124.0 |
| EVASIVE BY THE ODDS | 1 | 1 | 1 | 0.33 | +9 | +8.9 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 17 | 17 | 1 | 0.33 | +0 | +0.0 |
| HUNT IN PAIRS | 6 | 3 | 1 | 0.33 | +15 | +14.9 |
| OPENS UP IN FULL | 2 | 2 | 1 | 0.33 | +10 | +9.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -17 | -16.7 |
| RISK BY ARC | 6 | 6 | 1 | 0.33 | +0 | +0.4 |
| SET UP BY THE SET | 6 | 6 | 1 | 0.33 | +100 | +100.0 |
| SPELLS IN THE FIGHT | 3 | 3 | 1 | 0.33 | +10 | +9.8 |
| STAY WORTH | 169 | 152 | 1 | 0.33 | +3 | +3.2 |
| THE FIGHT MOVES | 3 | 3 | 1 | 0.33 | +0 | +0.4 |
| BACKS UP THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 13 | 13 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 14 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 38 | 38 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 33 | 33 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 39 | 38 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 22 | 22 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 82 | 82 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 43 | 34 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEAR WALKS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 56 | 52 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 6 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 14 | 7 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 267 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 78 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 30 | 29 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 270 | 268 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 291 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 8 | 8 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p15

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 4.00 | 31.2 |
| ARMY TABLE | rule | 3.00 | 1.33 | 100.1 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 1.33 | 53.0 |
| MARCH OF THE TABLE | rule | 0.33 | 0.67 | 9.6 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 16.5 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 4.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 12.2 |
| PATHS CROSS | rule | 0.33 | - | 12.7 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 16.7 |

### Plans: nw22-19bea9b-p15

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 75% | 160 | 79 | 49% |
| Mine | join | 1.7 | 100% | 58 | 0 | 0% |
| Mine | move | 33.3 | 99% | 1823 | 0 | 0% |
| Mine | shoot | 9.0 | 48% | 325 | 417 | 128% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 0.3 | 100% | 0 | 32 | - |
| Opponent | join | 2.0 | 100% | 114 | 0 | 0% |
| Opponent | move | 30.7 | 98% | 1031 | 0 | 0% |
| Opponent | shoot | 10.0 | 67% | 493 | 510 | 103% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p15

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 100% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p15

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 10 (11) | 10 | 0 | 0 | 55% | 2.8 | 16 (6) | 0 (5) | - | 16 (7) | 0 (4) |
| Mine | Clean-up | 7 | 45 (7) | 6 | 39 | 16 | 71% | 3.5 | 9 (4) | 167 (2) | 25 (1) | 14 (5) | 116 (2) |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 0 | 17% | 3.0 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Holder | 2 | 11 (2) | 0 | 11 | 0 | 100% | - | 22 (1) | 0 (1) | - | 11 (2) | - |
| Mine | Shooter | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 5 | 70 (5) | 70 | 0 | 40 | 0% | 1.0 | 175 (2) | 0 (1) | 0 (2) | - | 70 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 18 | 75% | 2.0 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 5 (9) | 5 | 0 | 0 | 33% | 3.3 | 0 (3) | 10 (5) | 0 (1) | 6 (6) | 0 (3) |
| Opponent | Clean-up | 2 | 68 (2) | 0 | 68 | 57 | 50% | 3.0 | 159 (1) | 0 (1) | - | 159 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 75 (3) | 0 | 75 | 31 | 33% | 3.0 | - | 109 (2) | 0 (1) | 110 (2) | 0 (1) |
| Opponent | Shooter | 3 | 125 (3) | 0 | 125 | 33 | 0% | 1.0 | - | 231 (1) | 72 (2) | 188 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 13 (5) | 13 | 0 | 41 | 20% | 1.0 | - | - | 13 (5) | - | 13 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 20% | 2.8 | 0 (3) | 0 (2) | - | 0 (3) | 0 (2) |

### Charged fights: nw22-19bea9b-p15

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 150 | 2.0 | 1.0 | 75 | 0 | +75 | 1 of 4 | 3 of 4 | - | +75 |
| Mine | Dwarfen Mountain Holds | 1 | 333 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 111 | 100 | 1.3 | 1.0 | 75 | 0 | +75 | 1 of 4 | 3 of 4 | - | +75 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 95 | 95 | 1.0 | 1.0 | 95 | 0 | +95 | 0 of 1 | 1 of 1 | - | +95 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 32 | 32 | 0.7 | 1.0 | 48 | 0 | +48 | 1 of 2 | 2 of 2 | - | +48 |

### Effective charges: nw22-19bea9b-p15

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 1 (net +0) | 0 | 0 | 1 (net +45) | 0 | 2 (net +127) | 0 | 0% (0 of 4) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +95) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p15

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 112 | 211 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 112 | 45 | +45 | 45 | 0 | +45 | +40.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 272 | 179 | +127 | 159 | 13 | +146 | +53.6 |
| Mine | All fights | 4 | 192 | 154 | +75 | 91 | 6 | +84 | +43.8 |
| Opponent | 76-89% | 1 | 205 | 95 | +95 | 170 | 157 | +13 | +6.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 50 | 339 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 2 | 128 | 217 | +48 | 85 | 78 | +7 | +5.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p15 | move | 6 | 2 (33%) | 1 (17%) | 0 (0%) | 4 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

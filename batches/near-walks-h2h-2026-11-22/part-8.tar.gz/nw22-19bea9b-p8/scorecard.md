# Doctrine scorecard: nw22-19bea9b-p8

### Scorecard: nw22-19bea9b-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 4 | 5 | 1 | 4 | 0 | 0 | 0 | 489 |
| L1431 | 3 | 1 | Mine | yes | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 0 | 3 | 0 | 0 | 562 |
| **Average** | | | Mine | 67% | 2.5 | 2.0 | 2.7 | 0.7 | 0.0 | 0.0 | 0.0 | 147.3 |
| **Average** | | | Opponent | 33% | 2.0 | 3.0 | 2.0 | 3.0 | 1.0 | 0.0 | 0.0 | 350.3 |

### KPIs: nw22-19bea9b-p8

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 7% (1 of 15) | 0% (0 of 12) | 4% (1 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 33% | 100% (1 of 1); on the table 100% | 50% (2 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 50% (2 of 4); on the table 50% | 100% (4 of 4); on the table 100% | 75% (6 of 8); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 6% (1 of 18) | 17% (4 of 24) | 12% (5 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 9% (1 of 11) | 19% (4 of 21) | 16% (5 of 32) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 62% (5 of 8) | 62% (5 of 8) |
| Points that never fought | lower | 42% (2494 of 6000) | 30% (1788 of 6000) | 36% (4282 of 12000) |
|   infantry points that never fought | lower | 52% (678 of 1315) | 46% (426 of 921) | 49% (1104 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (12 of 25) | 88% (28 of 32) | 70% (40 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 50% (1 of 2); 1.0 uses a game | 75% (3 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 10% (1 of 10); 0.3 uses a game | 0.0 uses a game | 10% (1 of 10); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (2650 of 5720) | 84% (4887 of 5830) | 65% (7537 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (35%) | 1.3 (20%) | 3.3 (27%) |
| MARCHED: its unit marched | 1.0 (18%) | 0.3 (5%) | 1.3 (11%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.0 (18%) | 0.3 (5%) | 1.3 (11%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.0 (60%) | 4.0 (32%) |
| GONE: slain | 1.3 (24%) | 0.0 (0%) | 1.3 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (10%) | 0.7 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.3 | 3.3 | 1.7 | 0.0 | 2.0 |
| not cast | 3.0 | 2.7 | 2.7 | 12.3 | 2.0 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (38%) | 0.0 (0%) | 3.3 (27%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (12%) | 0.7 (25%) | 1.3 (11%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (67%) | 0.0 (0%) | 2.0 (75%) | 4.0 (32%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.0 (0%) | 1.3 (50%) | 0.0 (0%) | 1.3 (11%) | 1.3 (67%) | 5.0 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.3 a game | 0.0 a game | 1.7 a game |
| stood (cast and not dispelled) | 30% (3 of 10) | - | 30% (3 of 10) |
| the unit moved after it | 67% (2 of 3) | - | 67% (2 of 3) |
| it charged on its next turn | 33% (1 of 3) | - | 33% (1 of 3) |
| the enemy charged it first | 0% (0 of 3) | - | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 67% (2 of 3) | - | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (59 of 93) | 64% (16 of 25) | 64% (75 of 118) |
|   cavalry | 43% (3 of 7) | 67% (10 of 15) | 59% (13 of 22) |
|   character | 34% (11 of 32) | 33% (2 of 6) | 34% (13 of 38) |
|   infantry | 70% (21 of 30) | 100% (4 of 4) | 74% (25 of 34) |
|   war machine | 100% (24 of 24) | - | 100% (24 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (38%) | 2.7 (89%) | 7.0 (49%) |
| CHARGED: it charged | 3.3 (29%) | 0.3 (11%) | 3.7 (26%) |
| IN COMBAT: it fought this turn or the last | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET IN RANGE | 1.7 (15%) | 0.0 (0%) | 1.7 (12%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (12%) | 0.0 (0%) | 1.3 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.0 | 0.7 | 90% | 5.4 pts | 38 pts |
| character | 6.0 | 1.3 | 78% | 5.2 pts | 31 pts |
| infantry | 14.7 | 4.3 | 80% | 7.5 pts | 109 pts |
| war machine | 8.0 | 6.0 | 54% | 18.0 pts | 144 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 2.0 | 4.0 |
| Charges that made contact a game | 4.3 | 1.3 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | - | 1.00 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.68 declared, 0.50 contact (22 units) | 0.26 declared, 0.17 contact (23 units) | 0.47 declared, 0.33 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (8 of 15) | 100% (2 of 2) | - | 59% (10 of 17) |
| Character in a unit | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Character on its own | 75% (3 of 4) | 75% (3 of 4) | 43% (3 of 7) | 60% (9 of 15) |
| Infantry | 83% (10 of 12) | 50% (1 of 2) | - | 79% (11 of 14) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 50% (2 of 4); on the table 50% | 6% (1 of 18) | 42% | 48% (12 of 25) | 100% (2 of 2); 2.7 uses a game | 10% (1 of 10); 0.3 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 12) | 33% | 100% (8 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | 33% (2 of 6) | 6% | 83% (10 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 51% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p8, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 20% (1) | 44% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: nw22-19bea9b-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 73% (11 of 15) | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (12 of 32) | 17% (1 of 6) |
| Strategy | Support requests answered (helper made contact too) | 80% (4 of 5) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 3) |
| Strategy | Joined characters whose unit fought | - | 80% (4 of 5) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 100% (7 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.7 | 3.0 |
| Movement | Points that never moved of their own | 147.3 | 350.3 |
| Movement | Fights charged into per game | 2.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +0 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +446 | 1 of 2, net +330 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 7, net +114 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 7, net +204 | 1 of 2, net +442 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 5.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 26% (9 of 35) | 81% (13 of 16) |
| Shooting | Points destroyed by shooting units | 117.3 | 0.0 |
| Shooting | War machine shots | 8.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (11 of 24) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (1 of 1) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 2.7 | 0.3 |
| Magic | Wounds caused by other spells | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 38.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 1.7 / 0.0 | 1.3 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 438.3 | 314.0 |
| Combat | Points run down | 0.0 | 41.0 |
| Combat | Net points per charged fight, damage counted | +185 | +160 |
| Combat | Net per 100 charger points, damage counted | +39.8 | +58.8 |
| Combat | First round won (charged fights) | 88% | 50% |
| Combat | Net points per charged fight | +197 | +120 |
| Combat | Net points per supported fight / lone fight | +232 / +185 | - / +120 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 8 | 3 of 4 |
| Game | Points lost | 321.7 | 947.7 |
| Game | VP from objectives | 876.7 | 276.7 |
| Game | Lone holders (player turns) | 2.5 | 2.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1243 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1269
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 28.3 | +67.7 | 0.0 | 82.0 | 23.7 | -48.5 | 0.0 | 445.0 |
| ASSAILMENT BY POINTS | 0.7 | +2.9 | 0.0 | 333.3 | - | - | - | - |
| BACKS UP THE FIGHT | 2.3 | +147.1 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 78.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +107.4 | 157.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +13.1 | 46.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +1.8 | 0.0 | 0.0 | 1.0 | +71.4 | 0.0 | 116.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -5.4 | 116.7 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 1.0 | -181.6 | 131.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.3 | -664.8 | 0.0 | 335.7 | 21.0 | -1608.7 | 0.0 | 738.7 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.7 | +0.0 | 675.3 | 0.0 | 1.0 | +0.0 | 355.0 | 77.3 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 4.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 150.0 |
| CONVEYANCE SEARCH | 2.7 | +260.2 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 8.3 | -430.8 | 0.0 | 41.0 | 4.7 | -432.9 | 0.0 | 114.0 |
| DENIED BY THE FIGHT | 1.3 | -11.6 | 229.3 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.7 | -7.2 | 0.0 | 0.0 | 7.0 | +48.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | +23.6 | 83.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 1.7 | +47.2 | 218.7 | 0.0 | - | - | - | - |
| ELIXIR WORTH | - | - | - | - | 0.3 | +2.5 | 0.0 | 116.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 3.7 | +389.9 | 0.0 | 84.0 |
| EXACT ROUND | 1.7 | +33.2 | 451.7 | 0.0 | 0.7 | +19.5 | 314.0 | 38.7 |
| FALL BACK GOOD ORDER | 1.7 | +3.7 | 200.0 | 0.0 | 1.0 | +0.0 | 355.0 | 77.3 |
| FALLS SHORT | - | - | - | - | 18.3 | +309.3 | 0.0 | 575.7 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +1.8 | 116.7 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 100.0 | +6888.9 | 1759.3 | 376.7 | 62.7 | +3202.0 | 355.0 | 1476.7 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 147.3 | 6.0 | +0.0 | 0.0 | 77.3 |
| FOCUS FIRE | 0.3 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +266.1 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 5.7 | +415.8 | 1025.3 | 0.0 | 1.0 | +108.4 | 355.0 | 77.3 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 96.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.0 | -9.2 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +14.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -6.0 | 116.7 | 0.0 | - | - | - | - |
| GOAL WALK | 5.3 | +400.9 | 0.0 | 0.0 | 13.0 | +793.9 | 0.0 | 167.3 |
| GUN FIGURES | 1.3 | +7.4 | 42.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.0 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 41.7 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.7 | +0.0 | 0.0 | 144.0 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 294.7 | 12.7 | +0.0 | 0.0 | 602.7 |
| HIS CHARGE DENIED | 1.7 | +30.6 | 583.3 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 36.7 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.7 | -20.0 | 0.0 | 0.0 | 3.3 | -20.4 | 0.0 | 84.0 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 274.7 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 154.7 |
| HIS RANDOM MOVE | 10.3 | +0.0 | 0.0 | 82.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 41.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.0 | +1013.8 | 0.0 | 82.0 | 39.3 | +849.7 | 0.0 | 923.3 |
| HIS SHOTS BY HIS RUN | 34.0 | +828.9 | 0.0 | 335.7 | 45.3 | +809.5 | 0.0 | 1134.0 |
| HIS TURN DENIED | 1.7 | +86.5 | 197.3 | 0.0 | - | - | - | - |
| HOLD ODDS | 13.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 48.0 |
| HOLDER ASSIGNMENT | 8.7 | +608.6 | 0.0 | 0.0 | 3.3 | +269.3 | 0.0 | 48.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -152.8 | 442.0 | 0.0 | 0.3 | -4.8 | 41.0 | 38.7 |
| HUNT RESULT | - | - | - | - | 0.3 | +209.6 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +224.0 | 166.7 | 38.7 |
| IDLE COST | - | - | - | - | 9.0 | -127.6 | 0.0 | 164.0 |
| JOINT CHARGE NOW | 2.7 | -79.1 | 697.3 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | 0.3 | +31.6 | 116.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 48.0 |
| LANE BY FIGURES | 1.3 | +134.5 | 0.0 | 0.0 | 0.7 | +21.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 257.0 | 603.7 | 3.3 | +0.0 | 0.0 | 755.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +0.7 | 317.0 | 0.0 | 0.3 | +0.0 | 147.3 | 0.0 |
| LOST CHARGE | 0.7 | -3.0 | 153.3 | 0.0 | - | - | - | - |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | -1.5 | 0.0 | 0.0 | 0.7 | +5.2 | 0.0 | 40.0 |
| MARCH AT ESCAPER | 0.3 | +8.8 | 0.0 | 0.0 | 0.3 | +10.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +45.1 | 0.0 | 0.0 | 0.7 | +3.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +59.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +19.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +10.5 | 0.0 | 0.0 | 0.7 | +105.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| MAX FOR POSITIONING | 0.7 | +34.6 | 0.0 | 0.0 | 1.0 | +26.4 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | +193.0 | 0.0 | 0.0 | 3.7 | +48.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.7 | +86.7 | 0.0 | 0.0 | 5.3 | +155.9 | 0.0 | 148.7 |
| MISSILES NEXT TURN | 5.7 | +51.5 | 0.0 | 0.0 | 6.0 | +117.6 | 0.0 | 148.7 |
| MOVE ORDER | 2.0 | +0.0 | 82.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 10.0 | +946.4 | 0.0 | 0.0 | 6.3 | +380.4 | 0.0 | 154.7 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +316.0 | 0.0 | 0.0 | 4.3 | +168.7 | 0.0 | 86.0 |
| NEXT CHARGE BY LIST | 6.0 | +719.8 | 0.0 | 0.0 | 4.3 | +179.9 | 0.0 | 77.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -0.6 | 0.0 | 48.0 |
| NO CHAFF EDGES | 3.3 | +112.0 | 222.0 | 0.0 | 1.7 | +42.7 | 500.0 | 80.7 |
| NO DOUBLE ROUNDS | 4.3 | -313.7 | 675.3 | 0.0 | 1.0 | -133.5 | 355.0 | 77.3 |
| NO LATE CUT | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +57.9 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.7 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -125.8 | 0.0 | 0.0 | 4.7 | -273.4 | 0.0 | 203.0 |
| ONE CHALLENGE TEST | 0.3 | -5.4 | 116.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 48.0 |
| ONE FIGHT FORMULA | 3.3 | -72.8 | 0.0 | 0.0 | 4.3 | -122.1 | 0.0 | 209.0 |
| ONE JOINT FIGURE | 1.7 | +120.6 | 583.3 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.0 | -47.9 | 0.0 | 0.0 | 0.7 | +6.4 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -18.6 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP IN FULL | 1.0 | +9.8 | 148.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +49.9 | 211.3 | 0.0 | 0.3 | +0.8 | 166.7 | 38.7 |
| PATHS CROSS | - | - | - | - | 0.3 | +20.7 | 0.0 | 0.0 |
| PLAN RESULT | 44.7 | +1627.1 | 496.3 | 502.3 | 31.7 | +355.0 | 398.3 | 1110.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 147.3 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.0 | -154.6 | 0.0 | 0.0 | 8.0 | -213.6 | 0.0 | 77.3 |
| PROMISE KNOWS THE FIGHT | 4.3 | -19.1 | 0.0 | 0.0 | 0.7 | -5.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 32.7 | +3084.6 | 302.7 | 294.7 | 16.3 | +2404.7 | 147.3 | 314.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +42.1 | 0.0 | 170.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +35.3 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 38.7 |
| REFORMS TO MEET IT | 0.7 | -14.2 | 0.0 | 0.0 | 0.7 | -27.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +22.5 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 5.0 | +52.0 | 977.3 | 0.0 | 1.0 | +46.0 | 355.0 | 77.3 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.0 |
| ROUNDS AFTER TERROR | 1.0 | -27.2 | 196.7 | 0.0 | - | - | - | - |
| RUN DOWN | 4.7 | -149.3 | 792.0 | 0.0 | 1.0 | -5.7 | 355.0 | 77.3 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | -0.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +71.0 | 48.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -14.8 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.0 | +0.1 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +22.9 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 48.0 |
| SET-UP ANY TARGET | 0.3 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 84.7 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +8.9 | 134.7 | 0.0 | 1.3 | +8.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -31.5 | 164.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 19.7 | -523.8 | 0.0 | 376.7 | 23.3 | -574.6 | 0.0 | 506.0 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.7 | +532.4 | 0.0 | 0.0 | 4.3 | +133.2 | 0.0 | 121.3 |
| SPELL SETS UP CHARGE | 0.3 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 3.7 | +111.9 | 0.0 | 0.0 | 1.3 | +6.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.7 | +10.9 | 356.0 | 0.0 | 0.3 | -9.6 | 166.7 | 38.7 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 296.0 |
| STAND AND SHOOT | 0.3 | -6.7 | 36.7 | 0.0 | 0.3 | -2.4 | 41.0 | 38.7 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 52.3 | +0.0 | 734.0 | 0.0 | 15.7 | +0.0 | 0.0 | 460.0 |
| STAY WORTH | 32.3 | +117.5 | 268.0 | 0.0 | 6.3 | +41.5 | 0.0 | 36.7 |
| STOPS | - | - | - | - | 0.3 | +19.0 | 166.7 | 38.7 |
| STRIKE BY THE ODDS | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| STRONG ENOUGH TO HOLD | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.7 | +463.0 | 0.0 | 0.0 | 4.3 | +212.6 | 0.0 | 83.3 |
| SUPPORT WORKED OUT | 3.7 | +463.0 | 0.0 | 0.0 | 4.3 | +212.6 | 0.0 | 83.3 |
| SURE REACH TOGETHER | 3.0 | +16.2 | 0.0 | 0.0 | 0.7 | +3.0 | 0.0 | 38.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 4.3 | +19.6 | 922.3 | 0.0 | 0.7 | +4.4 | 314.0 | 38.7 |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 18.3 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | - | - | - | - | 2.7 | +0.0 | 0.0 | 40.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.0 | +0.0 | 0.0 | 188.3 | 29.3 | +0.0 | 0.0 | 659.7 |
| TIED UP BY THE SUM | 2.3 | +201.8 | 235.7 | 0.0 | 0.3 | +18.5 | 41.0 | 38.7 |
| TIME ON OUR SIDE | 39.0 | +449.6 | 0.0 | 41.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -63.6 | 333.3 | 77.3 |
| WHO FIGHTS | 0.7 | +1.6 | 116.7 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +40.5 | 166.7 | 38.7 |
| WHOLE FIGHT DANGER | 1.0 | -45.9 | 0.0 | 0.0 | 3.0 | -1016.8 | 0.0 | 477.3 |
| WHOLE FIGHT GAIN | 1.7 | +152.7 | 583.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.7 | +105.5 | 78.7 | 188.3 | 3.3 | +132.0 | 0.0 | 366.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 4.7 | +292.0 | 0.0 | 167.3 |

### Rule changes: nw22-19bea9b-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 156 | 156 | 109 | 36.33 | +727 | +6.7 |
| HIS SHOTS BY HIS RUN | 238 | 232 | 49 | 16.33 | +650 | +13.3 |
| HIS SHOT LIST | 220 | 212 | 45 | 15.00 | +570 | +12.7 |
| FIVE ACTION | 488 | 475 | 36 | 12.00 | +1361 | +37.8 |
| MOVE TO CHARGE COMPUTED | 49 | 47 | 34 | 11.33 | +1101 | +32.4 |
| HOLDER ASSIGNMENT | 36 | 36 | 31 | 10.33 | +2324 | +75.0 |
| DEPLOY BY FIGURES | 41 | 41 | 24 | 8.00 | +227 | +9.5 |
| SHOT RISK POINTS | 129 | 125 | 23 | 7.67 | +634 | +27.6 |
| LEGAL CHARGES ONLY | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -1198 | -54.4 |
| NEXT CHARGE BY LIST | 31 | 31 | 21 | 7.00 | +878 | +41.8 |
| QUARTER ODDS | 147 | 142 | 20 | 6.67 | +2455 | +122.7 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 51 | 51 | 17 | 5.67 | -1104 | -65.0 |
| CHARGE LOSSES | 115 | 112 | 14 | 4.67 | +950 | +67.8 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 117 | 102 | 14 | 4.67 | +85 | +6.1 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| NO CHAFF EDGES | 15 | 15 | 13 | 4.33 | +443 | +34.1 |
| GOAL WALK | 55 | 55 | 12 | 4.00 | +742 | +61.8 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| FOUR ROUNDS | 20 | 20 | 10 | 3.33 | +347 | +34.7 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | -237 | -29.7 |
| PROMISE KNOWS THE FIGHT | 15 | 13 | 8 | 2.67 | -72 | -9.1 |
| EVASIVE BY THE ODDS | 11 | 11 | 6 | 2.00 | +1140 | +190.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +466 | +77.8 |
| MEETS IN TIME | 19 | 19 | 6 | 2.00 | +162 | +27.0 |
| MISSILES IN THE MOVE | 30 | 21 | 6 | 2.00 | +77 | +12.8 |
| SUPPORT ADDS | 24 | 24 | 6 | 2.00 | +301 | +50.1 |
| SUPPORT WORKED OUT | 24 | 24 | 6 | 2.00 | +301 | +50.1 |
| FALLS SHORT | 55 | 46 | 5 | 1.67 | +26 | +5.2 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 5 | 1.67 | +126 | +25.3 |
| RISK BY ARC | 18 | 18 | 5 | 1.67 | +205 | +41.0 |
| SHOTS IN THE MOVE | 72 | 53 | 5 | 1.67 | +45 | +9.0 |
| STAY WORTH | 116 | 101 | 5 | 1.67 | +71 | +14.3 |
| TIED UP BY THE SUM | 8 | 8 | 5 | 1.67 | +166 | +33.1 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +219 | +54.8 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +145 | +36.2 |
| ONE JOINT FIGURE | 5 | 5 | 4 | 1.33 | +107 | +26.7 |
| WHOLE FIGHT GAIN | 5 | 5 | 4 | 1.33 | +107 | +26.7 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +303 | +101.0 |
| MAX FOR POSITIONING | 5 | 5 | 3 | 1.00 | +5 | +1.7 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +68 | +22.6 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +8 | +2.7 |
| SHOTS AFTER THE MOVES | 17 | 17 | 3 | 1.00 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +9 | +4.4 |
| BACKS UP THE FIGHT | 7 | 5 | 2 | 0.67 | +37 | +18.4 |
| CANNON PLANNED TARGET | 24 | 24 | 2 | 0.67 | -9 | -4.4 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +20 | +9.8 |
| COVER ONCE | 39 | 22 | 2 | 0.67 | +4 | +2.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +798 | +399.2 |
| IDLE COST | 27 | 15 | 2 | 0.67 | +4 | +2.1 |
| MANOEUVRE | 5 | 5 | 2 | 0.67 | +16 | +7.8 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +102 | +51.2 |
| NEARER NOT NEEDED | 31 | 29 | 2 | 0.67 | +101 | +50.5 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -56 | -27.9 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +384 | +192.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +213 | +106.6 |
| SET UP BY THE SET | 4 | 4 | 2 | 0.67 | +10 | +4.8 |
| WOUNDS ON THE RANKS | 14 | 14 | 2 | 0.67 | +105 | +52.6 |
| CANNON SIGHT KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -4 | -4.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -3 | -3.1 |
| CHARGE NOW FIRST | 14 | 14 | 1 | 0.33 | -56 | -55.6 |
| DUEL STOPS AT THE KILL | 1 | 1 | 1 | 0.33 | +8 | +8.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| EXACT ROUND | 7 | 7 | 1 | 0.33 | +34 | +34.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +18 | +18.5 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +44 | +43.7 |
| HIS CHARGE DENIED | 5 | 5 | 1 | 0.33 | +3 | +3.1 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +49 | +48.7 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +95 | +94.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -60 | -59.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +65 | +65.1 |
| ONE OBJECTIVE FORMULA | 14 | 11 | 1 | 0.33 | +3 | +3.0 |
| OPENS UP IN FULL | 3 | 3 | 1 | 0.33 | +8 | +8.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +62 | +62.1 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -5 | -5.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +10 | +9.5 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SPELLS IN THE FIGHT | 6 | 6 | 1 | 0.33 | +3 | +3.1 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +5 | +4.7 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 11 | 9 | 1 | 0.33 | +0 | +0.0 |
| THE FIGHT MOVES | 15 | 15 | 1 | 0.33 | +8 | +8.5 |
| THE ROW IN ITS ORDER | 16 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 2 | 2 | 1 | 0.33 | +3 | +3.1 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +7 | +6.8 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +102 | +102.4 |
| WHOLE FIGHT REACTION | 15 | 15 | 1 | 0.33 | +1 | +0.9 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 32 | 32 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 5 | 5 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 7 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| GUN MASK | 3 | 3 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 7 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 69 | 69 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 13 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 15 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 37 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 31 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 1 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 53 | 53 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 13 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 35 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 16 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 23 | 10 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 229 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 42 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 42 | 40 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 204 | 200 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 229 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 3.33 | 4.00 | 51.1 |
| JOB FIRST | gate | 2.00 | 4.00 | 48.1 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 3.00 | 65.0 |
| PROMISE KNOWS THE FIGHT | rule | 2.00 | 0.67 | 9.1 |
| JOINT CHARGE NOW | rule | 1.67 | - | 83.6 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 10.9 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 4.4 |
| NO REASON | gate | - | 0.67 | 75.7 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 27.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 169.8 |
| CHAFF PASSED | rule | 0.33 | - | 4.0 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 3.1 |
| CHARGE NOW FIRST | rule | 0.33 | - | 55.6 |
| MARCH OF THE TABLE | rule | - | 0.33 | 59.7 |
| REFUSING RETIRES | rule | - | 0.33 | 5.0 |
| RULE SWITCHED OFF | gate | 0.33 | - | 11.5 |

### Plans: nw22-19bea9b-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.7 | 76% | 707 | 977 | 138% |
| Mine | move | 30.3 | 99% | 1939 | 0 | 0% |
| Mine | shoot | 8.7 | 73% | 336 | 650 | 194% |
| Opponent | charge | 1.0 | 100% | 201 | 355 | 176% |
| Opponent | join | 1.7 | 80% | 73 | 0 | 0% |
| Opponent | move | 27.0 | 91% | 1406 | 0 | 0% |
| Opponent | shoot | 2.0 | 0% | 33 | 0 | 0% |

### Packages: hunt the guns, nw22-19bea9b-p8

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 672 | 629 | 100% | 60 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Warriors of Chaos | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 672 | 629 | 100% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |

### Battle groups: nw22-19bea9b-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 80 (8) | 80 | 0 | 32 | 0% | 2.4 | 82 (3) | 80 (5) | - | 113 (2) | 71 (6) |
| Mine | Clean-up | 2 | 98 (2) | 0 | 98 | 50 | 50% | 2.0 | - | 98 (2) | - | 98 (2) | - |
| Mine | Fast Hammer | 8 | 57 (8) | 21 | 35 | 0 | 75% | 3.5 | 52 (4) | 61 (4) | - | 69 (3) | 49 (5) |
| Mine | Holder | 2 | 26 (2) | 0 | 26 | 0 | 0% | 2.5 | 26 (2) | - | - | 26 (2) | - |
| Mine | Shooter | 5 | 20 (5) | 20 | 0 | 0 | 0% | 1.0 | 22 (3) | 16 (2) | - | 25 (4) | 0 (1) |
| Mine | War machine | 4 | 65 (4) | 65 | 0 | 0 | 0% | 1.0 | 90 (2) | 39 (2) | - | 90 (2) | 39 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 42 (9) | 42 | 0 | 50 | 0% | 2.7 | 0 (5) | 80 (4) | - | 0 (4) | 71 (5) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 38 | 67% | 3.0 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 26 (3) | 0 | 26 | 36 | 0% | 2.7 | 26 (3) | - | - | 114 (1) | 0 (2) |
| Opponent | Hammer | 8 | 13 (8) | 13 | 0 | 35 | 50% | 3.0 | 0 (4) | 36 (3) | 0 (1) | 0 (4) | 31 (4) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 34 | 0% | 4.0 | 0 (2) | 0 (1) | - | - | 0 (3) |

### Charged fights: nw22-19bea9b-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 156 | 524 | 2.7 | 1.6 | 197 | 0 | +197 | 3 of 8 | 7 of 8 | +232 | +185 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 500 | 2.0 | 1.0 | 250 | 230 | +20 | 2 of 2 | 0 of 2 | - | +20 |
| Opponent | Wood Elf Realms | 1 | 0 | 442 | 1.0 | 1.0 | 442 | 0 | +442 | 1 of 1 | 1 of 1 | - | +442 |
| **Opponent** | all armies | 3 | 0 | 314 | 1.3 | 1.0 | 236 | 115 | +120 | 3 of 4 | 2 of 4 | - | +120 |

### Effective charges: nw22-19bea9b-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 8 | 1 (net +0) | 0 | 1 (net +446) | 2 (net +230) | 1 (net +114) | 2 (net +204) | 1 | 14% (1 of 7) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 1 (net +330) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +442) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 400 | 343 | +0 | 79 | 229 | -149 | -37.4 |
| Mine | Effective (55-75%) | 1 | 489 | 201 | +446 | 446 | 0 | +446 | +91.2 |
| Mine | 76-89% | 2 | 658 | 230 | +230 | 304 | 0 | +304 | +46.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 199 | 142 | +204 | 204 | 15 | +189 | +95.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 628 | 114 | +114 | 198 | 144 | +54 | +8.5 |
| Mine | No odds | 1 | 489 | 144 | +144 | 144 | 0 | +144 | +29.4 |
| Mine | All fights | 8 | 465 | 193 | +197 | 235 | 50 | +185 | +39.8 |
| Opponent | Effective (55-75%) | 1 | 116 | 500 | +330 | 500 | 170 | +330 | +284.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 342 | +442 | 442 | 0 | +442 | +88.6 |
| Opponent | No odds | 2 | 235 | 360 | -145 | 78 | 145 | -67 | -28.4 |
| Opponent | All fights | 4 | 271 | 390 | +120 | 275 | 115 | +160 | +58.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p8 | move | 16 | 3 (19%) | 3 (19%) | 1 (6%) | 12 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

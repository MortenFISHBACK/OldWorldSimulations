# Doctrine scorecard: nw22-19bea9b-p24

### Scorecard: nw22-19bea9b-p24

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 3 | 6 | 2 | 0 | 2 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | yes | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | - | 1 | 4 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 5 | 5 | 0 | 0 | 0 | 250 |
| L3033 | 3 | 1 | Mine | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 182 |
| **Average** | | | Mine | 33% | 2.5 | 4.0 | 2.0 | 1.7 | 1.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 67% | 0.0 | 2.7 | 3.7 | 2.7 | 0.0 | 0.0 | 0.0 | 144.0 |

### KPIs: nw22-19bea9b-p24

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 35% (6 of 17) | 19% (6 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (6 of 6); on the table 100% | 100% (8 of 8); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 75% | - | 25% (1 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 43% (3 of 7); on the table 71% | 100% (6 of 6); on the table 100% | 69% (9 of 13); on the table 85% |
| Magic missiles tried each own turn | 50%+ | 50% (12 of 24) | 33% (6 of 18) | 43% (18 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 63% (12 of 19) | 33% (6 of 18) | 49% (18 of 37) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 13% (795 of 5999) | 47% (2804 of 6000) | 30% (3599 of 11999) |
|   infantry points that never fought | lower | 43% (332 of 780) | 49% (943 of 1918) | 47% (1275 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 72% (13 of 18) | 68% (23 of 34) | 69% (36 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 3.3 uses a game | 50% (2 of 4); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3141 of 4808) | 63% (3750 of 5962) | 64% (6891 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (33%) | 3.0 (75%) | 4.3 (54%) |
| MARCHED: its unit marched | 0.3 (8%) | 1.0 (25%) | 1.3 (17%) |
| IN COMBAT: engaged in combat | 1.0 (25%) | 0.0 (0%) | 1.0 (12%) |
| GONE: slain | 0.7 (17%) | 0.0 (0%) | 0.7 (8%) |
| STUPIDITY: Stupidity | 0.7 (17%) | 0.0 (0%) | 0.7 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 2.3 | 1.7 | 6.0 | 1.3 | 1.0 |
| not cast | 5.3 | 0.7 | 4.3 | 8.0 | 4.7 | 23.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 4.3 (54%) | 2.0 (43%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (17%) | 0.7 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (15%) | 1.0 (12%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.3 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (25%) | 0.0 (0%) | 0.0 (0%) | 0.7 (8%) | 0.7 (14%) | 3.0 (13%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (8%) | 0.0 (0%) | 2.0 (9%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (29%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (50%) | 0.0 (0%) | 3.7 (85%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.0 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 1.3 a game | 0.8 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | 0% (0 of 4) | 20% (1 of 5) |
| the unit moved after it | 100% (1 of 1) | - | 100% (1 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 5) | 62% (57 of 92) | 59% (57 of 97) |
|   cavalry | - | 66% (29 of 44) | 66% (29 of 44) |
|   character | 0% (0 of 5) | 47% (7 of 15) | 35% (7 of 20) |
|   infantry | - | 64% (21 of 33) | 64% (21 of 33) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 6.3 (54%) | 6.3 (48%) |
| CHARGED: it charged | 1.0 (60%) | 3.3 (29%) | 4.3 (32%) |
| IN COMBAT: it fought this turn or the last | 0.3 (20%) | 1.0 (9%) | 1.3 (10%) |
| NO TARGET IN RANGE | 0.3 (20%) | 0.3 (3%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (6%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.0 | 3.7 | 82% | 2.7 pts | 35 pts |
| character | 2.3 | 1.3 | 43% | 13.9 pts | 32 pts |
| infantry | 9.3 | 8.3 | 54% | 17.6 pts | 164 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 4.7 | 4.7 |
| Charges that made contact a game | 2.7 | 4.3 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | - | 0.25 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.65 declared, 0.35 contact (20 units) | 0.45 declared, 0.42 contact (31 units) | 0.53 declared, 0.39 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (6 of 11) | 100% (2 of 2) | 100% (1 of 1) | 64% (9 of 14) |
| Character in a unit | 100% (1 of 1) | 60% (3 of 5) | 100% (1 of 1) | 71% (5 of 7) |
| Character on its own | 100% (4 of 4) | 100% (1 of 1) | 20% (1 of 5) | 60% (6 of 10) |
| Infantry | 67% (8 of 12) | 67% (2 of 3) | - | 67% (10 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (5 of 5) | - | - | 100% (5 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 0% (0 of 3); on the table 67% | 50% (12 of 24) | 14% | 92% (11 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 75% (3 of 4); on the table 75% | - | 12% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 100% (6 of 6); on the table 100% | 33% (6 of 18) | 47% | 68% (23 of 34) | 50% (2 of 4); 3.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p24, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 64% (7) | 50% (2) | 60% (9) |
| ...free all their last turn and able to turn (per game) | 2.33 | 0.33 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p24

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 46% (6 of 13) | 83% (10 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 42% (5 of 12) |
| Strategy | Support requests answered (helper made contact too) | 33% (1 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 60% (3 of 5) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 78% (7 of 9) | 100% (4 of 4) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.7 | 2.7 |
| Movement | Points that never moved of their own | 0.0 | 144.0 |
| Movement | Fights charged into per game | 2.3 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 3 of 11, net +43 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 1 of 11, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 6, net +113 | 2 of 11, net +390 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +237 | 5 of 11, net +115 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.3 | 19.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 50% (29 of 58) |
| Shooting | Points destroyed by shooting units | 0.0 | 15.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 3.3 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (2 of 10) | 20% (1 of 5) |
| Magic | Wounds caused by magic missiles | - | 6.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 95.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.7 / 0.3 / 0.7 | 0.3 / 1.3 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 273.0 | 704.3 |
| Combat | Points run down | 38.0 | 57.7 |
| Combat | Net points per charged fight, damage counted | +52 | +144 |
| Combat | Net per 100 charger points, damage counted | +14.9 | +46.2 |
| Combat | First round won (charged fights) | 100% | 75% |
| Combat | Net points per charged fight | +43 | +138 |
| Combat | Net points per supported fight / lone fight | +140 / +27 | +590 / +97 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 5 of 12 |
| Game | Points lost | 847.0 | 364.0 |
| Game | VP from objectives | 456.7 | 696.7 |
| Game | Lone holders (player turns) | 2.5 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -734 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1211
- Games not ended: 0; findings 6, warnings 0

### Opponent rules: nw22-19bea9b-p24

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +139.2 | 0.0 | 0.0 |
| ARMY TABLE | 28.3 | -92.6 | 0.0 | 567.3 | 36.0 | +511.6 | 0.0 | 38.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.6 | 0.0 | 70.3 | - | - | - | - |
| BACKS UP THE FIGHT | 0.7 | +0.5 | 0.0 | 30.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -4.5 | 20.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | -74.5 | 0.0 | 16.7 | - | - | - | - |
| CAST JOB | 1.3 | +5.1 | 76.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.0 | +43.4 | 98.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 3.7 | +110.8 | 0.0 | 30.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 2.3 | -2.3 | 0.0 | 38.0 |
| CHALLENGE BY POINTS | 0.3 | +20.2 | 0.0 | 84.7 | 1.0 | +112.8 | 0.0 | 78.7 |
| CHARACTER GUNS | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 0.7 | -27.1 | 78.7 | 0.0 | 1.0 | -63.3 | 20.0 | 0.0 |
| CHARGE LOSSES | 27.3 | -993.5 | 0.0 | 943.3 | 11.7 | -452.4 | 0.0 | 76.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 201.3 | 101.3 | 3.3 | +0.0 | 251.7 | 0.0 |
| CLEAR LANE AHEAD | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 14.7 | +0.0 | 0.0 | 66.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.3 | +13.1 | 0.0 | 0.0 | 1.3 | +67.7 | 0.0 | 0.0 |
| COVER ONCE | 10.0 | -898.6 | 0.0 | 305.0 | 14.0 | -555.7 | 0.0 | 84.7 |
| DENIED BY THE FIGHT | 1.0 | -1.6 | 114.0 | 84.7 | 0.3 | -1.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | +59.8 | 0.0 | 0.0 | 9.3 | -113.8 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -7.4 | 0.0 | 0.0 | 0.7 | -184.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +2.5 | 78.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.7 | +26.7 | 286.3 | 126.3 | 2.3 | +8.2 | 137.0 | 42.0 |
| FALL BACK GOOD ORDER | 3.3 | +14.2 | 205.0 | 126.3 | 2.7 | +0.0 | 228.7 | 42.0 |
| FALLS SHORT | 26.0 | +284.1 | 0.0 | 286.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +3.9 | 131.3 | 25.0 | 0.3 | +81.8 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.3 | +15.3 | 0.0 | 38.0 |
| FIVE ACTION | 84.0 | +4867.2 | 441.0 | 1654.3 | 100.0 | +7787.6 | 589.3 | 547.3 |
| FLANK NOT WEIGHED | 10.7 | +0.0 | 0.0 | 261.3 | 9.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +139.6 | 0.0 | 0.0 | 1.7 | +255.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +208.4 | 365.0 | 126.3 | 4.0 | +415.1 | 306.3 | 42.0 |
| FREED FROM HIS FIGHT | 5.0 | +0.0 | 0.0 | 125.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -29.9 | 34.7 | 0.0 | 0.7 | -5.0 | 62.0 | 0.0 |
| GOAL WALK | 6.7 | +715.7 | 0.0 | 124.0 | 19.7 | +1585.4 | 0.0 | 76.0 |
| HALF WHEN STILL FLEEING | 1.3 | -0.2 | 38.0 | 0.0 | 1.3 | +0.3 | 0.0 | 42.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 95.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | 0.7 | +0.0 | 93.3 | 25.0 | 0.3 | +0.0 | 0.0 | 42.0 |
| HELPER UNSEEN | 0.7 | +0.0 | 93.3 | 25.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 17.3 | +0.0 | 0.0 | 439.3 | 10.7 | +0.0 | 0.0 | 76.0 |
| HIS CHARGE DENIED | 1.3 | +55.8 | 148.7 | 84.7 | 0.3 | +14.4 | 0.0 | 0.0 |
| HIS CHARGE LIST | 6.3 | +0.0 | 0.0 | 235.3 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 8.0 | +0.0 | 0.0 | 284.0 | 7.0 | +0.0 | 0.0 | 38.0 |
| HIS MOVE AND SHOT | 8.7 | -77.3 | 0.0 | 62.0 | 1.0 | -3.3 | 0.0 | 0.0 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 253.3 | 3.3 | +0.0 | 0.0 | 42.0 |
| HIS OWN BEST MOVE | 13.3 | +0.0 | 0.0 | 284.0 | 12.0 | +0.0 | 0.0 | 200.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 66.0 | +1570.9 | 0.0 | 1198.0 | 31.7 | +273.2 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 68.3 | +1086.2 | 0.0 | 1432.7 | 28.7 | +272.8 | 0.0 | 76.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +4.2 | 20.0 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 246.0 | 8.0 | +0.0 | 0.0 | 76.0 |
| HOLDER ASSIGNMENT | 10.0 | +519.4 | 0.0 | 123.0 | 6.0 | +421.8 | 0.0 | 76.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 4.0 | -118.6 | 280.3 | 126.3 | 3.0 | -206.0 | 283.7 | 0.0 |
| HUNT IN PAIRS | 0.3 | +41.5 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 16.7 | -201.2 | 0.0 | 75.0 | - | - | - | - |
| JOINT CHARGE NOW | 2.0 | +61.5 | 207.3 | 109.7 | 1.0 | +19.5 | 30.0 | 42.0 |
| JOINT ON THE TABLE | 0.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.7 | +0.0 | 0.0 | 45.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +25.3 | 0.0 | 0.0 | 0.7 | +40.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 0.0 | 444.3 | 2.7 | +0.0 | 230.7 | 76.0 |
| LONG SHOT | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.7 | +1.5 | 169.3 | 41.7 | 1.7 | -0.6 | 15.0 | 42.0 |
| MAIN BODY KEEPS ITS BAND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MANOEUVRE | 2.3 | +0.0 | 0.0 | 82.0 | 0.7 | -0.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +8.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +120.0 | 0.0 | 0.0 | 0.3 | +23.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +17.9 | 0.0 | 0.0 | 2.0 | +83.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -77.6 | 0.0 | 0.0 | 1.0 | +64.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +12.8 | 0.0 | 40.0 | 1.3 | +15.1 | 0.0 | 41.0 |
| MEETS IN TIME | 3.3 | +190.8 | 0.0 | 0.0 | 5.0 | +92.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +11.3 | 0.0 | 20.0 | 7.0 | +261.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +12.4 | 0.0 | 20.0 | 6.7 | +132.4 | 0.0 | 0.0 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 34.7 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 2.3 | -78.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 9.7 | +1132.0 | 0.0 | 128.0 | 9.0 | +548.2 | 0.0 | 246.7 |
| NEAR WALKS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.0 | +366.5 | 0.0 | 82.0 | 8.7 | +384.3 | 0.0 | 125.3 |
| NEXT CHARGE BY LIST | 5.3 | +754.2 | 0.0 | 0.0 | 6.0 | +377.4 | 0.0 | 135.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -7.5 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.3 | +25.2 | 0.0 | 0.0 | 2.0 | +24.1 | 209.7 | 0.0 |
| NO DOUBLE ROUNDS | 4.0 | -231.6 | 365.0 | 109.7 | 2.3 | -150.6 | 206.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.3 | -2.4 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -242.9 | 0.0 | 64.0 | 4.7 | -232.0 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +1.5 | 84.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -96.0 | 0.0 | 120.0 | 7.3 | -131.1 | 0.0 | 114.7 |
| ONE JOINT FIGURE | 1.7 | +2.0 | 207.3 | 25.0 | 0.3 | +13.2 | 0.0 | 42.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -49.8 | 0.0 | 100.3 | 2.0 | -82.7 | 0.0 | 38.0 |
| ONE PROMISE A TARGET | 0.7 | -44.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +17.7 | 34.7 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 0.7 | +23.5 | 34.7 | 0.0 | 0.3 | +6.6 | 62.0 | 0.0 |
| OVERRUNS AWAY | 2.7 | +38.1 | 137.7 | 41.7 | 1.0 | +3.0 | 55.0 | 0.0 |
| PATHS CROSS | 0.3 | -3.9 | 0.0 | 0.0 | 1.0 | +24.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -17.0 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 44.0 | +333.8 | 76.0 | 1216.7 | 44.7 | +487.4 | 512.0 | 458.0 |
| PRIZE BY WORTH | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 11.0 | -280.0 | 0.0 | 128.0 | 14.0 | -630.3 | 0.0 | 111.3 |
| PROMISE KNOWS THE FIGHT | 2.7 | -3.5 | 0.0 | 30.0 | 1.7 | -1.9 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -41.7 | 0.0 | 0.0 |
| QUARTER ODDS | 20.3 | +2093.8 | 78.7 | 857.3 | 28.3 | +3393.4 | 307.7 | 126.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 5.0 | +286.3 | 0.0 | 85.0 | 0.3 | -4.1 | 0.0 | 6.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 105.0 | 0.7 | +0.0 | 0.0 | 12.7 |
| REDIRECT WEIGHED | 1.3 | +0.0 | 0.0 | 84.7 | - | - | - | - |
| REFORMS TO MEET IT | 1.7 | -5.0 | 0.0 | 0.0 | 4.0 | -51.8 | 0.0 | 42.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +17.2 | 0.0 | 0.0 | 0.3 | +2.9 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +5.2 | 0.0 | 0.0 |
| RISK BY ARC | 4.3 | -82.8 | 327.0 | 126.3 | 3.0 | +97.0 | 283.7 | 0.0 |
| RISK ON THE WAY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -3.2 | 38.0 | 0.0 | - | - | - | - |
| RUN DOWN | 4.7 | -68.8 | 365.0 | 126.3 | 0.3 | -1.5 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| SCOUT BY DROPS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.0 | -0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.3 | -58.1 | 0.0 | 30.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 5.7 | -152.4 | 0.0 | 96.7 | - | - | - | - |
| SET UP BY THE SET | 7.0 | +82.4 | 38.0 | 111.7 | 1.3 | +16.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +1.0 | 0.0 | 31.7 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.0 | +0.0 | 0.0 | 15.0 | 4.0 | +0.0 | 0.0 | 78.7 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +24.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -1.2 | 38.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 51.7 | -485.8 | 0.0 | 1299.7 | 9.7 | +10.8 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.3 | +22.2 | 0.0 | 0.0 | 17.7 | +304.7 | 0.0 | 116.7 |
| SPELL WORTH | 2.0 | +3.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 11.7 | +0.0 | 0.0 | 409.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -3.0 | 46.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 76.0 | 0.0 | - | - | - | - |
| STANDS STILL | 13.3 | +0.0 | 76.0 | 332.3 | 45.0 | +0.0 | 283.0 | 182.7 |
| STAY WORTH | 0.7 | +1.8 | 76.0 | 0.0 | 12.7 | +76.8 | 95.0 | 42.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +6.3 | 222.0 | 46.7 |
| STRONG ENOUGH TO HOLD | 1.7 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| STUBBORN ONCE | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 4.3 | +849.0 | 0.0 | 124.0 | 4.0 | +105.1 | 0.0 | 69.3 |
| SUPPORT NARROWED | 1.0 | +0.0 | 122.7 | 0.0 | 0.7 | +0.0 | 15.0 | 0.0 |
| SUPPORT WORKED OUT | 4.3 | +849.0 | 0.0 | 124.0 | 4.0 | +105.1 | 0.0 | 69.3 |
| SURE REACH TOGETHER | 1.0 | +7.0 | 0.0 | 15.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 62.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.7 | +4.4 | 201.3 | 0.0 | 1.3 | +0.7 | 99.7 | 42.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -98.3 | 0.0 | 42.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 57.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.7 | +0.0 | 0.0 | 95.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 95.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.0 | +0.0 | 0.0 | 769.0 | 47.3 | +0.0 | 0.0 | 252.7 |
| TIED UP BY THE SUM | 1.3 | +183.7 | 157.7 | 84.7 | 0.7 | +93.8 | 124.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 54.0 | +552.2 | 0.0 | 236.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 69.3 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -17.1 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +2.5 | 46.7 | 25.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | +9.5 | 0.0 | 33.3 | - | - | - | - |
| WHO FIGHTS | 1.0 | -13.8 | 91.0 | 0.0 | 0.7 | -0.5 | 87.0 | 0.0 |
| WHO GETS IN | 0.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +28.3 | 0.0 | 25.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +13.2 | 0.0 | 16.7 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -277.9 | 0.0 | 155.3 | 3.3 | -390.6 | 0.0 | 76.0 |
| WHOLE FIGHT GAIN | 0.7 | +17.3 | 84.7 | 0.0 | 0.3 | +3.3 | 0.0 | 42.0 |
| WHOLE FIGHT REACTION | - | - | - | - | 1.7 | +35.1 | 84.7 | 169.7 |
| WOUNDS ON THE RANKS | 6.3 | +212.5 | 0.0 | 0.0 | 2.0 | +19.7 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p24

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 193 | 193 | 130 | 43.33 | +1101 | +8.5 |
| HIS SHOT LIST | 293 | 282 | 57 | 19.00 | +316 | +5.5 |
| HIS SHOTS BY HIS RUN | 291 | 282 | 44 | 14.67 | +334 | +7.6 |
| HOLDER ASSIGNMENT | 48 | 48 | 42 | 14.00 | +2334 | +55.6 |
| FIVE ACTION | 552 | 529 | 41 | 13.67 | +2194 | +53.5 |
| MOVE TO CHARGE COMPUTED | 56 | 47 | 34 | 11.33 | +1187 | +34.9 |
| DEPLOY BY FIGURES | 49 | 49 | 30 | 10.00 | +280 | +9.3 |
| PROMISE BY ITS OWN SUM | 75 | 75 | 30 | 10.00 | -2731 | -91.0 |
| HARD STAY DROPPED | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -1425 | -52.8 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| QUARTER ODDS | 146 | 143 | 26 | 8.67 | +2717 | +104.5 |
| TIME ON OUR SIDE | 162 | 125 | 25 | 8.33 | +55 | +2.2 |
| GOAL WALK | 79 | 77 | 22 | 7.33 | +1171 | +53.2 |
| NEXT CHARGE BY LIST | 34 | 32 | 21 | 7.00 | +889 | +42.3 |
| LEGAL CHARGES ONLY | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| SHOT RISK POINTS | 184 | 181 | 17 | 5.67 | +98 | +5.8 |
| COVER ONCE | 72 | 48 | 15 | 5.00 | +124 | +8.2 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| FOUR ROUNDS | 26 | 25 | 14 | 4.67 | +493 | +35.2 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SET UP BY THE SET | 25 | 25 | 10 | 3.33 | +581 | +58.1 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +243 | +27.0 |
| MEETS IN TIME | 25 | 25 | 8 | 2.67 | +212 | +26.5 |
| NO CHAFF EDGES | 10 | 10 | 8 | 2.67 | +111 | +13.8 |
| PROMISE KNOWS THE FIGHT | 13 | 12 | 8 | 2.67 | -16 | -2.0 |
| CHAFF PASSED | 7 | 7 | 7 | 2.33 | -7 | -1.0 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1184 | +169.1 |
| IDLE COST | 50 | 38 | 7 | 2.33 | +25 | +3.6 |
| CHAFF IN THE MOVE | 11 | 11 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 117 | 114 | 6 | 2.00 | +676 | +112.7 |
| MAIN BODY KEEPS ITS BAND | 6 | 6 | 6 | 2.00 | +2 | +0.3 |
| WOUNDS ON THE RANKS | 25 | 25 | 6 | 2.00 | +27 | +4.5 |
| NEARER NOT NEEDED | 53 | 49 | 5 | 1.67 | +161 | +32.3 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +5 | +1.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +399 | +99.7 |
| EXACT ROUND | 18 | 17 | 4 | 1.33 | +9 | +2.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +197 | +49.2 |
| MARCH CHECK | 7 | 7 | 4 | 1.33 | +140 | +35.0 |
| OVERRUNS AWAY | 11 | 10 | 4 | 1.33 | +72 | +18.1 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +61 | +15.2 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +254 | +63.4 |
| BACKS UP THE FIGHT | 5 | 4 | 3 | 1.00 | +15 | +5.1 |
| CASTING BLOCK | 3 | 3 | 3 | 1.00 | +44 | +14.5 |
| CLEAR LANE AHEAD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 10 | 10 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT COUNTER | 16 | 13 | 3 | 1.00 | +167 | +55.7 |
| RISK BY ARC | 22 | 21 | 3 | 1.00 | +13 | +4.5 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +19 | +6.3 |
| TIED UP BY THE SUM | 6 | 6 | 3 | 1.00 | +98 | +32.7 |
| HIS CHARGE DENIED | 5 | 5 | 2 | 0.67 | +49 | +24.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +430 | +215.1 |
| ONE JOINT FIGURE | 6 | 6 | 2 | 0.67 | +24 | +11.8 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -134 | -67.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +60 | +30.2 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +10 | +4.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 2 | 0.67 | +15 | +7.3 |
| SUPPORT ADDS | 25 | 22 | 2 | 0.67 | +5 | +2.5 |
| SUPPORT WORKED OUT | 25 | 22 | 2 | 0.67 | +5 | +2.5 |
| WHOLE FIGHT DANGER | 18 | 18 | 2 | 0.67 | +356 | +177.8 |
| WHOLE FIGHT REACTION | 5 | 5 | 2 | 0.67 | +24 | +12.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +418 | +417.6 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -224 | -223.6 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +4 | +4.3 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +46 | +45.8 |
| HONEST WORTH | 21 | 20 | 1 | 0.33 | +28 | +27.9 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +110 | +109.9 |
| MISSILES IN THE MOVE | 30 | 22 | 1 | 0.33 | +31 | +30.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -51 | -51.1 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -123 | -123.3 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -8 | -8.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +16 | +15.5 |
| SAME CHARGE LATER | 1 | 1 | 1 | 0.33 | +4 | +3.6 |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 1 | 0.33 | +30 | +29.6 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| SUPPORT NARROWED | 5 | 5 | 1 | 0.33 | -100 | -99.8 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +1 | +0.7 |
| THE FIGHT MOVES | 9 | 9 | 1 | 0.33 | +1 | +0.9 |
| THE ROW IN ITS ORDER | 17 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -51 | -51.4 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.33 | +2 | +2.2 |
| WHO FIGHTS | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +110 | +109.9 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +11 | +10.6 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +13 | +12.9 |
| BACKUP TARGETS | 3 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 7 | 7 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 5 | 5 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 16 | 16 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 64 | 64 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 18 | 17 | 0 | 0.00 | - | - |
| FALLS SHORT | 78 | 63 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 60 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 31 | 30 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| HALF WHEN STILL FLEEING | 8 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 22 | 22 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 84 | 82 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 37 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 45 | 40 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 29 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 27 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 76 | 67 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 73 | 73 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 12 | 0 | 0.00 | - | - |
| MANOEUVRE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 34 | 25 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| NEAR WALKS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 19 | 19 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 36 | 15 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 21 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 266 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 17 | 15 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 8 | 8 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 17 | 17 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 15 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 8 | 8 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 54 | 35 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 56 | 51 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 175 | 164 | 0 | 0.00 | - | - |
| STAY WORTH | 40 | 29 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 5 | 5 | 0 | 0.00 | - | - |
| STUBBORN ONCE | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 268 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |

### Off best figure: nw22-19bea9b-p24

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 6.33 | 91.0 |
| JOB FIRST | gate | 4.33 | 4.33 | 54.5 |
| ARMY TABLE | rule | 2.67 | 3.33 | 46.2 |
| PROMISE KNOWS THE FIGHT | rule | 2.00 | 0.67 | 2.0 |
| JOINT CHARGE NOW | rule | 0.67 | 0.67 | 27.9 |
| CHAFF PASSED | rule | - | 1.00 | 2.3 |
| MAIN BODY KEEPS ITS BAND | rule | - | 1.00 | 48.8 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 7.8 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 67.1 |
| PATHS CROSS | rule | 0.33 | 0.33 | 6.4 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 223.6 |
| NO REASON | gate | - | 0.33 | 7.3 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 51.1 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 123.3 |
| REFUSING RETIRES | rule | 0.33 | - | 8.0 |
| SUPPORT NARROWED | rule | - | 0.33 | 99.8 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 51.4 |

### Plans: nw22-19bea9b-p24

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 82% | 412 | 334 | 81% |
| Mine | join | 2.7 | 100% | 97 | 0 | 0% |
| Mine | move | 36.0 | 94% | 1856 | 0 | 0% |
| Mine | shoot | 0.3 | 0% | 2 | 0 | 0% |
| Mine | support | 1.3 | 100% | 27 | 0 | 0% |
| Opponent | charge | 3.0 | 89% | 578 | 336 | 58% |
| Opponent | move | 38.0 | 96% | 2232 | 0 | 0% |
| Opponent | shoot | 3.7 | 55% | 225 | 151 | 67% |

### Battle groups: nw22-19bea9b-p24

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.0 | 20% | 67% | 0% | - | 0% | 0% | 33% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 0% | 100% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p24

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 88 (9) | 25 | 64 | 52 | 56% | 3.8 | 100 (7) | 0 (1) | 88 (1) | 88 (8) | 88 (1) |
| Mine | Character | 10 | 35 (10) | 35 | 0 | 15 | 20% | 4.5 | 24 (7) | 83 (2) | - | 35 (5) | 41 (4) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Fast Hammer | 8 | 18 (8) | 6 | 12 | 59 | 12% | 3.9 | 7 (3) | 19 (3) | 41 (2) | 11 (2) | 21 (6) |
| Mine | Hammer | 2 | 0 (2) | 0 | 0 | 100 | 0% | 5.5 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 73 | 0% | 2.5 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 50% | 2.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 84 (7) | 84 | 0 | 6 | 0% | 1.9 | 0 (3) | 142 (4) | - | 47 (4) | 132 (3) |
| Opponent | Clean-up | 2 | 28 (2) | 0 | 28 | 0 | 0% | 3.5 | - | 28 (2) | - | - | 28 (2) |
| Opponent | Fast Hammer | 5 | 30 (5) | 3 | 27 | 34 | 0% | 1.2 | 57 (2) | 0 (2) | 17 (1) | 0 (2) | 52 (3) |
| Opponent | Hammer | 11 | 12 (11) | 12 | 0 | 0 | 64% | 4.8 | 0 (4) | 3 (6) | 114 (1) | 0 (4) | 18 (7) |
| Opponent | Shooter | 8 | 41 (8) | 28 | 13 | 42 | 0% | 1.9 | 0 (1) | 41 (4) | 49 (3) | - | 41 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | - | - | - |

### Charged fights: nw22-19bea9b-p24

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 70 | 1.5 | 1.3 | 47 | 176 | -130 | 1 of 3 | 3 of 3 | +140 | -264 |
| Mine | Warriors of Chaos | 1 | 0 | 693 | 4.0 | 1.0 | 173 | 0 | +173 | 1 of 4 | 4 of 4 | - | +173 |
| **Mine** | all armies | 3 | 0 | 278 | 2.3 | 1.1 | 119 | 76 | +43 | 2 of 7 | 7 of 7 | +140 | +27 |
| Opponent | Wood Elf Realms | 3 | 110 | 594 | 4.0 | 1.1 | 148 | 10 | +138 | 5 of 12 | 9 of 12 | +590 | +97 |

### Effective charges: nw22-19bea9b-p24

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 3 | 0 | 0 | 0 | 1 (net -529) | 1 (net +0) | 1 (net +140) | 0 | 0% (0 of 3) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 2 (net +170) | 1 (net +334) | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 12 | 3 (net +43) | 0 | 1 (net +0) | 0 | 2 (net +390) | 5 (net +115) | 1 | 9% (1 of 11) |

### Charged fights, damage counted: nw22-19bea9b-p24

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 50 | 499 | -529 | 0 | 529 | -529 | -1058.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 311 | 182 | +237 | 293 | 80 | +213 | +68.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 559 | 155 | +113 | 149 | 0 | +149 | +26.7 |
| Mine | No odds | 1 | 98 | 19 | +19 | 19 | 0 | +19 | +19.4 |
| Mine | All fights | 7 | 349 | 192 | +43 | 150 | 98 | +52 | +14.9 |
| Opponent | Long shot (under 50%) | 3 | 245 | 368 | +43 | 154 | 72 | +82 | +33.6 |
| Opponent | Effective (55-75%) | 1 | 499 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 349 | 154 | +115 | 120 | 4 | +116 | +33.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 375 | 52 | +390 | 390 | 27 | +363 | +96.9 |
| Opponent | No odds | 1 | 0 | 173 | +173 | 173 | 0 | +173 | - |
| Opponent | All fights | 12 | 311 | 211 | +138 | 168 | 24 | +144 | +46.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p24 | move | 20 | 4 (20%) | 4 (20%) | 1 (5%) | 15 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

# Doctrine scorecard: nw22-19bea9b-p10

### Scorecard: nw22-19bea9b-p10

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | yes | - | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | yes | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 72 |
| L2025 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 1.0 | 3.0 | 2.0 | 0.7 | 0.0 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 67% | 2.5 | 2.0 | 5.0 | 1.0 | 0.3 | 0.0 | 0.0 | 24.0 |

### KPIs: nw22-19bea9b-p10

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 18) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 83% | 100% (3 of 3); on the table 100% | 89% (8 of 9); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 83% | 86% (6 of 7); on the table 86% | 85% (11 of 13); on the table 85% |
| Magic missiles tried each own turn | 50%+ | 20% (6 of 30) | 56% (10 of 18) | 33% (16 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 27% (6 of 22) | 56% (10 of 18) | 40% (16 of 40) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 20% (1 of 5) | - | 20% (1 of 5) |
| Points that never fought | lower | 29% (1724 of 5999) | 38% (2271 of 5999) | 33% (3995 of 11998) |
|   infantry points that never fought | lower | 51% (504 of 993) | 44% (457 of 1037) | 47% (961 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 45% (10 of 22) | 62% (10 of 16) | 53% (20 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (2204 of 5151) | 57% (2583 of 4500) | 50% (4787 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (17%) | 2.7 (100%) | 4.0 (38%) |
| MARCHED: its unit marched | 1.3 (17%) | 0.0 (0%) | 1.3 (12%) |
| IN COMBAT: engaged in combat | 1.7 (21%) | 0.0 (0%) | 1.7 (16%) |
| REAR RANK: in a rear rank | 2.3 (29%) | 0.0 (0%) | 2.3 (22%) |
| GONE: slain | 1.0 (12%) | 0.0 (0%) | 1.0 (9%) |
| NOT OFFERED: not in the cast list | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 1.0 | 0.7 | 5.3 | 1.0 |
| not cast | 7.3 | 1.0 | 5.3 | 10.7 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (11%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (38%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 1.7 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (27%) | 0.0 (0%) | 2.7 (50%) | 2.3 (22%) | 0.0 (0%) |
| GONE: slain | 1.0 (14%) | 0.0 (0%) | 0.0 (0%) | 1.0 (9%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (55%) | 0.0 (0%) | 2.7 (50%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.0 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 100% (2 of 2) | 100% (2 of 2) |
| the unit moved after it | - | 100% (2 of 2) | 100% (2 of 2) |
| it charged on its next turn | - | 50% (1 of 2) | 50% (1 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 50% (1 of 2) | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (34 of 58) | 61% (49 of 80) | 60% (83 of 138) |
|   cavalry | - | 86% (19 of 22) | 86% (19 of 22) |
|   character | 100% (6 of 6) | 0% (0 of 19) | 24% (6 of 25) |
|   chariot | 90% (9 of 10) | - | 90% (9 of 10) |
|   infantry | 35% (12 of 34) | 77% (30 of 39) | 58% (42 of 73) |
|   monster | 88% (7 of 8) | - | 88% (7 of 8) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (12%) | 1.7 (16%) | 2.7 (15%) |
| CHARGED: it charged | 0.3 (4%) | 3.3 (32%) | 3.7 (20%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.3 (54%) | 3.0 (29%) | 7.3 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (17%) | 1.0 (10%) | 2.3 (13%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (8%) | 0.7 (6%) | 1.3 (7%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 1.0 | 84% | 3.5 pts | 22 pts |
| character | 2.0 | 0.7 | 67% | 10.8 pts | 22 pts |
| chariot | 3.0 | 0.7 | 78% | 6.2 pts | 19 pts |
| infantry | 17.3 | 4.0 | 79% | 2.9 pts | 51 pts |
| monster | 2.3 | 1.0 | 71% | 12.6 pts | 29 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 8.0 | 5.3 |
| Charges that made contact a game | 2.3 | 5.0 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.25 contact (28 units) | 0.76 declared, 0.45 contact (29 units) | 0.53 declared, 0.35 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 67% (2 of 3) | - | 67% (2 of 3) |
| Character in a unit | 50% (2 of 4) | 67% (2 of 3) | 0% (0 of 1) | 50% (4 of 8) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 33% (2 of 6) | 50% (4 of 8) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 33% (2 of 6) | - | - | 33% (2 of 6) |
| Monster | 50% (2 of 4) | 67% (2 of 3) | - | 57% (4 of 7) |
| Monstrous | - | 50% (2 of 4) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 52% | 86% (6 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 17% (2 of 12) | 3% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 80% (4 of 5); on the table 80% | 33% (4 of 12) | 31% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 83% (5 of 6); on the table 83% | 17% (1 of 6) | 33% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 75% (9 of 12) | 48% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p10, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 27% (3) | 50% (2) | 33% (5) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p10

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 39% (9 of 23) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (13 of 26) | 35% (7 of 20) |
| Strategy | Support requests answered (helper made contact too) | - | 67% (2 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 86% (6 of 7) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 67% (2 of 3) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 0.7 | 1.0 |
| Movement | Points that never moved of their own | 225.0 | 24.0 |
| Movement | Fights charged into per game | 2.3 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net +195 | 5 of 12, net -173 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 2 of 12, net +210 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +66 | 2 of 12, net -74 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 2 of 12, net +195 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 17.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (15 of 34) | 25% (13 of 51) |
| Shooting | Points destroyed by shooting units | 0.0 | 29.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 2.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 60% (3 of 5) | 0% (0 of 8) |
| Magic | Wounds caused by magic missiles | 1.7 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 0.3 / 0.0 | 1.7 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 592.3 | 213.3 |
| Combat | Points run down | 0.0 | 100.3 |
| Combat | Net points per charged fight, damage counted | +71 | -9 |
| Combat | Net per 100 charger points, damage counted | +39.3 | -3.1 |
| Combat | First round won (charged fights) | 57% | 62% |
| Combat | Net points per charged fight | +71 | -7 |
| Combat | Net points per supported fight / lone fight | - / +71 | -334 / +53 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 7 | 6 of 13 |
| Game | Points lost | 515.3 | 559.0 |
| Game | VP from objectives | 556.7 | 643.3 |
| Game | Lone holders (player turns) | 1.0 | 2.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -5 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1074
- Games not ended: 0; findings 3, warnings 0

### Opponent rules: nw22-19bea9b-p10

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +125.8 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 20.0 | +480.5 | 0.0 | 117.7 | 21.0 | +280.9 | 0.0 | 242.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| BACKS UP THE FIGHT | 0.7 | +98.3 | 0.0 | 0.0 | 1.0 | +152.9 | 0.0 | 43.3 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +6.1 | 0.0 | 0.0 |
| BELL IN A UNIT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 70.0 | 0.0 |
| CAST JOB | 1.3 | +15.3 | 23.3 | 0.0 | 2.0 | +24.6 | 22.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +22.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.7 | -2.4 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 2.3 | -195.3 | 0.0 | 311.0 |
| CHARGE LOSSES | 14.0 | -580.6 | 0.0 | 285.7 | 11.7 | -437.4 | 0.0 | 85.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 87.0 | 0.0 | 3.0 | +0.0 | 306.0 | 130.0 |
| CLEAR LANE AHEAD | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 200.7 | 10.0 | +0.0 | 0.0 | 390.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +73.0 | 0.0 | 0.0 |
| COVER ONCE | 6.3 | -223.8 | 0.0 | 100.3 | 5.0 | -217.7 | 0.0 | 65.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -8.7 | 240.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +18.1 | 0.0 | 0.0 | 8.3 | +77.0 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -113.8 | 0.0 | 180.0 |
| EDGE GIVE GROUND | 0.3 | +16.9 | 65.0 | 0.0 | 0.7 | +21.4 | 85.0 | 65.0 |
| EXACT ROUND | 0.7 | +10.3 | 130.0 | 0.0 | 5.0 | +55.3 | 436.7 | 217.0 |
| FACES WHAT IT FOLLOWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 65.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 65.0 | 0.0 | 6.0 | +4.8 | 428.7 | 417.7 |
| FALLS SHORT | 3.0 | +31.5 | 0.0 | 36.7 | 15.0 | +124.4 | 0.0 | 22.0 |
| FEATURE BUFFS | 0.7 | +3.3 | 0.0 | 0.0 | 0.7 | +3.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +0.7 | 130.0 | 0.0 | 2.0 | +41.2 | 88.3 | 65.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 79.7 | +8060.5 | 435.3 | 877.7 | 93.7 | +6319.4 | 826.0 | 1244.3 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 61.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | - | - | - | - | 1.3 | +29.5 | 73.3 | 20.0 |
| FOLLOW UP WEIGHED | 0.7 | +137.7 | 0.0 | 0.0 | 1.0 | +91.0 | 0.0 | 65.0 |
| FOUR ROUNDS | 1.0 | +32.8 | 152.0 | 0.0 | 8.0 | +437.5 | 525.0 | 463.0 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 244.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -1.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -11.1 | 0.0 | 0.0 | 0.3 | -2.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -17.8 | 0.0 | 0.0 |
| GOAL WALK | 10.0 | +888.9 | 0.0 | 0.0 | 7.0 | +984.2 | 0.0 | 0.0 |
| GUN FIGURES | 3.0 | +163.8 | 0.0 | 61.7 | - | - | - | - |
| HALF WHEN STILL FLEEING | 0.3 | +0.0 | 65.0 | 0.0 | 1.3 | -1.4 | 100.3 | 65.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 43.3 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 244.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HELP BY WHAT IT ADDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 265.0 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 285.7 | 6.0 | +0.0 | 0.0 | 85.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 180.0 |
| HIS MOVE AND SHOT | 6.0 | -47.9 | 0.0 | 0.0 | 5.7 | -77.6 | 0.0 | 22.0 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.3 | +0.0 | 0.0 | 11.3 | 10.7 | +0.0 | 0.0 | 245.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.3 | +0.0 | 0.0 | 30.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 2.3 | +0.0 | 0.0 | 30.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 29.3 | +234.3 | 0.0 | 560.0 | 43.3 | +939.1 | 0.0 | 599.0 |
| HIS SHOTS BY HIS RUN | 42.3 | +192.9 | 0.0 | 651.7 | 36.7 | +672.1 | 0.0 | 182.3 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +50.4 | 340.3 | 22.7 |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 73.3 | 15.3 | +0.0 | 0.0 | 84.0 |
| HOLDER ASSIGNMENT | 8.3 | +563.2 | 0.0 | 36.7 | 10.7 | +849.5 | 0.0 | 62.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -20.7 | 87.0 | 0.0 | 6.0 | -216.7 | 525.0 | 245.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +120.1 | 0.0 | 0.0 |
| IDLE COST | 2.7 | -70.4 | 0.0 | 0.0 | 12.0 | -181.2 | 0.0 | 15.0 |
| INFANTRY NOT BEHIND INFANTRY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 2.3 | +279.7 | 200.7 | 287.7 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.5 | 0.0 | 0.0 | 1.3 | +61.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 223.7 | 96.3 | 2.7 | +0.0 | 0.0 | 98.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | -6.2 | 0.0 | 20.0 |
| LOST AFTER ESCAPE | 0.3 | -0.0 | 65.0 | 0.0 | 3.3 | +3.9 | 162.0 | 332.7 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 100.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | -14.6 | 0.0 | 126.0 | 0.7 | -5.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +61.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +156.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | -125.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 5.0 | +215.9 | 0.0 | 18.3 | 2.3 | +86.0 | 0.0 | 15.0 |
| MEETS IN TIME | 4.3 | +196.4 | 0.0 | 0.0 | 3.3 | +171.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +40.7 | 0.0 | 0.0 | 3.7 | +34.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +45.3 | 0.0 | 0.0 | 4.3 | +19.3 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.0 | -8.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.3 | +281.0 | 0.0 | 11.3 | 8.3 | +767.8 | 0.0 | 108.3 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEAR WALKS ONLY | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 10.3 | +414.6 | 0.0 | 144.3 | 10.0 | +360.6 | 0.0 | 62.0 |
| NEXT CHARGE BY LIST | 2.7 | +112.1 | 23.3 | 0.0 | 5.0 | +507.3 | 0.0 | 20.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -30.0 | 18.3 | 0.0 |
| NO CHAFF EDGES | 2.3 | +60.1 | 237.0 | 225.0 | 3.3 | +97.7 | 544.0 | 310.0 |
| NO DOUBLE ROUNDS | 0.3 | -1.0 | 22.0 | 0.0 | 6.3 | -229.2 | 525.0 | 241.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.3 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.7 | -144.7 | 0.0 | 0.0 | 5.7 | -106.9 | 78.0 | 425.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.7 | -62.9 | 0.0 | 0.0 | 5.3 | -114.3 | 0.0 | 15.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.7 | +343.8 | 0.0 | 287.7 |
| ONE OBJECTIVE FORMULA | 4.0 | -18.0 | 0.0 | 18.3 | 3.7 | +9.9 | 0.0 | 22.0 |
| ONE PROMISE A TARGET | 1.3 | -28.8 | 0.0 | 0.0 | 1.0 | -118.4 | 0.0 | 20.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +2.8 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.0 | +120.4 | 0.0 | 65.0 |
| OPENS UP IN FULL | 0.7 | +20.0 | 87.0 | 0.0 | 3.7 | +199.7 | 425.3 | 375.0 |
| OVERRUNS AWAY | - | - | - | - | 2.3 | +30.8 | 189.7 | 65.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.7 | -5.9 | 0.0 | 18.3 | - | - | - | - |
| PLAN RESULT | 37.0 | +505.5 | 390.0 | 860.3 | 46.0 | +665.5 | 322.0 | 1120.7 |
| PRIZE BY WORTH | - | - | - | - | 1.3 | +124.2 | 0.0 | 65.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 7.3 | -132.6 | 0.0 | 0.0 | 12.3 | -428.3 | 0.0 | 268.3 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 43.3 |
| PROMISE READS THE TABLE | 1.3 | -11.1 | 0.0 | 0.0 | 0.3 | -10.3 | 0.0 | 65.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -2.6 | 0.0 | 0.0 |
| QUARTER ODDS | 18.3 | +2503.9 | 22.0 | 0.0 | 21.3 | +2469.6 | 479.3 | 22.0 |
| RANDOM MOVE BY FIGURES | 1.7 | +26.0 | 0.0 | 140.0 | - | - | - | - |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.7 | +272.2 | 0.0 | 44.0 | 1.3 | +15.1 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +0.0 | 0.0 | 73.7 | 4.0 | +0.0 | 0.0 | 59.7 |
| REDIRECT WEIGHED | - | - | - | - | 1.7 | +32.1 | 61.7 | 65.0 |
| REFORMS TO MEET IT | 1.7 | -116.0 | 0.0 | 11.3 | 1.3 | -14.5 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 180.0 |
| RESERVE FALL BACK | - | - | - | - | 2.0 | +42.4 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | -3.3 | 87.0 | 0.0 | 7.3 | -85.9 | 525.0 | 440.3 |
| RISK ON THE WAY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.7 | -119.2 | 247.0 | 375.0 |
| RUN DOWN | - | - | - | - | 6.3 | -39.1 | 455.0 | 397.7 |
| SCOUT BY DROPS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 1.0 | +6.7 | 0.0 | 0.0 | 0.7 | -0.2 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -32.5 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +5.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +58.1 | 65.0 | 0.0 | 0.3 | +50.5 | 78.0 | 0.0 |
| SELF MOVE SPELL | 1.3 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -187.1 | 0.0 | 0.0 | 0.3 | -1.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +183.5 | 0.0 | 0.0 | 0.7 | +17.4 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +0.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +43.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.0 | +0.0 | 0.0 | 78.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +79.1 | 0.0 | 0.0 | 2.0 | +23.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -8.2 | 111.7 | 22.0 |
| SHOT RISK POINTS | 16.7 | -169.6 | 0.0 | 206.3 | 22.3 | +221.4 | 0.0 | 117.0 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.3 | +441.6 | 0.0 | 265.7 | 16.3 | +108.3 | 0.0 | 84.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +43.3 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 10.0 | +0.0 | 0.0 | 181.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -0.6 | 22.0 | 0.0 | 1.0 | -5.0 | 278.7 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 23.3 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 32.0 | +0.0 | 283.3 | 314.3 | 35.0 | +0.0 | 301.0 | 290.0 |
| STAY WORTH | 10.7 | +115.9 | 0.0 | 0.0 | 17.7 | +77.6 | 301.0 | 62.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.3 | +48.2 | 0.0 | 156.7 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.7 | +1501.4 | 0.0 | 106.3 | 4.0 | +175.5 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 65.0 |
| SUPPORT WORKED OUT | 9.7 | +1501.4 | 0.0 | 106.3 | 4.0 | +175.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +5.5 | 0.0 | 15.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 18.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.3 | -0.0 | 65.0 | 0.0 | 1.7 | +94.0 | 85.0 | 245.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -10.3 | 0.0 | 65.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 65.0 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 65.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.3 | +0.0 | 0.0 | 276.7 | 43.0 | +0.0 | 0.0 | 390.7 |
| TIED UP BY THE SUM | 0.3 | +31.0 | 22.0 | 0.0 | 1.3 | +164.7 | 151.0 | 0.0 |
| TIME ON OUR SIDE | 31.3 | +353.7 | 0.0 | 622.3 | 18.0 | +133.9 | 0.0 | 603.7 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.3 | +0.0 | 130.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -32.5 | 130.0 | 0.0 | 0.7 | +34.9 | 0.0 | 46.7 |
| WHO FIGHTS | - | - | - | - | 2.0 | +12.4 | 100.3 | 217.7 |
| WHO GETS IN | - | - | - | - | 0.7 | +118.0 | 0.0 | 200.0 |
| WHO HITS BACK | 0.3 | +27.8 | 0.0 | 0.0 | 0.7 | +49.7 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +19.5 | 65.0 | 0.0 | 0.3 | +0.8 | 0.0 | 23.3 |
| WHOLE FIGHT DANGER | 3.7 | -426.5 | 0.0 | 285.7 | 1.7 | -192.8 | 0.0 | 20.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.3 | +46.8 | 0.0 | 265.0 |
| WHOLE FIGHT REACTION | 3.0 | +575.8 | 87.7 | 320.0 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.3 | +7.7 | 0.0 | 0.0 | 1.0 | +5.5 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p10

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 123 | 123 | 70 | 23.33 | +1862 | +26.6 |
| HOLDER ASSIGNMENT | 57 | 57 | 50 | 16.67 | +2187 | +43.7 |
| HIS SHOT LIST | 218 | 208 | 34 | 11.33 | +182 | +5.4 |
| HIS SHOTS BY HIS RUN | 237 | 227 | 30 | 10.00 | +249 | +8.3 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -755 | -27.0 |
| MOVE TO CHARGE COMPUTED | 44 | 36 | 27 | 9.00 | +1063 | +39.4 |
| DEPLOY BY FIGURES | 48 | 48 | 24 | 8.00 | +222 | +9.2 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| QUARTER ODDS | 119 | 116 | 22 | 7.33 | +1691 | +76.9 |
| FIVE ACTION | 520 | 502 | 21 | 7.00 | +545 | +25.9 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 59 | 59 | 20 | 6.67 | -1683 | -84.1 |
| LEGAL CHARGES ONLY | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 148 | 126 | 18 | 6.00 | +44 | +2.4 |
| NEXT CHARGE BY LIST | 23 | 23 | 15 | 5.00 | +571 | +38.1 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 14 | 4.67 | +39 | +2.8 |
| GOAL WALK | 51 | 51 | 13 | 4.33 | +1430 | +110.0 |
| SUPPORT ADDS | 41 | 41 | 12 | 4.00 | +855 | +71.2 |
| SUPPORT WORKED OUT | 41 | 41 | 12 | 4.00 | +855 | +71.2 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +668 | +60.8 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| FOUR ROUNDS | 27 | 25 | 9 | 3.00 | +170 | +18.9 |
| NO CHAFF EDGES | 17 | 15 | 9 | 3.00 | +208 | +23.1 |
| CAST JOB | 10 | 10 | 8 | 2.67 | +6 | +0.8 |
| SHOT RISK POINTS | 117 | 110 | 8 | 2.67 | +62 | +7.7 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CLEAR LANE AHEAD | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +839 | +119.9 |
| ONE PROMISE A TARGET | 7 | 7 | 7 | 2.33 | -442 | -63.1 |
| SCOUTS HUNT GUNS ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHARGE LOSSES | 77 | 72 | 6 | 2.00 | +231 | +38.5 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +127 | +21.2 |
| CHARGE NOW FIRST | 13 | 13 | 5 | 1.67 | -365 | -72.9 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +686 | +137.2 |
| IDLE COST | 44 | 29 | 5 | 1.67 | +50 | +9.9 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +190 | +38.0 |
| MAX FOR POSITIONING | 22 | 21 | 5 | 1.67 | +9 | +1.9 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 1.67 | +812 | +162.3 |
| SCOUT BY DROPS | 7 | 7 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 83 | 64 | 5 | 1.67 | +132 | +26.4 |
| SUPPORT NARROWED | 5 | 5 | 5 | 1.67 | -784 | -156.7 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOCUS FIRE | 4 | 4 | 4 | 1.33 | +88 | +22.1 |
| ONE JOINT FIGURE | 5 | 5 | 4 | 1.33 | +486 | +121.5 |
| PRIZE BY WORTH | 4 | 4 | 4 | 1.33 | +373 | +93.1 |
| REDIRECT COUNTER | 18 | 18 | 4 | 1.33 | +156 | +39.0 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +145 | +36.1 |
| TIED UP BY THE SUM | 5 | 4 | 4 | 1.33 | +193 | +48.3 |
| BACKS UP THE FIGHT | 5 | 4 | 3 | 1.00 | +187 | +62.3 |
| COVER ONCE | 34 | 22 | 3 | 1.00 | +40 | +13.4 |
| FIGHT TO THE END | 8 | 7 | 3 | 1.00 | +16 | +5.4 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| NEARER NOT NEEDED | 61 | 50 | 3 | 1.00 | +68 | +22.6 |
| OPENS UP IN FULL | 13 | 11 | 3 | 1.00 | +66 | +22.1 |
| RISK BY ARC | 24 | 22 | 3 | 1.00 | +18 | +5.9 |
| SET UP BY THE SET | 6 | 6 | 3 | 1.00 | +186 | +62.0 |
| WEAPON BY POINTS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +159 | +53.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +377 | +188.7 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +3 | +1.5 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -7 | -3.7 |
| FALLS SHORT | 54 | 45 | 2 | 0.67 | +19 | +9.7 |
| MAIN BODY KEEPS ITS BAND | 2 | 2 | 2 | 0.67 | -28 | -13.9 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +379 | +189.6 |
| MISSILES IN THE MOVE | 19 | 10 | 2 | 0.67 | +19 | +9.6 |
| OPENS A LANE | 2 | 2 | 2 | 0.67 | +8 | +4.1 |
| OVERRUNS AWAY | 7 | 6 | 2 | 0.67 | +11 | +5.6 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -18 | -8.9 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -8 | -4.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +326 | +162.9 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +10 | +5.0 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +2 | +1.0 |
| THE FIGHT MOVES | 6 | 5 | 2 | 0.67 | +11 | +5.5 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +354 | +176.9 |
| WHOLE FIGHT DANGER | 16 | 16 | 2 | 0.67 | +101 | +50.5 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +6.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 17 | 15 | 1 | 0.33 | +1 | +1.4 |
| FACES WHAT IT FOLLOWS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 35 | 34 | 1 | 0.33 | +40 | +39.9 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +133 | +132.6 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | -26 | -26.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +186 | +185.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 20 | 19 | 1 | 0.33 | +38 | +37.9 |
| ONE FIGHT FORMULA | 33 | 21 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 23 | 15 | 1 | 0.33 | +18 | +17.7 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +34 | +33.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 1 | 0.33 | +78 | +77.9 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +16 | +16.1 |
| STAY WORTH | 85 | 72 | 1 | 0.33 | +11 | +11.0 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 6 | 1 | 0.33 | +1 | +1.4 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.33 | +10 | +9.5 |
| WHOLE FIGHT REACTION | 9 | 9 | 1 | 0.33 | +19 | +18.9 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 7 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 48 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 19 | 17 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 14 | 12 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 11 | 10 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 47 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 17 | 17 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 24 | 22 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 54 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 25 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 4 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 80 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 18 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 11 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NEAR WALKS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 11 | 11 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 249 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 10 | 7 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 11 | 11 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 18 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 42 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 17 | 17 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 201 | 195 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 238 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p10

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 4.67 | 27.6 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 4.33 | 84.1 |
| ONE PROMISE A TARGET | rule | 1.33 | 1.00 | 63.1 |
| ARMY TABLE | rule | 0.67 | 1.33 | 70.7 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.33 | 33.8 |
| CHARGE NOW FIRST | rule | 0.33 | 1.33 | 72.9 |
| SUPPORT NARROWED | rule | 1.33 | - | 195.8 |
| NO REASON | gate | - | 1.00 | 30.2 |
| PIVOT GUARDS FLANK | rule | 0.67 | - | 8.9 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 4.0 |
| CHAFF PASSED | rule | - | 0.33 | 6.8 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 2.5 |
| FALLBACK | gate | 0.33 | - | 0.9 |
| INFANTRY NOT BEHIND INFANTRY | rule | 0.33 | - | 26.0 |
| MAIN BODY KEEPS ITS BAND | rule | 0.33 | - | 27.9 |

### Plans: nw22-19bea9b-p10

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 100% | 181 | 152 | 84% |
| Mine | move | 28.7 | 92% | 2049 | 0 | 0% |
| Mine | shoot | 7.0 | 67% | 1031 | 354 | 34% |
| Mine | support | 0.3 | 0% | 0 | 0 | 0% |
| Opponent | charge | 7.3 | 41% | 1019 | 538 | 53% |
| Opponent | join | 1.3 | 100% | 47 | 0 | 0% |
| Opponent | move | 34.0 | 96% | 1465 | 0 | 0% |
| Opponent | shoot | 3.3 | 50% | 326 | 128 | 39% |

### Battle groups: nw22-19bea9b-p10

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 21% | 67% | 33% | 0% | 0% | 0% | 50% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p10

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 73 (1) | 73 | 0 | 0 | 0% | 5.0 | - | 73 (1) | - | - | 73 (1) |
| Mine | Chaff | 7 | 27 (7) | 0 | 27 | 76 | 29% | 3.0 | 40 (4) | 0 (3) | - | 35 (6) | 0 (1) |
| Mine | Character | 7 | 40 (7) | 40 | 0 | 0 | 14% | 3.0 | 35 (5) | 66 (2) | - | 35 (5) | 66 (2) |
| Mine | Clean-up | 4 | 83 (4) | 35 | 48 | 0 | 25% | 3.7 | 66 (1) | 119 (2) | 0 (1) | 66 (1) | 102 (3) |
| Mine | Fast Hammer | 1 | 168 (1) | 168 | 0 | 0 | 0% | 3.0 | - | 168 (1) | - | - | 168 (1) |
| Mine | Hammer | 11 | 23 (11) | 7 | 16 | 54 | 9% | 1.9 | 28 (4) | 20 (6) | 0 (1) | 30 (4) | 18 (7) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 0 | 0% | 4.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 26 (3) | 26 | 0 | 19 | 0% | 2.3 | 9 (1) | 77 (1) | - | 9 (1) | 77 (1) |
| Opponent | Chaff | 8 | 99 (8) | 7 | 92 | 47 | 25% | 1.5 | 129 (3) | 52 (1) | 86 (4) | 129 (3) | 78 (5) |
| Opponent | Character | 8 | 28 (8) | 28 | 0 | 21 | 25% | 3.5 | 26 (6) | 32 (2) | - | 0 (3) | 36 (5) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 53 | 0% | 3.2 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 7 | 39 (7) | 39 | 0 | 46 | 43% | 3.2 | 78 (3) | 5 (4) | - | 40 (2) | 38 (5) |
| Opponent | Holder | 4 | 57 (4) | 0 | 57 | 45 | 0% | 1.8 | 78 (3) | - | 0 (1) | 125 (2) | 0 (2) |
| Opponent | Shooter | 4 | 11 (4) | 11 | 0 | 0 | 0% | 1.0 | 0 (2) | 22 (2) | - | 0 (2) | 22 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (2) | 0 (1) | - | 0 (3) |

### Charged fights: nw22-19bea9b-p10

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 195 | 3.0 | 1.0 | 65 | 0 | +65 | 1 of 3 | 1 of 3 | - | +65 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 456 | 4.0 | 1.0 | 114 | 39 | +75 | 3 of 4 | 3 of 4 | - | +75 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 0 | 217 | 2.3 | 1.0 | 93 | 22 | +71 | 4 of 7 | 4 of 7 | - | +71 |
| Opponent | Tomb Kings of Khemri | 2 | 44 | 415 | 4.5 | 1.1 | 92 | 96 | -4 | 4 of 9 | 6 of 9 | -600 | +70 |
| Opponent | Vampire Counts | 1 | 0 | 210 | 4.0 | 1.2 | 52 | 65 | -12 | 2 of 4 | 2 of 4 | -68 | +6 |
| **Opponent** | all armies | 3 | 30 | 347 | 4.3 | 1.2 | 80 | 87 | -7 | 6 of 13 | 8 of 13 | -334 | +53 |

### Effective charges: nw22-19bea9b-p10

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 3 | 1 (net +195) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 3 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 9 | 4 (net -216) | 0 | 1 (net +255) | 0 | 1 (net +0) | 2 (net +195) | 1 | 12% (1 of 8) |
| Opponent | Vampire Counts | 4 | 1 (net +0) | 0 | 1 (net +165) | 1 (net -68) | 1 (net -147) | 0 | 0 | 25% (1 of 4) |

### Charged fights, damage counted: nw22-19bea9b-p10

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 40 | 195 | +195 | 195 | 0 | +195 | +487.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 350 | 66 | +66 | 77 | 16 | +61 | +17.5 |
| Mine | No odds | 5 | 174 | 213 | +47 | 79 | 31 | +48 | +27.4 |
| Mine | All fights | 7 | 180 | 190 | +71 | 95 | 25 | +71 | +39.3 |
| Opponent | Long shot (under 50%) | 5 | 176 | 257 | -173 | 36 | 173 | -137 | -77.8 |
| Opponent | Effective (55-75%) | 2 | 338 | 222 | +210 | 232 | 22 | +210 | +62.2 |
| Opponent | 76-89% | 1 | 548 | 197 | -68 | 0 | 308 | -308 | -56.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 250 | 144 | +195 | 212 | 40 | +172 | +68.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 289 | 48 | -74 | 30 | 74 | -43 | -15.0 |
| Opponent | No odds | 1 | 431 | 185 | +185 | 205 | 0 | +205 | +47.6 |
| Opponent | All fights | 13 | 278 | 192 | -7 | 103 | 111 | -9 | -3.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p10 | move | 18 | 6 (33%) | 3 (17%) | 4 (22%) | 8 (44%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

# Doctrine scorecard: nw22-19bea9b-p17

### Scorecard: nw22-19bea9b-p17

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | yes | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 295 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 0 | 3 | 0 | 0 | 0 | 290 |
| L0810 | 6 | 1 | Mine | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 380 |
| L0810 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 1 | 2 | 0 | 0 | 0 | 130 |
| L0827 | 5 | 1 | Opponent | yes | - | 1 | 1 | 5 | 0 | 0 | 0 | 75 |
| **Average** | | | Mine | 33% | 1.0 | 2.0 | 2.0 | 2.0 | 0.0 | 0.0 | 0.0 | 268.3 |
| **Average** | | | Opponent | 67% | 5.0 | 1.5 | 0.7 | 2.7 | 0.0 | 0.0 | 0.0 | 231.7 |

### KPIs: nw22-19bea9b-p17

Rules off - Mine only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 56% (9 of 16) | 0% (0 of 16) | 28% (9 of 32) |
| Winner chose to follow up after the loser gave ground |  | 60% (6 of 10); on the table 60% | 75% (3 of 4); on the table 100% | 64% (9 of 14); on the table 71% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 0% | - | 0% (0 of 2); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 50% (6 of 12); on the table 50% | 75% (3 of 4); on the table 100% | 56% (9 of 16); on the table 62% |
| Magic missiles tried each own turn | 50%+ | 83% (5 of 6) | 47% (17 of 36) | 52% (22 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 83% (5 of 6) | 50% (17 of 34) | 55% (22 of 40) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 56% (5 of 9) | 56% (5 of 9) |
| Points that never fought | lower | 71% (4278 of 5999) | 74% (4457 of 5998) | 73% (8735 of 11997) |
|   infantry points that never fought | lower | 100% (968 of 968) | 67% (743 of 1113) | 82% (1711 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (20 of 30) | 72% (18 of 25) | 69% (38 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 1.3 uses a game | 67% (2 of 3); 0.7 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 2); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (3401 of 5378) | 71% (3701 of 5181) | 67% (7102 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (47%) | 3.0 (45%) |
| MARCHED: its unit marched | 0.0 (0%) | 2.0 (32%) | 2.0 (30%) |
| CHARGED: its unit charged | 0.3 (100%) | 0.7 (11%) | 1.0 (15%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (11%) | 0.7 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.3 | 2.0 | 4.7 | 7.3 | 0.7 | 0.3 |
| not cast | 2.7 | 0.0 | 1.3 | 6.7 | 3.3 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.3 (25%) | 3.0 (45%) | 1.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 2.0 (30%) | 1.0 (30%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | - | 0.0 (0%) | 1.0 (15%) | 0.3 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.3 (25%) | 0.7 (10%) | 0.3 (10%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 1.0 (38%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (62%) | - | 0.7 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 27.3 (99%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 4.7 a game | 2.3 a game |
| stood (cast and not dispelled) | - | 71% (10 of 14) | 71% (10 of 14) |
| the unit moved after it | - | 70% (7 of 10) | 70% (7 of 10) |
| it charged on its next turn | - | 20% (2 of 10) | 20% (2 of 10) |
| the enemy charged it first | - | 0% (0 of 10) | 0% (0 of 10) |
| it fought by the end of its next turn | - | 0% (0 of 10) | 0% (0 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 10) | 0% (0 of 10) |
| none of these (no charge, no fight, no charge escaped) | - | 80% (8 of 10) | 80% (8 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (55 of 86) | 73% (22 of 30) | 66% (77 of 116) |
|   cavalry | 77% (17 of 22) | - | 77% (17 of 22) |
|   chariot | 64% (7 of 11) | 82% (9 of 11) | 73% (16 of 22) |
|   infantry | 58% (7 of 12) | 45% (5 of 11) | 52% (12 of 23) |
|   war machine | 59% (24 of 41) | 100% (8 of 8) | 65% (32 of 49) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (13%) | 1.0 (38%) | 2.3 (18%) |
| CHARGED: it charged | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (12%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 1.3 (13%) | 0.0 (0%) | 1.3 (10%) |
| MOVED: a war machine that moved | 2.7 (26%) | 0.0 (0%) | 2.7 (21%) |
| NO TARGET IN RANGE | 1.3 (13%) | 1.3 (50%) | 2.7 (21%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (23%) | 0.0 (0%) | 2.3 (18%) |
| SHELTERED: the target was sheltered | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.0 | 5.3 | 76% | 15.0 pts | 165 pts |
| chariot | 5.3 | 1.3 | 81% | 10.8 pts | 58 pts |
| infantry | 4.0 | 1.7 | 58% | 19.4 pts | 78 pts |
| war machine | 11.3 | 11.0 | 53% | 20.9 pts | 237 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 3.7 | 3.2 |
| Charges that made contact a game | 2.0 | 2.0 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.00 contact (1 units) | 0.75 declared, 0.50 contact (4 units) | 0.80 declared, 0.40 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.27 contact (22 units) | 0.38 declared, 0.19 contact (21 units) | 0.35 declared, 0.23 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (4 of 9) | 67% (2 of 3) | 100% (1 of 1) | 54% (7 of 13) |
| Character in a unit | 100% (9 of 9) | - | 100% (1 of 1) | 100% (10 of 10) |
| Character on its own | 50% (1 of 2) | 50% (1 of 2) | 33% (1 of 3) | 43% (3 of 7) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 33% (1 of 3) | 100% (1 of 1) | 50% (1 of 2) | 50% (3 of 6) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 69% (9 of 13) | - | - | 69% (9 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 50% (6 of 12); on the table 50% | 83% (5 of 6) | 71% | 67% (20 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 33% (1 of 3); 0.3 uses a game |
| Grand Cathay | 1 | - | 50% (12 of 24) | 73% | 40% (4 of 10) | 50% (1 of 2); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 100% | 50% (3 of 6) | 64% | 89% (8 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 86% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p17, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 50% (2) | 43% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 1.00 | 0.00 | 1.00 |

### Quality by phase: nw22-19bea9b-p17

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 62% (5 of 8) | 60% (6 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (12 of 41) | 42% (10 of 24) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 25% (1 of 4) | - |
| Strategy | Joined characters whose unit fought | 14% (1 of 7) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 14% (1 of 7) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 2.0 | 2.7 |
| Movement | Points that never moved of their own | 268.3 | 231.7 |
| Movement | Fights charged into per game | 2.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 3 of 5, net +88 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +0 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +0 | 1 of 5, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (19 of 32) | 71% (10 of 14) |
| Shooting | Points destroyed by shooting units | 97.7 | 0.0 |
| Shooting | War machine shots | 8.0 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 17% (4 of 24) | 62% (5 of 8) |
| Shooting | Points destroyed by war machines | 53.7 | 85.0 |
| Magic | Magic missiles cast | 1.3 | 4.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | 54% (7 of 13) |
| Magic | Wounds caused by magic missiles | 1.0 | 3.7 |
| Magic | Points destroyed by magic (all spells) | 21.7 | 99.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.3 / 0.0 / 0.0 | 3.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 149.0 | 88.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +99 | +64 |
| Combat | Net per 100 charger points, damage counted | +54.2 | +31.7 |
| Combat | First round won (charged fights) | 100% | 60% |
| Combat | Net points per charged fight | +102 | +53 |
| Combat | Net points per supported fight / lone fight | - / +102 | +0 / +66 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 6 | 4 of 5 |
| Game | Points lost | 401.3 | 502.7 |
| Game | VP from objectives | 746.7 | 576.7 |
| Game | Lone holders (player turns) | 1.0 | 5.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +208 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 904
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: nw22-19bea9b-p17

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +58.8 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 8.0 | -218.4 | 0.0 | 0.0 | 16.7 | -23.3 | 0.0 | 197.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 43.3 | 0.7 | +0.0 | 0.0 | 55.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.6 | 0.0 | 0.0 |
| BACKS UP THE FIGHT | 1.3 | +43.2 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| BELL IN A UNIT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.3 | +0.0 | 43.3 | 55.0 |
| CANNON PLANNED TARGET | 7.0 | +178.9 | 185.7 | 130.0 | 2.7 | +219.6 | 260.0 | 110.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.7 | -31.0 | 30.7 | 0.0 | 0.7 | -5.9 | 41.7 | 0.0 |
| CAST JOB | 2.0 | +86.5 | 140.0 | 0.0 | 3.7 | +170.9 | 483.7 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +61.4 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | - | - | - | - | 0.3 | -12.6 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +32.5 | 0.0 | 0.0 |
| CHARGE LOSSES | 14.0 | -950.3 | 0.0 | 176.7 | 15.7 | -915.9 | 0.0 | 520.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 100.0 | 0.0 | 2.0 | +0.0 | 41.7 | 0.0 |
| CLEAR LANE AHEAD | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 197.7 |
| CONVEYANCE SEARCH | - | - | - | - | 4.0 | +289.7 | 0.0 | 0.0 |
| COVER ONCE | 5.3 | -390.9 | 0.0 | 133.3 | 6.3 | -384.9 | 0.0 | 243.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -7.2 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | -27.3 | 0.0 | 41.7 | 7.0 | +33.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -28.0 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +4.8 | 86.3 | 0.0 | 3.3 | +13.3 | 130.0 | 0.0 |
| FACES WHAT IT FOLLOWS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +13.9 | 81.7 | 0.0 | 3.3 | +4.4 | 130.0 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +5.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 1.3 | +15.9 | 0.0 | 0.0 | 23.3 | +368.5 | 0.0 | 193.0 |
| FEATURE BUFFS | 0.7 | +11.1 | 0.0 | 0.0 | 0.7 | +5.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +0.0 | 68.0 | 0.0 | 2.3 | +139.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 54.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 93.0 | +5244.7 | 1400.3 | 726.0 | 83.0 | +5274.6 | 1691.3 | 1022.7 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 13.7 |
| FOLLOW UP WEIGHED | 1.3 | +107.5 | 0.0 | 0.0 | 0.7 | +208.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +180.7 | 100.0 | 0.0 | 3.7 | +339.2 | 130.0 | 0.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 135.0 |
| FRIEND SHOOTS FIRST | 3.3 | -135.5 | 84.0 | 0.0 | 1.0 | -26.7 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -9.5 | 0.0 | 0.0 |
| GOAL WALK | 8.0 | +540.5 | 0.0 | 0.0 | 15.0 | +1252.0 | 0.0 | 330.3 |
| GUN FIGURES | 2.3 | +0.0 | 0.0 | 88.3 | 1.0 | +54.6 | 0.0 | 43.3 |
| GUN MASK | - | - | - | - | 1.3 | +5.6 | 0.0 | 111.3 |
| HALF WHEN STILL FLEEING | 0.3 | -0.9 | 0.0 | 0.0 | 1.0 | +0.6 | 88.3 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 42.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 65.0 |
| HELP BY WHAT IT ADDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 176.7 | 9.7 | +0.0 | 0.0 | 520.3 |
| HIS CHARGE DENIED | 0.3 | +3.2 | 0.0 | 0.0 | 0.3 | +18.8 | 0.0 | 0.0 |
| HIS CHARGE LIST | 9.0 | +0.0 | 0.0 | 90.0 | 3.0 | +0.0 | 0.0 | 30.7 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.0 | -170.1 | 0.0 | 0.0 | 2.3 | -40.9 | 0.0 | 234.3 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 65.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.7 | +991.0 | 0.0 | 356.7 | 44.0 | +2388.0 | 0.0 | 422.7 |
| HIS SHOTS BY HIS RUN | 26.7 | +570.7 | 0.0 | 266.7 | 42.3 | +1349.1 | 0.0 | 647.7 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +171.0 | 41.7 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 0.0 | 13.7 | +0.0 | 0.0 | 172.7 |
| HOLDER ASSIGNMENT | 10.0 | +985.4 | 0.0 | 0.0 | 9.3 | +806.8 | 0.0 | 86.3 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -66.0 | 100.0 | 0.0 | 3.3 | -102.9 | 130.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +41.1 | 0.0 | 0.0 |
| IDLE COST | 1.3 | -10.9 | 0.0 | 0.0 | 14.3 | -139.8 | 0.0 | 131.0 |
| JOINT CHARGE NOW | 0.3 | +2.4 | 0.0 | 0.0 | 1.0 | -77.0 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +2.5 | 0.0 | 0.0 | 1.0 | +47.3 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 30.7 | 0.0 | 4.0 | +0.0 | 54.7 | 30.7 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.9 | 51.0 | 0.0 | 1.3 | +0.3 | 88.3 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.7 | +11.5 | 0.0 | 0.0 | 1.7 | +17.2 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +1.1 | 0.0 | 0.0 | 1.7 | +1.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +5.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +51.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +13.1 | 0.0 | 55.7 |
| MARCH OF THE TABLE | - | - | - | - | 1.3 | +36.9 | 0.0 | 55.7 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | -48.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +34.9 | 0.0 | 0.0 | 5.0 | +120.7 | 0.0 | 13.7 |
| MEETS IN TIME | 4.0 | +381.0 | 0.0 | 0.0 | 3.0 | +174.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +61.3 | 0.0 | 0.0 | 6.7 | +209.2 | 0.0 | 55.7 |
| MISSILES NEXT TURN | 1.3 | +28.5 | 0.0 | 0.0 | 9.7 | +161.2 | 0.0 | 111.3 |
| MISSILES ON ONE TARGET | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 13.7 | 18.3 |
| MOVE SPELL SPOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +453.0 | 0.0 | 0.0 | 6.0 | +490.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +305.9 | 0.0 | 0.0 | 4.0 | +152.4 | 0.0 | 30.7 |
| NEXT CHARGE BY LIST | 5.0 | +409.1 | 180.7 | 0.0 | 2.7 | +225.9 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.7 | +34.6 | 0.0 | 0.0 | 1.7 | +31.4 | 130.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -50.6 | 100.0 | 0.0 | 2.0 | -66.1 | 41.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 1.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.3 | -232.4 | 0.0 | 41.7 | 3.3 | -125.8 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.0 | +73.2 | 85.0 | 55.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -89.2 | 0.0 | 143.0 | 4.7 | -101.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +26.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.7 | +10.3 | 0.0 | 0.0 | 5.3 | +31.0 | 0.0 | 86.3 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +29.2 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 0.3 | +29.2 | 0.0 | 0.0 | 1.0 | +16.1 | 130.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +35.3 | 32.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 41.3 | +780.3 | 629.0 | 551.0 | 42.3 | +511.0 | 623.0 | 690.7 |
| PRIZE BY WORTH | 0.7 | +62.8 | 48.3 | 0.0 | - | - | - | - |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.3 | -235.7 | 0.0 | 0.0 | 7.7 | -134.8 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.0 | +0.0 | 84.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.0 | -40.4 | 0.0 | 0.0 | 1.3 | -72.3 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 2.0 | -17.4 | 320.7 | 109.3 | - | - | - | - |
| QUARTER ODDS | 20.3 | +1679.3 | 108.3 | 0.0 | 10.7 | +953.1 | 0.0 | 86.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +5.5 | 0.0 | 263.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +133.9 | 0.0 | 32.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 13.7 |
| REDIRECT WEIGHED | 0.7 | +18.6 | 48.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -0.7 | 0.0 | 0.0 | 1.0 | -1.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | -23.5 | 100.0 | 0.0 | 1.3 | -15.4 | 130.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -10.9 | 0.0 | 0.0 |
| RUN DOWN | 2.0 | -7.7 | 100.0 | 0.0 | 1.3 | -15.2 | 41.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -17.8 | 48.3 | 0.0 | - | - | - | - |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCOUTS HUNT GUNS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -50.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +36.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.3 | -9.9 | 0.0 | 0.0 | 0.7 | -19.4 | 0.0 | 15.0 |
| SET UP BY THE SET | 1.0 | +46.7 | 0.0 | 0.0 | 0.7 | +13.0 | 0.0 | 15.0 |
| SET UP TOGETHER | 1.7 | +11.5 | 0.0 | 0.0 | 1.7 | +17.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 1.3 | +179.9 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.7 | +95.1 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.7 | +0.0 | 0.0 | 184.7 | 8.0 | +0.0 | 0.0 | 152.0 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +4.9 | 21.7 | 0.0 | 4.3 | +180.9 | 462.7 | 21.7 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -111.2 | 176.7 | 0.0 |
| SHOT RISK POINTS | 18.0 | -52.6 | 0.0 | 90.0 | 30.7 | +71.5 | 0.0 | 579.7 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.3 | +799.8 | 0.0 | 363.0 | 7.0 | +489.8 | 0.0 | 153.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 1.3 | +179.9 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +1.8 | 0.0 | 0.0 | 5.0 | +41.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +0.7 | 18.3 | 0.0 | 0.7 | +8.6 | 130.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 149.0 |
| STAND AND SHOOT | 0.3 | -6.2 | 0.0 | 0.0 | 0.3 | -3.9 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 55.3 | +0.0 | 1300.3 | 549.3 | 26.3 | +0.0 | 1561.3 | 386.7 |
| STAY WORTH | 32.7 | +474.6 | 1064.0 | 345.0 | 11.7 | +199.1 | 745.3 | 351.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +1.4 | 0.0 | 0.0 |
| STRONG ENOUGH TO HOLD | 0.7 | -5.9 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +194.8 | 0.0 | 0.0 | 3.7 | +152.3 | 0.0 | 27.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 18.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +194.8 | 0.0 | 0.0 | 3.7 | +152.3 | 0.0 | 27.3 |
| SURE REACH TOGETHER | 1.3 | +16.8 | 0.0 | 0.0 | 1.0 | +5.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 13.7 |
| THE FIGHT MOVES | 0.7 | -0.1 | 68.0 | 0.0 | 1.0 | +0.6 | 88.3 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -94.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 30.7 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 30.7 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 77.3 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 77.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.0 | +0.0 | 0.0 | 273.0 | 40.3 | +0.0 | 0.0 | 421.7 |
| TIED UP BY THE SUM | 1.0 | +67.2 | 32.0 | 0.0 | 0.3 | +42.3 | 41.7 | 0.0 |
| TIME ON OUR SIDE | 40.3 | +482.0 | 0.0 | 143.0 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 286.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.3 | +33.8 | 0.0 | 0.0 | 1.3 | -50.5 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 2.0 | +69.4 | 0.0 | 0.0 |
| WHO GETS IN | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.7 | +11.8 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -264.3 | 0.0 | 176.7 | 4.3 | -400.8 | 0.0 | 236.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +86.3 | 0.0 | 0.0 |
| WHOLE FIGHT REACTION | 1.3 | +67.9 | 0.0 | 41.7 | 1.7 | +33.7 | 0.0 | 100.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.3 | +31.3 | 0.0 | 0.0 | 3.7 | +105.0 | 0.0 | 222.7 |

### Rule changes: nw22-19bea9b-p17

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 58 | 58 | 51 | 17.00 | +4805 | +94.2 |
| ARMY TABLE | 74 | 74 | 49 | 16.33 | -701 | -14.3 |
| HIS SHOT LIST | 227 | 220 | 44 | 14.67 | +670 | +15.2 |
| HIS SHOTS BY HIS RUN | 207 | 202 | 43 | 14.33 | +562 | +13.1 |
| FIVE ACTION | 528 | 515 | 40 | 13.33 | +1971 | +49.3 |
| TIME ON OUR SIDE | 121 | 106 | 26 | 8.67 | +84 | +3.2 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +417 | +16.7 |
| MOVE TO CHARGE COMPUTED | 34 | 29 | 23 | 7.67 | +730 | +31.7 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -1075 | -46.7 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| SHOT RISK POINTS | 146 | 142 | 19 | 6.33 | +379 | +20.0 |
| LEGAL CHARGES ONLY | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 69 | 67 | 15 | 5.00 | +1373 | +91.5 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 15 | 5.00 | -1112 | -74.1 |
| QUARTER ODDS | 93 | 89 | 15 | 5.00 | +1272 | +84.8 |
| CAST JOB | 17 | 17 | 13 | 4.33 | +334 | +25.7 |
| IDLE COST | 47 | 36 | 12 | 4.00 | +64 | +5.3 |
| NEXT CHARGE BY LIST | 23 | 19 | 12 | 4.00 | +365 | +30.4 |
| MEETS IN TIME | 21 | 21 | 11 | 3.67 | +583 | +53.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 9 | 3.00 | +157 | +17.5 |
| SHOTS IN THE MOVE | 79 | 59 | 9 | 3.00 | +341 | +37.9 |
| CHARGE NOW FIRST | 10 | 10 | 8 | 2.67 | -496 | -61.9 |
| NO CHAFF EDGES | 10 | 9 | 8 | 2.67 | +159 | +19.8 |
| COVER ONCE | 35 | 23 | 7 | 2.33 | +12 | +1.8 |
| MAX FOR POSITIONING | 23 | 23 | 7 | 2.33 | +13 | +1.9 |
| STAY WORTH | 133 | 118 | 7 | 2.33 | +151 | +21.5 |
| FALLS SHORT | 74 | 50 | 6 | 2.00 | +41 | +6.8 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +949 | +158.2 |
| FOUR ROUNDS | 19 | 15 | 6 | 2.00 | +372 | +62.0 |
| MAIN BODY KEEPS ITS BAND | 6 | 6 | 6 | 2.00 | +1185 | +197.6 |
| PROMISE SHOT AWAY | 6 | 6 | 6 | 2.00 | -52 | -8.7 |
| CHARGE LOSSES | 89 | 85 | 5 | 1.67 | +247 | +49.4 |
| CLEAR LANE AHEAD | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 5 | 1.67 | +17 | +3.3 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 4 | 1.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -224 | -56.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +150 | +37.4 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -111 | -27.7 |
| WHOLE FIGHT DANGER | 19 | 17 | 4 | 1.33 | +111 | +27.8 |
| CARRIES OUT SET-UP | 4 | 4 | 3 | 1.00 | -111 | -36.9 |
| FACES WHAT IT FOLLOWS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +220 | +73.2 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +745 | +248.3 |
| SCOUT BY DROPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 23 | 23 | 3 | 1.00 | +0 | +0.0 |
| SURE REACH TOGETHER | 7 | 7 | 3 | 1.00 | +6 | +1.8 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +231 | +77.0 |
| WOUNDS ON THE RANKS | 15 | 15 | 3 | 1.00 | +59 | +19.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +176 | +88.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIGHT TO THE END | 9 | 6 | 2 | 0.67 | +25 | +12.7 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 4 | 4 | 2 | 0.67 | +8 | +4.0 |
| HIS MOVE AND SHOT | 22 | 22 | 2 | 0.67 | +98 | +49.1 |
| HIS TURN DENIED | 5 | 4 | 2 | 0.67 | +110 | +54.8 |
| MANOEUVRE | 7 | 7 | 2 | 0.67 | +9 | +4.5 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +155 | +77.4 |
| ONE OBJECTIVE FORMULA | 27 | 20 | 2 | 0.67 | +164 | +81.9 |
| PRIZE BY WORTH | 2 | 2 | 2 | 0.67 | +188 | +94.2 |
| REDIRECT COUNTER | 5 | 3 | 2 | 0.67 | +199 | +99.5 |
| RISK BY ARC | 11 | 9 | 2 | 0.67 | +15 | +7.7 |
| SCOUTS HUNT GUNS ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +4 | +2.1 |
| SUPPORT ADDS | 18 | 17 | 2 | 0.67 | +225 | +112.7 |
| SUPPORT WORKED OUT | 18 | 17 | 2 | 0.67 | +225 | +112.7 |
| WHOLE FIGHT REACTION | 9 | 9 | 2 | 0.67 | +48 | +23.8 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.9 |
| BACKS UP THE FIGHT | 6 | 5 | 1 | 0.33 | +16 | +16.2 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 29 | 29 | 1 | 0.33 | +56 | +56.1 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +98 | +97.6 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -114 | -114.2 |
| EXACT ROUND | 16 | 14 | 1 | 0.33 | +9 | +9.1 |
| FALLBACK BY WORTH | 2 | 2 | 1 | 0.33 | +15 | +15.1 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +0 | +0.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +92 | +92.2 |
| MISSILES IN THE MOVE | 25 | 18 | 1 | 0.33 | +7 | +7.3 |
| NO DOUBLE ROUNDS | 12 | 10 | 1 | 0.33 | +1 | +0.9 |
| ONE FIGHT FORMULA | 29 | 12 | 1 | 0.33 | +3 | +3.2 |
| OPENS UP IN FULL | 4 | 3 | 1 | 0.33 | +9 | +9.1 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +53 | +52.7 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +4 | +4.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -4 | -3.6 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +7 | +7.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +110 | +110.3 |
| SET UP TOGETHER | 10 | 2 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 3 | 3 | 1 | 0.33 | +9 | +9.1 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -32 | -31.5 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 5 | 1 | 0.33 | +10 | +10.4 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +7 | +7.2 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 10 | trace | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 17 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 21 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 13 | 12 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 4 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 13 | 0 | 0.00 | - | - |
| HELP BY WHAT IT ADDS | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 54 | 52 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 36 | 35 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 10 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 18 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 88 | 0 | 0.00 | - | - |
| HONEST WORTH | 18 | 14 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 10 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 33 | 20 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 34 | 31 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 3 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 251 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 8 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 7 | 7 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 7 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 5 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 65 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 33 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 245 | 240 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE FIGHT MOVES | 5 | 3 | 0 | 0.00 | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 241 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 6 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 8 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p17

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 3.00 | 48.3 |
| ARMY TABLE | rule | 2.00 | 3.67 | 76.1 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 2.67 | 74.1 |
| CHARGE NOW FIRST | rule | 1.33 | 1.33 | 61.9 |
| PROMISE SHOT AWAY | rule | 2.00 | - | 8.7 |
| MARCH OF THE TABLE | rule | - | 1.33 | 27.7 |
| CARRIES OUT SET-UP | rule | 0.67 | 0.33 | 36.9 |
| JOINT CHARGE NOW | rule | - | 0.67 | 165.2 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 114.2 |
| NO REASON | gate | - | 0.33 | 12.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 3.6 |
| SUPPORT NARROWED | rule | - | 0.33 | 31.5 |

### Plans: nw22-19bea9b-p17

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 231 | 115 | 50% |
| Mine | join | 0.7 | 100% | 9 | 0 | 0% |
| Mine | move | 26.7 | 98% | 1114 | 0 | 0% |
| Mine | shoot | 11.7 | 71% | 864 | 665 | 77% |
| Opponent | charge | 2.7 | 25% | 492 | 108 | 22% |
| Opponent | join | 2.7 | 88% | 102 | 0 | 0% |
| Opponent | move | 29.3 | 93% | 1465 | 0 | 0% |
| Opponent | shoot | 7.0 | 67% | 424 | 403 | 95% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: nw22-19bea9b-p17

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 40% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p17

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | - | 0 (2) |
| Mine | Character | 12 | 14 (12) | 14 | 0 | 0 | 75% | 2.7 | 0 (3) | 22 (7) | 13 (2) | 8 (5) | 21 (7) |
| Mine | Fast Hammer | 5 | 62 (5) | 33 | 29 | 0 | 40% | 2.0 | 54 (3) | 71 (2) | - | 62 (5) | - |
| Mine | Hammer | 4 | 28 (4) | 0 | 28 | 21 | 50% | 1.0 | 0 (1) | 40 (3) | - | 0 (2) | 49 (2) |
| Mine | Shooter | 5 | 52 (5) | 43 | 9 | 24 | 0% | 1.4 | 18 (2) | 0 (1) | 105 (2) | 68 (4) | 0 (1) |
| Mine | War machine | 11 | 11 (11) | 11 | 0 | 55 | 18% | 1.2 | 0 (2) | 14 (9) | - | 0 (2) | 14 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 59 | 100% | - | 0 (3) | 0 (1) | 0 (1) | 0 (5) | - |
| Opponent | Character | 10 | 28 (10) | 28 | 0 | 6 | 50% | 2.2 | 0 (3) | 0 (4) | 80 (2) | 12 (7) | 86 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 6 | 25 (6) | 0 | 25 | 14 | 67% | 2.0 | 3 (4) | 78 (2) | - | 65 (3) | 0 (3) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Hammer | 4 | 0 (4) | 0 | 0 | 69 | 25% | 2.7 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Opponent | Holder | 4 | 99 (4) | 0 | 99 | 42 | 25% | 3.3 | - | 88 (2) | 106 (2) | 99 (4) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.5 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | War machine | 2 | 77 (2) | 77 | 0 | 50 | 0% | 1.0 | 155 (1) | 0 (1) | - | - | 77 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.3 | 0 (2) | 0 (1) | - | 0 (3) | - |

### Charged fights: nw22-19bea9b-p17

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 173 | 205 | 2.0 | 1.0 | 102 | 0 | +102 | 0 of 6 | 6 of 6 | - | +102 |
| Opponent | Grand Cathay | 1 | 554 | 265 | 2.0 | 1.0 | 132 | 0 | +132 | 1 of 2 | 1 of 2 | - | +132 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 0 | +0 | 3 of 3 | 2 of 3 | +0 | +0 |
| **Opponent** | all armies | 3 | 185 | 88 | 1.7 | 1.2 | 53 | 0 | +53 | 4 of 5 | 3 of 5 | +0 | +66 |

### Effective charges: nw22-19bea9b-p17

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 6 | 0 | 0 | 0 | 2 (net +207) | 1 (net +0) | 2 (net +0) | 1 | 0% (0 of 5) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 2 (net +132) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Opponent | Vampire Counts | 3 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: nw22-19bea9b-p17

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 189 | 102 | +207 | 207 | 0 | +207 | +109.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 176 | 149 | +0 | 22 | 21 | +1 | +0.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 189 | 41 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 1 | 181 | 145 | +200 | 225 | 45 | +180 | +99.4 |
| Mine | All fights | 6 | 184 | 115 | +102 | 114 | 15 | +99 | +54.2 |
| Opponent | 50-54% | 1 | 54 | 265 | +0 | 0 | 36 | -36 | -66.7 |
| Opponent | Effective (55-75%) | 3 | 242 | 210 | +88 | 183 | 64 | +119 | +49.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 236 | 265 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 5 | 203 | 232 | +53 | 110 | 46 | +64 | +31.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p17 | move | 19 | 7 (37%) | 5 (26%) | 2 (11%) | 10 (53%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

# Doctrine scorecard: nw22-19bea9b-p30

### Scorecard: nw22-19bea9b-p30

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 11 | 3 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 162 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 10 | 3 | 0 | 0 | 0 | 0 | 0 | 165 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 3.3 | 3.0 | 0.0 | 1.0 | 0.0 | 0.0 | 0.0 | 249.0 |
| **Average** | | | Opponent | 0% | 4.7 | 2.5 | 1.7 | 2.3 | 0.3 | 0.0 | 0.0 | 143.3 |

### KPIs: nw22-19bea9b-p30

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 50% (6 of 12) | 0% (0 of 12) | 25% (6 of 24) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Magic missiles tried each own turn | 50%+ | 40% (19 of 48) | 25% (3 of 12) | 37% (22 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (19 of 39) | 33% (3 of 9) | 46% (22 of 48) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (9 of 12) | 75% (9 of 12) |
| Points that never fought | lower | 74% (4457 of 5997) | 75% (4522 of 5999) | 75% (8979 of 11996) |
|   infantry points that never fought | lower | 82% (1298 of 1591) | 76% (1265 of 1660) | 79% (2563 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (19 of 34) | 70% (16 of 23) | 61% (35 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.0 uses a game | 100% (2 of 2); 3.3 uses a game | 100% (4 of 4); 3.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (3113 of 5667) | 70% (3596 of 5150) | 62% (6709 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.3 (34%) | 1.7 (56%) | 5.0 (39%) |
| MARCHED: its unit marched | 3.0 (31%) | 0.0 (0%) | 3.0 (24%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 2.0 (21%) | 0.0 (0%) | 2.0 (16%) |
| GONE: slain | 1.0 (10%) | 1.0 (33%) | 2.0 (16%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (11%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 4.7 | 1.0 | 7.3 | 0.3 | 1.3 |
| not cast | 1.0 | 3.0 | 1.0 | 12.7 | 1.7 | 18.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (89%) | 0.0 (0%) | 5.0 (39%) | 0.7 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (24%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (16%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 1.0 (100%) | 0.0 (0%) | 1.0 (100%) | 2.0 (16%) | 0.0 (0%) | 2.7 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 100% (3 of 3) | 100% (3 of 3) |
| the unit moved after it | - | 33% (1 of 3) | 33% (1 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (81 of 120) | 73% (41 of 56) | 69% (122 of 176) |
|   character | 100% (7 of 7) | 43% (6 of 14) | 62% (13 of 21) |
|   chariot | 72% (13 of 18) | 67% (4 of 6) | 71% (17 of 24) |
|   infantry | 53% (26 of 49) | 79% (19 of 24) | 62% (45 of 73) |
|   monster | 50% (2 of 4) | - | 50% (2 of 4) |
|   war machine | 79% (33 of 42) | 100% (12 of 12) | 83% (45 of 54) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (28%) | 2.0 (40%) | 5.7 (31%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (20%) | 1.0 (6%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.7 (13%) | 0.0 (0%) | 1.7 (9%) |
| NO TARGET IN RANGE | 3.0 (23%) | 1.3 (27%) | 4.3 (24%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.7 (28%) | 0.7 (13%) | 4.3 (24%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 6.0 | 0.7 | 89% | 1.4 pts | 9 pts |
| chariot | 5.7 | 4.3 | 65% | 32.5 pts | 184 pts |
| infantry | 19.0 | 10.3 | 68% | 8.5 pts | 162 pts |
| monster | 1.0 | 0.3 | 67% | 10.1 pts | 10 pts |
| war machine | 15.3 | 14.3 | 59% | 27.5 pts | 422 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 1.7 | 1.8 |
| Charges that made contact a game | 1.7 | 0.7 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.67 declared, 1.33 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.25 declared, 1.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (20 units) | 0.22 declared, 0.09 contact (23 units) | 0.14 declared, 0.07 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Character in a unit | 100% (5 of 5) | 100% (2 of 2) | 100% (1 of 1) | 100% (8 of 8) |
| Character on its own | 100% (2 of 2) | 25% (1 of 4) | 33% (1 of 3) | 44% (4 of 9) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 21% (3 of 14) | 75% (3 of 4) | - | 33% (6 of 18) |
| Monster | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 62% (5 of 8) | - | - | 62% (5 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 42% (10 of 24) | 88% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 38% (9 of 24) | 46% | 40% (4 of 10) | 100% (2 of 2); 9.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 88% | 50% (4 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | - | 50% (3 of 6) | 47% | 89% (8 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 91% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p30, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: nw22-19bea9b-p30

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 6) | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (19 of 50) | 68% (15 of 22) |
| Strategy | Support requests answered (helper made contact too) | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (5 of 5) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 7) | 50% (2 of 4) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 249.0 | 143.3 |
| Movement | Fights charged into per game | 0.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +140 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 1 of 1, net +104 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.0 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (22 of 48) | 63% (19 of 30) |
| Shooting | Points destroyed by shooting units | 83.0 | 41.7 |
| Shooting | War machine shots | 11.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (21 of 33) | 58% (7 of 12) |
| Shooting | Points destroyed by war machines | 391.7 | 0.0 |
| Magic | Magic missiles cast | 3.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (5 of 11) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 9.0 | 3.0 |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 48.3 | 75.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.7 / 0.7 / 0.0 | 2.7 / 1.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 46.7 | 92.3 |
| Combat | Points run down | 0.0 | 90.7 |
| Combat | Net points per charged fight, damage counted | +108 | +226 |
| Combat | Net per 100 charger points, damage counted | +14.9 | +107.7 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +70 | +190 |
| Combat | Net points per supported fight / lone fight | +140 / +0 | - / +190 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 0 of 2 |
| Game | Points lost | 343.3 | 638.7 |
| Game | VP from objectives | 770.0 | 766.7 |
| Game | Lone holders (player turns) | 3.3 | 4.7 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +269 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 982
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p30

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 14.3 | -36.5 | 0.0 | 151.3 | 23.3 | +832.4 | 0.0 | 640.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.0 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +0.8 | 0.0 | 0.0 |
| BELL IN A UNIT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 50.3 | 41.7 | - | - | - | - |
| CANNON PLANNED TARGET | 11.0 | +436.5 | 842.0 | 83.3 | 4.0 | +249.1 | 469.3 | 0.0 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +47.9 | 100.7 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 0.7 | +17.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 266.7 |
| CHAFF PASSED | 1.3 | -1.8 | 0.0 | 41.7 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 0.3 | -23.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARACTERS BY THEIR POINTS | 1.3 | -175.8 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 16.3 | -618.4 | 0.0 | 220.7 | 31.7 | -1493.5 | 0.0 | 1432.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 48.3 | 0.0 | 0.7 | +0.0 | 110.3 | 0.0 |
| CLEAR LANE AHEAD | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.0 | +0.0 | 0.0 | 151.3 | 11.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +177.1 | 266.7 | 266.7 |
| COVER ONCE | 9.3 | -670.3 | 0.0 | 125.3 | 4.0 | -99.4 | 0.0 | 32.7 |
| DENIED BY THE FIGHT | 1.0 | -6.8 | 0.0 | 0.0 | 0.3 | -10.2 | 34.7 | 0.0 |
| DEPLOY BY FIGURES | 8.3 | +4.6 | 0.0 | 41.7 | 7.0 | +32.4 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +3.9 | 0.0 | 108.0 |
| EXACT ROUND | 0.7 | +10.3 | 48.3 | 0.0 | 0.3 | +2.4 | 15.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +15.2 | 125.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 25.7 | +270.6 | 0.0 | 450.3 |
| FEATURE BUFFS | 2.0 | +6.9 | 0.0 | 0.0 | 2.0 | +33.4 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 101.3 | +7558.5 | 3398.0 | 538.7 | 97.7 | +6712.1 | 1079.0 | 2114.7 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 90.7 | 3.7 | +0.0 | 0.0 | 65.3 |
| FOUR ROUNDS | 2.0 | +23.9 | 48.3 | 0.0 | 1.0 | +85.9 | 125.3 | 0.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 151.3 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.7 | -72.6 | 0.0 | 0.0 | 0.7 | -9.9 | 0.0 | 0.0 |
| GOAL WALK | 7.7 | +367.3 | 0.0 | 151.3 | 14.3 | +2071.3 | 0.0 | 65.3 |
| GUN FIGURES | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +30.8 | 0.0 | 0.0 |
| GUN MASK | 2.7 | +65.3 | 0.0 | 0.0 | 1.3 | +61.6 | 0.0 | 0.0 |
| HALF WHEN STILL FLEEING | 1.0 | +26.6 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 151.3 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 220.7 | 13.0 | +0.0 | 0.0 | 360.7 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -57.9 | 0.0 | 0.0 | 6.7 | -98.6 | 0.0 | 247.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 100.7 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 15.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.3 | +1036.3 | 0.0 | 372.0 | 78.7 | +6602.6 | 0.0 | 1958.3 |
| HIS SHOTS BY HIS RUN | 34.7 | +669.6 | 0.0 | 220.7 | 60.3 | +1664.5 | 0.0 | 1540.3 |
| HIS TURN DENIED | 1.0 | +76.8 | 0.0 | 0.0 | 0.3 | +10.6 | 34.7 | 0.0 |
| HOLD ODDS | 24.7 | +0.0 | 0.0 | 0.0 | 25.0 | +0.0 | 0.0 | 65.3 |
| HOLDER ASSIGNMENT | 14.3 | +1502.7 | 0.0 | 0.0 | 14.7 | +1532.8 | 0.0 | 32.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -40.7 | 48.3 | 0.0 | 1.0 | -34.8 | 125.3 | 0.0 |
| HUNT IN PAIRS | 1.7 | +406.0 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 14.7 | -304.9 | 0.0 | 734.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 1.3 | +543.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.1 | 0.0 | 0.0 | 0.7 | +37.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 34.7 | - | - | - | - |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -26.8 | 0.0 | 0.0 | 0.3 | +0.1 | 34.7 | 0.0 |
| MAIN BODY KEEPS ITS BAND | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +8.0 | 0.0 | 0.0 | 1.0 | +27.6 | 0.0 | 0.0 |
| MANOEUVRE | 3.3 | +31.3 | 0.0 | 0.0 | 2.7 | +21.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +101.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 4.0 | +376.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.0 | +44.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | +83.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +279.9 | 0.0 | 0.0 | 1.7 | +74.9 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +429.5 | 0.0 | 0.0 | 2.7 | +345.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.0 | +240.3 | 0.0 | 0.0 | 3.3 | +217.6 | 0.0 | 108.0 |
| MISSILES NEXT TURN | 13.7 | +215.4 | 0.0 | 0.0 | 4.3 | +97.8 | 0.0 | 320.7 |
| MISSILES ON ONE TARGET | - | - | - | - | 0.7 | -23.0 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 15.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 266.7 |
| MOVE TO CHARGE COMPUTED | 4.0 | +286.0 | 0.0 | 0.0 | 2.7 | +234.0 | 0.0 | 0.0 |
| NEAR WALKS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 11.3 | +530.7 | 0.0 | 34.7 | 8.3 | +342.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.7 | +166.6 | 0.0 | 0.0 | 3.0 | +305.0 | 0.0 | 0.0 |
| NO CHAFF EDGES | 1.7 | +33.5 | 0.0 | 0.0 | 0.7 | +16.6 | 75.7 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -68.1 | 48.3 | 0.0 | 0.7 | -45.6 | 110.3 | 0.0 |
| NO LATE CUT | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -118.2 | 0.0 | 0.0 | 2.7 | -89.2 | 0.0 | 133.3 |
| OGRE LOADER SECOND SHOT | 2.3 | +65.2 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -53.9 | 0.0 | 0.0 | 4.0 | -114.6 | 0.0 | 50.3 |
| ONE JOINT FIGURE | 1.0 | +333.4 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 6.3 | +131.9 | 0.0 | 0.0 | 6.3 | +96.0 | 0.0 | 32.7 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +15.8 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP IN FULL | 0.3 | +15.8 | 0.0 | 0.0 | 0.3 | +10.5 | 75.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +9.2 | 0.0 | 0.0 | 1.0 | +69.8 | 125.3 | 0.0 |
| OWN CAST FIRST | 0.7 | -3.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 43.7 | +1505.8 | 1111.0 | 379.7 | 44.0 | +608.6 | 310.3 | 1105.7 |
| PRIZE BY WORTH | - | - | - | - | 0.3 | +70.2 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -299.8 | 0.0 | 0.0 | 3.3 | -23.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.1 | 0.0 | 0.0 | 0.7 | -5.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 18.0 | +1922.3 | 402.7 | 83.3 | 18.3 | +1355.8 | 280.0 | 316.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +206.7 | 0.0 | 193.3 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -22.9 | 0.0 | 0.0 | 1.0 | -48.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +14.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | -20.1 | 0.0 | 0.0 | 1.0 | -157.3 | 125.3 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 0.3 | -0.1 | 48.3 | 0.0 | 0.7 | -3.7 | 110.3 | 0.0 |
| SCOUT BY DROPS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +76.0 | 0.0 | 0.0 | 0.3 | +7.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.3 | -153.0 | 0.0 | 0.0 | 0.3 | -26.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.0 | +149.5 | 0.0 | 0.0 | 0.7 | +8.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +8.0 | 0.0 | 0.0 | 1.0 | +27.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 16.3 | +0.0 | 0.0 | 83.3 | 7.0 | +0.0 | 0.0 | 54.0 |
| SHOOTS FROM THE BEST SPOT | 6.3 | +514.8 | 699.7 | 0.0 | 1.7 | +27.1 | 83.3 | 108.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -8.8 | 15.0 | 0.0 |
| SHOT RISK POINTS | 14.7 | -198.2 | 0.0 | 220.7 | 46.0 | +112.2 | 0.0 | 1555.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 29.3 | +1659.7 | 0.0 | 269.3 | 13.3 | +767.4 | 0.0 | 241.3 |
| SPELL WORTH | - | - | - | - | 3.0 | +48.7 | 266.7 | 266.7 |
| SPELLS IN THE FIGHT | 0.3 | +4.3 | 48.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 230.0 |
| STAND AND SHOOT | 0.3 | -4.9 | 0.0 | 0.0 | 0.7 | -3.6 | 110.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.0 | +0.0 | 0.0 | 266.7 |
| STANDS STILL | 49.3 | +0.0 | 3349.7 | 166.7 | 35.3 | +0.0 | 953.7 | 572.0 |
| STAY WORTH | 42.7 | -106.5 | 1732.0 | 235.3 | 19.7 | +566.8 | 772.0 | 320.7 |
| STRIKE BY THE ODDS | 0.7 | +21.9 | 46.7 | 0.0 | 0.7 | +2.8 | 20.0 | 0.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 1.3 | -14.4 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +193.3 | 0.0 | 0.0 | 3.7 | +131.8 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +193.3 | 0.0 | 0.0 | 3.7 | +131.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +2.1 | 0.0 | 0.0 | 1.3 | +44.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 1.3 | +38.4 | 0.0 | 0.0 | 0.3 | +1.6 | 34.7 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 75.7 | 6.0 | +0.0 | 0.0 | 159.7 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 75.7 | 4.0 | +0.0 | 0.0 | 100.7 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 50.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.0 | +0.0 | 0.0 | 269.3 | 45.7 | +0.0 | 0.0 | 960.7 |
| TIED UP BY THE SUM | 0.3 | +27.9 | 0.0 | 0.0 | 0.7 | +101.0 | 110.3 | 0.0 |
| TIME ON OUR SIDE | 39.0 | +553.9 | 0.0 | 186.0 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +22.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -34.8 | 0.0 | 0.0 | 2.7 | -265.2 | 0.0 | 295.3 |
| WHOLE FIGHT GAIN | 1.0 | +48.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT REACTION | 1.7 | +179.3 | 0.0 | 125.3 | 0.7 | +314.5 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +56.8 | 0.0 | 0.0 | 3.3 | +85.1 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p30

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 113 | 113 | 92 | 30.67 | +2593 | +28.2 |
| HIS SHOT LIST | 330 | 321 | 81 | 27.00 | +2208 | +27.3 |
| HOLDER ASSIGNMENT | 87 | 87 | 78 | 26.00 | +5042 | +64.6 |
| HIS SHOTS BY HIS RUN | 285 | 278 | 69 | 23.00 | +1079 | +15.6 |
| SHOT RISK POINTS | 182 | 177 | 36 | 12.00 | +1180 | +32.8 |
| DEPLOY BY FIGURES | 46 | 46 | 29 | 9.67 | +567 | +19.6 |
| GOAL WALK | 66 | 66 | 24 | 8.00 | +1914 | +79.7 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -622 | -29.6 |
| FIVE ACTION | 597 | 586 | 20 | 6.67 | +1050 | +52.5 |
| MOVE TO CHARGE COMPUTED | 20 | 19 | 16 | 5.33 | +682 | +42.6 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 16 | 5.33 | +643 | +40.2 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 36 | 36 | 14 | 4.67 | -971 | -69.4 |
| TIME ON OUR SIDE | 117 | 99 | 14 | 4.67 | +44 | +3.1 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| CHARGE LOSSES | 144 | 141 | 11 | 3.67 | +740 | +67.3 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 17 | 17 | 11 | 3.67 | +575 | +52.3 |
| QUARTER ODDS | 109 | 107 | 11 | 3.67 | +1133 | +103.0 |
| SUPPORT ADDS | 19 | 19 | 10 | 3.33 | +469 | +46.9 |
| SUPPORT WORKED OUT | 19 | 19 | 10 | 3.33 | +469 | +46.9 |
| MARCH CHECK | 12 | 12 | 9 | 3.00 | +382 | +42.4 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +620 | +68.9 |
| STAY WORTH | 187 | 163 | 9 | 3.00 | +115 | +12.7 |
| CANNON SIGHT KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 44 | 39 | 7 | 2.33 | +110 | +15.8 |
| MAIN BODY KEEPS ITS BAND | 7 | 7 | 7 | 2.33 | +1246 | +177.9 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +196 | +27.9 |
| NO CHAFF EDGES | 7 | 7 | 6 | 2.00 | +119 | +19.8 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| MANOEUVRE | 18 | 18 | 5 | 1.67 | +175 | +34.9 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +760 | +152.1 |
| SHOTS AFTER THE MOVES | 25 | 25 | 5 | 1.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +53 | +13.3 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -5 | -1.3 |
| CLEAR LANE AHEAD | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 77 | 63 | 4 | 1.33 | +69 | +17.3 |
| GUN MASK | 12 | 12 | 4 | 1.33 | +169 | +42.2 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +1631 | +407.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +147 | +36.7 |
| SHOTS IN THE MOVE | 128 | 95 | 4 | 1.33 | +53 | +13.4 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +74 | +18.6 |
| WOUNDS ON THE RANKS | 18 | 18 | 4 | 1.33 | +51 | +12.8 |
| CANNON PLANNED TARGET | 45 | 45 | 3 | 1.00 | +111 | +37.0 |
| FOUR ROUNDS | 9 | 9 | 3 | 1.00 | +117 | +38.9 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HUNT IN PAIRS | 5 | 5 | 3 | 1.00 | +434 | +144.6 |
| LEGAL CHARGES ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +305 | +101.6 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -133 | -44.3 |
| NEARER NOT NEEDED | 59 | 55 | 3 | 1.00 | +42 | +13.9 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +779 | +259.7 |
| SURE REACH TOGETHER | 6 | 5 | 3 | 1.00 | +63 | +20.9 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +147 | +49.1 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +3 | +1.4 |
| CHARGE NOW FIRST | 3 | 3 | 2 | 0.67 | -84 | -42.0 |
| COVER ONCE | 40 | 28 | 2 | 0.67 | +23 | +11.7 |
| MAX FOR POSITIONING | 20 | 16 | 2 | 0.67 | +51 | +25.6 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +634 | +317.2 |
| ONE OBJECTIVE FORMULA | 38 | 24 | 2 | 0.67 | +69 | +34.6 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -11 | -5.5 |
| PROMISE READS THE TABLE | 3 | 3 | 2 | 0.67 | +102 | +51.1 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -0 | -0.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +44 | +21.8 |
| SCOUT BY DROPS | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +251 | +125.7 |
| SET UP BY THE SET | 11 | 11 | 2 | 0.67 | +90 | +45.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| THE ROW IN ITS ORDER | 24 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT REACTION | 7 | 7 | 2 | 0.67 | +61 | +30.5 |
| BELL IN A UNIT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 43 | 33 | 1 | 0.33 | +1 | +0.9 |
| ONE FIGHT FORMULA | 23 | 14 | 1 | 0.33 | +1 | +0.9 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +33 | +33.2 |
| PRIZE BY WORTH | 1 | 1 | 1 | 0.33 | +211 | +210.7 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -31 | -31.2 |
| SET UP TOGETHER | 5 | 4 | 1 | 0.33 | +18 | +17.5 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +60 | +59.7 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 18 | 18 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 12 | 12 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 10 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HALF WHEN STILL FLEEING | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 57 | 57 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 8 | 8 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 31 | 31 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 33 | 31 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 17 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 46 | 44 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HOLD ODDS | 149 | 149 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 54 | 41 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEAR WALKS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 6 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OPENS UP IN FULL | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 263 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 5 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 70 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 38 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 254 | 245 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE FIGHT MOVES | 5 | 5 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 26 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 272 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 16 | 16 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p30

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 2.00 | 30.2 |
| ARMY TABLE | rule | 2.33 | 2.33 | 87.4 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 0.33 | 69.4 |
| CHAFF PASSED | rule | 1.00 | - | 1.8 |
| MARCH OF THE TABLE | rule | 1.00 | - | 44.3 |
| CHARGE NOW FIRST | rule | - | 0.67 | 42.0 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 33.9 |
| OWN CAST FIRST | rule | 0.67 | - | 5.5 |
| RULE SWITCHED OFF | gate | - | 0.67 | 24.0 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 21.2 |
| REFUSING RETIRES | rule | - | 0.33 | 31.2 |

### Plans: nw22-19bea9b-p30

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 52 | 48 | 93% |
| Mine | move | 28.7 | 98% | 1641 | 0 | 0% |
| Mine | shoot | 14.3 | 81% | 1142 | 1457 | 128% |
| Opponent | charge | 0.7 | 100% | 77 | 110 | 143% |
| Opponent | move | 37.0 | 95% | 2389 | 0 | 0% |
| Opponent | shoot | 6.3 | 63% | 584 | 498 | 85% |

### Deployment: positions vs output by unit type: nw22-19bea9b-p30

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 15 (10) | 15 | 0 | 16 | 40% | 3.0 | 19 (5) | 5 (4) | 0 (1) | 20 (6) | 5 (4) |
| Mine | Clean-up | 3 | 93 (3) | 0 | 93 | 0 | 67% | 4.0 | - | 92 (2) | 95 (1) | 93 (3) | - |
| Mine | Fast Hammer | 3 | 9 (3) | 9 | 0 | 0 | 0% | 4.0 | 13 (2) | - | 0 (1) | 9 (3) | - |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 32 | 50% | 1.3 | 0 (2) | 0 (4) | - | 0 (4) | 0 (2) |
| Mine | Shooter | 6 | 186 (6) | 66 | 120 | 17 | 0% | 1.2 | 119 (2) | 216 (3) | 231 (1) | 187 (5) | 181 (1) |
| Mine | War machine | 8 | 109 (8) | 109 | 0 | 23 | 0% | 1.5 | - | 147 (3) | 89 (5) | - | 109 (8) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 25 | 25% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Chaff | 2 | 72 (2) | 0 | 72 | 0 | 100% | - | - | 72 (2) | - | 129 (1) | 0 (1) |
| Opponent | Character | 8 | 17 (8) | 17 | 0 | 46 | 38% | 2.8 | 47 (1) | 0 (4) | 42 (2) | 21 (6) | 0 (1) |
| Opponent | Clean-up | 2 | 232 (2) | 0 | 232 | 0 | 100% | - | - | 232 (2) | - | 232 (2) | - |
| Opponent | Fast Hammer | 6 | 31 (6) | 0 | 31 | 41 | 83% | 3.0 | - | 25 (4) | 48 (2) | 43 (5) | 0 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 5 | 31 (5) | 31 | 0 | 32 | 20% | 3.5 | - | 0 (2) | 51 (3) | 0 (4) | 160 (1) |
| Opponent | Holder | 4 | 8 (4) | 0 | 8 | 0 | 100% | - | - | 15 (2) | 0 (1) | 0 (2) | 27 (1) |
| Opponent | Shooter | 4 | 48 (4) | 48 | 0 | 35 | 0% | 1.8 | - | 0 (1) | 56 (3) | 48 (4) | - |
| Opponent | War machine | 2 | 89 (2) | 89 | 0 | 0 | 0% | 1.0 | - | - | 89 (2) | 179 (1) | 0 (1) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | 0 (1) | - |

### Charged fights: nw22-19bea9b-p30

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 640 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 290 | 140 | 2.0 | 2.5 | 70 | 0 | +70 | 1 of 2 | 2 of 2 | +140 | +0 |
| **Mine** | all armies | 3 | 523 | 47 | 0.7 | 2.5 | 70 | 0 | +70 | 1 of 2 | 2 of 2 | +140 | +0 |
| Opponent | High Elf Realms | 1 | 352 | 104 | 1.0 | 1.0 | 104 | 0 | +104 | 0 of 1 | 1 of 1 | - | +104 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 277 | 1.0 | 1.0 | 277 | 0 | +277 | 0 of 1 | 1 of 1 | - | +277 |
| **Opponent** | all armies | 3 | 117 | 127 | 0.7 | 1.0 | 190 | 0 | +190 | 0 of 2 | 2 of 2 | - | +190 |

### Effective charges: nw22-19bea9b-p30

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 1 (net +0) | 1 (net +140) | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +104) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p30

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 369 | 145 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 1070 | 222 | +140 | 295 | 80 | +215 | +20.1 |
| Mine | All fights | 2 | 720 | 184 | +70 | 147 | 40 | +108 | +14.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 104 | +104 | 104 | 0 | +104 | +42.1 |
| Opponent | No odds | 1 | 173 | 189 | +277 | 372 | 23 | +348 | +201.4 |
| Opponent | All fights | 2 | 210 | 146 | +190 | 238 | 12 | +226 | +107.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p30 | move | 15 | 2 (13%) | 2 (13%) | 4 (27%) | 9 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

# Doctrine scorecard: nw22-19bea9b-p28

### Scorecard: nw22-19bea9b-p28

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 473 |
| L0524 | 2 | 1 | Opponent | - | - | 6 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 675 |
| L0612 | 6 | 1 | Opponent | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 395 |
| L0628 | 4 | 1 | Opponent | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 3.0 | 0.7 | 3.0 | 0.0 | 0.0 | 0.0 | 514.3 |
| **Average** | | | Opponent | 0% | 6.0 | 6.0 | 0.0 | 2.3 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: nw22-19bea9b-p28

Rules off - Opponent only: NEAR WALKS ONLY.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 93% (14 of 15) | 0% (0 of 15) | 47% (14 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 53% (16 of 30) | 53% (16 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 55% (16 of 29) | 55% (16 of 29) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 86% (5182 of 6000) | 95% (5726 of 5998) | 91% (10908 of 11998) |
|   infantry points that never fought | lower | 89% (1993 of 2232) | 100% (694 of 694) | 92% (2687 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (18 of 27) | 61% (14 of 23) | 64% (32 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (2433 of 4232) | 67% (3870 of 5787) | 63% (6303 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (21%) | 1.0 (21%) |
| MARCHED: its unit marched | - | 3.0 (64%) | 3.0 (64%) |
| CHARGED: its unit charged | - | 0.3 (7%) | 0.3 (7%) |
| GONE: slain | - | 0.3 (7%) | 0.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 1.7 | 5.3 | 1.0 | 0.0 |
| not cast | 2.3 | 2.3 | 4.7 | 3.0 | 24.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (71%) | 1.0 (21%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.0 (64%) | 1.3 (44%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.3 (11%) | 0.0 (0%) |
| GONE: slain | 0.3 (14%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 1.0 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) | 1.3 (44%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (86%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.0 (96%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (142 of 203) | 86% (12 of 14) | 71% (154 of 217) |
|   cavalry | 62% (10 of 16) | 0% (0 of 2) | 56% (10 of 18) |
|   character | 88% (28 of 32) | - | 88% (28 of 32) |
|   infantry | 46% (26 of 56) | - | 46% (26 of 56) |
|   monster | 83% (10 of 12) | - | 83% (10 of 12) |
|   war machine | 78% (68 of 87) | 100% (12 of 12) | 81% (80 of 99) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 6.0 (30%) | 0.0 (0%) | 6.0 (29%) |
| CHARGED: it charged | 1.0 (5%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET IN RANGE | 7.3 (36%) | 0.7 (100%) | 8.0 (38%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (16%) | 0.0 (0%) | 3.3 (16%) |
| SHELTERED: the target was sheltered | 2.0 (10%) | 0.0 (0%) | 2.0 (10%) |
| STUPIDITY | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 1.7 | 60% | 15.6 pts | 52 pts |
| character | 9.3 | 4.7 | 71% | 13.6 pts | 127 pts |
| infantry | 16.7 | 5.7 | 74% | 11.5 pts | 191 pts |
| monster | 3.3 | 0.7 | 80% | 6.5 pts | 22 pts |
| war machine | 27.0 | 14.3 | 74% | 18.7 pts | 506 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 0.7 | 0.8 |
| Charges that made contact a game | 0.7 | 0.3 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.33 declared, 0.33 contact (3 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.14 declared, 0.10 contact (21 units) | 0.08 declared, 0.00 contact (13 units) | 0.12 declared, 0.06 contact (34 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | 100% (1 of 1) | 50% (1 of 2) | 43% (3 of 7) |
| Character in a unit | 75% (6 of 8) | 75% (3 of 4) | 100% (1 of 1) | 77% (10 of 13) |
| Character on its own | - | 100% (3 of 3) | 50% (1 of 2) | 80% (4 of 5) |
| Infantry | 43% (3 of 7) | 33% (2 of 6) | - | 38% (5 of 13) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 86% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 56% (10 of 18) | 100% | 33% (3 of 9) | 100% (3 of 3); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 92% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 83% (5 of 6) | 94% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (nw22-19bea9b-p28, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 50% (1) | 33% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: nw22-19bea9b-p28

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | 100% (1 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 58% (49 of 85) | 53% (9 of 17) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 3) |
| Strategy | Joined characters whose unit fought | 25% (3 of 12) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 0% (0 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.3 |
| Movement | Points that never moved of their own | 514.3 | 110.0 |
| Movement | Fights charged into per game | 0.7 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 1 of 1, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +161 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 25.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (45 of 76) | - |
| Shooting | Points destroyed by shooting units | 213.3 | 0.0 |
| Shooting | War machine shots | 22.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (44 of 68) | 8% (1 of 12) |
| Shooting | Points destroyed by war machines | 0.0 | 98.3 |
| Magic | Magic missiles cast | - | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 50% (5 of 10) |
| Magic | Wounds caused by magic missiles | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 3.7 / 1.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 53.7 | 0.0 |
| Combat | Points run down | 37.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +174 | +0 |
| Combat | Net per 100 charger points, damage counted | +116.1 | +0.0 |
| Combat | First round won (charged fights) | 100% | - |
| Combat | Net points per charged fight | +136 | +0 |
| Combat | Net points per supported fight / lone fight | - / +136 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 0 of 1 |
| Game | Points lost | 243.3 | 270.7 |
| Game | VP from objectives | 690.0 | 530.0 |
| Game | Lone holders (player turns) | 2.0 | 6.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +240 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 514
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: nw22-19bea9b-p28

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 5.3 | +113.4 | 0.0 | 0.0 | 13.3 | +307.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 31.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 158.3 | 38.3 | - | - | - | - |
| CANNON PLANNED TARGET | 19.3 | +131.5 | 633.3 | 243.3 | 4.0 | +183.0 | 138.3 | 110.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.0 | +22.5 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +34.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +1.6 | 0.0 | 53.7 |
| CHARACTER GUNS | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTERS BY THEIR POINTS | 0.3 | +7.3 | 53.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 7.0 | -187.5 | 0.0 | 0.0 | 25.0 | -1122.1 | 0.0 | 434.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 343.0 | 0.0 | 0.3 | +0.0 | 0.0 | 53.7 |
| CLEAR LANE AHEAD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 11.0 | -876.1 | 0.0 | 0.0 | 4.7 | -114.0 | 0.0 | 289.3 |
| DEPLOY BY FIGURES | 12.7 | -143.8 | 0.0 | 20.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| EXACT ROUND | 0.7 | +4.0 | 37.0 | 0.0 | 0.7 | +1.5 | 31.7 | 53.7 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 37.0 | 0.0 | 0.7 | +0.1 | 31.7 | 53.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 24.3 | +288.0 | 0.0 | 340.0 |
| FEATURE BUFFS | 0.7 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +0.3 | 37.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 129.3 | +5318.4 | 2569.3 | 630.0 | 70.3 | +2145.5 | 268.3 | 953.7 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 289.3 |
| FOLLOW UP WEIGHED | 0.3 | +37.2 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.0 | +35.1 | 90.7 | 0.0 | 0.7 | +6.4 | 31.7 | 53.7 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -10.3 | 0.0 | 0.0 | 1.7 | -58.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -3.6 | 37.0 | 0.0 | - | - | - | - |
| GOAL WALK | 4.0 | +302.1 | 0.0 | 0.0 | 3.7 | +409.6 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +7.2 | 0.0 | 38.3 | - | - | - | - |
| GUN MASK | 2.7 | +3.6 | 0.0 | 0.0 | 2.0 | +82.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 3.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 434.0 |
| HIS CHARGE DENIED | 0.3 | +12.7 | 53.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 14.0 | +0.0 | 0.0 | 63.3 | 7.7 | +0.0 | 0.0 | 218.7 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 144.7 |
| HIS MOVE AND SHOT | 3.7 | -38.2 | 0.0 | 0.0 | 6.3 | -48.8 | 0.0 | 289.3 |
| HIS ONE QUARTER | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 144.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.3 | +1042.1 | 0.0 | 143.3 | 47.0 | +4238.6 | 0.0 | 680.0 |
| HIS SHOTS BY HIS RUN | 26.7 | +554.0 | 0.0 | 80.0 | 43.7 | +1276.5 | 0.0 | 680.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 0.0 | 14.3 | +0.0 | 0.0 | 74.0 |
| HOLDER ASSIGNMENT | 12.3 | +1052.9 | 0.0 | 0.0 | 8.7 | +1003.8 | 0.0 | 37.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -22.3 | 53.7 | 0.0 | 0.7 | -9.9 | 31.7 | 53.7 |
| IDLE COST | - | - | - | - | 17.7 | -399.5 | 0.0 | 289.3 |
| INFANTRY NOT BEHIND INFANTRY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 107.3 |
| LONG SHOT | 0.3 | -0.4 | 53.7 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +3.0 | 37.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAIN BODY KEEPS ITS BAND | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 1.7 | +98.0 | 0.0 | 0.0 |
| MANOEUVRE | 2.3 | -19.7 | 0.0 | 0.0 | 1.7 | +9.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 1.7 | +87.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.7 | +152.6 | 0.0 | 144.7 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +46.1 | 0.0 | 144.7 |
| MARCH OVER CASTS | - | - | - | - | 2.3 | +52.0 | 0.0 | 144.7 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | - | - | - | - | 3.3 | +27.3 | 0.0 | 289.3 |
| MEETS IN TIME | 9.0 | +209.9 | 0.0 | 20.0 | 2.0 | +354.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 8.0 | +53.0 | 0.0 | 144.7 |
| MISSILES NEXT TURN | - | - | - | - | 10.3 | +55.2 | 0.0 | 289.3 |
| MODEL FACING | 4.0 | +1009.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +46.9 | 0.0 | 0.0 | 3.0 | +135.9 | 0.0 | 144.7 |
| NEAR WALKS ONLY | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.0 | +230.6 | 0.0 | 0.0 | 4.3 | +173.8 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.7 | +32.9 | 0.0 | 0.0 | 2.0 | +104.7 | 0.0 | 144.7 |
| NEXT OBJECTIVE NEARER | 1.3 | -40.0 | 0.0 | 0.0 | - | - | - | - |
| NO CHAFF EDGES | 0.3 | +0.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -12.2 | 90.7 | 0.0 | 0.7 | -4.8 | 31.7 | 53.7 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.7 | -297.3 | 37.0 | 31.7 | 5.3 | -160.5 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 3.7 | +7.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.0 | -8.9 | 0.0 | 0.0 | 5.0 | -116.6 | 0.0 | 303.0 |
| ONE OBJECTIVE FORMULA | 5.3 | +67.4 | 0.0 | 0.0 | 2.3 | -153.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +9.7 | 40.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +24.6 | 0.0 | 0.0 |
| PLAN RESULT | 57.3 | +1875.0 | 702.0 | 336.7 | 32.3 | +134.8 | 20.0 | 608.0 |
| PROMISE BY ITS OWN SUM | 5.3 | -127.1 | 0.0 | 0.0 | 6.0 | -32.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.3 | -30.5 | 0.0 | 0.0 |
| QUARTER ODDS | 15.3 | +992.7 | 0.0 | 0.0 | 2.7 | +925.7 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.0 | +41.0 | 0.0 | 0.0 | 1.3 | +66.8 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -48.9 | 0.0 | 0.0 | 1.0 | -6.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | +28.1 | 37.0 | 0.0 | 0.3 | +28.5 | 0.0 | 53.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | 0.7 | -8.8 | 37.0 | 0.0 | 0.3 | -0.4 | 0.0 | 53.7 |
| SCOUT BY DROPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -62.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +15.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +0.1 | 37.0 | 0.0 | 0.3 | +3.4 | 0.0 | 53.7 |
| SET CREDITED ONCE | - | - | - | - | 3.0 | -155.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +11.3 | 0.0 | 0.0 | 4.0 | +143.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 2.7 | +103.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 29.3 | +0.0 | 0.0 | 243.3 | 6.7 | +0.0 | 0.0 | 110.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +123.5 | 289.3 | 0.0 | 1.3 | +79.9 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 18.3 | +330.6 | 0.0 | 80.0 | 31.0 | -935.2 | 0.0 | 172.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 38.7 | +1368.3 | 0.0 | 243.3 | 4.0 | +205.8 | 0.0 | 110.0 |
| SPELL WORTH | - | - | - | - | 5.7 | +149.6 | 289.3 | 289.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +0.5 | 31.7 | 0.0 |
| SPOT AS THE GAME MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 144.7 |
| STANDS FOR A REASON | - | - | - | - | 5.3 | +0.0 | 0.0 | 144.7 |
| STANDS STILL | 98.7 | +0.0 | 2478.7 | 630.0 | 18.7 | +0.0 | 236.7 | 294.0 |
| STAY WORTH | 64.3 | +202.8 | 1610.7 | 405.0 | 10.0 | +97.7 | 236.7 | 165.0 |
| STRONG ENOUGH TO HOLD | - | - | - | - | 2.3 | -49.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +175.3 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +175.3 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.3 | +0.4 | 0.0 | 0.0 | 1.7 | +44.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE FIGHT MOVES | 0.7 | +0.2 | 37.0 | 0.0 | 0.3 | +0.1 | 31.7 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 56.0 | +0.0 | 0.0 | 243.3 | 36.3 | +0.0 | 0.0 | 450.0 |
| TIED UP BY THE SUM | 0.3 | +11.3 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 54.7 | +585.3 | 289.3 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +1.1 | 0.0 | 0.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 144.7 |
| WALKS ON ITS ROUTE | 1.0 | -70.8 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -2.9 | 37.0 | 0.0 | 0.3 | +1.7 | 0.0 | 53.7 |
| WHOLE FIGHT DANGER | 0.7 | -13.3 | 0.0 | 0.0 | 1.3 | -115.0 | 0.0 | 289.3 |
| WHOLE FIGHT REACTION | 0.3 | +23.6 | 0.0 | 31.7 | 0.7 | +7.5 | 0.0 | 37.0 |
| WOUNDS ON THE RANKS | 3.7 | +70.6 | 0.0 | 0.0 | 6.3 | +589.0 | 0.0 | 0.0 |

### Rule changes: nw22-19bea9b-p28

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 259 | 249 | 86 | 28.67 | +2236 | +26.0 |
| HOLDER ASSIGNMENT | 63 | 63 | 59 | 19.67 | +3899 | +66.1 |
| HIS SHOTS BY HIS RUN | 211 | 197 | 56 | 18.67 | +798 | +14.3 |
| ARMY TABLE | 56 | 56 | 51 | 17.00 | +1233 | +24.2 |
| SHOT RISK POINTS | 148 | 143 | 38 | 12.67 | +1037 | +27.3 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -1374 | -38.2 |
| DEPLOY BY FIGURES | 51 | 51 | 32 | 10.67 | +306 | +9.6 |
| TIME ON OUR SIDE | 164 | 145 | 28 | 9.33 | +106 | +3.8 |
| IDLE COST | 53 | 38 | 16 | 5.33 | +233 | +14.6 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MEETS IN TIME | 33 | 33 | 14 | 4.67 | +432 | +30.9 |
| CHARGE LOSSES | 96 | 93 | 12 | 4.00 | +770 | +64.1 |
| FIVE ACTION | 599 | 582 | 12 | 4.00 | +258 | +21.5 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +3028 | +252.3 |
| PROMISE BY ITS OWN SUM | 34 | 34 | 12 | 4.00 | -478 | -39.9 |
| THE TABLE AGAIN | 36 | 36 | 12 | 4.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 17 | 16 | 11 | 3.67 | +214 | +19.4 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +24 | +2.2 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| COVER ONCE | 47 | 39 | 10 | 3.33 | +10 | +1.0 |
| GOAL WALK | 23 | 21 | 10 | 3.33 | +1228 | +122.8 |
| WOUNDS ON THE RANKS | 30 | 28 | 10 | 3.33 | +254 | +25.4 |
| CANNON PLANNED TARGET | 70 | 70 | 9 | 3.00 | -10 | -1.1 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 7 | 2.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 11 | 11 | 6 | 2.00 | +157 | +26.1 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 6 | 2.00 | +259 | +43.1 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +262 | +52.5 |
| CAST JOB | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 73 | 64 | 4 | 1.33 | +49 | +12.2 |
| FOUR ROUNDS | 5 | 4 | 4 | 1.33 | +56 | +14.0 |
| MARCH CHECK | 5 | 4 | 4 | 1.33 | +233 | +58.2 |
| QUARTER ODDS | 54 | 54 | 4 | 1.33 | +173 | +43.2 |
| SUPPORT ADDS | 8 | 8 | 4 | 1.33 | +23 | +5.6 |
| SUPPORT WORKED OUT | 8 | 8 | 4 | 1.33 | +23 | +5.6 |
| SURE REACH TOGETHER | 6 | 6 | 4 | 1.33 | +12 | +2.9 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAIN BODY KEEPS ITS BAND | 3 | 3 | 3 | 1.00 | +532 | +177.2 |
| MOVE ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 23 | 18 | 3 | 1.00 | +32 | +10.6 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +74 | +24.6 |
| THE ROW IN ITS ORDER | 10 | 3 | 3 | 1.00 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 3 | 3 | 3 | 1.00 | -212 | -70.8 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 4 | 4 | 2 | 0.67 | -63 | -31.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| LEGAL CHARGES ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 10 | 10 | 2 | 0.67 | +2 | +0.8 |
| NO CHAFF EDGES | 2 | 2 | 2 | 0.67 | +0 | +0.2 |
| RISK BY ARC | 3 | 2 | 2 | 0.67 | +19 | +9.5 |
| SCOUT BY DROPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +10 | +5.2 |
| SHOTS IN THE MOVE | 128 | 103 | 2 | 0.67 | +66 | +33.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| CLEAR LANE AHEAD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +112 | +111.6 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +28 | +27.7 |
| HONEST WORTH | 4 | 4 | 1 | 0.33 | +0 | +0.5 |
| INFANTRY NOT BEHIND INFANTRY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +29 | +28.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -138 | -138.2 |
| MISSILES IN THE MOVE | 24 | 16 | 1 | 0.33 | +1 | +1.3 |
| MISSILES NEXT TURN | 31 | 24 | 1 | 0.33 | +3 | +3.1 |
| NEARER NOT NEEDED | 28 | 26 | 1 | 0.33 | +37 | +37.4 |
| NO DOUBLE ROUNDS | 5 | 4 | 1 | 0.33 | +0 | +0.5 |
| ONE FIGHT FORMULA | 21 | 18 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -30 | -30.1 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | +26 | +26.5 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 7 | 7 | 1 | 0.33 | +42 | +41.9 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +48 | +47.7 |
| SET UP BY THE SET | 13 | 11 | 1 | 0.33 | +57 | +57.4 |
| STAY WORTH | 223 | 205 | 1 | 0.33 | +4 | +3.8 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +16 | +16.2 |
| WHO FIGHTS | 2 | 1 | 1 | 0.33 | +3 | +2.8 |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 13 | 12 | 0 | 0.00 | - | - |
| CHARACTERS BY THEIR POINTS | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 52 | 45 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 3 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| GUN MASK | 14 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 38 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 65 | 65 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 23 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 30 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 2 | 2 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 31 | 28 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 90 | 89 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| NEAR WALKS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 7 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 8 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 108 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 20 | 17 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 352 | 345 | 0 | 0.00 | - | - |
| STRONG ENOUGH TO HOLD | 7 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE FIGHT MOVES | 3 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 277 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 8 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT REACTION | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: nw22-19bea9b-p28

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 4.33 | 39.5 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 1.00 | 39.9 |
| ARMY TABLE | rule | 0.67 | 1.33 | 1.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 16.6 |
| RULE SWITCHED OFF | gate | - | 1.00 | 18.9 |
| WALKS ON ITS ROUTE | rule | 1.00 | - | 70.8 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 5.1 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 31.7 |
| NO REASON | gate | 0.67 | - | 46.1 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| MARCH OF THE TABLE | rule | - | 0.33 | 138.2 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 30.1 |

### Plans: nw22-19bea9b-p28

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 72 | 95 | 133% |
| Mine | join | 2.0 | 100% | 70 | 0 | 0% |
| Mine | move | 30.7 | 98% | 1258 | 0 | 0% |
| Mine | shoot | 23.7 | 56% | 1048 | 1780 | 170% |
| Opponent | charge | 0.3 | 0% | 3 | 14 | 425% |
| Opponent | join | 2.0 | 100% | 93 | 0 | 0% |
| Opponent | move | 25.7 | 96% | 859 | 0 | 0% |
| Opponent | shoot | 3.7 | 45% | 216 | 120 | 56% |
| Opponent | support | 0.7 | 100% | 15 | 0 | 0% |

### Battle groups: nw22-19bea9b-p28

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 33% | 100% | 100% | 100% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.3 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: nw22-19bea9b-p28

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 8 (13) | 8 | 0 | 0 | 38% | 2.5 | 16 (5) | 0 (7) | 0 (1) | 9 (11) | 0 (2) |
| Mine | Clean-up | 4 | 58 (4) | 18 | 39 | 0 | 75% | 1.0 | - | 44 (3) | 185 (1) | 58 (4) | - |
| Mine | Fast | 3 | 73 (3) | 73 | 0 | 27 | 33% | 1.0 | - | 275 (1) | 0 (2) | 73 (3) | - |
| Mine | Hammer | 4 | 93 (4) | 7 | 87 | 0 | 50% | 2.0 | 17 (1) | 147 (3) | - | 93 (4) | - |
| Mine | Holder | 2 | 215 (2) | 118 | 98 | 0 | 0% | 1.5 | 0 (1) | 427 (1) | - | 427 (1) | 0 (1) |
| Mine | Shooter | 6 | 35 (6) | 5 | 30 | 0 | 17% | 3.0 | 73 (2) | 0 (1) | 9 (3) | 43 (5) | 0 (1) |
| Mine | War machine | 17 | 0 (17) | 0 | 0 | 36 | 12% | 1.4 | 0 (4) | 0 (9) | 0 (4) | 0 (3) | 0 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 25 | 100% | - | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 2 (10) | 2 | 0 | 18 | 70% | 1.0 | 0 (2) | 4 (6) | 0 (2) | 3 (9) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 3 | 18 (3) | 0 | 18 | 0 | 100% | - | - | 30 (2) | 0 (1) | 25 (2) | 0 (1) |
| Opponent | Holder | 6 | 81 (6) | 0 | 81 | 10 | 67% | 2.0 | - | 81 (6) | - | 125 (4) | 7 (2) |
| Opponent | War machine | 2 | 89 (2) | 89 | 0 | 50 | 0% | 1.0 | - | 109 (1) | 70 (1) | - | 89 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: nw22-19bea9b-p28

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 213 | 91 | 0.7 | 1.0 | 136 | 0 | +136 | 0 of 2 | 2 of 2 | - | +136 |
| Opponent | Grand Cathay | 1 | 355 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 0 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 118 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 0 | - | +0 |

### Effective charges: nw22-19bea9b-p28

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +161) | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: nw22-19bea9b-p28

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 239 | 161 | +161 | 184 | 104 | +81 | +33.8 |
| Mine | No odds | 1 | 60 | 111 | +111 | 306 | 39 | +267 | +444.2 |
| Mine | All fights | 2 | 150 | 136 | +136 | 245 | 72 | +174 | +116.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 470 | 95 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 1 | 470 | 95 | +0 | 0 | 0 | +0 | +0.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| nw22-19bea9b-p28 | move | 14 | 0 (0%) | 0 (0%) | 1 (7%) | 13 (93%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |
